Dim tdc
Dim qcServer As String
Dim strName As String
Dim strPass As String

Set tdc = CreateObject("TDApiOle80.TDConnection")
tdc.InitConnectionEx "https://almtrizetto1253.saas.microfocus.com/qcbin"
tdc.login "715241", "QwasZ2019$"
tdc.Connect "T3_PALM", "TMS"


'if connection fails exit function and display error message
If (tdc Is Nothing) Then
MsgBox errmsg
End If

'walk the folder list


 

Set testSetF = tdc.TestSetTreeManager

Set Root = testSetF.Root
Set TestFolderNode = Root.FindChildNode("bobt 3.5") ' 
Set lstNodes = TestFolderNode.SubNodes() 


For i = 1 To lstNodes.Count - 1
      Set SubNode = TestFolderNode.FindChildNode(lstNodes.Item(i))
       msgbox SubNode.NodeID & " " & SubNode.Name
Next

 


If tdc Is Nothing Then Exit Sub

'If tdc is connected disconnect
If tdc.Connected Then
tdc.Disconnect
End If

'if tdc is logged in than logout
If tdc.LoggedIn Then
tdc.Logout
End If

'Release the Connection
tdc.ReleaseConnection
Set tdc = Nothing