'QA - Dazzlers

ASP-TMS-SQL-342	QA	Dev-Int Deployment 2017
ASP-TMS-SQL-102	QA	QA Deployment 2016
ASP-TMS-APP-102	QA	QA Deployment 2016
ASP-TMS-SQL-172	QA	QA Deployment 2017

'--------------------------------------------------------------
'OffCycle

ASP-TMS-APP-107	QA	OffCycle - 2016-1	Used as needed for 4.1
ASP-TMS-SQL-107	QA	OffCycle - 2016-1	Used as needed for 4.1

'--------------------------------------------------------------
'Venkat
password for tmsadmin is Welcome1 on 102 and 103 environments

ASP-TMS-APP-102	QA	QA Deployment 2016	Dazzler-Spartans
ASP-TMS-SQL-172	QA	QA Deployment 2017	Dazzler-Spartans

'---------------------------------------------------------------
'102 - Role Access
Plz check with below ones -
Role		Login Name		Password
Admin		EAFAdmin		Welcome@123
Manager		EAFMgr			Welcome@123
User		EAFUser			Welcome@123
Readonly	EAFReadOnly		Welcome@123



\\abn-dev-file-01.dev.trizetto.com\Drop

