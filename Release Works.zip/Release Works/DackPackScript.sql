

Select * from [CmsManagerOecReconciliationStatistics]

Select * from tbdbupdates where ScriptName = 'TMSEAM_5.80.003.002_SCRIPT_INSERT_HISTORICAL_DATA_FOR_OEC_RECONCILIATION'

--Older One 
--DECLARE @StartDate DATETIME = '2021-01-01 00:00:00'
--SELECT EnrollmentPlanYear AS ContractYear
--, PlanId AS ContractId
--, ApplicationDate AS FileDate
--, COUNT(1) AS EnrollmentInEAM
--FROM [dbo].[tbtransactions]
--WHERE ProgramSource = '5'
--AND TransCode = '61'
--AND ApplicationDate BETWEEN @StartDate AND GETDATE()
--AND EnrollmentPlanYear IS NOT NULL
--GROUP BY EnrollmentPlanYear, PlanId, ApplicationDate

---New One 
SELECT EnrollmentPlanYear AS ContractYear
	   , PlanId AS ContractId
	   , ApplicationDate AS FileDate
	   , COUNT(1) AS EnrollmentInEAM
FROM [dbo].[tbtransactions]
WHERE ProgramSource = '5' 
	  AND TransCode = '61' 
	  AND EnrollmentPlanYear = 2021
GROUP BY EnrollmentPlanYear, PlanId, ApplicationDate