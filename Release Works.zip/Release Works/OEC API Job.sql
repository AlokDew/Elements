-- Load OEC File

Select Applicanthicn,Error,IsProcessed,* from EAM..ElecAppFile order by LoadedDate Desc

---OEC API  --- EnrollmentPlanYear/DOB/MBI (MA Plan)
Insert INTO EnrollmentInfo (ConfirmationNumber   ,SubmitDate   ,ContractId   ,PlanId       ,SegmentId    ,ApplicantTitle      ,ApplicantFirstName  ,ApplicantMiddleInitial       ,ApplicantLastName   ,ApplicantBirthDate  ,ApplicantGender     ,ApplicantAddress1       ,ApplicantAddress2   ,ApplicantAddress3   ,ApplicantCity       ,ApplicantCounty       ,ApplicantState      ,ApplicantZip ,ApplicantPhone      ,ApplicantEmailAddress       ,ApplicantHICN       ,ApplicantSSN ,MailingAddress1     ,MailingAddress2     ,MailingAddress3       ,MailingCity  ,MailingState ,MailingZip   ,MedicarePartA       ,MedicarePartB       ,EmergencyContact    ,EmergencyPhone      ,EmergencyRelationship     ,PremiumDeducted       ,PremiumSource       ,OtherCoverage       ,OtherCoverageName   ,OtherCoverageId     ,LongTerm       ,LongTermName ,LongTermPhone       ,AuthorizedRepName   ,AuthorizedRepAddress       ,AuthorizedRepCity   ,AuthorizedRepState  ,AuthorizedRepZip    ,AuthorizedRepPhone       ,AuthorizedRepRelationship ,Language     ,Esrd  ,StateMedicaid       ,WorkStatus       ,PrimaryCarePhysician      ,OtherCoverageGroup  ,AgentId      ,SubmitTime   ,PartDSubAppInd       ,DeemedInd    ,SubsidyPercentage   ,DeemedReasonCode    ,LisCopayLevelId       ,DeemedCopayLevelId  ,PartDOptOutSwitch   ,SepReasonCode       ,SepCMSReasonCode       ,PremiumDirectPay    ,EnrollmentPlanYear  ,PremiumWithhold     ,SpouseWorkStatus       ,AccessibilityFormat ,EmailOptIn   ) 
VALUES (									201 ,'01012020'   ,'R0105'      ,'007' ,			Null ,		'Mr'       ,'AQAFN'       ,'A'   ,'AQALN'       ,'11201951'   ,'M'   ,'Deui1'      ,111   ,Null    ,'MN'  ,'New York'  ,'NY'  ,12345        ,1234567890   ,'member@12xy.com'   ,'6A77AA0AD04'       ,6555555      ,13       ,11    ,55    ,'Rest6771'   ,'NY'  ,99999 ,01012019     ,01012019     ,'rEST771'    ,6034249364       ,'Son' ,'Yes' ,''    ,'Yes' ,'My Coverage'       ,1234567891   ,'Yes' ,'Instuiton'  ,1234567891       ,'GEORGE WASHINGTON' ,'100main'    ,'CHICAGO'    ,'NH'  ,03054 ,1234567890   ,'Daughter/POA'       ,'English'   ,''   ,'NO'  ,'No'     ,''    ,2     ,'001'   ,	  '2020-01-01 10:27:44.023'   ,'N','N'   ,50    ,2     ,Null       ,4     ,'Y'   ,'NEW01012019,MOV01012019,MDE20200101,INC01012021'    ,'CMS'   ,''    ,2021  ,'D'   ,'Yes' ,'AudioCD' ,'Yes')       

Insert INTO EnrollmentInfo (ConfirmationNumber   ,SubmitDate   ,ContractId   ,PlanId       ,SegmentId    ,ApplicantTitle      ,ApplicantFirstName  ,ApplicantMiddleInitial       ,ApplicantLastName   ,ApplicantBirthDate  ,ApplicantGender     ,ApplicantAddress1       ,ApplicantAddress2   ,ApplicantAddress3   ,ApplicantCity       ,ApplicantCounty       ,ApplicantState      ,ApplicantZip ,ApplicantPhone      ,ApplicantEmailAddress       ,ApplicantHICN       ,ApplicantSSN ,MailingAddress1     ,MailingAddress2     ,MailingAddress3       ,MailingCity  ,MailingState ,MailingZip   ,MedicarePartA       ,MedicarePartB       ,EmergencyContact    ,EmergencyPhone      ,EmergencyRelationship     ,PremiumDeducted       ,PremiumSource       ,OtherCoverage       ,OtherCoverageName   ,OtherCoverageId     ,LongTerm       ,LongTermName ,LongTermPhone       ,AuthorizedRepName   ,AuthorizedRepAddress       ,AuthorizedRepCity   ,AuthorizedRepState  ,AuthorizedRepZip    ,AuthorizedRepPhone       ,AuthorizedRepRelationship ,Language     ,Esrd  ,StateMedicaid       ,WorkStatus       ,PrimaryCarePhysician      ,OtherCoverageGroup  ,AgentId      ,SubmitTime   ,PartDSubAppInd       ,DeemedInd    ,SubsidyPercentage   ,DeemedReasonCode    ,LisCopayLevelId       ,DeemedCopayLevelId  ,PartDOptOutSwitch   ,SepReasonCode       ,SepCMSReasonCode       ,PremiumDirectPay    ,EnrollmentPlanYear  ,PremiumWithhold     ,SpouseWorkStatus       ,AccessibilityFormat ,EmailOptIn   ) 
VALUES (                                    202 ,'01012020'   ,'R0105'      ,'007' ,			Null ,		'Mr'       ,'BQAFN'       ,'A'   ,'BQALN'       ,'11201952'   ,'M'   ,'Deui1'      ,111   ,Null    ,'MN'  ,'New York'  ,'NY'  ,12345        ,1234567890   ,'member@12xy.com'   ,'6A77AA0AD05'       ,6555555      ,13       ,11    ,55    ,'Rest6771'   ,'NY'  ,99999 ,01012019     ,01012019      ,'rEST771'    ,6034249364       ,'Son' ,'Yes' ,''    ,'Yes' ,'My Coverage'       ,1234567892   ,'Yes' ,'Instuiton'  ,1234567892       ,'GEORGE WASHINGTON' ,'100main'    ,'CHICAGO'    ,'NH'  ,03054 ,1234567890   ,'Daughter/POA'       ,'English'   ,''   ,'NO'  ,'No'     ,''    ,2     ,'001'   ,   '2020-01-01 09:27:44.023'   ,'N','N'   ,50    ,2     ,Null       ,4     ,'Y'   ,'NEW01012019,MOV01012019,MDE20200101,INC01012021'    ,'CMS'  ,''    ,2021  ,'D'   ,'Yes' ,'LargePrint' ,'Yes')       

Insert INTO EnrollmentInfo (ConfirmationNumber   ,SubmitDate   ,ContractId   ,PlanId       ,SegmentId    ,ApplicantTitle      ,ApplicantFirstName  ,ApplicantMiddleInitial       ,ApplicantLastName   ,ApplicantBirthDate  ,ApplicantGender     ,ApplicantAddress1       ,ApplicantAddress2   ,ApplicantAddress3   ,ApplicantCity       ,ApplicantCounty       ,ApplicantState      ,ApplicantZip ,ApplicantPhone      ,ApplicantEmailAddress       ,ApplicantHICN       ,ApplicantSSN ,MailingAddress1     ,MailingAddress2     ,MailingAddress3       ,MailingCity  ,MailingState ,MailingZip   ,MedicarePartA       ,MedicarePartB       ,EmergencyContact    ,EmergencyPhone      ,EmergencyRelationship     ,PremiumDeducted       ,PremiumSource       ,OtherCoverage       ,OtherCoverageName   ,OtherCoverageId     ,LongTerm       ,LongTermName ,LongTermPhone       ,AuthorizedRepName   ,AuthorizedRepAddress       ,AuthorizedRepCity   ,AuthorizedRepState  ,AuthorizedRepZip    ,AuthorizedRepPhone       ,AuthorizedRepRelationship ,Language     ,Esrd  ,StateMedicaid       ,WorkStatus       ,PrimaryCarePhysician      ,OtherCoverageGroup  ,AgentId      ,SubmitTime   ,PartDSubAppInd       ,DeemedInd    ,SubsidyPercentage   ,DeemedReasonCode    ,LisCopayLevelId       ,DeemedCopayLevelId  ,PartDOptOutSwitch   ,SepReasonCode       ,SepCMSReasonCode       ,PremiumDirectPay    ,EnrollmentPlanYear  ,PremiumWithhold     ,SpouseWorkStatus       ,AccessibilityFormat ,EmailOptIn   ) 
VALUES (                                    203  ,'01012020'   ,'R0105'      ,'007' ,			Null ,		'Mr'       ,'CQAFN'       ,'A'   ,'CQALN'       ,'11201953'   ,'M'   ,'Deui1'      ,111   ,Null    ,'MN'  ,'New York'  ,'NY'  ,12345        ,1234567890   ,'member@12xy.com'   ,'6A77AA0AD06'       ,6555555      ,13       ,11    ,55    ,'Rest6771'   ,'NY'  ,99999 ,01012019     ,01012019      ,'rEST771'    ,6034249364       ,'Son' ,'Yes' ,''    ,'Yes' ,'My Coverage'       ,1234567893   ,'Yes' ,'Instuiton'  ,1234567893       ,'GEORGE WASHINGTON' ,'100main'    ,'CHICAGO'    ,'NH'  ,03054 ,1234567890   ,'Daughter/POA'       ,'English'   ,''   ,'NO'  ,'No'     ,''    ,2     ,'001'   ,   '2020-01-01 19:27:44.023'   ,'N','N'   ,50    ,2     ,Null       ,4     ,'Y'   ,'NEW 01012019,MOV 01012019,MDE 20200101,INC 01012021'    ,'CMS'  ,''    ,2021  ,'D'   ,'Yes' ,'Braille' ,'Yes')       

--Delete from EnrollmentInfo Where ApplicantHICN in ('6A77AA0AD04','6A77AA0AD05','6A77AA0AD06')

--Select * from tbplan_pbp

--- Verify Data Inserted---
Select Applicanthicn,ContractId,PlanID,EnrollmentPlanYear,SubmitDate,SubmitTime,SpouseWorkStatus,AccessibilityFormat,EmailOptIn,*
From EnrollmentInfo
Where 
--ContractId = 'T1234' And
Applicanthicn Between '6A77AA0AD04' AND '6A77AA0AD06' AND
EnrollmentPlanYear = 2021

--Update EnrollmentInfo Set ContractId = 'H1001' , PlanID = '001' Where Applicanthicn = '7B61K30PL11131415'


--Metadata side job info verfication
select * from pdmmetadata.[dbo].[SchedulerJobs] where Id = 'E4D9F7F7-EE59-48C4-8753-3B1F3C17BE2A' 

select  startDate as dd,[status],* from pdmmetadata.[dbo].[SchedulerJobTriggers] where JobId = 'E4D9F7F7-EE59-48C4-8753-3B1F3C17BE2A' 
and  IsTemplateTrigger = 0
and Description = 'OEC API'  order by startDate desc


Declare @JobDesc varchar(100) = 'OEC API'
Declare @JobID varchar(100) = '81d0d76d-9301-49c6-9535-9554c518575b' -- Job ID displays on UI
Declare @RequestID varchar(100) = '96d26a17-8446-4a62-9a6a-4823f8aa60a8' -- Request ID displays on UI
 -- File ID displays on UI
 

-- [ EAMWarehouse side data and request id verfication ] ---

Select * from EAMwarehouse..HistoryInputManagerjobs where jobid = @JobID -- job status 4

Select * from EAMwarehouse..HistoryInputManagerrequests where  jobid = @JobID

Select * from EAMwarehouse..HistoryInputManagerrequests where requestid = @RequestID -- match from UI

Select * from EAMwarehouse..HistoryInputManagerentities where requestid = @RequestID--number of records u enter

Select * from EAMwarehouse..HistoryInputManagerOecData where entityid in (select entityid from EAMwarehouse..HistoryInputManagerentities where requestid = @RequestID) ---Make sure Source against each transaction is 'OEC API'

 

-- EAM side data verfication 
Declare @FileID varchar(100) = '3074'

select  * from eam..ENRL_RESUBMIT_FILES where file_id = @FileID ---check for file name format

select * from eam..tbOECData_loadingHdr  where FILE_ID = @FileID order by  ConvertedDt desc --- check file name and header info and HDRRAw header infomation

select guid,* from eam..tbOECData_loading  where FILE_ID = @FileID order by  FILE_ID desc 

select Source,* from EAMWarehouse.dbo.historyinputmanageroecdata where entityid in (select GUID from eam..tbOECData_loading  where FILE_ID = @FileID )




--OECLoad Table

Select Applicanthicn,ContractId,PBPID,EnrollmentPlanYear,SubmitDate,SubmitTime,SpouseWorkStatus,AccessibilityFormat,EmailOptIn,SEPReasonCode,SEPCMSReasonCode
from eam..tbOECData_loading Where File_ID = '3074'

--Select Top 1 * from eam..tbOECData_loading Where File_ID = '3074'
--Select * from eam..tbOECData_loading Where Applicanthicn = '6A77AA0AD04'


--ElecAppFile Table
Select Error,IsProcessed,Applicanthicn,ContractId,PlanID,EnrollmentPlanYear,SubmitDate,SubmitTime,SpouseWorkStatus,AccessibilityFormat,EmailOptIn,FileName,SEPReasonCode,SEPCMSReasonCode
From EAM..ElecAppFile -- order by LoadedDate Desc 
Where FileName like 'OEC_20210306_065210_API%' --_267b84de-3568-4644-900f-575216c162b7.FALLOUT'

--Select *
--From EAM..ElecAppFile -- order by LoadedDate Desc 
--Where FileName like 'OEC_20210306_065210_API%'

Select Top 1 Language,*
From EAM..ElecAppFile -- order by LoadedDate Desc 
Where Applicanthicn = '6A77AA0AD04'


Select Applicanthicn,ContractId,PlanID,EnrollmentPlanYear,SubmitDate,SubmitTime,SpouseWorkStatus,AccessibilityFormat,EmailOptIn,*
From EnrollmentInfo
Where 
--ContractId = 'T1234' And
Applicanthicn like '6A77AA0AD%' AND
EnrollmentPlanYear = 2021


Select * from eam..tbtransactions where HIC in ('6A77AA0AD05','6A77AA0AD04') -- API,Batch

Select * from eam..tbeenrlmembers where hic in ('6A77AA0AD05','6A77AA0AD04') -- API,Batch

Select * from eam..tbmemberinfo where MemCodNum in ('20968','20967')  --- API--- Batch OEC

Select * from eam..tblanguage

--Transaction Level
Select T.HIC,AE.FieldName,OriginalValue,NewValue, TriggerActionType
From [EAMWarehouse].[Audit].[TransactionLevel_Audit] A Inner Join PDMMetadata.dbo.[AuditEntityFields] AE
ON A.FieldId = AE.FieldId Join EAM..tbtransactions T
On A.MemcodNum = T.Memcodnum
Where T.HIC = '6A77AA0AD04'
Order By AuditDate Desc  27/27

--Member Level
Select T.HIC,AE.FieldName,OriginalValue,NewValue, TriggerActionType,auditdate
From [EAMWarehouse].[Audit].[MemberLevel_Audit] A Inner Join PDMMetadata.dbo.[AuditEntityFields] AE
ON A.FieldId = AE.FieldId Join EAM..tbtransactions T
On A.MemcodNum = T.Memcodnum
Where T.HIC = '6A77AA0AD05'
Order By AuditDate Desc  83/72

Select MedicarePartA,MedicarePartB,*
From EAM..ElecAppFile --order by loadeddate desc
Where ApplicantHICN In ('6A77AA0AD04','6A77AA0AD05','6A77AA0AD06') And IsProcessed = 1

Select * from EAM.[dbo].[SalesReps]

Select * from EnrollmentInfo where applicanthicn In ('6A77AA0AD04','6A77AA0AD05')

