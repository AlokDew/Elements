Use CMSBEQ
 Declare @MBI varchar(100) = '3G77A00YY01'
 Select * from [BeqAddressInfo] where MedicareBeneficiaryIdentifier = @MBI
 Select * from [BeqAddressLineInfo] where MedicareBeneficiaryIdentifier = @MBI
 Select * from [BeqBeneficiaryInfo] where MedicareBeneficiaryIdentifier = @MBI
 Select * from [BeqEnrollmentInfo] where MedicareBeneficiaryIdentifier = @MBI
 Select * from [BeqEntitlementReasonInfo] where MedicareBeneficiaryIdentifier = @MBI
 Select * from [BeqEsrdCoverageInfo] where MedicareBeneficiaryIdentifier = @MBI
 Select * from [BeqLowIncomeSubsidyInfo] where MedicareBeneficiaryIdentifier = @MBI
 Select * from [BEQMedicareCardInfo] where MedicareBeneficiaryIdentifier = @MBI
 Select * from [BeqPeriodInfo] where MedicareBeneficiaryIdentifier = @MBI
 Select * from [BEQResponseCodeInfo] where MedicareBeneficiaryIdentifier = @MBI
 Select * from [BeqStateCountyInfo] where MedicareBeneficiaryIdentifier = @MBI
 Select * from [BEQUncoveredMonthsInfo] where MedicareBeneficiaryIdentifier = @MBI
 
 



 --Select * from  eam..tbnotes where data = '39326'
 --Select electiontype,* from eam..tbtransactions where hic = '7C77T08AD12'

 -- Select OrigGender,CMSSex, * from eam..[tbBEQRespData_loading] where orighic = '7C77T08AD11' order by id desc

 -- Select Sex,CMSSex,* from eam..tbeligibility where ClaimNumber = '7C77T08AD11' Order by DateCreated Desc

   --Select * from [BeqPeriodType]
 
  







-- Update [BeqStateCountyInfo] Set ZipCode =  '7666' where MedicareBeneficiaryIdentifier = '9V77T08TJ41' 

-- Delete [BEQUncoveredMonthsInfo] where MedicareBeneficiaryIdentifier = '9V77T08TJ41' 



-- Select  MostRecentDualsSepUseDate,* from eam..tbBeqRespData_loading where orighic = '6G77C00AA03'---'9V77T08TJ26'

-- --Select * from BeqPeriodType

-- --Select * from eam..tbeligibility where ClaimNumber = '6G77C00AA07'
 

--/*
--Select EffDatePartA,EffDatePartB,* from eam..tbeligibility where ClaimNumber In ('6D77C00AA02')  --, '6C77C00AA02') and EligibilityId in (10174,10227)

--Select PartAEffDate,PartBEffDate,* from eam..tbBeqRespData_loading where orighic In ('6D77C00AA02') , '6C77C00AA02') And ID in ('10266','10471')

--Select * from eam..tbtransactions where hic = '6D77C00AA11'

--Select * from eam..tbBEQBatchNumber where transid in (Select transid from eam..tbtransactions where hic = '6D77C00AA03' )

--Delete  from eam..tbBEQBatchNumber where transid in (Select transid from eam..tbtransactions where hic = '6D77C00AA03' )

--Select * from eam..tbnotes where data = '37620'

--Select * from BeqPeriodtype

--*/
--Go 
--SET IDENTITY_INSERT BeqPeriodInfo ON
--INSERT [BeqPeriodInfo] ([Id], [StartDate], [StopDate], [MedicareBeneficiaryIdentifier], [PeriodType]) 
--VALUES (ABS(CHECKSUM(NEWID())), '2020-01-01', '2020-12-31', '6G77C00AA03', )


--exec BEQResponse_Generator '7C77C01PT56',
-- 'ProcessedFlag=Y;
--BeneficiaryMatchFlag=Y;
--MedPartAEntStartDate=19970401;
--MedPartBEntStartDate=19970401;
--PartDEligibilityStartDate=20060101;
--DeemedLISEffDate1=20190201;
--DeemedLISEndDate1=20190228;
--PartDPremiumSubsidyPercent1=075;
--CopayLelelId1=4'

--Update [BeqBeneficiaryInfo] set firstname = 'XXXXX', lastname = 'YYYYY' where MedicareBeneficiaryIdentifier = '2C77C00AA02'

--Select * from delete eam..tbnotes where data = '27420'
--Delete from 

--Select * from beqperiodinfo