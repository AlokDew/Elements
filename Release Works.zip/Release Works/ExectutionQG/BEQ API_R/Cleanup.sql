Declare @TransId bigint
Declare @Memcodnum bigint
Declare @EffDate date
Declare @Hic varchar(Max) = '3G77A00YY01'
--Declare @EffDate DateTime ='2020-11-01 00:00:00'

Select @TransId=TransId from eam..tbTransactions Where HIC= @Hic --And EffectiveDate=@EffDate

Select @Memcodnum = MemCodNum from eam..tbtransactions where HIC = @HIC

--Update eam..tbTransactions
--Set BEQSequenceNum=null,
--ErrMessage='',DateModified=null,UserModified=null, Export_Legacy=null,MissingItem=null,Incomplete=null,IncompleteDate=null
--Where HIC= @Hic ---And EffectiveDate=@EffDate

--Delete from eam..tbBEQBatchNumber   where TransId=@TransId

Delete from eam..tbIncarceration   where TransId=@TransId
Delete from eam..tbNotLawfulPresence   where TransId=@TransId
Delete from eam..tbEmployerSubsidy   where TransId=@TransId
Delete from eam..[tbEligibility]   where TransId=@TransId
Delete from eam..[tbNuncMo]   where TransId=@TransId
Delete from eam..[tbBeneficiaryEnrlInformation]   where TransId=@TransId
Delete from eam..[tbMemberInfoCaraDateLog]   where TransId=@TransId
Delete from eam..[tbMemberMedicareEntitlementDate]   where TransId=@TransId
Delete from [EAMWarehouse].[dbo].HistoryInputManagerBeqExport where transid=@TransId

Delete from eam..[tbBEQRespData_loading]   where OrigHic=@Hic
Delete from [EAMWarehouse]..HistoryInputManagerBeqData  where OrigHic=@Hic

Delete tbMemberInfoLISLog where changeSource = 'BEQ' and memcodnum = @Memcodnum

--Select * from tbtransactions where hic = '3C77A00YY02'
--Select * from tbmemberinfo where memcodnum = '20951'
Update tbmemberinfo Set CMSPartAEff =Null, CMSPartBEff = Null,CMSPartDEff = Null,LatestBEQRequested = Null, LatestBEQReceived = Null, PossibleNUNCmo = ''
where memcodnum = @Memcodnum

Select @EffDate = CurrentEffDate from eam..tbeenrlmembers where HIC = @HIC

Update tbtransactions Set ElectionType = NULL, ErrMessage='',EffectiveDate = @EffDate where HIC = @HIC
--Select * from tbeenrlmembers where hic = '3C77A00YY01'


--Update eam..tbtransactions set ErrMessage='' where hic = '3G77A00YY03'