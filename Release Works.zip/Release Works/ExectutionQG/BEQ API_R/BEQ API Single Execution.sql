
--000 - Both PRocessed and MAtch flag = Y
--100 or 101 - Processed = Y and Match = N
--other codes - Both Processed �and Match = N
USE EAM
Delete FROM [dbo].[tbEGWPPlanPbpAssociation]

Select multiple from tbplan_pbp

Update tbplan_pbp Set multiple = 0 

Select * from tbtransactions where hic like '3G77A00YY0%'

Select * from tbplan_pbp Where PlanID = 'H1001' ANd PBPID IN ('001','002')
Select * from tbplan_pbp Where PlanID = 'H0002' ANd PBPID = '006'
Select * from tbplan_pbp Where PlanID = 'S2001' ANd PBPID = '001'


--Select Error,Isprocessed,Applicanthicn,* from ElecAppFile Where Applicanthicn like '6H77C00AA1%'

Select Error,Isprocessed,Applicanthicn,* from ElecAppFile
Where FileName = 'EAF_BEQAPIY02_20210101.txt'

Update tbtransactions Set TransStatus = 0 Where hic in ('3G77A00YY01','3G77A00YY03','3G77A00YY04','3G77A00YY05')
Update tbtransactions Set TransStatus = 1 Where hic in ('3G77A00YY02','5G77C00AA04')

Select * from [EAMWarehouse]..HistoryInputManagerBeqData  where OrigHic= '5G77C00AA04'	

Select * from eam..[tbBEQRespData_loading]   where OrigHic= '5G77C00AA04'	

Select * from tbeligibility where ClaimNumber = '5G77C00AA04'


--Multi -- 5G77C00AA0
					
Exec BEQResponse_Generator '5G77C00AA04',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20250101;
MedPartBEntStartDate=20250101;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'

	Select HIC, TransCode,TransStatus,Planid,PBPid,EffectiveDate,ElectionType
From tbtransactions
Where HIC Between '5G77C00AA01' AND '5G77C00AA07'
				

Select T.HIC,L.PartDSubsLevel,L.LowIncCoPayCat,L.LowIncomeCoPayEffectiveDate,L.LowIncomeCoPayEndDate,T.TransStatus
From tbMemberInfoLISLog L Join tbtransactions T
On L.MemCodNum = T.MemCodNum
Where T.HIC In ('5G77C00AA03','5G77C00AA05','5G77C00AA07')
					
					

					
					
					
					
					
					
					
					
				
					
				
					
					
					
					
					
					

					
					
					
					
					
					

					
					
					
					
					
					
					
					
				
					
					
					
					

Select * from eam..[tbBEQRespData_loading]   where OrigHic='3C77A00YY03'
Select * from [EAMWarehouse]..HistoryInputManagerBeqData  where hic = '3C77A00YY03'