Use CMSBEQ
GO

SET IDENTITY_INSERT BeqAddressInfo ON

INSERT [BeqAddressInfo] ([Id], [MedicareBeneficiaryIdentifier], [AddressStartDate], [City], [PostalStateCode], [ZipCode], [AddressType])
VALUES (ABS(CHECKSUM(NEWID())), '3G77A00YY01', '2020-11-01', 'ALCOVE', 'NY', 12007, 1)

INSERT [BeqAddressInfo] ([Id], [MedicareBeneficiaryIdentifier], [AddressStartDate], [City], [PostalStateCode], [ZipCode], [AddressType]) 
VALUES (ABS(CHECKSUM(NEWID())), N'3G77A00YY01', N'2020-11-01', N'ALCOVE', N'NY', N'12007', 2)

SET IDENTITY_INSERT BeqAddressInfo OFF

Set IDENTITY_INSERT [BeqAddressLineInfo] ON

INSERT [BeqAddressLineInfo]([Id], [MedicareBeneficiaryIdentifier], [Address], [AddressType])
VALUES (ABS(CHECKSUM(NEWID())), N'3G77A00YY01',N'FLAT1 BLOCK1',1) 

SET IDENTITY_INSERT  [BeqAddressLineInfo] OFF

SET IDENTITY_INSERT BeqBeneficiaryInfo ON

--===== [BeqBeneficiaryInfo] ====

INSERT [BeqBeneficiaryInfo] ([Id], [MedicareBeneficiaryIdentifier], [FirstName], [MiddleInitial], [LastName], [BirthDate], [DeathDate], [Gender], [DeathDateProof], [BeneficiaryKey], [LatestSpecialEnrollmentPeriodUseDate], [HasMedicaid])
VALUES (ABS(CHECKSUM(NEWID())), '3G77A00YY01', 'ET01', 'A', 'ETLN', '1955-01-01', Null, 1, Null, ABS(CHECKSUM(NEWID())), Null,0)

SET IDENTITY_INSERT BeqBeneficiaryInfo OFF

SET IDENTITY_INSERT BeqEnrollmentInfo ON

--===== [BeqEnrollmentInfo] ====

INSERT [BeqEnrollmentInfo] ([Id], [EnrollmentDate], [DisenrollmentDate], [ContractNumber], [PlanBenefitPackageNumber], [ProgramType], [PlanType], [SourceType], [IsEmployerGroupHealthPlan], [AddedDateTime], [SegmentNumber], [SubmittingContractNumber], [MedicareBeneficiaryIdentifier], [EnrollmentType])
VALUES (ABS(CHECKSUM(NEWID())), '2021-01-01', Null, 'H0002', '006', 1, 01,'D', 1, GetDate(), '', 'H0002', '3G77A00YY01', 1)

SET IDENTITY_INSERT BeqEnrollmentInfo OFF

SET IDENTITY_INSERT BeqEntitlementReasonInfo ON

--===== [BeqEntitlementReasonInfo] ====

INSERT [BeqEntitlementReasonInfo] ([Id], [EntitlementReason], [EntitlementReasonChangeDate], [MedicareBeneficiaryIdentifier])
VALUES (ABS(CHECKSUM(NEWID())), 'B', '2019-01-01', '3G77A00YY01')

SET IDENTITY_INSERT BeqEntitlementReasonInfo OFF



--===== [BeqLowIncomeSubsidyInfo] ====

--SET IDENTITY_INSERT BeqLowIncomeSubsidyInfo ON

--INSERT [BeqLowIncomeSubsidyInfo] ([Id], [StartDate], [StopDate], [CopaymentLevel], [PremiumSubsidyPercent], [InstitutionalStatus], [MedicareBeneficiaryIdentifier])
--VALUES (ABS(CHECKSUM(NEWID())), '2021-01-01', '2021-12-31', 1.00, 100, '1', '3G77A00YY01')

--SET IDENTITY_INSERT BeqLowIncomeSubsidyInfo OFF

SET IDENTITY_INSERT BEQMedicareCardInfo ON

--===== [BEQMedicareCardInfo] ====

INSERT [BEQMedicareCardInfo] ([Id], [CardRequestDate], [MedicareBeneficiaryIdentifier]) VALUES (ABS(CHECKSUM(NEWID())), '2020-01-01', '3G77A00YY01')

SET IDENTITY_INSERT BEQMedicareCardInfo OFF

SET IDENTITY_INSERT BeqPeriodInfo ON

--===== [BeqPeriodInfo] ====


INSERT [BeqPeriodInfo] ([Id], [StartDate], [StopDate], [MedicareBeneficiaryIdentifier], [PeriodType]) 
VALUES (ABS(CHECKSUM(NEWID())), '2019-01-01', '', '3G77A00YY01', 1)
INSERT [BeqPeriodInfo] ([Id], [StartDate], [StopDate], [MedicareBeneficiaryIdentifier], [PeriodType]) 
VALUES (ABS(CHECKSUM(NEWID())), '2019-01-01', '', '3G77A00YY01', 2)
INSERT [BeqPeriodInfo] ([Id], [StartDate], [StopDate], [MedicareBeneficiaryIdentifier], [PeriodType]) 
VALUES (ABS(CHECKSUM(NEWID())), '2020-02-01', '', '3G77A00YY01', 3)
--INSERT [BeqPeriodInfo] ([Id], [StartDate], [StopDate], [MedicareBeneficiaryIdentifier], [PeriodType]) 
--VALUES (ABS(CHECKSUM(NEWID())), '2019-01-01', '', '3G77A00YY01', 4)
--INSERT [BeqPeriodInfo] ([Id], [StartDate], [StopDate], [MedicareBeneficiaryIdentifier], [PeriodType]) 
--VALUES (ABS(CHECKSUM(NEWID())), '2018-01-01', '2018-12-31', '3G77A00YY01', 5)
--INSERT [BeqPeriodInfo] ([Id], [StartDate], [StopDate], [MedicareBeneficiaryIdentifier], [PeriodType]) 
--VALUES (ABS(CHECKSUM(NEWID())), '2019-01-01', '2019-12-31', '3G77A00YY01', 8)


SET IDENTITY_INSERT BeqPeriodInfo OFF

--===== [BEQResponseCodeInfo] ====

SET IDENTITY_INSERT [BEQResponseCodeInfo] ON

INSERT [BEQResponseCodeInfo] ([Id], [MedicareBeneficiaryIdentifier], [CodeName], [Code], [Description]) 
VALUES (ABS(CHECKSUM(NEWID())), '3G77A00YY01', 'MATCHED', '000', 'Matched Beneficary')

SET IDENTITY_INSERT [BEQResponseCodeInfo] OFF

--===== [BeqStateCountyInfo] ====

SET IDENTITY_INSERT BeqStateCountyInfo ON


INSERT [BeqStateCountyInfo] ([Id], [SsaCounty], [SsaState], [FipsCounty], [FipsState], [ZipCode], [MedicareBeneficiaryIdentifier])
VALUES (ABS(CHECKSUM(NEWID())), '000', 33, 198, 12, 7666, '3G77A00YY01')

SET IDENTITY_INSERT BeqStateCountyInfo OFF



--===== [BEQUncoveredMonthsInfo] ====

--SET IDENTITY_INSERT [BEQUncoveredMonthsInfo] ON

--Select * from [BEQUncoveredMonthsInfo] where [MedicareBeneficiaryIdentifier] = '1EG4TE5MK75'  
--Delete From [BEQUncoveredMonthsInfo] where [MedicareBeneficiaryIdentifier] = 3G77A00YY01

--INSERT [BEQUncoveredMonthsInfo] ([Id], [StartDate], [MonthsCount], [Status], [MedicareBeneficiaryIdentifier])
--VALUES (ABS(CHECKSUM(NEWID())), @UCStartDate, CAST(@UCMonthsCount AS Decimal(18, 2)), @UCStatus, 3G77A00YY01)


--SET IDENTITY_INSERT [BEQUncoveredMonthsInfo] OFF

