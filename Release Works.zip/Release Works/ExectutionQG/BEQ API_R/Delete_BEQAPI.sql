Declare @MBI varchar(100) = '3C77A00YY03'
 Use CMSBEQ

 Delete from [BeqAddressInfo] where MedicareBeneficiaryIdentifier = @MBI
 Delete from [BeqBeneficiaryInfo] where MedicareBeneficiaryIdentifier = @MBI
 Delete from [BeqEnrollmentInfo] where MedicareBeneficiaryIdentifier = @MBI
 Delete from [BeqEntitlementReasonInfo] where MedicareBeneficiaryIdentifier = @MBI
 Delete from [BeqLowIncomeSubsidyInfo] where MedicareBeneficiaryIdentifier = @MBI
 Delete from [BEQMedicareCardInfo] where MedicareBeneficiaryIdentifier = @MBI
 Delete from [BeqPeriodInfo] where MedicareBeneficiaryIdentifier = @MBI
 Delete from [BEQResponseCodeInfo] where MedicareBeneficiaryIdentifier = @MBI
 Delete from [BeqStateCountyInfo] where MedicareBeneficiaryIdentifier = @MBI
 Delete from [BEQUncoveredMonthsInfo] where MedicareBeneficiaryIdentifier = @MBI
 Delete from [BeqEsrdCoverageInfo] where MedicareBeneficiaryIdentifier = @MBI
 Delete from [BeqAddressLineInfo] where MedicareBeneficiaryIdentifier = @MBI

  /*
 Delete eam..tbeligibility where claimnumber = '6D77C00AA11'
Delete eam..tbBeqRespData_loading where orighic In ('6D77C00AA02')
Delete eam..tbnotes where data = '37864'
*/