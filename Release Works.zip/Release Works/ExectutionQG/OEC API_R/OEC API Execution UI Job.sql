--2020 - H0001,H1001
--2021 - H0002,H1002

---Data movemenet from mock server to warehouse

--Declare @JobDesc varchar(100) = 'OEC API'
Declare @JobID varchar(100) = 'bb0726cb-30ae-4076-9ff4-8e5cee364e0a' -- Job ID displays on UI
Declare @RequestID varchar(100) = '6bfff342-7a46-4957-83ef-cbf5850144a1' -- Request ID displays on UI

-- [ EAMWarehouse side data and request id verfication ] ---

Select * from EAMwarehouse..HistoryInputManagerjobs where jobid = @JobID -- job status 4

Select * from EAMwarehouse..HistoryInputManagerrequests where  jobid = @JobID

Select * from EAMwarehouse..HistoryInputManagerentities where requestid = @RequestID--number of records u enter

Select * from EAMwarehouse..HistoryInputManagerOecData where entityid in (select entityid from EAMwarehouse..HistoryInputManagerentities where requestid = @RequestID) ---Make sure Source against each transaction is 'OEC API'

 
Declare @FileID varchar(100) = '2820'

select  * from eam..ENRL_RESUBMIT_FILES where file_id = @FileID ---check for file name format

select * from eam..tbOECData_loadingHdr  where FILE_ID = @FileID order by  ConvertedDt desc --- check file name and header info and HDRRAw header infomation

select guid,* from eam..tbOECData_loading  where FILE_ID = @FileID order by  FILE_ID desc

---ElecAppFile

Declare @FileName varchar(100) = 'OEC_20210616_110600_API_b43e5963-9609-493d-9913-2296b8df1fb9'

Select Error,IsProcessed,Applicanthicn,ContractID,PlanID,ApplicantFirstName,ApplicantLastName,ApplicantBirthDate,SpouseWorkStatus,AccessibilityFormat,EmailOptIn,SubmitDate,SubmitTime,EnrollmentPlanYear,ApplicantZip,*
From EAM..ElecAppFile 
Where FileName = @FileName

-- Transaction / Member 
Select HIC,T.PlanID,T.PBPID,M.FirstName,M.LastName,M.DOB,M.SpouseWorkStatus,M.AccessibilityFormat,M.EmailOptIn,T.ReceiptDate,T.ApplicationDate,T.EnrollmentPlanYear,*
From eam..tbtransactions T Join eam..tbMemberinfo M
On T.Memcodnum = M.memcodnum
Where T.HIC like  '2G77AA0AD0%' 



Select error,* from eam..elecappfile where filename like'oec%' and isprocessed = 0