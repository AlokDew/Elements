Select * from eam..tbplan_pbp

Select * from eam..tbtransactions where hic like '1H77AA0AD0%'

Select * from enrollmentinfo

---OEC API  2020

Insert INTO EnrollmentInfo (ConfirmationNumber   ,SubmitDate   ,ContractId   ,PlanId       ,SegmentId    ,ApplicantTitle      ,ApplicantFirstName  ,ApplicantMiddleInitial       ,ApplicantLastName   ,ApplicantBirthDate  ,ApplicantGender     ,ApplicantAddress1       ,ApplicantAddress2   ,ApplicantAddress3   ,ApplicantCity       ,ApplicantCounty       ,ApplicantState      ,ApplicantZip ,ApplicantPhone      ,ApplicantEmailAddress       ,ApplicantHICN       ,ApplicantSSN ,MailingAddress1     ,MailingAddress2     ,MailingAddress3       ,MailingCity  ,MailingState ,MailingZip   ,MedicarePartA       ,MedicarePartB       ,EmergencyContact    ,EmergencyPhone      ,EmergencyRelationship     ,PremiumDeducted       ,PremiumSource       ,OtherCoverage       ,OtherCoverageName   ,OtherCoverageId     ,LongTerm       ,LongTermName ,LongTermPhone       ,AuthorizedRepName   ,AuthorizedRepAddress       ,AuthorizedRepCity   ,AuthorizedRepState  ,AuthorizedRepZip    ,AuthorizedRepPhone       ,AuthorizedRepRelationship ,Language     ,Esrd  ,StateMedicaid       ,WorkStatus       ,PrimaryCarePhysician      ,OtherCoverageGroup  ,AgentId      ,SubmitTime   ,PartDSubAppInd       ,DeemedInd    ,SubsidyPercentage   ,DeemedReasonCode    ,LisCopayLevelId       ,DeemedCopayLevelId  ,PartDOptOutSwitch   ,SepReasonCode       ,SepCMSReasonCode       ,PremiumDirectPay    ,EnrollmentPlanYear  ,PremiumWithhold     ,SpouseWorkStatus       ,AccessibilityFormat ,EmailOptIn   ) 
VALUES (1001 ,'01012020'   ,'H0001'      ,'001' ,			Null ,		'Mr'       ,'AQAFNA'       ,'A'   ,'AQALNA'       ,'11201951'   ,'M'   ,'Deui1'      ,Null   ,Null    ,'MN'  ,'New York'  ,'NY'  ,12345        ,1234567890   ,'member@12xy.com'   ,'1H77AA0AD01'       ,6555555      ,13       ,11    ,55    ,'Rest6771'   ,'NY'  ,99999 ,01012019     ,01012019     ,'REST771'    ,6034249364       ,'Son' ,'Yes' ,''    ,'Yes' ,'My Coverage'       ,1234567891   ,'Yes' ,'Instuiton'  ,1234567891       ,'GEORGE WASHINGTON' ,'100main'    ,'CHICAGO'    ,'NH'  ,03054 ,1234567890   ,'Daughter/POA'       ,'English'   ,''   ,'NO'  ,'No'     ,''    ,2     ,'001'   ,	  '2020-01-01 10:27:44.023'   ,'N','N'   ,50    ,2     ,Null       ,4     ,'Y'   ,'NEW 01012019,MOV 01012019,MDE 20200101,INC 01012021'    ,'CMS'   ,''    ,2020  ,'D'   ,'Yes' ,'AudioCD' ,'Yes')       
Insert INTO EnrollmentInfo (ConfirmationNumber   ,SubmitDate   ,ContractId   ,PlanId       ,SegmentId    ,ApplicantTitle      ,ApplicantFirstName  ,ApplicantMiddleInitial       ,ApplicantLastName   ,ApplicantBirthDate  ,ApplicantGender     ,ApplicantAddress1       ,ApplicantAddress2   ,ApplicantAddress3   ,ApplicantCity       ,ApplicantCounty       ,ApplicantState      ,ApplicantZip ,ApplicantPhone      ,ApplicantEmailAddress       ,ApplicantHICN       ,ApplicantSSN ,MailingAddress1     ,MailingAddress2     ,MailingAddress3       ,MailingCity  ,MailingState ,MailingZip   ,MedicarePartA       ,MedicarePartB       ,EmergencyContact    ,EmergencyPhone      ,EmergencyRelationship     ,PremiumDeducted       ,PremiumSource       ,OtherCoverage       ,OtherCoverageName   ,OtherCoverageId     ,LongTerm       ,LongTermName ,LongTermPhone       ,AuthorizedRepName   ,AuthorizedRepAddress       ,AuthorizedRepCity   ,AuthorizedRepState  ,AuthorizedRepZip    ,AuthorizedRepPhone       ,AuthorizedRepRelationship ,Language     ,Esrd  ,StateMedicaid       ,WorkStatus       ,PrimaryCarePhysician      ,OtherCoverageGroup  ,AgentId      ,SubmitTime   ,PartDSubAppInd       ,DeemedInd    ,SubsidyPercentage   ,DeemedReasonCode    ,LisCopayLevelId       ,DeemedCopayLevelId  ,PartDOptOutSwitch   ,SepReasonCode       ,SepCMSReasonCode       ,PremiumDirectPay    ,EnrollmentPlanYear  ,PremiumWithhold     ,SpouseWorkStatus       ,AccessibilityFormat ,EmailOptIn   ) 
VALUES (1002 ,'01012020'   ,'H0001'      ,'001' ,			Null ,		'Mr'       ,'AQAFNB'       ,'A'   ,'AQALNB'       ,'11201952'   ,'M'   ,'Deui1'      ,Null   ,Null    ,'MN'  ,'New York'  ,'NY'  ,12345        ,1234567890   ,'member@12xy.com'   ,'1H77AA0AD02'       ,6555555      ,13       ,11    ,55    ,'Rest6771'   ,'NY'  ,99999 ,01012019     ,01012019     ,'REST771'    ,6034249364       ,'Son' ,'Yes' ,''    ,'Yes' ,'My Coverage'       ,1234567891   ,'Yes' ,'Instuiton'  ,1234567891       ,'GEORGE WASHINGTON' ,'100main'    ,'CHICAGO'    ,'NH'  ,03054 ,1234567890   ,'Daughter/POA'       ,'Hindi'   ,''   ,'NO'  ,'No'     ,''    ,2     ,'001'   ,	  '2020-01-01 10:27:44.023'   ,'N','N'   ,50    ,2     ,Null       ,4     ,'Y'   ,'NEW 01012019,MOV 01012019,MDE 20200101,INC 01012021'    ,'CMS'   ,''    ,2020  ,'D'   ,'Yes' ,'Braille' ,'Yes')       
Insert INTO EnrollmentInfo (ConfirmationNumber   ,SubmitDate   ,ContractId   ,PlanId       ,SegmentId    ,ApplicantTitle      ,ApplicantFirstName  ,ApplicantMiddleInitial       ,ApplicantLastName   ,ApplicantBirthDate  ,ApplicantGender     ,ApplicantAddress1       ,ApplicantAddress2   ,ApplicantAddress3   ,ApplicantCity       ,ApplicantCounty       ,ApplicantState      ,ApplicantZip ,ApplicantPhone      ,ApplicantEmailAddress       ,ApplicantHICN       ,ApplicantSSN ,MailingAddress1     ,MailingAddress2     ,MailingAddress3       ,MailingCity  ,MailingState ,MailingZip   ,MedicarePartA       ,MedicarePartB       ,EmergencyContact    ,EmergencyPhone      ,EmergencyRelationship     ,PremiumDeducted       ,PremiumSource       ,OtherCoverage       ,OtherCoverageName   ,OtherCoverageId     ,LongTerm       ,LongTermName ,LongTermPhone       ,AuthorizedRepName   ,AuthorizedRepAddress       ,AuthorizedRepCity   ,AuthorizedRepState  ,AuthorizedRepZip    ,AuthorizedRepPhone       ,AuthorizedRepRelationship ,Language     ,Esrd  ,StateMedicaid       ,WorkStatus       ,PrimaryCarePhysician      ,OtherCoverageGroup  ,AgentId      ,SubmitTime   ,PartDSubAppInd       ,DeemedInd    ,SubsidyPercentage   ,DeemedReasonCode    ,LisCopayLevelId       ,DeemedCopayLevelId  ,PartDOptOutSwitch   ,SepReasonCode       ,SepCMSReasonCode       ,PremiumDirectPay    ,EnrollmentPlanYear  ,PremiumWithhold     ,SpouseWorkStatus       ,AccessibilityFormat ,EmailOptIn   ) 
VALUES (1003 ,'01012020'   ,'H1001'      ,'001' ,			Null ,		'Mr'       ,'AQAFNC'       ,'A'   ,'AQALNC'       ,'11201953'   ,'M'   ,'Deui1'      ,Null   ,Null    ,'MN'  ,'New York'  ,'NY'  ,12345        ,1234567890   ,'member@12xy.com'   ,'1H77AA0AD03'       ,6555555      ,13       ,11    ,55    ,'Rest6771'   ,'NY'  ,99999 ,01012019     ,01012019     ,'REST771'    ,6034249364       ,'Son' ,'Yes' ,''    ,'Yes' ,'My Coverage'       ,1234567891   ,'Yes' ,'Instuiton'  ,1234567891       ,'GEORGE WASHINGTON' ,'100main'    ,'CHICAGO'    ,'NH'  ,03054 ,1234567890   ,'Daughter/POA'       ,'British'   ,''   ,'NO'  ,'No'     ,''    ,2     ,'001'   ,	  '2020-01-01 10:27:44.023'   ,'N','N'   ,50    ,2     ,Null       ,4     ,'Y'   ,'NEW 01012019,MOV 01012019,MDE 20200101,INC 01012021'    ,'CMS'   ,''    ,2020  ,'D'   ,'' ,'' ,'')       
Insert INTO EnrollmentInfo (ConfirmationNumber   ,SubmitDate   ,ContractId   ,PlanId       ,SegmentId    ,ApplicantTitle      ,ApplicantFirstName  ,ApplicantMiddleInitial       ,ApplicantLastName   ,ApplicantBirthDate  ,ApplicantGender     ,ApplicantAddress1       ,ApplicantAddress2   ,ApplicantAddress3   ,ApplicantCity       ,ApplicantCounty       ,ApplicantState      ,ApplicantZip ,ApplicantPhone      ,ApplicantEmailAddress       ,ApplicantHICN       ,ApplicantSSN ,MailingAddress1     ,MailingAddress2     ,MailingAddress3       ,MailingCity  ,MailingState ,MailingZip   ,MedicarePartA       ,MedicarePartB       ,EmergencyContact    ,EmergencyPhone      ,EmergencyRelationship     ,PremiumDeducted       ,PremiumSource       ,OtherCoverage       ,OtherCoverageName   ,OtherCoverageId     ,LongTerm       ,LongTermName ,LongTermPhone       ,AuthorizedRepName   ,AuthorizedRepAddress       ,AuthorizedRepCity   ,AuthorizedRepState  ,AuthorizedRepZip    ,AuthorizedRepPhone       ,AuthorizedRepRelationship ,Language     ,Esrd  ,StateMedicaid       ,WorkStatus       ,PrimaryCarePhysician      ,OtherCoverageGroup  ,AgentId      ,SubmitTime   ,PartDSubAppInd       ,DeemedInd    ,SubsidyPercentage   ,DeemedReasonCode    ,LisCopayLevelId       ,DeemedCopayLevelId  ,PartDOptOutSwitch   ,SepReasonCode       ,SepCMSReasonCode       ,PremiumDirectPay    ,EnrollmentPlanYear  ,PremiumWithhold     ,SpouseWorkStatus       ,AccessibilityFormat ,EmailOptIn   ) 
VALUES (1004 ,'01012020'   ,'H1001'      ,'001' ,			Null ,		'Mr'       ,'AQAFND'       ,'A'   ,'AQALND'       ,'19541120'   ,'M'   ,'Deui1'      ,Null   ,Null    ,'MN'  ,'New York'  ,'NY'  , Null       ,1234567890   ,'member@12xy.com'   ,'1H77AA0AD04'       ,6555555      ,13       ,11    ,55    ,'Rest6771'   ,'NY'  ,99999 ,01012019     ,01012019     ,'REST771'    ,6034249364       ,'Son' ,'Yes' ,''    ,'Yes' ,'My Coverage'       ,1234567891   ,'Yes' ,'Instuiton'  ,1234567891       ,'GEORGE WASHINGTON' ,'100main'    ,'CHICAGO'    ,'NH'  ,03054 ,1234567890   ,'Daughter/POA'       ,'Polish'   ,''   ,'NO'  ,'No'     ,''    ,2     ,'001'   ,	  '2020-01-01 10:27:44.023'   ,'N','N'   ,50    ,2     ,Null       ,4     ,'Y'   ,'NEW 01012019,MOV 01012019,MDE 20200101,INC 01012021'    ,'CMS'   ,''    ,2020  ,'D'   ,'Yes' ,'AudioCD' ,'Yes')       
Insert INTO EnrollmentInfo (ConfirmationNumber   ,SubmitDate   ,ContractId   ,PlanId       ,SegmentId    ,ApplicantTitle      ,ApplicantFirstName  ,ApplicantMiddleInitial       ,ApplicantLastName   ,ApplicantBirthDate  ,ApplicantGender     ,ApplicantAddress1       ,ApplicantAddress2   ,ApplicantAddress3   ,ApplicantCity       ,ApplicantCounty       ,ApplicantState      ,ApplicantZip ,ApplicantPhone      ,ApplicantEmailAddress       ,ApplicantHICN       ,ApplicantSSN ,MailingAddress1     ,MailingAddress2     ,MailingAddress3       ,MailingCity  ,MailingState ,MailingZip   ,MedicarePartA       ,MedicarePartB       ,EmergencyContact    ,EmergencyPhone      ,EmergencyRelationship     ,PremiumDeducted       ,PremiumSource       ,OtherCoverage       ,OtherCoverageName   ,OtherCoverageId     ,LongTerm       ,LongTermName ,LongTermPhone       ,AuthorizedRepName   ,AuthorizedRepAddress       ,AuthorizedRepCity   ,AuthorizedRepState  ,AuthorizedRepZip    ,AuthorizedRepPhone       ,AuthorizedRepRelationship ,Language     ,Esrd  ,StateMedicaid       ,WorkStatus       ,PrimaryCarePhysician      ,OtherCoverageGroup  ,AgentId      ,SubmitTime   ,PartDSubAppInd       ,DeemedInd    ,SubsidyPercentage   ,DeemedReasonCode    ,LisCopayLevelId       ,DeemedCopayLevelId  ,PartDOptOutSwitch   ,SepReasonCode       ,SepCMSReasonCode       ,PremiumDirectPay    ,EnrollmentPlanYear  ,PremiumWithhold     ,SpouseWorkStatus       ,AccessibilityFormat ,EmailOptIn   ) 
VALUES (1005 ,'01012020'   ,'H1001'      ,'007' ,			Null ,		'Mr'       ,'AQAFNE'       ,'A'   ,'AQALNE'       ,'11201955'   ,'M'   ,'Deui1'      ,Null   ,Null    ,'MN'  ,'New York'  ,'NY'  ,12345        ,1234567890   ,'member@12xy.com'   ,'1H77AA0AD05'       ,6555555      ,13       ,11    ,55    ,'Rest6771'   ,'NY'  ,99999 ,01012019     ,01012019     ,'REST771'    ,6034249364       ,'Son' ,'Yes' ,''    ,'Yes' ,'My Coverage'       ,1234567891   ,'Yes' ,'Instuiton'  ,1234567891       ,'GEORGE WASHINGTON' ,'100main'    ,'CHICAGO'    ,'NH'  ,03054 ,1234567890   ,'Daughter/POA'       ,'English'   ,''   ,'NO'  ,'No'     ,''    ,2     ,'001'   ,	  '2020-01-01 10:27:44.023'   ,'N','N'   ,50    ,2     ,Null       ,4     ,'Y'   ,'NEW 01012019,MOV 01012019,MDE 20200101,INC 01012021'    ,'CMS'   ,''    ,2020  ,'D'   ,'Yes' ,'AudioCD' ,'Yes')       


--- OEC API  2021

Insert INTO EnrollmentInfo (ConfirmationNumber   ,SubmitDate   ,ContractId   ,PlanId       ,SegmentId    ,ApplicantTitle      ,ApplicantFirstName  ,ApplicantMiddleInitial       ,ApplicantLastName   ,ApplicantBirthDate  ,ApplicantGender     ,ApplicantAddress1       ,ApplicantAddress2   ,ApplicantAddress3   ,ApplicantCity       ,ApplicantCounty       ,ApplicantState      ,ApplicantZip ,ApplicantPhone      ,ApplicantEmailAddress       ,ApplicantHICN       ,ApplicantSSN ,MailingAddress1     ,MailingAddress2     ,MailingAddress3       ,MailingCity  ,MailingState ,MailingZip   ,MedicarePartA       ,MedicarePartB       ,EmergencyContact    ,EmergencyPhone      ,EmergencyRelationship     ,PremiumDeducted       ,PremiumSource       ,OtherCoverage       ,OtherCoverageName   ,OtherCoverageId     ,LongTerm       ,LongTermName ,LongTermPhone       ,AuthorizedRepName   ,AuthorizedRepAddress       ,AuthorizedRepCity   ,AuthorizedRepState  ,AuthorizedRepZip    ,AuthorizedRepPhone       ,AuthorizedRepRelationship ,Language     ,Esrd  ,StateMedicaid       ,WorkStatus       ,PrimaryCarePhysician      ,OtherCoverageGroup  ,AgentId      ,SubmitTime   ,PartDSubAppInd       ,DeemedInd    ,SubsidyPercentage   ,DeemedReasonCode    ,LisCopayLevelId       ,DeemedCopayLevelId  ,PartDOptOutSwitch   ,SepReasonCode       ,SepCMSReasonCode       ,PremiumDirectPay    ,EnrollmentPlanYear  ,PremiumWithhold     ,SpouseWorkStatus       ,AccessibilityFormat ,EmailOptIn   ) 
VALUES (2001 ,'01012021'   ,'H0002'      ,'001' ,			Null ,		'Mr'       ,'FNA'       ,'A'   ,'LNA'       ,'01011960'   ,'M'   ,'Add1'      ,Null   ,Null    ,'MN'  ,'New York'  ,'NY'  ,12345        ,1234567890   ,'member@12xy.com'   ,'2G77AA0AD01'       ,6555555      ,13       ,11    ,55    ,'Rest6771'   ,'NY'  ,99999 ,01012019     ,01012019     ,'REST771'    ,6034249364       ,'Son' ,'Yes' ,''    ,'Yes' ,'My Coverage'       ,1234567891   ,'Yes' ,'Instuiton'  ,1234567891       ,'GEORGE WASHINGTON' ,'100main'    ,'CHICAGO'    ,'NH'  ,03054 ,1234567890   ,'Daughter/POA'       ,'English'   ,''   ,'NO'  ,'No'     ,''    ,2     ,'001'   ,	  '2021-01-01 10:27:44.023'   ,'N','N'   ,50    ,2     ,Null       ,4     ,'Y'   ,'NEW 01012019,MOV 01012019,MDE 20200101,INC 01012021'    ,'CMS'   ,''    ,2021  ,'D'   ,'Yes' ,'AudioCD' ,'Yes')       
Insert INTO EnrollmentInfo (ConfirmationNumber   ,SubmitDate   ,ContractId   ,PlanId    ,SegmentId    ,ApplicantTitle      ,ApplicantFirstName  ,ApplicantMiddleInitial       ,ApplicantLastName   ,ApplicantBirthDate  ,ApplicantGender     ,ApplicantAddress1       ,ApplicantAddress2   ,ApplicantAddress3   ,ApplicantCity       ,ApplicantCounty       ,ApplicantState      ,ApplicantZip ,ApplicantPhone      ,ApplicantEmailAddress       ,ApplicantHICN       ,ApplicantSSN ,MailingAddress1     ,MailingAddress2     ,MailingAddress3       ,MailingCity  ,MailingState ,MailingZip   ,MedicarePartA       ,MedicarePartB       ,EmergencyContact    ,EmergencyPhone      ,EmergencyRelationship     ,PremiumDeducted       ,PremiumSource       ,OtherCoverage       ,OtherCoverageName   ,OtherCoverageId     ,LongTerm       ,LongTermName ,LongTermPhone       ,AuthorizedRepName   ,AuthorizedRepAddress       ,AuthorizedRepCity   ,AuthorizedRepState  ,AuthorizedRepZip    ,AuthorizedRepPhone       ,AuthorizedRepRelationship ,Language     ,Esrd  ,StateMedicaid       ,WorkStatus       ,PrimaryCarePhysician      ,OtherCoverageGroup  ,AgentId      ,SubmitTime   ,PartDSubAppInd       ,DeemedInd    ,SubsidyPercentage   ,DeemedReasonCode    ,LisCopayLevelId       ,DeemedCopayLevelId  ,PartDOptOutSwitch   ,SepReasonCode       ,SepCMSReasonCode       ,PremiumDirectPay    ,EnrollmentPlanYear  ,PremiumWithhold     ,SpouseWorkStatus       ,AccessibilityFormat ,EmailOptIn   ) 
VALUES (2002 ,'01012021'   ,'H0002'      ,'001' ,			Null ,		'Mr'       ,'FNB'       ,'A'   ,'LNB'       ,'01011961'   ,'M'   ,'Add2'      ,Null   ,Null    ,'MN'  ,'New York'  ,'NY'  ,12345        ,1234567890   ,'member@12xy.com'   ,'2G77AA0AD02'       ,6555555      ,13       ,11    ,55    ,'Rest6771'   ,'NY'  ,99999 ,01012019     ,01012019     ,'REST771'    ,6034249364       ,'Son' ,'Yes' ,''    ,'Yes' ,'My Coverage'       ,1234567891   ,'Yes' ,'Instuiton'  ,1234567891       ,'GEORGE WASHINGTON' ,'100main'    ,'CHICAGO'    ,'NH'  ,03054 ,1234567890   ,'Daughter/POA'       ,'Hindi'   ,''   ,'NO'  ,'No'     ,''    ,2     ,'001'   ,	  '2021-01-01 10:27:44.023'   ,'N','N'   ,50    ,2     ,Null       ,4     ,'Y'   ,'NEW 01012019,MOV 01012019,MDE 20200101,INC 01012021'    ,'CMS'   ,''    ,2021  ,'D'   ,'Yes' ,'Braille' ,'Yes')       
Insert INTO EnrollmentInfo (ConfirmationNumber   ,SubmitDate   ,ContractId   ,PlanId    ,SegmentId    ,ApplicantTitle      ,ApplicantFirstName  ,ApplicantMiddleInitial       ,ApplicantLastName   ,ApplicantBirthDate  ,ApplicantGender     ,ApplicantAddress1       ,ApplicantAddress2   ,ApplicantAddress3   ,ApplicantCity       ,ApplicantCounty       ,ApplicantState      ,ApplicantZip ,ApplicantPhone      ,ApplicantEmailAddress       ,ApplicantHICN       ,ApplicantSSN ,MailingAddress1     ,MailingAddress2     ,MailingAddress3       ,MailingCity  ,MailingState ,MailingZip   ,MedicarePartA       ,MedicarePartB       ,EmergencyContact    ,EmergencyPhone      ,EmergencyRelationship     ,PremiumDeducted       ,PremiumSource       ,OtherCoverage       ,OtherCoverageName   ,OtherCoverageId     ,LongTerm       ,LongTermName ,LongTermPhone       ,AuthorizedRepName   ,AuthorizedRepAddress       ,AuthorizedRepCity   ,AuthorizedRepState  ,AuthorizedRepZip    ,AuthorizedRepPhone       ,AuthorizedRepRelationship ,Language     ,Esrd  ,StateMedicaid       ,WorkStatus       ,PrimaryCarePhysician      ,OtherCoverageGroup  ,AgentId      ,SubmitTime   ,PartDSubAppInd       ,DeemedInd    ,SubsidyPercentage   ,DeemedReasonCode    ,LisCopayLevelId       ,DeemedCopayLevelId  ,PartDOptOutSwitch   ,SepReasonCode       ,SepCMSReasonCode       ,PremiumDirectPay    ,EnrollmentPlanYear  ,PremiumWithhold     ,SpouseWorkStatus       ,AccessibilityFormat ,EmailOptIn   ) 
VALUES (2003 ,'01012021'   ,'H1002'      ,'006' ,			Null ,		'Mr'       ,'FNC'       ,'A'   ,'LNC'       ,'01011962'   ,'M'   ,'Add3'      ,Null   ,Null    ,'MN'  ,'New York'  ,'NY'  ,12345        ,1234567890   ,'member@12xy.com'   ,'2G77AA0AD03'       ,6555555      ,13       ,11    ,55    ,'Rest6771'   ,'NY'  ,99999 ,01012019     ,01012019     ,'REST771'    ,6034249364       ,'Son' ,'Yes' ,''    ,'Yes' ,'My Coverage'       ,1234567891   ,'Yes' ,'Instuiton'  ,1234567891       ,'GEORGE WASHINGTON' ,'100main'    ,'CHICAGO'    ,'NH'  ,03054 ,1234567890   ,'Daughter/POA'       ,'British'   ,''   ,'NO'  ,'No'     ,''    ,2     ,'001'   ,	  '2021-01-01 10:27:44.023'   ,'N','N'   ,50    ,2     ,Null       ,4     ,'Y'   ,'NEW 01012019,MOV 01012019,MDE 20200101,INC 01012021'    ,'CMS'   ,''    ,2021  ,'D'   ,'' ,'' ,'')       
Insert INTO EnrollmentInfo (ConfirmationNumber   ,SubmitDate   ,ContractId   ,PlanId    ,SegmentId    ,ApplicantTitle      ,ApplicantFirstName  ,ApplicantMiddleInitial       ,ApplicantLastName   ,ApplicantBirthDate  ,ApplicantGender     ,ApplicantAddress1       ,ApplicantAddress2   ,ApplicantAddress3   ,ApplicantCity       ,ApplicantCounty       ,ApplicantState      ,ApplicantZip ,ApplicantPhone      ,ApplicantEmailAddress       ,ApplicantHICN       ,ApplicantSSN ,MailingAddress1     ,MailingAddress2     ,MailingAddress3       ,MailingCity  ,MailingState ,MailingZip   ,MedicarePartA       ,MedicarePartB       ,EmergencyContact    ,EmergencyPhone      ,EmergencyRelationship     ,PremiumDeducted       ,PremiumSource       ,OtherCoverage       ,OtherCoverageName   ,OtherCoverageId     ,LongTerm       ,LongTermName ,LongTermPhone       ,AuthorizedRepName   ,AuthorizedRepAddress       ,AuthorizedRepCity   ,AuthorizedRepState  ,AuthorizedRepZip    ,AuthorizedRepPhone       ,AuthorizedRepRelationship ,Language     ,Esrd  ,StateMedicaid       ,WorkStatus       ,PrimaryCarePhysician      ,OtherCoverageGroup  ,AgentId      ,SubmitTime   ,PartDSubAppInd       ,DeemedInd    ,SubsidyPercentage   ,DeemedReasonCode    ,LisCopayLevelId       ,DeemedCopayLevelId  ,PartDOptOutSwitch   ,SepReasonCode       ,SepCMSReasonCode       ,PremiumDirectPay    ,EnrollmentPlanYear  ,PremiumWithhold     ,SpouseWorkStatus       ,AccessibilityFormat ,EmailOptIn   ) 
VALUES (2004 ,'01012021'   ,'H1002'      ,'006' ,			Null ,		'Mr'       ,'FND'       ,'A'   ,'LND'       ,'01011963'   ,'M'   ,'Add4'      ,Null   ,Null    ,'MN'  ,'New York'  ,'NY'  ,12345       ,1234567890   ,'member@12xy.com'   ,'2G77AA0AD04'       ,6555555      ,13       ,11    ,55    ,'Rest6771'   ,'NY'  ,99999 ,01012019     ,01012019     ,'REST771'    ,6034249364       ,'Son' ,'Yes' ,''    ,'Yes' ,'My Coverage'       ,1234567891   ,'Yes' ,'Instuiton'  ,1234567891       ,'GEORGE WASHINGTON' ,'100main'    ,'CHICAGO'    ,'NH'  ,03054 ,1234567890   ,'Daughter/POA'       ,'Polish'   ,''   ,'NO'  ,'No'     ,''    ,2     ,'001'   ,	  '2021-01-01 10:27:44.023'   ,'N','N'   ,50    ,2     ,Null       ,4     ,'Y'   ,'NEW 01012019,MOV 01012019,MDE 20200101,INC 01012021'    ,'CMS'   ,''    ,2021  ,'D'   ,'Yes' ,'LargePrint' ,'Yes')       
Insert INTO EnrollmentInfo (ConfirmationNumber   ,SubmitDate   ,ContractId   ,PlanId    ,SegmentId    ,ApplicantTitle      ,ApplicantFirstName  ,ApplicantMiddleInitial       ,ApplicantLastName   ,ApplicantBirthDate  ,ApplicantGender     ,ApplicantAddress1       ,ApplicantAddress2   ,ApplicantAddress3   ,ApplicantCity       ,ApplicantCounty       ,ApplicantState      ,ApplicantZip ,ApplicantPhone      ,ApplicantEmailAddress       ,ApplicantHICN       ,ApplicantSSN ,MailingAddress1     ,MailingAddress2     ,MailingAddress3       ,MailingCity  ,MailingState ,MailingZip   ,MedicarePartA       ,MedicarePartB       ,EmergencyContact    ,EmergencyPhone      ,EmergencyRelationship     ,PremiumDeducted       ,PremiumSource       ,OtherCoverage       ,OtherCoverageName   ,OtherCoverageId     ,LongTerm       ,LongTermName ,LongTermPhone       ,AuthorizedRepName   ,AuthorizedRepAddress       ,AuthorizedRepCity   ,AuthorizedRepState  ,AuthorizedRepZip    ,AuthorizedRepPhone       ,AuthorizedRepRelationship ,Language     ,Esrd  ,StateMedicaid       ,WorkStatus       ,PrimaryCarePhysician      ,OtherCoverageGroup  ,AgentId      ,SubmitTime   ,PartDSubAppInd       ,DeemedInd    ,SubsidyPercentage   ,DeemedReasonCode    ,LisCopayLevelId       ,DeemedCopayLevelId  ,PartDOptOutSwitch   ,SepReasonCode       ,SepCMSReasonCode       ,PremiumDirectPay    ,EnrollmentPlanYear  ,PremiumWithhold     ,SpouseWorkStatus       ,AccessibilityFormat ,EmailOptIn   ) 
VALUES (2005 ,'01012021'   ,'H1002'      ,'006' ,			Null ,		'Mr'       ,'FNE'       ,'A'   ,'LNE'       ,'01011964'   ,'M'   ,'Add5'      ,Null   ,Null    ,'MN'  ,'New York'  ,'NY'  ,12345        ,1234567890   ,'member@12xy.com'   ,'2G77AA0AD05'       ,6555555      ,13       ,11    ,55    ,'Rest6771'   ,'NY'  ,99999 ,01012019     ,01012019     ,'REST771'    ,6034249364       ,'Son' ,'Yes' ,''    ,'Yes' ,'My Coverage'       ,1234567891   ,'Yes' ,'Instuiton'  ,1234567891       ,'GEORGE WASHINGTON' ,'100main'    ,'CHICAGO'    ,'NH'  ,03054 ,1234567890   ,'Daughter/POA'       ,'English'   ,''   ,'NO'  ,'No'     ,''    ,2     ,'001'   ,	  '2021-01-01 10:27:44.023'   ,'N','N'   ,50    ,2     ,Null       ,4     ,'Y'   ,'NEW 01012019,MOV 01012019,MDE 20200101,INC 01012021'    ,'CMS'   ,''    ,2021  ,'D'   ,'Yes' ,'AudioCD' ,'Yes')       

--Delete from EnrollmentInfo where Applicanthicn like '1H77AA0AD0%' -- 2020

--Delete from EnrollmentInfo where Applicanthicn like '2G77AA0AD0%' -- 2021


Select Applicanthicn,ContractID,PlanID,ApplicantFirstName,ApplicantLastName,ApplicantBirthDate,SpouseWorkStatus,AccessibilityFormat,EmailOptIn,SubmitDate,SubmitTime,EnrollmentPlanYear,*
From EnrollmentInfo where Applicanthicn like '2G77AA0AD0%'  ---2G77AA0AD0  --1C77AA0AD


--- Verify Data Inserted---
Select Applicanthicn,ContractId,PlanID,EnrollmentPlanYear,SubmitDate,SubmitTime,SpouseWorkStatus,AccessibilityFormat,EmailOptIn,*
From EnrollmentInfo
Where Applicanthicn like '1G77AA0AD0%'
And EnrollmentPlanYear = 2020












----Update EnrollmentInfo Set ContractId = 'H1001' , PlanID = '001' Where Applicanthicn = '7B61K30PL11131415'


----Metadata side job info verfication
--select * from pdmmetadata.[dbo].[SchedulerJobs] where Id = 'E4D9F7F7-EE59-48C4-8753-3B1F3C17BE2A' 

--select  startDate as dd,[status],* from pdmmetadata.[dbo].[SchedulerJobTriggers] where JobId = 'E4D9F7F7-EE59-48C4-8753-3B1F3C17BE2A' 
--and  IsTemplateTrigger = 0
--and Description = 'OEC API'  order by startDate desc


--Declare @JobDesc varchar(100) = 'OEC API'
--Declare @JobID varchar(100) = '6903c704-3858-4f77-b9f3-0c27a073c023' -- Job ID displays on UI
--Declare @RequestID varchar(100) = 'af084deb-303c-41b8-aff4-1c11c784d1ab' -- Request ID displays on UI
-- -- File ID displays on UI
 

---- [ EAMWarehouse side data and request id verfication ] ---

--Select * from EAMwarehouse..HistoryInputManagerjobs where jobid = @JobID -- job status 4

--Select * from EAMwarehouse..HistoryInputManagerrequests where  jobid = @JobID

--Select * from EAMwarehouse..HistoryInputManagerrequests where requestid = @RequestID -- match from UI

--Select * from EAMwarehouse..HistoryInputManagerentities where requestid = @RequestID--number of records u enter

--Select * from EAMwarehouse..HistoryInputManagerOecData where entityid in (select entityid from EAMwarehouse..HistoryInputManagerentities where requestid = @RequestID) ---Make sure Source against each transaction is 'OEC API'

 

---- EAM side data verfication 
--Declare @FileID varchar(100) = '2680'

--select  * from eam..ENRL_RESUBMIT_FILES where file_id = @FileID ---check for file name format

--select * from eam..tbOECData_loadingHdr  where FILE_ID = @FileID order by  ConvertedDt desc --- check file name and header info and HDRRAw header infomation

--select guid,* from eam..tbOECData_loading  where FILE_ID = @FileID order by  FILE_ID desc 

--select Source,* from EAMWarehouse.dbo.historyinputmanageroecdata where entityid in (select GUID from eam..tbOECData_loading  where FILE_ID = @FileID )




----OECLoad Table

--Select Applicanthicn,ContractId,PBPID,EnrollmentPlanYear,SubmitDate,SubmitTime,SpouseWorkStatus,AccessibilityFormat,EmailOptIn,SEPReasonCode,SEPCMSReasonCode
--from eam..tbOECData_loading Where File_ID = '3748'

----Select Top 1 * from eam..tbOECData_loading Where File_ID = '3074'
----Select * from eam..tbOECData_loading Where Applicanthicn = '6A77AA0AD04'


----ElecAppFile Table
--Select Error,IsProcessed,Applicanthicn,ContractId,PlanID,EnrollmentPlanYear,SubmitDate,SubmitTime,SpouseWorkStatus,AccessibilityFormat,EmailOptIn,FileName,SEPReasonCode,SEPCMSReasonCode
--From EAM..ElecAppFile -- order by LoadedDate Desc 
--Where FileName like 'OEC_20210317_031410_API_db804669-8382-4367-b515-76ae6383a7ff%' --_267b84de-3568-4644-900f-575216c162b7.FALLOUT'

----Select *
----From EAM..ElecAppFile -- order by LoadedDate Desc 
----Where FileName like 'OEC_20210306_065210_API%'

--Select Top 1 Language,*
--From EAM..ElecAppFile -- order by LoadedDate Desc 
--Where Applicanthicn = '1H77AA0AD01'


--Select Applicanthicn,ContractId,PlanID,EnrollmentPlanYear,SubmitDate,SubmitTime,SpouseWorkStatus,AccessibilityFormat,EmailOptIn,*
--From EnrollmentInfo
--Where 
----ContractId = 'T1234' And
--Applicanthicn like '1H77AA0AD01%' AND
--EnrollmentPlanYear = 2021


--Select * from eam..ElecAppFile where Applicanthicn in ('1H77AA0AD01','6A77AA0AD04')

--Select * from eam..tbtransactions where HIC in ('1H77AA0AD01','6A77AA0AD04') -- API,Batch

--Select * from eam..tbeenrlmembers where hic in  ('1H77AA0AD01','6A77AA0AD04') -- API,Batch

--Select * from eam..tbmemberinfo where MemCodNum in ('31262','31263')  --- API--- Batch OEC

--Select * from eam..tblanguage

----Transaction Level
--Select T.HIC,AE.FieldName,OriginalValue,NewValue, TriggerActionType
--From [EAMWarehouse].[Audit].[TransactionLevel_Audit] A Inner Join PDMMetadata.dbo.[AuditEntityFields] AE
--ON A.FieldId = AE.FieldId Join EAM..tbtransactions T
--On A.MemcodNum = T.Memcodnum
--Where T.HIC = '6A77AA0AD04'
--Order By AuditDate Desc  27/27

----Member Level
--Select T.HIC,AE.FieldName,OriginalValue,NewValue, TriggerActionType,auditdate
--From [EAMWarehouse].[Audit].[MemberLevel_Audit] A Inner Join PDMMetadata.dbo.[AuditEntityFields] AE
--ON A.FieldId = AE.FieldId Join EAM..tbtransactions T
--On A.MemcodNum = T.Memcodnum
--Where T.HIC = '6A77AA0AD05'
--Order By AuditDate Desc  83/72

--Select MedicarePartA,MedicarePartB,*
--From EAM..ElecAppFile --order by loadeddate desc
--Where ApplicantHICN In ('6A77AA0AD04','6A77AA0AD05','6A77AA0AD06') And IsProcessed = 1

--Select * from EAM.[dbo].[SalesReps]

--Select * from EnrollmentInfo where applicanthicn In ('6A77AA0AD04','6A77AA0AD05')


--Select * from enrollmentinfo where contractID = 'PDM02' and  EnrollmentPlanYear = 2021

--Update enrollmentinfo Set ContractID = 'XXXXX' where Enrollmentinfoid  = '7432'

--Update enrollmentinfo Set applicantssn = '6A77AA0AD04' where Enrollmentinfoid  = '7489'


--Select error,* from eam..elecappfile order by loadeddate desc

--Select error,applicanthicn,* from eam..elecappfile where filename = 'OEC_20210318_122010_API_7ca97f89-6e02-48dc-9614-ba8e730af918'