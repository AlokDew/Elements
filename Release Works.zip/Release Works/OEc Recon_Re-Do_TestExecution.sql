

Select OECNum,* from tbmemberinfo Where OECNum like 'OECR1001%'

Select * from tbtransactions Where hic like '3C77AA0AD%'

Select PlanID,PBPID,PBPType from tbplan_pbp Where PlanID = 'H0002' and PBPID = '006'

Select PlanID,PBPID,PBPType from tbplan_pbp Where PlanID = 'H1001' and PBPID = '001'

Select PlanID,PBPID,PBPType from tbplan_pbp Where PlanID = 'S2001' and PBPID = '001'

Select ConfirmationNumber,SubmitDate,SubmitTime,* from CMSBEQ.dbo.EnrollmentInfo where ConfirmationNumber like 'OECReDo10%'

--Delete CMSBEQ.dbo.EnrollmentInfo where ConfirmationNumber like 'OECReDo10%'

Select ApplicationDate,ReceiptDate,EffectiveDate,* from tbtransactions Where hic like '3C77AA0AD%'

Select Error, * from ElecAppFile where Applicanthicn like '3C77AA0AD%' And  IsProcessed = 0

Select * from ElecAppFile where FileName = 'OEC_01012021_ReDo_Fallout.txt'


Select MatchStatus,Applicanthicn,* from dbo.CmsManagerOecReconciliationData
Where ContractId in ('H0002','H1001','S2001')
And ConfirmationNumber like 'OECR%'

Select OECNum,* from tbmemberinfo Where OECNum like 'OECR%'


