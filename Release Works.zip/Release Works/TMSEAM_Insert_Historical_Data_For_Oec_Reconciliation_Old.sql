SET NOCOUNT ON; 
GO


DECLARE @iuser INT;
DECLARE @ErrMessage_Prereq VARCHAR(255);
DECLARE @DBname VARCHAR(128);
DECLARE @SQL VARCHAR(256);

SET @DBname = CONVERT(VARCHAR(128),DB_NAME());

SELECT @iuser = IS_MEMBER(user);
IF (@iuser <> 1)
BEGIN
	PRINT '--------------------------------------------------------------------------------------------------------'
	PRINT 'Unable to run this script. Current user is not a member of sysadmin group or role. Execution terminated.';
	PRINT '--------------------------------------------------------------------------------------------------------'
	
	RAISERROR('Unable to run this script. Current user is not a member of sysadmin group or role. Execution terminated.', 20,1)WITH LOG; 
END

-- For SQL Server 2014
IF EXISTS(Select 1 WHERE convert(int,SUBSTRING(convert(varchar(100),SERVERPROPERTY('ProductVersion')), 
      1,   CHARINDEX('.', convert(varchar(100),SERVERPROPERTY('ProductVersion')),0)-1)) = 12)
BEGIN
	SET  @SQL = 'ALTER DATABASE [' + @DBname + '] SET COMPATIBILITY_LEVEL = 100;';
	EXEC (@SQL);
END
GO

IF (SELECT DB_NAME()) in ('master','model','ReportServer','ReportServerTempDB','msdb','tempdb')
BEGIN
	PRINT '----------------------------------------------------------------------------------------------------------'
	PRINT 'This might not be TMS database. Please check database prior to running this script. Execution terminated.';
	PRINT '----------------------------------------------------------------------------------------------------------'

	RAISERROR('-------------------------------------------------------------------------------------------------------
	This might not be TMS database. Please check database prior to running this script. Execution terminated.', 20,1)WITH LOG; 
END

PRINT 'System Prerequisites CHECKS - Completed.'

GO

 
--DO NOT INCLUDE GO STATEMENTS ANYWHERE
DECLARE @App VARCHAR(16); 
SET @App = 'EAM';

IF (NOT EXISTS (SELECT [name] FROM sysobjects WHERE [name] = 'tbtransactions'))
BEGIN
	PRINT '';
	PRINT 'This might not be EAM database. Please check database prior to running this script. Execution terminated.'
	SET NOEXEC ON;
END
IF (NOT EXISTS (SELECT [name] FROM sysobjects WHERE [name] = 'CmsManagerOecReconciliationStatistics'))
BEGIN
	PRINT '';
	PRINT 'CmsManagerOecReconciliationStatistics table not exists, you need to install dacpac first.'
	SET NOEXEC ON;
END



--FILE NAME: PreDeploy_Bootstrap.sql
/*************************************************************************************************************************** 
***********************					    SCRIPT INFORMATION VARIABLES			          ******************************
***********************				DO NOT CHANGE ANYTHING - but variables assignments         *****************************/ 

	DECLARE @ScriptName VARCHAR(100), @PriorScriptName VARCHAR(64), @NextScriptName VARCHAR(64); 
	DECLARE @Pr_AppVersion VARCHAR(2), @Cr_AppVersion VARCHAR(5), @Nx_AppVersion VARCHAR(2);
	DECLARE @UpdateDesc VARCHAR(255), @ScriptPrefix VARCHAR(32), @MoreDscrpt VARCHAR(128), @IsPiorScriptSrubRequired BIT;	
	DECLARE @Pr_MJ_Release VARCHAR(2), @Cr_MJ_Release VARCHAR(2), @Nx_MJ_Release VARCHAR(2), @Remarks VARCHAR(255), @Remarks1 VARCHAR(255);
	DECLARE @Pr_MR_Release VARCHAR(3), @Cr_MR_Release VARCHAR(3), @Nx_MR_Release VARCHAR(3), @Prdct VARCHAR(8);
	DECLARE @Pr_HT_Release VARCHAR(3), @Cr_HT_Release VARCHAR(3), @Nx_HT_Release VARCHAR(3), @AllowExecMoreThanOnce BIT ;
	DECLARE @PriorScrubScriptName VARCHAR(64);
	

/**************************************************************************************************************************/


	IF OBJECT_ID('tempdb..#tbCurrentVersionDetails') IS NOT NULL          
    DROP TABLE #tbCurrentVersionDetails 

	CREATE TABLE #tbCurrentVersionDetails (
											AppVersion varchar(32) ,
											AppName varchar(32) ,
											ChangePackage_Version varchar(4),
											HotFix_Version varchar(4),
											Remarks VARCHAR(255))
	INSERT INTO #tbCurrentVersionDetails
	SELECT top 1 AppVersion,AppName  ,ChangePackage_Version,HotFix_Version ,Remarks
	FROM [tbDBUpdates] ORDER BY ID DESC

	--SELECT * FROM #tbCurrentVersionDetails

/***************************************************************************************************************************/
							
								
	DECLARE @AppName varchar(32) ,@ChangePackage_Version varchar(4),@HotFix_Version varchar(4) ,@EAMScriptName varchar(100) = 'SCRIPT_INSERT_HISTORICAL_DATA_FOR_OEC_RECONCILIATION'


    SELECT @Cr_AppVersion= AppVersion  from #tbCurrentVersionDetails
	SELECT @ChangePackage_Version= ChangePackage_Version  from #tbCurrentVersionDetails
	SELECT @HotFix_Version= HotFix_Version  from #tbCurrentVersionDetails
	SELECT @AppName= AppName  from #tbCurrentVersionDetails
	SELECT @Remarks = Remarks from #tbCurrentVersionDetails
	SET @Prdct = 'TMS'
			
    SET @ScriptName=@Prdct + @AppName + '_' +@Cr_AppVersion + '.' + @ChangePackage_Version+ '.'+ @HotFix_Version+ '_'  + @EAMScriptName
	SET @UpdateDesc = 'Update: EAM | TMSEAM_' +@Cr_AppVersion + '.' + @ChangePackage_Version+ '.'+ @HotFix_Version + ' Script to insert historical data in CmsManagerOecReconciliationStatistics'  
	
	  ---select @ScriptName,@UpdateDesc,@Remarks,@Cr_AppVersion,@AppName,@ChangePackage_Version,@HotFix_Version
/****************************************************************************************************************************/

--Permorm a check weterher it's a TMS Database
IF (NOT EXISTS (SELECT [name] FROM sysobjects WHERE [name] = 'tbDBUpdates'))
BEGIN	
	RAISERROR('This might not be TMS database. Please check database prior to running this script. Execution terminated.', 20,1)WITH LOG; 
END


--For First Time Installers
IF( NOT( EXISTS( SELECT 1 FROM dbo.tbDBUpdates))) 
BEGIN
print 'insert'
	INSERT INTO dbo.tbDBUpdates(
					ScriptName,
					UpdateDesc,
					Remarks,
					ExecuteDate,
					CreateDate,
					AppVersion,
					AppName,
					ChangePackage_Version,
					HotFix_Version,
					ScriptSource)
			SELECT	@ScriptName,
					@UpdateDesc,
					@Remarks,
					GETDATE(),
					GETDATE(),
					@Cr_AppVersion,
					@AppName,
					@ChangePackage_Version,
					@HotFix_Version,
					'Scrub';
			
END

--FILE NAME: PreDeploy_log.sql

	DELETE tbDBUpdateStaging;

	DECLARE @INSERT_SQL NVARCHAR (2000);
	
	IF @@ERROR = 0
	BEGIN		
			INSERT INTO tbDBUpdateStaging(
					ScriptName,
					spID,
					usID,
					dbID,
					UpdateDesc,
					Remarks,
					AppVersion,
					AppName,
					ChangePackage_Version,
					HotFix_Version,
					ScriptSource)
			SELECT @ScriptName ,
					spID,
					user_ID(),
					db_ID(),
					@UpdateDesc,
					@Remarks,
					@Cr_AppVersion,
					@AppName,
					@ChangePackage_Version,
					@HotFix_Version,
					'Development'
			FROM  master.dbo.sysprocesses WHERE
				dbID = db_ID() and 
				uID = user_ID() and 
				kpID <> 0 and 
				spID = @@SPID;

		END



/*-------------------------- SCRIPT CHANGE STARTED ----------------------*/
GO
IF NOT EXISTS (SELECT 1 FROM tbDBUpdates WHERE ScriptName LIKE '%SCRIPT_INSERT_HISTORICAL_DATA_FOR_OEC_RECONCILIATION%')
BEGIN
DECLARE @StartDate DATETIME =  '2021-01-01 00:00:00'
INSERT INTO [dbo].[CmsManagerOecReconciliationStatistics]
			(ContractYear
			,ContractId
			,FileDate
			,EnrollmentInEAM)
SELECT EnrollmentPlanYear AS ContractYear
	   , PlanId AS ContractId
	   , ApplicationDate AS FileDate
	   , COUNT(1) AS EnrollmentInEAM
FROM [dbo].[tbtransactions]
WHERE ProgramSource = '5' 
	  AND TransCode = '61' 
	  AND ApplicationDate BETWEEN @StartDate AND GETDATE()
	  AND EnrollmentPlanYear IS NOT NULL
GROUP BY EnrollmentPlanYear, PlanId, ApplicationDate 
END
GO
/*-----------------------------------SCRIPT CHANGE ENDED----------------------------------*/

/*** WRITE INTO TBDBUPDATES ***/
   
	  
 DECLARE @ScriptName as VARCHAR(100);
 SELECT @ScriptName = ScriptName FROM tbDBUpdateStaging

IF NOT EXISTS (SELECT 1 FROM dbo.tbDBUpdates WHERE ScriptName = @ScriptName)
begin
	INSERT INTO dbo.tbDBUpdates (
				[ScriptName],
				[UpdateDesc],
				[Remarks],
				[ExecuteDate],
				[CreateDate],
				[AppVersion],
				[AppName],
				[ChangePackage_Version],
				[HotFix_Version],
				[ScriptSource]
			)
			SELECT
				ScriptName,
				[UpdateDesc], 
				[Remarks],
				getdate(),
				getdate(), 
				[AppVersion],
				[AppName],
				[ChangePackage_Version],
				[HotFix_Version],
				[ScriptSource]
			FROM 
			tbDBUpdateStaging;
			end
ELSE  
		UPDATE d
			SET 
				d.CreateDate = CASE WHEN d.CreateDate IS NULL THEN getdate() ELSE d.CreateDate END,
				d.ExecuteDate = getdate(),
				d.UpdateDesc = s.UpdateDesc,
				d.Remarks = s.Remarks,
				d.AppVersion = s.AppVersion,
				d.ChangePackage_Version = s.ChangePackage_Version,
				d.HotFix_Version = s.HotFix_Version,
				d.ScriptSource = s.ScriptSource
			FROM dbo.tbDBUpdates d INNER JOIN tbDBUpdateStaging s ON
				d.ScriptName COLLATE DATABASE_DEFAULT = s.ScriptName COLLATE DATABASE_DEFAULT;



PRINT 'Script: ' + @ScriptName + ' Completed on ' + CONVERT(VARCHAR,GETDATE(),100) + '.';
PRINT '';


GO