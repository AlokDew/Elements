
--000 - Both PRocessed and MAtch flag = Y
--100 or 101 - Processed = Y and Match = N
--other codes - Both Processed �and Match = N
USE EAM
Delete FROM [dbo].[tbEGWPPlanPbpAssociation]

Select multiple from tbplan_pbp

Update tbplan_pbp Set multiple = 0 

Select * from tbtransactions where hic like '6G77C00AA0%'

Select * from tbplan_pbp Where PlanID = 'H1001' ANd PBPID IN ('001','002')
Select * from tbplan_pbp Where PlanID = 'H0002' ANd PBPID = '006'
Select * from tbplan_pbp Where PlanID = 'S2001' ANd PBPID = '001'

--Select Error,Isprocessed,Applicanthicn,* from ElecAppFile Where Applicanthicn like '6H77C00AA1%'

Select Error,Isprocessed,Applicanthicn,* from ElecAppFile
Where FileName In('OEC_01012020_BEQAPI_TC61A6_H10001.txt','EAF_BEQAPITC61A1_01012020.txt') 

Exec BEQResponse_Generator '6G77C00AA04',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20250101;
MedPartBEntStartDate=20250101;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'

Select HIC, TransCode,TransStatus,Planid,PBPid,EffectiveDate,ElectionType
From tbtransactions
Where HIC Between '6G77C00AA01' AND '6G77C00AA07'


Select T.HIC,L.PartDSubsLevel,L.LowIncCoPayCat,L.LowIncomeCoPayEffectiveDate,L.LowIncomeCoPayEndDate,T.TransStatus
From tbMemberInfoLISLog L Join tbtransactions T
On L.MemCodNum = T.MemCodNum
Where T.HIC In ('6G77C00AA03','6G77C00AA05','6G77C00AA07')

SELECT [ClaimNumber],[DOB],[Sex],[Surname],[FirstName],[MiddleInitial],[EffDatePartA],[TermDatePartA],[EffDatePartB],[TermDatePartB]
      ,[ESRD],[Medicaid],[SCC],[CC],[EmplSubs],[EffDatePartD],[LISEffDate1],[LISEndDate1],[CoPay1],[LISPercent1],[LISEffDate2],[LISEndDate2]
      ,[CoPay2],[LISPercent2],[CMSDOB],[CMSSex],[PartCDPlanID],[PartCDEnrollStartDate],[PartDIndicator],[PartCPlanID],[PartCEnrollStartDate]
      ,[PartCIndicator],[PrevEnrolledPartD],[PartCDPbpId],[PartCDPlanType],[PartCDEghpIndicator],[PartCPbpId],[PartCPlanType],[PartCEghpIndicator]

FROM [EAM].[dbo].[tbEligibility]

WHERE [FileControlNum] = 0 

And [ClaimNumber] LIKE '6G77C00AA0%' 


Select Distinct T.HIC,L.PartDSubsLevel,L.LowIncCoPayCat,L.LowIncomeCoPayEffectiveDate,L.LowIncomeCoPayEndDate,L.ChangeSource

From tbMemberInfoLISLog L Join tbtransactions T

On L.MemCodNum = T.MemCodNum

Where T.HIC Like '6G77C00AA0%'

Select T.HIC,AE.FieldName,OriginalValue,NewValue, TriggerActionType,auditdate
From [EAMWarehouse].[Audit].[TransactionLevel_Audit] A Inner Join PDMMetadata.dbo.[AuditEntityFields] AE
ON A.FieldId = AE.FieldId Join tbtransactions T
On A.MemcodNum = T.Memcodnum
Where TriggerActionType = 'Change'
And T.HIC = '6G77C00AA07'


Select T.HIC,AE.FieldName,OriginalValue,NewValue, TriggerActionType,auditdate
From [EAMWarehouse].[Audit].[MemberLevel_Audit] A Inner Join PDMMetadata.dbo.[AuditEntityFields] AE
ON A.FieldId = AE.FieldId Join tbtransactions T
On A.MemcodNum = T.Memcodnum
Where TriggerActionType = 'Change'
And T.HIC = '6G77C00AA07'




--Select HIC, TransCode,TransStatus,Planid,PBPid,EffectiveDate,ElectionType from tbtransactions Where HIC like '6C77C00AA1%' 

--Select TransID from tbtransactions where PlanID = 'H0002' and hic = '6C77C00AA11'

--Select DateComplete,* from tbnotes where data = '30485'

--Update tbtransactions set ElectionType = Null where TransID = '30485'




--Select HIC, TransCode,TransStatus,Planid,PBPid,EffectiveDate,ElectionType,IsElectionTypeManual
--From tbtransactions 
--Where 
--TransStatus = 2 and 
--HIC like '6C77C00AA1%' 

--Select membermcaid,* from tbmemberinfo Where memcodnum in (Select memcodnum from tbtransactions where hic like '6H77C00AA1%')

--Select * from tbnotes where data = '38833' in (select TransID from tbtransactions where PLanID = 'H0002' and hic = '6H77C00AA11')

--SELECT Distinct [ClaimNumber],[DOB],[Sex],[Surname],[FirstName],[MiddleInitial],[EffDatePartA],[TermDatePartA],[EffDatePartB],[TermDatePartB]
--      ,[ESRD],[Medicaid],[SCC],[CC],[EmplSubs],[EffDatePartD],[LISEffDate1],[LISEndDate1],[CoPay1],[LISPercent1],[LISEffDate2],[LISEndDate2]
--      ,[CoPay2],[LISPercent2],[CMSDOB],[CMSSex],[PartCDPlanID],[PartCDEnrollStartDate],[PartDIndicator],[PartCPlanID],[PartCEnrollStartDate]
--      ,[PartCIndicator],[PrevEnrolledPartD],[PartCDPbpId],[PartCDPlanType],[PartCDEghpIndicator],[PartCPbpId],[PartCPlanType],[PartCEghpIndicator]
--FROM [EAM].[dbo].[tbEligibility]
--WHERE [ClaimNumber] IN ('6C77C00AA10','6C77C00AA11','6C77C00AA12','6C77C00AA13') 
--Order by DateReceived Desc

--Select Distinct T.HIC,L.PartDSubsLevel,L.LowIncCoPayCat,L.LowIncomeCoPayEffectiveDate,L.LowIncomeCoPayEndDate,T.TransStatus,L.ChangeSource
--From tbMemberInfoLISLog L Join tbtransactions T
--On L.MemCodNum = T.MemCodNum
--Where T.TransStatus = 2
--And 
--T.HIC In('6C77C00AA10','6C77C00AA11','6C77C00AA12','6C77C00AA13')

--Update tbNotes Set DateComplete = '2021-01-01' where Category in ('ICEP','AEP','MAOEP','IEP','IEP2','OEPI','SEPS')

--Select TransID,HIC, TransCode,TransStatus,Planid,PBPid,EffectiveDate,ElectionType
--From tbtransactions
--Where 
--HIC Between '6C77C00AA10' AND '6C77C00AA13'



--Select TransID from tbtransactions where PLanID = 'H0002' and hic = '6H77C00AA11'
--Select DateComplete,* from tbnotes where data = '38833'

----1 6X77C00AA02/3 : Make transactions Active
----2 Add New Transaction 6X77C00AA02 Plan Change: H1001,001 - 02012021 01012021 (Watch OUT Part A, B and D Date), New to Medicare
----3 Add New Transaction 6X77C00AA03 PBP Change : H1001, 002 - 07012020 06302020 , Make Status Change by selecting gender F
----4 Make Status Change 6X77C00AA05
----5 MAke Failed BEQ 6X77C00AA04 and 6X77C00AA06 : 


--Exec BEQResponse_Generator '6D77C00AA04,6D77C00AA06',
--'ProcessedFlag=Y;
--BeneficiaryMatchFlag=Y;
--CurrentEnrlSrcTypeCodePartCD=A;
--CurrentEnrlSrcTypeCodePartC=D;'

----MedPartAEntStartDate=20250101;
----MedPartBEntStartDate=20250101;					
					
--Select HIC, TransCode,TransStatus,Planid,PBPid,EffectiveDate,ElectionType
--From tbtransactions
--Where 
----TransStatus = 2 And
--HIC Between '6H77C00AA10' AND '6H77C00AA13'

--Select * from Delete tbnotes where data Between '38832' And '38839'

--Select T.HIC,L.PartDSubsLevel,L.LowIncCoPayCat,L.LowIncomeCoPayEffectiveDate,L.LowIncomeCoPayEndDate,T.TransStatus,L.ChangeSource
--From tbMemberInfoLISLog L Join tbtransactions T
--On L.MemCodNum = T.MemCodNum
--Where T.HIC In ('6D77C00AA03','6D77C00AA05','6D77C00AA07')


-- --Select * from [BeqLowIncomeSubsidyInfo] where MedicareBeneficiaryIdentifier = @MBI

-- --Select * from [BeqEnrollmentInfo] where MedicareBeneficiaryIdentifier = @MBI

----Select * from eam..tbtransactions where hic like @MBI
-- Use CMSBEQ
-- Declare @MBI varchar(100) = '6D77C00AA02'
-- Select * from [BeqAddressInfo] where MedicareBeneficiaryIdentifier = @MBI
-- Select * from [BeqBeneficiaryInfo] where MedicareBeneficiaryIdentifier = @MBI
-- Select * from [BeqEnrollmentInfo] where MedicareBeneficiaryIdentifier = @MBI
-- Select * from [BeqEntitlementReasonInfo] where MedicareBeneficiaryIdentifier = @MBI
-- Select * from [BeqLowIncomeSubsidyInfo] where MedicareBeneficiaryIdentifier = @MBI
-- Select * from [BEQMedicareCardInfo] where MedicareBeneficiaryIdentifier = @MBI
-- Select * from [BeqPeriodInfo] where MedicareBeneficiaryIdentifier = @MBI
-- Select * from [BEQResponseCodeInfo] where MedicareBeneficiaryIdentifier = @MBI
-- Select * from [BeqStateCountyInfo] where MedicareBeneficiaryIdentifier = @MBI
-- Select * from [BEQUncoveredMonthsInfo] where MedicareBeneficiaryIdentifier = @MBI

-- Select * from BeqPeriodType

-- /*
-- Declare @MBI varchar(100) = '6D77C00AA02'
-- Use CMSBEQ

-- Delete from [BeqAddressInfo] where MedicareBeneficiaryIdentifier = @MBI
-- Delete from [BeqBeneficiaryInfo] where MedicareBeneficiaryIdentifier = @MBI
-- Delete from [BeqEnrollmentInfo] where MedicareBeneficiaryIdentifier = @MBI
-- Delete from [BeqEntitlementReasonInfo] where MedicareBeneficiaryIdentifier = @MBI
-- Delete from [BeqLowIncomeSubsidyInfo] where MedicareBeneficiaryIdentifier = @MBI
-- Delete from [BEQMedicareCardInfo] where MedicareBeneficiaryIdentifier = @MBI
-- Delete from [BeqPeriodInfo] where MedicareBeneficiaryIdentifier = @MBI
-- Delete from [BEQResponseCodeInfo] where MedicareBeneficiaryIdentifier = @MBI
-- Delete from [BeqStateCountyInfo] where MedicareBeneficiaryIdentifier = @MBI
-- Delete from [BEQUncoveredMonthsInfo] where MedicareBeneficiaryIdentifier = @MBI
-- */
----6 Export BEQ - H1001,H0002,S2001					
			
--Select * from eam..tbeligibility where claimnumber like '6D77C00AA02' --, '6C77C00AA02')

--Select  * from eam..tbtransactions where hic in ('6D77C00AA04')--, '6C77C00AA01') 
 
--Select * from eam..tbnotes where data = '37698'

-- Select * from eam..tbBeqRespData_loading where orighic In ('6C77C00AA03')

--Update eam..tbeligibility Set PartCDPlanID = Null, PartCPlanID = Null Where TransID = '37556'

--Delete eam..tbeligibility where claimnumber = '6D77C00AA04'

--Delete eam..tbBeqRespData_loading where orighic In ('6D77C00AA02')

--Delete eam..tbnotes where data = '37685'

--Select EffDatePartA,EffDatePartB,* from eam..tbeligibility where ClaimNumber In ('6D77C00AA01', '6C77C00AA01') and EligibilityId in (10174,10227)

--Select PartAEffDate,PartBEffDate,* from eam..tbBeqRespData_loading where orighic In ('6D77C00AA01', '6C77C00AA01') And ID in ('10266','10471')


----AEP					
--Exec BEQResponse_Generator '6D77C00AA04',
--'ProcessedFlag=Y;
--BeneficiaryMatchFlag=Y;
--MedPartAEntStartDate=20200101;
--MedPartBEntStartDate=20200101;
--PartDEligibilityStartDate=20200101;
--CurrentEnrlSrcTypeCodePartCD=A;
--CurrentEnrlSrcTypeCodePartC=D;' 

 
----IEP  -- 717 Remove
--exec BEQResponse_Generator '6C77C00AA02',
--'ProcessedFlag=Y;
--BeneficiaryMatchFlag=Y;
--MedPartAEntStartDate=20210201;
--MedPartBEntStartDate=20210201;
--PartDEligibilityStartDate=20210201;
--CurrentEnrlSrcTypeCodePartCD=A;
--CurrentEnrlSrcTypeCodePartC=D;

--DeemedLISEffDate1=20200201;
--DeemedLISEndDate1=20201231;
--PartDPremiumSubsidyPercent1=050;
--CopayLelelId1=4;

--DeemedLISEffDate2=20210101;
--DeemedLISEndDate2=20211231;
--PartDPremiumSubsidyPercent2=075;
--CopayLelelId2=4'				

--Exec BEQResponse_Generator '6C77C00AA03',
--'ProcessedFlag=Y;
--BeneficiaryMatchFlag=Y;
--MedPartAEntStartDate=20110201;
--MedPartBEntStartDate=20110201;
--PartDEligibilityStartDate=20110201;

--DeemedLISEffDate1=20200701;
--DeemedLISEndDate1=20201231;
--PartDPremiumSubsidyPercent1=075;
--CopayLelelId1=4'

----ICEP	-- 717 Remove			
--exec BEQResponse_Generator '6C77C00AA04',
--'ProcessedFlag=Y;
--BeneficiaryMatchFlag=Y;
--MedPartAEntStartDate=20190201;
--MedPartBEntStartDate=20190201;
--CurrentEnrlSrcTypeCodePartCD=A;
--CurrentEnrlSrcTypeCodePartC=D;

--DeemedLISEffDate1=20200701;
--DeemedLISEndDate1=20201231;
--PartDPremiumSubsidyPercent1=100;
--CopayLelelId1=1'					
					
----IEP2
--exec BEQResponse_Generator '6C77C00AA05',
--'ProcessedFlag=Y;
--BeneficiaryMatchFlag=Y;
--MedPartAEntStartDate=20200201;
--MedPartBEntStartDate=20200201;
--PartDEligibilityStartDate=20190101;
--CurrentEnrlSrcTypeCodePartCD=A;
--CurrentEnrlSrcTypeCodePartC=D;

--DeemedLISEffDate1=20200401;
--DeemedLISEndDate1=20201231;
--PartDPremiumSubsidyPercent1=100;
--CopayLelelId1=2'					
					
----SEPU				
--Exec BEQResponse_Generator '6C77C00AA06',
--'ProcessedFlag=Y;
--BeneficiaryMatchFlag=Y;
--MedPartAEntStartDate=20190101;
--MedPartBEntStartDate=20190201;
--PartDEligibilityStartDate=20190101;
--DeemedLISEndDate1=20191212;
--NotLawfulPresenceStartDate1=20180201;
--NotLawfulPresenceEndDate1=20181231'
 
---- SEPS
---- exec BEQResponse_Generator '6X77C00AA07',
----'ProcessedFlag=Y;
----BeneficiaryMatchFlag=Y;
----MedPartAEntStartDate=20140404;
----MedPartAEntEndDate=20241010;
----MedPartBEntStartDate=20140505;
----MedPartBEntEndDate=20241111;
----MedicaidIndicator=;
----PartDEligibilityStartDate=;
----ESRDIndicator=;
----PartCPlanType=;
----PartCDPlanType=;
----NotLawfulPresenceEndDate10=20120101;
----CurrentEnrlSrcTypeCodePartCD=B;
----CurrentEnrlSrcTypeCodePartC=D;
----PartDIndicator=Y;
----PriorPartCDContractNumber=H1002;
----PriorPartCDEnrlStartDate=20190201;
----PartCEnrollStartDate=20190201;

----DeemedLISEffDate1=20200701;
----DeemedLISEndDate1=20201231;
----PartDPremiumSubsidyPercent1=100;
----CopayLelelId1=4'

		

-----SEPS
--Exec BEQResponse_Generator '6C77C00AA07',   
--'ProcessedFlag=Y;   
--BeneficiaryMatchFlag=Y;   
--MedPartAEntStartDate=20110101;   
--MedPartBEntStartDate=20110101;
--PartDEligibilityStartDate=20110201;
--NotLawfulPresenceEndDate10=20110101;   
--CurrentEnrlSrcTypeCodePartCD=A;   
--CurrentEnrlSrcTypeCodePartC=D;

--DeemedLISEffDate1=20200701;
--DeemedLISEndDate1=20201231;
--PartDPremiumSubsidyPercent1=100;
--CopayLelelId1=4'				
					
					
					
--------------------------------------------------------------



--Select Applicanthicn,Error,IsProcessed from ElecAppFile where Applicanthicn like '6C77C00AA%'

--Select HIC, TransCode,TransStatus,Planid,PBPid,EffectiveDate,ElectionType from tbtransactions Where HIC like '6C77C00AA%' 

--Select T.HIC,L.PartDSubsLevel,L.LowIncCoPayCat,L.LowIncomeCoPayEffectiveDate,L.LowIncomeCoPayEndDate,T.TransStatus
--From tbMemberInfoLISLog L Join tbtransactions T
--On L.MemCodNum = T.MemCodNum
--Where T.TransStatus = 2
--And 
--T.HIC like '6C77C00AA%' In ('6C77C00AA03','6C77C00AA05','6C77C00AA07')

--Select * from tbtransactions where memcodnum = '56296'

--Select * from tbEligibility Where ClaimNumber like '6C77C00AA%'


--Select T.HIC,AE.FieldName,OriginalValue,NewValue, TriggerActionType,auditdate
--From [EAMWarehouse].[Audit].[TransactionLevel_Audit] A Inner Join PDMMetadata.dbo.[AuditEntityFields] AE
--ON A.FieldId = AE.FieldId Join tbtransactions T
--On A.MemcodNum = T.Memcodnum
--Where TriggerActionType = 'Change'
--And T.HIC = '6C77C00AA07'

--Select T.HIC,AE.FieldName,OriginalValue,NewValue, TriggerActionType,auditdate
--From [EAMWarehouse].[Audit].[MemberLevel_Audit] A Inner Join PDMMetadata.dbo.[AuditEntityFields] AE
--ON A.FieldId = AE.FieldId Join tbtransactions T
--On A.MemcodNum = T.Memcodnum
--Where TriggerActionType = 'Change'
--And T.HIC = '6C77C00AA07'

--And AE.FieldName In ('AccessibilityFormat','Language','SpouseWorkStatus','EmailOptIn','Email') 
--Order By AuditDate Desc					
					
					
					
					
					

					
					
					
					
					
					
					
					
				
					
				
					
					
					
					
					
					

					
					
					
					
					
					

					
					
					
					
					
					
					
					
				
					
					
					
					

'