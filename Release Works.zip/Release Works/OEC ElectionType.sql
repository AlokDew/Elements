Select * from tbtransactions where hic like '2D77C00AA%'

Select Error,ApplicantHICN,SepReasonCode,SubmitDate,SubmitTime,EnrollmentPlanYear,*
From ElecAppFile where ISProcessed = 1 And FileName = 'OEC_17072020_MAOEP03R4_05.txt'
																		
Select TransID,MemCodNum,HIC,PlanID, TransDOB, EffectiveDate,ReceiptDate as 'RecDate/SubmitDate',ApplicationDate,ElectionType,SEPSReason,TransStatus,iselectiontypemanual from Tbtransactions																		
Where HIC In (Select ApplicantHICN from ElecAppFile where ISProcessed = 1 And FileName = 'OEC_17072020_MAOEP01R4_06Y01.txt')																		
													

Update tbtransactions Set ReceiptDate = '2019-12-01' where TransID In ('106498')
Update tbtransactions Set TransStatus = 0	where HIC In ('7B77C00AZ57','7B77C00AZ58')

																	
Select TransID,MemCodNum,PlanID,HIC, EffectiveDate,ReceiptDate as 'RecDate/SubmitDate',ApplicationDate,ElectionType,SEPSReason,TransStatus from Tbtransactions																		
where hic  > '7B77C00AZ26'	AND hic < '7B77C00AZ31'																	
																		
Select * From tbPlan_pbp tbpbp inner join tbPlans tbplan																		
on tbpbp.PlanId = tbPlan.PlanId																		
Where pbptype = 1																		
																		
exec BEQResponse_Generator '7C77C01NN55',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20190201;
MedPartBEntStartDate=20190201;
PartCPlanType = 29
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'		
	
-- Queue Type																
-- Select * from [ConfigurationManagerQueueTypes]	
--PartDEnrEffDateEmpSubsStartDate1=20180101;														
--PartCDEnrollStartDate																		
--PartDIndicator																	
--PartCContractNumber																		
--PartCEnrollStartDate																		
																	
-------------------------------------------------
-- Work Around																	
																		
																		
Select * from elecappfile where filename  like '%oec%'


Select * from tbNotes Where Data = '107615'					--[First delete your data from table]	
						
Select * from tbtransactions Where hic = '7C77C01NW57'						
						
Delete from tbNotes Where Data like '107615'	  --<Delete Queue from table Trans ID> 

						--[First delete your data from table]
						
---- Eligibility Table Update data---------------						[Second Update PartCDPlnID from eligibility table]
Select PartCDPlanID,PartCEnrollStartDate,* from tbEligibility Where TransID = '107615'						
Update tbEligibility Set PartCEnrollStartDate = '2019-02-02 00:00:00.000' Where TransID = '107615' 	

Select * From tbPlan_pbp tbpbp inner join tbPlans tbplan
on tbpbp.PlanId = tbPlan.PlanId
Where  pbptype = 1


Select * from TransactionManagerAttestations where transid = '45662'

Select VisionOSB,MedicalOSB,DentalOSB,OtherOSB, * from elecappfile where filename like '%oec%'

	

				
				
					
					
Select EffectiveDate,EndDate,PremC,PremD from tbPlanPBPSegPremSpans
Where PlanId='H1003' and PBPID='011'and EffectiveDate In ('2019','2020','2021')

Select T.HIC,TransStatus,T.PlanID,T.PBPID,ApplicationDate,T.EffectiveDate,S.StartDate as SpanStart, S.EndDate as SpanEnd,PartC as TransPartC,PartD as TransPartD, M.PartCPremium as MemPartC, M.PartDPRemium as MemPartD
From Tbtransactions T Join tbmemberinfo M On T.MemCodNum = M.MemCodNum Join ElecAppFile E
On T.HIC = E.ApplicantHICN Join tbENRLSpans  S
On T.HIC = S.HIC															
Where E.FileName = 'OEC_00000000_SCCPRem002_H1003.txt'
Order by HIC
					



					
Select * from [dbo].[tbBEQBatchNumber]
Select * from [dbo].[tbBEQRespData_loading]





BEQResponse_Generator

SP_HElptext BEQResponse_Generator 


exec BEQResponse_Generator '7C77C01MO56',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20190201;
MedPartBEntStartDate=20190201;
PartCPlanType=50;
PartCEnrollStartDate=20200401;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'	

exec BEQResponse_Generator '7C77C01MN56',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20190201;
MedPartBEntStartDate=20190201;
PartCPlanType=;
PartCEnrollStartDate=20190201;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'	

exec BEQResponse_Generator '7C77C01MN57',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20190201;
MedPartBEntStartDate=20190201;
PartCPlanType=50;
PartCEnrollStartDate=20190201;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'	
					
					
					
					
					
					
					
					
