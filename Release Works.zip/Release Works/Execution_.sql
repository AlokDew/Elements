
Select Applicanthicn,ContractId,PlanID,EnrollmentPlanYear,SubmitDate,SubmitTime,SpouseWorkStatus,AccessibilityFormat,EmailOptIn
From EnrollmentInfo
Where 
--ContractId = 'T9876' And
--Applicanthicn like '6A77AA0AD%' AND
EnrollmentPlanYear = 2020


Select MedicarePartA,MedicarePartB,*
From EAM..ElecAppFile order by loadeddate desc
Where ApplicantHICN In ('5A77AA0AD01','4A77AA0AD01') And IsProcessed = 1

Select * from [dbo].[SalesReps]

Select * from tbmemberinfo where MemCodNum in ('20961','20962')
Select * from tbtransactions where HIC in ('5A77AA0AD01','4A77AA0AD01')
Select * from tbeenrlmembers where hic in ('5A77AA0AD01','4A77AA0AD01')

Declare @JobDesc varchar(100) = 'OEC API'
Declare @JobID varchar(100) = 'fd172b3a-bc92-47fa-a2db-1d0a652233e3' -- Job ID displays on UI
Declare @RequestID varchar(100) = '2be630d2-f1ed-4298-9376-f7f782252572' -- Request ID displays on UI
Declare @FileID varchar(100) = '3011' -- File ID displays on UI

--[ Metadata side job info verfication ]--

--Select  * from pdmmetadata.[dbo].[SchedulerJobs] where Name = @JobDesc order by createdate desc --- Job Scheduler 

--Select StartDate "TriggerTime", [Status], * from pdmmetadata.[dbo].[SchedulerJobTriggers] ---  Job Trigger
--where Id = @JobID  --- Unique ID for OEC API 
------and  IsTemplateTrigger = 0  order by startDate desc 

--Select * from pdmmetadata.[dbo].SchedulerJobParameters where TriggerId = @JobID --- All Job Related Parameters like van see on information popup

  
-- [ EAMWarehouse side data and request id verfication ] ---

Select * from EAMwarehouse..HistoryInputManagerjobs where jobid = @JobID -- job status 4

Select * from EAMwarehouse..HistoryInputManagerrequests where  jobid = @JobID

Select * from EAMwarehouse..HistoryInputManagerrequests where requestid = @RequestID -- match from UI

Select * from EAMwarehouse..HistoryInputManagerentities where requestid = @RequestID--number of records u enter

Select * from EAMwarehouse..HistoryInputManagerOecData where entityid in (select entityid from EAMwarehouse..HistoryInputManagerentities where requestid = @RequestID) ---Make sure Source against each transaction is 'OEC API'

  
-- EAM side data verfication 

--Declare @FileID varchar(100) = '3005'

select  * from eam..ENRL_RESUBMIT_FILES where file_id = @FileID ---check for file name format

select * from eam..tbOECData_loadingHdr  where FILE_ID = @FileID order by  ConvertedDt desc --- check file name and header info and HDRRAw header infomation

select guid,* from eam..tbOECData_loading  where FILE_ID = @FileID order by  FILE_ID desc 

select Source,* from EAMWarehouse.dbo.historyinputmanageroecdata where entityid in (select GUID from eam..tbOECData_loading  where FILE_ID = @FileID )


--ElecAppFile Table

Select Error,IsProcessed,Applicanthicn,ContractId,PlanID,EnrollmentPlanYear,SubmitDate,SubmitTime,SpouseWorkStatus,AccessibilityFormat,EmailOptIn,FileName,*
From EAM..ElecAppFile 
Where FileName = 'OEC_20210005_63650_API_eb48dd9d-1808-42a6-b419-33fcb56fa705.FALLOUT'

Select Applicanthicn,ContractId,PlanID,EnrollmentPlanYear,SubmitDate,SubmitTime,SpouseWorkStatus,AccessibilityFormat,EmailOptIn,*
From EnrollmentInfo
Where 
--ContractId = 'T1234' And
Applicanthicn like '4A77AA0AD%' AND
EnrollmentPlanYear = 2020

Select * from EnrollmentInfo where applicanthicn = '6A77AA0AD01'

--Transaction Level
Select T.HIC,AE.FieldName,OriginalValue,NewValue, TriggerActionType
From [EAMWarehouse].[Audit].[TransactionLevel_Audit] A Inner Join PDMMetadata.dbo.[AuditEntityFields] AE
ON A.FieldId = AE.FieldId Join tbtransactions T
On A.MemcodNum = T.Memcodnum
Where T.HIC = '5A77AA0AD01'
Order By AuditDate Desc

--Member Level
Select T.HIC,AE.FieldName,OriginalValue,NewValue, TriggerActionType,auditdate
From [EAMWarehouse].[Audit].[MemberLevel_Audit] A Inner Join PDMMetadata.dbo.[AuditEntityFields] AE
ON A.FieldId = AE.FieldId Join tbtransactions T
On A.MemcodNum = T.Memcodnum
Where T.HIC = '5A77AA0AD01'
Order By AuditDate Desc