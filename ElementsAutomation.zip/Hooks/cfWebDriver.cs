﻿using System;
using System.Collections.Generic;
using System.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using TechTalk.SpecFlow;
//using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System.IO;
using System.Xml;
//using System.Windows.Forms;
using System.Data.SqlClient;
using Microsoft.Data.SqlClient;
using System.Data;
using OpenQA.Selenium.Support.UI;
using System.Runtime.InteropServices;
using System.Text;
using System.Collections;
using System.Collections.ObjectModel;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using Microsoft.Office.Interop.Excel;
using System.ServiceProcess;
using OpenQA.Selenium.Winium;
using OpenQA.Selenium.Edge;
using TMSoR1.FrameworkCode;
using iTextSharp.text;
using System.Xml.XPath;
using Microsoft.Edge.SeleniumTools;
using Microsoft.VisualStudio.TestTools.UnitTesting;

//[assembly: Parallelize(Workers = 3, Scope = ExecutionScope.ClassLevel)]
namespace TMSoR1
{
    [Binding]
    public class Browser
    {
        private ScenarioContext _scenarioContext;

        public Browser(ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;
        }



        public static IWebDriver Wd;
        public static string WebDriverName;
        public static OpenQA.Selenium.Winium.DesktopOptions options;
        public static WiniumDriver winium;
        public static string serverPath = "Microsoft Web Driver";

        public static Microsoft.Edge.SeleniumTools.EdgeOptions edgeOptions;

        // commenting this as it is creating trouble when we upgraded to selenium version 3.14 

        public static void callWiniumDesktopDriver()
        {
            //options = new OpenQA.Selenium.Winium.DesktopOptions { ApplicationPath = " ", DebugConnectToRunningApp = true };
            //winium = new WiniumDriver("C:\\TMS", options);

            fw.ConsoleReport(" Comment Winium code due to Selenium 3.14 Version upgrade");
        }

        [When(@"Read XML file from specified download folder")]
        public void WhenReadXMLFileFromSpecifiedDownloadFolder()
        {
            string path = @"D:\temp\Test\Edge_4.xml";
            var document = new XmlDocument();
            document.Load(path);
            var nsmgr = new XmlNamespaceManager(document.NameTable);
            nsmgr.AddNamespace("ns1", "http://vo.edge.fm.cms.hhs.gov");

            var nl = document.SelectNodes("//ns1:includedSupplementalDiagnosisDetail", nsmgr);

            //XPathDocument doc = new XPathDocument(path);
            //XPathNavigator nav = doc.CreateNavigator();

            //// Compile a standard XPath expressionbefore
            //XPathExpression expr;
            //expr = nav.Compile("//ns1:includedSupplementalDiagnosisIssuer");
            //XPathNodeIterator iterator = nav.Select(expr);
            //try
            //{
            //    while (iterator.MoveNext())
            //    {

            //    }
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}
        }

        [BeforeScenario]
        public static void BeforeScenario()
        {
            Console.WriteLine("********************** Test Execution Started *************************************************************");
            //Console.WriteLine("\r\n Feature Name : " + FeatureContext.Current.FeatureInfo.Title);
            //Console.WriteLine("Scenario Description : " + FeatureContext.Current.FeatureInfo.Description);
            //Console.WriteLine("Scenario Name : " + ScenarioContext.Current.ScenarioInfo.Title);

            // delete a Specific Folder
            ReUsableFunctions.deleteFilesFromTempFolder();
            // Create a Specific Folder
            string activeRandomDir = @"C:\temp\tmsAlm"+ AngularFunction.getRandomNumber()+"\\";
            GlobalRef.tmsAlmRandomFolder = activeRandomDir;
            if (!Directory.Exists(activeRandomDir))  //  Verify Specific Folder Exists, if No then Create it.
            {
                Directory.CreateDirectory(activeRandomDir);
            }

            // Create a Specific Folder
            string activeDir = @"C:\temp\tmsAlm\";
            GlobalRef.tmsAlmFolder = activeDir;
            if (!Directory.Exists(activeDir))  //  Verify Specific Folder Exists, if No then Create it.
            {
                Directory.CreateDirectory(activeDir);
            }
            // 02/05/2020 Venkatesh  -- Added code to kill firefox, edge browser and driver to kill

            try
            {
                //var chromeDriverProcesses = Process.GetProcesses().
                // Where(pr => (pr.ProcessName.Contains("IEDriverServer")) || (pr.ProcessName.Contains("msedgedriver")) || (pr.ProcessName.Contains("chrome")) || (pr.ProcessName.Contains("firefox")) || (pr.ProcessName.Contains("MicrosoftEdge")) || (pr.ProcessName.Contains("msedge")) || (pr.ProcessName.Contains("chromedriver")) || (pr.ProcessName.Contains("geckodriver")) || (pr.ProcessName.Contains("MicrosoftWebDriver")) || (pr.ProcessName.Contains("IEDriverServer")) || (pr.ProcessName.Contains("Winium.Desktop.Driver")));
                //foreach (var process in chromeDriverProcesses)
                //{
                //    process.Kill();
                //}
            }
            catch
            {
                fw.ConsoleReport(" Not able to Kill Browser Driver Exe");
            }

            if (ConfigFile.BrowserType.Equals("edge") || ConfigFile.BrowserType.Equals("edgelegacy") || ConfigFile.BrowserType.Equals("edgechrome"))
            {
                fw.ConsoleReport(" Winium is not required to launch"); // tested on VM, there is no Authenciation required dialog
            }
            else
            {
                Browser.callWiniumDesktopDriver(); //Need to call only for Report TC's
            }

        }


        [AfterScenario]
        public static void AfterScenario()
        {


            // Comment

            Boolean Success = false;
            string SqlString = "";
        
            if (!Success)
            {
                try
                {
                    string ErrorMessage = "No Error";
                    string testResult = "Passed";
                    if (ScenarioContext.Current.TestError != null)
                    {
                        var error = ScenarioContext.Current.TestError;
                        ErrorMessage = "[" + error.GetType().Name + "] - [" + error.Message + "]";
                        testResult = "Failed";
                    }
                    ErrorMessage = ErrorMessage.Replace("'", "~");
                    string AllTags = "";
                    foreach (string tag in ScenarioContext.Current.ScenarioInfo.Tags)
                    {
                        AllTags += tag + " ";
                    }
                    //As Test run is taking time, timebeing , we comment this code, will be uncomment after sometime.
                    if ((testResult == "Failed") || (testResult == "Passed"))
                    {
                        ReUsableFunctions.takingSnapshots();
                        // Browser.CloseWebDriver();
                    }
                    SqlConnection DBConn = new SqlConnection();
                    //string thisConnectionString = "user id=pdmadmin;" +
                    //           "password=pdmrox;" +
                    //           "Data Source=asp-tms-SQL-118,1433;" +
                    //           "Network Library=DBMSSOCN;" +
                    //           "Initial Catalog=zAutomationFramework; " +
                    //           "connection timeout=30";
                    // Comment below code as 118 SQL server was not there
                    //string thisConnectionString = "server=asp-tms-SQL-118;" + "database=zAutomationFramework;"+ ";" + "user id=" + ConfigFile.DBUser + ";" + "password=" + ConfigFile.DBPassword + ";" + "Max Pool Size=9000;" + "Connection Timeout=150;" + "Min Pool Size=2";

                    //DBConn.ConnectionString = thisConnectionString;
                    //DBConn.Open();
                    //SqlString = "INSERT INTO dbo.TestExeRecords (TestCase,Result,ErrorMessage,MachineName,MachineDomain,MachineUserName,MachineOS,MachineTime,ExeBrowserType,ExeDatabase,ExeDataServer,ExeDBUser,ExeEAMDB,ExeUserId,TestTags,MachineUptime,ExeURL,Framework) VALUES ('" + ScenarioContext.Current.ScenarioInfo.Title + "','" + testResult + "','" + ErrorMessage + "','" + System.Environment.MachineName + "','" + System.Environment.UserDomainName + "','" + System.Environment.UserName + "','" + System.Environment.OSVersion + "','" + DateTime.Now + "','" + ConfigFile.BrowserType + "','" + ConfigFile.Database + "','" + ConfigFile.DataServer + "','" + ConfigFile.UserId + "','" + ConfigFile.EAMdb + "','" + ConfigFile.DBUser + "','" + AllTags + "','" + TimeSpan.FromMilliseconds(System.Environment.TickCount).ToString() + "','" + ConfigFile.URL + "','Gherkin')";
                    //SqlCommand thisCommand = new SqlCommand(SqlString, DBConn);
                    //SqlDataReader newReader = thisCommand.ExecuteReader();
                    Success = true;
                }
                catch (Exception e)
                {
                    //MessageBox.Show("Failed write record: [" + e + "] Query [" + SqlString + "]");
                }
            }


            //  Comment
            if (!Success)
            {
                // MessageBox.Show("Query [" + SqlString + "]");
            }
            // Dont Uncomment the belwo code as it is helpful for Gherkin Runner tool run
            try
            {
                System.IO.DirectoryInfo di = new DirectoryInfo("c:\\Temp\\");

                foreach (FileInfo file in di.GetFiles())
                {
                    file.Delete();
                }
                foreach (DirectoryInfo dir in di.GetDirectories())
                {
                    dir.Delete(true);
                }
            }
            catch
            {

            }

            // Need to close whenever it is called.
            try
            {
                Browser.Wd.Close();
                //Browser.winium.Close();
              //  Browser.winium.Quit();
            }
            catch { }

            Console.WriteLine("\r\n ************************* Execution Completed for this Scenario **********************************************************");
        }


        public static void SetNewUICalendar(IWebElement CalendarObject, string date)
        {

        }

        public static Dictionary<int, string[]> ExecuteSingleQuery(string SqlString, string DB_NAME, int numberOfColumn, int rowstartcnt, string colSkip)
        {
            Dictionary<int, string[]> table = new Dictionary<int, string[]>();
            SqlCommand thisCommand = null;
            List<string> list = new List<string>();
            try
            {

                //string thisConnectionString = "user id=" + ConfigFile.DBUser + "; " +
                //                   "password=" + ConfigFile.DBPassword + ";" +
                //                   "Server=" + ConfigFile.DataServer + ";" +
                //                   "Trusted_Connection=no; " +
                //                   "database=" + DB_NAME + "; " +
                //                   "connection timeout=30";

                string thisConnectionString = "server=" + ConfigFile.DataServer + ";" + "database=" + DB_NAME + ";" + "user id=" + ConfigFile.DBUser + ";" + "password=" + ConfigFile.DBPassword + ";" + "Max Pool Size=9000;" + "Connection Timeout=150;" + "Min Pool Size=2";

                SqlConnection DBConn = new SqlConnection();
                DBConn.ConnectionString = thisConnectionString;
                DBConn.Open();
                thisCommand = new SqlCommand(SqlString, DBConn);
                SqlDataReader reader = thisCommand.ExecuteReader();
                //int numberOfRows = (reader.FieldCount + 1) / numberOfColumn;
                int j = 0;


                if (reader.HasRows)
                {

                    while (reader.Read())
                    {

                        list.Clear();

                        for (int i = 0; i < numberOfColumn; i++)
                        {
                            list.Add(reader.GetValue(i).ToString().TrimEnd());
                        }

                        List<string> copyList = list;

                        table.Add(j, copyList.ToArray());

                        j++;
                    }


                }


            }
            catch (Exception e)
            {
                fw.ConsoleReport("Failed read record: [" + e + "] Query [" + SqlString + "]");
            }

            return table;

        }

        public static string ExecuteSingleQuery(string SqlString, string DB_NAME, int numberOfColumn, int rowstartcnt)
        {
            Dictionary<int, string[]> table = new Dictionary<int, string[]>();
            SqlCommand thisCommand = null;
            string count = null;

            List<string> list = new List<string>();
            try
            {
                SqlConnection DBConn = new SqlConnection();
                //string thisConnectionString = "user id=tmsservice;" +
                //           "password=TriZetto456;" +
                //           "Server=" + ConfigFile.DataServer + ";" +
                //           "Trusted_Connection = yes; " +
                //           "database=" + DB_NAME + "; " +
                //           "connection timeout=30";
                string thisConnectionString = "server=" + ConfigFile.DataServer + ";" + "database=" + DB_NAME + ";" + "user id=" + ConfigFile.DBUser + ";" + "password=" + ConfigFile.DBPassword + ";" + "Max Pool Size=9000;" + "Connection Timeout=150;" + "Min Pool Size=2";

                DBConn.ConnectionString = thisConnectionString;
                DBConn.Open();
                thisCommand = new SqlCommand(SqlString, DBConn);
                SqlDataReader reader = thisCommand.ExecuteReader();

                if (reader.HasRows)
                {
                    tmsWait.Hard(5);
                    while (reader.Read())
                    {
                        for (int i = 0; i < numberOfColumn; i++)
                        {
                            count = reader.GetValue(i).ToString().TrimEnd();
                        }
                      }

                }
                return count;
            }
            catch (Exception e)
            {

                return null;
            }


        }
        public static void SetWebdriverType(string strBrowserType)
        {


            switch (strBrowserType.ToLower())
            {
                case "edge":
                case "edgelegacy":
                    // Venkatesh P - Please do not modify - It wont run on Local VDI but will work on Win 10 Automation VM due to OS compatible
                    Wd = new OpenQA.Selenium.Edge.EdgeDriver();

                    break;

                case "edgechrome":
                    // Venkatesh P - Please do not modify - It will run on Local VDI and run Win 7 and Win 10 VM


                    edgeOptions = new Microsoft.Edge.SeleniumTools.EdgeOptions();
                    edgeOptions.UseChromium = true;
                    Wd = new Microsoft.Edge.SeleniumTools.EdgeDriver(edgeOptions);

                    break;

                case "firefox":
                    {
                        // Venkatesh P - Please do not modify - It will work on Both Local VDI and Automation VM 
                        FirefoxOptions ffprofile = new FirefoxOptions();
                        ffprofile.SetPreference("pdfjs.disabled", true);
                        ffprofile.SetPreference("webdriver_assume_untrusted_issuer", false);
                        ffprofile.SetPreference("browser.popups.showPopupBlocker", false);
                        ffprofile.SetPreference("browser.download.folderList", 1);
                        ffprofile.SetPreference("browser.download.manager.showWhenStarting", false);
                        ffprofile.SetPreference("browser.download.manager.showAlertOnComplete", false);
                        ffprofile.SetPreference("browser.download.manager.showWhenStarting", false);
                        ffprofile.SetPreference("browser.download.useDownloadDir", true);
                        ffprofile.SetPreference("browser.download.manager.focusWhenStarting", false);
                        ffprofile.SetPreference("browser.download.useDownloadDir", true);
                        ffprofile.SetPreference("browser.helperApps.alwaysAsk.force", false);
                        ffprofile.SetPreference("browser.download.manager.alertOnEXEOpen", false);
                        ffprofile.SetPreference("browser.download.manager.closeWhenDone", true);
                        ffprofile.SetPreference("browser.download.manager.showAlertOnComplete", false);
                        ffprofile.SetPreference("browser.download.manager.useWindow", false);
                        ffprofile.SetPreference("browser.helperApps.neverAsk.saveToDisk", "application/pdf,application/EXCEL,application/msword,application/csv,application/x-msexcel,application/excel,application/x-excel,application/vnd.ms-excel,text/csv,text/xls,text/xlsx,image/png ,image/jpeg, application/pdf, text/html,text/plain,application/octet-stream");
                        ffprofile.SetPreference("browser.download.dir", System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads"));
                        Wd = new FirefoxDriver(ffprofile); break;
                    }

                case "chromegrid":
                    {
                        // Venkatesh P - Please do not modify - It will work only on Automation VM using latest chrome


                        ChromeOptions opt = new ChromeOptions();
                        opt.AddUserProfilePreference("download.default_directory", System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads"));
                        opt.AddUserProfilePreference("download.prompt_for_download", false);
                        opt.AddUserProfilePreference("profile.default_content_setting_values.automatic_downloads", 1); // Disable Allow Multiple file download Prompt
                        // opt.AddArguments("start-maximized");
                         opt.AcceptInsecureCertificates=true;
                        opt.AddArguments("test-type");
                        opt.AddArguments("--allow-running-insecure-content");
                        opt.AddArguments("disable-popup-blocking");
                        opt.AddArguments("--no-sandbox");
                        opt.AddArguments("headlesss");
                       
                      
                        Wd = new RemoteWebDriver(new Uri("http://localhost:4444/wd/hub"), opt.ToCapabilities(), TimeSpan.FromMinutes(3));
                        break;
                    }

                case "chrome":
                    {
                        // Venkatesh P - Please do not modify - It will work on Both Local VDI and Automation VM using Browser Version 79
                        ChromeOptions opt = new ChromeOptions();
                        opt.AddUserProfilePreference("download.default_directory", System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads"));
                        opt.AddUserProfilePreference("download.prompt_for_download", false);
                        opt.AddUserProfilePreference("profile.default_content_setting_values.automatic_downloads", 1); // Disable Allow Multiple file download Prompt
                        // opt.AddArguments("start-maximized");
                        opt.AddArguments("test-type");
                        opt.AddArguments("--allow-running-insecure-content");
                        opt.AddArguments("disable-popup-blocking");
                        opt.AddArguments("--no-sandbox");
                        opt.AddArguments("headlesss");
                        opt.AcceptInsecureCertificates = true;
                        //opt.AddArguments("--user-data-dir=C:\\Users\\" + Environment.UserName + "\\AppData\\Local\\Google\\Chrome\\User Data");
                        Wd = new ChromeDriver(opt);

                        break;
                    }
                case "chromep":
                    {
                        // Venkatesh P - This will suport only for Chrome Profile 1.

                        ChromeOptions opt = new ChromeOptions();
                        opt.AddArguments("--user-data-dir=C:\\Users\\" + Environment.UserName + "\\AppData\\Local\\Google\\Chrome\\User Data");
                        opt.AddArgument("--profile-directory=Profile 1");
                        opt.AddArguments("--start-maximized");
                        opt.AddArguments("test-type");
                        opt.AddArguments("--allow-running-insecure-content");
                        opt.AddArguments("disable-popup-blocking");
                        opt.AddArguments("--no-sandbox");
                        opt.AddArguments("headlesss");
                        opt.AcceptInsecureCertificates = true;
                        opt.AddUserProfilePreference("download.default_directory", System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads"));
                        opt.AddUserProfilePreference("download.prompt_for_download", false);
                        opt.AcceptInsecureCertificates = true;
                        opt.AddUserProfilePreference("profile.default_content_setting_values.automatic_downloads", 1); // Disable Allow Multiple file download Prompt
                        Wd = new ChromeDriver(opt);
                        break;
                    }



                case "ie":
                    {
                        // Venkatesh P - Used IEDriverServer_Win32_3.9.0  (TMS) 
                        //  If IE is throwing this error like This is the initial start page for the WebDriver server. then make sure that Protected mode setting has set for all
                        // Please do not modify - It will work on Both Local VDI and Automation VM 

                        var optionsIE = new InternetExplorerOptions();
                        optionsIE.EnableNativeEvents = false;
                        optionsIE.IntroduceInstabilityByIgnoringProtectedModeSettings = true;
                        optionsIE.IgnoreZoomLevel = true;
                        optionsIE.EnsureCleanSession = true;
                        optionsIE.EnablePersistentHover = false;
                        //optionsIE.AcceptInsecureCertificates = true;  //  These 2 lines are commented due to App Certificate issue on Browser
                        //optionsIE.AddAdditionalCapability(CapabilityType.AcceptSslCertificates.ToString(), true);
                        optionsIE.AddAdditionalCapability("browserstack.ie.enablePopups", false);

                        Wd = new InternetExplorerDriver(optionsIE);
                        break;


                    }
            }



            ICapabilities caps = ((RemoteWebDriver)Wd).Capabilities;
            Console.WriteLine("Using Browser [" + caps.GetCapability("browserName") + "] version [" + caps.GetCapability("browserVersion") + "]");
        }

        public static void CloseWebDriver()
        {
            try
            {
                Wd.Close();
                Wd.Quit();
            }
            catch { }
            try
            {
                if (WebDriverName == "") return;

                foreach (Process process in Process.GetProcessesByName(WebDriverName))
                {
                    process.Kill();
                }
            }
            catch { }
        }

        public static void ClosePopUps(bool blnAction)
        {
            while (true)
            {
                try
                {
                    if (blnAction)
                    {
                        //tmsWait.Hard(2);
                        Wd.SwitchTo().Alert().Accept();
                        tmsWait.Hard(1);
                    }
                    else
                    {
                        Wd.SwitchTo().Alert().Dismiss();
                    }
                }

                catch (NoAlertPresentException)
                {
                    fw.ConsoleReport("No alert Present");
                    break;
                }

                catch (Exception)
                {
                    break;
                }
            }
        }

        public static string alertMessage()
        {
            string temp = Wd.SwitchTo().Alert().Text;
            tmsWait.Hard(1);
            Wd.SwitchTo().Alert().Accept();
            return temp;

        }

        public static Boolean SwitchWindow()
        {
            var currentWindow = Wd.CurrentWindowHandle;
            var availableWindows = new List<string>(Wd.WindowHandles);

            foreach (string w in availableWindows)
            {
                if (w != currentWindow)
                {
                    Wd.SwitchTo().Window(w);
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Switches to a window based on its zero based index
        /// </summary>
        /// <param name="index">0 is the parent window and 1 is the first child</param>
        public static IWebDriver SwitchToWindow(int index)
        {
            var wait = new WebDriverWait(Wd, TimeSpan.FromSeconds(60));
            wait.Until(d => d.WindowHandles.Count > index);
            return Wd.SwitchTo().Window(Wd.WindowHandles[index]);
        }

        /// <summary>
        /// Switches to the parent window
        /// </summary>
        public static IWebDriver SwitchToParentWindow()
        {
            return SwitchToWindow(0);
        }

        /// <summary>
        /// Switches to the frist child window. Use SwitchToWindow if you would like to switch to another child window other than the first.
        /// </summary>
        public static IWebDriver SwitchToChildWindow()
        {

            return SwitchToWindow(1);

        }

        public static Boolean SwitchWindow(string strTitle)
        {
            var currentWindow = Wd.CurrentWindowHandle;
            var availableWindows = new List<string>(Wd.WindowHandles);

            foreach (string w in availableWindows)
            {
                if (w != currentWindow)
                {
                    Wd.SwitchTo().Window(w);
                    if (Wd.Title.Contains(strTitle)) return true;
                }
            }
            Wd.SwitchTo().Window(currentWindow);
            return false;
        }


        /// <summary>
        /// Switch Window using Title
        /// </summary>
        /// <param name="title">Title</param>
        /// <returns>True value once switched success</returns>
        public static bool SwitchToWindowUsingTitle(string title)
        {
            var currentWindow = Wd.CurrentWindowHandle;
            ReadOnlyCollection<string> availableWindows = Wd.WindowHandles;
            if (availableWindows.Count != 0)
            {
                foreach (string windowId in availableWindows)
                {
                    if (Wd.SwitchTo().Window(windowId).Title.Equals(title))
                    {
                        return true;
                    }
                    else
                    {
                        Wd.SwitchTo().Window(currentWindow);
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// Switches focus to the displayed IFrame in the QFramework
        /// </summary>
        public static void SwitchToIFrame()
        {
            var wait = new WebDriverWait(Wd, TimeSpan.FromSeconds(30));
            IWebElement frame = wait.Until(d => d.FindElement(By.TagName("iframe")));
            Wd.SwitchTo().Frame(frame);
        }

        /// <summary>
        /// Get opened window count
        /// </summary>
        /// <returns>Count</returns>
        public static int GetWindowCount()
        {
            var wait = new WebDriverWait(Wd, TimeSpan.FromSeconds(30));
            wait.Until(d => d.WindowHandles.Count > 0);
            return Wd.WindowHandles.Count;
        }

        ///// <summary>
        ///// Restart service from Remote Machine
        ///// </summary>
        ///// <param name="serviceName">Name of Service to be restarted</param>
        ///// <param name="ipOfRemoteMachine">IP of Remote Machine</param>
        //public static void RestartServiceOnRemote(string serviceName, string ipOfRemoteMachine)
        //{
        //    ServiceController sc = new ServiceController(serviceName, ipOfRemoteMachine);
        //    sc.Stop();
        //    sc.WaitForStatus(ServiceControllerStatus.Stopped);
        //    sc.Start();
        //    sc.WaitForStatus(ServiceControllerStatus.Running);
        //    sc.Refresh();
        //}

    }
    [Binding]
    public class db
    {
        public static Dictionary<string, SqlConnection> DBConns = new Dictionary<string, SqlConnection>();
        public static Dictionary<string, SqlCommand> DBCommands = new Dictionary<string, SqlCommand>();

        public static void CreateConn(string DBName)
        {
            if (!DBConns.ContainsKey(DBName))
            {
                DBConns.Add(DBName, new SqlConnection());
            }
            else
            {
                DBConns[DBName].Close();
            }
            //       DBConns.Add(DBName, new SqlConnection());

            if (ConfigFile.URL == "")
            {
                ConfigFile.ReadFromConfigFile();
            }
            

            string thisConnectionString = "server=" + ConfigFile.DataServer + ";" + "database=" + ConfigFile.EAMdb + ";" + "user id=" + ConfigFile.DBUser + ";" + "password=" + ConfigFile.DBPassword + ";" + "Max Pool Size=9000;" + "Connection Timeout=150;" + "Min Pool Size=2";
            Console.WriteLine("Creating DB Connection [" + DBName + "] with Connection String [" + thisConnectionString + "]");
            DBConns[DBName].ConnectionString = thisConnectionString;
            DBConns[DBName].Open();
        }




        public static void CreatePDMMetaDataConn(string DBName)
        {
            if (!DBConns.ContainsKey(DBName))
            {
                DBConns.Add(DBName, new SqlConnection());
            }
            else
            {
                DBConns[DBName].Close();
            }
            //       DBConns.Add(DBName, new SqlConnection());

            if (ConfigFile.URL == "")
            {
                ConfigFile.ReadFromConfigFile();
            }
            //string thisConnectionString = "user id=" + ConfigFile.DBUser + ";" +
            //                       "password=" + ConfigFile.DBPassword + ";server=" + ConfigFile.DataServer + ";" +
            //                       "Trusted_Connection=yes;" +
            //                       "database=" + ConfigFile.Database + "; " +
            //                       "connection timeout=30";

            //string thisConnectionString = "user id=" + ConfigFile.DBUser + ";" +
            //                       "password=" + ConfigFile.DBPassword + ";" +
            //                       "Data Source=" + ConfigFile.DataServer + "," + ConfigFile.Port + ";" +
            //                       "Network Library=DBMSSOCN;" +
            //                       "Initial Catalog=" + ConfigFile.PDMMetaDatadb + "; " +
            //                       // "Initial Catalog=TMSFRM; " +
            //                       "connection timeout=30";
            //Console.WriteLine("Creating DB Connection [" + DBName + "] with Connection String [" + thisConnectionString + "]");
            //DBConns[DBName].ConnectionString = thisConnectionString;
            //DBConns[DBName].Open();


            string thisConnectionString = "server=" + ConfigFile.DataServer + ";" + "database=" + ConfigFile.PDMMetaDatadb + ";" + "user id=" + ConfigFile.DBUser + ";" + "password=" + ConfigFile.DBPassword + ";" + "Max Pool Size=9000;" + "Connection Timeout=150;" + "Min Pool Size=2";
            Console.WriteLine("Creating DB Connection [" + DBName + "] with Connection String [" + thisConnectionString + "]");
            DBConns[DBName].ConnectionString = thisConnectionString;
            DBConns[DBName].Open();

        }

        public static void CreateWarehouseConn(string DBName)
        {
            if (!DBConns.ContainsKey(DBName))
            {
                DBConns.Add(DBName, new SqlConnection());
            }
            else
            {
                DBConns[DBName].Close();
            }
            //       DBConns.Add(DBName, new SqlConnection());

            if (ConfigFile.URL == "")
            {
                ConfigFile.ReadFromConfigFile();
            }
            //string thisConnectionString = "user id=" + ConfigFile.DBUser + ";" +
            //                       "password=" + ConfigFile.DBPassword + ";server=" + ConfigFile.DataServer + ";" +
            //                       "Trusted_Connection=yes;" +
            //                       "database=" + ConfigFile.Database + "; " +
            //                       "connection timeout=30";
            //string thisConnectionString = "user id=" + ConfigFile.DBUser + ";" +
            //                       "password=" + ConfigFile.DBPassword + ";" +
            //                       "Data Source=" + ConfigFile.DataServer + "," + ConfigFile.Port + ";" +
            //                       "Network Library=DBMSSOCN;" +
            //                       "Initial Catalog=" + ConfigFile.Warehousedb + "; " +
            //                       // "Initial Catalog=TMSFRM; " +
            //                       "connection timeout=30";

            string thisConnectionString = "server=" + ConfigFile.DataServer + ";" + "database=" + ConfigFile.Warehousedb + ";" + "user id=" + ConfigFile.DBUser + ";" + "password=" + ConfigFile.DBPassword + ";" + "Max Pool Size=9000;" + "Connection Timeout=150;" + "Min Pool Size=2";
            Console.WriteLine("Creating DB Connection [" + DBName + "] with Connection String [" + thisConnectionString + "]");
            DBConns[DBName].ConnectionString = thisConnectionString;
            DBConns[DBName].Open();
        }
        public static void CreateESIFRMConn(string DBName)
        {
            if (!DBConns.ContainsKey(DBName))
            {
                DBConns.Add(DBName, new SqlConnection());
            }
            else
            {
                DBConns[DBName].Close();
            }
            //       DBConns.Add(DBName, new SqlConnection());

            if (ConfigFile.URL == "")
            {
                ConfigFile.ReadFromConfigFile();
            }
            //string thisConnectionString = "user id=" + ConfigFile.DBUser + ";" +
            //                       "password=" + ConfigFile.DBPassword + ";server=" + ConfigFile.DataServer + ";" +
            //                       "Trusted_Connection=yes;" +
            //                       "database=" + ConfigFile.Database + "; " +
            //                       "connection timeout=30";
            string thisConnectionString = "user id=" + ConfigFile.DBUser + ";" +
                                   "password=" + ConfigFile.DBPassword + ";" +
                                   "Data Source=" + ConfigFile.DataServer + "," + ConfigFile.Port + ";" +
                                   "Network Library=DBMSSOCN;" +
                                   "Initial Catalog=" + ConfigFile.FRMedb + "; " +
                                   // "Initial Catalog=TMSFRM; " +
                                   "connection timeout=30";
            Console.WriteLine("Creating DB Connection [" + DBName + "] with Connection String [" + thisConnectionString + "]");
            DBConns[DBName].ConnectionString = thisConnectionString;
            DBConns[DBName].Open();
        }

        public static void CreateFRMConn(string DBName)
        {
            if (!DBConns.ContainsKey(DBName))
            {
                DBConns.Add(DBName, new SqlConnection());
            }
            else
            {
                DBConns[DBName].Close();
            }
            //       DBConns.Add(DBName, new SqlConnection());

            if (ConfigFile.URL == "")
            {
                ConfigFile.ReadFromConfigFile();
            }
            //string thisConnectionString = "user id=" + ConfigFile.DBUser + ";" +
            //                       "password=" + ConfigFile.DBPassword + ";server=" + ConfigFile.DataServer + ";" +
            //                       "Trusted_Connection=yes;" +
            //                       "database=" + ConfigFile.Database + "; " +
            //                       "connection timeout=30";
            //string thisConnectionString = "user id=" + ConfigFile.DBUser + ";" +
            //                       "password=" + ConfigFile.DBPassword + ";" +
            //                       "Data Source=" + ConfigFile.DataServer + "," + ConfigFile.Port + ";" +
            //                       "Network Library=DBMSSOCN;" +
            //                       "Initial Catalog=" + ConfigFile.FRMdb + "; " +
            //                       // "Initial Catalog=TMSFRM; " +
            //                       "connection timeout=30";

            string thisConnectionString = "server=" + ConfigFile.DataServer + ";" + "database=" + ConfigFile.FRMdb + ";" + "user id=" + ConfigFile.DBUser + ";" + "password=" + ConfigFile.DBPassword + ";" + "Max Pool Size=9000;" + "Connection Timeout=150;" + "Min Pool Size=2";
            Console.WriteLine("Creating DB Connection [" + DBName + "] with Connection String [" + thisConnectionString + "]");
            DBConns[DBName].ConnectionString = thisConnectionString;
            DBConns[DBName].Open();
        }


        // This will connect ERF Database
        public static void CreateERFConn(string DBName)
        {
            if (!DBConns.ContainsKey(DBName))
            {
                DBConns.Add(DBName, new SqlConnection());
            }
            else
            {
                DBConns[DBName].Close();
            }
            //       DBConns.Add(DBName, new SqlConnection());

            if (ConfigFile.URL == "")
            {
                ConfigFile.ReadFromConfigFile();
            }
            //string thisConnectionString = "user id=" + ConfigFile.DBUser + ";" +
            //                       "password=" + ConfigFile.DBPassword + ";server=" + ConfigFile.DataServer + ";" +
            //                       "Trusted_Connection=yes;" +
            //                       "database=" + ConfigFile.Database + "; " +
            //                       "connection timeout=30";
            //string thisConnectionString = "user id=" + ConfigFile.DBUser + ";" +
            //                       "password=" + ConfigFile.DBPassword + ";" +
            //                       "Data Source=" + ConfigFile.DataServer + "," + ConfigFile.Port + ";" +
            //                       "Network Library=DBMSSOCN;" +
            //                       "Initial Catalog=" + ConfigFile.ERFdb + "; " +
            //                       "connection timeout=30";

            string thisConnectionString = "server=" + ConfigFile.DataServer + ";" + "database=" + ConfigFile.ERFdb + ";" + "user id=" + ConfigFile.DBUser + ";" + "password=" + ConfigFile.DBPassword + ";" + "Max Pool Size=9000;" + "Connection Timeout=150;" + "Min Pool Size=2";
            Console.WriteLine("Creating DB Connection [" + DBName + "] with Connection String [" + thisConnectionString + "]");
            DBConns[DBName].ConnectionString = thisConnectionString;
            DBConns[DBName].Open();
        }
        public static void CreateConnRAM(string DBName)
        {
            if (!DBConns.ContainsKey(DBName))
            {
                DBConns.Add(DBName, new SqlConnection());
            }
            else
            {
                DBConns[DBName].Close();
            }
            //       DBConns.Add(DBName, new SqlConnection());

            if (ConfigFile.URL == "")
            {
                ConfigFile.ReadFromConfigFile();
            }
            //string thisConnectionString = "user id=" + ConfigFile.DBUser + ";" +
            //                       "password=" + ConfigFile.DBPassword + ";server=" + ConfigFile.DataServer + ";" +
            //                       "Trusted_Connection=yes;" +
            //                       "database=" + ConfigFile.Database + "; " +
            //                       "connection timeout=30";
            //string thisConnectionString = "user id=" + ConfigFile.DBUser + ";" +
            //                       "password=" + ConfigFile.DBPassword + ";" +
            //                       "Data Source=" + ConfigFile.DataServer + "," + ConfigFile.Port + ";" +
            //                       "Network Library=DBMSSOCN;" +
            //                       "Initial Catalog=" + ConfigFile.RAMdb + "; " +
            //                       "connection timeout=30";

            string thisConnectionString = "server=" + ConfigFile.DataServer + ";" + "database=" + ConfigFile.RAMdb + ";" + "user id=" + ConfigFile.DBUser + ";" + "password=" + ConfigFile.DBPassword + ";" + "Max Pool Size=9000;" + "Connection Timeout=300;" + "Min Pool Size=2";
            Console.WriteLine("Creating DB Connection [" + DBName + "] with Connection String [" + thisConnectionString + "]");
            DBConns[DBName].ConnectionString = thisConnectionString;
            DBConns[DBName].Open();
        }

        public static void CreateConnCDM(string DBName)
        {
            Console.Write("Connecting to CDM DB... ");
            if (!DBConns.ContainsKey(DBName))
            {
                DBConns.Add(DBName, new SqlConnection());
            }
            else
            {
                DBConns[DBName].Close();
            }
            //       DBConns.Add(DBName, new SqlConnection());

            if (ConfigFile.URL == "")
            {
                ConfigFile.ReadFromConfigFile();
            }
            //string thisConnectionString = "user id=" + ConfigFile.DBUser + ";" +
            //                       "password=" + ConfigFile.DBPassword + ";server=" + ConfigFile.DataServer + ";" +
            //                       "Trusted_Connection=yes;" +
            //                       "database=" + ConfigFile.Database + "; " +
            //                       "connection timeout=30";
            //string thisConnectionString = "user id=" + ConfigFile.DBUser + ";" +
            //                       "password=" + ConfigFile.DBPassword + ";" +
            //                       "Data Source=" + ConfigFile.DataServer + "," + ConfigFile.Port + ";" +
            //                       "Network Library=DBMSSOCN;" +
            //                       "Initial Catalog=" + ConfigFile.CDMdb + "; " +
            //                       "connection timeout=30";

            string thisConnectionString = "server=" + ConfigFile.DataServer + ";" + "database=" + ConfigFile.CDMdb + ";" + "user id=" + ConfigFile.DBUser + ";" + "password=" + ConfigFile.DBPassword + ";" + "Max Pool Size=9000;" + "Connection Timeout=500;" + "Min Pool Size=2";
            Console.WriteLine("Creating DB Connection [" + DBName + "] with Connection String [" + thisConnectionString + "]");
            DBConns[DBName].ConnectionString = thisConnectionString;
            DBConns[DBName].Open();
        }
        public static void CreateConnPDEM(string DBName)
        {
            Console.Write("Connecting to PDEM DB... ");
            if (!DBConns.ContainsKey(DBName))
            {
                DBConns.Add(DBName, new SqlConnection());
            }
            else
            {
                DBConns[DBName].Close();
            }


            if (ConfigFile.URL == "")
            {
                ConfigFile.ReadFromConfigFile();
            }
            string thisConnectionString = "server=" + ConfigFile.DataServer + ";" + "database=" + ConfigFile.PDEMdb + ";" + "user id=" + ConfigFile.DBUser + ";" + "password=" + ConfigFile.DBPassword + ";" + "Max Pool Size=9000;" + "Connection Timeout=300;" + "Min Pool Size=2";
            Console.WriteLine("Creating DB Connection [" + DBName + "] with Connection String [" + thisConnectionString + "]");
            DBConns[DBName].ConnectionString = thisConnectionString;
            DBConns[DBName].Open();
        }

        public static void CreateConnRAMX(string DBName)
        {
            Console.Write("Connecting to RAMX DB... ");
            if (!DBConns.ContainsKey(DBName))
            {
                DBConns.Add(DBName, new SqlConnection());
            }
            else
            {
                DBConns[DBName].Close();
            }
            //       DBConns.Add(DBName, new SqlConnection());

            if (ConfigFile.URL == "")
            {
                ConfigFile.ReadFromConfigFile();
            }
            //string thisConnectionString = "user id=" + ConfigFile.DBUser + ";" +
            //                       "password=" + ConfigFile.DBPassword + ";server=" + ConfigFile.DataServer + ";" +
            //                       "Trusted_Connection=yes;" +
            //                       "database=" + ConfigFile.Database + "; " +
            //                       "connection timeout=30";
            //string thisConnectionString = "user id=" + ConfigFile.DBUser + ";" +
            //                       "password=" + ConfigFile.DBPassword + ";" +
            //                       "Data Source=" + ConfigFile.DataServer + "," + ConfigFile.Port + ";" +
            //                       "Network Library=DBMSSOCN;" +
            //                       "Initial Catalog=" + ConfigFile.RAMXdb + "; " +
            //                       "connection timeout=30";

            string thisConnectionString = "server=" + ConfigFile.DataServer + ";" + "database=" + ConfigFile.RAMXdb + ";" + "user id=" + ConfigFile.DBUser + ";" + "password=" + ConfigFile.DBPassword + ";" + "Max Pool Size=9000;" + "Connection Timeout=150;" + "Min Pool Size=2";
            Console.WriteLine("Creating DB Connection [" + DBName + "] with Connection String [" + thisConnectionString + "]");
            DBConns[DBName].ConnectionString = thisConnectionString;
            DBConns[DBName].Open();
        }


        public static void CreateIdentityServerConn(string DBName)
        {
            if (!DBConns.ContainsKey(DBName))
            {
                DBConns.Add(DBName, new SqlConnection());
            }
            else
            {
                DBConns[DBName].Close();
            }
            //       DBConns.Add(DBName, new SqlConnection());

            if (ConfigFile.URL == "")
            {
                ConfigFile.ReadFromConfigFile();
            }
            //string thisConnectionString = "user id=" + ConfigFile.DBUser + ";" +
            //                       "password=" + ConfigFile.DBPassword + ";server=" + ConfigFile.DataServer + ";" +
            //                       "Trusted_Connection=yes;" +
            //                       "database=" + ConfigFile.Database + "; " +
            //                       "connection timeout=30";
            //string thisConnectionString = "user id=" + ConfigFile.DBUser + ";" +
            //                       "password=" + ConfigFile.DBPassword + ";" +
            //                       "Data Source=" + ConfigFile.DataServer + "," + ConfigFile.Port + ";" +
            //                       "Network Library=DBMSSOCN;" +
            //                      "Initial Catalog=" + ConfigFile.IdentitySdb + ";" +
            //                       // "Initial Catalog=TMSFRM; " +
            //                       "connection timeout=30";

            string thisConnectionString = "server=" + ConfigFile.DataServer + ";" + "database=" + ConfigFile.IdentitySdb + ";" + "user id=" + ConfigFile.DBUser + ";" + "password=" + ConfigFile.DBPassword + ";" + "Max Pool Size=9000;" + "Connection Timeout=150;" + "Min Pool Size=2";
            Console.WriteLine("Creating DB Connection [" + DBName + "] with Connection String [" + thisConnectionString + "]");
            DBConns[DBName].ConnectionString = thisConnectionString;
            DBConns[DBName].Open();
        }


        public static void CreateConnForPDM(string DBName)
        {

            DBConns.Add(DBName, new SqlConnection());


            if (ConfigFile.URL == "")
            {
                ConfigFile.ReadFromConfigFile();
            }
            //string thisConnectionString = "user id=" + ConfigFile.PDMDB + ";" +
            //                       "password=" + ConfigFile.PDMDBPassword + ";server=" + ConfigFile.DataServer + ";" +
            //                       "Trusted_Connection=yes;" +
            //                       "database=" + DBName + "; " +
            //                       "connection timeout=30";

            string thisConnectionString = "server=" + ConfigFile.DataServer + ";" + "database=" + ConfigFile.PDMDB + ";" + "user id=" + ConfigFile.DBUser + ";" + "password=" + ConfigFile.DBPassword + ";" + "Max Pool Size=9000;" + "Connection Timeout=150;" + "Min Pool Size=2";
            Console.WriteLine("Creating DB Connection [" + DBName + "] with Connection String [" + thisConnectionString + "]");
            DBConns[DBName].ConnectionString = thisConnectionString;
            DBConns[DBName].Open();
        }

        public static void AddDBQuery(string DBName, string DBQuery)
        {
            if (!DBCommands.ContainsKey(DBName))
            {
                DBCommands.Add(DBName, new SqlCommand(DBQuery, DBConns[DBName]));

            }
            else
            {
                DBCommands.Remove(DBName);
                DBCommands.Add(DBName, new SqlCommand(DBQuery, DBConns[DBName]));

            }

            //          DBCommands.Add(DBName, new SqlCommand(DBQuery, DBConns[DBName]));            
        }

        public static void ExecuteUpdateQuery(string DBName)
        {

            SqlDataReader newReader = DBCommands[DBName].ExecuteReader();

        }

        public static void ExecuteDeleteQuery(string DBName)
        {

            SqlDataReader newReader = DBCommands[DBName].ExecuteReader();

        }

        public static void SetValues(string dbName, string plan, string PBP)
        {
            SqlDataReader newReader = DBCommands[dbName].ExecuteReader();
            int Columns = newReader.FieldCount;
            string strOutString = "";
            string[] values = new string[2];

            while (newReader.Read())
            {
                System.Threading.Thread.Sleep(550);

                for (int i = 0; i < Columns; i++)
                {
                    strOutString += newReader[i];
                    values[i] = newReader[i].ToString();
                    if (i != Columns - 1)
                    {
                        strOutString += "|";
                    }
                }
                Console.WriteLine(strOutString);
            }
            newReader.Close();

            fw.setVariable(plan, values[0]);
            fw.setVariable(PBP, values[1]);

        }

        public static void SetMemberGroupData(string dbName, string group, string subGroup, string classname)
        {
            SqlDataReader newReader = DBCommands[dbName].ExecuteReader();
            int Columns = newReader.FieldCount;
            string strOutString = "";
            string[] values = new string[3];

            while (newReader.Read())
            {
                System.Threading.Thread.Sleep(550);

                for (int i = 0; i < Columns; i++)
                {
                    strOutString += newReader[i];
                    values[i] = newReader[i].ToString();
                    if (i != Columns - 1)
                    {
                        strOutString += "|";
                    }
                }
                Console.WriteLine(strOutString);
            }
            newReader.Close();

            fw.setVariable(group, values[0]);
            fw.setVariable(subGroup, values[1]);
            fw.setVariable(classname, values[2]);

        }

        public static List<string> OutputDBResultsToList(string DBName)
        {
            List<string> list = new List<string>();
            SqlDataReader newReader = DBCommands[DBName].ExecuteReader();
            int Columns = newReader.FieldCount;
            Boolean Rows = newReader.HasRows;
            System.Data.DataTable ST = newReader.GetSchemaTable();
            string thisName = newReader.GetName(0);
            //    DataTable ColumnHeaders = newReader.GetName
            string columnsString = "";

            foreach (DataRow row in ST.Rows)
            {
                foreach (DataColumn column in ST.Columns)
                {
                    if (column.ColumnName == "ColumnName")
                    {
                        columnsString += row[column] + "|";
                    }
                }
            }

            Console.WriteLine(columnsString.Substring(0, columnsString.Length - 1));

            //  newReader.
            while (newReader.Read())
            {
                System.Threading.Thread.Sleep(550);
                string strOutString = "";
                for (int i = 0; i < Columns; i++)
                {
                    strOutString += newReader[i];
                    if (i != Columns - 1)
                    {
                        strOutString += "|";
                    }
                }
                Console.WriteLine(strOutString);

                list.Add(strOutString);
                //  list.Insert(strOutString, i);


            }
            newReader.Close();

            return list;
        }

        public static Dictionary<string, string> OutputDBResultsToDic(string DBName)
        {
            Dictionary<string, string> FalloutData = new Dictionary<string, string>();
            FalloutData.Clear();

            //List<string> list = new List<string>();
            SqlDataReader newReader = DBCommands[DBName].ExecuteReader();
            int Columns = newReader.FieldCount;
            //Boolean Rows = newReader.HasRows;
            System.Data.DataTable ST = newReader.GetSchemaTable();
            string thisName = newReader.GetName(0);
            while (newReader.Read())
            {
                for (int r = 0; r < Columns; r++)
                {
                    //Console.WriteLine(newReader.GetName(r) + "-" + newReader[newReader.GetName(r)].ToString());
                    FalloutData.Add(newReader.GetName(r), newReader[newReader.GetName(r)].ToString());
                    //string thisValue = newReader.GetValue(0).ToString();                    
                }
                break;
            }

            newReader.Close();
            return FalloutData;

        }
        public static void OutputDBResults(string DBName)
        {

            SqlDataReader newReader = DBCommands[DBName].ExecuteReader();
            int Columns = newReader.FieldCount;
            Boolean Rows = newReader.HasRows;
            System.Data.DataTable ST = newReader.GetSchemaTable();
            string thisName = newReader.GetName(0);
            //    DataTable ColumnHeaders = newReader.GetName
            string columnsString = "";

            foreach (DataRow row in ST.Rows)
            {
                foreach (DataColumn column in ST.Columns)
                {
                    if (column.ColumnName == "ColumnName")
                    {
                        columnsString += row[column] + "|";
                    }
                }
            }

            Console.WriteLine(columnsString.Substring(0, columnsString.Length - 1));

            //  newReader.
            while (newReader.Read())
            {
                System.Threading.Thread.Sleep(550);
                string strOutString = "";
                for (int i = 0; i < Columns; i++)
                {
                    strOutString += newReader[i];
                    if (i != Columns - 1)
                    {
                        strOutString += "|";
                    }
                }
                Console.WriteLine(strOutString);
                GlobalRef.ClientId = strOutString;

            }
            newReader.Close();
        }
        /// <summary>
        /// Return Column value based on SpecFied Column index
        /// </summary>
        /// <param name="DBName"></param>
        /// <param name="index"></param>
        /// <returns></returns>

        static int index;
        public static string[] returnSQLQueryresultsWithArrayFormat(string DBName)
        {

            var newReader = DBCommands[DBName].ExecuteReader();

            int Columns = newReader.FieldCount;
            string[] strOutputString = new string[Columns];
            Boolean Rows = newReader.HasRows;
            System.Data.DataTable ST = newReader.GetSchemaTable();

            index = 0;
            int i = 0;
            while (newReader.Read())
            {
                System.Threading.Thread.Sleep(550);

                while (i < Columns)
                {
                    strOutputString[i] = newReader.GetValue(i).ToString();
                    i++;
                }


                index++;

            }
            newReader.Close();
            return strOutputString;
        }

        public static List<string> returnSQLQueryresultsWithCompleteRowsInArrayFormat(string DBName)
        {
            List<string> dbrows = new List<string>();
            var newReader = DBCommands[DBName].ExecuteReader(); //  ExecuteDeleteQuery Query


            Boolean Rows = newReader.HasRows; // check do we have Rows

            while (newReader.Read()) // check we have next row
            {
                System.Threading.Thread.Sleep(550);

                dbrows.Add(newReader.GetString(0)); // get First column value ( GetString(0))                 

            }
            newReader.Close();
            return dbrows;
        }


        public static List<DateTime> returnSQLQueryresultsWithCompleteDateRowsInArrayFormat(string DBName)
        {
            List<DateTime> dbrows = new List<DateTime>();
            var newReader = DBCommands[DBName].ExecuteReader(); //  ExecuteDeleteQuery Query


            Boolean Rows = newReader.HasRows; // check do we have Rows

            while (newReader.Read()) // check we have next row
            {
                System.Threading.Thread.Sleep(550);

                dbrows.Add(newReader.GetDateTime(0)); // get First column value ( GetDateTime(0))                 

            }
            newReader.Close();
            return dbrows;
        }

        public static int returnSQLQueryresultsWithBlankValues(string DBName)
        {
            List<int> dbrows = new List<int>();
            var newReader = DBCommands[DBName].ExecuteReader(); //  ExecuteDeleteQuery Query


            Boolean Rows = newReader.HasRows; // check do we have Rows

            while (newReader.Read()) // check we have next row
            {
                System.Threading.Thread.Sleep(550);

                dbrows.Add(newReader.GetInt32(0)); // get First column value ( GetString(0))                 

            }
            newReader.Close();
            return dbrows.Count;
        }

        public static List<int> returnSQLQueryresultsWithCompleteIntegerRowsInArrayFormat(string DBName)
        {
            List<int> dbrows = new List<int>();
            var newReader = DBCommands[DBName].ExecuteReader(); //  ExecuteDeleteQuery Query


            Boolean Rows = newReader.HasRows; // check do we have Rows

            while (newReader.Read()) // check we have next row
            {
                System.Threading.Thread.Sleep(550);

                dbrows.Add(newReader.GetInt32(0)); // get First column value ( GetString(0))                 

            }
            newReader.Close();
            return dbrows;
        }


        public static string[,] returnSQLQueryresultsWithCompleteIntegerRowsInArrayFormatnew(string DBName)
        { //int n = 14;


            var newReader = DBCommands[DBName].ExecuteReader(); //  ExecuteDeleteQuery Query
            int n = 0;

            while (newReader.Read()) // check we have next row
            {
                n = n + 1;
            }

            newReader.Close();
            var newReader1 = DBCommands[DBName].ExecuteReader();
            Boolean Rows = newReader1.HasRows; // check do we have Rows


            System.Data.DataTable ST = newReader1.GetSchemaTable();
            // int n = ST.Rows.Count;



            newReader1.Read();
            string[,] array2Db = new string[n, 3];

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < 3; j++)
                {


                    array2Db[i, j] = newReader1.GetString(j); // get First column value ( GetString(0))                 

                }

                newReader1.Read();
            }
            newReader1.Close();


            return array2Db;
        }


        public static List<int> returnSQLQueryresultsWithCompleteIntegerRowsInArrayFormat16(string DBName)
        {
            List<int> dbrows = new List<int>();
            var newReader = DBCommands[DBName].ExecuteReader(); //  ExecuteDeleteQuery Query


            Boolean Rows = newReader.HasRows; // check do we have Rows

            while (newReader.Read()) // check we have next row
            {
                System.Threading.Thread.Sleep(550);

                dbrows.Add(newReader.GetInt16(0)); // get First column value ( GetString(0))                 

            }
            newReader.Close();
            return dbrows;
        }
        public static string returnSQLQueryresultsBasedOnIndex(string DBName, int index)
        {
            string strOutString = "";
            var newReader = DBCommands[DBName].ExecuteReader();

            int Columns = newReader.FieldCount;
            Boolean Rows = newReader.HasRows;
            System.Data.DataTable ST = newReader.GetSchemaTable();

            int i = 1;
            while (newReader.Read())
            {
                System.Threading.Thread.Sleep(550);

                if (i == index)
                {
                    strOutString = newReader.GetValue(0).ToString();
                    break;
                }
                i++;

            }
            newReader.Close();
            return strOutString;
        }

        static System.Data.DataTable resDataTable = new System.Data.DataTable();
        public static System.Data.DataTable executeQueryStoreIntoDatatable(string DBName)
        {

            // create data adapter
            SqlDataAdapter da = new SqlDataAdapter(DBCommands[DBName]);
            // this will query your database and return the result to your datatable
            da.Fill(resDataTable);

            foreach (DataRow dataRow in resDataTable.Rows)
            {
                foreach (var item in dataRow.ItemArray)
                {
                    Console.WriteLine(item);
                }
            }

            da.Dispose();

            return resDataTable;
        }
        public static string StoreDBResultsInString(string DBName)
        {
            string strOutString = "";
            SqlDataReader newReader = DBCommands[DBName].ExecuteReader();
            int Columns = newReader.FieldCount;
            Boolean Rows = newReader.HasRows;
            System.Data.DataTable ST = newReader.GetSchemaTable();
            string thisName = newReader.GetName(0);
            //    DataTable ColumnHeaders = newReader.GetName
            string columnsString = "";

            foreach (DataRow row in ST.Rows)
            {
                foreach (DataColumn column in ST.Columns)
                {
                    if (column.ColumnName == "ColumnName")
                    {
                        columnsString += row[column] + "|";
                    }
                }
            }

            Console.WriteLine(columnsString.Substring(0, columnsString.Length - 1));

            //  newReader.
            while (newReader.Read())
            {
                System.Threading.Thread.Sleep(550);

                for (int i = 0; i < Columns; i++)
                {
                    strOutString += newReader[i];
                    if (i != Columns - 1)
                    {
                        strOutString += "|";
                    }
                }
                Console.WriteLine(strOutString);

            }
            newReader.Close();
            return strOutString;

        }

        public static string StoreDBResults(string DBName)
        {
            string strOutString = "";
            SqlDataReader newReader = DBCommands[DBName].ExecuteReader();
            int Columns = newReader.FieldCount;
            Boolean Rows = newReader.HasRows;
            System.Data.DataTable ST = newReader.GetSchemaTable();
            string thisName = newReader.GetName(0);
            //    DataTable ColumnHeaders = newReader.GetName
            string columnsString = "";

            foreach (DataRow row in ST.Rows)
            {
                foreach (DataColumn column in ST.Columns)
                {
                    if (column.ColumnName == "ColumnName")
                    {
                        columnsString += row[column] + "|";
                    }
                }
            }

            //  newReader.
            while (newReader.Read())
            {
                System.Threading.Thread.Sleep(550);

                for (int i = 0; i < Columns; i++)
                {
                    strOutString += newReader[i];
                    if (i != Columns - 1)
                    {
                        strOutString += "|";
                    }
                }

            }
            newReader.Close();
            return strOutString;

        }




        public static void StoreDBResults(string DBName, List<string> list)
        {

            SqlDataReader newReader = DBCommands[DBName].ExecuteReader();
            int Columns = newReader.FieldCount;
            Boolean Rows = newReader.HasRows;
            System.Data.DataTable ST = newReader.GetSchemaTable();
            //string thisName = newReader.GetName(0);
            //    DataTable ColumnHeaders = newReader.GetName
            string columnsString = "";

            // Reading column header
            foreach (DataRow row in ST.Rows)
            {
                foreach (DataColumn column in ST.Columns)
                {
                    if (column.ColumnName == "ColumnName")
                    {
                        columnsString += row[column] + "|";
                    }
                }
            }

            Console.WriteLine(columnsString.Substring(0, columnsString.Length - 1));

            //  newReader.
            while (newReader.Read())
            {
                System.Threading.Thread.Sleep(550);
                string strOutString = "";
                for (int i = 0; i < Columns; i++)
                {
                    if (i % 2 != 0)
                    {
                        strOutString += newReader[i];
                        list.Add(strOutString);
                    }
                }
                Console.WriteLine(strOutString);
            }
            ScenarioContext.Current.Add("List", list);
            newReader.Close();
        }


        public static void VerifyDBResults(string DBName, Table GherkinTable)
        {
            Console.WriteLine("- Begin DataBase Validation - ");
            SqlDataReader newReader = DBCommands[DBName].ExecuteReader();
            int Columns = newReader.FieldCount;

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisDB = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(GherkinTable);

            TMSTableRow[] GTable = new TMSTableRow[500];


            int iCounter = 0;
            System.Data.DataTable ST = newReader.GetSchemaTable();
            string thisName = newReader.GetName(0);
            //    DataTable ColumnHeaders = newReader.GetName
            TMSTableRow[] thisTableArr = new TMSTableRow[500];
            int rowCounter = 0;
            thisTableArr[iCounter] = new TMSTableRow();
            thisTableArr[iCounter].RowIsHeader = true;
            thisTableArr[iCounter].RowIsData = false;
            thisTableArr[iCounter].RowIsMatched = false;

            foreach (DataRow row in ST.Rows)
            {
                foreach (DataColumn column in ST.Columns)
                {
                    if (column.ColumnName == "ColumnName")
                    {
                        thisTableArr[iCounter].Row.Add(row.ItemArray[0].ToString());
                        rowCounter++;
                    }
                }
            }
            iCounter++;

            while (newReader.Read())
            {
                thisTableArr[iCounter] = new TMSTableRow();
                thisTableArr[iCounter].RowIsHeader = false;
                thisTableArr[iCounter].RowIsData = true;
                thisTableArr[iCounter].RowIsMatched = false;

                string strOutString = "";
                for (int i = 0; i < Columns; i++)
                {
                    strOutString = "";

                    Type thisType = newReader[i].GetType();
                    string typeName = thisType.Name;
                    switch (typeName)
                    {
                        case "DateTime":
                            {
                                DateTime dateAndTime = (DateTime)(newReader[i]);
                                strOutString += dateAndTime.ToString("yyyy-MM-dd HH:mm:ss.fff");
                                break;
                            }
                        default:
                            {
                                strOutString += newReader[i].ToString();
                                break;
                            }
                    }

                    thisTableArr[iCounter].Row.Add(strOutString);
                    tmsWait.Hard(1);

                }
                tmsWait.Hard(1);
                iCounter++;
            }
            newReader.Close();
            Boolean bThisRowMatches = false;
            int iTableCounter = 0;
            foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
            {
                if (GherkinTableRow == null)
                {
                    break;
                }
                string[] GherkinTableArray = GherkinTableRow.Row.ToArray();
                for (int i = 0; i < iCounter; i++)
                {
                    bThisRowMatches = true;
                    TMSTableRow ApplicationRow = thisTableArr[i];
                    string[] DBTableRow = ApplicationRow.Row.ToArray();
                    int j;
                    int upperLimit = DBTableRow.Count();
                    for (j = 0; j < upperLimit; j++)
                    {
                        Console.WriteLine("~~~~~~~~ DB Table Row => " + DBTableRow[j]);
                        //**************************************************************************************************************************************
                        if (DBTableRow[j].Contains("\r\n-\t"))
                        {

                            if ((DBTableRow[j].Replace("\r\n-\t", "").Replace("\r\n", "").Trim().Contains(GherkinTableArray[j])))
                                bThisRowMatches = true;


                        }

                        else if (DBTableRow[j].Trim().Contains(GherkinTableArray[j].Trim()) || (DBTableRow[j].Trim() == GherkinTableArray[j].Trim()))
                            bThisRowMatches = true;


                        //********************************************************************************************************************************************

                        else if (DBTableRow[j].Trim() != GherkinTableArray[j].Trim() && GherkinTableArray[j].ToLower() != "[skip]")
                        {

                            bThisRowMatches = false;
                            if (GherkinTableArray[j].Trim() == "NULL")
                            {
                                bThisRowMatches = true;
                            }

                        }
                    }
                    iTableCounter = j - 1;
                    if (bThisRowMatches)
                    {
                        GherkinTableRow.RowIsMatched = true;
                        string TR0 = thisDB.ArrayToString(DBTableRow);
                        string TR1 = thisDB.ArrayToString(GherkinTableArray);

                        tmsWait.Hard(1);
                        Console.WriteLine("Expected Row Data --- " + TR1);
                        Console.WriteLine("Found Row Data --- " + TR0);

                    }
                }

            }

            //Look for all data rows matched in Gherkin  (pass if yes, fail if no)
            //Dump Gherkin table to output
            //dump database table to output
            Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
            if (fullMatching)
            {
                Console.WriteLine("All rows are matched, step completed as passed");
            }
            else
            {
                Assert.AreEqual(true, false, "Could not match all the rows in the Gherkin table with DB return rows");

            }
            Console.WriteLine("- End DataBase Validation - ");
        }






        public static void VerifyDBResultsToTable(string DBName, Table GherkinTable)
        {
            Console.WriteLine("- Begin DataBase Validation - ");
            SqlDataReader newReader = DBCommands[DBName].ExecuteReader();
            int Columns = newReader.FieldCount;

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisDB = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(GherkinTable);

            TMSTableRow[] GTable = new TMSTableRow[500];


            int iCounter = 0;
            System.Data.DataTable ST = newReader.GetSchemaTable(); // Returns a DataTable that describes the column metadata of the DataTableReader.
            string thisName = newReader.GetName(0);
            //    DataTable ColumnHeaders = newReader.GetName
            TMSTableRow[] thisTableArr = new TMSTableRow[500];
            int rowCounter = 0;
            thisTableArr[iCounter] = new TMSTableRow();
            thisTableArr[iCounter].RowIsHeader = true;
            thisTableArr[iCounter].RowIsData = false;
            thisTableArr[iCounter].RowIsMatched = false;
            // Just Adding only Columns
            foreach (DataRow row in ST.Rows)
            {
                foreach (DataColumn column in ST.Columns)
                {
                    if (column.ColumnName == "ColumnName")
                    {
                        //Console.WriteLine("Adding [" + row.ItemArray[0] + "] to header row");
                        thisTableArr[iCounter].Row.Add(row.ItemArray[0].ToString());
                        rowCounter++;
                    }
                }
                //                iCounter++;
            }
            iCounter++;
            //  newReader.
            while (newReader.Read())
            {
                thisTableArr[iCounter] = new TMSTableRow();
                thisTableArr[iCounter].RowIsHeader = false;
                thisTableArr[iCounter].RowIsData = true;
                thisTableArr[iCounter].RowIsMatched = false;

                string strOutString = "";
                for (int i = 0; i < Columns; i++)
                {
                    strOutString = "";

                    Type thisType = newReader[i].GetType(); // Gets the Type of the current instance.
                    string typeName = thisType.Name;
                    switch (typeName)
                    {
                        case "DateTime":
                            {
                                DateTime dateAndTime = (DateTime)(newReader[i]);
                                strOutString += dateAndTime.ToString("yyyy-MM-dd HH:mm:ss.fff");
                                break;
                            }
                        case "DBNull":
                            strOutString += "NULL";
                            break;
                        default:
                            {
                                strOutString += newReader[i].ToString();
                                break;
                            }
                    }

                    thisTableArr[iCounter].Row.Add(strOutString);
                    tmsWait.Hard(1);

                }
                tmsWait.Hard(1);
                iCounter++;

                //    Console.WriteLine(strOutString);
            }
            newReader.Close();
            Boolean bThisRowMatches = false;
            int iTableCounter = 0;
            foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
            {
                if (GherkinTableRow == null)
                {
                    break;
                }
                string[] GherkinTableArray = GherkinTableRow.Row.ToArray();
                //foreach (TMSTableRow ApplicationRow in thisTableArr)
                for (int i = 0; i < iCounter; i++)
                {
                    bThisRowMatches = true;
                    TMSTableRow ApplicationRow = thisTableArr[i];
                    string[] DBTableRow = ApplicationRow.Row.ToArray();
                    int j;
                    int upperLimit = DBTableRow.Count();
                    for (j = 0; j < upperLimit; j++)
                    {
                        Console.WriteLine("~~~~~~~~ DB Table Row => " + DBTableRow[j]);
                        //**************************************************************************************************************************************
                        if (DBTableRow[j].Contains("\r\n-\t"))
                        {

                            if ((DBTableRow[j].Replace("\r\n-\t", "").Replace("\r\n", "").Trim().Contains(GherkinTableArray[j])))
                            {

                                bThisRowMatches = true;

                            }

                        }

                        //********************************************************************************************************************************************

                        //          Console.WriteLine("Compare App Data j ["+ j +"] [" + DBTableRow[j].Trim()  + "] to Gherkin Data [" + GherkinTableArray[j].Trim() + "]");
                        else if (DBTableRow[j].Trim() != GherkinTableArray[j].Trim() && GherkinTableArray[j].ToLower() != "[skip]")
                        {

                            bThisRowMatches = false;

                            // if (GherkinTableArray[j].Trim() == "NULL" && upperLimit == 1)
                            if (GherkinTableArray[j].Trim() == "NULL")
                            {
                                bThisRowMatches = true;
                            }

                            //               Console.WriteLine("Not a match j ["+j+"] [" + DBTableRow[j].Trim() + "] / [" + GherkinTableArray[j].Trim() + "]");
                        }
                    }
                    iTableCounter = j - 1;
                    if (bThisRowMatches)
                    {
                        // break;
                        //       Console.WriteLine("Found a match");
                        GherkinTableRow.RowIsMatched = true;
                        string TR0 = thisDB.ArrayToString(DBTableRow);
                        string TR1 = thisDB.ArrayToString(GherkinTableArray);

                        tmsWait.Hard(1);
                        Console.WriteLine("Expected Row Data --- " + TR1);
                        Console.WriteLine("Found Row Data --- " + TR0);

                    }
                }
                //if (bThisRowMatches)
                //{
                //    GherkinTableRow.RowIsMatched = true;
                //}
                //    if (bThisRowMatches)
                //    {
                //        //report the success stuff.  Puts out the row data, etc.
                ////        thisDB.ReportMatching(thisDB.PageTable[iTableCounter], thisGT.GTable[iTableCounter], DBTableRowA, GherkinTableArray);
                //        string TR0 = thisDB.ArrayToString(DBTableRowA);
                //        string TR1 = thisDB.ArrayToString(GherkinTableArray);
                //        Console.WriteLine("Expected Row Data --- " + TR1);
                //        Console.WriteLine("Found Row Data --- " + TR0);
                //    }
            }

            //Look for all data rows matched in Gherkin  (pass if yes, fail if no)
            //Dump Gherkin table to output
            //dump database table to output
            Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
            if (fullMatching)
            {
                Console.WriteLine("All rows are matched, step completed as passed");
            }
            else
            {
                Assert.AreEqual( true, false, "Could not match all the rows in the Gherkin table with DB return rows");

            }
            Console.WriteLine("- End DataBase Validation - ");
        }

    }


    [Binding]
    public class fw
    {
        public static Dictionary<string, string> variable = new Dictionary<string, string>();
        public static void ConsoleReport(string strReport)
        {
            Console.WriteLine("|-->");
            Console.WriteLine("   " + strReport);
           
        }

        public static void setVariable(string varName, string varValue)
        {
            if (variable.ContainsKey(varName))
            {
                variable.Remove(varName);
                variable.Add(varName, varValue);
            }
            else
            {
                variable.Add(varName, varValue);
            }
            Console.WriteLine("Variable [" + varName + "] was set to [" + varValue + "]");
        }
        public static string getVariable(string varName)
        {
            string strReturnString = "";
            if (variable.ContainsKey(varName))
            {
                strReturnString = variable[varName];
            }
            return strReturnString;
        }
        public static Boolean elementExists(IWebElement thisElement)
        {
            try
            {
                string abc = thisElement.Size.ToString();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static void ReportOn(IWebElement thisElement, string fieldName)
        {
            Boolean Displayed = false;
            try
            {
                Displayed = thisElement.Displayed;
            }
            catch
            {
                Displayed = false;
            }
            if (Displayed)
            {
                Console.WriteLine("Element exists for [" + fieldName + "]");
            }
            else
            {
                Console.WriteLine("Element does not exist for [" + fieldName + "]");
            }
            Assert.AreEqual(true, Displayed, "Element exists for [" + fieldName + "]");
        }

        /// <summary>
        /// Execute Java Script with the help of Interface JavaScriptExecutor
        /// </summary>
        /// <param name="javaScript">Java Script</param>
        public static void ExecuteJavascript(string javaScript)
        {
            IJavaScriptExecutor js = Browser.Wd as IJavaScriptExecutor;
            js.ExecuteScript(javaScript);
        }
        /// <summary>
        /// refresh page using Java Scripts
        /// </summary>
        public static void RefreshUsingJavascript()
        {
            IJavaScriptExecutor js = Browser.Wd as IJavaScriptExecutor;
            js.ExecuteScript("location.reload()");
        }



        /// <summary>
        /// Return Hidden text using Javascript
        /// </summary>
        /// <param name="element">IWebElement</param>
        /// <returns>Object contains hidden text</returns>
        public static object ExecuteJavascriptReturnText(IWebElement element)
        {
            IJavaScriptExecutor js = Browser.Wd as IJavaScriptExecutor;
            return js.ExecuteScript("return arguments[0].innerHTML", element);
        }


        /// <summary>
        /// Click on element based on Argument and JavaScript Executor interface
        /// </summary>
        /// <param name="element">IWebElement</param>
        public static void ExecuteJavascript(IWebElement element)
        {
            IJavaScriptExecutor js = Browser.Wd as IJavaScriptExecutor;

            js.ExecuteScript("arguments[0].click();", element);

        }

        public static void ExecuteJavascriptUsingGetElementByID(string input)
        {
            string ID = input;
            IJavaScriptExecutor js = Browser.Wd as IJavaScriptExecutor;
            js.ExecuteScript("document.getElementById('" + ID + "').click();");


        }


        public static void ScrollWindowToViewElement(IWebElement element)
        {
            IJavaScriptExecutor js = Browser.Wd as IJavaScriptExecutor;
            js.ExecuteScript("arguments[0].scrollIntoView(true);", element);
        }
        public static void ScrollWindowToViewElement(By by)
        {
            IWebElement e = Browser.Wd.FindElement(by);
            IJavaScriptExecutor js = Browser.Wd as IJavaScriptExecutor;
            js.ExecuteScript("arguments[0].scrollIntoView(true);", e);
        }

        public static void ScrollWindowToViewElementUsingLocators(By loc)
        {
            IWebElement element = Browser.Wd.FindElement(loc);
            IJavaScriptExecutor js = Browser.Wd as IJavaScriptExecutor;
            js.ExecuteScript("arguments[0].scrollIntoView(true);", element);
        }
        public static void ExecuteJavascriptScroll(IWebElement element)
        {
            IJavaScriptExecutor js = Browser.Wd as IJavaScriptExecutor;
            js.ExecuteScript("arguments[0].scrollIntoView(true);", element);
            tmsWait.Hard(2);
            js.ExecuteScript("arguments[0].click();", element);
        }

        /// <summary>
        /// Set the date from Kendo Date and JavaScript Executor interface
        /// </summary>
        /// <param name="element">IWebElement</param>
        /// <param name="dt">Date to set MM/DD/YYYY</param>
        public static void ExecuteJavascriptSetText(IWebElement element, string dt)
        {
            IJavaScriptExecutor js = Browser.Wd as IJavaScriptExecutor;

            js.ExecuteScript("arguments[0].title='" + dt + "';", element);
        }

        /// <summary>
        /// Set the date from Kendo Date and JavaScript Executor interface
        /// </summary>
        /// <param name="element">IWebElement</param>
        /// <param name="dt">Date to set MM/DD/YYYY</param>
        public static void ExecuteJavascriptSetAtribute(IWebElement element, string dt)
        {
            IJavaScriptExecutor js = Browser.Wd as IJavaScriptExecutor;
            js.ExecuteScript("arguments[0].setAttribute('attr','" + dt + "')", element);
        }

        /// <summary>
        /// Set the date from Kendo Date and JavaScript Executor interface
        /// </summary>
        /// <param name="element">IWebElement</param>
        /// <param name="dt">Date to set MM/DD/YYYY</param>
        public static void ExecuteJavascriptSetAtributeValue(IWebElement element, string dt)
        {
            IJavaScriptExecutor js = Browser.Wd as IJavaScriptExecutor;
            js.ExecuteScript("arguments[0].setAttribute('value','" + dt + "')", element);
        }


        /// <summary>
        /// Gets the text of an element
        /// </summary>
        /// <param name="by">By</param>
        /// <returns>string</returns>
        public static string GetElementText(By by)
        {
            return (Browser.Wd.FindElement(by).Text);
        }


        /// <summary>
        /// Selecting value from Kendo Dropdown
        /// </summary>
        /// <param name="driver">Driver</param>
        /// <param name="select">SelectElement</param>
        /// <param name="value">Value to be selected</param>
        public static void KendoSelectByValue(IWebDriver driver, IWebElement select, string value)
        {
            var selectElement = new SelectElement(select);
            for (int i = 0; i < selectElement.Options.Count; i++)
            {
                if (selectElement.Options[i].GetAttribute("value") == value || selectElement.Options[i].GetAttribute("text") == value)
                {
                    var id = select.GetAttribute("id");
                    ((IJavaScriptExecutor)driver).ExecuteScript(String.Format("$('#{0}').data('kendoDropDownList').select({1});", id, i));
                    break;
                }
            }
        }

        internal static object setVariable(string p0)
        {
            throw new NotImplementedException();
        }
    }


    [Binding]
    public class ReadFileFunctions
    {
        /// <summary>
        /// Read PDF File Content
        /// </summary>
        /// <param name="pdfFilePath">PDF File Path</param>
        /// <returns>Text from PDF File</returns>
        public static string ReadPDFFile(string pdfFilePath)
        {
            int count = 0;
            do
            {
                tmsWait.Hard(2);
                count++;
                FileInfo filinfo = new FileInfo(pdfFilePath);
                filinfo.Refresh();
            } while (count < 7);
            fw.ConsoleReport(pdfFilePath + " is downloaded");
            PdfReader reader2 = new PdfReader(pdfFilePath);
            string textFromPDF = string.Empty;

            if (pdfFilePath.Contains("PIR By PCP"))
            {
                ITextExtractionStrategy its = new SimpleTextExtractionStrategy();
                PdfReader pdfReader = new PdfReader(pdfFilePath);
                string textfromPDF = PdfTextExtractor.GetTextFromPage(pdfReader, 1, its);
                textfromPDF = Encoding.UTF8.GetString(ASCIIEncoding.Convert(Encoding.Default, Encoding.UTF8, Encoding.Default.GetBytes(textfromPDF)));
                textFromPDF = textFromPDF + textfromPDF;
                pdfReader.Close();
            }

            else
            {


                for (int page = 1; page <= reader2.NumberOfPages; page++)
                {
                    ITextExtractionStrategy its = new SimpleTextExtractionStrategy();
                    PdfReader pdfReader = new PdfReader(pdfFilePath);
                    string textfromPDF = PdfTextExtractor.GetTextFromPage(pdfReader, page, its);
                    textfromPDF = Encoding.UTF8.GetString(ASCIIEncoding.Convert(Encoding.Default, Encoding.UTF8, Encoding.Default.GetBytes(textfromPDF)));
                    textFromPDF = textFromPDF + textfromPDF;
                    pdfReader.Close();

                }

            }
            reader2.Close();
            return textFromPDF;
        }


        /// <summary>
        /// Read CSV File Content
        /// </summary>
        /// <param name="csvFilePath">CSV File Path</param>
        /// <returns>Text from CSV File</returns>
        public static List<string> ReadCSVFile(string csvFilePath)
        {
            fw.ConsoleReport(csvFilePath + " is downloaded");
            StreamReader streamReader = new StreamReader(csvFilePath);
            List<string> csvData = new List<string>();
            string strline = "";
            string[] _values = null;
            int x = 0;
            while (!streamReader.EndOfStream)
            {
                x++;
                strline = streamReader.ReadLine();
                _values = strline.Split(';');
                foreach (string value in _values)
                {
                    csvData.Add(value);
                }
            }
            streamReader.Close();
            return csvData;
        }

        /// <summary>
        /// Read Text File Content
        /// </summary>
        /// <param name="txtFilePath">Text File Path</param>
        /// <returns>Text from File</returns>
        public static List<string> ReadTEXTFile(string txtFilePath)
        {
            fw.ConsoleReport(txtFilePath + " is downloaded");
            StreamReader streamReader = new StreamReader(txtFilePath);
            List<string> txtData = new List<string>();
            string strline = "";
            string[] _values = null;
            int x = 0;
            while (!streamReader.EndOfStream)
            {
                x++;
                strline = streamReader.ReadLine();
                _values = strline.Split(';');
                foreach (string value in _values)
                {
                    txtData.Add(value);
                }
            }
            streamReader.Close();
            return txtData;
        }

        /// <summary>
        /// Converting XLS filr into CSV
        /// <para>Calling function ReadCSVFile to read data from CSV file</para>
        /// </summary>
        /// <param name="sourceXLSFilePath">XLS Source File Path</param>
        /// <param name="targetCSVFilePath">Target CSV File Path</param>
        /// <returns>Data from converted CSV file</returns>
        public static List<string> ReadXLSFile(string sourceXLSFilePath, string targetCSVFilePath)
        {
            fw.ConsoleReport(sourceXLSFilePath + " is downloaded");
            Microsoft.Office.Interop.Excel.Application xls = new Microsoft.Office.Interop.Excel.Application();
            Workbook workbook = xls.Workbooks.Open(sourceXLSFilePath);
           
            Worksheet ws = (Worksheet)workbook.Sheets[1];

            //Conversion of XLS frile to CSV file
            ws.SaveAs(targetCSVFilePath, XlFileFormat.xlCSV);
            fw.ConsoleReport(" Now Excel file is converted to CSV format to read file content");
            // Deleting Source XLS file after saving in to .CSV format

            string[] fileExtensions = { ".XLS", ".xls" };

            string downloadPath = System.IO.Path.Combine(Environment.ExpandEnvironmentVariables("%userprofile%"), "Downloads");
            DirectoryInfo di = new DirectoryInfo(downloadPath);
            FileInfo[] oldDownloadedFiles = di.EnumerateFiles().Where(p => fileExtensions.Contains(p.Extension, StringComparer.InvariantCultureIgnoreCase)).ToArray();


            foreach (var oldFile in oldDownloadedFiles)
            {
                oldFile.Attributes = FileAttributes.Normal;
                File.Delete(oldFile.FullName);
            }
            //Releasing and killing XLS object
            Marshal.ReleaseComObject(ws);
            workbook.Close(0);
            xls.Quit();
            Marshal.ReleaseComObject(xls);
            Process[] process = Process.GetProcessesByName("Excel");
            foreach (Process p in process)
            {
                if (!string.IsNullOrEmpty(p.ProcessName))
                {
                    try
                    {
                        p.Kill();
                    }
                    catch { }
                }
            }

            //Reading data from CSV file
            return ReadCSVFile(targetCSVFilePath);
        }
    }

    [Binding]
    public static class KendoUIFunctions
    {
        private static bool nextPage;

        /// <summary>
        /// Click on Next Button
        /// </summary>

        public static void NextButton()
        {
            IWebElement NextButton = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
            fw.ExecuteJavascript(NextButton);
        }

        public static void previousButton()
        {
            IWebElement previousButton = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the previous page']"));
            fw.ExecuteJavascript(previousButton);
        }

        public static void GoToFirstPage()
        {
            IWebElement NextButton = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the first page']"));
            fw.ExecuteJavascript(NextButton);
        }

        public static void GoToLastPage()
        {
            IWebElement NextButton = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']"));
            fw.ExecuteJavascript(NextButton);
        }


        public static void deleteGridValue(string actualCode)
        {
            do
            {
                nextPage = SearchTextInResultGrid(actualCode);
                if (nextPage)
                {
                    tmsWait.Hard(2);
                    IWebElement NextButton = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    fw.ExecuteJavascript(NextButton);
                }
            } while (nextPage);

            if (!nextPage)
            {
                tmsWait.Hard(3);
                IWebElement deleteicon = Browser.Wd.FindElement(By.XPath("//tr[contains(.,'" + actualCode + "')]//td//button//span[@class='fas fa-trash-alt']"));
                fw.ExecuteJavascript(deleteicon);

            }


        }

        public static bool SearchTextInResultGridWithStatus(string textValidate, string status)
        {
            try
            {
                if (status.ToLower().Equals("active"))
                {
                    string check = Browser.Wd.FindElement(By.XPath("//table[@role='grid']//td[contains(.,'" + textValidate + "')]/preceding-sibling::td/input")).GetAttribute("checked");
                    if (check.ToLower().Equals("true"))
                    {

                        return false;
                    }
                }

            }
            catch (Exception ex)
            {
                return true;
            }
            return true;
        }

        public static bool SearchTextInResultGridandDoAction(string textValidate, string status)
        {
            try
            {
                if (status.ToLower().Equals("active"))
                {


                    if (Browser.Wd.FindElement(By.XPath("//table[@role='grid']//td[contains(.,'" + textValidate + "')]")).Displayed)
                    {
                        string check = Browser.Wd.FindElement(By.XPath("//table[@role='grid']//td[contains(.,'" + textValidate + "')]/preceding-sibling::td/input")).GetAttribute("checked");
                        if (check.ToLower().Equals("checked"))
                        {
                            Console.WriteLine("Reason Code already checked");
                            return false;
                        }
                        else
                        {
                            Browser.Wd.FindElement(By.XPath("//table[@role='grid']//td[contains(.,'" + textValidate + "')]/preceding-sibling::td/input")).Click();
                            Console.WriteLine("Reason Code is checked now");
                            return false;
                        }
                    }
                }
                if (status.ToLower().Equals("inactive"))
                {


                    if (Browser.Wd.FindElement(By.XPath("//table[@role='grid']//td[contains(.,'" + textValidate + "')]")).Displayed)
                    {
                        string check = Browser.Wd.FindElement(By.XPath("//table[@role='grid']//td[contains(.,'" + textValidate + "')]/preceding-sibling::td/input")).GetAttribute("checked");
                        if (check.ToLower().Equals("true"))
                        {
                            Browser.Wd.FindElement(By.XPath("//table[@role='grid']//td[contains(.,'" + textValidate + "')]/following-sibling::td/a")).Click();
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//tr[@data-role='editable']//input[@type='checkbox']")));
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//tr[@data-role='editable']//a[contains(@class,'update')]")));

                            Console.WriteLine("Reason Code is unchecked now");
                            return false;
                        }
                        else
                        {
                            // Browser.Wd.FindElement(By.XPath("//table[@role='grid']//td[contains(.,'" + textValidate + "')]/preceding-sibling::td/input")).Click();
                            Console.WriteLine("Reason Code already unchecked");
                            return false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return true;
            }
            return true;
        }

        public static bool SearchTextInResultGrid(string textValidate)
        {
            try
            {
                if (Browser.Wd.FindElement(By.XPath("//table[@role='presentation']//td[contains(.,'" + textValidate + "')]")).Displayed)
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                return true;
            }
            return true;
        }

        public static void KendoSelectByValue(IWebElement value, IWebElement Dropdownclick)
        {
            tmsWait.Hard(1);
            fw.ExecuteJavascript(Dropdownclick);
            tmsWait.Hard(3);
            fw.ExecuteJavascript(value);
        }
        public static void ResultGridTextValidationWithStatus(string textdata, string status)
        {
            do
            {
                nextPage = SearchTextInResultGridWithStatus(textdata, status);
                if (nextPage)
                {
                    string Actual_Page_Number = Browser.Wd.FindElement(By.XPath("//span[@class='k-pager-input k-label']//input")).GetAttribute("value");
                    string Number = Browser.Wd.FindElement(By.XPath("//span[@class='k-pager-input k-label']")).Text;
                    string Total_count = Number.Replace("Pageof", "");

                    if (Actual_Page_Number.Equals(Total_count))
                    {
                        Assert.Fail("As per expectation data not found in result grid till then end of page. Kindly verify the result grid manullay and verify the issue");
                    }
                    else
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@aria-label='Go to the next page']//span")));

                    }

                }
            } while (nextPage);
        }

        public static void ResultGridDoCheckUncheck(string reason, string status)

        {
            do
            {
                nextPage = SearchTextInResultGridandDoAction(reason, status);
                if (nextPage)
                {
                    string Actual_Page_Number = Browser.Wd.FindElement(By.XPath("//span[@class='k-pager-input k-label']//input")).GetAttribute("value");
                    string Number = Browser.Wd.FindElement(By.XPath("//span[@class='k-pager-input k-label']")).Text;
                    string Total_count = Number.Replace("Pageof", "");

                    if (Actual_Page_Number.Equals(Total_count))
                    {
                        Assert.Fail("As per expectation data not found in result grid till then end of page. Kindly verify the result grid manullay and verify the issue");
                    }
                    else
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@aria-label='Go to the next page']//span")));

                    }

                }
            } while (nextPage);
        }
        public static void ResultGridTextValidation(string textdata)
        {
            do
            {
                nextPage = SearchTextInResultGrid(textdata);
                if (nextPage)
                {
                    string Actual_Page_Number = Browser.Wd.FindElement(By.XPath("//span[@class='k-pager-input k-label']//input")).GetAttribute("value");
                    string Number = Browser.Wd.FindElement(By.XPath("//span[@class='k-pager-input k-label']")).Text;
                    string Total_count = Number.Replace("Page\r\nof ", "");

                    if (Actual_Page_Number.Equals(Total_count))
                    {
                        Assert.Fail("As per expectation data not found in result grid till then end of page. Kindly verify the result grid manullay and verify the issue");
                    }
                    else
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']//span")));

                    }

                }
            } while (nextPage);
        }

        public static void SearchTextInResultGridWithStatusList1()
        {
            string Actual_Page_Number = Browser.Wd.FindElement(By.XPath("//span[@class='k-pager-input k-label']//input")).GetAttribute("value");
            string Number = Browser.Wd.FindElement(By.XPath("//span[@class='k-pager-input k-label']")).Text;
            string Total_count = Number.Replace("Pageof", "");

        }

        public static void EditAndUpdateResultGridRecord(string actualCode, string actualDescription)
        {

            //Edit  dignosis code
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + actualCode + "')]//following-sibling::td//span[@class='fas fa-pencil-alt']")));
            string updateddescription = "Update" + actualDescription;
            tmsWait.Hard(5);
            // Update Diagnosis Code Description
            Browser.Wd.FindElement(By.XPath("//input[@name='description']")).Clear();
            tmsWait.Hard(1);
            Browser.Wd.FindElement(By.XPath("//input[@name='description']")).SendKeys(updateddescription);
            // fw.ExecuteJavascriptSetText(Browser.Wd.FindElement(By.XPath("//input[@name='description']")), updateddescription);
            //.SendKeys(updateddescription);
            //tmsWait.Hard(2);
            IWebElement currentElement = Browser.Wd.SwitchTo().ActiveElement();
            currentElement.SendKeys(OpenQA.Selenium.Keys.Tab);
            //Click on Save Button 
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//input[@id='description']/parent::td/following-sibling::td//button/span[@class='fas fa-save']")));
            tmsWait.Hard(1);
        }

    }

    public static class DeskTopWindowHandle
    {
        /// <summary>
        /// Get handles of Opened windows
        /// </summary>
        /// <returns>List of windows</returns>
        public static IDictionary<string, IntPtr> GetOpenWindows()
        {
            IntPtr lShellWindow = GetShellWindow();
            Dictionary<string, IntPtr> lWindows = new Dictionary<string, IntPtr>();
            EnumWindows(delegate (IntPtr hWnd, int lParam)
            {
                if (hWnd == lShellWindow) return true;
                if (!IsWindowVisible(hWnd)) return true;
                int lLength = GetWindowTextLength(hWnd);
                if (lLength == 0) return true;

                StringBuilder lBuilder = new StringBuilder(lLength);
                GetWindowText(hWnd, lBuilder, lLength + 1);
                lWindows[lBuilder.ToString()] = hWnd;
                return true;
            }, 0);

            return lWindows;
        }

        public delegate bool EnumDelegate(IntPtr hWnd, int lParam);
        public delegate bool EnumedWindow(IntPtr handleWindow, ArrayList handles);

        [DllImport("USER32.DLL")]
        public static extern bool EnumWindows(EnumDelegate enumFunc, int lParam);

        [DllImport("USER32.DLL")]
        public static extern IntPtr GetShellWindow();

        [DllImport("USER32.DLL")]
        public static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

        [DllImport("USER32.DLL")]
        public static extern int GetWindowTextLength(IntPtr hWnd);

        [DllImport("USER32.DLL")]
        public static extern bool IsWindowVisible(IntPtr hWnd);

        [DllImport("user32.dll")]
        public static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("user32.dll", EntryPoint = "FindWindow")]
        public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        [DllImport("user32", CharSet = CharSet.Ansi, SetLastError = true, ExactSpelling = true)]
        internal static extern IntPtr SetFocus(IntPtr hwnd);

        [DllImport("user32.dll", SetLastError = true)]
        public static extern void keybd_event(byte bVk, byte bScan, int dwFlags, int dwExtraInfo);

        public const int VK_TAB = 0x09; //Pressing TAB key
        public const int VK_RETURN = 0x0D; //Pressing ENTER key
        public const int VK_MENU = 0x12; // Pressing Alt Key
        public const int VK_CONTROL = 0x11; // Pressing Ctrl Key
        public const int VK_S = 0x53; // Pressing S Key
        public const int VK_ESCAPE = 0x1B;//Pressing ESCAPE key
        public const int KEYEVENTF_KEYUP = 0x0002;


    }

    public class MouseFunctions
    {
        /// <summary>
        /// Mouse move to Elemetn
        /// </summary>
        /// <param name="elementTobeMouseMove">Element to be move mouse on</param>
        public static void MouseMoveToElement(IWebElement elementTobeMouseMove)
        {
            OpenQA.Selenium.Interactions.Actions builder = new OpenQA.Selenium.Interactions.Actions(Browser.Wd);
            builder.MoveToElement(elementTobeMouseMove).ClickAndHold().Release().Build().Perform();
            tmsWait.Hard(3);
        }
        public static void MouseMoveToElementt(IWebElement elementTobeMouseMove)
        {
            OpenQA.Selenium.Interactions.Actions builder = new OpenQA.Selenium.Interactions.Actions(Browser.Wd);
            builder.MoveToElement(elementTobeMouseMove).Build().Perform();
            tmsWait.Hard(3);
        }
        public static void MouseMoveToElementt(IWebElement elementTobeMouseMove1, IWebElement elementTobeMouseMove2)
        {
            OpenQA.Selenium.Interactions.Actions builder = new OpenQA.Selenium.Interactions.Actions(Browser.Wd);
            builder.MoveToElement(elementTobeMouseMove1).MoveToElement(elementTobeMouseMove2).Build().Perform();
            tmsWait.Hard(3);
        }
        /// <summary>
        /// Double click on element with the help of Mouse
        /// </summary>
        /// <param name="elementTobeClick">Element to be clicked</param>
        public static void DoubleClickOnElement(IWebElement elementTobeClick)
        {
            OpenQA.Selenium.Interactions.Actions action = new OpenQA.Selenium.Interactions.Actions(Browser.Wd);
            action.DoubleClick(elementTobeClick).Build().Perform();
        }
    }



    public class tmsWait
    {
        public static void Hard(int iSeconds)
        {
            System.Threading.Thread.Sleep(iSeconds * 1000);
        }
        public static void Implicit(int iSeconds)
        {
            Browser.Wd.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(iSeconds);
        }


        /// <summary>
        /// Wait untill html element appears.
        /// Element will be found by locator By by. 
        /// Return found IWebelement or null
        /// </summary>
        public static IWebElement WaitForElementExist(By by, int iSeconds)
        {
            //The code in here DOES NOT WORK.
            //Do not hook it up again.   If we need this functionality we need 
            //WORKING functionality.

            tmsWait.Hard(5);
            //
            //IWebElement objElement = null;
            //try
            //{
            //    WebDriverWait wait = new WebDriverWait(Browser.Wd, TimeSpan.FromSeconds(iSeconds));
            //    objElement = wait.Until(x => x.FindElement(by));
            //}
            //catch (Exception) { }
            //return objElement;
            return null;
        }

        /// <summary>
        /// Wait for element to be visible on page
        /// </summary>
        /// <param name="by">By</param>
        /// <param name="maxSecondsToWait">Max second for wait</param>
        public static void WaitForElement(By by, int maxSecondsToWait = 100)
        {
            new WebDriverWait(Browser.Wd, new TimeSpan(0, 0, maxSecondsToWait))
                .Until(ExpectedConditions.ElementIsVisible(by));
        }

        /// <summary>
        /// Wait for element to be selected on page e.g. Dropdownbox
        /// </summary>
        /// <param name="by">By</param>
        /// <param name="maxSecondsToWait">Max second for wait</param>
        public static void WaitForElementIsSelectable(By by, int maxSecondsToWait = 30)
        {
            new WebDriverWait(Browser.Wd, new TimeSpan(0, 0, maxSecondsToWait))
                .Until(ExpectedConditions.ElementToBeSelected(by));
        }

        /// <summary>
        /// Wait for element to be clicked on page e.g Button, Radiobutton
        /// </summary>
        /// <param name="by">By</param>
        /// <param name="maxSecondsToWait">Max second for wait</param>
        public static void WaitForElementToBeClicked(By by, int maxSecondsToWait = 30)
        {
            new WebDriverWait(Browser.Wd, new TimeSpan(0, 0, maxSecondsToWait))
                .Until(ExpectedConditions.ElementToBeClickable(by));
        }


        /// <summary>
        /// Wait untill html element appears and have attribute readySate= complete.
        /// Element will be found by locator By by. 
        /// Return found IWebelement or null
        /// </summary>
        public static bool WaitForElementAttributeHasValue(By by, int iSeconds, string strAttrName, string strAttrValue)
        {
            bool res = false;
            try
            {
                WebDriverWait wait = new WebDriverWait(Browser.Wd, TimeSpan.FromSeconds(iSeconds));
                res = wait.Until(x => x.FindElement(by).GetAttribute(strAttrName).ToString().Equals(strAttrValue));
            }
            catch (Exception) { }
            return res;
        }

        /// <summary>
        /// Wait untill html element appears with expected text.
        /// Element will be found by locator By by. 
        /// Return true if element with expected text is found, false - otherwise
        /// </summary>
        public static bool WaitForElementHasText(By by, string strText, int iSeconds)
        {
            bool blnResult = false;
            try
            {
                WebDriverWait wait = new WebDriverWait(Browser.Wd, TimeSpan.FromSeconds(iSeconds));
                blnResult = wait.Until(d => d.FindElement(by).Text.Contains(strText));
            }
            catch (Exception) { }
            return blnResult;
        }

        /// <summary>
        /// Wait for Alert to be present
        /// </summary>
        /// <param name="maxSecondsToWait">Max seconds to wait</param>
        /// <returns>Boolean value whether Alert is present or not</returns>
        public static bool WaitForAlertPresent(int maxSecondsToWait = 3)
        {
            try
            {
                new WebDriverWait(Browser.Wd, new TimeSpan(0, 0, maxSecondsToWait))
                    .Until(d => IsAlertPresent());
                return true;
            }
            catch
            {
                //no alert found
                return false;
            }
        }

        /// <summary>
        /// Check whether Alert is present or not
        /// </summary>
        /// <returns>Boolean</returns>
        public static bool IsAlertPresent()
        {
            try
            {
                Browser.Wd.SwitchTo().Alert();
                return true;
            }
            catch (NoAlertPresentException)
            {
                return false;
            }
        }

        /// <summary>
        /// Check that a particular element is present on the page right now. Does not wait for it to be present.
        /// </summary>
        /// <param name="by">By</param>
        /// <returns>Boolean</returns>
        public static bool IsElementPresent(By by)
        {
            try
            {
                Browser.Wd.FindElement(by);
                return true;
            }
            catch (NoSuchElementException)
            {
                return false;
            }
        }


        /// <summary>
        /// Wait for document'sready state equals "complete"
        /// </summary>
        public static void WaitForReadyStateComplete(int iSeconds)
        {
            IWait<IWebDriver> wait = new OpenQA.Selenium.Support.UI.WebDriverWait(Browser.Wd, TimeSpan.FromSeconds(iSeconds));
            for (int i = 0; i < 4; i++)
            {
                wait.Until(driver1 => ((IJavaScriptExecutor)Browser.Wd).ExecuteScript("return document.readyState").Equals("complete"));
            }
        }


        /// <summary>
        /// Wait for other child window to open (Moving from Parent to Child Window)
        /// </summary>
        public static void WaitForWindowToOpen()
        {
            var wait = new WebDriverWait(Browser.Wd, TimeSpan.FromSeconds(30));
            wait.Until(d => d.WindowHandles.Count == 2);
        }

        /// <summary>
        /// Wait for other child window to close (Moving from Child to Parent Window)
        /// </summary>
        public static void WaitForWindowToClose()
        {
            var wait = new WebDriverWait(Browser.Wd, TimeSpan.FromSeconds(30));
            wait.Until(d => d.WindowHandles.Count == 1);
        }
    }

    public class tmsHTML
    {
        public static string tag;
    }

    public class tmsCommon
    {
        public static string BareDate(string strFullDate)
        {
            return strFullDate.Replace("/", "");
        }
        public static string GenerateData(string strInput)
        {
            if (ConfigFile.URL == "")
            {
                ConfigFile.ReadFromConfigFile();
            }

            string strReturnString = "";
            int lenOfString = strInput.Length;
            int maxCharactersMatch = 8;
            if (lenOfString < 8)
            {
                maxCharactersMatch = lenOfString;
            }
            string strNewString = strInput;
            if (strInput.Length > 9 && strInput.Substring(0, 9).ToLower() == "variable[")
            {
                string[] parts = strInput.Split('[');
                string[] final = parts[1].Split(']');

                strNewString = "Generate|variable|" + final[0];

            }
            if (strInput.Length > 10 && strInput.Substring(0, 11).ToLower() == "configfile[")
            {
                string[] parts = strInput.Split('[');
                string[] final = parts[1].Split(']');

                strNewString = "Generate|configfile|" + final[0];

            }

            if (strNewString.Substring(0, maxCharactersMatch).ToLower() != "generate")
            {
                strReturnString = strInput;
            }
            string[] strArray = strNewString.Split('|');



            int arrayCount = strArray.Count();
            for (int i = 0; i < arrayCount; i++)
            {
                if (strArray[i].Trim().ToLower() == "num")
                {
                    Random rnd = new Random();
                    int loopTo = Convert.ToInt32(strArray[i + 1]);
                    for (int lo = 1; lo < loopTo + 1; lo++)
                    {
                        strReturnString = strReturnString + rnd.Next(0, 9).ToString();
                    }

                }

                if (strArray[i].Trim().ToLower() == "numm")
                {
                    Random rnd = new Random();

                    strReturnString = strReturnString + rnd.Next(11, 60).ToString();
                }

                if (strArray[i].Trim().ToLower() == "current+1")
                {
                    DateTime Date = DateTime.Now;
                    System.DateTime DateAdd = Date.AddYears(1);
                    strReturnString = DateAdd.Year.ToString();
                }

                if (strArray[i].Trim().ToLower() == "current-1")
                {
                    DateTime Date = DateTime.Now;
                    System.DateTime DateAdd = Date.AddYears(-1);
                    strReturnString = DateAdd.Year.ToString();
                }
                if (strArray[i].Trim().ToLower() == "current-2")
                {
                    DateTime Date = DateTime.Now;
                    System.DateTime DateAdd = Date.AddYears(-2);
                    strReturnString = DateAdd.Year.ToString();
                }
                if (strArray[i].Trim().ToLower() == "current")
                {
                    DateTime dt = DateTime.Now;
                    strReturnString = dt.Year.ToString();
                }
                if (strArray[i].Trim().ToLower() == "currentdate")
                {
                    //DateTime today = DateTime.Today.
                    strReturnString = DateTime.Today.ToString("yyyyMMdd");
                }
                if (strArray[i].Trim().ToLower() == "timestamp")
                {
                    strReturnString = DateTime.Now.ToString("MMddyyyyHHmmss");
                }

                if (strArray[i].Trim().ToLower() == "variable")
                {
                    string varName = strArray[i + 1].ToString();
                    strReturnString = strReturnString + fw.getVariable(varName);
                    Console.WriteLine("Variable [" + varName + "] converted out to value [" + fw.getVariable(varName) + "]");
                }
                if (strArray[i].ToLower() == "configfile")
                {
                    string varName = strArray[i + 1].ToString();
                    switch (varName)
                    {
                        case "RAMExecutable": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.RAMExecutable + "]"); strReturnString += ConfigFile.RAMExecutable; break; }
                        case "RAMExecutablePath": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.RAMExecutablePath + "]"); strReturnString += ConfigFile.RAMExecutablePath; break; }
                        case "RAMUser": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.RAMUser + "]"); strReturnString += ConfigFile.RAMUser; break; }
                        case "RAMPassword": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.RAMPassword + "]"); strReturnString += ConfigFile.RAMPassword; break; }
                        case "BrowserType": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.BrowserType + "]"); strReturnString += ConfigFile.BrowserType; break; }
                        case "URL": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.URL + "]"); strReturnString += ConfigFile.URL; break; }
                        case "IDMURL": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.IDMURL + "]"); strReturnString += ConfigFile.IDMURL; break; }
                        case "UserId": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.UserId + "]"); strReturnString += ConfigFile.UserId; break; }
                        case "Password": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.Password + "]"); strReturnString += ConfigFile.Password; break; }
                        case "EAMdb": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.EAMdb + "]"); strReturnString += ConfigFile.EAMdb; break; }
                        case "FRMdb": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.FRMdb + "]"); strReturnString += ConfigFile.FRMdb; break; }
                        case "RSMdb": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.RSMdb + "]"); strReturnString += ConfigFile.RSMdb; break; }
                        case "PDEMdb": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.PDEMdb + "]"); strReturnString += ConfigFile.PDEMdb; break; }
                        case "DLMdb": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.DLMdb + "]"); strReturnString += ConfigFile.DLMdb; break; }
                        case "RAMdb": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.RAMdb + "]"); strReturnString += ConfigFile.RAMdb; break; }
                        case "RAMXdb": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.RAMXdb + "]"); strReturnString += ConfigFile.RAMXdb; break; }
                        case "FRMedb": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.FRMedb + "]"); strReturnString += ConfigFile.FRMedb; break; }
                        case "Warehousedb": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.Warehousedb + "]"); strReturnString += ConfigFile.Warehousedb; break; }
                        case "PDMMetaDatadb": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.PDMMetaDatadb + "]"); strReturnString += ConfigFile.PDMMetaDatadb; break; }
                        case "EAMedb": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.EAMedb + "]"); strReturnString += ConfigFile.EAMedb; break; }
                        case "PathforDataFile": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.PathforDataFile + "]"); strReturnString += ConfigFile.PathforDataFile; break; }
                        case "AllowLocalDt": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.AllowLocalDt + "]"); strReturnString += ConfigFile.AllowLocalDt; break; }
                        case "Client": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.Client + "]"); strReturnString += ConfigFile.Client; break; }
                        case "Database": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.Database + "]"); strReturnString += ConfigFile.Database; break; }
                        case "DataServer": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.DataServer + "]"); strReturnString += ConfigFile.DataServer; break; }
                        case "Port": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.Port + "]"); strReturnString += ConfigFile.Port; break; }
                        case "DBDriver": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.DBDriver + "]"); strReturnString += ConfigFile.DBDriver; break; }
                        case "DBUser": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.DBUser + "]"); strReturnString += ConfigFile.DBUser; break; }
                        case "DBPassword": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.DBPassword + "]"); strReturnString += ConfigFile.DBPassword; break; }
                        case "TCSServer": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.TCSServer + "]"); strReturnString += ConfigFile.TCSServer; break; }
                        case "TCSDatabase": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.TCSDatabase + "]"); strReturnString += ConfigFile.TCSDatabase; break; }
                        case "TCSDBUser": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.EAMdb + "]"); strReturnString += ConfigFile.EAMdb; break; }
                        case "EnvType": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.EnvType + "]"); strReturnString += ConfigFile.EnvType; break; }
                        case "TCSDBPassword": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.TCSDBPassword + "]"); strReturnString += ConfigFile.TCSDBPassword; break; }
                        case "ALMURL": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.ALMURL + "]"); strReturnString += ConfigFile.ALMURL; break; }
                        case "ALMDomain": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.ALMDomain + "]"); strReturnString += ConfigFile.ALMDomain; break; }
                        case "ALMProject": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.ALMProject + "]"); strReturnString += ConfigFile.ALMProject; break; }
                        case "ALMUser": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.ALMUser + "]"); strReturnString += ConfigFile.ALMUser; break; }
                        case "ALMPassword": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.ALMPassword + "]"); strReturnString += ConfigFile.ALMPassword; break; }
                        case "PDMDB": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.PDMDB + "]"); strReturnString += ConfigFile.PDMDB; break; }
                        case "PDMDBPassword": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.PDMDBPassword + "]"); strReturnString += ConfigFile.PDMDBPassword; break; }
                        case "Tenant": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.Tenant + "]"); strReturnString += ConfigFile.Tenant; break; }
                        case "Workflow": { Console.WriteLine("    variable swap [" + varName + "] to  [" + ConfigFile.Workflow + "]"); strReturnString += ConfigFile.Workflow; break; }
                    }
                    strReturnString = strReturnString + fw.getVariable(varName);
                    Console.WriteLine("Variable [" + varName + "] converted out to value [" + fw.getVariable(varName) + "]");
                }
                if (strArray[i].ToLower().Contains("db["))
                {

                    //Get the db Name out of the []
                    string[] parts = strInput.Split('[');
                    string[] final = parts[1].Split(']');

                    string DBName = final[0];
                    string fieldName = strArray[i + 1];
                    SqlDataReader newReader = db.DBCommands[DBName].ExecuteReader();
                    System.Threading.Thread.Sleep(250);

                    int Columns = newReader.FieldCount;

                    System.Data.DataTable ST = newReader.GetSchemaTable();
                    string thisName = newReader.GetName(0);
                    string columnsString = "";
                    int columnNumber = -1;
                    int columnCounter = 0;

                    foreach (DataRow row in ST.Rows)
                    {
                        foreach (DataColumn column in ST.Columns)
                        {
                            if (column.ColumnName == "ColumnName")
                            {
                                columnsString += row[column] + "|";
                                if (row[column].ToString() == fieldName)
                                {
                                    columnNumber = columnCounter;
                                }
                                columnCounter++;
                            }
                        }
                    }

                    newReader.Read();
                    System.Threading.Thread.Sleep(250);
                    strReturnString = strReturnString + newReader[columnNumber];
                    newReader.Close();
                }
                if (strArray[i].Trim().ToLower() == "alpha")
                {
                    Random rnd = new Random();
                    int loopTo = Convert.ToInt32(strArray[i + 1]);
                    for (int lo = 1; lo < loopTo + 1; lo++)
                    {
                        int thisFlag = rnd.Next(0, 100);
                        if (thisFlag > 50)
                        {
                            strReturnString = strReturnString + (char)rnd.Next(97, 122);
                        }
                        else
                        {
                            strReturnString = strReturnString + (char)rnd.Next(65, 90);
                        }
                    }
                }
                if (strArray[i].Trim().ToLower() == "ccm")
                {
                    int thisMonth = DateTime.Now.Month;  // Get the present Month here                    
                    int monthModifier = Convert.ToInt32(strArray[i + 1]);
                    int answerMonth = thisMonth + monthModifier;
                    string strAnswerMonth = answerMonth.ToString();
                    if (strAnswerMonth.Length == 1)
                    {
                        strAnswerMonth = "0" + strAnswerMonth;
                    }

                    strReturnString = strReturnString + strAnswerMonth;
                }
                if (strArray[i].ToLower() == "date")
                {
                    DateTime Date = DateTime.Now;
                    strReturnString = Date.ToString();

                }
                if (strArray[i].ToLower() == "lastdayofpreviousmonth")
                {
                    DateTime Date = DateTime.Now;
                    var month = new DateTime(Date.Year, Date.Month, 1);
                    strReturnString = month.AddDays(-1).ToString("MM/dd/yyyy");
                }


                if (strArray[i].ToLower() == "firstdayofcurrentmonth")
                {
                    DateTime Date = DateTime.Now;
                    strReturnString = new DateTime(Date.Year, Date.Month, 1).ToString("MM/dd/yyyy");

                }
                if (strArray[i].ToLower() == "firstdayofnextyear")
                {
                    DateTime Date = DateTime.Now;

                    strReturnString = new DateTime(Date.Year, Date.Month, 1).AddYears(2).ToString("MM/dd/yyyy");

                }


                if (strArray[i].ToLower() == "firstdayofpreviousmonth")
                {
                    DateTime Date = DateTime.Now;

                    var month = new DateTime(Date.Year, Date.Month, 1);
                    strReturnString = month.AddMonths(-1).ToString("MM/dd/yyyy");
                }

                if (strArray[i].ToLower() == "lastdayofprevioustopreviousmonth")
                {
                    DateTime Date = DateTime.Now;

                    var month = new DateTime(Date.Year, Date.Month, 1);
                    strReturnString = month.AddDays(-54).ToString("MM/dd/yyyy");
                }

                if (strArray[i].ToLower() == "lastdayofprevioustopreviousmonthreceipt")
                {
                    DateTime Date = DateTime.Now;

                    var month = new DateTime(Date.Year, Date.Month, 1);
                    strReturnString = month.AddDays(-55).ToString("MM/dd/yyyy");
                }

                if (strArray[i].ToLower() == "firstdayoflastmonth")
                {
                    DateTime Date = DateTime.Now;
                    var month = new DateTime(Date.Year, Date.Month, 1);
                    //  strReturnString = month.AddMonths(1);
                    strReturnString = new DateTime(Date.Year, Date.Month, 1).ToString("MM/dd/yyyy");

                }
                if (strArray[i].ToLower() == "lastdayofcurrentmonth")
                {
                    DateTime now = DateTime.Now;
                    var startDate = new DateTime(now.Year, now.Month, 1);
                    strReturnString = startDate.AddMonths(1).AddDays(-1).ToString("MM/dd/yyyy");

                }

                if (strArray[i].ToLower() == "firstdayofnextmonth")
                {
                    DateTime now = DateTime.Now;
                    var startDate = new DateTime(now.Year, now.Month, 1);
                    strReturnString = startDate.AddMonths(1).ToString("MM/dd/yyyy");

                }
                //Generate Today date
                if (strArray[i].ToLower() == "todaydate")
                {
                    // Date should be in MM/DD/YYYY
                    DateTime Date = DateTime.Now;
                    //DateTime strReturnStringDate = Date.ToString();
                    string strReturnStringNextMonthDate = Convert.ToString(Date);
                    string[] dateString = strReturnStringNextMonthDate.Split(' ');
                    string[] dateReturnString = dateString[0].Split('/');
                    if (Convert.ToUInt32(dateReturnString[0]) < 10)
                    {
                        dateReturnString[0] = "0" + dateReturnString[0];
                    }
                    if (Convert.ToUInt32(dateReturnString[1]) < 10)
                    {
                        dateReturnString[1] = "0" + dateReturnString[1];
                    }

                    strReturnString = dateReturnString[0] + "/" + dateReturnString[1] + "/" + dateReturnString[2];
                }
                //// Generate the effective date
                if (strArray[i].ToLower() == "activeeffectivedate")
                {
                    // Date should be in MM/DD/YYYY
                    DateTime Date = DateTime.Now;
                    DateTime strReturnStringDate = new DateTime(Date.AddMonths(1).Year, Date.AddMonths(1).Month, 1);
                    string strReturnStringNextMonthDate = Convert.ToString(strReturnStringDate);
                    string[] dateString = strReturnStringNextMonthDate.Split(' ');
                    string[] dateReturnString = dateString[0].Split('/');
                    if (Convert.ToUInt32(dateReturnString[0]) < 10)
                    {
                        dateReturnString[0] = "0" + dateReturnString[0];
                    }
                    if (Convert.ToUInt32(dateReturnString[1]) < 10)
                    {
                        dateReturnString[1] = "0" + dateReturnString[1];
                    }

                    strReturnString = dateReturnString[0] + "/" + dateReturnString[1] + "/" + dateReturnString[2];
                }

                if (strArray[i].ToLower() == "currentapplication")
                {
                    // return the only Tenat name of current application which is working
                    string[] url = ConfigFile.URL.Split('.');
                    string currentTenant = url[0].Substring(8);
                    strReturnString = strReturnString + currentTenant;
                }

                if (strArray[i].Trim().ToLower() == "ccd")
                {
                    int thisDay = DateTime.Now.Day;  // Get the present Month here                    
                    int dayModifier = Convert.ToInt32(strArray[i + 1]);
                    int answerDay = thisDay + dayModifier;
                    string strAnswerDay = answerDay.ToString();
                    if (strAnswerDay.Length == 1)
                    {
                        strAnswerDay = "0" + strAnswerDay;
                    }

                    strReturnString = strReturnString + strAnswerDay;
                }


                if (strArray[i].ToLower() == "ccy")
                {
                    int thisYear = DateTime.Now.Year;  // Get the present Month here                    
                    int YearModifier = Convert.ToInt32(strArray[i + 1]);
                    int answerYear = thisYear + YearModifier;
                    string strAnswerYear = answerYear.ToString();

                    strReturnString = strReturnString + strAnswerYear;

                }



                if (strArray[i].ToLower() == "today")
                {
                    int DateModifier = Convert.ToInt32(strArray[i + 1]);
                    strReturnString = DateTime.Today.AddDays(DateModifier).ToString();
                    string builtDate = "";
                    string[] strReturnStringArr = strReturnString.Split(' ');
                    string[] dateParts = strReturnStringArr[0].Split('/');
                    if (dateParts[0].Length < 2)
                    {
                        builtDate += "0";
                    }
                    builtDate += dateParts[0] + "/";
                    if (dateParts[1].Length < 2)
                    {
                        builtDate += "0";
                    }
                    builtDate += dateParts[1] + "/" + dateParts[2];
                    strReturnString = builtDate;
                }
                try
                {
                    if (strArray[i].Length > 1)
                    {
                        if (strArray[i].Substring(0, 1) == "'" && strArray[i].Substring(strArray[i].Length - 1, 1) == "'")
                        {
                            strReturnString += strArray[i].Substring(1, strArray[i].Length - 2);
                        }
                    }
                }
                catch { }
            }

            return strReturnString;
        }

        //NL 04/02/2015     
        /// <summary>
        /// Parse the value from the data table with square brackets; 
        /// e.g. if the value is "variable[HIC]" - 'HIC' text from square brackets will be returned, 
        /// if there are no brackets in the string, initial string will be returned
        /// </summary>
        /// <param name="data">string, passed by value, that contains value from tha data table
        /// </param>
        public static string GenerateDataForTable(string strInput)
        {
            string bracketStart = "["; string bracketEnd = "]";
            string dataValue = strInput;
            if (dataValue.ToLower() != "[skip]")
            {
                try
                {
                    dataValue = strInput.Substring((strInput.IndexOf(bracketStart) + bracketStart.Length), (strInput.IndexOf(bracketEnd) - strInput.IndexOf(bracketStart) - bracketStart.Length));
                    dataValue = tmsCommon.GenerateData("generate|variable|" + dataValue);
                }
                catch (ArgumentOutOfRangeException) { }
            }

            return dataValue;
        }
    }

    [Binding]
    public class EAMLogin
    {
        // Below code is commented temporarily for Jenkins Demo
        // public IWebElement UserID { get { return Browser.Wd.FindElement(By.Id("lcLogin_txtLogin")); } }
        public IWebElement UserID { get { return Browser.Wd.FindElement(By.Id("username")); } }
        //public IWebElement Password { get { return Browser.Wd.FindElement(By.Id("lcLogin_txtPwd")); } }
        public IWebElement Password { get { return Browser.Wd.FindElement(By.Id("password")); } }
        //public IWebElement Submit { get { return Browser.Wd.FindElement(By.Id("lcLogin_cmdSubmit")); } }
        public IWebElement Submit { get { return Browser.Wd.FindElement(By.CssSelector("button[test-id='login-btn-login']")); } }
        //  public IWebElement ProductSwitch { get { return Browser.Wd.FindElement(By.Id("appSwitch")); } }
        public IWebElement ProductSwitch { get { return Browser.Wd.FindElement(By.CssSelector("img[src='assets/img/icons/product_switch.png']")); } }
        //public IWebElement EAMApplication { get { return Browser.Wd.FindElement(By.CssSelector("span[test-id='menu-ddl-applicationNavigationEAMText']")); } }
        public IWebElement EAMApplication { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='menu-ddl-applicationNavigationEAMIcon1']")); } }

        public IWebElement RSMApplication { get { return Browser.Wd.FindElement(By.CssSelector("menu-ddl-applicationNavigationRSMIcon1")); } }
        public IWebElement RAMApplication { get { return Browser.Wd.FindElement(By.CssSelector(" menu-ddl-applicationNavigationRAMPIcon1")); } }

        public IWebElement AppsInProductSwitch { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='//*[@test-id= 'menu-ddl-applicationNavigation']")); } }
        public IWebElement IdentityServer { get { return Browser.Wd.FindElement(By.CssSelector("[title='Identity Server']")); } }
        public IWebElement AngularIdentityServer { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='subMenuEx-724bbcb5-e01a-4027-845d-f23b4f03a550']//span[contains(.,'Identity Server')]")); } }

    }

    [Binding]
    public class EAMLogout
    {
        public IWebElement headerButton { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='header-txt-profileInfo']")); } }
        public IWebElement Logout { get { return Browser.Wd.FindElement(By.PartialLinkText("Logout")); } }
    }
    public class EAMErrorPage
    {
        public IWebElement ErrorPage { get { return Browser.Wd.FindElement(By.TagName("td")); } }
    }


    [Binding]
    public class ConfigFile
    {
        public static string RAMExecutable = "";
        public static string RAMExecutablePath = "";
        public static string RAMUser = "";
        public static string RAMPassword = "";
        public static string BrowserType = "";
        public static string ParallelRun = "";
        public static string tenantType = "";
        public static string URL = "";
        public static string IDMURL = "";
        public static string UserId = "";
        public static string Password = "";
        public static string ADFSUserId = "";
        public static string ADFSPassword = "";
        public static string FirstName = "";
        public static string LastName = "";
        public static string EAMdb = "";
        public static string EnvType = "";
        public static string FRMdb = "";
        public static string RSMdb = "";
        public static string PDEMdb = "";
        public static string DLMdb = "";
        public static string RAMdb = "";
        public static string RAMXdb = "";
        public static string FRMedb = "";
        public static string Warehousedb = "";
        public static string PDMMetaDatadb = "";
        public static string EAMedb = "";
        public static string CDMdb = "";
        public static string PathforDataFile = "";
        public static string AllowLocalDt = "";
        public static string Client = "";
        public static string Database = "";
        public static string DataServer = "";
        public static string ERFdb = "";
        public static string Port = "";
        public static string DBDriver = "";
        public static string DBUser = "";
        public static string DBPassword = "";
        public static string TCSServer = "";
        public static string TCSDatabase = "";
        public static string TCSDBUser = "";
        public static string TCSDBPassword = "";
        public static string ALMURL = "";
        public static string ALMDomain = "";
        public static string ALMProject = "";
        public static string ALMUser = "";
        public static string ALMPassword = "";
        public static string PDMDBPassword = "";
        public static string PDMDB = "";
        public static string Tenant = "";
        public static string Workflow = "";
        public static string IDMUser = "";
        public static string IDMPassword = "";
        public static string IdentitySdb = "";
        public static string WorkflowApplicationURL = "";
        public static string WorkflowAServiceEndpointURL = "";

        public static void ReadFromConfigFile()
        {


            ///var myDocumentsPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            // var myDocumentPath = myDocumentsPath + "\\SpecFlowSettings.xml";


            //if (!bFileExists)
            //{
            //    string thisTag = "";
            //    string thisValue = "";
            //    SqlConnection DBConn = new SqlConnection();

            //    //string thisConnectionString = "user id=tmsadmin;" +
            //    //           "password=TriZetto458;" +
            //    //           "Data Source=ABN-PDM-SQL-D32.dev.trizetto.com,1433;" +
            //    //           "Network Library=DBMSSOCN;" +
            //    //           "Initial Catalog=zAutomationFramework; " +
            //    //           "connection timeout=30";

            //string thisConnectionString = "server=ABN-PDM-SQL-D32.dev.trizetto.com;" + ConfigFile.DataServer + ";" + "database=zAutomationFramework;" + "user id=" + ConfigFile.DBUser + ";" + "password=" + ConfigFile.DBPassword + ";" + "Max Pool Size=9000;" + "Connection Timeout=150;" + "Min Pool Size=2";
            //DBConn.ConnectionString = thisConnectionString;
            //    DBConn.Open();
            //    SqlCommand thisCommand = new SqlCommand("select * from dbo.SpecFlowSettings where Machine like '" + System.Environment.MachineName + "'", DBConn);
            //    SqlDataReader newReader = thisCommand.ExecuteReader();
            //    int Columns = newReader.FieldCount;

            //    System.Data.DataTable ST = newReader.GetSchemaTable();
            //    string thisName = newReader.GetName(0);
            //    newReader.Read();
            //    System.Threading.Thread.Sleep(550);
            //    for (int i = 0; i < Columns; i++)
            //    {
            //        thisTag = newReader.GetName(i);
            //        thisValue = newReader[i].ToString();
            //        switch (thisTag)
            //        {
            //            case "RAMExecutable": { RAMExecutable = thisValue; break; }
            //            case "RAMExecutablePath": { RAMExecutablePath = thisValue; break; }
            //            case "RAMUser": { RAMUser = thisValue; break; }
            //            case "RAMPassword": { RAMPassword = thisValue; break; }
            //            case "ParallelRun": { ParallelRun = thisValue; Console.WriteLine("    ParallelRun Set to [" + ParallelRun + "]"); break; }
            //            case "BrowserType": { BrowserType = thisValue; Console.WriteLine("    BrowserType Set to [" + BrowserType + "]"); break; }
            //            case "tenantType": { tenantType = thisValue; Console.WriteLine("    tenantType Set to [" + tenantType + "]"); break; }
            //            case "URL": { URL = thisValue; Console.WriteLine("    URL Set to [" + URL + "]"); break; }
            //            case "IDMURL": { IDMURL = thisValue; Console.WriteLine("    IDMURL Set to [" + IDMURL + "]"); break; }
            //            case "UserId": { UserId = thisValue; Console.WriteLine("    UserId Set to [" + UserId + "]"); break; }
            //            case "fwPassword": { Password = thisValue; Console.WriteLine("    Password Set to [" + Password + "]"); break; }
            //            case "ADFSUserId": { ADFSUserId = thisValue; Console.WriteLine("  ADFS  UserId Set to [" + ADFSUserId + "]"); break; }
            //            case "ADFSfwPassword": { ADFSPassword = thisValue; Console.WriteLine(" ADFS   Password Set to [" + ADFSPassword + "]"); break; }
            //            case "FirstName": { FirstName = thisValue; Console.WriteLine("    FirstName Set to [" + FirstName + "]"); break; }
            //            case "LastName": { LastName = thisValue; Console.WriteLine("    LastName Set to [" + LastName + "]"); break; }
            //            case "EAMdb": { EAMdb = thisValue; Console.WriteLine("    EAMdb Set to [" + EAMdb + "]"); break; }
            //            case "EnvType": { EnvType = thisValue; Console.WriteLine("    EnvType Set to [" + EnvType + "]"); break; }
            //            case "FRMdb": { FRMdb = thisValue; Console.WriteLine("    FRMdb Set to [" + FRMdb + "]"); break; }
            //            case "RSMdb": { RSMdb = thisValue; Console.WriteLine("    RSMdb Set to [" + RSMdb + "]"); break; }
            //            case "PDEMdb": { PDEMdb = thisValue; Console.WriteLine("    PDEMdb Set to [" + PDEMdb + "]"); break; }
            //            case "DLMdb": { DLMdb = thisValue; Console.WriteLine("    DLMdb Set to [" + DLMdb + "]"); break; }
            //            case "RAMdb": { RAMdb = thisValue; Console.WriteLine("    RAMdb Set to [" + RAMdb + "]"); break; }
            //            case "RAMXdb": { RAMXdb = thisValue; Console.WriteLine("   RAMXdb Set to [" + RAMXdb + "]"); break; }
            //            case "FRMedb": { FRMedb = thisValue; Console.WriteLine("   FRMedb Set to [" + FRMedb + "]"); break; }
            //            case "IdentitySdb": { IdentitySdb = thisValue; Console.WriteLine("   IdentitySdb Set to [" + IdentitySdb + "]"); break; }
            //            case "Warehousedb": { Warehousedb = thisValue; Console.WriteLine("   Warehousedb Set to [" + Warehousedb + "]"); break; }
            //            case "PDMMetaDatadb": { PDMMetaDatadb = thisValue; Console.WriteLine("   PDMMetaDatadb Set to [" + PDMMetaDatadb + "]"); break; }
            //            case "EAMedb": { EAMedb = thisValue; Console.WriteLine("   EAMedb Set to [" + EAMedb + "]"); break; }
            //            case "PathforDataFile": { PathforDataFile = thisValue; break; }
            //            case "AllowLocalDt": { AllowLocalDt = thisValue; break; }
            //            case "Client": { Client = thisValue; break; }
            //            case "fwDatabase": { Database = thisValue; Console.WriteLine("    Database Set to [" + Database + "]"); break; }
            //            case "DataServer": { DataServer = thisValue; Console.WriteLine("    DataServer Set to [" + DataServer + "]"); break; }
            //            case "ERFdb": { ERFdb = thisValue; Console.WriteLine("    ERFdb Set to [" + ERFdb + "]"); break; }
            //            case "Port": { Port = thisValue; break; }
            //            case "DBDriver": { DBDriver = thisValue; Console.WriteLine("    DBDriver Set to [" + DBDriver + "]"); break; }
            //            case "DBUser": { DBUser = thisValue; Console.WriteLine("    DBUser Set to [" + DBUser + "]"); break; }
            //            case "DBPassword": { DBPassword = thisValue; Console.WriteLine("    DBPassword Set to [" + DBPassword + "]"); break; }
            //            case "TCSServer": { TCSServer = thisValue; break; }
            //            case "TCSDatabase": { TCSDatabase = thisValue; break; }
            //            case "TCSDBUser": { TCSDBUser = thisValue; break; }
            //            case "TCSDBPassword": { TCSDBPassword = thisValue; break; }
            //            case "ALMURL": { ALMURL = thisValue; Console.WriteLine("    ALMURL Set to [" + ALMURL + "]"); break; }
            //            case "ALMDomain": { ALMDomain = thisValue; Console.WriteLine("    ALMDomain Set to [" + ALMDomain + "]"); break; }
            //            case "ALMProject": { ALMProject = thisValue; Console.WriteLine("    ALMProject Set to [" + ALMProject + "]"); break; }
            //            case "ALMUser": { ALMUser = thisValue; Console.WriteLine("    ALMUser Set to [" + ALMUser + "]"); break; }
            //            case "ALMPassword": { ALMPassword = thisValue; Console.WriteLine("    ALMPassword Set to [" + ALMPassword + "]"); break; }
            //            case "PDMDB": { PDMDB = thisValue; Console.WriteLine("    PDMDB Set to [" + PDMDB + "]"); break; }
            //            case "PDMDBPassword": { PDMDBPassword = thisValue; Console.WriteLine("    PDMDBPassword Set to [" + PDMDBPassword + "]"); break; }
            //            case "Tenant": { Tenant = thisValue; Console.WriteLine("    Tenant Set to [" + Tenant + "]"); break; }
            //            case "Workflow": { Workflow = thisValue; Console.WriteLine("    Workflow Set to [" + Workflow + "]"); break; }
            //            case "CDMdb": { CDMdb = thisValue; Console.WriteLine("    CDM Set to [" + CDMdb + "]"); break; }
            //            case "IDMUser": { IDMUser = thisValue; Console.WriteLine("    IDM User Set to [" + IDMUser + "]"); break; }
            //            case "IDMPassword": { IDMPassword = thisValue; Console.WriteLine("    IDM Password Set to [" + IDMPassword + "]"); break; }
            //            case "WorkflowApplicationURL": { WorkflowApplicationURL = thisValue; Console.WriteLine("    WorkflowApplicationURL Set to [" + WorkflowApplicationURL + "]"); break; }
            //            case "WorkflowAServiceEndpointURL": { WorkflowAServiceEndpointURL = thisValue; Console.WriteLine("    WorkflowAServiceEndpointURL Set to [" + WorkflowAServiceEndpointURL + "]"); break; }

            //        }

            //    }
            //}
            //var projectFolder = (System.IO.Directory.GetCurrentDirectory().Split("bin"))[0];
            //var myDocumentPath = projectFolder + "Features\\ConfigFile\\SpecFlowSettings.xml";
            //fw.ConsoleReport("SpecFlow Config File Path " + myDocumentPath);

            //Boolean bFileExists = File.Exists(myDocumentPath);
            //fw.ConsoleReport(" SpecFlow Config File Presence ?" + bFileExists);
            //Console.WriteLine("######## Machine Info");
            //string startupPath = System.IO.Directory.GetCurrentDirectory();
            //    Console.WriteLine("Framework 1.0.0.1");
            //    Console.WriteLine("    Computer Name [" + System.Environment.MachineName + "]");
            //    Console.WriteLine("    User Name [" + System.Environment.UserName + "]");
            //    Console.WriteLine("    User Domain Name [" + System.Environment.UserDomainName + "]");
            //    Console.WriteLine("    OS Version [" + System.Environment.OSVersion + "]");
            //    Console.WriteLine("    Current Machine Time [" + DateTime.Now + "]");
            //    Console.WriteLine("    Machine Uptime [" + TimeSpan.FromMilliseconds(System.Environment.TickCount).ToString() + "]");
            //    Console.WriteLine("######## Config File Variables");
            //    if (bFileExists)
            //    {
            //        XmlTextReader reader = new XmlTextReader(myDocumentPath);
            //        string thisTag1 = "";
            //        string thisValue1 = "";
            //        Boolean isSet1 = false;

            //        while (reader.Read())
            //        {
            //            // Do some work here on the data.
            //            switch (reader.NodeType)
            //            {
            //                case XmlNodeType.Element:
            //                    {
            //                        thisTag1 = "";
            //                        thisValue1 = "";
            //                        thisTag1 = reader.Name;
            //                        break;
            //                    }
            //                case XmlNodeType.Text:
            //                    {
            //                        thisValue1 = reader.Value;
            //                        isSet1 = true;
            //                        break;
            //                    }
            //            }
            //            if (isSet1 == true)
            //            {
            //                switch (thisTag1)
            //                {
            //                    case "RAMExecutable": { RAMExecutable = thisValue1; break; }
            //                    case "RAMExecutablePath": { RAMExecutablePath = thisValue1; break; }
            //                    case "RAMUser": { RAMUser = thisValue1; break; }
            //                    case "RAMPassword": { RAMPassword = thisValue1; break; }
            //                    case "ParallelRun": { ParallelRun = thisValue1; Console.WriteLine("    ParallelRun Set to [" + ParallelRun + "]"); break; }
            //                    case "BrowserType": { BrowserType = thisValue1; Console.WriteLine("    BrowserType Set to [" + BrowserType + "]"); break; }
            //                    case "tenantType": { tenantType = thisValue1; Console.WriteLine("    tenantType Set to [" + tenantType + "]"); break; }
            //                    case "URL": { URL = thisValue1; Console.WriteLine("    URL Set to [" + URL + "]"); break; }
            //                    case "IDMURL": { IDMURL = thisValue1; Console.WriteLine("    IDMURL Set to [" + IDMURL + "]"); break; }
            //                    case "UserId": { UserId = thisValue1; Console.WriteLine("    UserId Set to [" + UserId + "]"); break; }
            //                    case "Password": { Password = thisValue1; Console.WriteLine("    Password Set to [" + Password + "]"); break; }
            //                    case "ADFSUserId": { ADFSUserId = thisValue1; Console.WriteLine("   ADFS UserId Set to [" + ADFSUserId + "]"); break; }
            //                    case "ADFSPassword": { ADFSPassword = thisValue1; Console.WriteLine(" ADFS  Password Set to [" + ADFSPassword + "]"); break; }
            //                    case "FirstName": { FirstName = thisValue1; Console.WriteLine("    FirstName Set to [" + FirstName + "]"); break; }
            //                    case "LastName": { LastName = thisValue1; Console.WriteLine("    LastName Set to [" + LastName + "]"); break; }
            //                    case "EAMdb": { EAMdb = thisValue1; Console.WriteLine("    EAMdb Set to [" + EAMdb + "]"); break; }
            //                    case "EnvType": { EnvType = thisValue1; Console.WriteLine("    EnvType Set to [" + EnvType + "]"); break; }
            //                    case "FRMdb": { FRMdb = thisValue1; Console.WriteLine("    FRMdb Set to [" + FRMdb + "]"); break; }
            //                    case "RSMdb": { RSMdb = thisValue1; Console.WriteLine("    RSMdb Set to [" + RSMdb + "]"); break; }
            //                    case "PDEMdb": { PDEMdb = thisValue1; Console.WriteLine("    PDEMdb Set to [" + PDEMdb + "]"); break; }
            //                    case "DLMdb": { DLMdb = thisValue1; Console.WriteLine("    DLMdb Set to [" + DLMdb + "]"); break; }
            //                    case "RAMdb": { RAMdb = thisValue1; Console.WriteLine("    RAMdb Set to [" + RAMdb + "]"); break; }
            //                    case "RAMXdb": { RAMXdb = thisValue1; Console.WriteLine("  RAMXdb Set to [" + RAMXdb + "]"); break; }
            //                    case "FRMedb": { FRMedb = thisValue1; Console.WriteLine("  FRMedb Set to [" + FRMedb + "]"); break; }
            //                    case "IdentitySdb": { IdentitySdb = thisValue1; Console.WriteLine("  IdentitySdb Set to [" + IdentitySdb + "]"); break; }
            //                    case "Warehousedb": { Warehousedb = thisValue1; Console.WriteLine("  Warehousedb Set to [" + Warehousedb + "]"); break; }
            //                    case "PDMMetaDatadb": { PDMMetaDatadb = thisValue1; Console.WriteLine("  PDMMetaDatadb Set to [" + PDMMetaDatadb + "]"); break; }
            //                    case "EAMedb": { EAMedb = thisValue1; Console.WriteLine("  EAMedb Set to [" + EAMedb + "]"); break; }
            //                    case "CDMdb": { CDMdb = thisValue1; Console.WriteLine("    CDMdb Set to [" + CDMdb + "]"); break; }
            //                    case "PathforDataFile": { PathforDataFile = thisValue1; break; }
            //                    case "AllowLocalDt": { AllowLocalDt = thisValue1; break; }
            //                    case "Client": { Client = thisValue1; break; }
            //                    case "Database": { Database = thisValue1; Console.WriteLine("    Database Set to [" + Database + "]"); break; }
            //                    case "ERFdb": { ERFdb = thisValue1; Console.WriteLine("    ERFdb Set to [" + ERFdb + "]"); break; }
            //                    case "DataServer": { DataServer = thisValue1; Console.WriteLine("    DataServer Set to [" + DataServer + "]"); break; }
            //                    case "Port": { Port = thisValue1; break; }
            //                    case "DBDriver": { DBDriver = thisValue1; Console.WriteLine("    DBDriver Set to [" + DBDriver + "]"); break; }
            //                    case "DBUser": { DBUser = thisValue1; Console.WriteLine("    DBUser Set to [" + DBUser + "]"); break; }
            //                    case "DBPassword": { DBPassword = thisValue1; Console.WriteLine("    DBPassword Set to [" + DBPassword + "]"); break; }
            //                    case "TCSServer": { TCSServer = thisValue1; break; }
            //                    case "TCSDatabase": { TCSDatabase = thisValue1; break; }
            //                    case "TCSDBUser": { TCSDBUser = thisValue1; break; }
            //                    case "TCSDBPassword": { TCSDBPassword = thisValue1; break; }
            //                    case "ALMURL": { ALMURL = thisValue1; Console.WriteLine("    ALMURL Set to [" + ALMURL + "]"); break; }
            //                    case "ALMDomain": { ALMDomain = thisValue1; Console.WriteLine("    ALMDomain Set to [" + ALMDomain + "]"); break; }
            //                    case "ALMProject": { ALMProject = thisValue1; Console.WriteLine("    ALMProject Set to [" + ALMProject + "]"); break; }
            //                    case "ALMUser": { ALMUser = thisValue1; Console.WriteLine("    ALMUser Set to [" + ALMUser + "]"); break; }
            //                    case "ALMPassword": { ALMPassword = thisValue1; Console.WriteLine("    ALMPassword Set to [" + ALMPassword + "]"); break; }
            //                    case "PDMDB": { PDMDB = thisValue1; Console.WriteLine("    PDMDB Set to [" + PDMDB + "]"); break; }
            //                    case "PDMDBPassword": { PDMDBPassword = thisValue1; Console.WriteLine("    PDMDBPassword Set to [" + PDMDBPassword + "]"); break; }
            //                    case "Tenant": { Tenant = thisValue1; Console.WriteLine("    Tenant Set to [" + Tenant + "]"); break; }
            //                    case "Workflow": { Workflow = thisValue1; Console.WriteLine("    Workflow Set to [" + Workflow + "]"); break; }
            //                    case "IDMUser": { IDMUser = thisValue1; Console.WriteLine("    IDM User Set to [" + IDMUser + "]"); break; }
            //                    case "IDMPassword": { IDMPassword = thisValue1; Console.WriteLine("    IDM Password Set to [" + IDMPassword + "]"); break; }
            //                    case "WorkflowApplicationURL": { WorkflowApplicationURL = thisValue1; Console.WriteLine("    WorkflowApplicationURL Set to [" + WorkflowApplicationURL + "]"); break; }
            //                    case "WorkflowAServiceEndpointURL": { WorkflowAServiceEndpointURL = thisValue1; Console.WriteLine("    WorkflowAServiceEndpointURL Set to [" + WorkflowAServiceEndpointURL + "]"); break; }

            //                }
            //                isSet1 = false;
            //            }
            //        }
            //    }
                
            //if (ConfigFile.BrowserType.ToLower().Equals("chromegrid"))
            //{
            //    Console.WriteLine("*********** Running Test suite using " + ConfigFile.BrowserType);
            //    Console.WriteLine("***********Running Test suite using SpecFlowSettings.xml file***********");
            //}

            //else
            //{
                Console.WriteLine("*********** Running Test suite using SpecFlow.runsettings file ***********");

                var testContext = ScenarioContext.Current.ScenarioContainer.Resolve<Microsoft.VisualStudio.TestTools.UnitTesting.TestContext>();
                URL = testContext.Properties["URL"].ToString();
                //ParallelRun = testContext.Properties["ParallelRun"].ToString();
                BrowserType = testContext.Properties["BrowserType"].ToString();
                tenantType = testContext.Properties["tenantType"].ToString();
                UserId = testContext.Properties["UserId"].ToString();
                Password = testContext.Properties["Password"].ToString();
                EAMdb = testContext.Properties["EAMdb"].ToString();
                FirstName = testContext.Properties["FirstName"].ToString();
                LastName = testContext.Properties["LastName"].ToString();
                DLMdb = testContext.Properties["DLMdb"].ToString();
                CDMdb = testContext.Properties["CDMdb"].ToString();
                PDEMdb = testContext.Properties["PDEMdb"].ToString();
                RAMXdb = testContext.Properties["RAMXdb"].ToString();
                RSMdb = testContext.Properties["RSMdb"].ToString();
                FRMdb = testContext.Properties["FRMdb"].ToString();
                RAMdb = testContext.Properties["RAMdb"].ToString();
                IdentitySdb = testContext.Properties["IdentitySdb"].ToString();
                EnvType = testContext.Properties["EnvType"].ToString();
                RAMdb = testContext.Properties["RAMdb"].ToString();
                Warehousedb = testContext.Properties["Warehousedb"].ToString();
                PDMMetaDatadb = testContext.Properties["PDMMetaDatadb"].ToString();
                PDMDB = testContext.Properties["PDMDB"].ToString();
                PDMDBPassword = testContext.Properties["PDMDBPassword"].ToString();
                DataServer = testContext.Properties["DataServer"].ToString();
                Database = testContext.Properties["Database"].ToString();
                DBUser = testContext.Properties["DBUser"].ToString();
                DBPassword = testContext.Properties["DBPassword"].ToString();
                ALMUser = testContext.Properties["ALMUser"].ToString();
                ALMPassword = testContext.Properties["ALMPassword"].ToString();
                IDMURL = testContext.Properties["IDMURL"].ToString();
                ADFSUserId = testContext.Properties["ADFSUserId"].ToString();
                Workflow = testContext.Properties["Workflow"].ToString();
                WorkflowApplicationURL = testContext.Properties["WorkflowApplicationURL"].ToString();
                WorkflowAServiceEndpointURL = testContext.Properties["WorkflowAServiceEndpointURL"].ToString();

                Console.WriteLine("######## Running Machine Information ######## ");
                Console.WriteLine("Framework 1.0.0.1");
                Console.WriteLine("    Computer Name [" + System.Environment.MachineName + "]");
                Console.WriteLine("    User Name [" + System.Environment.UserName + "]");
                Console.WriteLine("    User Domain Name [" + System.Environment.UserDomainName + "]");
                Console.WriteLine("    OS Version [" + System.Environment.OSVersion + "]");
                Console.WriteLine("    Current Machine Time [" + DateTime.Now + "]");
                Console.WriteLine("    Machine Uptime [" + TimeSpan.FromMilliseconds(System.Environment.TickCount).ToString() + "]");


                fw.ConsoleReport(" ######## SpecFlow Configuration Variable Details ########  ");

                fw.ConsoleReport(" BrowserType --> " + BrowserType);
                fw.ConsoleReport(" ParallelRun --> " + ParallelRun);
                fw.ConsoleReport(" Tenant Type  -->" + tenantType);
                fw.ConsoleReport(" User ID  -->" + UserId);
                fw.ConsoleReport(" Password  -->" + Password);
                fw.ConsoleReport(" URL -->" + URL);
                fw.ConsoleReport(" FirstName -->" + FirstName);
                fw.ConsoleReport(" LastName -->" + LastName);
                fw.ConsoleReport(" EAM Database Name -->" + EAMdb);
                fw.ConsoleReport(" DLM Database Name -->" + DLMdb);
                fw.ConsoleReport(" CDM Database Name -->" + CDMdb);
                fw.ConsoleReport(" PDEM Database Name -->" + PDEMdb);
                fw.ConsoleReport(" RAMX Database Name -->" + RAMXdb);
                fw.ConsoleReport(" RSM Database Name -->" + RSMdb);
                fw.ConsoleReport(" FRM Database Name -->" + FRMdb);
                fw.ConsoleReport(" RAM Database Name -->" + RAMdb);
                fw.ConsoleReport(" Identity Server Database Name -->" + IdentitySdb);
                fw.ConsoleReport(" Env type -->" + EnvType);
                fw.ConsoleReport(" Warehouse Database Name -->" + Warehousedb);
                fw.ConsoleReport(" PDEM Meta Data Database Name -->" + PDMMetaDatadb);
                fw.ConsoleReport(" Reports Authentication User Name-->" + PDMDB);
                fw.ConsoleReport(" Reports Authentication Password -->" + PDMDBPassword);
                fw.ConsoleReport("SQL Server -->" + DataServer);
                fw.ConsoleReport(" Database User Name -->" + DBUser);
                fw.ConsoleReport(" Database Password -->" + DBPassword);
                fw.ConsoleReport(" IDM URL -->" + IDMURL);
                fw.ConsoleReport(" Work Flow Application URL -->" + WorkflowApplicationURL);
                fw.ConsoleReport(" Work Flow Service Endpoint URL -->" + WorkflowAServiceEndpointURL);

            //}
        }
    }
}
