﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using OpenQA.Selenium.Support.UI;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TMSoR1.FrameworkCode.CDM
{
    [Binding]
    class fscdmAdministration
    {

        private readonly ScenarioContext Context;

        public fscdmAdministration(ScenarioContext catalogContext)
        {
            Context = catalogContext;
        }


        [When(@"Search Encounter page Error Codes is set to ""(.*)""")]
        public void WhenSearchEncounterPageErrorCodesIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            tmsWait.Hard(2);
            // click on Report Link
            IWebElement lookup = Browser.Wd.FindElement(By.XPath("//a[@test-id='manageSuspects-a-providerLookup']"));
            fw.ExecuteJavascript(lookup);
            tmsWait.Hard(2);
            // Enter TRC
            IWebElement trrCode = Browser.Wd.FindElement(By.CssSelector("[test-id='errorCodes-txt-ErrorCode']"));
            trrCode.SendKeys(GeneratedData);
            tmsWait.Hard(2);
            // Click on Search
            IWebElement trrSearchButton = Browser.Wd.FindElement(By.CssSelector("[test-id='errorCodes-btn-search']"));
            fw.ExecuteJavascript(trrSearchButton);
            tmsWait.Hard(2);
            // Click on Checkbox
            IWebElement trrRowClick = Browser.Wd.FindElement(By.XPath("//input[@id='" + GeneratedData + "']"));
            fw.ExecuteJavascript(trrRowClick);
            tmsWait.Hard(2);
            // Add button
            IWebElement trrAddButton = Browser.Wd.FindElement(By.CssSelector("[test-id='errorCodes-btn-add']"));
            fw.ExecuteJavascript(trrAddButton);
            tmsWait.Hard(8);

        }
        [When(@"Search Encounter page Error Codes is selected as ""(.*)""")]
        public void WhenSearchEncounterPageErrorCodesIsSelectedAs(string status)
        {
            IWebElement WebElemDrp = Browser.Wd.FindElement(By.CssSelector("[aria-owns='formInputBoxStatus_listbox']"));
            fw.ExecuteJavascript(WebElemDrp);
            tmsWait.Hard(2);
            IWebElement WebElemDrpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='formInputBoxStatus_listbox']/li[contains(.,'" + status + "')]"));
            fw.ExecuteJavascript(WebElemDrpValue);
        }


        [When(@"Search Encounter page Search button is Clicked")]
        public void WhenSearchEncounterPageSearchButtonIsClicked()
        {
            IWebElement WebElemDrp = Browser.Wd.FindElement(By.CssSelector("[test-id='encounter-btn-search']"));
            fw.ExecuteJavascript(WebElemDrp);
            tmsWait.Hard(2);
        }


        [When(@"Element UI MOD CDM Application ""(.*)"" Section is Clicked")]  
        [When(@"TMS CDM Application ""(.*)"" Section is Clicked")]
        public void WhenTMSCDMApplicationSectionIsClicked(string p0)
        {
            switch (p0)
            {
                case "Administration":

                    IWebElement Administration = Browser.Wd.FindElement(By.CssSelector("[title='Administration']"));
                    fw.ExecuteJavascript(Administration);
                    break;

                case "Import":

                    IWebElement Task = Browser.Wd.FindElement(By.CssSelector("[title='Tasks']"));
                    fw.ExecuteJavascript(Task);
                    IWebElement Import = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Import')]"));
                    fw.ExecuteJavascript(Import);
                    break;
                case "Export":

                    IWebElement Tasks = Browser.Wd.FindElement(By.CssSelector("[title='Tasks']"));
                    fw.ExecuteJavascript(Tasks);
                    tmsWait.Hard(2);
                    IWebElement menu1 = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Export')]"));
                    fw.ExecuteJavascript(menu1);
                    break;

                case "CDM Configurations":
                  
                    IWebElement cdmConfigurations = Browser.Wd.FindElement(By.XPath("//span[contains(.,'CDM Configurations')]"));
                    fw.ExecuteJavascript(cdmConfigurations);
                    break;

                case "Main":

                    IWebElement Main = Browser.Wd.FindElement(By.CssSelector("[title='Main']"));
                    fw.ExecuteJavascript(Main);
                    break;
            }
        }


        [When(@"CDM Exports Page Export Level is selected as ""(.*)""")]
        public void WhenCDMExportsPageExportLevelIsSelectedAs(string p0)
        {
            IWebElement ele;
            switch (p0.ToLower())
            {
                case "clusters":
                    ele = Browser.Wd.FindElement(By.XPath("//*[@for='commaDelimied']/span"));
                    fw.ExecuteJavascript(ele);
                break;
                case "claims":
                    ele = Browser.Wd.FindElement(By.XPath("//*[@for='pipeDelimied']/span"));
                    fw.ExecuteJavascript(ele);
               
                break;
            }
        }

        [When(@"CDM Exports Page RAPS ICD(.*) File Layout option is selected")]
        public void WhenCDMExportsPageRAPSICDFileLayoutOptionIsSelected(int p0)
        {
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@for='commaDelimied']/span"));
            fw.ExecuteJavascript(ele);
        }

    
        [When(@"Other Settings tab Member Load Dupe Logic section MBI option is Clicked")]
        public void WhenOtherSettingsTabMemberLoadDupeLogicSectionMBIOptionIsClicked()
        {
           //IWebElement menu = Browser.Wd.FindElement(By.CssSelector("[test-id='otherSettings-radio-mbi']"));
            IWebElement menu = Browser.Wd.FindElement(By.XPath("//*[@id='otherSettingsFrm']//label[text()='MBI']"));
            ReUsableFunctions.clickOnWebElement(menu);

        }
        public static string setCheckboxTo;

        [When(@"Other Settings tab Run Enroll Check After Load checkbox is ""(.*)""")]
        public void WhenOtherSettingsTabRunEnrollCheckAfterLoadCheckboxIs(string p0)
        {
            IWebElement checkbox = Browser.Wd.FindElement(By.CssSelector("[test-id='otherSettings-chk-runEnrollCheck']"));


            string GenerateData = tmsCommon.GenerateData(p0);


            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("unchecked"))
            {
                if (checkbox.Selected == true)
                {
                    fw.ExecuteJavascript(checkbox);

                }


            }
            else
            {
                if (checkbox.Selected == false)
                {
                    fw.ExecuteJavascript(checkbox);

                }
            }
        }

        [When(@"Other Settings tab Enable Auto RAPS checkbox is ""(.*)""")]
        public void WhenOtherSettingsTabEnableAutoRAPSCheckboxIs(string p0)
        {
            //IWebElement checkbox = Browser.Wd.FindElement(By.CssSelector("[test-id='otherSettings-chk-enableAutoRaps']"));
            IWebElement checkbox = Browser.Wd.FindElement(By.XPath("//*[@id='lblIsEnableAutoRaps']"));
              string GenerateData = tmsCommon.GenerateData(p0);


            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("unchecked"))
            {
                if (checkbox.Selected == true)
                {
                    fw.ExecuteJavascript(checkbox);
                    
                }


            }
            else
            {
                if (checkbox.Selected == false)
                {
                    fw.ExecuteJavascript(checkbox);
                  
                }
            }

        }


        [When(@"Other Settings tab Submitter ID text box is set to ""(.*)""")]
        public void WhenOtherSettingsTabSubmitterIDTextBoxIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            IWebElement comp = Browser.Wd.FindElement(By.CssSelector("[test-id='otherSettings-txt-submitterId']"));
            comp.SendKeys(value);

        }

        [When(@"Other Settings tab File ID Prefix text box is set to ""(.*)""")]
        public void WhenOtherSettingsTabFileIDPrefixTextBoxIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            IWebElement comp = Browser.Wd.FindElement(By.CssSelector("[test-id='otherSettings-txt-fileIdPrefix']"));
            comp.SendKeys(value);
        }

        [When(@"Other Settings tab Save button is Clicked")]
        public void WhenOtherSettingsTabSaveButtonIsClicked()
        {
            IWebElement menu = Browser.Wd.FindElement(By.CssSelector("[test-id='OtherSettings-btn-save']"));
            // ReUsableFunctions.clickOnWebElement(menu);
            fw.ExecuteJavascript(menu);
        }

        [When(@"Other Settings tab Save button is Clicked and verify message ""(.*)""")]
        public void WhenOtherSettingsTabSaveButtonIsClickedAndVerifyMessage(string p0)
        {
            Console.Write("Clicking on Save button");
            tmsWait.Hard(5);
            IWebElement menu = Browser.Wd.FindElement(By.CssSelector("[test-id='OtherSettings-btn-save']"));
            // ReUsableFunctions.clickOnWebElement(menu);
            fw.ExecuteJavascript(menu);
          
        }


        [Then(@"Verify System displayed Toaster message as ""(.*)""")]
        public void ThenVerifySystemDisplayedToasterMessageAs(string expected)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By toastMsg = By.XPath("//div[@class='k-notification-content']");
                string actValue = Browser.Wd.FindElement(toastMsg).Text;
                Assert.IsTrue(actValue.Contains(expected));
            }
            else
            {
                IWebElement menu = Browser.Wd.FindElement(By.XPath("//div[@class='toast-message']"));
            string actual = menu.Text;

            Assert.AreEqual(expected, actual, " Both are not matching");
            }
        }

        [When(@"Member Documents dialog Select button is Clicked")]
        public void WhenMemberDocumentsDialogSelectButtonIsClicked()
        {
            tmsWait.Hard(4);
            fw.ExecuteJavascript(cfUIMODViewEditMember.ViewEditMemberPage.ViewAttachmentsSelectBtn);
        }
        [When(@"Member Documents dialog View Attachment button is Clicked")]
        public void WhenMemberDocumentsDialogViewAttachmentButtonIsClicked()
        {
            tmsWait.Hard(4);
            fw.ExecuteJavascript(cfUIMODViewEditMember.ViewEditMemberPage.ViewAttachmentsBtn);
        }

        [Then(@"Verify CDM Dashboard page displayed ""(.*)"" label")]
        public void ThenVerifyCDMDashboardPageDisplayedLabel(string p0)
        {
            IWebElement menu = Browser.Wd.FindElement(By.XPath("//label[contains(.,'"+p0+"')]"));
            bool presence = menu.Displayed;

            Assert.IsTrue(presence, p0 + " is not getting displayed");

        }
        [Given(@"Dashboard page Help link is Clicked")]
        public void GivenDashboardPageHelpLinkIsClicked()
        {
            tmsWait.Hard(3);
            IWebElement menu = Browser.Wd.FindElement(By.XPath("//*[@test-id='header-page-content-btn-help']"));
            fw.ExecuteJavascript(menu);
        }

        [When(@"Help link is Clicked")]
        public void WhenHelpLinkIsClicked()
        {
            tmsWait.Hard(3);
            IWebElement menu = Browser.Wd.FindElement(By.XPath("//*[@test-id='header-page-content-btn-help']"));
            fw.ExecuteJavascript(menu);

        }


        [When(@"Other Settings tab Member Load Dupe Logic section PlanID and MBI option is Clicked")]
        public void WhenOtherSettingsTabMemberLoadDupeLogicSectionPlanIDAndMBIOptionIsClicked()
        {
            IWebElement menu = Browser.Wd.FindElement(By.CssSelector("[test-id='otherSettings-radio-plan']"));
            ReUsableFunctions.clickOnWebElement(menu);
        }


        [When(@"TMS CDM Configuration ""(.*)"" Section is Clicked")]
        public void WhenTMSCDMConfigurationSectionIsClicked(string p0)
        {
           
            IWebElement submenu = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]"));
            ReUsableFunctions.clickOnWebElement(submenu);
        }

        [Then(@"Verify that CDM Configuration Page Add Submitters page is opened")]
        public void ThenVerifyThatCDMConfigurationPageAddSubmittersPageIsOpened()
        {

            IWebElement submitterid = Browser.Wd.FindElement(By.XPath("//input[@test-id='addSubmitters-txt-submitterId']"));
            tmsWait.Hard(5);
            Assert.IsTrue(submitterid.Displayed, "Submitter Id Does not exist");
           
        }

        [When(@"TMS CDM Configuration Add Submitters page submitter id is set ""(.*)""")]
        public void WhenTMSCDMConfigurationAddSubmittersPageSubmitterIdIsSet(string p0)
        {

            string subid = tmsCommon.GenerateData(p0);
            IWebElement submitterid = Browser.Wd.FindElement(By.XPath("//input[@test-id='addSubmitters-txt-submitterId']"));

            submitterid.SendKeys(subid);

            GlobalRef.Subid = subid;

        }

        [When(@"TMS CDM Configuration Add Submitters page PlanId is set ""(.*)""")]
        public void WhenTMSCDMConfigurationAddSubmittersPagePlanIdIsSet(string p0)
        {
            IWebElement planid = Browser.Wd.FindElement(By.XPath("//input[@test-id='addSubmitters-txt-planId']"));
            planid.SendKeys(p0);
        }

        [When(@"TMS CDM Configuration Add Submitters pag I Clicked on Add button")]
        public void WhenTMSCDMConfigurationAddSubmittersPagIClickedOnAddButton()
        {

            tmsWait.Hard(5);
            IWebElement add = Browser.Wd.FindElement(By.XPath("(//span[contains(text(),'ADD')])[2]"));
            fw.ExecuteJavascript(add);


        }


      

        [Then(@"Verify that submitter id ""(.*)"" is added successfully")]
        public void ThenVerifyThatSubmitterIdIsAddedSuccessfully(string subid)
        {


            string expsubid = tmsCommon.GenerateData(subid);
            //IWebElement SubmitterGrid = Browser.Wd.FindElement(By.XPath("//div[@id='grdAddSubmitter']//table//tbody"));
            //IReadOnlyCollection<IWebElement> Submitterrow = SubmitterGrid.FindElements(By.TagName("tr"));
            //string actualid;
            //Boolean ispresent =false;
            //foreach (var row in Submitterrow)
            //{
            //    actualid = row.Text.Split(' '); //row.FindElement(By.XPath("//td[2]/span")).Text;

            //  if(expsubid== actualid)
            //    {
            //        ispresent = true;
            //        break;
            //    } 
            //}
            //Assert.IsTrue(ispresent, "Submitter id not saved");

            IWebElement submitterid = Browser.Wd.FindElement(By.XPath("//span[text()='" + expsubid + "']"));
            Assert.IsTrue(submitterid.Displayed, "Submitter Id Does not exist in Search Grid");
            tmsWait.Hard(3);


        }


        [When(@"TMS CDM Configuration Add Submitters page submitter id ""(.*)"" is edited")]
        public void WhenTMSCDMConfigurationAddSubmittersPageSubmitterIdIsEdited(string subid)
        {
            
            string gridsubid = tmsCommon.GenerateData(subid);
            IWebElement gridsubmitterid = Browser.Wd.FindElement(By.XPath("//div[@test-id='addSubmitters-grid-grdAddSubmitter']//td/span[text()='S1234']/parent::td/following-sibling::td/a[1]"));
            fw.ExecuteJavascript(gridsubmitterid);
            tmsWait.Hard(3);



        }

        [When(@"TMS CDM Configuration Add Submitters page new submitter id is set ""(.*)""")]
        public void WhenTMSCDMConfigurationAddSubmittersPageNewSubmitterIdIsSet(string newid)
        {
            string NewSubmid = tmsCommon.GenerateData(newid);
            tmsWait.Hard(3);
            IWebElement gridsubmitterid = Browser.Wd.FindElement(By.XPath("//div[@test-id='addSubmitters-grid-grdAddSubmitter']//input[@name='submitterId']"));
            gridsubmitterid.SendKeys(NewSubmid);
            tmsWait.Hard(3);

        }
        

        [When(@"TMS CDM Configuration Add Submitters page save button clicked")]
        public void WhenTMSCDMConfigurationAddSubmittersPageSaveButtonClicked()
        {
            //IWebElement savebutton = Browser.Wd.FindElement(By.xpath("//span[@class='k-icon k-i-check']"));
            //fw.ExecuteJavascript(savebutton);
        }

        [When(@"CDM Batchupdate page open WorkflowAssignment panel")]
        public void WhenCDMBatchupdatePageOpenWorkflowAssignmentPanel()
        {
            fw.ExecuteJavascript(CDM.CDMAdministration.WFAssignmentLink);
        }

        [Then(@"Verify CDM Batchupdate page WorkflowAssignment panel is disabled")]
        public void ThenVerifyCDMBatchupdatePageWorkflowAssignmentPanelIs()
        {
            Boolean isdisabled = false;
            //string chkdisabled = Browser.Wd.FindElement(By.XPath("//select[@test-id='batchUpdate-select-workFlowAssignedUsers']")).GetAttribute("disabled");
            string chkdisabled = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='batchUpdate-select-workFlowAssignedUsers']//span[@unselectable='on']")).GetAttribute("aria-disabled");

            if (chkdisabled == "true")
            {
                isdisabled = true;
                
            }

            Assert.IsTrue(isdisabled);

        }

        [Then(@"Verify CDM Batchupdate page WorkflowAssignment panel is enabled")]
        public void ThenVerifyCDMBatchupdatePageWorkflowAssignmentPanelIsEnabled()
        {
            Boolean isenabled = false;
            string chkenabled = Browser.Wd.FindElement(By.Id("workflowhDiv")).GetAttribute("disabled");
            if(chkenabled == null)
            {
                isenabled = true;
            }

            Assert.IsTrue(isenabled);
        }


        [When(@"CDM Batchupdate page status ""(.*)"" is selected")]
        public void WhenCDMBatchupdatePageStatusIsSelected(string p0)
        {
            tmsWait.Hard(1);
            IWebElement elecType = Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='batchUpdate-select-status']//input"));

            elecType.SendKeys(p0);
            tmsWait.Hard(3);
            elecType.SendKeys(OpenQA.Selenium.Keys.Enter);
        }

        [When(@"CDM Batchupdate page FilesLoaded ""(.*)"" is selected")]
        public void WhenCDMBatchupdatePageFilesLoadedIsSelected(string p0)
        {
            string filename = tmsCommon.GenerateData(p0);
            filename = "Claim_66882882.Claims";
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//div[@class='k-multiselect-wrap k-floatwrap'])[3]")));
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@id='formInputBoxFilesLoaded-list']")));
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//ul[@id='formInputBoxFilesLoaded_listbox']//li[contains(., '"+filename+"')]")));
        }



        [When(@"CDM Batchupdate page AdvanceSearch link is clicked")]
        public void WhenCDMBatchupdatePageAdvanceSearchLinkIsClicked()
        {
            fw.ExecuteJavascript(CDM.CDMAdministration.AdvanceSearchAccordian);
            tmsWait.Hard(4);
        }

        [When(@"CDM Batchupdate page MBI is set to ""(.*)""")]
        public void WhenCDMBatchupdatePageMBIIsSetTo(string p0)
        {
            fw.ExecuteJavascript(CDM.CDMAdministration.BatchUpdateMBILookupIcon);
            tmsWait.Hard(10);
            CDM.CDMAdministration.BatchUpdateMBILookupText.SendKeys(p0);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='member-btn-search']")));
            tmsWait.Hard(10);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//input[@type='checkbox']")));
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='member-btn-add']")));
            //input[@type='checkbox']
        }


        [When(@"CDM Batchupdate page Search button is clicked")]
        public void WhenCDMBatchupdatePageSearchButtonIsClicked()
        {
            fw.ExecuteJavascript(CDM.CDMAdministration.BatchUpdateSearchButton);
            tmsWait.Hard(5);
            //try
            //{
            //    string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
            //    Assert.IsTrue(actualValue.Contains("No result found"));
            //}
            //catch {
            //    tmsWait.WaitForElement(By.XPath("(//div[@test-id='batchUpdate-grid-grdBatchUpdate']//span[@ng-bind ='dataItem.workFlowStatus'])[1]"), 60);
            //}
        }
          
        [When(@"CDM Batchupdate page notify workflowstatus and Assigneduser from the grid")]
        public void WhenCDMBatchupdatePageNotifyWorkflowstatusAndAssigneduserFromTheGrid()
        {
            GlobalRef.WFStatus = CDM.CDMAdministration.BatchUpdateWFStatusInGrid.Text;
            GlobalRef.WFUsers = CDM.CDMAdministration.BatchUpdateWFUsersInGrid.Text;
        }

        [When(@"CDM Batchupdate page WorkflowAssignment panel status ""(.*)"" is selected")]
        public void WhenCDMBatchupdatePageWorkflowAssignmentPanelStatusIsSelected(string p0)
        {
            string status = tmsCommon.GenerateData(p0);
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[@test-id='batchUpdate-lbl-workflowStatus']//following-sibling::span[@role='listbox']")));

            By Drp = By.XPath("(//label[contains(.,'Workflow Status')]/parent::div//span[@class='k-select'])[2]");
            By typeapp = By.XPath("//li[text()='" + status + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
        }

        [When(@"CDM Batchupdate page WorkflowAssignment panel users ""(.*)"" is selected")]
        public void WhenCDMBatchupdatePageWorkflowAssignmentPanelUsersIsSelected(string p0)
        {
            string user = tmsCommon.GenerateData(p0);
            By Drp = By.XPath("(//label[contains(.,'Assigned User')]/parent::div//span[@class='k-select'])[2]");
            By typeapp = By.XPath("//li[text()='" + user + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
        }

        [When(@"CDM Batchupdate page WorkflowAssignment panel AssignWorfklow button is clicked")]
        public void WhenCDMBatchupdatePageWorkflowAssignmentPanelAssignWorfklowButtonIsClicked()
        {
            fw.ExecuteJavascript(CDM.CDMAdministration.WFAssignmentAssignWorkflowButtom);
        }

        [Then(@"Verify Workflow status ""(.*)"" is displayed in the grid")]
        public void ThenVerifyWorkflowStatusIsDisplayedInTheGrid(string p0)
        {
            string status = tmsCommon.GenerateData(p0);
            string actualupdatedvalue = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='batchUpdate-grid-grdBatchUpdate']//td[contains(., '" + status + "')]")).Text;
            Assert.AreEqual(status, actualupdatedvalue, "CodeD Description has not been updated");


        }

        [Then(@"Verify Workflow users ""(.*)"" is displayed in the grid")]
        public void ThenVerifyWorkflowUsersIsDisplayedInTheGrid(string p0)
        {
            string user = tmsCommon.GenerateData(p0);
            string actualupdatedvalue = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='batchUpdate-grid-grdBatchUpdate']//td[contains(., '" + user + "')]")).Text;
            Assert.AreEqual(user, actualupdatedvalue, "CodeD user has not been updated");
        }

        [Then(@"Verify tooltip Message ""(.*)"" on workflowassignment panel")]
        public void ThenVerifyTooltipMessageOnWorkflowassignmentPanel(string p0)
        {
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//i[@data-role='tooltip'])[2]")));
            tmsWait.Hard(1);
            string actualtext = Browser.Wd.FindElement(By.XPath("(//div[contains(., 'This panel would only be enabled when status is one of the rejected status')])[1]")).Text;
            Assert.AreEqual(p0, actualtext);
        }

        [When(@"CDM Manage Provider Specialty page SearchProvider tab is clicked")]
        public void WhenCDMManageProviderSpecialtyPageSearchProviderTabIsClicked()
        {
            fw.ExecuteJavascript(CDM.CDMAdministration.ManageProvidersSearchProviderTab);
            tmsWait.Hard(1);
        }


        [When(@"CDM Manage Provider Speciality page provider id is set to ""(.*)""")]
        public void WhenCDMManageProviderSpecialityPageProviderIdIsSetTo(string p0)
        {
            CDM.CDMAdministration.ManageProviderProviderTextBox.Clear();
            tmsWait.Hard(1);
            CDM.CDMAdministration.ManageProviderProviderTextBox.SendKeys(p0.ToString());
            tmsWait.Hard(1);
        }


        [When(@"CDM Manage Provider Speciality page Action icon is clicked")]
        public void WhenCDMManageProviderSpecialityPageActionIconIsClicked()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//tr[1]//td//a//span[@class='fa fa-pencil-square-o k-i-edit'])[2]")));
            tmsWait.Hard(1);
        }

       


        [Given(@"CDM Manage Provider Specialty page Filtering logic is set to ""(.*)""")]
        public void GivenCDMManageProviderSpecialtyPageFilteringLogicIsSetTo(string p0)
        {

            tmsWait.Hard(10);
            string switchoption = tmsCommon.GenerateData(p0);
            IWebElement ClickOnswitchElement = Browser.Wd.FindElement(By.XPath("//input[@test-id='manageProvider-switch-providerFilterLogic']/parent::span"));
            IWebElement switchElement = Browser.Wd.FindElement(By.XPath("//input[@test-id='manageProvider-switch-providerFilterLogic']"));
            string switchingStatus = switchElement.GetAttribute("value");
            if (switchoption == "ON")
            {
                if (switchingStatus == "0")
                {
                    ClickOnswitchElement.Click();
                    tmsWait.Hard(2);
                }
            }
            else
            {
                if(switchingStatus== "1")
                {
                    ClickOnswitchElement.Click();
                    tmsWait.Hard(2);
                }
            }
        }


        [When(@"CDM Manage Provider Speciality page Provider ""(.*)"" Checkbox is ""(.*)""")]
        public void WhenCDMManageProviderSpecialityPageProviderCheckboxIs(string p0, string p1)
        {
            string provider = tmsCommon.GenerateData(p0);
            string status = tmsCommon.GenerateData(p1);
            By statusOfCheckbox = By.XPath("//table//td[contains(.,'"+ provider + "')]/following-sibling::td//input[@type='checkbox']");

            ReUsableFunctions.CheckBoxOperations(statusOfCheckbox, status);


        }


        [When(@"CDM Manage Provider Speciality page Checkbox is ""(.*)""")]
        public void WhenCDMManageProviderSpecialityPageCheckboxIs(string p0)
        {
            switch(p0.ToLower())
            {
                case "check":
                    if (GlobalRef.ischeckedvalue.ToString() != "true")
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//input[@name='isActive']")));
                    }
                    break;

                case "uncheck":
                    if (GlobalRef.ischeckedvalue.ToString() == "true")
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//input[@name='isActive']")));
                    }
                    break;

            }
        }



        [When(@"CDM Manage Provider Speciality page Save icon is clicked")]
        public void WhenCDMManageProviderSpecialityPageSaveIconIsClicked()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a/span[@class='k-icon k-i-check']")));
            tmsWait.Hard(1);
        }



        [When(@"CDM Manage Provider Specialty page Search button is clicked")]
        public void WhenCDMManageProviderSpecialtyPageSearchButtonIsClicked()
        {
            tmsWait.Hard(10);
            fw.ExecuteJavascript(CDM.CDMAdministration.ManageProvidersSearchProviderSearchBtn);
            tmsWait.Hard(4);
        }

        [Then(@"Verify CDM Manage Provider Specialty page active checkbox is checked or not")]
        public void ThenVerifyCDMManageProviderSpecialtyPageActiveCheckboxIsCheckedOrNot()
        {
            string ischecked = Browser.Wd.FindElement(By.XPath("//div[@id='grdSearchprovider']//td[6]/input")).GetAttribute("checked");
            GlobalRef.ischeckedvalue = bool.Parse(ischecked);
        }


        [Then(@"Verify Provider result grid is displayed")]
        public void ThenVerifyProviderResultGridIsDisplayed()
        {
            bool b = CDM.CDMAdministration.ManageProviderFirstRowEditbutton.Displayed;
            Assert.IsTrue(CDM.CDMAdministration.ManageProviderFirstRowEditbutton.Displayed);
        }

        [When(@"CDM Manage Provider Specialty page edit icon is clicked for first result")]
        public void WhenCDMManageProviderSpecialtyPageEditIconIsClickedForFirstResult()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='searchProvider-grid-grdSearchprovider']//td//span[@class='fas fa-pencil-alt'])[1]")));
        }

        [When(@"CDM Manage Provider Specialty page SpecialtyCodeDescription is set to ""(.*)""")]
        public void WhenCDMManageProviderSpecialtyPageSpecialtyCodeDescriptionIsSetTo(string p0)
        {
            string codeDescription = tmsCommon.GenerateData(p0);
            CDM.CDMAdministration.ManageProviderSpecialtyCodeDescription.Clear();
            tmsWait.Hard(2);
            CDM.CDMAdministration.ManageProviderSpecialtyCodeDescription.SendKeys(codeDescription);
            CDM.CDMAdministration.ManageProviderSpecialtyCodeDescription.SendKeys(Keys.Enter);
        }

        [When(@"CDM Manage Provider Specialty page update icon is clicked for first result")]
        public void WhenCDMManageProviderSpecialtyPageUpdateIconIsClickedForFirstResult()
        {
            tmsWait.Hard(2);
            CDM.CDMAdministration.ManageProviderFirstRowUpdateIcon.Click();
        }
        [When(@"Verify updated code description ""(.*)"" is displayed")]
        [Then(@"Verify updated code description ""(.*)"" is displayed")]
        public void ThenVerifyUpdatedCodeDescriptionIsDisplayed(string p0)
        {
            string codeD = tmsCommon.GenerateData(p0);
            string actualupdatedvalue = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='searchProvider-grid-grdSearchprovider']//td[contains(., '" + codeD + "')]")).Text;
            Assert.AreEqual(codeD, actualupdatedvalue, "CodeD Description has not been updated");
        }

        [When(@"WorkflowStatus tab workfowstatus is set to ""(.*)""")]
        public void WhenWorkflowStatusTabWorkfowstatusIsSetTo(string p0)
        {
            string wfstatus = tmsCommon.GenerateData(p0);
            CDM.CDMAdministration.WorkflowStatusTextBox.SendKeys(wfstatus);
        
        }

        [When(@"WorkflowStatus tab Add button is clicked")]
        public void WhenWorkflowStatusTabAddButtonIsClicked()
        {
            tmsWait.Hard(1);
            fw.ExecuteJavascript(CDM.CDMAdministration.WorkflowStatusAddButton);
        }

        [When(@"WorkflowStatus tab Add button is clicked and verify message ""(.*)""")]
        public void WhenWorkflowStatusTabAddButtonIsClickedAndVerifyMessage(string p0)
        {
            tmsWait.Hard(1);
            string expectedmessage = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(CDM.CDMAdministration.WorkflowStatusAddButton);
            //string actualValue = Browser.Wd.FindElement(By.XPath("//div[@class='k-notification-content']")).GetAttribute("Workflow status updated successfully.");
            //ReUsableFunctions.toasterMessageDisplay(expectedValue);
            //Assert.IsTrue(actualValue.Contains(expectedmessage));
        }


        [Then(@"Verify Workflow status drop down having value ""(.*)""")]
        public void ThenVerifyWorkflowStatusDropDownHavingValue(string p0)
        {
            string expectedwfstatus = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[contains(., ' Advanced Search')]")));
            tmsWait.Hard(1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//span[@role='listbox'])[5]")));
            tmsWait.Hard(2);
            IWebElement actualwfstatus = Browser.Wd.FindElement(By.XPath("(//li[@data-offset-index='7'])[4]"));
            string ss = actualwfstatus.Text;
            Assert.AreEqual(expectedwfstatus, actualwfstatus.Text, "Workflow Status has not been added");
        }

        [When(@"WorkflowStatus tab edit icon is clicked for workfowstatus ""(.*)""")]
        public void WhenWorkflowStatusTabEditIconIsClickedForWorkfowstatus(string p0)
        {
            tmsWait.Hard(3);
            string wf = tmsCommon.GenerateData(p0);
            bool elementSearch = false;

            By mbiBy = By.XPath("(//*[@id='workFlowStatusGrid']//td[contains(., '" + wf + "')]//parent::td//following-sibling::td//span[@class='fas fa-pencil-alt'])[1]");
            By nextPage = By.XPath("//*[@id='workFlowStatusGrid']//span[@aria-label='Go to the next page']");
            //*[@id='workFlowStatusGrid']//td[contains(., 'B06567137')]//parent::td//following-sibling::td//span[@class='fas fa-pencil-alt']

            while (!elementSearch)
            {
                elementSearch = elementPresence(mbiBy);
                tmsWait.Hard(3);
                if (!elementSearch)
                {
                    try
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(nextPage));
                    }
                    catch
                    {
                        Assert.Fail(" Expected WORKFLOW is not present on Search results");
                    }
                }

                if (elementSearch)
                {

                    tmsWait.Hard(2);
                    IWebElement edit = Browser.Wd.FindElement(By.XPath("(//*[@id='workFlowStatusGrid']//td[contains(., '" + wf + "')]//parent::td//following-sibling::td//span[@class='fas fa-pencil-alt'])[1]"));
                    fw.ExecuteJavascript(edit);


                }
            }

        }

        public bool elementPresence(By mbiBy)
        {

            try
            {
                Browser.Wd.FindElement(mbiBy);
                return true;
            }
            catch
            {
                return false;
            }
        }

        [When(@"WorkflowStatus tab edit icon is clicked for ""(.*)"" and verify message ""(.*)""")]
        public void WhenWorkflowStatusTabEditIconIsClickedForAndVerifyMessage(string p0, string p1)
        {
            Console.Write("Workflow status edit....");
            tmsWait.Hard(3);
            string status = tmsCommon.GenerateData(p0);
            string expectedvalue = tmsCommon.GenerateData(p1);
            tmsWait.Hard(5);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//*[@id='workFlowStatusGrid']//td[contains(., '" + status + "')]//parent::td//following-sibling::td//span)[1]")));

            //By toastMsg = By.XPath("//div[@class='k-notification-content']");
            //string actValue = Browser.Wd.FindElement(toastMsg).Text;
            //Assert.IsTrue(actValue.Contains(expectedvalue));
        }

        [When(@"WorkflowStatus tab new status is set to ""(.*)""")]
        public void WhenWorkflowStatusTabNewStatusIsSetTo(string p0)
        {
            //CDM.CDMAdministration.WorkflowStatusEditStatus.Clear();
            tmsWait.Hard(3);
            CDM.CDMAdministration.WorkflowStatusEditStatus.SendKeys(p0);
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@class='k-button k-button-icontext k-primary k-grid-update']")));
        }

        [Then(@"WorkflowStatus tab new status is set to ""(.*)"" and verify message ""(.*)""")]
        public void ThenWorkflowStatusTabNewStatusIsSetToAndVerifyMessage(string p0, string p1)
        {
            tmsWait.Hard(3);
            CDM.CDMAdministration.WorkflowStatusEditStatus.SendKeys(p0);
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@id='workFlowStatusGrid']//td//input[@id='WorkStatusDesc']//parent::td//following-sibling::td//span[@class='fas fa-save']")));

            //By toastMsg = By.XPath("//div[@class='k-notification-content']");
            //string actValue = Browser.Wd.FindElement(toastMsg).Text;
            //Assert.IsTrue(actValue.Contains(p1));

        }


        [Then(@"Verify Note ""(.*)""")]
        public void ThenVerifyNote(string expectednote)
        {
            string actualnote = Browser.Wd.FindElement(By.XPath("//*[@id='k-tabstrip-tabpanel-1']/app-search-provider/div/div[1]//div[contains(.,'NOTE:')]")).Text;
            Assert.AreEqual(expectednote, actualnote, "Noteis not displaying correctly");
        }

        [When(@"CDM Manage Provider Specialty page Filtering logic switch is clicked")]
        public void WhenCDMManageProviderSpecialtyPageFilteringLogicSwitchIsClicked()
        {
           tmsWait.Hard(2);
        //   Browser.Wd.FindElement(By.XPath("//*[@id='mainContant']/div[1]/div/div/div[2]/div[1]/span/span[2]")).Click();
           Browser.Wd.FindElement(By.XPath("//span[contains(@class,'k-switch-handle km-switch-handle')]")).Click();




        }

        [When(@"CDM BatchUpdate page Action ""(.*)"" is selected")]
        public void WhenCDMBatchUpdatePageActionIsSelected(string p0)
        {
            IWebElement drp = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='batchUpdate-select-action']//span[@class='k-select']"));

            AngularFunction.selectKendoDropDownValue(drp, p0);
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//span[@aria-label='select'])[7]")));
            ////fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//select[@test-id='batchUpdate-select-action']//option[contains(., '"+p0+"')]")));
           //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//li[contains(.,'"+p0+"')])[2]")));
            //ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.OSBConfiguration.OSBTypeDropdownlist);
            //UIMODUtilFunctions.selectDropDownValueFromGendoUIWithoutAriaOwns(cfUIMODEAMConfiguration.OSBConfiguration.OSBTypeDropdownlist, value);
        }

        [When(@"CDM BatchUpdate page Batch Update button is clicked")]
        public void WhenCDMBatchUpdatePageBatchUpdateButtonIsClicked()
        {
            fw.ExecuteJavascript(CDM.CDMAdministration.BatchUpdatebutton);
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[test-id='confirmationDialog-btn-Yes']")));


        }


        [When(@"CDM BatchUpdate page Batch Update button is clicked and Verify Message ""(.*)""")]
        public void WhenCDMBatchUpdatePageBatchUpdateButtonIsClickedAndVerifyMessage(string p0)
        {
            tmsWait.Hard(5);
            string expectedValue = tmsCommon.GenerateData(p0);

            fw.ExecuteJavascript(CDM.CDMAdministration.BatchUpdatebutton);
            tmsWait.Hard(1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'YES')]")));

            string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
            tmsWait.Hard(1);
            Assert.IsTrue(actualValue.Contains(expectedValue));
        }


        [When(@"CDM Batchupdate page ViewErrorCode link is clicked")]
        public void WhenCDMBatchupdatePageViewErrorCodeLinkIsClicked()
        {
            fw.ExecuteJavascript(CDM.CDMAdministration.ViewErrorCodesLink);
            tmsWait.Hard(2);
        }

        [When(@"CDM Main page ViewErrorCode link is clicked")]
        public void WhenCDMMainPageViewErrorCodeLinkIsClicked()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[test-id='encounter-link-viewerrorcodes']")));
            tmsWait.Hard(2);
        }


        [When(@"CDM Search ErrorCode window Error code is set to ""(.*)""")]
        public void WhenCDMSearchErrorCodeWindowErrorCodeIsSetTo(int p0)
        {
            CDM.CDMErrorCodeWindow.ErrorCodeTextBox.SendKeys(p0.ToString());
            tmsWait.Hard(1);
        }

        [When(@"CDM Search ErrorCode window Search button is clicked")]
        public void WhenCDMSearchErrorCodeWindowSearchButtonIsClicked()
        {
            fw.ExecuteJavascript(CDM.CDMErrorCodeWindow.ErrorCodeSearchButton);
            tmsWait.Hard(2);
        }

        [Then(@"Verify Error code is displayed with description ""(.*)""")]
        public void ThenVerifyErrorCodeIsDisplayedWithDescription(string expecteddescription)
        {

            IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@id='errorCodesGridOptions']//td[contains(.,'" + expecteddescription + "')]"));
            UIMODUtilFunctions.elementPresenceUsingWebElement(ele);

        }

        [Then(@"CDM Search ErrorCode window is closed")]
        public void ThenCDMSearchErrorCodeWindowIsClosed()
        {
            fw.ExecuteJavascript(CDM.CDMErrorCodeWindow.CloseErrorCodeWindow);
        }

        [When(@"CDM Manage Provider Search Provider Active dropdown value is set to ""(.*)""")]
        public void WhenCDMManageProviderSearchProviderActiveDropdownValueIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string value = tmsCommon.GenerateData(p0);

            By Drp = By.XPath("//label[contains(.,'Active')]/parent::div//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + value + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
        }

        //[When(@"CDM Batchupdate page errorcode is set to ""(.*)""")]
        //public void WhenCDMBatchupdatePageErrorcodeIsSetTo(int p0)
        //{
        //    CDM.CDMAdministration.ErrorCodeInputBox.SendKeys(p0.ToString());
        //}

        [When(@"CDM ErroCode window page errorcode is selected")]
        public void WhenCDMErroCodeWindowPageErrorcodeIsSelected()
        {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@id='k-grid2-checkbox0']")));
        }

        [When(@"CDM ErrorCode window Add button is clicked")]
        public void WhenCDMErrorCodeWindowAddButtonIsClicked()
        {
            fw.ExecuteJavascript(CDM.CDMErrorCodeWindow.ErrorCodeAddButton);
            tmsWait.Hard(1);
        }

        [When(@"CDM Batchupdate page ErrorCode lookup icon is clicked")]
        public void WhenCDMBatchupdatePageErrorCodeLookupIconIsClicked()
        {
            fw.ExecuteJavascript(CDM.CDMAdministration.ErrorCodeLookupIcon);
            tmsWait.Hard(1);
        }

        [Then(@"Verify CDM Batchupdate result grid displayed result")]
        public void ThenVerifyCDMBatchupdateResultGridDisplayedResult()
        {
            Boolean isdisplayedresult = true;
            try
            {
                if(Browser.Wd.FindElement(By.XPath("(//table//td/span[@ng-bind='dataItem.mbi'])[1]")).Displayed)
                
                {
                    Assert.IsTrue(isdisplayedresult);
                }
            }
            catch
            {
                string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                Assert.IsTrue(actualValue.Contains("No result found"));
            }
        }

        [When(@"CDM Configurations page Workflow status is set to ""(.*)""")]
        public void WhenCDMConfigurationsPageWorkflowStatusIsSetTo(string p0)
        {
            string newstatus = tmsCommon.GenerateData(p0);
            CDM.CDMAdministration.AddWorkflowStatusInputBox.SendKeys(newstatus);
        }

        [When(@"CDM Configurations page Add button is clicked")]
        public void WhenCDMConfigurationsPageAddButtonIsClicked()
        {
            fw.ExecuteJavascript(CDM.CDMAdministration.AddWFAddbutton);
            tmsWait.Hard(1);
        }

        [Then(@"Verify CDM Configuration ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyCDMConfigurationIsSetTo(string p0, string p1)
        {
            string status = tmsCommon.GenerateData(p1);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@id='workFlowStatusGrid']//span[contains(.,'" + status + "')]")).Displayed,"Status is not displayed");
        }

        [Then(@"Verify CDM Main Workflow status drop down displayed ""(.*)""")]
        public void ThenVerifyCDMMainWorkflowStatusDropDownDisplayed(string p0)
        {
            string expectedStatus = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(CDM.CDMMain.AdvanceSearch);
            tmsWait.Hard(1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//span[@class='k-select'])[8]")));
            string actualstatus = Browser.Wd.FindElement(By.XPath("//li[contains(., '" + expectedStatus + "')]")).Text;
            tmsWait.Hard(1);
           Assert.AreEqual(actualstatus, expectedStatus, "Workflow status has not been added");  
        }

        [When(@"CDM Configurations page edit icon is clicked for workflow status ""(.*)""")]
        public void WhenCDMConfigurationsPageEditIconIsClickedForWorkflowStatus(string p0)
        {
            string expectedstatus = tmsCommon.GenerateData(p0);
            IReadOnlyCollection<IWebElement> statusrow = CDM.CDMAdministration.WorkflowStatusTable.FindElements(By.TagName("tr"));
            foreach(var row in statusrow)
            {
                string statuschk = row.FindElement(By.XPath("//td[2]/span")).Text;
                if(expectedstatus==statuschk)
                {
                    fw.ExecuteJavascript(row.FindElement(By.XPath("//td[3]/a")));
                    break;
                }
            }
        }

        [When(@"CDM Configurations page update workflow status is ""(.*)""")]
        public void WhenCDMConfigurationsPageUpdateWorkflowStatusIs(string p0)
        {
            CDM.CDMAdministration.Editworkflowstatusinoutbox.Clear();
            tmsWait.Hard(1);
            CDM.CDMAdministration.Editworkflowstatusinoutbox.SendKeys(p0);
        }


        [When(@"CDM Configurations page Submitter PlanId is set to ""(.*)""")]
        public void WhenCDMConfigurationsPageSubmitterPlanIdIsSetTo(string p0)
        {
            string planid = tmsCommon.GenerateData(p0);
            CDM.CDMAdministration.AddSubmitterTxt.SendKeys(planid);
        }

        [When(@"CDM Configurations page SubmitterId is set to ""(.*)""")]
        public void WhenCDMConfigurationsPageSubmitterIdIsSetTo(string p0)
        {
            string subid = tmsCommon.GenerateData(p0);
            CDM.CDMAdministration.SubmitterIdTxt.SendKeys(subid);
        }

        [Then(@"CDM Configuration page SubmitterId ""(.*)"" is displayed")]
        public void ThenCDMConfigurationPageSubmitterIdIsDisplayed(string p0)
        {
            tmsWait.Hard(3);
            string subid = tmsCommon.GenerateData(p0);
            //bool results = Browser.Wd.FindElement(By.XPath("//div[@id='grdAddSubmitter']//td[contains(.,'" + subid + "')]")).Displayed;
            bool results = Browser.Wd.FindElement(By.XPath("//div[@class='k-grid-aria-root']//td[contains(.,'" + subid + "')]")).Displayed;
            Assert.IsTrue(results," Expected results are not displayed");
        }

        [Then(@"CDM Configuration page SubmitterId ""(.*)"" and PlanId ""(.*)"" is not displayed")]
        public void ThenCDMConfigurationPageSubmitterIdAndPlanIdIsNotDisplayed(string p0, string p1)
        {
            tmsWait.Hard(3);
            string subid = tmsCommon.GenerateData(p0);
            string planid = tmsCommon.GenerateData(p1);
            bool results = Browser.Wd.FindElement(By.XPath("//div[@class='k-grid-aria-root']//td[contains(.,'" + subid + "')]//following-sibling::td[contains(.,'" + planid + "')]")).Displayed;
            Assert.IsFalse(results, "Submitter ID is displayed and it should have been deleted");
        }

        [When(@"Verify CDM Configuration page PlanId ""(.*)"" is not present")]
        public void WhenVerifyCDMConfigurationPagePlanIdIsNotPresent(string p0)
        {
            string planid = tmsCommon.GenerateData(p0);
          if(Browser.Wd.FindElement(By.XPath("//div[@id='grdAddSubmitter']//td[contains(.,'" + planid + "')]")).Displayed)

            {
                tmsWait.Hard(3);
                Browser.Wd.FindElement(By.XPath("//div[@id='grdAddSubmitter']//td[contains(.,'" + planid + "')]//following-sibling::td/a[contains(@class,'Delete')]")).Click();
                tmsWait.Hard(2);
                Browser.Wd.FindElement(By.XPath("//button[@id='confirmationDialogYes']/span")).Click();
            }
        }


        [When(@"CDM Configurations page Submitter Add button is clicked")]
        public void WhenCDMConfigurationsPageSubmitterAddButtonIsClicked()
        {
            tmsWait.Hard(5);
            //fw.ExecuteJavascript(CDM.CDMAdministration.AddSubmitterSaveButton);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[text()='ADD']")));
            //CDM.CDMAdministration.AddSubmitterSaveButton.Click();
            tmsWait.Hard(5);
        }

        [When(@"CDM Configuration page SubmitterId ""(.*)"" and PlanId ""(.*)"" Delete button is clicked")]
        public void WhenCDMConfigurationsPageSubmitterIdAndPlanIdDeleteButtonIsClicked(string p0, string p1)
        {
            tmsWait.Hard(5);
            string subid = tmsCommon.GenerateData(p0);
            string planid = tmsCommon.GenerateData(p1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@class='k-grid-aria-root']//td[contains(.,'" + subid + "')]//following-sibling::td[contains(.,'" + planid + "')]//following-sibling::td/button/span[@class='fas fa-trash-alt']")));
            tmsWait.Hard(5);
        }

        [When(@"CDM Configurations page Submitter Dialog button is ""(.*)"" clicked")]
        public void WhenCDMConfigurationsPageSubmitterDialogButtonIsClicked(string p0)
        {
            tmsWait.Hard(5);
            string option = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//kendo-dialog-actions/div/button[@test-id='confirmationDialog-btn-" + option + "']")));
            tmsWait.Hard(5);
        }

        [When(@"CDM Configurations page edit icon is clicked for plan id ""(.*)""")]
        public void WhenCDMConfigurationsPageEditIconIsClickedForPlanId(string p0)
        {

            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//*[@id='submiiterGrid']//td//span[@class='fas fa-pencil-alt'])[1]")));

        }

        [When(@"CDM Configurations page submitterid is updates as ""(.*)""")]
        public void WhenCDMConfigurationsPageSubmitteridIsUpdatesAs(string p0)
        {
            CDM.CDMAdministration.EditSubmitterIdTxt.Clear();
            tmsWait.Hard(1);
            CDM.CDMAdministration.EditSubmitterIdTxt.SendKeys(p0);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@class='k-icon k-i-check']")));
            
        }

        [When(@"CDM Configuration page submitter id updates as ""(.*)"" and verify message ""(.*)""")]
        public void WhenCDMConfigurationPageSubmitterIdUpdatesAsAndVerifyMessage(string p0, string p1)
        {
            string expectedvalue = tmsCommon.GenerateData(p0);
            string expectedmessage = tmsCommon.GenerateData(p1);
            CDM.CDMAdministration.EditSubmitterIdTxt.Clear();
            tmsWait.Hard(1);
            CDM.CDMAdministration.EditSubmitterIdTxt.SendKeys(expectedvalue);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//*[@id='submiiterGrid']//td//span[@class='fas fa-save'])[1]")));
          
        }


        [When(@"Manage Provider Speciality page Provider Filtering Logic ""(.*)""")]
        public void GivenManageProviderSpecialityPageProviderFilteringLogic(string p0)
        {
           if(p0.Equals("ON"))
            {
                IWebElement ON = Browser.Wd.FindElement(By.XPath("//span[@class='k-switch-wrapper km-switch-wrapper']"));
                fw.ExecuteJavascript(ON);
            }
        }


        [Then(@"Verify MapProviderSpeciality radiobutton for ""(.*)"" is checked")]
        public void ThenVerifyMapProviderSpecialityRadiobuttonForIsChecked(string p0)
        {
            Boolean ischeked = false;
            switch (p0.ToLower())
            {
               case "both":IWebElement checkedvalue =CDM.CDMAdministration.MapProviderSpecialityBothCodesRadioButton;
                    Boolean isselected = checkedvalue.Selected;
                          if (isselected == true)
                             ischeked = true;
                     break;
               case "mapped":IWebElement checkedmappedvalue = CDM.CDMAdministration.MapProviderSpecialityMappedCodesRadioButton;
                    Boolean mapselected =checkedmappedvalue.Selected;

                    if (mapselected == true)
                                ischeked = true;
                    break;
               case "unmapped":IWebElement checkedunmappedvalue = CDM.CDMAdministration.MapProviderSpecialityUnMappedCodesRadioButton;
                    Boolean unmapselected = checkedunmappedvalue.Selected;
                               if (unmapselected == true)
                                 ischeked = true;
                    break;
            }

            Assert.IsTrue(ischeked, "Radio Button is not selected");
        }


        [When(@"ManageProviders MapProviderSpeciality page ""(.*)"" codes radio button is checked")]
        public void WhenManageProvidersMapProviderSpecialityPageCodesRadioButtonIsChecked(string p0)
        {
            switch (p0.ToLower())
            {
                case "both":
                   fw.ExecuteJavascript(CDM.CDMAdministration.MapProviderSpecialityBothCodesRadioButton);
                   break;
                case "mapped":
                    fw.ExecuteJavascript(CDM.CDMAdministration.MapProviderSpecialityMappedCodesRadioButton);
                    break;
                case "unmapped":
                    fw.ExecuteJavascript(CDM.CDMAdministration.MapProviderSpecialityUnMappedCodesRadioButton);
                    break;
            }
        }


        [When(@"ManageProviders MapProviderSpeciality page Update first speciality code to ""(.*)"" in the grid")]
        public void WhenManageProvidersMapProviderSpecialityPageUpdateFirstSpecialityCodeToInTheGrid(string p0)
        {
           

            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@id='k-tabstrip-tabpanel-0']//span[@class='fas fa-pencil-alt'][1]")));
            tmsWait.Hard(2);
            By Drp = By.XPath("//*[@id='k-tabstrip-tabpanel-0']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + p0 + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@id='k-tabstrip-tabpanel-0']//span[@class='fas fa-save']")));

        }
        [When(@"MapProviderSpeciality page Update first speciality code to ""(.*)"" and Verify Message ""(.*)""")]
        [Then(@"MapProviderSpeciality page Update first speciality code to ""(.*)"" and Verify Message ""(.*)""")]
        public void ThenMapProviderSpecialityPageUpdateFirstSpecialityCodeToAndVerifyMessage(string p0, string p1)
        {
            

            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@id='k-tabstrip-tabpanel-0']//span[@class='fas fa-pencil-alt'][1]")));
            tmsWait.Hard(2);
            By Drp = By.XPath("//*[@id='k-tabstrip-tabpanel-0']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + p0 + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@id='k-tabstrip-tabpanel-0']//span[@class='fas fa-save']")));


        }

        [Then(@"Verify MapProviderSpeciality grid is displayed mappedcode")]
        public void ThenVerifyMapProviderSpecialityGridIsDisplayedMappedcode()
        {
            Boolean isdisplayedcode = false;
            string mappedcode = GlobalRef.SpecialityCode.ToString();
            IReadOnlyCollection<IWebElement> allcodes = CDM.CDMAdministration.MapProviderSpecialityGrid.FindElements(By.TagName("tr"));
            foreach(var code in allcodes)
            {
                string actualcode = code.FindElement(By.XPath("//td[1]/span")).Text;
                if(actualcode==mappedcode)
                {
                    isdisplayedcode = true;
                    break;
                }
            }

            Assert.IsTrue(isdisplayedcode);
        }

        [When(@"CDMConfiguraions SubmissionDeadline page Edit Icon is clicked")]
        public void WhenCDMConfiguraionsSubmissionDeadlinePageEditIconIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(CDM.CDMAdministration.SubmissionDeadlineEditIcon);
            tmsWait.Hard(1);
        }

        [When(@"CDMConfigurations SubmissionDeadline page Update ""(.*)"" as ""(.*)""")]
        public void WhenCDMConfigurationsSubmissionDeadlinePageUpdateAs(string p0, string p1)
        {
            string value = tmsCommon.GenerateData(p1);

            switch (p0.ToLower())
            {
                case "tmsdate":
                    By tmsDate = By.XPath("(//kendo-datepicker[@id='TmsDate']//span[@role='button'])[1]");
                    AngularFunction.enterTodayAsDate(tmsDate);
                    tmsWait.Hard(1);
                    AngularFunction.enterDate(tmsDate, value);
                   

                    break;
                case "cmsdate":
                    By cmsDate = By.XPath("(//kendo-datepicker[@id='CmsDate']//span[@role='button'])[1]");
                    AngularFunction.enterTodayAsDate(cmsDate);
                    tmsWait.Hard(1);
                    AngularFunction.enterDate(cmsDate, value);

                   
                    break;
                case "fromdos":
                    By dosFromDate = By.XPath("(//kendo-datepicker[@name='FromDateOfService']//span[@role='button'])[1]");
                    AngularFunction.enterTodayAsDate(dosFromDate);
                    tmsWait.Hard(1);
                    AngularFunction.enterDate(dosFromDate, value);
                    break;
                case "throughdos":
                    By dosToDate = By.XPath("(//kendo-datepicker[@id='ThroughDateOfService']//span[@role='button'])[1]");
                    AngularFunction.enterTodayAsDate(dosToDate);
                    tmsWait.Hard(1);
                    AngularFunction.enterDate(dosToDate, value);
                    

                    break;
            }
           // fw.ExecuteJavascript(CDM.CDMAdministration.SubmissionDeadlineSaveIcon);
        }

        [When(@"CDMConfigurations SubmissionDeadline page SaveIcon is clicked")]
        public void WhenCDMConfigurationsSubmissionDeadlinePageSaveIconIsClicked()
        {

            tmsWait.Hard(4);
            fw.ExecuteJavascript(CDM.CDMAdministration.SubmissionDeadlineSaveIcon);
            tmsWait.Hard(3);
        }

        [Then(@"Verify CDMConfiguration SubmissionDeadline page ""(.*)"" is displayed ""(.*)"" in the grid")]
        public void ThenVerifyCDMConfigurationSubmissionDeadlinePageIsDisplayedInTheGrid(string p0, string p1)
        {
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//*[@id='submissionDeadlineForm']//td[contains(.,'" + p1+"')]")).Displayed);
            //*[@id="submissionDeadlineForm"]/kendo-grid/div/kendo-grid-list/div/div[1]/table/tbody/tr/td[4]/text()

        }


        [Then(@"Verify CDM Dashboard page LastRawFileLoad is ""(.*)""")]
        public void ThenVerifyCDMDashboardPageLastRawFileLoadIs(string p0)
        {
            string filename=tmsCommon.GenerateData(p0);
            tmsWait.Hard(3);
            string fname = Browser.Wd.FindElement(By.XPath("//span[@test-id='cdmDashboard-span-fileNameLR']")).Text;
            Assert.IsTrue(p0.Contains(fname), "File name does not exist");
        }


        [When(@"CDM Manage Provider Speciality page note down speciality code description value")]
        public void WhenCDMManageProviderSpecialityPageNoteDownSpecialityCodeDescriptionValue()
        {
            GlobalRef.Codedescription = Browser.Wd.FindElement(By.XPath("//span[@ng-bind='dataItem.specialityCodeDescription']")).Text;
        }


       
        [When(@"CDM Manage Provider Specialty page MapProviderSpeciality tab is clicked")]
        public void WhenCDMManageProviderSpecialtyPageMapProviderSpecialityTabIsClicked()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//li[@test-id='manageProvider-li-mapProviderSpeciality']/span")));
            tmsWait.Hard(2);
        }

        [When(@"CDM Manage Provider Speciality MapProviderspeciality edit icon is clicked for ""(.*)""")]
        public void WhenCDMManageProviderSpecialityMapProviderspecialityEditIconIsClickedFor(string p0)
        {
            IWebElement mapproviderTable = Browser.Wd.FindElement(By.XPath("//div[@id='grdMapProviderSpeciality']//table/tbody"));
            IReadOnlyCollection<IWebElement> tablerow = mapproviderTable.FindElements(By.TagName("tr"));
            string codeD = GlobalRef.Codedescription.ToString();
            foreach (var row in tablerow)
            {
                if(row.FindElement(By.XPath("td[2]/span")).Text== codeD)
                {
                    row.FindElement(By.XPath("td[8]/a")).Click();
                    break;
                }
            }
        }

        [When(@"CDM Manage Provider Speciality MapProviderspeciality Speciality code ""(.*)"" is selected")]
        public void WhenCDMManageProviderSpecialityMapProviderspecialitySpecialityCodeIsSelected(string p0)
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//span[@class='k-icon k-i-arrow-60-down'])[1]")));
            tmsWait.Hard(1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//ul[@class='k-list k-reset']/li[contains(.,'" + p0 + "')]")));
            tmsWait.Hard(1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@class='k-icon k-i-check']")));
        }

        [Then(@"CDM Manage Provider Speciality MapProviderspeciality radio button ""(.*)"" is selected")]
        public void ThenCDMManageProviderSpecialityMapProviderspecialityRadioButtonIsSelected(string p0)
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//input[@test-id='manageProvider-radio-" + p0 + "']")));
            tmsWait.Hard(2);
        }

        [Then(@"Verify MapProviderspeciality result grid display data for ""(.*)"" are ""(.*)"" and ""(.*)"" and ""(.*)"" and ""(.*)""")]
        public void ThenVerifyMapProviderspecialityResultGridDisplayDataForAreAndAndAnd(string p0, string p1, int p2, string p3, string p4)
        {
            IWebElement mapproviderTable = Browser.Wd.FindElement(By.XPath("//div[@id='grdMapProviderSpeciality']//table/tbody"));
            IReadOnlyCollection<IWebElement> tablerow = mapproviderTable.FindElements(By.TagName("tr"));
            foreach (var row in tablerow)
            {
                if (row.FindElement(By.XPath("td[2]/span")).Text == p0)
                {
                    Assert.IsTrue(row.FindElement(By.XPath("td[1]/span")).Text.Contains(p1),"Expected Data is not displayed");
                    Assert.IsTrue(row.FindElement(By.XPath("td[3]/span")).Text.Contains(p2.ToString()), "Expected Data is not displayed");
                    Assert.IsTrue(row.FindElement(By.XPath("td[4]/span")).Text.Contains(p3), "Expected Data is not displayed");
                    Assert.IsTrue(row.FindElement(By.XPath("td[5]/span")).Text.Contains(p4), "Expected Data is not displayed");
                    break;
                }
            }
        }


        [Then(@"Verify CDM Manage Provider Specialty page ProviderId ""(.*)"" displayed in the result grid")]
        public void ThenVerifyCDMManageProviderSpecialtyPageProviderIdDisplayedInTheResultGrid(int p0)
        {
            string actualId = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='searchProvider-grid-grdSearchprovider']//td[@aria-colindex='1']")).Text;
            Assert.IsTrue(actualId.Contains(p0.ToString()));
        }


    }
}
