﻿//using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using System.IO;

namespace TMSoR1.FrameworkCode.CDM
{
    [Binding]
    class fsMypractice
    {


        [Given(@"Find the total number of drives in the machine")]
        public void GivenFindTheTotalNumberOfDrivesInTheMachine()
        {
            DriveInfo[] di = DriveInfo.GetDrives();
            Console.WriteLine("Total Partition");


            foreach (DriveInfo items in di)
            {
                Console.WriteLine(items.Name);
                Console.WriteLine(items.RootDirectory);
                //Console.WriteLine(items.TotalFreeSpace);
                //Console.WriteLine(items.TotalSize);
                Console.WriteLine(items.DriveType);
                //Console.WriteLine(items.DriveFormat);
                Console.WriteLine(items.AvailableFreeSpace);
            }
        }


        [Given(@"I am playing with directoryinfo class")]
        public void GivenIAmPlayingWithDirectoryinfoClass()
        {
            DirectoryInfo drinfo = new DirectoryInfo(@"\\abs-tzg-vdm-20.dev.trizetto.com\TMS\QA Automation");
            Console.WriteLine(drinfo.CreationTime);
            Console.WriteLine(drinfo.FullName);
            Console.WriteLine(drinfo.GetDirectories());
            Console.WriteLine(drinfo.Root);
        }


        [Given(@"I am creating a new directory")]
        public void GivenIAmCreatingANewDirectory()
        {
            DirectoryInfo dir = new DirectoryInfo(@"\\abs-tzg-vdm-20.dev.trizetto.com\TMS\QA Automation\My");
            dir.Create();
            dir.CreateSubdirectory("my1");
            dir.CreateSubdirectory(@"my1\my12");

        }

        [Given(@"I am writing in a file")]
        public void GivenIAmWritingReadingInAFile()
        {
            string fname = @"\\abs-tzg-vdm-20.dev.trizetto.com\TMS\QA Automation\MyFirstFile.txt";
            string str = "lksjdfkjkjjlsdkfjlkjjlskdjfjlkjsdfkjjjslkdfkj \n  lksdfljljsdfjlkkjsdjfl \n lakjsdfjkjsdfj \n submit \n lkajsdjfkdsf";
            //if (File.Exists(fname))
            //{
            //    File.Delete(fname);
            //}

            //Create a new file
            //FileStream fs = File.Create(fname);
            // fs.Write("Monday is the first day of the week /n");
            //Console.Write("\n");

            using (StreamWriter writetext = new StreamWriter(fname))
            {
                writetext.WriteLine(str+Environment.NewLine );
                writetext.Write("jljljjj \n lkljklkj");
            }
        }

        [Given(@"I am writing in a file in anotherway")]
        public void GivenIAmWritingInAFileInAnotherway()
        {
            string[] lines = { "My First Line", "My Seccond Line", "Third Line", "My Fourth Line" };
            string mydocpath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            using (StreamWriter Swriter = new StreamWriter(mydocpath + @"\write.txt", true))
            {
                foreach(var line in lines)
                {
                    Swriter.WriteLine(line);
                }
            }
        }


    }
}
