﻿
using OpenQA.Selenium;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
//using System.Windows.Forms;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.CDM
{
    class CDM
    {
        public static CDMNavigation CDMNavigation { get { return new CDMNavigation(); } }
        public static CDMMain CDMMain { get { return new CDMMain(); } }
        public static CDMImport CDMImport { get { return new CDMImport(); } }
        public static CDMExport CDMExport { get { return new CDMExport(); } }
        public static CDMAdministration CDMAdministration {  get { return new CDMAdministration(); } } 
        public static CDMErrorCodeWindow CDMErrorCodeWindow {  get { return new CDMErrorCodeWindow(); } }
    }

    [Binding]
    public class CDMNavigation
    {
        [When(@"I have navigated to CDM ""(.*)"" page")]
        public void WhenIHaveNavigatedToCDMPage(string pageName)
        {
            //CDM page standard name(parameter) must be having first letter captial and rest of the letters should be small

            
                //

            if (pageName.Equals("Manage Providers"))
            {
                IWebElement cdmpage = Browser.Wd.FindElement(By.CssSelector("[title= 'Administration']"));
                fw.ExecuteJavascript(cdmpage);

                IWebElement mp = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Manage Providers')]"));
                fw.ExecuteJavascript(mp);
            }
            if (pageName.Equals("Batch Update"))
            {
                IWebElement cdmpage = Browser.Wd.FindElement(By.CssSelector("[title= 'Administration']"));
                fw.ExecuteJavascript(cdmpage);

                IWebElement mp = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Batch Update')]"));
                fw.ExecuteJavascript(mp);
            }
            
            else
            {
                IWebElement cdmpage = Browser.Wd.FindElement(By.CssSelector("[title='" + pageName + "']"));
                fw.ExecuteJavascript(cdmpage);
            }
        }

        [When(@"I have navigated to CDM Main page")]
        public void WhenIHaveNavigatedToCDMMainPage()
        {
            IWebElement main = Browser.Wd.FindElement(By.CssSelector("[title='Main']"));
            fw.ExecuteJavascript(main);
        }

    }

    public class CDMMain
    {
        public IWebElement Encounterpage {  get { return Browser.Wd.FindElement(By.XPath("//span[contains(., 'Search Encounter')]")); } }
        public IWebElement SearchbyMBI {  get { return Browser.Wd.FindElement(By.XPath("[test-id='MBI-txt-box']")); } }
        public IWebElement MBISearchIcon {  get { return Browser.Wd.FindElement(By.XPath("//a[@test-id='deleteSubmittedDiagnosis-a-providerLookup']")); } }
        public IWebElement MBIListButton {  get { return Browser.Wd.FindElement(By.XPath(".//*[@id='orSearchMenu']/button")); } }
        public IWebElement SearchByErrorCode {  get { return Browser.Wd.FindElement(By.XPath("[test-id='ErrorCodes-txt-box']")); } }
        public IWebElement AdvanceSearch {  get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Advance')]")); } }
        public IWebElement patientcontrolNumber {  get { return Browser.Wd.FindElement(By.XPath("[test-id='PatientControlNumber-txt-box']")); } }
        public IWebElement FromDate { get { return Browser.Wd.FindElement(By.Id("fromDate")); } }
        public IWebElement ThroughDate {  get { return Browser.Wd.FindElement(By.Id("throughDate")); } }
        public IWebElement SearchButton {  get { return Browser.Wd.FindElement(By.XPath("")); } }
        public IWebElement ResetButton {  get { return Browser.Wd.FindElement(By.XPath("")); } }
        public IWebElement ViewAllErrorCodes {  get { return Browser.Wd.FindElement(By.XPath("[test-id='viewCodes-link-viewErrorCodes']")); } }
        public IWebElement EncounterResultGrid {  get { return Browser.Wd.FindElement(By.XPath(".//*[@id='encountersDataGrid']//table//tbody")); } }
        public IWebElement MBILookupSearchBtn {  get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='member-btn-search']")); } }
        public IWebElement MBILookupResetBtn {  get { return Browser.Wd.FindElement(By.XPath("[test-id='member-btn-reset']")); } }
        public IWebElement MBILookupAddBtn {  get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='member-btn-add']")); } }
        public IWebElement MBILookupCancelBtn {  get { return Browser.Wd.FindElement(By.XPath("[test-id='member-btn-cancel']")); } }
        public IWebElement MBILookupResultGrid {  get { return Browser.Wd.FindElement(By.XPath("//div[@test-id='member-grid-auditslist']//table//tbody")); } }
        public IWebElement MBILookupMBITextBox {   get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='member-txt-hic']")); } }
        public IWebElement MBILookupFirstName {  get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='member-txt-firstname']")); } }
        public IWebElement MBILookupLastName {  get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='member-txt-lastname']")); } }
        public IWebElement EncounterPageSearchButton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='encounter-btn-search']")); } }



    }

   public class CDMImport
    {
        public IWebElement ImportsPageTitle {  get { return Browser.Wd.FindElement(By.XPath(".//*[@id='mainContant']//span[contains(text(),'Imports')]")); } }
       
    }

    public class CDMExport
    {

    }
    
    public class CDMAdministration
    {
        public IWebElement BatchUpdateTitle {  get { return Browser.Wd.FindElement(By.XPath("//span[contains[.,'Batch Update']")); } }
        public IWebElement BatchUpdateStatusDropDown {  get { return Browser.Wd.FindElement(By.XPath("(//div[@class='k-multiselect-wrap k-floatwrap'])[2]")); } }
        public IWebElement BatchUpdateSearchButton {  get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='batchUpdate-btn-search']")); } }
        public IWebElement BatchUpdateWFStatusInGrid { get { return Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='batchUpdate-grid-grdBatchUpdate']//td[@data-kendo-grid-column-index='8'])[1]")); } }
        public IWebElement BatchUpdateWFUsersInGrid { get { return Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='batchUpdate-grid-grdBatchUpdate']//td[@data-kendo-grid-column-index='9'])[1]")); } }
        public IWebElement AdvanceSearchAccordian {  get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='batchUpdate-lbl-advancedSearch']")); } }
        public IWebElement WFAssignmentLink { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='batchUpdate-lbl-workflowAssignment']")); } }
        public IWebElement WFAssignmentStatusdropdown {  get { return Browser.Wd.FindElement(By.XPath("(//span[@class='k-icon k-i-arrow-60-down'])[5]")); } }
        public IWebElement WFAssignmentUsersdropdown { get { return Browser.Wd.FindElement(By.XPath("(//span[@class='k-icon k-i-arrow-60-down'])[6]")); } }
        public IWebElement WFAssignmentAssignWorkflowButtom {  get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='batchUpdate-btn-assignWorkflow']")); } }
        public IWebElement BatchUpdateMBILookupText {  get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='member-txt-hic']")); } }
        public IWebElement BatchUpdateMBILookupIcon { get { return Browser.Wd.FindElement(By.XPath("//a[@test-id='deleteSubmittedDiagnosis-a-providerLookup']")); } }
        public IWebElement ManageProvidersSearchProviderTab {  get { return Browser.Wd.FindElement(By.XPath("//li[@role='tab']//span[contains(.,'Search Provider')]")); } }
        public IWebElement ManageProviderProviderTextBox {  get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='searchProvider-txt-providerId']")); } }  
        public IWebElement ManageProvidersSearchProviderSearchBtn {  get { return Browser.Wd.FindElement(By.Id("btnSearchProviderFilter")); } }
        public IWebElement ManageProviderFirstRowEditbutton { get { return Browser.Wd.FindElement(By.XPath("(//a[@role='button'])[1]/span")); } }
        public IWebElement ManageProviderSpecialtyCodeDescription {  get { return Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='searchProvider-grid-grdSearchprovider']//td//input[@value='dataItem.specialityCodeDescription']")); } }
        public IWebElement ManageProviderFirstRowUpdateIcon {  get { return Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='searchProvider-grid-grdSearchprovider']//td//span[@class='fas fa-save'])[1]")); } }
        public IWebElement MapProviderSpecialityGrid { get { return Browser.Wd.FindElement(By.XPath("//div[@test-id='manageProvider-grid-grdMapProviderSpeciality']//table/tbody")); } }
        public IWebElement MapProviderSpecialityMappedCodesRadioButton { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='manageProvider-radio-mappedCodes']")); } }
        public IWebElement MapProviderSpecialityUnMappedCodesRadioButton { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='manageProvider-radio-unMappedCodes']")); } }
        public IWebElement MapProviderSpecialityBothCodesRadioButton { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='manageProvider-radio-bothMap']")); } }
        public IWebElement WorkflowStatusTextBox {  get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='addStatus-txt-status']")); } }
        public IWebElement WorkflowStatusAddButton {  get { return Browser.Wd.FindElement(By.XPath("(//span[contains(.,'ADD')])[1]")); } }
        public IWebElement WorkflowStatusEditStatus {  get { return Browser.Wd.FindElement(By.XPath("//input[@name='WorkStatusDesc']")); } }
        public IWebElement BatchUpdatebutton {  get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='batchUpdate-btn-batchUpdate']")); } }
        public IWebElement ViewErrorCodesLink { get { return Browser.Wd.FindElement(By.XPath("//span[@test-id='batchUpdate-span-viewErrorCodes']")); } }
        public IWebElement ErrorCodeLookupIcon {  get { return Browser.Wd.FindElement(By.XPath("//a[@test-id='batchUpdate-a-errorCodeLookup']")); } }
        public IWebElement AddWorkflowStatusInputBox {  get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='addStatus-txt-status']")); } }
        public IWebElement AddWFAddbutton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='addSubmitters-btn-save']")); } }
        public IWebElement WorkflowStatusTable {  get { return Browser.Wd.FindElement(By.XPath("//div[@test-id='addWorkflowStatus-grid-grdWorkflowStatus']/table/tbody")); } }
        public IWebElement Editworkflowstatusinoutbox {  get { return Browser.Wd.FindElement(By.XPath("//input[@name='workStatusDesc']")); } }
        public IWebElement AddSubmitterTxt {  get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='addSubmitters-txt-planId']")); } }
        public IWebElement SubmitterIdTxt { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='addSubmitters-txt-submitterId']")); } }
        public IWebElement AddSubmitterSaveButton { get { return Browser.Wd.FindElement(By.Id("btnSave")); } }
        public IWebElement AddSubmitterResultGrid { get { return Browser.Wd.FindElement(By.XPath("//div[@test-id='addSubmitters-grid-grdAddSubmitter']/table/tbody")); } }
        public IWebElement EditSubmitterIdTxt { get { return Browser.Wd.FindElement(By.XPath("//input[@name='submitterId']")); } }
        public IWebElement SubmissionDeadlineEditIcon { get { return Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='submissionDeadline-grid-grdSubmissionDeadline']//td//span[@class='fas fa-pencil-alt'])[1]")); } }
        public IWebElement SubmissionDeadlineSaveIcon { get { return Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='submissionDeadline-grid-grdSubmissionDeadline']//td//span[@class='fas fa-save'])[1]")); } }
        public IWebElement SubmissionDeadlineTMSDate { get { return Browser.Wd.FindElement(By.XPath("//span[@class='k-dateinput-wrap'][1]")); } }
        public IWebElement SubmissionDeadlineCMSDate { get { return Browser.Wd.FindElement(By.XPath("//span[@class='k-dateinput-wrap'][2]")); } }
        public IWebElement SubmissionDeadlineFromDOS { get { return Browser.Wd.FindElement(By.XPath("//span[@class='k-dateinput-wrap'][3]")); } }
        public IWebElement SubmissionDeadlineThroughDOS { get { return Browser.Wd.FindElement(By.XPath("//span[@class='k-dateinput-wrap'][4]")); } }
    }

    public class CDMErrorCodeWindow
    {
        public IWebElement ErrorCodeTextBox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='errorCodes-txt-ErrorCode']")); } }
        public IWebElement ErrorCodeSearchButton {  get { return Browser.Wd.FindElement(By.Id("btnUpdate")); } }
        public IWebElement ErrorCodeResultGrid {  get { return Browser.Wd.FindElement(By.XPath("//div[@test-id='errorCodes-grid-errorCodes']//table/tbody")); } }
        public IWebElement ErrorCodeAddButton {  get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='errorCodes-btn-add']")); } }
        public IWebElement CloseErrorCodeWindow {  get { return Browser.Wd.FindElement(By.XPath("//span[@class='k-icon k-i-x']")); } }

    }
}
