﻿
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
//using System.Windows.Forms;
using TechTalk.SpecFlow;


namespace TMSoR1.FrameworkCode.CDM
{
    [Binding]
    public class fsEncounter
    {
        private readonly ScenarioContext Context;

        public fsEncounter(ScenarioContext catalogContext)
        {
            Context = catalogContext;
        }

        [When(@"CDMMainEncounter page MBIlookup icon is clicked")]
        public void WhenCDMMainEncounterPageMBIlookupIconIsClicked()
        {
            fw.ExecuteJavascript(CDM.CDMMain.MBISearchIcon);
            
        }

        [When(@"CDMMainEncounter page MBIlookup MBI is set to ""(.*)""")]
        public void WhenCDMMainEncounterPageMBIlookupMBIIsSetTo(string p0)
        {
            string mBI = tmsCommon.GenerateData(p0);
            CDM.CDMMain.MBILookupMBITextBox.SendKeys(mBI);
            tmsWait.Hard(1);
        }

        [When(@"CDMMainEncounter page Status ""(.*)"" is selected")]
        public void WhenCDMMainEncounterPageStatusIsSelected(string p0)
        {
                                              
        }

        [When(@"CDMMainEncounter page MBILookup Search button is clicked")]
        public void WhenCDMMainEncounterPageMBILookupSearchButtonIsClicked()
        {
            fw.ExecuteJavascript(CDM.CDMMain.MBILookupSearchBtn);
        }

        [When(@"CDMMainEncounter page MBIlookup first result is selected")]
        public void WhenCDMMainEncounterPageMBIlookupFirstResultIsSelected()
        {
          
            IReadOnlyCollection<IWebElement> allrows = CDM.CDMMain.MBILookupResultGrid.FindElements(By.TagName("tr"));
            // Boolean Rsame = false;
            foreach (var row in allrows)
            {
                IWebElement FirstMBI = row.FindElement(By.XPath("td//input"));
                fw.ExecuteJavascript(FirstMBI);
                tmsWait.Hard(1);
                fw.ExecuteJavascript(CDM.CDMMain.MBILookupAddBtn);

            }
         }

        [When(@"CDMMainEncounter page MBILookup Add button is clicked")]
        public void WhenCDMMainEncounterPageMBILookupAddButtonIsClicked()
        {
            fw.ExecuteJavascript(CDM.CDMMain.MBILookupAddBtn);
        }



        [Then(@"Verify CDMMainEncounter page data displayed on MBI Field is ""(.*)""")]
        public void ThenVerifyCDMMainEncounterPageDataDisplayedOnMBIFieldIs(string p0)
        {
            string expectedMBI = tmsCommon.GenerateData(p0);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//span[@ng-bind='dataItem.hicNumber'])[1]")).Text.Contains(expectedMBI), "Data is not displayed as expected");
           
        }

        [Then(@"Verify CDMMainEncounter page error code field is empty")]
        public void ThenVerifyCDMMainEncounterPageErrorCodeFieldIsEmpty()
        {
            string expectedErrorCode = Browser.Wd.FindElement(By.XPath("(//span[@ng-bind='dataItem.errorcodes'])[1]")).Text;
            Assert.IsTrue(string.IsNullOrEmpty(expectedErrorCode));
        }
       



        [When(@"CDMMainEncounter page Search button is clicked")]
        public void WhenCDMMainEncounterPageSearchButtonIsClicked()
        {
            fw.ExecuteJavascript(CDM.CDMMain.EncounterPageSearchButton);
            tmsWait.Hard(5);
        }

        [Then(@"Verify CDMMainEncounter page result grid displayed data")]
        public void ThenVerifyCDMMainEncounterPageResultGridDisplayedData()
        {
            bool results = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='encounter-grid-encounters']")).Displayed;
            Assert.IsTrue(results, " Expected results are not displayed");
        }

        [When(@"CDMImports page import link ""(.*)"" is clicked")]
        public void WhenCDMImportsPageImportLinkIsClicked(string p0)
        {
            Assert.Fail();
        }

        [When(@"CDMMainEncounter page FilesLoaded is selected as ""(.*)""")]
        public void WhenCDMMainEncounterPageFilesLoadedIsSelectedAs(string p0)
        {
            string filename = tmsCommon.GenerateData(p0);
            //ReUsableFunctions.selectValueFromDropDown(Browser.Wd.FindElement(By.XPath("//select[@test-id='encounter-select-filesloaded']")), filename);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//span[@aria-label='select'])[2]")));
            //SelectElement filedropdown = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@test-id='encounter-select-filesloaded']")));
            //filedropdown.SelectByText(filename);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//ul[@id='formInputBoxFilesLoaded_listbox']/li[contains(.,'" + filename + "')]")));
        }

        [When(@"CDM Main Encounter page Advanced Search button is clicked")]
        public void WhenCDMMainEncounterPageAdvancedSearchButtonIsClicked()
        {
            fw.ExecuteJavascript(CDM.CDMMain.AdvanceSearch);
            tmsWait.Hard(2);
        }

        [When(@"CDM Main Encounter page Workflow Status ""(.*)"" is selected")]
        public void WhenCDMMainEncounterPageWorkflowStatusIsSelected(string p0)
        {
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='encounter-select-workflowstatus']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + p0 + "']");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
        }

        [When(@"CDM Main Encounter page Main Search first result Edit button is clicked")]
        public void WhenCDMMainEncounterPageMainSearchFirstResultEditButtonIsClicked()
        {
            IWebElement FirstResult = Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='encounter-grid-encounters']//tr//td//a[@title='Edit'])[1]"));
            fw.ExecuteJavascript(FirstResult);
            tmsWait.Hard(2);
        }

        [Then(@"Verify CDM Main Encounter page ClusterId page is displayed")]
        public void ThenVerifyCDMMainEncounterPageClusterIdPageIsDisplayed()
        {
            tmsWait.Hard(2);
            bool results = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Cluster ID')]")).Displayed;
            Assert.IsTrue(results, " Expected results are not displayed");
        }
    }
}
