﻿using System;

using System.Collections;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Windows;
using System.Drawing;
//using System.Windows.Forms;
using System.Windows.Input;
using System.IO;
using OpenQA.Selenium.Support.UI;
using System.Text;
using TMSoR1.FrameworkCode;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TMSoR1
{
    [Binding]
    public class fsCDMTask
    {
        private readonly ScenarioContext Context;

        public fsCDMTask(ScenarioContext catalogContext)
        {
            Context = catalogContext;
        }


        [When(@"CDM Imports Page ""(.*)"" link is Clicked")]
        public void WhenCDMImportsPageLinkIsClicked(string link)
        {
            tmsWait.Hard(10);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[contains(.,'"+link+"')]")));
        }

        [Then(@"on CMS page From Date is set to ""(.*)""")]
        public void ThenOnCMSPageFromDateIsSetTo(string p0)
        {
            tmsWait.Hard(10);
            By ele=By.XPath("//kendo-datepicker[@test-id='from_date']//span[@class='k-select']");
            AngularFunction.enterDate_In_Report(ele, p0);
        }

        [When(@"CDM Exports Page DOS From Date is selected as ""(.*)""")]
        public void WhenCDMExportsPageDOSFromDateIsSelectedAs(string p0)
        {
            string generatedData = tmsCommon.GenerateData(p0);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@test-id='DOSFrom']"));
          //  fw.ExecuteJavascriptSetText(ele, generatedData);
            ele.SendKeys(generatedData);
            //SelectElement ele1 = new SelectElement(Browser.Wd.FindElement(By.XPath("//*[@test-id='DOSFrom']")));
            //ele1.SelectByText(generatedData);
        }

        [When(@"CDM Exports Page DOS To Date is selected as ""(.*)""")]
        public void WhenCDMExportsPageDOSToDateIsSelectedAs(string p0)
        {
            string generatedData = tmsCommon.GenerateData(p0);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@test-id='DOSTo']"));
            // fw.ExecuteJavascriptSetText(ele, generatedData);
            ele.SendKeys(generatedData);
        }

        [When(@"CDM Exports Page ICDVersion is selected as ""(.*)""")]
        public void WhenCDMExportsPageICDVersionIsSelectedAs(string p0)
        {
            string generatedData = tmsCommon.GenerateData(p0);
            SelectElement ele= new SelectElement(Browser.Wd.FindElement(By.XPath("//*[@test-id='ICDVersion']")));
            ele.SelectByText(generatedData);
        }

        [When(@"i click on More link on File Processing Status page")]
        public void WhenIClickOnMoreLinkOnFileProcessingStatusPage()
        {
            tmsWait.Hard(4);
            IWebElement link = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='jobProcessingStatus-grid-jobs']//td/div/a/i[@class='fas fa-info-circle border-0 p-0 text-secondary'][1]"));
            
            link.Click();

        }

        [When(@"""(.*)"" is set to output folder location value")]
        public void WhenIsSetToOutputFolderLocationValue(string p0)
        {

            IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@id='jobParamListGrid']/div[2]/table/tbody/tr/td[2]/span"));
            string folderlocation = ele.Text.ToString();
            fw.setVariable(p0, folderlocation.ToString());
         
        }


        [When(@"verify there is ""(.*)"" file ""(.*)"" in output folder ""(.*)""")]
        [Given(@"verify there is ""(.*)"" file ""(.*)"" in output folder ""(.*)""")]
        public void WhenVerifyThereIsFileInOutputFolder(string fileExtension, string FileToBeSearched, string p0)
        {
            bool flag = false;
            string outputfolderpath = tmsCommon.GenerateData(p0);
            string fileName = tmsCommon.GenerateData(FileToBeSearched);
            string path = Path.GetFullPath(outputfolderpath);
            string jobId = GlobalRef.JobID.ToString();
            
            DirectoryInfo fileinfo = new DirectoryInfo(path);
            switch (fileExtension.ToLower()) {
                case "duplicate":
                    fileName = fileName + ".processing_" + jobId + ".Duplicates";
                    foreach (FileInfo f in fileinfo.GetFiles("*.Duplicates"))
                    {
                        if (f.Name.Contains(fileName))
                        {
                            flag = true;
                            Console.Write("Duplicate file exists in Output Folder: " + f.Name);
                            break;
                        }
                    }
                break;

                case "completed":
                    fileName = fileName + ".Claims.completed";
                    foreach (FileInfo f in fileinfo.GetFiles("*.Claims.completed"))
                    {
                        Console.Write(f.Name);
                        if (f.Name.Contains(fileName))
                        {
                            flag = true;
                            Console.Write("Completed file exists in Output Folder: " + f.Name);
                            break;
                        }
                    }
               break;

            }
            
            if (flag == false)
            {
                Assert.Fail("File does not exist in Output Folder");
            }
        }

        [Then(@"verify loaded file name on the CDM Dashboard is same as ""(.*)""")]
        public void ThenVerifyLoadedFileNameOnTheCDMDashboardIsSameAs(string p0)
        {
            tmsWait.Hard(5);
            string expFileName = tmsCommon.GenerateData(p0);
            IWebElement ele1 = Browser.Wd.FindElement(By.XPath("//*[@test-id='cdmDashboard-span-fileNameLR']"));
            string actFilename = ele1.Text;
            Console.Write("Loaded file name is :" + actFilename);
            Assert.AreEqual(expFileName, actFilename, "Loaded file name is not correct");
        }


        
        [Then(@"on CMS page Through Date is set to ""(.*)""")]
        public void ThenOnCMSPageThroughDateIsSetTo(string p0)
        {
            By ele=By.XPath("//kendo-datepicker[@test-id='to_date']//span[@class='k-select']");
            AngularFunction.enterDate_In_Report(ele, p0);
        }


        [Given(@"variable ""(.*)"" is set to current date")]
        [When(@"variable ""(.*)"" is set to current date")]
        [Then(@"variable ""(.*)"" is set to current date")]
        public void GivenVariableIsSetToCurrentDate(string p0)
        {
            string date = DateTime.Now.ToString("MM/dd/yyyy");
            fw.setVariable(p0, date);
        }

        [Then(@"variable ""(.*)"" is set to current calender date")]
        [Given(@"variable ""(.*)"" is set to current calender date")]
        [When(@"variable ""(.*)"" is set to current calender date")]
        public void ThenVariableIsSetToCurrentCalenderDate(string p0)
        {
            string date = DateTime.Now.ToString("yyyy-MM-dd 00:00:00.000");
            fw.setVariable(p0, date);
        }


        [Given(@"variable ""(.*)"" is set to ""(.*)"" months after current date")]
        public void GivenVariableIsSetToMonthsAfterCurrentDate(string p0, int months)
        {
            DateTime Currdate = DateTime.Now;
            string date= Currdate.AddMonths(months).ToString("MM/dd/yyyy");
            fw.setVariable(p0, date);
        }



        [Then(@"on CDM report page is Process Date set to ""(.*)""")]
        public void ThenOnCDMReportPageIsProcessDateSetTo(string p0)
        {
            string generateddata = tmsCommon.GenerateData(p0);
            //IWebElement multiSelect = Browser.Wd.FindElement(By.XPath("//multiselect[@test-id='Process_Date']"));
            //fw.ExecuteJavascript(multiSelect);
           // tmsWait.Hard(3);
            IWebElement option = Browser.Wd.FindElement(By.XPath("//a[contains(.,'" + generateddata + "')]"));
            fw.ExecuteJavascript(option);
          }


        [Then(@"verify Plan Number text on the report")]
        [When(@"verify Plan Number text on the report")]
        public void ThenVerifyPlanNumberTextOnTheReport()
        {
            Browser.SwitchToChildWindow();
            string planNumberValue = Browser.Wd.FindElement(By.XPath("//table[@cols='15']/tbody/tr[6]/td[4]/div/div")).Text.ToString();
            Assert.AreEqual("ALL", planNumberValue, "Plan Number Value is incorrect on the report");
        }

        [Then(@"verify Provider Type text on the report")]
        [When(@"verify Provider Type text on the report")]
        public void ThenVerifyProviderTypeTextOnTheReport()
        {
            Browser.SwitchToChildWindow();
            string value = Browser.Wd.FindElement(By.XPath("//table[@cols='15']/tbody/tr[7]/td[3]/div/div")).Text.ToString();
            Assert.AreEqual("ALL", value, "Provider Type Value is incorrect on the report");
        }

        [Then(@"verify Process Date on the report should be ""(.*)""")]
        [When(@"verify Process Date on the report should be ""(.*)""")]
        public void ThenVerifyProcessDateOnTheReportShouldBe(string p0)
        {
            Browser.SwitchToChildWindow();
            string generatedData = tmsCommon.GenerateData(p0);
            string value = Browser.Wd.FindElement(By.XPath("//table[@cols='15']/tbody/tr[8]/td[3]/div/div")).Text.ToString();
            Assert.AreEqual(generatedData, value, "Process Date Value is incorrect on the report");
        }
               

        [Then(@"verify Year of DOS text on the report")]
        [When(@"verify Year of DOS text on the report")]
        public void ThenVerifyYearOfDOSTextOnTheReport()
        {
            Browser.SwitchToChildWindow();
            string value = Browser.Wd.FindElement(By.XPath("//table[@cols='15']/tbody/tr[9]/td[3]/div/div")).Text.ToString();
            Assert.AreEqual("ALL", value, "Year of DOS Value is incorrect on the report");
        }

        [Then(@"verify there should be a record for ""(.*)"" on the report")]
        [When(@"verify there should be a record for ""(.*)"" on the report")]
        public void ThenVerifyThereShouldBeARecordForOnTheReport(string p0)
        {
            Browser.SwitchToChildWindow();
            string generatedData = tmsCommon.GenerateData(p0);
            string value = Browser.Wd.FindElement(By.XPath("//table[@cols='13']/tbody/tr[4]/td[1]/div/div")).Text.ToString();
            Assert.AreEqual(generatedData, value, "There is no record for the process date on the report");
        }



        [Then(@"Verify CDM Table has ""(.*)"" Greater than Zero")]
        public void ThenVerifyCDMTableHasGreaterThanZero(string p0)
        {
            string totalrecords = tmsCommon.GenerateData(p0);
            bool ispresent = false;
            if(Int32.Parse(totalrecords) > 0 )
            {
                ispresent = true;
            }
            Assert.IsTrue(ispresent, "CDM Table has record equal to zero or null");
        }





        [Then(@"Verify CDM Table has ""(.*)"" Equal to Zero")]
        public void ThenVerifyCDMTableHasEqualToZero(string p0)
        {
            string totalrecords = tmsCommon.GenerateData(p0);
            bool ispresent = false;
            if (Int32.Parse(totalrecords) == 0)
            {
                ispresent = true;
            }
            Assert.IsTrue(ispresent, "CDM Table has record greater zero or null");
        }






        [When(@"CDM Imports Page Load RAM Extract Exported File")]
        public void WhenCDMImportsPageLoadRAMExtractExportedFile()
        {
            string downloadPath = AngularFunction.returnSystemdownloadFolderPath();
          
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
            int filecount = newFilePaths.Length;
            var FileName = Path.Combine(downloadPath, newFilePaths[filecount - 1]);

            Browser.Wd.FindElement(By.CssSelector("[test-id='import-input-fileUpload'] input")).SendKeys(FileName);
            tmsWait.Hard(2);
            EAM.LoadEAFFile.Upload.Click();
            tmsWait.Hard(30);
        }




        [When(@"CDM Imports Page ALM Test ID ""(.*)"" attached File ""(.*)"" is renamed and imported with New File Name ""(.*)"" in EAM")]
        public void WhenCDMImportsPageALMTestIDAttachedFileIsRenamedAndImportedWithNewFileNameInEAM(string p0, string p1, string p2)
        {
            
            string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);

            Boolean keepTrying = true;
            int maxAttempts = 11;
            int thisAttempt = 0;
            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            // We added this code for Jenkins run
            string SourceFileLocation = "C:\\SourceFile\\";
            Boolean didUpload = false;
            string source = SourceFileLocation + p1_gen;
            try
            {
                if (Directory.Exists(SourceFileLocation))
                {
                    if (!File.Exists(controllerFileLocation))
                    {
                        File.Copy(SourceFileLocation + p1_gen, controllerFileLocation + Path.GetFileName(source));
                    }
                }
            }
            catch
            {
                fw.ConsoleReport(" There is no file found on Source File folder");
            }
            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");
            if (File.Exists(controllerFileLocation + p1_gen))
            {
                File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen, true);
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");

            }
            //else
            //{
            //    Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

            //    didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            //}
            if (didUpload)
            {
                while (keepTrying)
                {
                    string FileName = "C:\\Temp\\" + p1_gen;


                    string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen);
                    //Move method moves an existing file to a new location with the same or a different file name, move delete original file
                    File.Move(@FileName, @newFileName);
                    FileName = newFileName;
                    //EAM.LoadEAFFile.SelectFiles.SendKeys(FileName);
                    Browser.Wd.FindElement(By.CssSelector("input[name='files']")).SendKeys(FileName);
                    tmsWait.Hard(2);
                    EAM.LoadEAFFile.Upload.Click();
                    tmsWait.Hard(30);

                    //try
                    //{
                    //    thisResponse = EAM.LoadEAFFile.UIModResponseMessage.Text;
                    //}
                    //catch
                    //{
                    //    if (thisResponse == "The specified filename does not match for this file type. Please verify the file or modify the filename.")
                    //    {
                    //        keepTrying = false;
                    //        Console.WriteLine("File load failed with message [" + thisResponse + "]");
                    //        break; //  Exit from While loop
                    //    }
                    //}

                    break; // Exit from while loop
                }

            }

            try
            {
                System.IO.DirectoryInfo di = new DirectoryInfo("c:\\Temp\\");

                foreach (FileInfo file in di.GetFiles())
                {
                    file.Delete();
                }
                foreach (DirectoryInfo dir in di.GetDirectories())
                {
                    dir.Delete(true);
                }
            }
            catch
            {

            }
        }

        
    }
}
