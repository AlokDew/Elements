﻿

using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1
{
    class cfUserManagementAngular
    {

        public static ExternalSystemAngular ExternalSystemAngular { get { return new ExternalSystemAngular(); } }
        public static UserManagementAngular UserManagementAngular { get { return new UserManagementAngular(); } }
    }

    [Binding]
    public class ExternalSystemAngular
    {
        public IWebElement IdentityServer { get { return Browser.Wd.FindElement(By.CssSelector("[title='Identity Server']")); } }
        public IWebElement NavigateIcon { get { return Browser.Wd.FindElement(By.XPath("//div[@test-id='identityserver-grid-grdidentityserver']//a/span[@class='NavigateIcon']")); } }
        
    }
    [Binding]
    public class UserManagementAngular
    {
        public IWebElement addUser { get { return Browser.Wd.FindElement(By.XPath("//button[contains(.,'ADD USER')]")); } }
        public IWebElement UPDATE { get { return Browser.Wd.FindElement(By.XPath("//button[contains(.,'UPDATE')]")); } }
        public IWebElement CANCEL { get { return Browser.Wd.FindElement(By.XPath("//button[contains(.,'CANCEL')]")); } }
        public IWebElement loginName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='edit-user-input-login-name']")); } }
        public IWebElement NoActive { get { return Browser.Wd.FindElement(By.XPath("//label[@for='inActiveUser']")); } }
        public IWebElement password { get { return Browser.Wd.FindElement(By.XPath("//input[@modelname='New Password']")); } }
        public IWebElement confirmPassword { get { return Browser.Wd.FindElement(By.XPath("//input[@modelname='Confirm Password']")); } }
        public IWebElement displayName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='EditUser-Span-ErrorMessage-DisplayName']")); } }
        public IWebElement firstName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='edit-user-input-first-name']")); } }
        public IWebElement lastName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='edit-user-input-last-name']")); } }
        public IWebElement emailID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='EmailUser-Input-email']")); } }
        public IWebElement phone { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='EditUser-Input-PhoneNumber']/input")); } }
        public IWebElement activeYesOptionButton { get { return Browser.Wd.FindElement(By.XPath("//input[@id='activeUser']")); } }
        public IWebElement RoleDropdown { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='edit-user-select-role']//span[@class='k-select']")); } }
        public IWebElement AddRecordButton { get { return Browser.Wd.FindElement(By.XPath("//button[contains(.,'Add Record')]")); } }
        public IWebElement ADDButton { get { return Browser.Wd.FindElement(By.CssSelector("[name='update']")); } }

        public IWebElement MapEAMRoleDropdown { get { return Browser.Wd.FindElement(By.XPath("(//kendo-dropdownlist[@test-id='edit-user-select-eam-role']//span[@class='k-select'])[1]")); } }
        public IWebElement ApplicantID { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='edit-user-select-application']//span[@class='k-select']")); } }
        public IWebElement RoleName { get { return Browser.Wd.FindElement(By.XPath("(//kendo-dropdownlist[@test-id='edit-user-select-role']//span[@class='k-select'])[2]")); } }
        public IWebElement SetDefaultApplication { get { return Browser.Wd.FindElement(By.XPath("(//kendo-dropdownlist[@test-id='edit-user-select-eam-role']//span[@class='k-select'])[2]")); } }
        public IWebElement SaveButton { get { return Browser.Wd.FindElement(By.XPath("//span[@class='fas fa-save']")); } }

        public IWebElement TC90Checkbox { get { return Browser.Wd.FindElement(By.CssSelector("[name='tc90appRole']")); } }
        public IWebElement StatusOverrideCheckbox { get { return Browser.Wd.FindElement(By.CssSelector("[name='statusoverrideRole']")); } }

        

        



    }
}
