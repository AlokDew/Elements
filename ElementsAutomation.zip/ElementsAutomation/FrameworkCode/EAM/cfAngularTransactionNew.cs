﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1
{

        [Binding]
        public class cfAngularTransaction
        {

            public static AngularNewTransaction AngularNewTransaction { get { return new AngularNewTransaction(); } }
        }

    [Binding]
    public class AngularNewTransaction
    {
        public IWebElement TCCode { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='transaction-select-code']//span[@class='k-select']")); } }
        public IWebElement MBI { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'MBI')]/parent::div/div//input")); } }
        public IWebElement effectiveDate { get { return Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='DemographicDetailsEffectiveDate']//span[@role='button']")); } }
        public IWebElement SexDrp { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Gender')]/parent::div//span[@class='k-select']")); } }
        public IWebElement PlanIDDrp { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Plan ID')]/parent::div//span[@class='k-select']")); } }
        public IWebElement typeOfApplicationDrp { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='transaction-select-typeOfApplication']//span[@class='k-select']")); } }
        public IWebElement salesRepDrp { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Name of Agent/Broker')]/parent::div//span[@class='k-select']")); } }
        public IWebElement ElectionTypeDrp { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Election Type')]/parent::div//span[@class='k-select']")); } }

        public IWebElement ZipCode { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Zip')]/parent::div//input)[1]")); } }
        public IWebElement AddressOne { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Residence Address 1')]/parent::div//input")); } }
        public IWebElement AddressTwo { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Residence Address 2')]/parent::div//input")); } }
        public IWebElement PBPDrp { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'PBP')]/parent::div//span[@class='k-select']")); } }
        public IWebElement PWODrp { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Prem. Withhold Option')]/parent::div//span[@class='k-select']")); } }
        public IWebElement FirstName { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'First Name')]/parent::div/div//input)[1]")); } }
        public IWebElement EGHP { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'EGHP')]/parent::div//span[@class='k-select']")); } }
        public IWebElement receiptDate { get { return Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='DemographicDetailsReceiptDate']//span[@role='button']")); } }
        public IWebElement DOB { get { return Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='DemographicDetailsDob']//span[@role='button']")); } }

    
        public IWebElement signDate { get { return Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='DemographicDetailsSignatureDate']//span[@role='button']")); } }
        public IWebElement PrimaryRxID { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Primary Rx ID')]/parent::div//input")); } }
        public IWebElement lastName { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Last Name')]/parent::div/div//input)[1]")); } }

        public IWebElement AccessibilityFormat { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Accessibility Format')]/parent::div//span[@class='k-select']")); } }
        public IWebElement DateEditOvr { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Date Edit Override')]/parent::div//span[@class='k-select']")); } }






    }
}
