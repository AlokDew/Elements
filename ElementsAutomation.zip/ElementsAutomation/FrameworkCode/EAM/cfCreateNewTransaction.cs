﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1
{
    class cfCreateNewTransaction
    {
        public static CreateNewTransaction CreateNewTransaction { get { return new CreateNewTransaction(); } }
    }


    [Binding]
    public class CreateNewTransaction
    {
        public IWebElement MBI { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtHic_01")); } }
        public IWebElement SearchButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSearch")); } }
    }
}
