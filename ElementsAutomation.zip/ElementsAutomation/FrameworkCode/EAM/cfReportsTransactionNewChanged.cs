﻿using OpenQA.Selenium;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.EAM
{
    [Binding]
    public class cfReportsTransactionNewChanged
    {

        public static IWebElement reportsLinkUIMod { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_EamNavigation_uiModReportsHyperLink")); } }        
        public static IWebElement newChangedlnk { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='New/changed Transaction']")); } }        
        public static IWebElement runReportButton{ get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='report-btn-runReport']")); } }                
        public static IWebElement planIDDropdown { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='PLAN_ID']")); } }                
        public static IWebElement pbpIDDropdown { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id = 'PBPID']")); } }
        public static IWebElement pbpIDDropdownSelect { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PBPID']")); } }
        public static IWebElement transCode { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='TRANS_CODE']")); } }
        public static IWebElement transCoderopdownSelect { get { return Browser.Wd.FindElement(By.XPath("//multiselect[@test-id='TRANS_CODE']//ul/li[contains(.,'61')]")); } }
        public static IWebElement effectivedate { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='EffDate_From']")); } }
        
        






    }
}
