﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1
{
    [Binding]
    class cfUIMODMemberCreation
    {
        public static UIMODMemberCreationBasic UIMODMemberCreation { get { return new UIMODMemberCreationBasic(); } }
        public static UIMODMemDemographics UIMODMemDemographics { get { return new UIMODMemDemographics(); } }
        public static UIMODMemRxDetails UIMODMemRxDetails { get { return new UIMODMemRxDetails(); } }
        public static UIMODMemContacts UIMODMemContacts { get { return new UIMODMemContacts(); } }
        public static UIMODSpan UIMODSpan { get { return new UIMODSpan(); } }
        public static UIMODEligibility UIMODEligibility { get { return new UIMODEligibility(); } }
        public static UIMODTRR UIMODTRR { get { return new UIMODTRR(); } }
        public static UIMODIDHistory UIMODIDHistory { get { return new UIMODIDHistory(); } }
        public static UIMODCorrespondence UIMODCorrespondence { get { return new UIMODCorrespondence(); } }
        public static UIMODTransaction UIMODTransaction { get { return new UIMODTransaction(); } }
        public static UIMODPremiumLIS UIMODPremiumLIS { get { return new UIMODPremiumLIS(); } }
        public static UIMODPayment UIMODPayment { get { return new UIMODPayment(); } }
        public static UIMODProvider UIMODProvider { get { return new UIMODProvider(); } }
        public static UIMODOECSales UIMODOECSales { get { return new UIMODOECSales(); } }
        public static UIMODPlanDefinedFields UIMODPlanDefinedFields { get { return new UIMODPlanDefinedFields(); } }
        public static UIMODTransactions UIMODTransactions { get { return new UIMODTransactions(); } }


    }


    [Binding]
    public class UIMODTransactions
    {
        public IWebElement AddTransLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='transactions-link-AddTransaction']")); } }
        public IWebElement TransPageRXID { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Primary Rx ID')]/parent::div//input")); } }
        public IWebElement PWOOption { get { return Browser.Wd.FindElement(By.XPath("//*[@id='div_DemographicDetailsPremWithholdOption']//span[@class='k-input ng-scope']")); } }

    }


    [Binding]
    public class UIMODPlanDefinedFields
    {
        public IWebElement GroupDropDownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='group_listbox']")); } }
        public IWebElement GroupDropDown { get { return Browser.Wd.FindElement(By.XPath("//*[@aria-owns='group_listbox']/span/span[@class='k-input ng-scope']")); } }
        public IWebElement SubGroupDropDownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='subGroup_listbox']")); } }
        public IWebElement ClassDropDownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='class_listbox']")); } }
        public IWebElement MedicalIDDropDownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='medicalProductId_listbox']")); } }
        public IWebElement PharmcyIDDropDownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='pharmacyId_listbox']")); } }
        public IWebElement DentalIDDropDownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='dentalId_listbox']")); } }
        public IWebElement VisionDropDownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='visionId_listbox']")); } }
        public IWebElement UseMappingCheckbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-chk-useMapping']")); } }
        public IWebElement Source { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-input-entrySource']")); } }
        public IWebElement Plan1 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-input-plan1']")); } }
        public IWebElement Plan2 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-input-plan2']")); } }
        public IWebElement Plan3 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-input-plan3']")); } }
        public IWebElement Plan4 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-input-plan4']")); } }
        public IWebElement Plan5 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-input-plan5']")); } }
        public IWebElement Plan6 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-input-plan6']")); } }
        public IWebElement Plan7 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-input-plan7']")); } }
        public IWebElement Plan8 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-input-plan8']")); } }
        public IWebElement Plan9 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-input-plan9']")); } }
        public IWebElement Plan10 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-input-plan10']")); } }

        public IWebElement Plan1Label { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-lbl-plan1']")); } }
        public IWebElement Plan2Label { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-lbl-plan2']")); } }
        public IWebElement Plan3Label { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-lbl-plan3']")); } }
        public IWebElement Plan4Label { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-lbl-plan4']")); } }
        public IWebElement Plan5Label { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-lbl-plan5']")); } }
        public IWebElement Plan6Label { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-lbl-plan6']")); } }
        public IWebElement Plan7Label { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-lbl-plan7']")); } }
        public IWebElement Plan8Label { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-lbl-plan8']")); } }
        public IWebElement Plan9Label { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-lbl-plan9']")); } }
        public IWebElement Plan10Label { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-lbl-plan10']")); } }
        public IWebElement SendPlan10OnLegacyCheckbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-chk-plan10Legacy']")); } }
        //public IWebElement SaveBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberViewEdit-btn-save']")); } }
    }
    [Binding]
    public class UIMODOECSales
    {
        public IWebElement OECSalesLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberOecSales-lbl-OecSales']")); } }
        public IWebElement OECFileNumber { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberOecSales-input-oecFileNumber']")); } }
        public IWebElement OECFileDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberOecSales-input-oecFileDate']")); } }
        public IWebElement OECSubmitTime { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberOecSales-input-oecSubmitTime']")); } }
        public IWebElement OECCountry { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberOecSales-input-oecCounty']")); } }
        public IWebElement MemberOtherInsCheckbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberOecSales-chk-memberOtherIns']")); } }
        public IWebElement OtherInsID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberOecSales-input-OtherInsId']")); } }
        public IWebElement OtherInsGroup { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberOecSales-input-OtherInsGroup']")); } }
        public IWebElement MemberLongTermCheckbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberOecSales-chk-memberLongTerm']")); } }
        public IWebElement InstitutionName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberOecSales-input-institutionName']")); } }
        public IWebElement InstitutionAddress { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberOecSales-input-institutionAddress']")); } }
        public IWebElement InstitutionPhone { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberOecSales-input-institutionPhone']")); } }
        public IWebElement EmailAddress { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberOecSales-input-emailAddress']")); } }
        public IWebElement MemberESRDcheckbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberOecSales-chk-memberEsrd']")); } }
        public IWebElement MemberMcaidcheckbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberOecSales-chk-memberMcAid']")); } }
        public IWebElement MemberWorkingcheckbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberOecSales-chk-memberWorking']")); } }
        public IWebElement MedcaidNumber { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberOecSales-input-medicaidNumber']")); } }
        public IWebElement SEPReason { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberOecSales-input-sepReason']")); } }
        public IWebElement SEPCMSReasonCode { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberOecSales-input-sepCmsReason']")); } }
        public IWebElement SalesLocation { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberOecSales-input-salesLocation']")); } }
        public IWebElement SalesDate { get { return Browser.Wd.FindElement(By.CssSelector("[aria-controls='selSalesDate_dateview']")); } }
        public IWebElement SalesRepDroDownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='inputSalesRep_listbox']")); } }
    }
    [Binding]
    public class UIMODTRR
    {
        public IWebElement UIMODNoTRRMessage { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='trrView-span-noTrrRecords']")); } }
    }
    [Binding]
    public class UIMODProvider
    {
        public IWebElement FirstName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='provider-input-firstName']")); } }
        public IWebElement FirstNameAngular { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='provider-input-firstName']")); } }
        public IWebElement LastName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='provider-input-lastname']")); } }
        public IWebElement PCPID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='provider-input-pcpId']")); } }
        public IWebElement PCPPrvID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='provider-input-pcpPrvId']")); } }
        public IWebElement PCPPrvIDAngular { get { return Browser.Wd.FindElement(By.XPath("(//input[@test-id='provider-input-pcpId'])[2]")); } }
        
        public IWebElement HospName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='provider-input-hospName']")); } }
        public IWebElement HospID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='provider-input-hospId']")); } }
        public IWebElement HospPrvID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='provider-input-hospPrvId']")); } }
        public IWebElement GynName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='provider-input-gynName']")); } }
        public IWebElement GynPCPID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='provider-input-gynPcpId']")); } }
        public IWebElement GynPCPPrv { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='provider-input-gynPcpPrv']")); } }
        public IWebElement MPName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='provider-input-mpName']")); } }
        public IWebElement MPID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='provider-input-mpId']")); } }
        public IWebElement MPPrv { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='provider-input-mpPrv']")); } }
        public IWebElement DentalName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='provider-input-dentalName']")); } }
        public IWebElement DentalID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='provider-input-dentalId']")); } }
        public IWebElement DentalPrv { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='provider-input-dentalPrv']")); } }
        public IWebElement IPAGroupID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='provider-input-ipaGroupId']")); } }
        public IWebElement MedicalRec { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='provider-input-medicalRec']")); } }
        public IWebElement HospicePrv { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='provider-input-hospicePrv']")); } }
    }
    [Binding]
    public class UIMODPayment
    {
        public IWebElement ContractType { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='payment-input-contractType']")); } }
        public IWebElement BillingMethod { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='payment-input-billingType']")); } }
        public IWebElement PaymentMethod { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='payment-input-paymentMethod']")); } }
        public IWebElement SupressStatementCheckbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='payment-chk-suppressStmt']")); } }
        public IWebElement SupressDate { get { return Browser.Wd.FindElement(By.CssSelector("[aria-controls='selSuppressDate_dateview']")); } }
        public IWebElement Bank { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='payment-input-bank']")); } }
        public IWebElement AccountTypeDropDownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='inputAccountType_listbox']")); } }
        public IWebElement BankAccountTypeDropDownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='inputBankAccountType_listbox']")); } }
        public IWebElement TrusteeRouting { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='payment-input-trusteeRouting']")); } }
        public IWebElement BankACHNumber { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='payment-input-bankAchNumber']")); } }
        public IWebElement AccountNumber { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='payment-input-accountNumber']")); } }
        public IWebElement Payer { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='payment-input-payer']")); } }
        public IWebElement CardExpirationDate { get { return Browser.Wd.FindElement(By.CssSelector("[aria-controls='selCardExpiration_dateview']")); } }
        public IWebElement BillingProfileID { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='inputBillingProfileId_listbox']")); } }
    }
    [Binding]
    public class UIMODPremiumLIS
    {
        public IWebElement UIMODPartCPremium { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='premiumLis-input-partCPremium']")); } }
        public IWebElement UIMODPartDPremium { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='premiumLis-input-partDPremium']")); } }
        public IWebElement UIMODBillAmount { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='premiumLis-input-billAmount']")); } }
        public IWebElement UIMODBillEffectiveDate { get { return Browser.Wd.FindElement(By.CssSelector("[aria-controls='billingEffDate_dateview']")); } }
        public IWebElement UIMODUncoveredMonths { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='premiumLis-input-uncoveredMonths']")); } }
        public IWebElement UIMODCreditcoverDropDownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='creditCover_listbox']")); } }

        public IWebElement UIMODEmployerSubsOverCheckbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='premiumLis-chk-chkEmplSubOverride']")); } }
        public IWebElement UIMODPWODropdownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='pwOption_listbox']")); } }
        public IWebElement UIMODPWODropdownListAngular { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'PW Option')]/parent::div//span[@class='k-input']")); } }
        public IWebElement UIMODLEPAmount { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='premiumLis-input-lepAmt']")); } }
        public IWebElement UIMODLEPWaivedAmount { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='premiumLis-input-lepWaivedAmt']")); } }
        public IWebElement UIMODLEPSubsAmount { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='premiumLis-input-lepSubsAmt']")); } }
        public IWebElement UIMODEmployerPaysLEPCheckbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='premiumLis-chk-chkEgPaysLep']")); } }
        public IWebElement UIMODEmployerGroupNumber { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='premiumLis-select-emplGroupNum']")); } }
        public IWebElement UIMODEmployerName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='premiumLis-input-employerName']")); } }
        public IWebElement UIMODOtherInsName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='premiumLis-input-otherInsurance']")); } }
        public IWebElement UIMODEmpDialogEmployerGroupNumber { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='employerGroup-txt-employerGroupNumber']")); } }
        public IWebElement UIMODEmpDialogEmployerName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='employerGroup-txt-employerName']")); } }
        public IWebElement UIMODEmpDialogSave { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='employerGroup-btn-save']")); } }
        public IWebElement UIMODEmployerPlusSymbol { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='premiumLis-lbl-emplGroupNum']/parent::div//i")); } }
        public IWebElement UIMODLISDropdownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='lisLevel_listbox']")); } }
        public IWebElement UIMODCreditCoverdownList { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='premiumLis-lbl-creditCover']/parent::div//span[@role='listbox']")); } }
        public IWebElement UIMODCopayCatDropdownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='coPayCat_listbox']")); } }
        public IWebElement UIMODLISTypeDropdownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='lisType_listbox']")); } }
        public IWebElement UIMODLISStartDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='premiumLis-txt-startDate']")); } }
        public IWebElement UIMODLISEndDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='premiumLis-txt-endDate']")); } }
        //public IWebElement UIMODLISEndDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='premiumLis-txt-endDate']")); } }
        public IWebElement UIMODLISSaveBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='premiumLis-btn-save']")); } }

    }


    [Binding]
    public class UIMODTransaction
    {

        public IWebElement UIMODMemberTransactionLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberViewEdit-lbl-transactions']")); } }
        public IWebElement UIMODNoTransactionMessage { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='transactions-span-noTransactionsMsg']")); } }
        public IWebElement AddTransaction { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='transactions-link-AddTransaction']")); } }
        public IWebElement ReplyCodeTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ApplicationDispositionReplyCode']")); } }
        public IWebElement TRRRespDateTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ApplicationDispositionTRRResponseDate']")); } }
        public IWebElement ReplyDescTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ApplicationDispositionReplyDescrip']")); } }
    }

    [Binding]
    public class UIMODCorrespondence
    {
        public IWebElement UIMODOnDemandLetterOptBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='correspondence-radio-onDemand']")); } }
        public IWebElement UIMODPreCMSLettersOptBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='correspondence-radio-preCms']")); } }
        public IWebElement UIMODPostCMSLettersOptBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='correspondence-radio-postCms']")); } }
        public IWebElement UIMODLettersNameDropDownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='inputBoxlLtterTypes_listbox']")); } }
        public IWebElement AngularUIMODLettersNameDropDownList { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Letter Name')]/parent::div/parent::div//span[@class='k-select']")); } }
        public IWebElement UIMODOn_DemandPlanDefinedField { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='correspondence-input-planDefinedField']")); } }
        public IWebElement UIMODAddToQueueBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='correspondence-btn-addToQueue']")); } }
        public IWebElement UIMODAddTransactionBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='correspondence-btn-addTransaction']")); } }
        public IWebElement UIMODAddTRRBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='correspondence-btn-addTrr']")); } }
        public IWebElement UIMODNoCorrespondenceHistoryMessage { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='correspondence-span-noCorrespondenceHistoryMsg']")); } }
        public IWebElement UIMODLettersName { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='inputBoxlLtterTypes_listbox']")); } }
        public IWebElement UIMODSelectTransaction { get { return Browser.Wd.FindElement(By.XPath("//form[@id='frmTrrTransactionDetails']//div[2]/table/tbody/tr/td[1]")); } }
        public IWebElement AngularUIMODSelectTransaction { get { return Browser.Wd.FindElement(By.XPath("//*[@id='trrTransactionDetailsGrid']//table//tr[1]//td[1]//input")); } }
    }

    [Binding]
    public class UIMODIDHistory
    {
        public IWebElement UIMODUpdateBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='idHistory-btn-update']")); } }
        public IWebElement UIMODNoIDHistoryMessage { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='idHistory-btn-update']")); } }
    }

    [Binding]
    public class UIMODEligibility
    {
        public IWebElement UIMODPlanPartAEffectiveDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='eligibility-txt-planPartAEffDate']")); } }
        public IWebElement UIMODCMSPartAEffectiveDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='eligibility-txt-cmsPartAEff']")); } }
        public IWebElement UIMODCMSPartAEndDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='eligibility-txt-cmsPartAEnd']")); } }

        public IWebElement UIMODPlanPartBEffectiveDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='eligibility-txt-planPartBEffDate']")); } }
        public IWebElement UIMODCMSPartBEffectiveDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='eligibility-txt-txtCmsPartBEff']")); } }
        public IWebElement UIMODCMSPartBEndDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='eligibility-txt-txtCmspartBEnd']")); } }

        public IWebElement UIMODPlanPartDEffectiveDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='eligibility-txt-planPartDEffDate']")); } }
        public IWebElement UIMODCMSPartDEffectiveDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='eligibility-txt-txtCmsPartDEff']")); } }
        public IWebElement UIMODCMSPartDEndDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='eligibility-txt-txtCmsPartDEnd']")); } }

        public IWebElement UIMODCountyCode { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='eligibility-span-txtCountyCode']")); } }
        public IWebElement UIMODStateCode { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='eligibility-txt-txtStateCode']")); } }
        public IWebElement ESRD { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='eligibility-txt-txtEsrd']")); } }
    }


    [Binding]
    public class UIMODSpan
    {
        public IWebElement SpansLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberSpanInfo-lbl-span']")); } }
        public IWebElement UIMODPlanIDDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='planIds_listbox']")); } }
        public IWebElement UIMODStatusTypeDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='statusTypes_listbox']")); } }
        public IWebElement UIMODStatusTypeDropdownOptions { get { return Browser.Wd.FindElement(By.XPath("//*[@id='statusTypes']/option")); } }
        public IWebElement UIMODSpanValue { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='memberSpan-input-riskType']")); } }
        public IWebElement UIMODStartDate { get { return Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='memberSpan-txt-startDate']//span[@class='k-select']")); } }
        public IWebElement UIMODEndDate { get { return Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='memberSpan-txt-endDate']//span[@class='k-select']")); } }
        public IWebElement UIMODEndDateTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberSpan-txt-endDate']")); } }
        public IWebElement UIMODStartDateTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberSpan-txt-startDate']")); } }
        public IWebElement UIMODSave { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberSpan-btn-save']")); } }
        public IWebElement UIMODReset { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberSpan-btn-reset']")); } }
        public IWebElement UIMODNoRecordsMessage { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDemographics-lbl-noSpanRecords']")); } }
    }
    [Binding]
    public class UIMODMemContacts
    {
        public IWebElement UIMODPrimaryAddressTypeDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='addressTypes_listbox']")); } }
        public IWebElement UIMODPrimaryAddress1 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberContacts-input-address1']")); } }
        public IWebElement UIMODPrimaryAddress2 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberContacts-input-address2']")); } }
        public IWebElement UIMODPrimaryPhone { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberContacts-input-phone']")); } }
        public IWebElement UIMODPrimaryCity { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberContacts-input-city']")); } }
        public IWebElement UIMODPrimaryState { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberContacts-txt-state']")); } }
        public IWebElement UIMODPrimaryZip { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberContacts-txt-zip']")); } }
        public IWebElement UIMODPrimarySCC { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberContacts-input-scc']")); } }
        public IWebElement UIMODPrimaryCountyDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='county_listbox']")); } }


        public IWebElement UIMODPrimarySCCLookup { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberContacts-a-sccLookup']")); } }
        public IWebElement UIMODPrimarySCCLookupSCCTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='sccLookup-txt-scc']")); } }
        public IWebElement UIMODPrimarySCCLookupCountyTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='sccLookup-txt-county']")); } }
        public IWebElement UIMODPrimarySCCLookupStateTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='sccLookup-txt-state']")); } }
        public IWebElement UIMODPrimarySCCLookupSearchBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='sccLookup-btn-search']")); } }
        public IWebElement UIMODPrimarySCCLookupResetBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='sccLookup-btn-reset']")); } }

        public IWebElement UIMODLetterTypeDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='inputBoxlLtterTypes_listbox']")); } }
        public IWebElement UIMODSecondAddressTypeDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='secondaryAddressType_listbox']")); } }
        public IWebElement UIMODSecondAddress1 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberContacts-input-c2NdAddress1']")); } }
        public IWebElement UIMODSecondAddress2 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberContacts-input-c2NdAddress2']")); } }
        public IWebElement UIMODSecondPhone { get { return Browser.Wd.FindElement(By.XPath("(//input[@test-id='memberContacts-input-phone'])[2]")); } }
        public IWebElement UIMODSecondCity { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberContacts-input-c2NdCity']")); } }
        public IWebElement UIMODSecondState { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberContacts-txt-c2ndState']")); } }
        public IWebElement UIMODSecondZip { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberContacts-txt-c2ndZip']")); } }
        public IWebElement UIMODSecondCountyDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='secondCounties_listbox']")); } }

        public IWebElement UIMODDecisionResponsibilityDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='decisionResponsibilities_listbox']")); } }
        public IWebElement UIMODResponsibilityName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberContacts-input-responsibilityName']")); } }
        public IWebElement UIMODResponseAddress { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberContacts-input-responseAddress']")); } }
        public IWebElement UIMODResponsePhone { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberContacts-input-responseTelNum']")); } }
        public IWebElement UIMODResponseCity { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberContacts-input-responseCity']")); } }
        public IWebElement UIMODResponseState { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberContacts-txt-responseState']")); } }
        public IWebElement UIMODResponseZip { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberContacts-txt-responseZip']")); } }
        public IWebElement UIMODResponseRelationDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='responseRelations_listbox']")); } }

        public IWebElement UIMODResponseRelationDropdown { get { return Browser.Wd.FindElement(By.Id("responseRelations")); } }

        public IWebElement UIMODEmergencyContact { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberContacts-input-emergencyContact']")); } }
        public IWebElement UIMODEmergencyRelation { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberContacts-input-emergencyRelation']")); } }
        public IWebElement UIMODEmergenceyPhone { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberContacts-input-emergencyPhone']")); } }


    }
    [Binding]
    public class UIMODMemberCreationBasic
    {
        public IWebElement UIMODMBI { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-txt-mbi']")); } }
        public IWebElement AddMBI { get { return Browser.Wd.FindElement(By.XPath("//input[@placeholder='Add MBI']")); } }
        public IWebElement ExpanAllBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='membercontent-btn-expandAndCollapse']")); } }
        public IWebElement PlanDefinedSection { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberPlanDefinedFields-lbl-planDefinedFields']")); } }
        public IWebElement UIMODMemberID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-txt-memberId']")); } }
        public IWebElement UIMODSal { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-txt-sal']")); } }
        public IWebElement UIMODfirstName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-txt-firstName']")); } }
        public IWebElement UIMODMiddleInitial { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-txt-mi']")); } }
        public IWebElement UIMODlastName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-txt-lastName']")); } }
        public IWebElement UIMODMemberStatus { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-span-memberStatus']")); } }
        public IWebElement UIMODRecordSource { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-span-recordSource']")); } }
        public IWebElement UIMODDateEntered { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-span-dateEntered']")); } }
        public IWebElement UIMODUserModified { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-span-userModified']")); } }
        public IWebElement UIMODDateModified { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-span-dateModified']")); } }
        public IWebElement ExpandAll { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='membercontent-btn-expandAndCollapse']")); } }
        public IWebElement SaveBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberViewEdit-btn-save']")); } }
        public IWebElement CancelBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberViewEdit-btn-cancel']")); } }
        public IWebElement UIMODSearchMBItextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-input-selectedHic']")); } }
        public IWebElement UIMODSearchMBIBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-btn-search']")); } }
        public IWebElement ViewNotesIcon { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-btn-viewNotes']")); } }
        public IWebElement ViewOOAIcon { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-btn-viewOoa']")); } }
        public IWebElement ViewAttachmentsIcon { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-btn-viewAttachments']")); } }
        public IWebElement ViewSNPIcon { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-btn-viewSnp']")); } }
        public IWebElement addSuspect { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='snp-btn-addSuspect']")); } }
        public IWebElement ViewAuditHistoryIcon { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-link-viewAudit']")); } }
        public By ViewSNPIconLoc = By.CssSelector("[test-id='memberInfo-btn-viewSnp']");
        public By ViewAuditHistoryIconLoc = By.CssSelector("[test-id='memberInfo-link-viewAudit']");
        public IWebElement AddNewTransactionLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='transactions-link-AddTransaction']")); } }
        public IWebElement addSuspectAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='snp-button-addSuspect']")); } }


    }
        [Binding]
        public class UIMODMemDemographics
        {
            public IWebElement UIMODAppel { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDemographics-input-appel']")); } }
            public IWebElement UIMODDOB { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDemographics-txt-dob']")); } }
            public IWebElement UIMODSex { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDemographics-select-sex']")); } }
            public IWebElement UIMODSexDropDownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='sex_listbox']")); } }
            public IWebElement UIMODMaritalStatusDropDownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='maritalStatus_listbox']")); } }
            public IWebElement UIMODSSN { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDemographics-input-ssn']")); } }
            public IWebElement UIMODLanguageDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='language_listbox']")); } }
            public IWebElement UIMODRaceDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='race_listbox']")); } }
            public IWebElement UIMODDOD { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDemographics-txt-dod']")); } }
            public IWebElement UIMODPlanIdDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='planId_listbox']")); } }
            public IWebElement UIMODPBPDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='pbp_listbox']")); } }
            public IWebElement UIMODSegmentIDPDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='segmentIds_listbox']")); } }
            public IWebElement UIMODEGHPCheckbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='mmemberDemographics-chk-eghp']")); } }
            public IWebElement UIMODEffectiveDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDemographics-txt-effectiveDate']")); } }
            public IWebElement UIMODTermDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDemographics-txt-termDate']")); } }
            public IWebElement UIMODElectionTypeDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='electionTypes_listbox']")); } }
            public IWebElement UIMODPartDOptOutDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='partDOptOutOptions_listbox']")); } }
        }

        [Binding]
        public class UIMODMemRxDetails
        {

            public IWebElement UIMODRxID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberRxDetails-inpu-rxid']")); } }
            public IWebElement UIMODRxGroup { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberRxDetails-input-rxGroup']")); } }
            public IWebElement UIMODRxBIN { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberRxDetails-input-rxBin']")); } }
            public IWebElement UIMODRxPCN { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberRxDetails-input-rxPcn']")); } }
            public IWebElement UIMODSecondaryDrugInsFlag { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberRxDetails-chk-secDrug']")); } }
            public IWebElement UIMODSecondaryRxID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberRxDetails-input-secondaryRxId']")); } }
            public IWebElement UIMODSecondaryRxGroup { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberRxDetails-input-secondaryRxGroup']")); } }
            public IWebElement UIMODSecondaryRxBIN { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberRxDetails-input-secondaryBin']")); } }
            public IWebElement UIMODSecondaryRxPCN { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberRxDetails-input-secondaryPcn']")); } }






        }
    }
    


