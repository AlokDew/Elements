﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using System.Collections.Generic;
using OpenQA.Selenium.Support.UI;
using System.IO;
using TMSoR1.FrameworkCode;
using System.Linq;
using System.Data.SqlClient;

namespace TMSoR1.FrameworkCode.EAM
{
    [Binding]
    class fsEAMWorkflow_2
    {

      
        [When(@"Workflow Engine WorkflowConfigName is set to ""(.*)""")]
        public void WhenWorkflowEngineWorkflowConfigNameIsSetTo(string p0)
        {
            string Configvalue = tmsCommon.GenerateData(p0);
            EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFConfigurationName.Clear();
            EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFConfigurationName.SendKeys(Configvalue);
            tmsWait.Hard(2);

        }

        [When(@"Workflow Engine Application URL is set")]
        public void WhenWorkflowEngineApplicationURLIsSet()
        {
            EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFApplicationurl.Clear();
            EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFApplicationurl.SendKeys(ConfigFile.WorkflowApplicationURL);
            tmsWait.Hard(2);
        }

        [When(@"Workflow Engine Service Endpoint URL is set")]
        public void WhenWorkflowEngineServiceEndpointURLIsSet()
        {
            EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFEndpointurl.Clear();
            EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFEndpointurl.SendKeys(ConfigFile.WorkflowAServiceEndpointURL);
            tmsWait.Hard(2);
        }

        [When(@"Worklow Configuration Page Save button is clicked")]
        public void WhenWorklowConfigurationPageSaveButtonIsClicked()
        {
            EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFConfigsave.Click();
            tmsWait.Hard(2);

        }

        [Then(@"Verify that Workflow Configuaration page grid has row ""(.*)""")]
        public void ThenVerifyThatWorkflowConfiguarationPageGridHasRow(string p0)
        {


            string ConfigName = tmsCommon.GenerateData(p0);
            By loc = By.XPath("//kendo-grid[@test-id='workflowEngine-label-grdWorkflowConfiguration']//td[contains(.,'" + ConfigName + "')]");
            AngularFunction.elementPresenceUsingLocators(loc);
        }

        [When(@"I Clicked on Manage Configuration")]
        public void WhenIClickedOnManageConfiguration()
        {
            EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.ManageConfig.Click();
            tmsWait.Hard(2);
        }

        [When(@"Workflow Engine dropdown is set to ""(.*)""")]
        public void WhenWorkflowEngineDropdownIsSetTo(string p0)
        {
            string WFconfigvalue = tmsCommon.GenerateData(p0);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='manageConfiguration-select-workflow']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + WFconfigvalue + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(2);
        }
        
        [When(@"I clicked on Manage Configuration Page Save button")]
        public void WhenIClickedOnManageConfigurationPageSaveButton()
        {
            EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.ManageConfigsave.Click();
            tmsWait.Hard(3);

        }
        [Then(@"Verfiy that Tenant Workflow configutaion is saved successfully with value ""(.*)""")]
        public void ThenVerfiyThatTenantWorkflowConfigutaionIsSavedSuccessfullyWithValue(string p0)
        {
            tmsWait.Hard(2);
            string ExptedWFvalue = tmsCommon.GenerateData(p0);
            IWebElement ActualWFValue = Browser.Wd.FindElement(By.XPath("(//label[text()='Workflow Engine']/parent::div//span[@class='k-input'])"));
            string actual_value = ActualWFValue.Text;
            Assert.IsTrue(actual_value.Contains(ExptedWFvalue), "Value does not match");
            tmsWait.Hard(2);
        }
        [When(@"Manage Configuration Page I clicked on Back to Record link")]
        public void WhenManageConfigurationPageIClickedOnBackToRecordLink()
        {
            EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.ManageConfigBackButton.Click();
            tmsWait.Hard(2);

        }

        [Then(@"Verfiy that User is in Workflow mode gets message ""(.*)""")]
        public void ThenVerfiyThatUserIsInWorkflowModeGetsMessage(string p0)
        {
            tmsWait.Hard(2);
            IWebElement ActualWFValue = EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFModenoqueue;
            string actual_value = ActualWFValue.Text;
            Assert.IsTrue(actual_value.Contains(p0), "Value does not match");
            tmsWait.Hard(2);
        }

        [Then(@"Verfy that EAM ""(.*)"" page is displayed")]
        public void ThenVerfyThatEAMPageIsDisplayed(string page)
        {
            tmsWait.Hard(2);
            string VerifyTitle = page.ToString();
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//div[contains(text(),'" + VerifyTitle + "')]"));
            AngularFunction.elementPresenceUsingWebElement(ele);
            tmsWait.Hard(2);
          

        }


        [Then(@"Verify that WorkflowDashboardBad message count is matched with DB Count ""(.*)""")]
        public void ThenVerifyThatWorkflowDashboardBadMessageCountIsMatchedWithDBCount(string p0)
        {
            string WFDBCount = tmsCommon.GenerateData(p0);
            IWebElement WFUICount = EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFDashboardBAdMessage;
            string WFUIBadCount = WFUICount.Text;
            Assert.AreEqual(WFDBCount, WFUIBadCount, "Both  values are not matching");
        }


        [When(@"EAM WorkflowDashboard queue All workflow items are selected")]
        public void WhenEAMWorkflowDashboardQueueAllWorkflowItemsAreSelected()
        {
            tmsWait.Hard(2);
            EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFDashboardSelectAll.Click();
            tmsWait.Hard(2);

        }
        [When(@"EAM WorkflowDashboard Back to Workflow Dashboard link is clicked")]
        public void WhenEAMWorkflowDashboardBackToWorkflowDashboardLinkIsClicked()
        {

            tmsWait.Hard(5);
            EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFBacktoDashboardlink.Click();
            tmsWait.Hard(2);
        }

        [Then(@"Verify that EAM WorkflowDashboard Priority is set to ""(.*)""")]
        public void ThenVerifyThatEAMWorkflowDashboardPriorityIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string Expectedpriority = tmsCommon.GenerateData(p0);
            IWebElement ActualValue = Browser.Wd.FindElement(By.XPath("//td[contains(text(),'" + Expectedpriority + "')]"));
            string ActualPriority = ActualValue.Text;
            Assert.IsTrue(ActualPriority.Contains(Expectedpriority), "Priority Values does not match");
            tmsWait.Hard(2);
           

        }
        [Then(@"Verify that WorkFlowmode page assigned workingon itemtype to variable ""(.*)""")]
        public void ThenVerifyThatWorkFlowmodePageAssignedWorkingonItemtypeToVariable(string p0)
        {
            tmsWait.Hard(3);
            IWebElement WorkflowitemTypeElement = EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFGetwokingonitem;
            string WorkflowitemType = WorkflowitemTypeElement.Text;
            fw.setVariable(p0, WorkflowitemType);
            tmsWait.Hard(2);
        }

        [Then(@"WorkFlowmode page workitemkey is set to variable ""(.*)""")]
        public void ThenWorkFlowmodePageWorkitemkeyIsSetToVariable(string p0)
        {
       
            IWebElement WorkflowitemKeyElement = EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WorkflowitemKeyElement;
            string workflowitemkey = WorkflowitemKeyElement.Text;
            fw.setVariable(p0, workflowitemkey);
            tmsWait.Hard(2);
        }

        [Then(@"WorkFlowmode page ""(.*)"" variable is set to ""(.*)"" and ""(.*)""")]
        public void ThenWorkFlowmodePageVariableIsSetToAnd(string p0, string p1, string p2)
        {
            string WorkItemType = tmsCommon.GenerateData(p1);
            string workitemkey = tmsCommon.GenerateData(p2);
            tmsWait.Hard(2);

            //fw.setVariable(p0, MessageID);

            switch (WorkItemType)

            {
                case "You are working on Trr :":
                    String WorkitemkeytrrFinal = "Trr" + workitemkey;
                    fw.setVariable(p0, WorkitemkeytrrFinal);
                    tmsWait.Hard(2);
                    EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFModeBacktoMember.Click();
                    tmsWait.Hard(3);
                    break;
                case "You are working on Transaction :":
                    String WorkitemkeytransactionFinal = "Transaction" + workitemkey;
                    fw.setVariable(p0, WorkitemkeytransactionFinal);
                    break;

                case "You are working on Member :":
                    String WorkitemkeymemberFinal = "Member" + workitemkey;
                    fw.setVariable(p0, WorkitemkeymemberFinal);
                    break;
                    
            }

        }

        [When(@"WorkFlowmode page clicked on WFModeBacktoMember link")]
        public void WhenWorkFlowmodePageClickedOnWFModeBacktoMemberLink()
        {
            tmsWait.Hard(2);
            EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFModeBacktoMember.Click();
            tmsWait.Hard(3);
        }


        [Then(@"Verify EAM WorkflowDashboard page workflow item is Locked by user")]
        public void ThenVerifyEAMWorkflowDashboardPageWorkflowItemIsLockedByUser()
        {
            tmsWait.Hard(2);
            bool ispresent = false;
            ispresent = EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFlockbutton.Displayed;
            Console.WriteLine(ispresent);
            Assert.IsTrue(ispresent, "Locked by User is not present");
            tmsWait.Hard(3);
            String ExpectedUsername = ConfigFile.UserId;
            String ActuaUservalue = EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFlockedbyUser.Text;
            Console.WriteLine(ActuaUservalue);
            Assert.AreEqual(ExpectedUsername, ActuaUservalue, "locked by user name is not matching");
           

        }

  

[When(@"EAM WorkflowDashboard page clicked on lockbutton for the workflowitem ""(.*)""")]
public void WhenEAMWorkflowDashboardPageClickedOnLockbuttonForTheWorkflowitem(string p0)
{
    string WorkItemType = tmsCommon.GenerateData(p0);
    tmsWait.Hard(2);
    AngularFunction.clickOnElement(EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFlockbutton);
    tmsWait.Hard(3);

}
[Then(@"Verify that EAM WorkflowDashboard page unlockbutton is present for the workflowitem ""(.*)""")]
public void ThenVerifyThatEAMWorkflowDashboardPageUnlockbuttonIsPresentForTheWorkflowitem(string p0)
{
    string WorkItemType = tmsCommon.GenerateData(p0);
    By loc = By.XPath("//td[contains(.,'" + WorkItemType + "')]/following-sibling::td//i[@class='fas fa-unlock fa-x text-secondary border-0 p-0']");
    AngularFunction.elementPresenceUsingLocators(loc);
    String ExpectedUsername = ConfigFile.UserId;
    By locusernameloc = By.XPath("//td[contains(.,'" + WorkItemType + "')]/following-sibling::td//span[contains(.,'" + ExpectedUsername + "')]");
    AngularFunction.elementNotPresenceUsingLocators(locusernameloc);

}

[When(@"EAM WorkflowDashboard queue ""(.*)"" workflow item is selected")]
public void WhenEAMWorkflowDashboardQueueWorkflowItemIsSelected(string p0)
{
    string checboxnumber = tmsCommon.GenerateData(p0);

    switch (checboxnumber)
    {
        case "First":
            AngularFunction.clickOnElement(EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.CheckboxWF1);
            break;
        case "Second":
            AngularFunction.clickOnElement(EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.CheckboxWF2);
            break;
        case "Third":
            AngularFunction.clickOnElement(EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.CheckboxWF3);
            break;
            ;
        case "Fourth":
            AngularFunction.clickOnElement(EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.CheckboxWF4);
            break;
            ;

    }
}

        [Then(@"Verify that EAM WorkflowDashboard Priority for ""(.*)"" workflow item is set to ""(.*)""")]
        public void ThenVerifyThatEAMWorkflowDashboardPriorityForWorkflowItemIsSetTo(string p0, string p1)
        {
            string WorkItemNumber = tmsCommon.GenerateData(p0);
            string NewWFItemPrority = tmsCommon.GenerateData(p1);

            switch (WorkItemNumber)
            {
                case "First":
                    IWebElement ActualValueFirst = Browser.Wd.FindElement(By.XPath("//input[@id='k-grid1-checkbox0']/parent::td/following-sibling::td/following-sibling::td[@data-kendo-grid-column-index='2']"));
                    string ActualPriorityFrist = ActualValueFirst.Text;
                    Assert.IsTrue(ActualPriorityFrist.Contains(NewWFItemPrority), "Priority Values does not match");
                    break;
                case "Second":
                    IWebElement ActualValueSecond = Browser.Wd.FindElement(By.XPath("//input[@id='k-grid1-checkbox1']/parent::td/following-sibling::td/following-sibling::td[@data-kendo-grid-column-index='2']"));
                    string ActualPrioritySecond = ActualValueSecond.Text;
                    Assert.IsTrue(ActualPrioritySecond.Contains(NewWFItemPrority), "Priority Values does not match");
                    break;
                case "Third":
                    IWebElement ActualValueThrid = Browser.Wd.FindElement(By.XPath("//input[@id='k-grid1-checkbox2']/parent::td/following-sibling::td/following-sibling::td[@data-kendo-grid-column-index='2']"));
                    string ActualPrioritythrid = ActualValueThrid.Text;
                    Assert.IsTrue(ActualPrioritythrid.Contains(NewWFItemPrority), "Priority Values does not match");
                    break;
                case "Fourth":
                    IWebElement ActualFourth = Browser.Wd.FindElement(By.XPath("//input[@id='k-grid1-checkbox3']/parent::td/following-sibling::td/following-sibling::td[@data-kendo-grid-column-index='2']"));
                    string ActualPriorityActualFourth = ActualFourth.Text;
                    Assert.IsTrue(ActualPriorityActualFourth.Contains(NewWFItemPrority), "Priority Values does not match");
                    break;

            }
        }


            [Then(@"Verify that User is Navigated to Workflow Page")]
        public void ThenVerifyThatUserIsNavigatedToWorkflowPage()
        {
            Browser.SwitchToChildWindow();
            AngularFunction.resolveCertificateErrors();
            tmsWait.Hard(60);
            IWebElement WFPageEAMName = EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFPageHomeMenu;
            Assert.IsTrue(WFPageEAMName.Displayed,"User is not navigated to Work flow Page");
            
        }


        [When(@"EAM WorkflowDashboard Clicked on Priority column")]
        public void WhenEAMWorkflowDashboardClickedOnPriorityColumn()
        {
            tmsWait.Hard(3);
            EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFSortPriority.Click();

        }


        [Then(@"Verfiy that EAM WorkflowDashboard Page sorted by Priority")]
        public void ThenVerfiyThatEAMWorkflowDashboardPageSortedByPriority()
        {

            //First Workflow Items priority 
            IWebElement ActualValueFirst1 = Browser.Wd.FindElement(By.XPath("//input[@id='k-grid1-checkbox0']/parent::td/following-sibling::td/following-sibling::td[@data-kendo-grid-column-index='2']"));
            string ActualPriorityFrist1 = ActualValueFirst1.Text;
            Assert.IsTrue(ActualPriorityFrist1.Contains("Normal"), "First Workflow Items Priority Values does not match");

            //Second  Workflow Items priority 
            IWebElement ActualValueSecond1 = Browser.Wd.FindElement(By.XPath("//input[@id='k-grid1-checkbox1']/parent::td/following-sibling::td/following-sibling::td[@data-kendo-grid-column-index='2']"));
            string ActualPrioritySecond1 = ActualValueSecond1.Text;
            Assert.IsTrue(ActualPrioritySecond1.Contains("Medium"), "Second Workflow Items Priority Values does not match");

            //Third  Workflow Items priority 

            IWebElement ActualValueThrid1 = Browser.Wd.FindElement(By.XPath("//input[@id='k-grid1-checkbox2']/parent::td/following-sibling::td/following-sibling::td[@data-kendo-grid-column-index='2']"));
            string ActualPrioritythrid1 = ActualValueThrid1.Text;
            Assert.IsTrue(ActualPrioritythrid1.Contains("High"), "Thrid Workflow Items Priority Values does not match");

            //Fourth  Workflow Items priority 
            IWebElement ActualFourth1 = Browser.Wd.FindElement(By.XPath("//input[@id='k-grid1-checkbox3']/parent::td/following-sibling::td/following-sibling::td[@data-kendo-grid-column-index='2']"));
            string ActualPriorityActualFourth1 = ActualFourth1.Text;
            Assert.IsTrue(ActualPriorityActualFourth1.Contains("Medium"), "Fourth Workflow Items Priority Values does not match");
            
        }

        [Then(@"Verify that WorkFLow Page has all wokflowdashboard menus")]
        public void ThenVerifyThatWorkFLowPageHasAllWokflowdashboardMenus()
        {
            //Verification of all menus on Workflow Dashboard Menus 

            //Home
            IWebElement WFPageHomeMenu = EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFPageHomeMenu;
            Assert.IsTrue(WFPageHomeMenu.Displayed, "WFPageHomeMenu Menu is not displayed");
            //Inventory
            IWebElement WFPageInventoryMenu = EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFPageInventoryMenu;
            Assert.IsTrue(WFPageInventoryMenu.Displayed, "WFPageInventoryMenu Menu is not displayed");
            //User
            IWebElement WFPageUserMenu = EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFPageUserMenu;
            Assert.IsTrue(WFPageUserMenu.Displayed, "WFPageUserMenu Menu is not displayed ");
            //Work Item
            IWebElement WFPageWorkItemMenu = EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFPageWorkItemMenu;
            Assert.IsTrue(WFPageWorkItemMenu.Displayed, "WFPageWorkItemMenu Menu is not displayed ");
            //Workforce
            IWebElement WFPageWorkforceMenu = EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFPageWorkforceMenu;
            Assert.IsTrue(WFPageWorkforceMenu.Displayed, "WFPageWorkforceMenu Menu is not displayed ");

            //Also The Verification of all menus on Workflow Configurations Menus 

            //Click on Go to Configuration Menu 
            AngularFunction.clickOnElement(EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFPageGoConfiguration);
            tmsWait.Hard(10);

            //Properties
            IWebElement WFPagePropertiesMenu = EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFPagePropertiesMenu;
            Assert.IsTrue(WFPagePropertiesMenu.Displayed, "WFPageHomeMenu Menu is not displayed");
            //Admin
            IWebElement WFPageMenuAdmin = EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFPageMenuAdmin;
            Assert.IsTrue(WFPageMenuAdmin.Displayed, "WFPageInventoryMenu Menu is not displayed");
            //Qualifiers
            IWebElement WFPageMenuQualifiers = EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFPageMenuQualifiers;
            Assert.IsTrue(WFPageMenuQualifiers.Displayed, "WFPageUserMenu Menu is not displayed ");
            //Roles
            IWebElement WFPageMenuRoles = EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFPageMenuRoles;
            Assert.IsTrue(WFPageMenuRoles.Displayed, "WFPageWorkItemMenu Menu is not displayed ");
            //Queues
            IWebElement WFPageMenuQueues = EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFPageMenuQueues;
            Assert.IsTrue(WFPageMenuQueues.Displayed, "WFPageWorkforceMenu Menu is not displayed ");
            //Rules
            IWebElement WFPageMenuRules = EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFPageMenuRules;
            Assert.IsTrue(WFPageMenuRules.Displayed, "WFPageWorkforceMenu Menu is not displayed ");
            //Users
            IWebElement WFPageMenuUsers = EAM.cfEAMWorkflowConfiguration.WFConfigurationPage.WFPageMenuUsers;
            Assert.IsTrue(WFPageMenuUsers.Displayed, "WFPageWorkforceMenu Menu is not displayed ");                           

        }


    }

}
