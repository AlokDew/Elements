﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;


namespace TMSoR1
{
    [Binding]
    class fsAdministrationEditLISInformation
    {

        [Then(@"Verify Members New Tab RXBilling Table has data Level as ""(.*)"" Co Pay Cat as ""(.*)"" LIS Type as ""(.*)"" Source as ""(.*)""")]
        public void ThenVerifyMembersNewTabRXBillingTableHasDataLevelAsCoPayCatAsLISTypeAsSourceAs(string level, string category, string listype, string Source)
        {
            tmsWait.Hard(5);
            IWebElement rxbillingpresence = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_RsGrid']//tr/td[contains(.,'"+ level + "')]/following-sibling::td[contains(.,'"+ category + "')]/following-sibling::td[contains(.,'"+ listype + "')]/following-sibling::td[contains(.,'"+ Source + "')]"));
            Assert.IsTrue(rxbillingpresence.Displayed,"Expected RX Billing values are not displayed");
            
        }

        [Then(@"Verify RXBilling Table has data Level as ""(.*)"" Co Pay Cat as ""(.*)"" Start Date ""(.*)"" End Date ""(.*)"" LIS Type as ""(.*)"" Source as ""(.*)""")]
        public void ThenVerifyRXBillingTableHasDataLevelAsCoPayCatAsStartDateEndDateLISTypeAsSourceAs(string level, string category, string sdate, string edate, string listype, string Source)
        {
            tmsWait.Hard(5);
            IWebElement rxbillingpresence = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_RsGrid']//tr/td[contains(.,'" + level + "')]/following-sibling::td[contains(.,'" + category + "')]/following-sibling::td[contains(.,'" + sdate + "')]/following-sibling::td[contains(.,'" + edate + "')]/following-sibling::td[contains(.,'" + listype + "')]/following-sibling::td[contains(.,'" + Source + "')]"));
            Assert.IsTrue(rxbillingpresence.Displayed, "Expected RX Billing values are not displayed");
        }

        [Then(@"Verify RXBilling Tab has data Level as ""(.*)"" Co Pay Cat as ""(.*)"" Start Date ""(.*)"" End Date ""(.*)"" LIS Type as ""(.*)"" Source as ""(.*)"" Valid as ""(.*)"" Current as ""(.*)""")]
        public void ThenVerifyRXBillingTabHasDataLevelAsCoPayCatAsStartDateEndDateLISTypeAsSourceAsValidAsCurrentAs(string level, string category, string sdate, string edate, string listype, string Source, string valid, string current)
        {

        tmsWait.Hard(5);
            IWebElement rxbillingpresence = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_RsGrid']//tr/td[contains(.,'" + level + "')]/following-sibling::td[contains(.,'" + category + "')]/following-sibling::td[contains(.,'" + sdate + "')]/following-sibling::td[contains(.,'" + edate + "')]/following-sibling::td[contains(.,'" + listype + "')]/following-sibling::td[contains(.,'" + Source + "')]/following-sibling::td[contains(.,'" + valid + "')]/following-sibling::td[contains(.,'" + current + "')]"));
            Assert.IsTrue(rxbillingpresence.Displayed, "Expected RX Billing values are not displayed");
        }



        [When(@"Administration Edit LIS StartDate is set to ""(.*)""")]
        public void WhenAdministrationEditLISStartDateIsSetTo(int p0)
        {
            EAM.AdministrationEditLISInformation.EditStartDate.Clear();
            EAM.AdministrationEditLISInformation.EditStartDate.SendKeys(p0.ToString());
        }

        [When(@"Administration Edit LIS EndDate is set to ""(.*)""")]
        public void WhenAdministrationEditLISEndDateIsSetTo(int p0)
        {
            EAM.AdministrationEditLISInformation.EditEndDate.SendKeys(p0.ToString());
        }

        [Then(@"Verify RX Billing tab displayed error message ""(.*)""")]
        public void ThenVerifyRXBillingTabDisplayedErrorMessage(string p0)
        {
            tmsWait.Hard(5);
            IWebElement textPresence = Browser.Wd.FindElement(By.XPath("//span[@id='ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_lblMsg'][contains(.,'"+p0+"')]"));
            Assert.IsTrue(textPresence.Displayed, "Expected Error message are not displayed");
        }




    }
}
