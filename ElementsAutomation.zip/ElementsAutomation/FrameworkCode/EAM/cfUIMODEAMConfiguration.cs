﻿
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1
{
    [Binding]
    class cfUIMODEAMConfiguration
    {

        public static PlanDefinedFields PlanDefinedFields { get { return new PlanDefinedFields(); } }
        public static Language Language { get { return new Language(); } }
        public static RelationShip RelationShip { get { return new RelationShip(); } }
        public static AddGroups AddGroups { get { return new AddGroups(); } }
        public static SalesRepresentative SalesRepresentative { get { return new SalesRepresentative(); } }
        public static SpanTypes SpanTypes { get { return new SpanTypes(); } }

        public static OnHoldReason OnHoldReason { get { return new OnHoldReason(); } }
        public static Disenrollment Disenrollment { get { return new Disenrollment(); } }
        public static Plan5StarStatus Plan5StarStatus { get { return new Plan5StarStatus(); } }
        public static OOA OOA { get { return new OOA(); } }
        public static OEVLetter OEVLetter { get { return new OEVLetter(); } }
        public static SNPConfiguration SNPConfiguration { get { return new SNPConfiguration(); } }
        public static OSBConfiguration OSBConfiguration { get { return new OSBConfiguration(); } }
        public static PDDDConfiguration PDDDConfiguration { get { return new PDDDConfiguration(); } }
        public static BusinessRules BusinessRules { get { return new BusinessRules(); } }


    }



    [Binding]
    public class SalesRepresentative
    {
        public IWebElement RepID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='salesRepresentative-txt-repId']")); } }
        public IWebElement RepName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='salesRepresentative-txt-repName']")); } }
        public IWebElement ResetBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='salesRepresentative-btn-resetSalesRepresentative']")); } }
        public IWebElement SaveBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='salesRepresentative-btn-saveSalesRepresentative']")); } }
        public IWebElement EditRepName { get { return Browser.Wd.FindElement(By.CssSelector("[name='repName']")); } }



    }
    [Binding]
    public class SpanTypes
    {

        public IWebElement SpanTypeTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='spanTypes-txt-addSpanType']")); } }
        public IWebElement ResetBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='spanTypes-btn-reset']")); } }
        public IWebElement SaveBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='spanTypes-btn-save']")); } }

    }
    [Binding]
    public class OnHoldReason
    {
        public IWebElement OnHoldReasonTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='onHoldReasons-txt-addReason']")); } }
        public IWebElement ResetBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='OnHoldReasons-btn-cancel']")); } }
        public IWebElement SaveBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='OnHoldReasons-btn-save']")); } }
        public IWebElement EditreasonDescription { get { return Browser.Wd.FindElement(By.CssSelector("[name='reasonDescription']")); } }


    }

    [Binding]
    public class Disenrollment

    {
        public IWebElement MapToDropdownlistAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='disenrollmentReasons-select-ddlMapTo']")); } }
        public IWebElement EditMapToDropdownlistAngJS { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='disenrollmentReasons-select-ddlMapTo']")); } }
        public IWebElement DisEnrollmentReasonCodeTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='disenrollmentReasons-txt-txtCode']")); } }
        public IWebElement DisEnrollmentReasonDiscriptionTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='lblDescription-txt-Description']")); } }
        public IWebElement MapToDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlMapTo_listbox']")); } }
        public IWebElement ResetBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='disenrollmentReasons-btn-reset']")); } }
        public IWebElement SaveBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='disenrollmentReasons-btn-saveLanguage']")); } }
       
  public IWebElement EditCheckbox { get { return Browser.Wd.FindElement(By.XPath("(//*[@id='active'])[1]")); } }
        public IWebElement EditDisEnrollmentReasonDiscriptionTextbox { get { return Browser.Wd.FindElement(By.XPath("//input[@name='description']")); } }
        public IWebElement EditMapToDropdownlist { get { return Browser.Wd.FindElement(By.XPath("//input[@name='active']/parent::td/following-sibling::td/span[@role='listbox']")); } }
    }

    [Binding]
    public class Plan5StarStatus
    {
        public IWebElement UpdateBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planStarStatus-btn-updatePlanStarStatus']")); } }

        
    }

    [Binding]
    public class OOA
    {
        public IWebElement OutOfAreaConfiguration { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ooa-li-outofAreaConfiguration']")); } }
        public IWebElement PossibleOutOfAreaStatus { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ooa-li-possibleOutofAreaStatus']")); } }
        public IWebElement StatusTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='possibleOoaStatus-txt-status']")); } }
        public IWebElement SaveBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='possibleOoaStatus-btn-savePossibleOoaStatus']")); } }


    }

    [Binding]
    public class OEVLetter
    {
        public IWebElement SaveBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='oevletter-btn-save']")); } }


    }
    [Binding]
    public class SNPConfiguration
    {

        public IWebElement PlanIDDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='snpConfigure-select-planId']")); } }
        public IWebElement PBPIDDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='snpConfigure-select-pbpId']")); } }
        public IWebElement SNPTypeDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='snpConfigure-select-snpTypes']")); } }
        public IWebElement MonthsOfeligibilityDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='snpConfigure-select-drpMonth']")); } }
        public IWebElement ChronicTypeDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='snpConfigure-select-drpChronicType']")); } }
        public IWebElement StateDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='snpConfigure-select-drpStateType']")); } }
        public IWebElement SaveBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='snpConfigure-btn-saveSnpConfigure']")); } }
        public IWebElement ResetBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='snpConfigure-button-reset']")); } }
        public IWebElement ESRDCheckbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='snpConfigure-chk-esrd']")); } }
        public IWebElement HistoryLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='snpConfigure-lbl-settingHistory']")); } }
        public IWebElement SNPHistoryPage { get { return Browser.Wd.FindElement(By.XPath("//div[@id='eamAuditInfoDialog']//span[contains(.,'SNP Configuration History')]")); } }
        public IWebElement SNPHistoryCancel { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='auditInfo-btn-cancel']")); } }
        public IWebElement SNPEditPage { get { return Browser.Wd.FindElement(By.CssSelector("[id='dialog']")); } }
        public IWebElement SNPEditSpanType { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='editSnp-select-snpTypes']")); } }
        public IWebElement SNPEditMonthsEligibility { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='editSnp-select-drpMonth']")); } }
        public IWebElement SNPEditState { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='editSnp-select-drpStateType']")); } }
        public IWebElement SNPEditChronicType { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='editSnp-select-drpChronicType']")); } }
        public IWebElement SNPEditESRDCheckbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='editSnp-chk-esrd']")); } }
        public IWebElement SNPEditButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='editSnp-button-update']")); } }
        public IWebElement SNPResetButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='editSnp-button-reset']")); } }
        public IWebElement SNPEditClose { get { return Browser.Wd.FindElement(By.XPath("//i[@class='fa fa-times-circle rptlink cursorLink']")); } }
        public IWebElement SNPHistoryPagAngJS { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'SNP Configuration History')]")); } }


    }
    [Binding]
    public class OSBConfiguration
    {

        public IWebElement PlanIDDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='osbConfiguration-select-planId']")); } }
        public IWebElement PBPIDDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='osbConfiguration-select-pbpID']")); } }
        public IWebElement OSBTypeDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlOsbType_listbox']")); } }
        public IWebElement OSBPremiumTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='osbConfiguration-txt-OsbPremiuim']")); } }
        public IWebElement OSBStartYearDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlOsbStartYear_listbox']")); } }
        public IWebElement OSBEndYearDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlOsbEndYear_listbox']")); } }
        public IWebElement EditOSBPremium { get { return Browser.Wd.FindElement(By.XPath("//input[@name='osbPremium']")); } }
        public IWebElement EditOSBStartDate { get { return Browser.Wd.FindElement(By.XPath("//input[@aria-owns='osbStartDate_dateview']")); } }
        public IWebElement EditOSBEndDate { get { return Browser.Wd.FindElement(By.XPath("//input[@aria-owns='osbEndDate_dateview']")); } }
        public IWebElement ResetBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='osbConfiguration-btn-reset']")); } }
        public IWebElement SaveBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='osbConfiguration-btn-save']")); } }
        public IWebElement EditOSBPremiumAngJS { get { return Browser.Wd.FindElement(By.XPath("//input[@name='osbPremium']")); } }
        public IWebElement EditOSBStartDateAngJS { get { return Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@id='osbStartDate']//input")); } }
        public IWebElement EditOSBEndDateAngJS { get { return Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@id='osbEndDate']//span[@role='button']")); } }
        public IWebElement ResetBtnAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='osbConfiguration-btn-reset']")); } }
    }

    [Binding]
    public class PDDDConfiguration
    {
        //pdddConfiguration-txt-txtFileMessage
                  public IWebElement AngFileMessageTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pdddConfiguration-txt-txtFileMessage']")); } }
        public IWebElement AngPlanMessageTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pdddConfiguration-txt-txtCode']")); } }
        public IWebElement FileMessageTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pdddConfiguration-txt-addFileMessage']")); } }
        public IWebElement PlanMessageTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pdddConfiguration-txt-addPlanMesaage']")); } }
        public IWebElement PlanDataDueDateDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='formInputBoxPlanDataDueDate_listbox']")); } }
        public IWebElement ReportMonthDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pdddConfiguration-txt-reportMonth']")); } }
        public IWebElement FileDueDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pdddConfiguration-txt-fileDueDate']")); } }
        public IWebElement PlanDueDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pdddConfiguration-txt-planDueDate']")); } }
        public IWebElement ResetBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pdddConfiguration-btn-cancel']")); } }
        public IWebElement SaveBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pdddConfiguration-btn-save']")); } }
        public IWebElement SearchBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pdddConfiguration-btn-search']")); } }
        public IWebElement UpdateReportMonth { get { return Browser.Wd.FindElement(By.CssSelector("[data-bind='value:reportMonth']")); } }
        public IWebElement UpdateFileDueDate { get { return Browser.Wd.FindElement(By.CssSelector("[data-bind='value:fileDueDate']")); } }
        public IWebElement UpdateFileMessage { get { return Browser.Wd.FindElement(By.CssSelector("[data-bind='value:fileMessage']")); } }
        public IWebElement UpdatePlanDueDate { get { return Browser.Wd.FindElement(By.CssSelector("[data-bind='value:planDueDate']")); } }
        public IWebElement UpdatePlanMessage { get { return Browser.Wd.FindElement(By.CssSelector("[data-bind='value:planMessage']")); } }

        public IWebElement UpdateFileMessageAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[id='planMessage']")); } }
        public IWebElement UpdatePlanDueDateAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[id='fileMessage']")); } }
        public IWebElement UpdatePlanMessageAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[id='planMessage']")); } }

    }

    [Binding]
    public class BusinessRules
    {
        public IWebElement PLAN_CHANGE_PRE_CMS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='businessRules-chk-PLAN_CHANGE_PRE_CMS']")); } }
        public IWebElement PLAN_CHANGE_POST_CMS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='businessRules-chk-PLAN_CHANGE_POST_CMS']")); } }
        public IWebElement NOTES_ACTIONS_SHOW_ACTIONS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='businessRules-chk-NOTES_ACTIONS_SHOW_ACTIONS']")); } }

        public IWebElement SEND_PLAN_10_LEGACY { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='businessRules-chk-SEND_PLAN_10_LEGACY']")); } }
        public IWebElement EGHPValidation { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='businessRules-chk-EGHPValidation']")); } }
        public IWebElement ReceiptDateValidation { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='businessRules-chk-ReceiptDateValidation']")); } }


        public IWebElement SignatureDateValidation { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='businessRules-chk-SignatureDateValidation']")); } }
        public IWebElement DateOfDeathValidation { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='businessRules-chk-DateOfDeathValidation']")); } }
        public IWebElement SCCCodeValidation { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='businessRules-chk-SCCCodeValidation']")); } }

        public IWebElement ElectionTypeValidation { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='businessRules-chk-ElectionTypeValidation']")); } }
        public IWebElement MemberDupeCheck { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='businessRules-chk-MemberDupeCheck']")); } }
        public IWebElement IsLetterAggregated { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='businessRules-chk-IsLetterAggregated']")); } }
        public IWebElement FailedBeqToTriggerRfi { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='businessRules-chk-FailedBeqToTriggerRfi']")); } }
        public IWebElement ApplicationDateForCmsTransferFile { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='businessRules-chk-ApplicationDateForCmsTransferFile']")); } }
        public IWebElement saveBusinessRules { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='businessRules-btn-saveBusinessRules']")); } }


    }

    [Binding]
    public class PlanDefinedFields
    {
        public IWebElement MemberFieldsPlan1Textbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-memberFieldPlanOne']")); } }
        public IWebElement MemberFieldsPlan2Textbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-memberFieldPlanTwo']")); } }
        public IWebElement MemberFieldsPlan3Textbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-memberFieldPlanThree']")); } }
        public IWebElement MemberFieldsPlan4Textbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-memberFieldPlanFour']")); } }
        public IWebElement MemberFieldsPlan5Textbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-memberFieldPlanFive']")); } }
        public IWebElement MemberFieldsPlan6Textbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-memberFieldPlanSix']")); } }
        public IWebElement MemberFieldsPlan7Textbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-memberFieldPlanSeven']")); } }
        public IWebElement MemberFieldsPlan8Textbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-memberFieldPlanEight']")); } }
        public IWebElement MemberFieldsPlan9Textbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-memberFieldPlanNine']")); } }
        public IWebElement MemberFieldsPlan10Textbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-memberFieldPlanTen']")); } }

        public IWebElement TransactionFieldsPlan1Textbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-transactionFieldPlanOne']")); } }
        public IWebElement TransactionFieldsPlan2Textbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-transactionFieldPlanTwo']")); } }
        public IWebElement TransactionFieldsPlan3Textbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-transactionFieldPlanThree']")); } }
        public IWebElement TransactionFieldsPlan4Textbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-transactionFieldPlanFour']")); } }
        public IWebElement TransactionFieldsPlan5Textbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-transactionFieldPlanFive']")); } }
        public IWebElement TransactionFieldsPlan6Textbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-transactionFieldPlanSix']")); } }
        public IWebElement TransactionFieldsPlan7Textbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-transactionFieldPlanSeven']")); } }
        public IWebElement TransactionFieldsPlan8Textbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-transactionFieldPlanEight']")); } }
        public IWebElement TransactionFieldsPlan9Textbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-transactionFieldPlanNine']")); } }
        public IWebElement TransactionFieldsPlan10Textbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-transactionFieldPlanTen']")); } }
        public IWebElement SaveMemberFieldsButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-btn-saveMemberFields']")); } }
        public IWebElement SaveTransactionFieldsButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-btn-saveTransactionFields']")); } }

    }
    [Binding]
    public class Language
    {
        public IWebElement Code { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='language-txt-txtCode']")); } }
        public IWebElement LanguageTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='language-txt-language']")); } }
        public IWebElement SaveButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='language-btn-saveLanguage']")); } }
        public IWebElement ResetButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='language-btn-resetLanguage']")); } }

    }
    public class RelationShip
    {
        public IWebElement RelationCode { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='relationship-txt-relationshipCode']")); } }
        public IWebElement RelationShipTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='relationship-txt-relationship']")); } }
        public IWebElement SaveButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='relationship-btn-saveRelationship']")); } }
        public IWebElement ResetButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='relationship-btn-resetRelationship']")); } }

    }

    public class AddGroups
    {
        public IWebElement GroupOptionButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='group-rd-File']")); } }
        public IWebElement SubGroupOptionButton { get { return Browser.Wd.FindElement(By.XPath("(//input[@test-id='group-rd-Parameter'])[1]")); } }
        public IWebElement ClassOptionButton { get { return Browser.Wd.FindElement(By.XPath("(//input[@test-id='group-rd-Parameter'])[2]")); } }
        public IWebElement GRGRID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='group-txt-groupId']")); } }
        public IWebElement GroupName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='group-input-groupName']")); } }
        public IWebElement SGSGID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='group-txt-subGroupId']")); } }
        public IWebElement SubGroupName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='group-input-subGroupName']")); } }
        public IWebElement SelectGroupDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlgroupsName_listbox']")); } }
        public IWebElement CSCSID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='group-txt-classId']")); } }
        public IWebElement ClassName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='group-input-className']")); } }
        public IWebElement ADDButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='gorup-btn-add']")); } }
        public IWebElement GroupRadioButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='group-lbl-group']")); } }
        public IWebElement SubGroupRadioButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='group-lbl-subGroup']")); } }
        public IWebElement ClassRadioButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='group-lbl-class']")); } }
        public IWebElement AddIndependent { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='group-lbl-independentClass']")); } }
        public IWebElement MapGroup { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='group-lbl-groupclass']")); } }
        public IWebElement MapSubGroup { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='group-lbl-subGroupClass']")); } }
        public IWebElement SelectSubGroupDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlsubGroupName_listbox']")); } }
        
    }
}