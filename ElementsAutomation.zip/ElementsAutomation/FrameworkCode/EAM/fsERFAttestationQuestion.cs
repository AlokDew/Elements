﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using OpenQA.Selenium.Support.UI;
using System.Collections.ObjectModel;

namespace TMSoR1.FrameworkCode.EAM
{
    [Binding]
    class fsERFAttestationQuestion
    {
        TMSoR1.BuisnessRulesFields fields = new BuisnessRulesFields();
        TMSoR1.ERF erfObj = new ERF();
        cfERFAttestationQuestion obj = new cfERFAttestationQuestion();
        TMSoR1.TransactionsViewEdit TransVieEdit = new TransactionsViewEdit();
        TMSoR1.FrameworkCode.HCC_RAM.fsManageProjects tableoperation = new TMSoR1.FrameworkCode.HCC_RAM.fsManageProjects();
        TMSoR1.TransactionsNew newTransObj = new TransactionsNew();
        TMSoR1.ERF qalink = new ERF();
        private StringBuilder verificationErrors;

        [When(@"EAM Administration Business Rules ""(.*)"" is unchecked")]
        public void WhenEAMAdministrationBusinessRulesIsUnchecked(string p0)
        {
            Assert.IsTrue(fields.ElectionTypeValidationCheckbox.Displayed, "Election Type Validation check is not displayed");
           if(fields.ElectionTypeValidationCheckbox.Selected) fields.ElectionTypeValidationCheckbox.Click();
            
            
        }
        [When(@"EAM Administration Business Rules ""(.*)"" is checked")]
        public void WhenEAMAdministrationBusinessRulesIsChecked(string p0)
        {
            Assert.IsTrue(fields.ElectionTypeValidationCheckbox.Displayed, "Election Type Validation check is not displayed");
            if (!fields.ElectionTypeValidationCheckbox.Selected) fw.ExecuteJavascript(fields.ElectionTypeValidationCheckbox);
        }
        [When(@"EAM Administration Business Rules SAVE button is clicked(.*)")]
        public void WhenEAMAdministrationBusinessRulesSAVEButtonIsClicked(int p0)
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id= 'businessRules-btn-saveBusinessRules']")));
           // Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[contains(text(), 'Configuration updated successfully.')]")).Displayed, "Success message for Update is not displayed");
        }

        [When(@"EAM Administration Business Rules SAVE button is clicked")]
        [Then(@"EAM Administration Business Rules SAVE button is clicked")]
        [Given(@"EAM Administration Business Rules SAVE button is clicked")]
        public void WhenEAMAdministrationBusinessRulesSAVEButtonIsClicked()
        {
            fw.ExecuteJavascript(fields.SaveButton);
              tmsWait.Hard(5);
            //string successmessageXpath = "//span[contains(text(), 'Configuration updated succesfully.')]";
            //string successmessageXpath1 = "//span[contains(text(), 'Other configuration added succesfully.')]";
        
           
            //try{ Assert.IsTrue(Browser.Wd.FindElement(By.XPath(successmessageXpath)).Displayed, "Success message for Update is not displayed"); }
            //catch { Assert.IsTrue(Browser.Wd.FindElement(By.XPath(successmessageXpath1)).Displayed, "Success message for Update is not displayed"); }
        }

        [When(@"EAM Administration Business Rules Enahance Member Dupe Check is ""(.*)""")]
        public void WhenEAMAdministrationBusinessRulesEnahanceMemberDupeCheckIs(string p0)
        {
            string status = tmsCommon.GenerateData(p0);
            By loc = By.CssSelector("[test-id='businessRules-chk-MemberDupeCheck']");
            ReUsableFunctions.CheckBoxOperations(loc, status);
        }

        [When(@"Verify that ERF ""(.*)"" link is displayed")]
        public void WhenVerifyThatERFLinkIsDisplayed(string LinkName)
        {
            WebDriverWait wait = new WebDriverWait(Browser.Wd , TimeSpan.FromSeconds(20));
            wait.Until(ExpectedConditions.InvisibilityOfElementWithText(By.XPath(".//*[@id='Loadingdiv']//span[text() = 'Please wait...']"), "Please wait..."));
            
            
            Assert.IsTrue(qalink.AttestationQuestion.Displayed, "Attestation question link is not displayed");
            qalink.AttestationQuestion.Click();           
            wait.Until(ExpectedConditions.ElementIsVisible(By.XPath(".//span[contains(text(),'Attestation Questions')]")));
        }
        [When(@"I have switched to ERF Form")]
        public void WhenIHaveSwitchedToERFForm()
        {
            obj.SwitchToERFFrame();
        }
        [When(@"I have switched back to EAM Form")]
        [Then(@"I have switched back to EAM Form")]
        public void ThenIHaveSwitchedBackToEAMForm()
        {
            obj.SwitchToEAMFrame();
        }

        [When(@"ERF MBI is set to ""(.*)""")]
        public void WhenERFMBIIsSetTo(string MBI)
        {
            MBI = tmsCommon.GenerateData(MBI);
            erfObj.ERFHIC.SendKeys(MBI);
            while(!erfObj.ERFHIC.GetAttribute("value").ToString().Equals(MBI))
            {
                erfObj.ERFHIC.Clear();
                tmsWait.Hard(2);
                fw.ExecuteJavascriptSetText(erfObj.ERFHIC, MBI);
            }
            try
            {
                Assert.IsTrue(erfObj.ERFHIC.GetAttribute("value").ToString().Equals(MBI), MBI + " is not set as MBI at UI");
            }
            catch { erfObj.ERFHIC.Clear(); erfObj.ERFHIC.SendKeys(MBI); }
        }
        [When(@"ERF PlanID is set to ""(.*)""")]
        public void WhenERFPlanIDIsSetTo(string PlanID)
        {
            PlanID = tmsCommon.GenerateData(PlanID);
            SelectElement planID = new SelectElement(erfObj.ERFPlanIDDropdown);
            planID.SelectByText(PlanID);
        }
        [When(@"ERF PBP is set to ""(.*)""")]
        public void WhenERFPBPIsSetTo(string PBPID)
        {
            PBPID = tmsCommon.GenerateData(PBPID);
            SelectElement pbpID = new SelectElement(erfObj.ERFPBPIDDropdown);
            pbpID.SelectByText(PBPID);
        }
        [When(@"ERF FName is set to ""(.*)""")]
        public void WhenERFFNameIsSetTo(string FirstName)
        {
            FirstName = tmsCommon.GenerateData(FirstName);
            erfObj.ERFFirstName.SendKeys(FirstName);
        }
        [When(@"ERF LName is set to ""(.*)""")]
        public void WhenERFLNameIsSetTo(string LastName)
        {
            LastName = tmsCommon.GenerateData(LastName);
            erfObj.ERFLastName.SendKeys(LastName);
        }

        [When(@"ERF DOB is set to current month ""(.*)"" day ""(.*)""and year ""(.*)""")]
        public void WhenERFDOBIsSetToCurrentMonthDayAndYear(string month, string day, string year)
        {
            string DOB = obj.CalculateDate(month.ToString(), day.ToString(), year.ToString());
            fw.ExecuteJavascriptSetText(erfObj.ERFDOB, DOB);
            tmsWait.Hard(3);
        }
        [When(@"ERF Gender is set to ""(.*)""")]
        public void WhenERFGenderIsSetTo(string gender)
        {
            gender = tmsCommon.GenerateData(gender);
            SelectElement pbpID = new SelectElement(erfObj.ERFGenderDropdown);
            pbpID.SelectByText(gender);
            tmsWait.Hard(3);
        }
        [When(@"ERF ElectionType is set to ""(.*)""")]
        public void WhenERFElectionTypeIsSetTo(string ElectionType)
        {
            ElectionType = tmsCommon.GenerateData(ElectionType);
            SelectElement pbpID = new SelectElement(erfObj.ERFElectionTypeDropdown);
            pbpID.SelectByText(ElectionType);
            tmsWait.Hard(1);
        }
        [When(@"ERF SEPS Reason is set to ""(.*)""")]
        public void WhenERFSEPSReasonIsSetTo(string SEPSReason)
        {
            SEPSReason = tmsCommon.GenerateData(SEPSReason);
            SelectElement pbpID = new SelectElement(erfObj.ERFSEPSReason);
            pbpID.SelectByText(SEPSReason);
            tmsWait.Hard(2);
        }
        [When(@"ERF MemberID is set to ""(.*)""")]
        public void WhenERFMemberIDIsSetTo(string MemberID)
        {
            MemberID = tmsCommon.GenerateData(MemberID);
            fw.ExecuteJavascriptSetText(erfObj.ERFMemberID, MemberID);
        }
        [When(@"ERF EffectiveDate is set to current month ""(.*)"" day ""(.*)""and year ""(.*)""")]
        public void WhenERFEffectiveDateIsSetToCurrentMonthDayAndYear(string month, string day, string year)
        {
            string effectiveDate = obj.CalculateDate(month.ToString(), day.ToString(), year.ToString());
            fw.ExecuteJavascriptSetText(erfObj.ERFEffectiveDate, effectiveDate);
            GlobalRef.effectiveDate = effectiveDate;
            tmsWait.Hard(2);
        }
        [When(@"ERF NewEffectiveDate is set to current month ""(.*)"" day ""(.*)""and year ""(.*)""")]
        public void WhenERFNewEffectiveDateIsSetToCurrentMonthDayAndYear(string month, string day, string year)
        {
            string effectiveDate = obj.CalculateDate(month.ToString(), day.ToString(), year.ToString());
            GlobalRef.effectiveDate = effectiveDate;
        }

        [When(@"ERF ReceiptDate is set to current month ""(.*)"" day ""(.*)""and year ""(.*)""")]
        public void WhenERFReceiptDateIsSetToCurrentMonthDayAndYear(string month, string day, string year)
        {
            string ReceiptDate = obj.CalculateDate(month.ToString(), day.ToString(), year.ToString());
            fw.ExecuteJavascriptSetText(erfObj.ERFReceiptDate, ReceiptDate);
            tmsWait.Hard(2);
        }

        [When(@"ERF SignatureDate is set to current month ""(.*)"" day ""(.*)""and year ""(.*)""")]
        public void WhenERFSignatureDateIsSetToCurrentMonthDayAndYear(string month, string day, string year)
        {
            string SignatureDate = obj.CalculateDate(month.ToString(), day.ToString(), year.ToString());
            fw.ExecuteJavascriptSetText(erfObj.ERFSignatureDate, SignatureDate);
            tmsWait.Hard(2);
        }
        [When(@"ERF ZIP is set to ""(.*)""")]
        public void WhenERFZIPIsSetTo(string ZIP)
        {
            ZIP = tmsCommon.GenerateData(ZIP);
            fw.ExecuteJavascriptSetText(erfObj.ERFResidenceZip, ZIP);
        }
        [When(@"ERF City is set to ""(.*)""")]
        public void WhenERFCityIsSetTo(string City)
        {
            City = tmsCommon.GenerateData(City);
            fw.ExecuteJavascriptSetText(erfObj.ERFResidenceCity, City);
        }
        [When(@"ERF County is set to ""(.*)""")]
        public void WhenERFCountyIsSetTo(string country)
        {
            country = tmsCommon.GenerateData(country);
            fw.ExecuteJavascriptSetText(erfObj.ERFResidenceCountry, country);
        }
        [When(@"ERF SCC is set to ""(.*)""")]
        public void WhenERFSCCIsSetTo(string SCC)
        {
            SCC = tmsCommon.GenerateData(SCC);
            fw.ExecuteJavascriptSetText(erfObj.ERFResidenceSCC, SCC);
        }

        [When(@"ERF State is set to ""(.*)""")]
        public void WhenERFStateIsSetTo(string state)
        {
            state = tmsCommon.GenerateData(state);
            fw.ExecuteJavascriptSetText(erfObj.ERFResidenceState, state);
        }

        [When(@"ERF Street Address is set to ""(.*)""")]
        public void WhenERFStreetAddressIsSetTo(string Address)
        {
            Address = tmsCommon.GenerateData(Address);
            fw.ExecuteJavascriptSetText(erfObj.ERFResidenceAddress1, Address);
        }
        [When(@"ERF Premium Withhold Options is set to ""(.*)""")]
        public void WhenERFPremiumWithholdOptionsIsSetTo(string PWOption)
        {
            PWOption = tmsCommon.GenerateData(PWOption);
            SelectElement pbpID = new SelectElement(erfObj.ERFPremiumWithholdOption);
            pbpID.SelectByText(PWOption);



        }
        [When(@"ERF SUBMIT button is clicked")]
        public void WhenERFSUBMITButtonIsClicked()
        {
            fw.ExecuteJavascript(erfObj.ERFSubmitbutton);
            WebDriverWait wait = new WebDriverWait(Browser.Wd,TimeSpan.FromSeconds(30));
            try { if (Browser.Wd.FindElement(By.XPath("//span[contains(.,'Possible EAM duplicates')]")).Displayed)
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'Continue Anyway')]/parent::button")));  }
           catch {
                
            }

            wait.Until(ExpectedConditions.ElementIsVisible(By.Id("ButtonResetNew")));
            tmsWait.Hard(22);
        }
        [Then(@"Verify transaction is saved successfully with message ""(.*)"",""(.*)"", ""(.*)"" ""(.*)""")]
        public void ThenVerifyTransactionIsSavedSuccessfullyWithMessage(string message1, string ElectioType, string message2, string effectiveDate)
        {
            ElectioType = tmsCommon.GenerateData(ElectioType);
            effectiveDate = GlobalRef.effectiveDate.ToString();
            message1 = message1 + ElectioType  + message2 + effectiveDate;
            Assert.IsTrue(erfObj.ERFResultsmsg.Text.Contains(message1), "Expcted message is " + erfObj.ERFResultsmsg.Text + "while message displayed at UI is" + message1);
        }
        [Then(@"Verify transaction is saved successfully with success message ""(.*)""")]
        public void ThenVerifyTransactionIsSavedSuccessfullyWithSuccessMessage(string message1)
        {
        Assert.IsTrue(erfObj.ERFResultsmsg.Text.Contains(message1), "Expcted message is " + erfObj.ERFResultsmsg.Text + "while message displayed at UI is" + message1);
        }


        [Then(@"Verify Members EletionType is set to ""(.*)""")]
        public void ThenVerifyMembersEletionTypeIsSetTo(string ElectioType)
        {
            ElectioType = tmsCommon.GenerateData(ElectioType);
            SelectElement electioTypedrpdown = new SelectElement(TMSoR1.EAM.MembersViewEdit.MemberElectionType);
           string UIElectionType = electioTypedrpdown.SelectedOption.Text;
            Assert.IsTrue(UIElectionType.Equals(ElectioType), "Member Page does not display correct election type which is :IEP2 ");
        }
        [Then(@"Verify Members EffectiveDate is set to ""(.*)""")]
        public void ThenVerifyMembersEffectiveDateIsSetTo(string effectiveDate)
        {
            effectiveDate = GlobalRef.effectiveDate.ToString();
            string effectUI = TMSoR1.EAM.MembersViewEdit.MemberViewEditEffectiveDate.GetAttribute("value").ToString();
            Assert.IsTrue(effectUI.Equals(effectiveDate), "Member Page does not display correct Effective Date which is "+ effectiveDate);
        }
        [When(@"Attestation Question ""(.*)"" is set as  ""(.*)""")]
        public void WhenAttestationQuestionIsSetAs(string question, string value)
        {
            if (question.Contains("Generate|variable")) question = tmsCommon.GenerateData(question);
            if (value.Contains("Generate|variable")) value = tmsCommon.GenerateData(value);
            string AQForm = ".//*[@id='attestationQuestionsForm']//div/label[contains(text(),'"+ question + "')]";
            IWebElement AQQuestion = Browser.Wd.FindElement(By.XPath(AQForm));
            Assert.IsTrue(AQQuestion.Displayed, question + " ,is not displayed in Attestation Question Form");
            string AQID = AQQuestion.GetAttribute("for").ToString();
            string inputAnswer = ".//*[@id='attestationQuestionsForm']//div/label[contains(text(),'" + question + "')]//following-sibling::input[@id ='"+ AQID + "' ]";
            IWebElement AQAnswer = Browser.Wd.FindElement(By.XPath(inputAnswer));
            if (value == "checked")
            { if (!AQAnswer.Selected) AQAnswer.Click(); }
            else fw.ExecuteJavascriptSetText(AQAnswer, value);
        }
        [When(@"Attestation Question OK button is clicked")]
        public void WhenAttestationQuestionOKButtonIsClicked()
        {
            fw.ExecuteJavascript(erfObj.OKButton);
            tmsWait.Hard(5);
        }
        [When(@"Transacton Search HIC Number is set to ""(.*)""")]
        public void WhenTransactonSearchHICNumberIsSetTo(string MBI)
        {
            MBI = tmsCommon.GenerateData(MBI);
            fw.ExecuteJavascriptSetText(TransVieEdit.MBITransViewEdit, MBI);
        }
        [When(@"Transacton View Edit Search button is clicked")]
        public void WhenTransactonViewEditSearchButtonIsClicked()
        {
            fw.ExecuteJavascript(TransVieEdit.SearchTransViewEdit);
            WebDriverWait wait = new WebDriverWait(Browser.Wd,TimeSpan.FromSeconds(30));
            wait.Until(ExpectedConditions.ElementIsVisible(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dgTrans")));
        }


        [Then(@"Transaction View Edit Table has row")]
        public void ThenTransactionViewEditTableHasRow(Table gherkintable)
        {
            IWebElement UITable = TransVieEdit.TransactionsTable;
            IDictionary<int ,string[]> Gtable  = tableoperation.ReadGherkinTable(gherkintable);
        }
        [Then(@"Transaction View Edit Table Edit Icon is clicked for row")]
        public void ThenTransactionViewEditTableEditIconIsClickedForRow(Table table)
        {
            IWebElement UITableObj = TransVieEdit.TransactionsTable;
            Dictionary<int, string[]> Gtable = tableoperation.ReadGherkinTable(table);
            Dictionary<int, string[]> UItable = tableoperation.readUItable(UITableObj);
            bool isselected = tableoperation.SelectRowAtUI(UItable, Gtable, UITableObj);
        }

        [Then(@"Verify Transaction New MBI is set to ""(.*)""")]
        public void ThenVerifyTransactionNewMBIIsSetTo(string MBI)
        {
            MBI = tmsCommon.GenerateData(MBI);

            string UIMBI = newTransObj.HIC.GetAttribute("value").ToString();
            Assert.IsTrue(UIMBI.Equals(MBI), UIMBI + " at UI do not match with expected" + MBI);

        }

        [Then(@"Verify Transaction EletionType is set to ""(.*)""")]
        public void ThenVerifyTransactionEletionTypeIsSetTo(string electionType)
        {
            electionType = tmsCommon.GenerateData(electionType);
            SelectElement ElectionTypeDropDwn = new SelectElement(newTransObj.ElectionType);
            string UIElectionType = ElectionTypeDropDwn.SelectedOption.Text.ToString();
            //string UIElectionType = fw.ExecuteJavascriptReturnText(newTransObj.ElectionType).ToString();
            Assert.IsTrue(electionType.Equals(UIElectionType), UIElectionType + " at UI do not match with expected" + electionType);
        }
        [Then(@"Verify Transaction EffectiveDate is set to ""(.*)""")]
        public void ThenVerifyTransactionEffectiveDateIsSetTo(string EffectiveDate)
        {
            EffectiveDate = GlobalRef.effectiveDate.ToString();
            Assert.IsTrue(newTransObj.EffectiveDate.GetAttribute("value").ToString().Equals(EffectiveDate), "Expected effective date at UI is " + EffectiveDate);
        }

        [Then(@"Election type question form icon is clicked")]
        public void ThenElectionTypeQuestionFormIconIsClicked()
        {
            TransVieEdit.AQLink.Click();
            WebDriverWait wait = new WebDriverWait(Browser.Wd, TimeSpan.FromSeconds(20));           
            wait.Until(ExpectedConditions.ElementIsVisible(By.Id("ctl00_ctl00_MainMasterContent_MainContent_pnlElection")));
        }
        [Then(@"Verify that All the fields are read only")]
        public void ThenVerifyThatAllTheFieldsAreReadOnly()
        {
            verificationErrors = new StringBuilder();
            string xpath1 = ".//*[@id='ctl00_ctl00_MainMasterContent_MainContent_pnlElection']//input[contains(@id,'ctl00_ctl00_MainMasterContent_MainContent_txtDate')]";
            string xpath2 = ".//*[@id='ctl00_ctl00_MainMasterContent_MainContent_pnlElection']//input[contains(@id,'ctl00_ctl00_MainMasterContent_MainContent_chk')]";
            IList<IWebElement> AQQuestionsInputFieldDate = new List<IWebElement>();
            AQQuestionsInputFieldDate = Browser.Wd.FindElements(By.XPath(xpath1));
            IList<IWebElement> AQQuestionsInputFieldcheckbox = new List<IWebElement>();
            AQQuestionsInputFieldcheckbox = Browser.Wd.FindElements(By.XPath(xpath2));
            
            foreach (var question in AQQuestionsInputFieldDate)
            {
                
                try
                {
                    Assert.IsTrue(!question.Enabled, question.GetAttribute("name").ToString()+" is enabled");
                }
                catch(Exception e)
                {
                    if (question.GetAttribute("type").ToString().Contains("image")) Console.WriteLine("this is a calendar image");
                    else if (question.GetAttribute("type").ToString().Contains("hidden")) Console.WriteLine("this is a hidden image");
                    else verificationErrors.Append(e.ToString());
                }
            }
            foreach (var question in AQQuestionsInputFieldcheckbox)
            {
                try
                {
                    Assert.IsTrue(!question.Enabled, question.GetAttribute("name").ToString() + " is enabled");
                }
                catch (Exception e)
                {
                    verificationErrors.Append(e.ToString());
                }
            }
        }

    }


}
