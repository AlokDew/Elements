﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.EAM

{ 
     [Binding]
   class cfTestMember
    {
        public static TestMember TestMemberPage {
            get {
                return new TestMember();
            }
        }
    }

    [Binding]
    public class TestMember
    {
        public IWebElement MBI {
            get
            {
                return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtHic_01"));
            }
        }
        public IWebElement Save {
            get {
                return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSave"));
            }
        }
        public IWebElement PlanID
        {
            get
            {
                return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPlanID_10"));
            }
        }

        public IWebElement Fname
        {
            get
            {
                return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtFName_03"));
            }
        }

        public IWebElement Lname
        {
            get
            {
                return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtLName_02"));
            }
        }

        public IWebElement PBP
        {
            get
            {
                return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPBP_08"));
            }
        }

        public IWebElement EffDate
        {
            get
            {
                return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtEffDate_14"));
            }
        }

        public IWebElement DOB
        {
            get
            {
                return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtDOB_06"));
            }
        }

        public IWebElement Sex
        {
            get
            {
                return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboSex_05"));
            }
        }
        public IWebElement RxID
        {
            get
            {
                return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtRxID_39"));
            }
        }
        public IWebElement MemberId
        {
            get
            {
                return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtMemberID_43"));
            }
        }
    }

}

  
    

