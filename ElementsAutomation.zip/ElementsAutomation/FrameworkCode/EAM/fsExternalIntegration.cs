﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using TMSoR1.FrameworkCode;

namespace TMSoR1
{
    [Binding]
    class fsExternalIntegration
    {

        [Then(@"Verify External Integration page EAM Option button is displayed")]
        public void ThenVerifyExternalIntegrationPageEAMOptionButtonIsDisplayed()
        {
            AngularFunction.elementPresenceUsingWebElement(cfExternalIntegration.EAMIntegration.EAMOptionButton);
        }


    }
}
