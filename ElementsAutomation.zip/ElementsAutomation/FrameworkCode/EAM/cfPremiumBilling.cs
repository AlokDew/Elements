﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using TechTalk.SpecFlow;
namespace TMSoR1
{
    public class PremiumBilling
    {
        public static RxBillingTab RxBillingTab { get { return new RxBillingTab(); } }
    }


    [Binding]

    public class RxBillingTab
    {
        public IWebElement PartCAmount { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_txtPartC")); } }

    }

}
