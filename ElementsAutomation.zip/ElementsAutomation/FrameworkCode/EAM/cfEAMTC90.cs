﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1
{
    [Binding]
    class cfEAMTC90
    {
        public static TC90DrugEditTC TC90DrugEditTC { get { return new TC90DrugEditTC(); } }


    }

    [Binding]
    class TC90DrugEditTC
    {
        // Defining Locators
        public IWebElement mbiLookup { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='deleteSubmittedDiagnosis-a-providerLookup']")); } }

        public IWebElement MBITextBox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='member-txt-hic']")); } }
        public IWebElement MemberTextBox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='member-txt-memberid']")); } }

        public IWebElement FirstNameTextBox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='member-txt-firstname']")); } }
        public IWebElement LastNameTextBox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='member-txt-lastname']")); } }
        public IWebElement SearchButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='member-btn-search']")); } }
        public IWebElement ResetButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='member-btn-reset']")); } }
        public IWebElement AddButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='member-btn-select']")); } }
        public IWebElement CancelButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='member-btn-cancel']")); } }
        public IWebElement planIDDrpOwns { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Plan Id')]/parent::div//span[@class='k-select']")); } }
        public IWebElement addUpdateDeleteFlagOwns { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='formInputBoxAUD_listbox']")); } }
        public IWebElement posEditStatus { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='formInputBoxDos_listbox']")); } }
        public IWebElement NotificationStartDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='tc90-txt-notificationStartDate']")); } }
        public IWebElement NotificationEndDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='tc90-txt-notificationEndDate']")); } }
        public IWebElement ImplementationStartDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='tc90-txt-implementationStartDate']")); } }
        public IWebElement ImplementationEndDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='tc90-txt-implementationEndDate']")); } }
        public IWebElement drugClass { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='tc90-select-drugclass']")); } }
        public IWebElement posEditCode { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='tc90-select-poseditcode']")); } }
        public IWebElement Prescriber_Limitation_Status { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='formInputBoxAging_listbox']")); } }
        public IWebElement Pharmacy_Limitation_Status { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='formInputBoxAging_listbox']")); } }
        public IWebElement Savebutton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='tc90-btn-save']")); } }
        public IWebElement Resetbutton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='tc90-btn-reset']")); } }



    }
}
