﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using TechTalk.SpecFlow;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using System.Diagnostics;
using System.Windows;
using System.Collections.ObjectModel;

namespace TMSoR1.FrameworkCode.EAM
{
  
   public class cfEAMWorkflowConfiguration

    {

        public static WFConfigurationPage WFConfigurationPage { get { return new WFConfigurationPage(); } }
    }

    [Binding]
    public class WFConfigurationPage
    {

        public IWebElement WFConfigurationName { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='workflowEngine-txt-configurationName']")); } }

        public IWebElement WFApplicationurl { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='workflowEngine-txt-applicationUrl']")); } }

        public IWebElement WFEndpointurl { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='workflowEngine-txt-serviceEndpointUrl']")); } }

        public IWebElement WFConfigsave { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'SAVE')]")); } }

        public IWebElement ManageConfig { get { return Browser.Wd.FindElement(By.XPath("//div//td/a[contains(.,'Manage Configuration')]")); } }

        public IWebElement ManageConfigsave { get { return Browser.Wd.FindElement(By.XPath("//button//span[contains(.,'SAVE')]")); } }

        public IWebElement ManageConfigBackButton { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Back To Record')]")); } }

        public IWebElement WFModenoqueue { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'There are no work items in the queue. Please try again later!')]")); } }

        public IWebElement WFDashboardBAdMessage{ get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='workflowDashboard-lbl-badMessageCount']")); } }

        public IWebElement WFDashboardSelectAll { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='workflow-cb-workflowgrid']")); } }

        public IWebElement WFBacktoDashboardlink{ get { return Browser.Wd.FindElement(By.XPath("//span[@test-id='workflowDetails-span-backToDashboard']")); } }

        public IWebElement WFGetwokingonitem { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='workflowControl-lbl-message']")); } }

        public IWebElement WorkflowitemKeyElement { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='workflowControl-lbl-message']/following-sibling::span")); } }

        public IWebElement WFModeBacktoMember { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Back to Member Info')]")); } }

        public IWebElement WFlockbutton { get { return Browser.Wd.FindElement(By.XPath("//i[@class='fas fa-lock fa-x text-secondary border-0 p-0']")); } }

        public IWebElement WFlockedbyUser { get { return Browser.Wd.FindElement(By.XPath("  //i[@class='fas fa-lock fa-x text-secondary border-0 p-0']//following-sibling::span")); } }

        public IWebElement CheckboxWF1 { get { return Browser.Wd.FindElement(By.XPath("//input[@id='k-grid1-checkbox0']")); } }

        public IWebElement CheckboxWF2 { get { return Browser.Wd.FindElement(By.XPath("//input[@id='k-grid1-checkbox1']")); } }

        public IWebElement CheckboxWF3 { get { return Browser.Wd.FindElement(By.XPath("//input[@id='k-grid1-checkbox2']")); } }

        public IWebElement CheckboxWF4 { get { return Browser.Wd.FindElement(By.XPath("//input[@id='k-grid1-checkbox3']")); } }

        public IWebElement WFPageHomeMenu { get { return Browser.Wd.FindElement(By.XPath("//tz-chip[contains(.,'Home')]")); } }

        public IWebElement WFPageInventoryMenu { get { return Browser.Wd.FindElement(By.XPath("//tz-chip[contains(.,'Inventory')]")); } }

        public IWebElement WFPageEAMName { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'EAM Medicare Enrollment')]")); } }

        public IWebElement WFPageUserMenu { get { return Browser.Wd.FindElement(By.XPath("//tz-chip[contains(.,'User')]")); } }

        public IWebElement WFPageWorkItemMenu { get { return Browser.Wd.FindElement(By.XPath("//tz-chip[contains(.,'Work Item')]")); } }

        public IWebElement WFPageWorkforceMenu { get { return Browser.Wd.FindElement(By.XPath("//tz-chip[contains(.,'Workforce')]")); } }

        public IWebElement WFPageGoConfiguration { get { return Browser.Wd.FindElement(By.XPath("//div//tz-icon[@class='tz-toolbar-app-switcher-icon-fill']")); } }

        public IWebElement WFPagePropertiesMenu { get { return Browser.Wd.FindElement(By.XPath("//tz-chip[contains(.,'Properties')]")); } }


        public IWebElement WFPageMenuAdmin { get { return Browser.Wd.FindElement(By.XPath("//tz-chip[contains(.,'Admin')]")); } }

        public IWebElement WFPageMenuQualifiers { get { return Browser.Wd.FindElement(By.XPath("//tz-chip[contains(.,'Qualifiers')]")); } }

        public IWebElement WFPageMenuRoles { get { return Browser.Wd.FindElement(By.XPath("//tz-chip[contains(.,'Roles')]")); } }

        public IWebElement WFPageMenuQueues { get { return Browser.Wd.FindElement(By.XPath("//tz-chip[contains(.,'Queues')]")); } }

        public IWebElement WFPageMenuRules { get { return Browser.Wd.FindElement(By.XPath("//tz-chip[contains(.,'Rules')]")); } }

        public IWebElement WFPageMenuUsers { get { return Browser.Wd.FindElement(By.XPath("//tz-chip[contains(.,'Users')]")); } }

        public IWebElement WFSortPriority { get { return Browser.Wd.FindElement(By.XPath("//table[@role='presentation']//span[contains(.,'Priority')]")); } }

    }


}
