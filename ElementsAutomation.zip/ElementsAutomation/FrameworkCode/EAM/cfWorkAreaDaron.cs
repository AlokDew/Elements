﻿//using System;
//using Microsoft.VisualStudio.TestTools.UnitTesting;
//using OpenQA.Selenium;
//using System.Collections.ObjectModel;
//using OpenQA.Selenium.Firefox;
//using OpenQA.Selenium.IE;
//using OpenQA.Selenium.Support.UI;
//using System.Collections;
//using System.Collections.Generic;

//namespace MultipleMembers
//{
//    [TestClass]
//    public class UnitTest1
//    {
//        InternetExplorerDriver ie;

//        [TestMethod]
//        public void TestMethod1()
//        {
//            // firefox = new FirefoxDriver();
//            ie = new InternetExplorerDriver(@"C:\tms\");

//            ie.Navigate().GoToUrl("http://abn-pdm-app-d16/PDMAdministration/Administration/Login.aspx");

//            ie.FindElement(By.Id("lcLogin_txtLogin")).SendKeys("SwapnaC");
//            ie.FindElement(By.Id("lcLogin_txtPwd")).SendKeys("Welcome1");

//            ie.FindElement(By.Id("lcLogin_cmdSubmit")).Submit();

//            System.Threading.Thread.Sleep(2 * 1000);


//            //ie.FindElement(By.XPath(".//*[@id='ctl00_ctl00_MainMasterContent_EamNavigation_Hyperlink3']")).Click();

//            ie.FindElement(By.XPath("//a[@href='Member/MemberViewEdit.aspx?context=new']")).Click();

//            System.Threading.Thread.Sleep(2 * 1000);

//            //Send HIC
//            string HIC = "HSPC_new1";
//         //   System.Threading.Thread.Sleep(10 * 1000);
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtHic_01")).SendKeys(HIC);

//            //Group
//            IWebElement webGroup = ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboGroup"));
//            SelectElement select = new SelectElement(ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboGroup")));
//            select.SelectByText("MEDPLUSS");

//            //SelectElement(ie.FindElement(By.XPath("ctl00_ctl00_MainMasterContent_MainContent_cboGroup"))).

//            System.Threading.Thread.Sleep(3 * 1000);
//            //Subgroup
//            IWebElement subGroup = ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboSubGroup"));

//            SelectElement select1 = new SelectElement(ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboSubGroup")));
//            select1.SelectByText("MED1");

//            System.Threading.Thread.Sleep(2 * 1000);

//            //Class
//            IWebElement subclass = ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboClass"));

//            SelectElement select2 = new SelectElement(ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboClass")));

//            select2.SelectByText("MED1");

//            // ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboClass")).SendKeys("MED1");

//            // firefox.Navigate().GoToUrl("http://abn-pdm-app-d16/PDMAdministration/Administration/Login.aspx");



//            //Member ID
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtMemberID_43")).SendKeys("HSPC_new1");

//            //First and Last name
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtFName_03")).SendKeys("HSPC_new1");
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtLName_02")).SendKeys("HSPC_new1");

//            System.Threading.Thread.Sleep(1 * 1000);

//            //DOB
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtDOB_06")).Clear();

//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtDOB_06")).SendKeys("02291956");

//            System.Threading.Thread.Sleep(2 * 1000);
//            //Sex

//            IWebElement sex = ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboSex_05"));
//            SelectElement sexsel = new SelectElement(ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboSex_05")));
//            sexsel.SelectByText("F");

//            //Plan ID

//            SelectElement selectPlanID = new SelectElement(ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPlanID_10")));
//            selectPlanID.SelectByText("PDM01");

//            System.Threading.Thread.Sleep(2 * 1000);

//            //PBP

//            SelectElement selectPBP = new SelectElement(ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPBP_08")));
//            selectPBP.SelectByText("001");
//            System.Threading.Thread.Sleep(2 * 1000);

//            //Effdate
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtEffDate_14")).Clear();
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtEffDate_14")).SendKeys("01012014");

//            System.Threading.Thread.Sleep(1 * 1000);
//            //Election Type
//            SelectElement ElectType = new SelectElement(ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboElections")));
//            ElectType.SelectByText("AEP");

//            System.Threading.Thread.Sleep(2 * 1000);
//            //RXID
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtRxID_39")).SendKeys("3214");

//            //Save
//            // ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSave")).Click();

//            //Click on Eligibility
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnStatus")).Click();
//            System.Threading.Thread.Sleep(2 * 1000);

//            //Part A effective date
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberStatus_txtPlanPartA")).Clear();
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberStatus_txtPlanPartA")).SendKeys("01012014");

//            //Part B effective date
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberStatus_txtPlanPartB")).Clear();
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberStatus_txtPlanPartB")).SendKeys("01012014");

//            //Part D effective date
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberStatus_txtPlanPartD")).Clear();
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberStatus_txtPlanPartD")).SendKeys("01012014");


//            //Click on RX/Billing
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnBilling")).Click();
//            System.Threading.Thread.Sleep(2 * 1000);


//            //Part C premium
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_txtPartC")).SendKeys("0.00");

//            //Part D premium
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_txtPartD")).SendKeys("0.00");

//            //Bill amount

//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_txtAmount")).SendKeys("0.00");

//            //Credit cover

//            IWebElement credit = ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_cboCreditCov"));
//            SelectElement selectCredit = new SelectElement(ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_cboCreditCov")));
//            selectCredit.SelectByText("Y");
//            System.Threading.Thread.Sleep(2 * 1000);


//            //Medical ID
//            SelectElement selectMedical = new SelectElement(ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_drpMedical")));
//            selectMedical.SelectByText("MEDPLUS0");
//            System.Threading.Thread.Sleep(2 * 1000);

//            //Pharmacy ID
//            SelectElement selecPharma = new SelectElement(ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_drpPharmacy")));
//            selecPharma.SelectByText("HPNPLISC");
//            System.Threading.Thread.Sleep(2 * 1000);


//            //Dental
//            SelectElement selectDental = new SelectElement(ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_drpDental")));
//            selectDental.SelectByText("D9870099D9870099D987");
//            System.Threading.Thread.Sleep(2 * 1000);

//            //Vision
//            SelectElement selectVision = new SelectElement(ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_drpVision")));
//            selectVision.SelectByText("VISION1");
//            System.Threading.Thread.Sleep(2 * 1000);

//            //Payment Tab
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnPayment")).Click();
//            System.Threading.Thread.Sleep(2 * 1000);

//            //Biling Profile
//            SelectElement selectBilling = new SelectElement(ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_cboBillingProfile")));
//            selectBilling.SelectByText("a");
//            System.Threading.Thread.Sleep(2 * 1000);

//            //Save
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSave")).Click();

//            //Transaction 
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnTransactions")).Click();

//            //Add new trans
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucTransHistory_LinkButton1")).Click();
//            System.Threading.Thread.Sleep(2 * 1000);

//            //Transcode
//            SelectElement selecttransCode = new SelectElement(ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboTransCode_12")));
//            selecttransCode.SelectByText("61");
//            System.Threading.Thread.Sleep(2 * 1000);


//            //Application type
//            SelectElement SelectAppType = new SelectElement(ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboAppType")));
//            SelectAppType.SelectByText("Paper Enrollment");

//            //Effective date
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtEffDate_14")).Clear();
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtEffDate_14")).SendKeys("01012014");

//            //signature date

//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtAppDate_11")).Clear();
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtAppDate_11")).SendKeys("10102013");
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txt_ReceiptDate_46")).Clear();
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txt_ReceiptDate_46")).SendKeys("10102013");

//            //Election type
//            SelectElement selectelect = new SelectElement(ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboElectionPeriod_09")));
//            selectelect.SelectByText("AEP");
//            System.Threading.Thread.Sleep(2 * 1000);

//            //Zip
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtZip")).SendKeys("12007");
//            System.Threading.Thread.Sleep(2 * 1000);

//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtStreetAddr")).SendKeys("gsdfsd");

//            //Save
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSave")).Click();
//            System.Threading.Thread.Sleep(2 * 1000);

//            //Status Override
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_EamNavigation_pnlUserAdmin_itemStatusOverride_link")).Click();

//            //Status Override
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_EamNavigation_pnlUserAdmin_itemStatusOverride_link")).Click();
//            System.Threading.Thread.Sleep(2 * 1000);

//            //TRansaction checkbox
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_EamNavigation_pnlUserAdmin_itemStatusOverride_link")).Click();
//            System.Threading.Thread.Sleep(2 * 1000);

//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtHic")).SendKeys(HIC);
//            System.Threading.Thread.Sleep(1 * 1000);

//            //Search button
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSearch")).Click();
//            System.Threading.Thread.Sleep(2 * 1000);
//            //Edit
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dgTrans")).Click();

//            //Trans status
//            SelectElement transSelect = new SelectElement(ie.FindElement(By.Id("tl00_ctl00_MainMasterContent_MainContent_cboTStatus")));
//            transSelect.SelectByText("Accepted By CMS");
//            System.Threading.Thread.Sleep(2 * 1000);

//            //Transcode
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtReplyCode")).SendKeys("011");

//            //Export
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_chkResetExport")).Click();
//            System.Threading.Thread.Sleep(2 * 1000);
//            //Save
//            ie.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSave")).Click();
//            System.Threading.Thread.Sleep(2 * 1000);



//        }

//        [TestCleanup]
//        public void TearDown()
//        {
//            //firefox.Quit();
//            ie.Quit();
//        }
//    }
//}
