﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1
{
    [Binding]
    class cfUIMODCreateTransaction
    {
        public static UIMODCreateTransactionBasic UIMODCreateTransactionBasic { get { return new UIMODCreateTransactionBasic(); } }
        public static TransDemographicsDetails TransDemographics { get { return new TransDemographicsDetails(); } }
        public static TransRxDetails TransRxDetails { get { return new TransRxDetails(); } }
        public static TransactionRelatedPlanFields TransactionRelatedPlanFields { get { return new TransactionRelatedPlanFields(); } }
        public static MemberRelatedPlanFields MemberRelatedPlanFields { get { return new MemberRelatedPlanFields(); } }
        public static CoreEligibilityDetails CoreEligibilityDetails { get { return new CoreEligibilityDetails(); } }
        public static ResidenceAddress ResidenceAddress { get { return new ResidenceAddress(); } }
        public static MailingAddress MailingAddress { get { return new MailingAddress(); } }
        public static ResidenceAddressUpdate ResidenceAddressUpdate { get { return new ResidenceAddressUpdate(); } }
        public static EmergencyContact EmergencyContact { get { return new EmergencyContact(); } }
        public static MedicareInsurance MedicareInsurance { get { return new MedicareInsurance(); } }
        public static ApplicationDisposition ApplicationDisposition { get { return new ApplicationDisposition(); } }
    }

    [Binding]
    public class ApplicationDisposition
    {
        public IWebElement NameOfAgentDrp { get { return Browser.Wd.FindElement(By.CssSelector("//div[@id='div_ApplicationDispositionNameOfAgentBroker']/span")); } }
        public IWebElement ProblemCaseTypeDrp { get { return Browser.Wd.FindElement(By.XPath("//div[@id='div_ApplicationDispositionProblemCaseType']/span")); } }
        public IWebElement OnHoldTransactionStatusDrp { get { return Browser.Wd.FindElement(By.CssSelector("//div[@id='div_ApplicationDispositionOnHoldTransactionStatus']/span")); } }
        public IWebElement OnHoldReasonDrp { get { return Browser.Wd.FindElement(By.CssSelector("//div[@id='div_ApplicationDispositionOnHoldReason']/span")); } }
        public IWebElement MissingItemDrp { get { return Browser.Wd.FindElement(By.XPath("//div[@id='div_ApplicationDispositionMissingItem']/span")); } }
        public IWebElement DenialReasonDrp { get { return Browser.Wd.FindElement(By.CssSelector("//div[@id='div_ApplicationDispositionDenialReason']/span")); } }
        public IWebElement MissingItemOther{ get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ApplicationDispositionOther']")); } }
        public IWebElement DenialReasonOther { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ApplicationDispositionDenialReasonOther']")); } }
        public IWebElement SalesLocation { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ApplicationDispositionSaleLocation']")); } }
        public IWebElement SalesDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ApplicationDispositionSaleDate']")); } }
        public IWebElement RFIReceiptDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ApplicationDispositionRfiReceiptDate']")); } }
        public IWebElement InCompleteApplicationCheckbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ApplicationDispositionIncompleteApplication']")); } }
        public IWebElement ForceDenyCheckbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ApplicationDispositionForceDeny']")); } }
        public IWebElement ForceAcceptanceCheckbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ApplicationDispositionForceAcceptance']")); } }
        public IWebElement ResetExportLegacycheckbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ApplicationDispositionResetExportLegacy']")); } }
        public IWebElement AngForceDenyCheckbox { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Force Deny')]/preceding-sibling::input")); } }
        public IWebElement AngForceAcceptanceCheckbox { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Force Acceptance')]/preceding-sibling::input")); } }
        public IWebElement AngResetExportLegacycheckbox { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Reset Export Legacy')]/preceding-sibling::input")); } }
        public IWebElement AngInCompleteApplicationCheckbox { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Incomplete Application')]/preceding-sibling::input")); } }
       
    }

    [Binding]
    public class MedicareInsurance
    {
        public IWebElement PartAEffectiveDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='MedicareInsurancePartAEffectiveDate']")); } }
        public IWebElement PartBEffectiveDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='MedicareInsurancePartBEffectiveDate']")); } }
        public IWebElement PartDEffectiveDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='MedicareInsurancePartDEffectiveDate']")); } }
    }

    [Binding]
    public class EmergencyContact
    {
        public IWebElement EmergencyContactField { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='EmergencyContactEmergencyContact']")); } }
        public IWebElement EmergencyContactphone { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='EmergencyContactEmergencyContactphone']")); } }
        public IWebElement EmergencyContactRelationship { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='EmergencyContactEmergencyContactRelationship']")); } }
    }

        [Binding]
    public class MailingAddress
    {
        public IWebElement MailingAddress1 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='MailingAddressMailingAddress1']")); } }
        public IWebElement MailingAddress2 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='MailingAddressMailingAddress2']")); } }
        public IWebElement City { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='MailingAddressCity']")); } }
        public IWebElement State { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='MailingAddressState']")); } }
        public IWebElement Zip { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='MailingAddressZip']")); } }
        public IWebElement SCCCode { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='MailingAddressSCC']")); } }
        public IWebElement County { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='MailingAddressMailingCounty']")); } }
    }

    [Binding]
    public class ResidenceAddress
    {
        public IWebElement StreetAddress1 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Transactioncode61ResidentialAddressupdateStreetAddress']")); } }
        public IWebElement StreetAddress2 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Transactioncode61ResidentialAddressupdateStreetAddress2']")); } }
        public IWebElement City { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Transactioncode61ResidentialAddressupdateCity']")); } }
        public IWebElement State { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Transactioncode61ResidentialAddressupdateState']")); } }
        public IWebElement Zip { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Transactioncode61ResidentialAddressupdateZip']")); } }
        public IWebElement Zip76 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Transactioncode76ResidentialAddressupdateZip']")); } }
        public IWebElement SCCCode { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Transactioncode61ResidentialAddressupdateSccCode']")); } }
        public IWebElement CountyDropDownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='{{section.name}}{{::field.name}}_listbox']")); } }
        public IWebElement Phone { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Transactioncode61ResidentialAddressupdatePhone']")); } }
        public IWebElement AlternatePhone { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Transactioncode61ResidentialAddressupdateAlternatePhone']")); } }
        public IWebElement Email { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Transactioncode61ResidentialAddressupdateEmail']")); } }
        public IWebElement ZipFour { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Transactioncode76ResidentialAddressupdateZipFour']")); } }
        public IWebElement AddressEffectiveDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Transactioncode76ResidentialAddressupdateAddressEffectiveDate']")); } }
        public IWebElement ActionDropDownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='{{section.name}}{{::field.name}}_listbox']")); } }
        public IWebElement AddressEndDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Transactioncode76ResidentialAddressupdateAddressEndDate']")); } }
    }


    [Binding]
    public class CoreEligibilityDetails
    {
        public IWebElement GroupDropDownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='{{section.name}}{{::field.name}}_listbox']")); } }
        public IWebElement SubGroupDropDownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='{{section.name}}{{::field.name}}_listbox']")); } }
        public IWebElement ClassDropDownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='{{section.name}}{{::field.name}}_listbox']")); } }
        public IWebElement MedicalIDDropDownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='{{section.name}}{{::field.name}}_listbox']")); } }
        public IWebElement PharmacyIDDropDownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='{{section.name}}{{::field.name}}_listbox']")); } }
        public IWebElement DentalIDDropDownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='{{section.name}}{{::field.name}}_listbox']")); } }
        public IWebElement VisionIDDropDownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='{{section.name}}{{::field.name}}_listbox']")); } }
        public IWebElement UseMappingCheckbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='CoreEligibilityDetailsUseMapping']")); } }


    }

    [Binding]
    public class MemberRelatedPlanFields
    {
        public IWebElement Plan1 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PlanDefinedMemberLevelPlan1']")); } }
        public IWebElement Plan2 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PlanDefinedMemberLevelPlan2']")); } }
        public IWebElement Plan3 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PlanDefinedMemberLevelPlan3']")); } }
        public IWebElement Plan4 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PlanDefinedMemberLevelPlan4']")); } }
        public IWebElement Plan5 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PlanDefinedMemberLevelPlan5']")); } }
        public IWebElement Plan6 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PlanDefinedMemberLevelPlan6']")); } }
        public IWebElement Plan7 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PlanDefinedMemberLevelPlan7']")); } }
        public IWebElement Plan8 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PlanDefinedMemberLevelPlan8']")); } }
        public IWebElement Plan9 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PlanDefinedMemberLevelPlan9']")); } }
        public IWebElement Plan10 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PlanDefinedMemberLevelPlan10']")); } }
    }

    [Binding]
    public class TransactionRelatedPlanFields
    {
        public IWebElement Plan1 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='TransactionRelatedPlanFieldsPlan1']")); } }
        public IWebElement Plan2 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='TransactionRelatedPlanFieldsPlan2']")); } }
        public IWebElement Plan3 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='TransactionRelatedPlanFieldsPlan3']")); } }
        public IWebElement Plan4 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='TransactionRelatedPlanFieldsPlan4']")); } }
        public IWebElement Plan5 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='TransactionRelatedPlanFieldsPlan5']")); } }
        public IWebElement Plan6 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='TransactionRelatedPlanFieldsPlan6']")); } }
        public IWebElement Plan7 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='TransactionRelatedPlanFieldsPlan7']")); } }
        public IWebElement Plan8 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='TransactionRelatedPlanFieldsPlan8']")); } }
        public IWebElement Plan9 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='TransactionRelatedPlanFieldsPlan9']")); } }
        public IWebElement Plan10 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='TransactionRelatedPlanFieldsPlan10']")); } }
        
        public IWebElement labelPlan1 { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='TransactionRelatedPlanFieldsPlan1']/parent::span/preceding-sibling::label")); } }
        public IWebElement labelPlan2 { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='TransactionRelatedPlanFieldsPlan2']/parent::span/preceding-sibling::label")); } }
        public IWebElement labelPlan3 { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='TransactionRelatedPlanFieldsPlan3']/parent::span/preceding-sibling::label")); } }
        public IWebElement labelPlan4 { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='TransactionRelatedPlanFieldsPlan4']/parent::span/preceding-sibling::label")); } }
        public IWebElement labelPlan5 { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='TransactionRelatedPlanFieldsPlan5']/parent::span/preceding-sibling::label")); } }
        public IWebElement labelPlan6 { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='TransactionRelatedPlanFieldsPlan6']/parent::span/preceding-sibling::label")); } }
        public IWebElement labelPlan7 { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='TransactionRelatedPlanFieldsPlan7']/parent::span/preceding-sibling::label")); } }
        public IWebElement labelPlan8 { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='TransactionRelatedPlanFieldsPlan8']/parent::span/preceding-sibling::label")); } }
        public IWebElement labelPlan9 { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='TransactionRelatedPlanFieldsPlan9']/parent::span/preceding-sibling::label")); } }
        public IWebElement labelPlan10 { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='TransactionRelatedPlanFieldsPlan10']/parent::span/preceding-sibling::label")); } }

        public IWebElement labelPlan1AngJS { get { return Browser.Wd.FindElement(By.XPath("(//div[@id='TransactionRelatedPlanFields']//label[1])[1]")); } }
        public IWebElement labelPlan2AngJS { get { return Browser.Wd.FindElement(By.XPath("(//div[@id='TransactionRelatedPlanFields']//label[1])[2]")); } }
        public IWebElement labelPlan3AngJS { get { return Browser.Wd.FindElement(By.XPath("(//div[@id='TransactionRelatedPlanFields']//label[1])[3]")); } }
        public IWebElement labelPlan4AngJS{ get { return Browser.Wd.FindElement(By.XPath("(//div[@id='TransactionRelatedPlanFields']//label[1])[4]")); } }
        public IWebElement labelPlan5AngJS{ get { return Browser.Wd.FindElement(By.XPath("(//div[@id='TransactionRelatedPlanFields']//label[1])[5]")); } }
        public IWebElement labelPlan6AngJS { get { return Browser.Wd.FindElement(By.XPath("(//div[@id='TransactionRelatedPlanFields']//label[1])[6]")); } }
        public IWebElement labelPlan7AngJS { get { return Browser.Wd.FindElement(By.XPath("(//div[@id='TransactionRelatedPlanFields']//label[1])[7]")); } }
        public IWebElement labelPlan8AngJS { get { return Browser.Wd.FindElement(By.XPath("(//div[@id='TransactionRelatedPlanFields']//label[1])[8]")); } }
        public IWebElement labelPlan9AngJS { get { return Browser.Wd.FindElement(By.XPath("(//div[@id='TransactionRelatedPlanFields']//label[1])[9]")); } }
        public IWebElement labelPlan10AngJS { get { return Browser.Wd.FindElement(By.XPath("(//div[@id='TransactionRelatedPlanFields']//label[1])[10]")); } }
    }
    [Binding]
    public class TransRxDetails
    {
        public IWebElement PrimaryRxID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='RxDetailsPrimaryRxID']")); } }
        public IWebElement PrimaryRxGroup { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='RxDetailsPrimaryRxGroup']")); } }
        public IWebElement PrimaryRxBin { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='RxDetailsPrimaryRxBIN']")); } }
        public IWebElement PrimaryRxPCN { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='RxDetailsPrimaryRxPCN']")); } }
        public IWebElement SecondaryRxID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='RxDetailsSecondaryRxID']")); } }
        public IWebElement SecondaryRxGroup { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='RxDetailsSecondaryRxGroup']")); } }
        public IWebElement SecondaryRxBin { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='RxDetailsSecondaryRxBIN']")); } }
        public IWebElement SecondaryRxPCN { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='RxDetailsSecondaryRxPCN']")); } }
        public IWebElement SecondaryRxInsurFlagDropDownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='{{section.name}}{{::field.name}}_listbox']")); } }
    }

    [Binding]
    public class UIMODCreateTransactionBasic
    {
        public IWebElement TCCodeDropDownList { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='transaction-select-code']//span[@class='k-select']")); } }

        
        public IWebElement TypeOfApplicationDropDownList { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='transaction-select-typeOfApplication']//span[@class='k-select']")); } }
        public IWebElement ExpandAllBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='transaction-btn-expandAndCollapse']")); } }
        public IWebElement TransactionStatus { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='transaction-span-transactionStatus']")); } }
        public IWebElement SaveBtn { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='transaction-btn-save']")); } }
        public IWebElement ViewMemberBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='transaction-btn-memberInfo']")); } }
        public IWebElement confirmationYesBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='confirmationDialog-btn-Yes']")); } }
        public IWebElement confirmationNoBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='confirmationDialog-btn-No']")); } }
        public IWebElement CancelBtn { get { return Browser.Wd.FindElement(By.CssSelector("[id='btnCancelTransaction']")); } }
    }
    [Binding]
    public class TransDemographicsDetails
    {
        public IWebElement MBITextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='DemographicDetailsMBI']")); } }
        public IWebElement PlanIDDropDownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='{{section.name}}{{::field.name}}_listbox']")); } }
        public IWebElement GenderDropDownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='{{section.name}}{{::field.name}}_listbox']")); } }
        public IWebElement PBPIDDropDownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='{{section.name}}{{::field.name}}_listbox']")); } }
        public IWebElement SegmentIDDropDown { get { return Browser.Wd.FindElement(By.XPath("(//span[@role='listbox'])[4]")); } }
        public IWebElement SegmentIDDropDown1 { get { return Browser.Wd.FindElement(By.XPath("(//span[@role='listbox'])[5]")); } }
        public IWebElement SegmentIDDropDownList { get { return Browser.Wd.FindElement(By.XPath("//li[@text='003']")); } }
        public IWebElement DisEnrollmentReasonDrp { get { return Browser.Wd.FindElement(By.XPath("//div[@id='div_DemographicDetailsDisenReason']//select")); } }

        // above Two will be updated later
        public IWebElement PlanIDDescriptionTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='DemographicDetailsPlanDescription']")); } }
        public IWebElement PBPIDDescriptionTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='DemographicDetailsPBPDescription']")); } }
        public IWebElement FirstNameTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='DemographicDetailsFirstName']")); } }
        public IWebElement LastNameTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='DemographicDetailsLastName']")); } }
        public IWebElement MITextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='DemographicDetailsMI']")); } }
        public IWebElement SalutationTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='DemographicDetailsSalutation']")); } }
        public IWebElement AppelTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='DemographicDetailsAppel']")); } }
        public IWebElement DOB { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='DemographicDetailsDob']")); } }
        public IWebElement SexDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='{{section.name}}{{::field.name}}_listbox']")); } }
        public IWebElement EnrollmentSourceDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='{{section.name}}{{::field.name}}_listbox']")); } }
        public IWebElement ElectionTypeDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='{{section.name}}{{::field.name}}_listbox']")); } }
        public IWebElement SEPSReasonDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='{{section.name}}{{::field.name}}_listbox']")); } }
        public IWebElement LanguageDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='{{section.name}}{{::field.name}}_listbox']")); } }
        public IWebElement PriorComDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='{{section.name}}{{::field.name}}_listbox']")); } }
        public IWebElement PartDOptOutDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='{{section.name}}{{::field.name}}_listbox']")); } }
        public IWebElement PremiumWithHoldOptionDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='{{section.name}}{{::field.name}}_listbox']")); } }
        public IWebElement VerifyValueOfPremiumWithHoldOption { get { return Browser.Wd.FindElement(By.XPath("(//select[@id='DemographicDetailsPremWithholdOption']/preceding-sibling::span/span)[1]")); } }
        public IWebElement EGHPDropdownlist { get { return Browser.Wd.FindElement(By.XPath("//div[@id='div_DemographicDetailsEGHP']/span[@aria-owns='{{::section.name}}{{::field.name}}_listbox']")); } }
        public IWebElement CreditCoverDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='{{section.name}}{{::field.name}}_listbox']")); } }
        public IWebElement SSN { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='DemographicDetailsSSN']")); } }
        public IWebElement MemberID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='DemographicDetailsMemberID']")); } }
        public IWebElement EffectiveDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='DemographicDetailsEffectiveDate']")); } }
        public IWebElement SignatureDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='DemographicDetailsSignatureDate']")); } }
        public IWebElement ReceiptDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='DemographicDetailsReceiptDate']")); } }
        public IWebElement PremAmountC { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='DemographicDetailsPremAmtC']")); } }
        public IWebElement PremAmountD { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='DemographicDetailsPremAmtD']")); } }
        public IWebElement UncoveredMonths { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='DemographicDetailsUncoveredMonths']")); } }
        public IWebElement EmplSubsOverride { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='DemographicDetailsEmplSubsOverride']")); } }


        public IWebElement DisenReason { get { return Browser.Wd.FindElement(By.CssSelector("[id='div_DemographicDetailsDisenReason']")); } }
    }

    [Binding]
    public class ResidenceAddressUpdate

    {
        public IWebElement AddressEffectiveDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Transactioncode76ResidentialAddressupdateAddressEffectiveDate']")); } }
        public IWebElement ZIP { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Transactioncode76ResidentialAddressupdateZip']")); } }
        public IWebElement Action { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='{{section.name}}{{::field.name}}_listbox']")); } }
        public IWebElement ZipFour { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Transactioncode76ResidentialAddressupdateZipFour']")); } }

    }

    }
