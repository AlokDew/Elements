﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Windows;
using System.Drawing;
//using System.Windows.Forms;
using System.Windows.Input;
using System.IO;
using OpenQA.Selenium.Support.UI;
using System.Net;
//using System.Web.Script.Serialization;
using System.Xml;



namespace TMSoR1
{
    [Binding]
    class fsEAMLoadBEQFile
    {

        [When(@"Load BEQ File page, Config File ALM Project, Test ID ""(.*)"" attached file ""(.*)"" is selected with New File Name ""(.*)""")]
        public void WhenLoadBEQFilePageConfigFileALMProjectTestIDAttachedFileIsSelectedWithNewFileName(string p0, string p1, string p2)
        {
             string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);
            Boolean keepTrying = true;
            int maxAttempts = 11;
            int thisAttempt = 0;
            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            string controllerFileLocation = "C:\\Temp\\tmsAlm\\";
            // We added this code for Jenkins run
            string SourceFileLocation = "C:\\SourceFile\\";
            Boolean didUpload = false;
            string source = SourceFileLocation + p1_gen;
            if (Directory.Exists(SourceFileLocation))
            {
                if (!File.Exists(controllerFileLocation))
                {
                    File.Copy(SourceFileLocation + p1_gen, controllerFileLocation + Path.GetFileName(source));
                }
            }

            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen)  + "]");
            if (File.Exists(controllerFileLocation + p1_gen))
            {
                File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen,true);
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");

            }
            else
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
            if (didUpload)
            {
                while (keepTrying)
                {
                    string FileName = "C:\\Temp\\" + p1_gen;

                    //For debugging
                    string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen); 
                    File.Move(@FileName, @newFileName);
                    FileName = newFileName;
                    EAM.LoadBEQFile.Browse.SendKeys(FileName);
                    EAM.LoadBEQFile.Import.Click();
                    tmsWait.Hard(1);
                    string thisResponse = EAM.LoadBEQFile.ResponseMessage.Text;
                    if (thisResponse != "The specified filename does not match for this file type. Please verify the file or modify the filename.")
                    {
                        keepTrying = false;
                        Console.WriteLine("File load failed with message [" + thisResponse + "]");
                    }
                    if (thisAttempt > maxAttempts)
                    {
                        keepTrying = false;
                    }
                    thisAttempt++;
                }

            }       

        }

        [When(@"Load edited BEQ File page, Config File ALM Project, Test ID ""(.*)"" attached file ""(.*)"" is selected with New File Name ""(.*)""")]
        public void WhenLoadEditedBEQFilePageConfigFileALMProjectTestIDAttachedFileIsSelectedWithNewFileName(string p0, string p1, string p2)
        {
            string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);
            Boolean keepTrying = true;
            int maxAttempts = 11;
            int thisAttempt = 0;
            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            string controllerFileLocation = "C:\\Temp\\tmsAlm\\";
            Boolean didUpload = false;
            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");
            if (File.Exists(controllerFileLocation + p1_gen))
            {
                File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen, true);
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");

            }
            else
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
            if (didUpload)
            {
                while (keepTrying)
                {
                    string FileName = "C:\\Temp\\" + p1_gen;

                    //For debugging
                    string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen);
                    File.Move(@FileName, @newFileName);
                    FileName = newFileName;

                    //Added by Swati to Edit BEQ File before uploading it for  a perticular member
                    string BEQStringtoReplace = GlobalRef.BEQStringReplacement.ToString();
                    string fileName = GlobalRef.BEQFileName.ToString();

                    var lines = File.ReadAllLines(@"C:\\Temp\\" + tmsCommon.GenerateData(p2_gen));
                    string Oldvalue = lines[1].Substring(8, 37);
                    string newvalue = BEQStringtoReplace;
                    if (Oldvalue.Length != newvalue.Length) newvalue.PadRight(Oldvalue.Length - newvalue.Length);
                    lines[1] = lines[1].Replace(Oldvalue, BEQStringtoReplace);
                    File.WriteAllLines(@"C:\\Temp\\" + tmsCommon.GenerateData(p2_gen), lines);

                    EAM.LoadBEQFile.Browse.SendKeys(FileName);
                    EAM.LoadBEQFile.Import.Click();
                    tmsWait.Hard(1);
                    string thisResponse = EAM.LoadBEQFile.ResponseMessage.Text;
                    if (thisResponse != "The specified filename does not match for this file type. Please verify the file or modify the filename.")
                    {
                        keepTrying = false;
                        Console.WriteLine("File load failed with message [" + thisResponse + "]");
                    }
                    if (thisAttempt > maxAttempts)
                    {
                        keepTrying = false;
                    }
                    thisAttempt++;
                }

            }
        }


        [When(@"Tasks Check eligibility BEQ file PlanID is selected as ""(.*)""")]
        public void WhenTasksCheckEligibilityBEQFilePlanIDIsSelectedAs(string Plan_ID)
        {
            string Planid = tmsCommon.GenerateData(Plan_ID);
            SelectElement thisField = new SelectElement(EAM.LoadBEQFile.PlanIDDropdownlist);
            thisField.SelectByText(Planid);
        }
        [When(@"Tasks Check eligibility BEQ file Export button is clicked")]
        public void WhenTasksCheckEligibilityBEQFileExportButtonIsClicked()
        {
          
            EAM.LoadBEQFile.ExportButton.Click();
            string buttonclicked = DateTime.Now.ToString("MM/dd/yyyy HH:mm:ss");
            GlobalRef.buttonclicked = buttonclicked;
        }
        [When(@"Tasks Check eligibility BEQ file response message is displayed as ""(.*)""")]
        public void WhenTasksCheckEligibilityBEQFileResponseMessageIsDisplayedAs(string message)
        {
            if (message.Equals("Successful"))

                   Assert.IsTrue(EAM.LoadBEQFile.ResponseMessage.Text.Contains("Job is requested at RequestID"), " There is no file to export with selected Plan ID.");

            if (message.Equals("Fail"))
                EAM.LoadBEQFile.ResponseMessage.Text.Equals("There is no file to export with selected Plan ID.");

        }
        [When(@"Generated BEQ file is read from File processing status page for PlanID as ""(.*)"" and ""(.*)""")]
        public void WhenGeneratedBEQFileIsReadFromFileProcessingStatusPageForPlanIDAsAnd(string Plan_ID, string HIC)
        {

            string planID = tmsCommon.GenerateData(Plan_ID);
            HIC = tmsCommon.GenerateData(HIC);
            tmsWait.Hard(10);
            bool found = false;
            string Datetime = GlobalRef.buttonclicked.ToString();
            string Timeofjob = GlobalRef.buttonclicked.ToString();
            Navigation.ClickLink("FilesProcessingStatus");
            DateTime Timeofjob1;
            IWebElement filename = null;
            string fileName= "";
            string line = "";
            String BEQStringReplacement = "";
            while (!found)
            {
                try
                {
                    
                    string Xpath = ".//td[text()='" + Timeofjob + "']//following-sibling::td[contains(.,'CMS BEQ File')]//following-sibling::td[contains(.,'Complete')]//preceding-sibling::td[contains(.,'" + planID + "')]/a";
                    
                    filename = Browser.Wd.FindElement(By.XPath(Xpath));

                    fileName = filename.Text.ToString();
                    GlobalRef.BEQFileName = fileName;
                    if (filename.Displayed) filename.Click();
                    found = true;
                }
                catch(Exception e)
                {
                   
                    bool cov = DateTime.TryParse(Timeofjob, out Timeofjob1);
                    Timeofjob1 = Timeofjob1.AddSeconds(1);
                    Timeofjob = Timeofjob1.ToString("MM/dd/yyyy HH:mm:ss");
                }
            }
            tmsWait.Hard(5);         
                DirectoryInfo dinfo2 = new DirectoryInfo("C:\\Users\\" + System.Environment.UserName.ToString()+"\\Downloads");
                FileInfo[] Files2 = dinfo2.GetFiles("*.txt");
               foreach(FileInfo file in Files2)
                {
                    if (file.Name.Equals(fileName))
                    {
                        Console.WriteLine("Found the file in download folder");
                    break;
                   
                }
                }
            StreamReader sr = new StreamReader(@"C:\\Users\\" + Environment.UserName.ToString() + "\\Downloads\\" + fileName);
            for (int i=0; i<=1;i++)
            {
                line = sr.ReadLine();
                if (line.Contains(HIC)) { BEQStringReplacement = line.Substring(5, 37); GlobalRef.BEQStringReplacement = BEQStringReplacement; }
            }

    }

        }

    }



