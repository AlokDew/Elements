﻿using System;
using System.IO;
using OpenQA.Selenium;
using TechTalk.SpecFlow;
//using Microsoft.VisualStudio.TestTools.UnitTesting;
using TDAPIOLELib; // This is the QTP interop library 
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TMSoR1
{

    [Binding]
    public class LoadEAFFile
    {
        //public IWebElement Browse { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_FileUpload1")); } }
        public IWebElement Browse { get { return Browser.Wd.FindElement(By.Id("fileUpload")); } }
        public IWebElement SelectFiles { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='import-input-fileUpload'] input")); } }
        public IWebElement Import { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnImport")); } }
        public IWebElement Upload { get { return Browser.Wd.FindElement(By.XPath("//button[contains(.,'Upload')]")); } }

        public IWebElement ResponseMessage { get { return Browser.Wd.FindElement(By.Id("fileStatusEnrollmentID")); } }
                
       // public IWebElement ResponseMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblMsg")); } }
        public IWebElement UIModResponseMessage { get { return Browser.Wd.FindElement(By.XPath("//div[@ng-if='showErrorMessage']//span")); } }
        
    }

    public class LoadNoRxFile
    {
        public IWebElement Browse { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_FileUpload1")); } }
        public IWebElement Import { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnImport")); } }
        public IWebElement ResponseMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblMsg")); } }

    }
    public class UploadNewFile
    {
        public IWebElement Browse { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='scc-input-fileUpload']")); } }
        public IWebElement Import { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='scc-btn-import']")); } }
    }
    public class LoadNoPremiumDueFile
    {
        public IWebElement Browse { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_fileUpload")); } }
        public IWebElement Import { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnImport")); } }
    }
    
    public class LoadTRRFile
    {
        public IWebElement Browse { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_FileUpload1")); } }
        public IWebElement Import { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnImport")); } }
        public IWebElement ResponseMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblMsg")); } }
    }
    public class LoadBulkAttachment
    {
                
        public IWebElement BrowseButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='bulkAttachment-input-fileUpload']")); } }
        public IWebElement AttachButton { get { return Browser.Wd.FindElement(By.XPath("//button[contains(.,'Upload')]")); } }
        public IWebElement ResponseMessage { get { return Browser.Wd.FindElement(By.XPath("//*[@id='ctl00_ctl00_MainMasterContent_MainContent_AttachMember_grdMultifile']//td[contains(.,'Attached Successfully')]")); } }
    }
    public class MemberBulkAttachment
    {
        public IWebElement MemberAtttachmentICon { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_memberDocumentsButton")); } }
        public IWebElement BrowseButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_memberDocuments_attachDocumentDialog_mbrDocUploadfile0")); } }
        public IWebElement AttachButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_memberDocuments_attachButton")); } }
        public IWebElement UploadButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_memberDocuments_attachDocumentDialog_uploadButton")); } }
        public IWebElement UploadClose{ get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_memberDocuments_attachDocumentDialog_uploadMessageBoxDialog_closeButton")); } }
        public IWebElement MemberDocumentsClose { get { return Browser.Wd.FindElement(By.XPath("//i[@class='fa fa-times-circle rptlink cursorLink']")); } }

        public IWebElement ResponseMessage { get { return Browser.Wd.FindElement(By.ClassName("toast-message")); } }
    }
    public class CreateCMSFile
    {
        public IWebElement DataTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_grdMarkFile")); } }
        public IWebElement Remove { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnDelete")); } }
        public IWebElement ExcludeRetro { get {return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_CheckBoxExcludeRetros")); } }
        public IWebElement ExcludeFutures { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_CheckBoxExcludeFutures")); } }

        public IWebElement CMSFileExport { get
        {
            return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnTransFile")); 
        } }
        public IWebElement CMFFileMarkButton { get
        {
            return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnMark"));
        } }
        public IWebElement CMSFileExportDate { get { 
            return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtCreateDate"));
        } }
        public IWebElement CMSFileEarliestEffectiveDate { get {
            return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtEffDate1"));
        } }
        public IWebElement CMSFileLatestEffectiveDate { get {
            return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtEffDate2"));
        } }
        public IWebElement CMSFileRefreshButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Button2")); } }
        public IWebElement CreateCMSFilePlan { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPlan")); } }
        public IWebElement CreateCMSFileTransaction { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboTransCode")); } }
        public IWebElement CreateCMSFileElection { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ListElection")); } }

    }

    public class CreateBEQFile
    {
        public IWebElement BEQFileExport
        {
            get
            {
                return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnCreateBEQ"));
            }
        }
        public IWebElement CreateBEQFilePlan { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPlan")); } }
    }
        public class EAMHomePage
    {
        public IWebElement Confirmation_of_Enrollment_Letter_queue_Count { get { return Browser.Wd.FindElement(By.XPath("//*[@id='ctl00_ctl00_MainMasterContent_MainContent_QueuesCtr1_Table2']/tbody/tr[7]/td[1]/a")); } }
        public IWebElement queueTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_UpdatePanel1")); } }
        public IWebElement QueuedItemsTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_QueuesCtr1_Table2")); } }
        public IWebElement PlanIDDropdown { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPlan")); } }
        public IWebElement PBPDropdown { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPBP")); } }
        public IWebElement GoButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnGo")); } }
        public IWebElement EAMTitle { get { return Browser.Wd.FindElement(By.CssSelector("span[id='pageName']")); } }
        public IWebElement SEPActionTable {  get {  return Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_Datagrid1']/tbody"));  } }
                                                                                                         
    }
    
    
    [Binding]
    public class ALMUtilities
    {
         [STAThread]
        public static TDConnection Connect()
        {
            Console.WriteLine("**Connect to ALM - Top");
            Console.WriteLine("**Connect to ALM - Create New TDConnection");

            TDConnection thisTDC = new TDConnection();
            string status = "Initialising" + "";
             try
            {
                Console.WriteLine("**Connect to ALM - InitConnectionEx");

               // thisTDC.InitConnectionEx("http://alm.corp.trizetto.com:8080/qcbin");
                //thisTDC.InitConnectionEx("https://almtrizetto1253.saas.hpe.com/qcbin");
                thisTDC.InitConnectionEx("https://almtrizetto1253.saas.microfocus.com/qcbin");
           
                Console.WriteLine("**Connect to ALM - ConnectProjectEx");

              //  thisTDC.ConnectProjectEx("DEFAULT", "TMS", "qos.automation", "Testing456");
                thisTDC.ConnectProjectEx("T3_PALM", "TMS", "qos.automation", "Testing456");
                //        thisTDC.ConnectProjectEx("TZG", "TMS_671", "qos.automation", "Testing456");

                if (thisTDC.ProjectConnected)
                {
                    status = "Connected";
                }
            }
            catch (Exception Daron)
            {
                status = "Failed";
                Exception a = Daron;
            }
             string b = status;
            return thisTDC;
        }
        public static Boolean GetALMTestPlanAttachedFile(string FileName, string TestID)
        {
            Boolean thisReturnValue = false;
            Console.WriteLine("**GetALMTestPlanAttachedFile - Top");
            Console.WriteLine("**GetALMTestPlanAttachedFile - FileName [" + FileName + "]");
            Console.WriteLine("**GetALMTestPlanAttachedFile - TestID [" + TestID + "]");
            Console.WriteLine("**GetALMTestPlanAttachedFile - Calling To Connect");

            TDConnection useConnection = ALMUtilities.Connect();
            
            Console.WriteLine("**GetALMTestPlanAttachedFile - Call to connect completed");

            if (useConnection.Connected)
            {
                //pick the test by Test ID, given in the parameters
                TestFactory myTF = (TestFactory)useConnection.TestFactory;
                int thisTestID = Convert.ToInt32(TestID);
                Test myTest = (Test)myTF[thisTestID];

                //Get the list of attachments to the test
                AttachmentFactory thisAF = (AttachmentFactory)myTest.Attachments;
                TDAPIOLELib.List thisList = thisAF.NewList("");
                int AttachmentCount = thisList.Count;

                string thisFileLocation = "c:\\Temp\\";  //Local machine file location
                foreach (Attachment thisAttachment in thisList)
                {
                    //Split the string which is long, many parts by the \.  
                    string tempString = thisAttachment.FileName.Replace("\\\\","\\");
                    string[] arrParts = tempString.Split('\\');
                    int LastPart = arrParts.Length;
                    string workingString = arrParts[LastPart-1];

                    //Take off the front of the name for comparrison "Test_33_" is removed from left
                    int firstCutIndex = workingString.IndexOf("_");
                    string firstCutString = workingString.Substring(firstCutIndex+1);
                    int secondCutIndex = firstCutString.IndexOf("_");
                    string secondCutString = firstCutString.Substring(secondCutIndex+1);

                    //If the current attachment is the one we want, bring it down, then move it.
                    if (secondCutString == FileName)
                    {
                        try
                        {
                            Console.WriteLine("Attachment Name [" + secondCutString + "]");
                            Console.WriteLine("Trying to load file to [" + thisFileLocation + "]");
                            thisAttachment.Load(false, thisFileLocation);
                            tmsWait.Hard(2);
                            Console.WriteLine("Doing Copy from [" + thisAttachment.FileName + "]");
                            Console.WriteLine("Doing Copy to [" + thisFileLocation + FileName + "]");
                            File.Copy(thisAttachment.FileName, thisFileLocation + FileName, true);
                            thisReturnValue = true;
                        }
                        catch
                        {
                            tmsWait.Hard(2);
                            Console.WriteLine("Trying again to copy file in catch");
                            Console.WriteLine("Attachment Name [" + secondCutString + "]");
                            Console.WriteLine("Trying to load file to [" + thisFileLocation + "]");

                            thisAttachment.Load(false, thisFileLocation);
                            tmsWait.Hard(2);
                            Console.WriteLine("Doing Copy from [" + thisAttachment.FileName + "]");
                            Console.WriteLine("Doing Copy to [" + thisFileLocation + FileName + "]");

                            File.Copy(thisAttachment.FileName, thisFileLocation + FileName, true);
                            thisReturnValue = true;
                        
                        }
                    }
                }
                if (!thisReturnValue)
                {
                    Assert.AreEqual(true, false, "The expected Filename [" + FileName + "] was not found attached to the test.   It can't be downloaded and used in the test");
                }
                useConnection.Disconnect();
                //Added 06.23.2016 - Daron - Need to reduce otaclient connections
            }
            else
            {
                Console.WriteLine("We were expecting to connect to ALM to grab a file attachment");
                Console.WriteLine("The connection didn't happen so this will cause a failure from here");
            }

            return thisReturnValue;
        }
    }

}