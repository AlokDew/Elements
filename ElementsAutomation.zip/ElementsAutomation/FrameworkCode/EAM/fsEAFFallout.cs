﻿using Microsoft.Office.Interop.Excel;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.EAM
{
    [Binding]
    class fsEAFFallout
    {

        [When(@"I have navigated to EAM ""(.*)"" page")]
        public void WhenIHaveNavigatedToEAMPage(string p0)
        {
            tmsWait.Hard(2);

            try { 
                By loc = By.XPath("//span[contains(.,'"+ p0 + "')]/parent::div/parent::div[contains(@test-id,'submenu')]");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);

                
            }
           catch
            {
                By loc = By.CssSelector("[title='" + p0 + "']");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
               
            }
        }

        [When(@"EAF Fallout Records page File Name Drop down list is set to ""(.*)""")]
        public void WhenEAFFalloutRecordsPageFileNameDropDownListIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            //By drp = By.CssSelector("[aria-owns='formInputBoxAUD_listbox']");
            //UIMODUtilFunctions.selectDropDownValueFromGendoUI(Browser.Wd.FindElement(drp), value);

            By Drp = By.XPath("//label[contains(.,'File Name')]/parent::div//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + value + "']");


            UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
        }

        [When(@"EAF Fallout Records page Search button is Clicked")]
        public void WhenEAFFalloutRecordsPageSearchButtonIsClicked()
        {
            By btn = By.CssSelector("[test-id='eafFalloutCorrection-btn-search']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(btn);
            tmsWait.Hard(5);
        }

        [Then(@"Verify Results Grid display File Name as ""(.*)"" TC Code as ""(.*)"" MBI as ""(.*)"" Plan ID as ""(.*)"" PBP as ""(.*)"" First Name as ""(.*)"" Last Name as ""(.*)"" Status as ""(.*)""")]
        public void ThenVerifyResultsGridDisplayFileNameAsTCCodeAsMBIAsPlanIDAsPBPAsFirstNameAsLastNameAsStatusAs(string file, string TC, string mbi, string plan, string pbp, string first, string last, string status)
        {

            string filename = tmsCommon.GenerateData(file);
            By loc = By.XPath("//div[@test-id='eafFalloutCorrection-grid']//td[contains(.,'" + filename + "')]/following::td[contains(.,'" + TC + "')]/following::td[contains(.,'" + mbi + "')]/following::td[contains(.,'" + plan + "')]/following::td[contains(.,'" + pbp + "')]/following::td[contains(.,'" + first + "')]/following::td[contains(.,'" + last + "')]/following::td[contains(.,'" + status + "')]");
            UIMODUtilFunctions.elementNotPresenceUsingLocators(loc);
        }
        [Then(@"Verify EAF Fallout Record Error Summary dispalyed messages as ""(.*)""")]
        public void ThenVerifyEAFFalloutRecordErrorSummaryDispalyedMessagesAs(string p0)
        {
            tmsWait.Hard(15);
            string[] words = p0.Split(',');
            foreach (var msg in words)
            {
                string[] error = msg.Split(':');
                //By loc = By.XPath("//div[@ng-if='showValidationSummaryMessage'][contains(.,'" + error[1].Trim() + "')]");
                By loc = By.XPath("//div[@test-id='eafFalloutCorrectionContent-lbl-errorSummary'][contains(.,'" + error[1].Trim() + "')]");

                UIMODUtilFunctions.elementPresenceUsingLocators(loc);
                System.Console.WriteLine(msg + "  is displaying");

            }

        }

        [Then(@"Verify EAF Fallout Fields ""(.*)"" Highlighted")]
        public void ThenVerifyEAFFalloutFieldsHighlighted(string p0)
        {
            Boolean expflag = true;

            string[] words = p0.Split(',');

            IList<IWebElement> options1 = Browser.Wd.FindElements(By.XPath("//*[contains(@class,'invalid')]/parent::div/label"));
            IList<IWebElement> options2 = Browser.Wd.FindElements(By.XPath("//kendo-dropdownlist[contains(@class,'ng-invalid')]/parent::div/parent::div/label"));
            IList<IWebElement> options = options1.Concat(options2).ToList();

            foreach (var Elem in words)
            {
                Boolean actflag = false;

                for (int i = 0; i <= options.Count - 1; i++)
                {
                    if (Elem.ToLower().Equals(options[i].Text.ToLower()))
                    {
                        actflag = true;
                        break;
                    }
                }

                Assert.AreEqual(expflag, actflag, Elem + " Field is not highlighting");
                System.Console.WriteLine(Elem + " is highlighting");
            }

        }

        [Then(@"Verify EAF Fallout Record Error Summary dispalyed message as ""(.*)""")]
        public void ThenVerifyEAFFalloutRecordErrorSummaryDispalyedMessageAs(string msg)
        {

            tmsWait.Hard(3);
            By loc = By.XPath("//*[@class='alert alert-danger']//*[contains(.,' " + msg+"')]");
            //span[@class='alert alert-danger'][contains(.,' Plan ID is required ')]
            //*[@class='alert alert-danger']//*[text()=' Plan ID is required ']
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }
        [When(@"I have navigated to EAM Administration menu")]
        public void WhenIHaveNavigatedToEAMAdministrationMenu()
        {
            By loc = By.CssSelector("[title='Administration']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);

        }

        [When(@"I have navigated to EAM EAF Fallout Configuration sub menu")]
        public void WhenIHaveNavigatedToEAMEAFFalloutConfigurationSubMenu()
        {
            By loc = By.XPath("//span[contains(.,'EAF Fallout Configuration')]/parent::div/parent::div[contains(@test-id,'submenu')]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
        }

        [When(@"I have navigated to EAM EAF Fallout Configuration Export sub menu")]
        public void WhenIHaveNavigatedToEAMEAFFalloutConfigurationExportSubMenu()
        {
            By loc = By.XPath("//span[contains(.,'Export')]/parent::div/parent::div[contains(@test-id,'subMenu')]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
        }

        [When(@"Export Corrected Fallout Records page Export button is Clicked")]
        public void WhenExportCorrectedFalloutRecordsPageExportButtonIsClicked()
        {
            By loc = By.CssSelector("[test-id='eafFallout-btn-export']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            tmsWait.Hard(10);
        }


        [Then(@"Verify EAF Fallout Record page displayed message as ""(.*)""")]
        public void ThenVerifyEAFFalloutRecordPageDisplayedMessageAs(string msg)
        {

            //tmsWait.Hard(5);
            //By loc = By.XPath("//span[@test-id='eafFalloutCorrectionContent-spn-message'][contains(.,'"+ msg + "')]");
            //UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }

        [Then(@"I Clicked on Back to EAF Fallout Records link")]
        public void ThenIClickedOnBackToEAFFalloutRecordsLink()
        {
            By loc = By.XPath("//span[@test-id='eafFalloutCorrection-span-back']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);

            tmsWait.Hard(5);
        }
       public string actualstatus;
        
        [When(@"Navigate to Job Processing status Note Exported EAF File Name ""(.*)"" from EAF Fallout Export Job")]
        public void WhenNavigateToJobProcessingStatusNoteExportedEAFFileNameFromEAFFalloutExportJob(string p0)
        {

            By drp = By.XPath("//kendo-dropdownlist[@test-id='jobProcessingStatus-txt-ddlJobName']//span[@class='k-select']");               

            string job = "EAF Fallout Export Job";          

            UIMODUtilFunctions.selectDropDownValueFromKendoDropDown(drp, job);   
                       
            fw.ConsoleReport(job + " File Type Drop is selected and Filtered");

            By SearchBtn = By.CssSelector("[test-id='jobProcessingStatus-button-search']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(SearchBtn);
            tmsWait.Hard(5);

            //By importPlus = By.XPath("//a[@class='k-icon k-plus']");
            By importPlus = By.XPath("//tr[@data-kendo-grid-item-index='0']//a[@title='Expand Details']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(importPlus);

            string currentDate= DateTime.Now.ToString("MM/dd/yyyy").Replace("/", string.Empty);

            tmsWait.Hard(5);
            fw.ConsoleReport(job + " Import Plus Button is Clicked");
            
            tmsWait.Hard(3);
            string xpath = "";
           

            xpath = "//kendo-grid[@test-id='jobProcessingStatus-grid-grdJobRequestInfo']//td[contains(.,'EAF_FalloutCorrectedRecords_"+currentDate+"')]/following-sibling::td[@aria-colindex='2']";// Indicate Success Status

           
            try
            {
                actualstatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
            }
            catch
            {
                actualstatus = "Pending";


            }
           
            int ReturnStatus = StatusValidation(actualstatus);

            while (ReturnStatus != 0)
            {

                fw.ExecuteJavascript(Browser.Wd.FindElement(SearchBtn));
                tmsWait.Hard(5);                
                UIMODUtilFunctions.clickOnWebElementUsingLocators(importPlus);
                tmsWait.Hard(3);

                try {
                    actualstatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                }

                catch
                {
                    actualstatus = "Pending";


                }
                fw.ConsoleReport(" Current File Processing status --> " + actualstatus);
                ReturnStatus = StatusValidation(actualstatus);
            }

            tmsWait.Hard(5);
           
            Assert.AreEqual("Success", actualstatus, " Expected execution status are not matching");

            string exportFileName = Browser.Wd.FindElement(By.XPath("//a[contains(text(),'EAF_FalloutCorrectedRecords')]")).Text.ToString();
            
            fw.ConsoleReport(" Exported EAF File from EAF Fallout Report Job " + exportFileName);
            fw.setVariable(p0, exportFileName);
        }


        public int StatusValidation(string actualStatus)
        {
            tmsWait.Hard(5);
            if (actualStatus.Equals("Pending"))
            {
                tmsWait.Hard(2);
                return 1;
            }
            else if (actualStatus.Equals("Executing"))
            {
                return 1;
            }

            else if (actualStatus.Equals("Failed"))
            {
                Assert.Fail(" Job Processing is failed");
                return 0;
            }
            else if (actualStatus.Equals("Failure"))
            {
                Assert.Fail(" Job Processing is failed");
                return 0;
            }
            else if (actualStatus.Equals("Complete"))
            {

                return 0;
            }
            else if (actualStatus.Equals("Success"))
            {

                return 0;
            }

            return 0;
        }

        [When(@"EAF Fallout Record page ""(.*)"" field is set to ""(.*)""")]
        public void WhenEAFFalloutRecordPageFieldIsSetTo(string p0, string value)
        {
            tmsWait.Hard(3);
            string field = tmsCommon.GenerateData(p0);
            switch(field)
            {
                case "Plan ID":
                    By plan = By.XPath("//kendo-dropdownlist[@test-id='eafFalloutCorrectionContent-select-planId']//span[@class='k-select']");                   
                    
                    UIMODUtilFunctions.selectDropDownValueFromKendoDropDown(plan, value);
                    break;

                case "PBP ID":
                    By pbp = By.XPath("//label[contains(.,'PBP ID')]/parent::div//span[@class='k-select']");
                    UIMODUtilFunctions.selectDropDownValueFromKendoDropDown(pbp, value);
                    break;
                case "Segment ID":
                    By segment = By.XPath("//label[contains(.,'Segment ID')]/parent::div//span[@class='k-select']");
                    UIMODUtilFunctions.selectDropDownValueFromKendoDropDown(segment, value);
                    break;

                case "TC Code":

                    By TC = By.XPath("//kendo-dropdownlist[@test-id='eafFalloutCorrectionContent-select-transCode']//span[@class='k-select']");
                                  
                    UIMODUtilFunctions.selectDropDownValueFromKendoDropDown(TC, value);

                    break;

                case "Election Type":

                    By elect = By.XPath("//label[contains(.,'Election Type')]/parent::div//span[@class='k-select']");
                    UIMODUtilFunctions.selectDropDownValueFromKendoDropDown(elect, value);

                    break;

                case "SEPS Reason":

                    By seps = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-sEPSReason']");
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(seps, value);

                    break;
                case "Member First Name":

                    By first = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-firstName']");
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(first, value);

                    break;

                case "Member Last Name":

                    By last = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-lastName']");
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(last, value);

                    break;



                case "Member Birth Date":
                    By dob = By.CssSelector("[test-id='eafFalloutCorrectionContent-txt-dob']");
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(dob, value);

                    break;
                   
                case "MBI":
                    By mbi = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-mbi']");
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(mbi,value);
                    break;
                case "Submit Date":

                    By Submit = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-submitDate']");
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(Submit, value);
                    break;
                case "Application Sign Date":

                    By Sign = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-applicationSignDate']");
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(Sign, value);
                    break;
                case "Primary RxID":

                    By RxID = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-primaryRxID']");
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(RxID, value);
                    break;

                    



                case "Member ID":

                    By mem = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-memberId']");
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(mem, value);
                    break;
                case "Creditable Coverage":

                    By cred = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-creditableCoverage']");
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(cred, value);
                    break;
                //case "Uncovered Months":

                //    By uncover = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-uncoveredMonths']");
                //    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(uncover, value);
                //    break;
                    
                case "Member Gender":

                    //By gender = By.CssSelector("//label[contains(.,'Member Gender')]/parent::div//span[@class='k-select']");
                    By gender = By.XPath("//label[contains(.,'Member Gender')]/parent::div//span[@class='k-select']");
                    UIMODUtilFunctions.selectDropDownValueFromKendoDropDown(gender, value);
                    break;

                case "Enroll Medicare Date":

                    By enroll = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-enrollMedicareDate']");
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(enroll, value);
                    break;

                case "Recently Changed Medicaid Date":

                    By recent = By.CssSelector("[id='txtRecentlyChangedMedicaidDate']");
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(recent, value);
                    break;

                    


                case "Disenrollment Reason":

                    By dis = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-disenrollmentReason']");
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(dis, value);
                    break;

                    
                case "Premium Withhold Option":

                    By prem = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-premiumWithholdOption']");
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(prem, value);
                    break;

                    

                case "Effective Date":

                    By eff = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-effectiveDate']");
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(eff, value);
                    break;


                case "RFI Receipt Date":

                    By rfi = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-rFIReceiptDate']");
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(rfi, value);
                    break;
                case "Sales Date":

                    By sales = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-salesDate']");
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(sales, value);
                    break;
                case "Member Address 1":

                    By add1 = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-address1']");
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(add1, value);
                    break;
                case "Member City":

                    By city = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-city']");
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(city, value);
                    break;

                case "Member State":

                    By State = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-state']");
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(State, value);
                    break;

                case "Member Zip":

                    By zip = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-zip']");
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(zip, value);
                    break;

                    

                case "EGHP":

                    By eghp = By.CssSelector("[test-id='eafFalloutCorrectionContent-chk-eghp']");
                    ReUsableFunctions.CheckBoxOperations(eghp, value);
                    break;

                case "Medical OSB":

                    By medical = By.CssSelector("[test-id='eafFalloutCorrectionContent-chk-medicalOSB']");
                    ReUsableFunctions.CheckBoxOperations(medical, value);
                    break;

                case "Dental OSB":

                    By Dental = By.CssSelector("[test-id='eafFalloutCorrectionContent-chk-DentalOSB']");
                    ReUsableFunctions.CheckBoxOperations(Dental, value);
                    break;


                case "Vision OSB":

                    By vision = By.CssSelector("[test-id='eafFalloutCorrectionContent-chk-visionOSB']");
                    ReUsableFunctions.CheckBoxOperations(vision, value);
                    break;

                case "Other OSB":

                    By Other = By.CssSelector("[test-id='eafFalloutCorrectionContent-chk-OtherOSB']");
                    ReUsableFunctions.CheckBoxOperations(Other, value);
                    break;

                case "Secondary Rx Group":

                    By rxg = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-secondaryRxGroup']");
                    //ReUsableFunctions.CheckBoxOperations(rxg, value);
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(rxg, value);
                    break;
                case "Secondary RxBIN":

                    By RxBIN = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-secondaryRxBIN']");
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(RxBIN, value);
                    break;

                case "RxBIN":

                    By PRxBIN = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-rxBIN']");
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(PRxBIN, value);
                    break;

                case "Secondary Rx ID":

                    By sRxID = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-secondaryRxID']");
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(sRxID, value);
                    break;

                //case "State":

                //    By State = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-state']");
                //    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(State, value);
                //    break;

                case "ZIP":

                    By ZIP = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-zip']");
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(ZIP, value);
                    break;

                case "Address 1":

                    By Address1 = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-address1']");
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(Address1, value);
                    break;

                case "City":

                    By City = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-city']");
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(City, value);
                    break;
                case "Application Type":

                    By app = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-applicationType']");
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(app, value);
                    break;

                    

                case "SCC Code":

                    By SCC = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-sCCCode']");
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(SCC, value);
                    break;

                case "Uncovered Months":

                    By uncover = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-uncoveredMonths']");
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(uncover, value);
                    break;

                case "Part D Opt Out":

                    By partdoptout = By.CssSelector("[test-id='eafFalloutCorrectionContent-input-partDOptOut']");
                    UIMODUtilFunctions.enterValueOnWebElementUsingLocators(partdoptout, value);
                    break;

            }
        }

        string electionswitch;
         

        [When(@"I ""(.*)"" on Election Type Validation checkbox")]
        public void WhenIOnElectionTypeValidationCheckbox(string SwitchStatus)
        {
            if (SwitchStatus.ToLower().Equals("checked") || SwitchStatus.ToLower().Equals("on"))
            {
                electionswitch = "on";
            }
            else
            {
                electionswitch = "off";
            }

            bool iselementpresent = false;
            By buttonStatus = By.XPath("//div[@data-role='tooltip']//span[contains(@class,'k-switch km-switch k-widget km-widget k-switch-off km-switch-" + electionswitch + "')]");
            if (electionswitch.Equals("on"))
            {
                try
                {
                    iselementpresent = Browser.Wd.FindElement(buttonStatus).Displayed;
                    fw.ConsoleReport(" Election Type switch is already in ON Status");
                }
                catch
                {

                    fw.ConsoleReport(" Election Type switch is already in ON Status");
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-wrapper km-switch-wrapper'])[1]")));
                    tmsWait.Hard(5);
                }

                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[contains(@k-content,'Turn this setting On to turn On Election Type Validation')]/span")));
            }

            else if (electionswitch.Equals("off"))

            {
                try
                {
                    iselementpresent = Browser.Wd.FindElement(buttonStatus).Displayed;
                    fw.ConsoleReport("Election Type switch  is already in OFF Status");
                }
                catch
                {
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-container km-switch-container'])[1]")));
                    tmsWait.Hard(2);
                }
            }
        }




        [When(@"EAF Fallout Record page Save Button is Clicked")]
        public void WhenEAFFalloutRecordPageSaveButtonIsClicked()
        {
            By loc = By.CssSelector("[test-id='eafFalloutCorrectionFooter-btn-saveDraft']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            tmsWait.Hard(7);
        }


        [Then(@"Verify Results Grid display File Name as ""(.*)"" TC Code as ""(.*)"" MBI as ""(.*)"" Plan ID as ""(.*)"" PBP as ""(.*)"" First Name as ""(.*)"" Last Name as ""(.*)"" Status as ""(.*)"" row is Clicked")]
        public void ThenVerifyResultsGridDisplayFileNameAsTCCodeAsMBIAsPlanIDAsPBPAsFirstNameAsLastNameAsStatusAsRowIsClicked(string file, string TC, string mbi, string plan, string pbp, string first, string last, string status)
        {
            string filename = tmsCommon.GenerateData(file);
            By loc = By.XPath("//kendo-grid[@test-id='eafFalloutCorrection-grid']//following::td[.='" + TC + "']/following-sibling::td/a");
                                 
            bool hasrow = false;

            int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//span[@class='k-numeric-wrap']/input")).GetAttribute("aria-valuemax"));
                                           
                for (int i = 1; i <= totalPagesIntheGrid; i++)
                {
                    try
                    {
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
                        tmsWait.Hard(10);
                    break;
                    }
                catch (Exception ex)
                {
                    try { 
                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
                        tmsWait.Hard(10);
                        break;
                    }
                    catch
                    {
                        IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the previous page']"));
                        ReUsableFunctions.clickOnWebElement(nextpage);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
                        tmsWait.Hard(10);
                        break;

                    }


                }
            }
        }
        [When(@"Verify Results Grid display File Name as ""(.*)"" TC Code as ""(.*)"" MBI as ""(.*)"" Plan ID as ""(.*)"" PBP as ""(.*)"" First Name as ""(.*)"" Last Name as ""(.*)"" Status as ""(.*)"" row is Clicked")]
        public void WhenVerifyResultsGridDisplayFileNameAsTCCodeAsMBIAsPlanIDAsPBPAsFirstNameAsLastNameAsStatusAsRowIsClicked(string file, string TC, string mbi, string plan, string pbp, string first, string last, string status)
        {
            string filename = tmsCommon.GenerateData(file);
            By loc = By.XPath("//kendo-grid[@test-id='eafFalloutCorrection-grid']//following::td[.='" + first + "']/following-sibling::td/a/span");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            tmsWait.Hard(7);
        }
        public string downloadPath = System.IO.Path.Combine(Environment.ExpandEnvironmentVariables("%userprofile%"), "Downloads");
        [Then(@"Download Excel sheet ""(.*)"" from Test ID ""(.*)"" Verify Excel sheet name ""(.*)"" contains message as ""(.*)""")]
        public void ThenDownloadExcelSheetFromTestIDVerifyExcelSheetNameContainsMessageAs(string p0, string p1, string p2, string p3)
        {
           

        string filename = tmsCommon.GenerateData(p0);
            string testid = tmsCommon.GenerateData(p1);
            string sheetname = tmsCommon.GenerateData(p2);
            string message = tmsCommon.GenerateData(p3);
            string targetCSVFilePath="";
         ReUsableFunctions.deleteFilesFromDownloadFolder();
            ReUsableFunctions.deleteFilesFromTempFolder();

            // Create a Specific Folder
            string activeDir = "c:\\temp\\tmsAlm\\";
            if (!Directory.Exists(activeDir))  //  Verify Specific Folder Exists, if No then Create it.
            {
                Directory.CreateDirectory(activeDir);
            }

            if (ConfigFile.EnvType.Equals("ESI") || ConfigFile.EnvType.Equals("Main"))
            {
               
                string p2_gen = tmsCommon.GenerateData(p2);

                Boolean keepTrying = true;

                Console.WriteLine("**Before call to ALM file download**");
                //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
                //if they are there, we copy across.   Otherwise we reach into ALM to get them.
                string controllerFileLocation = "c:\\temp\\tmsAlm\\";
                // We added this code for Jenkins run
                // Do not comment below code as it will be used for Smoke test suite
                string SourceFileLocation = "C:\\SourceFile\\";
                string tempFolder = "c:\\temp\\";
                Boolean didUpload = false;
                string source = SourceFileLocation + filename;
                bool fileDownloadOnALM = false;


                if (Directory.Exists(SourceFileLocation))
                {
                    if (!File.Exists(controllerFileLocation))
                    {
                        File.Copy(SourceFileLocation + filename, tempFolder + filename);
                        fileDownloadOnALM = true;
                        didUpload = true;

                        fw.ConsoleReport(" File is found on Source File Folder");
                    }
                }


                Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + filename + "] is [" + File.Exists(controllerFileLocation + filename) + "]");



                if (!fileDownloadOnALM)
                {
                    Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                    didUpload = ALMUtilities.GetALMTestPlanAttachedFile(filename, testid);
                }


                if (didUpload)
                {
                   
                    // Convert XLS to .csv file

                        string FileName = "C:\\Temp\\" + filename;
                         targetCSVFilePath = "C:\\Temp\\tmsAlm\\" + "TC00_ExecuteValidation.csv";
                        Microsoft.Office.Interop.Excel.Application xls = new Microsoft.Office.Interop.Excel.Application();
                        Workbook workbook = xls.Workbooks.Open(FileName);
                       // string sheetname = workbook.Worksheets.get_Item(1).Name; // Getting Sheet name based on Index
                        Worksheet ws = (Worksheet)workbook.Sheets[sheetname];

                        //Conversion of XLS frile to CSV file
                        ws.SaveAs(targetCSVFilePath, XlFileFormat.xlCSV);
                        fw.ConsoleReport(" Now Excel file is converted to CSV format to read file content");
                    //Deleting Source XLS file after saving in to.CSV format

                        string[] fileExtensions = { ".XLS", ".xls" };

                    string downloadPath = System.IO.Path.Combine(Environment.ExpandEnvironmentVariables("%userprofile%"), "Downloads");
                    DirectoryInfo di = new DirectoryInfo(downloadPath);
                    FileInfo[] oldDownloadedFiles = di.EnumerateFiles().Where(p => fileExtensions.Contains(p.Extension, StringComparer.InvariantCultureIgnoreCase)).ToArray();


                    foreach (var oldFile in oldDownloadedFiles)
                    {
                        oldFile.Attributes = FileAttributes.Normal;
                        File.Delete(oldFile.FullName);
                    }
                    //Releasing and killing XLS object
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(ws);
                        workbook.Close(0);
                        xls.Quit();
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(xls);
                        Process[] process = Process.GetProcessesByName("Excel");
                        foreach (Process p in process)
                        {
                            if (!string.IsNullOrEmpty(p.ProcessName))
                            {
                                try
                                {
                                    p.Kill();
                                }
                                catch { }
                            }
                        }

                    
                }
                //  Read Values

                fw.ConsoleReport(targetCSVFilePath + " is downloaded");
                StreamReader streamReader = new StreamReader(targetCSVFilePath);
                List<string> csvData = new List<string>();
                string strline = "";
                string[] _values = null;
                int x = 0;
                while (!streamReader.EndOfStream)
                {
                    x++;
                    strline = streamReader.ReadLine();
                    _values = strline.Split(';');
                    foreach (string value in _values)
                    {
                        csvData.Add(value);
                    }
                }
                streamReader.Close();

                bool flag = false;
                tmsWait.Hard(5);

                foreach (string data in csvData)
                {

                    if (data.Contains(message)) // Message Verification
                    {
                        flag = true;
                        break;
                    }
                }


                //  return csvData;

                //            tmsWait.Hard(7);
                //public static List<string> ReadXLSFile(string sourceXLSFilePath, string targetCSVFilePath)
                //{
                //    fw.ConsoleReport(sourceXLSFilePath + " is downloaded");



                //    //Reading data from CSV file
                //    return ReadCSVFile(targetCSVFilePath);
                //}
                //var excelData = ReadFileFunctions.ReadXLSFile(downloadPath + "\\" + "" + reportName + ".XLSX", downloadPath + "\\" + "" + reportName + ".CSV");
                //VerifyText(excelData, ReportValidationText, format);

                //public void VerifyText(List<string> dataFromFile, string reportName, string format)
                //{
                //    bool flag = false;
                //    tmsWait.Hard(5);

                //    foreach (string data in dataFromFile)
                //    {

                //        if (data.ToUpper().Contains(reportName.ToUpper()))
                //        {
                //            flag = true;
                //            break;
                //        }
                //    }
                //    if (format.ToUpper().Equals("CSV"))
                //    {

                //        Assert.IsTrue(flag, format + " File has missed some data. Failed..."); //For CSV there is Report Name is not getting displayed. File is getting dreated successfully...
                //    }
                //    if (format.ToUpper().Equals("XLS"))
                //    {
                //        Assert.IsTrue(flag, format + " File has missed some data. Failed...");
                //    }
                //    if (format.ToUpper().Equals("XLSX"))
                //    {
                //        Assert.IsTrue(flag, format + " File has missed some data. Failed...");
                //    }
                //}
            }
        }


        [When(@"View Edit Plan Info page Plan ID ""(.*)"" PBP ID ""(.*)"" row is edited and PBP Type as ""(.*)"" State is set to ""(.*)""")]
        public void WhenViewEditPlanInfoPagePlanIDPBPIDRowIsEditedAndPBPTypeAsStateIsSetTo(string p0, string p1, string pbp, string state)
        {
            //By loc = By.XPath("//kendo-grid-list//td[contains(.,'" + p0 + "')]/following-sibling::td[contains(.,'" + p1 + "')]/following-sibling::td/a/span");
            //bool elementPresence = false;
            //By next = By.CssSelector("[title='Go to the next page']");
            //string statedrp="//kendo-dropdownlist[@test-id='planInfoDetails-select-mmpState']//span[@class='k-select']";
            //string pbpdrp = "//kendo-dropdownlist[@test-id='planInfoDetails-select-pbpType']//span[@class='k-select']";           
            //By saveBtn = By.CssSelector("[test-id='planInfoDetails-btn-save']");

            By loc = By.XPath("//kendo-grid-list//td[contains(.,'" + p0 + "')]/following-sibling::td[contains(.,'" + p1 + "')]/following-sibling::td/a/span");
            bool elementPresence = false;
            By next = By.CssSelector("[title='Go to the next page']");
            string statedrp = "//kendo-dropdownlist[@test-id='pbpInfoEdit-select-mmpState']//span[@class='k-select']";
            string pbpdrp = "//kendo-dropdownlist[@test-id='pbpLevel-select-pbpType']//span[@class='k-select']";

            By saveBtn = By.CssSelector("[test-id='pbpLevelFooter-btn-savePbpLevelDetail']");
            By stripLevel = By.XPath("//span[contains(text(),'PBP Level')]");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(stripLevel);

            while (!elementPresence)
            {
                try
                {

                    elementPresence = Browser.Wd.FindElement(loc).Displayed;
                    if (elementPresence)
                    {
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.selectDropDownValueUsingAngularContains(pbpdrp, pbp);
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.selectDropDownValueUsingAngularContains(statedrp, state);
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(saveBtn);
                        tmsWait.Hard(3);
                        break;
                    }


                }
                catch
                {
                    elementPresence = false;
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(next);
                }
            }
        }


        [When(@"View Edit Plan Info page Plan ID ""(.*)"" PBP ID ""(.*)"" row is edited and State is set to ""(.*)""")]
        public void WhenViewEditPlanInfoPagePlanIDPBPIDRowIsEditedAndStateIsSetTo(string p0, string p1, string state)
        {
            By first = By.CssSelector("[title='Go to the first page']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(first);
            // Above statement is added as WorkAround, DevBug is raised.

            By loc = By.XPath("//kendo-grid//table//td[contains(.,'" + p0+ "')]/following-sibling::td[contains(.,'" + p1 + "')]/following-sibling::td/a/span");
            bool elementPresence = false;
            By next = By.CssSelector("[title='Go to the next page']");
            By statedrp = By.XPath("//label[contains(.,'MMP State')]/parent::div//span[@class='k-select']");
            By saveBtn = By.CssSelector("[test-id='planInfoDetails-btn-save']");

            while(!elementPresence)
            {
                try
                {

                    elementPresence = Browser.Wd.FindElement(loc).Displayed;
                    if (elementPresence)
                    {
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);                       
                        ReUsableFunctions.selectDropDownValueUsingContainsTextAngularChanges(Browser.Wd.FindElement(statedrp), state);
                      
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(saveBtn);
                        break;
                    }


                }
                catch
                {
                    elementPresence = false;
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(next);
                }
            }
        }

    }
}
