﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;
using TechTalk.SpecFlow;

namespace TMSoR1
{


    [Binding]
    class cfComplianceReport
    {

        public static QuarterlyDisEnrollmentReport QuarterlyDisEnrollmentReport { get { return new QuarterlyDisEnrollmentReport(); } }
        public static QuarterlyEnrollmentReport QuarterlyEnrollmentReport { get { return new QuarterlyEnrollmentReport(); } }
    }
    [Binding]
    public class QuarterlyEnrollmentReport
    {

        public IWebElement Total_Enrollments_Received_A_Column_Total { get { return Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='6']//tr[11]/td[5]/div/div")); } }
        public IWebElement Enrollments_Complete_at_the_Time_of_Initial_Receipt_B_Column_Total { get { return Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='6']//tr[11]/td[6]/div/div")); } }
        public IWebElement Enrollments_that_Required_Requests_or_Additional_Information_C_Column_Total { get { return Browser.Wd.FindElement(By.XPath("(//div[@dir='LTR']//table[@cols='6']//tr[11]/td[5]/div/div)[2]")); } }
        public IWebElement Enrollments_Denied_Information_to_Complete_Enrollment_not_Received_Timely_F_Column_Total { get { return Browser.Wd.FindElement(By.XPath("(//div[@dir='LTR']//table[@cols='6']//tr[11]/td[6]/div/div)[3]")); } }
        public IWebElement Enrollments_Received_By_Paper_G_Column_Total { get { return Browser.Wd.FindElement(By.XPath("(//div[@dir='LTR']//table[@cols='6']//tr[12]/td/div/div)[2]")); } }
        public IWebElement Enrollments_N_StandAlone_PartD_Total { get { return Browser.Wd.FindElement(By.XPath("(//div[@dir='LTR']//table[@cols='6']//tr[12]/td[5]/div/div)[4]")); }}
        public IWebElement K_PartC_Column_Q2 { get { return Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='8']//tr[6]/td[7]/div/div")); } }
        public IWebElement K_PartD_Column_Q2 { get { return Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='8']//tr[6]/td[8]/div/div")); } }
        public IWebElement Expand_A_Q1 { get { return Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='6']//tr[3]/td[5]/div/div/a")); } }
        public IWebElement Expand_A_Q4 { get { return Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='6']//tr[9]/td[5]/div/div/a")); } }
        public IWebElement Expand_C_Q4 { get { return Browser.Wd.FindElement(By.XPath("(//div[@dir='LTR']//table[@cols='6']//tr[9]/td[5]/div/div/a)[2]")); } }
        public IWebElement Expand_F_Q4 { get { return Browser.Wd.FindElement(By.XPath("(//div[@dir='LTR']//table[@cols='6']//tr[9]/td[6]/div/div/a)[3]")); } }
        public IWebElement Expand_G_Q4 { get { return Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='6']//tr[10]/td[5]/div/div/a")); } }
        public IWebElement Expand_N_StandAlonePartD { get { return Browser.Wd.FindElement(By.XPath("(//div[@dir='LTR']//table[@cols='6']//tr[6]/td[5]/div/div/a)[4]")); } }
        public IWebElement Expand_K_PartC { get { return Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='8']//tr[4]/td[7]/div/div/a")); } }
        public IWebElement Expand_K_PartD { get { return Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='8']//tr[4]/td[8]/div/div/a")); } }
    }

    [Binding]
    public class QuarterlyDisEnrollmentReport
    {

        

        public IWebElement Quarterly_Enrollment_Compliance_Report { get { return Browser.Wd.FindElement(By.XPath("//span[contains(@test-id,'Quarterly Enrollment Compliance')]")); } }
        public IWebElement Quarterly_Disenrollment_Compliance_Report { get { return Browser.Wd.FindElement(By.XPath("//span[contains(@test-id,'Quarterly Disenrollment Compliance')]")); } }


        public IWebElement ExpandMenu { get { return Browser.Wd.FindElement(By.XPath("(//a[@test-id='header-btn-expanMenu'])[1]")); } }
        public IWebElement ReportSection { get { return Browser.Wd.FindElement(By.CssSelector("[title='Reports']")); } }
        public IWebElement ReportButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-runReport']")); } }
        public IWebElement PlanIDDrp { get { return Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='PlanId']//input[@class='k-input']")); } }
        public IWebElement YearDrp { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='Year']//span[@class='k-icon k-i-arrow-s']")); } }
        public IWebElement QuarterDrp { get { return Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='Quarters']//input[@class='k-input']")); } }


        public IWebElement Total_Voluntary_Disenrollments_Received_A_Column_Total { get { return Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='8']//tr[8]/td[5]/div/div")); } }
        public IWebElement Disenrollments_Complete_atthe_Time_of_Initial_Receipt_B_Column_Total { get { return Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='8']//tr[8]/td[6]/div/div")); } }
        public IWebElement Disenrollments_Denied_by_the_Sponsor_for_Any_Reason_C_PartC_Column_Total { get { return Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='8']//tr[8]/td[7]/div/div")); } }
        public IWebElement Total_Involuntary_Disenrollments_Due_to_Failure_to_Pay_Plan_Premium_D_PartC_Column_Total { get { return Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='8']//tr[8]/td[8]/div/div")); } }
        public IWebElement Total_Disenrollments_That_Required_Requests_For_Additional_Information_Column_Total { get { return Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='6']//tr[8]/td[2]/div/div")); } }
        public IWebElement Total_Disenrollments_Denied_by_the_Sponsor_IneligibilityD_PartD { get { return Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='6']//tr[8]/td[3]/div/div")); } }
        public IWebElement G_PartD_Column_Total { get { return Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='6']//tr[8]/td[6]/div/div")); } }
        public IWebElement Disenrollments_Denied_by_the_Sponsor_for_Any_Reason_C_PartC_Column_Q2 { get { return Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='8']//tr[5]/td[7]/div/div")); } }
        public IWebElement Disenrollments_That_Required_Requests_for_Additional_Information_C_PartD_Column_Q2 { get { return Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='6']//tr[4]/td[2]/div/div")); } }
        public IWebElement Disenrollments_Denied_by_the_Sponsor_Ineligibility_Q2 { get { return Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='6']//tr[4]/td[3]/div/div")); } }
        public IWebElement E_PartD_Column_Q2 { get { return Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='6']//tr[4]/td[4]/div/div")); } }
        public IWebElement F_PartD_Column_Q2 { get { return Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='6']//tr[4]/td[5]/div/div")); } }
        public IWebElement G_PartD_Column_Q2 { get { return Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='6']//tr[4]/td[6]/div/div")); } }


        public IWebElement Disenrollments_That_Required_Requests_for_Additional_Information_C_PartD_Column_Count { get { return Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='6']//tr[8]/td[2]/div/div")); } }
        public IWebElement Disenrollments_Denied_by_Sponsor__Ineligibility_D_PartD_Column_count { get { return Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='6']//tr[8]/td[3]/div/div")); } }
        public IWebElement Incomplete_Disenrollments_Received_that_are_Completed_within_an_Established_Time_Frame_E_PartD_Column_count { get { return Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='6']//tr[8]/td[4]/div/div")); } }
        public IWebElement Disenrollments_Denied_Information_to_Complete_Disenrollment_not_Received_Timely_F_PartD_Column_count { get { return Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='6']//tr[8]/td[5]/div/div")); } }
        public IWebElement Total_Involuntary_Disenrollments_Due_to_Failure_to_Pay_Plan_Premium_G_PartD_ColumnCount { get { return Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='6']//tr[8]/td[6]/div/div")); } }









        





    }
}
