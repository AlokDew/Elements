﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using TechTalk.SpecFlow;

using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using System.Diagnostics;
using System.Windows;
using System.Collections.ObjectModel;


namespace TMSoR1
{
    [Binding]
    public class Letters
    {
        public IWebElement LettersTable { get { return Browser.Wd.FindElement(By.XPath("//table[contains(@id, 'dgLetters')]")); } }
        public IWebElement LettersTableNew { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dgLetters")); } }
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.XPath("//select[contains(@id, 'cboPlan')]")); } }
        public IWebElement PBP { get { return Browser.Wd.FindElement(By.XPath("//select[contains(@id, 'cboPBP')]")); } }
        //public IWebElement PBP { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPBP")); } }
      //  public IWebElement SortBy { get { return Browser.Wd.FindElement(By.XPath("//select[contains(@id, 'cboSort')]")); } }
        public IWebElement SortBy { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboSort")); } }
        public IWebElement Values { get { return Browser.Wd.FindElement(By.XPath("//select[contains(@id, 'cboRange')]")); } }
        public IWebElement Language { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboLanguage")); } }
 //       public IWebElement GoButton { get { return Browser.Wd.FindElement(By.XPath("//input[contains(@id, 'btnGo')]")); } }
        public IWebElement GoButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnGo")); } }
        
        public IWebElement PreviewButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnPreview")); } }
        public IWebElement GenerateLetterButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnGenerateLetters")); } }
           
    public IWebElement SelectAll { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lnkSelectAll")); } }
        public IWebElement DeSelectAll { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lnkDeSelectAll")); } }
        public IWebElement RemoveButton { get { return Browser.Wd.FindElement(By.XPath("//input[contains(@id, 'cmdRemove')]")); } }
        public IWebElement ToggleRemoveAll { get { return Browser.Wd.FindElement(By.XPath("//a[contains(@id, 'cmdRemoveAll')]")); } }
        public IWebElement GenerateButton { get { return Browser.Wd.FindElement(By.Id("btnSubmitJob")); } }
        public IWebElement LettersQueueTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_QueuesCtr1_Table2")); } }
        public IWebElement OldLettersQueueTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dgLetters")); } }        
        public IWebElement MedicareMedicaidLettersQueueTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dgLetters")); } }
        public IWebElement LetterPage { get { return Browser.Wd.FindElement(By.Id("outerContainer")); } }
        public IWebElement LetterPageDivID { get { return Browser.Wd.FindElement(By.Id("UpdatePanel1")); } }
        public IWebElement LetterSpyGlass { get { return Browser.Wd.FindElement(By.Id("viewFind")); } }
        public IWebElement LetterSearchText { get { return Browser.Wd.FindElement(By.Id("findInput")); } }
        public IWebElement LetterHighlightAll { get { return Browser.Wd.FindElement(By.Id("findHighlightAll")); } }
        public IWebElement LetterFindNext { get { return Browser.Wd.FindElement(By.Id("findNext")); } }
        public By LetterPageDiv { get { return By.Id("btnSubmitJob"); } }
        public IWebElement LettersGoButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnGo")); } }
        public IWebElement LetterName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlLetterType")); } }
        public IWebElement LettersQueueRemovebutton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cmdRemove")); } }
        public IWebElement LettersHomePageGrid { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_QueuesCtr1_Table2")); } }
    }

    [Binding]
    public class LettersOnDemandLetter : Letters
    {
        public IWebElement LetterName { get { return Browser.Wd.FindElement(By.XPath("//select[contains(@id, 'ddlLetterType')]")); } }  
    }

    [Binding]
    public class LettersPostCMS : Letters
    {
        public IWebElement LettersMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblMsg")); } }
        public IWebElement LettersTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dgLetters")); } }
        public IWebElement LetterDisEnrollPassiveMMP { get { return Browser.Wd.FindElement(By.XPath("//a[contains(@href,'reports/reportmain_letterqueue.aspx?code=030&type=2')]")); } }
        public IWebElement LetterCanEnrollNoticeCMS { get { return Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Reports/reportmain_letterqueue.aspx?code=031&type=2')]")); } }


    }
}
