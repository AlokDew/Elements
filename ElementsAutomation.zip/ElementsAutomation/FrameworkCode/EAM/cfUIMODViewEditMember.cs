﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
namespace TMSoR1
{
    [Binding]

    class cfUIMODViewEditMember
    {
        public static ViewEditMemberPage ViewEditMemberPage { get { return new ViewEditMemberPage(); } }
        public static MemberLookup MemberLookup { get { return new MemberLookup(); } }
        public static ViewEditMemberInformation MemberInformation { get { return new ViewEditMemberInformation(); } }
        public static ViewOOA ViewOOA { get { return new ViewOOA(); } }

    }
    [Binding]
    public class ViewOOA
    {
        public IWebElement ViewOOABtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-btn-viewOoa']")); } }
        public IWebElement PotentialOutOfAreaCheckbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='outOfArea-chk-potentialOutOfArea']")); } }
        public IWebElement OOASave { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='outOfArea-btn-save']")); } }
        public IWebElement OOAClose { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='outOfArea-btn-close']")); } }
        public IWebElement UserModified { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='outOfArea-txt-userModified']")); } }
        public IWebElement DateModified { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='outOfArea-txt-dateModified']")); } }
        public IWebElement AddNewSuspectBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='outOfArea-btn-addSuspect']")); } }
        public IWebElement PossibleSCCDiscrepancyExistsCheckbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='outOfArea-chk-potentialSccDiscrepancy']")); } }
        public IWebElement QueuePotentialOOALetterCheckbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='outOfArea-chk-queuePotentialOoa']")); } }
        public IWebElement InContinuingAreaCheckbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='outOfArea-chk-inContinuingArea']")); } }
        public IWebElement TravelersVisitorsProgramCheckbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='outOfArea-chk-travelersProgram']")); } }
        public IWebElement ICEPConversion { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='outOfArea-chk-icepConversion']")); } }
    }

    [Binding]
    public class ViewEditMemberInformation
    {
        public IWebElement MemberStatus { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-span-memberStatus']")); } }
        public IWebElement MembersubStatus { get { return Browser.Wd.FindElement(By.XPath("//sub[contains(text(),'Future Plan/PBP change')]")); } }
        public IWebElement RecordSource { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-span-recordSource']")); } }
        public IWebElement MBI { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-txt-mbi']")); } }
        public IWebElement MemberID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-txt-memberId']")); } }
        public IWebElement Sal { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-txt-sal']")); } }
        public IWebElement FirstName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-txt-firstName']")); } }
        public IWebElement LastName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-txt-lastName']")); } }
        public IWebElement MI { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-txt-mi']")); } }
        public IWebElement UserEntered { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-span-userEntered']")); } }
        public IWebElement DateEntered { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-span-dateEntered']")); } }
        public IWebElement UserModified { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-span-userModified']")); } }
        public IWebElement DateModified { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-span-dateModified']")); } }



    }


        [Binding]
    public class MemberLookup
    {
        public IWebElement MBI { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberSearch-input-mbi']")); } }
        public IWebElement MBI_R2 { get { return Browser.Wd.FindElement(By.CssSelector("[placeholder='Add MBI']")); } }
        public IWebElement MemberID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberSearch-input-memberId']")); } }
        public IWebElement FirstName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='member-txt-firstname']")); } }
        public IWebElement LastName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='member-txt-lastname']")); } }
        public IWebElement SearchBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='member-btn-search']")); } }
        public IWebElement ResetBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='member-btn-reset']")); } }
        public IWebElement ADDBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='member-btn-add']")); } }
        public IWebElement CancelBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='member-btn-cancel']")); } }
       

    }
        [Binding]
    public class ViewEditMemberPage
    {
        
        public IWebElement MBIorMemSelectBtn { get { return Browser.Wd.FindElement(By.XPath("//or-search[@test-id='memberSearch-ctrl-orsearch']//button[@data-toggle='dropdown']")); } }
        public IWebElement MemberIDTextbox { get { return Browser.Wd.FindElement(By.XPath("//input[@placeholder='Add Member ID']")); } }
        public IWebElement MBITextbox { get { return Browser.Wd.FindElement(By.XPath("//input[@placeholder='Add MBI']")); } }      
        

        public IWebElement FirstName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberSearch-input-firstName']")); } }
        public IWebElement ViewEditPageMemberID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-txt-memberId']")); } }
        public IWebElement MiddleInitial { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberSearch-input-middleInitial']")); } }
        public IWebElement LastName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberSearch-input-lastName']")); } }
        public IWebElement MEMID { get { return Browser.Wd.FindElement(By.XPath("//input[@placeholder='Add Member ID']")); } }
        public IWebElement PlanIDDropDownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='inputBoxPlanId_listbox']")); } }
        public IWebElement PBPIDDropDownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='dropdownPbpId_listbox']")); } }
        public IWebElement MemberStatusDropDownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='dropdownMemberStatus_listbox']")); } }
        public IWebElement ProgramSourceDropDownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='dropdownProgramSource_listbox']")); } }
        public IWebElement ResetBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberSearch-btn-reset']")); } }
        public IWebElement SearchBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberSearch-btn-search']")); } }
        public IWebElement MBILookup { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='deleteSubmittedDiagnosis-a-providerLookup']")); } }
        public IWebElement ViewOOABtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-btn-viewOoa']")); } }
        public IWebElement ViewmemInfo { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='transaction-btn-memberInfo']")); } }
        public IWebElement ViewAttachmentsBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-btn-viewAttachments']")); } }
        public IWebElement ViewSNPBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-btn-viewSnp']")); } }
        public IWebElement AuditHistoryBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-link-viewAudit']")); } }
        public IWebElement ViewNotesBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-btn-viewNotes']")); } }
        public IWebElement NoSearchResult {  get { return Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']/following-sibling::span")); } }
        public IWebElement NextPageSearchResult { get { return Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']")); } }
        public IWebElement ViewAttachmentsSelectBtn { get { return Browser.Wd.FindElement(By.XPath("//input[@id='fileUpload']")); } }


    }
}
