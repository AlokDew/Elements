﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using System.Collections.Generic;
using OpenQA.Selenium.Support.UI;
using System.IO;
using TMSoR1.FrameworkCode;
using System.Linq;
using Microsoft.Data.SqlClient;

namespace TMSoR1
{
    [Binding]
    public class EAMMembersNew
    {

        [Given(@"variable for PlanId ""(.*)"" and PBPID ""(.*)"" are set for PlanType ""(.*)""")]
        [Then(@"variable for PlanId ""(.*)"" and PBPID ""(.*)"" are set for PlanType ""(.*)""")]
        public void GivenVariableForPlanIdAndPBPIDAreSetForPlanType(string p0, string p1, string p2)
        {
            string dbQuery = null;
            switch (p2)
            {
                case "MA-only":
                    {

                        dbQuery = "select top 1 a.planID, a.pbpid  from tbplan_pbp a INNER JOIN tbplans b ON b.PlanId = a.PlanID where b.idtype = 0 and a.PBPType = 0  and a.planID like '[HSR]%' ORDER BY NEWID()";
                        break;
                    }

                case "MA-PD":
                    {
                        dbQuery = "select top 1 a.planID, a.pbpid  from tbplan_pbp a INNER JOIN tbplans b ON b.PlanId = a.PlanID where b.idtype = 0 and a.PBPType = 1  and a.planID like '[HSR]%' ORDER BY NEWID()";  //dbQuery = "select  top 1 planID, pbpid  from tbplan_pbp where PBPType = 1 and planid like '[HSR]%' ORDER BY NEWID()";
                        break;
                    }

                case "PDP":
                    {
                        dbQuery = "select top 1 a.planID, a.pbpid  from tbplan_pbp a INNER JOIN tbplans b ON b.PlanId = a.PlanID where b.idtype = 0 and a.PBPType = 2  and a.planID like '[HSR]%' ORDER BY NEWID()";
                        break;
                    }
                default:
                    {
                        Assert.AreEqual(false, true, "The plan type [" + p2 + "] was not matched");
                        break;
                    }
            }
            string dbName = ConfigFile.EAMdb;

            db.CreateConn(dbName);
            db.AddDBQuery(dbName, dbQuery);
            db.SetValues(dbName, p0, p1);

        }

        [Given(@"variable for Group ""(.*)"" and Subgroup ""(.*)"" and Class ""(.*)""")]
        [Then(@"variable for Group ""(.*)"" and Subgroup ""(.*)"" and Class ""(.*)""")]
        public void GivenVariableForGroupAndSubgroupAndClass(string p0, string p1, string p2)
        {
            string dbQuery = null;
            string dbName = ConfigFile.EAMdb;
            /*
             select top 1 g.GRGR_ID, s.SGSG_ID, c.CSCS_ID
                from groups g
	                inner join subgroups s
		                on g.groupid = s.groupid
	                inner join classes c
		                on c.facetID = g.groupID
	                where g.Active=1
		                and s. Active =1
		                and C.Active =1
                ORDER BY NEWID()
             */

            dbQuery = "select top 1 g.GRGR_ID, s.SGSG_ID, c.CSCS_ID from classes C,groups g inner join subgroups s on g.groupid = s.groupid where g.Active=1 and s. Active =1 and C.Active =1";


            db.CreateConn(dbName);

            db.AddDBQuery(dbName, dbQuery);
            db.SetMemberGroupData(dbName, p0, p1, p2);
        }

        [Given(@"set the ""(.*)"" to active")]
        public void GivenSetTheToActive(string p0)
        {
            string dbQuery = "update " + p0 + " set Active = 1";

            string dbName = ConfigFile.EAMdb;

            db.CreateConn(dbName);
            db.AddDBQuery(dbName, dbQuery);

            db.ExecuteUpdateQuery(dbName);
        }

        [Given(@"Members New HIC is set to MBI(.*) value")]
        public void GivenMembersNewHICIsSetToMBIValue(string p0)
        {
            tmsWait.Hard(3);
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersNew.HICNumber.Clear();
            EAM.MembersNew.HICNumber.SendKeys(GeneratedData);
        }

      


        [Given(@"Members New HIC is set to ""(.*)""")]
        [When(@"Members New HIC is set to ""(.*)""")]
        public void WhenMembersNewHICIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersNew.HICNumber.Clear();
            EAM.MembersNew.HICNumber.SendKeys(GeneratedData);

            GlobalRef.TransMBI = GeneratedData;
        }
        [Then(@"Verify Members New HIC is set to ""(.*)""")]
        public void ThenVerifyMembersNewHICIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            string fieldName = "HIC";
            string GeneratedData = tmsCommon.GenerateData(p0).ToUpper();
            string thisFieldValue = EAM.MembersNew.HICNumber.GetAttribute("value");
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [When(@"Members New Status is set to ""(.*)""")]
        [When(@"Verify Members New Status is set to ""(.*)""")]
        [Then(@"Verify Members New Status is set to ""(.*)""")]
        public void ThenVerifyMembersNewStatusIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string thisFieldValue = "";
            string GeneratedData = tmsCommon.GenerateData(p0).ToUpper();
            try
            {
                thisFieldValue = EAM.MembersNew.Status.Text.ToUpper();
            }
            catch
            {
                tmsWait.Hard(2);
                thisFieldValue = EAM.MembersNew.Status.Text.ToUpper();

            }
            Assert.AreEqual(GeneratedData, thisFieldValue, "Field [Status] has [{0}] value, but expected is [{1}]", thisFieldValue, GeneratedData);

        }

        [When(@"Verify Members New Record Source is set to ""(.*)""")]
        [Then(@"Verify Members New Record Source is set to ""(.*)""")]
        public void ThenVerifyMembersNewRecordSourceIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0).ToUpper();
            string sourceTxt = EAM.MembersNew.RecordSource.Text.ToUpper();
            tmsWait.Hard(3);
            Assert.AreEqual(GeneratedData, sourceTxt, "Field [Record SOurce] has {0} value, but expected is {1}", sourceTxt, GeneratedData);
        }

        [Given(@"Members New PlanID is set to ""(.*)""")]
        [When(@"Members New PlanID is set to ""(.*)""")]
        [Then(@"Members New PlanID is set to ""(.*)""")]
        public void WhenMembersNewPlanIDIsSetTo(string p0)
        {
            string strID = EAM.MembersNew.PBP.GetAttribute("id");

            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.MembersNew.PlanID);
            select.SelectByText(GeneratedData);

            tmsWait.Hard(5);
            tmsWait.WaitForElementExist(By.Id(strID), 15);
        }

        [Then(@"Verify Members New Plan ID is set to ""(.*)""")]
        public void ThenVerifyMembersNewPlanIDIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNew.PlanID.GetAttribute("value");
            IList<IWebElement> thisOptionCollection = EAM.MembersNew.PlanID.FindElements(By.TagName("option"));
            foreach (IWebElement thisOption in thisOptionCollection)
            {
                if (thisOption.GetAttribute("value") == thisFieldValue)
                {
                    thisFieldValue = thisOption.Text;
                    Assert.IsTrue(GeneratedData == thisFieldValue, "Field Plan ID has [{0}] value, but exppected is [{1}]", thisFieldValue, GeneratedData);
                    fw.ConsoleReport(String.Format("   Verification Point: Field Plan ID has [{0}] value, but exppected is [{1}]", thisFieldValue, GeneratedData));
                }
            }
        }

        [Then(@"Verify Members New Part D Opt Out is set to ""(.*)""")]
        public void ThenVerifyMembersNewPartDOptOutIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNew.PartDOptOut.GetAttribute("value");
            IList<IWebElement> thisOptionCollection = EAM.MembersNew.PartDOptOut.FindElements(By.TagName("option"));
            foreach (IWebElement thisOption in thisOptionCollection)
            {
                if (thisOption.GetAttribute("value") == thisFieldValue)
                {
                    thisFieldValue = thisOption.Text;
                    Assert.IsTrue(GeneratedData == thisFieldValue, "PartDOptOut has [{0}] value, but exppected is [{1}]", thisFieldValue, GeneratedData);
                }
            }
        }

        [Then(@"Verify Members New Marital Status is set to ""(.*)""")]
        public void ThenVerifyMembersNewMaritalStatusIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNew.MaritalStatus.GetAttribute("value");
            IList<IWebElement> thisOptionCollection = EAM.MembersNew.MaritalStatus.FindElements(By.TagName("option"));
            foreach (IWebElement thisOption in thisOptionCollection)
            {
                if (thisOption.GetAttribute("value") == thisFieldValue)
                {
                    thisFieldValue = thisOption.Text;
                    Assert.IsTrue(GeneratedData == thisFieldValue, "MaritalStatus has [{0}] value, but exppected is [{1}]", thisFieldValue, GeneratedData);
                }
            }
        }

        [Then(@"Verify Members New Language is set to ""(.*)""")]
        public void ThenVerifyMembersNewLanguageIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNew.Language.GetAttribute("value");
            IList<IWebElement> thisOptionCollection = EAM.MembersNew.Language.FindElements(By.TagName("option"));
            foreach (IWebElement thisOption in thisOptionCollection)
            {
                if (thisOption.GetAttribute("value") == thisFieldValue)
                {
                    thisFieldValue = thisOption.Text;
                    Assert.IsTrue(GeneratedData == thisFieldValue, "Language has [{0}] value, but exppected is [{1}]", thisFieldValue, GeneratedData);
                }
            }
        }

        [Then(@"VeifyMembers New DOD is set to ""(.*)""")]
        public void ThenVeifyMembersNewDODIsSetTo(string p0)
        {
            Assert.AreEqual(p0, EAM.MembersNew.DOD.Text);
        }

        [Then(@"Verify Members New Sal is set to ""(.*)""")]
        public void ThenVerifyMembersNewSalIsSetTo(string p0)
        {
            Assert.AreEqual(p0, EAM.MembersNew.Sal.Text);
        }

        [Then(@"Verify Members New Medicaid Number is set to ""(.*)""")]
        public void ThenVerifyMembersNewMedicaidNumberIsSetTo(int p0)
        {
            Assert.AreEqual(p0.ToString(), EAM.MembersNew.MedicaidNumber.Text);
        }



        [Then(@"Verify Members New Group is set to ""(.*)""")]
        public void ThenVerifyMembersNewGroupIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNew.Group.GetAttribute("value");
            IList<IWebElement> thisOptionCollection = EAM.MembersNew.Group.FindElements(By.TagName("option"));
            foreach (IWebElement thisOption in thisOptionCollection)
            {
                if (thisOption.GetAttribute("value") == thisFieldValue)
                {
                    thisFieldValue = thisOption.Text;
                    Assert.IsTrue(GeneratedData == thisFieldValue, "Field Plan ID has [{0}] value, but exppected is [{1}]", thisFieldValue, GeneratedData);
                    fw.ConsoleReport(String.Format("   Verification Point: Field Plan ID has [{0}] value, but exppected is [{1}]", thisFieldValue, GeneratedData));
                }
            }
        }

        [Then(@"Verify Members New Sub-Group is set to ""(.*)""")]
        public void ThenVerifyMembersNewSub_GroupIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNew.SubGroup.GetAttribute("value");
            IList<IWebElement> thisOptionCollection = EAM.MembersNew.SubGroup.FindElements(By.TagName("option"));
            foreach (IWebElement thisOption in thisOptionCollection)
            {
                if (thisOption.GetAttribute("value") == thisFieldValue)
                {
                    thisFieldValue = thisOption.Text;
                    Assert.IsTrue(GeneratedData == thisFieldValue, "Field Plan ID has [{0}] value, but exppected is [{1}]", thisFieldValue, GeneratedData);
                    fw.ConsoleReport(String.Format("   Verification Point: Field Plan ID has [{0}] value, but exppected is [{1}]", thisFieldValue, GeneratedData));
                }
            }
        }

        [Then(@"Verify Members New Class is set to ""(.*)""")]
        public void ThenVerifyMembersNewClassIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNew.Class.GetAttribute("value");
            IList<IWebElement> thisOptionCollection = EAM.MembersNew.Class.FindElements(By.TagName("option"));
            foreach (IWebElement thisOption in thisOptionCollection)
            {
                if (thisOption.GetAttribute("value") == thisFieldValue)
                {
                    thisFieldValue = thisOption.Text;
                    Assert.IsTrue(GeneratedData == thisFieldValue, "Field Plan ID has [{0}] value, but exppected is [{1}]", thisFieldValue, GeneratedData);
                    fw.ConsoleReport(String.Format("   Verification Point: Field Plan ID has [{0}] value, but exppected is [{1}]", thisFieldValue, GeneratedData));
                }
            }
        }



        [Then(@"Verify Members New PBP is set to ""(.*)""")]
        public void ThenVerifyMembersNewPBPIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNew.PBP.GetAttribute("value");
            IList<IWebElement> thisOptionCollection = EAM.MembersNew.PBP.FindElements(By.TagName("option"));
            foreach (IWebElement thisOption in thisOptionCollection)
            {
                if (thisOption.GetAttribute("value") == thisFieldValue)
                {
                    thisFieldValue = thisOption.Text;
                    Assert.IsTrue(GeneratedData == thisFieldValue, "Field PBP has [{0}] value, but exppected is [{1}]", thisFieldValue, GeneratedData);
                    fw.ConsoleReport(String.Format("   Verification Point: Field PBP has [{0}] value, but exppected is [{1}]", thisFieldValue, GeneratedData));
                }
            }
        }

        [Then(@"Verify Members New SegID is set to ""(.*)""")]
        public void ThenVerifyMembersNewSegIDIsSetTo(int p0)
        {
            Assert.AreEqual(p0.ToString(), EAM.MembersNew.SCC.Text);
        }


        [Given(@"Members New First Name is set to ""(.*)""")]
        [When(@"Members New First Name is set to ""(.*)""")]
        public void WhenMembersNewFirstNameIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersNew.FirstName.Clear();
            EAM.MembersNew.FirstName.SendKeys(GeneratedData);
        }
        [Then(@"Verify Members New First Name is set to ""(.*)""")]
        public void ThenVerifyMembersNewFirstNameIsSetTo(string p0)
        {
            string fieldName = "First Name";
            string GeneratedData = tmsCommon.GenerateData(p0).ToUpper();
            string thisFieldValue = EAM.MembersNew.FirstName.GetAttribute("value");
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Given(@"Members New Last Name is set to ""(.*)""")]
        [When(@"Members New Last Name is set to ""(.*)""")]
        public void WhenMembersNewLastNameIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersNew.LastName.Clear();
            EAM.MembersNew.LastName.SendKeys(GeneratedData);
        }

        [Then(@"Verify Members New Last Name is set to ""(.*)""")]
        public void ThenVerifyMembersNewLastNameIsSetTo(string p0)
        {
            string fieldName = "Last Name";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNew.LastName.GetAttribute("value");
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");

        }

        [When(@"Members New MI is set to ""(.*)""")]
        public void WhenMembersNewMIIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersNew.MI.Clear();
            EAM.MembersNew.MI.SendKeys(GeneratedData);
        }
        [Then(@"Verify Members New MI is set to ""(.*)""")]
        public void ThenVerifyMembersNewMIIsSetTo(string p0)
        {
            string fieldName = "MI";
            string GeneratedData = tmsCommon.GenerateData(p0).ToUpper();
            string thisFieldValue = EAM.MembersNew.MI.GetAttribute("value");
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [When(@"Members New Appel is set to ""(.*)""")]
        public void WhenMembersNewAppelIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersNew.Appel.Clear();
            EAM.MembersNew.Appel.SendKeys(GeneratedData);
        }
        [Then(@"Verify Members New Appel is set to ""(.*)""")]
        public void ThenVerifyMembersNewAppelIsSetTo(string p0)
        {
            string fieldName = "Appel";
            string GeneratedData = tmsCommon.GenerateData(p0).ToUpper();
            string thisFieldValue = EAM.MembersNew.Appel.GetAttribute("value");
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Given(@"Members New Member ID is set to ""(.*)""")]
        [When(@"Members New Member ID is set to ""(.*)""")]
        public void WhenMembersNewMemberIDIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersNew.MemberID.Clear();
            EAM.MembersNew.MemberID.SendKeys(GeneratedData);
        }
        [Then(@"Verify Members New Member ID is set to ""(.*)""")]
        public void ThenVerifyMembersNewMemberIDIsSetTo(string p0)
        {
            string fieldName = "Member ID";
            string GeneratedData = tmsCommon.GenerateData(p0).ToUpper();
            string thisFieldValue = EAM.MembersNew.MemberID.GetAttribute("value");
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Given(@"Members New DOB is set to ""(.*)""")]
        [When(@"Members New DOB is set to ""(.*)""")]
        public void WhenMembersNewDOBIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            //  string thisValue = "";
            int iCount = 0;
            // Boolean bNotSet = true;
            while (iCount++ < 2)
            {
                string GeneratedData = tmsCommon.GenerateData(p0);
                GeneratedData = GeneratedData.Replace("/", "");
                EAM.MembersNew.DOB.Clear();
                EAM.MembersNew.DOB.SendKeys(GeneratedData);
                tmsWait.Hard(1);
                //06.09.2016 -Daron - DOB is not setting so i am pushing it twice.  
                //after it's set, I can't find a way to know, so just running it twice..

                //thisValue = EAM.MembersNew.DOB.GetCssValue("value");
                //if (thisValue == p0)
                //{
                //    bNotSet = false;
                //}
                //iCount++;
                //if (iCount > 7)
                //{
                //    bNotSet = false;
                //    //have to get out if it's not going to set.
                //}

            }
            GlobalRef.DOB = tmsCommon.GenerateData(p0);
        }

        [When(@"Sex Popup is clicked")]
        public void WhenSexPopupIsClicked()
        {
            EAM.MembersNew.SexPopUp.Click();
        }

        [Then(@"Verify that the Sex Pop is displayed")]
        public void ThenVerifyThatTheSexPopIsDisplayed()
        {
            Assert.IsTrue(EAM.MembersNew.SexPopUpDlg.Displayed);
        }
        [Then(@"Verify that the table sex has the following rows")]
        public void ThenVerifyThatTheTableSexHasTheFollowingRows(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                IWebElement dlg = EAM.MembersNew.SexPopUpDlg;
                IWebElement tablep = dlg.FindElement(By.XPath(".//table"));

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = dlg.FindElement(By.XPath(".//table"));

                // IList<IWebElement> GenderRows = EAM.MembersNew.Sex.FindElements(By.TagName("tr"));


                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same
                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }

                baseTable = dlg.FindElement(By.XPath(".//table"));

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

        [Then(@"close the Sex popup")]
        public void ThenCloseTheSexPopup()
        {
            EAM.MembersNew.SexPopupClose.Click();
        }

        [When(@"Latest Election type Popup is clicked")]
        public void WhenLatestElectionTypePopupIsClicked()
        {
            EAM.MembersNew.ElectionTypePopUp.Click();
        }

        [Then(@"the Election Type popup Information has rows")]
        public void ThenTheElectionTypePopupInformationHasRows(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                IWebElement dlg = EAM.MembersNew.ElectionTypeDlg;
                IWebElement tablep = dlg.FindElement(By.XPath(".//table"));

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = dlg.FindElement(By.XPath(".//table"));

                // IList<IWebElement> GenderRows = EAM.MembersNew.Sex.FindElements(By.TagName("tr"));


                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same
                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }

                baseTable = dlg.FindElement(By.XPath(".//table"));

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

        [Then(@"Election Type button X is clicked")]
        public void ThenElectionTypeButtonXIsClicked()
        {
            fw.ExecuteJavascript(EAM.MembersNew.ElectionTypePopupClose);
        }

        [Then(@"Election Type Popup is closed")]
        public void ThenElectionTypePopupIsClosed()
        {
            IWebElement electiontypeDlg = null;
            try
            {
                electiontypeDlg = EAM.MembersNew.ElectionTypeDlg;
            }
            catch
            {
                Assert.AreEqual(electiontypeDlg, null);
            }
        }

        [Then(@"Marital Status popup is clicked")]
        public void ThenMaritalStatusPopupIsClicked()
        {
            EAM.MembersNew.MaritalStatuspopup.Click();
        }

        [Then(@"the Marital popup Information has rows")]
        public void ThenTheMaritalPopupInformationHasRows(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                IWebElement dlg = EAM.MembersNew.MaritalStatusDlg;
                IWebElement tablep = dlg.FindElement(By.XPath(".//table"));

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = dlg.FindElement(By.XPath(".//table"));

                // IList<IWebElement> GenderRows = EAM.MembersNew.Sex.FindElements(By.TagName("tr"));


                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same
                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }

                baseTable = dlg.FindElement(By.XPath(".//table"));

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

        [Then(@"Members Marital Status button X is clicked")]
        public void ThenMembersMaritalStatusButtonXIsClicked()
        {
            // IWebElement temp = EAM.MembersNew.MaritalStatusTitleBar;

            IWebElement pop = Browser.Wd.FindElement(By.XPath("(//a[@role='button'])[2]"));
            fw.ExecuteJavascript(pop);
        }

        [Then(@"Verify Marital Status Popup is closed")]
        public void ThenVerifyMaritalStatusPopupIsClosed()
        {
            IWebElement maritalStatusDlg = null;
            try
            {
                maritalStatusDlg = EAM.MembersNew.MaritalStatusDlg;
            }
            catch
            {
                Assert.AreEqual(maritalStatusDlg, null);
            }
        }

        [Then(@"Race Popup is clicked")]
        public void ThenRacePopupIsClicked()
        {
            EAM.MembersNew.RacePopupBtn.Click();
        }

        [Then(@"the Race popup Information has rows")]
        public void ThenTheRacePopupInformationHasRows(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                IWebElement dlg = EAM.MembersNew.RacePopDlg;
                IWebElement tablep = dlg.FindElement(By.XPath(".//table"));

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = dlg.FindElement(By.XPath(".//table"));

                // IList<IWebElement> GenderRows = EAM.MembersNew.Sex.FindElements(By.TagName("tr"));


                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same
                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }

                baseTable = dlg.FindElement(By.XPath(".//table"));

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

        [Then(@"Members Race button X is clicked")]
        public void ThenMembersRaceButtonXIsClicked()
        {
            fw.ExecuteJavascript(EAM.MembersNew.RacePopClose);
        }

        [Then(@"Race Popup is closed")]
        public void ThenRacePopupIsClosed()
        {
            IWebElement raceDlg = null;
            try
            {
                raceDlg = EAM.MembersNew.RacePopDlg;
            }
            catch
            {
                Assert.AreEqual(raceDlg, null);
            }
        }


        [Then(@"Verify Members New DOB is set to ""(.*)""")]
        public void ThenVerifyMembersNewDOBIsSetTo(string p0)
        {
            string fieldName = "DOB";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNew.DOB.GetAttribute("value");
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Given(@"Members New Sex is set to ""(.*)""")]
        [When(@"Members New Sex is set to ""(.*)""")]
        [Then(@"Members New Sex is set to ""(.*)""")]
        public void WhenMembersNewSexIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.MembersNew.Sex);
            select.SelectByText(GeneratedData);
        }
        [Then(@"Verify Members New Sex is set to ""(.*)""")]
        public void ThenVerifyMembersNewSexIsSetTo(string p0)
        {
            string fieldName = "Sex";
            string GeneratedData = tmsCommon.GenerateData(p0).ToUpper();
            string thisFieldValue = EAM.MembersNew.Sex.GetAttribute("value"); //Will give a 1 or -1, etc.  Needs next step to validate text
            IList<IWebElement> thisOptionCollection = EAM.MembersNew.Sex.FindElements(By.TagName("option"));  //Get the options
            foreach (IWebElement thisOption in thisOptionCollection) //Loop through them
            {
                if (thisOption.GetAttribute("value") == thisFieldValue)  //if this option has the same value we found above (4 lines) then.. See if the text is right
                {
                    thisFieldValue = thisOption.Text;
                    Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
                    fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
                    break;
                }
            }
        }

        [Then(@"Verify Members New SSN is set to ""(.*)""")]
        public void ThenVerifyMembersNewSSNIsSetTo(int p0)
        {
            string SSN = p0.ToString();
            Assert.AreEqual(SSN, EAM.MembersNew.SSN.Text);
        }

        [Then(@"Verify Members New Plan(.*) is set to ""(.*)""")]
        public void ThenVerifyMembersNewPlanIsSetTo(int p0, int p1)
        {
            Assert.AreEqual(p1, EAM.MembersNew.Plan1.Text);
        }


        [When(@"Members New SSN is set to ""(.*)""")]
        public void WhenMembersNewSSNIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersNew.SSN.Clear();
            EAM.MembersNew.SSN.SendKeys(GeneratedData);
        }

        [When(@"Members New Plan1 is set to ""(.*)""")]
        public void WhenMembersNewPlanIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersNew.Plan1.SendKeys(GeneratedData);
        }

        [When(@"Members New Group is set to ""(.*)""")]
        [Then(@"Members New Group is set to ""(.*)""")]
        public void WhenMembersNewGroupIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string value = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.MembersNew.Group);
            select.SelectByText(value);
            tmsWait.Hard(2);
        }

        [When(@"Members New Sub-Group is set to ""(.*)""")]
        [Then(@"Members New Sub-Group is set to ""(.*)""")]
        public void WhenMembersNewSub_GroupIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string value = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.MembersNew.SubGroup);
            select.SelectByText(value);
            tmsWait.Hard(2);
        }

        [When(@"Members New Class is set to ""(.*)""")]
        [Then(@"Members New Class is set to ""(.*)""")]
        public void WhenMembersNewClassIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string value = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.MembersNew.Class);
            select.SelectByText(value);
        }

        [Given(@"Members New PBP is set to ""(.*)""")]
        [When(@"Members New PBP is set to ""(.*)""")]
        [Then(@"Members New PBP is set to ""(.*)""")]
        public void WhenMembersNewPBPIsSetTo(string p0)
        {
            string strID = EAM.MembersNew.PlanID.GetAttribute("id");

            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.MembersNew.PBP);
            select.SelectByText(GeneratedData);

            tmsWait.Hard(5);
            //  tmsWait.WaitForElementExist(By.Id(strID), 15);
        }

        [When(@"Members New SegID is set to ""(.*)""")]
        public void WhenMembersNewSegIDIsSetTo(string p0)
        {
            SelectElement select = new SelectElement(EAM.MembersNew.SegID);
            select.SelectByText(p0);
        }

        [Then(@"Verify Member View Edit page displays message ""(.*)""")]
        public void ThenVerifyMemberViewEditPageDisplaysMessage(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNew.ResponseMessage.Text;

            Assert.AreEqual(GeneratedData, thisFieldValue, "Actual msg is [{0}], but expected is [{1}]", thisFieldValue, GeneratedData);
            fw.ConsoleReport("   Verification Point: Response message is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }


        [When(@"Members New Effective Date is set as ""(.*)""")]
        public void WhenMembersNewEffectiveDateIsSetAs(string p0)
        {
            //tmsWait.Hard(5);

            //string GeneratedData = tmsCommon.GenerateData(p0);
            //GeneratedData = GeneratedData.Replace("/", "");
            //EAM.MembersNew.EffectiveDate.Clear();
            //EAM.MembersNew.EffectiveDate.Click();
            //EAM.MembersNew.EffectiveDate.SendKeys(Keys.Home);
            //tmsWait.Hard(5);
            //EAM.MembersNew.EffectiveDate.SendKeys(Keys.Home);
            //EAM.MembersNew.EffectiveDate.SendKeys(GeneratedData);
            //tmsWait.Hard(1);
            fw.ExecuteJavascriptSetText(EAM.MembersNew.EffectiveDate, "01/01/1998");


        }

        [Then(@"Verify Member Info Page TRR Tab Static Message is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageTRRTabStaticMessageIsSetTo(string expected)
        {
            string actual = EAM.MembersNew.TRRStaticMsg.Text;

            Assert.AreEqual(expected, actual, expected + "is not geting displayed");

        }

        [Then(@"Member Info Page Transactions tab is clicked")]
        public void ThenMemberInfoPageTransactionsTabIsClicked()
        {
            EAM.MemberInformation.TransactionsTab.Click();
        }

        [Then(@"Verify Member Info Page Transactions Tab Static Message is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageTransactionsTabStaticMessageIsSetTo(string expected)
        {
            string actual = EAM.MembersNew.TransactionTabStaticMsg.Text;

            Assert.AreEqual(expected, actual, expected + "is not geting displayed");

        }


        [Then(@"Member Info Page TRR tab is clicked")]
        public void ThenMemberInfoPageTRRTabIsClicked()
        {
            EAM.MemberInformation.TRRTab.Click();
            tmsWait.Hard(2);
        }
        string actualres = null;
        [Then(@"Verify Member View Edit page RX Billing Tab ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditPageRXBillingTabIsSetTo(string field, string value)
        {

            switch (field)
            {

                case "Part C Premium":
                    Assert.AreEqual(EAM.MembersNewTabRXBilling.PartCPremium.Text, value, value + "is not getting matched");
                    break;
                case "Part D Premium":
                    Assert.AreEqual(EAM.MembersNewTabRXBilling.PartDPremium.GetAttribute("value"), value, value + "is not getting matched");
                    break;
                case "Bill Amount":
                    Assert.AreEqual(EAM.MembersNewTabRXBilling.BillAmount.Text, value, value + "is not getting matched");
                    break;
                case "Sec. Rx ID":
                    Assert.AreEqual(EAM.MembersNewTabRXBilling.SecRxID.Text, value, value + "is not getting matched");
                    break;
                case "Sec. Rx Group":
                    Assert.AreEqual(EAM.MembersNewTabRXBilling.SecRxGroup.Text, value, value + "is not getting matched");
                    break;
                case "Sec. BIN":
                    Assert.AreEqual(EAM.MembersNewTabRXBilling.SecBIN.Text, value, value + "is not getting matched");
                    break;
                case "Uncovered Months":
                    Assert.AreEqual(EAM.MembersNewTabRXBilling.UncoveredMonths.Text, value, value + "is not getting matched");
                    break;
                case "Bill Eff Date":
                    Assert.AreEqual(EAM.MembersNewTabRXBilling.BillEffDate.Text, value, value + "is not getting matched");
                    break;
                case "Employer Name":
                    Assert.AreEqual(EAM.MembersNewTabRXBilling.EmployerName.Text, value, value + "is not getting matched");
                    break;
                case "Other Ins Name":
                    Assert.AreEqual(EAM.MembersNewTabRXBilling.OtherInsName.Text, value, value + "is not getting matched");
                    break;
                case "Second PCN":
                    Assert.AreEqual(EAM.MembersNewTabRXBilling.SecondPCN.Text, value, value + "is not getting matched");
                    break;
                case "LEP Amount":
                    Assert.AreEqual(EAM.MembersNewTabRXBilling.LEPAmt.GetAttribute("value"), value, value + "is not getting matched");
                    break;
                case "LEP Subs Amount":
                    Assert.AreEqual(EAM.MembersNewTabRXBilling.LEPSubsAmt.GetAttribute("value"), value, value + "is not getting matched");
                    break;
                case "LEP Waived Amount":
                    Assert.AreEqual(EAM.MembersNewTabRXBilling.LEPWaivedAmt.GetAttribute("value"), value, value + "is not getting matched");
                    break;
                case "Credit Cover":
                    SelectElement cc = new SelectElement(EAM.MembersNewTabRXBilling.CreditCover);
                    actualres = cc.SelectedOption.GetAttribute("value");
                    Assert.AreEqual(actualres, value, value + "is not getting matched");
                    break;
                case "Employer Group Number":
                    actualres = EAM.MembersNewTabRXBilling.EmployerGroupNumber.GetAttribute("value");
                    Assert.AreEqual(actualres, value, value + "is not getting matched");
                    break;
                case "Medical ID":
                    SelectElement mi = new SelectElement(EAM.MembersNewTabRXBilling.MedicalID);
                    actualres = mi.SelectedOption.Text;
                    Assert.AreEqual(actualres, value, value + "is not getting matched");
                    break;
                case "Pharmacy ID":
                    SelectElement pi = new SelectElement(EAM.MembersNewTabRXBilling.PharmacyID);
                    actualres = pi.SelectedOption.Text;
                    Assert.AreEqual(actualres, value, value + "is not getting matched");
                    break;
                case "Dental ID":
                    SelectElement di = new SelectElement(EAM.MembersNewTabRXBilling.DentalID);
                    actualres = di.SelectedOption.Text;
                    Assert.AreEqual(actualres, value, value + "is not getting matched");
                    break;
                case "Vision ID":
                    SelectElement vi = new SelectElement(EAM.MembersNewTabRXBilling.VisionID);
                    actualres = vi.SelectedOption.Text;
                    Assert.AreEqual(actualres, value, value + "is not getting matched");
                    break;

            }
        }


        [Given(@"Members New Effective Date is set to ""(.*)""")]
        [When(@"Members New Effective Date is set to ""(.*)""")]
        public void WhenMembersNewEffectiveDateIsSetTo(string eff)
        {
            tmsWait.Hard(2);
            string p0 = tmsCommon.GenerateData(eff);

            fw.ExecuteJavascriptSetText(EAM.MembersNew.EffectiveDate, p0);

            //string GeneratedData = tmsCommon.GenerateData(p0);
            //string ExpectedData = GeneratedData;
            //GeneratedData = GeneratedData.Replace("/", "");
            //tmsWait.Hard(5);
            //for (int i = 0; i < 5; i++)
            //{
            //    EAM.MembersNew.EffectiveDate.Click();
            //    tmsWait.Hard(1);
            //    EAM.MembersNew.EffectiveDate.SendKeys(GeneratedData);
            //    EAM.MembersNew.EffectiveDate.SendKeys(Keys.Tab);

            //    tmsWait.Hard(1);
            //    string thisValue = EAM.MembersNew.EffectiveDate.GetAttribute("value");
            //    tmsWait.Hard(1);
            //    if (thisValue == ExpectedData)
            //    {
            //        break;
            //    }
            //    else
            //    {
            //        EAM.MembersNew.EffectiveDate.Clear();
            //        tmsWait.Hard(1);
            //    }
            //}
            //EAM.MembersNew.EffectiveDate.Clear();
            //tmsWait.Hard(1);
            //EAM.MembersNew.EffectiveDate.SendKeys(GeneratedData);
            //tmsWait.Hard(1);
            //string GeneratedData = tmsCommon.GenerateData(p0);
            //GeneratedData = GeneratedData.Replace("/", "");
            //EAM.MembersNew.EffectiveDate.Clear();
            //EAM.MembersNew.EffectiveDate.Click();
            //EAM.MembersNew.EffectiveDate.SendKeys(Keys.Home);
            //EAM.MembersNew.EffectiveDate.SendKeys(GeneratedData);
        }

        [Then(@"Verify Members New Effective Date is set to ""(.*)""")]
        public void ThenVerifyMembersNewEffectiveDateIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNew.EffectiveDate.GetAttribute("value");
            Assert.AreEqual(GeneratedData, thisFieldValue, "Term Date has value [{0}], but expected is [{1}]", thisFieldValue, GeneratedData);
            fw.ConsoleReport("   Verification Point: Field Effective Date value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }


        [When(@"Members New Term Date is set to ""(.*)""")]
        public void WhenMembersNewTermDateIsSetTo(string term)
        {
            string p0 = tmsCommon.GenerateData(term);
            fw.ExecuteJavascriptSetText(EAM.MembersNew.TermDate, p0);
            //string GeneratedData = tmsCommon.GenerateData(p0);
            //string ExpectedData = GeneratedData;

            //GeneratedData = GeneratedData.Replace("/", "");
            //for (int i = 0; i < 5; i++)
            //{
            //    EAM.MembersNew.TermDate.SendKeys(GeneratedData);
            //    tmsWait.Hard(1);
            //    string thisValue = EAM.MembersNew.TermDate.GetAttribute("value");
            //    tmsWait.Hard(1);
            //    if (thisValue == ExpectedData)
            //    {
            //        break;
            //    }
            //    else
            //    {
            //        EAM.MembersNew.TermDate.Clear();
            //        tmsWait.Hard(1);
            //    }
            //}


            //EAM.MembersNew.TermDate.Clear();
            //EAM.MembersNew.TermDate.SendKeys(GeneratedData);
        }

        [Then(@"Verify Members New Term Date is set to ""(.*)""")]
        public void ThenVerifyMembersNewTermDateIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNew.TermDate.GetAttribute("value");
            Assert.AreEqual(GeneratedData, thisFieldValue, "Term Date has value [{0}], but expected is [{1}]", thisFieldValue, GeneratedData);
            fw.ConsoleReport("   Verification Point: Field Term Date value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");

        }

        [Given(@"Members New Latest Elect\. Type is set to ""(.*)""")]
        [When(@"Members New Latest Elect\. Type is set to ""(.*)""")]
        public void WhenMembersNewLatestElect_TypeIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.MembersNew.LatestElectType);
            select.SelectByText(GeneratedData);
        }

        [Then(@"Verify Members New Latest Elect\. Type is set to ""(.*)""")]
        public void ThenVerifyMembersNewLatestElect_TypeIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = "";

            IList<IWebElement> theseOptions = EAM.MembersNew.LatestElectType.FindElements(By.TagName("option"));
            foreach (IWebElement thisOption in theseOptions)
            {
                string selectedAttribute = thisOption.GetAttribute("selected");
                if (selectedAttribute == "true")
                {
                    thisFieldValue = thisOption.Text;
                    break;
                }
            }

            Assert.AreEqual(GeneratedData, thisFieldValue, "Latest Elect Type has value [{0}] but expected is [{1}]", thisFieldValue, GeneratedData);
        }

        [When(@"Members New IPA Group ID is set to ""(.*)""")]
        public void WhenMembersNewIPAGroupIDIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersNew.IPAGroupID.SendKeys(GeneratedData);
        }

        [Then(@"Verify Members New IPA Group ID is set to ""(.*)""")]
        public void ThenVerifyMembersNewIPAGroupIDIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNew.IPAGroupID.GetAttribute("value");
            Assert.IsTrue(GeneratedData == thisFieldValue, "Field IPA Group ID value is [{0}], expected [{1}]", thisFieldValue, GeneratedData);
            fw.ConsoleReport(String.Format("   Verification Point: Field IPA Group ID value is [{0}], expected [{1}] - They are expected to match.", thisFieldValue, GeneratedData));
        }

        [When(@"Members New IPA Group ID Link is clicked")]
        public void WhenMembersNewIPAGroupIDLinkIsClicked()
        {
            EAM.MembersNew.IPAGroupIDLink.Click();
            tmsWait.Hard(1);
        }


        [Then(@"Verify ""(.*)"" dropdown is disabled")]
        public void ThenVerifyDropdownIsDisabled(string p0)
        {
            tmsWait.Hard(3);
            Browser.Wd.SwitchTo();
            IWebElement participatingdd = Browser.Wd.FindElement(By.XPath("//form//select[@id='ddParticipate']"));
        }


        [When(@"Members New Part D Opt Out is set to ""(.*)""")]
        public void WhenMembersNewPartDOptOutIsSetTo(string p0)
        {
            SelectElement select = new SelectElement(EAM.MembersNew.PartDOptOut);
            select.SelectByText(p0);
        }

        [Then(@"Verify Members New Part D Opt-out is set to ""(.*)""")]
        public void ThenVerifyMembersNewPartDOpt_OutIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = "";

            IList<IWebElement> theseOptions = EAM.MembersNew.PartDOptOut.FindElements(By.TagName("option"));
            foreach (IWebElement thisOption in theseOptions)
            {
                string selectedAttribute = thisOption.GetAttribute("selected");
                if (selectedAttribute == "true")
                {
                    thisFieldValue = thisOption.Text;
                    break;
                }
            }
            Assert.IsTrue(GeneratedData == thisFieldValue, "Field IPA Part D Opt-out value is [{0}], expected [{1}]", thisFieldValue, GeneratedData);

        }

        [When(@"Members New RX ID is set to ""(.*)""")]
        public void WhenMembersNewRXIDIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersNew.RXID.SendKeys(GeneratedData);
            tmsWait.Hard(1);
            EAM.MembersNew.RXID.Clear();
            tmsWait.Hard(1);
            EAM.MembersNew.RXID.SendKeys(GeneratedData);
            tmsWait.Hard(1);

        }

        [Then(@"Verify Members New RX ID is set to ""(.*)""")]
        public void ThenVerifyMembersNewRXIDIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNew.RXID.GetAttribute("value");
            Assert.IsTrue(GeneratedData == thisFieldValue, "Field RxID value is [{0}], expected [{1}]", thisFieldValue, GeneratedData);
        }

        //[Then(@"Verify Members New RX ID is blank")]
        //public void ThenVerifyMembersNewRXIDIsBlank()
        //{

        //    Boolean checked = isAttribtuePresent(EAM.MembersNew.RXID, "value");

           
        //}

        //public Boolean isAttribtuePresent(IWebElement element, String attribute)
        //{
        //    Boolean result = false;
        //    try
        //    {
        //        String value = element.GetAttribute(attribute);
        //        if (value != null)
        //        {
        //            result = true;
        //        }
        //    }
        //    catch (Exception e) { }

        //    return result;
        //}

        [When(@"Members New RX Group is set to ""(.*)""")]
        public void WhenMembersNewRXGroupIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersNew.RXGroup.SendKeys(GeneratedData);
        }

        [Then(@"Verify Members New RX Group is set to ""(.*)""")]
        public void ThenVerifyMembersNewRXGroupIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNew.RXGroup.GetAttribute("value");
            Assert.IsTrue(GeneratedData == thisFieldValue, "Field RXGroup value is [{0}], expected [{1}]", thisFieldValue, GeneratedData);
        }

        [Then(@"Verify that there is no SNP icon")]
        public void ThenVerifyThatThereIsNoSNPIcon()
        {
           IWebElement SNPIcon = null;
            try
            {
                SNPIcon = EAM.MembersNew.SNPIcon;
            }
            catch
            {
                Assert.AreEqual(SNPIcon, null);
                Console.Write("SNPIcon does not exist");
            }
        }

        [Then(@"Verify that the SNP icon is present")]
        public void ThenVerifyThatTheSNPIconIsPresent()
        {
            IWebElement SNPIcon = EAM.MembersNew.SNPIcon;
            Assert.IsTrue(SNPIcon.Displayed);
        }

        [When(@"the SNP button is clicked")]
        public void WhenTheSNPButtonIsClicked()
        {
            IWebElement SNPIcon = EAM.MembersNew.SNPIcon;
            fw.ExecuteJavascript(SNPIcon);
        }

        [Then(@"Verify SNP follow up Activity page is displayed")]
        public void ThenVerifySNPFollowUpActivityPageIsDisplayed()
        {
            tmsWait.Hard(2);
            Browser.Wd.SwitchTo();
            IWebElement SNPAtivityDialog = EAM.MembersNew.SNPActivityDialog;
            Assert.IsTrue(SNPAtivityDialog.Displayed);
        }

        [Then(@"Verify Add Action Dialog Page is displayed")]
        [Given(@"Verify Add Action Dialog Page is displayed")]
        [When(@"Verify Add Action Dialog Page is displayed")]
        public void ThenVerifyAddActionDialogPageIsDisplayed()
        {
            tmsWait.Hard(2);
            Browser.Wd.SwitchTo();
            IWebElement AddActionDialog = EAM.MembersNew.AddNewActionDialog;
            Assert.IsTrue(AddActionDialog.Displayed);
        }


        [Then(@"The screen displays Add SNP Suspect button")]
        public void ThenTheScreenDisplaysAddSNPSuspectButton()
        {
            IWebElement SNPAddNewSuspect = EAM.MembersNew.SNPAddNewSuspectBtn;
            Assert.IsTrue(SNPAddNewSuspect.Displayed);
        }

        [Then(@"Add SNP Suspect is disabled")]
        public void ThenAddSNPSuspectIsDisabled()
        {
            IWebElement SNPAddNewSuspect = EAM.MembersNew.SNPAddNewSuspectBtn;
            Assert.IsFalse(SNPAddNewSuspect.Enabled);
        }


        [Then(@"Add SNP Suspect is clicked")]
        public void ThenAddSNPSuspectIsClicked()
        {
            IWebElement SNPAddNewSuspect = EAM.MembersNew.SNPAddNewSuspectBtn;
            SNPAddNewSuspect.Click();
        }


        [Then(@"'(.*)' is displayed")]
        public void ThenIsDisplayed(string p0)
        {
            Browser.Wd.SwitchTo();
            IWebElement SNPFollowAct = EAM.MembersNew.SNPFollowAct;
            Assert.AreEqual(SNPFollowAct.Text, p0);
        }

        [Then(@"Verify that SNP Status '(.*)' '(.*)' and '(.*)' options are displayed")]
        public void ThenVerifyThatSNPStatusAndOptionsAreDisplayed(string p0, string p1, string p2)
        {
            String[] status = { p0, p1, p2 };
            IWebElement SNPStatus = EAM.MembersNew.SNPStatus;
            SelectElement select = new SelectElement(SNPStatus);
            IList<IWebElement> options = select.Options;

                // int len = status.GetUpperBound(0);
          
            Assert.AreEqual(status.Length, options.Count);
            for( int i = 0; i< options.Count; i++)
            {
                Assert.AreEqual(status[i], options[i].Text);
            }
        }


        [Then(@"Verify that Followup methods '(.*)' '(.*)' '(.*)' and '(.*)' options are displayed")]
        public void ThenVerifyThatFollowupMethodsAndOptionsAreDisplayed(string p0, string p1, string p2, string p3)
        {
            String[] followUp = { p0, p1, p2, p3 };
            IWebElement followUpMth = EAM.MembersNew.FollowUp;
            SelectElement select = new SelectElement(followUpMth);
            IList<IWebElement> options = select.Options;

            // int len = status.GetUpperBound(0);

            Assert.AreEqual(followUp.Length, options.Count);
            for (int i = 0; i < options.Count; i++)
            {
                Assert.AreEqual(followUp[i], options[i].Text);
            }
        }

        [Then(@"SNPVerificationDate is set to ""(.*)""")]
        public void ThenSNPVerificationDateIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            String strValue = tmsCommon.GenerateData(p0);
            strValue = strValue.Replace("/", "");
    
            IWebElement VerificationDt = EAM.MembersNew.SNPVerificationDt;
            tmsWait.Hard(2);
            VerificationDt.Click();
            VerificationDt.Clear();

            VerificationDt.SendKeys(strValue);
        }


        [Then(@"AddActions DueDate is set to ""(.*)""")]
        public void ThenAddActionsDueDateIsSetTo(string p0)
        {
           tmsWait.Hard(2);
            String strValue = tmsCommon.GenerateData(p0);
            strValue = strValue.Replace("/", "");
            tmsWait.Hard(2);
            Browser.SwitchToWindow(2);
            IWebElement DueDate = EAM.MembersNew.AddActionDueDate;
            DueDate.Click();
            DueDate.Clear();
            DueDate.SendKeys(strValue);
        }


        [Then(@"AddActions text is set to ""(.*)""")]
        public void ThenAddActionsTextIsSetTo(string p0)
        {
            String strValue = tmsCommon.GenerateData(p0);
            Browser.SwitchToWindow(2);
            IWebElement DueDate = EAM.MembersNew.AddActionText;
            DueDate.Click();
            //DueDate.Clear();
            DueDate.SendKeys(strValue);
        }


        [Then(@"FollowUpDate is set to ""(.*)""")]
        public void ThenFollowUpDateIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            String strValue = tmsCommon.GenerateData(p0);
            strValue = strValue.Replace("/", "");

            IWebElement FollowUpDt = EAM.MembersNew.SNPFollowUpDate;
            tmsWait.Hard(2);

            FollowUpDt.Click();
            FollowUpDt.Clear();

            FollowUpDt.SendKeys(strValue);
        }

        [Then(@"Queue SNP Loss letter is checked")]
        public void ThenQueueSNPLossLetterIsChecked()
        {
            IWebElement letterCheck = EAM.MembersNew.SNPLetterQueue;
            if (!letterCheck.Selected)
                letterCheck.Click();
        }

        [Then(@"Verify SNP loss of letter checkbox is displayed")]
        public void ThenVerifySNPLossOfLetterCheckboxIsDisplayed()
        {
            IWebElement letterCheck = EAM.MembersNew.SNPLetterQueue;
            Assert.IsTrue(letterCheck.Displayed);
        }

        [Then(@"Verify the SNP loss of letter checkbox is enabled")]
        public void ThenVerifyTheSNPLossOfLetterCheckboxIsEnabled()
        {
            IWebElement letterCheck = EAM.MembersNew.SNPLetterQueue;
            Assert.IsTrue(letterCheck.Enabled);
        }
      
        [Given(@"The Save button is clicked")]
        [Then(@"The Save button is clicked")]
        public void ThenTheSaveButtonIsClicked()
        {
            IWebElement saveBtn = EAM.MembersNew.SNPActionSave;
            fw.ExecuteJavascript(saveBtn);
        }

        [Then(@"Action Dialog Add Action button is clicked")]
        public void ThenActionDialogAddActionButtonIsClicked()
        {
            
            IWebElement AddActionBtn = EAM.MembersNew.ActionDialog_AddAction;
            fw.ExecuteJavascript(AddActionBtn);


        }

        [Then(@"Add Action Dialog Close button is clicked")]
        public void ThenAddActionDialogCloseButtonIsClicked()
        {
            IWebElement Action_CloseBtn = EAM.MembersNew.ActionDialog_Close;
            fw.ExecuteJavascript(Action_CloseBtn);
        }


        [Then(@"Action Dialog Close button is clicked")]
        public void ThenActionDialogCloseButtonIsClicked()
        {
            Browser.SwitchToWindow(1);
            IWebElement Action_CloseBtn = EAM.MembersNew.ActionDialog_Close;
            fw.ExecuteJavascript(Action_CloseBtn);
            Browser.SwitchToWindow(0);
            
        }

        [Then(@"I switch to EAM page")]
        public void ThenISwitchToEAMPage()
        {
            Browser.SwitchToParentWindow();
        }
        


        [Given(@"Member New EGHP is ""(.*)""")]
        public void GivenMemberNewEGHPIs(string p0)
        {
            if(p0.ToLower().Trim().Equals("checked"))
            {
                EAM.MembersNew.EGHP.Click();
            }

        }

        [Then(@"Verify letter sliding pane is displayed")]
        public void ThenVerifyLetterSlidingPaneIsDisplayed()
        {
            IWebElement LettersPane = EAM.MembersNew.SNPLettersSlidingPane;
            Assert.IsTrue(LettersPane.Displayed);
        }

        [Then(@"Verify that Generate Letters link is not displayed")]
        public void ThenVerifyThatGenerateLettersLinkIsNotDisplayed()
        {
            IWebElement letterLink = null;
            try
            {
                letterLink = EAM.MembersNew.SNPGenerateLetterLink;
            }
            catch
            {
                Assert.AreEqual(letterLink, null);
                Console.Write("Generate letters link does not exist");
            }
        }

        [Then(@"Verify that Generate Letters link is displayed")]
        public void ThenVerifyThatGenerateLettersLinkIsDisplayed()
        {
            IWebElement letterLink = EAM.MembersNew.SNPGenerateLetterLink;
            Assert.IsTrue(letterLink.Displayed);
        }

        [Then(@"Click on the Generate Letters Link")]
        public void ThenClickOnTheGenerateLettersLink()
        {
            IWebElement letterLink = EAM.MembersNew.SNPGenerateLetterLink;
            letterLink.Click();
        }

               
        [Then(@"Verify Actions sliding pane is displayed")]
        public void ThenVerifyActionsSlidingPaneIsDisplayed()
        {
            IWebElement SNPActionsSlidingPane = EAM.MembersNew.SNPActionsSlidingPane;
            Assert.IsTrue(SNPActionsSlidingPane.Enabled);           
        }

        [Then(@"Click on the Actions pane")]
        public void ThenClickOnTheActionsPane()
        {
            IWebElement SNPActionsSlidingPane = EAM.MembersNew.SNPActionsSlidingPane;
            SNPActionsSlidingPane.Click();
        }

        [Then(@"Verify that complete action button is not displayed")]
        public void ThenVerifyThatCompleteActionButtonIsNotDisplayed()
        {
            IWebElement actionCompleteBtn = null;
            try
            {
                actionCompleteBtn = EAM.MembersNew.SNPCompleteActionBtn;
            }
            catch
            {
                Assert.AreEqual(null, actionCompleteBtn);
                Console.WriteLine("SNP Actions Complete btn is not displayed");
            }
        }


        [Then(@"Verify that complete action button is displayed")]
        public void ThenVerifyThatCompleteActionButtonIsDisplayed()
        {
            IWebElement actionCompleteBtn = EAM.MembersNew.SNPCompleteActionBtn;
            actionCompleteBtn.Click();
        }

        [Then(@"Click on Complete Action Button")]
        public void ThenClickOnCompleteActionButton()
        {
            
        }


        [Then(@"Click on the letter SlidingPane")]
        public void ThenClickOnTheLetterSlidingPane()
        {
            IWebElement SNPActionsSlidingPane = EAM.MembersNew.SNPActionsSlidingPane;
            SNPActionsSlidingPane.Click();
        }


        [Then(@"Verify that the Add New Suspect button is disabled")]
        public void ThenVerifyThatTheAddNewSuspectButtonIsDisabled()
        {
            IWebElement SNPAddNewSuspect = EAM.MembersNew.SNPAddNewSuspectBtn;
            Assert.IsFalse(SNPAddNewSuspect.Enabled);
        }


        [Then(@"The '(.*)' hover text is displayed")]
        public void ThenTheHoverTextIsDisplayed(string p0)
        {
            IWebElement SNPAddNewSuspect = EAM.MembersNew.SNPAddNewSuspectBtn;
            Assert.AreEqual(p0,SNPAddNewSuspect.GetAttribute("Title"));
        }

        [Then(@"Verify the screen displays close button at the top right of the page")]
        public void ThenVerifyTheScreenDisplaysCloseButtonAtTheTopRightOfThePage()
        {
            IWebElement closeBtn = EAM.MembersNew.SNPActivityDlgClose;
            Assert.IsTrue(closeBtn.Displayed);
        }
        [When(@"the close button is clicked the dialog is dismissed")]
        public void WhenTheCloseButtonIsClickedTheDialogIsDismissed()
        {
              //  Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_snpDialog_btnClose")).Click();
            
               IWebElement closeBtn = EAM.MembersNew.SNPActivityDlgClose;
               fw.ExecuteJavascript(closeBtn);
            tmsWait.Hard(3);
          
        }

        [Then(@"click on the X button")]
        public void ThenClickOnTheXButton()
        {
            Browser.Wd.FindElement(By.XPath("//span[@class='ui-icon ui-icon-closethick']")).Click();
            //IWebElement closeBtn = EAM.MembersNew.SNPActivityDlgClose;
            //closeBtn.Click();
        }

        [Then(@"verify that the dialog closes")]
        public void ThenVerifyThatTheDialogCloses()
        {
            Assert.IsTrue(EAM.MembersNew.SNPIcon.Displayed);
        }
        

        [When(@"the close button is clicked the Activity window is dismissed")]
        public void WhenTheCloseButtonIsClickedTheActivityWindowIsDismissed()
        {
            IWebElement closeBtn = EAM.MembersNew.SNPFollowUpClose;
            closeBtn.Click();
            Assert.IsTrue(EAM.MembersNew.SNPIcon.Displayed);
        }


        [Then(@"verify the tooltip is ""(.*)""")]
        public void ThenVerifyTheTooltipIs(string p0)
        {
            IWebElement SNPIconToolTip = EAM.MembersNew.SNPIconToolTip;
            Assert.AreEqual(p0, SNPIconToolTip.GetAttribute("title"));
        }

        [Then(@"verify that the Notes icon exists")]
        public void ThenVerifyThatTheNotesIconExists()
        {
            IWebElement NoteImageButton = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lnk_AddNote"));
            Assert.IsTrue(NoteImageButton.Displayed);
        }

        [When(@"the Notes button is clicked")]
        public void WhenTheNotesButtonIsClicked()
        {
            IWebElement NoteImageButton = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lnk_AddNote"));
            fw.ExecuteJavascript(NoteImageButton);
        }


        [When(@"the Actions button is clicked")]
        public void WhenTheActionsButtonIsClicked()
        {
            IWebElement NoteImageButton = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lnk_AddAction"));
            fw.ExecuteJavascript(NoteImageButton);
        }


        [Then(@"Add New Action button is clicked")]
        public void ThenAddNewActionButtonIsClicked()
        {
            tmsWait.Hard(2);
            Browser.SwitchToChildWindow();
            IWebElement ActionsImageButton = Browser.Wd.FindElement(By.XPath("//*[@id='Notes1_lnk_AddAction']"));
          //  ActionsImageButton.Click();
          fw.ExecuteJavascript(ActionsImageButton);
        }


        [Then(@"verify that the Actions icon exists")]
        public void ThenVerifyThatTheActionsIconExists()
        {
            IWebElement MemberViewEditViewAction = EAM.MembersViewEdit.MemberViewEditViewAction;
            Assert.IsTrue(MemberViewEditViewAction.Displayed);
        }

        [Then(@"verify that the Attachment icon exists")]
        public void ThenVerifyThatTheAttachmentIconExists()
        {
            IWebElement ViewAttachment = EAM.MembersViewEdit.ViewAttachment;
            Assert.IsTrue(ViewAttachment.Displayed);
        }

        [Then(@"verify that the OOA icon exists")]
        public void ThenVerifyThatTheOOAIconExists()
        {
            IWebElement OOAIcon = EAM.MemberInformation.OOAIcon;
            Assert.IsTrue(OOAIcon.Displayed);
        }

        [Then(@"verify that the Audit icon exists")]
        public void ThenVerifyThatTheAuditIconExists()
        {
            IWebElement ViewAuditHistoryButton = EAM.MembersNew.ViewAuditHistoryButton;
            Assert.IsTrue(ViewAuditHistoryButton.Displayed);
        }


        [When(@"Members New SCC is set to ""(.*)""")]
        public void WhenMembersNewSCCIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersNew.SCC.SendKeys(GeneratedData);
        }

        [Then(@"Verify Members ZIP(.*) is set to ""(.*)""")]
        public void ThenVerifyMembersZIPIsSetTo(int p0, string p1)
        {
            string GeneratedData = tmsCommon.GenerateData(p1);
            IWebElement comp = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtPZip"));
            string thisFieldValue = comp.GetAttribute("value");
            Assert.IsTrue(GeneratedData == thisFieldValue, "Field SCC value is [{0}], expected [{1}]", thisFieldValue, GeneratedData);

        }

        [When(@"Members ZIP(.*) is set to ""(.*)""")]
        public void WhenMembersZIPIsSetTo(int p0, string p1)
        {
            IWebElement comp = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtZipFour_59"));
            comp.Clear();
            comp.SendKeys(p1);
        }
        [Then(@"Members New SCC is set to ""(.*)""")]
        public void ThenMembersNewSCCIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            IWebElement comp = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtScc"));
            comp.SendKeys(p0);
        }

        [Then(@"Members New County Name is set to ""(.*)""")]
        public void ThenMembersNewCountyNameIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            IWebElement comp = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_ddlCounty"));
            new SelectElement(comp).SelectByText(GeneratedData);
        }


        [Then(@"Verify Members New SCC is set to ""(.*)""")]
        public void ThenVerifyMembersNewSCCIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNew.SCC.GetAttribute("value");
            Assert.IsTrue(GeneratedData == thisFieldValue, "Field SCC value is [{0}], expected [{1}]", thisFieldValue, GeneratedData);
            fw.ConsoleReport(String.Format("   Verification Point: Field SCC value is [{0}], expected [{1}] - They are expected to match.", thisFieldValue, GeneratedData));
        }

        [When(@"Members New County Name is set to ""(.*)""")]
        public void WhenMembersNewCountyNameIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersNew.CountyName.SendKeys(GeneratedData);
        }

        [Then(@"Verify Members New County Name is set to ""(.*)""")]
        public void ThenVerifyMembersNewCountyNameIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNew.CountyName.GetAttribute("value");
            Assert.IsTrue(GeneratedData == thisFieldValue, "Field New County Name value is [{0}], expected [{1}]", thisFieldValue, GeneratedData);
            fw.ConsoleReport(String.Format("   Verification Point: Field New County Name value is [{0}], expected [{1}] - They are expected to match.", thisFieldValue, GeneratedData));
        }


        [When(@"Members New Marital Status is set to ""(.*)""")]
        public void WhenMembersNewMaritalStatusIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.MembersNew.MaritalStatus);
            select.SelectByText(GeneratedData);
        }

        [When(@"Members New Language is set to ""(.*)""")]
        public void WhenMembersNewLanguageIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.MembersNew.Language);
            select.SelectByText(GeneratedData);
        }

        [When(@"Members Notes note page displays ""(.*)""")]
        [Then(@"Members Notes note page displays ""(.*)""")]
        public void WhenMembersNotesNotePageDisplays(string p0)
        {
            tmsWait.Hard(2);
            string GeneratedData = tmsCommon.GenerateData(p0);
            string txt = EAM.MembersNew.NoNotesMessage.Text;
            Assert.AreEqual(EAM.MembersNew.NoNotesMessage.Text.ToLower(), GeneratedData.ToLower());
        }

        [When(@"Members New Reset link is clicked")]
        public void WhenMembersNewResetLinkIsClicked()
        {
            EAM.MembersNew.Reset.Click();
            tmsWait.Hard(2);
        }

        [When(@"Members New Page is Reset")]
        public void WhenMembersNewPageIsReset()
        {
            tmsWait.Hard(2);
            Assert.IsTrue(EAM.MembersNew.HICNumber.Text.Equals(""));
            Assert.IsTrue(EAM.MembersNew.MemberID.Text.Equals(""));
            Assert.IsTrue(EAM.MembersNew.MI.Text.Equals(""));
            Assert.IsTrue(EAM.MembersNew.Appel.Text.Equals(""));
            SelectElement pi = new SelectElement(EAM.MembersNew.PlanID);
            Assert.IsTrue(pi.SelectedOption.Text.Equals("Select..."));
        }


        [When(@"Members Notes actions page displays ""(.*)""")]
        [Then(@"Members Notes actions page displays ""(.*)""")]
        public void WhenMembersNotesActionsPageDisplays(string p0)
        {
            tmsWait.Hard(2);
            string GeneratedData = tmsCommon.GenerateData(p0);
            string txt = EAM.MembersNew.NoActionsMessage.Text;
            Assert.AreEqual(EAM.MembersNew.NoActionsMessage.Text.ToLower(), GeneratedData.ToLower());
        }




        [When(@"Members Actions Close button is Clicked")]
        [Then(@"Members Actions Close button is Clicked")]
        public void WhenMembersActionsCloseButtonIsClicked()
        {
            EAM.MembersNew.CloseBtnMembersNew.Click();
        }

        [Then(@"Click on MembersAttachment icon")]
        public void ThenClickOnMembersAttachmentIcon()
        {
            EAM.MembersNew.AddAttachment.Click();
        }

        [Then(@"Verify Member Attachment dialog Save button is displayed")]
        public void ThenVerifyMemberAttachmentDialogSaveButtonIsDisplayed()
        {
            tmsWait.Hard(2);
            IWebElement save = Browser.Wd.FindElement(By.XPath("//input[@id='ctl00_ctl00_MainMasterContent_MainContent_memberDocuments_MemberDocumentsGrid_ctl00_ctl04_downloadDocument']"));
            Assert.IsTrue(save.Enabled, " Save button is not enabled");
        }

        [Then(@"Verify Members Document pop up is displayed")]
        public void ThenVerifyMembersDocumentPopUpIsDisplayed()
        {
            tmsWait.Hard(2);
            IWebElement temp = EAM.MembersNew.MemberAttchPopup;
            Assert.IsTrue(EAM.MembersNew.MemberAttchPopup.Displayed);
        }

        [Then(@"Members New Member Documents Attach button is clicked")]
        public void ThenMembersNewMemberDocumentsAttachButtonIsClicked()
        {
            EAM.MembersNew.AttachBtn.Click();
        }

        [Then(@"Members New Attach Document Browse button is clicked")]
        public void ThenMembersNewAttachDocumentBrowseButtonIsClicked()
        {
           // EAM.MembersNew.DocBrowse.Click();
        }

        [When(@"Framework page EAM Role is set to ""(.*)""")]
        public void WhenFrameworkPageEAMRoleIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            IWebElement drp = Browser.Wd.FindElement(By.CssSelector("[test-id='Adduser-Select-EAMRoles']"));
            SelectElement eamrole = new SelectElement(drp);
            eamrole.SelectByText(p0);
        }
        [When(@"Framework page Default Application is set to ""(.*)""")]
        public void WhenFrameworkPageDefaultApplicationIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            IWebElement drp = Browser.Wd.FindElement(By.CssSelector("[test-id='AddUser-Select-DefaultApplicationRequired']"));
            SelectElement eamrole = new SelectElement(drp);
            eamrole.SelectByText(p0);
        }


        [Then(@"Load Member Document, Config File ALM Project, Test ID ""(.*)"" attached file ""(.*)"" is selected with New File Name ""(.*)""")]
        public void ThenLoadMemberDocumentConfigFileALMProjectTestIDAttachedFileIsSelectedWithNewFileName(int p0, string p1, string p2)
        {
            string po_gen = tmsCommon.GenerateData(p0.ToString());
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);
            Boolean keepTrying = true;
            int maxAttempts = 11;
            int thisAttempt = 0;
            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            Boolean didUpload = false;
            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");
            if (File.Exists(controllerFileLocation + p1_gen))
            {
                File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen, true);
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");

            }
            else
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
            if (didUpload)
            {
                while (keepTrying)
                {
                    string FileName = "C:\\Temp\\" + p1_gen;

                    //For debugging
                    string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen);
                    File.Move(@FileName, @newFileName);
                    FileName = newFileName;
                    EAM.MembersNew.DocBrowse.SendKeys(FileName);
                    EAM.MembersNew.DocUpload.Click();

                    tmsWait.Hard(1);
                    string thisResponse = EAM.MembersNew.SuccessfulUploadMsg.Text;
                    if (thisResponse != "Upload failed. File already exists.")
                    {
                        keepTrying = false;
                        Console.WriteLine("File load failed with message [" + thisResponse + "]");
                    }
                    if (thisAttempt > maxAttempts)
                    {
                        keepTrying = false;
                    }
                    thisAttempt++;
                }

            }
        }

        [Then(@"choose File to Upload is displayed")]
        public void ThenChooseFileToUploadIsDisplayed()
        {
            EAM.MembersNew.DocUpload.Click();
            tmsWait.Hard(2);
        }

        [Then(@"verify ""(.*)"" is displayed on the membersPop")]
        public void ThenVerifyIsDisplayedOnTheMembersPop(string p0)
        {
            Assert.AreEqual(EAM.MembersNew.SuccessfulUploadMsg.Text, p0);
        }

        [Then(@"Member Documents close button is clicked")]
        public void ThenMemberDocumentsCloseButtonIsClicked()
        {
            fw.ExecuteJavascript(EAM.MembersNew.MemberDocClose);
        }

        [Then(@"Upload Docs close button is clicked")]
        public void ThenUploadDocsCloseButtonIsClicked()
        {
            fw.ExecuteJavascript(EAM.MembersNew.UploadFileClose);
        }

        [Then(@"Verify Member View Edit Page Member Documents has Document Name ""(.*)""")]
        public void ThenVerifyMemberViewEditPageMemberDocumentsHasDocumentName(string p0)
        {
            tmsWait.Hard(2);
            string XpathEle;
            string fileName = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                XpathEle = "//kendo-grid[@test-id='memberDocuments-grid-documents']//tr[contains(.,'" + fileName + "')]";
            }
            else
            {
                XpathEle = "//div[@test-id='memberDocuments-grid-documents']//tr[contains(.,'" + fileName + "')]";
            }

            bool elementDisplay = Browser.Wd.FindElement(By.XPath(XpathEle)).Displayed;
            Assert.IsTrue(elementDisplay, " File Name is not getting displayed");
        }


        [Then(@"Verify that the Member Documents Table has row")]
        public void ThenVerifyThatTheMemberDocumentsTableHasRow(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.MembersNew.MemberDocTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same
                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }

                baseTable = EAM.MembersNew.MemberDocTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        
        }


        [When(@"Members New Race is set to ""(.*)""")]
        public void WhenMembersNewRaceIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.MembersNew.Race);
            select.SelectByText(GeneratedData);
        }

        [When(@"Members Action Icon is clicked")]
        [Then(@"Members Action Icon is clicked")]
        public void WhenMembersActionIconIsClicked()
        {
            EAM.MembersNew.NewMemberActionLink.Click();
            Browser.SwitchToWindowUsingTitle("Notes Screen");
            tmsWait.Hard(2);
        }

        [When(@"Members New DOD is set to ""(.*)""")]
        public void WhenMembersNewDODIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            GeneratedData = GeneratedData.Replace("/", "");
            EAM.MembersNew.DOD.Clear();
            EAM.MembersNew.DOD.SendKeys(GeneratedData);
        }
        [When(@"Members New Sal is set to ""(.*)""")]
        public void WhenMembersNewSalIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersNew.Sal.SendKeys(GeneratedData);
        }

        [When(@"Members New Medicaid Number is set to ""(.*)""")]
        public void WhenMembersNewMedicaidNumberIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersNew.MedicaidNumber.SendKeys(GeneratedData);
        }

        [When(@"Members New RX BIN is set to ""(.*)""")]
        public void WhenMembersNewRXBINIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersNew.RXBIN.SendKeys(GeneratedData);
        }

        [Then(@"Verify Members New RX BIN is set to ""(.*)""")]
        public void ThenVerifyMembersNewRXBINIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNew.RXBIN.GetAttribute("value");
            Assert.IsTrue(GeneratedData == thisFieldValue, "Field RXBIN value is [{0}], expected [{1}]", thisFieldValue, GeneratedData);
        }

        [When(@"Members New RX PCN is set to ""(.*)""")]
        public void WhenMembersNewRXPCNIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersNew.RXPCN.SendKeys(GeneratedData);
        }

        [Then(@"Verify Members New RX PCN is set to ""(.*)""")]
        public void ThenVerifyMembersNewRXPCNIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNew.RXPCN.GetAttribute("value");
            Assert.IsTrue(GeneratedData == thisFieldValue, "Field RXPCN value is [{0}], expected [{1}]", thisFieldValue, GeneratedData);
        }

        [Then(@"Verify Members PW Option is set to ""(.*)""")]
        public void ThenVerifyMembersPWOptionIsSetTo(string p0)
        {
            if (p0.Contains("|"))
            {
                //string delimiter = "|";
                string[] value =p0.Split('|');
                SelectElement select = new SelectElement(Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_drpPremium")));
                string SelectedOption = select.SelectedOption.Text;
                if (SelectedOption.Contains(value[0]))
                {
                    Assert.AreEqual(SelectedOption, value[0], "Expected value of PW option is not matching with catual value");
                }
                else {
                  
                    Assert.AreEqual(SelectedOption, value[1], "Expected value of PW option is not matching with catual value");
                }
            }
            else
            {
                tmsWait.Hard(3);
                SelectElement select = new SelectElement(Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_drpPremium")));
                string SelectedOption = select.SelectedOption.Text;
                Assert.AreEqual(SelectedOption, p0.ToString(), "Expected value of PW option is not matching with catual value");
            }
        }

        [When(@"Verify Members New User entered is set to ""(.*)""")]
        [Then(@"Verify Members New User entered is set to ""(.*)""")]
        public void ThenVerifyMembersNewUserEnteredIsSetTo(string p0)
        {
            Assert.AreEqual(p0, EAM.MembersNew.UserEntered.Text);
        }



        [When(@"Members New Plan2 is set to ""(.*)""")]
        public void WhenMembersNewPlan2IsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersNew.Plan2.SendKeys(GeneratedData);
        }

        [When(@"Members New Plan3 is set to ""(.*)""")]
        public void WhenMembersNewPlan3IsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersNew.Plan3.SendKeys(GeneratedData);
        }
        [When(@"Members New Plan4 is set to ""(.*)""")]
        public void WhenMembersNewPlan4IsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersNew.Plan4.SendKeys(GeneratedData);
        }

        [When(@"Members New page Save button is Clicked")]
        public void WhenMembersNewPageSaveButtonIsClicked()
        {
            IWebElement save = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSave"));
            fw.ExecuteJavascript(save);
            tmsWait.Hard(5);
        }
        [Then(@"Verify View Edit Member page EGHP Checkbox is ""(.*)""")]
        public void ThenVerifyViewEditMemberPageEGHPCheckboxIs(string status)
        {
            tmsWait.Hard(3);
            if (status.ToLower() == "checked")
            {
                Assert.IsTrue(Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_chkEGHP")).Selected);

            }
            else
            {
                Assert.IsFalse(Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_chkEGHP")).Selected);
            }

        }


        [When(@"View Edit Member page EGHP Checkbox is ""(.*)""")]
        public void WhenViewEditMemberPageEGHPCheckboxIs(string status)
        {
            tmsWait.Hard(4);
            IWebElement check = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_chkEGHP"));

            if (status.ToLower() == "checked")
            {
                if (!check.Selected)
                {
                    fw.ExecuteJavascript(check);

                }
            }
            else
            {
                if (check.Selected)
                {
                    fw.ExecuteJavascript(check);
                }
            }
        }

        [Then(@"Verify Members new page ""(.*)"" Error Message")]
        public void ThenVerifyMembersNewPageErrorMessage(string p0)
        {
            tmsWait.Hard(4);
            IWebElement save = Browser.Wd.FindElement(By.XPath("//div[@id='ctl00_ctl00_MainMasterContent_MainContent_ValidationSummary1']//li[contains(.,'" + p0+"')]"));
            Assert.IsTrue(save.Displayed);

        }


        [When(@"Members New Plan5 is set to ""(.*)""")]
        public void WhenMembersNewPlan5IsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersNew.Plan5.SendKeys(GeneratedData);
        }
        //NL 03/31/2015
        //Verify Plan1 - Plan5 fields' names
        [Then(@"Verify Members New Plan Fields Labels")]
        public void ThenVerifyMembersNewPlanFieldsLabels(Table table)
        {
            try
            {
                ICollection<string> thisDataHeader = table.Header;
                if (!thisDataHeader.Contains("Label") || !thisDataHeader.Contains("Name")) { Assert.Fail("Verify Members New Plan Fields Labels: data table has wrong columns names"); }

                string fieldName = "";

                foreach (var row in table.Rows)
                {
                    string dataValue = tmsCommon.GenerateDataForTable(row["Name"]);
                    string rowLabel = row["Label"];
                    string rowName = dataValue;
                    if (rowName.ToLower() != "skip")
                    {
                        switch (rowLabel.ToLower())
                        {
                            case "plan1": { fieldName = EAM.MembersNew.Plan1Label.Text; break; }
                            case "plan2": { fieldName = EAM.MembersNew.Plan2Label.Text; break; }
                            case "plan3": { fieldName = EAM.MembersNew.Plan3Label.Text; break; }
                            case "plan4": { fieldName = EAM.MembersNew.Plan4Label.Text; break; }
                            case "plan5": { fieldName = EAM.MembersNew.Plan5Label.Text; break; }
                            default: Console.WriteLine("Filed name {0} was not found!", rowLabel); break;
                        }
                        Console.WriteLine("Verify Members New Plan Fields Labels: Expected [{0}], Actual [{1}]", rowName, fieldName);
                        Assert.AreEqual(fieldName, rowName, "Verify Members New Plan Fields Labels: Expected [{0}], Actual [{1}]", rowName, fieldName);
                    }
                }
            }
            catch (Exception ex)
            {
                Assert.Fail("Administration Plan Defined Fields Members Fields set values. Exception: (0)", ex.Message);
            }
        }

        [When(@"Members New Tab Eligibility Medicare Part B is set to ""(.*)""")]
        public void WhenMembersNewTabEligibilityMedicarePartBIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            string GeneratedData = tmsCommon.GenerateData(p0);
            GeneratedData = GeneratedData.Replace("/", "");
            EAM.MembersNewTabEligibility.PlanPartBEff.Clear();
            fw.ExecuteJavascript(EAM.MembersNewTabEligibility.PlanPartBEff);
            tmsWait.Hard(1);
            EAM.MembersNewTabEligibility.PlanPartBEff.SendKeys(Keys.Home);
            tmsWait.Hard(1);
            EAM.MembersNewTabEligibility.PlanPartBEff.SendKeys(GeneratedData);
         }

        [When(@"Members New Tab Eligibility Medicare Part A is set to ""(.*)""")]
        public void WhenMembersNewTabEligibilityMedicarePartAIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            string GeneratedData = tmsCommon.GenerateData(p0);
            GeneratedData = GeneratedData.Replace("/", "");
            EAM.MembersNewTabEligibility.PlanPartAEff.Clear();
            fw.ExecuteJavascript(EAM.MembersNewTabEligibility.PlanPartAEff);
            tmsWait.Hard(1);
            EAM.MembersNewTabEligibility.PlanPartAEff.SendKeys(Keys.Home);
            tmsWait.Hard(3);
            EAM.MembersNewTabEligibility.PlanPartAEff.SendKeys(GeneratedData);
            tmsWait.Hard(3);
        }

        [Then(@"Members New page Save button is Clicked successfully")]
        public void ThenMembersNewPageSaveButtonIsClickedSuccessfully()
        {
            tmsWait.Hard(3);
            fw.ExecuteJavascript(EAM.MembersNew.Save);
        }


        [When(@"Members New Tab Eligibility Eligibility Link is Clicked")]
        public void WhenMembersNewTabEligibilityEligibilityLinkIsClicked()
        {
            EAM.MembersNewTabEligibility.EligibilityTabLink.Click();
            tmsWait.WaitForReadyStateComplete(30);
        }

        [When(@"Members New Tab Transactions Transactions Link is Clicked")]
        public void WhenMembersNewTabTransactionsTransactionsLinkIsClicked()
        {
            tmsWait.Hard(2);
          
            fw.ExecuteJavascript(EAM.MembersNewTabTransactions.TransactionsTab);
            tmsWait.Hard(2);
        }

        
        [When(@"Members Correspondence Tab displays")]
        public void WhenMembersCorrespondenceTabDisplays()
        {
            Assert.IsTrue(EAM.MembersNewTabCorrespondence.CorrespondenceTabLink.Displayed);
        }

        [When(@"Members New Tab Correspondence Correspondence Link is Clicked")]
        public void WhenMembersNewTabCorrespondenceCorrespondenceLinkIsClicked()
        {
            fw.ExecuteJavascript(EAM.MembersNewTabCorrespondence.CorrespondenceTabLink);
            tmsWait.WaitForReadyStateComplete(30);
        }

        [When(@"Members Correspondence Tab Letter Name displays ""(.*)""")]
        public void WhenMembersCorrespondenceTabLetterNameDisplays(string p0)
        {
            SelectElement letterNames = new SelectElement(EAM.MembersNewTabCorrespondence.CorrespondenceLetterName);
            IWebElement selectedLetter = letterNames.SelectedOption;
            Assert.AreEqual(selectedLetter.Text, p0);
        }

        [When(@"Members New Tab Correspondence Letter name is set to ""(.*)""")]
        public void WhenMembersNewTabCorrespondenceLetterNameIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement lettername = new SelectElement(EAM.MembersNewTabCorrespondence.CorrespondenceLetterName);
            lettername.SelectByText(GeneratedData);
                
        }

        [When(@"Members New Tab Correspondence AddTransaction button is clicked")]
        public void WhenMembersNewTabCorrespondenceAddTransactionButtonIsClicked()
        {
            tmsWait.Hard(4);
            fw.ExecuteJavascript(EAM.MembersNewTabCorrespondence.AddTransactionBtn);
            tmsWait.Hard(3);
        }

        [When(@"Members New Tab Correspondence first transaction is selected")]
        public void WhenMembersNewTabCorrespondenceFirstTransactionIsSelected()
        {
            tmsWait.Hard(4);
            fw.ExecuteJavascript(EAM.MembersNewTabCorrespondence.SelectFirstTrans);
        }


        [When(@"Members New Tab Correspondence Add Queue button is clicked")]
        public void WhenMembersNewTabCorrespondenceAddQueueButtonIsClicked()
        {
            fw.ExecuteJavascript(EAM.MembersNewTabCorrespondence.AddQeueuBtn);
            tmsWait.Hard(3);
        }

        [Then(@"Verify Letter queue message contains ""(.*)""")]
        public void ThenVerifyLetterQueueMessageContains(string Msg)
        {
            tmsWait.Hard(2);
            string actualmsg = EAM.MembersNewTabCorrespondence.LetterQueuedMsg.Text;
            Assert.IsTrue(actualmsg.Contains(Msg));
           
        }


        [When(@"Members Correspondence Correspondence History - System Generated and On Demand Letters fields are blank")]
        public void WhenMembersCorrespondenceCorrespondenceHistory_SystemGeneratedAndOnDemandLettersFieldsAreBlank()
        {
            IWebElement historyTable = EAM.MembersNewTabCorrespondence.CorrespondenceHistory;
            IList<IWebElement> letterHistory = historyTable.FindElements(By.TagName("tr"));
            Assert.AreEqual(letterHistory.Count, 2);
        }

        [When(@"Members New Tab ID History ID History Link is Clicked")]
        public void WhenMembersNewTabIDHistoryIDHistoryLinkIsClicked()
        {
            EAM.MembersNewTabIDHistory.IDHistoryTabLink.Click();
            tmsWait.WaitForReadyStateComplete(30);
        }

        [When(@"RX Billing tab save button is Clicked")]
        public void WhenRXBillingTabSaveButtonIsClicked()
        {
            IWebElement element = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_btnSave"));
            fw.ExecuteJavascript(element);
        }

        [When(@"View Edit Member page Member field is set to ""(.*)""")]
        [Given(@"View Edit Member page Member field is set to ""(.*)""")]
        [Then(@"View Edit Member page Member field is set to ""(.*)""")]
        public void WhenViewEditMemberPageMemberFieldIsSetTo(string value)
        {
            string p0 = tmsCommon.GenerateData(value);
            IWebElement element = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtMemberID_43"));
            element.SendKeys(p0);
        }


        [When(@"RX Billing tab LIS Type is set to ""(.*)""")]
        public void WhenRXBillingTabLISTypeIsSetTo(string p0)
        {
            tmsWait.Hard(4);
            IWebElement element = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_cboLISType"));
            SelectElement ele = new SelectElement(element);
            ele.SelectByText(p0);
        }

        [When(@"RX Billing tab LIS Level is set to ""(.*)""")]
        public void WhenRXBillingTabLISLevelIsSetTo(string p0)
        {
            tmsWait.Hard(4);
            IWebElement element = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_cboSubSidyLevel"));
            SelectElement ele = new SelectElement(element);
            ele.SelectByText(p0);
        }
        [When(@"RX Billing tab Start Date is set to ""(.*)""")]
        public void WhenRXBillingTabStartDateIsSetTo(string p0)
        {
            IWebElement element = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_txtCoPayEffDate"));
            fw.ExecuteJavascriptSetText(element, p0);
            
        }

        [When(@"Members New Page RxBilling Tab is Clicked")]
        public void WhenMembersNewPageRxBillingTabIsClicked()
        {
            IWebElement element = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnBilling"));
            fw.ExecuteJavascript(element);
        }

        [When(@"RX Billing tab End Date is set to ""(.*)""")]
        public void WhenRXBillingTabEndDateIsSetTo(string p0)
        {
            IWebElement element = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_txtCoPayEndDate"));
            fw.ExecuteJavascriptSetText(element, p0);
        }


        [When(@"RX Billing tab Co-Pay cat is set to ""(.*)""")]
        public void WhenRXBillingTabCo_PayCatIsSetTo(string p0)
        {

        tmsWait.Hard(4);
            IWebElement element = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_cboCoPayCat"));
            SelectElement ele = new SelectElement(element);
            ele.SelectByText(p0);
        }

        [When(@"Edit LIS Information Page Plan ID is set to ""(.*)""")]
        public void WhenEditLISInformationPagePlanIDIsSetTo(string p0)
        {
            IWebElement element = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPlan"));
            SelectElement ele = new SelectElement(element);
            ele.SelectByText(p0);
        }
        [When(@"Edit LIS Information page Search button is Clicked")]
        public void WhenEditLISInformationPageSearchButtonIsClicked()
        {

            IWebElement element = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cmdSearch"));
            fw.ExecuteJavascript(element);
        }


        [When(@"Administration section Edit LIS Information link is Clicked")]
        public void WhenAdministrationSectionEditLISInformationLinkIsClicked()
        {
            IWebElement element = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_EamNavigation_pnlUserAdmin_ctl05_link"));
            fw.ExecuteJavascript(element);
        }

        [When(@"Edit LIS Information page MBI is set to ""(.*)""")]
        public void WhenEditLISInformationPageMBIIsSetTo(string p0)
        {
            string mbi = tmsCommon.GenerateData(p0);
            IWebElement element = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtHic"));
            element.SendKeys(mbi);
        }

        [Then(@"Verify Members New Tab RXBilling Table has Level as ""(.*)"" End Date as ""(.*)"" Source as ""(.*)""")]
        public void ThenVerifyMembersNewTabRXBillingTableHasLevelAsEndDateAsSourceAs(string Level, string EndDate, string source)
        {
            tmsWait.Hard(3);
            IWebElement element = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_RsGrid']//tr/td[contains(.,'"+Level+"')]/following-sibling::td[contains(.,'"+EndDate+"')]/following-sibling::td[contains(.,'"+source+"')]"));
            Assert.IsTrue(element.Displayed, "Expected Value is  not getting displayed");
        }

        [When(@"Edit LIS Information page display below table details Level as ""(.*)"" EndDate as ""(.*)"" Source as ""(.*)""")]
        public void WhenEditLISInformationPageDisplayBelowTableDetailsLevelAsEndDateAsSourceAs(string p0, string p1, string p2)
        {
            tmsWait.Hard(3);
            IWebElement element = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_GV_EditLIS']//tr/td[contains(.,'"+p0+"')]/following-sibling::td[contains(.,'"+p1+"')]/following-sibling::td[contains(.,'"+p2+"')]"));
            Assert.IsTrue(element.Displayed, "Expected Value is  not getting displayed");
        }


        [When(@"Members New Tab RXBilling Link is Clicked")]
        public void WhenMembersNewTabRXBillingLinkIsClicked()
        {
            EAM.MembersNewTabRXBilling.RXBillingTabLink.Click();
            tmsWait.Hard(2);
            tmsWait.WaitForReadyStateComplete(30);
        }
        [When(@"Members New Tab RXBilling RXBilling Link is Clicked")]
        public void WhenMembersNewTabRXBillingRXBillingLinkIsClicked()
        {
            EAM.MembersNewTabRXBilling.RXBillingTabLink.Click();
            tmsWait.Hard(2);
            tmsWait.WaitForReadyStateComplete(30);
        }


        [When(@"Members New Tab RXBilling Save Icon is clicked")]
        public void WhenMembersNewTabRXBillingSaveIconIsClicked()
        {
            //tmsWait.Hard(3);
            EAM.MembersNewTabRXBilling.SaveButton.Click();
            tmsWait.Hard(3);
        }


        [Then(@"Verify Members New Tab RXBilling Copay Amount ""(.*)"" is displayed")]
        public void ThenVerifyMembersNewTabRXBillingCopayAmountIsDisplayed(string p0)
        {
           
        }


        [Then(@"Verify Members New Tab Rx/Billing Credit Cover: is set to ""(.*)""")]
        [Then(@"Verify Members New Tab RXBilling Credit Cover is set to ""(.*)""")]
        public void ThenVerifyMembersNewTabRxBillingCreditCoverIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = "";

            IList<IWebElement> theseOptions = EAM.MembersNewTabRXBilling.CreditCover.FindElements(By.TagName("option"));
            foreach (IWebElement thisOption in theseOptions)
            {
                string selectedAttribute = thisOption.GetAttribute("selected");
                if (selectedAttribute == "true")
                {
                    thisFieldValue = thisOption.Text;
                    break;
                }
            }
            Assert.IsTrue(GeneratedData == thisFieldValue, "Field Credit Cover value is [{0}], expected [{1}]", thisFieldValue, GeneratedData);
        }

        [Then(@"Verify Members New Tab RXBilling Uncovered Months is set to ""(.*)""")]
        public void ThenVerifyMembersNewTabRXBillingUncoveredMonthsIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNewTabRXBilling.UncoveredMonths.GetAttribute("value");
            Assert.IsTrue(GeneratedData == thisFieldValue, "Field Uncovered Months value is [{0}], expected [{1}]", thisFieldValue, GeneratedData);
        }

        [Then(@"Verify Members New Tab RXBilling PW Option is set to ""(.*)""")]
        public void ThenVerifyMembersNewTabRXBillingPWOptionIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = "";

            IList<IWebElement> theseOptions = EAM.MembersNewTabRXBilling.PWOption.FindElements(By.TagName("option"));
            foreach (IWebElement thisOption in theseOptions)
            {
                string selectedAttribute = thisOption.GetAttribute("selected");
                if (selectedAttribute == "true")
                {
                    thisFieldValue = thisOption.Text;
                    break;
                }
            }
            Assert.IsTrue(GeneratedData == thisFieldValue, "Field PW Option value is [{0}], expected [{1}]", thisFieldValue, GeneratedData);
        }

        [Then(@"Verify Members New Tab RXBilling LEP Am't is set to ""(.*)""")]
        public void ThenVerifyMembersNewTabRXBillingLEPAmTIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNewTabRXBilling.LEPAmt.GetAttribute("value");
            Assert.IsTrue(GeneratedData == thisFieldValue, "Field LEP Am't value is [{0}], expected [{1}]", thisFieldValue, GeneratedData);
        }

        [When(@"Members New Tab RxBilling LEPAmt is set to ""(.*)""")]
        public void WhenMembersNewTabRxBillingLEPAmtIsSetTo(Decimal p0)
        {
            EAM.MembersNewTabRXBilling.LEPAmt.Clear();
            EAM.MembersNewTabRXBilling.LEPAmt.SendKeys(p0.ToString());
        
        }

        [When(@"Members New Tab RxBilling UncoveredMonth is set to ""(.*)""")]
        public void WhenMembersNewTabRxBillingUncoveredMonthIsSetTo(int p0)
        {
            EAM.MembersNewTabRXBilling.UncoveredMonths.Clear();
            EAM.MembersNewTabRXBilling.UncoveredMonths.SendKeys(p0.ToString());
        }

        [When(@"Members New Tab RxBilling WaivedLEPAmt is set to ""(.*)""")]
        public void WhenMembersNewTabRxBillingWaivedLEPAmtIsSetTo(int p0)
        {
            EAM.MembersNewTabRXBilling.LEPWaivedAmt.Clear();
            EAM.MembersNewTabRXBilling.LEPWaivedAmt.SendKeys(p0.ToString());
        }



        [When(@"Members New Tab RxBilling LEPSubsAmt is set to ""(.*)""")]
        public void WhenMembersNewTabRxBillingLEPSubsAmtIsSetTo(int p0)
        {
            EAM.MembersNewTabRXBilling.LEPSubsAmt.Clear();
            EAM.MembersNewTabRXBilling.LEPSubsAmt.SendKeys(p0.ToString());
        }



        [Then(@"Members New Tab RXBilling table is empty")]
        public void ThenMembersNewTabRXBillingTableIsEmpty()
        {
            try
            {
                IWebElement baseTable = EAM.MembersNewTabRXBilling.LISTable;
                Assert.AreEqual(true, true, "RX Billing table is present, was not supposed to be");
            }
            catch (NoSuchElementException)
            {
                Console.WriteLine("RX Billing table is not present, was not supposed to be");
            }

        }

        [Then(@"Verify Members New Tab RXBilling Table has (.*) rows")]
        public void VerifyThenMembersNewTabRXBillingTableHasRows(int p0)
        {
            IWebElement baseTable;
            try
            {
                baseTable = EAM.MembersNewTabRXBilling.LISTable;
            }
            catch (NoSuchElementException)
            {
                Assert.IsTrue(p0 == 0, "LIS table does not exist, but expected rows count = [{0}]", p0);
                return;
            }

            IList<IWebElement> objUITableRowsList = baseTable.FindElements(By.TagName("tr"));
            int intRowsCount = objUITableRowsList.Count;

            Assert.IsTrue(intRowsCount - 1 == p0, "LIS table has [{0}] rows, but expected rows count = [{1}]", intRowsCount - 1, p0);

        }
        [Then(@"Verify Members New Tab RXBilling Table does not have row")]
        public void ThenVerifyMembersNewTabRXBillingTableDoesNotHaveRow(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.MembersNewTabRXBilling.LISTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                //            thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "th", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                    Assert.AreEqual(true, false, "Row is not supposed to match, test step failed");
                }
                //else
                //{
                //    //Click next page link and start over.
                //    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                //    {
                //        thisTP.bNotAtLastPageOfRecords = true;
                //        thisTP.NPL.Click();
                //        tmsWait.Hard(2);
                //    }
                //}
                baseTable = EAM.MembersNewTabRXBilling.LISTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportPassOnNotMatching(thisGT.GTable);
                }
            }
        }


        [When(@"Edit LIS Information page display below table details")]
        public void WhenEditLISInformationPageDisplayBelowTableDetails(Table table)
        {
            tmsWait.Hard(5);
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.MembersNewTabRXBilling.EditLISTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                //            thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "th", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                //else
                //{
                //    //Click next page link and start over.
                //    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                //    {
                //        thisTP.bNotAtLastPageOfRecords = true;
                //        thisTP.NPL.Click();
                //        tmsWait.Hard(2);
                //    }
                //}
                baseTable = EAM.MembersNewTabRXBilling.EditLISTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }

        }


        [Then(@"Verify Members New Tab RXBilling Table has row")]
        public void ThenVerifyMembersNewTabRXBillingTableHasRow(Table table)
        {
            tmsWait.Hard(5);
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.MembersNewTabRXBilling.LISTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                //            thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                //else
                //{
                //    //Click next page link and start over.
                //    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                //    {
                //        thisTP.bNotAtLastPageOfRecords = true;
                //        thisTP.NPL.Click();
                //        tmsWait.Hard(2);
                //    }
                //}
                baseTable = EAM.MembersNewTabRXBilling.LISTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

        [Then(@"Verify Members New Tab RXBilling response message ""(.*)""")]
        public void ThenVerifyMembersNewTabRXBillingResponseMessage(string p0)
        {
            
        }


        [Then(@"Verify Members New Tab RXBilling Response Message ""(.*)"" is displayed")]
        public void ThenVerifyMembersNewTabRXBillingResponseMessageIsDisplayed(string p0)
        {
            tmsWait.Hard(10);
            string value = tmsCommon.GenerateData(p0);
            Boolean matchedMessage = false;

            IWebElement responseMessagesParent = EAM.MembersNewTabRXBilling.Response;
// IList1<IWebElement> allMessages = responseMessagesParent.FindElements(By.TagName("span"));
            IList<IWebElement> allMessages = Browser.Wd.FindElements(By.XPath("//div[@id='ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_UpdatePanel1']/span[1]"));
            string bareParentText = responseMessagesParent.Text.Replace("\r", "");
            bareParentText = bareParentText.Replace("\n", " ");

            //          if (responseMessagesParent.Text == value)
            if (responseMessagesParent.Text.IndexOf(value, 0) != -1)
            {
                matchedMessage = true;
            }
            foreach (IWebElement thisMessage in allMessages)
            {
                if (thisMessage.Text == value)
                {
                    matchedMessage = true;
                    break;
                }
            }
            Console.WriteLine("Verifying message [" + value + "] is in the RXBilling Response list. ");
            Assert.AreEqual(true, matchedMessage, "Verifying message [" + value + "] is in the RXBilling Response list. ");
        }

        //Author : Gurdeep Arora

        [Then(@"Verify Members New Tab RXBilling Response Message is displayed ""(.*)"" OR  ""(.*)""")]
        public void ThenVerifyMembersNewTabRXBillingResponseMessageIsDisplayedOR(string p0, string p1)
        {
            tmsWait.Hard(10);
            string value1 = tmsCommon.GenerateData(p0);
            string value2 = tmsCommon.GenerateData(p1);
            Boolean matchedMessage = false;

            IWebElement responseMessagesParent = EAM.MembersNewTabRXBilling.Response;
            string bareParentText = responseMessagesParent.Text.Replace("\r", "");
            bareParentText = bareParentText.Replace("\n", " ");

            if (responseMessagesParent.Text.IndexOf(value1, 0) != -1 || responseMessagesParent.Text.IndexOf(value2, 0) != -1)
                {
                    matchedMessage = true;
                }
            Assert.AreEqual(true, matchedMessage, "Verifying message [" + responseMessagesParent.Text + "] is in the RXBilling Response list. ");
        }
                
        [When(@"Members New Tab RXBilling Start Date is set to ""(.*)""")]
        public void WhenMembersNewTabRXBillingStartDateIsSetTo(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascriptSetText(EAM.MembersNewTabRXBilling.StartDate,strValue);
            //string GeneratedData = tmsCommon.GenerateData(p0);
            //GeneratedData = GeneratedData.Replace("/", "");
            //EAM.MembersNewTabRXBilling.StartDate.Clear();
            //EAM.MembersNewTabRXBilling.StartDate.Click();
            //EAM.MembersNewTabRXBilling.StartDate.SendKeys(Keys.Home);
            //EAM.MembersNewTabRXBilling.StartDate.SendKeys(GeneratedData);

            //tmsWait.Hard(1);
        }
        [When(@"Members New Tab RXBilling End Date is set to ""(.*)""")]
      
        public void WhenMembersNewTabRXBillingEndDateIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            
            fw.ExecuteJavascriptSetText(EAM.MembersNewTabRXBilling.EndDate, GeneratedData);
            //GeneratedData = GeneratedData.Replace("/", "");
            //EAM.MembersNewTabRXBilling.EndDate.Clear();
            //EAM.MembersNewTabRXBilling.EndDate.Click();
            //EAM.MembersNewTabRXBilling.EndDate.SendKeys(Keys.Home);
            //EAM.MembersNewTabRXBilling.EndDate.SendKeys(GeneratedData);

            tmsWait.Hard(1);
        }
        [When(@"Members New Tab RXBilling LIS Level is set to ""(.*)""")]
        public void WhenMembersNewTabRXBillingLISLevelIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.MembersNewTabRXBilling.LISLevel);
            select.SelectByText(value);
        }

        [When(@"Members New Tab RXBilling Co-Pay Cat is set to ""(.*)""")]
         public void WhenMembersNewTabRXBillingCo_PayCatIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.MembersNewTabRXBilling.CoPayCat);
            select.SelectByText(value);
        }

        [When(@"Members New Tab RXBilling LIS Type is set to ""(.*)""")]
        public void WhenMembersNewTabRXBillingLISTypeIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.MembersNewTabRXBilling.LISType);
            select.SelectByText(value);
        }

        [When(@"Members New Tab OECSales OECSales Link is Clicked")]

        public void WhenMembersNewTabOECSalesOECSalesLinkIsClicked()
        {
            EAM.MembersNewTabOECSales.OECSalesTabLink.Click();
        }

        [Then(@"Verify Members OECSalesTab message displays ""(.*)""")]
        public void ThenVerifyMembersOECSalesTabMessageDisplays(string p0)
        {
            Assert.AreEqual(p0, EAM.MembersNewTabOECSales.OECNewMessage.Text);
        }

        [Then(@"Verify Members OECSales Tab ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyMembersOECSalesTabIsSetTo(string p0, string p1)
        {
            IWebElement OECSalesTab = EAM.MembersNewTabOECSales.OECSaleTable;

            IList <IWebElement> allRows = Browser.Wd.FindElements(By.TagName("tr"));

            foreach(IWebElement row in allRows )
            {
                if(row.Text.Contains(p0))
                {
                    IList<IWebElement> allColumns = Browser.Wd.FindElements(By.TagName("td"));
                    allColumns[0].Text.Contains(p0);
                    allColumns[1].Text.Contains(p1);
                    break;
                }
            }
        }

        [Then(@"Verify NewProvider ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyNewProviderIsSetTo(string p0, string p1)
        {
            IWebElement ProviderTab = EAM.MembersNewTabProvider.ProviderTabTable;

            IList<IWebElement> allRows = Browser.Wd.FindElements(By.TagName("tr"));

            foreach (IWebElement row in allRows)
            {
                if (row.Text.Contains(p0))
                {
                    IList<IWebElement> allColumns = Browser.Wd.FindElements(By.TagName("td"));
                    allColumns[0].Text.Contains(p0);
                    allColumns[1].Text.Contains(p1);
                    break;
                }
            }
        }


        [When(@"Verify Members Payment Tab ""(.*)"" is set to ""(.*)""")]
        public void WhenVerifyMembersPaymentTabIsSetTo(string p0, string p1)
        {
            IWebElement PaymentTab = EAM.MembersNewTabPayment.PaymentDataTable;

            IList<IWebElement> allRows = Browser.Wd.FindElements(By.TagName("tr"));

            foreach (IWebElement row in allRows)
            {
                if (row.Text.Contains(p0))
                {
                    IList<IWebElement> allColumns = Browser.Wd.FindElements(By.TagName("td"));
                    allColumns[0].Text.Contains(p0);
                    allColumns[1].Text.Contains(p1);
                    break;
                }
            }
        }
        [When(@"Members New Tab Member ID is set to ""(.*)""")]
        public void WhenMembersNewTabMemberIDIsSetTo(string p0)
        {
            IWebElement memberid = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtMemberID_43"));
            memberid.SendKeys(p0);
        }

        [Then(@"Verify that Sales Rep is displayed to per selection from New Transaction page")]
        public void ThenVerifyThatSalesRepIsDisplayedToPerSelectionFromNewTransactionPage()
        {
                IWebElement SaleReps = Browser.Wd.FindElement(By.XPath("//table[@id='Table1']//td//div//input[@id='ctl00_ctl00_MainMasterContent_MainContent_ucOECSales_RadComboBox1_Input']"));
                string salesRepValue=SaleReps.GetAttribute("value");
                Assert.AreEqual(salesRepValue, GlobalRef.SalesRep.ToString(), "Sales Rep value are not matching per expectation");
        }

        [Then(@"View Edit Member page Member ID is set to ""(.*)""")]
        public void ThenViewEditMemberPageMemberIDIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            IWebElement memID = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtMemberID_43"));

            ReUsableFunctions.enterValueOnWebElement(memID, value);
            
        }

        [Then(@"View Edit Member page Save button is Clicked Succcessfully")]
        public void ThenViewEditMemberPageSaveButtonIsClickedSucccessfully()
        {
            IWebElement save = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSave"));

            ReUsableFunctions.clickOnWebElement(save);
            tmsWait.Hard(5);
        }

        [Then(@"Verify View Edit Member page RX ID field value is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageRXIDFieldValueIsSetTo(string expected)
        {
            IWebElement actual = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtRxID_39"));
            tmsWait.Hard(4);
            ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expected, actual);
        }


        [Then(@"Verify View Edit Member page displayed message as ""(.*)""")]
        public void ThenVerifyViewEditMemberPageDisplayedMessageAs(string expected)
        {
            IWebElement actual = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblMsg"));
            tmsWait.Hard(4);
            ReUsableFunctions.compareExpectedStringActualWebElementStringValue(expected, actual);
        }

        [Then(@"Verify View Edit Transaction page displayed message as ""(.*)""")]
        public void ThenVerifyViewEditTransactionPageDisplayedMessageAs(string expected)
        {

            IWebElement actual = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblMsg"));
            tmsWait.Hard(4);
            ReUsableFunctions.compareExpectedStringActualWebElementStringValue(expected, actual);
        }

        [Then(@"Verify Member View Edit page ""(.*)"" Name is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditPageNameIsSetTo(string field, string value)
        {
            string expectedvalue = tmsCommon.GenerateData(value);
            string actualValue;
            switch (field)
            {
                case "City":                
                 actualValue = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtPCity")).GetAttribute("value");
                Assert.AreEqual(expectedvalue, actualValue, "Both values are not matching");
                    break;
            }

        }


        [Then(@"Verify Member OEC Sales Rep tab is set to ""(.*)""")]
        public void ThenVerifyMemberOECSalesRepTabIsSetTo(string p0)
        {
            string expectedvalue = tmsCommon.GenerateData(p0);

            string actualValue = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucOECSales_RadComboBox1_Input")).GetAttribute("value");

            Assert.AreEqual(expectedvalue, actualValue, "Both values are not matching");
        }


        [Then(@"Members New Tab OECSales Sales Rep is set to ""(.*)""")]
        [When(@"Members New Tab OECSales Sales Rep is set to ""(.*)""")]
        public void ThenMembersNewTabOECSalesSalesRepIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string value = tmsCommon.GenerateData(p0);
            EAM.MembersNewTabOECSales.SalesRep.SendKeys(value);
            tmsWait.Hard(3);
            //     EAM.MembersNewTabOECSales.SalesRep.SendKeys(value+"\n");

            IList<IWebElement> theseElements = EAM.MembersNewTabOECSales.SalesDropDownList.FindElements(By.TagName("div"));
            Boolean foundElementToClick = false;
            foreach (IWebElement thisElement in theseElements)
            {
                if (thisElement.Text == value)
                {
                    thisElement.Click();
                    foundElementToClick = true;
                }
            }
            Assert.AreEqual(true, foundElementToClick, "Trying to click on item [" + value + "] in the Sales Rep OECSales field, it wasn't found in the list");
            tmsWait.Hard(2);
        }
        [Then(@"Verify Members New Tab OECSales Sales Rep field does not have ""(.*)"" value")]
        public void ThenVerifyMembersNewTabOECSalesSalesRepFieldDoesNotHaveValue(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            EAM.MembersNewTabOECSales.SalesDropDownListArrow.Click();
            tmsWait.Hard(2);
            IList<IWebElement> theseElements = EAM.MembersNewTabOECSales.SalesDropDownList.FindElements(By.TagName("div"));
            Boolean foundElementToClick = false;
            string foundElements = "";

            foreach (IWebElement thisElement in theseElements)
            {
                foundElements += thisElement.Text + "  ";
                if (thisElement.Text == value)
                {
                    foundElementToClick = true;
                }
            }
            Console.WriteLine("Verifying item [" + value + "] is not in the Sales Rep OECSales field list. list Values [" + foundElements + "]");

            Assert.AreEqual(false, foundElementToClick, "Verifying item [" + value + "] is not in the Sales Rep OECSales field list. list Values [" + foundElements + "]");
            tmsWait.Hard(2);
        }

        [When(@"Members New Tab Provider Provider Link is Clicked")]
        public void WhenMembersNewTabProviderProviderLinkIsClicked()
        {
            tmsWait.Hard(2);

            fw.ExecuteJavascript(EAM.MembersNewTabProvider.ProviderTabLink);
           
            tmsWait.Hard(2);
        }

        [When(@"Members New Tab Contact Contact Link is Clicked")]
        public void WhenMembersNewTabContactContactLinkIsClicked()
        {
            tmsWait.Hard(2);
            EAM.MembersNewTabContact.ContactTabLink.Click();
            tmsWait.Hard(2);
        }

        [When(@"Members New Tab Payment Payment Link is Clicked")]
        public void WhenMembersNewTabPaymentPaymentLinkIsClicked()
        {
            tmsWait.Hard(2);
            EAM.MembersNewTabPayment.PaymentTabLink.Click();
            tmsWait.Hard(2);
        }

        [Then(@"Spans Tab PlanID is set to ""(.*)""")]
        public void ThenSpansTabPlanIDIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.MembersNewTabSpans.PlanID);
            select.SelectByText(GeneratedData);

        }

        [Then(@"Spans Tab StausType is set to ""(.*)""")]
        public void ThenSpansTabStausTypeIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.MembersNewTabSpans.StatusType);
            select.SelectByText(GeneratedData);
        }

        [Then(@"Spans Tab value is set to ""(.*)""")]
        public void ThenSpansTabValueIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersNewTabSpans.Value.Clear();
            EAM.MembersNewTabSpans.Value.SendKeys(GeneratedData);
        }

        [Then(@"Spans Tab Start Date is set to ""(.*)""")]
        public void ThenSpansTabStartDateIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersNewTabSpans.StartDate.Clear();
            //EAM.MembersNewTabSpans.StartDate.Clear();
            ////EAM.MembersNewTabSpans.StartDate.Clear();
            EAM.MembersNewTabSpans.StartDate.SendKeys(GeneratedData);
        }

        [Then(@"Spans Tab Save button is clicked")]
        public void ThenSpansTabSaveButtonIsClicked()
        {

            fw.ExecuteJavascript(EAM.MembersNewTabSpans.SaveButton);
            tmsWait.Hard(2);
        }


        [Then(@"Spans Tab End Date is set to ""(.*)""")]
        public void ThenSpansTabEndDateIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersNewTabSpans.EndDate.Clear();
            EAM.MembersNewTabSpans.EndDate.SendKeys(GeneratedData);
        }


        [Then(@"Verify Spans Tab static message is set to ""(.*)""")]
        public void ThenVerifySpansTabStaticMessageIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string fieldName = "Member Information Page Spans Tab Static Message ";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNewTabSpans.StaticMessage.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        
       

        [Then(@"Verify Member Info Page Response message is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageResponseMessageIsSetTo(string p0)
        {
            string fieldName = "Member Information Page Response Message ";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNew.ResponseMessage.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [When(@"Members New Page displays message ""(.*)""")]
        public void WhenMembersNewPageDisplaysMessage(string p0)
        {
           
        }

        [When(@"Members New Save is clicked")]
        public void WhenMembersNewSaveIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(EAM.MembersNew.Save);
        }
        [When(@"Contact Tab (.*)nd Address Type is set to ""(.*)""")]
        public void WhenContactTabNdAddressTypeIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(2);
            IWebElement add2 = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_drpAddType2"));
            SelectElement addtype = new SelectElement(add2);
            addtype.SelectByText(p1);
        }
        [When(@"(.*)nd Address(.*) field is set to ""(.*)""")]
        public void WhenNdAddressFieldIsSetTo(int p0, int p1, string p2)
        {
            IWebElement add2 = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtMAdd1"));
            add2.SendKeys(p2);
        }
        [When(@"(.*)nd Address(.*) is set to ""(.*)""")]
        public void WhenNdAddressIsSetTo(int p0, int p1, string p2)
        {
            IWebElement add2 = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtMAdd2"));
            add2.SendKeys(p2);
        }
        [When(@"(.*)nd Address Zip code is set to ""(.*)""")]
        public void WhenNdAddressZipCodeIsSetTo(int p0, string p1)
        {
            IWebElement zip2 = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtMZip"));
            zip2.SendKeys(p1);
        }
        [Then(@"Verify Second Address Zip Code is set to ""(.*)""")]
        public void ThenVerifySecondAddressZipCodeIsSetTo(string expected)
        {
            tmsWait.Hard(3);
            IWebElement msg = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtMZip"));
            string actual = msg.GetAttribute("value");

            Assert.AreEqual(expected, actual, "Both values are not matching");
        }

        [When(@"Members New page Save is clicked")]
        public void WhenMembersNewPageSaveIsClicked()
        {
            fw.ExecuteJavascript(EAM.MembersNew.Save);
        }


        [Given(@"Members New Save button is clicked")]
        [When(@"Members New Save button is clicked")]
        [Then(@"Members New Save button is clicked")]
        public void WhenMembersNewSaveButtonIsClicked()
        {
           
            tmsWait.Hard(2);
            try
            {
                fw.ExecuteJavascript(EAM.MembersNew.Save);
                tmsWait.Hard(2);
                IWebElement msg = Browser.Wd.FindElement(By.XPath("//div[@id='ctl00_ctl00_MainMasterContent_MainContent_UpdatePanel1']//ul"));
                if (msg.Text.Contains("Effective Date is required."))
                {
                    fw.ExecuteJavascriptSetText(EAM.MembersNew.EffectiveDate, "01/01/1998");
                    fw.ExecuteJavascript(EAM.MembersNew.Save);
                }
                IWebElement msg1 = Browser.Wd.FindElement(By.XPath("//span[@id='ctl00_ctl00_MainMasterContent_MainContent_lblMsg']"));
                
                if (msg1.Text.Contains("DOB is required.") || msg1.Text.Contains("Date of Birth cannot be greater than Today."))
                {
                    string dob = GlobalRef.DOB.ToString();
                    string GeneratedData = tmsCommon.GenerateData(dob);
                    GeneratedData = GeneratedData.Replace("/", "");
                    EAM.MembersNew.DOB.Clear();
                    EAM.MembersNew.DOB.SendKeys(GeneratedData);
                    fw.ExecuteJavascript(EAM.MembersNew.Save);
                }
            }
            catch
            {
                Console.WriteLine(" There is no Element Presence");
            }
            fw.ExecuteJavascript(EAM.MembersNew.Save);
            tmsWait.Hard(2);
           // tmsWait.Hard(5);
           // //       tmsWait.WaitForElementAttributeHasValue(By.Id("btnSave"), 15, "readyState", "complete");
           // //Putting on hold until we work out the wait loops discussion 
           // fw.ExecuteJavascript(EAM.MembersNew.Save);
           //// EAM.MembersNew.Save.Click();
           
            //tmsWait.WaitForReadyStateComplete(30);
            //IWebElement objMsg = tmsWait.WaitForElementExist(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblMsg"), 15);
            //try
            //{
            //    EAM.TransactionsNew.ContinueAnyway.Click();
            //}
            //catch { }
        }


        [When(@"Members New Save btn is clicked")]
        public void WhenMembersNewSaveBtnIsClicked()
        {
            fw.ExecuteJavascript(EAM.MembersNew.Save);
            tmsWait.Hard(2);
        }


        [Then(@"Verify Member Information page displayed ""(.*)""")]
        public void ThenVerifyMemberInformationPageDisplayed(string p0)
        {
            fw.ExecuteJavascript(EAM.MembersNew.Reset);
            tmsWait.Hard(4);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//span[@id='ctl00_ctl00_MainMasterContent_MainContent_lblMsg']"));
            Assert.AreEqual(ele.Text, p0, "Both values are not getting matched");
          
        }

        [Then(@"Verify Member Information page displays ""(.*)""")]
        public void ThenVerifyMemberInformationPageDisplays(string p0)
        {
            tmsWait.Hard(2);
            try
            {
                IWebElement msg = Browser.Wd.FindElement(By.XPath("//div[@id='ctl00_ctl00_MainMasterContent_MainContent_UpdatePanel1']//ul"));
                if (msg.Text.Contains("Effective Date is required."))
                {
                    fw.ExecuteJavascriptSetText(EAM.MembersNew.EffectiveDate, "01/01/1998");
                    fw.ExecuteJavascript(EAM.MembersNew.Save);
                }
            }
            catch
            {
                Console.WriteLine(" There is no Element Presence");
            }
            fw.ExecuteJavascript(EAM.MembersNew.Save);
            tmsWait.Hard(2);
            
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//div[@id='ctl00_ctl00_MainMasterContent_MainContent_UpdatePanel1']//ul[contains(.,'" + p0+"')]"));
            Assert.IsTrue(ele.Displayed,p0+"is not getting displayed");
        }

        [Then(@"Verify Member Information page error displays ""(.*)""")]
        public void ThenVerifyMemberInformationPageErrorDisplays(string p0)
        {
            fw.ExecuteJavascript(EAM.MembersNew.Save);
            tmsWait.Hard(2);
            //IWebElement summary = EAM.MembersNew.ResponseMessage;
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//ul[contains(.,'" + p0 + "')]"));
            Assert.IsTrue(ele.Displayed, p0 + "is not getting displayed");
        }

        [When(@"Members New ""(.*)"" icon is Clicked")]
        public void WhenMembersNewIconIsClicked(string p0)
        {
            EAM.MembersNew.HelpIcon.Click();
            tmsWait.Hard(2);
        }

        [When(@"Members New page Home icon is Clicked")]
        public void WhenMembersNewPageHomeIconIsClicked()
        {
            IWebElement home = Browser.Wd.FindElement(By.XPath("(//a[contains(.,'Home')])[1]"));
            fw.ExecuteJavascript(home);
           
            tmsWait.Hard(2);
        }

        [Then(@"variable password ""(.*)"" is got from the config file")]
        public void ThenVariablePasswordIsGotFromTheConfigFile(string p0)
        {
            string password = ConfigFile.Password;
            fw.setVariable(p0, password); 
        }

        [Then(@"Change Password Page Old Password is set to ""(.*)""")]
        public void ThenChangePasswordPageOldPasswordIsSetTo(string p0)
        {
            string oldPwd = tmsCommon.GenerateData(p0);
            EAM.MembersNew.OldPassword.SendKeys(oldPwd);
        }


        [Then(@"Change Password Page New Password is set to ""(.*)""")]
        public void ThenChangePasswordPageNewPasswordIsSetTo(string p0)
        {
            string newPwd = tmsCommon.GenerateData(p0);
            EAM.MembersNew.NewPassword.SendKeys(newPwd);
        }

        [Then(@"Change Password Page Confirm Password is set to ""(.*)""")]
        public void ThenChangePasswordPageConfirmPasswordIsSetTo(string p0)
        {
            string cfmPwd = tmsCommon.GenerateData(p0);
            EAM.MembersNew.ConfirmdPassword.SendKeys(cfmPwd);
        }

        [Then(@"Submit is clicked")]
        public void ThenSubmitIsClicked()
        {
            EAM.MembersNew.PwdSubmitBtn.Click();
        }

        [Then(@"Change Password Page displays message ""(.*)""")]
        public void ThenChangePasswordPageDisplaysMessage(string p0)
        {
            Assert.AreEqual(EAM.MembersNew.PwdChgConfm.Text, p0);
        }

        [Then(@"Password Cancel is clicked")]
        public void ThenPasswordCancelIsClicked()
        {
            EAM.MembersNew.PwdCancelBtn.Click();
        }

        [Then(@"Verify Old Password is ""(.*)""")]
        public void ThenVerifyOldPasswordIs(string p0)
        {
            Assert.AreEqual(EAM.MembersNew.OldPassword.Text, p0);
        }

        [Then(@"Verify New Password is ""(.*)""")]
        public void ThenVerifyNewPasswordIs(string p0)
        {
            Assert.AreEqual(EAM.MembersNew.NewPassword.Text, p0);
        }

        [Then(@"Verify confirm password is ""(.*)""")]
        public void ThenVerifyConfirmPasswordIs(string p0)
        {
            Assert.AreEqual(EAM.MembersNew.PwdChgConfm.Text, p0);
        }

        [Then(@"Verify that EAM DB name displays")]
        public void ThenVerifyThatEAMDBNameDisplays()
        {
            string dbName = ConfigFile.EAMdb;
            string dbNameDisplay = EAM.MembersNew.DbNameDisplay.Text;
            Assert.IsTrue(dbNameDisplay.Contains(dbName));
        }

        [Then(@"Verify Logged in as username is displayed")]
        public void ThenVerifyLoggedInAsUsernameIsDisplayed()
        {
            string user = ConfigFile.UserId;
            string displayUser = EAM.MembersNew.UserNameDisplay.Text;
            Assert.IsTrue(displayUser.Contains(user));
        }


        [Then(@"Change Password Failed Page displays message ""(.*)""")]
        public void ThenChangePasswordFailedPageDisplaysMessage(string p0)
        {
            Assert.AreEqual(EAM.MembersNew.PwdChgFailed.Text, p0);
        }


        [Then(@"Members New page Change Password icon is Clicked")]
        public void ThenMembersNewPageChangePasswordIconIsClicked()
        {
            EAM.MembersNew.ChangePwdIcon.Click();
            tmsWait.Hard(2);
        }


        [Then(@"Verify ""(.*)"" page opens")]
        public void ThenVerifyPageOpens(string p0)
        {
            Browser.SwitchToWindowUsingTitle(p0);
            string windowHandle = Browser.Wd.CurrentWindowHandle;
            string tit = Browser.Wd.Title;
            Assert.AreEqual(Browser.Wd.Title, p0);

        }

        [Then(@"Close the Help page")]
        public void ThenCloseTheHelpPage()
        {
            Browser.Wd.Close();
            Browser.SwitchToParentWindow();
        }


        [When(@"Verify Members New Group does not have ""(.*)"" value")]
        public void WhenVerifyMembersNewGroupDoesNotHaveValue(string p0)
        {
            string expectedValue = (tmsCommon.GenerateData(p0));
            string listValues = "";

            SelectElement selectList = new SelectElement(EAM.MembersNew.Group);

            IList<IWebElement> options = selectList.Options;
            Boolean isFound = false;
            foreach (IWebElement option in options)
            {
                listValues = listValues + option.Text + ";";
                if (option.Text == expectedValue)
                {
                    isFound = true;
                    break;
                }
            }
            Console.WriteLine("List values are: {0}", listValues);
            Assert.AreEqual(isFound, false, "Group List has [" + expectedValue + "] value, but should not");
        }
        [Then(@"Verify Members New Class does not have ""(.*)"" value")]
        public void ThenVerifyMembersNewClassDoesNotHaveValue(string p0)
        {
            string expectedValue = (tmsCommon.GenerateData(p0));
            string listValues = "";
            SelectElement selectList = new SelectElement(EAM.MembersNew.Class);
            IList<IWebElement> options = selectList.Options;
            Boolean isFound = false;
            foreach (IWebElement option in options)
            {
                listValues = listValues + option.Text + ";";
                if (option.Text == expectedValue)
                {
                    isFound = true;
                    break;
                }
            }
            Console.WriteLine("List values are: {0}", listValues);
            Assert.AreEqual(isFound, false, "Class List has [" + expectedValue + "] value, but should not");
        }
        [Then(@"Verify Members New Sub-Group does not have ""(.*)"" value")]
        public void ThenVerifyMembersNewSub_GroupDoesNotHaveValue(string p0)
        {
            string expectedValue = (tmsCommon.GenerateData(p0));
            string listValues = "";
            SelectElement selectList = new SelectElement(EAM.MembersNew.SubGroup);
            IList<IWebElement> options = selectList.Options;
            Boolean isFound = false;
            foreach (IWebElement option in options)
            {
                listValues = listValues + option.Text + ";";
                if (option.Text == expectedValue)
                {
                    isFound = true;
                    break;
                }
            }
            Console.WriteLine("List values are: {0}", listValues);
            Assert.AreEqual(isFound, false, "SubGroup List has [" + expectedValue + "] value, but should not");
        }

        [When(@"WebAdministration page Enable NotesAndActions is ""(.*)""")]
        public void WhenWebAdministrationPageEnableNotesAndActionsIs(string p0)
        {
            if (p0.ToLower().Equals("checked"))
            {
                if (!EAM.AdministrationPage.NotesActionCheck.Selected)
                    EAM.AdministrationPage.NotesActionCheck.Click();
            }
            else
            {
                if (EAM.AdministrationPage.NotesActionCheck.Selected)
                    EAM.AdministrationPage.NotesActionCheck.Click();
            }
        }

        
        [Then(@"Verify Message """"(.*)"" letter is queued\."" is displayed")]
        public void ThenVerifyMessageLetterIsQueued_IsDisplayed(string p0)
        {
            
        }




        [When(@"Verify Members New Static Message ""(.*)"" is displayed")]
        [Then(@"Verify Members New Static Message ""(.*)"" is displayed")]
        public void ThenVerifyMembersNewStaticMessageIsDisplayed(string p0)
        {
          

            if (p0.Contains("DOB is required.") || p0.Contains("Date of Birth cannot be greater than Today.") || p0.Contains("Date of Birth is not a date."))
            {
                string dob = GlobalRef.DOB.ToString();
                string dob1 = tmsCommon.GenerateData(dob);
                dob1 = dob1.Replace("/", "");
                EAM.MembersNew.DOB.Clear();
                EAM.MembersNew.DOB.SendKeys(dob1);
                fw.ExecuteJavascript(EAM.MembersNew.Save);
            }
            if (p0.Contains("Termination Date is not a date."))
            {

                EAM.MembersNew.TermDate.Clear();
                EAM.MembersNew.TermDate.SendKeys("00/00/0000");
                fw.ExecuteJavascript(EAM.MembersNew.Save);
            }
            if(p0.Contains("Termination Date is not a date."))
                {
                EAM.MembersNew.TermDate.Clear();
                EAM.MembersNew.TermDate.SendKeys("13/32/9890");
                fw.ExecuteJavascript(EAM.MembersNew.Save);

              }
            else
            {
                try
                {
                    IWebElement msg = Browser.Wd.FindElement(By.XPath("//div[@id='ctl00_ctl00_MainMasterContent_MainContent_UpdatePanel1']//li"));
                    if (msg.Text.Contains("Effective Date is required."))
                    {
                        fw.ExecuteJavascriptSetText(EAM.MembersNew.EffectiveDate, "01/01/1998");
                        fw.ExecuteJavascript(EAM.MembersNew.Save);
                    }

                }

                catch
                {
                    Console.WriteLine(" There is no expected message presence");
                }
            }

            tmsWait.Hard(2);
            string GeneratedData = tmsCommon.GenerateData(p0);
            string fieldValue = EAM.MembersNew.ResponseMessage.Text;
            Console.WriteLine("Verify Members New Static Message: Expected [{0}], Actual [{1}]", GeneratedData, fieldValue);
            //Assert.IsTrue(String.Compare(fieldValue, p0) == 0, "Verify Members New Static Message: Expected [{0}], Actual [{1}]", GeneratedData, fieldValue);
            Assert.IsTrue(fieldValue.Contains(p0), "Verify Members New Static Message: Expected [{0}], Actual [{1}]", GeneratedData, fieldValue);
           }

        [Then(@"Verify Transaction New page displayed warning Message ""(.*)""")]
        public void ThenVerifyTransactionNewPageDisplayedWarningMessage(string p0)
        {
            tmsWait.Hard(2);
            By loc = By.XPath("//span[contains(.,'"+p0+"')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }

        [Then(@"Verify Transaction New page displayed warning Message for Blank RX Bin")]
        public void ThenVerifyTransactionNewPageDisplayedWarningMessageForBlankRXBin()
        {
            tmsWait.Hard(5);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By loc = By.XPath("(//span[contains(.,'Please provide Primary Rx BIN')])[1]");
                bool presence = Browser.Wd.FindElement(loc).Displayed;
                Assert.IsTrue(presence, " Expected Element is not displayed");
                //UIMODUtilFunctions.elementPresenceUsingLocators(loc);
            }
            else
            {
                By loc = By.XPath("//span[contains(.,'Please provide Primary Rx BIN')]");
                UIMODUtilFunctions.elementPresenceUsingLocators(loc);
            }
        }


        [Then(@"Verify Transaction New Static Message ""(.*)"" is displayed")]
        public void ThenVerifyTransactionNewStaticMessageIsDisplayed(string p0)
        {
            tmsWait.Hard(2);
            string GeneratedData = tmsCommon.GenerateData(p0);
            string fieldValue = EAM.TransactionsNew.SummaryMessage.Text;
            Console.WriteLine("Verify Members New Static Message: Expected [{0}], Actual [{1}]", GeneratedData, fieldValue);
           // Assert
            Assert.IsTrue(fieldValue.Contains(GeneratedData), "Verify Members New Static Message: Expected [{0}], Actual [{1}]", GeneratedData, fieldValue);
        }

        [Then(@"Members New New button is clicked")]
        public void ThenMembersNewNewButtonIsClicked()
        {
            EAM.MembersNew.New.Click();
        }

        [Then(@"Members New Page is displayed")]
        public void ThenMembersNewPageIsDisplayed()
        {
            Assert.AreEqual(EAM.MembersNew.MemberStatus.Text, "");
        }


        [Then(@"Members ID History Tab displays")]
        public void ThenMembersIDHistoryTabDisplays()
        {
            Assert.IsTrue(EAM.MembersNew.HistoryTab.Displayed);
        }

        [Then(@"click on ID History tab")]
        public void ThenClickOnIDHistoryTab()
        {
            EAM.MembersNew.HistoryTab.Click();
        }


        [Then(@"Members ID history Tab displays message ""(.*)""")]
        public void ThenMembersIDHistoryTabDisplaysMessage(string p0)
        {
            Assert.AreEqual(p0, EAM.MembersNew.HistoryTabContents.Text);
        }


        [Then(@"Verify Members New Plan 1 Label is set to ""(.*)""")]
        public void ThenVerifyMembersNewPlan1LabelIsSetTo(string p0)
        {
            string fieldName = "Members New Plan 1 Label";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNew.Plan1Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Members New Plan 2 Label is set to ""(.*)""")]
        public void ThenVerifyMembersNewPlan2LabelIsSetTo(string p0)
        {
            string fieldName = "Members New Plan 2 Label";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNew.Plan2Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Members New Plan 3 Label is set to ""(.*)""")]
        public void ThenVerifyMembersNewPlan3LabelIsSetTo(string p0)
        {
            string fieldName = "Members New Plan 3 Label";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNew.Plan3Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Members New Plan 4 Label is set to ""(.*)""")]
        public void ThenVerifyMembersNewPlan4LabelIsSetTo(string p0)
        {
            string fieldName = "Members New Plan 4 Label";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNew.Plan4Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Members New Plan 5 Label is set to ""(.*)""")]
        public void ThenVerifyMembersNewPlan5LabelIsSetTo(string p0)
        {
            string fieldName = "Members New Plan 5 Label";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNew.Plan5Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        //************************
        //     Tab Payment
        //************************
        [Then(@"Verify Members New Tab Payment Fileds Labels")]
        public void ThenVerifyMembersNewTabPaymentFiledsLabels(Table table)
        {
            try
            {
                ICollection<string> thisDataHeader = table.Header;
                if (!thisDataHeader.Contains("Label") || !thisDataHeader.Contains("Name")) { Assert.Fail("Verify Members New Plan Fields Labels: data table has wrong columns names"); }

                string fieldName = "";

                foreach (var row in table.Rows)
                {
                    string dataValue = tmsCommon.GenerateDataForTable(row["Name"]);
                    string rowLabel = row["Label"];
                    string rowName = dataValue;
                    if (rowName.ToLower() != "skip")
                    {
                        switch (rowLabel.ToLower())
                        {
                            case "plan6": { fieldName = EAM.MembersNewTabPayment.Plan6Label.Text; break; }
                            case "plan7": { fieldName = EAM.MembersNewTabPayment.Plan7Label.Text; break; }
                            case "plan8": { fieldName = EAM.MembersNewTabPayment.Plan8Label.Text; break; }
                            case "plan9": { fieldName = EAM.MembersNewTabPayment.Plan9Label.Text; break; }
                            case "plan10": { fieldName = EAM.MembersNewTabPayment.Plan10Label.Text; break; }
                            default: Console.WriteLine("Filed name {0} was not found!", rowLabel); break;
                        }
                        Console.WriteLine("Verify Members New Tab Payment Fileds Labels: Expected [{0}], Actual [{1}]", rowName, fieldName);
                        Assert.AreEqual(fieldName, rowName, "Verify Members New Tab Payment Fileds Labels: Expected [{0}], Actual [{1}]", rowName, fieldName);
                    }
                }
            }
            catch (Exception ex)
            {
                Assert.Fail("Administration Plan Defined Fields Members Fields set values. Exception: (0)", ex.Message);
            }
        }
        [Then(@"Verify Members New Payment Tab Plan 6 Label is set to ""(.*)""")]
        public void ThenVerifyMembersNewPaymentTabPlan6LabelIsSetTo(string p0)
        {
            string fieldName = "Members New Payment Tab Plan 6 Label";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNewTabPayment.Plan6Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [Then(@"Verify Members New Payment Tab Plan 7 Label is set to ""(.*)""")]
        public void ThenVerifyMembersNewPaymentTabPlan7LabelIsSetTo(string p0)
        {
            string fieldName = "Members New Payment Tab Plan 7 Label";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNewTabPayment.Plan7Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [Then(@"Verify Members New Payment Tab Plan 8 Label is set to ""(.*)""")]
        public void ThenVerifyMembersNewPaymentTabPlan8LabelIsSetTo(string p0)
        {
            string fieldName = "Members New Payment Tab Plan 8 Label";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNewTabPayment.Plan8Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [Then(@"Verify Members New Payment Tab Plan 9 Label is set to ""(.*)""")]
        public void ThenVerifyMembersNewPaymentTabPlan9LabelIsSetTo(string p0)
        {
            string fieldName = "Members New Payment Tab Plan 9 Label";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNewTabPayment.Plan9Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [Then(@"Verify Members New Payment Tab Plan 10 Label is set to ""(.*)""")]
        public void ThenVerifyMembersNewPaymentTabPlan10LabelIsSetTo(string p0)
        {
            string fieldName = "Members New Payment Tab Plan 10 Label";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNewTabPayment.Plan10Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        //************************
        //     Tab Contact
        //************************

        [When(@"Members New Tab Contact Address1 is set to ""(.*)""")]
        public void WhenMembersNewTabContactAddressIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersNewTabContact.Address1.Clear();
            EAM.MembersNewTabContact.Address1.Click();
            EAM.MembersNewTabContact.Address1.SendKeys(GeneratedData);
        }

        [When(@"Members New Tab Contact Address2 is set to ""(.*)""")]
        public void WhenMembersNewTabContactAddress2IsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersNewTabContact.Address2.Clear();
            EAM.MembersNewTabContact.Address2.Click();
            EAM.MembersNewTabContact.Address2.SendKeys(GeneratedData);
        }

        [Then(@"Verify Members New Tab Contact County is set to ""(.*)""")]
        public void ThenVerifyMembersNewTabContactCountyIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNewTabContact.County.GetAttribute("value");
            Assert.IsTrue(GeneratedData == thisFieldValue, "Field County on Contact Tab has value [{0}], expected [{1}]", thisFieldValue, GeneratedData);
            fw.ConsoleReport(String.Format("   Verification Point: Field County on Contact Tab has value [{0}], expected [{1}] - They are expected to match.", thisFieldValue, GeneratedData));
        }

        [When(@"Members New Tab Contact tab County is selected as ""(.*)""")]
        public void WhenMembersNewTabContactTabCountyIsSelectedAs(string p0)
        {
            tmsWait.Hard(2);
            new SelectElement(Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_ddlCounty"))).SelectByText(p0);
            tmsWait.Hard(2);
        }


        [Then(@"Verify Members New Tab Contact SCC is set to ""(.*)""")]
        public void ThenVerifyMembersNewTabContactSCCIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNewTabContact.SCC.GetAttribute("value");
            Assert.IsTrue(GeneratedData == thisFieldValue, "Field SCC on Contact Tab has value [{0}], expected [{1}]", thisFieldValue, GeneratedData);
            fw.ConsoleReport(String.Format("   Verification Point: Field SCC on Contact Tab has value [{0}], expected [{1}] - They are expected to match.", thisFieldValue, GeneratedData));
        }
        [Then(@"Verify Members New Tab Contact Respons Relation field attribute ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyMembersNewTabContactResponsRelationFieldAttributeIsSetTo(string p0, string p1)
        {
            string fieldName = "Members New Contact Tab - respons relation attribute check [" + p0 + "]";
            string GeneratedData = tmsCommon.GenerateData(p1);
            string thisFieldValue = EAM.MembersNewTabContact.ResponsRelation.GetAttribute(p0);
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [When(@"Members New Tab Contact Respons Relation is set to ""(.*)""")]
        public void WhenMembersNewTabContactResponsRelationIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.MembersNewTabContact.ResponsRelation);
            select.SelectByText(value);
        }
        [Then(@"Verify Members New Tab Contact Respons Relation is set to ""(.*)""")]
        public void ThenVerifyMembersNewTabContactResponsRelationIsSetTo(string p0)
        {
            string fieldName = "Members New Contact Tab - respons relation value";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = "";
            Boolean bValidatedSelected = false;
            IList<IWebElement> theseOptions = EAM.MembersNewTabContact.ResponsRelation.FindElements(By.TagName("option"));
            foreach (IWebElement thisOption in theseOptions)
            {
                string selectedAttribute = thisOption.GetAttribute("selected");
                if (selectedAttribute == "true" )
                {
                    bValidatedSelected = true;
                    thisFieldValue = thisOption.Text;
                    break;
                }
            }
            Assert.AreEqual(true, bValidatedSelected, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");

        }

        [When(@"Members New Tab Contact Zip is set to ""(.*)""")]
        public void WhenMembersNewTabContactZipIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);

            EAM.MembersNewTabContact.Zip.Clear();
            EAM.MembersNewTabContact.Zip.Click();
            EAM.MembersNewTabContact.Zip.SendKeys(GeneratedData);
            EAM.MembersNewTabContact.City.Click();
            tmsWait.Hard(1);
            tmsWait.WaitForReadyStateComplete(30);
            tmsWait.WaitForElementExist(By.XPath("//*[contains(@id, 'ucMemberAddr_txtPCity')]"), 30);
        }

        [When(@"Members New Tab Contact City is set to ""(.*)""")]
        public void WhenMembersNewTabContactCityIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersNewTabContact.City.Clear();
            EAM.MembersNewTabContact.City.Click();
            EAM.MembersNewTabContact.City.SendKeys(GeneratedData);

        }



        [When(@"Verify Members New Tab Contact Zip is set to ""(.*)""")]
        [Then(@"Verify Members New Tab Contact Zip is set to ""(.*)""")]
        public void WhenVerifyMembersNewTabContactZipIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            Assert.IsTrue(EAM.MembersNewTabContact.Zip.Text.Contains(""));
        }


        [When(@"Members New Tab Contact Address Type is set to ""(.*)""")]
        public void WhenMembersNewTabContactAddressTypeIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);

            string strID = EAM.MembersNewTabContact.Address1.GetAttribute("id");

            SelectElement select = new SelectElement(EAM.MembersNewTabContact.AddressType);
            select.SelectByText(GeneratedData);
            tmsWait.Hard(2);
            tmsWait.WaitForReadyStateComplete(30);
            tmsWait.WaitForElementExist(By.Id(strID), 40);
        }

        [When(@"Members New Tab Contact Address(.*) Type is set to ""(.*)""")]
        public void WhenMembersNewTabContactAddressTypeIsSetTo(int p0, string p1)
        {
            string GeneratedData = tmsCommon.GenerateData(p1);

            string strID = EAM.MembersNewTabContact.Address2.GetAttribute("id");

            SelectElement select = new SelectElement(EAM.MembersNewTabContact.AddressType2);
            select.SelectByText(GeneratedData);
            tmsWait.Hard(2);
            tmsWait.WaitForReadyStateComplete(30);
            tmsWait.WaitForElementExist(By.Id(strID), 40);
        }

        [Then(@"Verify Members New Tab Contact Zip is default set to ""(.*)""")]
        public void ThenVerifyMembersNewTabContactZipIsDefaultSetTo(string p0)
        {
            string defaultZip = EAM.MembersNewTabContact.Zip.GetAttribute("value");
            Assert.IsNotNull(defaultZip,"Zip is not empty and has value: {0}",defaultZip);
        }


        [When(@"Members New Tab Contact County is set to ""(.*)""")]
        public void WhenMembersNewTabContactCountyIsSetTo(string p0)
        {
            string strID = EAM.MembersNewTabContact.Address1.GetAttribute("id");

            string GeneratedData = tmsCommon.GenerateData(p0).ToUpper();

            SelectElement select = new SelectElement(EAM.MembersNewTabContact.County);
            select.SelectByText(GeneratedData);
            tmsWait.Hard(2);
            tmsWait.WaitForElementExist(By.Id(strID), 20);
        }



        [Then(@"Verify Members New Tab Contact City is set to ""(.*)""")]
        public void ThenVerifyMembersNewTabContactCityIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNewTabContact.City.GetAttribute("value");

            Assert.IsTrue(String.Compare(thisFieldValue, GeneratedData, true) == 0, "Field City on Contact Tab has value [{0}], expected [{1}]", thisFieldValue, GeneratedData);
            fw.ConsoleReport(String.Format("   Verification Point: Field City on Contact Tab has value [{0}], expected [{1}] - They are expected to match.", thisFieldValue, GeneratedData));
        }

        [Then(@"Verify Members New Tab Contact State is set to ""(.*)""")]
        public void ThenVerifyMembersNewTabContactStateIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNewTabContact.State.GetAttribute("value");
            //Assert.IsTrue(String.Compare(thisFieldValue, GeneratedData, true) == 0, "Field State on Contact Tab has value [{0}], expected [{1}]", thisFieldValue, GeneratedData);
            Assert.IsTrue(thisFieldValue.Contains(GeneratedData));
            fw.ConsoleReport(String.Format("   Verification Point: Field State on Contact Tab has value [{0}], expected [{1}] - They are expected to match.", thisFieldValue, GeneratedData));
        }

        [Then(@"Verify Members New Tab Contact Static Message ""(.*)"" is displayed")]
        public void ThenVerifyMembersNewTabContactStaticMessageIsDisplayed(string p0)
        {
         //   IWebElement msg = tmsWait.WaitForElementExist(By.XPath("//*[contains(@id, 'ucMemberAddr_lblMsg')]"), 30);
            tmsWait.Hard(3);
            string fieldValue = EAM.MembersNewTabContact.StaticMessage.Text;
            Console.WriteLine("Verify Members New Static Message: Expected [{0}], Actual [{1}]", p0, fieldValue);
            Assert.IsTrue(String.Compare(fieldValue, p0) == 0, "Verify Members New Static Message: Expected [{0}], Actual [{1}]", p0, fieldValue);
        }



        [Then(@"Members View Edit Page Contact tab zip is noted")]
        public void ThenMembersViewEditPageContactTabZipIsNoted()
        {
            string defaultZip = EAM.MembersNewTabContact.Zip.GetAttribute("value").ToString();
            GlobalRef.OldZip = defaultZip;
        }


        //************************
        //     Tab Spans
        //************************

        [When(@"Members New Tab Spans Spans Link is Clicked")]
        public void WhenMembersNewTabSpansSpansLinkIsClicked()
        {
            fw.ExecuteJavascript(EAM.MembersNewTabSpans.SpansTabLink);
            tmsWait.Hard(6);
           //01142016 These NEVER work, stop using them until they do - Daron tmsWait.WaitForReadyStateComplete(30);
        }

        [When(@"Span Tab newly Inserted value is edited")]
        public void WhenSpanTabNewlyInsertedValueIsEdited()
        {
            By edit = By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_ucMemberSpans_dgHistory']//img[@alt='Edit']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(edit));
            tmsWait.Hard(3);
        }


        [When(@"Members New Tab Spans Value is set to ""(.*)""")]
        public void WhenMembersNewTabSpansValueIsSetTo(int p0)
        {
            string value = tmsCommon.GenerateData(p0.ToString());
            EAM.MembersNewTabSpans.Value.SendKeys(Keys.Home);
            EAM.MembersNewTabSpans.Value.Clear();
            EAM.MembersNewTabSpans.Value.SendKeys(value);
        }

        [When(@"Members New Tab Spans Value is set as ""(.*)""")]
        public void WhenMembersNewTabSpansValueIsSetAs(string p0)
        {
            string value = tmsCommon.GenerateData(p0.ToString());
            EAM.MembersNewTabSpans.Value.SendKeys(value);
        }

        [When(@"Members New Tab Spans Status Type ""(.*)"" is deleted")]
        public void WhenMembersNewTabSpansStatusTypeIsDeleted(string statusType)
        {
            try
            {
                if (Browser.Wd.FindElement(By.XPath("//td[text()='" + statusType + "']/parent::tr//img[@alt='Delete']")).Displayed)
                {
                    Browser.Wd.FindElement(By.XPath("//td[text()='" + statusType + "']/parent::tr//img[@alt='Delete']")).Click();
                    Browser.ClosePopUps(true);
                }
            }
            catch (Exception ex)
            {
                //skip
            }
        }

        [When(@"Members New Tab Spans Drp Value is set as ""(.*)""")]
        public void WhenMembersNewTabSpansDrpValueIsSetAs(string p0)
        {
            tmsWait.Hard(2);
            By drp = By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberSpans_drpRiskTypes");
            new SelectElement(Browser.Wd.FindElement(drp)).SelectByText(p0);
        }


        [When(@"Members New Tab Spans Status Type is set to ""(.*)""")]
        [Then(@"Members New Tab Spans Status Type is set to ""(.*)""")]
        public void ThenMembersNewTabSpansStatusTypeIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);

            SelectElement select = new SelectElement(EAM.MembersNewTabSpans.StatusType);
            Boolean foundIt = false;
            try
            {
                select.SelectByText(GeneratedData);
                tmsWait.Hard(2);
                foundIt = true;
            }
            catch
            {
                select.SelectByText(GeneratedData.ToUpper());
                tmsWait.Hard(2);
                foundIt = true;

            }
            Assert.AreEqual(true, foundIt, "Couldn't find [" + GeneratedData + "] in the Members New Tab Spans Status type field");
        }
        [Then(@"Verify Members New Tab Spans Status Type field does not have ""(.*)"" value")]
        public void ThenVerifyMembersNewTabSpansStatusTypeFieldDoesNotHaveValue(string p0)
        {
            string expectedValue = (tmsCommon.GenerateData(p0));
            string listValues = "";

            SelectElement selectList = new SelectElement(EAM.MembersNewTabSpans.StatusType);

            IList<IWebElement> options = selectList.Options;
            Boolean isFound = false;
            foreach (IWebElement option in options)
            {
                listValues += option.Text + " ";
                if (option.Text == expectedValue)
                {
                    isFound = true;
                    break;
                }
            }
            Console.WriteLine("List values are: {0}", listValues);
            Assert.AreEqual(false, isFound, "Spans Tab Status Type field has value [" + expectedValue + "] which should not be in the list:  [" + listValues + "]");
        }


        
        [Then(@"Verify Members Information Spans section Status Type field does not have ""(.*)"" value")]
        public void ThenVerifyMembersInformationSpansSectionStatusTypeFieldDoesNotHaveValue(string p0)
        {

            bool flag=false;
            string statusType = tmsCommon.GenerateData(p0);
            IList<IWebElement> options = Browser.Wd.FindElements(By.XPath("//*[@id='statusTypes']/option"));
       
            for (int i=0; i<=options.Count-1;i++) {
                if (options[i].GetAttribute("value") == statusType) {
                    flag = true;
                    break;
                }
            }
             Assert.AreEqual(false,flag, "Status Type Drop down has value "+ statusType + " which should not be in the list");
        }


        [When(@"Members New Tab Spans Start Date is set to ""(.*)""")]
        public void WhenMembersNewTabSpansStartDateIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
           // fw.ExecuteJavascriptSetText(EAM.MembersNewTabSpans.StartDate, GeneratedData);
            GeneratedData = GeneratedData.Replace("/", "");

            EAM.MembersNewTabSpans.StartDate.Clear();
           // EAM.MembersNewTabSpans.StartDate.Click();
            EAM.MembersNewTabSpans.StartDate.SendKeys(Keys.Home);
            EAM.MembersNewTabSpans.StartDate.SendKeys(GeneratedData);
        }


        [When(@"Members New Tab Spans End Date is set to ""(.*)""")]
        public void WhenMembersNewTabSpansEndDateIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascriptSetText(EAM.MembersNewTabSpans.EndDate, GeneratedData);
            //GeneratedData = GeneratedData.Replace("/", "");

            //EAM.MembersNewTabSpans.EndDate.Clear();
            //EAM.MembersNewTabSpans.EndDate.Click();
            //EAM.MembersNewTabSpans.EndDate.SendKeys(Keys.Home);
            //EAM.MembersNewTabSpans.EndDate.SendKeys(GeneratedData);
        }

        [When(@"Members New Tab Spans Save Icon is clicked")]
        public void WhenMembersNewTabSpansSaveIconIsClicked()
        {
            EAM.MembersNewTabSpans.SaveButton.Click();
            tmsWait.Hard(4);
        }

        [When(@"Members New Tab Spans Plan ID is set to ""(.*)""")]
        public void WhenMembersNewTabSpansPlanIDIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            SelectElement selectList = new SelectElement(EAM.MembersNewTabSpans.PlanID);
            selectList.SelectByText(value);
        }

        [Then(@"Verify Members New Tab Spans Static Message ""(.*)"" is displayed")]
        public void ThenVerifyMembersNewTabSpansStaticMessageIsDisplayed(string p0)
        {
            tmsWait.Hard(3);
//            IWebElement msg = tmsWait.WaitForElementExist(By.XPath("//*[contains(@id, 'ucMemberSpans_lblMessage')]"), 15);

            string fieldValue = EAM.MembersNewTabSpans.StaticMessage.Text;
            Console.WriteLine("Verify Members New Tab Spans Static Message: Expected [{0}], Actual [{1}]", p0, fieldValue);
            Assert.IsTrue(String.Compare(fieldValue, p0) == 0, "Verify Members New Tab Spans Static Message: Expected [{0}], Actual [{1}]", p0, fieldValue);
        }
        [Then(@"Verify Members New Tab Spans Table has row")]
        public void ThenVerifyMembersNewTabSpansTableHasRow(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.MembersNewTabSpans.SpansTable;

                //Look for a next page link.  We will set 'last page of records' here also.
    //            thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]" )
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 2)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[2];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                //else
                //{
                //    //Click next page link and start over.
                //    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                //    {
                //        thisTP.bNotAtLastPageOfRecords = true;
                //        thisTP.NPL.Click();
                //        tmsWait.Hard(2);
                //    }
                //}
                baseTable = EAM.MembersNewTabSpans.SpansTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }        //[Then(@"Verify Members New Tab Spans Table has row")]
        //public void ThenVerifyMembersNewTabSpansTableHasRow(Table table)
        //{
        //    try
        //    {
        //        IWebElement objWebTable = EAM.MembersNewTabSpans.SpansTable;

        //        String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
        //        for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
        //        {
        //            int index = 0;
        //            if (int.TryParse(arrRes[i, 0], out index))
        //            {
        //                if (index < 0)
        //                {
        //                    Assert.Fail("Expected row was not found: {0}", arrRes[i, 1]);
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        Assert.Fail("Verify Members New Spans Tab Table has row: {0}", e.Message);
        //    }
        //}

        [Then(@"Verify Members New Tab Spans Table does not have rows")]
        public void ThenVerifyMembersNewTabSpansTableDoesNotHaveRows(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.MembersNewTabSpans.SpansTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index >= 0)
                        {
                            Assert.Fail("Expected row [{0}] was found but should NOT {1}: ", i+1, arrRes[i, 1]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Verify Members New Spans Tab Table does not have rows: {0}", e.Message);
            }
        }

        [When(@"Members New Tab Spans Table Edit icon is clicked for row")]
        public void WhenMembersNewTabSpansTableEditIconIsClickedForRow(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.MembersNewTabSpans.SpansTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index > 0)
                        {
                            index++;
                            string xPath = "//tr[" + index + "]//img[@alt='Edit']";
                            IWebElement editIcon = EAM.MembersNewTabSpans.SpansTable.FindElement(By.XPath(xPath));
                            editIcon.Click();
                            try
                            {
                                editIcon.SendKeys(Keys.Enter);
                            }
                            catch (Exception) { }
                            tmsWait.Hard(2);
                            IWebElement objHIC = tmsWait.WaitForElementExist(By.XPath("//*[contains(@id, 'MainContent_txtHic_01')]"), 15);
                            Console.WriteLine("Edit icon was clicked");
                        }
                        else { Assert.Fail("Edit Icon for expected row was not found"); }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Members New Tab Spans Table Edit icon is clicked for row: {0}", e.Message);
            }
        }

        [Then(@"View Edit Member page Transactions Tab is Clicked")]
        public void ThenViewEditMemberPageTransactionsTabIsClicked()
        {
            By transTab = By.XPath("//a[@id='ctl00_ctl00_MainMasterContent_MainContent_btnTransactions']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(transTab));
            tmsWait.Hard(2);
        }


        //************************
        //     Tab Transactions
        //************************
        [When(@"Members New Transactions Tab Add New Transaction Link is clicked")]
        [Given(@"Members New Transactions Tab Add New Transaction Link is clicked")]
        [Then(@"Members New Transactions Tab Add New Transaction Link is clicked")]

        public void WhenMembersNewTransactionsTabAddNewTransactionLinkIsClicked()
        {           
            try
            {
                fw.ExecuteJavascript(EAM.MembersNewTabTransactions.AddNewTransactionLink);
                tmsWait.Hard(6);
          
            }
            catch (NoSuchElementException) { }
            
        }
        [Then(@"Verify Members View Edit Eligiblity Tab CMS Part A End is set to ""(.*)""")]
        public void ThenVerifyMembersViewEditEligiblityTabCMSPartAEndIsSetTo(string p0)
        {
            string fieldName = "CMS Part A End";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNewTabEligibility.CMSPartAEnd.GetAttribute("value");
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [When(@"Members New Tab Transactions Table Edit icon is clicked for row")]
        public void WhenMembersNewTabTransactionsTableEditIconIsClickedForRow(Table table)
        {
            try
            {                
                IWebElement objWebTable = EAM.MembersNewTabTransactions.TransactionsTable;
                string strTableID = objWebTable.GetAttribute("id");

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index > 0)
                        {
                            index++;
                            string xPath = "//table[@id='" + strTableID + "']//tr[" + index + "]//img[@alt='Edit']";
                            EAM.MembersNewTabTransactions.TransactionsTable.FindElement(By.XPath(xPath)).Click();
                           
                            tmsWait.Hard(5);
                            tmsWait.WaitForElementExist(By.XPath("//*[contains(@id, 'cboTransCode_12')]"), 30);
                            Console.WriteLine("Edit icon was clicked");
                        }
                        else { Assert.Fail("Edit Icon for expected row was not found"); }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Members New Tab Transactions Table Edit icon is clicked for row: {0}", e.Message);
            }
        }

        [Then(@"Verify Members New Tab Transactions Table has row")]
        public void ThenVerifyMembersNewTabTransactionsTableHasRow(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.MembersNewTabTransactions.TransactionsTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i+1, arrRes[i, 1]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Members New Tab Transactions Table has row failed: {0}", e.Message);
            }
        }

        [Then(@"Verify Members New Tab Transactions Table has (.*) rows")]
        public void ThenVerifyMembersNewTabTransactionsTableHasRows(int p0)
        {
            IWebElement baseTable;
            try
            {
                baseTable = EAM.MembersNewTabTransactions.TransactionsTable;
            }
            catch (NoSuchElementException)
            {
                Assert.IsTrue(p0 == 0, "Transactions table does not exist, but expected rows count = [{0}]", p0);
                return;
            }

            IList<IWebElement> objUITableRowsList = baseTable.FindElements(By.TagName("tr"));
            int intRowsCount = objUITableRowsList.Count;

            Assert.IsTrue(intRowsCount - 1 == p0, "Transactions table has [{0}] rows, but expected rows count = [{1}]", intRowsCount - 1, p0);
        }


        [When(@"Members New Tab Transactions Transactions Detail Link is Clicked for row")]
        [When(@"Members New Tab Transactions Transactions Detail Link is clicked for row")]
        public void WhenMembersNewTabTransactionsTransactionsDetailLinkIsClickedForRow(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.MembersNewTabTransactions.TransactionsTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index > 0)
                        {
                            index++;
                            string xPath = "//tr[" + index + "]//a[contains(@href, 'TransHistory') and contains(text(), 'Detail')]";
                            IWebElement editIcon = EAM.MembersNewTabTransactions.TransactionsTable.FindElement(By.XPath(xPath));
                            editIcon.Click();
                            try
                            {
                                editIcon.SendKeys(Keys.Enter);
                            }
                            catch (Exception) { }
                            tmsWait.Hard(3);
                            tmsWait.WaitForReadyStateComplete(30);
                            tmsWait.WaitForElementExist(By.XPath("//input[contains(@id, 'ucTransHistory_txtSearch')]"), 60);
                            Console.WriteLine("Detail Link was clicked");
                        }
                        else { Assert.Fail("Detail Link for expected row was not found"); }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Members New Tab Transactions Transactions Detail Link is Clicked for row: {0}", e.Message);
            }
        }
        [When(@"Members New Tab Transactions Detail Window Code Type is set to ""(.*)""")]
        public void WhenMembersNewTabTransactionsDetailWindowCodeTypeIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.MembersNewTabTransactions.TRCDetailPopUpCodeType);
            select.SelectByText(value);
        }

        [When(@"Members New Tab Transactions Detail Window TRR Code is set to ""(.*)""")]
        public void WhenMembersNewTabTransactionsDetailWindowTRRCodeIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            EAM.MembersNewTabTransactions.TRCDetailPopUpTRRCode.SendKeys(value);
        }
        [When(@"Members New Tab Transactions Detail Window Search Link is clicked")]
        public void WhenMembersNewTabTransactionsDetailWindowSearchLinkIsClicked()
        {
            EAM.MembersNewTabTransactions.TRCDetailPopUpSearchLink.Click();
            tmsWait.Hard(2);
        }

        [Then(@"Verify Members New Tab Transactions Detail Window has row")]
        public void ThenVerifyMembersNewTabTransactionsDetailWindowHasRow(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.MembersNewTabTransactions.TRCDetailPopUpTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i + 1, arrRes[i, 1]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Verify Members New Tab Transactions Detail Window has row: {0}", e.Message);
            }
        }

        [When(@"Members New Tab Transactions Detail Window Detail Link is clicked")]
        public void WhenMembersNewTabTransactionsDetailWindowDetailLinkIsClicked()
        {
            string tableID = EAM.MembersNewTabTransactions.TRCDetailPopUpTable.GetAttribute("id");
            IWebElement lnkDetail = Browser.Wd.FindElement(By.XPath("//table[@id='" + tableID + "']//a[contains(text(), 'Detail')]"));
            lnkDetail.Click();
            tmsWait.Hard(5);
            tmsWait.WaitForReadyStateComplete(30);
            
        }
        public string getTextfromWebElement(IWebElement dd)
        {
            string ddelement = dd.Text.Replace("\r\n","");       
            return ddelement;

        }

        [Then(@"Verify Members New Tab Transactions Detail Window ""(.*)"" is set to""(.*)""")]
        public void ThenVerifyMembersNewTabTransactionsDetailWindowIsSetTo(string p0, string p1)
        {

            string field = p0.ToString();
            string expected = tmsCommon.GenerateData(p1);
            switch(field)
            {
                case "Detailed Description":
                    IWebElement dd = Browser.Wd.FindElement(By.XPath("//span[@id='ctl00_ctl00_MainMasterContent_MainContent_ucTransHistory_DetailViewTrr_Label2']"));
                    string detaildesc = getTextfromWebElement(dd);
                    Assert.AreEqual(expected, detaildesc, expected + "is not found");
                    break;
                case "Note Action":
                    IWebElement na = Browser.Wd.FindElement(By.XPath("//span[@id='ctl00_ctl00_MainMasterContent_MainContent_ucTransHistory_DetailViewTrr_Label4']"));
                    string notesaction = getTextfromWebElement(na);
                    Assert.AreEqual(expected, notesaction, expected + "is not found");
                    break;

                    

            }
        }


        [Then(@"Verify Code Detailed Description table has row")]
        public void ThenVerifyCodeDetailedDescriptionTableHasRow(Table table)
        {


            //       string reportText = Browser.Wd.SwitchTo().Window(ReportWindowHandle).SwitchTo().DefaultContent().SwitchTo().Frame(0).FindElement(reportViewBy).Text;
            IWebElement reportTable = EAM.MembersNewTabTransactions.TRCDetailPopUpTRRDetailTable;
            IList<IWebElement> theseTDs = reportTable.FindElements(By.TagName("td"));
            IList<IWebElement> theseTRs = reportTable.FindElements(By.TagName("tr"));
            IList<IWebElement> theseTDSpans = reportTable.FindElements(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucTransHistory_DetailViewTrr_Label2"));
            IList<IWebElement> theseTDActionSpans = reportTable.FindElements(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucTransHistory_DetailViewTrr_Label4"));

            string thisDDescription = theseTDSpans[1].Text;
            thisDDescription = thisDDescription.Replace("\r\n", " ");
            string thisDAction = theseTDActionSpans[1].Text;
            thisDAction = thisDAction.Replace("\r\n", " ");
            Console.WriteLine(thisDDescription);
            //    Console.WriteLine(thisTDSpan.Text);
            List<string> compiledTRText = new List<string>();
            List<string> compiledTRTextsp = new List<string>();

            foreach (IWebElement thisTR in theseTRs)
            {
                string thisTRString = thisTR.Text.Replace("\n", "");
                thisTRString = thisTRString.Replace("\r", "");
                if (thisTRString.Trim() != "")
                {
                    compiledTRText.Add(thisTRString.Trim());
                    string thisTRStringsp = thisTR.Text.Replace("\n\r", " ");
                    thisTRStringsp = thisTRStringsp.Replace("\r\n", " ");
                    if(thisTRStringsp.Contains("\r \n"))
                    {
                        thisTRStringsp = thisTRStringsp.Replace("\r \n", " ");
                    }
                    compiledTRTextsp.Add(thisTRStringsp.Trim());
                }
            }

            foreach (var dataRow in table.Rows)
            {
                string dataLabel1 = tmsCommon.GenerateData(dataRow[0].ToString());
                string dataValue1 = tmsCommon.GenerateData(dataRow[1].ToString());
               
                string dataLabelValuePair1 = dataLabel1 + " " + dataValue1;
          
                string dataLabelValuePairNS = dataLabel1 + dataValue1;
                Boolean haveMatchedThisPair = false;
                foreach (string AppTRow in compiledTRTextsp)
                {
                    if (AppTRow.Trim().Contains(dataLabel1))
                    {
                        haveMatchedThisPair = true;
                        Console.WriteLine("Have matched the data pair [" + dataLabel1+ "] in report td [" + AppTRow + "]");
                        //break;
                    }
                   

                }

                foreach (string AppTRow in compiledTRTextsp)
                {
                    if (AppTRow.Contains(dataValue1))
                    {
                        haveMatchedThisPair = true;
                        Console.WriteLine("Have matched the data pair [" + dataValue1 + "] in report td [" + AppTRow + "]");
                        //break;
                    }


                }


                if (!haveMatchedThisPair)
                {
                    Console.WriteLine(" ------- ");
                    Console.WriteLine(thisDDescription.Trim());

                    Console.WriteLine(dataLabelValuePair1);
                    Console.WriteLine(" ------- ");

                    if (thisDDescription.Contains(dataLabelValuePair1))
                    {
                        haveMatchedThisPair = true;
                        Console.WriteLine("Have matched the data pair [" + dataLabelValuePair1 + "] in report td [" + thisDDescription + "]");
                        //break;
                    }
                    
                }
                if (!haveMatchedThisPair)
                {
                    Console.WriteLine(" ------- ");
                    Console.WriteLine(thisDAction.Trim());

                    Console.WriteLine(dataLabelValuePair1);
                    Console.WriteLine(" ------- ");

                    if (thisDAction.Contains(dataLabelValuePair1))
                    {
                        haveMatchedThisPair = true;
                        Console.WriteLine("Have matched the data pair [" + dataLabelValuePair1 + "] in report td [" + thisDAction + "]");
                        //break;
                    }
                    
                }
                if (!haveMatchedThisPair)
                {
                    Console.WriteLine("*******");
                    Console.WriteLine("Data mismatch trying to find [" + dataLabelValuePair1 + "]");
                    Console.WriteLine("*******");
                    //                    MessageBox.Show("Was not able to match data pair [" + dataLabelValuePair + "] or [" + dataLabelValuePairNS + "] in the drill down table");
                    Assert.AreEqual(true, false, "Was not able to match data pair [" + dataLabelValuePair1 + "] or [" + dataLabelValuePairNS + "] in the drill down table");
                }

               
            }
        }

        [When(@"Members New Tab Transactions Detail Window Incomplete Application is ""(.*)""")]
        public void WhenMembersNewTabTransactionsDetailWindowIncompleteApplicationIs(string status)
        {
            if (status.Equals("Checked"))
            {
                if (!EAM.TransactionsViewEdit.Incompletecheckbox.Selected)
                    EAM.TransactionsViewEdit.Incompletecheckbox.Click();
            }
            if(status.Equals("Unchecked"))
            {
                if (EAM.TransactionsViewEdit.Incompletecheckbox.Selected)
                    EAM.TransactionsViewEdit.Incompletecheckbox.Click();
            }
        }

        [When(@"Members New Tab Transactions Detail Window Missing Item is selected as ""(.*)""")]
        public void WhenMembersNewTabTransactionsDetailWindowMissingItemIsSelectedAs(string missingItem)
        {
            SelectElement missingitemDD = new SelectElement(EAM.TransactionsNew.MissingItem);
            missingitemDD.SelectByText(missingItem);
        }


        [Then(@"Verify Members New Tab Transactions Detail Window has data")]
        public void ThenVerifyMembersNewTabTransactionsDetailWindowHasData(Table table)
        {


            //       string reportText = Browser.Wd.SwitchTo().Window(ReportWindowHandle).SwitchTo().DefaultContent().SwitchTo().Frame(0).FindElement(reportViewBy).Text;
            IWebElement reportTable = EAM.MembersNewTabTransactions.TRCDetailPopUpTRRDetailTable;
            IList<IWebElement> theseTDs = reportTable.FindElements(By.TagName("td"));
            IList<IWebElement> theseTRs = reportTable.FindElements(By.TagName("tr"));
            IList<IWebElement> theseTDSpans = reportTable.FindElements(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucTransHistory_DetailViewTrr_Label2"));
            IList<IWebElement> theseTDActionSpans = reportTable.FindElements(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucTransHistory_DetailViewTrr_Label4"));

            string thisDDescription = theseTDSpans[1].Text;
            thisDDescription = thisDDescription.Replace("\r\n", " ");
            string thisDAction = theseTDActionSpans[1].Text;
            thisDAction = thisDAction.Replace("\r\n", " ");
            Console.WriteLine(thisDDescription);
        //    Console.WriteLine(thisTDSpan.Text);
            List<string> compiledTRText = new List<string>();
            List<string> compiledTRTextsp = new List<string>();

            foreach (IWebElement thisTR in theseTRs)
            {
                string thisTRString = thisTR.Text.Replace("\n", "");
                thisTRString = thisTRString.Replace("\r", "");
                if (thisTRString.Trim() != "")
                {
                    compiledTRText.Add(thisTRString.Trim());
                    string thisTRStringsp = thisTR.Text.Replace("\n\r", " ");
                    thisTRStringsp = thisTRStringsp.Replace("\r\n", " ");
                    compiledTRTextsp.Add(thisTRStringsp.Trim());
                }
            }

            foreach (var dataRow in table.Rows)
            {
                string dataLabel = tmsCommon.GenerateData(dataRow[0].ToString());
                string dataValue = tmsCommon.GenerateData(dataRow[1].ToString());
                string dataLabelValuePair = dataLabel + " " + dataValue;
                string dataLabelValuePairNS = dataLabel + dataValue;
                Boolean haveMatchedThisPair = false;
                foreach (string AppTRow in compiledTRTextsp)
                {
                    if (AppTRow.Trim().Contains(dataLabelValuePair))
                    {
                        haveMatchedThisPair = true;
                        Console.WriteLine("Have matched the data pair [" + dataLabelValuePair + "] in report td [" + AppTRow + "]");
                        //break;
                    }
                }


                if (!haveMatchedThisPair)
                {
                    Console.WriteLine(" ------- ");
                    Console.WriteLine(thisDDescription.Trim());

                    Console.WriteLine(dataLabelValuePair);
                    Console.WriteLine(" ------- ");

                    if (thisDDescription.Contains(dataLabelValuePair))
                    {
                        haveMatchedThisPair = true;
                        Console.WriteLine("Have matched the data pair [" + dataLabelValuePair + "] in report td [" + thisDDescription + "]");
                        //break;
                    }
                }
                if (!haveMatchedThisPair)
                {
                    Console.WriteLine(" ------- ");
                    Console.WriteLine(thisDAction.Trim());

                    Console.WriteLine(dataLabelValuePair);
                    Console.WriteLine(" ------- ");

                    if (thisDAction.Contains(dataLabelValuePair))
                    {
                        haveMatchedThisPair = true;
                        Console.WriteLine("Have matched the data pair [" + dataLabelValuePair + "] in report td [" + thisDAction + "]");
                        //break;
                    }
                }
                if (!haveMatchedThisPair)
                {
                    Console.WriteLine("*******");
                    Console.WriteLine("Data mismatch trying to find [" + dataLabelValuePair + "]");
                    Console.WriteLine("*******");
                    //                    MessageBox.Show("Was not able to match data pair [" + dataLabelValuePair + "] or [" + dataLabelValuePairNS + "] in the drill down table");
                    Assert.AreEqual(true, false, "Was not able to match data pair [" + dataLabelValuePair + "] or [" + dataLabelValuePairNS + "] in the drill down table");
                }
            }
        }



        [When(@"Members New Tab Transactions Detail Window is closed")]
        public void WhenMembersNewTabTransactionsDetailWindowIsClosed()
        {
            EAM.MembersNewTabTransactions.TRCDetailPopUpCloseButton.Click();
            tmsWait.WaitForReadyStateComplete(30);
        }



        //*********************************
        //      Tab Provider
        //*********************************
        [Then(@"Verify Members New Tab Provider PCP ID is set to ""(.*)""")]
        public void ThenVerifyMembersNewTabProviderPCPIDIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNewTabProvider.PCPID.GetAttribute("value");
            Assert.IsTrue(GeneratedData == thisFieldValue, "Field PCP ID on Provider Tab has value [{0}], expected [{1}]", thisFieldValue, GeneratedData);
            fw.ConsoleReport(String.Format("   Verification Point: Field PCP ID on Provider Tab has value [{0}], expected [{1}] - They are expected to match.", thisFieldValue, GeneratedData));    
        }

        [Then(@"Verify Members New Tab Provider First Name is set to ""(.*)""")]
        public void ThenVerifyMembersNewTabProviderFirstNameIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNewTabProvider.FirstName.GetAttribute("value");
            Assert.IsTrue(GeneratedData == thisFieldValue, "Field First Name Provider Tab has value [{0}], expected [{1}]", thisFieldValue, GeneratedData);
            fw.ConsoleReport(String.Format("   Verification Point: Field First Name on Provider Tab has value [{0}], expected [{1}] - They are expected to match.", thisFieldValue, GeneratedData));  
        }

        [Then(@"Verify Members New Tab Provider Last Name is set to ""(.*)""")]
        public void ThenVerifyMembersNewTabProviderLastNameIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNewTabProvider.LastName.GetAttribute("value");
            Assert.IsTrue(GeneratedData == thisFieldValue, "Field Last Name Provider Tab has value [{0}], expected [{1}]", thisFieldValue, GeneratedData);
            fw.ConsoleReport(String.Format("   Verification Point: Field Last Name on Provider Tab has value [{0}], expected [{1}] - They are expected to match.", thisFieldValue, GeneratedData)); 
        }

        [When(@"Members New Tab Provider PCP Prv ID is set to ""(.*)""")]
        public void WhenMembersNewTabProviderPCPPrvIDIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersNewTabProvider.PCPPrvID.SendKeys(GeneratedData);
        }

        [When(@"Members New Tab Provider PCPID is set to ""(.*)""")]
        public void WhenMembersNewTabProviderPCPIDIsSetTo(int p0)
        {
            EAM.MembersNewTabProvider.PCPID.SendKeys(p0.ToString());
        }


        [When(@"Members New Tab Provider GynName is set to ""(.*)""")]
        public void WhenMembersNewTabProviderGynNameIsSetTo(string p0)
        {
            EAM.MembersNewTabProvider.GynName.SendKeys(p0);
        }

        [When(@"Members New Tab Provider GynPCPID is set to ""(.*)""")]
        public void WhenMembersNewTabProviderGynPCPIDIsSetTo(int p0)
        {
            EAM.MembersNewTabProvider.GynPCPID.SendKeys(p0.ToString());

        }

        [When(@"Members New Tab Provider GynPCPPrv is set to ""(.*)""")]
        public void WhenMembersNewTabProviderGynPCPPrvIsSetTo(int p0)
        {
            EAM.MembersNewTabProvider.GynPCPPrv.SendKeys(p0.ToString());
        }



        //*********************************
        //      Tab ID History
        //*********************************
        [Then(@"Verify Members New Tab ID History Table has row")]
        public void ThenVerifyMembersNewTabIDHistoryTableHasRow(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.MembersNewTabIDHistory.HistoryTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i + 1, arrRes[i, 1]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Verify Members New Tab ID History Table has row: {0}", e.Message);
            }
        }





        //***********************************
        //      PCP/IPA Lookup 
        //***********************************
        [Then(@"Members New PCPIPA Lookup is opened")]
        public void ThenMembersNewPCPIPALookupIsOpened()
        {
            var currentWindow = Browser.Wd.CurrentWindowHandle;
            if (!Browser.SwitchWindow("EAM - PCP/IPA Lookup"))
            {
                Assert.Fail("Members New PCPIPA Lookup was not opened");
            }

            fw.ConsoleReport("      Members New PCPIPA Lookup was opened");
        }

        //*********************************
        //      Tab Provider
        //*********************************
        [Then(@"Verify Members New Tab Eligibility Medicare Part A is set to ""(.*)""")]
        public void ThenVerifyMembersTabEligibilityMedicarePartAIsSetTo(string p0)
        {
            string fieldName = "Medicare Part A";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNewTabEligibility.PlanPartAEff.GetAttribute("value");
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [Then(@"Verify Members New Tab Eligibility Medicare Part B is set to ""(.*)""")]
        public void ThenVerifyMembersNewTabEligibilityMedicarePartBIsSetTo(string p0)
        {
            string fieldName = "Medicare Part B";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNewTabEligibility.PlanPartBEff.GetAttribute("value");
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }


        //***********************************
        //      Audit
        //***********************************
        [When(@"Member New View Audit History icon is clicked")]
        public void WhenMemberNewViewAuditHistoryIconIsClicked()
        {
            EAM.MembersNew.ViewAuditHistoryButton.Click();
            fw.ExecuteJavascript(EAM.MembersNew.ViewAuditHistoryButton);
            tmsWait.WaitForElementExist(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAuditDialog_lblFullName"), 30);
        }



        [Then(@"Verify Member New Audit History header section")]
        public void ThenVerifyMemberNewAuditHistoryHeaderSection(Table table)
        {
            string strValue = "", strHeader = "", strActualValue = "";
            var headersEnum = table.Header.GetEnumerator();

            foreach (var row in table.Rows)
            {
                headersEnum.Reset();

                foreach (var value in row.Values)
                {
                    headersEnum.MoveNext();

                    strValue = tmsCommon.GenerateDataForTable(value);
                    if (strValue.ToLower() != "[skip]")
                    {
                        strHeader = headersEnum.Current.ToLower();
                        strActualValue = "";
                        switch (strHeader)
                        {
                            case "full name ": strActualValue = new SelectElement(EAM.AdministrationEditLISInformation.EditLISLevel).SelectedOption.Text; break;
                            case "dob": strActualValue = new SelectElement(EAM.AdministrationEditLISInformation.EditCoPayCat).SelectedOption.Text; break;
                            case "hic": break;
                            case "plan": strActualValue = EAM.AdministrationEditLISInformation.EditStartDate.Text;   break;
                            case "pbp": strActualValue = EAM.AdministrationEditLISInformation.EditEndDate.Text; break;
                            case "gender": strActualValue = new SelectElement(EAM.AdministrationEditLISInformation.EditLISType).SelectedOption.Text; break;
                            default: break;
                        }
                        Assert.IsTrue(strActualValue.Equals(strValue), "Value in [{0}] field = [{1}] does not equal to expected = [{2}]", strHeader, strActualValue, strValue);
                    }
                }
            }
        }

        [Then(@"Members Audit History Date is set to ""(.*)""")]
        public void ThenMembersAuditHistoryDateIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            if (p0.ToString().Contains("DateFrom"))
            {
                EAM.MembersNewMemberAuditHistory.DateFrom.SendKeys(GeneratedData);
            }
            else {
                EAM.MembersNewMemberAuditHistory.DateThru.SendKeys(GeneratedData);
            }   
            
           
        }


        [Then(@"Members Audit History Activity is set to ""(.*)""")]
        public void ThenMembersAuditHistoryActivityIsSetTo(string p0)
        {
            tmsWait.Hard(10);
            string xpath = "//label[contains(.," + p0.ToString() + ")]/input";
            Browser.Wd.FindElement(By.XPath(xpath)).Click();
            Browser.SwitchToChildWindow();
        }

        [Then(@"Members Audit History Return Action is set to ""(.*)""")]
        public void ThenMembersAuditHistoryReturnActionIsSetTo(string p0)
        {
            string xpath = "//label[contains(.," + p0.ToString() + ")]/input";
            Browser.Wd.FindElement(By.XPath(xpath)).Click();
        }


        [When(@"Members New Audit History Run button is clicked")]
        public void WhenMembersNewAuditHistoryRunButtonIsClicked()
        {
            fw.ExecuteJavascript(EAM.MembersNewMemberAuditHistory.RunButton);
            tmsWait.Hard(3);
        }

        [When(@"Members New Audit History expand link is clicked")]
        public void WhenMembersNewAuditHistoryExpandLinkIsClicked()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@title='Expand Details']")));
            tmsWait.Hard(3);
        }

        [When(@"Members New Audit History Field ""(.*)"" is displayed")]
        public void WhenMembersNewAuditHistoryFieldIsDisplayed(string p0)
        {
            string expected_data = tmsCommon.GenerateData(p0);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='jobProcessingStatus-grid-grdJobRequestInfo']//td[contains(.,'"+ expected_data + "')]")).Displayed, "Audit History Data is not displayed"); 
        }


        [When(@"Members New OOA Icon is clicked")]
        public void WhenMembersNewOOAIconIsClicked()
        {
            EAM.MembersNew.MemberOOAIcon.Click();
            tmsWait.Hard(2);
        }

        [When(@"Members New OOA AddNewSuspect button is clicked")]
        public void WhenMembersNewOOAAddNewSuspectButtonIsClicked()
        {
            EAM.MembersNew.MemberOOAAddNewSuspect.Click();
            tmsWait.Hard(1);
        }
        [When(@"Members New OOA dialog page Potential OOA checkbox is checked")]
        public void WhenMembersNewOOADialogPagePotentialOOACheckboxIsChecked()
        {
            EAM.MembersNew.MemberPotentialOOA_Checkbox.Click();
            tmsWait.Hard(1);
        }

        [When(@"Members New OOA dialog page Possible SCC checkbox is checked")]
        public void WhenMembersNewOOADialogPagePossibleSCCCheckboxIsChecked()
        {
            EAM.MembersNew.MemberPossibleSCC_Checkbox.Click();
            tmsWait.Hard(1);
        }

        [When(@"Members New OOA dialog page potential OOA letter checkbox is checked")]
        public void WhenMembersNewOOADialogPagePotentialOOALetterCheckboxIsChecked()
        {
            EAM.MembersNew.MemberPotentialOOALetter_Checkbox.Click();
            tmsWait.Hard(1);
        }

        [When(@"Members New OOA dialog page Continuing area checkbox is checked")]
        public void WhenMembersNewOOADialogPageContinuingAreaCheckboxIsChecked()
        {
            EAM.MembersNew.MemberOOAContinuingArea_Checkbox.Click();
            tmsWait.Hard(1);
        
        }

        [When(@"Members New OOA dialog page TravelersVisitorsProgram checkbox is checked")]
        public void WhenMembersNewOOADialogPageTravelersVisitorsProgramCheckboxIsChecked()
        {
            EAM.MembersNew.MemberOOATravelerVisitorsProgram_Checkbox.Click();
            tmsWait.Hard(1);
        }
        [When(@"Members New OOA dialog page ICEPConversion checkbox is checked")]
        public void WhenMembersNewOOADialogPageICEPConversionCheckboxIsChecked()
        {
            EAM.MembersNew.MemberOOAICEPConversion_Checkbox.Click();
            tmsWait.Hard(1);
            
        }

        [When(@"Members New OOA dialog page save button is clicked")]
        public void WhenMembersNewOOADialogPageSaveButtonIsClicked()
        {
            EAM.MembersNew.MemebrOOASaveButton.Click();
            IAlert alert = Browser.Wd.SwitchTo().Alert();
            alert.Accept();
            tmsWait.Hard(1);
        }

        [When(@"Members New OOA dialog page Close button is clicked")]
        public void WhenMembersNewOOADialogPageCloseButtonIsClicked()
        {
            EAM.MembersNew.MemberOOAClosebutton.Click();
            tmsWait.Hard(1);
        }

        [Then(@"I close New View Audit History popup")]
        public void ThenICloseNewViewAuditHistoryPopup()
        {
            EAM.MembersNewMemberAuditHistory.CloseButton.Click();
        }


        [Then(@"Verify Members New Audit History Result table has row")]
        public void ThenVerifyMembersNewAuditHistoryResultTableHasRow(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.MembersNewMemberAuditHistory.ResultTableHeader;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Members View Edit span Table has row: {0}", e.Message);
            }
        }


        [Then(@"Verify OSB Config History details Result table has row")]
        public void ThenVerifyOSBConfigHistoryDetailsResultTableHasRow(Table table)
        {
            tmsWait.Hard(10);
            try
            {
                IWebElement objWebTable = EAM.AdminEAMConfiguration.ResultTableOsbConfigHistory;
                
                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                        }
                    }
                }
            }

             
            catch (Exception e)
            {
                Assert.Fail("Osb Configuration History Table has row: {0}", e.Message);
            }
        }

        [Then(@"On executing query ""(.*)"" value of ""(.*)"" is returned ""(.*)""")]
        public void ThenOnExecutingQueryValueOfIsReturned(string myquery, string valueof, string expectedretrun)
        {
            string actualreturn;
            //string thisConnectionString = "user id=" + ConfigFile.DBUser + ";" +
            //                       "password=" + ConfigFile.DBPassword + ";" +
            //                       "Data Source=" + ConfigFile.DataServer + "," + ConfigFile.Port + ";" +
            //                       "Network Library=DBMSSOCN;" +
            //                       "Initial Catalog=" + ConfigFile.ERFdb + "; " +
            //                       "connection timeout=30";

            string thisConnectionString = "server=" + ConfigFile.DataServer + ";" + "database=" + ConfigFile.ERFdb + ";" + "user id=" + ConfigFile.DBUser + ";" + "password=" + ConfigFile.DBPassword + ";" + "Max Pool Size=9000;" + "Connection Timeout=150;" + "Min Pool Size=2";
            string sql = myquery;
            using (SqlConnection conn = new SqlConnection(thisConnectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@" + valueof + "", 1);
                try
                {
                    conn.Open();
                    actualreturn = cmd.ExecuteScalar().ToString();
                    Assert.AreEqual(actualreturn, expectedretrun, "Total number of records in the file does not matches with records in data base");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                      
                }
            }
        }

        [When(@"Members View Edit Page Language is set to ""(.*)""")]
        public void WhenMembersViewEditPageLanguageIsSetTo(string p0)
        {
            SelectElement lang = new SelectElement(EAM.MembersNew.Language);
            lang.SelectByText(p0);
        }


        [When(@"MembersNew Paymenttab Plan(.*) is set to ""(.*)""")]
        public void WhenMembersNewPaymenttabPlanIsSetTo(int p0, string p1)
        {
            EAM.MembersNewTabPayment.Plan10.SendKeys(p1);
        }

        [When(@"MembersNew Paymenttab plan(.*)checkbox is clicked")]
        public void WhenMembersNewPaymenttabPlancheckboxIsClicked(int p0)
        {
            fw.ExecuteJavascript(EAM.MembersNewTabPayment.SendPlan10OnLegacy);
        }

    }
}