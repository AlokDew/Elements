﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
//using System.Windows.Forms;
using TechTalk.SpecFlow;
using TMSoR1;

namespace TMSoR
{
    [Binding]
    class fsDupeLogic
    {
        public string setCheckboxTo;

        [Given(@"I Click on TMSLogo")]
        public void GivenIclickOnTMSLogo()
        {
            IWebElement TZLogo = Browser.Wd.FindElement(By.Id("Navigation1_ProductMenu1_Menu1-menuItem000"));
            TZLogo.Click();
        }

        [Given(@"I navigate to ""(.*)""")]
        public void GivenINavigateTo(string p0)
        {
            tmsWait.Implicit(3);
            IWebElement AdministrationPage = Browser.Wd.FindElement(By.Id("Navigation1_ProductMenu1_Menu1-menuItem000-subMenu-menuItem000"));
            AdministrationPage.Click();
        }

        [When(@"Enhance Member Dupe Check box is ""(.*)""")]
        public void WhenEnhanceMemberDupeCheckCheckBoxIs(string p0)
        {
            string GenerateData = tmsCommon.GenerateData(p0);


            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("UnChecked"))
            {
                
                if (EAM.AdministrationPage.EnhanceMemberDupeCheck.Selected == true)
                {
                    EAM.AdministrationPage.EnhanceMemberDupeCheck.Click();
                }
                
            }
            else if (setCheckboxTo.Equals("checked"))
            {                
                if (EAM.AdministrationPage.EnhanceMemberDupeCheck.Selected == false)
                {
                    EAM.AdministrationPage.EnhanceMemberDupeCheck.Click();
                }                
            }
        }

        [Then(@"Verify Administration Page Alert diplays message ""(.*)""")]
        public void ThenVerifyAdministrationPageAlertDiplaysMessage(string dbAppUpdateMessage)
        {
            tmsWait.WaitForAlertPresent(20);
            dbAppUpdateMessage = tmsCommon.GenerateData(dbAppUpdateMessage);
            string databaseUpdate = Browser.Wd.SwitchTo().Alert().Text;
            Console.WriteLine("Expected Alert message [" + dbAppUpdateMessage + "] was found in dialog text [" + databaseUpdate + "]");
            IAlert alert = Browser.Wd.SwitchTo().Alert();
            alert.Accept();
        }


        [When(@"Administration page Workflow Configuration Name as ""(.*)"" is selected")]
        public void WhenAdministrationPageWorkflowConfigurationNameAsIsSelected(string configName)
        {
            SelectElement workflow = new SelectElement(EAM.AdministrationPage.WorkFlowConfigurationName);
            workflow.SelectByText(configName);
        }


        [When(@"Administration page ""(.*)"" is ""(.*)""")]
        public void WhenAdministrationPageIs(string option, string action)
        {
            switch(option.ToLower())
            {
                case "enable workflow":
                    if (action.ToLower().Equals("checked"))
                    {
                        if(!EAM.AdministrationPage.WorkFlowEnable.Selected)
                        EAM.AdministrationPage.WorkFlowEnable.Click();
                    }
                    break;
            }
        }

        [When(@"Administration page DB Password is set to ""(.*)""")]
        public void WhenAdministrationPageDBPasswordIsSetTo(string DbPassword)
        {
            string databasePassword = tmsCommon.GenerateData(DbPassword);
            EAM.AdministrationPage.DbPassword.SendKeys(databasePassword);
        }

        [When(@"Administration page EAMdb Password is set to ""(.*)""")]
        public void WhenAdministrationPageEAMdbPasswordIsSetTo(string DbPassword)
        {
            string databasePassword = tmsCommon.GenerateData(DbPassword);
            EAM.AdministrationPage.DbPassword.SendKeys(databasePassword);
        }

        [When(@"Administration Page Database Name is set to ""(.*)""")]
        public void WhenAdministrationPageDatabaseNameIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            EAM.AdministrationPage.DatabaseName.SendKeys(value);
        }
        [When(@"Administration Page Database Server is set to ""(.*)""")]
        public void WhenAdministrationPageDatabaseServerIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            EAM.AdministrationPage.DatabaseServer.SendKeys(value);
        }
        [When(@"Administration Page Authentication is set to ""(.*)""")]
        public void WhenAdministrationPageAuthenticationIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.AdministrationPage.Authentication);
            select.SelectByText(value);
            tmsWait.Hard(2);

        }

        [When(@"Administration Page Database User is set to ""(.*)""")]
        public void WhenAdministrationPageDatabaseUserIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            EAM.AdministrationPage.DatabaseUser.SendKeys(value);
        }
        [When(@"Administration page Database Password is set to ""(.*)""")]
        public void WhenAdministrationPageDatabasePasswordIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            EAM.AdministrationPage.DatabasePassword.SendKeys(value);
        }

        [When(@"Administration Page Output Folder is set to ""(.*)""")]
        public void WhenAdministrationPageOutputFolderIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            EAM.AdministrationPage.OutputFolder.SendKeys(value);
        }
        [When(@"Administration Page Attachment Folder is set to ""(.*)""")]
        public void WhenAdministrationPageAttachmentFolderIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            EAM.AdministrationPage.AttachmentFolder.SendKeys(value);
        }
        [When(@"Administration Page Letter Folder is set to ""(.*)""")]
        public void WhenAdministrationPageLetterFolderIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            EAM.AdministrationPage.LetterFolder.SendKeys(value);
        }

        [When(@"Administration Page Enable TCS Checkbox is checked")]
        public void WhenAdministrationPageEnableTCSCheckboxIsChecked()
        {
            EAM.AdministrationPage.EnableTCSCheckbox.Click();
            tmsWait.Hard(2);
            try
            {
                IAlert alert = Browser.Wd.SwitchTo().Alert();
                alert.Accept();
            }
            catch
            { }
            tmsWait.Hard(1);

        }
        [When(@"Administration Page TCS Configuration Name is set to ""(.*)""")]
        public void WhenAdministrationPageTCSConfigurationNameIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.AdministrationPage.TCSConfigurationName);
            select.SelectByText(value);
            tmsWait.Hard(2);
        }

        [When(@"Administration Page TCS Process Service is set to ""(.*)""")]
        public void WhenAdministrationPageTCSProcessServiceIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            EAM.AdministrationPage.TCSProcessService.Clear();
            EAM.AdministrationPage.TCSProcessService.SendKeys(value);
        }
        [When(@"Administration Page TCS Inquiry Service is set to ""(.*)""")]
        public void WhenAdministrationPageTCSInquiryServiceIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            EAM.AdministrationPage.TCSInquiryService.Clear();
            EAM.AdministrationPage.TCSInquiryService.SendKeys(value);
        }

        [When(@"Administration page ERF Database Password is set to ""(.*)""")]
        public void WhenAdministrationPageERFDatabasePasswordIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            EAM.AdministrationPage.ERFDBPassword.SendKeys(value);
        }

        [When(@"Administration page ERF Database User is set to ""(.*)""")]
        public void WhenAdministrationPageERFDatabaseUserIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            EAM.AdministrationPage.ERFDatabaseUser.SendKeys(value);
        }

        [When(@"Administration page ERF Database Server is set to ""(.*)""")]
        public void WhenAdministrationPageERFDatabaseServerIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            EAM.AdministrationPage.ERFDatabaseServer.SendKeys(value);
        }

        [When(@"Administration page ERF Database Name is set to ""(.*)""")]
        public void WhenAdministrationPageERFDatabaseNameIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            EAM.AdministrationPage.ERFDatabaseName.SendKeys(value);
        }
        [When(@"Administration page Enable Workflow Checkbox is Checked")]
        public void WhenAdministrationPageEnableWorkflowCheckboxIsChecked()
        {

            EAM.AdministrationPage.WorkFlowEnable.Click();
            tmsWait.Hard(2);

            //Boolean isVisible = false;
            //string cbValue = "off";
            //try
            //{
            //    isVisible = EAM.AdministrationPage.WorkFlowEnable.Displayed;
            //    //        cbValue = EAM.AdministrationPage.EnrollmentRequestForm.GetAttribute("value");
            //}
            //catch
            //{ }
            //if (!isVisible)
            //{
            //    EAM.AdministrationPage.WorkFlowEnable.Click();
            //    tmsWait.Hard(2);
            //}
        }
        [When(@"Administration page Workflow Configuration Name is set to ""(.*)""")]
        public void WhenAdministrationPageWorkflowConfigurationNameIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.AdministrationPage.WorkFlowConfigurationName);
            select.SelectByText(value);
            tmsWait.Hard(2);
        }

        [When(@"Administration page Enrollment Request Form Checkbox is Checked")]
        public void WhenAdministrationPageEnrollmentRequestFormCheckboxIsChecked()
        {
//#daronerf
            Boolean isVisible = false;
            try
            {
                isVisible = EAM.AdministrationPage.ERFDatabaseName.Displayed;
        //        cbValue = EAM.AdministrationPage.EnrollmentRequestForm.GetAttribute("value");
            }
            catch 
            { }
            if (!isVisible)
            {
                EAM.AdministrationPage.EnrollmentRequestForm.Click();
                tmsWait.Hard(2);
            }
        }

        [When(@"Administration Page TCS Administration Service is set to ""(.*)""")]
        public void WhenAdministrationPageTCSAdministrationServiceIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            EAM.AdministrationPage.TCSAdministrationService.Clear();
            EAM.AdministrationPage.TCSAdministrationService.SendKeys(value);
        }
        [When(@"Administration Page Add Database Button is clicked")]
        public void WhenAdministrationPageAddDatabaseButtonIsClicked()
        {
            EAM.AdministrationPage.AddDatabase.Click();
            tmsWait.Hard(2);
        }
        [When(@"Administration Page Assign Application is clicked")]
        public void WhenAdministrationPageAssignApplicationIsClicked()
        {
            EAM.AdministrationPage.AssignApplication.Click();
            tmsWait.Hard(5);
        }

        [When(@"Administration Page Input Folder is set to ""(.*)""")]
        public void WhenAdministrationPageInputFolderIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            EAM.AdministrationPage.InputFolder.SendKeys(value);
        }

        [When(@"Administration page ERFDB Password is set to ""(.*)""")]
        public void WhenAdministrationPageERFDBPasswordIsSetTo(string DbPassword)
        {
            string databasePassword = tmsCommon.GenerateData(DbPassword);
            try
            {
                EAM.AdministrationPage.ERFDBPassword.SendKeys(databasePassword);
            }
            catch
            { }
        }

        [Given(@"I click on TMS-QA Details link")]
        [When(@"I click on TMS-QA Details link")]
        [Then(@"I click on TMS-QA Details link")]
        public void GivenIClickOnTMS_QADetailsLink()
        {
            IList<IWebElement> theseDetailLinks = Browser.Wd.FindElements(By.LinkText("Details"));
            theseDetailLinks[1].Click();
            tmsWait.Hard(1);
        }


        [Given(@"I click on TMS Details link")]
        [Then(@"I click on TMS Details link")]
        public void GivenIClickOnTMSDetailsLink()
        {
            IList<IWebElement> theseDetailLinks = Browser.Wd.FindElements(By.LinkText("Details"));
            theseDetailLinks[0].Click();
            tmsWait.Hard(1);
        }

        [Given(@"Administration New User Add New User Link is clicked")]
        public void GivenAdministrationNewUserAddNewUserLinkIsClicked()
        {
            EAM.UserAdministrationCrudUser.AddNewUser.Click();
            tmsWait.Hard(3);
        }

        [When(@"Administration Add an Application Link is Clicked")]
        public void WhenAdministrationAddAnApplicationLinkIsClicked()
        {
            tmsWait.Hard(1);
            EAM.AdministrationPage.AddAnApplicationLink.Click();
            tmsWait.Hard(2);
        }
        [When(@"Administration New User Client List is set to ""(.*)""")]
        public void WhenAdministrationNewUserClientListIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.UserAdministrationCrudUser.ClientListDropdown);
            select.SelectByText(value);
            tmsWait.Hard(3);

        }
        [When(@"Administration New User ID fields is set to ""(.*)""")]
        public void WhenAdministrationNewUserIDFieldsIsSetTo(string p0)
        {
            string GD = tmsCommon.GenerateData(p0); 
            EAM.UserAdministrationCrudUser.UserID.SendKeys(GD);
        }
        [When(@"Administration New Password is set to ""(.*)""")]
        public void WhenAdministrationNewPasswordIsSetTo(string p0)
        {
            string GD = tmsCommon.GenerateData(p0);
            EAM.UserAdministrationCrudUser.Password.SendKeys(GD);
        }
        [When(@"Administration New Confirm Password is set to ""(.*)""")]
        public void WhenAdministrationNewConfirmPasswordIsSetTo(string p0)
        {
            string GD = tmsCommon.GenerateData(p0);
            EAM.UserAdministrationCrudUser.ConfirmPassword.SendKeys(GD);
        }
        [When(@"Administration New First Name is set to ""(.*)""")]
        public void WhenAdministrationNewFirstNameIsSetTo(string p0)
        {
            string GD = tmsCommon.GenerateData(p0);
            EAM.UserAdministrationCrudUser.FirstName.SendKeys(GD);
        }
        [When(@"Administration New Last Name is set to ""(.*)""")]
        public void WhenAdministrationNewLastNameIsSetTo(string p0)
        {
            string GD = tmsCommon.GenerateData(p0);
            EAM.UserAdministrationCrudUser.LastName.SendKeys(GD);
        }
        [When(@"Administration New Active is set to ""(.*)""")]
        public void WhenAdministrationNewActiveIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.UserAdministrationCrudUser.Active);
            select.SelectByText(value);
            tmsWait.Hard(2);
        }
        [When(@"Checkbox (.*) clicked")]
        public void WhenCheckboxClicked(int p0)
        {
            Browser.Wd.FindElement(By.Id("AssignedAppsGridView_enableAppForThisUser_0")).Click();
            Browser.Wd.FindElement(By.Id("AssignedAppsGridView_setAsDefault_0")).Click();
            SelectElement select = new SelectElement(Browser.Wd.FindElement(By.Id("AssignedAppsGridView_ddlAccessLevel_0")));
            select.SelectByText("Client Admin");
        }

        [When(@"Database ""(.*)"" is hooked up as administrator")]
        public void WhenDatabaseIsHookedUpAsAdministrator(string p0)
        {
            string thisSuffix = tmsCommon.GenerateData(p0);
            IWebElement baseTable = Browser.Wd.FindElement(By.Id("AssignedAppsGridView"));
            IWebElement basebody = baseTable.FindElement(By.TagName("tbody"));
            IList<IWebElement> AllTRs = basebody.FindElements(By.TagName("tr"));
            foreach (IWebElement thisTR in AllTRs)
            {
                IList<IWebElement> localTDs = thisTR.FindElements(By.TagName("td"));
                foreach (IWebElement thisTD in localTDs)
                {
                    string thisDatabase = localTDs[6].Text;
                    if (thisTD.Text.Contains("Grid_"+thisSuffix))
                    {
                        localTDs[1].Click();
                        IWebElement thisSpan = localTDs[0].FindElement(By.TagName("input"));

                        thisSpan.Click();
                        IWebElement thisSelectRole = localTDs[5].FindElement(By.TagName("select"));
                        SelectElement select = new SelectElement(thisSelectRole);
                        select.SelectByText("Administrator");


                    }
                }
            }
        }


        [When(@"Administration Application dropdown is set to ""(.*)""")]
        public void WhenAdministrationApplicationDropdownIsSetTo(string p0)
        {

            string value = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.AdministrationPage.ApplicationDropdown);
            select.SelectByText(value);
            tmsWait.Hard(2);
        }

        [When(@"Administration NextButton is clicked")]
        public void WhenAdministrationNextButtonIsClicked()
        {
            EAM.AdministrationPage.NextButton.Click();
            tmsWait.Hard(2);
        }
        [When(@"Administration Add a New Database Link is Clicked")]
        public void WhenAdministrationAddANewDatabaseLinkIsClicked()
        {
            EAM.AdministrationPage.AddANewDatabaseLink.Click();
            tmsWait.Hard(2);
        }

        [When(@"Administration Page Update Database Button is clicked")]
        public void WhenAdministrationPageUpdateDatabaseButtonIsClicked()
        {
            tmsWait.Hard(1);
            EAM.AdministrationPage.UpdateDatabase.Click();
            tmsWait.Hard(3);
        }        
    }
}
