﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Text;
//using System.Windows.Forms;
using TechTalk.SpecFlow;
using TMSoR1.FrameworkCode;
using TMSoR1.FrameworkCode.ADFS;

namespace TMSoR1
{
    [Binding]
    public class appLogin
    {

        [Given(@"I Opened Elements Application Login page")]
        public void GivenIOpenedElementsApplicationLoginPage()
        {
            ConfigFile.ReadFromConfigFile();
            Console.WriteLine("Begin Navigate");
            Browser.SetWebdriverType(ConfigFile.BrowserType);
            Console.WriteLine("Finished SetWebdriverType to config file browser type");            
            tmsWait.Hard(5);
            Browser.Wd.Manage().Window.Maximize();
            Console.WriteLine("Finished Window Maximize");
            Browser.Wd.Navigate().GoToUrl(ConfigFile.URL);
        }

        [Given(@"I entered user name as ""(.*)"" Password as ""(.*)""")]
        public void GivenIEnteredUserNameAsPasswordAs(string username, string password)
        {
            tmsWait.Hard(5);
            EAM.EAMLogin.UserID.Clear();
            EAM.EAMLogin.UserID.SendKeys(username);
            EAM.EAMLogin.Password.Clear();
            EAM.EAMLogin.Password.SendKeys(password);
            fw.ExecuteJavascript(EAM.EAMLogin.Submit);
        }

        [Then(@"Verify Error message ""(.*)"" is displayed successfully")]
        public void ThenVerifyErrorMessageIsDisplayedSuccessfully(string p0)
        {
            tmsWait.Hard(5);
            IWebElement errorMsg = Browser.Wd.FindElement(By.XPath("//div[contains(.,'"+p0+"')]"));
            Assert.IsTrue(errorMsg.Displayed, "Expected Error message is not getting displayed");
        }

        [Then(@"Verify Add New User page Error message ""(.*)"" is displayed")]
        public void ThenVerifyAddNewUserPageErrorMessageIsDisplayed(string p0)
        {
            try { 
            tmsWait.Hard(5);
            IWebElement errorMsg = Browser.Wd.FindElement(By.XPath("//span[contains(.,'"+ p0 + "')]"));
            Assert.IsTrue(errorMsg.Displayed, "Expected Error message is not getting displayed");
            }catch
            {
                IWebElement errorMsg = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]"));
                Assert.IsTrue(errorMsg.Displayed, "Expected Error message is not getting displayed");
            }
        }
        [Then(@"Verify Error message ""(.*)"" displayed for Password mismatch")]
        public void ThenVerifyErrorMessageDisplayedForPasswordMismatch(string p0)
        {
            IWebElement errorMsg = Browser.Wd.FindElement(By.XPath("//span[contains(.,'New password and confirm password should be same')]"));
            Assert.IsTrue(errorMsg.Displayed, p0+"Error message is not getting displayed");
        }


        [Then(@"Verify Add New User page Error toaster message ""(.*)"" is displayed")]
        public void ThenVerifyAddNewUserPageErrorToasterMessageIsDisplayed(string p0)
        {
           
           // IWebElement errorMsg = Browser.Wd.FindElement(By.XPath("//div[@class='toast-message'][contains(.,'"+p0+"')]"));
           // Assert.IsTrue(errorMsg.Displayed, "Expected Error message is not getting displayed");
        }
        [Then(@"Edit Application Role for existing User ""(.*)"" and Role is set as ""(.*)""")]
        public void ThenEditApplicationRoleForExistingUserAndRoleIsSetAs(string p0, string p1)
        {

            string user = tmsCommon.GenerateData(p0);
            string role = tmsCommon.GenerateData(p1);
            IWebElement lastpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']"));
            fw.ExecuteJavascript(lastpage);
            tmsWait.Hard(2);
            IWebElement edituser = Browser.Wd.FindElement(By.XPath("//table//tr/td[contains(.,'" + user + "')]/following-sibling::td/a"));
            fw.ExecuteJavascript(edituser);
            tmsWait.Hard(2);
            tmsWait.Hard(2);
           
            SelectElement select = new SelectElement(EAM.UserAdministrationCrudUser.TmsServerList);
            select.SelectByText(role);
            tmsWait.Hard(2);
            IWebElement save = Browser.Wd.FindElement(By.XPath("(//a[@role='button'])[2]"));
            fw.ExecuteJavascript(save);

            IWebElement msg = Browser.Wd.FindElement(By.XPath("//div[@class='toast-message']"));
            string actualResults = msg.Text;
            string expResults = "Application Updated Successfully";
            Assert.AreEqual(expResults, actualResults, "Both are not getting matched");
        }

        [Given(@"Edit Application Role for existing User ""(.*)""")]
        public void GivenEditApplicationRoleForExistingUser(string p0)
        {
            string user = tmsCommon.GenerateData(p0);
            IWebElement lastpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']"));
            fw.ExecuteJavascript(lastpage);
            tmsWait.Hard(2);
            IWebElement edituser = Browser.Wd.FindElement(By.XPath("//table//tr/td[contains(.,'" + user + "')]/following-sibling::td/a"));
            fw.ExecuteJavascript(edituser);
            tmsWait.Hard(2);
            IWebElement edit = Browser.Wd.FindElement(By.XPath("(//a[@role='button'])[2]"));
            fw.ExecuteJavascript(edit);
            tmsWait.Hard(2);
            IWebElement appDrp = Browser.Wd.FindElement(By.XPath("(//span[@class='k-dropdown-wrap k-state-default'])[1]"));
            fw.ExecuteJavascript(appDrp);
           
            IWebElement selectDB = Browser.Wd.FindElement(By.XPath("//ul[@data-role='staticlist']/li[contains(.,'User')]"));
            fw.ExecuteJavascript(selectDB);
            IWebElement save = Browser.Wd.FindElement(By.XPath("(//a[@role='button'])[2]"));
            fw.ExecuteJavascript(save);

            IWebElement msg = Browser.Wd.FindElement(By.XPath("//div[@class='toast-message']"));
            string actualResults = msg.Text;
            string expResults = "Application Updated Successfully";
            Assert.AreEqual(expResults, actualResults, "Both are not getting matched");
        }


        [Given(@"Delete Entered Application Role for User ""(.*)""")]
        public void GivenDeleteEnteredApplicationRoleForUser(string p0)
        {
            string user = tmsCommon.GenerateData(p0);
            IWebElement lastpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']"));
            fw.ExecuteJavascript(lastpage);
            tmsWait.Hard(2);
            IWebElement edituser = Browser.Wd.FindElement(By.XPath("//table//tr/td[contains(.,'"+ user + "')]/following-sibling::td/a"));
            fw.ExecuteJavascript(edituser);
            tmsWait.Hard(2);
            IWebElement role = Browser.Wd.FindElement(By.XPath("//div[@id='applicationAndRolesGrid']//a[@role='button'][2]"));
            fw.ExecuteJavascript(role);
            tmsWait.Hard(2);
            IWebElement msg = Browser.Wd.FindElement(By.XPath("//div[@class='toast-message']"));
            string actualResults = msg.Text;
            string expResults = "Application Deleted Successfully";
            Assert.AreEqual(expResults, actualResults, "Both are not getting matched");

        }
        [Given(@"Administration New User Delete ""(.*)"" application for Existing user ""(.*)""")]
        public void GivenAdministrationNewUserDeleteApplicationForExistingUser(string p0, string p1)
        {
            string user = tmsCommon.GenerateData(p1);
            IWebElement lastpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']"));
            fw.ExecuteJavascript(lastpage);
            tmsWait.Hard(2);
            IWebElement edituser = Browser.Wd.FindElement(By.XPath("//table//tr/td[contains(.,'" + user + "')]/following-sibling::td/a"));
            fw.ExecuteJavascript(edituser);
            tmsWait.Hard(2);
            IWebElement delete = Browser.Wd.FindElement(By.XPath("//span[text()='" + p0 + "']/parent::td/following-sibling::td/a[contains(@class,'delete')]"));
            
            fw.ExecuteJavascript(delete);
            tmsWait.Hard(2);
            IWebElement update = Browser.Wd.FindElement(By.XPath("//button[@ng-click='editUser()']"));
            fw.ExecuteJavascript(update);
        }

        [Given(@"User Management page Existing user ""(.*)"" is Edited")]
        public void GivenUserManagementPageExistingUserIsEdited(string p0)
        {
            string user = tmsCommon.GenerateData(p0);
            IWebElement lastpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']"));
            fw.ExecuteJavascript(lastpage);
            tmsWait.Hard(2);
            IWebElement edituser = Browser.Wd.FindElement(By.XPath("//table//tr/td[contains(.,'" + user + "')]/following-sibling::td/a"));
            fw.ExecuteJavascript(edituser);
            tmsWait.Hard(2);
        }


        [Given(@"Administration New User Active Option button is set to ""(.*)"" for Existing user ""(.*)""")]
        public void GivenAdministrationNewUserActiveOptionButtonIsSetToForExistingUser(string p0, string p1)
        {
            string user = tmsCommon.GenerateData(p1);
            IWebElement lastpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']"));
            fw.ExecuteJavascript(lastpage);
            tmsWait.Hard(2);
            IWebElement edituser = Browser.Wd.FindElement(By.XPath("//table//tr/td[contains(.,'" + user + "')]/following-sibling::td/a"));
            fw.ExecuteJavascript(edituser);
            tmsWait.Hard(2);
            IWebElement InActive = Browser.Wd.FindElement(By.XPath("//label[@for='inActiveUser']"));
            fw.ExecuteJavascript(InActive);
            IWebElement update = Browser.Wd.FindElement(By.XPath("//button[@ng-click='editUser()']"));
            fw.ExecuteJavascript(update);
            tmsWait.Hard(1);
            IWebElement toaster = Browser.Wd.FindElement(By.XPath("//div[contains(.,'User updated successfully')]"));
            Assert.IsTrue(toaster.Displayed, "Expected Error message is not getting displayed");

        }

        [Given(@"Administration New User Change Password ""(.*)"" for existing User ""(.*)""")]
        public void GivenAdministrationNewUserChangePasswordForExistingUser(string p0, string p1)
        {
            
        }

       
        [Given(@"Administration New User Change Password for existing User ""(.*)""")]
        [When(@"Administration New User Change Password for existing User ""(.*)""")]
        [Then(@"Administration New User Change Password for existing User ""(.*)""")]
        public void GivenAdministrationNewUserChangePasswordForExistingUser(string p0)
        {
            string user = tmsCommon.GenerateData(p0);
            IWebElement lastpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']"));
            fw.ExecuteJavascript(lastpage);
            tmsWait.Hard(2);
            IWebElement edituser = Browser.Wd.FindElement(By.XPath("//table//tr/td[contains(.,'" + user + "')]/following-sibling::td/a"));
            fw.ExecuteJavascript(edituser);
            tmsWait.Hard(2);
            IWebElement changePassword = Browser.Wd.FindElement(By.CssSelector("[test-id='addUserTab-tab-changePassword']"));
            fw.ExecuteJavascript(changePassword);
            tmsWait.Hard(2);
            IWebElement newpwd = Browser.Wd.FindElement(By.XPath("(//input[@type='password'])[1]"));
            newpwd.Clear();
            newpwd.SendKeys("P@ssw0rd@321");
            IWebElement confpwd = Browser.Wd.FindElement(By.XPath("(//input[@type='password'])[2]"));
            confpwd.Clear();
            confpwd.SendKeys("P@ssw0rd@321");
            tmsWait.Hard(2);
            IWebElement update = Browser.Wd.FindElement(By.XPath("//button[contains(text(),'UPDATE') and @ng-click='changePassword()']"));
            fw.ExecuteJavascript(update);
            tmsWait.Hard(1);
            IWebElement errorMsg1 = Browser.Wd.FindElement(By.XPath("//*[@class='toast-message'][contains(.,'Password changed successfully')]"));
            Assert.IsTrue(errorMsg1.Displayed, "Expected Error message is not getting displayed");
            tmsWait.Hard(1);
        }




        [Given,When(@"I am logged in to EAM with userid ""(.*)"" and Password ""(.*)""")]
        [When(@"I am logged in to EAM with userid ""(.*)"" and Password ""(.*)""")]
        [Given(@"I am logged in to EAM with userid ""(.*)"" and Password ""(.*)""")]
        public void GivenIAmLoggedInToEAMWithUseridAndPassword(string p0, string pass)
        {
            string pwd = tmsCommon.GenerateData(pass);
            tmsWait.Hard(2);
            //if (p0.Equals("tmsapp") && pwd.Equals("Welcome1"))
            //{
            //    string GeneratedUserID = tmsCommon.GenerateData(p0);
            //    ConfigFile.ReadFromConfigFile();
            //    Console.WriteLine("Begin Navigate");
            //    Browser.SetWebdriverType(ConfigFile.BrowserType);
            //    Console.WriteLine("Finished SetWebdriverType to config file browser type");
            //    Browser.Wd.Manage().Window.Maximize();
            //    Console.WriteLine("Finished Window Maximize");
            //    string IDMURL = ConfigFile.URL.Replace("44330/tms", "44330/idm");               
            //    Browser.Wd.Navigate().GoToUrl(IDMURL);
            //    tmsWait.Implicit(30);
            //    tmsWait.Hard(2);
            //    EAM.EAMLogin.UserID.Clear();
            //    EAM.EAMLogin.UserID.SendKeys(GeneratedUserID);
            //    EAM.EAMLogin.Password.Clear();
            //    EAM.EAMLogin.Password.SendKeys(pwd);
            //    EAM.EAMLogin.Submit.Click();
            //    tmsWait.Implicit(10);
            //}
            if ((p0.Equals("tmsapp") && pwd.Equals("Welcome1")) || (p0.Equals("tmsadmin") && pwd.Equals("Welcome@123"))|| (p0.Equals("tmsapp") && pwd.Equals("Welcome@123")))
            {
                string GeneratedUserID = tmsCommon.GenerateData(p0);
                ConfigFile.ReadFromConfigFile();
                Console.WriteLine("Begin Navigate");
                Browser.SetWebdriverType(ConfigFile.BrowserType);
                Console.WriteLine("Finished SetWebdriverType to config file browser type");
                Browser.Wd.Manage().Window.Maximize();
                Console.WriteLine("Finished Window Maximize");
                Browser.Wd.Navigate().GoToUrl(ConfigFile.URL);
                tmsWait.Implicit(15);


                if (ConfigFile.BrowserType.Equals("edge") || ConfigFile.BrowserType.Equals("chrome") || ConfigFile.BrowserType.Equals("edgelegacy") || ConfigFile.BrowserType.Equals("edgechrome"))
                {
                    try
                    {
                        IWebElement advancedButton = Browser.Wd.FindElement(By.CssSelector("[id='details-button']"));
                        fw.ExecuteJavascript(advancedButton);
                        tmsWait.Hard(5);

                        IWebElement acceptRiskBtn = Browser.Wd.FindElement(By.CssSelector("[id='proceed-link']"));
                        fw.ExecuteJavascript(acceptRiskBtn);
                        tmsWait.Hard(10);

                        IWebElement advancedButton1 = Browser.Wd.FindElement(By.CssSelector("[id='details-button']"));
                        fw.ExecuteJavascript(advancedButton1);
                        tmsWait.Hard(5);

                        IWebElement acceptRiskBtn1 = Browser.Wd.FindElement(By.CssSelector("[id='proceed-link']"));
                        fw.ExecuteJavascript(acceptRiskBtn1);

                    }
                    catch
                    {
                        try
                        {
                            IWebElement continueBtn = Browser.Wd.FindElement(By.PartialLinkText("Continue to this webpage"));
                            fw.ExecuteJavascript(continueBtn);
                            tmsWait.Hard(5);
                        }
                        catch
                        {

                            fw.ConsoleReport("There is no Certiicate Warning");
                        }
                    }
                }


                if (ConfigFile.BrowserType.Equals("firefox"))
                {
                    try
                    {
                        IWebElement advancedButton = Browser.Wd.FindElement(By.Id("advancedButton"));
                        fw.ExecuteJavascript(advancedButton);
                        tmsWait.Hard(5);

                        IWebElement acceptRiskBtn = Browser.Wd.FindElement(By.Id("exceptionDialogButton"));
                        fw.ExecuteJavascript(acceptRiskBtn);
                        tmsWait.Hard(10);

                        IWebElement advancedButton1 = Browser.Wd.FindElement(By.Id("advancedButton")); // Due to Stale Element reference Exception, we created Duplicate statement
                        fw.ExecuteJavascript(advancedButton1);
                        tmsWait.Hard(5);

                        IWebElement acceptRiskBtn1 = Browser.Wd.FindElement(By.Id("exceptionDialogButton"));
                        fw.ExecuteJavascript(acceptRiskBtn1);
                        tmsWait.Hard(10);

                    }
                    catch
                    {
                        fw.ConsoleReport("There is no Warning: Potential Security Risk Ahead");
                    }
                }

                if (ConfigFile.BrowserType.Equals("ie"))
                {
                    try
                    {
                        IWebElement Moreinformation = Browser.Wd.FindElement(By.LinkText("More information"));
                        fw.ExecuteJavascript(Moreinformation);
                        tmsWait.Hard(2);

                        IWebElement Goontothewebpage = Browser.Wd.FindElement(By.PartialLinkText("Go on to the webpage"));
                        fw.ExecuteJavascript(Goontothewebpage);
                        tmsWait.Hard(10);


                        IWebElement Moreinformation1 = Browser.Wd.FindElement(By.LinkText("More information"));
                        fw.ExecuteJavascript(Moreinformation1);
                        tmsWait.Hard(2);

                        IWebElement Goontothewebpage1 = Browser.Wd.FindElement(By.PartialLinkText("Go on to the webpage"));
                        fw.ExecuteJavascript(Goontothewebpage1);

                    }
                    catch
                    {
                        fw.ConsoleReport(" There is no App Server Certificate Issue");
                    }
                }
                    tmsWait.Hard(2);
                EAM.EAMLogin.UserID.Clear();
                EAM.EAMLogin.UserID.SendKeys(ConfigFile.UserId);
                EAM.EAMLogin.Password.Clear();
                EAM.EAMLogin.Password.SendKeys(ConfigFile.Password);
                EAM.EAMLogin.Submit.Click();
                tmsWait.Implicit(10);

                By error = By.XPath("//strong[contains(.,'Error')]");

                try
                {
                    if (Browser.Wd.FindElement(error).Displayed)
                    {
                        EAM.EAMLogin.UserID.Clear();
                        EAM.EAMLogin.UserID.SendKeys(ConfigFile.UserId);
                        EAM.EAMLogin.Password.Clear();
                        EAM.EAMLogin.Password.SendKeys(ConfigFile.Password);
                        EAM.EAMLogin.Submit.Click();
                        tmsWait.Hard(10);
                    }
                }
                catch
                {

                }

                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Root Administration']")));
                    tmsWait.Hard(3);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'External Systems')]")));
                    tmsWait.Hard(2);
                    fw.ExecuteJavascript(EAM.EAMLogin.AngularIdentityServer);
                }
                else
                {
                    fw.ExecuteJavascript(EAM.EAMLogin.IdentityServer);
                }
                   
                string tenantName = "Identity Server_"+ ((ConfigFile.URL.Split('.'))[0].Split(':'))[1].Substring(2);
                string splTenantName = "Identity Server_" + ((ConfigFile.URL.Split('.'))[0].Split(':'))[1].Substring(2).ToUpper();
                tmsWait.Hard(2);
                try
                {
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By path = By.XPath("//*[@id='grdIdsConfiguration']//td[contains(.,'" + tenantName + "')]/following-sibling::td/a[1]");
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(path);
                    }
                    else
                    {
                        By path = By.XPath("//div[@test-id='identityserver-grid-grdidentityserver']//td[contains(.,'" + tenantName + "')]/following-sibling::td/a[1]");
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(path);
                    }
                }
                catch
                {
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By path = By.XPath("//*[@id='grdIdsConfiguration']//td[contains(.,'" + splTenantName + "')]/following-sibling::td/a[1]");
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(path);
                    }
                    else
                    {
                        By path = By.XPath("//div[@test-id='identityserver-grid-grdidentityserver']//td[contains(.,'" + splTenantName + "')]/following-sibling::td/a[1]");
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(path);

                    }
                       
                }
                tmsWait.Hard(10);
                Browser.SwitchToWindow(1);
                tmsWait.Hard(20);
            }
            else
            {
                string GeneratedUserID = tmsCommon.GenerateData(p0);
                ConfigFile.ReadFromConfigFile();
                Console.WriteLine("Begin Navigate");
                Browser.SetWebdriverType(ConfigFile.BrowserType);
                Console.WriteLine("Finished SetWebdriverType to config file browser type");
                tmsWait.Hard(5);
                Browser.Wd.Manage().Window.Maximize();
                Console.WriteLine("Finished Window Maximize");               
                Browser.Wd.Navigate().GoToUrl(ConfigFile.URL);
                tmsWait.Hard(7);
                EAM.EAMLogin.UserID.Clear();
                EAM.EAMLogin.UserID.SendKeys(GeneratedUserID);
                EAM.EAMLogin.Password.Clear();
                EAM.EAMLogin.Password.SendKeys(pwd);
                EAM.EAMLogin.Submit.Click();
                tmsWait.Hard(2);

            }
        }



        [Given(@"I am logged in to IDM with userid and Password from configfile")]
        public void GivenIAmLoggedInToIDMWithUseridAndPasswordFromConfigfile()
        {
           // string GeneratedUserID = tmsCommon.GenerateData(p0);
            ConfigFile.ReadFromConfigFile();
            Console.WriteLine("Begin Navigate");
            Browser.SetWebdriverType(ConfigFile.BrowserType);
            Console.WriteLine("Finished SetWebdriverType to config file browser type");
            Browser.Wd.Manage().Window.Maximize();
            Console.WriteLine("Finished Window Maximize");
            string IDMURL = ConfigFile.URL.Replace("tms/", "idm/");
            Browser.Wd.Navigate().GoToUrl(IDMURL);
        
            //Browser.Wd.Navigate().GoToUrl("https://tms-qa.abn-tms-app-q19.dev.trizetto.com:44330/idm");
            tmsWait.Implicit(60);
            EAM.EAMLogin.UserID.Clear();
            EAM.EAMLogin.UserID.SendKeys(ConfigFile.UserId);
            EAM.EAMLogin.Password.Clear();
            EAM.EAMLogin.Password.SendKeys(ConfigFile.Password);
            EAM.EAMLogin.Submit.Click();
            tmsWait.Hard(10);
            By error = By.XPath("//strong[contains(.,'Error')]");
        

            try
            {
                if (Browser.Wd.FindElement(error).Displayed)
                {
                    EAM.EAMLogin.UserID.Clear();
                    EAM.EAMLogin.UserID.SendKeys(ConfigFile.UserId);
                    EAM.EAMLogin.Password.Clear();
                    EAM.EAMLogin.Password.SendKeys(ConfigFile.Password);
                    EAM.EAMLogin.Submit.Click();
                    tmsWait.Hard(10);
                }
            }
            catch
            {

            }
        }
        [Then(@"I am logged in to IDM with userid ""(.*)"" and Password ""(.*)""")]

        [Given(@"I am logged in to IDM with userid ""(.*)"" and Password ""(.*)""")]
        public void GivenIAmLoggedInToIDMWithUseridAndPassword(string p0, string password)
        {
            string GeneratedUserID = tmsCommon.GenerateData(p0);
            string GeneratedPassword = tmsCommon.GenerateData(password);
            ConfigFile.ReadFromConfigFile();
            Console.WriteLine("Begin Navigate");
            Browser.SetWebdriverType(ConfigFile.BrowserType);
            Console.WriteLine("Finished SetWebdriverType to config file browser type");
            Browser.Wd.Manage().Window.Maximize();
            Console.WriteLine("Finished Window Maximize");
            string IDMURLDetails = ConfigFile.IDMURL;
            Browser.Wd.Navigate().GoToUrl(IDMURLDetails);
            //Browser.Wd.Navigate().GoToUrl("https://tms-qa.abn-tms-app-q19.dev.trizetto.com:44330/idm");
            tmsWait.Implicit(30);

            if (ConfigFile.BrowserType.Equals("edge") || ConfigFile.BrowserType.Equals("chrome") || ConfigFile.BrowserType.Equals("edgelegacy") || ConfigFile.BrowserType.Equals("edgechrome"))
            {
                try
                {
                    IWebElement advancedButton = Browser.Wd.FindElement(By.CssSelector("[id='details-button']"));
                    fw.ExecuteJavascript(advancedButton);
                    tmsWait.Hard(5);

                    IWebElement acceptRiskBtn = Browser.Wd.FindElement(By.CssSelector("[id='proceed-link']"));
                    fw.ExecuteJavascript(acceptRiskBtn);
                    tmsWait.Hard(5);

                    IWebElement advancedButton1 = Browser.Wd.FindElement(By.CssSelector("[id='details-button']"));
                    fw.ExecuteJavascript(advancedButton1);
                    tmsWait.Hard(5);

                    IWebElement acceptRiskBtn1 = Browser.Wd.FindElement(By.CssSelector("[id='proceed-link']"));
                    fw.ExecuteJavascript(acceptRiskBtn1);

                }
                catch
                {
                    try
                    {
                        IWebElement continueBtn = Browser.Wd.FindElement(By.PartialLinkText("Continue to this webpage"));
                        fw.ExecuteJavascript(continueBtn);
                        tmsWait.Hard(5);
                    }
                    catch
                    {

                        fw.ConsoleReport("There is no Certiicate Warning");
                    }
                }
            }

            try
            { 
           if(EAM.EAMLogin.UserID.Displayed)
            { 
            EAM.EAMLogin.UserID.Clear();
            EAM.EAMLogin.UserID.SendKeys(GeneratedUserID);
            //  EAM.EAMLogin.Password.Clear();
            EAM.EAMLogin.Password.SendKeys(GeneratedPassword);
            EAM.EAMLogin.Submit.Click();
            }
            }
            catch (TimeoutException e)
            {

            }
            catch (WebDriverException e1)
            {

            }
            finally { 
          
            By error = By.XPath("//strong[contains(.,'Error')]");

            try
            {
                if (Browser.Wd.FindElement(error).Displayed)
                {
                    EAM.EAMLogin.UserID.Clear();
                    EAM.EAMLogin.UserID.SendKeys(ConfigFile.UserId);
                    EAM.EAMLogin.Password.Clear();
                    EAM.EAMLogin.Password.SendKeys(ConfigFile.Password);
                    EAM.EAMLogin.Submit.Click();
                    tmsWait.Hard(10);
                }
            }
            catch
            {

            }
            }
        }

        [Given(@"I am logged in to EAM with username ""(.*)"" and password ""(.*)""")]
        public void GivenIAmLoggedInToEAMWithUsernameAndPassword(string userID, string password)
        {

            string variableUserName = tmsCommon.GenerateData(userID);
            Navigation.navigate();
            Browser.Wd.Manage().Window.Maximize();
            tmsWait.Hard(10);

            EAM.EAMLogin.UserID.Clear();
            EAM.EAMLogin.UserID.SendKeys(variableUserName);
            EAM.EAMLogin.Password.Clear();
            tmsWait.Hard(2);
            string variablepassword = tmsCommon.GenerateData(password);
            EAM.EAMLogin.Password.SendKeys(variablepassword);
            EAM.EAMLogin.Submit.Click();
            tmsWait.Hard(2);            
           
            
        }
        [Given(@"I logged in to EAM with with username ""(.*)"" and password ""(.*)""")]
        public void GivenILoggedInToEAMWithWithUsernameAndPassword(string userID, string password)
        {
            string variableUserName = tmsCommon.GenerateData(userID);
            Navigation.navigate();
            Browser.Wd.Manage().Window.Maximize();
            tmsWait.Hard(10);

            EAM.EAMLogin.UserID.Clear();
            EAM.EAMLogin.UserID.SendKeys(variableUserName);
            EAM.EAMLogin.Password.Clear();
            tmsWait.Hard(2);
            EAM.EAMLogin.Password.SendKeys(password);
            EAM.EAMLogin.Submit.Click();
            tmsWait.Hard(2);
        }

        [Then(@"Verify Application displayed message as ""(.*)""")]
        public void ThenVerifyApplicationDisplayedMessageAs(string msg)
        {
            tmsWait.Hard(5);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//div[@class='alert alert-danger'][contains(.,'"+ msg + "')]"));
            AngularFunction.elementPresenceUsingWebElement(ele);
        }


        [Given(@"I am logged in to EAM with username ""(.*)"" and Admin provided password ""(.*)""")]
        public void GivenIAmLoggedInToEAMWithUsernameAndAdminProvidedPassword(string userID, string password)
        {
            
            string variableUserName = tmsCommon.GenerateData(userID);
            string variablePassword = tmsCommon.GenerateData(password);
            Navigation.navigate();
            Browser.Wd.Manage().Window.Maximize();
            tmsWait.Hard(5);
            try {
                if (EAM.EAMLogin.UserID.Displayed) { 
            ReUsableFunctions.clearContentOnWebElement(EAM.EAMLogin.UserID);
            ReUsableFunctions.enterValueOnWebElement(EAM.EAMLogin.UserID, variableUserName);
            tmsWait.Hard(2);
            ReUsableFunctions.clearContentOnWebElement(EAM.EAMLogin.Password);   
            ReUsableFunctions.enterValueOnWebElement(EAM.EAMLogin.Password, variablePassword);
            ReUsableFunctions.clickOnWebElement(EAM.EAMLogin.Submit);
            }

            }
            catch(TimeoutException e)
            {
                Console.Write("TimeoutException accurd");
            }
            catch (WebDriverException e)
            {
                Console.Write("TimeoutException accurd");
            }
        }


        [Given(@"I am logged in to EAM with with username ""(.*)"" and password ""(.*)""")]
        [Then(@"I am logged in to EAM with with username ""(.*)"" and password ""(.*)""")]
        public void GivenIAmLoggedInToEAMWithWithUsernameAndPassword(string userID, string password)
        {
            string variableUserName= tmsCommon.GenerateData(userID);
            string variablePassword = tmsCommon.GenerateData(password);
            Navigation.navigate();
            Browser.Wd.Manage().Window.Maximize();
            tmsWait.Hard(10);

            EAM.EAMLogin.UserID.Clear();
            EAM.EAMLogin.UserID.SendKeys(variableUserName);
            EAM.EAMLogin.Password.Clear();
            tmsWait.Hard(2);
            EAM.EAMLogin.Password.SendKeys(variablePassword);
            EAM.EAMLogin.Submit.Click();
            tmsWait.Hard(2);
            //fw.ExecuteJavascript(EAM.EAMLogin.ProductSwitch);
            try
            {
                EAM.EAMLogin.ProductSwitch.Click();
            }
            catch
            {
                
            }
            tmsWait.Hard(2);
            //EAM.EAMLogin.EAMApplication.Click();

        }
        [Given(@"I am logged in to default EAM with with username ""(.*)"" and password ""(.*)""")]
        public void GivenIAmLoggedInToDefaultEAMWithWithUsernameAndPassword(string userID, string password)
        {
            string variableUserName = tmsCommon.GenerateData(userID);
            string variablePassword = tmsCommon.GenerateData(password);
            Navigation.navigate();
            // Browser.Wd.Manage().Window.Maximize();
            tmsWait.Hard(10);
            try {

                if (EAM.EAMLogin.UserID.Displayed) {
            EAM.EAMLogin.UserID.Clear();
            EAM.EAMLogin.UserID.SendKeys(variableUserName);
            EAM.EAMLogin.Password.Clear();
            tmsWait.Hard(2);
            EAM.EAMLogin.Password.SendKeys(variablePassword);
            EAM.EAMLogin.Submit.Click();
            tmsWait.Hard(2);
           // fw.ExecuteJavascript(EAM.EAMLogin.ProductSwitch);
            //EAM.EAMLogin.ProductSwitch.Click();
            tmsWait.Hard(2);
                }
                //EAM.EAMLogin.EAMApplication.Click();
            }
            catch(TimeoutException e)
            {

            }
            catch (WebDriverException e)
            {

            }
        }

        [Given(@"I am logged in to EAM with InvalidUserId ""(.*)"" and InvalidPassword ""(.*)""")]
        public void GivenIAmLoggedInToEAMWithInvalidUserIdAndInvalidPassword(string p0, string p1)
        {
            Boolean SuccessfulPageLoad = false;
            int loadAttempts = 0;
            int maxLoadAttempts = 5;
            while (!SuccessfulPageLoad && (loadAttempts < maxLoadAttempts + 1))
            {
                loadAttempts++;
                try
                {
                    //original code start
                    Navigation.navigate();
                    //tmsWait.Hard(5);
                    Browser.Wd.Manage().Window.Maximize();
                    //tmsWait.Hard(12);
                    EAM.EAMLogin.UserID.Clear();
                    EAM.EAMLogin.UserID.SendKeys(p0);
                    EAM.EAMLogin.Password.Clear();
                    EAM.EAMLogin.Password.SendKeys(p1);
                    EAM.EAMLogin.Submit.Click();
                    tmsWait.Hard(5);
                    SuccessfulPageLoad = true;
                  
                    if (loadAttempts++ == maxLoadAttempts)
                    {
                        SuccessfulPageLoad = true;
                    }
                }
                catch (Exception e)
                {
                    Assert.AreEqual(1, 1, "Attempt on the login page failed [" + loadAttempts + "], will do a retry.");



                    Browser.CloseWebDriver();
                    tmsWait.Hard(2);

                  

                }
            }
            //            ****************************** Commented Temporarily for Jenkins demo, you can revert back later
            if (!SuccessfulPageLoad)
            {
                Assert.AreEqual(1, 2, "Had a problem getting through the login page on your App server, Please have a look on it");
            }
        }

        [Given(@"I am logged in to IDM Application using IDM URL")]
        public void GivenIAmLoggedInToIDMApplicationUsingIDMURL()
        {
            Boolean SuccessfulPageLoad = false;
            int loadAttempts = 0;
            int maxLoadAttempts = 5;
            while (!SuccessfulPageLoad && (loadAttempts < maxLoadAttempts + 1))
            {
                loadAttempts++;
                try
                {
                    //original code start
                    Navigation.navigateIDMURL();
                    tmsWait.Hard(5);
                    Browser.Wd.Manage().Window.Maximize();
                    tmsWait.Hard(12);
                    EAM.EAMLogin.UserID.Clear();
                    EAM.EAMLogin.UserID.SendKeys(ConfigFile.UserId);
                    EAM.EAMLogin.Password.Clear();
                    EAM.EAMLogin.Password.SendKeys(ConfigFile.Password);
                    EAM.EAMLogin.Submit.Click();
                    tmsWait.Hard(5);
                    SuccessfulPageLoad = true;
                   
                   
                    if (loadAttempts++ == maxLoadAttempts)
                    {
                        SuccessfulPageLoad = true;
                    }
                }
                catch (Exception e)
                {
                    Assert.AreEqual(1, 1, "Attempt on the login page failed [" + loadAttempts + "], will do a retry.");



                    Browser.CloseWebDriver();
                    tmsWait.Hard(2);

                    

                }
            }
            //            ****************************** Commented Temporarily for Jenkins demo, you can revert back later
            if (!SuccessfulPageLoad)
            {
                Assert.AreEqual(1, 2, "Had a problem getting through the login page on your App server, Please have a look on it");
            }
           
        }

        [Given(@"I am logged in to Elements Application Framework page through ADFS Tenant Admin")]
        public void GivenIAmLoggedInToElementsApplicationFrameworkPageThroughADFSTenantAdmin()
        {

            Boolean SuccessfulPageLoad = false;
            int loadAttempts = 0;
            int maxLoadAttempts = 5;
            while (!SuccessfulPageLoad && (loadAttempts < maxLoadAttempts + 1))
            {
                loadAttempts++;
                try
                {

                    Navigation.navigate();
                    tmsWait.Hard(5);
                    Browser.Wd.Manage().Window.Maximize();
                    tmsWait.Hard(12);
                    fw.ConsoleReport(" Navigating to ADFS Login page");
                    ReUsableFunctions.clickOnWebElement(cfADFSLogin.ADFSLoginPage.loginWithADFSButton);

                    tmsWait.Hard(7);
                    ReUsableFunctions.enterValueOnWebElement(cfADFSLogin.ADFSLoginPage.username, "dev\tadmin");
                    ReUsableFunctions.enterValueOnWebElement(cfADFSLogin.ADFSLoginPage.password, "Welcome@123");
                    ReUsableFunctions.clickOnWebElement(cfADFSLogin.ADFSLoginPage.signInButton);
                    tmsWait.Hard(5);
                    SuccessfulPageLoad = true;


                    if (loadAttempts++ == maxLoadAttempts)
                    {
                        SuccessfulPageLoad = true;
                    }
                }
                catch (Exception e)
                {
                    Assert.AreEqual(1, 1, "Attempt on the ADFS login page failed [" + loadAttempts + "], will do a retry.");



                    Browser.CloseWebDriver();
                    tmsWait.Hard(2);



                }
            }

            if (!SuccessfulPageLoad)
            {
                Assert.AreEqual(1, 2, "Had a problem getting through the ADFS login page on your App server, Please have a look on it");
            }

        }


        [Given(@"I am logged in to Elements Application Framework page through ADFS Root Admin")]
        public void GivenIAmLoggedInToElementsApplicationFrameworkPageThroughADFSRootAdmin()
        {
          

        Boolean SuccessfulPageLoad = false;
            int loadAttempts = 0;
            int maxLoadAttempts = 5;
            while (!SuccessfulPageLoad && (loadAttempts < maxLoadAttempts + 1))
            {
                loadAttempts++;
                try
                {

                    Navigation.navigate();
                    tmsWait.Hard(5);
                    Browser.Wd.Manage().Window.Maximize();
                    tmsWait.Hard(12);
                    fw.ConsoleReport(" Navigating to ADFS Login page");
                    ReUsableFunctions.clickOnWebElement(cfADFSLogin.ADFSLoginPage.loginWithADFSButton);
                    AngularFunction.resolveCertificateErrors();
                    tmsWait.Hard(7);
                    ReUsableFunctions.enterValueOnWebElement(cfADFSLogin.ADFSLoginPage.username, ConfigFile.ADFSUserId);
                    ReUsableFunctions.enterValueOnWebElement(cfADFSLogin.ADFSLoginPage.password, ConfigFile.ADFSPassword);
                    ReUsableFunctions.clickOnWebElement(cfADFSLogin.ADFSLoginPage.signInButton);
                    tmsWait.Hard(10);
                    SuccessfulPageLoad = true;


                    if (loadAttempts++ == maxLoadAttempts)
                    {
                        SuccessfulPageLoad = true;
                    }
                }
                catch (Exception e)
                {
                    Assert.AreEqual(1, 1, "Attempt on the ADFS login page failed [" + loadAttempts + "], will do a retry.");



                    Browser.CloseWebDriver();
                    tmsWait.Hard(2);



                }
            }

            if (!SuccessfulPageLoad)
            {
                Assert.AreEqual(1, 2, "Had a problem getting through the ADFS login page on your App server, Please have a look on it");
            }

        }


        [Given(@"I am logged in to Elements Administration page")]     
        [Given(@"I am logged in to TMS with Config File Parameters")]
        [Given(@"I am logged in to EAM with Config File Parameters")]
        [Then(@"I am logged in to EAM with Config File Parameters")]
        public void GivenIAmLoggedInToEAMWithConfigFileParameters()
        {
          
            // UIMODUtilFunctions.executeStoredProcedure();

            //DesktopOptions options = new DesktopOptions { ApplicationPath = " ", DebugConnectToRunningApp = true };
            //WiniumDriver winium = new WiniumDriver("C:\\TMS", options);
            //IWebElement securityWindow = winium.FindElement(By.ClassName("WinButton"));
            //securityWindow.Click();
            //Daron - 04.08.2016 - Code update here if the page doesn't get loaded
            //to close browser, retry n times.
            //side note:   The pages started having intermittant hiccups after we got microsoft updates on the machines.
            //it seems to come a bit rare, usually on first test case up.  
            //Daron - 12.01.2016 - Code did not previously exit upon reaching max try attempts.   Added code to exit after maxtries.

            //Daron - 11.17.2017 - the following 7 lines are commented out so we can put back the looping / re-attempt of the same code below.
            //If anyone needs to disable the looping code, let's talk over as a team what is bringing that decision and see if removing it is the
            //best answer or if we should do another fix.
            //Also notice that we can change between each version by changing the condition of the IF statements.   This is important code flow area
            //so I don't want to remove working code, just want to zero in on our best solution here.
            //if (1 == 2)
            //{
            //    Navigation.navigate();
            //    tmsWait.Hard(5);
            //    EAM.EAMLogin.UserID.Clear();
            //    EAM.EAMLogin.UserID.SendKeys(ConfigFile.UserId);
            //    EAM.EAMLogin.Password.Clear();
            //    EAM.EAMLogin.Password.SendKeys(ConfigFile.Password);
            //    EAM.EAMLogin.Submit.Click();
            //}
            // if (1 == 1)
            // {
            Boolean SuccessfulPageLoad = false;
                int loadAttempts = 0;
                int maxLoadAttempts = 5;
                while (!SuccessfulPageLoad && (loadAttempts < maxLoadAttempts + 1))
                {
                    loadAttempts++;
                    try
                    {
                        //original code start
                        Navigation.navigate();
                        tmsWait.Hard(3);
                        Browser.Wd.Manage().Window.Maximize();
                        tmsWait.Hard(5);
                        EAM.EAMLogin.UserID.Clear();
                        EAM.EAMLogin.UserID.SendKeys(ConfigFile.UserId);
                        EAM.EAMLogin.Password.Clear();
                        EAM.EAMLogin.Password.SendKeys(ConfigFile.Password);
                        EAM.EAMLogin.Submit.Click();
                        tmsWait.Hard(5);
                        SuccessfulPageLoad = true;
                //***********Below code is NEW UI related*********************//
                //  fw.ExecuteJavascript(EAM.EAMLogin.ProductSwitch);
                //tmsWait.Hard(2);
                //fw.ExecuteJavascript(EAM.EAMLogin.EAMApplication);
                //    SuccessfulPageLoad = true;

                        //original code end

                        //2.28.2017 - Daron - Commented the check on the right page for now, may want to bring back
                        //                      a better check, this one is obsolete for R3
                        //IList<IWebElement> TZLogo = Browser.Wd.FindElements(By.Id("Navigation1_ProductMenu1_Menu1-menuItem000"));
                        //if (TZLogo.Count > 0)
                        //        {
                        //            SuccessfulPageLoad = true;
                        //        }
                        //        else
                        //        {
                        //    //foreach (var process in Process.GetProcessesByName("iexplore"))
                        //    //{
                        //    //    process.Kill();
                        //    //}
                        //    //foreach (var process in Process.GetProcessesByName("firefox.exe *32"))
                        //    //{
                        //    //    process.Kill();
                        //    //}
                        //    //foreach (var process in Process.GetProcessesByName("chrome.exe"))
                        //    //{
                        //    //    process.Kill();
                        //    //}
                        //    //foreach (var process in Process.GetProcessesByName("chrome.exe *32"))
                        //    //{
                        //    //    process.Kill();
                        //    //}
                        //    //foreach (var process in Process.GetProcessesByName("chrome"))
                        //    //{
                        //    //    process.Kill();
                        //    //}

                        //    Browser.CloseWebDriver();
                        //}
                        if (loadAttempts++ == maxLoadAttempts)
                        {
                            SuccessfulPageLoad = true;
                        }
                   }
                    catch(Exception e)
                    {
                        Assert.AreEqual(1, 1, "Attempt on the login page failed [" + loadAttempts + "], will do a retry.");

                   

                        Browser.CloseWebDriver();
                        tmsWait.Hard(2);

                        //foreach (var process in Process.GetProcessesByName("iexplore"))
                        //{
                        //    process.Kill();
                        //}
                        //foreach (var process in Process.GetProcessesByName("firefox.exe *32"))
                        //{
                        //    process.Kill();
                        //}

                        //foreach (var process in Process.GetProcessesByName("chrome.exe"))
                        //{
                        //    process.Kill();
                        //}
                        //foreach (var process in Process.GetProcessesByName("chrome.exe *32"))
                        //{
                        //    process.Kill();
                        //}
                        //foreach (var process in Process.GetProcessesByName("chrome"))
                        //{
                        //    process.Kill();
                        //}

                    }
                }
    //            ****************************** Commented Temporarily for Jenkins demo, you can revert back later
                if (!SuccessfulPageLoad)
                {
                    Assert.AreEqual(1, 2, "Had a problem getting through the login page on your App server, Please have a look on it");
                }
           // }
        }

        [Given(@"I am logged in to Elements Administration Page")]
        //TMS Framework  UI mod login function 
        [Given(@"I am logged in to TMSUIMod  with Config File Parameters")]
          public void GivenIAmLoggedInToTMSUIModWithConfigFileParameters()
        {
            //Wardhaman Bedmutha : Added this function for TMS Framework : 29nov2016 

            Boolean SuccessfulPageLoad = false;
            int loadAttempts = 0;
            int maxLoadAttempts = 1;
            while (!SuccessfulPageLoad)
            {
                try
                {
                    //original code start
                    Navigation.navigate();
                    EAM.EAMLogin.UserID.Clear();
                    EAM.EAMLogin.UserID.SendKeys(ConfigFile.UserId);
                    EAM.EAMLogin.Password.Clear();
                    EAM.EAMLogin.Password.SendKeys(ConfigFile.Password);
                    EAM.EAMLogin.Submit.Click();
                    Browser.Wd.Manage().Window.Maximize();
                    tmsWait.Hard(2);
                    //original code end

                    // IList<IWebElement> TZLogo = Browser.Wd.FindElements(By.Id("Navigation1_ProductMenu1_Menu1-menuItem000"));
                    //tmsWait.Hard(10);
                   // Boolean isdisplayed = Browser.Wd.FindElement(By.Id("appSwitch")).Enabled;
                    if ((Browser.Wd.FindElement(By.Id("appSwitch")).Enabled))
                    {
                        SuccessfulPageLoad = true;
                    }
                    else
                    {
                        foreach (var process in Process.GetProcessesByName("iexplore"))
                        {
                            process.Kill();
                        }
                        foreach (var process in Process.GetProcessesByName("firefox.exe *32"))
                        {
                            process.Kill();
                        }
                        foreach (var process in Process.GetProcessesByName("chrome.exe"))
                        {
                            process.Kill();
                        }
                        foreach (var process in Process.GetProcessesByName("chrome.exe *32"))
                        {
                            process.Kill();
                        }
                        foreach (var process in Process.GetProcessesByName("chrome"))
                        {
                            process.Kill();
                        }

                        Browser.Wd.Close();
                    }
                    if (loadAttempts++ == maxLoadAttempts)
                    {
                        SuccessfulPageLoad = true;
                    }
                }
                catch
                {
                    foreach (var process in Process.GetProcessesByName("iexplore"))
                    {
                        process.Kill();
                    }
                    foreach (var process in Process.GetProcessesByName("firefox.exe *32"))
                    {
                        process.Kill();
                    }

                    foreach (var process in Process.GetProcessesByName("chrome.exe"))
                    {
                        process.Kill();
                    }
                    foreach (var process in Process.GetProcessesByName("chrome.exe *32"))
                    {
                        process.Kill();
                    }
                    foreach (var process in Process.GetProcessesByName("chrome"))
                    {
                        process.Kill();
                    }

                }
            }
        }






        [Given(@"I am logged in to EAM with with variable ""(.*)""")]
        public void GivenIAmLoggedInToEAMWithWithVariable(string p0)
        {
           
        }


        [Given(@"I am logged in to EAM with parameters from a database")]
        public void GivenIAmLoggedInToEAMWithParametersFromADatabase()
        {
            Navigation.navigate();
            Browser.Wd.Manage().Window.Maximize();
            tmsWait.Hard(2);
            EAM.EAMLogin.UserID.SendKeys(ConfigFile.UserId);
            EAM.EAMLogin.Password.SendKeys(ConfigFile.Password);
            EAM.EAMLogin.Submit.Click();
            tmsWait.Hard(2);
            EAM.EAMLogin.ProductSwitch.Click();
            tmsWait.Hard(2);
            EAM.EAMLogin.EAMApplication.Click();
        }


        [Given(@"I am logged in with new created userid and password ""(.*)""")]
        public void GivenIAmLoggedInWithNewCreatedUseridAndPassword(string p0)
        {
            Navigation.navigate();
            EAM.EAMLogin.UserID.SendKeys(UserAdministration.GeneratedUserID);
            EAM.EAMLogin.Password.SendKeys(p0);
            EAM.EAMLogin.Submit.Click();
        }

        [Given(@"I Get Machine Processes")]
        public void GivenIGetMachineProcesses()
        {
        //    Process[] processes = Process.GetProcesses();
            Process[] processes = Process.GetProcessesByName("iexplore");
            IList<Process> myProcs = Process.GetProcessesByName("iexplore");
            int i = 0;
            foreach (Process thisProcess in processes)
            {
                Console.WriteLine("["+i+"]"+processes[i].ProcessName);

                i++;
            }
            string thisProcessName = processes[5].MainWindowTitle;
            
        }

        [When(@"I click logout")]
        [Given(@"I click logout")]
        [Then(@"I click logout")]
        public void GivenIClickLogout()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(EAM.EAMLogout.Logout);
            Browser.Wd.Manage().Cookies.DeleteAllCookies();
            tmsWait.Hard(2);
        }

        [Given(@"variable ""(.*)"" is set to the contents of the clipboard")]
        public void GivenVariableIsSetToTheContentsOfTheClipboard(string p0)
        {
            IWebDriver TAbr = new InternetExplorerDriver();

            TAbr.Navigate().GoToUrl("c:\\tms\\TextArea.html");
            tmsWait.Hard(2);
            IWebElement thisTB = TAbr.FindElement(By.TagName("textarea"));
            thisTB.Clear();
            tmsWait.Hard(1);
            //SendKeys.SendWait("^{v}");
            tmsWait.Hard(1);
            string thisText = thisTB.Text;
            fw.setVariable(p0, thisText);
            TAbr.Close();
            TAbr.Dispose();
        }


       
         [Given(@"I clicked EAM Application from Elements Administration page")]
        [Given(@"I select EAM database from Application Switch Button")]
        [When(@"I select EAM database from Application Switch Button")]
        [When(@"I select database from config file")]
        [Given(@"I select database from config file")]
        [Then(@"I select database from config file")]
        [Given(@"I select EAM database from config file")]
        [Then(@"I select EAM database from config file")]
        public void GivenISelectDatabaseFromConfigFile()
        {


            


            tmsWait.Hard(3);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                
                IWebElement expandMenu = Browser.Wd.FindElement(By.XPath("(//a[@test-id='header-btn-expanMenu'])[2]"));
                fw.ExecuteJavascript(expandMenu);

                tmsWait.Hard(3);


                IWebElement eam = Browser.Wd.FindElement(By.CssSelector("a [test-id='menu-ddl-applicationNavigationEAMIcon1']"));
                fw.ExecuteJavascript(eam);
                GlobalRef.ApplicationName = "EAM";
            }
            else
            {

                tmsWait.Hard(3);

                try
                {
                    Navigation.SwitchToApplication(ConfigFile.EAMdb);
                    GlobalRef.ApplicationName = "EAM";
                }
                catch (Exception ex)
                {
                    try
                    {
                        IWebElement test = Browser.Wd.FindElement(By.XPath("//font[contains(., '" + ConfigFile.EAMdb + "')]"));
                        fw.ExecuteJavascript(test);
                        GlobalRef.ApplicationName = "EAM";
                    }
                    catch
                    {
                        Assert.Fail("Application is not getting loaded with in Specified time");
                    }

                }
            }


        }

        [Then(@"I select database ""(.*)""")]
        [When(@"I select database ""(.*)""")]
        [Given(@"I select database ""(.*)""")]
        public void GivenISelectDatabase(string p0)
        {
            //look for it by name   "TMSWeb Administration" ==>  TMS|Administration
            tmsWait.Hard(4);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement expandMenu = Browser.Wd.FindElement(By.XPath("(//a[@test-id='header-btn-expanMenu'])[2]"));
                fw.ExecuteJavascript(expandMenu);

                tmsWait.Hard(3);


                IWebElement eam = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'framework')]"));
                fw.ExecuteJavascript(eam);
            }
            else
            {

                try
                {
                    if (Browser.Wd.FindElement(By.Id("ctl00_ctl00_ProductMenu1_Menu1-menuItem000")).Displayed)
                    {
                        IWebElement test = Browser.Wd.FindElement(By.XPath("//td[contains(., 'Framework')]"));
                        fw.ExecuteJavascript(test);
                    }
                }
                catch (Exception ex)
                {
                    Navigation.SwitchToApplication("Framework");
                }
            }
        }       

        [Given(@"I select FRM database from config file")]
        [Then(@"I select FRM database from config file")]
        [When(@"I select FRM database from config file")]
        public void GivenISelectFRMDatabaseFromConfigFile()
        {
          

            tmsWait.Hard(5);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement expandMenu = Browser.Wd.FindElement(By.XPath("(//a[@test-id='header-btn-expanMenu'])[2]"));
                fw.ExecuteJavascript(expandMenu);

                tmsWait.Hard(2);

                GlobalRef.ApplicationName = "FRM";
                IWebElement eam = Browser.Wd.FindElement(By.CssSelector("[test-id='menu-ddl-applicationNavigationFRMIcon1']"));
                fw.ExecuteJavascript(eam);
            }
            else
            {
                GlobalRef.ApplicationName = "FRM";
                Navigation.SwitchToApplication("FRM");

            }
        }

        [Given(@"I select ""(.*)"" database from Application Switch Tray")]
        [When(@"I select ""(.*)"" database from Application Switch Tray")]
        public void GivenISelectDatabaseFromApplicationSwitchTray(string appName)
        {
            tmsWait.Hard(5);

            try
            {
                if (Browser.Wd.FindElement(By.Id("ctl00_ctl00_ProductMenu1_Menu1-menuItem000")).Displayed)
                {
                    IWebElement test = Browser.Wd.FindElement(By.XPath("//font[contains(., '" + appName + "')]"));
                    fw.ExecuteJavascript(test);
                }
            }
            catch (Exception ex)
            {
                Navigation.SwitchToApplication(appName);
            }
        }


        [Then(@"verfiy that user is unable to access any other applications")]
        public void ThenVerfiyThatUserIsUnableToAccessAnyOtherApplications()
        {
            tmsWait.Hard(5);
            string[] appName = { "FRM", "RAM", "RAMX", "PDEM", "CDM", "Framework", "RSM", "RxM", "DLM" };
            //IWebElement appSwitch = Browser.Wd.FindElement(By.Id("appSwitch"));
            IWebElement appSwitch = Browser.Wd.FindElement(By.XPath("//a[@test-id='header-btn-expanMenu']//span[@title='Application Switch']"));
            appSwitch.Click();
            tmsWait.Hard(2);
            //if (Browser.Wd.FindElement(By.XPath("//div[@test-id='menu-ddl-applicationNavigation']")).Displayed)
            //{
            //    foreach (string app in appName)
            //    {
            //        string path = "//*[@test-id='menu-ddl-applicationNavigation"+app+"Text']";
            //        Console.Write(path);
            //        IWebElement ele = Browser.Wd.FindElement(By.XPath(path));
            //        Assert.IsTrue(ele.Enabled, "Failed");

            //        }
            //    }

            if (Browser.Wd.FindElement(By.XPath("//kendo-popup//div[contains(text(),'Applications')]")).Displayed)
            {
                foreach (string app in appName)
                {
                    string path = "//app-application-switch-nav//kendo-popup//div//small[contains(text(),'" + app + "')]";
                    Console.Write(path);
                    IWebElement ele = Browser.Wd.FindElement(By.XPath(path));
                    Assert.IsTrue(ele.Enabled, "Failed");

                }
            }


        }





        [Given(@"I select RAMX database from config file")]
        [When(@"I select RAMX database from config file")]
        public void GivenISelectRAMXDatabaseFromConfigFile()
        {
            tmsWait.Hard(30);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement expandMenu = Browser.Wd.FindElement(By.XPath("(//a[@test-id='header-btn-expanMenu'])[2]"));
                fw.ExecuteJavascript(expandMenu);

                tmsWait.Hard(3);


                IWebElement eam = Browser.Wd.FindElement(By.CssSelector("[test-id='menu-ddl-applicationNavigationRAMXIcon1']"));
                fw.ExecuteJavascript(eam);
            }
            else
            {
                IWebElement expandMenu = Browser.Wd.FindElement(By.XPath("(//a[@test-id='header-btn-expanMenu'])[2]"));
                fw.ExecuteJavascript(expandMenu);

                tmsWait.Hard(3);


                IWebElement eam = Browser.Wd.FindElement(By.CssSelector("[test-id='menu-ddl-applicationNavigationRAMXIcon1']"));
                fw.ExecuteJavascript(eam);
            }
        }

        [Given(@"I select framework Application from Switch Over Button")]
        [When(@"I select framework Application from Switch Over Button")]
        public void GivenISelectFrameworkApplicationFromSwitchOverButton()
        {
            tmsWait.Hard(8);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement expandMenu = Browser.Wd.FindElement(By.XPath("(//a[@test-id='header-btn-expanMenu'])[2]"));
                fw.ExecuteJavascript(expandMenu);

                tmsWait.Hard(3);


                IWebElement eam = Browser.Wd.FindElement(By.CssSelector("[test-id='menu-ddl-applicationNavigationFrameworkIcon1']"));
                fw.ExecuteJavascript(eam);
            }
            else
            {
                tmsWait.Hard(5);
                try
                {
                    IWebElement ramx = Browser.Wd.FindElement(By.CssSelector("[test-id='menu-ddl-applicationNavigationFrameworkIcon1']"));
                    fw.ExecuteJavascript(ramx);
                }
                catch
                {
                    Assert.Fail(" Framework Application is not Enabled in your Application.");
                }
            }
        }



        [Given(@"I select RAM database from config file")]
        [Then(@"I select RAM database from config file")]
        [When(@"I select RAM database from config file")]
        public void GivenISelectRAMDatabaseFromConfigFile()
        {
            tmsWait.Hard(5);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement expandMenu = Browser.Wd.FindElement(By.XPath("(//a[@test-id='header-btn-expanMenu'])[2]"));
                fw.ExecuteJavascript(expandMenu);

                tmsWait.Hard(3);
               GlobalRef.ApplicationName = ConfigFile.RAMdb;

                IWebElement eam = Browser.Wd.FindElement(By.CssSelector("[test-id='menu-ddl-applicationNavigationRAMIcon1']"));
                fw.ExecuteJavascript(eam);

               
            }
            else
            {

                tmsWait.Hard(5);
                try
                {
                    IWebElement ram = Browser.Wd.FindElement(By.CssSelector("[test-id='menu-ddl-applicationNavigationRAMIcon1']"));
                    fw.ExecuteJavascript(ram);
                }
                catch
                {
                    try
                    {
                        IWebElement ram = Browser.Wd.FindElement(By.CssSelector("[test-id='menu-ddl-applicationNavigationRAMPIcon1']"));
                        fw.ExecuteJavascript(ram);
                    }
                    catch
                    {
                        Assert.Fail(" RAM Application is not added in Your Application");
                    }

                }

                //try
                //{
                //    if (Browser.Wd.FindElement(By.Id("ctl00_ctl00_ProductMenu1_Menu1-menuItem000")).Displayed)
                //    {
                //        IWebElement test = Browser.Wd.FindElement(By.XPath("//font[contains(., '" + ConfigFile.RAMdb + "')]"));
                //        fw.ExecuteJavascript(test);
                //    }
                //}
                //catch (Exception ex)
                //{
                //    Navigation.SwitchToApplication(ConfigFile.RAMdb);
                //}


                //try
                //{
                //Navigation.SwitchToApplication(ConfigFile.RAMdb);
                //}
                //catch (Exception ex)
                //{
                //    IWebElement test = Browser.Wd.FindElement(By.XPath("//font[contains(., '" + ConfigFile.RAMdb + "')]"));
                //    fw.ExecuteJavascript(test);
                //}
            }
        }

        [Given(@"I select RxM database from config file")]
        public void GivenISelectRxMDatabaseFromConfigFile()
        {
            tmsWait.Hard(60);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement expandMenu = Browser.Wd.FindElement(By.XPath("(//a[@test-id='header-btn-expanMenu'])[2]"));
                fw.ExecuteJavascript(expandMenu);

                tmsWait.Hard(3);


                IWebElement eam = Browser.Wd.FindElement(By.CssSelector("[test-id='menu-ddl-applicationNavigationRxMIcon1']"));
                fw.ExecuteJavascript(eam);
            }
            else
            {
                tmsWait.Hard(5);
                IWebElement rxm = Browser.Wd.FindElement(By.CssSelector("[test-id='menu-ddl-applicationNavigationRxMIcon1']"));
                fw.ExecuteJavascript(rxm);
            }
        }

        [Given(@"I select RSM database from config file")]
        [When(@"I select RSM database from config file")]
        [Then(@"I select RSM database from config file")]
        public void GivenISelectRSMDatabaseFromConfigFile()
        {
            tmsWait.Hard(5);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement expandMenu = Browser.Wd.FindElement(By.XPath("(//a[@test-id='header-btn-expanMenu'])[2]"));
                fw.ExecuteJavascript(expandMenu);

                tmsWait.Hard(3);

                GlobalRef.ApplicationName = "RSM";
                IWebElement rsm = Browser.Wd.FindElement(By.CssSelector("[test-id='menu-ddl-applicationNavigationRSMIcon1']"));
                fw.ExecuteJavascript(rsm);
            }
            else
            {

                //try
                //{
                Navigation.SwitchToApplication(ConfigFile.RSMdb);

                //}
                //catch (Exception ex)
                //{
                //     IWebElement test = Browser.Wd.FindElement(By.XPath("//font[contains(., '" + ConfigFile.RSMdb + "')]"));
                //        fw.ExecuteJavascript(test);

                //}
            }
        }


        [When(@"I select RSM database from EAM Home page")]
        public void WhenISelectRSMDatabaseFromEAMHomePage()
        {
            tmsWait.Hard(5);
            Navigation.selectRSMDatabase();
        }

        [Given(@"I select PDEM database from config file")]
        [When(@"I select PDEM database from config file")]
        [Then(@"I select PDEM database from config file")]
        public void GivenISelectPDEMDatabaseFromConfigFile()
        {

            tmsWait.Hard(10);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement expandMenu = Browser.Wd.FindElement(By.XPath("(//a[@test-id='header-btn-expanMenu'])[2]"));
                fw.ExecuteJavascript(expandMenu);

                tmsWait.Hard(4);


                IWebElement eam = Browser.Wd.FindElement(By.CssSelector("[test-id='menu-ddl-applicationNavigationPDEMIcon1']"));
                fw.ExecuteJavascript(eam);
            }
            else
            {
                tmsWait.Hard(7);
                IWebElement pdem = Browser.Wd.FindElement(By.CssSelector("[test-id='menu-ddl-applicationNavigationPDEMText']"));
                fw.ExecuteJavascript(pdem);
                tmsWait.Hard(5);
            }
            //try
            //{
            //    if (Browser.Wd.FindElement(By.Id("ctl00_ctl00_ProductMenu1_Menu1-menuItem000")).Displayed)
            //    {
            //        IWebElement test = Browser.Wd.FindElement(By.XPath("//font[contains(., '" + ConfigFile.PDEMdb + "')]"));
            //        fw.ExecuteJavascript(test);
            //    }
            //}
            //catch (Exception ex)
            //{
            //    Navigation.SwitchToApplication(ConfigFile.PDEMdb);
            //}

            //try
            // {
            // Navigation.SwitchToApplication(ConfigFile.PDEMdb);

            //}
            //catch (Exception ex)
            //{
            //    if (Browser.Wd.FindElement(By.Id("ctl00_ctl00_ProductMenu1_Menu1-menuItem000")).Displayed)
            //    {
            //        IWebElement test = Browser.Wd.FindElement(By.XPath("//font[contains(., '" + ConfigFile.PDEMdb + "')]"));
            //        fw.ExecuteJavascript(test);
            //    }
            //}
        }


      


        [Given(@"I select DLM database from config file")]
        [Then(@"I select DLM database from config file")]
        public void GivenISelectDLMDatabaseFromConfigFile()
        {
           // tmsWait.Hard(5);
            tmsWait.Hard(60);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement expandMenu = Browser.Wd.FindElement(By.XPath("(//a[@test-id='header-btn-expanMenu'])[2]"));
                fw.ExecuteJavascript(expandMenu);
                tmsWait.Hard(3);

                IWebElement eam = Browser.Wd.FindElement(By.CssSelector("[test-id='menu-ddl-applicationNavigationDLMIcon1']"));
                fw.ExecuteJavascript(eam);
            }
            else
            {

                // try
                // {
                Navigation.SwitchToApplication(ConfigFile.DLMdb);

                // }
                //  catch (Exception ex)
                // {
                //  IWebElement test = Browser.Wd.FindElement(By.XPath("//font[contains(., '" + ConfigFile.DLMdb + "')]"));
                //        fw.ExecuteJavascript(test);
                //  
                // }
            }
        }

        [Given(@"I select CDM Application from TMS Framework page")]
        [Then(@"I select CDM Application from TMS Framework page")]
        public void GivenISelectCDMApplicationFromTMSFrameworkPage()
        {
            tmsWait.Hard(8);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement expandMenu = Browser.Wd.FindElement(By.XPath("(//a[@test-id='header-btn-expanMenu'])[2]"));
                fw.ExecuteJavascript(expandMenu);

                tmsWait.Hard(3);


                IWebElement eam = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'cdm')]"));
                fw.ExecuteJavascript(eam);
            }
            else
            {
                try
                {
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[test-id='menu-ddl-applicationNavigationCDMIcon1']")));
                }
                catch
                {
                    Assert.Fail(" CDM Application is not available on Your App Server");
                }
            }
        }


        [Given(@"I select DLM Application from TMS Framework page")]
        public void GivenISelectDLMApplicationFromTMSFrameworkPage()
        {
            tmsWait.Hard(8);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement expandMenu = Browser.Wd.FindElement(By.XPath("(//a[@test-id='header-btn-expanMenu'])[2]"));
                fw.ExecuteJavascript(expandMenu);

                tmsWait.Hard(3);


                IWebElement eam = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'dlm')]"));
                fw.ExecuteJavascript(eam);
            }
            else
            {
                try
                {
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[test-id='menu-ddl-applicationNavigationDLMIcon1']")));
                }
                catch
                {
                    Assert.Fail(" DLM Application is not available on Your App Server");
                }
            }

        }

        [Given(@"I select RXM Application from TMS Framework page")]
        [Then(@"I select RXM Application from TMS Framework page")]

        public void GivenISelectRXMApplicationFromTMSFrameworkPage()
        {

            tmsWait.Hard(8);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement expandMenu = Browser.Wd.FindElement(By.XPath("(//a[@test-id='header-btn-expanMenu'])[2]"));
                fw.ExecuteJavascript(expandMenu);

                tmsWait.Hard(3);


                IWebElement eam = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'rxm')]"));
                fw.ExecuteJavascript(eam);
            }
            else
            {
                try
                {
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[test-id='menu-ddl-applicationNavigationRxMIcon1']")));
                }
                catch
                {
                    Assert.Fail(" RXM Application is not available on Your App Server");
                }
            }
        }


        [Given(@"I select CDM database from config file")]
        public void GivenISelectCDMDatabaseFromConfigFile()
        {
            tmsWait.Hard(5);
            tmsWait.Hard(8);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement expandMenu = Browser.Wd.FindElement(By.XPath("(//a[@test-id='header-btn-expanMenu'])[2]"));
                fw.ExecuteJavascript(expandMenu);

                tmsWait.Hard(3);

                //IWebElement eam = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'cdm')]"));
                //fw.ExecuteJavascript(eam);

                IWebElement eam = Browser.Wd.FindElement(By.CssSelector("[test-id='menu-ddl-applicationNavigationCDMIcon1']"));
                fw.ExecuteJavascript(eam);
                GlobalRef.ApplicationName = "CDM";
            }
            else
            {

                fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[test-id='menu-ddl-applicationNavigationCDMText']")));
                GlobalRef.ApplicationName = "CDM";
            }
            //try
            //{
            //    if (Browser.Wd.FindElement(By.Id("ctl00_ctl00_ProductMenu1_Menu1-menuItem000")).Displayed)
            //    {
            //        IWebElement test = Browser.Wd.FindElement(By.XPath("//font[contains(., '" + ConfigFile.CDMdb + "')]"));
            //        fw.ExecuteJavascript(test);
            //    }
            //}
            //catch (Exception ex)
            //{
            //    Navigation.SwitchToApplication(ConfigFile.CDMdb);
            //}

            //try
            //{
            // Navigation.SwitchToApplication(ConfigFile.CDMdb);
            //}
            //catch (Exception ex)
            //{
            //    if (Browser.Wd.FindElement(By.Id("ctl00_ctl00_ProductMenu1_Menu1-menuItem000")).Displayed)
            //    {
            //        IWebElement test = Browser.Wd.FindElement(By.XPath("//font[contains(., '" + ConfigFile.CDMdb + "')]"));
            //        fw.ExecuteJavascript(test);
            //    }

            //}
        }

        [Given(@"Verify ""(.*)"" Database under Triangle logo is not displayed")]
        public void GivenVerifyDatabaseUnderTriangleLogoIsNotDisplayed(string p0)
        {
            Navigation.VerifyFRMDB();
        }


        [Given(@"FRM Home Page Database EAM is selected")]
        public void GivenFRMHomePageDatabaseEAMIsSelected()
        {
            Navigation.selectEAMDatabase();
        }

        [Given(@"I have navigated to link ""(.*)""")]
        public void GivenIHaveNavigatedToLink(string link)
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[text()='" + link + "']")));
        }

        [When(@"Database Details page Authentication is selected as ""(.*)""")]
        public void WhenDatabaseDetailsPageAuthenticationIsSelectedAs(string type)
        {
            tmsWait.Hard(3);
            SelectElement authentication = new SelectElement(Browser.Wd.FindElement(By.Id("ddlAuthentication")));
            authentication.SelectByText(type);
        }

        [When(@"Database Details page Databse User is set to ""(.*)""")]
        public void WhenDatabaseDetailsPageDatabseUserIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string dbUser = tmsCommon.GenerateData(p0);
            Browser.Wd.FindElement(By.Id("EditDatabaseUserTextBox")).Clear();
            Browser.Wd.FindElement(By.Id("EditDatabaseUserTextBox")).SendKeys(dbUser);
        }

        [When(@"Database Details page Databse Password is set to ""(.*)""")]
        public void WhenDatabaseDetailsPageDatabsePasswordIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string dbPassword = tmsCommon.GenerateData(p0);
            Browser.Wd.FindElement(By.Id("EditDatabasePasswordTextBox")).SendKeys(dbPassword);
        }

        [When(@"Database Details page Input Folder text is entered as ""(.*)""")]
        public void WhenDatabaseDetailsPageInputFolderTextIsEnteredAs(string path)
        {
            tmsWait.Hard(3);
            Browser.Wd.FindElement(By.Id("InputFolder")).Clear();
            Browser.Wd.FindElement(By.Id("InputFolder")).SendKeys(path);
        }

        [When(@"Database Details page Input Folder text is entered as default value ""(.*)""")]
        public void WhenDatabaseDetailsPageInputFolderTextIsEnteredAsDefaultValue(string p0)
        {
            string sqlServer = tmsCommon.GenerateData(p0);
            string inputFolder = "\\" + sqlServer + "\\TMSShareFolder\\RAM\\Input";
            Browser.Wd.FindElement(By.Id("InputFolder")).Clear();
            Browser.Wd.FindElement(By.Id("InputFolder")).SendKeys(inputFolder);
        }

        [When(@"Database Details page Update Database button is clicked")]
        public void WhenDatabaseDetailsPageUpdateDatabaseButtonIsClicked()
        {
            tmsWait.Hard(3);
            Browser.Wd.FindElement(By.Id("Button1")).Click();
            tmsWait.Hard(2);
            Browser.Wd.SwitchTo().Alert().Accept();
        }


        [Given(@"FRM Home Page Expand Button is clicked")]
        public void GivenFRMHomePageExpandButtonIsClicked()
        {
            FRM.FRMMainPage.ProductExpandButton.Click();
            tmsWait.Hard(3);
        }

        [Given(@"FRM Home page Information button is clicked")]
        public void GivenFRMHomePageInformationButtonIsClicked()
        {
            tmsWait.Hard(2);
            FRM.FRMMainPage.informationButton.Click();
            tmsWait.Hard(2);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//*[@id='TMSAdminHeading']//li[contains(., '" + ConfigFile.FRMdb + "')]")).Displayed, "FRM Database name is not displayed.");
        }


        [Then(@"TMS Data Load Manager page ""(.*)"" section is ""(.*)""")]
        public void WhenTMSDataLoadManagerPageSectionIs(string menu, string state)
        {
            try
            {
                switch (menu)
                {
                    case "MMR Load":
                        if (state.ToLower().Equals("invisible"))
                        {
                            Assert.IsFalse((Browser.Wd.FindElement(By.XPath("//span[contains(.,'MMR Load')]"))).Displayed, menu + " is not visible");
                        }
                        else
                        {
                            Assert.IsTrue(FRM.FRMAdministrator.FRMAdministrationMenu.Text.Equals(menu), menu + " is visible");
                        }
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
            }
        }

        [Then(@"FRM Home Page ""(.*)"" menu should ""(.*)""")]
        public void ThenFRMHomePageMenuShould(string menu, string state)
        {
            try
            {
                switch (menu.ToLower())
                {
                    case "administration":
                        if (state.ToLower().Equals("invisible"))
                        {
                           
                                AngularFunction.elementNotPresenceUsingLocators(FRM.FRMAdministrator.FRMAdministrationMenu);
                            
                           
                        }
                        else
                        {
                            Assert.IsTrue(FRM.FRMAdministrator.FRMAdministrationMenu.Text.Equals(menu), menu + " is visible");
                        }
                        break;
                    case "adjust discrepancy":
                        if (state.ToLower().Equals("invisible"))
                        {
                            AngularFunction.elementNotPresenceUsingLocators(FRM.FRMAdministrator.FRMAdjustDiscrepancyLink);
                        }
                        else
                        {
                            Assert.IsTrue(FRM.FRMAdministrator.FRMAdjustDiscrepancyLink.Text.Equals(menu), menu + " is visible");
                        }
                        break;
                    case "view":
                        if (state.ToLower().Equals("invisible"))
                        {
                            AngularFunction.elementNotPresenceUsingLocators(FRM.FRMAdministrator.FRMViewSection);
                        }
                        else
                        {
                            Assert.IsTrue(FRM.FRMAdministrator.FRMViewSection.Text.Equals(menu), menu + " is visible");
                        }
                        break;
                    case "enroll/disenroll member":
                        if (state.ToLower().Equals("invisible"))
                        {
                            AngularFunction.elementNotPresenceUsingLocators(FRM.FRMAdministrator.FRMEnrollDisenrollLink);
                        }
                        else
                        {
                            Assert.IsTrue(FRM.FRMAdministrator.FRMEnrollDisenrollLink.Text.Equals(menu), menu + " is visible");
                        }
                        break;
                    case "job processing status":
                        if (state.ToLower().Equals("invisible"))
                        {
                            AngularFunction.elementNotPresenceUsingLocators(FRM.FRMAdministrator.FRMFileProcessingmenu);
                        }
                        else
                        {
                            Assert.IsTrue(FRM.FRMAdministrator.FRMFileProcessingmenu.Text.Equals(menu), menu + " is visible");
                        }
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
            }
        }

        [When(@"TMS FRM page Main menu is Clicked")]
        public void WhenTMSFRMPageMainMenuIsClicked()
        {
            FRM.FRMLogin.MainMenu.Click();
            tmsWait.Hard(2);
        }

        [When(@"TMS FRM page Product Dropdown list EAM Application is Selected")]
        public void WhenTMSFRMPageProductDropdownListEAMApplicationIsSelected()
        {

            string myDatabase = "EAM|" + ConfigFile.EAMdb;

            Browser.Wd.FindElement(By.Id("dropdownProduct")).Click();
            tmsWait.Hard(3);
            IList<IWebElement> pdt = Browser.Wd.FindElements(By.XPath("//ul[@aria-labelledby='dropdownProduct']/li"));
    
            Boolean bFoundDBInList = false;
            for (int k = 0; k < pdt.Count; k++)
            {
                if (pdt[k].Text == myDatabase)
                {
                    bFoundDBInList = true;

                    string menu = pdt[k].Text;

                    Browser.Wd.FindElement(By.LinkText(menu)).Click();

                   // pdt[k].Click();

                    break;
                }
            }


            if (!bFoundDBInList)
            {
                Assert.AreEqual(true, false, "Trying to select Product " + myDatabase + ", unable to find it in the Product dropdown list");
            }
            else
            {
                Console.WriteLine("Trying to select Product " + myDatabase + ", was able to find it in the Product dropdown list");
            }
        }

        [Then(@"Verify EAM Home page is displayed")]
        public void ThenVerifyEAMHomePageIsDisplayed()
        {
            tmsWait.Hard(2);
            Assert.AreEqual("Home", Browser.Wd.Title, " EAM Home page is getting displayed");
        }

        [When(@"TMS FRM page Main section is Clicked")]
        public void WhenTMSFRMPageMainSectionIsClicked()
        {
            tmsWait.Hard(12);
            fw.ExecuteJavascript(FRM.FRMAdministrator.FRMHomemenu);
            tmsWait.Hard(2);
        }

        [When(@"TMS FRM page Reports section is Clicked")]
        public void WhenTMSFRMPageReportsSectionIsClicked()
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(FRM.FRMMainmenu.Reports);
            
        }

        [When(@"TMS FRM page Administration section Run Enrollment Check submenu is Clicked")]
        public void WhenTMSFRMPageAdministrationSectionRunEnrollmentCheckSubmenuIsClicked()
        {
            tmsWait.Hard(3);
            fw.ExecuteJavascript(FRMMainNavigation.FRMAdministartormenurunEnrollmentCheck);
        }

        [When(@"TMS FRM page Administration section File Processing submenu is Clicked")]
        public void WhenTMSFRMPageAdministrationSectionFileProcessingSubmenuIsClicked()
        {
            tmsWait.Hard(12);
            
                fw.ExecuteJavascript(FRM.FRMAdministrator.FRMFileProcessingmenu);
            
        }


        [When(@"TMS FRM page Administration section Batch Update submenu is Clicked")]
        public void WhenTMSFRMPageAdministrationSectionBatchUpdateSubmenuIsClicked()
        {
            tmsWait.Hard(3);
            //FRM.FRMLogin.MainMenu.Click();

            //FRM.FRMMainmenu.Administration.Click();
            //tmsWait.Hard(2);
            //FRMMainNavigation.FRMAdministartormenubatchUpdate.Click();
            fw.ExecuteJavascript(FRMMainNavigation.FRMAdministratormenu);
            tmsWait.Hard(3);

            fw.ExecuteJavascript(FRMMainNavigation.FRMAdministartormenubatchUpdate);
            
        }

        [When(@"TMS FRM page Administration section Change Plan ID submenu is Clicked")]
        public void WhenTMSFRMPageAdministrationSectionChangePlanIDSubmenuIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(FRMMainNavigation.FRMAdministratormenu);

            tmsWait.Hard(3);
            fw.ExecuteJavascript(FRMMainNavigation.ChangePlanIDLink);
        }


        [When(@"TMS FRM page Report Manager section is Clicked")]
        public void WhenTMSFRMPageReportManagerSectionIsClicked()
        {

            tmsWait.Hard(3);
            fw.ExecuteJavascript(FRM.FRMMainmenu.ReportManager);
        }

        [When(@"TMS FRM page Change Plan ID section Save button is Clicked")]
        public void WhenTMSFRMPageChangePlanIDSectionSaveButtonIsClicked()
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(FRM.FRMChangePlanID.SaveButton);
          
            tmsWait.Hard(3);
        }
        [When(@"TMS FRM page Change Plan ID section ""(.*)"" option is Clicked")]
        public void WhenTMSFRMPageChangePlanIDSectionOptionIsClicked(string p0)
        {
            string option = p0.ToString();

            switch(option)
            {
                case "Part C":
                    fw.ExecuteJavascript(FRM.FRMChangePlanID.PartCOption);
                    tmsWait.Hard(2);
                    break;
                case "Part D":
                    fw.ExecuteJavascript(FRM.FRMChangePlanID.PartDOption);
                    tmsWait.Hard(2);
                    break;
            }
        }


        [When(@"TMS FRM page Change Plan ID section Add button is Clicked")]
        public void WhenTMSFRMPageChangePlanIDSectionAddButtonIsClicked()
        {
            tmsWait.Hard(2);
            FRM.FRMChangePlanID.AddButton.Click();
            tmsWait.Hard(2);
        }


        [When(@"TMS FRM page Change Plan ID section Current Plan Enrolled is Clicked")]
        public void WhenTMSFRMPageChangePlanIDSectionCurrentPlanEnrolledIsClicked()
        {
            tmsWait.Hard(13);
            FRM.FRMChangePlanID.CurrentPlanEnrolledCheckbox.Click();
        }

        [When(@"TMS FRM page Change Plan ID section MBI selected from Lookup")]
        public void WhenTMSFRMPageChangePlanIDSectionMBISelectedFromLookup()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@test-id='changePlanId-span-existingSearchName']/a")));
            tmsWait.Hard(5);
            Browser.Wd.FindElement(By.XPath("//input[@test-id='searchHIC-txt-ClaimNumberHicID']")).SendKeys("HIC");
            tmsWait.Hard(1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='searchHIC-btn-PopupexistingSearchNamenbtnS']")));
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='searchHIC-grid-hicnameGrid']//span[@class='fas fa-info-circle border-0 p-0 text-secondary'])[1]")));
            tmsWait.Hard(3);
        }



        [When(@"TMS FRM page Change New Plan ID is set to ""(.*)""")]
        public void WhenTMSFRMPageChangeNewPlanIDIsSetTo(string expected)
        {
            //IWebElement drp = Browser.Wd.FindElement(By.CssSelector("[test-id='changePlanId-select-selectedPlanId']"));
            //fw.ExecuteJavascript(drp);
            //tmsWait.Hard(2);
            //IWebElement value = Browser.Wd.FindElement(By.XPath("(//select[@test-id='changePlanId-select-selectedPlanId']/option)[2]"));
            //fw.ExecuteJavascript(value);
            String p0 = tmsCommon.GenerateData(expected);

            //By Drp = By.XPath("//label[text()='New Plan ID']/parent::div//span[@class='k-select']");
            //By typeapp = By.XPath("//li[text()='" + p0 + "']");


            //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
            //tmsWait.Hard(3);
            //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

            //SelectElement newplan = new SelectElement(FRM.FRMChangePlanID.NewPlanID);

            By Drp = By.XPath("//label[contains(.,'New Plan ID')]/parent::div//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + p0 + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);

        }

        [Then(@"Verify TMS FRM page Change Plan ID section displayed Success message ""(.*)""")]
        public void ThenVerifyTMSFRMPageChangePlanIDSectionDisplayedSuccessMessage(string p0)
        {

            tmsWait.Hard(15);
            String expected = p0.ToString();
            string actual = FRM.FRMChangePlanID.SucessMessage.Text;
            Assert.AreEqual(expected, actual, expected + " message is getting displayed");
        }


        [Then(@"Verify TMS FRM page Change Plan ID section displayed error message ""(.*)""")]
        public void ThenVerifyTMSFRMPageChangePlanIDSectionDisplayedErrorMessage(string p0)
        {
            tmsWait.Hard(10);
            String expected = p0.ToString();
            string actual = FRM.FRMChangePlanID.ErrorMessage.Text;
            Assert.AreEqual(expected, actual, expected+" message is getting displayed");
        }

        //[When(@"TMS FRM page Change Plan ID section HIC Number value is set to ""(.*)""")]
        //public void WhenTMSFRMPageChangePlanIDSectionHICNumberValueIsSetTo(string hic)
        //{
        //    FRM.FRMChangePlanID.HICNumber.Clear();
        //    FRM.FRMChangePlanID.HICNumber.SendKeys(hic);

        //    tmsWait.Hard(5);
        //}


        [When(@"TMS FRM UI page Change Plan ID section HIC Number value is set to ""(.*)""")]
        public void WhenTMSFRMUIPageChangePlanIDSectionHICNumberValueIsSetTo(string hic)
        {
            FRM.FRMChangePlanID.HICNumber.Clear();
            FRM.FRMChangePlanID.HICNumber.SendKeys(hic);
            tmsWait.Hard(5);
        }

        [When(@"TMS FRM UI page Change Plan ID section MBI Number value is set to ""(.*)""")]
        public void WhenTMSFRMUIPageChangePlanIDSectionMBINumberValueIsSetTo(string p0)
        {
            IWebElement mbiLookup = Browser.Wd.FindElement(By.XPath("//span[@test-id='changePlanId-span-existingSearchName']/a"));
            fw.ExecuteJavascript(mbiLookup);
            tmsWait.Hard(5);
            IWebElement reset = Browser.Wd.FindElement(By.CssSelector("[test-id='searchHIC-btn-resetHicNameSearch']"));
            fw.ExecuteJavascript(reset);
            tmsWait.Hard(2);
            IWebElement mbi = Browser.Wd.FindElement(By.CssSelector("[test-id='searchHIC-txt-ClaimNumberHicID']"));
            mbi.Clear();
            mbi.SendKeys("MBI");
            IWebElement searchBtn = Browser.Wd.FindElement(By.CssSelector("[test-id='searchHIC-btn-PopupexistingSearchNamenbtnS']"));
            fw.ExecuteJavascript(searchBtn);

            try
            {
                By toastMsg = By.XPath("//div[@class='toast-message'][contains(.,'No items found matching the search criteria.')]");
                bool msgDisplay = Browser.Wd.FindElement(toastMsg).Displayed;
                if (!msgDisplay)
                {
                    mbi.Clear();
                    mbi.SendKeys("123");
                    fw.ExecuteJavascript(searchBtn);
                }
            }
            catch { }
           

            tmsWait.Hard(2);
            IWebElement select = Browser.Wd.FindElement(By.XPath("//a[@title='Select']"));
            fw.ExecuteJavascript(select);
            tmsWait.Hard(2);



        }


        [When(@"TMS FRM page Change Plan ID section HIC Number value is set to ""(.*)""")]
        public void WhenTMSFRMPageChangePlanIDSectionHICNumberValueIsSetTo(string p0)
        {
            string hic = tmsCommon.GenerateData(p0);
            FRM.FRMChangePlanID.HICNumber.Clear();
            FRM.FRMChangePlanID.HICNumber.SendKeys(hic);
            FRM.FRMChangePlanID.HICNumber.SendKeys(OpenQA.Selenium.Keys.Tab);
            tmsWait.Hard(5);
        }


        [When(@"I Clicked on ""(.*)"" section")]
        public void WhenIClickedOnSection(string tabs)
        {
            tmsWait.Hard(2);
            IWebElement tab = Browser.Wd.FindElement(By.XPath("//li[@heading='"+tabs+"']/a"));
            fw.ExecuteJavascript(tab);
            tmsWait.Hard(2);
        }



        [Given(@"FRM Application I Clicked on ""(.*)"" menu")]
        [When(@"FRM Application I Clicked on ""(.*)"" menu")]
        public void GivenFRMApplicationIClickedOnMenu(string menu)
        {
            tmsWait.Hard(2);
            IWebElement menuElement = Browser.Wd.FindElement(By.XPath("//a[@title='"+ menu + "']"));
            fw.ExecuteJavascript(menuElement);
            tmsWait.Hard(2);
        }
        [When(@"I Entered new MBI in ""(.*)""")]
        public void WhenIEnteredNewMBIIn(string p0)
        {
            string changeMBI = tmsCommon.GenerateData(p0);
            IWebElement newMBI = Browser.Wd.FindElement(By.CssSelector("[test-id='changeIndHIC-txt-NewHic']"));
            newMBI.SendKeys(changeMBI);
        }

        [When(@"I Entered MBI in ""(.*)""")]
        public void WhenIEnteredMBIIn(string p0)
        {
            string changeMBI = tmsCommon.GenerateData(p0);
            IWebElement newMBI = Browser.Wd.FindElement(By.CssSelector("[test-id='hicNameSearchCriteria-inp-txtHic']"));
            newMBI.SendKeys(changeMBI);
        }


        [When(@"I Clicked on Update button")]
        public void WhenIClickedOnUpdateButton()
        {
            IWebElement lookup = Browser.Wd.FindElement(By.CssSelector("[test-id='changeIndHIC-btn-individualbtnUpdate']"));
            fw.ExecuteJavascript(lookup);
            tmsWait.Hard(2);
            IWebElement yes = Browser.Wd.FindElement(By.CssSelector("[test-id='confirmationDialog-btn-Yes']"));
            fw.ExecuteJavascript(yes);
            tmsWait.Hard(4);
        }


        [When(@"I selected MBI Change Reason from Drop down list")]
        public void WhenISelectedMBIChangeReasonFromDropDownList()
        {
            IWebElement reason = Browser.Wd.FindElement(By.CssSelector("[test-id='changeIndHIC-select-reasonHicID']"));


            By Drp = By.XPath("//kendo-dropdownlist[@test-id='changeIndHIC-select-reasonHicID']//span[@class='k-select']");
            By typeapp = By.XPath("//li[contains(.,'U')]");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            //new SelectElement(reason).SelectByIndex(2);

        }
        [When(@"I Clicked on View link")]
        public void WhenIClickedOnViewLink()
        {
            IWebElement view = Browser.Wd.FindElement(By.XPath("(//a[@title='Select'])[1]"));
            fw.ExecuteJavascript(view);
        }

        [When(@"I Clicked on Search button")]
        public void WhenIClickedOnSearchButton()
        {
            IWebElement search = Browser.Wd.FindElement(By.CssSelector("[test-id='hicNameSearchCriteria-btn-btnSearch']"));
            fw.ExecuteJavascript(search);
        }

        [When(@"I Clicked on View link on Search Results")]
        public void WhenIClickedOnViewLinkOnSearchResults()
        {
            IWebElement view = Browser.Wd.FindElement(By.XPath("//span[@title='View']"));
            fw.ExecuteJavascript(view);
        }

        [When(@"I Clicked on Report button on MBI Change History page")]
        public void WhenIClickedOnReportButtonOnMBIChangeHistoryPage()
        {

            IWebElement report = Browser.Wd.FindElement(By.CssSelector("[test-id='hicChangeHist-btn-btnReportSuggest']"));
            fw.ExecuteJavascript(report);
            tmsWait.Hard(2);
        }


        [When(@"I Clicked on ""(.*)"" link")]
        public void WhenIClickedOnLink(string p0)
        {
            IWebElement view = Browser.Wd.FindElement(By.LinkText(p0));
            fw.ExecuteJavascript(view);
        }


        [When(@"I selected any Existing MBI from MBI Lookup page")]
        public void WhenISelectedAnyExistingMBIFromMBILookupPage()
        {
            
            IWebElement lookup = Browser.Wd.FindElement(By.XPath("//a[@test-id='deleteSubmittedDiagnosis-a-providerLookup']"));
            fw.ExecuteJavascript(lookup);
            tmsWait.Hard(4);
            //IWebElement mbi = Browser.Wd.FindElement(By.CssSelector("[test-id='member-txt-hic']"));
            //mbi.SendKeys("MBI");
            //tmsWait.Hard(1);
            IWebElement search = Browser.Wd.FindElement(By.CssSelector("[test-id='member-btn-search']"));
            fw.ExecuteJavascript(search);
            tmsWait.Hard(1);
            IWebElement selectcheckbox = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='member-grid-auditslist']//tr[1]//input"));
            fw.ExecuteJavascript(selectcheckbox);
            tmsWait.Hard(1);
            IWebElement selectedmbi = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='member-grid-auditslist']//tr[1]//td[@aria-colindex='3']"));
            GlobalRef.MBI = selectedmbi.Text;
            IWebElement Addbtn = Browser.Wd.FindElement(By.XPath("//button[@test-id='member-btn-add']"));
            fw.ExecuteJavascript(Addbtn);
            tmsWait.Hard(2);


            //try
            //{
            //    By toastMsg = By.XPath("//div[@class='toast-message'][contains(.,'No matching records found')]");
            //    bool msgDisplay = Browser.Wd.FindElement(toastMsg).Displayed;
            //     tmsWait.Hard(3);
            //    if (msgDisplay)
            //    {
            //        mbi.Clear();
            //        mbi.SendKeys("HICN031708");
            //        fw.ExecuteJavascript(search);
            //    }
            //}
            //catch
            //{

            //}

            //ReadOnlyCollection<IWebElement> selectMBI = Browser.Wd.FindElements(By.XPath("//div[@test-id='searchHIC-grid-hicnameGrid']//div[@role='gridcell'][2]/div"));

            //foreach(IWebElement temp in selectMBI)
            //{
            //    GlobalRef.MBI = temp.Text;
            //    break;
            //}

            //IWebElement view = Browser.Wd.FindElement(By.XPath("(//a[@title='Select'])[1]"));
            //fw.ExecuteJavascript(view);
            ////IWebElement backtorecord = Browser.Wd.FindElement(By.CssSelector("[test-id='searchHIC-span-Back']"));
            ////fw.ExecuteJavascript(backtorecord);
            //tmsWait.Hard(2);

            

        }


        [When(@"TMS FRM page ""(.*)"" option is Selected")]
        public void WhenTMSFRMPageOptionIsSelected(string p0)
        {
            string optionbutton = p0.ToString();

            switch(optionbutton)
            {
                case "Enrollment Disenrollment":

                    fw.ExecuteJavascript(FRM.BatchUpdateProcessing.EnrollDisenroll);
                    break;
                case "MBI Change":
                    fw.ExecuteJavascript(FRM.BatchUpdateProcessing.HICChange);
                    break;
                   
                case "Flag Update":
                    fw.ExecuteJavascript(FRM.BatchUpdateProcessing.FlagUpdate);
                    break;
                    

            }
            tmsWait.Hard(5);
        }

        [When(@"TMS FRM page Batch Update Processing page Browse button is Clicked")]
        public void WhenTMSFRMPageBatchUpdateProcessingPageBrowseButtonIsClicked()
        {
            
        }

        [When(@"TMS FRM page Batch Update Processing page Upload button is Clicked")]
        public void WhenTMSFRMPageBatchUpdateProcessingPageUploadButtonIsClicked()
        {

            fw.ExecuteJavascript(FRM.BatchUpdateProcessing.Upload);
            
        }

        [When(@"File Processing Status page Next button is Clicked")]
        public void WhenFileProcessingStatusPageNextButtonIsClicked()
        {

            FRM.FRMFilesProcessingStatus.NextButton.Click();
        }

        [When(@"TMS FRM Administration page Plan Star Ratings section Page Size is set to ""(.*)""")]
        public void WhenTMSFRMAdministrationPagePlanStarRatingsSectionPageSizeIsSetTo(string p0)
        {

            FRM.PlanStartRating.PlanStarRatingPageSize.Clear();

            tmsWait.Hard(2);
            FRM.PlanStartRating.PlanStarRatingPageSize.SendKeys(p0);


           
        }

        [Then(@"Verify Plan Star Rating page Verify Pagination is getting displayed")]
        public void ThenVerifyPlanStarRatingPageVerifyPaginationIsGettingDisplayed()
        {
            tmsWait.Hard(2);
            IWebElement pagination = Browser.Wd.FindElement(By.XPath("(//kendo-pager)[1]"));
            bool elementPresence = pagination.Displayed;

            Assert.IsTrue(elementPresence, " Pagination is not getting displayed");

        }


        [When(@"Plan Star Ratings page Next button is Clicked")]
        public void WhenPlanStarRatingsPageNextButtonIsClicked()
        {
            tmsWait.Hard(2);
            FRM.PlanStartRating.PaginationNext.Click();
        }


        [Then(@"Verify Plan Star Ratings page ""(.*)"" button is ""(.*)""")]
        public void ThenVerifyPlanStarRatingsPageButtonIs(string p0, string p1)
        {

            string button = p0.ToString();
            string status = p1.ToString();
            switch (button)
            {
                case "Next":

                    if (status.Equals("Enabled"))
                    {
                        Assert.IsTrue(FRM.PlanStartRating.PaginationNext.Enabled, p0 + "button is enabled");
                    }

                    else if (status.Equals("Disabled"))
                    {
                        Assert.IsTrue(FRM.PlanStartRating.PlanStarRatingPaginationNext.GetAttribute("disabled").Contains("disabled"), p0 + "button is Disabled");
                    }

                    break;

                case "Previous":

                    if (status.Equals("Enabled"))
                    {
                        Assert.IsTrue(FRM.PlanStartRating.PaginationPrevious.Enabled, p0 + "button is not enabled");
                    }

                    else if (status.Equals("Disabled"))
                    {
                       
                        Assert.IsTrue(FRM.PlanStartRating.PlanStarRatingPaginationPrevious.GetAttribute("disabled").Contains("disabled"), p0 + "button is Disabled");
                    }

                    break;

                case "First":

                    if (status.Equals("Enabled"))
                    {
                        Assert.IsTrue(FRM.PlanStartRating.PaginationFirst.Enabled, p0 + "button is enabled");
                    }

                    else if (status.Equals("Disabled"))
                    {
                        Assert.IsTrue(FRM.PlanStartRating.PlanStarRatingPaginationFirst.GetAttribute("disabled").Contains("disabled"), p0 + "button is Disabled");
                    }

                    break;
                case "Last":

                    if (status.Equals("Enabled"))
                    {
                        Assert.IsTrue(FRM.PlanStartRating.PaginationLast.Enabled, p0 + "button is enabled");
                    }

                    else if (status.Equals("Disabled"))
                    {
                        Assert.IsTrue(FRM.PlanStartRating.PlanStarRatingPaginationLast.GetAttribute("disabled").Contains("disabled"), p0 + "button is Disabled");
                    }

                    break;


            }

        }
        [Then(@"Verify Job Processing Status page ""(.*)"" button is ""(.*)""")]
        public void ThenVerifyJobProcessingStatusPageButtonIs(string p0, string p1)
        {

            string button = p0.ToString();
            string status = p1.ToString();
            switch (button)
            {
                case "Next":

                    if (status.Equals("Enabled"))
                    {
                        Assert.IsTrue(FRM.FRMFilesProcessingStatus.NextButton.Enabled, p0 + "button is enabled");
                    }

                    else if (status.Equals("Disabled"))
                    {
                        Assert.IsTrue(FRM.FRMFilesProcessingStatus.FilePrcessingPaginationNext.GetAttribute("class").Contains("disabled"), p0 + "button is Disabled");
                    }

                    break;

                case "Previous":

                    if (status.Equals("Enabled"))
                    {
                        Assert.IsTrue(FRM.FRMFilesProcessingStatus.PreviousButton.Enabled, p0 + "button is enabled");
                    }

                    else if (status.Equals("Disabled"))
                    {
                        Assert.IsTrue(FRM.FRMFilesProcessingStatus.FilePrcessingPaginationPrevious.GetAttribute("class").Contains("disabled"), p0 + "button is Disabled");
                    }

                    break;

                case "First":

                    if (status.Equals("Enabled"))
                    {
                        Assert.IsTrue(FRM.FRMFilesProcessingStatus.FirstButton.Enabled, p0 + "button is enabled");
                    }

                    else if (status.Equals("Disabled"))
                    {
                        Assert.IsTrue(FRM.FRMFilesProcessingStatus.FilePrcessingPaginationFirst.GetAttribute("class").Contains("disabled"), p0 + "button is Disabled");
                    }

                    break;
                case "Last":

                    if (status.Equals("Enabled"))
                    {
                        Assert.IsTrue(FRM.FRMFilesProcessingStatus.LastButton.Enabled, p0 + "button is enabled");
                    }

                    else if (status.Equals("Disabled"))
                    {
                        Assert.IsTrue(FRM.FRMFilesProcessingStatus.FilePrcessingPaginationLast.GetAttribute("class").Contains("disabled"), p0 + "button is Disabled");
                    }

                    break;


            }
        }


        [Then(@"Verify File Processing Status page ""(.*)"" button is ""(.*)""")]
        public void ThenVerifyFileProcessingStatusPageButtonIs(string p0, string p1)
        {
            string button = p0.ToString();
            string status = p1.ToString();
              switch(button)
            {
                case "Next":

                   if(status.Equals("Enabled"))
                    {
                        Assert.IsTrue(FRM.FRMFilesProcessingStatus.NextButton.Enabled,p0+"button is enabled");
                    }

                   else if(status.Equals("Disabled"))
                        {
                        Assert.IsTrue(FRM.FRMFilesProcessingStatus.FilePrcessingPaginationNext.GetAttribute("class").Contains("disabled"), p0 + "button is Disabled");
                    }

                    break;

                case "Previous":

                    if (status.Equals("Enabled"))
                    {
                        Assert.IsTrue(FRM.FRMFilesProcessingStatus.PreviousButton.Enabled, p0 + "button is enabled");
                    }

                    else if (status.Equals("Disabled"))
                    {
                        Assert.IsTrue(FRM.FRMFilesProcessingStatus.FilePrcessingPaginationPrevious.GetAttribute("class").Contains("disabled"), p0 + "button is Disabled");
                    }

                    break;

                case "First":

                    if (status.Equals("Enabled"))
                    {
                        Assert.IsTrue(FRM.FRMFilesProcessingStatus.FirstButton.Enabled, p0 + "button is enabled");
                    }

                    else if (status.Equals("Disabled"))
                    {
                        Assert.IsTrue(FRM.FRMFilesProcessingStatus.FilePrcessingPaginationFirst.GetAttribute("class").Contains("disabled"), p0 + "button is Disabled");
                    }

                    break;
                case "Last":

                    if (status.Equals("Enabled"))
                    {
                        Assert.IsTrue(FRM.FRMFilesProcessingStatus.LastButton.Enabled, p0 + "button is enabled");
                    }

                    else if (status.Equals("Disabled"))
                    {
                        Assert.IsTrue(FRM.FRMFilesProcessingStatus.FilePrcessingPaginationLast.GetAttribute("class").Contains("disabled"), p0 + "button is Disabled");
                    }

                    break;


            }
        

        }


        [Then(@"Verify TMS FRM page ""(.*)"" section page is displayed")]
        public void ThenVerifyTMSFRMPageSectionPageIsDisplayed(string p0)
        {
            string expected = p0.ToString();
            switch (expected)
            {
                case "Dashboard":
                    tmsWait.Hard(3);
                    Assert.AreEqual(expected, FRM.FRMMainmenu.DashboardPage.Text, expected + "page is getting displayed");
                    tmsWait.Hard(3);
                    //FRM.FRMLogin.MainMenu.Click();
                    break;
                case "Main":
                    // Due to discripancy in Chrome and FF browser below code update to work in all browser
                    tmsWait.Hard(5);
                    Assert.AreEqual(expected, FRM.FRMMainmenu.FRMMainpage.Text, expected + "page is getting displayed");
                    break;
                case "FRM Main":
                    // Due to discripancy in Chrome and FF browser below code update to work in all browser
                    tmsWait.Hard(5);
                    By loc = By.XPath("//div[@class='adminTitle ng-scope']/span[contains(.,'"+ expected + "')]");
                    UIMODUtilFunctions.elementPresenceUsingLocators(loc);
                    break;
                case "Job Processing Status":
                    tmsWait.Hard(3);
                    Assert.AreEqual(expected, FRM.FRMMainmenu.FileProcessingStatusPage.Text, expected + "page is getting displayed");
                    break;
                case "Report List":
                    tmsWait.Hard(3);
                    Assert.AreEqual(expected, FRM.FRMMainmenu.ReportsPage.Text, expected + "page is getting displayed");
                    break;
                case "Report Manager":
                    tmsWait.Hard(3);
                    Assert.AreEqual(expected, FRM.FRMMainmenu.ReportManagerPage.Text, expected + "page is getting displayed");
                    break;
                case "Enrollment Check":
                    tmsWait.Hard(3);
                    Assert.AreEqual(expected, FRM.FRMEnrollmentCheck.PageTitle.Text, expected + "page is getting displayed");
                    break;
                case "Change Plan ID":
                    tmsWait.Hard(3);
                    Assert.AreEqual(expected, FRM.FRMEnrollmentCheck.PageTitle.Text, expected + "page is getting displayed");
                    break;
                case "Batch Update Processing":
                    tmsWait.Hard(3);
                    Assert.AreEqual("Batch Update", FRM.BatchUpdateProcessing.PageTitle.Text, expected + "page is getting displayed");
                    break;

                case "File Processing Status":
                    tmsWait.Hard(3);
                    Assert.AreEqual(expected, FRM.FRMMainmenu.FileProcessingStatusPage.Text, expected + "page is getting displayed");
                    break;
            }
        }

        [When(@"TMS FRM Page Administration section Run Enrollment Check button is Clicked")]
        public void WhenTMSFRMPageAdministrationSectionRunEnrollmentCheckButtonIsClicked()
        {
            fw.ExecuteJavascript(FRM.FRMEnrollmentCheck.RunEnrollmentCheckButton);
            tmsWait.Hard(3);
        }

        [Then(@"Verify TMS FRM Page Administration section Run Enrollment Check display message ""(.*)""")]
        public void ThenVerifyTMSFRMPageAdministrationSectionRunEnrollmentCheckDisplayMessage(string p0)
        {
            tmsWait.Hard(5);
            //string expected = p0.ToString();
            //string actual = FRM.FRMEnrollmentCheck.Successmessage.Text;

            bool results = FRM.FRMEnrollmentCheck.Successmessage.Displayed;

            Assert.IsTrue(results, p0+ " message is not getting displayed");
        }

        [Then(@"Verify FRM Exports displayed Export List ""(.*)""")]
        public void ThenVerifyFRMExportsDisplayedExportList(string list)
        {
            By exportList = By.XPath("(//ul[@test-id='export-ul-exportjoblist']//label[contains(.,'"+ list + "')])[1]");
            UIMODUtilFunctions.elementPresenceUsingLocators(exportList);
        }


        [When(@"TMS FRM page ""(.*)"" section is Clicked")]
        public void WhenTMSFRMPageSectionIsClicked(string p0)
        {
            string expected = p0.ToString();
           
            tmsWait.Hard(3);
            switch (expected)
            {

                case "Dashboard":
                    tmsWait.Hard(3);
                  
                    FRM.FRMMainmenu.Dashboard.Click();
                   
                    break;

                case "FRM Main":
               
                    tmsWait.Hard(3);
               
                   
                    FRM.FRMMainmenu.Main.Click();
                    break;

                case "Job Processing Status":
                    tmsWait.Hard(3);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@title='Menu']")));
                    //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@title='Tasks']")));
                    FRM.FRMMainmenu.FileProcessingStatus.Click();
                    break;

                case "Report List":
                    tmsWait.Hard(3);
                
                    FRM.FRMMainmenu.Reports.Click();
                    break;
                case "FRM Report Manager":
                    tmsWait.Hard(3);
                
                    FRM.FRMMainmenu.ReportManager.Click();
                    break;
                case "Task Export":
                    tmsWait.Hard(3);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@title='Menu']")));
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@title='Tasks']")));
                    fw.ExecuteJavascript(FRM.FRMMainmenu.TaskExport);
                    break;

            }

        }



        [Given(@"I do an empty fast step")]
        public void GivenIDoAnEmptyFastStep()
        {
            Console.WriteLine(DateTime.Now.ToString());
        }

        [Given(@"I do another empty fast step")]
        public void GivenIDoAnotherEmptyFastStep()
        {
            Console.WriteLine(DateTime.Now.ToString());
        }

        [Then(@"I finish with another fast empty step")]
        public void ThenIFinishWithAnotherFastEmptyStep()
        {
            Console.WriteLine(DateTime.Now.ToString());
        }
        [When(@"I Clicked on icon")]
        public void WhenIClickedOnIcon()
        {
            tmsWait.Hard(2);
            IWebElement btn;
            if (ConfigFile.tenantType == "tmsx")
            {
                 btn = Browser.Wd.FindElement(By.XPath("//*[@id='adminLettersTooltipId']"));
                fw.ExecuteJavascript(btn);
                tmsWait.Hard(2);
            }
            else
            {
                btn = Browser.Wd.FindElement(By.XPath("//i[@test-id='letterTemplate-tooltip-letterTemplateTooltip']"));
                fw.ExecuteJavascript(btn);
                tmsWait.Hard(2);
            }
        }
    }





    [Binding]
    public class EAMNavigation
    {
        [Given(@"I have navigated to ""(.*)""")]
        [When(@"I have navigated to ""(.*)""")]
        [Then(@"I have navigated to ""(.*)""")]
        public void GivenIHaveNavigatedTo(string p0)
        {
           tmsWait.Hard(2);
         
            Boolean successful = false;
            int LoopCounter = 0;
            if (!successful && LoopCounter < 5)
            {
                LoopCounter++;
                try
                {
                    Navigation.ClickLink(p0);
                    successful = true;
                }
                catch
                {
                    Console.WriteLine("Failed attempt to do menu navigation for ["+ p0 +"] for ["+LoopCounter.ToString() +"] time");
                }
            }

            tmsWait.Hard(4);
        }

        [Then(@"Verify ERF is not Present on new UI MOD")]
        public void ThenVerifyERFIsNotPresentOnNewUIMOD()
        {
            try
            {
                IWebElement erf = Browser.Wd.FindElement(By.LinkText("EnrollmentRequestFormNew"));
            }
            catch
            {
                Assert.IsTrue(true," ERF is Present on new UI MOD");
            }

        }

        [Then(@"I clicked on Collapse button")]
        public void WhenIClickedOnCollapseButton()
        {
            try
            {   //button[@test-id='report-button-expandcolaps']
                tmsWait.Hard(2);
                IWebElement btn = Browser.Wd.FindElement(By.XPath("//button[@test-id='report-button-expandcolaps']"));
                fw.ExecuteJavascript(btn);
                tmsWait.Hard(2);
            }
            catch
            {

            }
        }
        [Then(@"I have navigated to ReportsQueue")]
        public void ThenIHaveNavigatedToReportsQueue()
        {
            tmsWait.Hard(2);
            Actions action = new Actions(Browser.Wd);
           

            //Double click
          
            IWebElement btn = Browser.Wd.FindElement(By.XPath("//label[contains(text(),'Queue')]"));
            //fw.ExecuteJavascript(btn);
            action.DoubleClick(btn).Perform();
            tmsWait.Hard(2);
        }


        [When(@"I have navigated to ""(.*)"" link")]
        [Then(@"I have navigated to ""(.*)"" link")]
        public void WhenIHaveNavigatedToLink(string linkname)
        {
            IWebElement link = Browser.Wd.FindElement(By.LinkText(linkname));
            fw.ExecuteJavascript(link);
        }


        [Then(@"I have navigated to link ""(.*)""")]
        public void ThenIHaveNavigatedToLink(string link)
        {
            IWebElement linkToClick = Browser.Wd.FindElement(By.LinkText(link));
            fw.ExecuteJavascript(linkToClick);
            tmsWait.Hard(5);
        }


        [Then(@"I have navigated to Compliance Enrollment Report")]
        [When(@"I have navigated to Compliance Enrollment Report")]
        [Given(@"I have navigated to Compliance Enrollment Report")]
        public void GivenIHaveNavigatedToComplianceEnrollmentReport()
        {
            fw.ExecuteJavascript(EAM.EnrollmentComplianceReport.EnrollemntLink);
            tmsWait.Hard(2);
        }

        [Then(@"I have navigated to NoRx Fallout Report")]
        public void ThenIHaveNavigatedToNoRxFalloutReport()
        {
            tmsWait.Hard(3);
            fw.ExecuteJavascript(EAM.NoRxFalloutReport.EnrollemntLink);
            tmsWait.Hard(2);
        }

        [Then(@"Transaction Missing CMS data Report File Name is selected as ""(.*)""")]
        public void ThenTransactionMissingCMSDataReportFileNameIsSelectedAs(string p0)
        {
            tmsWait.Hard(3);
            string variableFileName = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.ReportsTransMissingCMSData.FileName);
            select.SelectByText(variableFileName);
        }


        [When(@"I have navigated to ""(.*)"" page")]
        public void WhenIHaveNavigatedToPage(string link)
        {
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.LinkText(link)));

            String xpath = "//span[contains(text()," + "'" + link + "')]";
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(xpath)));
        }

        [Then(@"EAM Report page Run Button is click")]
        public void ThenEAMReportPageRunButtonIsClick()
        {
              fw.ExecuteJavascript(EAM.ReportsTransMissingCMSData.RunReport);
        }

        [Then(@"Transaction Missing CMS data Report MBI ""(.*)"" should be displayed")]
        public void ThenTransactionMissingCMSDataReportMBIShouldBeDisplayed(string p0)
        {
            By reportViewBy = EAM.Reports.ReportMainViewBy;
            string reportExpText = p0;
            string reportHandle = "";

            reportHandle = ReportsCommon.SwitchToReportWindow(reportViewBy, 30, reportExpText);

            if (reportHandle == "")
            {
                Assert.Fail("CMS Response Code Level Detail Report was not opened");
            }

            

            Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle);
        }



        [Then(@"Verify that ""(.*)"" Link is present")]
        public void ThenVerifyThatLinkIsPresent(string p0)
        {
            IReadOnlyList<IWebElement> links = Browser.Wd.FindElements(By.TagName("a"));

            for (int i = 0; i < links.Count; i++)
            {
                if (links[i].GetAttribute("LinkText") == p0)
                {
                    System.Console.WriteLine("Test Passed" + "Link should be present");
                    break;
                }
                else
                {
                    System.Console.WriteLine("Test Failed" + "Link should not be present");
                }
            }
        }


        [Then(@"Verify that ""(.*)"" Link is not present")]
        public void ThenVerifyThatLinkIsNotPresent(string p0)
        {
            IReadOnlyList<IWebElement> links = Browser.Wd.FindElements(By.TagName("a"));

            for (int i = 0; i < links.Count; i++)
            {
                if (links[i].GetAttribute("LinkText") == p0)
                {
                    System.Console.WriteLine("Test Failed" + " Link should not be present");
                    Assert.Fail();
                    break;
                }
                else
                {
                    System.Console.WriteLine("Test Passed" + " Link should not be present");
                    // Assert.IsTrue(true,);
                    break;
                }

            }
        }
        [Then(@"Very Auditing Configuration page Activity ""(.*)"" has ON OFF toggle button")]
        public void ThenVeryAuditingConfigurationPageActivityHasONOFFToggleButton(string p0)
        {
            tmsWait.Hard(5);
            IWebElement links = Browser.Wd.FindElement(By.XPath("//label[contains(.,'EAF Fallout')]/parent::div/following-sibling::div/kendo-switch/span"));

            tmsWait.Hard(5);

            Assert.IsTrue(links.Enabled);
           

        }

        [Then(@"Auditing Configuration page ""(.*)"" Activity toggle button is clicked")]
        public void ThenAuditingConfigurationPageActivityToggleButtonIsClicked(string p0)
        {
            tmsWait.Hard(5);
            IWebElement button = Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + p0 + "')]/parent::div/following-sibling::div//span[@class='k-switch-handle']"));
            tmsWait.Hard(5); tmsWait.Hard(5);

            button.Click();
        }
        [Then(@"Verify Auditing Configuration page ""(.*)"" Activity toggle button ""(.*)"" is displayed")]
        public void ThenVerifyAuditingConfigurationPageActivityToggleButtonIsDisplayed(string p0, string p1)
        {
            tmsWait.Hard(5);
            IWebElement current = Browser.Wd.FindElement(By.XPath("//label[contains(.,'EAF Fallout')]/parent::div/following-sibling::div//span[contains(@class,'" + p1 + "')]"));
            tmsWait.Hard(5); Assert.IsTrue(current.Displayed);
            
        }


        [Then(@"Auditing Configuration page ""(.*)"" Activity toggle button is set to ""(.*)""")]
        public void ThenAuditingConfigurationPageActivityToggleButtonIsSetTo(string p0, string p1)
        {
            IWebElement current = Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + p0 + "')]/parent::div/following-sibling::div/kendo-switch/span"));
            switch (p1)
            {
                case "off":
                    if (current.GetAttribute("aria-checked").Trim().ToLower().Equals("true") && p1.ToLower().Equals("off"))
                    {
                        Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + p0 + "')]/parent::div/following-sibling::div/kendo-switch//span[contains(text(),'Yes')]")).Click();
                        tmsWait.Hard(2);
                        Assert.IsFalse(Boolean.Parse(current.GetAttribute("aria-checked")));
                    }
                    else
                    {
                        Assert.IsFalse(Boolean.Parse(current.GetAttribute("aria-checked")));
                    }
                    break;

                case "on":
                    if (current.GetAttribute("aria-checked").Trim().ToLower().Equals("false") && p1.ToLower().Equals("on"))
                    {
                        Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + p0 + "')]/parent::div/following-sibling::div/kendo-switch//span[contains(text(),'No')]")).Click();
                        tmsWait.Hard(2);
                        Assert.IsTrue(Boolean.Parse(current.GetAttribute("aria-checked")));
                    }
                    else
                    {
                        Assert.IsTrue(Boolean.Parse(current.GetAttribute("aria-checked")));
                    }
                    break;                   
            }
        }


        [Then(@"Verify View/Edit Plan Info Table")]
        public void ThenVerifyViewEditPlanInfoTable(Table table)
        {
            tmsWait.Hard(3);
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.EditPLanInfo.EditPlanInfoTable;
                {

                }
                //Look for a next page link.  We will set 'last page of records' here also.
                           thisTP.LoadNextPageLink(baseTable);
                           tmsWait.Hard(3);

                           IWebElement baseTable1 = EAM.EditPLanInfo.EditPlanInfoTable;
                           tmsWait.Hard(2);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable1, "th", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            if (bThisRowMatches)
                            {
                                Assert.IsTrue(true);
                            }

                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }

                baseTable1 = EAM.EditPLanInfo.EditPlanInfoTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

        [Then(@"Verify Members View Edit Page table as the below row")]
        public void ThenVerifyMembersViewEditPageTableAsTheBelowRow(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.MembersSearch.MemberSearchTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Members View Edit Table has row: {0}", e.Message);
            } 
        }


        [When(@"Members View Edit Page modify a member")]
        public void WhenMembersViewEditPageModifyAMember(Table table)
        {

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.MembersSearch.MemberSearchTable;
                {

                }
                //Look for a next page link.  We will set 'last page of records' here also.
                //thisTP.LoadNextPageLink(baseTable);
                //thisTP.LoadNextGreaterThanPageLink(baseTable);


                //IWebElement baseTable1 = EAM.MembersSearch.MemberSearchTable;
                tmsWait.Hard(2);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)

                thisTP.LoadPageTable(baseTable, "th", "td");


                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                tmsWait.Hard(2);
                                iElementCounter++;

                            }
                            if (AppTableRow.Length == 0)
                            {

                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            tmsWait.Hard(2);

                            if (bThisRowMatches)
                            {
                                tmsWait.Hard(2);
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            if (bThisRowMatches)
                            {
                                tmsWait.Hard(4);
                                IList<IWebElement> rowImages = ApplicationRow.Element[0].FindElements(By.TagName("img"));
                                foreach (IWebElement thisImage in rowImages)
                                {
                                    tmsWait.Hard(1);
                                    if (thisImage.GetAttribute("src").Contains("icon_edit"))
                                    {
                                        tmsWait.Hard(2);
                                        fw.ExecuteJavascript(thisImage);
                                        tmsWait.Hard(2); break;
                                    }
                                }
                            }

                        }
                    }
                    tmsWait.Hard(2);
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                    break;
                }
                else
                {
                    //Click next page link and start over. 
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here. 
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        //thisTP.LoadNextGreaterThanPageLink(baseTable1);                        
                        tmsWait.Hard(5);
                    }
                }

                baseTable = EAM.MembersSearch.MemberSearchTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }



        [When(@"ViewEdit Plan Info Page modifiy PBP Type for planid ""(.*)"" and pbp ""(.*)""")]
        public void WhenViewEditPlanInfoPageModifiyPBPTypeForPlanidAndPbp(string p0, int p1)
        {
            int i = 0;
            while (i == 0)
            {

                try
                {
                    if (Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + p1 + "')]//preceding-sibling::td[contains(.,'" + p0 + "')]//preceding-sibling::td/a")).Displayed)
                    {
                        //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + p1 + "')]//preceding-sibling::td[contains(.,'" + p0 + "')]//preceding-sibling::td/a")));
                        Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + p1 + "')]//preceding-sibling::td[contains(.,'" + p0 + "')]//preceding-sibling::td/a")).Click();
                        break;
                    }
                }

                catch {

                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//td[contains(@class,'charData')]//a)[15]")));
                }
            }
        }



        [Then(@"View/Edit Plan Info Page modify PBP Type")]
        [When(@"View/Edit Plan Info Page modify PBP Type")]
        public void WhenViewEditPlanInfoPageModifyPBPTypeFor(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.EditPLanInfo.EditPlanInfoTable;
                {

                }
                //Look for a next page link.  We will set 'last page of records' here also.
                //thisTP.LoadNextPageLink(baseTable);
                thisTP.LoadNextGreaterThanPageLink(baseTable);
                tmsWait.Hard(1);

                IWebElement baseTable1 = EAM.EditPLanInfo.EditPlanInfoTable;
                tmsWait.Hard(2);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable1, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            tmsWait.Hard(1);
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;

                            }
                            if (AppTableRow.Length == 0)
                            {
                                tmsWait.Hard(1);
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();


                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            if (bThisRowMatches)
                            {
                                tmsWait.Hard(1);
                                IList<IWebElement> rowImages = ApplicationRow.Element[0].FindElements(By.TagName("img"));
                                foreach (IWebElement thisImage in rowImages)
                                {
                                    if (thisImage.GetAttribute("src").Contains("icon_edit"))
                                    {
                                        tmsWait.Hard(4);
                                        fw.ExecuteJavascript(thisImage);
                                        //thisImage.Click();
                                        tmsWait.Hard(1); break;
                                    }
                                }
                            }

                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over. 
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here. 
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        //thisTP.LoadNextGreaterThanPageLink(baseTable1);                        
                        tmsWait.Hard(1);
                    }
                }

                baseTable1 = EAM.EditPLanInfo.EditPlanInfoTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

        [Given(@"I click on the Details link")]
        public void GivenIClickOnTheDetailsLink()
        {
            try
            {
                IList<IWebElement> theseDetailLinks = Browser.Wd.FindElements(By.LinkText("Details"));
                theseDetailLinks[1].Click();
                tmsWait.Hard(1);
            }
            catch { }
        }

        [When(@"EAM Application Database delete link is clicked")]
        public void WhenEAMApplicationDatabaseDeleteLinkIsClicked(Table table)
        {
            try
            {
                IList<IWebElement> theseDetailLinks = Browser.Wd.FindElements(By.LinkText("Details"));
                theseDetailLinks[1].Click();
                tmsWait.Hard(1);
            }
            catch { }

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGt = new GherkinTable();
            TablePaging thisTp = new TablePaging();

            //Load the Gherkin table into the storage
            thisGt.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGt.GTable[0].AllRowsMatched(thisGt.GTable) == false && thisTp.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTp.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.AdministrationPage.ModifyApplicationDatabase;
                {

                }
                //Look for a next page link.  We will set 'last page of records' here also.
                thisTp.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTp.LoadPageTable(baseTable, "th", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGt.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTp.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTp.ReportMatching(thisTp.PageTable[iTableCounter], thisGt.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            if (bThisRowMatches)
                            {
                                IList<IWebElement> rowImages = ApplicationRow.Element[0].FindElements(By.TagName("input"));
                                foreach (IWebElement thisImage in rowImages)
                                {
                                    if (thisImage.GetAttribute("src").Contains("icon_delete"))
                                    {
                                        IJavaScriptExecutor js = Browser.Wd as IJavaScriptExecutor;
                                        js.ExecuteScript("arguments[0].click();", thisImage);
                                        // thisImage.Click();
                                        //tmsWait.Hard(2);

                                        IAlert conf = Browser.Wd.SwitchTo().Alert();
                                        conf.Accept();
                                        
                                        break;

                                    }
                                }
                                //IWebElement thisEditTD = ApplicationRow.Element[0];
                                ////IWebElement thisEditLink = thisEditTD.FindElement(By.TagName("a"));  EshvaryaM
                                //IWebElement thisEditLink = thisEditTD.FindElement(By.Id("DetailsView1_ctl02_setUIClientAppLinkID"));
                                //thisEditLink.Click();
                                //tmsWait.Hard(2);
                            }

                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGt.GTable[0].AllRowsMatched(thisGt.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                //UnComment Venkat
                else
                {
                    //Click next page link and start over.
                    if (thisTp.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTp.bNotAtLastPageOfRecords = true;
                        thisTp.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.AdministrationPage.ModifyApplicationDatabase;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTp.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTp.ReportNotMatching(thisGt.GTable);
                }
            }
            //string myDatabase = "EAM" + ConfigFile.EAMdb;
            ////var table = Browser.Wd.FindElement(By.Id("DetailsView1"));
            ////var db = table.FindElement(By.LinkText(myDatabase));
            ////string row = db.GetAttribute("Row");
            //IWebElement updateDB =  Browser.Wd.FindElement(By.Id("DetailsView1_ctl02_setUIClientAppLinkID"));
            //updateDB.Click();   
        }


        [When(@"EAM Application Database modify link is clicked")]
        public void WhenEAMApplicationDatabaseModifyLinkIsClicked(Table table)
        {
            try
            {
                IList<IWebElement> theseDetailLinks = Browser.Wd.FindElements(By.LinkText("Details"));
                theseDetailLinks[1].Click();
                tmsWait.Hard(1);
            }
            catch { }

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.AdministrationPage.ModifyApplicationDatabase;
                {

                }
                //Look for a next page link.  We will set 'last page of records' here also.
                  thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "th", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            if (bThisRowMatches)
                            {
                                IList<IWebElement> rowImages = ApplicationRow.Element[0].FindElements(By.TagName("input"));
                                foreach (IWebElement thisImage in rowImages)
                                {
                                    if (thisImage.GetAttribute("src").Contains("icon_edit"))
                                    {
                                        IJavaScriptExecutor js = Browser.Wd as IJavaScriptExecutor;
                                        js.ExecuteScript("arguments[0].click();", thisImage);
                                       // thisImage.Click();
                                        tmsWait.Hard(2); break;
                                    }
                                }
                                //IWebElement thisEditTD = ApplicationRow.Element[0];
                                ////IWebElement thisEditLink = thisEditTD.FindElement(By.TagName("a"));  EshvaryaM
                                //IWebElement thisEditLink = thisEditTD.FindElement(By.Id("DetailsView1_ctl02_setUIClientAppLinkID"));
                                //thisEditLink.Click();
                                //tmsWait.Hard(2);
                            }

                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                //UnComment Venkat
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.AdministrationPage.ModifyApplicationDatabase;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
            //string myDatabase = "EAM" + ConfigFile.EAMdb;
            ////var table = Browser.Wd.FindElement(By.Id("DetailsView1"));
            ////var db = table.FindElement(By.LinkText(myDatabase));
            ////string row = db.GetAttribute("Row");
            //IWebElement updateDB =  Browser.Wd.FindElement(By.Id("DetailsView1_ctl02_setUIClientAppLinkID"));
            //updateDB.Click();            
        }

        [Then(@"Verify Job status for the Job created")]
        public void ThenVerifyJobStatusForTheJobCreated(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.AdministrationJobsPage.JobsGrid;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Members View Edit Table has row: {0}", e.Message);
            }
 
        }
    }

    [Binding]
    public class EAMCloseApp
    {
        [Given(@"Browser will be closed")]
        [When(@"Browser will be closed")]
        [Then(@"EAM will be closed")]
        [Given(@"EAM will be closed")]
        [When(@"EAM will be closed")]
        [Then(@"Browser will be closed")]
        public void ThenEAMWillBeClosed()
        {
            tmsWait.Hard(2);
            Browser.Wd.Close();
            // Browser.Wd.Close();
            // Browser.CloseWebDriver();
            //Closing Winium Driver
            //  Browser.winium.Quit();
        }
        [Given(@"I closed the Browser")]
        [When(@"I closed the Browser")]
        [Then(@"I closed the Browser")]
        public void ThenIClosedTheBrowser()
        {
            tmsWait.Hard(2);
            Browser.Wd.Close();
        }

        [Given(@"I throw an error")]
        public void GivenIThrowAnError()
        {
            Assert.AreEqual(true, false, "Throwing an error just to throw an error");
        }


      


        [When(@"File is readed from Temp file")]
        public void WhenFileIsReadedFromTempFile()
        {
            
            string[] lines = System.IO.File.ReadAllLines(@"C:\tmp\EFTO.RH1001.DTRRD.D170421.StaticMemberUpdate_Arrow13320_01161");
           string[] st1 = new string[lines.Length];
           
            for (int i = 0; i < lines.Length; i++)
            {
               
                StringBuilder st = new StringBuilder(lines[i]);

                st.Remove(486, 5);
                st.Insert(486, "XXXXX");
                st1[i] = st.ToString();

                Console.WriteLine(st1[i]);
               
                
            }

            System.IO.File.WriteAllLines(@"C:\tmp\EFTO.RH1001.DTRRD.D170421.StaticMemberUpdate_Arrow13320_01161", st1);

        }

        [Then(@"PDEM will be closed")]
        public void ThenPDEMWillBeClosed()
        {
            Browser.CloseWebDriver();
        }


    }

    [Binding]
    public class EAMErrorPageHandlers
    {
        [Then(@"Error Page is not shown")]
        public void ThenErrorPageIsNotShown()
        {
            tmsWait.Hard(2);
            Boolean ErrorPageExists = false;
            ICollection<IWebElement> elementsTD = Browser.Wd.FindElements(By.TagName("td"));
            foreach (IWebElement thisElement in elementsTD)
            {
                string myElementText = thisElement.Text;
                if (myElementText == "Error Page")
                {
                    ErrorPageExists = true;
                }
            }
            Assert.AreEqual(false, ErrorPageExists, "Not Expecting the error page to exist, but it did");
        }
    }
}
