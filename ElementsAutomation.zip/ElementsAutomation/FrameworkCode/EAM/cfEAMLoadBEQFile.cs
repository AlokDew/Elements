﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using TechTalk.SpecFlow;
//using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using System.Diagnostics;
using System.Windows;
using TDAPIOLELib; // This is the QTP interop library 
using System.Net.Http;
using System.Net;

namespace TMSoR1
{   
    [Binding]
    public class LoadBEQFile 
        {
            public IWebElement Browse { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_FileUpload1")); } }
            public IWebElement Import { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnImportBEQ")); } }
            public IWebElement ResponseMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblMsg")); } }
        public IWebElement PlanIDDropdownlist { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPlan")); } }
        public IWebElement ExportButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnCreateBEQ")); } }
        public IWebElement BEQStaticMsg { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblMsg")); } }

        
    }    
}
