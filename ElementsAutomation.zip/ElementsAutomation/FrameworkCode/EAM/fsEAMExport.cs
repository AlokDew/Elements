﻿// Added by Swapna Chappidi
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;
using OpenQA.Selenium.Support.UI;
using System.Diagnostics;
using System.Windows;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Interactions.Internal;


using System.Drawing;
using OpenQA.Selenium.IE;
using System.IO;
using Microsoft.Data.SqlClient;
using TMSoR1.FrameworkCode;

namespace TMSoR1
{
    [Binding]
    public sealed class fsEAMExport
    {
        // For additional details on SpecFlow step definitions see http://go.specflow.org/doc-stepdef

        string documentPath = Path.Combine(Environment.ExpandEnvironmentVariables("%userprofile%"), "My Documents");
        string downloadPath = Path.Combine(Environment.ExpandEnvironmentVariables("%userprofile%"), "Downloads");
       // string downloadPath = "\\\\tcsdatacifs09.corp.trizetto.com\\citrixprofiles\\kuntal.shukla.upm\\DATA\\Downloads";

        

       

        [When(@"I Clicked on Export link")]
        public void WhenIClickedOnExportLink()
        {
            IWebElement export = Browser.Wd.FindElement(By.LinkText("Export"));
            fw.ExecuteJavascript(export);
            tmsWait.Hard(5);
        }

        [Then(@"EAM Export page ""(.*)"" link is clicked")]
        public void ThenEAMExportPageLinkIsClicked(string exportType)
        {
            IWebElement export = null;
            switch (exportType)
            {
                case "To Legacy Member":
                    export = Browser.Wd.FindElement(By.XPath("(//label[@test-id='export-lbl-member'])[2]"));                    
                    break;
            }
            tmsWait.Hard(3);
            fw.ExecuteJavascript(export);
        }


        [When(@"Legay Member PlanId is set to ""(.*)""")]
        public void WhenLegayMemberPlanIdIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(cfEAMExport.ExportLegacyMembers.PlanID);
            select.SelectByText(value);
            tmsWait.Hard(2);
        }

        [When(@"Legacy Member Status is set to ""(.*)""")]
        public void WhenLegacyMemberStatusIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(cfEAMExport.ExportLegacyMembers.MemberStatus);
            select.SelectByText(value);           
        }



        [When(@"Go Button is clicked")]
        public void WhenGoButtonIsClicked()
        {
            tmsWait.Hard(3);
            fw.ExecuteJavascript(cfEAMExport.ExportLegacyMembers.GoButton);
        }

        [When(@"Export Button is clicked")]
        public void WhenExportButtonIsClicked()
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(cfEAMExport.ExportLegacyMembers.ExportButton);
            tmsWait.Hard(5);
        }


        [Then(@"Legacy Member Export Grid is displayed")]
        public void ThenLegacyMemberExportGridIsDisplayed()
        {
            Assert.Fail();
        }

        [Then(@"Verify the message ""(.*)"" is displayed")]
        public void ThenVerifyTheMessageIsDisplayed(string p0)
        {
            tmsWait.Hard(10);
            string GeneratedData = tmsCommon.GenerateData(p0);
            string fieldValue = cfEAMExport.ExportLegacyMembers.ExportmemberJobInfo.Text;

            string subs = fieldValue.Substring(0, 51);

            Assert.AreEqual(p0,fieldValue.Substring(0,51));
        }


        [When(@"Downloaded Legacy Transaction file records Count is save in variable ""(.*)""")]
        public void WhenDownloadedLegacyTransactionFileRecordsCountIsSaveInVariable(string p0)
        {
            //string field = p0.ToString();
            string FileRecord_count = getMemberLegacyFileTotalRecordCount();
            fw.ConsoleReport(" Exported File Records Count --> " + FileRecord_count);
            fw.setVariable(p0, FileRecord_count);
        }

        public string getMemberLegacyFileTotalRecordCount()
        {
            tmsWait.Hard(5);    //Wait for download, save and reading purpose
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
            var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));

            var lastLine = System.IO.File.ReadLines(srcFile).Reverse();
            string line = lastLine.First();
            string[] LineArray = line.Split('*');
            GlobalRef.TotalcountInFile = Int32.Parse(LineArray[LineArray.Length - 1]);
           
            return LineArray[LineArray.Length - 1];
        }

        

        [Then(@"Verify Total number of records are same as result of query ""(.*)""")]
        public void ThenVerifyTotalNumberOfRecordsAreSameAsResultOfQuery(string p0)
        {
            int TotalRecords = 0;
            //string thisConnectionString = "user id=" + ConfigFile.DBUser + ";" +
            //                       "password=" + ConfigFile.DBPassword + ";" +
            //                       "Data Source=" + ConfigFile.DataServer + "," + ConfigFile.Port + ";" +
            //                       "Network Library=DBMSSOCN;" +
            //                       "Initial Catalog=" + ConfigFile.ERFdb + "; " +
            //                       "connection timeout=30";

            string thisConnectionString = "server=" + ConfigFile.DataServer + ";" + "database=" + ConfigFile.ERFdb + ";" + "user id=" + ConfigFile.DBUser + ";" + "password=" + ConfigFile.DBPassword + ";" + "Max Pool Size=9000;" + "Connection Timeout=150;" + "Min Pool Size=2";

            string sql = p0;
            using (SqlConnection conn = new SqlConnection(thisConnectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@planid", 1);
                try
                {
                    conn.Open();
                    TotalRecords = (int)cmd.ExecuteScalar();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            int mycount = Int32.Parse(GlobalRef.TotalcountInFile.ToString());
            Assert.AreEqual(TotalRecords, mycount, "Total number of records in the file does not matches with records in data base");
        }


        [Then(@"Verify Downloaded Legacy Transaction file records Count is set to ""(.*)""")]
        public void ThenVerifyDownloadedLegacyTransactionFileRecordsCountIsSetTo(string p0)
        {
            string OldFile_Downloaded_count = tmsCommon.GenerateData(p0);
            string NewFile_Downloaded_count = getMemberLegacyFileTotalRecordCount();

            Assert.AreEqual(OldFile_Downloaded_count, NewFile_Downloaded_count, "Same downloaded filter is getting differnt count. Kindly check both file");
        }


        [Given(@"variable ""(.*)"" from database is set to ""(.*)""")]
        public void GivenVariableFromDatabaseIsSetTo(string p0, string p1)
        {
            string MBI = ExecuteSingleQuery(p1, ConfigFile.EAMdb, 1, 0);
            fw.setVariable(p0, MBI);
            Console.WriteLine(p0);
        }
       
        [Given(@"I store variable ""(.*)"" by executing SQL Query ""(.*)"" on Database EAM with HIC ""(.*)""")]
        public void GivenIStoreVariableByExecutingSQLQueryOnDatabaseEAMWithHIC(string p0, string p1, string p2)
        {
            string HIC = GlobalRef.MBI.ToString();
            string sql = tmsCommon.GenerateData(p1);
            string SqlString = sql + "'" + HIC + "'";
            Console.Write("Query is : " + SqlString);
            string dbQuery = tmsCommon.GenerateData(sql);
            string MBI = ExecuteSingleQuery(dbQuery, ConfigFile.EAMdb, 1, 0);
            fw.setVariable(p0, MBI);
            Console.WriteLine(p0); ;
        }


        [Then(@"Verify Downloaded Legacy Transaction file ""(.*)"" is same as database count ""(.*)""")]
        public void ThenVerifyDownloadedLegacyTransactionFileIsSameAsDatabaseCount(string p0, string p1)
        {
            string FileRecord_count = tmsCommon.GenerateData(p0);
            string DBRecord_count = ExecuteSingleQuery(p1,ConfigFile.EAMdb, 1, 0);
            Assert.AreEqual(FileRecord_count, DBRecord_count, "Exported File  records not matching with Database table records. Total count is getting mis-matched.Export Legacy File total count is :"+ FileRecord_count+ "and Database table total count is :"+DBRecord_count);

        }




        public string ExecuteSingleQuery(string SqlString, string DB_NAME, int numberOfColumn, int rowstartcnt)
        {
            string fieldValue = SqlString;
           
            if (fieldValue.Contains("Generate"))
            {
                fieldValue = tmsCommon.GenerateData(fieldValue.Substring(fieldValue.IndexOf('\'') + 1, fieldValue.LastIndexOf('\'') - (fieldValue.IndexOf('\'') + 1)));
                SqlString = (SqlString.Split('='))[0] + "='" + fieldValue + "\'";
                

            }
            

            Dictionary<int, string[]> table = new Dictionary<int, string[]>();
            SqlCommand thisCommand = null;
            string count = null;                      
                                 
            
            List<string> list = new List<string>();
            try
            {
                SqlConnection DBConn = new SqlConnection();
                string thisConnectionString = "user id=" + ConfigFile.DBUser +" ;" +
                           "password=" + ConfigFile.DBPassword +"; " +
                           "Server=" + ConfigFile.DataServer + ";" +
                           "Trusted_Connection = yes; " +
                           "database=" + DB_NAME + "; " +
                           "connection timeout=30";
                DBConn.ConnectionString = thisConnectionString;
                DBConn.Open();
                thisCommand = new SqlCommand(SqlString, DBConn);
                SqlDataReader reader = thisCommand.ExecuteReader();
                
                if (reader.HasRows)
                {
                    tmsWait.Hard(5);
                    while (reader.Read())
                    {
                        for (int i = rowstartcnt; i < numberOfColumn; i++)
                        {
                             count=reader.GetValue(i).ToString().TrimEnd();
                        }
                    }
                   
                }
                return count;
            }
            catch(Exception e) {

                return null;
            }


      }



        [Then(@"Verify Legacy Member Export Grid is displayed has row")]
        public void ThenVerifyLegacyMemberExportGridIsDisplayedHasRow(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = cfEAMExport.ExportLegacyMembers.ExportMemberGrid;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same
                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }

                baseTable = cfEAMExport.ExportLegacyMembers.ExportMemberGrid;
                //baseTable = EAM.AdministrationManagePlanSCCViewEdit.EditPlanTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

    }

    // Added by Swapna CHappidi on 9/17/2015
    [Binding]
    public class EAMExportToFacets
    {
        [Then(@"Verify the page Title ""(.*)"" is displayed")]
        public void ThenVerifyThePageTitleIsDisplayed(string p0)
        {
            tmsWait.Hard(2);
            string GeneratedData = tmsCommon.GenerateData(p0);
            string fieldValue = cfEAMExport.ExportSpansToFacets.PageTitle.Text;
            string subs = fieldValue.Substring(0, 21);

            Assert.AreEqual(p0, subs);            
        }

        [Then(@"Verify Export button exists")]
        public void ThenVerifyExportButtonExists()
        {
            bool isDisplayed = cfEAMExport.ExportSpansToFacets.ExportButton.Displayed;
            Assert.AreEqual(isDisplayed, true);
            
        }


        [Then(@"i click on Spans - Facets File Refresh button")]
        [Given(@"i click on Spans - Facets File Refresh button")]
        [When(@"i click on Spans - Facets File Refresh button")]
        public void ThenIClickOnSpans_FacetsFileRefreshButton()
        {
            bool isEnabled;
            do
            {
                cfEAMExport.ExportSpansToFacets.RefreshButton.Click();
                tmsWait.Hard(2);
                isEnabled = cfEAMExport.ExportSpansToFacets.ExportButton.Enabled;
            } while (isEnabled != true);
        }

        
        [Then(@"i click on Spans - Facets File export button")]
        [Given(@"i click on Spans - Facets File export button")]
        [When(@"i click on Spans - Facets File export button")]
        public void ThenIClickOnSpans_FacetsFileExportButton()
        {
            tmsWait.Hard(1);
            cfEAMExport.ExportSpansToFacets.ExportButton.Click();
            tmsWait.Implicit(60);
            Assert.AreEqual("Export spans in progress.",cfEAMExport.ExportSpansToFacets.ToastMessage.Text, "Message text not matching");
            tmsWait.Hard(2);
        }


        [Then(@"Verify ""(.*)"" is displayed")]
        public void ThenVerifyIsDisplayed(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string fieldValue = cfEAMExport.ExportSpansToFacets.UserWarningMsgLabel.Text;
            Assert.AreEqual(GeneratedData, fieldValue);
        }

        //to do 

        [When(@"UserWarningMessage is set to ""(.*)""")]
        public void WhenUserWarningMessageIsSetTo(string p0)
        {
            string userWarningMsg = tmsCommon.GenerateData(p0);
            cfEAMExport.ExportSpansToFacets.UserWarningMsgText.Clear();
            cfEAMExport.ExportSpansToFacets.UserWarningMsgText.SendKeys(userWarningMsg);
        }


        [When(@"Save button is clicked")]
        public void WhenSaveButtonIsClicked()
        {
            cfEAMExport.ExportSpansToFacets.SaveButton.Click();
        }

        // Added by Swapna CHappidi on 9/22/2015
        [Then(@"Verify that UserWarningMessage is set to ""(.*)""")]
        public void ThenVerifyThatUserWarningMessageIsSetTo(string p0)
        {
           // cfEAMExport.ExportSpansToFacets.UserWarningMsgText.Click();

            IWebElement web = cfEAMExport.ExportSpansToFacets.UserWarningMsgText;
            string st2 = cfEAMExport.ExportSpansToFacets.UserWarningMsgText.GetAttribute("value");
            Assert.AreEqual(p0, st2);
        }


        [Given(@"I click on Collapsable button")]
        public void GivenIClickOnCollapsableButton()
        {
            cfEAMExport.ExportSpansToFacets.CollapsableButton.Click();
        }

        [Then(@"Verify Log Table exists")]
        public void ThenVerifyLogTableExists()
        {
            bool exists = cfEAMExport.ExportSpansToFacets.LogTable.Displayed;
            Assert.AreEqual(true,exists);
        }

        [Then(@"Verify Log Table has row")]
        public void ThenVerifyLogTableHasRow(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = cfEAMExport.ExportSpansToFacets.LogTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same
                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }

                baseTable = cfEAMExport.ExportSpansToFacets.LogTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

        [Then(@"Quarterly Enrollment Compliance Report Plan ID ""(.*)"" is selected")]
        [When(@"Quarterly Enrollment Compliance Report Plan ID ""(.*)"" is selected")]
        [Given(@"Quarterly Enrollment Compliance Report Plan ID ""(.*)"" is selected")]
        public void GivenQuarterlyEnrollmentComplianceReportPlanIDIsSelected(string planid)
        {
            tmsWait.Hard(2);
       
            string Planid = tmsCommon.GenerateData(planid);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                fw.ExecuteJavascript(EAM.EnrollmentComplianceReport.AngularPlanIDDropdown);
                IWebElement plan = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + Planid + "')]"));
                fw.ExecuteJavascript(plan);
                tmsWait.Hard(2);
            }
            else
            {
                fw.ExecuteJavascript(EAM.EnrollmentComplianceReport.PlanIDDropdown);
                IWebElement plan = Browser.Wd.FindElement(By.XPath("//a[contains(.,'" + Planid + "')]"));
                fw.ExecuteJavascript(plan);
                tmsWait.Hard(2);
            }

        }
        [Then(@"NoRx Fallout Report Plan ID ""(.*)"" is selected")]
        public void ThenNoRxFalloutReportPlanIDIsSelected(string planid)
        {
            tmsWait.Hard(3);
            string Planid = tmsCommon.GenerateData(planid);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Plan ID')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + Planid + "']");


                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);



            }
            else
            {


                SelectElement planIDDD = new SelectElement(EAM.NoRxFalloutReport.PlanIDDropdown);

                planIDDD.SelectByText(Planid);
            }
        }



        [Then(@"Quarterly Enrollment Compliance Report Year ""(.*)"" is selected")]
        [When(@"Quarterly Enrollment Compliance Report Year ""(.*)"" is selected")]
        [Given(@"Quarterly Enrollment Compliance Report Year ""(.*)"" is selected")]
        public void GivenQuarterlyEnrollmentComplianceReportYearIsSelected(string year)
        {
            string Year = tmsCommon.GenerateData(year);
            SelectElement Planyear = new SelectElement(EAM.EnrollmentComplianceReport.YearDropdown);
            Planyear.SelectByText(Year);
        }

        [Then(@"Quarterly Enrollment Compliance Report Quarter ""(.*)"" is selected")]
        [When(@"Quarterly Enrollment Compliance Report Quarter ""(.*)"" is selected")]
        [Given(@"Quarterly Enrollment Compliance Report Quarter ""(.*)"" is selected")]
        public void GivenQuarterlyEnrollmentComplianceReportQuarterIsSelected(string quarter)
        {
            string Quarter = tmsCommon.GenerateData(quarter);
            fw.ExecuteJavascript(EAM.EnrollmentComplianceReport.QuarterDropdown);

            IWebElement qua = Browser.Wd.FindElement(By.XPath("//a[contains(.,'" + Quarter + "')]"));
            fw.ExecuteJavascript(qua);
            fw.ExecuteJavascript(EAM.EnrollmentComplianceReport.QuarterDropdown);
        }
        [Then(@"Quarterly Enrollment Compliance Run Report button is clicked")]
        [When(@"Quarterly Enrollment Compliance Run Report button is clicked")]
        [Given(@"Quarterly Enrollment Compliance Run Report button is clicked")]
        public void GivenQuarterlyEnrollmentComplianceRunReportButtonIsClicked()
        
            {
            EAM.EnrollmentComplianceReport.RunReportButton.Click();
            tmsWait.Hard(2);
            if (ConfigFile.BrowserType.ToString().ToLower().Equals("chrome"))
            {
                Browser.winium.FindElement(By.Name("Username")).SendKeys(ConfigFile.DBUser);
               // //System.Windows.Forms.SendKeys.SendWait("{TAB}");
                Browser.winium.FindElement(By.Name("Password")).SendKeys(ConfigFile.DBPassword);
               // //System.Windows.Forms.SendKeys.SendWait("{TAB}");
              //  //System.Windows.Forms.SendKeys.SendWait("{ENTER}");
            }
            if (ConfigFile.BrowserType.ToString().ToLower().Equals("ff"))
            {


                Browser.winium.FindElement(By.Name("User Name:")).SendKeys(ConfigFile.DBUser);
              //  //System.Windows.Forms.SendKeys.SendWait("{TAB}");
                Browser.winium.FindElement(By.Name("Password:")).SendKeys(ConfigFile.DBPassword);
               // //System.Windows.Forms.SendKeys.SendWait("{TAB}");
               // //System.Windows.Forms.SendKeys.SendWait("{ENTER}");
            }
            By reportViewBy = EAM.Reports.ReportMainViewBy;
            string reportExpText = "Quarterly Enrollment Compliance Report";
            string reportHandle = "";


            reportHandle = ReportsCommon.SwitchToReportWindow(reportViewBy, 60, reportExpText);

            if (reportHandle == "")
            {
                Assert.Fail("  Quarterly Enrollment Compliance Report was not opened");
            }

            //try
            //{
            //    ReportsCommon.VerifyOECEAFFalloutReportDoesNotHaveData(reportViewBy, reportExpText, table);
            //}
            //catch (Exception e)
            //{
            //    Assert.Fail("Verify OEC/EAF Fallout Report has data that should not be there. ");
            //}
            //Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle);
           
            
        }

        [Then(@"NoRx Fallout Report Run Report button is clicked")]
        public void ThenNoRxFalloutReportRunReportButtonIsClicked()
        {
            tmsWait.Hard(3);
            fw.ExecuteJavascript(EAM.EnrollmentComplianceReport.RunReportButton);

            ReUsableFunctions.reportAuthenticationHandler();
            tmsWait.Hard(2);

            By reportViewBy = EAM.Reports.ReportMainViewBy;
            string reportExpText = "NoRx Fallout Report";
            string reportHandle = "";


            reportHandle = ReportsCommon.SwitchToReportWindow(reportViewBy, 60, reportExpText);

            if (reportHandle == "")
            {
                Assert.Fail("NoRx Fallout Report was not opened");
            }
        }

        [When(@"Mailing List From Transaction Export page Transaction Type is set to ""(.*)""")]
        public void WhenMailingListFromTransactionExportPageTransactionTypeIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            IWebElement element = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlPayYear"));
            new SelectElement(element).SelectByText(p0);
        }

        [When(@"Export Legacy Member page Modified Only checkbox is Checked")]
        public void WhenExportLegacyMemberPageModifiedOnlyCheckboxIsChecked()
        {
            tmsWait.Hard(2);
            IWebElement element = Browser.Wd.FindElement(By.CssSelector("[test-id='legacyMember-lbl-chkIdEnableModifiedOnly']"));
            ReUsableFunctions.clickOnWebElement(element);
            tmsWait.Hard(2);
        }

        [When(@"Export Legacy Member page Include Future Dates checkbox is Checked")]
        public void WhenExportLegacyMemberPageIncludeFutureDatesCheckboxIsChecked()
        {
            tmsWait.Hard(2);
            IWebElement element;
            if (ConfigFile.tenantType == "tmsx")
              element = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Include Future Dates')]/parent::div//input")); 
                else
              element = Browser.Wd.FindElement(By.CssSelector("[test-id='legacyMember-chk-chkIsEnableFutureDate']"));
            ReUsableFunctions.clickOnWebElement(element);
            tmsWait.Hard(2);
        }

        [When(@"Export Legacy Member page Send Future LIS checkbox is Checked")]
        public void WhenExportLegacyMemberPageSendFutureLISCheckboxIsChecked()
        {
            tmsWait.Hard(2);
            IWebElement element = Browser.Wd.FindElement(By.CssSelector("[test-id='legacyMember-lbl-chkIdEnableSendFutureLIS']"));
            ReUsableFunctions.clickOnWebElement(element);
            tmsWait.Hard(2);
        }


        [When(@"Export Legacy Member page Plan ID is set to ""(.*)""")]
        public void WhenExportLegacyMemberPagePlanIDIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            string planID = tmsCommon.GenerateData(p0);
            GlobalRef.PlanID = planID;
            IWebElement drp;
            IWebElement element;

            if (ConfigFile.tenantType == "tmsx")
            {
                drp = Browser.Wd.FindElement(By.XPath("//*[@test-id='legacyMember-select-ddlPlanId']/span/span"));
                fw.ExecuteJavascript(drp);
                tmsWait.Hard(2);
                element = Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + planID + "')]"));
                fw.ExecuteJavascript(element);
            }
            else
            {
                drp = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='ddlPlanId_listbox']"));
                fw.ExecuteJavascript(drp);
                tmsWait.Hard(2);
                element = Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + planID + "')]"));
                fw.ExecuteJavascript(element);
            }
        }

      

        [When(@"Export Legacy Member page Include Future Dates is checked")]
        public void WhenExportLegacyMemberPageIncludeFutureDatesIsChecked()
        {
            IWebElement drp = Browser.Wd.FindElement(By.CssSelector("[test-id='legacyMember-lbl-chkIsEnableFutureDate']"));
            fw.ExecuteJavascript(drp);
        }


        [When(@"Export Legacy Member page Member Status is set to ""(.*)""")]
        public void WhenExportLegacyMemberPageMemberStatusIsSetTo(string p0)
        {
            string status = tmsCommon.GenerateData(p0);
            tmsWait.Hard(2);
            IWebElement drp;
            IWebElement element;
            if (ConfigFile.tenantType == "tmsx")
            {
                drp = Browser.Wd.FindElement(By.XPath("//*[@test-id='legacyMember-select-ddlMemberStatus']/span/span"));
                fw.ExecuteJavascript(drp);
                tmsWait.Hard(2);
                element = Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + status + "')]"));
                fw.ExecuteJavascript(element);
            }
            else
            {
                drp = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='ddlMemberStatus_listbox']"));
                fw.ExecuteJavascript(drp);
                tmsWait.Hard(2);
                element = Browser.Wd.FindElement(By.XPath("//ul[@id='ddlMemberStatus_listbox']/li[contains(.,'" + status + "')]"));
                fw.ExecuteJavascript(element);
            }
        }

        [When(@"Export Legacy Member page Export Option is set to ""(.*)""")]
        public void WhenExportLegacyMemberPageExportOptionIsSetTo(string export)
        {

            tmsWait.Hard(2);
            IWebElement drp;
            IWebElement element;
            if (ConfigFile.tenantType == "tmsx")
            {
                drp = Browser.Wd.FindElement(By.XPath("//*[@test-id='legacyMember-select-ddlExport']/span/span[@class='k-select']"));
                fw.ExecuteJavascript(drp);
                tmsWait.Hard(2);
                element = Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + export + "')]"));
                fw.ExecuteJavascript(element);
            }
            else
            {
                drp = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='ddlExport_listbox']"));
                fw.ExecuteJavascript(drp);
                tmsWait.Hard(2);
                element = Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + export + "')]"));
                fw.ExecuteJavascript(element);
            }
        }


        [When(@"Export Legacy Member page Reset button is clicked")]
        public void WhenExportLegacyMemberPageResetButtonIsClicked()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='legacyMember-btn-reset']")));
            tmsWait.Hard(2);
        }

        [Then(@"Verify Export Legacy Member Screen is Reset Successfully")]
        public void ThenVerifyExportLegacyMemberScreenIsResetSuccessfully()
        {
            string evalue = Browser.Wd.FindElement(By.XPath("//span[@class='k-pager-input k-label']")).Text;
            string[] avalue = evalue.Split(' ');
            Assert.AreEqual("0", avalue[1], "Page has not been reset Successfully");
        }


        [Then(@"verify members record count on Export Legacy Member page")]
        public void ThenVerifyMembersRecordCountOnExportLegacyMemberPage()
        {
            string evalue = Browser.Wd.FindElement(By.XPath("//span[@class='k-pager-input k-label']")).Text;
            string[] avalue = evalue.Split(' ');
            GlobalRef.MemberCount= Int32.Parse(avalue[1]);
            
        }

        [Then(@"verify all the values on Export Legacy Member Screen are Reset Successfully")]
        public void ThenVerifyAllTheValuesOnExportLegacyMemberScreenAreResetSuccessfully()
        {
            string recordCount = Browser.Wd.FindElement(By.XPath("//span[@class='k-pager-input k-label']")).Text;
            string[] actualMemberCount = recordCount.Split(' ');
            string expMemCount = GlobalRef.MemberCount.ToString();
            Assert.AreEqual(expMemCount, actualMemberCount[1], "Page has not been reset Successfully");

            string planIDValue;
            if (ConfigFile.tenantType == "tmsx")
                planIDValue = Browser.Wd.FindElement(By.XPath("//*[@test-id='legacyMember-select-ddlPlanId']/span/span")).Text;
            else
                planIDValue = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='ddlPlanId_listbox']")).Text;
            Assert.AreEqual("ALL", planIDValue);

            string memberStatus;
            if (ConfigFile.tenantType == "tmsx")
                memberStatus = Browser.Wd.FindElement(By.XPath("//*[@test-id='legacyMember-select-ddlMemberStatus']/span/span")).Text;
            else
                memberStatus = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='ddlPlanId_listbox']")).Text;
            Assert.AreEqual("ALL", memberStatus);
            Assert.IsFalse( Browser.Wd.FindElement(By.Id("chkIdEnableModifiedOnly")).Selected);
            // Assert.("False", Browser.Wd.FindElement(By.Id("chkIdEnableModifiedOnly")).Selected);
        }
        

        [When(@"Mailing List From Transaction Exports page Transaction Status is set to ""(.*)""")]
        public void WhenMailingListFromTransactionExportsPageTransactionStatusIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            IWebElement drp = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='transactionStatus_listbox']"));
            fw.ExecuteJavascript(drp);
            
            tmsWait.Hard(2);
            IWebElement element = Browser.Wd.FindElement(By.XPath("//ul[@id='transactionStatus_listbox']/li[contains(.,'" + p0 + "')]"));
            fw.ExecuteJavascript(element);
        }


        [When(@"Mailing List From Transaction Export page Transaction Status is set to ""(.*)""")]
        public void WhenMailingListFromTransactionExportPageTransactionStatusIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            IWebElement element = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlTransStatus"));
            new SelectElement(element).SelectByText(p0);
        }

        [When(@"Mailing List From Transaction Exports page Transaction Type is set to ""(.*)""")]
        public void WhenMailingListFromTransactionExportsPageTransactionTypeIsSetTo(string p0)
        {
            tmsWait.Hard(2);

            string ttype = tmsCommon.GenerateData(p0);
            GlobalRef.PlanID = ttype;
           

            IWebElement drp = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='transactionType_listbox']"));
            fw.ExecuteJavascript(drp);

            tmsWait.Hard(2);
            IWebElement element = Browser.Wd.FindElement(By.XPath("//ul[@id='transactionType_listbox']/li[contains(.,'" + ttype + "')]"));
            fw.ExecuteJavascript(element);
        }


        [When(@"Mailing List From Transaction Export page Plan ID is set to ""(.*)""")]
        public void WhenMailingListFromTransactionExportPagePlanIDIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            IWebElement drp;
            IWebElement element;
            string planID = tmsCommon.GenerateData(p0);
            GlobalRef.PlanID = planID;
            
            if (ConfigFile.tenantType == "tmsx")
            {
                drp = Browser.Wd.FindElement(By.XPath("//*[@test-id='transMailing-select-planId']/span/span"));
                fw.ExecuteJavascript(drp);
                tmsWait.Hard(2);
                element = Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + planID + "')]"));
                fw.ExecuteJavascript(element);
            }
            else
            {
                drp = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='planId_listbox']"));
                fw.ExecuteJavascript(drp);
                tmsWait.Hard(2);
                element = Browser.Wd.FindElement(By.XPath("//ul[@id='planId_listbox']/li[contains(.,'" + planID + "')]"));
                fw.ExecuteJavascript(element);
            }

        }
        
        [Then(@"I have navigated to Letters Section")]
        [When(@"I have navigated to Letters Section")]
        public void ThenIHaveNavigatedToLettersSection()
        {
            IWebElement letter = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_EamNavigation_pnlUserAdmin_ctl03_item"));
            fw.ExecuteJavascript(letter);
        }

        [Then(@"I have navigated to Letters Template section")]
        [When(@"I have navigated to Letters Template section")]
        [Given(@"I have navigated to Letters Template section")]

        public void ThenIHaveNavigatedToLettersTemplateSection()
        {
            IWebElement letterTemp = Browser.Wd.FindElement(By.LinkText("Letter Templates"));
            fw.ExecuteJavascript(letterTemp);
        }

        [When(@"Letters section ""(.*)"" Letter is selected")]
        public void WhenLettersSectionLetterIsSelected(string p0)
        {
            tmsWait.Hard(2);
            IWebElement letter = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlLetters"));
            new SelectElement(letter).SelectByText(p0);
        }

        [When(@"Letters section ""(.*)"" Language is selected")]
        public void WhenLettersSectionLanguageIsSelected(string p0)
        {
            tmsWait.Hard(2);
            IWebElement lang = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlLang"));
            new SelectElement(lang).SelectByText(p0);
            
        }

        [When(@"Letters section ""(.*)"" Year is selected")]
        public void WhenLettersSectionYearIsSelected(string p0)
        {
            tmsWait.Hard(2);
            IWebElement year = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlEffYear"));
            new SelectElement(year).SelectByText(p0);
        }
        [When(@"Letters Page ""(.*)"" Template is Selected")]
        public void WhenLettersPageTemplateIsSelected(string p0)
        {
            Assert.Fail();
        }


        [When(@"Lettters section Go button is Clicked")]
        public void WhenLetttersSectionGoButtonIsClicked()
        {
            tmsWait.Hard(2);
            IWebElement button = Browser.Wd.FindElement(By.XPath("//input[@value='OK']"));
            fw.ExecuteJavascript(button);
        }
        IWebElement temp;
        [When(@"Letters section ""(.*)"" Letter Template Plan ID ""(.*)"" PBP ID ""(.*)"" is selected")]
        public void WhenLettersSectionLetterTemplatePlanIDPBPIDIsSelected(string p0, string plan, string pbp)
        {
          
            if(p0.Equals("Rejection of Enrollment Letter"))
            {

                temp = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_GridView1']//tr/td[contains(.,'"+ plan + "')]/following-sibling::td[contains(.,'"+ pbp + "')]/following-sibling::td//input[1]"));
                
            }
            if (p0.Equals("Rejection of Disenrollment Letter"))
            {

                temp = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_GridView1']//tr/td[contains(.,'" + plan + "')]/following-sibling::td[contains(.,'" + pbp + "')]/following-sibling::td//input[1]"));

            }
            if (p0.Equals("RDS Letter"))
            {

                temp = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_GridView1']//tr/td[contains(.,'" + plan + "')]/following-sibling::td[contains(.,'" + pbp + "')]/following-sibling::td//input[1]"));

            }

            if (temp.GetAttribute("checked").Contains("checked"))
            {
                fw.ConsoleReport(" Check box is already checked");
            }
            else
            {
                fw.ExecuteJavascript(temp);
            }
            tmsWait.Hard(2);
            IWebElement save = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_BtnSave"));
            fw.ExecuteJavascript(save);
        }

        [Then(@"Letters section ""(.*)"" Letter Template Plan ID ""(.*)"" PBP ID ""(.*)"" is selected")]
        public void ThenLettersSectionLetterTemplatePlanIDPBPIDIsSelected(string p0, string plan, int pbp)
        {

            temp = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_GridView1']//tr/td[contains(.,'" + plan + "')]/following-sibling::td[contains(.,'" + pbp + "')]/following-sibling::td//input[1]"));
            fw.ExecuteJavascript(temp);
        }

        [When(@"Letter Queue ""(.*)"" is Removed successfully")]
        public void WhenLetterQueueIsRemovedSuccessfully(string letter)
        {

            try
            {
                By letterCount = By.XPath("//td[contains(.,'" + letter + "')]/preceding-sibling::td/a");
                fw.ExecuteJavascript(Browser.Wd.FindElement(letterCount));
                tmsWait.Hard(2);
                By drpElement = By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPlan");
                By Go = By.XPath("//input[@value='Go']");
                By toggleRemove = By.XPath("//table//tr//a[@id='cmdRemoveAll']");
                By Remove = By.XPath("//input[@value='Remove']");

                try
                {
                    IWebElement drpField = Browser.Wd.FindElement(drpElement);
                    IWebElement GoBtn = Browser.Wd.FindElement(Go);
                    IWebElement toggleRemoveBtn = Browser.Wd.FindElement(toggleRemove);
                    IWebElement RemoveBtn = Browser.Wd.FindElement(Remove);
                    IList<IWebElement> planList = new SelectElement(drpField).Options;

                    foreach (IWebElement plan in planList)
                    {
                        new SelectElement(drpField).SelectByText(plan.Text);
                        fw.ExecuteJavascript(GoBtn);
                        tmsWait.Hard(5);
                       // toggleRemoveBtn.Click();
                        fw.ExecuteJavascript(RemoveBtn);
                        tmsWait.Hard(1);
                        IAlert alert = Browser.Wd.SwitchTo().Alert();
                        alert.Accept();
                        tmsWait.Hard(2);
                    }
                }
                catch
                {
                    fw.ConsoleReport(" There is no Session");
                }

           

            }
            catch
            {
                fw.ConsoleReport(" There is no Letter in Queue");
            }

            

        
           

        }


        [Then(@"Verify Export Session page should not contain any Sesssion")]
        public void ThenVerifyExportSessionPageShouldNotContainAnySesssion()
        {
            By Msg = By.XPath("//span[contains(.,'Currently no user exporting a file.')]");
            bool deleteIconPresence = false;
            try
            {
                if(Browser.Wd.FindElement(Msg).Displayed)
                {
                    Assert.IsTrue(true);
                    fw.ConsoleReport(" There is no Session ");
                }

            }
            catch
            {
                while (!deleteIconPresence)
                {
                    IWebElement delete;
                    try
                    {
                        if (ConfigFile.tenantType.Equals("tmsx"))
                        {
                             delete = Browser.Wd.FindElement(By.XPath("//a/span[contains(@class,'fas fa-trash-alt')]"));
                        }
                        else
                        {
                            
                             delete = Browser.Wd.FindElement(By.XPath("//a[contains(@class,'Delete')]"));
                        }
                          fw.ExecuteJavascript(delete);
                        tmsWait.Hard(2);
                        UIMODUtilFunctions.clickOnConfirmationYesDialog();
                        tmsWait.Hard(2);

                        Browser.Wd.Navigate().Refresh();
                        tmsWait.Hard(4);

                    }
                    catch
                    {
                        deleteIconPresence = true;
                        fw.ConsoleReport(" There is no Session");
                    }
                }
            }
            

           
        }


        [When(@"Mailing List From Transaction Export page Go button is Clicked")]
        public void WhenMailingListFromTransactionExportPageGoButtonIsClicked()
        {
            tmsWait.Hard(3);
            IWebElement element = Browser.Wd.FindElement(By.CssSelector("[test-id='legacyMember-btn-search']"));
            ReUsableFunctions.clickOnWebElement(element);
            tmsWait.Hard(10);
        }

        [When(@"Mailing List-From T/RR Deselect All button is Clicked")]
        public void WhenMailingList_FromTRRDeselectAllButtonIsClicked()
        {
            tmsWait.Hard(2);
            IWebElement element = Browser.Wd.FindElement(By.CssSelector("[test-id='trrMailing-btn-deselectAll']"));
            ReUsableFunctions.clickOnWebElement(element);
            tmsWait.Hard(4);
        }

        [When(@"Mailing List-From T/RR Search button is Clicked")]
        public void WhenMailingList_FromTRRSearchButtonIsClicked()
        {
            IWebElement element = Browser.Wd.FindElement(By.CssSelector("[test-id='trrMailing-btn-search']"));
            ReUsableFunctions.clickOnWebElement(element);
            tmsWait.Hard(4);
        }


        [When(@"Mailing List-From T/RR ""(.*)"" value is set to ""(.*)""")]
        public void WhenMailingList_FromTRRValueIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);

            IWebElement WebElemDrp;
            IWebElement WebElemDrpValue;
            switch (field)
            {
                case "TRR Start Date":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'TRR Start Date')]/parent::div//span[@class='k-select']");
                        By typeapp = By.XPath("//li[text()='" + value + "']");
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                        tmsWait.Hard(3);
                    }
                    else
                    {
                        WebElemDrp = Browser.Wd.FindElement(By.CssSelector("[aria-owns='trrStartDate_listbox']"));
                        fw.ExecuteJavascript(WebElemDrp);

                        tmsWait.Hard(2);
                        WebElemDrpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='trrStartDate_listbox']/li[contains(.,'" + value + "')]"));
                        fw.ExecuteJavascript(WebElemDrpValue);
                    }         
                    break;

                case "TRR End Date":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'TRR End Date')]/parent::div//span[@class='k-select']");
                        By typeapp = By.XPath("//li[text()='" + value + "']");
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                        tmsWait.Hard(3);
                    }
                    else
                    {
                        WebElemDrp = Browser.Wd.FindElement(By.CssSelector("[aria-owns='trrEndDate_listbox']"));
                        fw.ExecuteJavascript(WebElemDrp);
                        tmsWait.Hard(2);
                        WebElemDrpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='trrEndDate_listbox']/li[contains(.,'" + value + "')]"));
                        fw.ExecuteJavascript(WebElemDrpValue);
                    }
                   
                    break;
               
                case "Plan ID":
                    GlobalRef.PlanID = value;
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'Plan ID')]/parent::div//span[@class='k-select']");
                        By typeapp = By.XPath("//li[text()='" + value + "']");
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                        tmsWait.Hard(3);
                    }
                    else
                    {
                        WebElemDrp = Browser.Wd.FindElement(By.CssSelector("[aria-owns='planId_listbox']"));
                        fw.ExecuteJavascript(WebElemDrp);
                        tmsWait.Hard(2);
                        WebElemDrpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='planId_listbox']/li[contains(.,'" + value + "')]"));
                        fw.ExecuteJavascript(WebElemDrpValue);
                    }
                   
                    break;
                case "PBP ID":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'PBP ID')]/parent::div//span[@class='k-select']");
                        By typeapp = By.XPath("//li[text()='" + value + "']");
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                        tmsWait.Hard(3);
                    }
                    else
                    {
                        WebElemDrp = Browser.Wd.FindElement(By.CssSelector("[aria-owns='pbpID_listbox']"));
                        fw.ExecuteJavascript(WebElemDrp);
                        tmsWait.Hard(2);
                        WebElemDrpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='pbpID_listbox']//li[contains(.,'" + value + "')]"));
                        fw.ExecuteJavascript(WebElemDrpValue);
                    }
                  
                    break;
                case "TRR Code":
                    string GeneratedData = tmsCommon.GenerateData(p1);
                    tmsWait.Hard(2);
                    // click on Report Link
                    IWebElement lookup = Browser.Wd.FindElement(By.XPath("//i[@class='text-secondary fas fa-search mt-2']"));
                    fw.ExecuteJavascript(lookup);
                    tmsWait.Hard(2);
                    // Enter TRC

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement trrCode = Browser.Wd.FindElement(By.XPath("//*[@id='txtTrrCode']"));
                        trrCode.SendKeys(GeneratedData);
                    }
                    else
                    {
                        IWebElement trrCode = Browser.Wd.FindElement(By.CssSelector("[test-id='trrCodes-txt-trrCodes']"));
                        trrCode.SendKeys(GeneratedData);
                    }
                    tmsWait.Hard(2);
                    // Click on Search
                    IWebElement trrSearchButton = Browser.Wd.FindElement(By.CssSelector("[test-id='trrCodes-btn-search']"));
                    fw.ExecuteJavascript(trrSearchButton);
                    tmsWait.Hard(2);
                    // Click on Checkbox
                    IWebElement trrRowClick = Browser.Wd.FindElement(By.XPath("//input[@id='" + GeneratedData + "']"));
                    fw.ExecuteJavascript(trrRowClick);
                    tmsWait.Hard(2);
                    // Add button
                    IWebElement trrAddButton = Browser.Wd.FindElement(By.CssSelector("[test-id='trrCodes-btn-add']"));
                    fw.ExecuteJavascript(trrAddButton);
                    tmsWait.Hard(8);
                    break;
            }
        }


        [When(@"Mailing List From Transaction Export page Deselect All button is Clicked")]
        public void WhenMailingListFromTransactionExportPageDeselectAllButtonIsClicked()
        {
            IWebElement element = Browser.Wd.FindElement(By.Id("btnLegacyMemberDeSelectAll"));
            ReUsableFunctions.clickOnWebElement(element);
            tmsWait.Hard(4);
        }

        [When(@"Mailing List From Transaction Export page Select All button is Clicked")]
        public void WhenMailingListFromTransactionExportPageSelectAllButtonIsClicked()
        {
            IWebElement element = Browser.Wd.FindElement(By.Id("btnLegacyMemberSelectAll"));
            ReUsableFunctions.clickOnWebElement(element);
            tmsWait.Hard(4);
        }


        [When(@"Mailing List From Transaction Exports page Deselect All button is Clicked")]
        public void WhenMailingListFromTransactionExportsPageDeselectAllButtonIsClicked()
        {
            IWebElement element = Browser.Wd.FindElement(By.CssSelector("[test-id='transMailing-btn-deselectAll']"));
            ReUsableFunctions.clickOnWebElement(element);
            tmsWait.Hard(4);
        }


        [When(@"Mailing List From Transaction Exports page Go button is Clicked")]
        public void WhenMailingListFromTransactionExportsPageGoButtonIsClicked()
        {
            IWebElement element = Browser.Wd.FindElement(By.CssSelector("[test-id='transMailing-btn-search']"));
            ReUsableFunctions.clickOnWebElement(element);
            tmsWait.Hard(10);
        }

        [When(@"Mailing List From Transaction Exports page First Record is Checked")]
        public void WhenMailingListFromTransactionExportsPageFirstRecordIsChecked()
        {
            
                IWebElement firstCheck = Browser.Wd.FindElement(By.XPath("(//div[@test-id='transMailing-grid-TransMailingGrid']//input[@type='checkbox'])[1]"));
                fw.ExecuteJavascript(firstCheck);
                IWebElement mbi;
                if (ConfigFile.tenantType == "tmsx")
                {
                    mbi = Browser.Wd.FindElement(By.XPath("(//div[@test-id='transMailing-grid-TransMailingGrid']//td)[1]"));
                }
                else
                {
                    mbi = Browser.Wd.FindElement(By.XPath("(//div[@test-id='transMailing-grid-TransMailingGrid']//td/span[@ng-bind='dataItem.hic'])[1]"));
                }
                GlobalRef.MBI = mbi.Text;
            

            
        }



        [When(@"Mailing List From Transaction Export page Fist Record is Checked")]
        public void WhenMailingListFromTransactionExportPageFistRecordIsChecked()
        {
            IWebElement element;
            IWebElement hic;
            if (ConfigFile.tenantType == "tmsx")
            {
                element=Browser.Wd.FindElement(By.XPath("(//*[@test-id='legacyMember-grid-legacyMemberDataGrid']//input[@type='checkbox'])[1]"));
                ReUsableFunctions.clickOnWebElement(element);
                hic = Browser.Wd.FindElement(By.XPath("(//*[@test-id='legacyMember-grid-legacyMemberDataGrid']//td)[1]"));
            }
            else
            {
                element = Browser.Wd.FindElement(By.XPath("(//div[@test-id='legacyMember-grid-legacyMemberGrid']//input[@type='checkbox'])[1]"));
                ReUsableFunctions.clickOnWebElement(element);
                hic = Browser.Wd.FindElement(By.XPath("(//div[@test-id='legacyMember-grid-legacyMemberGrid']//input[@type='checkbox'])[1]/parent::td/preceding-sibling::td/span[@ng-bind='dataItem.hic']"));
            }

            string MBIValue = hic.Text;
            GlobalRef.MBI = MBIValue;
            tmsWait.Hard(5);
            
            //ReUsableFunctions.clickOnWebElement(element);
            fw.ConsoleReport(" Exported MBI " + MBIValue);
        }


        [When(@"Mailing List From Transaction Exports page Export button is Clicked")]
        public void WhenMailingListFromTransactionExportsPageExportButtonIsClicked()
        {
            IWebElement element = Browser.Wd.FindElement(By.CssSelector("[test-id='transMailing-btn-initiateExport']"));
            ReUsableFunctions.clickOnWebElement(element);
            tmsWait.Hard(5);
        }


        [When(@"Mailing List From Transaction Export page Export button is Clicked")]
        public void WhenMailingListFromTransactionExportPageExportButtonIsClicked()
        {

            tmsWait.Hard(3);
            IWebElement element;
            
            if(ConfigFile.tenantType == "tmsx")
                element = Browser.Wd.FindElement(By.XPath("//*[@test-id='legacyMember-btn-save']"));
            else
                element = Browser.Wd.FindElement(By.CssSelector("[test-id='legacyMember-btn-save']"));
            ReUsableFunctions.clickOnWebElement(element);
            tmsWait.Hard(5);
        }

        [When(@"Legacy Transaction File Exports page Export button is Clicked")]
        public void WhenLegacyTransactionFileExportsPageExportButtonIsClicked()
        {
            IWebElement element = Browser.Wd.FindElement(By.CssSelector("[test-id='transMailing-btn-initiateExport']"));
            ReUsableFunctions.clickOnWebElement(element);
            tmsWait.Hard(5);
        }

        [Then(@"Report Page Plan ID is set to ""(.*)""")]
       

        [When(@"Report Page Plan ID is set to ""(.*)""")]
        public void WhenReportPagePlanIDIsSetTo(string planid)
        {
            tmsWait.Hard(5);
            string Planid = tmsCommon.GenerateData(planid);
            SelectElement planIDDD = new SelectElement(EAM.DisenrollmentComplianceReport.PlanIDDropdown);
            planIDDD.DeselectAll();
            planIDDD.SelectByText(Planid);
        }


        [Then(@"Quarterly Disenrollment Compliance Report Plan ID ""(.*)"" is selected")]
 
        [Given(@"Quarterly Disenrollment Compliance Report Plan ID ""(.*)"" is selected")]
        public void GivenQuarterlyDisenrollmentComplianceReportPlanIDIsSelected(string planid)
        {
            string GeneratedData = tmsCommon.GenerateData(planid.ToString());

            if(ConfigFile.EnvType.Equals("ESI"))
            {

                //Browser.Wd.FindElement(By.XPath("//button[@id='ReportViewerControl_ctl04_ctl03_ctl01']")).Click();
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@id='ReportViewerControl_ctl04_ctl03_ctl01']")));
                tmsWait.Hard(1);
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//input[@id='ReportViewerControl_ctl04_ctl03_divDropDown_ctl00']")));
                tmsWait.Hard(2);
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[contains(.,'"+ GeneratedData +"')]/preceding-sibling::input")));
            }

            else
            {
                //string xpathstring = "//multiselect[@test-id='PlanId']//a[contains(.,'" + GeneratedData + "')]";
                //SelectDropDownValues(xpathstring);
                IWebElement elecType = Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='PlanId']//input"));

                elecType.SendKeys(GeneratedData);
                tmsWait.Hard(3);
                elecType.SendKeys(OpenQA.Selenium.Keys.Enter);
            }
           
        }

        public void SelectDropDownValues(string xpathstring)
        {
            IWebElement test = Browser.Wd.FindElement(By.XPath(xpathstring));
            fw.ExecuteJavascript(test);
        }

        [Then(@"I click on Reports link")]
        [Given(@"I click on Reports link")]
        [When(@"I click on Reports link")]
        public void ThenIClickOnReportsLink()
        {
            fw.ExecuteJavascript(EAM.DisenrollmentComplianceReport.ReportsLink);
        }
        
        [When(@"Report Page Year is set to ""(.*)""")]
        [Given(@"Report Page Year is set to ""(.*)""")]
        [Then(@"Report Page Year is set to ""(.*)""")]
        public void WhenReportPageYearIsSetTo(string year)
        {
            string Year = tmsCommon.GenerateData(year);
            SelectElement planIDDD = new SelectElement(EAM.DisenrollmentComplianceReport.YearDropdown);
            planIDDD.SelectByText(Year);
        }

        [Then(@"Quarterly Disenrollment Compliance Report Year ""(.*)"" is selected")]
        [Given(@"Quarterly Disenrollment Compliance Report Year ""(.*)"" is selected")]
        public void GivenQuarterlyDisenrollmentComplianceReportYearIsSelected(string year)
        {
            string Year = tmsCommon.GenerateData(year);
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                IWebElement Yeardd = Browser.Wd.FindElement(By.XPath("//select[@id='ReportViewerControl_ctl04_ctl05_ddValue']"));
                SelectElement planIDDD = new SelectElement(Yeardd);
                planIDDD.SelectByText(Year);
            }

            else
            {
                //SelectElement planIDDD = new SelectElement(EAM.DisenrollmentComplianceReport.YearDropdown);
                //planIDDD.SelectByText(Year);
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='Year']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + Year + "']");

                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
            }
                
        }

        [When(@"Report Page Quarter is set to ""(.*)""")]
        public void WhenReportPageQuarterIsSetTo(string quarter)
        {
            string Quarter = tmsCommon.GenerateData(quarter);
            SelectElement quarterDD = new SelectElement(EAM.DisenrollmentComplianceReport.QuarterDropdown);
            quarterDD.SelectByText(Quarter);
        }

        [Then(@"Quarterly Disenrollment Compliance Report Quarter ""(.*)"" is selected")]
        [Given(@"Quarterly Disenrollment Compliance Report Quarter ""(.*)"" is selected")]
        [When(@"Quarterly Disenrollment Compliance Report Quarter ""(.*)"" is selected")]
        public void GivenQuarterlyDisenrollmentComplianceReportQuarterIsSelected(string quarter)
        {
            string GeneratedData = tmsCommon.GenerateData(quarter.ToString());
            if (ConfigFile.EnvType.Equals("ESI"))
            {

            }

            else
            {
                //string xpathstring = "//multiselect[@test-id='Quarters']//button[@title='" + GeneratedData + "']";
                //SelectDropDownValues(xpathstring);

                IWebElement elecType = Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='Quarters']//input"));

                elecType.SendKeys(GeneratedData);
                tmsWait.Hard(3);
                elecType.SendKeys(OpenQA.Selenium.Keys.Enter);
            }
                
        }

        [When(@"Run Report button is clicked successfully")]
        public void WhenRunReportButtonIsClickedSuccessfully()
        {
            fw.ExecuteJavascript(EAM.DisenrollmentComplianceReport.RunReportButton);
            tmsWait.Hard(10);
            Browser.SwitchToChildWindow();
            Browser.SwitchToIFrame();
        }

        [Then(@"Close Report Window successfully")]
        public void ThenCloseReportWindowSuccessfully()
        {
            Browser.SwitchToChildWindow().Close();
            Browser.SwitchToParentWindow();
        }


        [Then(@"Quarterly Disenrollment Compliance Run Report button is clicked")]
        [Given(@"Quarterly Disenrollment Compliance Run Report button is clicked")]
        public void GivenQuarterlyDisenrollmentComplianceRunReportButtonIsClicked()
        {

            if (ConfigFile.EnvType.Equals("ESI"))
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//input[@value='View Report']")));
                tmsWait.Hard(10);
            }

            else
            {
                AngularFunction.clickOnElement(EAM.DisenrollmentComplianceReport.RunReportButton);
                tmsWait.Hard(10);
                Browser.SwitchToChildWindow();
                tmsWait.Hard(10);

                AngularFunction.resolveCertificateErrors();
            }
           
        }

        
        [When(@"Lagacy Transaction Page Deselect All button is clicked")]
        public void WhenLagacyTransactionPageDeselectAllButtonIsClicked()
        {
            tmsWait.Hard(5);
            IWebElement element = Browser.Wd.FindElement(By.CssSelector("[test-id='legacyTrans-btn-deselectAll']"));
            fw.ExecuteJavascript(element);
           tmsWait.Hard(5);
        }

        [When(@"Lagacy Transaction Page Select All button is clicked")]
        public void WhenLagacyTransactionPageSelectAllButtonIsClicked()
        {
            tmsWait.Hard(5);
            IWebElement element = Browser.Wd.FindElement(By.CssSelector("[test-id='legacyTrans-btn-selectAll']"));
            fw.ExecuteJavascript(element);
            tmsWait.Hard(3);
        }


        [When(@"Lagacy Member Deselect All button is clicked")]
        public void WhenLagacyMemberDeselectAllButtonIsClicked()
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(cfEAMExport.ExportLegacyMembers.DeselectAll);
            tmsWait.Hard(7);
        }

        // below code for Legcacy Member, There is some problem with Gherkin format
        [When(@"Lagacy Member Checked send button for ""(.*)"" record and Noted MBI")]
        public void WhenLagacyMemberCheckedSendButtonForRecordAndNotedMBI(string p0)
        {
            string mbi = tmsCommon.GenerateData(p0);
            bool elementSearch = false;
            By mbiBy;
            if (ConfigFile.tenantType == "tmsx")
                mbiBy= By.XPath("//*[@class='k-grid-aria-root']//td[contains(.,'" + mbi + "')]");
            else
                 mbiBy = By.XPath("//div[@test-id='legacyMember-grid-legacyMemberGrid']//tbody[contains(.,'" + mbi + "')]");

            By nextPage = By.XPath("//a[@title='Go to the next page']");

            while (!elementSearch)
            {
                elementSearch = elementPresence(mbiBy);
                tmsWait.Hard(3);
                if (!elementSearch)
                {
                    try
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(nextPage));
                    }
                    catch
                    {
                        Assert.Fail(" Expected MBI is not present on Export Search results");
                    }
                }

                if (elementSearch)
                {
                    
                    tmsWait.Hard(2);
                    IWebElement checkbox;
                    if (ConfigFile.tenantType == "tmsx")
                        checkbox = Browser.Wd.FindElement(By.XPath("//*[@class='k-grid-aria-root']//tr[contains(.,'"+ mbi + "')]//td/input[@type='checkbox']"));
                    else
                       checkbox = Browser.Wd.FindElement(By.XPath("//div[@test-id='legacyMember-grid-legacyMemberGrid']//td/span[@ng-bind='dataItem.hic'][contains(.,'" + mbi + "')]/parent::td/following-sibling::td/input[@type='checkbox']"));
                    fw.ExecuteJavascript(checkbox);

                    IWebElement mbiValue;
                    if (ConfigFile.tenantType == "tmsx")
                    {
                        mbiValue = Browser.Wd.FindElement(By.XPath("(//*[@class='k-grid-aria-root']//tr[contains(.,'" + mbi + "')]//td)[1]"));
                    }
                    else {
                        mbiValue = Browser.Wd.FindElement(By.XPath("//div[@test-id='legacyMember-grid-legacyMemberGrid']//td/span[@ng-bind='dataItem.hic'][contains(.,'" + mbi + "')]")); }
                    GlobalRef.TransMBI = mbiValue.Text;
                }
            }
        }

        [Then(@"Verify Export Legacy Member page not displaying MBI ""(.*)""")]
        public void ThenVerifyExportLegacyMemberPageNotDisplayingMBI(string p0)
        {
            string mbi = tmsCommon.GenerateData(p0);
            bool elementSearch = false;
            By mbiBy = By.XPath("//div[@test-id='legacyMember-grid-legacyMemberGrid']//tbody[contains(.,'" + mbi + "')]");
            elementSearch = elementPresence(mbiBy);
            if (!elementSearch)
            {

                Assert.IsTrue(true," Expected MBI is present on Export Search results");
            }
            else
            {
                Assert.Fail(" Expected MBI found");
            }
        }


        [Then(@"Verify Export Legacy Member page not displayed MBI ""(.*)""")]
        public void ThenVerifyExportLegacyMemberPageNotDisplayedMBI(string p0)
        {
            string mbi = tmsCommon.GenerateData(p0);
            bool elementSearch = false;
            By mbiBy = By.XPath("//div[@test-id='legacyMember-grid-legacyMemberGrid']//tbody[contains(.,'" + mbi + "')]");
            By nextPage = By.XPath("//a[@title='Go to the next page']");

            while (!elementSearch)
            {
                elementSearch = elementPresence(mbiBy);
                tmsWait.Hard(3);
                if (!elementSearch)
                {
                    try
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(nextPage));
                    }
                    catch
                    {
                        Assert.IsTrue(true, " Expected MBI found");
                        elementSearch = false;
                        break;
                    }
                }

               
            }
            if (elementSearch)
            {

                Assert.Fail(" Expected MBI is not present on Export Search results");
            }
            else
            {
                Assert.IsTrue(true, " Expected MBI found");
            }
        }


        [When(@"Mailing List From Transaction Exports page Search Results Expected MBI Record is checked on Send button and Note MBI")]
        public void WhenMailingListFromTransactionExportsPageSearchResultsExpectedMBIRecordIsCheckedOnSendButtonAndNoteMBI()
        {
            string mbi = GlobalRef.LTMBI.ToString();


            bool elementSearch = false;
            By mbiBy = By.XPath("//div[@test-id='transMailing-grid-TransMailingGrid']//tbody[contains(.,'" + mbi + "')]");
            By nextPage = By.XPath("//a[@title='Go to the next page']");
            By DeselectAll = By.Id("btnlegacyTransDeSelectAll");
            while (!elementSearch)
            {
                elementSearch = elementPresence(mbiBy);
                tmsWait.Hard(3);
                if (!elementSearch)
                {
                    try
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(nextPage));
                    }
                    catch
                    {
                        Assert.Fail(" Expected MBI is not present on Export Search results");
                    }
                }

                if (elementSearch)
                {
                    fw.ExecuteJavascript(Browser.Wd.FindElement(DeselectAll));
                    tmsWait.Hard(2);
                    IWebElement checkbox = Browser.Wd.FindElement(By.XPath("//div[@test-id='transMailing-grid-TransMailingGrid']//td/span[@ng-bind='dataItem.hic'][contains(.,'" + mbi + "')]/parent::td/following-sibling::td/input[@type='checkbox']"));
                    fw.ExecuteJavascript(checkbox);


                    IWebElement mbiValue = Browser.Wd.FindElement(By.XPath("//div[@test-id='transMailing-grid-TransMailingGrid']//td/span[@ng-bind='dataItem.hic'][contains(.,'" + mbi + "')]"));
                    GlobalRef.TransMBI = mbiValue.Text;
                }

            }
        }

        // below code for Legcacy Transaction, There is some problem with Gherkin format

        [When(@"Lagacy Member Checked send button for ""(.*)"" record and Note MBI")]
        public void WhenLagacyMemberCheckedSendButtonForRecordAndNoteMBI(string p0)
        {
            string mbi = tmsCommon.GenerateData(p0);
            bool elementSearch = false;
            By mbiBy = By.XPath("//kendo-grid-list[@role='presentation']//tbody[contains(.,'" + mbi + "')]");
            By nextPage = By.XPath("//a[@title='Go to the next page']");

            while (!elementSearch)
            {
                elementSearch = elementPresence(mbiBy);
                tmsWait.Hard(3);
                if (!elementSearch)
                {
                    try
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(nextPage));
                    }
                    catch
                    {
                        Assert.Fail(" Expected MBI is not present on Export Search results");
                    }
                }

                if(elementSearch)
                {
                    fw.ExecuteJavascript(cfEAMExport.ExportLegacyMembers.DeselectAll);
                    tmsWait.Hard(2);
                    IWebElement checkbox = Browser.Wd.FindElement(By.XPath("//kendo-grid-list[@role='presentation']//td[contains(.,'" + mbi + "')]/following-sibling::td/input[@type='checkbox']"));
                  // IWebElement checkbox = Browser.Wd.FindElement(By.XPath("//div[@test-id='legacyTrans-grid-legacyTransGrid']//td/span[@ng-bind='dataItem.hic'][contains(.,'"+ mbi + "')]/parent::td/following-sibling::td/input[@type='checkbox']"));
                    fw.ExecuteJavascript(checkbox);


                    IWebElement mbiValue = Browser.Wd.FindElement(By.XPath("//kendo-grid-list[@role='presentation']//td[contains(.,'" + mbi + "')]"));
                    GlobalRef.TransMBI = mbiValue.Text;
                }

            }
            
         
        }


       public bool elementPresence(By ele)
        {

            try
            {
                Browser.Wd.FindElement(ele);
                return true;
            }
            catch
            {
                return false;
            }
        }

        //Gurdeep Arora - Updated for Angular changes - 09/14/2020
        [When(@"Mailing List From Transaction Exports page Checked send button for first records and Note MBI")]
        public void WhenMailingListFromTransactionExportsPageCheckedSendButtonForFirstRecordsAndNoteMBI()
        {
            IWebElement firstCheck = Browser.Wd.FindElement(By.XPath("(//div[@test-id='transMailing-grid-TransMailingGrid']//input[@type='checkbox'])[1]"));
            fw.ExecuteJavascript(firstCheck);
            IWebElement mbi;
            if (ConfigFile.tenantType == "tmsx")
            {
                mbi = Browser.Wd.FindElement(By.XPath("(//div[@test-id='transMailing-grid-TransMailingGrid']//td)[1]"));
            }
            else {
                mbi = Browser.Wd.FindElement(By.XPath("(//div[@test-id='transMailing-grid-TransMailingGrid']//td/span[@ng-bind='dataItem.hic'])[1]"));
            }
            GlobalRef.MBI = mbi.Text;
        }

        [When(@"Mailing List-From T/RR Export button is Clicked")]
        public void WhenMailingList_FromTRRExportButtonIsClicked()
        {
            IWebElement export = Browser.Wd.FindElement(By.CssSelector("[test-id='trrMailing-btn-initiateExport']"));
            fw.ExecuteJavascript(export);

        }

        [When(@"Mailing List-From T/RR search results first record and noted MBI")]
        public void WhenMailingList_FromTRRSearchResultsFirstRecordAndNotedMBI()
        {

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement firstCheck = Browser.Wd.FindElement(By.XPath("(//kendo-grid//table[@role='presentation']//td/input[@type='checkbox'])[1]"));
                fw.ExecuteJavascript(firstCheck);
                IWebElement mbi = Browser.Wd.FindElement(By.XPath("//kendo-grid//table[@role='presentation']//td[1]"));
                GlobalRef.MBI = mbi.Text;
            }
            else
            {

                IWebElement firstCheck = Browser.Wd.FindElement(By.XPath("(//div[@test-id='trrMailing-grid-trrMailingMembersDataGrid']//input[@type='checkbox'])[1]"));
                fw.ExecuteJavascript(firstCheck);
                IWebElement mbi = Browser.Wd.FindElement(By.XPath("(//div[@test-id='trrMailing-grid-trrMailingMembersDataGrid']//td/span[@ng-bind='dataItem.hic'])[1]"));
                GlobalRef.MBI = mbi.Text;

            }




        }
        [When(@"Lagacy Member Page Send button is checked for New MBI ""(.*)""")]
        public void WhenLagacyMemberPageSendButtonIsCheckedForNewMBI(string p0)
        {
            string mbi = tmsCommon.GenerateData(p0);


            bool elementSearch = false;
            By mbiBy = By.XPath("//div[@test-id='legacyMember-grid-legacyMemberGrid']//tbody[contains(.,'" + mbi + "')]");
            By nextPage = By.XPath("//a[@title='Go to the next page']");
            By DeselectAll = By.Id("btnLegacyMemberDeSelectAll");
            while (!elementSearch)
            {
                elementSearch = elementPresence(mbiBy);
                tmsWait.Hard(3);
                if (!elementSearch)
                {
                    try
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(nextPage));
                    }
                    catch
                    {
                        Assert.Fail(" Expected MBI is not present on Export Search results");
                    }
                }

                if (elementSearch)
                {
                    //fw.ExecuteJavascript(Browser.Wd.FindElement(DeselectAll));
                    tmsWait.Hard(2);
                    IWebElement checkbox = Browser.Wd.FindElement(By.XPath("//div[@test-id='legacyMember-grid-legacyMemberGrid']//td/span[@ng-bind='dataItem.hic'][contains(.,'" + mbi + "')]/parent::td/following-sibling::td/input[@type='checkbox']"));
                    fw.ExecuteJavascript(checkbox);


                    IWebElement mbiValue = Browser.Wd.FindElement(By.XPath("//div[@test-id='legacyMember-grid-legacyMemberGrid']//td/span[@ng-bind='dataItem.hic'][contains(.,'" + mbi + "')]"));
                    GlobalRef.TransMBI = mbiValue.Text;
                }

            }


        }

        [When(@"Lagacy Member Page Send button is checked for MBI ""(.*)""")]
        public void WhenLagacyMemberPageSendButtonIsCheckedForMBI(string p0)
        {
            string mbi = tmsCommon.GenerateData(p0);


            bool elementSearch = false;
            By mbiBy = By.XPath("//div[@test-id='legacyMember-grid-legacyMemberGrid']//tbody[contains(.,'" + mbi + "')]");
            By nextPage = By.XPath("//a[@title='Go to the next page']");
            By DeselectAll = By.Id("btnLegacyMemberDeSelectAll");
            while (!elementSearch)
            {
                elementSearch = elementPresence(mbiBy);
                tmsWait.Hard(3);
                if (!elementSearch)
                {
                    try
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(nextPage));
                    }
                    catch
                    {
                        Assert.Fail(" Expected MBI is not present on Export Search results");
                    }
                }

                if (elementSearch)
                {
                    fw.ExecuteJavascript(Browser.Wd.FindElement(DeselectAll));
                    tmsWait.Hard(2);
                    IWebElement checkbox = Browser.Wd.FindElement(By.XPath("//div[@test-id='legacyMember-grid-legacyMemberGrid']//td/span[@ng-bind='dataItem.hic'][contains(.,'" + mbi + "')]/parent::td/following-sibling::td/input[@type='checkbox']"));
                    fw.ExecuteJavascript(checkbox);


                    IWebElement mbiValue = Browser.Wd.FindElement(By.XPath("//div[@test-id='legacyMember-grid-legacyMemberGrid']//td/span[@ng-bind='dataItem.hic'][contains(.,'" + mbi + "')]"));
                    GlobalRef.TransMBI = mbiValue.Text;
                }

            }

        }


        [When(@"Lagacy Member Checked send button for Divorced Member and Note MBI")]
        public void WhenLagacyMemberCheckedSendButtonForDivorcedMemberAndNoteMBI()
        {
            string mbi = GlobalRef.LTMBI.ToString();
            bool elementSearch = false;
            By mbiBy;
            if (ConfigFile.tenantType == "tmsx")
                mbiBy = By.XPath("//*[@class='k-grid-aria-root']//td[contains(.,'" + mbi + "')]");
            else
                mbiBy = By.XPath("//div[@test-id='legacyMember-grid-legacyMemberGrid']//tbody[contains(.,'" + mbi + "')]");

            By nextPage = By.XPath("//a[@title='Go to the next page']");

            while (!elementSearch)
            {
                elementSearch = elementPresence(mbiBy);
                tmsWait.Hard(3);
                if (!elementSearch)
                {
                    try
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(nextPage));
                    }
                    catch
                    {
                        Assert.Fail(" Expected MBI is not present on Export Search results");
                    }
                }

                if (elementSearch)
                {

                    tmsWait.Hard(2);
                    IWebElement checkbox;
                    if (ConfigFile.tenantType == "tmsx")
                        checkbox = Browser.Wd.FindElement(By.XPath("//*[@class='k-grid-aria-root']//tr[contains(.,'" + mbi + "')]//td/input[@type='checkbox']"));
                    else
                        checkbox = Browser.Wd.FindElement(By.XPath("//div[@test-id='legacyMember-grid-legacyMemberGrid']//td/span[@ng-bind='dataItem.hic'][contains(.,'" + mbi + "')]/parent::td/following-sibling::td/input[@type='checkbox']"));
                    fw.ExecuteJavascript(checkbox);

                    IWebElement mbiValue;
                    if (ConfigFile.tenantType == "tmsx")
                    {
                        mbiValue = Browser.Wd.FindElement(By.XPath("(//*[@class='k-grid-aria-root']//tr[contains(.,'" + mbi + "')]//td)[1]"));
                    }
                    else
                    {
                        mbiValue = Browser.Wd.FindElement(By.XPath("//div[@test-id='legacyMember-grid-legacyMemberGrid']//td/span[@ng-bind='dataItem.hic'][contains(.,'" + mbi + "')]"));
                    }
                    GlobalRef.TransMBI = mbiValue.Text;

                }
            }
        }

        [When(@"Lagacy Member Checked send button for Expected Member and Note MBI")]
        public void WhenLagacyMemberCheckedSendButtonForExpectedMemberAndNoteMBI()
        {
            string mbi = GlobalRef.LTMBI.ToString();


            bool elementSearch = false;
            By mbiBy;
            By nextPage = By.XPath("//a[@title='Go to the next page']");
            By DeselectAll = By.Id("btnLegacyMemberDeSelectAll");

            if (ConfigFile.tenantType == "tmsx")
                mbiBy = By.XPath("//*[@class='k-grid-aria-root']//td[contains(.,'" + mbi + "')]");
            else
                mbiBy = By.XPath("//div[@test-id='legacyMember-grid-legacyMemberGrid']//tbody[contains(.,'" + mbi + "')]");

            while (!elementSearch)
            {
                elementSearch = elementPresence(mbiBy);
                tmsWait.Hard(3);
                if (!elementSearch)
                {
                    try
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(nextPage));
                    }
                    catch
                    {
                        Assert.Fail(" Expected MBI is not present on Export Search results");
                    }
                }

                if (elementSearch)
                {
                    fw.ExecuteJavascript(Browser.Wd.FindElement(DeselectAll));
                    tmsWait.Hard(2);

                    IWebElement checkbox;
                    if (ConfigFile.tenantType == "tmsx")
                        checkbox = Browser.Wd.FindElement(By.XPath("//*[@class='k-grid-aria-root']//tr[contains(.,'" + mbi + "')]//td/input[@type='checkbox']"));
                    else
                        checkbox = Browser.Wd.FindElement(By.XPath("//div[@test-id='legacyMember-grid-legacyMemberGrid']//td/span[@ng-bind='dataItem.hic'][contains(.,'" + mbi + "')]/parent::td/following-sibling::td/input[@type='checkbox']"));

                    tmsWait.Hard(2);
                    fw.ExecuteJavascript(checkbox);

                    IWebElement mbiValue;
                    if (ConfigFile.tenantType == "tmsx")
                    {
                        mbiValue = Browser.Wd.FindElement(By.XPath("(//*[@class='k-grid-aria-root']//tr[contains(.,'" + mbi + "')]//td)[1]"));
                    }
                    else
                    {
                        mbiValue = Browser.Wd.FindElement(By.XPath("//div[@test-id='legacyMember-grid-legacyMemberGrid']//td/span[@ng-bind='dataItem.hic'][contains(.,'" + mbi + "')]"));
                    }

                    GlobalRef.TransMBI = mbiValue.Text;
                }

            }

        }


        [When(@"Lagacy Member Checked send button for Expected Language Member and Note MBI")]
        public void WhenLagacyMemberCheckedSendButtonForExpectedLanguageMemberAndNoteMBI()
        {
            string mbi = GlobalRef.LTMBI.ToString();

            bool elementSearch = false;
            By mbiBy;
            if (ConfigFile.tenantType == "tmsx")
                mbiBy = By.XPath("//*[@class='k-grid-aria-root']//td[contains(.,'" + mbi + "')]");
            else
                mbiBy = By.XPath("//div[@test-id='legacyMember-grid-legacyMemberGrid']//tbody[contains(.,'" + mbi + "')]");

            By nextPage = By.XPath("//a[@title='Go to the next page']");

            By DeselectAll = By.Id("btnLegacyMemberDeSelectAll");
            while (!elementSearch)
            {
                elementSearch = elementPresence(mbiBy);
                tmsWait.Hard(3);
                if (!elementSearch)
                {
                    try
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(nextPage));
                    }
                    catch
                    {
                        Assert.Fail(" Expected MBI is not present on Export Search results");
                    }
                }

                if (elementSearch)
                {
                    fw.ExecuteJavascript(Browser.Wd.FindElement(DeselectAll));
                    tmsWait.Hard(2);
                    IWebElement checkbox;

                    if (ConfigFile.tenantType == "tmsx")
                        checkbox = Browser.Wd.FindElement(By.XPath("//*[@class='k-grid-aria-root']//tr[contains(.,'" + mbi + "')]//td/input[@type='checkbox']"));
                    else
                        checkbox = Browser.Wd.FindElement(By.XPath("//div[@test-id='legacyMember-grid-legacyMemberGrid']//td/span[@ng-bind='dataItem.hic'][contains(.,'" + mbi + "')]/parent::td/following-sibling::td/input[@type='checkbox']"));
                    fw.ExecuteJavascript(checkbox);

                    IWebElement mbiValue;
                    if (ConfigFile.tenantType == "tmsx")
                    {
                        mbiValue = Browser.Wd.FindElement(By.XPath("(//*[@class='k-grid-aria-root']//tr[contains(.,'" + mbi + "')]//td)[1]"));
                    }
                    else
                    {
                        mbiValue = Browser.Wd.FindElement(By.XPath("//div[@test-id='legacyMember-grid-legacyMemberGrid']//td/span[@ng-bind='dataItem.hic'][contains(.,'" + mbi + "')]"));
                    }
                    GlobalRef.TransMBI = mbiValue.Text;

                }

            }

        }

        [When(@"Lagacy Member Checked send button for first record and Note MBI")]
        public void WhenLagacyMemberCheckedSendButtonForFirstRecordAndNoteMBI()
        {
            IWebElement firstCheck;
            IWebElement mbi;
            if (ConfigFile.tenantType == "tmsx")
            {
                firstCheck = Browser.Wd.FindElement(By.XPath("(//*[@class='k-grid-aria-root']//input[@type='checkbox'])[1]"));
                fw.ExecuteJavascript(firstCheck);
                mbi = Browser.Wd.FindElement(By.XPath("(//*[@class='k-grid-aria-root']//td)[1]"));
            }
            else
            {
                firstCheck = Browser.Wd.FindElement(By.XPath("(//div[@test-id='legacyTrans-grid-legacyTransGrid']//input[@type='checkbox'])[1]"));
                fw.ExecuteJavascript(firstCheck);
                mbi = Browser.Wd.FindElement(By.XPath("(//div[@test-id='legacyTrans-grid-legacyTransGrid']//td/span[@ng-bind='dataItem.hic'])[1]"));
            }
            GlobalRef.TransMBI = mbi.Text;

       }


        [When(@"Lagacy Transaction Page Newly Created Member MBI ""(.*)"" is checked from Search results and Exported")]
        public void WhenLagacyTransactionPageNewlyCreatedMemberMBIIsCheckedFromSearchResultsAndExported(string p0)
        {
            string mbi = tmsCommon.GenerateData(p0);
            bool elementSearch = false;
            By mbiBy = By.XPath("//div[@test-id='legacyTrans-grid-legacyTransGrid']//tbody[contains(.,'" + mbi + "')]");
            By nextPage = By.XPath("//a[@title='Go to the next page']");

            while (!elementSearch)
            {
                elementSearch = elementPresence(mbiBy);
                tmsWait.Hard(3);
                if (!elementSearch)
                {
                    try
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(nextPage));
                    }
                    catch
                    {
                        Assert.Fail(" Expected MBI is not present on Export Search results");
                    }
                }

                if (elementSearch)
                {
                    fw.ExecuteJavascript(cfEAMExport.ExportLegacyMembers.DeselectAll);
                    tmsWait.Hard(2);
                    IWebElement checkbox = Browser.Wd.FindElement(By.XPath("//div[@test-id='legacyTrans-grid-legacyTransGrid']//td/span[@ng-bind='dataItem.hic'][contains(.,'" + mbi + "')]/parent::td/following-sibling::td/input[@type='checkbox']"));
                    fw.ExecuteJavascript(checkbox);


                    IWebElement mbiValue = Browser.Wd.FindElement(By.XPath("//div[@test-id='legacyTrans-grid-legacyTransGrid']//td/span[@ng-bind='dataItem.hic'][contains(.,'" + mbi + "')]"));
                    GlobalRef.TransMBI = mbiValue.Text;
                }

            }
        }

        [When(@"Lagacy Member Export page Search results Expected MBI Send button is Checked and Note MBI")]
        public void WhenLagacyMemberExportPageSearchResultsExpectedMBISendButtonIsCheckedAndNoteMBI()
        {
            string mbi = GlobalRef.LTMBI.ToString();
            bool elementSearch = false;
            By mbiBy = By.XPath("//div[@test-id='legacyTrans-grid-legacyTransGrid']//tbody[contains(.,'" + mbi + "')]");
            By nextPage = By.XPath("//a[@title='Go to the next page']");

            while (!elementSearch)
            {
                elementSearch = elementPresence(mbiBy);
                tmsWait.Hard(3);
                if (!elementSearch)
                {
                    try
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(nextPage));
                    }
                    catch
                    {
                        Assert.Fail(" Expected MBI is not present on Export Search results");
                    }
                }

                if (elementSearch)
                {
                    fw.ExecuteJavascript(cfEAMExport.ExportLegacyMembers.DeselectAll);
                    tmsWait.Hard(2);
                    IWebElement checkbox = Browser.Wd.FindElement(By.XPath("//div[@test-id='legacyTrans-grid-legacyTransGrid']//td/span[@ng-bind='dataItem.hic'][contains(.,'" + mbi + "')]/parent::td/following-sibling::td/input[@type='checkbox']"));
                    fw.ExecuteJavascript(checkbox);


                    IWebElement mbiValue = Browser.Wd.FindElement(By.XPath("//div[@test-id='legacyTrans-grid-legacyTransGrid']//td/span[@ng-bind='dataItem.hic'][contains(.,'" + mbi + "')]"));
                    GlobalRef.TransMBI = mbiValue.Text;
                }

            }

        }


        [When(@"Lagacy Member Chekced send button for first records and Note MBI")]
        public void WhenLagacyMemberChekcedSendButtonForFirstRecordsAndNoteMBI()
        {
            IWebElement firstCheck;
            IWebElement mbi;
            if (ConfigFile.tenantType == "tmsx")
            {
                firstCheck = Browser.Wd.FindElement(By.XPath("(//*[@class='k-grid-aria-root']//input[@type='checkbox'])[1]"));
                fw.ExecuteJavascript(firstCheck);
                mbi = Browser.Wd.FindElement(By.XPath("(//*[@class='k-grid-aria-root']//td)[1]"));
            }
            else
            {
                firstCheck = Browser.Wd.FindElement(By.XPath("(//div[@test-id='legacyTrans-grid-legacyTransGrid']//input[@type='checkbox'])[1]"));
                fw.ExecuteJavascript(firstCheck);
                mbi = Browser.Wd.FindElement(By.XPath("(//div[@test-id='legacyTrans-grid-legacyTransGrid']//td/span[@ng-bind='dataItem.hic'])[1]"));
            }
            GlobalRef.TransMBI = mbi.Text;
                

        }

        [When(@"Lagacy Member Page Multi Records are selected and Exported")]
        public void WhenLagacyMemberPageMultiRecordsAreSelectedAndExported()
        {
            IWebElement firstCheck;
            IWebElement SecondCheck;
            IWebElement mbi;
            if (ConfigFile.tenantType == "tmsx")
            {
                firstCheck = Browser.Wd.FindElement(By.XPath("(//*[@test-id='legacyMember-grid-legacyMemberDataGrid']//input[@type='checkbox'])[1]"));
                fw.ExecuteJavascript(firstCheck);
                SecondCheck = Browser.Wd.FindElement(By.XPath("(//*[@test-id='legacyMember-grid-legacyMemberDataGrid']//input[@type='checkbox'])[2]"));
                tmsWait.Hard(1);
                fw.ExecuteJavascript(SecondCheck);
                mbi = Browser.Wd.FindElement(By.XPath("(//*[@test-id='legacyMember-grid-legacyMemberDataGrid']//td)[1]"));
            }
            else {
                firstCheck = Browser.Wd.FindElement(By.XPath("(//div[@test-id='legacyMember-grid-legacyMemberGrid']//input[@type='checkbox'])[1]"));
                fw.ExecuteJavascript(firstCheck);
                SecondCheck = Browser.Wd.FindElement(By.XPath("(//div[@test-id='legacyMember-grid-legacyMemberGrid']//input[@type='checkbox'])[2]"));
                tmsWait.Hard(1);
                fw.ExecuteJavascript(SecondCheck);
                mbi = Browser.Wd.FindElement(By.XPath("(//div[@test-id='legacyMember-grid-legacyMemberGrid']//td/span[@ng-bind='dataItem.hic'])[1]"));
            }
               
      }


        [When(@"Lagacy Transaction Page Multi Recors are selected and Exported")]
        public void WhenLagacyTransactionPageMultiRecorsAreSelectedAndExported()
        {

            IWebElement firstCheck;
            IWebElement SecondCheck;
            IWebElement mbi;

            if (ConfigFile.tenantType == "tmsx")
            {
                firstCheck = Browser.Wd.FindElement(By.XPath("(//*[@class='k-grid-aria-root']//input[@type='checkbox'])[1]"));
                fw.ExecuteJavascript(firstCheck);
                SecondCheck = Browser.Wd.FindElement(By.XPath("(//*[@class='k-grid-aria-root']//input[@type='checkbox'])[2]"));
                fw.ExecuteJavascript(SecondCheck);
                mbi = Browser.Wd.FindElement(By.XPath("(//*[@class='k-grid-aria-root']//td)[1]"));
            }
            else
            {
                firstCheck = Browser.Wd.FindElement(By.XPath("(//div[@test-id='legacyTrans-grid-legacyTransGrid']//input[@type='checkbox'])[1]"));
                fw.ExecuteJavascript(firstCheck);
                SecondCheck = Browser.Wd.FindElement(By.XPath("(//div[@test-id='legacyTrans-grid-legacyTransGrid']//input[@type='checkbox'])[2]"));
                fw.ExecuteJavascript(SecondCheck);
                mbi = Browser.Wd.FindElement(By.XPath("(//div[@test-id='legacyTrans-grid-legacyTransGrid']//td/span[@ng-bind='dataItem.hic'])[1]"));

            }
            GlobalRef.TransMBI= mbi.Text;
          
        }


        [When(@"Lagacy Member Chekced send button for first five records")]
        public void WhenLagacyMemberChekcedSendButtonForFirstFiveRecords()
        {
            //IReadOnlyCollection<IWebElement> MyLagacymember = cfEAMExport.ExportLegacyMembers.ExportMemberGrid.FindElements(By.TagName("tr"));

            //foreach(var mylagacy in MyLagacymember)
            //{
            //    IWebElement myele = mylagacy.FindElement(By.XPath("td[6]"));
            //    string myvalue = myele.Text;
            //    if (myvalue != "Send")
            //    {
            //        fw.ExecuteJavascript(mylagacy.FindElement(By.XPath("td[6]/input")));
            //    }
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dgRaps_ctl03_chk")));
            tmsWait.Hard(1);
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dgRaps_ctl04_chk")));
            // tmsWait.Hard(1);
            // fw.ExecuteJavascript(Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dgRaps_ctl05_chk")));
            // tmsWait.Hard(2);


            IWebElement hic = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_dgRaps']//tr[2]//td[1]"));
            string MBIValue = hic.Text;
            GlobalRef.TransMBI= MBIValue;
            
        }

        [When(@"Legacy Member Check modified only check box")]
        public void WhenLegacyMemberCheckModifiedOnlyCheckBox()
        {
            fw.ExecuteJavascript(cfEAMExport.ExportLegacyMembers.ModifiedCheck);
            tmsWait.Hard(1);
        }

        [When(@"Legacy Member Order by is set to ""(.*)""")]
        public void WhenLegacyMemberOrderByIsSetTo(string od)
        {
            SelectElement orderby = new SelectElement(cfEAMExport.ExportLegacyMembers.OrderBy);
            orderby.SelectByText(od);
            tmsWait.Hard(1);
        }

        [When(@"Legacy Member Export is set to ""(.*)""")]
        public void WhenLegacyMemberExportIsSetTo(string exportoption)
        {
            tmsWait.Hard(5);
            SelectElement Memexport = new SelectElement(cfEAMExport.ExportLegacyMembers.Export);
            Memexport.SelectByText(exportoption);
            tmsWait.Hard(1);
        }

        [When(@"Legacy Member OrderBy ""(.*)""")]
        public void WhenLegacyMemberOrderBy(string p0)
        {
            tmsWait.Hard(1);
            SelectElement Memexport = new SelectElement(cfEAMExport.ExportLegacyMembers.OrderBy);
            Memexport.SelectByText(p0);
            tmsWait.Hard(2);
        }


        [When(@"Legacy Member Reset button is clicked")]
        public void WhenLegacyMemberResetButtonIsClicked()
        {
            fw.ExecuteJavascript(cfEAMExport.ExportLegacyMembers.ResetButton);
            tmsWait.Hard(3);
        }

        [Then(@"Verify Legacy Member fields reset to default values as Planid ""(.*)"" MemberStatus ""(.*)"" OrderBy ""(.*)""")]
        public void ThenVerifyLegacyMemberFieldsResetToDefaultValuesAsPlanidMemberStatusOrderBy(string planid, string status, string orderby)
        {
            Boolean ispresent = false;
            SelectElement pi = new SelectElement(cfEAMExport.ExportLegacyMembers.PlanID);
            string actual_planid = pi.SelectedOption.Text;
            SelectElement ms = new SelectElement(cfEAMExport.ExportLegacyMembers.MemberStatus);
            string actual_memberstatus = ms.SelectedOption.Text;
            SelectElement ob = new SelectElement(cfEAMExport.ExportLegacyMembers.OrderBy);
            string actual_orderby = ob.SelectedOption.Text;
            if(actual_planid == planid)
            {
                ispresent = true;
            }

            Assert.IsTrue(ispresent);
        }

        [Then(@"Verify Check box under column Send is unchecked")]
        public void ThenVerifyCheckBoxUnderColumnSendIsUnchecked()
        {
            tmsWait.Hard(3);
            IWebElement myuncheck = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dgRaps_ctl03_chk"));
            Boolean boolmyunchek=myuncheck.Selected;
            Assert.IsFalse(boolmyunchek);
        }

        [When(@"Legacy Member Select All button is clicked")]
        public void WhenLegacyMemberSelectAllButtonIsClicked()
        {
            fw.ExecuteJavascript(cfEAMExport.ExportLegacyMembers.SelectAll);
            tmsWait.Hard(3);
        }

      
        [Then(@"Verify check box under column Send is ""(.*)""")]
        public void ThenVerifyCheckBoxUnderColumnSendIs(string p0)
        {
            tmsWait.Hard(3);
            IWebElement mycheck = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dgRaps_ctl03_chk"));
            Boolean boolmycheck=mycheck.Selected;
            Assert.IsTrue(boolmycheck);
        }


        // Below code is to get first value of the very first column hence this is useful if coder looking for single value of any specific column

        [When(@"Execute sql query ""(.*)"" to get the value of ""(.*)""")]
        public void WhenExecuteSqlQueryToGetTheValueOf(string myquery, string valueOf)
        {
            int TotalRecords = 0;
            string thisConnectionString = "user id=" + ConfigFile.DBUser + ";" +
                                   "password=" + ConfigFile.DBPassword + ";" +
                                   "Data Source=" + ConfigFile.DataServer + "," + ConfigFile.Port + ";" +
                                   "Network Library=DBMSSOCN;" +
                                   "Initial Catalog=" + ConfigFile.ERFdb + "; " +
                                   "connection timeout=30";
            string sql = myquery;
            using (SqlConnection conn = new SqlConnection(thisConnectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, conn);
                string mycolumn = "@" +valueOf;
                cmd.Parameters.AddWithValue(mycolumn, 1);
               // try
               // {
                    conn.Open();
               
                //TotalRecords = int(cmd.ExecuteScalar());
                string ii = cmd.ExecuteScalar().ToString();
                TotalRecords = Int32.Parse(ii.ToString());
               // }
                //catch (Exception ex)
               // {
                    //Console.WriteLine(ex.Message);
                //}
            }

            GlobalRef.querycount = TotalRecords;
          


        }

        [Then(@"Verify above query result should be equal to ""(.*)""")]
        public void ThenVerifyAboveQueryResultShouldBeEqualTo(int p0)
        {
            string actualvalue = GlobalRef.querycount.ToString();
            int acvalue = Int32.Parse(actualvalue);
            Assert.AreEqual(p0, actualvalue, "Query result is not what is expected");
        }


        [When(@"I store the result of above query")]
        public void WhenIStoreTheResultOfAboveQuery()
        {
            GlobalRef.querycount = Int32.Parse(GlobalRef.querycount.ToString());
        }


        [Then(@"Verify Total number of records in member legacy file are same as total count of plan id ""(.*)""")]
        public void ThenVerifyTotalNumberOfRecordsInMemberLegacyFileAreSameAsTotalCountOfPlanId(string p0)
        {
            int mycount = Int32.Parse(GlobalRef.TotalcountInFile.ToString());
            int querycount1 = Int32.Parse(GlobalRef.querycount.ToString());
            
            Assert.AreEqual(querycount1, mycount, "Total number of records in the file does not matches with records in data base");
        }


        [Then(@"Verify OUTOFAREA value is displayed ""(.*)""")]
        public void ThenVerifyOUTOFAREAValueIsDisplayed(int p0)
        {
           
            int querycount1 = Int32.Parse(GlobalRef.querycount.ToString());
            Assert.AreEqual(querycount1, p0, "OutOfArea value does not matched");
        }


        [Then(@"Verify the message on Legacy Member page ""(.*)"" is displayed")]
        public void ThenVerifyTheMessageOnLegacyMemberPageIsDisplayed(string Norecords)
        {
            tmsWait.Hard(2);
            Assert.AreEqual(cfEAMExport.ExportLegacyMembers.NorecordInQMessage.Text, Norecords, "There is no such message is displayed");
        }

        [Then(@"Verify Legacy Member Result Grid has MBI ""(.*)""")]
        public void ThenVerifyLegacyMemberResultGridHasMBI(string p0)
        {
            Boolean ispresent = false;
            string expectedMbi = tmsCommon.GenerateData(p0);
            IWebElement exportGrid = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_dgRaps']/tbody"));
            IReadOnlyCollection<IWebElement> allrows = exportGrid.FindElements(By.TagName("tr"));
            foreach(var row in allrows)
            {
                //string actualMBI = row.FindElement(By.XPath("//td[1]")).Text;
                string[] actualhic = row.Text.Split(' ');

                if (expectedMbi.ToLower()== actualhic[0].ToLower())
                {
                    ispresent = true;
                    break;
                }
            }
            Assert.IsTrue(ispresent, "MBI Is not available for Export");
        }


        [Then(@"Verify Legacy Member Result Grid does not contains MBI ""(.*)""")]
        public void ThenVerifyLegacyMemberResultGridDoesNotContainsMBI(string p0)
        {
            Boolean ispresent = true;
            string expectedMbi = tmsCommon.GenerateData(p0);
            IWebElement exportGrid = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_dgRaps']/tbody"));
            IReadOnlyCollection<IWebElement> allrows = exportGrid.FindElements(By.TagName("tr"));
            foreach (var row in allrows)
            {
                //string actualMBI = row.FindElement(By.XPath("//td[1]")).Text;
                string[] actualhic = row.Text.Split(' ');

                if (expectedMbi.ToLower() == actualhic[0].ToLower())
                {
                    ispresent = false;
                    break;
                }
            }
            Assert.IsFalse(ispresent, "MBI Is available for Export, but it should not");
        }


        [When(@"Legacy Member Send checkbox is checked for MBI ""(.*)""")]
        public void WhenLegacyMemberSendCheckboxIsCheckedForMBI(string p0)
        {
           // Boolean ispresent = false;
            string expectedMbi = tmsCommon.GenerateData(p0);
            IWebElement exportGrid = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_dgRaps']/tbody"));
            IReadOnlyCollection<IWebElement> allrows = exportGrid.FindElements(By.TagName("tr"));
            foreach (var row in allrows)
            {
                //  string actualMBI = row.FindElement(By.XPath("//td[1]")).Text;
                string[] actualhic = row.Text.Split(' ');
                if (expectedMbi == actualhic[0])
                {
                    fw.ExecuteJavascript(row.FindElement(By.XPath("//td[6]/input")));                   
                    break;
                }
            }
            
        }


        //[Then(@"Verify legacy member export file has data ""(.*)""")]
        //public void ThenVerifyLegacyMemberExportFileHasData(string p0)
        //{
        //    string expecteddata = tmsCommon.GenerateData(p0);
        //    var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
        //}

        [When(@"Legacy Member Export page number ""(.*)"" is clicked")]
        public void WhenLegacyMemberExportPageNumberIsClicked(int p0)
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[contains(.,'"+p0.ToString()+"')]")));
            tmsWait.Hard(3);
        }

        [When(@"Export BEQ File Export button is clicked")]
        public void WhenExportBEQFileExportButtonIsClicked()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='exportBeq-btn-export']")));
            tmsWait.Hard(3);
        }



    }
}
