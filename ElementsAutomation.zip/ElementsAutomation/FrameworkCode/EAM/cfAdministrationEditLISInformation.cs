﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.EAM
{
   public class cfAdministrationEditLISInformation
    {
        public static AdministrationEditLISInformation AdministrationEditLISInformation { get { return new AdministrationEditLISInformation(); } }
    }


    [Binding]

    public class AdministrationEditLISInformation
    {
        public IWebElement PartCAmount { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_txtPartC")); } }
       
    }
}
