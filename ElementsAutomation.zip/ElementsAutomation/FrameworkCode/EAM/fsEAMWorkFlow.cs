﻿using System;
using OpenQA.Selenium;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Support.UI;
using System.Collections.ObjectModel;
using TechTalk.SpecFlow;


//Added by Swapna Chappidi on 02/24/2016 for WorkFlow
namespace TMSoR1
{

    [Binding]
    public class WF_DashBoard_WorkItems
    {

        public static string GeneratedUserID;
        
        //Added by Swapna Chappidi on 03/01/2016 for WorkFlow
        [When(@"""(.*)"" is present and Count is stored in variable ""(.*)""")]
        public void WhenIsPresentAndCountIsStoredInVariable(string p0, string p1)
        {
            //Get the table container by.id
            //Get the TR  List by.Tagname
            //Search through the TR's looking for TD's by.Tagname that match table

            IWebElement baseTable = EAM.WFDashboard.WFDashboardTable;
            ReadOnlyCollection<IWebElement> allRows = baseTable.FindElements(By.TagName("tr"));


            foreach (IWebElement row in allRows)
            {

                if (row.Text.Contains(p0))
                {
                    ReadOnlyCollection<IWebElement> cells = row.FindElements(By.TagName("td"));

                    foreach (IWebElement cell in cells)
                    {
                        // p1 = cell.Text;
                        GeneratedUserID = tmsCommon.GenerateData(cell.Text);
                        fw.setVariable(p1, GeneratedUserID);

                        break;
                    }

                }


            }
        }

        //Added by Swapna Chappidi on 03/02/2016 for WorkFlow
        [Then(@"""(.*)"" is present and Count is stored in variable ""(.*)""")]
        public void ThenIsPresentAndCountIsStoredInVariable(string p0, string p1)
        {

            IWebElement baseTable = EAM.WFDashboard.WFDashboardTable;
            ReadOnlyCollection<IWebElement> allRows = baseTable.FindElements(By.TagName("tr"));


            foreach (IWebElement row in allRows)
            {

                if (row.Text.Contains(p0))
                {
                    ReadOnlyCollection<IWebElement> cells = row.FindElements(By.TagName("td"));

                    foreach (IWebElement cell in cells)
                    {
                        // p1 = cell.Text;
                        GeneratedUserID = tmsCommon.GenerateData(cell.Text);
                        fw.setVariable(p1, GeneratedUserID);

                        break;
                    }

                }


            }
        }
        //Added by Swapna Chappidi on 03/02/2016 for WorkFlow
        [Then(@"Verify Integer comparison ""(.*)"" and ""(.*)"" = ""(.*)""")]
        public void ThenVerifyIntegerComparrisonAnd(string p0, string p1, int p2)
        {
            string numValueB = fw.getVariable(p0);
            string numValueA = fw.getVariable(p1);
            int intNumValueB, intNumValueA;
         
            try
            {
                intNumValueB = Convert.ToInt32(numValueB);
                intNumValueA = Convert.ToInt32(numValueA);
                int diff = intNumValueA - intNumValueB;
                Assert.AreEqual(p2, diff);

            }
            catch (OverflowException)
            {
                Console.WriteLine("{0} is outside the range of the Int32 type.", numValueB);
            }
            catch (FormatException)
            {
                Console.WriteLine("The {0} value '{1}' is not in a recognizable format.",
                                  numValueB.GetType().Name, numValueB);
            } 

            /*int beforeCnt = Convert.ToInt32(p0);
            int afterCnt = Convert.ToInt32(p1);*/

 

            
        }


        [Then(@"PageName Workflow Items table has row, and ""(.*)"" is present and Count is stored in variable ""(.*)""")]
        public void ThenPageNameWorkflowItemsTableHasRowAndCountIsStoredInVariable(string p0, string p1, Table table)
        {
            //Get the table container by.id
            //Get the TR  List by.Tagname
            //Search through the TR's looking for TD's by.Tagname that match table

            IWebElement baseTable = EAM.WFDashboard.WFDashboardTable;
            ReadOnlyCollection<IWebElement> allRows = baseTable.FindElements(By.TagName("tr"));

            
            foreach (IWebElement row in allRows)
            {
                
                if (row.Text.Contains(p0))
                {
                    ReadOnlyCollection<IWebElement> cells = row.FindElements(By.TagName("td"));

                    foreach (IWebElement cell in cells)
                    {
                       // p1 = cell.Text;
                        GeneratedUserID = tmsCommon.GenerateData(cell.Text);
                        fw.setVariable(p1, GeneratedUserID);

                        break;
                     }
                    
                }
               
                 
            }
        }

        [Then(@"Numcmo Initial Enrollment Queue count is set to ""(.*)""")]
        public void ThenNumcmoInitialEnrollmentQueueCountIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            p0 = EAM.WFDashboard.NumcmoEnrlQueueCnt.Text;
            //EAM.MembersNew.FirstName.Clear();
            //EAM.MembersNew.FirstName.SendKeys(GeneratedData);
        }

            


        [Then(@"Dashboard Inventory Summary Chart should be displayed")]
        public void ThenDashboardInventorySummaryChartShouldBeDisplayed()
        {
            Browser.SwitchToChildWindow();
            Assert.IsTrue(EAM.WorkFlowConfiguration.WFSummaryChart.Displayed, "Workflow Summary Chart is not displayed");
        }

        [Then(@"Verify Administration Menu should not be displayed")]
        public void ThenVerifyAdministrationMenuShouldNotBeDisplayed()
        {
            try
            {
                Assert.IsFalse(EAM.AdministrationWorkflow.AdministartionLink.Displayed, "Administration link is displayed");
            }
            catch (Exception ex)
            {
                fw.ConsoleReport("Administration link is not displayed");
            }
        }

        [Then(@"Get initial count of ""(.*)""")]
        public void ThenGetInitialCountOf(string detail)
        {
            GlobalRef.InitialOECCount = Int32.Parse(Browser.Wd.FindElement(By.XPath(".//td[contains(.,'" + detail + "')]/preceding-sibling::td/a")).Text);
            
        }

        [Then(@"Verify queue ""(.*)"" count is not increased")]
        public void ThenVerifyQueueCountIsNotIncreased(string detail)
        {
            GlobalRef.FinalOECCount = Int32.Parse(Browser.Wd.FindElement(By.XPath(".//td[contains(.,'" + detail + "')]/preceding-sibling::td/a")).Text);
            var initcount = GlobalRef.InitialOECCount;
            var finalcount = GlobalRef.FinalOECCount;
            int initiallettercount = Convert.ToInt32(initcount);
            int finallettercount = Convert.ToInt32(finalcount);
            bool res = (initiallettercount == finallettercount);
            Assert.IsTrue(res, "Letter Count for Outbound Enrollment Verification Letter is Increased");
            fw.ConsoleReport("Letter Count for Outbound Enrollment Verification Letter is not increased");
        }

        [Then(@"Verify queue ""(.*)"" count is increased by (.*)")]
        public void ThenVerifyQueueCountIsIncreasedBy(string detail, int count)
        {
            GlobalRef.FinalOECCount = Int32.Parse(Browser.Wd.FindElement(By.XPath(".//td[contains(.,'" + detail + "')]/preceding-sibling::td/a")).Text);
            var initcount = GlobalRef.InitialOECCount;
            var finalcount = GlobalRef.FinalOECCount;
            int initiallettercount = Convert.ToInt32(initcount);
            int finallettercount = Convert.ToInt32(finalcount);
            bool res = ((initiallettercount + count) == finallettercount);
            Assert.IsTrue(res, "Letter Count for Outbound Enrollment Verification Letter is not Increased by 1");
            fw.ConsoleReport("Letter Count for Outbound Enrollment Verification Letter is increased by 1");
        }
        

        [When(@"WorkflowDashboard ""(.*)"" workitem count is clicked")]
        public void WhenWorkflowDashboardWorkitemCountIsClicked(string detail)
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(".//td[contains(.,'" + detail + "')]/preceding-sibling::td/a")));
        }

        [When(@"Workitemdetails Workitem Re-Assign button is clicked")]
        public void WhenWorkitemdetailsWorkitemRe_AssignButtonIsClicked()
        {
            tmsWait.Hard(2);
            EAM.WorkFlowConfiguration.ReassignButton.Click();
        }

        [Then(@"Verify workitemdetails Error message ""(.*)""")]
        public void ThenVerifyWorkitemdetailsErrorMessage(string errorMessage)
        {
            tmsWait.Hard(2);
            Assert.IsTrue(EAM.WorkFlowConfiguration.ErrorMessage.Text.Contains(errorMessage), "Error message is not displayed. Failed.....");
        }

        [When(@"Workitemdetails Workitem ""(.*)"" check box is checked")]
        public void WhenWorkitemdetailsWorkitemCheckBoxIsChecked(string messageID)
        {
            tmsWait.Hard(2);
            Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + messageID + "')]/preceding-sibling::td/input")).Click();
        }


        [When(@"Reassign window ChangeAssignment Queue is set to ""(.*)""")]
        public void WhenReassignWindowChangeAssignmentQueueIsSetTo(string queueToBeChanged)
        {
            tmsWait.Hard(2);
            SelectElement queue = new SelectElement(EAM.WorkFlowConfiguration.QueueDropdown);
            queue.SelectByText(queueToBeChanged);
            tmsWait.Hard(2);
        }

        [When(@"Reassign window ChangeAssignment Role is set to ""(.*)""")]
        public void WhenReassignWindowChangeAssignmentRoleIsSetTo(string roleToBeChanged)
        {
            tmsWait.Hard(5);
            SelectElement role = new SelectElement(EAM.WorkFlowConfiguration.RoleDropdown);
            role.SelectByText(roleToBeChanged);
        }

        [When(@"ChangeAssignment Submit button is clicked")]
        public void WhenChangeAssignmentSubmitButtonIsClicked()
        {
            tmsWait.Hard(2);
            EAM.WorkFlowConfiguration.SubmitButton.Click();
        }

        [When(@"PFWF queue ""(.*)"" is clicked")]
        public void WhenPFWFQueueIsClicked(string workItem)
        {
            tmsWait.Hard(2);
            Browser.SwitchToChildWindow();
            switch (workItem.ToLower())
            {
                case "beq others":
                    EAM.WorkFlowConfiguration.BEQOthersBar.Click();
                    break;
                case "failed beq":
                    EAM.WorkFlowConfiguration.FailedBEQBar.Click();
                    break;
                case "enrollment reject queue":
                    EAM.WorkFlowConfiguration.EnrlRejectBar.Click();
                    break;
                case "numcmo initial enrollment queue":
                    EAM.WorkFlowConfiguration.NumcmoInitialEnrlBar.Click();
                    break;
            }
        }

        [When(@"PFWF queue circle is clicked")]
        public void WhenPFWFQueueCircleIsClicked()
        {
            tmsWait.Hard(2);
            EAM.WorkFlowConfiguration.PFWFCircle.Click();
        }

        [When(@"PF(.*)WF queue circle is clicked")]
        public void WhenPFWFQueueCircleIsClicked(int p0)
        {
            tmsWait.Hard(2);
            EAM.WorkFlowConfiguration.PFWFCircle1.Click();
        }

        [Then(@"Verify queue ""(.*)"" does not have workitem ""(.*)""")]
        public void ThenVerifyQueueDoesNotHaveWorkitem(string detail, string workItem)
        {
            tmsWait.Hard(2);
            EAM.WorkFlowConfiguration.MessageIDTextbox.SendKeys(workItem);
            try
            {
                if (EAM.WorkFlowConfiguration.GridFirstCell.Displayed)
                    Assert.IsFalse(EAM.WorkFlowConfiguration.GridFirstCell.Text.Contains(workItem), workItem + " is displayed in " + detail);
            }catch(Exception ex)
            {
                fw.ConsoleReport(workItem + " is displayed in " + detail);
            }
        }

        [Then(@"Verify queue ""(.*)"" has workitem ""(.*)""")]
        public void ThenVerifyQueueHasWorkitem(string detail, string value)
        {
            string workItem = tmsCommon.GenerateData(value);
            tmsWait.Hard(2);
            EAM.WorkFlowConfiguration.MessageIDTextbox.Clear();
            EAM.WorkFlowConfiguration.MessageIDTextbox.SendKeys(workItem);
            Assert.IsTrue(EAM.WorkFlowConfiguration.GridFirstCell.Text.Contains(workItem), workItem + " is not displayed in " + detail);           
        }


        [When(@"PFWF back button is clicked")]
        public void WhenPFWFBackButtonIsClicked()
        {
            tmsWait.Hard(2);
            EAM.WorkFlowConfiguration.PFWFBackButton.Click();
        }


        [When(@"PFWF queue ""(.*)"" workitem ""(.*)"" is searched and clicked")]
        public void WhenPFWFQueueWorkitemIsSearchedAndClicked(string detail, string workItem)
        {
            tmsWait.Hard(2);
            EAM.WorkFlowConfiguration.MessageIDTextbox.Clear();
            EAM.WorkFlowConfiguration.MessageIDTextbox.SendKeys(workItem);
            EAM.WorkFlowConfiguration.GridFirstCell.Click();
        }

        [When(@"PFWF Reassign button is clicked")]
        public void WhenPFWFReassignButtonIsClicked()
        {
            tmsWait.Hard(2);
            EAM.WorkFlowConfiguration.PFWFReassignButton.Click();
        }


        [When(@"PFWF Reassign Queue is set to ""(.*)""")]
        public void WhenPFWFReassignQueueIsSetTo(string queueToSelect)
        {
            tmsWait.Hard(2);
            SelectElement queue = new SelectElement(EAM.WorkFlowConfiguration.PFWFQueueDropdown);
            queue.SelectByText(queueToSelect);
        }

        [When(@"PFWF Reassign Role is set to ""(.*)""")]
        public void WhenPFWFReassignRoleIsSetTo(string roelToSelect)
        {
            tmsWait.Hard(2);
            SelectElement role = new SelectElement(EAM.WorkFlowConfiguration.PFWFRoleDropdown);
            role.SelectByText(roelToSelect);
        }


        [When(@"PFWF Reassign Save button is clicked")]
        public void WhenPFWFReassignSaveButtonIsClicked()
        {
            tmsWait.Hard(2);
            EAM.WorkFlowConfiguration.PFWFSaveButton.Click();
        }

        //Added by Swapna Chappidi on 3/3/2016
        [Then(@"Workflowdashboard WorkflowQueue workitem count is displayed in descending order")]
        public void ThenWorkflowdashboardWorkflowQueueWorkitemCountIsDisplayInDescendingOrder()
        {
            IWebElement baseTable = EAM.WFDashboard.WFDashboardTable;
            ReadOnlyCollection<IWebElement> allRows = baseTable.FindElements(By.TagName("tr"));

            int row1=0, row2 = 0;
            int counter=0;

            foreach (IWebElement row in allRows)
            {

                    ReadOnlyCollection<IWebElement> cells = row.FindElements(By.TagName("td"));

                    foreach (IWebElement cell in cells)
                    {
                        counter++;
                        GeneratedUserID = tmsCommon.GenerateData(cell.Text);
                        
                        try
                        {
                            if (counter == 1)
                            {
                                row1 = Convert.ToInt32(GeneratedUserID);
                            }
                            if(counter >=2 )
                            {
                                row2 = Convert.ToInt32(GeneratedUserID);
                                Assert.AreEqual(row1, row2);
                                row1 = row2;
                            }

                        }
                        catch (OverflowException)
                        {
                            Console.WriteLine("is outside the range of the Int32 type.");
                        }
                        catch (FormatException)
                        {
                            Console.WriteLine("is not in a recognizable format." );
                        } 
                     
                        break;
                    }
             
            }
        }


        [Then(@"Verify WFSupervisorDashboard ""(.*)"" button is disabled")]
        public void ThenVerifyWFSupervisorDashboardButtonIsDisabled(string action)
        {
            try
            {
                switch (action.ToLower())
                {
                    case "resend all":
                        Assert.IsTrue(EAM.WorkFlowConfiguration.PFWFResendAllButton.Displayed);
                        break;
                    case "delete all":
                        Assert.IsTrue(EAM.WorkFlowConfiguration.PFWFDeleteAllButton.Displayed);
                        break;
                }
            }catch(Exception ex)
            {
                fw.ConsoleReport(action + " is disabled.");
            }
        }

        [When(@"workflowdashboard ""(.*)"" button is clicked")]
        public void WhenWorkflowdashboardButtonIsClicked(string action)
        {
            tmsWait.Hard(2);
            if (!EAM.WorkFlowConfiguration.BadMessageCount.Text.Equals("0"))
            {
                switch (action.ToLower())
                {
                    case "resend all":
                        EAM.WorkFlowConfiguration.PFWFResendAllButton.Click();
                        Browser.Wd.SwitchTo().Alert().Accept();
                        break;
                    case "delete all":
                        EAM.WorkFlowConfiguration.PFWFDeleteAllButton.Click();
                        Browser.Wd.SwitchTo().Alert().Accept();
                        break;
                }
            }
            else
            {
                fw.ConsoleReport("Bad Message count is already 0.");
            }
            if (action.ToLower().Equals("refresh data"))
            {
                GlobalRef.InitialBadMessageCount = Int32.Parse(EAM.WorkFlowConfiguration.BadMessageCount.Text);
                EAM.WorkFlowConfiguration.PFWFRefreshDataButton.Click();
            }
        }

        [When(@"Verify workflowDashboard Bad message count is updated")]
        public void WhenVerifyWorkflowDashboardBadMessageCountIsUpdated()
        {
            GlobalRef.BadMessageCountAfterRefresh = EAM.WorkFlowConfiguration.BadMessageCount.Text;
            var initcount = GlobalRef.InitialBadMessageCount;
            var finalcount = GlobalRef.BadMessageCountAfterRefresh;
            int initiaBadMessageCount = Convert.ToInt32(initcount);
            int finalBadMessageCount = Convert.ToInt32(finalcount);
            bool res = (initiaBadMessageCount >= finalBadMessageCount);
            Assert.IsTrue(res, "Bad Message Count is not updated.");
            fw.ConsoleReport("Bad Message Count is updated after refreshing data...");
        }


        [Then(@"Verify workflowdashboard Bad message count is displayed ""(.*)""")]
        public void ThenVerifyWorkflowdashboardBadMessageCountIsDisplayed(string count)
        {
            Assert.IsTrue(EAM.WorkFlowConfiguration.BadMessageCount.Text.Equals(count), "Bad Message Count is not 0");
        }


        [When(@"Workitemdetails priority filter is set to ""(.*)""")]
        public void WhenWorkitemdetailsPriorityFilterIsSetTo(string priorityToSelect)
        {
            tmsWait.Hard(2);
            SelectElement priority = new SelectElement(EAM.WorkFlowConfiguration.PFWFPriorityDropdown);
            priority.SelectByText(priorityToSelect);
            tmsWait.Hard(2);
            EAM.WorkFlowConfiguration.PFWFApplyButton.Click();
        }

        [Then(@"Verify All the ""(.*)"" priority workitems ""(.*)""")]
        public void ThenVerifyAllThePriorityWorkitems(string priority, string status)
        {
            try
            {
                if (EAM.WorkFlowConfiguration.PFWFPriorityFirstCell.Displayed)
                {
                    if (status.ToLower().Equals("displayed"))
                    {
                        Assert.IsTrue(EAM.WorkFlowConfiguration.PFWFPriorityFirstCell.Text.Equals(priority), priority + " priority records are not getting displayed.");
                    }
                    else
                    {
                        Assert.IsFalse(EAM.WorkFlowConfiguration.PFWFPriorityFirstCell.Text.Equals(priority), priority + " priority records are not getting displayed.");
                    }
                }
            }
            catch (Exception e)
            {
                fw.ConsoleReport("No records to display...");
            }
        }

        [When(@"workflow dashboard ""(.*)"" button is clicked")]
        public void WhenWorkflowDashboardButtonIsClicked(string p0)
        {
            EAM.WorkFlowConfiguration.BackToDashboardButton.Click();
        }

        [Then(@"Workflowdashboard WorkflowQueue row ""(.*)"" initial count is checked")]
        public void ThenWorkflowdashboardWorkflowQueueRowInitialCountIsChecked(string detail)
        {
            GlobalRef.InitialCount = Int32.Parse(Browser.Wd.FindElement(By.XPath(".//td[contains(.,'" + detail + "')]/preceding-sibling::td/a")).Text);
        }

        [Then(@"Workflowdashboard WorkflowQueue row ""(.*)"" final count is checked")]
        public void ThenWorkflowdashboardWorkflowQueueRowFinalCountIsChecked(string detail)
        {
            GlobalRef.FinalCount = Int32.Parse(Browser.Wd.FindElement(By.XPath(".//td[contains(.,'" + detail + "')]/preceding-sibling::td/a")).Text);
            var initcount = GlobalRef.InitialCount;
            var finalcount = GlobalRef.FinalCount;
            int initiaBadMessageCount = Convert.ToInt32(initcount);
            int finalBadMessageCount = Convert.ToInt32(finalcount);
            bool res = ((initiaBadMessageCount + 1) == finalBadMessageCount);
            Assert.IsTrue(res, detail + " is increased by one.");
            fw.ConsoleReport(detail + " increased by one. ");
        }

        [When(@"I clicked on EAM Main section")]
        public void WhenIClickedOnEAMMainSection()
        {
            tmsWait.Hard(20);
            IWebElement main = Browser.Wd.FindElement(By.XPath("//div[@title='Main']"));
            fw.ExecuteJavascript(main);
            tmsWait.Hard(3);
        }

        [Then(@"""(.*)"" link should ""(.*)"" Under Administration section")]
        public void ThenLinkShouldUnderAdministrationSection(string link, string status)
        {
         
            try
            {
                if (status.ToLower().Equals("not available"))
                    Assert.IsFalse(Browser.Wd.FindElement(By.XPath("//span[contains(.,'"+ link + "')]")).Displayed, link + " is available.");
                else
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + link + "')]")).Displayed, link + " is available.");
            }
            catch(Exception ex)
            {
                fw.ConsoleReport(link + " is not available. Caught exception while checking link availability...");
            }
            tmsWait.Hard(3);
        }

        [Given(@"I Name is set to '(.*)'")]
        public void GivenINameIsSetTo(string name)
        {
            EAM.WorkFlowConfiguration.WorkflownameTextbox.Clear();
            EAM.WorkFlowConfiguration.WorkflownameTextbox.SendKeys(name);
            Assert.IsTrue(EAM.WorkFlowConfiguration.WorkflownameTextbox.Text.Equals(""),"Name field contains special character.");
        }

        [Then(@"Values from all the fields should be cleared")]
        public void ThenValuesFromAllTheFieldsShouldBeCleared()
        {
            Assert.IsTrue(EAM.WorkFlowConfiguration.WFConfigurationServiceUrl.Text.Equals(""), "Service URL textbox is not resettled.");
            Assert.IsTrue(EAM.WorkFlowConfiguration.WFConfigurationAppUrl.Text.Equals(""), "Application URL textbox is not resettled.");
            Assert.IsTrue(EAM.WorkFlowConfiguration.WorkflownameTextbox.Text.Equals(""), "Name field textbox is not resettled.");
        }

        [When(@"I click on edit icon for the databse ""(.*)""")]
        public void WhenIClickOnEditIconForTheDatabse(string dbName)
        {
            Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + dbName + "')]/preceding-sibling::td//input[1]")).Click();
        }


        //Added by Swapna Chappidi on 03/03/2016
        [When(@"Workitem details page Back to Dashboard Home Clicked")]
        public void WhenWorkitemDetailsPageBackToDashboardHomeClicked()
        {
            EAM.WFDashboard.BackToWFDashBoard.Click();
        }

        //Added by Swapna Chappidi on 03/03/2016
        [Then(@"Verify Workflow Dashboard home page is displayed")]
        public void ThenVerifyWorkflowDashboardHomePageIsDisplayed()
        {
            string str = EAM.WFDashboard.WFDashboardTitle.Text;
        }


        //Added by Swapna Chappidi on 03/03/2016
        [Then(@"Workflowdashboard workitem count for ""(.*)"" is clicked")]
        [When(@"Workflowdashboard workitem count for ""(.*)"" is clicked")]
        public void WhenWorkflowdashboardWorkitemCountForIsClicked(string p0)
        {
            IWebElement baseTable = EAM.WFDashboard.WFDashboardTable;
            ReadOnlyCollection<IWebElement> allRows = baseTable.FindElements(By.TagName("tr"));

            foreach (IWebElement row in allRows)
            {

                if (row.Text.Contains(p0))
                {
                    ReadOnlyCollection<IWebElement> cells = row.FindElements(By.TagName("td"));

                    foreach (IWebElement cell in cells)
                    {
                        IWebElement countLink = cell.FindElement(By.TagName("a"));

                        countLink.Click();

                        break;
                    }
                    break;
                }

            }
        }

        //Added by Swapna Chappidi on 03/04/2016
        [Then(@"Workflowdashboard Queue Details Message ID ""(.*)"" is displayed")]
        public void ThenWorkflowdashboardQueueDetailsMessageIDIsDisplayed(string p0)
        {
            IWebElement baseTable = EAM.WFDashboard.WorkItemTable;
            ReadOnlyCollection<IWebElement> allRows = baseTable.FindElements(By.TagName("tr"));
            bool isPresent = false;

            foreach (IWebElement row in allRows)
            {

                if (row.Text.Contains(p0))
                {
                    isPresent = true;
                    break
                        ;
                }
            }
            Assert.IsTrue(isPresent);
        }



        [Then(@"I click on PFWorkFlow queue ""(.*)"" is clicked")]
        public void ThenIClickOnPFWorkFlowQueueIsClicked(string p0)
        {
            
        }

        //Added by swpana Chappidi on 03/08/3016
        [Then(@"Workitems details page is displayed")]
        public void ThenWorkitemsDetailsPageIsDisplayed()
        {
            Assert.IsTrue(EAM.WFDashboard.WorkItemTable.Displayed);
        }


        [When(@"Unlock button for WorkitemDetails ""(.*)"" is clicked")]
        public void WhenUnlockButtonForWorkitemDetailsIsClicked(string p0)
        {
            IWebElement baseTable = EAM.WFDashboard.WorkItemTable;
            ReadOnlyCollection<IWebElement> allRows = baseTable.FindElements(By.TagName("tr"));


            foreach (IWebElement row in allRows)
            {

                if (row.Text.Contains(p0))
                {
                    ReadOnlyCollection<IWebElement> cells = row.FindElements(By.TagName("td"));

                    foreach (IWebElement cell in cells)
                    {
     
                        //Browser.Wd.FindElement(By.XPath(".//td[contains(.,'" + detail + "')]/preceding-sibling::td/a")).Text;

                        IWebElement spantest = Browser.Wd.FindElement(By.XPath("//span[contains(.,'soapui')]"));
                        IWebElement lockunlock = Browser.Wd.FindElement(By.XPath("//span[contains(.,'soapui')]/preceding-sibling::*[1]"));
                        lockunlock.Click();                      
                        break;
                    }
                    break;

                }
                
            }
        }


        //Added by SC on 03/08/2016
        [When(@"PWF Enrollment Reject Queue is clicked")]
        public void WhenPWFEnrollmentRejectQueueIsClicked()
        {
            Browser.SwitchToChildWindow();
        }



        //Added by swpana Chappidi on 03/08/3016
        [Then(@"Verify Workflowdashboard workitem Table has row")]
        public void ThenVerifyWorkflowdashboardWorkitemTableHasRow(Table table)
        {
            {
                //Create Storage for the Gherkin table and the page data
                GherkinTable thisGT = new GherkinTable();
                TablePaging thisTP = new TablePaging();

                //Load the Gherkin table into the storage
                thisGT.LoadGherkinTable(table);

                //The big loop.  Keep working until all the Gherkin table rows are marked as matched
                //Or until we are on the last page of records, then we also quit looking.
                while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
                {
                    //Start out with the assumption we are not on the last page of records.  We will check later.
                    thisTP.bNotAtLastPageOfRecords = true;

                    //Get the table object again, since the page refreshes we need to get it fresh
                    IWebElement baseTable = EAM.WFDashboard.WFDashboardTable;

                    //Look for a next page link.  We will set 'last page of records' here also.
                    thisTP.LoadNextPageLink(baseTable);

                    //Load the page data off the application.   
                    //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                    thisTP.LoadPageTable(baseTable, "td", "th");

                    int iTableCounter = 0;
                    //                string expectedTableCheckboxValue = "";
                    //for each row in the Gherkin table, start flipping through all the rows in the page data.
                    foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                    {
                        //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                        //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                        if (GherkinTableRow == null)
                        {
                            break;
                        }

                        //If this Gherkin table row is not yet matched, proceed.
                        if (GherkinTableRow.RowIsMatched == false)
                        {
                            //Convert the row to an array so we can do an element by element match.
                            string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                            //For each row in the page data
                            foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                            {
                                //Convert page data to array elements
                                //Only work with the loaded element rows.  The first unloaded one will be null.
                                if (ApplicationRow == null)
                                {
                                    break;
                                }

                                //Convert the page row to array so we can pair up by elements.
                                string[] AppTableRow = ApplicationRow.Row.ToArray();
                                int iElementCounter = 0;
                                Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                                //In here as we pair up the data you will have custom matching.
                                //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                                foreach (string appTD in AppTableRow)
                                {
                                    //if (iElementCounter > 0 && TDA.RowIsData)
                                    if (ApplicationRow.RowIsData)
                                    {
                                        //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                        if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                        {
                                            bThisRowMatches = false;
                                        }
                                    }
                                    else
                                    {
                                        //Also fail row match if the element count of the page data row is 0
                                        if (iElementCounter > 0)
                                        {
                                            bThisRowMatches = false;
                                        }
                                    }
                                    iElementCounter++;
                                }
                                if (AppTableRow.Length == 0)
                                {
                                    //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                    bThisRowMatches = false;
                                }
                                //Instance of TableRow Class for reporting functions
                                var TableRow = new TMSString();
                                //If we get here and we still match, then the array elements were the same
                                if (bThisRowMatches)
                                {
                                    //report the success stuff.  Puts out the row data, etc.
                                    thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                                }
                            }
                        }
                        iTableCounter++;
                    }
                    //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                    Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                    if (fullMatching)
                    {
                        Console.WriteLine("All rows are matched, step completed as passed");
                    }
                    else
                    {
                        //Click next page link and start over.
                        if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                        {
                            thisTP.bNotAtLastPageOfRecords = true;
                            thisTP.NPL.Click();
                            tmsWait.Hard(2);
                        }
                    }

                    baseTable = EAM.AdministrationManagePlanSCCViewEdit.EditPlanTable;

                    //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                    //Time to boil it down and report which rows didn't get matched.
                    //Also to fail because we were planning to match the rows.
                    if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                    {
                        thisTP.ReportNotMatching(thisGT.GTable);
                    }
                }
            }
        }

        //Added by Swapna Chappidi on 03/10/2016
        [When(@"Workitem details page pagenumber ""(.*)"" is Clicked")]
        public void WhenWorkitemDetailsPagePagenumberIsClicked(int p0)
        {
            tmsWait.Hard(3);
            IWebElement baseTable = EAM.WFDashboard.WorkItemTable;
            ReadOnlyCollection<IWebElement> allRows = baseTable.FindElements(By.TagName("tr"));
            String classname = "pgr";

            foreach (IWebElement row in allRows)
            {
                if(row.GetAttribute("class") ==  classname)
                {
                    ReadOnlyCollection<IWebElement> cells = row.FindElements(By.TagName("td"));
                    foreach (IWebElement cell in cells)
                    {
                        IWebElement pageNum = cell.FindElement(By.TagName("a"));
                        if(pageNum.Text == p0.ToString())
                        {
                            pageNum.Click();
                        }

                        break;
                    }
                    break;
                }
            }
        }

        [Then(@"Verify Workitem details page pagennumber ""(.*)"" is displayed")]
        public void ThenVerifyWorkitemDetailsPagePagennumberIsDisplayed(int p0)
        {
            tmsWait.Hard(3);
            IWebElement baseTable = EAM.WFDashboard.WorkItemTable;
            ReadOnlyCollection<IWebElement> allRows = baseTable.FindElements(By.TagName("tr"));
            String classname = "pgr";

            foreach (IWebElement row in allRows)
            {
                if (row.GetAttribute("class") == classname)
                {
                    ReadOnlyCollection<IWebElement> cells = row.FindElements(By.TagName("td"));
                    foreach (IWebElement cell in cells)
                    {
                        IWebElement pageNum = cell.FindElement(By.TagName("span"));
                        Assert.AreEqual(pageNum.Text, p0.ToString());
                        break;

                    }

                }
            }
        }

        //Added by Swapna Chappidi on 03/14/2016
        [Then(@"PFWF Enrollment Reject Queue unlock icon is clicked for workitem ""(.*)""")]
        public void ThenPFWFEnrollmentRejectQueueUnlockIconIsClickedForWorkitem(string p0)
        {
            Browser.SwitchToChildWindow();           

            IWebElement baseTable = EAM.WorkFlowConfiguration.PFWFTable;

            IWebElement curRow = baseTable.FindElement(By.TagName("tr"));

            ReadOnlyCollection<IWebElement> cellscols = curRow.FindElements(By.TagName("td"));
            int counter = cellscols.Count;

            ReadOnlyCollection<IWebElement> cells = curRow.FindElements(By.TagName("a"));

            IWebElement lockUnlockBtn = Browser.Wd.FindElement(By.XPath("//td[8]"));
            lockUnlockBtn.Click();

         }


        [Then(@"Verify workitem ""(.*)"" is unlocked")]
        public void ThenVerifyWorkitemIsUnlocked(string p0)
        {
            EAM.WorkFlowConfiguration.PFWFBackButton.Click();
            EAM.WorkFlowConfiguration.EnrlRejectBar.Click();
            tmsWait.Hard(2);

            EAM.WorkFlowConfiguration.MessageIDTextbox.Clear();
            EAM.WorkFlowConfiguration.MessageIDTextbox.SendKeys(p0);
            IWebElement lockUnlockBtn = Browser.Wd.FindElement(By.XPath("//td[7]"));
            Assert.AreEqual(lockUnlockBtn.Text, " ");

        }

        [When(@"I have navigated to MainWindow")]
        public void WhenIHaveNavigatedToMainWindow()
        {
            Browser.SwitchToParentWindow();
        }

        [Then(@"Verify queue has item ""(.*)""")]
        public void ThenVerifyQueueHasItem(string p0)
        {
            tmsWait.Hard(2);
            EAM.WorkFlowConfiguration.MessageIDTextbox.Clear();
            EAM.WorkFlowConfiguration.MessageIDTextbox.SendKeys(p0);
        }

        [Then(@"Verify that WorkitemDetails ""(.*)"" is unlocked")]
        public void ThenVerifyThatWorkitemDetailsIsUnlocked(string p0)
        {
            IWebElement baseTable = EAM.WFDashboard.WorkItemTable;
            ReadOnlyCollection<IWebElement> allRows = baseTable.FindElements(By.TagName("tr"));

            foreach (IWebElement row in allRows)
            {

                if (row.Text.Contains(p0))
                {
                    IWebElement cell = row.FindElement(By.TagName("span"));
                    Assert.AreEqual(cell.Text, "");
                     break;
                }
            }
        }

        //Added on 03/16/2016
        [Then(@"Workitemdetails Workitem ""(.*)"" check box is checked")]

        public void ThenWorkitemdetailsWorkitemCheckBoxIsChecked(string p0)
        {
            IWebElement baseTable = EAM.WFDashboard.WorkItemTable;
            ReadOnlyCollection<IWebElement> allRows = baseTable.FindElements(By.TagName("tr"));

            foreach (IWebElement row in allRows)
            {

                if (row.Text.Contains(p0))
                {
                    IWebElement checkSel = row.FindElement(By.XPath("./td[1]"));
                    checkSel.Click();
                    break;
                }

            }
        }

        [Then(@"Workitemdetails ChangePriority button is clicked")]
        [When(@"Workitemdetails ChangePriority button is clicked")]
        public void ThenWorkitemdetailsChangePriorityButtonIsClicked()
        {
            EAM.WFDashboard.PriorityBtn.Click();
        }

        [Then(@"Workitemdetails ChangePriority new window is displayed")]
        public void ThenWorkitemdetailsChangePriorityNewWindowIsDisplayed()
        {
            Browser.Wd.SwitchTo().ActiveElement();            
            Assert.AreNotEqual(EAM.WFDashboard.PriorityModal, null);
        }

        [Then(@"Verify Workitem ""(.*)"" is displayed")]
        public void ThenVerifyWorkitemIsDisplayed(string p0)
        {
            IWebElement baseTable = EAM.WFDashboard.PriorityTableItems;
            ReadOnlyCollection<IWebElement> allRows = baseTable.FindElements(By.TagName("tr"));

            foreach (IWebElement row in allRows)
            {

                if (row.Text.Contains(p0))
                {
                    IWebElement workItem = row.FindElement(By.TagName("td"));
                    Assert.AreEqual(p0, workItem.Text);
                    break;
                }

            }
        }


        [When(@"ChangePriority ""(.*)"" button is clicked")]
        public void WhenChangePriorityButtonIsClicked(string p0)
        {
            switch (p0.ToLower())
            {
                case "cancel":
                    EAM.WFDashboard.PriorityModalcancelBtn.Click();
                    break;
                case "submit":
                    EAM.WFDashboard.PriorityModalSubmitBtn.Click();
                    break;
            }
            tmsWait.Hard(2);
        }

        [Then(@"Verify workitemdetails workitem ""(.*)"" check box is unchecked")]
        public void ThenVerifyWorkitemdetailsWorkitemCheckBoxIsUnchecked(string p0)
        {
            IWebElement baseTable = EAM.WFDashboard.WorkItemTable;
            ReadOnlyCollection<IWebElement> allRows = baseTable.FindElements(By.TagName("tr"));
            foreach (IWebElement row in allRows)
            {

                if (row.Text.Contains(p0))
                {
                    IWebElement checkSel = Browser.Wd.FindElement(By.XPath("//td[contains(.,p0)]/preceding-sibling::*[1]"));
                    Assert.IsFalse(checkSel.Selected);
                    break;
                }

            }
        }

        //Added by Swapna Chappidi on 03/17/2016
        [When(@"ChangePriority Priority is set to ""(.*)""")]
        public void WhenChangePriorityPriorityIsSetTo(string p0)
        {
            SelectElement select = new SelectElement(EAM.WFDashboard.NewPriorityDropDown);
            select.SelectByText(p0);
            tmsWait.Hard(2);
        }

        [When(@"ChangePriority Priority for Workitem ""(.*)"" is set to ""(.*)""")]
        public void WhenChangePriorityPriorityForWorkitemIsSetTo(string p0, string p1)
        {
            IWebElement baseTable = EAM.WFDashboard.WorkItemTable;
            ReadOnlyCollection<IWebElement> allRows = baseTable.FindElements(By.TagName("tr"));

            foreach (IWebElement row in allRows)
            {
                if (row.Text.Contains(p0))
                {
                    SelectElement select = new SelectElement(EAM.WFDashboard.NewPriorityDropDown);
                    select.SelectByText(p1);
                    break;
                }

            }
        }


        [Then(@"Verify workitemdetails workitem ""(.*)"" Priority ""(.*)"" is displayed")]
        public void ThenVerifyWorkitemdetailsWorkitemPriorityIsDisplayed(string p0, string p1)
        {
            IWebElement baseTable = EAM.WFDashboard.WorkItemTable;
            ReadOnlyCollection<IWebElement> allRows = baseTable.FindElements(By.TagName("tr"));
            foreach (IWebElement row in allRows)
            {
                if (row.Text.Contains(p0))
                {
                    IWebElement priority = row.FindElement(By.XPath("./td[3]"));
                    Assert.AreEqual(priority.Text, p1);
                    break;
                }
            }
        }


        [Then(@"Verify the dropdown has ""(.*)"", ""(.*)"" and ""(.*)""")]
        public void ThenVerifyTheDropdownHasAnd(string p0, string p1, string p2)
        {
            string[] expectedPriorities = { p0, p1, p2 };
            ReadOnlyCollection<IWebElement> allOptions =
                EAM.WFDashboard.NewPriorityDropDown.FindElements(By.TagName("option"));
            for(int i=0; i<allOptions.Count;i++)
            {
                Assert.AreEqual(expectedPriorities[i],allOptions[i].Text);
            }

        }

        [Then(@"PFWF Change priority button for ""(.*)"" is clicked")]
        public void ThenPFWFChangePriorityButtonForIsClicked(string p0)
        {
            Browser.Wd.SwitchTo().ActiveElement();

            IWebElement baseTable = EAM.WorkFlowConfiguration.PFWFTable;

            IWebElement curRow = baseTable.FindElement(By.TagName("tr"));
            curRow.Click();
            EAM.WorkFlowConfiguration.PFWFChangePriorityBtn.Click();

            Browser.Wd.SwitchTo().ActiveElement();
           // Assert.AreEqual(EAM.WorkFlowConfiguration.PFWFPriorityModal.Text, "Change priority");
        }

        [Then(@"PFWF Change priority is set to ""(.*)""")]
        public void ThenPFWFChangePriorityIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            Browser.Wd.SwitchTo().ActiveElement();
            IWebElement priority = EAM.WorkFlowConfiguration.PFWFSetPriority;
            priority.Click();
            priority.Clear();
            priority.SendKeys(p0);
        }

        [When(@"PFWF Change Priority save button is clicked")]
        public void WhenPFWFChangePrioritySaveButtonIsClicked()
        {
            EAM.WorkFlowConfiguration.PFWFSavePriority.Click();
        }

        [Then(@"Verify PFWF Priority ""(.*)"" for workitem ""(.*)"" is displayed")]
        public void ThenVerifyPFWFPriorityForWorkitemIsDisplayed(string p0, string p1)
        {
            EAM.WorkFlowConfiguration.PFWFBackButton.Click();
            EAM.WorkFlowConfiguration.EnrlRejectBar.Click();
            tmsWait.Hard(2);

            EAM.WorkFlowConfiguration.MessageIDTextbox.Clear();
            EAM.WorkFlowConfiguration.MessageIDTextbox.SendKeys(p1);
            IWebElement priorityLabel = Browser.Wd.FindElement(By.XPath("//td[2]"));
            Assert.AreEqual(priorityLabel.Text, p0);
        }

        //Aded by Swapna on 03/18/2016
        [When(@"I switch  back to the main window")]
        public void WhenISwitchBackToTheMainWindow()
        {
            Browser.SwitchToParentWindow();
        }

        [When(@"Switch back to Child Window")]
        public void WhenSwitchBackToChildWindow()
        {
            Browser.SwitchToChildWindow();
        }


        [Then(@"Verify ""(.*)"" has description ""(.*)""")]
        public void ThenVerifyHasDescription(string p0, string p1)
        {
            IWebElement flagRow = EAM.WFDashboard.WorkItemPageFlagsRow;
            ReadOnlyCollection<IWebElement> allImgs = flagRow.FindElements(By.TagName("img"));

            string src = "";

            foreach (IWebElement img in allImgs)
            {
                src = img.GetAttribute("src");
                if(src.Contains(p0))
                {
                    Assert.AreEqual(img.Text, p1);
                }

                break;
            }
        }

        [Then(@"Verify Red flag for item having status ""(.*)"" is displayed")]
        public void ThenVerifyRedFlagForItemHavingStatusIsDisplayed(string p0)
        {
            IWebElement baseTable = EAM.WFDashboard.WorkItemTable;
            ReadOnlyCollection<IWebElement> allRows = baseTable.FindElements(By.TagName("tr"));

            foreach (IWebElement row in allRows)
            {
                if (row.FindElements(By.TagName("th")).Count == 0)
                {
                    IWebElement status = row.FindElement(By.XPath("./td[7]"));

                    if (status.Text.Equals(p0))
                    {
                        IWebElement cell = row.FindElement(By.XPath("./td[8]"));
                        IWebElement imageCol = row.FindElement(By.TagName("img"));
                        string src = imageCol.GetAttribute("src");
                        Assert.IsTrue(src.Contains("flagRed"));
                        break;
                    }
                }
            }
        }

        [Then(@"Verify Green flag for item having status ""(.*)"" is displayed")]
        public void ThenVerifyGreenFlagForItemHavingStatusIsDisplayed(string p0)
        {
            IWebElement baseTable = EAM.WFDashboard.WorkItemTable;
            ReadOnlyCollection<IWebElement> allRows = baseTable.FindElements(By.TagName("tr"));

            foreach (IWebElement row in allRows)
            {
                if (row.FindElements(By.TagName("td")).Count == 10)
                {
                    IWebElement status = row.FindElement(By.XPath("./td[7]"));

                    if (status.Text.Equals(p0))
                    {
                        IWebElement cell = row.FindElement(By.XPath("./td[8]"));
                        IWebElement imageCol = row.FindElement(By.TagName("img"));
                        string src = imageCol.GetAttribute("src");
                        Assert.IsTrue(src.Contains("flagGreen"));
                        break;
                    }
                }
            }
        }

        [Then(@"verify unlock button is present for all locked workitems")]
        public void ThenVerifyUnlockButtonIsPresentForAllLockedWorkitems()
        {
            IWebElement baseTable = EAM.WFDashboard.WorkItemTable;
            ReadOnlyCollection<IWebElement> allRows = baseTable.FindElements(By.TagName("tr"));
            string lockSrc = "Styles/images/Lock.png";
            foreach (IWebElement row in allRows)
            {
                if (row.FindElements(By.TagName("td")).Count == 10)
                {
                    ReadOnlyCollection<IWebElement> cells = row.FindElements(By.TagName("td"));

                    IWebElement spantest = row.FindElement(By.XPath("./td[6]"));
                    if (spantest.Text != " ")
                    {
                        IWebElement lockunlock = row.FindElement(By.XPath("//span[contains(.,'soapui')]/preceding-sibling::*[1]"));
                        Assert.IsTrue(lockunlock.GetAttribute("src").Contains(lockSrc));                        
                    }                    
                }
            }
        }

        [Then(@"verify Send To Workflow button is disabled")]
        public void ThenVerifySendToWorkflowButtonIsDisabled()
        {
            IWebElement SendToWF = EAM.WFDashboard.SendToWFBtn;
            Assert.IsFalse(SendToWF.Enabled);
        }

        [When(@"Total number of record waiting to be sent to WF is ""(.*)""")]
        public void WhenTotalNumberOfRecordWaitingToBeSentToWFIs(int p0)
        {
            IWebElement actaulCnt = EAM.WFDashboard.StatisticsCount;
            Assert.AreEqual(p0.ToString(), actaulCnt.Text);
        }

        [Then(@"Verify PFWorkItem ""(.*)"" priority is changed to ""(.*)""")]
        public void ThenVerifyPFWorkItemPriorityIsChangedTo(string p0, string p1)
        {
            Browser.SwitchToChildWindow();

            IWebElement baseTable = EAM.WorkFlowConfiguration.PFWFTable;

            IWebElement curRow = baseTable.FindElement(By.TagName("tr"));

            curRow.Click();

            EAM.WorkFlowConfiguration.PFWFChangePriorityBtn.Click();


            
        }

        [Then(@"Verify ""(.*)"" has priority ""(.*)""")]
        public void ThenVerifyHasPriority(string p0, string p1)
        {

            EAM.WorkFlowConfiguration.MessageIDTextbox.Clear();
            EAM.WorkFlowConfiguration.MessageIDTextbox.SendKeys(p0);
            IWebElement Priority = Browser.Wd.FindElement(By.XPath("//td[3]"));
            Assert.AreEqual(Priority.Text, p1);
        }

        [Then(@"Goto the MainWindow")]
        public void ThenGotoTheMainWindow()
        {
            Browser.SwitchToParentWindow();
        }

        [Then(@"Verif the current row is selected")]
        public void ThenVerifTheCurrentRowIsSelected()
        {
            IWebElement baseTable = EAM.WorkFlowConfiguration.PFWFTable;
            IWebElement curRow = baseTable.FindElement(By.TagName("tr"));
            curRow.Click();
        }


    }
}


