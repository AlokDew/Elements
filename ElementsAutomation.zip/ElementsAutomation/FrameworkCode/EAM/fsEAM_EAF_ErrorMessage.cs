﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using TechTalk.SpecFlow;
using TMSoR1;
using TMSoR1.FrameworkCode;

namespace Daron0004
{
    [Binding]
    class fsEAM_EAF_ErrorMessage
    {
        public string setCheckboxTo;
        public bool tc90linkvisible;
        public string downloadPath = Path.Combine(Environment.ExpandEnvironmentVariables("%userprofile%"), "Downloads");

        [Given(@"Logging Application")]
        public void GivenLoggingApplication()
        {
            
        }


        [Then(@"Member View Edit Page HIC is set to ""(.*)""")]
        public void ThenMemberViewEditPageHICIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersViewEdit.MemberViewEditHIC.Clear();
            EAM.MembersViewEdit.MemberViewEditHIC.SendKeys(GeneratedData);

        }

        [Then(@"Member View Edit Page Save button is clicked")]
        public void ThenMemberViewEditPageSaveButtonIsClicked()
        {
            EAM.MembersViewEdit.MemberViewEditSaveButton.Click();
        }

        [Then(@"Verify Member View Edit Page Response message is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditPageResponseMessageIsSetTo(string p0)
        {
            String Actual = EAM.MembersViewEdit.MemberViewEditResponseMessage.Text;
            String expected = tmsCommon.GenerateData(p0);

            string fieldName = "Member Info Page Response Message";

            Assert.AreEqual(true, Actual.Equals(expected), "Field " + fieldName + " value is [" + Actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + Actual + "], expected [" + expected + "] - They are expected to match.");
        }

        [Then(@"Member View Edit Page ID History table tab is clicked")]
        public void ThenMemberViewEditPageIDHistoryTableTabIsClicked()
        {
            EAM.MembersViewEdit.MemberViewEditIDHistoryTab.Click();
        }

        [Then(@"Member View Edit Page Search for HIC is set to ""(.*)""")]
        public void ThenMemberViewEditPageSearchForHICIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersViewEdit.MemberViewEditSearchForHIC.Clear();
            EAM.MembersViewEdit.MemberViewEditSearchForHIC.SendKeys(GeneratedData);
        }

        [Then(@"Member View Edit Page Search for HIC Go button is clicked")]
        public void ThenMemberViewEditPageSearchForHICGoButtonIsClicked()
        {
            EAM.MembersViewEdit.MemberViewEditGoButton.Click();
        }

        [Then(@"Verify Member View Edit Page HIC is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditPageHICIsSetTo(string p0)
        {
            String Actual = EAM.MembersViewEdit.MemberViewEditHIC.GetAttribute("value");
            String expected = tmsCommon.GenerateData(p0);

            string fieldName = "Member Info Page HIC";

            Assert.AreEqual(true, Actual.Equals(expected), "Field " + fieldName + " value is [" + Actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + Actual + "], expected [" + expected + "] - They are expected to match.");
        }


        [Then(@"Member View Edit Page ID History table has row")]
        public void ThenMemberViewEditPageIDHistoryTableHasRow(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.MembersViewEdit.MemberViewEditIDHistoryTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Members View Edit Table has row: {0}", e.Message);
            }
        }


        [Then(@"Verify Transaction View Edit Page Search resuts has no row")]
        public void ThenVerifyTransactionViewEditPageSearchResutsHasNoRow()
        {
            tmsWait.Implicit(2);

            string fieldName = "Transaction Search Results";
            string expected = "Cannot find transaction for the provided criteria. Please try again.";
            string actual = EAM.TransactionsViewEdit.TransactionSearchResultStaticText.Text;
            Assert.AreEqual(true, expected.Equals(actual), "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }


        [When(@"Receipt Date Validation Check box is set to ""(.*)""")]
        public void WhenReceiptDateValidationCheckBoxIsSetTo(string p0)
        {

            string GenerateData = tmsCommon.GenerateData(p0);


            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("UnChecked"))
            {

                if (EAM.AdministrationPage.ReceiptDateValidation.Selected == true)
                {
                    EAM.AdministrationPage.ReceiptDateValidation.Click();
                }

            }
            else if (setCheckboxTo.Equals("checked"))
            {
                if (EAM.AdministrationPage.ReceiptDateValidation.Selected == false)
                {
                    EAM.AdministrationPage.ReceiptDateValidation.Click();
                }
            }
        }

        [When(@"Signature Date Validation Check box is set to ""(.*)""")]
        public void WhenSignatureDateValidationCheckBoxIsSetTo(string p0)
        {

            string GenerateData = tmsCommon.GenerateData(p0);


            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("UnChecked"))
            {

                if (EAM.AdministrationPage.SignatureDateValidation.Selected == true)
                {
                    EAM.AdministrationPage.SignatureDateValidation.Click();
                }

            }
            else if (setCheckboxTo.Equals("checked"))
            {
                if (EAM.AdministrationPage.SignatureDateValidation.Selected == false)
                {
                    EAM.AdministrationPage.SignatureDateValidation.Click();
                }
            }
        }

        [When(@"Election Type Validation Check box is set to ""(.*)""")]
        public void WhenElectionTypeValidationCheckBoxIsSetTo(string p0)
        {

            string GenerateData = tmsCommon.GenerateData(p0);


            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("UnChecked"))
            {

                if (EAM.AdministrationPage.ElectionTypeValidation.Selected == true)
                {
                    EAM.AdministrationPage.ElectionTypeValidation.Click();
                }

            }
            else if (setCheckboxTo.Equals("checked"))
            {
                if (EAM.AdministrationPage.ElectionTypeValidation.Selected == false)
                {
                    EAM.AdministrationPage.ElectionTypeValidation.Click();
                }
            }
        }


        [Then(@"Verify Member Info Page Spans tab Table has no ""(.*)""")]
        public void ThenVerifyMemberInfoPageSpansTabTableHasNo(string p0, Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.MemberInformation.SpansTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            if (bThisRowMatches)
                            {

                                IWebElement thisEditTD = ApplicationRow.Element[2];
                                Assert.AreNotEqual(p0, thisEditTD.Text, "Expected Span status Type is not found in this SPANs table");
                                Console.WriteLine("There is No " + p0 + " SPANs status Type found in this SPANs table");
                            }

                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }

        }



        [Then(@"Verify Members View Edit Page Transaction tab table has no TC (.*)")]
        public void ThenVerifyMembersViewEditPageTransactionTabTableHasNoTC(string p0, Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.MemberInformation.TransactionHistoryTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            if (bThisRowMatches)
                            {

                                IWebElement thisEditTD = ApplicationRow.Element[2];
                                Assert.AreNotEqual(p0, thisEditTD.Text, "Expected TC is not found in this Transaction table");
                                Console.WriteLine("There is No TC " + p0 + " found in this Transaction table");
                            }

                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                //baseTable = EAM.AdministrationStatusoverride.TransactionSearchTable;
                //    baseTable =EAM.MemberInformation.TransactionHistoryTable;


                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }

        }

        [Then(@"Verify Member view Edit Sales Date is set to""(.*)""")]
        public void ThenVerifyMemberViewEditSalesDateIsSetTo(string p0)
        {
            string fieldName = "Member View Edit Page Sales Date ";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MembersViewEdit.MemberViewEditSalesDate.GetAttribute("value");

            Assert.AreEqual(true, expected == actual, "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }


        [Then(@"Verify Member view Edit Sales Location is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditSalesLocationIsSetTo(string p0)
        {
            fw.ScrollWindowToViewElement(EAM.MembersViewEdit.MemberViewEditSalesLocation);
            string fieldName = "Member View Edit Page Sales Location";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MembersViewEdit.MemberViewEditSalesLocation.GetAttribute("value");

            Assert.AreEqual(true, expected == actual, "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }

        [Then(@"Verify Member Info page OEC Sales tab Sales Location is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageOECSalesTabSalesLocationIsSetTo(string p0)
        {
            string fieldName = "Member Info Page Sales Location";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MemberInformation.MemberInfoSalesLocation.GetAttribute("value");

            Assert.AreEqual(true, expected == actual, "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }



        [Then(@"Member Info Page OEC Sales tab is Clicked")]
        public void ThenMemberInfoPageOECSalesTabIsClicked()
        {
            EAM.MemberInformation.OECSalesTab.Click();
        }


        [Then(@"Verify Member View Edit Page Primary Rx Group is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditPagePrimaryRxGroupIsSetTo(string p0)
        {

            string fieldName = "Member View Edit Page Primary Rx Group ID";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MembersViewEdit.MemberViewEditPrimaryRxGrp.GetAttribute("value");

            Assert.AreEqual(true, expected == actual, "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }

        [Then(@"Verify Member View Edit Page Primary RxBIN is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditPagePrimaryRxBINIsSetTo(string p0)
        {
            string fieldName = "Member View Edit Page Primary Rx BIN ID";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MembersViewEdit.MemberViewEditPrimaryRxBIN.GetAttribute("value");

            Assert.AreEqual(true, expected == actual, "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }

        [Then(@"Verify Member View Edit Page Primary RxPCN is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditPagePrimaryRxPCNIsSetTo(string p0)
        {
            string fieldName = "Member View Edit Page Primary Rx PCN ID";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MembersViewEdit.MemberViewEditPrimaryRxPCN.GetAttribute("value");

            Assert.AreEqual(true, expected.Equals(actual), "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }

        [Then(@"Verify Member View Edit Page Secondary RxPCN is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditPageSecondaryRxPCNIsSetTo(string p0)
        {
            string fieldName = "Member View Edit Page Secondary Rx PCN ID";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MembersViewEdit.MemberViewEditSecondaryRxPCN.GetAttribute("value");

            Assert.AreEqual(true, expected.Equals(actual), "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");

        }


        [Then(@"Verify Member Info Page Primary Rx Group is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPagePrimaryRxGroupIsSetTo(string p0)
        {
            string fieldName = "Member Info Page Primary Rx Group ID";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MemberInformation.MemberInfoPrimaryRxGroup.GetAttribute("value");

            Assert.AreEqual(true, expected == actual, "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }

        [Then(@"Verify Member Info Page Primary RxID is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPagePrimaryRxIDIsSetTo(string p0)
        {
            string fieldName = "Member Info Page Primary Rx ID";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MemberInformation.MemberInfoPrimaryRxID.GetAttribute("value");

            Assert.AreEqual(true, expected == actual, "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }

        [Then(@"Verify Member Info Page Primary RxBIN is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPagePrimaryRxBINIsSetTo(string p0)
        {
            string fieldName = "Member Info Page Primary Rx BIN ID";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MemberInformation.MemberInfoPrimaryRxBIN.GetAttribute("value");

            Assert.AreEqual(true, expected == actual, "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }

        [Then(@"Verify View Edit Member page Segment ID is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageSegmentIDIsSetTo(string p0)
        {
            string fieldName = "View Edit Member Page Sement ID";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MemberInformation.SegmentID.GetAttribute("value");

            Assert.AreEqual(true, expected == actual, "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }


        [Then(@"Verify Member Info Page Date of Death is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageDateOfDeathIsSetTo(string p0)
        {
            string fieldName = "Member Info Page DOD";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MemberInformation.MemberInfoDeathDate.GetAttribute("value");

            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [Then(@"Verify Member Info Page Termination Date is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageTerminationDateIsSetTo(string p0)
        {
            string fieldName = "Member Info Page Termination Date";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MemberInformation.MemberInfoTerminationDate.GetAttribute("value");

            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [Then(@"Verify Status Override link is not visible")]
        public void ThenVerifyStatusOverrideLinkIsNotVisible()
        {
            try
            {
                tc90linkvisible = EAM.AdministrationStatusoverride.StatusOverrideLink.Displayed;
            }
            catch (NoSuchElementException e)
            {

                fw.ConsoleReport("There is no Status Override link.");

            }
        }

        [Then(@"Verify TC(.*) link is not visible")]
        public void ThenVerifyTCLinkIsNotVisible(int p0)
        {

            try
            {
                tc90linkvisible = EAM.TC90.TC90link.Displayed;
            }
            catch (NoSuchElementException e)
            {

                fw.ConsoleReport("There is no TC 90 link.");

            }


        }

        [Then(@"Verify TC (.*) Drug Edit Transaction page is displayed")]
        public void ThenVerifyTCDrugEditTransactionPageIsDisplayed(String p0)
        {
            string fieldName = "TC90 Page";
            string expected = "POS Drug Edit";
            string actual = Browser.Wd.Title;

            Assert.AreEqual(true, expected.Equals(actual), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }

        [Then(@"Verify Manual Status Override page is displayed")]
        public void ThenVerifyManualStatusOverridePageIsDisplayed()
        {
            string fieldName = "Manual Status Override Page";
            string expected = "Manual Status Override";
            string actual = Browser.Wd.Title;

            Assert.AreEqual(true, expected.Equals(actual), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }

        [Then(@"Verify Status Override page is displayed")]
        public void ThenVerifyStatusOverridePageIsDisplayed()
        {
            string fieldName = "Status Override Page";
            string expected = "Status Override";
            string actual = Browser.Wd.Title;

            Assert.AreEqual(true, expected.Equals(actual), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }



        [Then(@"Administration Edit User Update user button is clicked")]
        public void ThenAdministrationEditUserUpdateUserButtonIsClicked()
        {
            EAM.UserAdministrationCrudUser.UpdateUserButton.Click();
            tmsWait.Hard(4);
        }

        [Then(@"Search Add User page TMSWeb Administration role is selected")]
        public void ThenSearchAddUserPageTMSWebAdministrationRoleIsSelected()
        {
            IWebElement table1 = Browser.Wd.FindElement(By.Id("EditUserAssignedAppsGridView")); // you have the table
            IList<IWebElement> allElements1 = table1.FindElements(By.TagName("tr")); // you have all row that are visible
            int thisCount1 = allElements1.Count;
            IWebElement thisWebElement1 = null;
            foreach (IWebElement abc in allElements1)
            {
                thisWebElement1 = abc;
                if (abc.Text.Contains("TMSWeb Administration"))
                {
                    break;
                }
            }

            SelectElement selectrole = new SelectElement(Browser.Wd.FindElement(By.Id("EditUserAssignedAppsGridView_ctl02_ddlAccessLevel")));
            selectrole.SelectByText("Client Manager");
        }


        [Then(@"Administration Edit User Checkbox Enable for Admin and Active database row set Role as ""(.*)"" and set Permission as ""(.*)""")]
        public void ThenAdministrationEditUserCheckboxEnableForAdminAndActiveDatabaseRowSetRoleAsAndSetPermissionAs(string p0, string p1)
        {

            //string[] parts1 = mystr1.Split('_');
            //string thisPart1 = parts1[1];

            //string homePageCheckbox1 = "AssignedAppsGridView_" + thisPart1 + "_setAsDefault";
            //IWebElement thishomePageCheckbox1 = Browser.Wd.FindElement(By.Id(homePageCheckbox1));
            //thishomePageCheckbox1.Click();

            ////Selecting Active Databse
            //IWebElement table = Browser.Wd.FindElement(By.Id("AssignedAppsGridView")); // you have the table
            //IList<IWebElement> allElements = table.FindElements(By.TagName("tr")); // you have all row that are visible
            //int thisCount = allElements.Count;
            //IWebElement thisWebElement = null;
            //foreach (IWebElement abc in allElements)
            //{
            //    thisWebElement = abc;
            //    if (abc.Text.Contains(ConfigFile.Database))
            //    {
            //        break;
            //    }
            //}
            //string mystr = (thisWebElement.FindElement(By.CssSelector("input[type=checkbox]")).GetAttribute("id"));
            //IWebElement thisLineCheckbox = Browser.Wd.FindElement(By.Id(mystr));
            //thisLineCheckbox.Click();

            //string[] parts = mystr.Split('_');
            //string thisPart = parts[1];

            //string homePageCheckbox = "AssignedAppsGridView_" + thisPart + "_setAsDefault";
            //IWebElement thishomePageCheckbox = Browser.Wd.FindElement(By.Id(homePageCheckbox));
            //thishomePageCheckbox.Click();

            //string RoleId = "AssignedAppsGridView_" + thisPart + "_ddlAccessLevel";
            //IWebElement thisLineSelectRole = Browser.Wd.FindElement(By.Id(RoleId));
            //var mySelectDropdown = new SelectElement(thisLineSelectRole);
            //mySelectDropdown.SelectByText(p0);
            //string permissiondrop = "EditUserAssignedAppsGridView_ctl08_ucPermissionEditList_imgBtnOpen";
            //IWebElement dropdown = Browser.Wd.FindElement(By.Id(permissiondrop));
            //string TC90permission = "EditUserAssignedAppsGridView_ctl08_ucPermissionEditList_DDList_2";
            //IWebElement TC90 = Browser.Wd.FindElement(By.Id(TC90permission));

            //string statusOverridepermission = "EditUserAssignedAppsGridView_ctl08_ucPermissionEditList_DDList_1";
            //IWebElement statusOverride = Browser.Wd.FindElement(By.Id(statusOverridepermission));

            if (p1.Equals("TC90"))
            {
                EAM.UserAdministrationCrudUser.EditUserDropdown.Click();
                EAM.UserAdministrationCrudUser.EditUserTC90.Click();

                EAM.UserAdministrationCrudUser.EditUserCrossButton.Click();
            }
            else if (p1.Equals("Status Override"))
            {
                EAM.UserAdministrationCrudUser.EditUserDropdown.Click();
                bool tc90select = EAM.UserAdministrationCrudUser.EditUserTC90.Selected;
                bool statusoverrideselect = EAM.UserAdministrationCrudUser.EditUserStatusOverride.Selected;

                if (tc90select)
                {

                    EAM.UserAdministrationCrudUser.EditUserTC90.Click();
                    EAM.UserAdministrationCrudUser.EditUserCrossButton.Click(); ;
                }
                if (!statusoverrideselect)
                {
                    EAM.UserAdministrationCrudUser.EditUserStatusOverride.Click();
                    EAM.UserAdministrationCrudUser.EditUserCrossButton.Click();
                }

            }

            else if (p1.Equals("Status Override and TC90"))
            {

                EAM.UserAdministrationCrudUser.EditUserDropdown.Click();
                bool tc90select = EAM.UserAdministrationCrudUser.EditUserTC90.Selected;
                bool statusoverrideselect = EAM.UserAdministrationCrudUser.EditUserStatusOverride.Selected;

                if (!tc90select)
                {

                    EAM.UserAdministrationCrudUser.EditUserTC90.Click();
                    EAM.UserAdministrationCrudUser.EditUserCrossButton.Click(); ;
                }
                if (!statusoverrideselect)
                {
                    EAM.UserAdministrationCrudUser.EditUserStatusOverride.Click();
                    EAM.UserAdministrationCrudUser.EditUserCrossButton.Click();
                }
            }


            else if (p1.Equals("None"))
            {
                EAM.UserAdministrationCrudUser.EditUserDropdown.Click();
                bool tc90select = EAM.UserAdministrationCrudUser.EditUserTC90.Selected;
                bool statusoverrideselect = EAM.UserAdministrationCrudUser.EditUserStatusOverride.Selected;
                if (tc90select)
                {

                    EAM.UserAdministrationCrudUser.EditUserTC90.Click();
                    EAM.UserAdministrationCrudUser.EditUserCrossButton.Click(); ;
                }
                if (statusoverrideselect)
                {
                    EAM.UserAdministrationCrudUser.EditUserStatusOverride.Click();
                    EAM.UserAdministrationCrudUser.EditUserCrossButton.Click();
                }
                tmsWait.Hard(4);

            }

            else
            {
                Console.WriteLine("This is not valid input");
            }
        }


        [Given(@"Administration New User Checkbox Enable for Admin and Active database row set Role as ""(.*)"" and set Permission as ""(.*)""")]
        public void GivenAdministrationNewUserCheckboxEnableForAdminAndActiveDatabaseRowSetRoleAsAndSetPermissionAs(string p0, string p1)
        {

            //IWebElement table1 = Browser.Wd.FindElement(By.Id("AssignedAppsGridView")); // you have the table
            //IList<IWebElement> allElements1 = table1.FindElements(By.TagName("tr")); // you have all row that are visible
            //int thisCount1 = allElements1.Count;
            //IWebElement thisWebElement1 = null;
            //foreach (IWebElement abc in allElements1)
            //{
            //    thisWebElement1 = abc;
            //    if (abc.Text.Contains("TMSWeb Administration"))
            //    {
            //        break;
            //    }
            //}
            //string tmsadminEnable = (thisWebElement1.FindElement(By.CssSelector("input[type=checkbox]")).GetAttribute("id"));
            //IWebElement tmsadminEnableCheck = Browser.Wd.FindElement(By.Id(tmsadminEnable));
            //tmsadminEnableCheck.Click();

            //string tmsadminHome = (thisWebElement1.FindElement(By.CssSelector("input[type=radio]")).GetAttribute("id"));
            //IWebElement tmsadminHomeradio = Browser.Wd.FindElement(By.Id(tmsadminHome));
            //tmsadminHomeradio.Click();

            //SelectElement selectrole = new SelectElement(Browser.Wd.FindElement(By.Id("AssignedAppsGridView_ctl02_ddlAccessLevel")));
            //selectrole.SelectByText("Client Manager");

            //string[] parts1 = mystr1.Split('_');
            //string thisPart1 = parts1[1];

            //string homePageCheckbox1 = "AssignedAppsGridView_ctl02_setAsDefault";
            //IWebElement thishomePageCheckbox1 = Browser.Wd.FindElement(By.Id(homePageCheckbox1));
            //thishomePageCheckbox1.Click();

            //Selecting Active Databse
            IWebElement table2 = Browser.Wd.FindElement(By.Id("AssignedAppsGridView")); // you have the table
            IList<IWebElement> allElements2 = table2.FindElements(By.TagName("tr")); // you have all row that are visible
            int thisCount = allElements2.Count;
            IWebElement thisWebElement2 = null;
            foreach (IWebElement abc in allElements2)
            {
                thisWebElement2 = abc;
                if (abc.Text.Contains(ConfigFile.Database))
                {
                    break;
                }
            }
            string mystr = (thisWebElement2.FindElement(By.CssSelector("input[type=checkbox]")).GetAttribute("id"));
            IWebElement thisLineCheckbox = Browser.Wd.FindElement(By.Id(mystr));
            thisLineCheckbox.Click();

            string[] parts = mystr.Split('_');
            string thisPart = parts[1];

            //string homePageCheckbox = "AssignedAppsGridView_" + thisPart + "_setAsDefault";
            //IWebElement thishomePageCheckbox = Browser.Wd.FindElement(By.Id(homePageCheckbox));
            //thishomePageCheckbox.Click();

            string RoleId = "AssignedAppsGridView_" + thisPart + "_ddlAccessLevel";
            IWebElement thisLineSelectRole = Browser.Wd.FindElement(By.Id(RoleId));
            var mySelectDropdown = new SelectElement(thisLineSelectRole);
            mySelectDropdown.SelectByText(p0);

            if (p1.Equals("TC90"))
            {

                string permissiondrop = "AssignedAppsGridView_" + thisPart + "_ucPermissionAddList_imgBtnOpen";
                IWebElement thisLinedropPermission = Browser.Wd.FindElement(By.Id(permissiondrop));
                thisLinedropPermission.Click();

                string permission = "AssignedAppsGridView_" + thisPart + "_ucPermissionAddList_DDList_2";
                IWebElement thisLineSelectPermission = Browser.Wd.FindElement(By.Id(permission));
                thisLineSelectPermission.Click();

            }
            else if (p1.Equals("Status Override"))
            {

                string permissiondrop = "AssignedAppsGridView_" + thisPart + "_ucPermissionAddList_imgBtnOpen";
                IWebElement thisLinedropPermission = Browser.Wd.FindElement(By.Id(permissiondrop));
                thisLinedropPermission.Click();

                string permission = "AssignedAppsGridView_" + thisPart + "_ucPermissionAddList_DDList_1";
                IWebElement thisLineSelectPermission = Browser.Wd.FindElement(By.Id(permission));
                thisLineSelectPermission.Click();

            }

            else if (p1.Equals("None"))
            {

                tmsWait.Hard(4);

            }

            else
            {
                Console.WriteLine("This is not valid input");
            }
        }


        [Given(@"Administration New User Checkbox Enable for active database row set Role as ""(.*)"" and set Permission as ""(.*)""")]
        public void GivenAdministrationNewUserCheckboxEnableForActiveDatabaseRowSetRoleasAndSetPermissionas(string p0, string p1)
        {

            IWebElement table = Browser.Wd.FindElement(By.Id("AssignedAppsGridView")); // you have the table
            IList<IWebElement> allElements = table.FindElements(By.TagName("tr")); // you have all row that are visible
            int thisCount = allElements.Count;
            IWebElement thisWebElement = null;
            foreach (IWebElement abc in allElements)
            {
                thisWebElement = abc;
                if (abc.Text.Contains(ConfigFile.Database))
                {
                    break;
                }
            }
            string mystr = (thisWebElement.FindElement(By.CssSelector("input[type=checkbox]")).GetAttribute("id"));
            IWebElement thisLineCheckbox = Browser.Wd.FindElement(By.Id(mystr));
            thisLineCheckbox.Click();

            string[] parts = mystr.Split('_');
            string thisPart = parts[1];

            string homePageCheckbox = "AssignedAppsGridView_" + thisPart + "_setAsDefault";
            IWebElement thishomePageCheckbox = Browser.Wd.FindElement(By.Id(homePageCheckbox));
            thishomePageCheckbox.Click();

            string RoleId = "AssignedAppsGridView_" + thisPart + "_ddlAccessLevel";
            IWebElement thisLineSelectRole = Browser.Wd.FindElement(By.Id(RoleId));
            var mySelectDropdown = new SelectElement(thisLineSelectRole);
            mySelectDropdown.SelectByText(p0);

            if (p1.Equals("TC90"))
            {

                string permissiondrop = "AssignedAppsGridView_" + thisPart + "_ucPermissionAddList_imgBtnOpen";
                IWebElement thisLinedropPermission = Browser.Wd.FindElement(By.Id(permissiondrop));
                thisLinedropPermission.Click();

                string permission = "AssignedAppsGridView_" + thisPart + "_ucPermissionAddList_DDList_1";
                IWebElement thisLineSelectPermission = Browser.Wd.FindElement(By.Id(permission));
                thisLineSelectPermission.Click();

            }

            else if (p1.Equals("None"))
            {


                tmsWait.Hard(4);


            }

            else
            {
                Console.WriteLine("This is not valid input");
            }
        }

        [Then(@"Transactions Tab Add New Transaction link is clicked")]
        [When(@"Transactions Tab Add New Transaction link is clicked")]
        public void ThenTransactionsTabAddNewTransactionLinkIsClicked()
        {
            EAM.MemberInformation.AddNewTransactionLink.Click();
        }
        [When(@"Transactions New Action is set to ""(.*)""")]
        public void WhenTransactionsNewActionIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            IWebElement action = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddAction_62"));
            new SelectElement(action).SelectByText(p0);
            tmsWait.Hard(2);
        }

        [When(@"Transactions New (.*) Effective Date is set to ""(.*)""")]
        public void WhenTransactionsNewEffectiveDateIsSetTo(int p0, string p1)
        {

            string GeneratedData = tmsCommon.GenerateData(p1);
            GeneratedData = GeneratedData.Replace("/", "");
            EAM.TransactionsNew.EffectiveDate.Clear();

            EAM.TransactionsNew.EffectiveDate.Click();
            EAM.TransactionsNew.EffectiveDate.SendKeys(Keys.Home);
            EAM.TransactionsNew.EffectiveDate.SendKeys(GeneratedData);
        }

        [When(@"Transactions New (.*) Signature Date is set to ""(.*)""")]
        public void WhenTransactionsNewSignatureDateIsSetTo(int p0, string p1)
        {
            string GeneratedData = tmsCommon.GenerateData(p1);
            GeneratedData = GeneratedData.Replace("/", "");
            EAM.TransactionsNew.SignatureDate.Clear();

            EAM.TransactionsNew.SignatureDate.Click();
            EAM.TransactionsNew.SignatureDate.SendKeys(Keys.Home);
            EAM.TransactionsNew.SignatureDate.SendKeys(GeneratedData);
        }

        [Then(@"Verify searched username is Edited")]
        public void ThenVerifySearchedUsernameIsEdited(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.UserAdministrationSearchUser.UserSearchTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            if (bThisRowMatches)
                            {
                                IWebElement thisEditTD = ApplicationRow.Element[0];
                                IWebElement thisEditLink = thisEditTD.FindElement(By.TagName("img"));
                                thisEditLink.Click();
                                tmsWait.Hard(2);

                            }

                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                //baseTable = EAM.AdministrationStatusoverride.TransactionSearchTable;
                //    baseTable =EAM.MemberInformation.TransactionHistoryTable;


                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }


        [Then(@"Verify searched username is displayed")]
        public void ThenVerifySearchedUsernameIsDisplayed(Table table)
        {


            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.UserAdministrationSearchUser.UserSearchTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");
                //               Boolean bTransStatusMatching = false;
                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {

                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //if(AppTableRow.Equals(GherkinTableArray[iElementCounter])
                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (appTD.Equals("Canceled"))
                                //{

                                //    Assert.IsTrue(appTD.Equals("Canceled"));
                                //    bTransStatusMatching = true;
                                //    //Console.WriteLine("TC 61 status is found as Canceled");
                                //}

                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //    //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }


                        }

                    }
                    iTableCounter++;
                    //if (bTransStatusMatching)
                    //{
                    //    Console.WriteLine("Transaction status is updated to Canceled in Transaction History");
                    //}
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                //if (bTransStatusMatching)
                //{
                //    Console.WriteLine("Member Info page Transaction status is updated to Canceled in Transaction History table");
                //}

                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.UserAdministrationSearchUser.UserSearchTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }


        }


        [Given(@"Search Add User page Add User dialog User role Permissions drop down displayed Multiple choices")]
        public void GivenSearchAddUserPageAddUserDialogUserRolePermissionsDropDownDisplayedMultipleChoices()
        {
            tmsWait.Hard(3);
            EAM.UserAdministrationCrudUser.Permissionsdropdown.Click();


            IWebElement table = Browser.Wd.FindElement(By.Id("AssignedAppsGridView_ctl08_ucPermissionAddList_divCheckBoxList")); // you have the table
            IList<IWebElement> allElements = table.FindElements(By.TagName("tr")); // you have all row that are visible
            int thisCount = allElements.Count;

            Console.WriteLine("List of Options are in Permission Drop down list");

            foreach (IWebElement abc in allElements)
            {

                Console.WriteLine(abc.Text);

            }


            tmsWait.Hard(3);
            EAM.UserAdministrationCrudUser.PermissionCrossButton.Click();

        }

        [Given(@"Search Add User page Add User dialog User role None Permission is disabled")]
        public void GivenSearchAddUserPageAddUserDialogUserRoleNonePermissionIsDisabled()
        {
            string fieldName = "Permission Drop down None option";

            bool noneoption = EAM.UserAdministrationCrudUser.PermissionNonecheckbox.Enabled;


            Assert.AreEqual(false, noneoption, "Field " + fieldName + " value is [" + noneoption + "], expected [" + "false" + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + noneoption + "], expected [" + "false" + "] - They are expected to match.");
        }


        [Given(@"Search Add User page Add User dialog Manager role Permissions drop down displayed Multiple choices")]
        public void GivenSearchAddUserPageAddUserDialogManagerRolePermissionsDropDownDisplayedMultipleChoices()
        {
            tmsWait.Hard(3);
            EAM.UserAdministrationCrudUser.Permissionsdropdown.Click();


            IWebElement table = Browser.Wd.FindElement(By.Id("AssignedAppsGridView_ctl08_ucPermissionAddList_DDList")); // you have the table
            IList<IWebElement> allElements = table.FindElements(By.TagName("tr")); // you have all row that are visible
            int thisCount = allElements.Count;

            Console.WriteLine("List of Options are in Permission Drop down list");

            foreach (IWebElement abc in allElements)
            {

                Console.WriteLine(abc.Text);

            }
            EAM.UserAdministrationCrudUser.PermissionCrossButton.Click();
        }

        [Given(@"Search Add User page Add User dialog Manager role None Permission is disabled")]
        public void GivenSearchAddUserPageAddUserDialogManagerRoleNonePermissionIsDisabled()
        {
            string fieldName = "Permission Drop down None option";

            bool noneoption = EAM.UserAdministrationCrudUser.PermissionNonecheckbox.Enabled;


            Assert.AreEqual(false, noneoption, "Field " + fieldName + " value is [" + noneoption + "], expected [" + "false" + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + noneoption + "], expected [" + "false" + "] - They are expected to match.");
        }

        [When(@"Search and Add User page Searchbutton is clicked")]
        [Given(@"Search and Add User page Searchbutton is clicked")]
        public void GivenSearchAndAddUserPageSearchbuttonIsClicked()
        {
            EAM.UserAdministrationCrudUser.Searchbutton.Click();
        }

        [When(@"Search and Add User page Username is set to ""(.*)""")]
        [Given(@"Search and Add User page Username is set to ""(.*)""")]
        public void GivenSearchAndAddUserPageUsernameIsSetTo(string p0)
        {

            string GeneratedUserID = tmsCommon.GenerateData(p0);
            EAM.UserAdministrationCrudUser.Username.SendKeys(GeneratedUserID);
        }

        [When(@"Transactions New (.*) Receipt Date is set to ""(.*)""")]
        public void WhenTransactionsNewReceiptDateIsSetTo(int p0, string p1)
        {
            string GeneratedData = tmsCommon.GenerateData(p1);
            //  GeneratedData = GeneratedData.Replace("/", "");
            EAM.TransactionsNew.ReceiptDate.Clear();

            //EAM.TransactionsNew.ReceiptDate.Click();
            // EAM.TransactionsNew.ReceiptDate.SendKeys(Keys.Home);
            EAM.TransactionsNew.ReceiptDate.SendKeys(GeneratedData);
        }

        [Given(@"Administration New User Page Add User Role is set to ""(.*)""")]
        public void GivenAdministrationNewUserPageAddUserRoleIsSetTo(string p0)
        {

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Role')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + p0 + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                tmsWait.Hard(3);
            }
            else
            {
                IWebElement userroles = Browser.Wd.FindElement(By.XPath("//select[@test-id='AddUser-Select-Role']"));
                SelectElement urole = new SelectElement(userroles);
                urole.SelectByText(p0);
            }
         
        }


        [Given(@"Administration New User page EAM Roles as ""(.*)"" Default Application as ""(.*)"" Checkbox Enable for ""(.*)""")]
        public void GivenAdministrationNewUserPageEAMRolesAsDefaultApplicationAsCheckboxEnableFor(string p0, string p1, string p2)
        {
            IWebElement userroles = Browser.Wd.FindElement(By.XPath("//select[@test-id='Adduser-Select-EAMRoles']"));
            SelectElement urole = new SelectElement(userroles);
            urole.SelectByText(p0);
            tmsWait.Hard(2);
            IWebElement DefaultAp = Browser.Wd.FindElement(By.XPath("//select[@test-id='AddUser-Select-DefaultApplicationRequired']"));
            SelectElement app = new SelectElement(DefaultAp);
            app.SelectByText(p1);
            tmsWait.Hard(2);
            switch (p2)
            {
                case "TC90 App":
                    IWebElement checkbox = Browser.Wd.FindElement(By.CssSelector("[test-id='AddUser-CheckBox-TC90App']"));
                    fw.ExecuteJavascript(checkbox);
                    break;
                case "Status Override":
                    IWebElement checkboxs = Browser.Wd.FindElement(By.CssSelector("[test-id='AddUser-CheckBox-StatusOverride']"));
                    fw.ExecuteJavascript(checkboxs);
                    break;
            }

            tmsWait.Hard(1);

        }


        [Given(@"Framework page Administration page User Role ""(.*)"" EAM Role ""(.*)"" Default Application ""(.*)""")]
        public void GivenFrameworkPageAdministrationPageUserRoleEAMRoleDefaultApplication(string p0, string p1, string p2)
        {
            IWebElement userroles = Browser.Wd.FindElement(By.XPath("//select[@test-id='AddUser-Select-Role']"));
            SelectElement urole = new SelectElement(userroles);
            urole.SelectByText(p0);
            tmsWait.Hard(2);
            IWebElement eamrole = Browser.Wd.FindElement(By.XPath("//select[@test-id='Adduser-Select-EAMRoles']"));
            SelectElement eam = new SelectElement(eamrole);
            eam.SelectByText(p1);
            tmsWait.Hard(2);
            IWebElement DefaultAp = Browser.Wd.FindElement(By.XPath("//select[@test-id='AddUser-Select-DefaultApplicationRequired']"));
            SelectElement app = new SelectElement(DefaultAp);
            app.SelectByText(p2);
            tmsWait.Hard(2);
        }


        [Given(@"Administration New User Checkbox Enable for active database row set role to ""(.*)"" and set permission to ""(.*)""")]
        public void GivenAdministrationNewUserCheckboxEnableForActiveDatabaseRowSetRoleToAndSetPermissionTo(string p0, string p1)
        {
            IWebElement table = Browser.Wd.FindElement(By.Id("AssignedAppsGridView")); // you have the table
            IList<IWebElement> allElements = table.FindElements(By.TagName("tr")); // you have all row that are visible
            int thisCount = allElements.Count;
            IWebElement thisWebElement = null;
            string TC90Position = "1";
            switch (p0.ToLower())
            {
                case "user": TC90Position = "2"; break;
                case "manager": TC90Position = "1"; break;

            }
            foreach (IWebElement abc in allElements)
            {
                thisWebElement = abc;
                if (abc.Text.Contains(ConfigFile.Database))
                {
                    break;
                }
            }
            string mystr = (thisWebElement.FindElement(By.CssSelector("input[type=checkbox]")).GetAttribute("id"));
            IWebElement thisLineCheckbox = Browser.Wd.FindElement(By.Id(mystr));
            thisLineCheckbox.Click();

            string[] parts = mystr.Split('_');
            string thisPart = parts[2];

            string homePageCheckbox = "AssignedAppsGridView_setAsDefault_" + thisPart;
            IWebElement thishomePageCheckbox = Browser.Wd.FindElement(By.Id(homePageCheckbox));
            thishomePageCheckbox.Click();

            //Looks like this changed, need to grab that 4 off the end now.
            //"AssignedAppsGridView_ddlAccessLevel_4"
            string RoleId = "AssignedAppsGridView_ddlAccessLevel_" + thisPart;
            IWebElement thisLineSelectRole = Browser.Wd.FindElement(By.Id(RoleId));
            var mySelectDropdown = new SelectElement(thisLineSelectRole);
            mySelectDropdown.SelectByText(p0);

            if (p1.Equals("Status Override"))
            {
                string permissiondrop = "AssignedAppsGridView_ucPermissionAddList_" + thisPart + "_imgBtnOpen_" + thisPart;
                IWebElement thisLinedropPermission = Browser.Wd.FindElement(By.Id(permissiondrop));
                thisLinedropPermission.Click();

                string permission = "AssignedAppsGridView_ucPermissionAddList_" + thisPart + "_DDList_" + thisPart + "_1_" + thisPart;
                IWebElement thisLineSelectPermission = Browser.Wd.FindElement(By.Id(permission));
                thisLineSelectPermission.Click();
            }
            else if (p1.Equals("TC90"))
            {

                string permissiondrop = "AssignedAppsGridView_ucPermissionAddList_" + thisPart + "_imgBtnOpen_" + thisPart;
                IWebElement thisLinedropPermission = Browser.Wd.FindElement(By.Id(permissiondrop));
                thisLinedropPermission.Click();

                IList<IWebElement> myLabels = Browser.Wd.FindElements(By.TagName("label"));
                foreach (IWebElement thisLabel in myLabels)
                {
                    if (thisLabel.Text == "TC90")
                    {
                        thisLabel.Click();
                    }
                }
            }
            else if (p1.Equals("Status Override and TC90"))
            {
                string permissiondrop = "AssignedAppsGridView_ucPermissionAddList_" + thisPart + "_imgBtnOpen_" + thisPart;
                IWebElement thisLinedropPermission = Browser.Wd.FindElement(By.Id(permissiondrop));
                thisLinedropPermission.Click();

                IList<IWebElement> myLabels = Browser.Wd.FindElements(By.TagName("label"));
                foreach (IWebElement thisLabel in myLabels)
                {
                    if (thisLabel.Text == "TC90" || thisLabel.Text == "Status Override")
                    {
                        thisLabel.Click();
                    }
                }

                tmsWait.Hard(4);

            }
            else if (p1.Equals("None"))
            {

                tmsWait.Hard(4);
                // string permissiondrop = "AssignedAppsGridView_" + thisPart + "_ucPermissionAddList_imgBtnOpen";
                //IWebElement thisLinedropPermission = Browser.Wd.FindElement(By.Id(permissiondrop));
                //thisLinedropPermission.Click();

                //string crossbutton = "AssignedAppsGridView_" + thisPart + "_ucPermissionAddList_imgBtnClose";
                //IWebElement thisLineCrossbutton = Browser.Wd.FindElement(By.Id(crossbutton));
                //thisLineCrossbutton.Click();

            }

            else
            {
                Console.WriteLine("This is not valid input");
            }


            //var mySelectPerm = new SelectElement(thisLineSelectPermission);
            //mySelectPerm.c

            tmsWait.WaitForReadyStateComplete(30);
        }

        [Then(@"Verify Member Info Page Effctive Date is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageEffctiveDateIsSetTo(string p0)
        {
            string fieldName = "Member Info Page Effective Date";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MemberInformation.MemberInfoEffectiveDate.GetAttribute("value");

            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }


        [Then(@"Verify Member Info Page Primary RxPCN is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPagePrimaryRxPCNIsSetTo(string p0)
        {
            string fieldName = "Member Info Page Primary Rx PCN ID";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MemberInformation.MemberInfoPrimaryRxPCN.GetAttribute("value");

            Assert.AreEqual(true, expected.Equals(actual), "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }

        [Then(@"Verify Member Info Page Segment ID is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageSegmentIDIsSetTo(string p0)
        {
            string fieldName = "Segment ID  ";

            string expected = tmsCommon.GenerateData(p0);

            SelectElement s = new SelectElement(EAM.MemberInformation.SegmentID);
            String actual = s.SelectedOption.Text;

            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }

        [Then(@"Verify Member Info Page RX Billing tab Secondary RxPCN is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageRXBillingTabSecondaryRxPCNIsSetTo(string p0)
        {
            string fieldName = "Member Info Page Secondary Rx PCN ID";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MemberInformation.MemberInfoSecondaryRxPCN.GetAttribute("value");

            Assert.AreEqual(true, expected.Equals(actual), "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }

        [Then(@"Verify Member Info Page Contact tab Second Phone is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageContactTabSecondPhoneIsSetTo(string p0)
        {
            string fieldName = "Member Info Page Secondary Phone number";
            string expected = tmsCommon.GenerateData(p0);
            string entrystring = "(___) ___-____";
            if (expected == "")
            {
                expected = entrystring;
            }
            string actual = EAM.MemberInformation.MemberInfoSecondaryPhone.GetAttribute("value");

            Assert.AreEqual(true, expected.Equals(actual), "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }



        [Then(@"Verify Transaction tab table has no TC (.*)")]
        public void ThenVerifyTransactionTabTableHasNoTC(int p0, Table table)
        {

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.MemberInformation.TransactionHistoryTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            if (bThisRowMatches)
                            {
                                IWebElement thisEditTD = ApplicationRow.Element[0];
                                IWebElement thisEditLink = thisEditTD.FindElement(By.TagName("img"));
                                thisEditLink.Click();
                                tmsWait.Hard(2);

                            }

                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                //baseTable = EAM.AdministrationStatusoverride.TransactionSearchTable;
                //    baseTable =EAM.MemberInformation.TransactionHistoryTable;


                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }


        }



        [Then(@"Reports Enrollment Transactions Missing CMS Data File Name is set to ""(.*)""")]
        public void ThenReportsEnrollmentTransactionsMissingCMSDataFileNameIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                ReUsableFunctions.selectDropDownValueUsingAngularChanges(EAM.ReportsTransMissingCMSData.FileNameAngular,GeneratedData);
            }
            else
            {
                SelectElement select = new SelectElement(EAM.ReportsTransMissingCMSData.FileName);
                select.SelectByText(GeneratedData);
            }
        }

        [Then(@"Reports Enrollment Transactions Missing CMS Data Run Report Button is Clicked")]
        public void ThenReportsEnrollmentTransactionsMissingCMSDataRunReportButtonIsClicked()
        {
            string MainWindowHandle = Browser.Wd.CurrentWindowHandle;
            string ReportWindowHandle = "";
            EAM.ReportsTransMissingCMSData.RunReport.Click();
            tmsWait.Hard(1);

            if (ReportWindowHandle == "")
            {
                ReadOnlyCollection<string> windowHandles = Browser.Wd.WindowHandles;

                foreach (string handle in windowHandles)
                {
                    if (handle != MainWindowHandle)
                    {
                        ReportWindowHandle = handle;
                        break;
                    }
                }
            }

            Browser.Wd.SwitchTo().Window(ReportWindowHandle).Close();
            tmsWait.Hard(1);
            Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle);

            fw.ConsoleReport("Report was closed");
            ReportWindowHandle = "";
        }

        [Then(@"Verify Member Info Page Rx Billing Tab LEP Amount is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageRxBillingTabLEPAmountIsSetTo(string p0)
        {
            string fieldName = "RX Billing tab LEP amount ";

            string expected = tmsCommon.GenerateData(p0);
            String actual = EAM.MemberInformation.RXBillingLEPamount.GetAttribute("value");

            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }

        [Then(@"Verify Member Info Page RX Billing Tab Credit Cover is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageRXBillingTabCreditCoverIsSetTo(string p0)
        {

            string fieldName = "RX Billing tab Credit Cover  ";

            string expected = tmsCommon.GenerateData(p0);

            SelectElement s = new SelectElement(EAM.MemberInformation.CreditCover);
            String actual = s.SelectedOption.Text;

            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }

        [Then(@"Verify Member Info Page RX Billing Tab Uncovered Months is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageRXBillingTabUncoveredMonthsIsSetTo(String p0)
        {
            string fieldName = "RX Billing tab UnCovered Months  ";

            string expected = tmsCommon.GenerateData(p0);

            String actual = EAM.MemberInformation.UnCoveredMonths.GetAttribute("value");

            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }

        [Then(@"Verify Member Info Page Rx Billing Tab PartD opt out is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageRxBillingTabPartDOptOutIsSetTo(string p0)
        {
            string fieldName = "RX Billing tab PartD Opt Out Options ";

            string expected = tmsCommon.GenerateData(p0);

            SelectElement s = new SelectElement(EAM.MemberInformation.PartDOptOut);
            String actual = s.SelectedOption.Text;

            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }


        [Then(@"Verify Member Info Page Rx Billing Tab Premium Withhold Option is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageRxBillingTabPremiumWithholdOptionIsSetTo(string p0)
        {
            string fieldName = "RX Billing tab Premium Withhold Options ";

            string expected = tmsCommon.GenerateData(p0);

            SelectElement s = new SelectElement(EAM.MemberInformation.RXBillingPWoption);
            String actual = s.SelectedOption.Text;

            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }

        [Then(@"Verify View Edit Transaction Page Disenrollment reason code is set to ""(.*)""")]
        public void ThenVerifyViewEditTransactionPageDisenrollmentReasonCodeIsSetTo(string p0)
        {
            string fieldName = "View Edit Transaction Page Disenrollment reason code  ";

            string expected = tmsCommon.GenerateData(p0);

            SelectElement s = new SelectElement(EAM.TransactionsViewEdit.DisenReason);
            String actual = s.SelectedOption.Text;

            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }


        [Then(@"Verify Member Info Page Premium Withhold Option is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPagePremiumWithholdOptionIsSetTo(string p0)
        {
            string fieldName = "Member Info Page Premium Withhold Options ";

            string expected = tmsCommon.GenerateData(p0);

            SelectElement s = new SelectElement(EAM.MemberInformation.MemberInfoPWoption);
            String actual = s.SelectedOption.Text;

            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }

        [When(@"Rx Billing Tab PW Option is selected as ""(.*)""")]
        public void WhenRxBillingTabPWOptionIsSelectedAs(string p0)
        {
            tmsWait.Hard(2);
            SelectElement s = new SelectElement(EAM.MemberInformation.MemberInfoRXBillingPWO);
            s.SelectByText(p0);
        }

        [Then(@"Verify Member Info RX Billing Tab Premium Withhold Option is set to ""(.*)""")]
        public void ThenVerifyMemberInfoRXBillingTabPremiumWithholdOptionIsSetTo(string p0)
        {
            string fieldName = "Member Info Page RX Billing Premium Withhold Options ";

            string expected = tmsCommon.GenerateData(p0);

            SelectElement s = new SelectElement(EAM.MemberInformation.MemberInfoRXBillingPWO);
            String actual = s.SelectedOption.Text;

            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }

        [Then(@"Member Info Page RX Billing tab is clicked")]
        public void ThenMemberInfoPageRXBillingTabIsClicked()
        {
            EAM.MemberInformation.RXBillingTab.Click();
        }

        [Then(@"RxBilling tab has row")]
        public void ThenRxBillingTabHasRow(Table table)
        {

            Exception thisE = null;
            Boolean bSuccess = false;
            int iCt = 0;
            while (iCt < 5 && !bSuccess)
            {
                iCt++;
                try
                {
                    IWebElement objWebTable = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_RsGrid']"));
                    Console.WriteLine("Input data row: [" + table.ToString() + "]");

                    String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                    for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                    {
                        int index = 0;
                        if (int.TryParse(arrRes[i, 0], out index))
                        {
                            if (index < 0)
                            {
                                Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                            }
                        }
                    }
                    bSuccess = true;
                }
                catch (Exception e)
                {
                    thisE = e;
                    Console.WriteLine("Failed trying to hit found hic lookup [" + iCt + "]");
                }
            }
            if (!bSuccess)
            {
                Assert.Fail("Members View Edit Table has row: {0}", thisE.Message);

            }
        }


        [Then(@"Verify Member Info Page Provider tab PCP Provider ID is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageProviderTabPCPProviderIDIsSetTo(string p0)
        {
            string fieldName = "PCP Provider ID";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MemberInformation.PCPProviderID.GetAttribute("value");

            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }


        [Then(@"Verify Member Info Page Provider tab Provider First Name is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageProviderTabProviderFirstNameIsSetTo(string p0)
        {
            string fieldName = "Provider First Name";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MemberInformation.ProviderFirstName.GetAttribute("value");

            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [Then(@"Verify Member Info Page Provider tab Provider Last Name is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageProviderTabProviderLastNameIsSetTo(string p0)
        {
            string fieldName = "Provider Last Name";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MemberInformation.ProviderLastName.GetAttribute("value");

            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [Then(@"Member Info Page Provider tab is clicked")]
        public void ThenMemberInfoPageProviderTabIsClicked()
        {
            EAM.MemberInformation.ProviderTab.Click();
        }


        [Then(@"Member Info Page Rx Billing tab is clicked")]
        public void ThenMemberInfoPageRxBillingTabIsClicked()
        {
            EAM.MemberInformation.RXBillingTab.Click();
        }

        [Then(@"Verify View Edit Member Page Contact tab Address1 is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageContactTabAddress1IsSetTo(string p1)
        {
            string fieldName = "Member Info Page Address 1";
            string expected = tmsCommon.GenerateData(p1);
            string actual = EAM.MembersViewEdit.MemberViewEditResidenceAddress1.GetAttribute("value");

            Assert.AreEqual(true, expected.Equals(actual), "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");

        }

        [Then(@"View Edit Member page Address Type is set to ""(.*)""")]
        public void ThenViewEditMemberPageAddressTypeIsSetTo(string p0)
        {
            SelectElement addresstype = new SelectElement(EAM.MemberInformation.AddressTypeMailing);
            addresstype.SelectByText("Mailing");
        }

        [Then(@"View Edit Member page RXID is set to ""(.*)""")]
        public void ThenViewEditMemberPageRXIDIsSetTo(string p0)
        {
            EAM.MembersViewEdit.MemberViewEditRXID.SendKeys(p0);
        }

        [Then(@"View Edit Member page Mailing Address(.*) is set to ""(.*)""")]
        public void ThenViewEditMemberPageMailingAddressIsSetTo(int p0, string p1)
        {
            EAM.MembersViewEdit.MemberViewEditMailingModAddress1.SendKeys(p1);
        }

        [Then(@"Verify View Edit Member Page Contact tab Address2 is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageContactTabAddress2IsSetTo(string p1)
        {
            string fieldName = "Member Info Page Address 2";
            string expected = tmsCommon.GenerateData(p1);
            string actual = EAM.MembersViewEdit.MemberViewEditResidenceAddress2.GetAttribute("value");

            Assert.AreEqual(true, expected.Equals(actual), "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }

        [Then(@"View Edit Member Page Contact tab Address1 is set to ""(.*)""")]
        public void ThenViewEditMemberPageContactTabAddress1IsSetTo(string p1)
        {
            EAM.MembersViewEdit.MemberViewEditResidenceAddress1.SendKeys(p1);
        }

        [Then(@"View Edit Member Page Save button is Clicked")]
        public void ThenViewEditMemberPageSaveButtonIsClicked()
        {
            EAM.MembersViewEdit.MemberViewEditSaveButton.Click();
            tmsWait.Hard(1);
        }


        [Then(@"Member Info Page Contact tab is clicked")]
        public void ThenMemberInfoPageContactTabIsClicked()
        {
            EAM.MemberInformation.ContactTab.Click();
            tmsWait.Hard(1);
        }

        [Then(@"Verify Member Info Page SCC and Contact tab SCC is same")]
        public void ThenVerifyMemberInfoPageSCCAndContactTabSCCIsSame()
        {
            String MemberInfoSCC = EAM.MemberInformation.MemberInfoSCC.GetAttribute("value");
            String ContactTabSCC = EAM.MemberInformation.ContactTabSCC.GetAttribute("value");
            GlobalRef.MemberInfoSCC = EAM.MemberInformation.MemberInfoSCC.GetAttribute("value");
            GlobalRef.ContactTabSCC = EAM.MemberInformation.ContactTabSCC.GetAttribute("value");

            string fieldName = "SCC ";

            Assert.AreEqual(true, MemberInfoSCC.Equals(ContactTabSCC), "Field " + fieldName + " value is [" + ContactTabSCC + "], expected [" + MemberInfoSCC + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + ContactTabSCC + "], expected [" + MemberInfoSCC + "] - They are expected to match.");
        }

        [Then(@"Verify Member Info Page SCC has not changed")]
        public void ThenVerifyMemberInfoPageSCCHasNotChanged()
        {

            String AfterMemberInfoSCC = EAM.MemberInformation.MemberInfoSCC.GetAttribute("value");
            var BeforeMemberInfoSCC = GlobalRef.MemberInfoSCC;

            string fieldName = "Member Info SCC ";

            Assert.AreEqual(true, AfterMemberInfoSCC.Equals(BeforeMemberInfoSCC), "Field " + fieldName + " value is [" + BeforeMemberInfoSCC + "], expected [" + AfterMemberInfoSCC + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + BeforeMemberInfoSCC + "], expected [" + AfterMemberInfoSCC + "] - They are expected to match.");
        }

        [Then(@"Verify Member Info Page County has not changed")]
        public void ThenVerifyMemberInfoPageCountyHasNotChanged()
        {
            String AfterMemberInfoCounty = EAM.MemberInformation.MemberInfoCounty.GetAttribute("value");
            var BeforeMemberInfoCounty = GlobalRef.MemberInfoCounty;

            string fieldName = "Member Info County ";

            Assert.AreEqual(true, AfterMemberInfoCounty.Equals(BeforeMemberInfoCounty), "Field " + fieldName + " value is [" + BeforeMemberInfoCounty + "], expected [" + AfterMemberInfoCounty + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + BeforeMemberInfoCounty + "], expected [" + AfterMemberInfoCounty + "] - They are expected to match.");
        }

        [Then(@"Verify View Edit Member Page Contact tab City is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageContactTabCityIsSetTo(string p0)
        {
            string fieldName = "Member Info Page Contact Tab City";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MembersViewEdit.MemberViewEditResidenceCity.GetAttribute("value");

            Assert.AreEqual(true, expected.Equals(actual), "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }

        [Then(@"Verify View Edit Member Page Contact tab State is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageContactTabStateIsSetTo(string p0)
        {
            string fieldName = "Member Info Page Contact Tab State";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MembersViewEdit.MemberViewEditResidenceState.GetAttribute("value");

            Assert.AreEqual(true, expected.Equals(actual), "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }

        [Then(@"Verify View Edit Member Page Contact tab Zip is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageContactTabZipIsSetTo(string p0)
        {
            string fieldName = "Member Info Page Contact Tab Zip";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MembersViewEdit.MemberViewEditResidenceZip.GetAttribute("value");

            Assert.AreEqual(true, expected.Equals(actual), "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }

        [Then(@"Verify View Edit Member Page Contact tab County is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageContactTabCountyIsSetTo(string p0)
        {
            string fieldName = "Member Info Page Contact Tab County";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MembersViewEdit.MemberViewEditResidenceCounty.GetAttribute("value");

            Assert.AreEqual(true, expected.Equals(actual), "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }

        [Then(@"Verify View Edit Member Page Contact tab SCC is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageContactTabSCCIsSetTo(string p0)
        {
            string fieldName = "Member Info Page Contact Tab SCC";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MembersViewEdit.MemberViewEditResidenceSCC.GetAttribute("value");

            Assert.AreEqual(true, expected.Equals(actual), "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }


        [Then(@"Verify Members View Edit Eligibility Tab BEQ Requested set to ""(.*)""")]
        public void ThenVerifyMembersViewEditEligibilityTabBEQRequestedSetTo(string p0)
        {
            string fieldName = "Member View Edit Eligiblity Page BEQ Requested";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MembersViewEditEligibilityTab.BEQRequested.GetAttribute("value");

            Assert.AreEqual(true, expected.Equals(actual), "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }

        [Then(@"Verify Members View Edit Eligibility Tab Possible NUNCMo set to ""(.*)""")]
        public void ThenVerifyMembersViewEditEligibilityTabPossibleNUNCMoSetTo(string p0)
        {
            string fieldName = "Member View Edit Eligiblity Tab Possible NUNCMo";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MembersViewEditEligibilityTab.PossibleNUNCMo.GetAttribute("value");

            Assert.AreEqual(true, expected.Equals(actual), "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }


        [Then(@"Verify Member Info Page Contact Tab County has not changed")]
        public void ThenVerifyMemberInfoPageContactTabCountyHasNotChanged()
        {
            String AfterContactTabCounty = EAM.MemberInformation.MemberInfoCounty.GetAttribute("value");
            var BeforeContactTabCounty = GlobalRef.ContactTabCounty;

            string fieldName = "Member Info  Contact Tab County ";

            Assert.AreEqual(true, AfterContactTabCounty.Equals(BeforeContactTabCounty), "Field " + fieldName + " value is [" + BeforeContactTabCounty + "], expected [" + AfterContactTabCounty + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + BeforeContactTabCounty + "], expected [" + AfterContactTabCounty + "] - They are expected to match.");
        }

        [Then(@"Member Info Page Save button is clicked")]
        public void ThenMemberInfoPageSaveButtonIsClicked()
        {
            EAM.MemberInformation.MemberInfoPageSaveButton.Click();
        }

        [Then(@"Verify Member Info Page Contact Tab SCC has not changed")]
        public void ThenVerifyMemberInfoPageContactTabSCCHasNotChanged()
        {
            String AfterContactTabSCC = EAM.MemberInformation.ContactTabSCC.GetAttribute("value");
            var BeforeContactTabSCC = GlobalRef.ContactTabSCC;

            string fieldName = "Member Info Page Contact Tab SCC ";

            Assert.AreEqual(true, AfterContactTabSCC.Equals(BeforeContactTabSCC), "Field " + fieldName + " value is [" + BeforeContactTabSCC + "], expected [" + AfterContactTabSCC + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + BeforeContactTabSCC + "], expected [" + AfterContactTabSCC + "] - They are expected to match.");
        }


        [Then(@"Verify Member Info Page County and Contact tab County is same")]
        public void ThenVerifyMemberInfoPageCountyAndContactTabCountyIsSame()
        {
            String MemberInfoCounty = EAM.MemberInformation.MemberInfoCounty.GetAttribute("value");
            String ContactTabCounty = EAM.MemberInformation.ContactTabCounty.GetAttribute("value");
            GlobalRef.MemberInfoCounty = EAM.MemberInformation.MemberInfoCounty.GetAttribute("value");
            GlobalRef.ContactTabCounty = EAM.MemberInformation.ContactTabCounty.GetAttribute("value");

            string fieldName = "County ";

            Assert.AreEqual(true, MemberInfoCounty.Equals(ContactTabCounty), "Field " + fieldName + " value is [" + ContactTabCounty + "], expected [" + MemberInfoCounty + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + ContactTabCounty + "], expected [" + MemberInfoCounty + "] - They are expected to match.");
        }

        [Then(@"Set address to ""(.*)""")]
        public void ThenSetAddressTo(string p0)
        {
            EAM.MembersNewTabContact.Address1.Clear();
            EAM.MembersNewTabContact.Address1.SendKeys(p0);
        }

        [Then(@"Clear the Member Address")]
        public void ThenClearTheMemberAddress()
        {
            EAM.MembersNewTabContact.Address1.Clear();
        }

        [Then(@"clear the Member ZipCode")]
        public void ThenClearTheMemberZipCode()
        {
            EAM.MembersNewTabContact.Zip.Clear();
        }


        [Then(@"Member ID is set to ""(.*)""")]
        public void ThenMemberIDIsSetTo(string p0)
        {
            EAM.MemberInformation.MemberInfoMemberID.Clear();
            EAM.MemberInformation.MemberInfoMemberID.SendKeys(tmsCommon.GenerateData(p0));
        }


        [Then(@"Verify Member Info Page Contact tab MailingCity is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageContactTabMailingCityIsSetTo(string p0)
        {
            SelectElement addresstype = new SelectElement(EAM.MemberInformation.AddressTypeMailing);
            addresstype.SelectByText("Mailing");
            tmsWait.Implicit(2);

            string fieldName = "Mailing City ";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MemberInformation.MailingCity.GetAttribute("value");

            Assert.AreEqual(true, GeneratedData.Equals(thisFieldValue), "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [Then(@"Set ZipCode to ""(.*)""")]
        public void ThenSetZipCodeTo(int p0)
        {
            EAM.MembersNewTabContact.Zip.Clear();
            EAM.MembersNewTabContact.Zip.SendKeys(p0.ToString());
            //tmsWait(2);
        }

        [Then(@"Verify Address is set to ""(.*)""")]
        public void ThenVerifyAddressIsSetTo(string p0)
        {
            SelectElement addresstype = new SelectElement(EAM.MemberInformation.AddressTypeMailing);
            addresstype.SelectByText("Mailing");
            tmsWait.Implicit(2);

            string fieldName = "Address ";
            string GeneratedData = tmsCommon.GenerateData(p0);
            //string thisFieldValue = EAM.MemberInformation.MailingCity.GetAttribute("value");

            string thisFieldValue = EAM.MembersNewTabContact.Address1.GetAttribute("value");

            Assert.AreEqual(true, GeneratedData.Equals(thisFieldValue), "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");

        }

        [Then(@"verify ZipCode is set to ""(.*)""")]
        public void ThenVerifyZipCodeIsSetTo(int p0)
        {
            tmsWait.Hard(2);
            SelectElement addresstype = new SelectElement(EAM.MemberInformation.AddressTypeMailing);
            addresstype.SelectByText("Mailing");
            tmsWait.Implicit(2);

            string fieldName = "ZipCode ";
            string GeneratedData = tmsCommon.GenerateData(p0.ToString());
            //string thisFieldValue = EAM.MemberInformation.MailingCity.GetAttribute("value");

            string thisFieldValue = EAM.MembersNewTabContact.Zip.GetAttribute("value");

            Assert.AreEqual(true, GeneratedData.Equals(thisFieldValue), "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");


        }



        [Then(@"Verify Medicare PartB Eff value is set to ""(.*)""")]
        public void ThenVerifyMedicarePartBEffValueIsSetTo(string p0)
        {
            string fieldName = "Medicare PartB Effective date ";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNewTabEligibility.PlanPartBEff.GetAttribute("value");

            Assert.AreEqual(true, GeneratedData.Equals(thisFieldValue), "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }


        [Then(@"Verify Medicare PartA Eff value is set to ""(.*)""")]
        public void ThenVerifyMedicarePartAEffValueIsSetTo(string p0)
        {
            string fieldName = "Medicare PartA Effective date ";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNewTabEligibility.PlanPartAEff.GetAttribute("value");

            Assert.AreEqual(true, GeneratedData.Equals(thisFieldValue), "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }


        [Then(@"Member Info Page Eligibility tab is clicked")]
        public void ThenMemberInfoPageEligibilityTabIsClicked()
        {
            EAM.MemberInformation.EligibilityTab.Click();
        }

        [Then(@"Member Info Page Spans Tab Plan ID is set to ""(.*)""")]
        public void ThenMemberInfoPageSpansTabPlanIDIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.MemberInformation.SpansPlanID);
            select.SelectByText(GeneratedData);
        }

        [Then(@"Member Info Page Spans Tab Status type is set to ""(.*)""")]
        public void ThenMemberInfoPageSpansTabStatusTypeIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.MemberInformation.SpansStatusType);
            select.SelectByText(GeneratedData);
        }

        [Then(@"Member Info Page Spans Tab value is set to ""(.*)""")]
        public void ThenMemberInfoPageSpansTabValueIsSetTo(string p0)
        {
            EAM.MemberInformation.Spansvalue.SendKeys(p0);
        }

        [Then(@"Member Info Page Spans Tab Start Date is set to ""(.*)""")]
        public void ThenMemberInfoPageSpansTabStartDateIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            GeneratedData = GeneratedData.Replace("/", "");
            EAM.MemberInformation.SpansStartDate.Clear();
            EAM.MemberInformation.SpansStartDate.Click();
            EAM.MemberInformation.SpansStartDate.SendKeys(Keys.Home);
            EAM.MemberInformation.SpansStartDate.SendKeys(GeneratedData);
        }

        [Then(@"Member Info Page Spans Tab End Date is set to ""(.*)""")]
        public void ThenMemberInfoPageSpansTabEndDateIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            GeneratedData = GeneratedData.Replace("/", "");
            EAM.MemberInformation.SpansEndDate.Clear();
            EAM.MemberInformation.SpansEndDate.Click();
            EAM.MemberInformation.SpansEndDate.SendKeys(Keys.Home);
            EAM.MemberInformation.SpansEndDate.SendKeys(GeneratedData);
        }

        [Then(@"Member Info Page Spans Tab Save button icon is Clicked")]
        public void ThenMemberInfoPageSpansTabSaveButtonIconIsClicked()
        {
            fw.ExecuteJavascript(EAM.MemberInformation.SpansSaveButton);
        }

        [Then(@"Member Info Page Spans tab is clicked")]
        public void ThenMemberInfoPageSpansTabIsClicked()
        {
            fw.ExecuteJavascript(EAM.MemberInformation.SpansTab);
            tmsWait.Hard(2);

        }
        [Then(@"Verify Member Info Page Span Tab status PCP(.*) is deleted")]
        public void ThenVerifyMemberInfoPageSpanTabStatusPCPIsDeleted(int p0)
        {
            try
            {
                IList<IWebElement> web = Browser.Wd.FindElements(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_ucMemberSpans_dgHistory']/tbody//following::td[contains(text(),'PCP1')]"));
                if (web.Count == 0)
                {
                    Assert.IsTrue(true);
                }

            }
            catch (Exception ex)
            {
                Assert.IsTrue(true);

            }




        }

        [Then(@"Verify Member Info Page Span Tab status PCP(.*) EndDate Is Updated As Last Day of Current Month")]
        public void ThenVerifyMemberInfoPageSpanTabStatusPCPEndDateIsUpdatedAsLastDayOfCurrentMonth(int p0)
        {
            var now = DateTime.Now;
            var first = new DateTime(now.Year, now.Month, 1);
            var last = first.AddMonths(1).AddDays(-1);
            string enddate = "0" + last.ToShortDateString();
            Console.WriteLine(last);
            string actdate;

            try
            {
                IWebElement web = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_ucMemberSpans_dgHistory']/tbody//following::td[contains(text(),'PCP1')][2]/following-sibling::td[3]"));
                actdate = web.Text;

            }
            catch
            {
                IWebElement web = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_ucMemberSpans_dgHistory']/tbody//following::td[contains(text(),'PCP1')]/following-sibling::td[3]"));
                actdate = web.Text;

            }

            Assert.AreEqual(true, actdate.Equals(enddate));
        }



        [Then(@"Verify Member Info Page Span Tab status GRP1 and value 1000351 EndDate Is Updated As Last Day of Current Month")]
        public void VerifyMemberInfoPageSpanTabGRP1andvalue1000351EndDateIsUpdatedAsLastDayofCurrentMonth()
        {
            var now = DateTime.Now;
            var first = new DateTime(now.Year, now.Month, 1);
            var last = first.AddMonths(1).AddDays(-1);
            string enddate = "0" + last.ToShortDateString();
            Console.WriteLine(last);


            IWebElement web = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_ucMemberSpans_dgHistory']/tbody/tr[2]/td[4][contains(text(),'GRP1')]/following-sibling::td[1][contains(text(),'1000351 ')]/following-sibling::td[2]"));
            string actdate = web.Text;
            Assert.AreEqual(true, actdate.Equals(enddate));

        }
        [Then(@"Member Info Page Spans tab EFF Button is clicked")]
        public void ThenMemberInfoPageSpansTabEFFButtonIsClicked()
        {
            EAM.MemberInformation.EFFbutton.Click();
            tmsWait.Hard(5);
        }



        [Then(@"Member Span File page Modofied Only checkbox is checked")]
        public void ThenMemberSpanFilePageModofiedOnlyCheckboxIsChecked()
        {
            tmsWait.Hard(2);
            //    cfMemberSpanFile.ModifiedOnlyCheckbox.Click();
        }

        [Then(@"Member Span File page Export button is clicked")]
        public void ThenMemberSpanFilePageExportButtonIsClicked()
        {
            tmsWait.Hard(2);
            //      cfMemberSpanFile.ExportSpanFileButton.Click();
            //string moreOptionClick = "$('input#ctl00_ctl00_MainMasterContent_MainContent_TRRCodeUserList1_btnExport').click();";
            //fw.ExecuteJavascript(moreOptionClick);
        }

        [Then(@"Files Processed wait a maximum of ""(.*)"" seconds to have Status ""(.*)""")]
        public void ThenFilesProcessedWaitAMaximumOfSecondsToHaveStatus(int p0, string status)
        {

            //do
            //{
            //    tmsWait.Hard(5);
            //    Navigation.ClickLink("FilesProcessingStatus");
            //    tmsWait.Hard(5);
            //} while (!cfMemberSpanFile.CompleteStatus.Text.Equals(status));
        }

        [Then(@"File Processing Status page span file is opened")]
        public void ThenFileProcessingStatusPageSpanFileIsOpened()
        {
            var oldTextFiles = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
            foreach (var oldText in oldTextFiles)
            {
                File.Delete(oldText);
            }
            //string moreOptionClick = "$('a.truncate').click();";
            //fw.ExecuteJavascript(moreOptionClick);
            Browser.Wd.FindElement(By.CssSelector("a[href*='../../Common/Handlers/GenericFileDownload.ashx?']")).Click();
            //Browser.Wd.FindElement(By.PartialLinkText("Spans" + DateTime.Today.ToString("yyyyMMdd") + "")).Click();
            tmsWait.Hard(4);
            DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_MENU, 0, 0, 0);
            DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_S, 0, 0, 0);
            tmsWait.Hard(2);
            DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_ESCAPE, 0, 0, 0);
        }

        [Then(@"Verify modified span value ""(.*)""")]
        public void ThenVerifyModifiedSpanValue(string expectedValue)
        {
            tmsWait.Hard(5);    //Wait for download, save and reading purpose
            var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
            var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
                var values = line.Split(' ');
                if (count > 1)
                {
                    Assert.IsTrue(values[12].Contains(expectedValue), "Expected Field Value is dislayed.");
                    fw.ConsoleReport(" Legacy File Field number 13 displayed Expected value as " + expectedValue);
                    break;
                }
            }
        }

        [Then(@"Verify EAM Span file modified span value ""(.*)""")]
        public void ThenVerifyEAMSpanFileModifiedSpanValue(string expectedValue)
        {
            tmsWait.Hard(5);    //Wait for download, save and reading purpose
            var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
            var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
                bool contains = line.Contains(expectedValue);

                if (contains)
                {
                    Assert.IsTrue(contains, "Expected Field Value is dislayed.");
                    fw.ConsoleReport(" EAM span file contains " + expectedValue);
                    break;
                }
                else
                {
                    fw.ConsoleReport("EAM Span file does not contain " + expectedValue);
                }
            }
        }

        [Then(@"Verify modified span value ""(.*)"" not present")]
        public void ThenVerifyModifiedSpanValueNotPresent(string expectedValue)
        {
            tmsWait.Hard(5);    //Wait for download, save and reading purpose
            var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
            var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
                var values = line.Split(' ');
                if (count > 1)
                {
                    Assert.IsFalse(values[12].Contains(expectedValue), "Expected Field Value is dislayed.");
                    fw.ConsoleReport(expectedValue + "is present and should not be");
                    break;
                }
            }
        }

        [Then(@"Verify EAM Span file modified span value ""(.*)"" not present")]
        public void ThenVerifyEAMSpanFileModifiedSpanValueNotPresent(string expectedValue)
        {
            tmsWait.Hard(5);    //Wait for download, save and reading purpose
            var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
            var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();

                Assert.IsFalse(line.Contains(expectedValue), "Expected Field Value is dislayed.");
                fw.ConsoleReport(expectedValue + "is present and should not be");
                break;

            }
        }

        [Then(@"Verify modified span value HIC ""(.*)"" is ""(.*)""")]
        public void ThenVerifyModifiedSpanValueHICIs(string expectedValue, string status)
        {
            tmsWait.Hard(5);    //Wait for download, save and reading purpose
            bool flag = true;
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
            var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            while (!reader.EndOfStream)
            {
                var line = reader.ReadLine();
                var values = line.Split(' ');
                for (int index = 0; index < values.Length; index++)
                {
                    if (values[index].Contains(expectedValue))
                    {
                        flag = false;
                        break;
                    }
                }
            }
            if (status.ToLower().Equals("displayed"))
            {
                Assert.IsFalse(flag, "HIC " + expectedValue + " is not found in SPAN file.");
            }
            else
            {
                Assert.IsFalse(flag, "HIC " + expectedValue + " is not found in SPAN file.");
            }
        }


        [Then(@"Member Info Page Spans Table Edit Icon is clicked for row")]
        public void ThenMemberInfoPageSpansTableEditIconIsClickedForRow(Table table)
        {

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.MemberInformation.SpansTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            if (bThisRowMatches)
                            {
                                IWebElement thisEditTD = ApplicationRow.Element[0];
                                IWebElement thisEditLink = thisEditTD.FindElement(By.TagName("a"));
                                thisEditLink.Click();
                                tmsWait.Hard(2);

                            }

                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.MemberInformation.SpansTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }

        }



        [Then(@"Verify Member Info Page Spans Tab Span value is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageSpansTabSpanValueIsSetTo(string p0)
        {
            String strValue = tmsCommon.GenerateData(p0);

            tmsWait.Hard(1);
            IWebElement objDate = EAM.MemberInformation.SpanTabSpanValue;
            objDate.Clear();
            objDate.SendKeys(strValue);
        }

        [Then(@"Verify Member Info Page Spans Tab Static Message is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageSpansTabStaticMessageIsSetTo(string p0)
        {
            string fieldName = " Member Information Page Span Table Static Message ";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MemberInformation.SpanTabStaticMessage.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [When(@"Member View Edit page Spans tab Save icon is Clicked")]
        public void WhenMemberViewEditPageSpansTabSaveIconIsClicked()
        {
            EAM.MemberInformation.SpansSaveButton.Click();
        }


        [When(@"Member View Edit page Spans tab ""(.*)"" is set to ""(.*)""")]
        public void WhenMemberViewEditPageSpansTabIsSetTo(string field, string value)
        {
            switch (field)
            {
                case "Plan ID":
                    SelectElement pi = new SelectElement(EAM.MemberInformation.SpansPlanID);
                    pi.SelectByText(value);
                    break;
                case "Status Type":
                    SelectElement st = new SelectElement(EAM.MemberInformation.SpansStatusType);
                    st.SelectByText(value);
                    break;
                case "Value":
                    EAM.MemberInformation.Spansvalue.SendKeys(value);
                    break;
                case "Start Date":
                    string GeneratedData = tmsCommon.GenerateData(value);
                    GeneratedData = GeneratedData.Replace("/", "");
                    EAM.MemberInformation.SpansStartDate.Clear();
                    EAM.MemberInformation.SpansStartDate.Click();
                    EAM.MemberInformation.SpansStartDate.SendKeys(Keys.Home);
                    tmsWait.Hard(5);
                    EAM.MemberInformation.SpansStartDate.SendKeys(Keys.Home);
                    EAM.MemberInformation.SpansStartDate.SendKeys(GeneratedData);
                    tmsWait.Hard(1);
                    break;
                case "End Date":
                    string GeneratedData1 = tmsCommon.GenerateData(value);
                    GeneratedData1 = GeneratedData1.Replace("/", "");
                    EAM.MemberInformation.SpansEndDate.Clear();
                    EAM.MemberInformation.SpansEndDate.Click();
                    EAM.MemberInformation.SpansEndDate.SendKeys(Keys.Home);
                    tmsWait.Hard(5);
                    EAM.MemberInformation.SpansEndDate.SendKeys(Keys.Home);
                    EAM.MemberInformation.SpansEndDate.SendKeys(GeneratedData1);
                    tmsWait.Hard(1);
                    break;
            }
        }


        [Then(@"Member Info Page Spans Tab Save button is clicked")]
        public void ThenMemberInfoPageSpansTabSaveButtonIsClicked()
        {
            EAM.MemberInformation.SpanTabSaveButton.Click();
        }


        [Then(@"Verify Member Info Page Spans Table has row")]
        public void ThenVerifyMemberInfoPageSpansTableHasRow(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.MemberInformation.SpansTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");
                //               Boolean bTransStatusMatching = false;
                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {

                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //if(AppTableRow.Equals(GherkinTableArray[iElementCounter])
                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (appTD.Equals("Canceled"))
                                //{

                                //    Assert.IsTrue(appTD.Equals("Canceled"));
                                //    bTransStatusMatching = true;
                                //    //Console.WriteLine("TC 61 status is found as Canceled");
                                //}

                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //    //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }


                        }

                    }
                    iTableCounter++;
                    //if (bTransStatusMatching)
                    //{
                    //    Console.WriteLine("Transaction status is updated to Canceled in Transaction History");
                    //}
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                //if (bTransStatusMatching)
                //{
                //    Console.WriteLine("Member Info page Transaction status is updated to Canceled in Transaction History table");
                //}

                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.MemberInformation.SpansTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }

        }


        [Then(@"Letters Table has no rows")]
        public void ThenLettersTableHasNoRows(Table table)
        {

            string LettersMessage = EAM.LettersPostCMS.LettersMessage.Text;
            Console.WriteLine("Letters Page Message Text [" + LettersMessage + "]");

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.LettersPostCMS.LettersTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                //           thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");
                //               Boolean bTransStatusMatching = false;
                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {

                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //if(AppTableRow.Equals(GherkinTableArray[iElementCounter])
                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (appTD.Equals("Canceled"))
                                //{

                                //    Assert.IsTrue(appTD.Equals("Canceled"));
                                //    bTransStatusMatching = true;
                                //    //Console.WriteLine("TC 61 status is found as Canceled");
                                //}

                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //    //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                                Assert.AreEqual(true, false, "Did not expect to match any rows.   This row did match.   Fail");

                            }
                        }
                    }
                    iTableCounter++;
                    //if (bTransStatusMatching)
                    //{
                    //    Console.WriteLine("Transaction status is updated to Canceled in Transaction History");
                    //}
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                //if (bTransStatusMatching)
                //{
                //    Console.WriteLine("Member Info page Transaction status is updated to Canceled in Transaction History table");
                //}

                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                //else
                //{


                //    //Click next page link and start over.
                //    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                //    {
                //        thisTP.bNotAtLastPageOfRecords = true;
                //        thisTP.NPL.Click();
                //        tmsWait.Hard(2);
                //    }
                //}
                baseTable = EAM.LettersPostCMS.LettersTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportPassOnNotMatching(thisGT.GTable);
                }
            }

        }


        [Then(@"Verify Member Info Page Spans Table has no row")]
        public void ThenVerifyMemberInfoPageSpansTableHasNoRow(Table table)
        {

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.MemberInformation.SpansTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                //           thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");
                //               Boolean bTransStatusMatching = false;
                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {

                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //if(AppTableRow.Equals(GherkinTableArray[iElementCounter])
                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (appTD.Equals("Canceled"))
                                //{

                                //    Assert.IsTrue(appTD.Equals("Canceled"));
                                //    bTransStatusMatching = true;
                                //    //Console.WriteLine("TC 61 status is found as Canceled");
                                //}

                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //    //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                                Assert.AreEqual(true, false, "Did not expect to match any rows.   This row did match.   Fail");

                            }



                        }

                    }
                    iTableCounter++;
                    //if (bTransStatusMatching)
                    //{
                    //    Console.WriteLine("Transaction status is updated to Canceled in Transaction History");
                    //}
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                //if (bTransStatusMatching)
                //{
                //    Console.WriteLine("Member Info page Transaction status is updated to Canceled in Transaction History table");
                //}

                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                //else
                //{


                //    //Click next page link and start over.
                //    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                //    {
                //        thisTP.bNotAtLastPageOfRecords = true;
                //        thisTP.NPL.Click();
                //        tmsWait.Hard(2);
                //    }
                //}
                baseTable = EAM.MemberInformation.SpansTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportPassOnNotMatching(thisGT.GTable);
                }
            }
        }


        [Then(@"Verify Member Info Page Spans Table Span End Date")]
        public void ThenVerifyMemberInfoPageSpansTableSpanEndDate(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.MemberInformation.SpansTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");
                Boolean bSpanEndMatching = false;
                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {

                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //if(AppTableRow.Equals(GherkinTableArray[iElementCounter])
                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                if (appTD.Equals("12/31/2015"))
                                {

                                    Assert.IsTrue(appTD.Equals("12/31/2015"));
                                    bSpanEndMatching = true;
                                    //Console.WriteLine("TC 61 status is found as Canceled");
                                }

                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }

                                iElementCounter++;


                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //    //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }


                        }

                    }
                    iTableCounter++;
                    //if (bTransStatusMatching)
                    //{
                    //    Console.WriteLine("Transaction status is updated to Canceled in Transaction History");
                    //}
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (bSpanEndMatching)
                {
                    Console.WriteLine("Member Info page Span End Date is Matching with Gherkin Table");
                }

                //if (fullMatching)
                //{
                //    Console.WriteLine("All rows are matched, step completed as passed");
                //}
                //else
                //{
                //Click next page link and start over.
                if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                {
                    thisTP.bNotAtLastPageOfRecords = true;
                    thisTP.NPL.Click();
                    tmsWait.Hard(2);
                }
                //}
                baseTable = EAM.MemberInformation.SpansTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }


        [Then(@"Verify Member Info Page Spans Table Span Effective Date")]
        public void ThenVerifyMemberInfoPageSpansTableSpanEffectiveDate(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.MemberInformation.SpansTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");
                Boolean bSpanEffectiveMatching = false;
                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {

                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //if(AppTableRow.Equals(GherkinTableArray[iElementCounter])
                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                if (appTD.Equals("08/01/2015"))
                                {

                                    Assert.IsTrue(appTD.Equals("08/01/2015"));
                                    bSpanEffectiveMatching = true;
                                    //Console.WriteLine("TC 61 status is found as Canceled");
                                }

                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }

                                iElementCounter++;


                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //    //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }


                        }

                    }
                    iTableCounter++;
                    //if (bTransStatusMatching)
                    //{
                    //    Console.WriteLine("Transaction status is updated to Canceled in Transaction History");
                    //}
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (bSpanEffectiveMatching)
                {
                    Console.WriteLine("Member Info page Span Effective Date is Matching with Gherkin Table");
                }

                //if (fullMatching)
                //{
                //    Console.WriteLine("All rows are matched, step completed as passed");
                //}
                //else
                //{
                //Click next page link and start over.
                if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                {
                    thisTP.bNotAtLastPageOfRecords = true;
                    thisTP.NPL.Click();
                    tmsWait.Hard(2);
                }
                //}
                baseTable = EAM.MemberInformation.SpansTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

        [Then(@"Eligibility tab Plan Part A Effective Date is set to ""(.*)""")]
        public void ThenEligibilityTabPlanPartAEffectiveDateIsSetTo(string p0)
        {

            string GeneratedData = tmsCommon.GenerateData(p0);
            // GeneratedData = GeneratedData.Replace("/", "");
            EAM.MemberInformation.PlanPartAEffDate.Clear();
            fw.ExecuteJavascriptSetText(EAM.MemberInformation.PlanPartAEffDate, GeneratedData);


            //EAM.MemberInformation.PlanPartAEffDate.Click();
            //EAM.MemberInformation.PlanPartAEffDate.SendKeys(Keys.Home);
            //EAM.MemberInformation.PlanPartAEffDate.SendKeys(GeneratedData);            

        }
        [Then(@"Eligibility tab Plan Part B Effective Date is set to ""(.*)""")]
        public void ThenEligibilityTabPlanPartBEffectiveDateIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            // GeneratedData = GeneratedData.Replace("/", "");
            EAM.MemberInformation.PlanPartBEffDate.Clear();
            fw.ExecuteJavascriptSetText(EAM.MemberInformation.PlanPartBEffDate, GeneratedData);

            //string GeneratedData = tmsCommon.GenerateData(p0);
            //GeneratedData = GeneratedData.Replace("/", "");
            //EAM.MemberInformation.PlanPartBEffDate.Clear();
            //EAM.MemberInformation.PlanPartBEffDate.Click();
            //EAM.MemberInformation.PlanPartBEffDate.SendKeys(Keys.Home);
            //EAM.MemberInformation.PlanPartBEffDate.SendKeys(GeneratedData);

        }

        [Then(@"Eligibility tab Plan Part D Effective Date is set to ""(.*)""")]
        public void ThenEligibilityTabPlanPartDEffectiveDateIsSetTo(string p0)
        {

            string GeneratedData = tmsCommon.GenerateData(p0);
            // GeneratedData = GeneratedData.Replace("/", "");
            EAM.MemberInformation.PlanPartDEffDate.Clear();
            fw.ExecuteJavascriptSetText(EAM.MemberInformation.PlanPartDEffDate, GeneratedData);

            //string GeneratedData = tmsCommon.GenerateData(p0);
            //GeneratedData = GeneratedData.Replace("/", "");
            //EAM.MemberInformation.PlanPartDEffDate.Clear();
            //EAM.MemberInformation.PlanPartDEffDate.Click();
            //EAM.MemberInformation.PlanPartDEffDate.SendKeys(Keys.Home);
            //EAM.MemberInformation.PlanPartDEffDate.SendKeys(GeneratedData);
        }



        [Then(@"Verify Member Info Page Eligibility tab Plan Part A Effective Date is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageEligibilityTabPlanPartAEffectiveDateIsSetTo(string p0)
        {
            string fieldName = "Plan PartD Effective Date";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MemberInformation.PlanPartAEffDate.GetAttribute("value");

            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [Then(@"Verify Member Info Page Eligibility tab Plan Part B Effective Date is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageEligibilityTabPlanPartBEffectiveDateIsSetTo(string p0)
        {
            string fieldName = "Plan PartD Effective Date";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MemberInformation.PlanPartBEffDate.GetAttribute("value");

            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }


        [Then(@"Verify Member Info Page Eligibility tab Plan Part D Effective Date is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageEligibilityTabPlanPartDEffectiveDateIsSetTo(String p0)
        {
            string fieldName = "Plan PartD Effective Date";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MemberInformation.PlanPartDEffDate.GetAttribute("value");

            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }


        [Then(@"Verify Member Info Page RX Biling tab Employer Group Number is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageRXBilingTabEmployerGroupNumberIsSetTo(string p0)
        {
            string fieldName = "Employer Group Number";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MemberInformation.EmployerGroupNumber.GetAttribute("value");

            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [When(@"View Edit Member page Address type dropdown list is set to ""(.*)""")]
        public void WhenViewEditMemberPageAddressTypeDropdownListIsSetTo(string drp)
        {
            SelectElement drplist = null;
            switch (drp)
            {
                case "Residence":
                    drplist = new SelectElement(EAM.MemberInformation.AddressTypeMailing);
                    drplist.SelectByText(drp);
                    break;
                case "Mailing":
                    drplist = new SelectElement(EAM.MemberInformation.AddressTypeMailing);
                    drplist.SelectByText(drp);
                    break;
                case "Other":
                    drplist = new SelectElement(EAM.MemberInformation.AddressTypeMailing);
                    drplist.SelectByText(drp);
                    break;
            }
            tmsWait.Hard(5);
        }

        [Then(@"Verify Member Info Page County is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageCountyIsSetTo(string p0)
        {
            string fieldName = "Member Info Page County";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MemberInformation.MemberInfoCounty.GetAttribute("value");

            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [Then(@"Verify Member Info Page Contact tab County is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageContactTabCountyIsSetTo(string p0)
        {
            string fieldName = "Member Info Page Contact tab County ";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MemberInformation.ContactTabCounty.GetAttribute("value");

            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }


        [Then(@"Verify Member Info Page Contact tab SCC is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageContactTabSCCIsSetTo(string p0)
        {
            string fieldName = "Member Info Page Contact tab SCC ";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MemberInformation.ContactTabSCC.GetAttribute("value");

            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [Then(@"Verify Member Info Page SCC is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageSCCIsSetTo(string p0)
        {
            string fieldName = "Member Info Page SCC";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MemberInformation.MemberInfoSCC.GetAttribute("value");

            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [Then(@"Verify Member Info page OEC Sales tab Sales Date is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageOECSalesTabSalesDateIsSetTo(string p0)
        {
            string fieldName = "OEC Sales Tab Sales Date";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MemberInformation.MemberInfoOECSalesDate.GetAttribute("value");

            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [Then(@"OEC Sales tab Institution Name field is set to ""(.*)""")]
        public void ThenOECSalesTabInstitutionNameFieldIsSetTo(string p0)
        {
            string fieldvalue = tmsCommon.GenerateData(p0);
            EAM.MemberInformation.MemberInfoOECSalesInstName.SendKeys(fieldvalue);
        }


        [Then(@"Verify Member Info page OEC Sales tab Institution Name field is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageOECSalesTabInstitutionNameFieldIsSetTo(string p0)
        {
            string fieldName = "OEC Sales Tab Inst name";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MemberInformation.MemberInfoOECSalesInstName.GetAttribute("value");

            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [Then(@"Verify Member Info page OEC Sales tab Institution Address field is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageOECSalesTabInstitutionAddressFieldIsSetTo(string p0)
        {
            string fieldName = "OEC Sales Tab Inst Address";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MemberInformation.MemberInfoOECSalesInstAddress.GetAttribute("value");

            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [When(@"View Edit Member page Group is set to ""(.*)""")]
        public void WhenViewEditMemberPageGroupIsSetTo(string p0)
        {
            string fieldvalue = tmsCommon.GenerateData(p0);
            SelectElement drp = new SelectElement(EAM.MemberInformation.MemberInfoGroup);
            drp.SelectByText(fieldvalue);

            tmsWait.Hard(6);
        }

        [When(@"View Edit Member page sub Group is set to ""(.*)""")]
        public void WhenViewEditMemberPageSubGroupIsSetTo(string p0)
        {
            string fieldvalue = tmsCommon.GenerateData(p0);
            SelectElement drp = new SelectElement(EAM.MemberInformation.MemberInfoSubGroup);
            drp.SelectByText(fieldvalue);
            tmsWait.Hard(6);
        }

        [When(@"View Edit Member page Class is set to ""(.*)""")]
        public void WhenViewEditMemberPageClassIsSetTo(string p0)
        {
            string fieldvalue = tmsCommon.GenerateData(p0);
            SelectElement drp = new SelectElement(EAM.MemberInformation.MemberInfoClass);
            drp.SelectByText(fieldvalue);
            tmsWait.Hard(6);
        }

        [Then(@"Verify View Edit Member page sub Group is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageSubGroupIsSetTo(string p0)
        {
            string fieldName = " Sub Group ID";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = new SelectElement(EAM.MemberInformation.MemberInfoSubGroup).SelectedOption.Text;

            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [Then(@"Verify View Edit Member page Group is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageGroupIsSetTo(string p0)
        {
            string fieldName = " Group ID";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = new SelectElement(EAM.MemberInformation.MemberInfoGroup).SelectedOption.Text;

            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [When(@"View Edit Member page Part D Opt drop down list is selected as  ""(.*)""")]
        public void WhenViewEditMemberPagePartDOptDropDownListIsSelectedAs(string p0)
        {
            IWebElement partd = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPartDOptOut"));

            SelectElement drp = new SelectElement(partd);
            drp.SelectByText(p0);
        }


        [Then(@"Verify View Edit Member page Part D Opt drop down list is selected as  ""(.*)""")]
        public void ThenVerifyViewEditMemberPagePartDOptDropDownListIsSelectedAs(string expected)
        {
            tmsWait.Hard(4);
            IWebElement partd = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPartDOptOut"));

            string actual = new SelectElement(partd).SelectedOption.Text;
            Assert.AreEqual(expected, actual, "Both values are not getting matched");
        }

        [When(@"View Edit Member page ""(.*)"" Text box value is set to ""(.*)""")]
        public void WhenViewEditMemberPageTextBoxValueIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(4);
            string plan = "ctl00_ctl00_MainMasterContent_MainContent_txt" + p0 + "";
            tmsWait.Hard(2);
            IWebElement planfield = Browser.Wd.FindElement(By.Id(plan));
            tmsWait.Hard(4);
            //planfield.Clear();
            // tmsWait.Hard(2);
            planfield.SendKeys(p1);
        }

        [Then(@"Verify View Edit Member page ""(.*)"" Text box value is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageTextBoxValueIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(2);
            string plan = "ctl00_ctl00_MainMasterContent_MainContent_txt" + p0 + "";
            IWebElement planfield = Browser.Wd.FindElement(By.Id(plan));
            tmsWait.Hard(4);
            Assert.AreEqual(planfield.GetAttribute("value"), p1, " Both values are not matching");
        }

        [When(@"View Edit Member page Contact tab Address Type is selected as ""(.*)""")]
        public void WhenViewEditMemberPageContactTabAddressTypeIsSelectedAs(string p0)
        {
            tmsWait.Hard(2);
            new SelectElement(Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_drpAddType1"))).SelectByText(p0);

            tmsWait.Hard(4);
        }
        [When(@"View Edit Member page Zip field is set to ""(.*)""")]
        public void WhenViewEditMemberPageZipFieldIsSetTo(string p0)
        {
            IWebElement zip = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtPZip"));
            zip.Clear();
            zip = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtPZip"));
            tmsWait.Hard(3);

            zip.SendKeys(p0);

        }

        [Then(@"Verify View Edit Member page Address(.*) field is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageAddressFieldIsSetTo(int p0, string expected)
        {
            tmsWait.Hard(2);
            string actual = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtPAdd1")).GetAttribute("value");
            Assert.AreEqual(expected, actual, "Both values are not matching");
        }

        [Then(@"Verify View Edit Member page Zip field is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageZipFieldIsSetTo(string expected)
        {
            tmsWait.Hard(2);
            string actual = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtPZip")).GetAttribute("value");
            Assert.AreEqual(expected, actual, "Both values are not matching");
        }

        [Then(@"Verify View Edit Member page EnrollmentSource field is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageEnrollmentSourceFieldIsSetTo(string expected)
        {

            tmsWait.Hard(5);
            SelectElement select = new SelectElement(Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_DropDpwnEnrollSource")));
            string selectedValue = select.SelectedOption.Text;
            Assert.AreEqual(selectedValue, expected.ToString(), "EnrollmentSource is not macthing with expected value");

        }
        [When(@"View Edit Member page Bank field is set to ""(.*)""")]
        public void WhenViewEditMemberPageBankFieldIsSetTo(string p0)
        {
            Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_txtBank")).Clear();
            Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_txtBank")).SendKeys(p0);

        }

        [When(@"View Edit Member page Hospital Name is set to ""(.*)""")]
        public void WhenViewEditMemberPageHospitalNameIsSetTo(string p0)
        {
            IWebElement ele = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucProviderInfo_txtHospital"));
            ele.Clear();
            ele.SendKeys(p0);
        }

        [Then(@"Verify View Edit Member page Primary RX ID is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPagePrimaryRXIDIsSetTo(string expected)
        {
            tmsWait.Hard(3);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(3);

                By Drp = By.XPath("//label[contains(.,'RX ID')]//parent::div//input");
                string actualValue = Browser.Wd.FindElement(Drp).GetAttribute("value");
                Assert.AreEqual(expected, actualValue, " Both values are not matching");
            }
            else
            {

                string actual = Browser.Wd.FindElement(By.CssSelector("[test-id='memberRxDetails-inpu-rxid']")).GetAttribute("value");
                Assert.AreEqual(expected, actual, "Both values are not matching");
            }
        }

        [Then(@"Verify View Edit Transaction page Primary RX ID is set to ""(.*)""")]
        public void ThenVerifyViewEditTransactionPagePrimaryRXIDIsSetTo(string expected)
        {
            tmsWait.Hard(3);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(3);

                By Drp = By.XPath("//label[contains(.,'Primary Rx ID')]//parent::div//input");
                string actualValue = Browser.Wd.FindElement(Drp).GetAttribute("value");
                Assert.AreEqual(expected, actualValue, " Both values are not matching");
            }
            else
            {

                string actual = Browser.Wd.FindElement(By.Id("RxDetailsPrimaryRxID")).GetAttribute("value");
                Assert.AreEqual(expected, actual, "Both values are not matching");
            }

        }


        [When(@"View Edit Member page Language is set to ""(.*)""")]
        public void WhenViewEditMemberPageLanguageIsSetTo(string p0)
        {
            new SelectElement(Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboLanguage"))).SelectByText(p0);
        }


        [When(@"View Edit Member page Gyn Name is set to ""(.*)""")]
        public void WhenViewEditMemberPageGynNameIsSetTo(string p0)
        {
            IWebElement ele = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucProviderInfo_txtGynPCPName"));
            ele.Clear();
            ele.SendKeys(p0);
        }

        [When(@"View Edit Member page MP Name is set to ""(.*)""")]
        public void WhenViewEditMemberPageMPNameIsSetTo(string p0)
        {
            IWebElement ele = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucProviderInfo_txtMPName"));
            ele.Clear();
            ele.SendKeys(p0);
        }

        [When(@"View Edit Member page Dental Name is set to ""(.*)""")]
        public void WhenViewEditMemberPageDentalNameIsSetTo(string p0)
        {
            IWebElement ele = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucProviderInfo_txtDentPCPName"));
            ele.Clear();
            ele.SendKeys(p0);
        }


        [Then(@"Verify View Edit Member page Hospital Name is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageHospitalNameIsSetTo(string p0)
        {
            string actual = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucProviderInfo_txtHospital")).GetAttribute("value");
            Assert.AreEqual(p0, actual, "Both values are not matching");
        }

        [Then(@"Verify View Edit Member page Gyn Name is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageGynNameIsSetTo(string p0)
        {
            string actual = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucProviderInfo_txtGynPCPName")).GetAttribute("value");
            Assert.AreEqual(p0, actual, "Both values are not matching");
        }

        [Then(@"Verify View Edit Member page MP Name is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageMPNameIsSetTo(string p0)
        {
            string actual = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucProviderInfo_txtMPName")).GetAttribute("value");
            Assert.AreEqual(p0, actual, "Both values are not matching");
        }

        [Then(@"Verify View Edit Member page Dental Name is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageDentalNameIsSetTo(string p0)
        {
            string actual = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucProviderInfo_txtDentPCPName")).GetAttribute("value");
            Assert.AreEqual(p0, actual, "Both values are not matching");
        }


        [Then(@"Click on Provider tab")]
        public void ThenClickOnProviderTab()
        {
            IWebElement link = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnProvider"));
            fw.ExecuteJavascript(link);
            tmsWait.Hard(2);
        }

        [Then(@"Verify View Edit Member page Bank field is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageBankFieldIsSetTo(string expected)
        {
            string actual = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_txtBank")).GetAttribute("value");

            Assert.AreEqual(expected, actual, "Both values are not matching");

        }

        [Then(@"Verify View Edit Member page Bank Account Type field is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageBankAccountTypeFieldIsSetTo(string expected)
        {
            string actual = new SelectElement(Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_cboBankAccType"))).SelectedOption.Text;
            Assert.AreEqual(expected, actual, "Both values are not matching");
        }

        [When(@"View Edit Member page Bank Account Type field is set to ""(.*)""")]
        public void WhenViewEditMemberPageBankAccountTypeFieldIsSetTo(string p0)
        {
            new SelectElement(Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_cboBankAccType"))).SelectByText(p0);

            tmsWait.Hard(3);

        }


        [Then(@"Click on Payment tab")]
        public void ThenClickOnPaymentTab()
        {
            IWebElement link = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnPayment"));
            fw.ExecuteJavascript(link);
            tmsWait.Hard(2);
        }


        [When(@"View Edit Member page Address(.*) field is set to ""(.*)""")]
        public void WhenViewEditMemberPageAddressFieldIsSetTo(string p0, string p1)
        {
            IWebElement txt = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtPAdd1"));
            txt.Clear();
            txt.SendKeys(p1);
            tmsWait.Hard(5);
        }


        [Then(@"Verify View Edit Member page Class is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageClassIsSetTo(string p0)
        {
            string fieldName = " Class ";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = new SelectElement(EAM.MemberInformation.MemberInfoClass).SelectedOption.Text;

            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }


        [Then(@"Verify Member Info page OEC Sales tab Institution Phone field is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageOECSalesTabInstitutionPhoneFieldIsSetTo(string p0)
        {
            string fieldName = "OEC Sales Tab Inst Phone";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MemberInformation.MemberInfoOECSalesInstPhone.GetAttribute("value");

            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }


        [Then(@"OEC Sales tab Institution Address field is set to ""(.*)""")]
        public void ThenOECSalesTabInstitutionAddressFieldIsSetTo(string p0)
        {
            string fieldvalue = tmsCommon.GenerateData(p0);
            EAM.MemberInformation.MemberInfoOECSalesInstAddress.SendKeys(fieldvalue);
        }

        [Then(@"OEC Sales tab Institution Phone field is set to ""(.*)""")]
        public void ThenOECSalesTabInstitutionPhoneFieldIsSetTo(string p0)
        {
            string fieldvalue = tmsCommon.GenerateData(p0);
            EAM.MemberInformation.MemberInfoOECSalesInstPhone.SendKeys(fieldvalue);
        }


        [Then(@"Verify Member Info Page RX Biling tab Employer Group Name is set to ""(.*)""")]
        public void ThenVerifyMemberInfoPageRXBilingTabEmployerGroupNameIsSetTo(string p0)
        {
            string fieldName = "Employer Group Name";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MemberInformation.EmployerGroupName.GetAttribute("value");

            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [Then(@"Members View Edit Table has no row")]
        public void ThenMembersViewEditTableHasNoRow()
        {
            tmsWait.Hard(10);
            By ele;
            bool elementDisplay;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                //ele = By.XPath("//td[contains(.,'No records available.')]");
                //elementDisplay = Browser.Wd.FindElement(ele).Enabled;
                //Assert.IsTrue(elementDisplay, " Element is displayed");
                //tmsWait.Hard(5);
                //ReUsableFunctions.clickOnWebElement(cfEAMTC90.TC90DrugEditTC.CancelButton);
            }
            else
            {
                ele = By.XPath("//span[contains(.,'No items to display')]");
                elementDisplay = Browser.Wd.FindElement(ele).Displayed;
                Assert.IsTrue(elementDisplay, " Element is displayed");
                tmsWait.Hard(5);
                ReUsableFunctions.clickOnWebElement(cfEAMTC90.TC90DrugEditTC.CancelButton);

            }
        }
    }
}
