﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using TechTalk.SpecFlow;

using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using System.Diagnostics;
using System.Windows;


namespace TMSoR1
{
    [Binding]
    public class MembersSearch
    {
        public IWebElement HICNumber { get { return Browser.Wd.FindElement(By.CssSelector("input[placeholder='Add MBI']")); } }
              //public IWebElement HICNumber { get { return Browser.Wd.FindElement(By.XPath(".//*[contains(@id,'txtHic')]")); } }
        
        public IWebElement FirstName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='transSearch-input-firstName']")); } }
        public IWebElement LastName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='transSearch-input-lastName']")); } }
        public IWebElement MemberID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtMemID")); } }
        public IWebElement MI { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtMI")); } }
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPlan")); } }
        public IWebElement PBPID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPBP")); } }
        public IWebElement MemberStatus { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboStatus")); } }
        public IWebElement ProgramSource { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboProgramSource")); } }
        public IWebElement Search { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberSearch-btn-search']")); } }
        //   public IWebElement Search { get { return Browser.Wd.FindElement(By.XPath(".//*[contains(@id, 'cmdSearch')]")); } }

       // public IWebElement MemberSearchTable { get { return Browser.Wd.FindElement(By.XPath("//table[contains(@id, 'dgMember')]")); } }
        public IWebElement MemberSearchTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dgMember")); } }
        public IWebElement ViewEditPlanInfoTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dgPlan")); } }
        public IWebElement TransactionSearchTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dgTrans")); } }
        public IWebElement MemberSearchResultStaticText { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblreturn")); } }

        public IWebElement SearchTabletest { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_gridPanel")); } }

        public IWebElement TransIDText { get { return Browser.Wd.FindElement(By.XPath("//*[@id='ctl00_ctl00_MainMasterContent_MainContent_ucTransHistory_dgHistory']/tbody/tr[2]/td[2]")); } }
    }
    [Binding]
    public class MembersNew
    {
        public IWebElement TransactionTabStaticMsg { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucTransHistory_lblMsg")); } }
        public IWebElement TRRStaticMsg { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucTrrInfo_lblTrrMsg")); } }
        public IWebElement EGHP { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_chkEGHP")); } }
        public IWebElement HICNumber { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtHic_01")); } }
        public IWebElement MemberID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtMemberID_43")); } }
        public IWebElement FirstName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtFName_03")); } }
        public IWebElement MI { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtMI")); } }
        public IWebElement LastName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtLName_02")); } }
        public IWebElement Appel { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtAppel")); } }
        public IWebElement DOB { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtDOB_06")); } }
        public IWebElement Sex { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboSex_05")); } }
        public IWebElement SSN { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtSSN")); } }
        public IWebElement Plan1 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtPlan1")); } }
        public IWebElement Group { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboGroup")); } }
        public IWebElement SubGroup { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboSubGroup")); } }
        public IWebElement Class { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboClass")); } }
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPlanID_10")); } }
        public IWebElement PBP { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPBP_08")); } }
        public IWebElement SegID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboSegment_99")); } }
        public IWebElement EffectiveDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtEffDate_14")); } }
        public IWebElement EffectiveDatePicker { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtEffDate_Img")); } }
        public IWebElement TermDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtTermDate")); } }
        public IWebElement LatestElectType { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboElections")); } }
        public IWebElement IPAGroupID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtIPAGrpID")); } }
        public IWebElement IPAGroupIDLink { get { return Browser.Wd.FindElement(By.Name("lnk_IPA_Lookup")); } }
        public IWebElement PartDOptOut { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPartDOptOut")); } }
        public IWebElement RXID { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='memberRxDetails-inpu-rxid']")); } }
        public IWebElement RXGroup { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtRxGroup_38")); } }
        public IWebElement SCC { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_scc_id")); } }
        public IWebElement CountyName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtCountyName_44")); } }
        public IWebElement MaritalStatus { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboMaritalStatus")); } }
        public IWebElement Language { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboLanguage")); } }
        public IWebElement Race { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_drpRace")); } }
        public IWebElement DOD { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtDOD")); } }
        public IWebElement Sal { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtSalutation")); } }
        public IWebElement MedicaidNumber { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtMedicaidNum")); } }
        public IWebElement RXBIN { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtRXBIN_36")); } }
        public IWebElement RXPCN { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtRXPCN_37")); } }
        public IWebElement Plan2 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtPlan2")); } }
        public IWebElement Plan3 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtPlan3")); } }
        public IWebElement Plan4 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtPlan4")); } }
        public IWebElement Plan5 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtPlan5")); } }
        public IWebElement Search { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSearch")); } }
        public IWebElement Reset { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnNew")); } }
        public IWebElement New { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnNew")); } }
        public IWebElement Save { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSave")); } }
        public IWebElement Plan1Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblPlan1")); } }
        public IWebElement Plan2Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblPlan2")); } }
        public IWebElement Plan3Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblPlan3")); } }
        public IWebElement Plan4Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblPlan4")); } }
        public IWebElement Plan5Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblPlan5")); } }
        public IWebElement StaticMessage { get { return Browser.Wd.FindElement(By.ClassName("ctl00_ctl00_MainMasterContent_MainContent_messageText")); } }
        public IWebElement ResponseMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblMsg")); } }
        public IWebElement MemberStatus { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblStatus"));  } }
        public IWebElement ViewAuditHistoryButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ibtnAuditHistory")); } }
        public IWebElement Status { get { return Browser.Wd.FindElement(By.XPath("//span[@test-id='memberInfo-span-memberStatus']")); } }
        public IWebElement RecordSource { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblRecSource"));  } }
        public IWebElement SummaryDetails { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ValidationSummary1")); } }
        public IWebElement UserEntered { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblUserCreated")); } }
        public IWebElement HistoryTab { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnIDHistory")); } }
        public IWebElement HistoryTabContents { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucIDHistory_lblMsg"));  } }
        public IWebElement HelpIcon { get { return Browser.Wd.FindElement(By.PartialLinkText("Help"));  } }
        public IWebElement HomeIcon { get { return Browser.Wd.FindElement(By.XPath("//a[contains(@href,'/PDMWeb/EENRL/Home.aspx?')]")); }}
        public IWebElement ChangePwdIcon { get { return Browser.Wd.FindElement(By.XPath("//a[contains(@href,'/PDMWeb/EENRL/ChangePassword.aspx')]")); } }
        public IWebElement OldPassword { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_oldPassword"));  } }
        public IWebElement NewPassword { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_newPassword")); } }
        public IWebElement ConfirmdPassword { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_confirmPassword"));  } }
        public IWebElement PwdSubmitBtn { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Submit")); } }
        public IWebElement PwdChgConfm { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Span1"));  } }
        public IWebElement PwdChgFailed { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_NewPasswordCompare")); } }
        public IWebElement PwdCancelBtn { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Cancel")); } }
        public IWebElement DbNameDisplay { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='HeaderTop']/div[1]")); } }
        public IWebElement UserNameDisplay { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='HeaderTop']/div[2]")); } }
        public IWebElement SexPopUp { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_GlossaryIconButton2")); } }
        public IWebElement SexPopUpDlg { get { return Browser.Wd.FindElement(By.Id("cboSex_05_glossaryPanel")); } }
        public IWebElement SexPopUpTable { get {  return Browser.Wd.FindElement(By.XPath("//table[contains(@id,'cboSex_05_glossaryPanel')]"));} }
        public IWebElement SexPopupClose { get { return Browser.Wd.FindElement(By.XPath("//*[@id='aspnetForm']/div[5]/div[1]/a/span")); } }
        public IWebElement AddAttachment { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_memberDocumentsButton")); } }
        public IWebElement MemberAttchPopup { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_memberDocuments_memberDocumentsDialogPnl")); } }
        public IWebElement AttachBtn { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_memberDocuments_attachButton")); } }
        public IWebElement DocBrowse { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_memberDocuments_attachDocumentDialog_mbrDocUploadfile0")); } }
        public IWebElement DocUpload { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_memberDocuments_attachDocumentDialog_uploadButton"));  } }
        public IWebElement SuccessfulUploadMsg { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_memberDocuments_attachDocumentDialog_uploadMessageBoxDialog_messageText")); } }
        public IWebElement UploadFileClose { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_memberDocuments_attachDocumentDialog_uploadMessageBoxDialog_closeButton"));  } }
        public IWebElement MemberDocClose { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_memberDocuments_closeButton"));  } }
        public IWebElement MemberDocTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_memberDocuments_MemberDocumentsGrid_ctl00"));  } }
        public IWebElement ElectionTypePopUp { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_GlossaryIconButton1")); } }
        public IWebElement ElectionTypeDlg { get { return Browser.Wd.FindElement(By.Id("cboElections_glossaryPanel")); } }
        public IWebElement ElectionTypeTable { get { return Browser.Wd.FindElement(By.XPath("//table[contains(@id,'cboElections_glossaryPanel')]")); } }
        public IWebElement ElectionTypePopupClose { get { return Browser.Wd.FindElement(By.XPath("//a[@role='button']")); } }
        public IWebElement NewMemberActionLink { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lnk_AddAction")); } }
        public IWebElement MaritalStatuspopup { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_GlossaryIconButton3")); } }
        public IWebElement MaritalStatusDlg { get { return Browser.Wd.FindElement(By.Id("cboMaritalStatus_glossaryPanel")); } }
        public IWebElement MaritalStatusTable { get { return Browser.Wd.FindElement(By.XPath("//table[contains(@id,'cboMaritalStatus_glossaryPanel')]")); } }
        public IWebElement MaritalStatusTitleBar { get { return Browser.Wd.FindElement(By.XPath("//*[@id='aspnetForm']/div[8]/div[1]")); } }
        public IWebElement MaritalstatuspopupClose { get { return Browser.Wd.FindElement(By.XPath("(//a[@role='button'])[2]")); } }
        public IWebElement RacePopupBtn { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_GlossaryIconButton4")); } }
        public IWebElement RacePopDlg { get { return Browser.Wd.FindElement(By.Id("drpRace_glossaryPanel")); } }
        public IWebElement RacePopClose { get { return Browser.Wd.FindElement(By.XPath("(//a[@role='button'])[3]")); } }
        public IWebElement NoNotesMessage { get { return Browser.Wd.FindElement(By.XPath("//*[@id='Notes1_lblNote']")); } }
        public IWebElement NoActionsMessage { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='Notes1_lblAction']")); } }
        public IWebElement CloseBtnMembersNew { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='Form1']/table/tbody/tr[2]/td[2]/table/tbody/tr[12]/td/input")); } }
        public IWebElement SNPIcon { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ibtnSnp")); } }
        public IWebElement SNPIconToolTip { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ibtnSnp"));  } }
        public IWebElement SNPActivityDialog { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_snpDialog_snpDialog"));  } }
        public IWebElement SNPAddNewSuspectBtn { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_snpDialog_addNewSuspectButton")); } }
        public IWebElement SNPFollowAct { get { return Browser.Wd.FindElement(By.Id("ui-dialog-title-ctl00_ctl00_MainMasterContent_MainContent_snpDialog_snpDialog"));  } }
        public IWebElement SNPVerificationDt { get { return Browser.Wd.FindElement(By.XPath("//input[contains(@id, 'ctl00_ctl00_MainMasterContent_MainContent_snpDialog_txtVerificationDate')]")); } }
        public IWebElement AddActionDueDate { get { return Browser.Wd.FindElement(By.XPath("//input[(@id='txtDueDate')]")); } }
        public IWebElement AddActionText { get { return Browser.Wd.FindElement(By.XPath("//*[(@id='txtAction')]")); } }

        public IWebElement SNPStatus { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_snpDialog_ddlSnpStatus")); } }
        public IWebElement FollowUp { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_snpDialog_ddlFollowup")); } }
        public IWebElement SNPFollowUpDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_snpDialog_txtFollowupDate")); } }
        public IWebElement SNPLetterQueue { get { return Browser.Wd.FindElement(By.XPath("//@test-id='snp-chk-queueLossOfSnp'")); } }
        public IWebElement SNPActionSave { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_snpDialog_btnSavSNP")); } }
        public IWebElement ActionDialog_AddAction{ get { return Browser.Wd.FindElement(By.Id("cmdAdd")); } }
        public IWebElement ActionDialog_Close{ get { return Browser.Wd.FindElement(By.XPath("//*[@name='cmdClose']")); } }
        public IWebElement SNPLettersSlidingPane { get { return Browser.Wd.FindElement(By.Id("RAD_SLIDING_PANE_TEXT_ctl00_ctl00_MainMasterContent_MainContent_snpDialog_lettersSlidingPane")); } }
        public IWebElement SNPActionsSlidingPane { get { return Browser.Wd.FindElement(By.Id("RAD_SLIDING_PANE_TEXT_ctl00_ctl00_MainMasterContent_MainContent_snpDialog_actionsSlidingPane")); } }
        public IWebElement SNPGenerateLetterLink { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_snpDialog_navigateToPreviewHyperLink"));  } }
        public IWebElement SNPCompleteActionBtn { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_snpDialog_activeAction_ctl00_ctl04_gbcCompleteAction")); } }
        public IWebElement SNPCompleteAction { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_snpDialog_activeAction_ctl00_ctl04_gbcCompleteAction")); } }
        public IWebElement SNPActivityDlgClose { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_snpDialog_btnClose")); } }
        public IWebElement SNPFollowUpClose { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_snpDialog_btnClose")); } }
        public IWebElement MemberOOAIcon {  get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_iMageButtonOOA")); } }
        public IWebElement MemberOOAAddNewSuspect { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_outOfAreaDialog_addNewSuspectButton")); } }
        public IWebElement MemberPotentialOOA_Checkbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_outOfAreaDialog_cbOutOfArea")); } }
        public IWebElement MemberPossibleSCC_Checkbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_outOfAreaDialog_cbPossibleSCC")); } }
        public IWebElement MemberPotentialOOALetter_Checkbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_outOfAreaDialog_cbLetterQueue")); } }
        public IWebElement MemberOOAContinuingArea_Checkbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_outOfAreaDialog_cbContinuingArea")); } }
        public IWebElement MemberOOATravelerVisitorsProgram_Checkbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_outOfAreaDialog_cbTravelerVisitorsProgram")); } }
        public IWebElement MemberOOAICEPConversion_Checkbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_outOfAreaDialog_cbICEPConversion")); } }
        public IWebElement MemberOOASuspectStatus { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_outOfAreaDialog_ooaSuspectStatusesDdl")); } }
        public IWebElement MemebrOOASaveButton {  get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_outOfAreaDialog_btnSaveOOA")); } }
        public IWebElement MemberOOAClosebutton {  get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_outOfAreaDialog_btnClose")); } }
        public IWebElement AddNewActionDialog { get { return Browser.Wd.FindElement(By.Id("txtAction")); } }

    }


    [Binding]
    public class MembersNewTabSpans
    {
        public IWebElement SpansTabLink { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSpans")); } }

        public IWebElement EFF { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberSpans_btnEff")); } }

        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberSpans_drpPlanID")); } }
        public IWebElement StatusType { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberSpans_drpStatus")); } }
        public IWebElement Value { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberSpans_txtValue")); } }
        public IWebElement StartDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberSpans_txtStart")); } }
        public IWebElement EndDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberSpans_txtEnd")); } }

        public IWebElement SaveButton { get { return Browser.Wd.FindElement(By.XPath("//*[@id='ctl00_ctl00_MainMasterContent_MainContent_ucMemberSpans_btnAdd' or @id='ctl00_ctl00_MainMasterContent_MainContent_ucMemberSpans_btnSave']")); } }

        public IWebElement SpansTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberSpans_dgHistory")); } }

        public IWebElement StaticMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberSpans_lblMessage")); } }
    }
    [Binding]
    public class MembersNewTabEligibility
    {
        public IWebElement EligibilityTabLink { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnStatus")); } }
        public IWebElement PlanPartAEff { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberStatus_txtPlanPartA")); } }
        public IWebElement PlanPartBEff { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberStatus_txtPlanPartB")); } }
        public IWebElement CMSPartAEnd { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberStatus_txtCMSPartAEnd")); } }
        
    }
    public class MembersNewTabTransactions
    {
        public IWebElement TransactionsTabLink { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnTransactions")); } }
        public IWebElement TransactionsTab { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnTransactions")); } }
        public IWebElement TransactionsTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucTransHistory_dgHistory")); } }
      //  public IWebElement AddNewTransactionLink { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucTransHistory_LinkButton1")); } }
        public IWebElement AddNewTransactionLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='transactions-link-AddTransaction']")); } }
        public IWebElement TRCDetailPopUp { get { return Browser.Wd.FindElement(By.XPath("//div[contains(@id, 'ucTransHistory_Panel2')]")); } }
        public IWebElement TRCDetailPopUpTRRCode { get { return Browser.Wd.FindElement(By.XPath("//input[contains(@id, 'ucTransHistory_txtSearch')]")); } }
        public IWebElement TRCDetailPopUpCodeName { get { return Browser.Wd.FindElement(By.XPath("//input[contains(@id, 'ucTransHistory_txtCodeName')]")); } }
        public IWebElement TRCDetailPopUpCodeType { get { return Browser.Wd.FindElement(By.XPath("//select[contains(@id, 'ucTransHistory_DropdownCodeType')]")); } }
        public IWebElement TRCDetailPopUpCodeDescription { get { return Browser.Wd.FindElement(By.XPath("//input[contains(@id, 'ucTransHistory_txtCodeDescription')]")); } }
        public IWebElement TRCDetailPopUpSearchLink { get { return Browser.Wd.FindElement(By.XPath("//a[contains(@id, 'ucTransHistory_lnkSearch')]")); } }
        public IWebElement TRCDetailPopUpResetLink { get { return Browser.Wd.FindElement(By.XPath("//a[contains(@id, 'ucTransHistory_lnkReset')]")); } }
        public IWebElement TRCDetailPopUpTable { get { return Browser.Wd.FindElement(By.XPath("//table[contains(@id, 'ucTransHistory_GVShortTrr')]")); } }
        public IWebElement TRCDetailPopUpTRRDetailTable { get { return Browser.Wd.FindElement(By.XPath("//table[contains(@id, 'ucTransHistory_DetailViewTrr')]")); } }
        public By          TRCDetailPopUpTRRDetailTableBy { get { return By.XPath("//table[contains(@id, 'ucTransHistory_DetailViewTrr')]"); } }

        public IWebElement TRCDetailPopUpCloseButton { get { return Browser.Wd.FindElement(By.XPath("//input[contains(@id, 'ucTransHistory_btnclose')]")); } }
        public IWebElement TRCDetailPopUpTopCloseButton { get { return Browser.Wd.FindElement(By.XPath("//table[contains(@id, 'ucTransHistory_TopCloseButton')]")); } }

        public IWebElement TRCDetailDescription { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucTransHistory_DetailViewTrr")); } }
    }
    public class MembersNewTabCorrespondence
    {
        public IWebElement CorrespondenceTabLink { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnCorrespondence")); } }
        public IWebElement CorrespondenceTabTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucCorrespondence_gvCORR")); } }
        public IWebElement CorrespondenceLetterName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucCorrespondence_ddlLetterTypes")); } }
        public IWebElement CorrespondenceHistory { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucCorrespondence_gvCORR")); } }
        public IWebElement AddTransactionBtn {  get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucCorrespondence_btnAddTransaction")); } }
        public IWebElement SelectFirstTrans {  get { return Browser.Wd.FindElement(By.XPath("(//table[@id='ctl00_ctl00_MainMasterContent_MainContent_ucCorrespondence_dgMemberTransactions']//input[@type='checkbox'])[1]")); } }
        public IWebElement AddQeueuBtn {  get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucCorrespondence_btnAddToQueueTrans")); } }
        public IWebElement LetterQueuedMsg {  get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucCorrespondence_lblMessage")); } }

    }
    public class MembersNewTabIDHistory
    {
        public IWebElement IDHistoryTabLink { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnIDHistory")); } }
        public IWebElement HistoryTable { get { return Browser.Wd.FindElement(By.XPath("//table[contains(@id, 'ucIDHistory_dgHistory')]")); } }
    }
    public class MembersNewTabRXBilling
    {
        public IWebElement RXBillingTabLink { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnBilling")); } }

        public IWebElement PartCPremium { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_txtPartC")); } }
        public IWebElement PartDPremium { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_txtPartD")); } }
        public IWebElement BillAmount { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_txtAmount")); } }
        public IWebElement PWOption { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_drpPremium")); } }
                                                                                   
        public IWebElement CreditCover { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_cboCreditCov")); } }
        public IWebElement UncoveredMonths { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_txtUnCovMons")); } }                                                                                       
        public IWebElement EmployerSubsOver { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_chkEmpSubsOver")); } }
        public IWebElement BillEffDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_txtBillingEffDate")); } }

        public IWebElement LEPAmt { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_txtLepAmt")); } }
        public IWebElement LEPWaivedAmt { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_txtLepWaived")); } }
        public IWebElement LEPSubsAmt { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_txtLepSubsAmt")); } }
        public IWebElement EmployerPaysLEP { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_chkEGPaysLEP")); } }

        public IWebElement SecondDrugInsFlag { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_chkDrugInsurFlag")); } }
        public IWebElement SecRxID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_txtRXid")); } }
        public IWebElement SecRxGroup { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_txtRXGroup")); } }
        public IWebElement SecBIN { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_txt2ndBIN")); } }

        public IWebElement EmployerGroupNumber { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_empGrpNumber_Input")); } }
        public IWebElement EmployerGroupNumberEditIcon { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_editEmplGroup")); } }
        public IWebElement EmployerName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_txtEmployer")); } }
        public IWebElement OtherInsName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_txtOtherInsur")); } }
        public IWebElement SecondPCN { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_txt2ndPCN")); } }

        public IWebElement MedicalID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_drpMedical")); } }
        public IWebElement PharmacyID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_drpPharmacy")); } }
        public IWebElement DentalID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_drpDental")); } }
        public IWebElement VisionID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_drpVision")); } }

        public IWebElement LISLevel { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_cboSubSidyLevel")); } }
        public IWebElement CoPayCat { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_cboCoPayCat")); } }
        public IWebElement StartDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_txtCoPayEffDate")); } }
        public IWebElement EndDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_txtCoPayEndDate")); } }
        public IWebElement LISType { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_cboLISType")); } }

        public IWebElement SaveButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_btnSave")); } }
        public IWebElement Response { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_lblMsg")); } }

        public IWebElement LISTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_RsGrid")); } }
        public IWebElement EditLISTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_GV_EditLIS")); } }


    }
    public class MembersNewTabOECSales
    {
        public IWebElement OECSalesTabLink { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnOECSales")); } }
        public IWebElement OECNewMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucOECSales_lblMsg")); } }
        public IWebElement OECSaleTable { get { return Browser.Wd.FindElement(By.Id("Table1")); } }

        public IWebElement OECFileNumber { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucOECSales_txtOECFileNumber")); } }
        public IWebElement OECFileDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucOECSales_txtOECFileDate")); } }
        public IWebElement OECSubmitTime { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucOECSales_txtOECSubmitTime")); } }
        public IWebElement OECCounty { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucOECSales_txtOECcounty")); } }

        public IWebElement MemberOtherIns { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucOECSales_cboOtherIns")); } }
        public IWebElement OtherInsID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucOECSales_txtOtherInsID")); } }
        public IWebElement OtherInsGrp { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucOECSales_txtOtherInsGrp")); } }

        public IWebElement MemberLongTerm { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucOECSales_cboLongTerm")); } }
        public IWebElement InstitutionName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucOECSales_txtInstName")); } }
        public IWebElement InstitutionAddress { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucOECSales_txtInstAddress")); } }
        public IWebElement InstitutionPhone { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucOECSales_txtInstPhone")); } }

        public IWebElement EmailAddress { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucOECSales_txtEmail")); } }
        public IWebElement MemberESRD { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucOECSales_cboESRD")); } }
        public IWebElement MemberMCaid { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucOECSales_cboMCaid")); } }
        public IWebElement MemberWorking { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucOECSales_cboWA")); } }

        public IWebElement SEPReason { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucOECSales_txtSEPReason")); } }
        public IWebElement SEPCMSReasonCode { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucOECSales_txtSEPCMSID")); } }
        public IWebElement SalesRep { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucOECSales_RadComboBox1_Input")); } }
        public IWebElement SalesLocation { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucOECSales_txtSalesLocation")); } }
        public IWebElement SalesDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucOECSales_txtSalesDate")); } }
        public IWebElement SalesDropDownList { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucOECSales_RadComboBox1_DropDown")); } }
        public IWebElement SalesDropDownListArrow { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucOECSales_RadComboBox1_Image")); } }


    }
    public class MembersNewTabProvider
    {
        public IWebElement ProviderTabLink { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnProvider")); } }
        public IWebElement ProviderTabTable { get { return Browser.Wd.FindElement(By.Id("Table1")); } }

        public IWebElement FirstName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucProviderInfo_txtPCPFName")); } }
        public IWebElement LastName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucProviderInfo_txtPCPLName")); } }

        public IWebElement PCPID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucProviderInfo_txtPCPid")); } }
        public IWebElement PCPPrvID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucProviderInfo_txtPCPProvid")); } }

        public IWebElement HospName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucProviderInfo_txtHospital")); } }
        public IWebElement GynName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucProviderInfo_txtGynPCPName")); } }
        public IWebElement MPName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucProviderInfo_txtMPName")); } }
        public IWebElement DentalName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucProviderInfo_txtDentPCPName")); } }
        public IWebElement MedicalRec { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucProviderInfo_txtMedRecNo")); } }

        public IWebElement HospID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucProviderInfo_txtHospitalid")); } }
        public IWebElement GynPCPID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucProviderInfo_txtGynPCPid")); } }
        public IWebElement MPID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucProviderInfo_txtMPid")); } }
        public IWebElement DentalID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucProviderInfo_txtDentPCPid")); } }

        public IWebElement HospPrvID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucProviderInfo_txtHospitalProvid")); } }
        public IWebElement GynPCPPrv { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucProviderInfo_txtGynPCPProvid")); } }
        public IWebElement MPPrv { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucProviderInfo_txtMPProvid")); } }
        public IWebElement DentalPrv { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucProviderInfo_txtDentPCPProvid")); } }
    }
    public class MembersNewTabContact
    {
        public IWebElement ContactTabLink { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnContact")); } }

        public IWebElement AddressType { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_drpAddType1")); } }
        public IWebElement AddressType2 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_drpAddType2")); } }
        public IWebElement Address1 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtPAdd1")); } }
        public IWebElement Address2 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtPAdd2")); } }
        public IWebElement City { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtPCity")); } }
        public IWebElement State { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtPState")); } }
        public IWebElement Zip { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtPZip")); } }
        public IWebElement County { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_ddlCounty")); } }
        public IWebElement SCC { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtScc")); } }

        public IWebElement SecondAddressType { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_drpAddType2")); } }
        public IWebElement SecondAddress1 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtMAdd1")); } }
        public IWebElement SecondAddress2 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtMAdd2")); } }
        public IWebElement SecondCity { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtMCity")); } }
        public IWebElement SecondState { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtMState")); } }
        public IWebElement SecondZip { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtMZip")); } }

        public IWebElement Phone { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtPhone")); } }
        public IWebElement SecondPhone { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtPhone2")); } }

        public IWebElement DecisionResponsibility { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_cboResponsibility")); } }
        public IWebElement ResponsibilityName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtRespName")); } }
        public IWebElement ResponsAddress { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtResponsAdd1")); } }
        public IWebElement ResponsCity { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtRespCity")); } }
        public IWebElement ResponsState { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtRespState")); } }
        public IWebElement Responszip { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtRespZip")); } }

        public IWebElement ResponsRelation { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_cboResponsRel")); } }
        public IWebElement EmergContact { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtEmergContact")); } }
        public IWebElement EmergRelation { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtEmergRel")); } }
        public IWebElement EmergPhone { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtContact")); } }
        public IWebElement ResponsPhone { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtRespPhone")); } }
        public IWebElement StaticMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_lblMsg")); } }

    }

    public class MembersViewEditSpansTab
    {
        public IWebElement SpansTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberSpans_dgHistory")); } }
        public IWebElement EFFButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberSpans_btnEff")); } }
    }

    public class MembersViewEditEligibilityTab
    {
        public IWebElement CountryCode { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberStatus_txtCC")); } }
        public IWebElement StateCode { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberStatus_txtSCC")); } }
        public IWebElement DateOfDeath { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberStatus_txtCMSDOD")); } }
        public IWebElement ESRD { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberStatus_txtESRD")); } }
        public IWebElement CMSPartAEff { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberStatus_txtCMSPartA")); } }
        public IWebElement CMSPartAEnd { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberStatus_txtCMSPartAEnd")); } }
        public IWebElement CMSPartBEff { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberStatus_txtCMSPartB")); } }
        public IWebElement CMSPartBEnd { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberStatus_txtCMSPartBEnd")); } }
        public IWebElement PlanId { get { return Browser.Wd.FindElement(By.Id("ctl00_MainMasterContent_PLAN_ID")); } }

        public IWebElement BEQRequested { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberStatus_txtDateReque")); } }
        public IWebElement PossibleNUNCMo { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberStatus_txtPossibleNUNCMo")); } }


    }

    public class MembersViewEditTransactionsTab
    {
        public IWebElement TransactionsTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucTransHistory_dgHistory")); } }
    }
    public class MembersNewTabPayment
    {
        public IWebElement PaymentTabLink { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnPayment")); } }
        public IWebElement PaymentDataTable { get { return Browser.Wd.FindElement(By.Id("Table1")); } }

        public IWebElement ContractType { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_txtContractType")); } }
        public IWebElement BillingMethod { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_txtBillMethod")); } }
        public IWebElement PaymentMethod { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_txtPayMethod")); } }
        public IWebElement SuppressStmt { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_chkSupprStmt")); } }
        public IWebElement SuppressDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_txtSupprDate")); } }

        public IWebElement AccountNbr { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_txtAccNum")); } }
        public IWebElement Payor { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_txtPayor")); } }

        public IWebElement Bank { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_txtBank")); } }
        public IWebElement AccountType { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_cboAccType")); } }
        public IWebElement BankAcctType { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_cboBankAccType")); } }
        public IWebElement TrusteeRouting { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_txtRoutingNum")); } }
        public IWebElement BankACHNbr { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_txtBankACHNum")); } }

        public IWebElement CardExpiration { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_txtCardExpDate")); } }
        public IWebElement BillingProfileID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_txtBillingEntity")); } }

        public IWebElement SendPlan10OnLegacy { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_chkPlan10")); } }

        public IWebElement Plan6 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_txtPlan6")); } }
        public IWebElement Plan7 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_txtPlan7")); } }
        public IWebElement Plan8 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_txtPlan8")); } }
        public IWebElement Plan9 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_txtPlan9")); } }
        public IWebElement Plan10 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_txtPlan10")); } }

        public IWebElement Plan6Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_lblPlan6")); } }
        public IWebElement Plan7Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_lblPlan7")); } }
        public IWebElement Plan8Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_lblPlan8")); } }
        public IWebElement Plan9Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_lblPlan9")); } }
        public IWebElement Plan10Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_lblPlan10")); } }
    }

    public class MembersNewMemberAuditHistory
    {
        public IWebElement FullName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAuditDialog_lblFullName")); } }
        public IWebElement HIC { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAuditDialog_lblHic")); } }
        public IWebElement Gender { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAuditDialog_lblGender")); } }
        public IWebElement DOB { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAuditDialog_lblDateOfBirth")); } }
        public IWebElement Plan { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAuditDialog_lblPlan")); } }

        public IWebElement PBP { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAuditDialog_lblPbp")); } }
        public IWebElement Activity { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAuditDialog_rcbActivity_P")); } }
        public IWebElement ActivityDropDown { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAuditDialog_rcbActivity_DropDown")); } }
        public IWebElement DateFrom { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAuditDialog_rmtbxDateFrom")); } }

        public IWebElement ReturnAction { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAuditDialog_rcbReturnAction_P")); } }
        public IWebElement ReturnActionDropDown { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAuditDialog_rcbReturnAction_DropDown")); } }
        public IWebElement DateThru { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAuditDialog_rmtbxDateThru")); } }
        public IWebElement RunButton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='audit-btn-search']")); } }
        public IWebElement ClearButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAuditDialog_btnClear")); } }
        public IWebElement ResultTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAuditDialog_rgrdFilterResult_ctl00")); } }
        public IWebElement ResultTableHeader { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAuditDialog_rgrdFilterResult_ctl00_Header")); } }
        public IWebElement CloseButton { get { return Browser.Wd.FindElement(By.XPath("//div[contains(.,'Member Audit History')]/a/span")); } }

    }

    


}


