﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1
{
    class cfTransactionSearch
    {
        public static TransactionSearch TransactionSearch { get { return new TransactionSearch(); } }
    }

   


    [Binding]
    public class TransactionSearch
    {
        public IWebElement SearchPageText { get { return Browser.Wd.FindElement(By.XPath("//div[@id='eamBodyContainer']/p")); } }
     
    }
}
