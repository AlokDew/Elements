﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1
{
    [Binding]
    class cfEAMMODReports
    {

        public static EAMMODReports EAMMODReports { get { return new EAMMODReports(); } }
        public static CodeLevelDetailsReport CodeLevelDetailsReport { get { return new CodeLevelDetailsReport(); } }
        public static OECEAFReport OECEAFReport { get { return new OECEAFReport(); } }
        public static TransactionsMissingCMSData TransactionsMissingCMSData { get { return new TransactionsMissingCMSData(); } }

    }
    [Binding]
    public class TransactionsMissingCMSData
    {
        public IWebElement FileName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='file_name']")); } }
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Planid']")); } }
        public IWebElement PBPID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PBPID']")); } }
    }

    [Binding]
    public class OECEAFReport
    {
        public IWebElement FileName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='FileName']")); } }
    }
    [Binding]
    public class EAMMODReports
    {
        public IWebElement EAMReportsLink { get { return Browser.Wd.FindElement(By.XPath("//a[@id='ctl00_ctl00_MainMasterContent_EamNavigation_uiModReportsHyperLink']")); } }
        public IWebElement EAMImportsLink { get { return Browser.Wd.FindElement(By.XPath("//a[@id='ctl00_ctl00_MainMasterContent_EamNavigation_importHyperlink']")); } }
        public IWebElement EAMExportsLink { get { return Browser.Wd.FindElement(By.XPath("//a[@id='ctl00_ctl00_MainMasterContent_EamNavigation_uiModExportHyperLink']")); }
        //public IWebElement EAMExportsLink { get { return Browser.Wd.FindElement(By.XPath("//a[@id='ctl00_ctl00_MainMasterContent_EamNavigation_uiModExportHyperLink']")); } }
    }
    }


    [Binding]
    public class CodeLevelDetailsReport
    {
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PlanID']")); } }
        public IWebElement TRRMonth { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='TRR_Month']")); } }
        public IWebElement TRRStartDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='TRRStartDate']")); } }
        public IWebElement TRREndDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='TRREndDate']")); } }
        

    }

}
