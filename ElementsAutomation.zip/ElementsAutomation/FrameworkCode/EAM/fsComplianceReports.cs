﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TechTalk.SpecFlow;
using System.Collections.ObjectModel;
using OpenQA.Selenium;
using TMSoR1.FrameworkCode;
using System.IO;
namespace TMSoR1
{
    [Binding]
    class fsComplianceReports
    {

        [Then(@"Quarterly Disenrollment Compliance Report page Total_Voluntary_Disenrollments_Received column count is noted as ""(.*)""")]
        public void ThenQuarterlyDisenrollmentComplianceReportPageTotal_Voluntary_Disenrollments_ReceivedColumnCountIsNotedAs(string p0)
        {

            string colATotalcount = cfComplianceReport.QuarterlyDisEnrollmentReport.Total_Voluntary_Disenrollments_Received_A_Column_Total.Text;
            // Assigning value to Variable
            fw.setVariable(p0, colATotalcount);

            fw.ConsoleReport(p0 + " count " + colATotalcount);
        }

        [Then(@"Quarterly Disenrollment Compliance Report page Disenrollments Complete at the Time of Initial Receipt column count is noted as ""(.*)""")]
        public void ThenQuarterlyDisenrollmentComplianceReportPageDisenrollmentsCompleteAtTheTimeOfInitialReceiptColumnCountIsNotedAs(string p0)
        {
            string colBTotalcount = cfComplianceReport.QuarterlyDisEnrollmentReport.Disenrollments_Complete_atthe_Time_of_Initial_Receipt_B_Column_Total.Text;
            // Assigning value to Variable
            fw.setVariable(p0, colBTotalcount);

            fw.ConsoleReport(p0 + " count " + colBTotalcount);
        }


        [Then(@"Quarterly Disenrollment Compliance Report page Total_Disenrollments_Denied_by_the_Sponsor column count is noted as ""(.*)""")]
        public void ThenQuarterlyDisenrollmentComplianceReportPageTotal_Disenrollments_Denied_By_The_SponsorColumnCountIsNotedAs(string p0)
        {
            string colCTotalcount = cfComplianceReport.QuarterlyDisEnrollmentReport.Disenrollments_Denied_by_the_Sponsor_for_Any_Reason_C_PartC_Column_Total.Text;
            // Assigning value to Variable
            fw.setVariable(p0, colCTotalcount);

            fw.ConsoleReport(p0 + " count " + colCTotalcount);
        }

        [Then(@"Quarterly Disenrollment Compliance Report page Disenrollments Total_Involuntary_Disenrollments_Due_to_Failure_to_Pay_Plan_Premium column count is noted as ""(.*)""")]
        public void ThenQuarterlyDisenrollmentComplianceReportPageDisenrollmentsTotal_Involuntary_Disenrollments_Due_To_Failure_To_Pay_Plan_PremiumColumnCountIsNotedAs(string p0)
        {
            string colDTotalcount = cfComplianceReport.QuarterlyDisEnrollmentReport.Total_Involuntary_Disenrollments_Due_to_Failure_to_Pay_Plan_Premium_D_PartC_Column_Total.Text;
            // Assigning value to Variable
            fw.setVariable(p0, colDTotalcount);

            fw.ConsoleReport(p0 + " count " + colDTotalcount);
        }
        [Then(@"Quarterly Disenrollment Compliance Report page Disenrollments Denied by the Sponsor Ineligibility column count is noted as ""(.*)""")]
        public void ThenQuarterlyDisenrollmentComplianceReportPageDisenrollmentsDeniedByTheSponsorIneligibilityColumnCountIsNotedAs(string p0)
        {
            string colD_PartD = cfComplianceReport.QuarterlyDisEnrollmentReport.Total_Disenrollments_Denied_by_the_Sponsor_IneligibilityD_PartD.Text;
            // Assigning value to Variable
            fw.setVariable(p0, colD_PartD);

            fw.ConsoleReport(p0 + " count " + colD_PartD);
        }

        [Then(@"Quarterly Disenrollment Compliance Report page Total Involuntary Disenrollments Due to Failure to Pay Plan Premium column count is noted as ""(.*)""")]
        public void ThenQuarterlyDisenrollmentComplianceReportPageTotalInvoluntaryDisenrollmentsDueToFailureToPayPlanPremiumColumnCountIsNotedAs(string p0)
        {
            string colG_PartD = cfComplianceReport.QuarterlyDisEnrollmentReport.G_PartD_Column_Total.Text;
            // Assigning value to Variable
            fw.setVariable(p0, colG_PartD);

            fw.ConsoleReport(p0 + " count " + colG_PartD);
        }


        [Then(@"Quarterly Enrollment Compliance Report page Total Disenrollments That Required Requests for Additional Information column count is noted as ""(.*)""")]
        public void ThenQuarterlyEnrollmentComplianceReportPageTotalDisenrollmentsThatRequiredRequestsForAdditionalInformationColumnCountIsNotedAs(string p0)
        {
            string colC_PartDTotalcount = cfComplianceReport.QuarterlyDisEnrollmentReport.Total_Disenrollments_That_Required_Requests_For_Additional_Information_Column_Total.Text;
            // Assigning value to Variable
            fw.setVariable(p0, colC_PartDTotalcount);

            fw.ConsoleReport(p0 + " count " + colC_PartDTotalcount);
        }

        [Then(@"Quarterly Disenrollment Compliance Report page Total_Disenrollments_Denied_by_the_SponsorQ2 column count is noted as ""(.*)""")]
        public void ThenQuarterlyDisenrollmentComplianceReportPageTotal_Disenrollments_Denied_By_The_SponsorQColumnCountIsNotedAs(string p0)
        {
            string colCTotalcountQ2 = cfComplianceReport.QuarterlyDisEnrollmentReport.Disenrollments_Denied_by_the_Sponsor_for_Any_Reason_C_PartC_Column_Q2.Text;
            // Assigning value to Variable
            fw.setVariable(p0, colCTotalcountQ2);

            fw.ConsoleReport(p0 + " count " + colCTotalcountQ2);
        }
        [Then(@"Quarterly Enrollment Compliance Report page Disenrollments That Required Requests for Additional InformationQ2 column count is noted as ""(.*)""")]
        public void ThenQuarterlyEnrollmentComplianceReportPageDisenrollmentsThatRequiredRequestsForAdditionalInformationQ2ColumnCountIsNotedAs(string p0)
        {
            string colC_PartDcountQ2 = cfComplianceReport.QuarterlyDisEnrollmentReport.Disenrollments_That_Required_Requests_for_Additional_Information_C_PartD_Column_Q2.Text;
            // Assigning value to Variable
            fw.setVariable(p0, colC_PartDcountQ2);

            fw.ConsoleReport(p0 + " count " + colC_PartDcountQ2);
        }


        [Then(@"Quarterly Disenrollment Compliance Report page Disenrollments Denied by the Sponsor Ineligibility_Q2 column count is noted as ""(.*)""")]
        public void ThenQuarterlyDisenrollmentComplianceReportPageDisenrollmentsDeniedByTheSponsorIneligibility_QColumnCountIsNotedAs(string p0)
        {
            string colD_PartDcountQ2 = cfComplianceReport.QuarterlyDisEnrollmentReport.Disenrollments_Denied_by_the_Sponsor_Ineligibility_Q2.Text;
            // Assigning value to Variable
            fw.setVariable(p0, colD_PartDcountQ2);

            fw.ConsoleReport(p0 + " count " + colD_PartDcountQ2);
        }

        [Then(@"Quarterly Disenrollment Compliance Report page Incomplete Disenrollments Received that are Completed within an Established Time Frame_Q2 column count is noted as ""(.*)""")]
        public void ThenQuarterlyDisenrollmentComplianceReportPageIncompleteDisenrollmentsReceivedThatAreCompletedWithinAnEstablishedTimeFrame_QColumnCountIsNotedAs(string p0)
        {
            string colE_PartDcountQ2 = cfComplianceReport.QuarterlyDisEnrollmentReport.E_PartD_Column_Q2.Text;
            // Assigning value to Variable
            fw.setVariable(p0, colE_PartDcountQ2);

            fw.ConsoleReport(p0 + " count " + colE_PartDcountQ2);
        }
        [Then(@"Quarterly Disenrollment Compliance Report page Disenrollments Denied, Information to Complete Disenrollment not Received Timely_Q2 column count is noted as ""(.*)""")]
        public void ThenQuarterlyDisenrollmentComplianceReportPageDisenrollmentsDeniedInformationToCompleteDisenrollmentNotReceivedTimely_Q2ColumnCountIsNotedAs(string p0)
        {
            string colF_PartDcountQ2 = cfComplianceReport.QuarterlyDisEnrollmentReport.F_PartD_Column_Q2.Text;
            // Assigning value to Variable
            fw.setVariable(p0, colF_PartDcountQ2);

            fw.ConsoleReport(p0 + " count " + colF_PartDcountQ2);
        }

        [Then(@"Quarterly Disenrollment Compliance Report page Total Involuntary Disenrollments Due to Failure to Pay Plan Premium_Q2 column count is noted as ""(.*)""")]
        public void ThenQuarterlyDisenrollmentComplianceReportPageTotalInvoluntaryDisenrollmentsDueToFailureToPayPlanPremium_QColumnCountIsNotedAs(string p0)
        {
            string colG_PartDcountQ2 = cfComplianceReport.QuarterlyDisEnrollmentReport.G_PartD_Column_Q2.Text;
            // Assigning value to Variable
            fw.setVariable(p0, colG_PartDcountQ2);

            fw.ConsoleReport(p0 + " count " + colG_PartDcountQ2);
        }

        [Then(@"Quarterly Enrollment Compliance Report page Total_Enrollments_Received column count is noted as ""(.*)""")]
        public void ThenQuarterlyEnrollmentComplianceReportPageTotal_Enrollments_ReceivedColumnCountIsNotedAs(string p0)
        {
            tmsWait.Hard(20);
            string colATotalcount = cfComplianceReport.QuarterlyEnrollmentReport.Total_Enrollments_Received_A_Column_Total.Text;
            // Assigning value to Variable
            fw.setVariable(p0, colATotalcount);

            fw.ConsoleReport(p0 + " count " + colATotalcount);
        }


        [Then(@"Quarterly Enrollment Compliance Report page Enrollments Complete at the Time of Initial Receipt column count is noted as ""(.*)""")]
        public void ThenQuarterlyEnrollmentComplianceReportPageEnrollmentsCompleteAtTheTimeOfInitialReceiptColumnCountIsNotedAs(string p0)
        {
            string colBTotalcount = cfComplianceReport.QuarterlyEnrollmentReport.Enrollments_Complete_at_the_Time_of_Initial_Receipt_B_Column_Total.Text;
            // Assigning value to Variable
            fw.setVariable(p0, colBTotalcount);

            fw.ConsoleReport(p0 + " count " + colBTotalcount);
        }

        [Then(@"Quarterly Enrollment Compliance Report page Enrollments that Required Requests or Additional Information column count is noted as ""(.*)""")]
        public void ThenQuarterlyEnrollmentComplianceReportPageEnrollmentsThatRequiredRequestsOrAdditionalInformationColumnCountIsNotedAs(string p0)
        {
            string colCTotalcount = cfComplianceReport.QuarterlyEnrollmentReport.Enrollments_that_Required_Requests_or_Additional_Information_C_Column_Total.Text;
            // Assigning value to Variable
            fw.setVariable(p0, colCTotalcount);

            fw.ConsoleReport(p0 + " count " + colCTotalcount);
        }

        [Then(@"Quarterly Enrollment Compliance Report page Enrollments Denied Information to Complete Enrollment not Received Timely column count is noted as ""(.*)""")]
        public void ThenQuarterlyEnrollmentComplianceReportPageEnrollmentsDeniedInformationToCompleteEnrollmentNotReceivedTimelyColumnCountIsNotedAs(string p0)
        {
            string colFTotalcount = cfComplianceReport.QuarterlyEnrollmentReport.Enrollments_Denied_Information_to_Complete_Enrollment_not_Received_Timely_F_Column_Total.Text;
            // Assigning value to Variable
            fw.setVariable(p0, colFTotalcount);

            fw.ConsoleReport(p0 + " count " + colFTotalcount);
        }

        [Then(@"Quarterly Enrollment Compliance Report page Enrollments Received By Paper column count is noted as ""(.*)""")]
        public void ThenQuarterlyEnrollmentComplianceReportPageEnrollmentsReceivedByPaperColumnCountIsNotedAs(string p0)
        {
            string colGTotalcount = cfComplianceReport.QuarterlyEnrollmentReport.Enrollments_Received_By_Paper_G_Column_Total.Text;
            // Assigning value to Variable
            fw.setVariable(p0, colGTotalcount);

            fw.ConsoleReport(p0 + " count " + colGTotalcount);
        }

        [Then(@"Quarterly Enrollment Compliance Report page Total Related to Medicare Advantage Open Enrollment Period column count is noted as ""(.*)""")]
        public void ThenQuarterlyEnrollmentComplianceReportPageTotalRelatedToMedicareAdvantageOpenEnrollmentPeriodColumnCountIsNotedAs(string p0)
        {
            string colNTotalcount = cfComplianceReport.QuarterlyEnrollmentReport.Enrollments_N_StandAlone_PartD_Total.Text;
            // Assigning value to Variable
            fw.setVariable(p0, colNTotalcount);
            fw.ConsoleReport(p0 + " count " + colNTotalcount);
        }
        [Then(@"Quarterly Enrollment Compliance Report page Total K_PartC column count is noted as ""(.*)""")]
        public void ThenQuarterlyEnrollmentComplianceReportPageTotalK_PartCColumnCountIsNotedAs(string p0)
        {
            string colK_PartCTotalcountQ2 = cfComplianceReport.QuarterlyEnrollmentReport.K_PartC_Column_Q2.Text;
            // Assigning value to Variable
            fw.setVariable(p0, colK_PartCTotalcountQ2);

            fw.ConsoleReport(p0 + " count " + colK_PartCTotalcountQ2);
        }

        [Then(@"Quarterly Enrollment Compliance Report page Total K_PartD column count is noted as ""(.*)""")]
        public void ThenQuarterlyEnrollmentComplianceReportPageTotalK_PartDColumnCountIsNotedAs(string p0)
        {
            string colK_PartDTotalcountQ2 = cfComplianceReport.QuarterlyEnrollmentReport.K_PartD_Column_Q2.Text;
            // Assigning value to Variable
            fw.setVariable(p0, colK_PartDTotalcountQ2);

            fw.ConsoleReport(p0 + " count " + colK_PartDTotalcountQ2);
        }


        [When(@"I clicked on Expan Menu in EAM Dashboard")]
        public void WhenIClickedOnExpanMenuInEAMDashboard()
        {
            AngularFunction.clickOnElement(cfComplianceReport.QuarterlyDisEnrollmentReport.ExpandMenu);
        }

        [When(@"I clicked on Reports section")]
        public void WhenIClickedOnReportsSection()
        {
            AngularFunction.clickOnElement(cfComplianceReport.QuarterlyDisEnrollmentReport.ReportSection);

        }

        [Then(@"Verify ""(.*)"" count is ""(.*)"" than ""(.*)"" count")]
        public void ThenVerifyCountIsThanCount(string p0, string type, string p2)
        {
            //int first = Int32.Parse(tmsCommon.GenerateData(p0));
            string value = tmsCommon.GenerateData(p0);
            int first = Int32.Parse(value);
            int second = Int32.Parse(tmsCommon.GenerateData(p2));

            fw.ConsoleReport(p0 + " Count -->" + first);
            fw.ConsoleReport(p0 + " Count -->" + second);
            bool results;
            if(type.Equals("increased"))
            {
                results = (second > first);

                Assert.IsTrue(results, p2+" Second count is not increased");

            }
            if (type.Equals("decreased"))
            {
                results = (first>second);

                Assert.IsTrue(results, p2+" Second count is not decreased");

            }
            if (type.Equals("same"))
            {
                results = (first == second);

                Assert.IsTrue(results, p2 + " No Change. Values are same ");

            }

        }

        [Then(@"verify ""(.*)"" exists in Q1 of A")]
        [Then(@"verify ""(.*)"" is displayed in Q1 grid of A")]
        public void ThenVerifyExistsInQOfA(string p0)
        {
            tmsWait.Hard(20);
            string expected = tmsCommon.GenerateData(p0); 
            AngularFunction.clickOnElement(cfComplianceReport.QuarterlyEnrollmentReport.Expand_A_Q1);
            tmsWait.Hard(20);
            string actual = Browser.Wd.FindElement(By.XPath("//table[@cols='6']//div/div[contains(.,'" + expected + "')]")).Text;
            Assert.AreEqual(expected, actual, "MBI does not exist");


        }
        [Then(@"verify ""(.*)"" is displayed in Q4 grid of A")]
        public void ThenVerifyIsDisplayedInQGridOfA(string p0, int p1)
        {
            tmsWait.Hard(20);
            string expected = tmsCommon.GenerateData(p0);
            AngularFunction.clickOnElement(cfComplianceReport.QuarterlyEnrollmentReport.Expand_A_Q4);
            tmsWait.Hard(20);
            string actual = Browser.Wd.FindElement(By.XPath("//table[@cols='6']//div/div[contains(.,'" + expected + "')]")).Text;
            Assert.AreEqual(expected, actual, "MBI does not exist");

        }

        [Then(@"verify ""(.*)"" is displayed in Q4 grid of C")]
        public void ThenVerifyIsDisplayedInQGridOfC(string p0, int p1)
        {
            tmsWait.Hard(20);
            string expected = tmsCommon.GenerateData(p0);
            AngularFunction.clickOnElement(cfComplianceReport.QuarterlyEnrollmentReport.Expand_C_Q4);
            tmsWait.Hard(20);
            string actual = Browser.Wd.FindElement(By.XPath("(//table[@cols='6']//div/div[contains(.,'" + expected + "')])[2]")).Text;
            Assert.AreEqual(expected, actual, "MBI does not exist");
        }

        [Then(@"verify ""(.*)"" is displayed in Q4 grid of F")]
        public void ThenVerifyIsDisplayedInQGridOfF(string p0, int p1)
        {
            tmsWait.Hard(20);
            string expected = tmsCommon.GenerateData(p0);
            AngularFunction.clickOnElement(cfComplianceReport.QuarterlyEnrollmentReport.Expand_F_Q4);
            tmsWait.Hard(20);
            string actual = Browser.Wd.FindElement(By.XPath("(//table[@cols='6']//div/div[contains(.,'" + expected + "')])[3]")).Text;
            Assert.AreEqual(expected, actual, "MBI does not exist");
        }

        [Then(@"verify ""(.*)"" is displayed in Q4 grid of G")]
        public void ThenVerifyIsDisplayedInQGridOfG(string p0, int p1)
        {
            tmsWait.Hard(20);
            string expected = tmsCommon.GenerateData(p0);
            AngularFunction.clickOnElement(cfComplianceReport.QuarterlyEnrollmentReport.Expand_G_Q4);
            tmsWait.Hard(20);
            string actual = Browser.Wd.FindElement(By.XPath("(//table[@cols='6']//div/div[contains(.,'" + expected + "')])[4]")).Text;
            Assert.AreEqual(expected, actual, "MBI does not exist");
        }

        [When(@"verify ""(.*)"" is displayed in Q(.*) of N_StandAlone Part D")]
        public void WhenVerifyIsDisplayedInQOfN_StandAlonePartD(string p0, int p1)
        {
            tmsWait.Hard(20);
            string expected = tmsCommon.GenerateData(p0);
            AngularFunction.clickOnElement(cfComplianceReport.QuarterlyEnrollmentReport.Expand_N_StandAlonePartD);
            tmsWait.Hard(20);
            string actual = Browser.Wd.FindElement(By.XPath("(//table[@cols='6']//div/div[contains(.,'" + expected + "')]")).Text;
            Assert.AreEqual(expected, actual, "MBI does not exist");
        }

        [Then(@"verify ""(.*)"" is displayed in Q(.*) of K_PartC")]
        [When(@"verify ""(.*)"" is displayed in Q(.*) of K_PartC")]
        public void WhenVerifyIsDisplayedInQ2OfK_PartC(string p0)
        {
            tmsWait.Hard(20);
            string expected = tmsCommon.GenerateData(p0);
            AngularFunction.clickOnElement(cfComplianceReport.QuarterlyEnrollmentReport.Expand_K_PartC);
            tmsWait.Hard(20);
            string actual = Browser.Wd.FindElement(By.XPath("(//table[@cols='6']//div/div[contains(.,'" + expected + "')]")).Text;
            Assert.AreEqual(expected, actual, "MBI does not exist");
        }

        [Then(@"verify ""(.*)"" is displayed in Q(.*) of K_PartD")]
        [When(@"verify ""(.*)"" is displayed in Q(.*) of K_PartD")]
        public void ThenVerifyIsDisplayedInQOfK_PartD(string p0, int p1)
        {
            tmsWait.Hard(20);
            string expected = tmsCommon.GenerateData(p0);
            AngularFunction.clickOnElement(cfComplianceReport.QuarterlyEnrollmentReport.Expand_K_PartD);
            tmsWait.Hard(20);
            string actual = Browser.Wd.FindElement(By.XPath("(//table[@cols='6']//div/div[contains(.,'" + expected + "')]")).Text;
            Assert.AreEqual(expected, actual, "MBI does not exist");
        }


        [When(@"I clicked on ""(.*)"" report")]
        public void WhenIClickedOnReport(string p0)
        {
            IWebElement reportBtn = Browser.Wd.FindElement(By.XPath("//span[@test-id='"+p0+"']"));
            AngularFunction.clickOnElement(reportBtn);
        }

        [When(@"I selected ""(.*)"" on Plan ID drop down")]
        public void WhenISelectedOnPlanIDDropDown(string value)
        {
            tmsWait.Hard(10);
            try
            {
                AngularFunction.selectMultiSelectDropDown(cfComplianceReport.QuarterlyDisEnrollmentReport.PlanIDDrp, value);
            }
            catch
            {

               
            }
        }
        [When(@"I clear Plan ID dropdown")]
        public void WhenIClearPlanIDDropdown()
        {
            tmsWait.Hard(5);
            cfComplianceReport.QuarterlyDisEnrollmentReport.PlanIDDrp.Clear();
        }

        [When(@"I clear MBI dropdown in Status Override page")]
        public void WhenIClearMBIDropdownInStatusOverridePage()
        {
            tmsWait.Hard(5);
            cfUIMODEAMAdmin.StatusOverride.MBITextbox.Clear();
        }

        [When(@"I have clicked on ""(.*)"" button")]
        public void WhenIHaveClickedOnButton(string p0)
        {
            AngularFunction.clickOnElement(By.XPath("//button[contains(.,'"+p0+"')]"));
        }



        [When(@"I selected ""(.*)"" on Year drop down")]
        public void WhenISelectedOnYearDropDown(string value)
        {
            tmsWait.Hard(10);
            try
            {
                AngularFunction.selectDropDownValue(cfComplianceReport.QuarterlyDisEnrollmentReport.YearDrp, value);
       
            }
            catch
            {


            }
        }
        [When(@"I selected ""(.*)"" on Quarter drop down")]
        public void WhenISelectedOnQuarterDropDown(string p0)
        {
            AngularFunction.selectMultiSelectDropDown(cfComplianceReport.QuarterlyDisEnrollmentReport.QuarterDrp, p0);
        }




        [When(@"Run Report button is Clicked successfully")]
        public void WhenRunReportButtonIsClickedSuccessfully()
        {
            AngularFunction.clickOnElement(cfComplianceReport.QuarterlyDisEnrollmentReport.ReportButton);
        }

        [When(@"I switched to Report Window")]
        public void WhenISwitchedToReportWindow()
        {
            tmsWait.Hard(20);
            Browser.SwitchToChildWindow();
            //Browser.Wd.Navigate().Refresh();
            AngularFunction.resolveCertificateErrors();
            string title = Browser.Wd.Title;

            fw.ConsoleReport(" Child Window Title " + title);
        }
        [When(@"I switched to Parent Window")]
        [Then(@"I switched to Parent Window")]
        public void ThenISwitchedToParentWindow()
        {
            Browser.SwitchToParentWindow();
           
            string title = Browser.Wd.Title;

            fw.ConsoleReport(" Parent Window Title " + title);
        }
        [Then(@"verify Report displayed ""(.*)"" label")]
        public void ThenVerifyReportDisplayedLabel(string p0)
        {
            IWebElement menu = Browser.Wd.FindElement(By.XPath("//div[contains(.,'" + p0 + "')]"));
            bool presence = menu.Displayed;
            Assert.IsTrue(presence, p0 + " is not getting displayed");

        }







    }
}
