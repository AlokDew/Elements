﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using TechTalk.SpecFlow;

using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using System.Diagnostics;
using System.Windows;
using System.Collections.ObjectModel;


namespace TMSoR1
{

    [Binding]
    public class TransactionsNew
    {
        public IWebElement DisenrlreasonCode { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboDisenReason_13")); } }
        public IWebElement ForceAcceptance { get { return Browser.Wd.FindElement(By.Id("ApplicationDispositionForceAcceptance")); } }
        public IWebElement DenialReasonDropDown { get { return Browser.Wd.FindElement(By.Id("div_ApplicationDispositionDenialReason")); } }
        public IWebElement DenialReasonActionDropDown { get { return Browser.Wd.FindElement(By.Id("div_ApplicationDispositionActionsDenialReason")); } }
        public IWebElement ApplicationDispositionDenialReasonDropdown { get { return Browser.Wd.FindElement(By.XPath("kendo-dropdownlist[test-id='ApplicationDispositionDenialReason']")); } }
        public IWebElement IncompleteApplication { get { return Browser.Wd.FindElement(By.Id("ApplicationDispositionIncompleteApplication")); } }
        public IWebElement MissingItem { get { return Browser.Wd.FindElement(By.Id("div_ApplicationDispositionMissingItem")); } }
        public IWebElement Other { get { return Browser.Wd.FindElement(By.Id("txtMissingOther")); } }
        public IWebElement Resubmit { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='transaction-btn-resubmit']")); } }
        public IWebElement ForceDeny { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ApplicationDispositionForceDeny']")); } }
        public IWebElement ForceDeny1 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ApplicationDispositionForceDeny']")); } }
        public IWebElement ForceDeny2 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ApplicationDispositionActionsForceDeny']")); } }
                                                                                                      
        public IWebElement EnrollmentSource { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_DropDpwnEnrollSource")); } }


        public IWebElement SalesRep { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_RadComboBox1_Input")); } }
        public IWebElement SalesRepBox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_RadComboBox1_Input")); } }
        public IWebElement SaleDate { get { return Browser.Wd.FindElement(By.Id("txtSaleDate")); } }
        public IWebElement SaleLocation { get { return Browser.Wd.FindElement(By.Id("ApplicationDispositionSaleLocation")); } }
        public IWebElement ProblemCaseType { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboProblemType")); } }
        public IWebElement SummaryMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ValidationSummary1")); } }
        public IWebElement HIC { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='DemographicDetailsMBI']")); } }
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPlanID_10")); } }
        public IWebElement TransCode { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboTransCode_12")); } }
        public IWebElement FirstName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='DemographicDetailsFirstName']")); } }
        public IWebElement LastName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='DemographicDetailsLastName']")); } }
        
        public IWebElement MI { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtMI_04")); } }
        public IWebElement DOB { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='DemographicDetailsDob']")); } }

        public IWebElement VerificationDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='snp-txt-verificationDate']")); } }

        public IWebElement FollowUpDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='snp-txt-followUpDate']")); } }

        public IWebElement Sex { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboSex_05")); } }
        public IWebElement EffectiveDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='DemographicDetailsEffectiveDate']")); } }
        public IWebElement SignatureDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='DemographicDetailsSignatureDate']")); } }
        public IWebElement ReceiptDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='DemographicDetailsReceiptDate']")); } }
        public IWebElement StreetAddress { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Transactioncode61ResidentialAddressupdateStreetAddress']")); } }
        public IWebElement StreetAddress1 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Transactioncode61ResidentialAddressupdateStreetAddress2']")); } }

        public IWebElement ElectionType { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboElectionPeriod_09")); } }

        public IWebElement PBP { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPBP_08")); } }
        public IWebElement SegID { get { return Browser.Wd.FindElement(By.Id("DemographicDetailsSegID")); } }
        public IWebElement PriorComm { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_drpPriorComm_17")); } }
        public IWebElement DisenReason { get { return Browser.Wd.FindElement(By.Id("div_DemographicDetailsDisenReason")); } }
        public IWebElement CancelTransaction { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnCancelTransaction")); } }


        
        public IWebElement DisenReasonTable { get { return Browser.Wd.FindElement(By.Id("cboDisenReason_13_glossaryPanel")); } }
        public IWebElement PartDOptOut { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPartDOptOut_24")); } }
        public IWebElement PremWithholdOption { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_drpPremium_18")); } }
        public IWebElement PremAmtC { get { return Browser.Wd.FindElement(By.Id("DemographicDetailsPremAmtC")); } }
        public IWebElement PremAmtD { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtPremAmtD_20")); } }
        public IWebElement EGHP { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboEGHP_07")); } }
        public IWebElement CreditCover { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboCreditCov_21")); } }
        public IWebElement UncoveredMonths { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtUncovMonth_22")); } }
        public IWebElement EmplSubsOverride { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_chkEmplSubOverride")); } }

        public IWebElement SecondaryRxInsurFlag { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cbo2ndDrugInsur_27")); } }
        public IWebElement PrimaryRxID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='RxDetailsPrimaryRxID']")); } }
        public IWebElement PrimaryRxGroup { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtPrimaryRxGroup_38")); } }
        public IWebElement PrimaryRxBIN { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='RxDetailsPrimaryRxBIN']")); } }
        public IWebElement PrimaryRxPCN { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtPrimaryPCN_37")); } }
        public IWebElement SecondaryRxID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txt2ndRxID_28")); } }
        public IWebElement SecondaryRxGroup { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txt2ndRxGroup_29")); } }
        public IWebElement SecondaryRxBIN { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txt2ndBIN_40")); } }
        public IWebElement SecondaryRxPCN { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txt2ndPCN_41")); } }

        public IWebElement BCSSResponse { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblBCSSResp")); } }
        public IWebElement BCSSResponseDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblBcssRespDt")); } }
        public IWebElement TRRResponseDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lbltrrDate")); } }

        public IWebElement TransStatus { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='transaction-span-transactionStatus']")); } }
        public IWebElement ReplyCode { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtReplyCode")); } }
        public IWebElement SubmitDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtSubDate")); } }
        public IWebElement ExportLegacyDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ExpLegacyDate")); } }

        public IWebElement ErrorMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtErrMessage")); } }
        public IWebElement ReplyDescrip { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtReplyDescrip")); } }
        public IWebElement SubmitMethod { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtSubMethod")); } }
        public IWebElement FileName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtFileName")); } }

        public IWebElement DateCompleted { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblDateCompleted")); } }
        public IWebElement IncompleteDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblDateIncomplete")); } }
        public IWebElement DateDenied { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblDateDenied")); } }
        public IWebElement UserEntered { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblUser")); } }
        public IWebElement DateEntered { get { return Browser.Wd.FindElement(By.XPath("//span[@test-id='transaction-span-dateEntered']")); } }
        public IWebElement UserModified { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblUserModified")); } }
        public IWebElement DateModified { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblModifiedDate")); } }
        public IWebElement RFIDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtRFIReceiptDate")); } }
        public IWebElement RFIDate1 { get { return Browser.Wd.FindElement(By.Id("ApplicationDispositionActionsRfiReceiptDate")); } }
        public IWebElement RFIReceiptDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ApplicationDispositionActionsRfiReceiptDate']")); } }

        public IWebElement FirstButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnFirst")); } }
        public IWebElement PreviousButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnPrevious")); } }
        public IWebElement NextButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnNext")); } }
        public IWebElement LastButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnLast")); } }
        public IWebElement SearchButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSearch")); } }
        public IWebElement SaveButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='transaction-btn-save']")); } }
        public IWebElement SaveButton1 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ransaction-btn-save']")); } }
        public IWebElement ResetButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnReset")); } }
        public IWebElement ViewMemberInfoButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='transaction-btn-memberInfo']")); } }
        public IWebElement ViewTRRDetailButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnViewTRR")); } }
        public IWebElement ContinueAnyway { get { return Browser.Wd.FindElement(By.XPath("//button[@id='btnContinue']")); } }

        public IWebElement Plan1 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Textplan1")); } }
        public IWebElement Plan2 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Textplan2")); } }
        public IWebElement Plan3 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Textplan3")); } }
        public IWebElement Plan4 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Textplan4")); } }
        public IWebElement Plan5 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Textplan5")); } }
        public IWebElement Plan6 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Textplan6")); } }
        public IWebElement Plan7 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Textplan7")); } }
        public IWebElement Plan8 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Textplan8")); } }
        public IWebElement Plan9 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Textplan9")); } }
        public IWebElement Plan10 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Textplan10")); } }

        public IWebElement Plan1Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblplan1")); } }
        public IWebElement Plan2Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblplan2")); } }
        public IWebElement Plan3Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblplan3")); } }
        public IWebElement Plan4Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblplan4")); } }
        public IWebElement Plan5Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblplan5")); } }
        public IWebElement Plan6Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblplan6")); } }
        public IWebElement Plan7Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblplan7")); } }
        public IWebElement Plan8Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblplan8")); } }
        public IWebElement Plan9Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblplan9")); } }
        public IWebElement Plan10Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblplan10")); } }
        public IWebElement OnHoldDropDown { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_DropDownSnpStatus")); } }
        public IWebElement OnHoldReasonDropDn { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_DropDownOnHoldReason")); } }
        public IWebElement TransactionTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucTransHistory_dgHistory")); } }
        public IWebElement CMSEffectiveDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtEffDate1")); } }
        public IWebElement CMSResponseEffDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtCreateDate")); } }
        public IWebElement CMSLatestEffDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtEffDate2")); } }
        public IWebElement CMSPlanID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPlan")); } }
        public IWebElement CMSTransID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboTransCode")); } }
        public IWebElement ExportBtn { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnTransFile")); } }
        public IWebElement MarkBtn { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnMark")); } }
        public IWebElement FileprocessingStatusGrid { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_FileStatusGrid")); } }
        public IWebElement CMSResTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_grdMarkFile")); } }

        public IWebElement ProgramSource { get { return Browser.Wd.FindElement(By.XPath("//span[@test-id='memberInfo-span-recordSource']")); } }
        public IWebElement DisenReasonIcon
        { 
            get 
            { 
                IList<IWebElement> weList = Browser.Wd.FindElements(By.TagName("img"));
                IWebElement thisReturnElement = null;
                foreach (IWebElement thisImage in weList)
                {
                    string thisOnClick = thisImage.GetAttribute("onclick");
                    if (thisOnClick != null)
                    {
                        if (thisOnClick.Contains("Disenrollment Reason"))
                        {
                            thisReturnElement = thisImage;
                        }
                    }
                }
                return thisReturnElement;
            } 
        }
        public IWebElement DisenReasonTableClose
        {
            get
            {
                IList<IWebElement> weList = Browser.Wd.FindElements(By.TagName("span"));
                IWebElement thisReturnElement = null;
                foreach (IWebElement thisImage in weList)
                {
                    string thisOnClick = thisImage.GetAttribute("class");
                    if (thisOnClick != null)
                    {
                        if (thisOnClick.Contains("ui-icon ui-icon-closethick"))
                        {
                            thisReturnElement = thisImage;
                        }
                    }
                }
                return thisReturnElement;
            }
        }


        public IWebElement PageMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblMsg")); } }
        public IWebElement SEPSReason { get { return Browser.Wd.FindElement(By.Id("div_DemographicDetailsSEPSReason")); } }
        public IWebElement SecInsurFlag { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cbo2ndDrugInsur_27")); } }

    }

    public class TransactionsNew61 : TransactionsNew
    {
        public IWebElement TypeOfApplication { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboAppType")); } }
        public IWebElement SpecialNeedPlan { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_imgExpand")); } }
        public IWebElement MedicaidNumber { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtMedicaidNum")); } }
        public IWebElement SNPStatus { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_DropDownSnpStatus")); } }
        public IWebElement MedicaidLevel { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtMedicaidLevel")); } }
        public IWebElement FacilityType { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtFacilityType")); } }
        public IWebElement FacilityEntryDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtFacilityEntryDate")); } }
        public IWebElement VerificationDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtVerificationDate")); } }
        public IWebElement CareAssessmentReceivedCompleted { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_rbtnReceived")); } }
        public IWebElement ChronicConditions { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_DropDownChronicConditions")); } }
        public IWebElement DiagnosisCodes { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtDiagnosisCodes")); } }
        public IWebElement InstitutionAddress { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtInstAddress")); } }        
        public IWebElement GracePeriod { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_DropDownGracePeriod")); } }        
        public IWebElement FollowUpDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtFollowUpDates")); } }
        public IWebElement ContactInfo { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtContactInfo")); } }        
        public IWebElement InstitutionName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtInstName")); } }                        
        public IWebElement StreetAddress { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='Transactioncode61ResidentialAddressupdateStreetAddress']")); } }
        public IWebElement StreetAddress2 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtStreetAddr2")); } }
        public IWebElement City { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtCity")); } }
        public IWebElement State { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtState")); } }
        public IWebElement Zip { get { return Browser.Wd.FindElement(By.Id("Transactioncode61ResidentialAddressupdateZip")); } }
        public IWebElement County { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlCounty")); } }
        public IWebElement SCCCode { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtSCCCode")); } }
        public IWebElement AngZip { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Zip')]/parent::div//input)[1]")); } }
    }

    public class TransactionsNew76 : TransactionsNew
    {
  //01122016      public IWebElement StreetAddress { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtStreetAddr")); } }
        public IWebElement StreetAddress { get { return Browser.Wd.FindElement(By.Id("Transactioncode76ResidentialAddressupdateStreetAddress")); } }
        public IWebElement StreetAddress2 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtAddress2_53")); } }
        public IWebElement City { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtCity_63")); } }
        public IWebElement State { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtState_64")); } }
        public IWebElement Zip { get { return Browser.Wd.FindElement(By.Id("Transactioncode76ResidentialAddressupdateZip")); } }
        public IWebElement Zipfour { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Transactioncode76ResidentialAddressupdateZipFour']")); } }
        public IWebElement Action { get { return Browser.Wd.FindElement(By.Id("div_Transactioncode76ResidentialAddressupdateAction")); } }
        public IWebElement AddressEffectiveDate { get { return Browser.Wd.FindElement(By.Id("Transactioncode76ResidentialAddressupdateAddressEffectiveDate")); } }
    }
}