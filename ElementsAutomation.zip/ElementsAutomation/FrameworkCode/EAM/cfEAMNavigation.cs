﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using TechTalk.SpecFlow;

using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using System.Diagnostics;
using System.Windows;
using System.Collections.ObjectModel;
using OpenQA.Selenium.Support.UI;
using TMSoR1.FrameworkCode;

namespace TMSoR1
{
    [Binding]
    public class NavigationBar
    {
        public IWebElement AdministrationExportSession { get { return Browser.Wd.FindElement(By.Id("Navigation1_pnlUserAdmin_lnkSessionExport_link")); } }
        public IWebElement AdministrationExternalIntegration { get { return Browser.Wd.FindElement(By.Id("Navigation1_pnlUserAdmin_lnkSessionExport_link")); } }
        public IWebElement AdministrationStatusOverride { get { return Browser.Wd.FindElement(By.PartialLinkText("Status Override")); } }
        public IWebElement MembersViewEdit { get { return Browser.Wd.FindElement(By.XPath("//a[@href='Member/MemberSearch.aspx?formName=MemberViewEdit.aspx']")); } }
        public IWebElement MembersNew { get { return Browser.Wd.FindElement(By.XPath("//a[@href='Member/MemberViewEdit.aspx?context=new']")); } }
        public IWebElement TriZettoLog1 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_ProductMenu1_Menu1-menuItem000")); } }
        public IWebElement TriZettoLog2 { get { return Browser.Wd.FindElement(By.Id("Navigation1_ProductMenu1_Menu1-menuItem000")); } }
        public IWebElement MembersERF { get { return Browser.Wd.FindElement(By.XPath("//a[@href='ctl00_ctl00_MainMasterContent_EamNavigation_pnlEnrollment_subitemErfEnrollment_link']")); } }
    }
    [Binding]
    public class EAMNavigationBar
    {
        public static IWebElement AdministrationLabel;
        public static void FindClassObjects()
        {
            try
            {
                IList<IWebElement> AdministrationLabelTemp = Browser.Wd.FindElements(By.ClassName("menuSectionTitle"));
                int thisCount = AdministrationLabelTemp.Count;
                IWebElement thisWebElement = null;
                Boolean bFoundMatch = false;
                foreach (IWebElement abc in AdministrationLabelTemp)
                {
                    thisWebElement = abc;
                    //    Console.WriteLine(abc.Text);
                    if (abc.Text.Equals("Administration"))
                    {
                        bFoundMatch = true;
                        break;
                    }
                }
                if (bFoundMatch)
                {
                    AdministrationLabel = thisWebElement;
                }
                else
                {
                    AdministrationLabel = null;
                }
            }
            catch { }
        }
    }

    [Binding]
    public class Navigation
    {
        public static void ClickLink(string strNavigation)
        {
            //Function is for clicking on the Navigation links.
            //
            //November 2014 - Daron Spicher
            //
            //Design is to have the user put the link in as it shows
            //in complete format from the application.
            //
            //The function then uses the Switch statement to handle the 
            //click.   In each case, we have linkTextValue.  This is 
            //the link text as you see it in the application.
            //
            //The code grabs all the links on the page which have that text.
            //A lot of them come back with 1 match.   Others have multiples.
            //For ones with multiples, we need a second identifier.
            //
            //The second identifier is the 'id', but that comes with problems too.
            //Some links have different 'id's depending on which page you are already on.
            //For that reason, each case has a string array with it.
            //
            //It would be very difficult to identify all the different possible 'id's
            //up front, so I imagine we will see a period of time when a running test case 
            //will fail on a menu navigation.   At that point, you can run the test
            //to the fail point and see what that menu item id is at that point.
            //
            //Add the id to the string array by putting a comma behind the last value, 
            //and putting the new id in the next string after.   Run again, it should work.
            string[] arrIDs = new string[] { };
            string linkTextValue = "";
            Boolean bFoundLink = false;
            Boolean bHandledInCase = false;
            switch (strNavigation)
            {

                case "Export":
                    {
                        string[] IDs = new string[]
                        {
                           "ctl00_ctl00_MainMasterContent_EamNavigation_uiModExportHyperLink"
                        }; arrIDs = IDs; break;
                    }
                case "Reports":
                    {
                        
                        string[] IDs = new string[]
                        {
                           "ctl00_ctl00_MainMasterContent_EamNavigation_uiModReportsHyperLink"
                        }; arrIDs = IDs; break;
                    }
                case "Export Spans - Facets":
                    {
                linkTextValue = "Export Spans - Facets";
                string[] IDs = new string[]
                {
                            "ctl00_ctl00_MainMasterContent_EamNavigation_lnkExpSpanfacet"
                }; arrIDs = IDs; break;
                }

                case "TRR Rules Config.":
                    {
                        linkTextValue = "TRR Rules Config.";
                        string[] IDs = new string[]
                        {
                            "ctl00_ctl00_MainMasterContent_EamNavigation_pnlUserAdmin_trrConfigurations_link"
                        }; arrIDs = IDs; break;
                    }

               

                case "EAM Configuration":
                    {

                        if (ConfigFile.tenantType.Equals("tmsx"))
                        {
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Administration']")));
                            tmsWait.Hard(3);
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@test-id='subMenu-titleList']//span[contains(.,'EAM Configuration')]")));
                        }
                        else
                        {
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@title='Administration']")));
                            tmsWait.Hard(2);
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@title='EAM Configuration']")));
                            tmsWait.Hard(3);
                        }
                        break;
                    }
                case "PDEM Administration":
                    {
                        tmsWait.Hard(5);
                        linkTextValue = "Administration";
                        string[] IDs = new string[]
                        {
                            "ctl00_RadMenu1_m6"
                        }; arrIDs = IDs; break;
                    }


                case "TmsOperational Config.":
                    {
                        linkTextValue = "TmsOperational Config.";
                        string[] IDs = new string[]
                        {
                            "Navigation1_menuTmsOperationalConfiguration"
                        }; arrIDs = IDs;
                        break;
                    }

                case "OSB Config":
                    {
                        linkTextValue = "OSB Config";
                        string[] IDs = new string[]
                        {
                            ""
                        }; arrIDs = IDs; break;
                    }
                case "Business Rules":
                    {
                        linkTextValue = "Business Rules";
                        string[] IDs = new string[]
                        {
                            ""
                        }; arrIDs = IDs; break;
                    }


                case "EnrollmentRequestFormNew":
                    {
                        linkTextValue = "New";
                        string[] IDs = new string[]
                        {
                            "ctl00_ctl00_MainMasterContent_EamNavigation_pnlEnrollment_subitemErfEnrollment_link"
                        }; arrIDs = IDs; break;
                    }

                case "AdministrationApplications":
                    {
                        linkTextValue = "Applications";
                        string[] IDs = new string[]
                        {
                            "Navigation1_appsmenu"
                        }; arrIDs = IDs; break;
                    }

                case "SNPConfig":
                    {
                        tmsWait.Hard(3);
                        linkTextValue = "SNP Config";
                        string[] IDs = new string[]
                        {
                            ""
                        }; arrIDs = IDs; break;
                    }
                case "PDDD Config":
                    {
                        tmsWait.Hard(3);
                        linkTextValue = "PDDD Config";
                        string[] IDs = new string[]
                        {
                            ""
                        }; arrIDs = IDs; break;
                    }

                case "AdministrationPlanDefinedFieldsOOATab":
                    {
                        tmsWait.Hard(3);
                        linkTextValue = "OOA";
                        string[] IDs = new string[]
                        {
                            ""
                        }; arrIDs = IDs; break;
                    }
                case "AdministrationPlanDefinedFieldsNew":
                    {
                        tmsWait.Hard(3);
                        linkTextValue = "Plan Defined Fields";
                        string[] IDs = new string[]
                        {
                            ""
                        }; arrIDs = IDs; break;
                    }

                case "EAMConfiguration":
                    {
                        if (ConfigFile.tenantType.Equals("tmsx"))
                        {
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Administration']")));
                            tmsWait.Hard(3);
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@test-id='subMenu-titleList']//span[contains(.,'EAM Configuration')]")));
                        }
                        else
                        {
                            IWebElement admin = Browser.Wd.FindElement(By.CssSelector("[title='Administration']"));
                            fw.ExecuteJavascript(admin);
                            IWebElement config = Browser.Wd.FindElement(By.CssSelector("[title='EAM Configuration']"));
                            fw.ExecuteJavascript(config);
                        }
                        //tmsWait.Hard(3);
                        //linkTextValue = "EAM Configuration";
                        //string[] IDs = new string[]
                        //{
                        //    "ctl00_ctl00_MainMasterContent_EamNavigation_pnlUserAdmin_ctl06_link"
                        //}; arrIDs = IDs;

                        break;
                    }


                case "AdministrationEAMConfiguration":
                    {
                        if (ConfigFile.tenantType.Equals("tmsx"))
                        {
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Administration']")));
                            tmsWait.Hard(3);
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@test-id='subMenu-titleList']//span[contains(.,'EAM Configuration')]")));
                        }
                        else
                        {
                            IWebElement admin = Browser.Wd.FindElement(By.CssSelector("[title='Administration']"));
                            fw.ExecuteJavascript(admin);
                            IWebElement config = Browser.Wd.FindElement(By.CssSelector("[title='EAM Configuration']"));
                            fw.ExecuteJavascript(config);
                        }
                        //tmsWait.Hard(3);
                        //linkTextValue = "EAM Configuration";
                        //string[] IDs = new string[]
                        //{
                        //    "ctl00_ctl00_MainMasterContent_EamNavigation_pnlUserAdmin_ctl06_link"
                        //}; arrIDs = IDs;

                        break;
                    }

                case "OEV Letter":
                    {
                        if (ConfigFile.tenantType.Equals("tmsx"))
                        {
                            tmsWait.Hard(1);
                             fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Administration']")));
                                tmsWait.Hard(3);
                                IWebElement link = Browser.Wd.FindElement(By.XPath("//span[contains(.,'EAM Configuration')]"));
                                fw.ExecuteJavascript(link);
                                tmsWait.Hard(2);
                                IWebElement oevlink = Browser.Wd.FindElement(By.XPath("//label[contains(.,'OEV Letter')]"));
                                fw.ExecuteJavascript(oevlink);
                                tmsWait.Hard(2);
                                
                        }
                        else
                        {
                            IWebElement planDefined = Browser.Wd.FindElement(By.CssSelector("[test-id='11']"));
                            fw.ExecuteJavascript(planDefined);
                            tmsWait.Hard(2);
                        }
                        //tmsWait.Hard(3);
                        //linkTextValue = "OEV Letter";
                        //string[] IDs = new string[]
                        //{
                        //    ""
                        //}; arrIDs = IDs; 
                        break;
                    }  
                case  "AdministrationPlanDefinedFieldsOOAPossibleOutofAreaStatusTab":
                    {
                        tmsWait.Hard(3);
                        linkTextValue = "Possible Out of Area Status";
                        string[] IDs = new string[]
                        {
                            ""
                        }; arrIDs = IDs; break;
                    }
  
                case  "AdministrationPlanDefinedFieldsOOAOutofAreaConfigurationTab":
                    {
                        tmsWait.Hard(3);
                        linkTextValue = "Out of Area Configuration";
                        string[] IDs = new string[]
                        {
                            ""
                        }; arrIDs = IDs; break;
                    }

                case "AdministrationPlanDefinedFieldsSalesRepTab":
                    {
                        tmsWait.Hard(3);
                        linkTextValue = "Sales Rep";
                        string[] IDs = new string[]
                        {
                            ""
                        }; arrIDs = IDs; break;
                    }

                case "HomePage":
                    {
                        if (ConfigFile.tenantType.Equals("tmsx"))
                        {
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Dashboard']")));
                            tmsWait.Hard(2);
                        }
                        else
                        {
                            IWebElement dashboard = Browser.Wd.FindElement(By.XPath("//a[@title='Dashboard']"));
                            fw.ExecuteJavascript(dashboard);
                            tmsWait.Hard(2);
                        }
                        //linkTextValue = "Home";
                        //string[] IDs = new string[]
                        //{
                        //    "ctl00_ctl00_MainMasterContent_EamNavigation_lnkHome"
                        //}; arrIDs = IDs; 
                        break;
                    }

                case "Jobs":
                    {
                        linkTextValue = "Jobs";
                        string[] IDs = new string[]
                        {
                            "Navigation1_menuEditUser2"
                        }; arrIDs = IDs; break;
                    }
                case "MembersNew":
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@title='Main']")));
                        tmsWait.Hard(3);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@title='New Member']")));
                        tmsWait.Hard(2);
                        //linkTextValue = "New";
                        //string[] IDs = new string[]
                        //{
                        //    //"Navigation1_Hyperlink3",
                        //    //"ctl00_ctl00_MainMasterContent_EamNavigation_Hyperlink3",
                        //    //"ctl00_MainMasterContent_ctl00_Hyperlink3"
                        //    "ctl00_ctl00_MainMasterContent_EamNavigation_addMemberUiMod"
                        //}; arrIDs = IDs;

                        break;
                    }
                case "MembersViewEdit":
                    {
                        if (ConfigFile.tenantType.Equals("tmsx"))
                        {
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Main']")));
                            tmsWait.Hard(3);
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@test-id='subMenu-titleList']//span[contains(.,'Edit Member')]")));



                        }
                        else
                        {

                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@title='Main']")));
                            tmsWait.Hard(2);
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@title='View/Edit Member']")));
                            tmsWait.Hard(3);

                        }
                        break;
                    }


                case "Recalculations":
                    {
                        linkTextValue = "Recalculations";
                        string[] IDs = new string[]
                        {
                            "ctl00_ctl00_MainMasterContent_EamNavigation_pnlUserAdmin_ctl04_link"
                        }; arrIDs = IDs; break;
                    }
                case "TransactionsNewTrans":
                    {
                        if (ConfigFile.tenantType.Equals("tmsx"))
                        {
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//a[@test-id='header-btn-expanMenu']/span)[1]")));
                            tmsWait.Hard(3);

                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Main']")));
                            tmsWait.Hard(3);
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@test-id='subMenu-titleList']//span[contains(.,'New Transaction')]")));
                        }
                        else
                        {
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@title='Main']")));
                            tmsWait.Hard(3);
                            By link = By.XPath("//a[@title='New Transaction']");
                            UIMODUtilFunctions.clickOnWebElementUsingLocators(link);
                            tmsWait.Hard(4);
                        }
                            
                        //linkTextValue = "New Trans";
                        //string[] IDs = new string[]
                        //{
                        //    "Navigation2_pnlTrans_divTransactionMarx_link",
                        //    "Navigation1_pnlTrans_divTransactionMarx_link"
                        //}; arrIDs = IDs;

                        break;
                    }
                case "Administration Letters":
                    {

                        By link = By.XPath("(//a[@title='Letters'])[2]");
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(link);
                        tmsWait.Hard(4);

                        //linkTextValue = "Pre-CMS";
                        //string[] IDs = new string[]
                        //{
                        //    "ctl00_ctl00_MainMasterContent_EamNavigation_pnlLetters_ctl01_item",
                        //    "Navigation1_pnlLetters_ctl01_item"
                        //}; arrIDs = IDs; 
                        break;
                    }
                case "TransactionsViewEdit":
                    {
                        if (ConfigFile.tenantType.Equals("tmsx"))
                        {
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Main']")));
                            tmsWait.Hard(3);
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@test-id='subMenu-titleList']//span[contains(.,'Edit Transaction')]")));
                        }
                        else
                        {
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@title='Main']")));
                            tmsWait.Hard(2);
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@title='View/Edit Transaction']")));
                            tmsWait.Hard(3);
                            //linkTextValue = "View/Edit";
                            //string[] IDs = new string[]
                            //{
                            //    "Navigation1_pnlTrans_lnkMemberEdit_link",
                            //    "ctl00_ctl00_MainMasterContent_EamNavigation_pnlTrans_lnkMemberEdit_link","ctl00_MainMasterContent_ctl00_pnlTrans_lnkMemberEdit_link"
                            //}; arrIDs = IDs;
                        }

                        break;
                    }
                case "TransactionsTC90":
                    {
                        if (ConfigFile.tenantType.Equals("tmsx"))
                        {
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Main']")));
                            tmsWait.Hard(3);
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@test-id='subMenu-titleList']//span[contains(.,'TC 90')]")));
                        }
                        else
                        {
                            linkTextValue = "TC90";
                            string[] IDs = new string[]
                            {
                            "Navigation1_pnlTrans_itemTC90_link"
                            }; arrIDs = IDs;
                        }
                        break;
                    }

                case "MemberViewEditTransactionsTab":
                    {
                        linkTextValue = "Transactions";
                        string[] IDs = new string[]
                        {
                            "ctl00_ctl00_MainMasterContent_MainContent_btnTransactions"                            
                        }; arrIDs = IDs; break;
                    }

                case "MemberViewEditContactTab":
                    {

                        linkTextValue = "Contact";
                        string[] IDs = new string[]
                        {
                            "ctl00_ctl00_MainMasterContent_MainContent_btnContact"                            
                        }; arrIDs = IDs; break;

                    }

                case "MemberViewEditSpansTab":
                    {
                        linkTextValue = "Spans";
                        string[] IDs = new string[]
                        {
                            "ctl00_ctl00_MainMasterContent_MainContent_btnSpans"                            
                        }; arrIDs = IDs; break;
                    }



                case "TasksCheckEligibility":
                    {
                        linkTextValue = "Check Eligibility";
                        string[] IDs = new string[]
                        {
                            "divEligibility","ctl00_ctl00_MainMasterContent_EamNavigation_divCheckEligibility"
                        }; arrIDs = IDs; break;
                    }

                case "MembersViewEditEligibilityTab":
                    {
                        linkTextValue = "Eligibility";
                        string[] IDs = new string[]
                        {
                            "ctl00_ctl00_MainMasterContent_MainContent_btnStatus"
                        }; arrIDs = IDs; break;
                    }


                case "TasksCheckEligibilityBEQFile":
                    {
                        linkTextValue = "BEQ File";
                        string[] IDs = new string[]
                        {
                            "ctl00_ctl00_MainMasterContent_EamNavigation_lnkBEQFile"
                        }; arrIDs = IDs; break;
                    }
                case "TasksLoadData":
                    {
                        linkTextValue = "Load Data";
                        string[] IDs = new string[]
                        {
                            "divLoadData"
                        }; arrIDs = IDs; break;
                    }
                case "TasksLoadDataTRRFile":
                    {
                        linkTextValue = "TRR File";
                        string[] IDs = new string[]
                        {
                            "ctl00_ctl00_MainMasterContent_EamNavigation_lnkDoTRR"
                        }; arrIDs = IDs; break;
                    }
                case "TasksLoadDataDeemedLISFile":
                    {
                        linkTextValue = "Deemed LIS File";
                        string[] IDs = new string[]
                        {
                            "ctl00_ctl00_MainMasterContent_EamNavigation_lnkLoad_DeemedLIS"
                        }; arrIDs = IDs; break;
                    }

                case "TasksLoadDataNotificationFile":
                    {
                        linkTextValue = "Notification File";
                        string[] IDs = new string[]
                        {
                            "ctl00_ctl00_MainMasterContent_EamNavigation_lnkNotification"
                        }; arrIDs = IDs; break;
                    }
                case "TasksLoadDataNoRxFile":
                    {
                        linkTextValue = "No Rx File";
                        string[] IDs = new string[]
                        {
                            "Navigation1_lnkNoRx"
                        }; arrIDs = IDs; break;
                    }
                case "TasksLoadDataOECFile":
                    {
                        linkTextValue = "OEC File";
                        string[] IDs = new string[]
                        {
                            "Navigation1_lnkLoadOEC"
                        }; arrIDs = IDs; break;
                    }
                case "TasksLoadDataEAFFile":
                    {
                        linkTextValue = "EAF File";
                        string[] IDs = new string[]
                        {
                            "Navigation1_lnkLoadEAF"
                        }; arrIDs = IDs; break;
                    }
                case "TasksLoadDataLISHistory":
                    {
                        linkTextValue = "LIS History";
                        string[] IDs = new string[]
                        {
                            "Navigation1_lnkLoadLISHist"
                        }; arrIDs = IDs; break;
                    }
                case "TasksLoadDataBCSSFile":
                    {
                        linkTextValue = "BCSS File";
                        string[] IDs = new string[]
                        {
                            "Navigation1_lnkLoadBCSS"
                        }; arrIDs = IDs; break;
                    }
                case "TasksLoadDataLegacyResetFile":
                    {
                        linkTextValue = "Legacy Reset File";
                        string[] IDs = new string[]
                        {
                            "Navigation1_lnkLoadLegacyReset"
                        }; arrIDs = IDs; break;
                    }
                case "TasksLoadDataProviderFile":
                    {
                        linkTextValue = "Provider File";
                        string[] IDs = new string[]
                        {
                            "Navigation1_lnkLoadPRovider"
                        }; arrIDs = IDs; break;
                    }
                case "TasksLoadDataNoPremiumDue":
                    {
                        linkTextValue = "No Premium Due";
                        string[] IDs = new string[]
                        {
                            "Navigation1_lnkImportNoPremiumDue"
                        }; arrIDs = IDs; break;
                    }
                case "TasksCreateCMSFile":
                    {
                        linkTextValue = "Create CMS File";
                        string[] IDs = new string[]
                        {
                            "navigationCntrl_Hyperlink2"
                        }; arrIDs = IDs; break;
                    }
                case "TasksCreateRetroFile":
                    {
                        linkTextValue = "Create Retro File";
                        string[] IDs = new string[]
                        {
                            "navigationCntrl_lnkExportRetroContractor"
                        }; arrIDs = IDs; break;
                    }
                case "ViewBidData":
                    {
                        linkTextValue = "View Bid Data";
                        string[] IDs = new string[]
                        {
                            "ctl00_ctl00_MainMasterContent_EamNavigation_pnlUserAdmin_ctl07_link"
                        }; arrIDs = IDs; break;
                    }

                case "FilesProcessingStatus":
                    {
                        linkTextValue = "Processing Status";
                        string[] IDs = new string[]
                        {
                            "Navigation1_lnkFileProcessed", "ctl00_ctl00_MainMasterContent_EamNavigation_lnkFileProcessed"
                        }; arrIDs = IDs; break;
                    }
                case "ExportMemberSpanFile":
                    {
                        linkTextValue = "Member/Span File";
                        string[] IDs = new string[]
                        {
                            "Navigation1_lnkExpMemspan"
                        }; arrIDs = IDs; break;
                    }
                case "ExportToLegacyTrans":
                    {
                        linkTextValue = "To Legacy - Trans.";
                        string[] IDs = new string[]
                        {
                            "Navigation2_lnkLegTrans"
                        }; arrIDs = IDs; break;
                    }
                case "ExportToLegacyMember":
                    {
                        linkTextValue = "To Legacy - Member";
                        string[] IDs = new string[]
                        {
                            "Navigation1_lnkExpLegTrans"
                        }; arrIDs = IDs; break;
                    }
                case "ExportMailingList":
                    {
                        linkTextValue = "Mailing List";
                        string[] IDs = new string[]
                        {
                            "imagePreMailing"
                        }; arrIDs = IDs; break;
                    }
                case "ExportMailingListFromTransactions":
                    {
                        linkTextValue = "From Transactions";
                        string[] IDs = new string[]
                        {
                            "Navigation1_LnkExpMailList"
                        }; arrIDs = IDs; break;
                    }
                case "ExportMailingListFromTRR":
                    {
                        linkTextValue = "From T/RR";
                        string[] IDs = new string[]
                        {
                            "Navigation2_LnkExpCLDMailList"
                        }; arrIDs = IDs; break;
                    }
                case "ExportAcumenLISFile":
                    {
                        linkTextValue = "Acumen LIS File";
                        string[] IDs = new string[]
                        {
                            "Navigation1_lnkExpAcuLIS"
                        }; arrIDs = IDs; break;
                    }
                case "LettersPreCMS":
                    {
                       
                       
                        
                        //linkTextValue = "Pre-CMS";
                        //string[] IDs = new string[]
                        //{
                        //    "ctl00_ctl00_MainMasterContent_EamNavigation_pnlLetters_ctl01_item",
                        //    "Navigation1_pnlLetters_ctl01_item"
                        //}; arrIDs = IDs; 
                        break;
                    }
                
                case "LettersPreCMSAckEnroll":
                    {
                        linkTextValue = "Ack. Enroll";
                        //string[] IDs = new string[]
                        //{
                        //    "ctl00_ctl00_MainMasterContent_EamNavigation_pnlLetters_ctl01_ctl01_link",
                        //    "Navigation1_pnlLetters_ctl01_ctl01_link"
                        //}; arrIDs = IDs; 
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_EamNavigation_pnlLetters_ctl01_ctl01_link")));
                        break;
                    }
                case "LettersPreCMSAckDisenroll":
                    {
                        linkTextValue = "Ack. Disenroll";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlLetters_ctl01_ctl02_link"
                        }; arrIDs = IDs; break;
                    }
                case "LettersPreCMSRequestInfoDisenroll":
                    {
                        linkTextValue = "Req. Information Disenroll";
                        string[] IDs = new string[]
                        {
                            "ctl00_ctl00_MainMasterContent_EamNavigation_pnlLetters_ctl01_ctl08_link"
                        }; arrIDs = IDs; break;
                    }

                    
                case "LettersPreCMSAckOfCancelEnrl":
                    {
                        linkTextValue = "Ack. Of Cancel Enrl";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlLetters_ctl01_ctl03_link"
                        }; arrIDs = IDs; break;
                    }
                case "LettersPreCMSAckOfCancelDisenroll":
                    {
                        linkTextValue = "Ack. Of Cancel Disenroll";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlLetters_ctl01_ctl04_link"
                        }; arrIDs = IDs; break;
                    }
                case "LettersPreCMSLossSNP":
                    {
                        linkTextValue = "Disenroll Loss SNP";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlLetters_ctl01_ctl05_link"
                        }; arrIDs = IDs; break;
                    }
                case "LettersPreCMSReqInformationEnroll":
                    {
                        linkTextValue = "Req. Information Enroll";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlLetters_ctl01_ctl06_link",
                            "ctl00_ctl00_MainMasterContent_EamNavigation_pnlLetters_ctl01_ctl08_link"

                        }; arrIDs = IDs; break;
                    }
                case "LettersPreCMSDenialEnroll":
                    {
                        linkTextValue = "Denial Enroll";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlLetters_ctl01_ctl07_link"
                        }; arrIDs = IDs; break;
                    }
                case "LettersPreCMSPlanChange":
                    {
                        linkTextValue = "Plan Change";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlLetters_ctl01_hPlanChange_link"
                        }; arrIDs = IDs; break;
                    }
                case "LettersPreCMSReqInformationDisenroll":
                    {
                        linkTextValue = "Req. Information Disenroll";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlLetters_ctl01_ctl08_link"
                        }; arrIDs = IDs; break;
                    }
                case "LettersPreCMSDenialDisenroll":
                    {
                        linkTextValue = "Denial Disenroll";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlLetters_ctl01_ctl09_link"
                        }; arrIDs = IDs; break;
                    }
                case "LettersPreCMSBreakInCoverage":
                    {
                        linkTextValue = "Break In Coverage";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlLetters_ctl01_ctl10_link"
                        }; arrIDs = IDs; break;
                    }
                case "LettersPreCMSNewToDrugPlan":
                    {
                        linkTextValue = "New To Drug Plan";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlLetters_ctl01_ctl11_link"
                        }; arrIDs = IDs; break;
                    }
                case "LettersPreCMSOutboundEnrollmentVerification":
                    {
                        //IWebElement dashboard = Browser.Wd.FindElement(By.XPath("//a[@title='Dashboard']"));
                        //fw.ExecuteJavascript(dashboard);
                        //tmsWait.Hard(2);
                        //IWebElement dashboardLetters = Browser.Wd.FindElement(By.CssSelector("[test-id='eamDashboard-img-letters']"));
                        //fw.ExecuteJavascript(dashboardLetters);
                        if (ConfigFile.tenantType.Equals("tmsx"))
                        {
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Administration']")));
                            tmsWait.Hard(3);
                            IWebElement link = Browser.Wd.FindElement(By.XPath("//span[contains(.,'EAM Configuration')]"));
                            fw.ExecuteJavascript(link);
                            tmsWait.Hard(2);
                            IWebElement oevlink = Browser.Wd.FindElement(By.XPath("//label[contains(.,'OEV Letter')]"));
                            fw.ExecuteJavascript(oevlink);
                            tmsWait.Hard(2);
                            bool iselementpresent;
                            By oev = By.XPath("//kendo-switch[contains(@class,'k-switch-on')]");
                            try
                            {
                                iselementpresent = Browser.Wd.FindElement(oev).Displayed;
                                fw.ConsoleReport(" OEV is already in ON Status");
                            }
                            catch
                            {
                                Browser.Wd.FindElement(By.XPath("//kendo-switch[@test-id='oevletter-input-all']/span")).Click();
                                tmsWait.Hard(2);
                            }

                        }

                        else
                        {
                            IWebElement link = Browser.Wd.FindElement(By.XPath("//a[@title='EAM Configuration']"));
                        fw.ExecuteJavascript(link);
                        tmsWait.Hard(2);
                        IWebElement oevlink = Browser.Wd.FindElement(By.CssSelector("[test-id='10']"));
                        fw.ExecuteJavascript(oevlink);
                        tmsWait.Hard(2);
                        bool iselementpresent;
                        By oev = By.XPath("//div[@id='mainSwitchButtonArea']//span[contains(@class,'switch-on')]");
                        try
                        {
                            iselementpresent = Browser.Wd.FindElement(oev).Displayed;
                            fw.ConsoleReport(" OEV is already in ON Status");
                        }
                        catch
                        {
                            Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-container km-switch-container'])[1]")).Click();
                            tmsWait.Hard(2);
                        }
                        }

                        //linkTextValue = "Outbound Enrl Verif";
                        //string[] IDs = new string[]
                        //{
                        //    "ctl00_ctl00_MainMasterContent_EamNavigation_pnlLetters_ctl01_ctl12_link"
                        //}; arrIDs = IDs;

                        break;
                    }
                    
                case "LettersPostCMS":
                    {
                        linkTextValue = "Post-CMS";
                        string[] IDs = new string[]
                        {
                            "ctl00_ctl00_MainMasterContent_EamNavigation_pnlLetters_ctl02_item",
                            "Navigation1_pnlLetters_ctl02_item"
                        }; arrIDs = IDs; break;
                    }
                case "LettersPostCMSConfirmEnroll":
                    {
                        linkTextValue = "Confirm Enroll";
                        string[] IDs = new string[]
                        {
                            "ctl00_ctl00_MainMasterContent_EamNavigation_pnlLetters_ctl02_ctl01_link",
                            "Navigation1_pnlLetters_ctl02_ctl01_link"
                        }; arrIDs = IDs; break;
                    }
                case "LettersPostCMSConfirmPassEnroll":
                    {
                        linkTextValue = "Confirm Pass Enroll";
                        string[] IDs = new string[]
                        {
                            "ctl00_ctl00_MainMasterContent_EamNavigation_pnlLetters_ctl02_ctl01_link",
                            "Navigation1_pnlLetters_ctl02_ctl02_link"
                        }; arrIDs = IDs; break;
                    }
                case "LettersPostCMSPlanChange":
                    {
                        linkTextValue = "Plan Change";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlLetters_ctl02_hPlanChangePost_link"
                        }; arrIDs = IDs; break;
                    }
                case "LettersPostCMSConfirmDisenroll":
                    {
                        linkTextValue = "Confirm Disenroll";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlLetters_ctl02_ctl03_link"
                        }; arrIDs = IDs; break;
                    }
                case "LettersPostCMSRejectEnroll":
                    {
                        linkTextValue = "Reject Enroll";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlLetters_ctl02_ctl04_link"
                        }; arrIDs = IDs; break;
                    }
                case "LettersPostCMSRejectDisenroll":
                    {
                        linkTextValue = "Reject Disenroll";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlLetters_ctl02_ctl05_link"
                        }; arrIDs = IDs; break;
                    }
                case "LettersPostCMSDisenrollDeath":
                    {
                        linkTextValue = "Disenroll Death";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlLetters_ctl02_ctl06_link"
                        }; arrIDs = IDs; break;
                    }
                case "LettersPostCMSLossofPartAB":
                    {
                        linkTextValue = "Loss of Part A/B";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlLetters_ctl02_ctl07_link"
                        }; arrIDs = IDs; break;
                    }
                case "LettersPostCMSStatusUpdate":
                    {
                        linkTextValue = "Status Update";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlLetters_ctl02_ctl08_link"
                        }; arrIDs = IDs; break;
                    }
                case "LettersPostCMSRDSLetter":
                    {
                        linkTextValue = "RDS Letter";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlLetters_ctl02_ctl09_link"
                        }; arrIDs = IDs; break;
                    }
                case "LettersPostCMSInvolDisenrollPartD":
                    {
                        linkTextValue = "Invol Disenroll PartD";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlLetters_ctl02_ctl10_link"
                        }; arrIDs = IDs; break;
                    }
                case "LettersPostCMSPotentialOOA":
                    {
                        linkTextValue = "Potential OOA";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlLetters_ctl02_ctl11_link"
                        }; arrIDs = IDs; break;
                    }
                case "LettersPostCMSDisenrollPremium":
                    {
                        linkTextValue = "Disenroll Premium";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlLetters_ctl02_ctl12_link"
                        }; arrIDs = IDs; break;
                    }
                case "LettersPostCMSLISRider":
                    {
                        linkTextValue = "LIS Rider";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlLetters_ctl02_ctl13_link"
                        }; arrIDs = IDs; break;
                    }
                case "LettersPostCMSLossofLIS":
                    {
                        linkTextValue = "Loss of LIS";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlLetters_ctl02_ctl14_link"
                        }; arrIDs = IDs; break;
                    }
                case "LettersPostCMSRemovalofLISPeriod":
                    {
                        linkTextValue = "Removal of LIS Period";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlLetters_ctl02_ctl15_link"
                        }; arrIDs = IDs; break;
                    }
                case "LettersPostCMSConfirmationofReinstatement":
                    {
                        linkTextValue = "Confirmation of Reinstatement";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlLetters_ctl02_ctl16_link"
                        }; arrIDs = IDs; break;
                    }
                case "LettersPostCMSConfDisenrollDuePassiveEnrollIntoMMPPlan":
                    {
                        linkTextValue = "Conf Disenroll Due Passive Enroll Into MMP Plan";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlLetters_ctl02_ctl17_link"
                        }; arrIDs = IDs; break;
                    }
                case "LettersPostCMSConfirmationofCancellationofEnrollmentDuetoNoticefromCMSTRC015":
                    {
                        linkTextValue = "Confirmation of Cancellation of Enrollment Due to Notice from CMS (TRC 015)";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlLetters_ctl02_ctl18_link",
                            "ctl00_ctl00_MainMasterContent_EamNavigation_pnlLetters_ctl02_ctl18_link"
                        }; arrIDs = IDs; break;
                    }

                case "LettersPostCMSDisenrollIncarceration":
                    {
                        linkTextValue = "Disenroll Incarceration";
                        string[] IDs = new string[]
                        {
                            //"Navigation1_pnlLetters_ctl02_ctl19_link",
                            "ctl00_ctl00_MainMasterContent_EamNavigation_pnlLetters_ctl02_ctl19_link"
                        }; arrIDs = IDs; break;
                    }
                case "LettersPostCMSDisenrollNotLawfullyPresent":
                    {
                        linkTextValue = "Disenroll Incarceration";
                        string[] IDs = new string[]
                        {
                           // "Navigation1_pnlLetters_ctl02_ctl20_link",
                            "ctl00_ctl00_MainMasterContent_EamNavigation_pnlLetters_ctl02_ctl20_link"
                        }; arrIDs = IDs; break;
                    }
                case "LettersOnDemand":
                    {
                        linkTextValue = "On Demand";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlLetters_ctl03_link"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsCMSResponse":
                    {
                        linkTextValue = "CMS Response";
                        string[] IDs = new string[]
                        {
                            "Navigation1_lnkRepTRRCode",
                            "ctl00_ctl00_MainMasterContent_EamNavigation_lnkRepTRRCode"
                        }; arrIDs = IDs;

                        break;
                    }
                case "ReportsCMSResponseCodeLevelDetail":
                    {
                        linkTextValue = "Code Level Detail";
                        string[] IDs = new string[]
                        {
                            "Navigation1_lnkRepTRRCode",
                            "ctl00_ctl00_MainMasterContent_EamNavigation_lnkRepTRRCode" 
                        }; arrIDs = IDs; break;
                    }
                case "ReportsTransactionElectionTypeValidation":
                    {
                        linkTextValue = "Election Type Validation";
                        string[] IDs = new string[]
                        {
                            "ctl00_ctl00_MainMasterContent_EamNavigation_linkElectionValidation"
                            
                        }; arrIDs = IDs; break;
                    }

                case "ReportsCMSResponsePremiumCDiscrepancies700TRCs":
                    {
                        linkTextValue = "Premium C Discrepancies 700 TRCs";
                        string[] IDs = new string[]
                        {
                            "Navigation1_lnkPemCDescerps"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsCMSResponseTRRSummary":
                    {
                        linkTextValue = "TRR Summary";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkTRRSummary"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsCMSResponseTRRDetail":
                    {
                        linkTextValue = "TRR Detail";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkTRRDetail"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsCMSResponseBCSSSummary":
                    {
                        linkTextValue = "BCSS Summary";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkBCSSSummary"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsCMSResponseBCSSDetail":
                    {
                        linkTextValue = "BCSS Detail";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkBCSSDetail"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsCMSResponseRecordsDupedOutfromTRR":
                    {
                        linkTextValue = "Records Duped Out from T/RR";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkTRRDupedOutRec"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsCMSResponseNoPremiumDue":
                    {
                        linkTextValue = "No Premium Due";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkNoPremiumDue"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsCMSResponseAvoidableUnavoidableTRCSummary":
                    {
                        linkTextValue = "Avoidable / Unavoidable TRC Summary";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkAvoidableNonAvoidable"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsCMSResponseAvoidableTRCDetail":
                    {
                        linkTextValue = "Avoidable TRC Detail";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkAvoidableTRCDetail"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsCMSResponseAutomatedSpans":
                    {
                        linkTextValue = "Automated Spans";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkAutomatedSpans"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsCorrespondence":
                    {
                        linkTextValue = "Correspondence";
                        string[] IDs = new string[]
                        {
                            "imageCorres"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsCorrespondenceByMember":
                    {
                        linkTextValue = "By Member";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkByMember"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsCorrespondenceByLetterType":
                    {
                        linkTextValue = "By LetterType";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkLetterType"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsEligibility":
                    {
                        linkTextValue = "Eligibility";
                        string[] IDs = new string[]
                        {
                            "imageElig"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsEligibilityCheckSummary":
                    {
                        linkTextValue = "Check Summary";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkCheckSummary"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsEligibilityPassed":
                    {
                        linkTextValue = "Passed";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkPassed",
                            "ctl00_MainMasterContent_ctl00_lnkPassed"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsEligibilityFailedBEQ":
                    {
                        linkTextValue = "Failed BEQ";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkFailedBEQ"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsEligibilityBEQsentnotRecd":
                    {
                        linkTextValue = "BEQ sent not Rec'd";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkBEQSentNotRecd"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsEligibilityABDDiscrep":
                    {
                        linkTextValue = "A/B/D Discrep";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkABDiscrep"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsEligibilityBEQDetails":
                    {
                        linkTextValue = "BEQ Details";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkBEQDetails"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsEligibilityBEQMismatches":
                    {
                        linkTextValue = "BEQ Mismatches";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkBEQMismatches"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsEnrollment":
                    {
                        linkTextValue = "Enrollment";
                        string[] IDs = new string[]
                        {
                            "imageEnrol"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsEnrollmentEnrollSummary":
                    {
                        linkTextValue = "Enroll Summary";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkEnrlSummary"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsEnrollmentDisenrollReason":
                    {
                        linkTextValue = "Disenroll Reason";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkDisReason"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsEnrollmentOECEAFFallout":
                    {
                        linkTextValue = "OEC/EAF Fallout";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkFallout","ctl00_ctl00_MainMasterContent_EamNavigation_lnkFallout"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsEnrollmentCanceledEnrollments":
                    {
                        linkTextValue = "Canceled Enrollments";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkCanEnroll"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsEnrollmentDisenrollReasonDetail":
                    {
                        linkTextValue = "Disenroll Reason Detail";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkDisReasonDetail"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsEnrollmentTransactionsMissingCMSData":
                    {
                        linkTextValue = "Transactions Missing CMS Data";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkOECEAFMissingCMSData"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsLIS":
                    {
                        linkTextValue = "LIS";
                        string[] IDs = new string[]
                        {
                            "imageLIS"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsLISLISHistoryFileRecon":
                    {
                        linkTextValue = "LIS History File Recon";
                        string[] IDs = new string[]
                        {
                            "imageLisReconReports"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsLISLISHistoryFileReconLISDiscrepancies":
                    {
                        linkTextValue = "LIS Discrepancies";
                        string[] IDs = new string[]
                        {
                            "Navigation1_lnkLisDiscrepancies"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsLISLISHistoryFileReconLISHistoryFileRecon":
                    {
                        linkTextValue = "LIS History File Recon";
                        string[] IDs = new string[]
                        {
                            "Navigation1_lnkLisHistoryFileRecon",
                            "imageLisReconReports",
                            "ctl06_lnkLisHistoryFileRecon",
                            "ctl00_MainMasterContent_ctl00_lnkLisHistoryFileRecon"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsLISDeemedLISRpt":
                    {
                        linkTextValue = "Deemed LIS Rpt";
                        string[] IDs = new string[]
                        {
                            "Navigation1_lnkLISRpt"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsLISLISRoster":
                    {
                        linkTextValue = "LIS Roster";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkLISRoster"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsLISLISHistoryDataSingleMember":
                    {
                        linkTextValue = "LIS History Data - Single Member";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkLISHistDataSingleMem"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsLISLISHistoryDataAllMembers":
                    {
                        linkTextValue = "LIS History Data - All Members";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkLISHistDataAllMem"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsMember":
                    {
                        linkTextValue = "Member";
                        string[] IDs = new string[]
                        {
                            "imageMember"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsMemberSingleMember":
                    {
                        linkTextValue = "Single Member";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkSinMem"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsMemberAllMembers":
                    {
                        linkTextValue = "All Members";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkAllMem"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsMemberMemberRoster":
                    {
                        linkTextValue = "Member Roster";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkMemRos"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsMemberIDHistory":
                    {
                        linkTextValue = "ID History";
                        string[] IDs = new string[]
                        {
                            "ctl00_ctl00_MainMasterContent_EamNavigation_lnkIDHistory"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsMemberWithoutTrans":
                    {
                        linkTextValue = "Without Trans";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkWTrans"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsMemberCOBReport":
                    {
                        linkTextValue = "COB Report";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkCOBRpt"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsMemberMissing4RxData":
                    {
                        linkTextValue = "Missing 4Rx Data";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkMis4RxData"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsMemberMembersbyPremiumWithholdOption":
                    {
                        linkTextValue = "Members by Premium Withhold Option";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkMemPreWithOpt"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsMemberMemberswithLEP":
                    {
                        linkTextValue = "Members with LEP";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkMemLEP"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsMemberMembersTRRHistory":
                    {
                        linkTextValue = "Members T/RR History";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkTRRHistory"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsMemberMemberOOAStatus":
                    {
                        linkTextValue = "Member OOA Status";
                        string[] IDs = new string[]
                        {
                            "ctl00_MainMasterContent_ctl00_lnkMemberOOAStatus"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsMemberSNPFollowupActivity":
                    {
                        linkTextValue = "SNP Follow up Activity";
                        string[] IDs = new string[]
                        {
                            "ctl00_MainMasterContent_ctl00_lnkSNPFollowupActivity"
                        }; arrIDs = IDs; break;
                    }


                case "ReportsNotesActions":
                    {
                        linkTextValue = "Notes/Actions";
                        string[] IDs = new string[]
                        {
                            "imageNote"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsNotesActionsNotesActions":
                    {
                        linkTextValue = "Notes/Actions";
                        string[] IDs = new string[]
                        {
                            "Navigation1_lnkNotesActions","ctl06_lnkNotesActions"
                        }; arrIDs = IDs; break;
                    }

                case "AuditingConfiguration":
                    {
                        linkTextValue = "AuditingConfiguration";
                        string[] IDs = new string[]
                        {
                            "ctl00_ctl00_MainMasterContent_EamNavigation_pnlUserAdmin_auditConfiguration_link"
                        }; arrIDs = IDs; break;
                    }

                case "ReportsNotesActionsPastDueActions":
                    {
                        linkTextValue = "Past Due Actions";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkPastDueActions"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsQueue":
                    {
                        linkTextValue = "Queue";
                        string[] IDs = new string[]
                        {
                            "imageQue"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsQueueLetterQueueRpt":
                    {
                        linkTextValue = "Letter Queue Rpt";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkLetterQRpt"
                        }; arrIDs = IDs; break;
                    }

                case "ReportsQueueLetterStatus":
                    {
                        linkTextValue = "Letter Status";
                        string[] IDs = new string[]
                        {
                            "ctl00_MainMasterContent_ctl00_lnkLetterQRpt"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsQueueSendToCMS":
                    {
                        linkTextValue = "Send To CMS Queue  ";
                        string[] IDs = new string[]
                        {
                            ""
                         
                        }; arrIDs = IDs; break;
                    }
                case "ReportsTransaction":
                    {
                        linkTextValue = "Transaction";
                        string[] IDs = new string[]
                        {
                            "imageTrans"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsTransactionNewChanged":
                    {
                        linkTextValue = "New/Changed";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkNewChanged"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsTransactionSummary":
                    {
                        linkTextValue = "Summary";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkSummary"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsTransactionDetail":
                    {
                        linkTextValue = "Detail";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkDetail"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsTransactionForcedTrans":
                    {
                        linkTextValue = "Forced Trans";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkForcedTrans"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsTransactionIncompleteTrans":
                    {
                        linkTextValue = "Incomplete Trans";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkInTrans"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsTransactionDenialReport":
                    {
                        linkTextValue = "Denial Report";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkDenialRpt"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsTransactionNoRxFalloutReport":
                    {
                        linkTextValue = "NoRx Fallout Report";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkNoRxFallout"
                        }; arrIDs = IDs; break;
                    }

                case "MembersViewEditRxBillingTab":
                    {
                        linkTextValue = "Rx/Billing";
                        string[] IDs = new string[]
                        {
                            "ctl00_ctl00_MainMasterContent_MainContent_btnBilling"
                        }; arrIDs = IDs; break;
                    }

                case "ReportsTransactionAutoenrollee72FalloutReport":
                    {
                        linkTextValue = "Autoenrollee 72 Fallout Report";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkAutoEnroll72Fallout"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsTransactionOutofAreaTrans":
                    {
                        linkTextValue = "Out of Area Trans";
                        string[] IDs = new string[]
                        {
                            "ctl06_lnkOutofTran"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsTransactionPossibleNumberofUncoveredMonthsChange":
                    {
                        linkTextValue = "Possible Number of Uncovered Months Change";
                        string[] IDs = new string[]
                        {
                            "ctl06_linkPosNUncMo"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsCompliance":
                    {
                        linkTextValue = "Compliance";
                        string[] IDs = new string[]
                        {
                            "imageCompliance"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsComplianceEnrollment":
                    {
                        linkTextValue = "Enrollment";
                        string[] IDs = new string[]
                        {
                            "ctl00_MainMasterContent_ctl00_hlEnrollment","ctl06_hlEnrollment","ctl06_hlEnrollment","Navigation1_hlEnrollment"
                        }; arrIDs = IDs; break;
                    }
                case "ReportsComplianceDisenrollment":
                    {
                        linkTextValue = "Disenrollment";
                        string[] IDs = new string[]
                        {
                            "ctl00_MainMasterContent_ctl00_hlDisenrollment","ctl06_hlDisenrollment"
                        }; arrIDs = IDs; break;
                    }

                case "CoreSystems":
                    {
                        linkTextValue = "Core Systems";
                        string[] IDs = new string[]
                        {
                            "root_admin_N manuIcons","External Systems"
                        }; arrIDs = IDs; break;
                    }


                case "AdministrationExternalIntegration":
                    {
                        linkTextValue = "External Integration";
                        string[] IDs = new string[]
                        {
                            "ctl06_pnlUserAdmin_ctl01_link"
                        }; arrIDs = IDs; break;
                    }
                case "AdministrationViewEditPlanInfo":
                    {
                        linkTextValue = "View/Edit Plan Info.";
                        string[] IDs = new string[]
                        {
                            "ctl06_pnlUserAdmin_ctl02_link",
                            "ctl00_ctl00_MainMasterContent_EamNavigation_pnlUserAdmin_ctl02_link"
                        }; arrIDs = IDs; break;
                    }
                case "AdministrationPage":
                    {
                        linkTextValue = "";
                        string[] Ids = new string[]
                        {
                            "ctl00_ctl00_ProductMenu1_Menu1-menuItem000"
                        }; arrIDs = Ids; break;
                    }
                case "AdministrationStatusOverride":
                    {
                        linkTextValue = "Status Override";
                        string[] IDs = new string[]
                        {
                            "ctl06_pnlUserAdmin_itemStatusOverride_link", "ctl00_ctl00_MainMasterContent_EamNavigation_pnlUserAdmin_itemStatusOverride_link"
                        }; arrIDs = IDs; break;
                    }
                case "AdministrationExportSession":
                    {
                        if (ConfigFile.tenantType.Equals("tmsx"))
                        {
                            tmsWait.Hard(3);
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Administration']")));
                            tmsWait.Hard(3);
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@test-id='subMenu-titleList']//span[contains(.,'Export Session')]")));
                        }
                        else
                        {
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@title='Administration']")));
                            tmsWait.Hard(3);
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@title='Export Session']")));
                        }
                      

                        break;
                    }
                case "AdministrationLetters":
                    {
                        if (ConfigFile.tenantType.Equals("tmsx"))
                        {
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Administration']")));
                            tmsWait.Hard(3);
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@test-id='subMenu-titleList']//span[contains(.,'Letters')]")));
                        }
                        else
                        {
                            By lettertemp = By.XPath("(//a[@title='Letters'])[2]");
                            UIMODUtilFunctions.clickOnWebElementUsingLocators(lettertemp);
                            tmsWait.Hard(3);
                            //linkTextValue = "Letters";
                            //string[] IDs = new string[]
                            //{
                            //    "Navigation1_pnlUserAdmin_ctl03_item",
                            //    "ctl00_ctl00_MainMasterContent_EamNavigation_pnlUserAdmin_ctl03_item"
                            //}; arrIDs = IDs;
                        }
                        break;
                    }
                case "AdministrationLettersLetterTemplates":
                    {

                        if (ConfigFile.tenantType.Equals("tmsx"))
                        {
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@id='k-tabstrip-tab-0']/span")));
                            tmsWait.Hard(2);
                        }
                        else
                        {
                            By temp = By.CssSelector("[test-id='frmLetters-tab-Letters'] a");
                            UIMODUtilFunctions.clickOnWebElementUsingLocators(temp);
                            tmsWait.Hard(2);
                            //linkTextValue = "Letter Templates";
                            //string[] IDs = new string[]
                            //{
                            //    "Navigation1_pnlUserAdmin_ctl03_ctl01_link",
                            //    "ctl00_ctl00_MainMasterContent_EamNavigation_pnlUserAdmin_ctl03_ctl01_link"
                            //}; arrIDs = IDs;

                        }
                        break;
                    }
                case "AdministrationLettersOnDemandLetterNames":
                    {
                        if (ConfigFile.tenantType.Equals("tmsx"))
                        {
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@id='k-tabstrip-tab-1']/span")));
                            tmsWait.Hard(2);
                        }
                        else
                        {
                            By temp = By.LinkText("On-Demand Letter Names & Templates");
                            UIMODUtilFunctions.clickOnWebElementUsingLocators(temp);
                            tmsWait.Hard(2);
                        }

                        break;
                    }
                case "AdministrationLettersOnDemandLetterTemplates":
                    {
                        if (ConfigFile.tenantType.Equals("tmsx"))
                        {
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@id='k-tabstrip-tab-1']/span")));
                            tmsWait.Hard(2);
                        }
                        else
                        {
                            By temp = By.LinkText("On-Demand Letter Names & Templates");
                            UIMODUtilFunctions.clickOnWebElementUsingLocators(temp);
                            tmsWait.Hard(2);
                        }

                        break;
                    }
                case "AdministrationRecalculations":
                    {
                        linkTextValue = "Recalculations";
                        string[] IDs = new string[]
                        {
                            "ctl00_navigation_pnlUserAdmin_ctl04_link"
                        }; arrIDs = IDs; break;
                    }
                case "AdministrationEditLISInformation":
                    {
                        //linkTextValue = "Edit LIS Information";
                        //string[] IDs = new string[]
                        //{
                        //    "ctl00_navigation_pnlUserAdmin_ctl05_link"
                        //}; arrIDs = IDs; 
                        IWebElement ele = Browser.Wd.FindElement(By.CssSelector("a[title='Edit LIS Information']"));
                        fw.ExecuteJavascript(ele);
                        tmsWait.Hard(2);
                        break;
                    }
                case "AdministrationPlanDefinedFields":
                    {
                        IWebElement link = Browser.Wd.FindElement(By.XPath("//a[@title='EAM Configuration']"));
                        fw.ExecuteJavascript(link);
                        tmsWait.Hard(2);
                    
                        //linkTextValue = "EAM Configuration";
                        //string[] IDs = new string[]
                        //{
                        //    "Navigation1_pnlUserAdmin_ctl06_link",
                        //    "ctl00_ctl00_MainMasterContent_EamNavigation_pnlUserAdmin_ctl06_link"
                        //}; arrIDs = IDs;

                        break;
                    }
                case "AdministrationBEQCMSTransfer":
                    {
                        linkTextValue = "BEQ/CMS Transfer";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlUserAdmin_ctl07_link"
                        }; arrIDs = IDs; break;
                    }
                case "AdministrationManagePlanSCC":
                    {
                        linkTextValue = "Manage Plan/SCC";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlUserAdmin_ctl08_item"
                        }; arrIDs = IDs; break;
                    }
                case "AdministrationManagePlanSCCViewEdit":
                    {
                        linkTextValue = "View/Edit";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlUserAdmin_ctl08_ctl01_link",
                            "Navigation1_pnlUserAdmin_ctl09_ctl01_link",
                            "ctl00_ctl00_MainMasterContent_EamNavigation_pnlUserAdmin_ctl09_ctl01_link"
                        }; arrIDs = IDs; break;
                    }
                case "AdministrationManagePlanSCCUploadNewFile":
                    {
                        linkTextValue = "Upload New File";
                        string[] IDs = new string[]
                        {
                            "Navigation1_pnlUserAdmin_ctl08_ctl02_link"
                        }; arrIDs = IDs; break;
                    }
                case "AdministrationMMPManagement":
                    {
                        linkTextValue = "MMP Management";
                        string[] IDs = new string[]
                        {
                            "ctl00_ctl00_MainMasterContent_EamNavigation_pnlUserAdmin_ctl10_link"

                        }; arrIDs = IDs; break;
                    }
                case "AdministrationTRCRules":
                    {
                        linkTextValue = "TRC Rules";
                        string[] IDs = new string[]
                        {
                            "ctl00_navigation_pnlUserAdmin_ctl10_link"
                        }; arrIDs = IDs; break;
                    }
                case "AdministrationUsers":
                    {
                        linkTextValue = "Users";
                        string[] IDs = new string[]
                        {
                            "Navigation1_Hyperlink1"
                        }; arrIDs = IDs; break;
                    }
                case "AdministrationJobs":
                    {
                        linkTextValue = "Jobs";
                        string[] IDs = new string[]
                        {
                            "Navigation1_Hyperlink1"
                        }; arrIDs = IDs; break;
                    }
                case "AdministrationDBVersions":
                    {
                        linkTextValue = "DB Versions";
                        string[] IDs = new string[]
                        {
                            "Navigation1_Hyperlink1"
                        }; arrIDs = IDs; break;
                    }
                case "AdministrationWebConfiguration":
                    {
                        linkTextValue = "Web Configuration";
                        string[] IDs = new string[]
                        {
                            "Navigation1_Hyperlink1"
                        }; arrIDs = IDs; break;
                    }
                case "AdministrationWorkFlowConfig":
                    {
                        linkTextValue = "Workflow Config.";
                        string[] IDs = new string[]
                        {
                            "Navigation1_Hyperlink1"
                        }; arrIDs = IDs; break;
                    }
                case "AdministrationWarehouseConfig":
                    {
                        linkTextValue = "Warehouse Config.";
                        string[] IDs = new string[]
                        {
                            "Navigation1_Hyperlink1"
                        }; arrIDs = IDs; break;
                    }
                case "TmsOperationConfig":
                    {
                        linkTextValue = "TMSOperational Config.";
                        string[] IDs = new string[]
                        {
                            "Navigation1_Hyperlink1"
                        }; arrIDs = IDs; break;
                    }
                case "TCSConfiguration":
                    {
                        linkTextValue = "TCS Configuration";
                        string[] IDs = new string[]
                        {
                            "Navigation1_Hyperlink1"
                        }; arrIDs = IDs; break;
                    }
                case "NotesActionsView":
                    {
                        linkTextValue = "View";
                        string[] IDs = new string[]
                        {
                            "ctl00_ctl00_MainMasterContent_EamNavigation_lnkNote"
                        }; arrIDs = IDs; break;
                    }
                case "ChangePassword":
                    {
                        linkTextValue = "Change Password";
                        string[] IDs = new string[]
                        {
                            "Navigation1_changePassword","ctl00_navigation_changePassword"
                        }; arrIDs = IDs; break;
                    }
                case "Logout":
                    {
                        linkTextValue = "Logout";
                        string[] IDs = new string[]
                        {
                            "Navigation1_logout","ctl06_logout"
                        }; arrIDs = IDs; break;
                    }
                case "WorkFlowStart":
                    {
                        linkTextValue = "Start";
                        string[] IDs = new string[]
                        {
                            "MainMasterContent_EamNavigation_sectionWorkload_WorkflowItem_link"

                        }; arrIDs = IDs; break;
                    }
                case "AdministrationWorkFlow":
                    {
                        linkTextValue = "Workflow";
                        string[] IDs = new string[]
                        {
                            "ctl00_ctl00_MainMasterContent_EamNavigation_pnlUserAdmin_workFlowAdministrator_link"

                        }; arrIDs = IDs; break;
                    }
                case "WorkFlowConfig":
                    {
                        linkTextValue = "Workflow Config.";
                        string[] IDs = new string[]
                        {
                            "Navigation1_menuWorkloadConfiguration"
                        }; arrIDs = IDs; break;
                    }

                case "AdministrationWorkflowDashboard":
                case "WorkflowDashboard":
                    {
                        linkTextValue = "Workflow Dashboard";
                        string[] IDs = new string[]
                        {
                            "ctl00_ctl00_MainMasterContent_EamNavigation_pnlUserAdmin_workFlowDashBoard_link"
                        }; arrIDs = IDs; string scrolltoAddUserBtn = "window.scrollBy(0,100)";
                        fw.ExecuteJavascript(scrolltoAddUserBtn); break;
                    }


                case "TRRRulesConfig":
                    {
                        linkTextValue = "TRR Rules Config.";
                        string[] IDs = new string[]
                        {
                            "ctl00_ctl00_MainMasterContent_EamNavigation_pnlUserAdmin_trrConfigurations_link"
                        }; arrIDs = IDs; string scrolltoAddUserBtn = "window.scrollBy(0,100)";
                        fw.ExecuteJavascript(scrolltoAddUserBtn); break;
                    }

                case "ERF":
                    {
                        linkTextValue = "New";
                        string[] IDs = new string[]
                        {
                            "ctl00_ctl00_MainMasterContent_EamNavigation_pnlEnrollment_subitemErfEnrollment_link"
                        }; arrIDs = IDs; break;
                    }

                //case "EAMConfiguration":
                //    {
                //        linkTextValue = "EAM Configuration";
                //        string[] IDs = new string[]
                //        {
                //            "ctl00_ctl00_MainMasterContent_EamNavigation_pnlUserAdmin_ctl06_link"
                //        }; arrIDs = IDs; break;
                //    }


               

                default:
                    {
                        Assert.AreEqual(false, true, "The Menu item [" + strNavigation + "] was not matched");
                        break;
                    }
            }
            //ReadOnlyCollection<OpenQA.Selenium.IWebElement> myCollection = Browser.Wd.FindElements(By.LinkText(linkTextValue));
            //foreach (IWebElement thisElement in myCollection)
            //{
            //    bFoundLink = false;
            //    //try
            //    //{
            //    //    bFoundLink = false;
            //    //    string strThisHref = thisElement.GetAttribute("href");
            //    //    string strThisID = thisElement.GetAttribute("id");
            //    //    if (myCollection.Count == 1)
            //    //    {
            //    //        //thisElement.Click();
            //    //        tmsWait.Hard(3);
            //    //        fw.ExecuteJavascript(thisElement);
            //    //        bFoundLink = true;
            //    //        break;
            //    //    }
            //    //    else
            //    //    {
            //    //        for (int i = 0; i <= arrIDs.Length; i++)
            //    //        {
            //    //            if (arrIDs[i] == strThisID)
            //    //            {
            //    //                //thisElement.Click();
            //    //                fw.ExecuteJavascript(thisElement);
            //    //                bFoundLink = true;
            //    //                break;
            //    //            }
            //    //        }
            //    //        if (bFoundLink) { break; }
            //    //    }
            //    //}
            //    //catch
            //    //{
            //    //}
            //}
            //if (!bFoundLink && !bHandledInCase)
            //{
            //    try
            //    {
            //        for (int i = 0; i <= arrIDs.Length; i++)
            //        {
            //            Browser.Wd.FindElement(By.Id(arrIDs[i])).Click();
            //            bFoundLink = true;
            //            break;
            //        }
            //    }
            //    catch
            //    {
            //    }
            //}
            //if (!bFoundLink && !bHandledInCase)
            //{
            //    Assert.AreEqual(bFoundLink, true, "The Menu item [" + strNavigation + "] with link text [" + linkTextValue + "] was not matched and clicked on.");
            //}
        }

        public static void navigateIDMURL()
        {
            ConfigFile.ReadFromConfigFile();
            Console.WriteLine("Begin Navigate");
            Browser.SetWebdriverType(ConfigFile.BrowserType);
            Console.WriteLine("Finished SetWebdriverType to config file browser type");
            if (!ConfigFile.BrowserType.Equals("chromep"))
            {
                Browser.Wd.Manage().Window.Maximize();
            }
            Console.WriteLine("Finished Window Maximize");

          
            Browser.Wd.Navigate().GoToUrl(ConfigFile.IDMURL);

            if (ConfigFile.BrowserType.Equals("ie"))
            {
                tmsWait.Hard(15); //  this wait is intentional
            }

            if (Browser.Wd.Title.Equals("Certificate Error: Navigation Blocked"))
            {
                Browser.Wd.Navigate().GoToUrl("javascript:document.getElementById('overridelink').click()");
            }

            if (ConfigFile.BrowserType.Equals("chrome"))
            {
                try
                {
                    IWebElement advancedButton = Browser.Wd.FindElement(By.CssSelector("[id='details-button']"));
                    fw.ExecuteJavascript(advancedButton);
                    tmsWait.Hard(5);

                    IWebElement acceptRiskBtn = Browser.Wd.FindElement(By.CssSelector("[id='proceed-link']"));
                    fw.ExecuteJavascript(acceptRiskBtn);
                    tmsWait.Hard(10);

                    IWebElement advancedButton1 = Browser.Wd.FindElement(By.CssSelector("[id='details-button']"));
                    fw.ExecuteJavascript(advancedButton1);
                    tmsWait.Hard(5);

                    IWebElement acceptRiskBtn1 = Browser.Wd.FindElement(By.CssSelector("[id='proceed-link']"));
                    fw.ExecuteJavascript(acceptRiskBtn1);

                }
                catch
                {
                    fw.ConsoleReport("There is no Certiicate Warning");
                }
            }


            if (ConfigFile.BrowserType.Equals("edge") || ConfigFile.BrowserType.Equals("edgelegacy"))
            {
                try
                {
                    IWebElement advancedButton = Browser.Wd.FindElement(By.CssSelector("[id='continueLink']"));
                    fw.ExecuteJavascript(advancedButton);
                    tmsWait.Hard(5);

                    IWebElement acceptRiskBtn = Browser.Wd.FindElement(By.CssSelector("[id='continueLink']"));
                    fw.ExecuteJavascript(acceptRiskBtn);
                    tmsWait.Hard(10);

                    //IWebElement advancedButton1 = Browser.Wd.FindElement(By.CssSelector("[id='details-button']"));
                    //fw.ExecuteJavascript(advancedButton1);
                    //tmsWait.Hard(5);

                    //IWebElement acceptRiskBtn1 = Browser.Wd.FindElement(By.CssSelector("[id='proceed-link']"));
                    //fw.ExecuteJavascript(acceptRiskBtn1);
                    //tmsWait.Hard(5);
                }

                catch
                {
                    fw.ConsoleReport("There is no Certiicate Warning");
                }

            }

            if (ConfigFile.BrowserType.Equals("firefox"))
            {
                try
                {
                    IWebElement advancedButton = Browser.Wd.FindElement(By.Id("advancedButton"));
                    fw.ExecuteJavascript(advancedButton);
                    tmsWait.Hard(5);

                    IWebElement acceptRiskBtn = Browser.Wd.FindElement(By.Id("exceptionDialogButton"));
                    fw.ExecuteJavascript(acceptRiskBtn);
                    tmsWait.Hard(10);

                    IWebElement advancedButton1 = Browser.Wd.FindElement(By.Id("advancedButton")); // Due to Stale Element reference Exception, we created Duplicate statement
                    fw.ExecuteJavascript(advancedButton1);
                    tmsWait.Hard(5);

                    IWebElement acceptRiskBtn1 = Browser.Wd.FindElement(By.Id("exceptionDialogButton"));
                    fw.ExecuteJavascript(acceptRiskBtn1);
                    tmsWait.Hard(10);

                }
                catch
                {
                    fw.ConsoleReport("There is no Warning: Potential Security Risk Ahead");
                }
            }

            if (ConfigFile.BrowserType.Equals("ie"))
            {
                try
                {
                    IWebElement Moreinformation = Browser.Wd.FindElement(By.LinkText("More information"));
                    fw.ExecuteJavascript(Moreinformation);
                    tmsWait.Hard(2);

                    IWebElement Goontothewebpage = Browser.Wd.FindElement(By.PartialLinkText("Go on to the webpage"));
                    fw.ExecuteJavascript(Goontothewebpage);
                    tmsWait.Hard(10);


                    IWebElement Moreinformation1 = Browser.Wd.FindElement(By.LinkText("More information"));
                    fw.ExecuteJavascript(Moreinformation1);
                    tmsWait.Hard(2);

                    IWebElement Goontothewebpage1 = Browser.Wd.FindElement(By.PartialLinkText("Go on to the webpage"));
                    fw.ExecuteJavascript(Goontothewebpage1);

                }
                catch
                {
                    fw.ConsoleReport(" There is no App Server Certificate Issue");
                }
            }
            Console.WriteLine("Finished Goto URL to config file url.");
            tmsWait.Implicit(5);
            Console.WriteLine("Navigate is finished");
        }

        public static void navigate()
        {
            ConfigFile.ReadFromConfigFile(); 
            Console.WriteLine("Begin Navigate");
            Browser.SetWebdriverType(ConfigFile.BrowserType);
            Console.WriteLine("Finished SetWebdriverType to config file browser type");
            if (!ConfigFile.BrowserType.Equals("chromep"))
            {
                Browser.Wd.Manage().Window.Maximize();
            }
            Console.WriteLine("Finished Window Maximize");

            //2.27.2017 - Daron - Build Tenant URL
            string[] URLParts = ConfigFile.URL.Split('/');
            string newURL = URLParts[0] + "//" + ConfigFile.Tenant + ".";
            for (int i = 2; i < URLParts.GetUpperBound(0) + 1; i++)
            {
                newURL += URLParts[i] + "/";
            }
            //Browser.Wd.Navigate().GoToUrl(newURL);
                Browser.Wd.Navigate().GoToUrl(ConfigFile.URL);

            if (ConfigFile.BrowserType.Equals("ie"))
            {
                tmsWait.Hard(15); //  this wait is intentional
            }

                if (Browser.Wd.Title.Equals("Certificate Error: Navigation Blocked"))
            {
                Browser.Wd.Navigate().GoToUrl("javascript:document.getElementById('overridelink').click()");
            }
            

            if (ConfigFile.BrowserType.Equals("edge") || ConfigFile.BrowserType.Equals("chrome") || ConfigFile.BrowserType.Equals("edgelegacy") || ConfigFile.BrowserType.Equals("edgechrome"))
            {
                try
                {
                    IWebElement advancedButton = Browser.Wd.FindElement(By.CssSelector("[id='details-button']"));
                    fw.ExecuteJavascript(advancedButton);
                    tmsWait.Hard(5);

                    IWebElement acceptRiskBtn = Browser.Wd.FindElement(By.CssSelector("[id='proceed-link']"));
                    fw.ExecuteJavascript(acceptRiskBtn);
                    tmsWait.Hard(10);

                    IWebElement advancedButton1 = Browser.Wd.FindElement(By.CssSelector("[id='details-button']"));
                    fw.ExecuteJavascript(advancedButton1);
                    tmsWait.Hard(5);

                    IWebElement acceptRiskBtn1 = Browser.Wd.FindElement(By.CssSelector("[id='proceed-link']"));
                    fw.ExecuteJavascript(acceptRiskBtn1);

                }
                catch
                {
                    try
                    {
                        IWebElement continueBtn = Browser.Wd.FindElement(By.PartialLinkText("Continue to this webpage"));
                        fw.ExecuteJavascript(continueBtn);
                        tmsWait.Hard(5);
                    }
                    catch
                    {

                        fw.ConsoleReport("There is no Certiicate Warning");
                    }
                }
            }


            if (ConfigFile.BrowserType.Equals("edge") || ConfigFile.BrowserType.Equals("edgelegacy") || ConfigFile.BrowserType.Equals("edgechrome"))
            {
              try
                {
                    IWebElement advancedButton = Browser.Wd.FindElement(By.CssSelector("[id='continueLink']"));
                    fw.ExecuteJavascript(advancedButton);
                    tmsWait.Hard(5);

                    IWebElement acceptRiskBtn = Browser.Wd.FindElement(By.CssSelector("[id='continueLink']"));
                    fw.ExecuteJavascript(acceptRiskBtn);
                    tmsWait.Hard(10);

                    //IWebElement advancedButton1 = Browser.Wd.FindElement(By.CssSelector("[id='details-button']"));
                    //fw.ExecuteJavascript(advancedButton1);
                    //tmsWait.Hard(5);

                    //IWebElement acceptRiskBtn1 = Browser.Wd.FindElement(By.CssSelector("[id='proceed-link']"));
                    //fw.ExecuteJavascript(acceptRiskBtn1);
                    //tmsWait.Hard(5);
                }

                catch
                {
                    fw.ConsoleReport("There is no Certiicate Warning");
                }

            }

                if (ConfigFile.BrowserType.Equals("firefox"))
                {
                try
                {
                    IWebElement advancedButton = Browser.Wd.FindElement(By.Id("advancedButton"));
                    fw.ExecuteJavascript(advancedButton);
                    tmsWait.Hard(5);

                    IWebElement acceptRiskBtn = Browser.Wd.FindElement(By.Id("exceptionDialogButton"));
                    fw.ExecuteJavascript(acceptRiskBtn);
                    tmsWait.Hard(10);

                    IWebElement advancedButton1 = Browser.Wd.FindElement(By.Id("advancedButton")); // Due to Stale Element reference Exception, we created Duplicate statement
                    fw.ExecuteJavascript(advancedButton1);
                    tmsWait.Hard(5);

                    IWebElement acceptRiskBtn1 = Browser.Wd.FindElement(By.Id("exceptionDialogButton"));
                    fw.ExecuteJavascript(acceptRiskBtn1);
                    tmsWait.Hard(10);

                }
                catch
                {
                  fw.ConsoleReport("There is no Warning: Potential Security Risk Ahead");
                }
                }

                    if (ConfigFile.BrowserType.Equals("ie"))
            {
                try
                {
                    IWebElement Moreinformation = Browser.Wd.FindElement(By.LinkText("More information"));
                    fw.ExecuteJavascript(Moreinformation);
                    tmsWait.Hard(2);

                    IWebElement Goontothewebpage = Browser.Wd.FindElement(By.PartialLinkText("Go on to the webpage"));
                    fw.ExecuteJavascript(Goontothewebpage);
                    tmsWait.Hard(10);


                    IWebElement Moreinformation1 = Browser.Wd.FindElement(By.LinkText("More information"));
                    fw.ExecuteJavascript(Moreinformation1);
                    tmsWait.Hard(2);

                    IWebElement Goontothewebpage1 = Browser.Wd.FindElement(By.PartialLinkText("Go on to the webpage"));
                    fw.ExecuteJavascript(Goontothewebpage1);

                }
                catch
                {
                    fw.ConsoleReport(" There is no App Server Certificate Issue");
                }
            }
            Console.WriteLine("Finished Goto URL to config file url.");
            tmsWait.Implicit(5);
            Console.WriteLine("Navigate is finished");
        }
        public static void navigateR2()
        {
            ConfigFile.ReadFromConfigFile();
            Console.WriteLine("Begin Navigate");
            Browser.SetWebdriverType(ConfigFile.BrowserType);
            Console.WriteLine("Finished SetWebdriverType to config file browser type");
            Browser.Wd.Manage().Window.Maximize();
            Console.WriteLine("Finished Window Maximize");

            //2.27.2017 - Daron - Build Tenant URL
            string[] URLParts = ConfigFile.URL.Split('/');
            string newURL = URLParts[0] + "//" + ConfigFile.Tenant + ".";
            for (int i = 2; i < URLParts.GetUpperBound(0) + 1; i++)
            {
                newURL += URLParts[i] + "/";
            }
            Browser.Wd.Navigate().GoToUrl(ConfigFile.URL);
            //    Browser.Wd.Navigate().GoToUrl(ConfigFile.URL);


            if (Browser.Wd.Title.Equals("Certificate Error: Navigation Blocked"))
            {
                Browser.Wd.Navigate().GoToUrl("javascript:document.getElementById('overridelink').click()");
            }
            Console.WriteLine("Finished Goto URL to config file url.");
            //tmsWait.Implicit(20);
            Console.WriteLine("Navigate is finished");
        }
        public static void navigate(string URL)
        {
            ConfigFile.ReadFromConfigFile();
            Browser.SetWebdriverType(ConfigFile.BrowserType);
            Browser.Wd.Navigate().GoToUrl(URL);
            tmsWait.Implicit(5);
        }
        
        public static void selectDatabase()
        {
            tmsWait.Hard(3);
            Boolean logoSuccess = false;
            for (int trytimes = 0; trytimes < 3; trytimes++)
            {
                try
                {
                    IWebElement TZLogo = Browser.Wd.FindElement(By.XPath("//*[@id='ctl00_ctl00_ProductMenu1_Menu1-menuItem000']/img"));
                    TZLogo.Click();
                    logoSuccess = true;
                    break;
                }
                catch { }
            }
            if (!logoSuccess)
            {
                for (int trytimes = 0; trytimes < 3; trytimes++)
                {
                    try
                    {
                        IWebElement TZLogo = Browser.Wd.FindElement(By.XPath("//*[@id='ctl00_ctl00_ProductMenu1_Menu1-menuItem000']/img"));
                        TZLogo.Click();
                        logoSuccess = true;
                        break;
                    }
                    catch { }
                }
            }
 
            string myDatabase = "EAM|" + ConfigFile.EAMdb;
            IList<IWebElement> classList = Browser.Wd.FindElements(By.ClassName("skmSubMenu"));
            Boolean bFoundDBInList = false;
            for (int k = 0; k < classList.Count; k++)
            {
                if (classList[k].Text.Contains(myDatabase))
                {
                    bFoundDBInList = true;
                    classList[k].Click();
                    break;
                }
            }
            if (!bFoundDBInList)
            {
                Assert.AreEqual(true, false, "Trying to select database " + myDatabase + ", unable to find it in the DB list");
            }
            else
            {
                Console.WriteLine("Trying to select database " + myDatabase + ", was able to find it in the DB list");
            }
        }
        public static void selectDatabase(string dbToSelect)
        {
            try
            {
                //ctl00_ctl00_ProductMenu1_Menu1-menuItem000
                IWebElement TZLogo = Browser.Wd.FindElement(By.Id("Navigation1_ProductMenu1_Menu1-menuItem000"));
                TZLogo.Click();

            }
            catch (NoSuchElementException e)
            {

                //IWebElement TZLogo1 = Browser.Wd.FindElement(By.Id("ctl00_ctl00_ProductMenu1_Menu1-menuItem000"));

                 EAM.NavigationBar.TriZettoLog1.Click();

            }
         
            string myDatabase =  dbToSelect;
            IList<IWebElement> classList = Browser.Wd.FindElements(By.ClassName("skmSubMenu"));
            Boolean bFoundDBInList = false;
            for (int k = 0; k < classList.Count; k++)
            {
                if (classList[k].Text == myDatabase)
                {
                    bFoundDBInList = true;
                    classList[k].Click();
                    break;
                }
            }
            if (!bFoundDBInList)
            {
                Assert.AreEqual(true, false, "Trying to select database " + myDatabase + ", unable to find it in the DB list");
            }
            else
            {
                Console.WriteLine("Trying to select database " + myDatabase + ", was able to find it in the DB list");
            }
            
            //if (dbToSelect.Equals("ProductMenu"))
            //{
            //    //IWebDriver driver; // assume assigned elsewhere
            //    IJavaScriptExecutor js = Browser.Wd as IJavaScriptExecutor;
            //    js.ExecuteScript("document.getElementById('Navigation1_ProductMenu1_Menu1').click();");
            //}

        }

        public static void selectAdministration()
        {
            try
            {
                //ctl00_ctl00_ProductMenu1_Menu1-menuItem000
                IWebElement TZLogo = Browser.Wd.FindElement(By.Id("Navigation1_ProductMenu1_Menu1-menuItem000"));
                TZLogo.Click();

            }
            catch (NoSuchElementException e)
            {

                //IWebElement TZLogo1 = Browser.Wd.FindElement(By.Id("ctl00_ctl00_ProductMenu1_Menu1-menuItem000"));

                EAM.NavigationBar.TriZettoLog1.Click();

            }

            string myDatabase = "TMS|Administration";
            IList<IWebElement> classList = Browser.Wd.FindElements(By.ClassName("skmSubMenu"));

            Boolean bFoundDBInList = false;
            for (int k = 0; k < classList.Count; k++)
            {
                if (classList[k].Text == myDatabase)
                {
                    bFoundDBInList = true;
                    classList[k].Click();
                    break;
                }
            }
            if (!bFoundDBInList)
            {
                Assert.AreEqual(true, false, "Trying to select Administration " + myDatabase + ", unable to find Administration");
            }
            else
            {
                Console.WriteLine("Trying to select database " + myDatabase + ", unable to find Administration");
            }
            
        }

        /// <summary>
        /// Switch to App in new TMS framework
        /// </summary>
        /// <param name="appName">Name of Application</param>
        public static void SwitchToApplication(string appName)
        {
           // tmsWait.Hard(2);
            if (appName.ToLower().Contains("ram"))
            {
                appName += "P";
            }
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.Id("appSwitch")));
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[contains(@tooltip,'" + appName + "')]")));
            try
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[test-id='menu-ddl-applicationNavigation" + appName + "Icon1']")));
                tmsWait.Implicit(60);
            }
            catch
            {
                Assert.Fail(appName+" Application is not available on Your App Server");
            }

        }

        public static void selectFRMDatabase()
        {
            //IWebElement TZLogo = Browser.Wd.FindElement(By.Id("Navigation1_ProductMenu1_Menu1-menuItem000"));
            //TZLogo.Click();
            //string myDatabase = "FRM|" + ConfigFile.FRMdb;
            //IList<IWebElement> classList = Browser.Wd.FindElements(By.ClassName("skmSubMenu"));
            //Boolean bFoundDBInList = false;
            //for (int k = 0; k < classList.Count; k++)
            //{
            //    if (classList[k].Text == myDatabase)
            //    {
            //        bFoundDBInList = true;
            //        classList[k].Click();
            //        break;
            //    }
            //}
            //if (!bFoundDBInList)
            //{
            //    Assert.AreEqual(true, false, "Trying to select database " + myDatabase + ", unable to find it in the DB list");
            //}
            //else
            //{
            //    Console.WriteLine("Trying to select database " + myDatabase + ", was able to find it in the DB list");
            //}
            IWebElement dbLink = Browser.Wd.FindElement(By.XPath("//font[contains(., '" + ConfigFile.FRMdb + "')]"));
            fw.ExecuteJavascript(dbLink);
        }

        public static void selectRSMDatabase()
        {
            IWebElement dbLink = Browser.Wd.FindElement(By.XPath("//font[contains(., '"+ ConfigFile.RSMdb + "')]"));
            fw.ExecuteJavascript(dbLink);
        }

        
             public static void selectPDEMMDatabase()
        {
            IWebElement dbLink = Browser.Wd.FindElement(By.XPath("//font[contains(., '" + ConfigFile.PDEMdb + "')]"));
            fw.ExecuteJavascript(dbLink);
        }

        public static void selectDLMDatabase()
        {
            IWebElement dbLink = Browser.Wd.FindElement(By.XPath("//font[contains(., '" + ConfigFile.DLMdb + "')]"));
            fw.ExecuteJavascript(dbLink);
        }

        
        public static void selectRAMDatabase()
        {
            tmsWait.Hard(2);
            IWebElement dbLink = Browser.Wd.FindElement(By.XPath("//font[contains(., '" + ConfigFile.RAMdb + "')]"));
            fw.ExecuteJavascript(dbLink);
        }

        public static void VerifyDBExists(string db)
        {
            try
            {
                if (Browser.Wd.FindElement(By.XPath("//font[contains(., '" + db + "')]")).Displayed)
                {
                    Assert.IsTrue(true);
                }
            }
            catch (Exception)
            {
                Assert.Fail();
            }
        }


        public static void VerifyFRMDB()
        {
            try
            {
                if (Browser.Wd.FindElement(By.XPath("//font[contains(., '" + ConfigFile.FRMdb + "')]")).Displayed)
                {
                    Assert.Fail();
                }
            }
            catch (Exception)
            {
                Assert.IsTrue(true);
            }
        }

        public static void selectEAMDatabase()
        {
            FRM.FRMMainPage.ProductSelectBox.Click();
            string myDatabase = ConfigFile.EAMdb;
            tmsWait.Hard(2);
            Browser.Wd.FindElement(By.XPath("//a[@role='menuitem']/small[contains(., '" + myDatabase + "')]")).Click();
            Assert.IsTrue(Browser.Wd.Title.Equals("Home"), "EAM Home page is displayed.");
        }

        public static void Goto(string strNavigation)
        {
            switch (strNavigation)
            {
                case "MembersViewEdit":
                    {
                        EAM.NavigationBar.MembersViewEdit.Click();
                        break;
                    }
                case "MembersNew":
                    {
                        EAM.NavigationBar.MembersNew.Click();
                        break;
                    }
                case "AdministrationMMPManagement":
                    {
                        IWebElement AdministrationMMPManagement = Browser.Wd.FindElement(By.Id("Navigation1_pnlUserAdmin_ctl09_link"));
                        AdministrationMMPManagement.Click();
                        break;
                    }
                case "AdministrationUsers":
                    {
                        IWebElement AdministrationUsers = Browser.Wd.FindElement(By.Id("Navigation1_Hyperlink1"));
                        AdministrationUsers.Click();
                        break;
                    }
                case "AdministrationJobs":
                    {
                        IWebElement AdministrationJobs = Browser.Wd.FindElement(By.Id("Navigation1_Hyperlink1"));
                        AdministrationJobs.Click();
                        break;
                    }
                case "AdministrationDBVersions":
                    {
                        IWebElement AdministrationDBVersions = Browser.Wd.FindElement(By.Id("Navigation1_Hyperlink1"));
                        AdministrationDBVersions.Click();
                        break;
                    }
                case "AdministrationWebConfiguration":
                    {
                        IWebElement AdministrationWebConfiguration = Browser.Wd.FindElement(By.Id("Navigation1_Hyperlink1"));
                        AdministrationWebConfiguration.Click();
                        break;
                    }
                case "AdministrationWorkFlowConfig":
                    {
                        IWebElement AdministrationWorkFlowConfig = Browser.Wd.FindElement(By.Id("Navigation1_Hyperlink1"));
                        AdministrationWorkFlowConfig.Click();
                        break;
                    }
                case "AdministrationWarehouseConfig":
                    {
                        IWebElement AdministrationWarehouseConfig = Browser.Wd.FindElement(By.Id("Navigation1_Hyperlink1"));
                        AdministrationWarehouseConfig.Click();
                        break;
                    }
                case "TmsOperationConfig":
                    {
                        IWebElement TmsOperationConfig = Browser.Wd.FindElement(By.Id("Navigation1_Hyperlink1"));
                        TmsOperationConfig.Click();
                        break;
                    }
                case "TCSConfiguration":
                    {
                        IWebElement TCSConfiguration = Browser.Wd.FindElement(By.Id("Navigation1_Hyperlink1"));
                        TCSConfiguration.Click();
                        break;
                    }
                case "ERFNew":
                    {
                        EAM.NavigationBar.MembersERF.Click();
                        break;
                    }
            }
        }

        public static void TZlogo()
        {
            IWebElement TZLogo = Browser.Wd.FindElement(By.Id("Navigation1_ProductMenu1_Menu1-menuItem000"));
            TZLogo.Click();
        }
    }
}
