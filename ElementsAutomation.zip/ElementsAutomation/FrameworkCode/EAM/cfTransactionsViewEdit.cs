﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using TechTalk.SpecFlow;

using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using System.Diagnostics;
using System.Windows;
using System.Collections.ObjectModel;


namespace TMSoR1
{
    [Binding]
    public class TransactionsViewEdit
    {
        public IWebElement AQForm { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_pnlElection")); } }
        public IWebElement AQLink { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ImageButton3")); } }
        public IWebElement Incompletecheckbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_chkIncomplete_00")); } }
        public IWebElement ForceDenyCheckbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_chk_Deny")); } }
        public IWebElement MissingItem { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboMissingReason")); } }
        public IWebElement DenialReason { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboDenialReason")); } }
        public IWebElement MissingOther { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtMissingOther")); } }
        public IWebElement FirstName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtFirst")); } }
        public IWebElement TransViewEditSave { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSave")); } }
        public IWebElement TransViewEditForceAcceptanceCheck { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_chkForcedAccept")); } }
        public IWebElement SearchButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cmdSearch")); } }
        public IWebElement TransactionsTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dgTrans")); } }
        public IWebElement DisenReason { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboDisenReason_13")); } }
        public IWebElement PremWithholdOption { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_drpPremium_18")); } }
        public IWebElement HICNumber { get { return Browser.Wd.FindElement(By.XPath("//input[@placeholder='Add MBI']")); } }
        public IWebElement Search { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='transSearch-btn-search']")); } }
        public IWebElement TransactionSearchResultStaticText { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblreturn")); } }
        public IWebElement CreditCover { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboCreditCov_21")); } }
        public IWebElement UncoveredMonths { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtUncovMonth_22")); } }
        public IWebElement Plan1 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='TransactionRelatedPlanFieldsPlan1']")); } }
        public IWebElement Plan2 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='TransactionRelatedPlanFieldsPlan2']")); } }
        public IWebElement Plan3 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='TransactionRelatedPlanFieldsPlan3']")); } }
        public IWebElement Plan4 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='TransactionRelatedPlanFieldsPlan4']")); } }
        public IWebElement Plan5 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='TransactionRelatedPlanFieldsPlan5']")); } }
        public IWebElement Plan6 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='TransactionRelatedPlanFieldsPlan6']")); } }
        public IWebElement Plan7 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='TransactionRelatedPlanFieldsPlan7']")); } }
        public IWebElement Plan8 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='TransactionRelatedPlanFieldsPlan8']")); } }
        public IWebElement Plan9 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='TransactionRelatedPlanFieldsPlan9']")); } }
        public IWebElement Plan10 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='TransactionRelatedPlanFieldsPlan10']")); } }
        public IWebElement EnrollmentSource { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_DropDpwnEnrollSource")); } }
        public IWebElement ProgramSource { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboProgramSource")); } }
        public IWebElement TransCodeSearch { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboTransCode")); } }
        public IWebElement TransStatusSearch { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboTransStatus")); } }
        public IWebElement Userentered {  get { return Browser.Wd.FindElement(By.XPath("//span[@test-id='transaction-span-userEntered']")); } }

        //Legacy Emport File Page
        public IWebElement LegacyTransactionFileExportTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dgRaps")); } }
        public IWebElement LegacyTransactionFileExportPlanID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlPlan")); } }
        public IWebElement LegacyTransactionFileExportPBPID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlPBPid")); } }
        public IWebElement LegacyTransactionFileExportTCType { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlPayYear")); } }
        public IWebElement LegacyTransactionFileExportTCStatus { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlTransStatus")); } }
        public IWebElement LegacyTransactionFileExportGoButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='legacyTrans-btn-search']")); } }
        public IWebElement LegacyTransactionFileExportExportButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='legacyTrans-btn-initiateExport']")); } }
        public IWebElement LegacyTransactionFileExportResetButton {  get { return Browser.Wd.FindElement(By.CssSelector("[test-id='legacyTrans-btn-reset']")); } }
        public IWebElement LegacyTransactionFileExportFromDate {  get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtFromDate")); } }
        public IWebElement LegacyTransactionFileExportToDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtToDate")); } }
        public IWebElement MBITransViewEdit { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtHic")); } }
        public IWebElement SearchTransViewEdit { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cmdSearch")); } }
        public IWebElement PartCAmount { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtPremAmtC_19")); } }

    }
}
