﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1
{
    [Binding]
    class cfCreateMember
    {

        public static CreateNewMemberNew CreateNewMemberNew { get { return new CreateNewMemberNew(); } }
    }

    [Binding]
    public class CreateNewMemberNew
    {
        public IWebElement plan2 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtPlan2")); } }
        public IWebElement plan3{ get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtPlan3")); } }
        public IWebElement SaveBtn { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSave")); } }
        public IWebElement ElectionType { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboElections")); } }

    }
}

