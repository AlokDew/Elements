﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;


namespace TMSoR1
{
    class cfExternalIntegration
    {
        public static FacetsIntegration FacetsIntegration { get { return new FacetsIntegration(); } }
        public static EAMIntegration EAMIntegration { get { return new EAMIntegration(); } }
    }

    [Binding]
    public class EAMIntegration
    {
        public IWebElement EAMOptionButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='externalIntegration-radio-rdeam']")); } }



    }
    [Binding]
    public class FacetsIntegration
    {
        public IWebElement EAMOptionButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='externalIntegration-chk-chkIdExportSpan']")); } }



    }

}
