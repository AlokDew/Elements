﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TMSoR1
{
    public class GlobalRef
    {
        public static string providerID = "";
        public static string tmsAlmFolder = "";
        public static string tmsAlmRandomFolder = "";
        public static string JobName = "";
        public static string ExportName = "";
        public static string mPriority = "";
        public static string memberremaing = "";
        public static string mEnrolledMonths = "";
        public static string mMemberID = "";

        public static string mMarkAsOpen = "";
        public static string mProviderID = "";
        public static string mPCPID = "";
        public static string ProviderName = "";
        public static string SuspectCount = "";
        public static string SuspectSummary_PlanID = "";
        public static string SuspectSummary_SuspectCount = "";

        
            
        public static int TotalEnrlReceivedAInit = 0;
        public static string TotalEnrollmentsDeniedColD_Init = "";
        public static string TotalEnrollmentsDeniedColF_Init = "";


        public static string EnrollmentsthatRequiredRequestsorAdditionalInformationCColumnInit = "";
        public static string EnrollmentsthatRequiredRequestsorAdditionalInformationCColumnFinal = "";
        public static string TotalVoluntaryDisenrollmentsReceivedInit = "";


        public static string TotalEnrlReceivedAFinal = "";
         public static string MemberId = "";
        public static string TotalTransactions_Finalcount = "";

        public static string TotalVoluntaryDisenrollmentsReceivedFinal = "";
        public static string EnrollmentsCompleteattheTimeofInitialReceiptInit = "";
         public static string PotentialDiagCode = "";

        public static string DisEnrollmentCompleteattheTimeofInitialReceiptInit = "";
        public static string DisEnrollmentCompleteattheTimeofInitialReceiptFinal = "";
        public static string EnrollmentsCompleteattheTimeofInitialReceiptFinal = "";

        public static string adddiagcode = "";


        public static string TotalEnrollmentsDeniedColD_Final = "";
        public static string Value0 = "";
        public static string Value1 = "";
        public static string Value2 = "";
        public static string Value3 = "";
        public static string Value4 = "";
        public static string Value5 = "";
        public static string Value6 = "";
        public static string Value7 = "";

        public static string TValue0 = "";
        public static string TValue1 = "";
        public static string TValue2 = "";
        public static string TValue3 = "";
        public static string TValue4 = "";
        public static string TValue5 = "";
        public static string TValue6 = "";
        public static string TValue7 = "";

        public static string TotalEnrollmentsDeniedColF_Final = "";
        public static string DIAGCODE = "";

        public static string MEMID = "";
        public static int InitialReportCount = 0;
        public static string PCPValue = "";
        public static string HCCID = "";
        public static string outputpath = "";
       public static string mSuspectType = "";

        



        public static string ReportPlanID = "";
        public static string activityValue_default = "";
        public static string actionValue_default = "";
        public static string userValue_default = "";
        
        public static int InitialCoderIDCount = 0;
        
        public static string ReportPaymentMon = "";
        public static string ReportPaymentMonth = "";
        public static string ReportMBI = "";
         public static string ActionItem = "";

        public static string ReportdiscrepancyStatus = "";
        public static string ReportdiscrepancyReason = "";
        public static string ReportPath = "";
        public static string Tenant = "";

        public static string FirstPCPID = "";
        public static string ItemBeforeWFOperation = "";
        public static string TransactionWorkItem = "";
        public static string Item = "";
        public static bool TCSConfigExist = false;
        public static string LetterJOBID = "";
        public static string DescriptionText = "";
        
        public static string FirstIPAID = "";
        public static string SecondPCPID = "";
        public static string PCPID = "";
        //PDEM

        public static string PageDiagCodeID1 = "";
        public static string PageDiagCodeID2 = "";
        public static string PageDiagCodeID3 = "";

        public static string CLAIMID = "";
        public static string Reason = "";
        public static string PROVID = "";
        public static string MEMName = "";
        public static int PDEMRecCount = 0;
        public static string PDEMMBI = "";


        public static string TransMBI = "";
        public static string LTMBI = "";
        public static string PlanID = "";
        public static string PBPID = "";
        public static string TType = "";
        public static string Type = "";
        public static string ApplicationName = "";
        public static int InitialOECCount = 0;
        public static int FinalOECCount = 0;
        public static string TotalAction = "";
        public static string OldZip = "";
         public static string FRMMBI = "";
        public static int FinalCount = 0;
        public static int InitialBadMessageCount = 0;
        public static string falloutReportPath = "";
        public static string cmsextractPath = "";
        public static string PDFPath = "";
        public static string BadMessageCountAfterRefresh = "";
        public static int InitialCount = 0;
        public static string TStatus = "";
        public static string CMSREPType = "";
        public static string DISENRL = "";
        public static string PRBCASETYPE = "";
        public static string ReplyCode = "";
        public static string letterJobID = "";
        public static string LettersJobId = "";
        public static string TransactionId = "";
        public static string LetterLocation = "";
        public static int Bcount = 0;
        public static int Acount = 0;
        public static string ResolutionTimeline = "";
        public static string BEQStringReplacement = "";
        public static string BEQFileName = "";
        public static string buttonclicked = "";
        public static string RequestID = "";
        public static string SalesRep = "";
        public static string requestID = "";
        public static string PartCAmtTC78 = "";
         public static string mControlNumber = "";
        public static int Confirmation_of_Enrollment_Letter_queue_Count = 0;
        public static string LetterData = "";
        public static string DBQueryResult = "";
        public static string TCSTemplateExist = "";
        public static string ADD1 = "";
        public static string ADD2 = "";
        public static string AGE = "";
        public static string FRMSurName = "";
        public static string FRMMemberID = "";
        public static string FRMRXId = "";
        public static string Year = "";
        public static string Surname = "";
        public static string MBI = "";
        public static string DOB = "";
        public static string NewFileName = "";
        public static string Sex = "";
        public static string VerificationDate = "";
        public static string FollowUpDate = "";
        public static string captionText = "";
        public static string clientId = "";
        public static string ClientId = "";
        
        public static string Subid = "";
        public static string WFUsers = "";
        public static string WFStatus = "";
        public static bool ischeckedvalue = false;
         public static string SpecialityCode = "";
        public static string Codedescription = "";
        public static string JobID = "";
        public static string RequestId = "";
        public static string UserName = "";
        public static DateTime CurrentDataLoadDateTime;
        public static string MidOEVLetterCount = "";
        public static int BeforeOEVLetterCount = 0;
        public static string furtherOEVLetterCount = "";
        public static string finalOEVLetterCount = "";
        public static int NowOEVLetterCount = 0;
        public static int InitialreportCountEnrl = 0;
        public static int OldreportCountEnrl = 0;
        public static int FinalLetterCount = 0;
        public static int finalLetterCount = 0;
        public static int MidLetterCount = 0;
        public static int FirstLetterCount = 0;
        public static int FinalColumnCcount = 0;
        public static int SecondLetterCount = 0;
        public static int InitialColumnCcount = 0;
        public static int InitialreportCount = 0;
         public static string mSuspectStatus = "";
        public static int InitialColumnAcount = 0;
        public static int InitialreportCountB = 0;
        public static int InitialColumnBcount = 0;
        public static int EnrollmentsCompleteattheTimeofInitialReceiptInitB = 0;
        public static int CurrentColumnAcount = 0;
        public static int FinalColumnAcount = 0;
        public static int TotalPBP = 0;
        public static string SourceOfVerification = "";
        public static string VerificationResult = "";
        public static string Notes = "";
        public static string SNPStatus = "";

        public static int OldreportCount = 0;
        public static int Count = 0;
        public static int InitialreportCountA = 0;
        public static int FinalColumnBcount = 0;
        public static int InitialColumnDcount = 0;
        public static int FinalColumnDcount = 0;
        public static int TC51ColumnAcount = 0;
        public static int TC51ColumnBcount = 0;
        public static string InitialPartCAmt = "";
        public static string InitialTranspagePartCAmt = "";
        public static string OSBAmount = "";
        
        public static string ReportName = "";
        public static string MemberInfoSCC = "";
        public static string ContactTabSCC = "";
        public static string ContactTabCounty = "";
          public static string MODADD1 = "";
        public static string effectiveDate = "";
        public static string MemberInfoCounty = "";
        public static string MMPState = "";
        
         public static string BeforeLetter = "";
        public static string MODADD2 = "";
        public static string DecreaseLetterCount = "";
        public static int LetterCountBEF= 0;
        public static string UserCreated = "";
        public static string MyLetterCount = "";
        public static string LetterCountBefore = "";
        public static string LetterCountAfter = "";
        public static string secondLetterCount = "";
        public static string ThirdLetterCount = "";
        public static int NoteInitialLetterCount = 0;
        public static int CurrentLetterCount = 0;
        public static int NoteFinalLetterCount = 0;
        public static int querycount = 0;
        public static int TotalcountInFile = 0;
        public static int MemberCount = 0;
        public static int LetterCount = 0;
        public static int InitialLetterCount = 0;
        public static string NoOfLetterInit = "";
        public static string NoOfLetterFinal = "";

        
        public static string ReplyDate = "";
        public static string BEQHeader = "";
        public static string BEQMBI = "";
        public static string BEQDOB = "";
        public static string BEQTrailer = "";

        public static string InitialstartDate = "";
        public static string CalendarEndDate= "";

        public static string FinalstartDate = "";
        public static string HICMemberSearchCriteria = "";
        public static string HIC = "";
        public static string MBISelected = "";
        public static string MBINAME = "";
         public static string mPlanID = "";
        public static string CMSFILEID = "";
         public static int CountOfWindow = 0;
        public static string winium = "";
        public static string RootAdmin = "";
          public static string User = "";
        public static string TenantAdmin = "";
        public static string MemberID = "";
        public static string Finalcount = "";
        public static string currentCount = "";
        public static string HICN = "";
        
        public static string HCCValue = "";
        public static string AutoIT = "";
        public static string OutputFolderPath = "";
        public static string EDGE_SERVER_XML_FILE = "";
        public static string TotalReasonCount = "";
        
        public static string EDATA_FORMAT_FILE = "";
        public static string NUMRECORD = "";
       public static string TotalTransactions_Initialcount = "";
        public static string FileName = "";

        public static string PLAN1 = "";
        public static string PAYYEAR1 = "";

        public static string mPIRStatus = "";
        public static string mPaymentYear = "";
        public static string FullFilePath = "";
        public static string DownloadFileName = "";
        public static string ProjectName = "";
        public static string Reference = "";
        public static string ProviderID = "";
        public static string ActualLoadDate = "";
        public static string AuditREviewProviderId = "";


    }
}
