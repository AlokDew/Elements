﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FileHelpers;

using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Globalization;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.ComponentModel;
using OpenQA.Selenium.Interactions;

namespace TMSoR1.FrameworkCode
{
    class AngularFunction
    {

        public static string downloadFolderPath = System.IO.Path.Combine(Environment.ExpandEnvironmentVariables("%userprofile%"), "Downloads");

        public static string returnSystemdownloadFolderPath()
        {
            return downloadFolderPath;
        }
        /// split By Letter by Letter 
        public static char[] splitByLetterbyLetter(string input)
        {
            return input.ToCharArray();
        }

        public static string getRecent_FilefromSpecialFolderUsingExtension(string Special_FolderPath, string fileExtension)
        {

            string downloadPath = Special_FolderPath;

            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*." + fileExtension + "");
            int filecount = newFilePaths.Length;
            string RecentFile = Path.Combine(downloadPath, newFilePaths[filecount - 1]);
            return RecentFile;
        }

        public static string getRecent_FilefromSpecial_Folder(string Special_FolderPath,string fileExtension)
        {

            string downloadPath = Special_FolderPath;
       
        var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*."+ fileExtension + "");
        int filecount = newFilePaths.Length;
        string RecentFile = Path.Combine(downloadPath, newFilePaths[filecount - 1]);
            return RecentFile;
        }

        public static string returnDateMMDDYYYY()
        {
            return DateTime.Now.ToString("MM/dd/yyyy");
        }

            public static void resolveCertificateErrors()
        {


            if (Browser.Wd.Title.Equals("Certificate Error: Navigation Blocked"))
            {
                Browser.Wd.Navigate().GoToUrl("javascript:document.getElementById('overridelink').click()");
            }


            if (ConfigFile.BrowserType.Equals("chromep") || ConfigFile.BrowserType.Equals("edge") || ConfigFile.BrowserType.Equals("chrome") || ConfigFile.BrowserType.Equals("edgelegacy") || ConfigFile.BrowserType.Equals("edgechrome"))
            {
                try
                {
                    IWebElement advancedButton = Browser.Wd.FindElement(By.CssSelector("[id='details-button']"));
                    fw.ExecuteJavascript(advancedButton);
                    tmsWait.Hard(5);

                    IWebElement acceptRiskBtn = Browser.Wd.FindElement(By.CssSelector("[id='proceed-link']"));
                    fw.ExecuteJavascript(acceptRiskBtn);
                    tmsWait.Hard(10);

                    IWebElement advancedButton1 = Browser.Wd.FindElement(By.CssSelector("[id='details-button']"));
                    fw.ExecuteJavascript(advancedButton1);
                    tmsWait.Hard(5);

                    IWebElement acceptRiskBtn1 = Browser.Wd.FindElement(By.CssSelector("[id='proceed-link']"));
                    fw.ExecuteJavascript(acceptRiskBtn1);

                }
                catch
                {
                    try
                    {
                        IWebElement continueBtn = Browser.Wd.FindElement(By.PartialLinkText("Continue to this webpage"));
                        fw.ExecuteJavascript(continueBtn);
                        tmsWait.Hard(5);
                    }
                    catch
                    {

                        fw.ConsoleReport("There is no Certiicate Warning");
                    }
                }
            }


            if (ConfigFile.BrowserType.Equals("edge") || ConfigFile.BrowserType.Equals("edgelegacy") || ConfigFile.BrowserType.Equals("edgechrome"))
            {
                try
                {
                    IWebElement advancedButton = Browser.Wd.FindElement(By.CssSelector("[id='continueLink']"));
                    fw.ExecuteJavascript(advancedButton);
                    tmsWait.Hard(5);

                    IWebElement acceptRiskBtn = Browser.Wd.FindElement(By.CssSelector("[id='continueLink']"));
                    fw.ExecuteJavascript(acceptRiskBtn);
                    tmsWait.Hard(10);

                    //IWebElement advancedButton1 = Browser.Wd.FindElement(By.CssSelector("[id='details-button']"));
                    //fw.ExecuteJavascript(advancedButton1);
                    //tmsWait.Hard(5);

                    //IWebElement acceptRiskBtn1 = Browser.Wd.FindElement(By.CssSelector("[id='proceed-link']"));
                    //fw.ExecuteJavascript(acceptRiskBtn1);
                    //tmsWait.Hard(5);
                }

                catch
                {
                    fw.ConsoleReport("There is no Certiicate Warning");
                }

            }

            if (ConfigFile.BrowserType.Equals("firefox"))
            {
                try
                {
                    IWebElement advancedButton = Browser.Wd.FindElement(By.Id("advancedButton"));
                    fw.ExecuteJavascript(advancedButton);
                    tmsWait.Hard(5);

                    IWebElement acceptRiskBtn = Browser.Wd.FindElement(By.Id("exceptionDialogButton"));
                    fw.ExecuteJavascript(acceptRiskBtn);
                    tmsWait.Hard(10);

                    IWebElement advancedButton1 = Browser.Wd.FindElement(By.Id("advancedButton")); // Due to Stale Element reference Exception, we created Duplicate statement
                    fw.ExecuteJavascript(advancedButton1);
                    tmsWait.Hard(5);

                    IWebElement acceptRiskBtn1 = Browser.Wd.FindElement(By.Id("exceptionDialogButton"));
                    fw.ExecuteJavascript(acceptRiskBtn1);
                    tmsWait.Hard(10);

                }
                catch
                {
                    fw.ConsoleReport("There is no Warning: Potential Security Risk Ahead");
                }
            }

            if (ConfigFile.BrowserType.Equals("ie"))
            {
                try
                {
                    IWebElement Moreinformation = Browser.Wd.FindElement(By.LinkText("More information"));
                    fw.ExecuteJavascript(Moreinformation);
                    tmsWait.Hard(2);

                    IWebElement Goontothewebpage = Browser.Wd.FindElement(By.PartialLinkText("Go on to the webpage"));
                    fw.ExecuteJavascript(Goontothewebpage);
                    tmsWait.Hard(10);


                    IWebElement Moreinformation1 = Browser.Wd.FindElement(By.LinkText("More information"));
                    fw.ExecuteJavascript(Moreinformation1);
                    tmsWait.Hard(2);

                    IWebElement Goontothewebpage1 = Browser.Wd.FindElement(By.PartialLinkText("Go on to the webpage"));
                    fw.ExecuteJavascript(Goontothewebpage1);

                }
                catch
                {
                    fw.ConsoleReport(" There is no App Server Certificate Issue");
                }
            }


        }

        public static string FileRootPath()
        {
            return Browser.Wd.FindElement(By.XPath("//input[@test-id='manageConfiguration-txt-fileRootPath']")).GetAttribute("value");
        }
        public static string getTenantName()
        {
            return ((ConfigFile.URL.Split('.'))[0].Split('/'))[2];
        }

        public static string getRandomNumber()
        {
            Random rnd = new Random();

            string strReturnString = rnd.Next(100000, 999999).ToString();
            return strReturnString;

        }

        public static void clickOnDropDownValue(string value)
        {
            By ele=By.XPath("//li[contains(.,'"+ value + "')]");
            AngularFunction.clickOnElement(ele);
            
        }

        public static void selectMultiSelectDropDown(By loc,string value)
        {
            AngularFunction.sendKeysWithOutClear(loc,value);

            By ele = By.XPath("//li[contains(.,'" + value + "')]");
            AngularFunction.clickOnElement(ele);

        }

        public static void selectMultiSelectDropDown(IWebElement webele, string value)
        {
            AngularFunction.sendKeysWithOutClear(webele, value);

            By ele = By.XPath("//li[contains(.,'" + value + "')]");
            AngularFunction.clickOnElement(ele);

        }


        public static void enterDate_In_Report(By datepicker, string dateInput)
        {
            var months = new Dictionary<string, string>()
        {
            { "1", "Jan" },
            { "2", "Feb" },
            { "3", "Mar" },
            { "4", "Apr" },
            { "5", "May" },
            { "6", "Jun" },
            { "7", "Jul" },
            { "8", "Aug" },
            { "9", "Sep" },
            { "01", "Jan" },
            { "02", "Feb" },
            { "03", "Mar" },
            { "04", "Apr" },
            { "05", "May" },
            { "06", "Jun" },
            { "07", "Jul" },
            { "08", "Aug" },
            { "09", "Sep" },
            { "10", "Oct" },
            { "11", "Nov" },
            { "12", "Dec" }

        };

            string ip = dateInput; // MM DD YYYY
            string[] dateValue = ip.Split('/');


            string currentMonthYear = AngularFunction.currentMonth() + " " + AngularFunction.currentYear();
            By currentMonYear = By.XPath("//span[text()='" + currentMonthYear + "']");

            By year = By.XPath("//span[contains(.,'" + AngularFunction.currentYear() + "')]");
            By mid = By.XPath("//span[text()='1970']");
            By todayDate = By.XPath("//span[contains(.,'TODAY')]");

            string firsthreechar = AngularFunction.firstthreecharsofYear(dateValue[2]) + "0";     // Year First 3 char       
            By firstthreecharsofYear = By.XPath("//span[contains(.,'" + firsthreechar + "')]");
            By expYear1 = By.XPath("(//span[text()='" + dateValue[2] + "'])[1]"); // Year
            By expYear2 = By.XPath("(//span[text()='" + dateValue[2] + "'])[2]"); // Year
            string mon = months[dateValue[0]];
            By expMon = By.XPath("(//span[contains(.,'" + mon + "')])[1]");

            if (dateValue[1].StartsWith("0"))
            {
                dateValue[1] = dateValue[1].Substring(1);
            }
            By expDay = By.XPath("//kendo-calendar//span[text()='" + dateValue[1] + "']");


            UIMODUtilFunctions.clickOnWebElementUsingLocators(datepicker); // Click on Calendar icon
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(currentMonYear); // Click on current Year Month
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(year); // Click on Year

            int yeardiff = Int32.Parse(AngularFunction.currentYear()) - Int32.Parse(dateValue[2]);
            tmsWait.Hard(2);
            int reminderYear = yeardiff / 10;
            string yearnum= AngularFunction.currentYear();

            if (yeardiff != 0)
            {
                for (int i = 0; i <= reminderYear; i++)
                {
               

                     tmsWait.Hard(2);
                System.Windows.Forms.SendKeys.SendWait("{PGUP}");
               
            }
           }

            try
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(expYear2));
                //UIMODUtilFunctions.clickOnWebElementUsingLocators(expYear2);
            }
            catch
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(expYear1));
                //UIMODUtilFunctions.clickOnWebElementUsingLocators(expYear1);
            }
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(expMon);
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(expDay);
        }

        /// <summary>
        ///  You can use this code for RAM, RAMX, RSM or any Reports start date, end date
        /// </summary>
        /// <param name="datepicker"></param>
        /// <param name="dateInput"></param>
        public static void enterRAMX_RXM_Date(By datepicker, string dateInput)
        {
            var months = new Dictionary<string, string>()
        {
            { "1", "Jan" },
            { "2", "Feb" },
            { "3", "Mar" },
            { "4", "Apr" },
            { "5", "May" },
            { "6", "Jun" },
            { "7", "Jul" },
            { "8", "Aug" },
            { "9", "Sep" },
            { "01", "Jan" },
            { "02", "Feb" },
            { "03", "Mar" },
            { "04", "Apr" },
            { "05", "May" },
            { "06", "Jun" },
            { "07", "Jul" },
            { "08", "Aug" },
            { "09", "Sep" },
            { "10", "Oct" },
            { "11", "Nov" },
            { "12", "Dec" }

        };

            string ip = dateInput; // MM DD YYYY
            string[] dateValue = ip.Split('/');


            string currentMonthYear = AngularFunction.currentMonth() + " " + AngularFunction.currentYear();
            By currentMonYear = By.XPath("//span[text()='" + currentMonthYear + "']");

            By year = By.XPath("//span[contains(.,'" + AngularFunction.currentYear() + "')]");
            By mid = By.XPath("//span[text()='1970']");
            By todayDate = By.XPath("//span[contains(.,'TODAY')]");

            string firsthreechar = AngularFunction.firstthreecharsofYear(dateValue[2]) + "0";     // Year First 3 char       
            By firstthreecharsofYear = By.XPath("//span[contains(.,'" + firsthreechar + "')]");
            By expYear1 = By.XPath("(//span[text()='" + dateValue[2] + "'])[1]"); // Year
            By expYear2 = By.XPath("(//span[text()='" + dateValue[2] + "'])[2]"); // Year
            string mon = months[dateValue[0]];
            By expMon = By.XPath("(//span[contains(.,'" + mon + "')])[1]");

            if (dateValue[1].StartsWith("0"))
            {
                dateValue[1] = dateValue[1].Substring(1);
            }
            By expDay = By.XPath("//kendo-calendar//span[text()='" + dateValue[1] + "']");


            UIMODUtilFunctions.clickOnWebElementUsingLocators(datepicker); // Click on Calendar icon
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(currentMonYear); // Click on current Year Month
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(year); // Click on Year

            int yeardiff = Int32.Parse(AngularFunction.currentYear()) - Int32.Parse(dateValue[2]);
            tmsWait.Hard(2);
            int reminderYear = yeardiff / 10;

            if (yeardiff != 0)
            {
                for (int i = 0; i <= reminderYear; i++)
                {
                  System.Windows.Forms.SendKeys.SendWait("{PGUP}");
                }
            }

            try
            {
                UIMODUtilFunctions.clickOnWebElementUsingLocators(expYear1);
            }
            catch
            {
                UIMODUtilFunctions.clickOnWebElementUsingLocators(expYear2);
            }
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(expMon);
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(expDay);
        }


        public static void compareExpectedValueWithActual(string act, string exp)
        {
            Assert.AreEqual(exp, act);
        }

        public static void getActualTextAndcompareExpectedValue(IWebElement ele, string exp)
        {
            Assert.AreEqual(exp, ele.Text.Trim());
        }


        public static void clickOnNOonConfirmationDialog()
        {
            try
            {
                IWebElement ele = Browser.Wd.FindElement(By.XPath("//button[@id='confirmationDialogNo']"));
                tmsWait.Hard(2);
                IJavaScriptExecutor js = Browser.Wd as IJavaScriptExecutor;

                js.ExecuteScript("arguments[0].click();", ele);
                tmsWait.Hard(2);
            }
            catch
            {
                fw.ConsoleReport(" There is no Confirmation dialog");
            }

        }

        public static void clickOnYESonConfirmationDialog()
        {
            try
            {
                IWebElement ele = Browser.Wd.FindElement(By.XPath("//button[@id='confirmationDialogYes']"));
                tmsWait.Hard(2);
                IJavaScriptExecutor js = Browser.Wd as IJavaScriptExecutor;

                js.ExecuteScript("arguments[0].click();", ele);
                tmsWait.Hard(2);
            }
            catch
            {
                fw.ConsoleReport(" There is no Confirmation dialog");
            }

        }


        public static void enterRAMX_RXM_Date(IWebElement datepicker, string dateInput)
        {
            var months = new Dictionary<string, string>()
        {
            { "1", "Jan" },
            { "2", "Feb" },
            { "3", "Mar" },
            { "4", "Apr" },
            { "5", "May" },
            { "6", "Jun" },
            { "7", "Jul" },
            { "8", "Aug" },
            { "9", "Sep" },
            { "01", "Jan" },
            { "02", "Feb" },
            { "03", "Mar" },
            { "04", "Apr" },
            { "05", "May" },
            { "06", "Jun" },
            { "07", "Jul" },
            { "08", "Aug" },
            { "09", "Sep" },
            { "10", "Oct" },
            { "11", "Nov" },
            { "12", "Dec" }

        };

            string ip = dateInput; // MM DD YYYY
            string[] dateValue = ip.Split('/');


            string currentMonthYear = AngularFunction.currentMonth() + " " + AngularFunction.currentYear();
            By currentMonYear = By.XPath("//span[text()='" + currentMonthYear + "']");

            By year = By.XPath("//span[contains(.,'" + AngularFunction.currentYear() + "')]");
            By mid = By.XPath("//span[text()='1970']");
            By todayDate = By.XPath("//span[contains(.,'TODAY')]");

            string firsthreechar = AngularFunction.firstthreecharsofYear(dateValue[2]) + "0";     // Year First 3 char       
            By firstthreecharsofYear = By.XPath("//span[contains(.,'" + firsthreechar + "')]");
            By expYear1 = By.XPath("(//span[text()='" + dateValue[2] + "'])[1]"); // Year
            By expYear2 = By.XPath("(//span[text()='" + dateValue[2] + "'])[2]"); // Year
            string mon = months[dateValue[0]];
            By expMon = By.XPath("(//span[contains(.,'" + mon + "')])[1]");

            if (dateValue[1].StartsWith("0"))
            {
                dateValue[1] = dateValue[1].Substring(1);
            }
            By expDay = By.XPath("//kendo-calendar//span[text()='" + dateValue[1] + "']");


            fw.ExecuteJavascript(datepicker); // Click on Calendar icon
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(currentMonYear); // Click on current Year Month
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(year); // Click on Year

            int yeardiff = Int32.Parse(AngularFunction.currentYear()) - Int32.Parse(dateValue[2]);
            tmsWait.Hard(2);
            int reminderYear = yeardiff / 10;

            if (yeardiff != 0)
            {
                for (int i = 0; i < reminderYear; i++)
                {
                    System.Windows.Forms.SendKeys.SendWait("{PGUP}");
                }
            }

            try
            {
                UIMODUtilFunctions.clickOnWebElementUsingLocators(expYear2);
            }
            catch
            {
                UIMODUtilFunctions.clickOnWebElementUsingLocators(expYear1);
            }
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(expMon);
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(expDay);
        }

        /// <summary>
        ///      /// This Date can  be used for RAM Encounter Date type calendar with IWebElement ( Date component) and String argument ( your date)
        /// </summary>
        /// <param name="datepicker"></param>
        /// <param name="dateInput"></param>

        public static void enterRAM_EncounterDate(IWebElement datepicker, string dateInput)
        {
            var months = new Dictionary<string, string>()
        {
            { "1", "Jan" },
            { "2", "Feb" },
            { "3", "Mar" },
            { "4", "Apr" },
            { "5", "May" },
            { "6", "Jun" },
            { "7", "Jul" },
            { "8", "Aug" },
            { "9", "Sep" },
            { "01", "Jan" },
            { "02", "Feb" },
            { "03", "Mar" },
            { "04", "Apr" },
            { "05", "May" },
            { "06", "Jun" },
            { "07", "Jul" },
            { "08", "Aug" },
            { "09", "Sep" },
            { "10", "Oct" },
            { "11", "Nov" },
            { "12", "Dec" }

        };

            string ip = dateInput; // MM DD YYYY
            string[] dateValue = ip.Split('/');

            if (Convert.ToInt32(dateValue[2]) > 2030)
            {
                dateValue[2] = "2030";

            }
            string currentMonthYear = AngularFunction.currentMonth() + " " + AngularFunction.currentYear();
            By currentMonYear = By.XPath("//span[text()='" + currentMonthYear + "']");

            By year = By.XPath("(//span[contains(.,'" + AngularFunction.currentYear() + "')])[2]");
            By mid = By.XPath("//span[text()='1970']");

            string firsthreechar = AngularFunction.firstthreecharsofYear(dateValue[2]) + "0";     // Year First 3 char       
              // By firstthreecharsofYear = By.XPath("(//span[contains(.,'" + firsthreechar + "')])[1]");
            By firstthreecharsofYear = By.XPath("//span[text()='" + firsthreechar + "']");
            By expYear1 = By.XPath("(//span[text()='" + dateValue[2] + "'])[1]"); // Year
            By expYear2 = By.XPath("(//span[text()='" + dateValue[2] + "'])[2]"); // Year
            string mon = months[dateValue[0]];
            By expMon = By.XPath("(//span[contains(.,'" + mon + "')])[1]");

            if (dateValue[1].StartsWith("0"))
            {
                dateValue[1] = dateValue[1].Substring(1);
            }
            By expDay = By.XPath("//kendo-calendar//span[text()='" + dateValue[1] + "']");
            // By expDay = By.XPath("(//kendo-calendar//span[text()='" + dateValue[1] + "'])[1]");

            AngularFunction.clickOnElement(datepicker);
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(currentMonYear);
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(year);
            tmsWait.Hard(2);
            if (Int32.Parse(dateValue[2]) < 1960)
            {
                try
                {
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(mid);
                    tmsWait.Hard(2);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(firstthreecharsofYear);
                    tmsWait.Hard(2);
                }
                catch
                {

                }
            }

            else
            {
                try
                {
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(firstthreecharsofYear);
                    tmsWait.Hard(2);

                }
                catch
                {

                }
            }
            try
            {
                UIMODUtilFunctions.clickOnWebElementUsingLocators(expYear2);
            }
            catch
            {
                UIMODUtilFunctions.clickOnWebElementUsingLocators(expYear1);
            }
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(expMon);
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(expDay);

        }

        /// This Date can  be used for RAM Encounter Date type calendar

        public static void enterRAM_EncounterDate(By datepicker, string dateInput)
        {
            var months = new Dictionary<string, string>()
        {
            { "1", "Jan" },
            { "2", "Feb" },
            { "3", "Mar" },
            { "4", "Apr" },
            { "5", "May" },
            { "6", "Jun" },
            { "7", "Jul" },
            { "8", "Aug" },
            { "9", "Sep" },
            { "01", "Jan" },
            { "02", "Feb" },
            { "03", "Mar" },
            { "04", "Apr" },
            { "05", "May" },
            { "06", "Jun" },
            { "07", "Jul" },
            { "08", "Aug" },
            { "09", "Sep" },
            { "10", "Oct" },
            { "11", "Nov" },
            { "12", "Dec" }

        };

            string ip = dateInput; // MM DD YYYY
            string[] dateValue = ip.Split('/');

            if (Convert.ToInt32(dateValue[2]) > 2030)
            {
                dateValue[2] = "2030";

            }
            string currentMonthYear = AngularFunction.currentMonth() + " " + AngularFunction.currentYear();
            By currentMonYear = By.XPath("//span[text()='" + currentMonthYear + "']");

            By year = By.XPath("(//span[contains(.,'" + AngularFunction.currentYear() + "')])[2]");
            By mid = By.XPath("//span[text()='1970']");

            string firsthreechar = AngularFunction.firstthreecharsofYear(dateValue[2]) + "0";     // Year First 3 char       
            By firstthreecharsofYear = By.XPath("//span[text()='" + firsthreechar + "']");            
            By expYear1 = By.XPath("(//span[text()='" + dateValue[2] + "'])[1]"); // Year
            By expYear2 = By.XPath("(//span[text()='" + dateValue[2] + "'])[2]"); // Year
            string mon = months[dateValue[0]];
            By expMon = By.XPath("(//span[contains(.,'" + mon + "')])[1]");

            if (dateValue[1].StartsWith("0"))
            {
                dateValue[1] = dateValue[1].Substring(1);
            }
            By expDay = By.XPath("//kendo-calendar//span[text()='" + dateValue[1] + "']");
           // By expDay = By.XPath("(//kendo-calendar//span[text()='" + dateValue[1] + "'])[1]");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(datepicker);
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(currentMonYear);
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(year);
            tmsWait.Hard(2);
            if (Int32.Parse(dateValue[2]) < 1960)
            {
                try
                {
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(mid);
                    tmsWait.Hard(2);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(firstthreecharsofYear);
                    tmsWait.Hard(2);
                }
                catch
                {

                }
            }
          
            else
            {
                try
                {
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(firstthreecharsofYear);
                    tmsWait.Hard(2);
                    
                }
                catch
                {

                }
            }
            try
            {
                UIMODUtilFunctions.clickOnWebElementUsingLocators(expYear2);
            }
            catch
            {
                UIMODUtilFunctions.clickOnWebElementUsingLocators(expYear1);
            }
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(expMon);
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(expDay);

        }


        public static void enterDatePreLoadedNew(By datepicker, string dateInput)
        {
            var months = new Dictionary<string, string>()
                            {
                                { "1", "Jan" },
                                { "2", "Feb" },
                                { "3", "Mar" },
                                { "4", "Apr" },
                                { "5", "May" },
                                { "6", "Jun" },
                                { "7", "Jul" },
                                { "8", "Aug" },
                                { "9", "Sep" },
                                { "01", "Jan" },
                                { "02", "Feb" },
                                { "03", "Mar" },
                                { "04", "Apr" },
                                { "05", "May" },
                                { "06", "Jun" },
                                { "07", "Jul" },
                                { "08", "Aug" },
                                { "09", "Sep" },
                                { "10", "Oct" },
                                { "11", "Nov" },
                                { "12", "Dec" }



                            };



            string ip = dateInput; // MM DD YYYY
            string[] dateValue = ip.Split('/');




            string currentMonthYear = AngularFunction.currentMonth() + " " + AngularFunction.currentYear();
            By currentMonYear = By.XPath("//span[text()='" + currentMonthYear + "']");



            By year = By.XPath("(//span[text()='" + AngularFunction.currentYear() + "'])[2]");
            By mid = By.XPath("//span[text()='1970']");



            string firsthreechar = AngularFunction.firstthreecharsofYear(dateValue[2]) + "0";     // Year First 3 char       
            By firstthreecharsofYear = By.XPath("//span[contains(.,'" + firsthreechar + "')]");
            if (Convert.ToInt32(dateValue[2]) > 2030)
            {
                dateValue[2] = "2030";



            }
            By expYear1 = By.XPath("(//span[contains(.,'" + dateValue[2] + "')])[1]"); // Year
            By expYear2 = By.XPath("(//span[text()='" + dateValue[2] + "'])[1]"); // Year
            string mon = months[dateValue[0]];
            By expMon = By.XPath("(//span[contains(.,'" + mon + "')])[1]");



            if (dateValue[1].StartsWith("0"))
            {
                dateValue[1] = dateValue[1].Substring(1);
            }
            By expDay = By.XPath("//kendo-calendar//span[text()='" + dateValue[1] + "']");



            fw.ExecuteJavascript(Browser.Wd.FindElement(datepicker));



            tmsWait.Hard(2);
            //fw.ExecuteJavascript(Browser.Wd.FindElement(currentMonYear));
            //tmsWait.Hard(2);
           // fw.ExecuteJavascript(Browser.Wd.FindElement(year));



            tmsWait.Hard(2);
            if (Int32.Parse(dateValue[2]) < 1960)
            {
                try
                {
                    By todayUI = By.XPath("//span[contains(.,'1960')]");
                    fw.ExecuteJavascript(Browser.Wd.FindElement(todayUI));



                    fw.ExecuteJavascript(Browser.Wd.FindElement(mid));
                    tmsWait.Hard(2);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(firstthreecharsofYear));
                    tmsWait.Hard(2);
                }
                catch (Exception e)
                {
                    //Console.WriteLine(" Catch" + e);
                }
            }
            else
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(firstthreecharsofYear));
                tmsWait.Hard(2);



            }
            try
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(expYear2));
            }
            catch
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(expYear1));
            }
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(expMon));
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(expDay));




        }

        /// <summary>
        ///  
        /// </summary>
        /// <param name="dateInput"> Pass Date Format as MM / DD / YYYY</param>
        /// <param name="datepicker"> Pass Date Field Locator </param>
        public static void enterDate(By datepicker, string dateInput)
        {
            var months = new Dictionary<string, string>()
        {
            { "1", "Jan" },
            { "2", "Feb" },
            { "3", "Mar" },
            { "4", "Apr" },
            { "5", "May" },
            { "6", "Jun" },
            { "7", "Jul" },
            { "8", "Aug" },
            { "9", "Sep" },
            { "01", "Jan" },
            { "02", "Feb" },
            { "03", "Mar" },
            { "04", "Apr" },
            { "05", "May" },
            { "06", "Jun" },
            { "07", "Jul" },
            { "08", "Aug" },
            { "09", "Sep" },
            { "10", "Oct" },
            { "11", "Nov" },
            { "12", "Dec" }

        };

            string ip = dateInput; // MM DD YYYY
            string[] dateValue = ip.Split('/');

            if (Convert.ToInt32(dateValue[2]) > 2030)
            {
                dateValue[2] = "2030";

            }
            string currentMonthYear = AngularFunction.currentMonth() + " " + AngularFunction.currentYear();
            By currentMonYear = By.XPath("//span[text()='" + currentMonthYear + "']");

            By year = By.XPath("(//span[contains(.,'" + AngularFunction.currentYear() + "')])[2]");
            By mid = By.XPath("//span[text()='1970']");

            string firsthreechar = AngularFunction.firstthreecharsofYear(dateValue[2]) + "0";     // Year First 3 char       
            By firstthreecharsofYear = By.XPath("//span[contains(.,'" + firsthreechar + "')]");
            By expYear1 = By.XPath("(//span[text()='" + dateValue[2] + "'])[1]"); // Year
            By expYear2 = By.XPath("(//span[text()='" + dateValue[2] + "'])[2]"); // Year
            string mon = months[dateValue[0]];
            By expMon = By.XPath("(//span[contains(.,'" + mon + "')])[1]");

            if (dateValue[1].StartsWith("0"))
            {
                dateValue[1] = dateValue[1].Substring(1);
            }
           By expDay = By.XPath("//kendo-calendar//span[text()='" + dateValue[1] + "']");
          

            UIMODUtilFunctions.clickOnWebElementUsingLocators(datepicker);
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(currentMonYear);
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(year);
            tmsWait.Hard(2);
            if (Int32.Parse(dateValue[2]) < 1960)
            {
                try
                {
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(mid);
                    tmsWait.Hard(2);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(firstthreecharsofYear);
                    tmsWait.Hard(2);
                }
                catch
                {

                }
            }
            //if (dateValue[2].EndsWith("0"))
            //{

            //    UIMODUtilFunctions.clickOnWebElementUsingLocators(firstthreecharsofYear);
            //    tmsWait.Hard(2);
            //    UIMODUtilFunctions.clickOnWebElementUsingLocators(expYear1);
            //}
            else
            {
                try
                {
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(firstthreecharsofYear);
                    tmsWait.Hard(2);
                    //UIMODUtilFunctions.clickOnWebElementUsingLocators(expYear2);
                }
                catch
                {

                }
            }
            try
            {
                UIMODUtilFunctions.clickOnWebElementUsingLocators(expYear2);
            }
            catch
            {
                UIMODUtilFunctions.clickOnWebElementUsingLocators(expYear1);
            }
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(expMon);
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(expDay);

        }

        /// <summary>
        ///  This method is for Preloaded Date
        /// </summary>
        /// <param name="datepicker"></param>
        /// <param name="dateInput"></param>

        public static void enterDatePreLoaded(By datepicker, string dateInput)
        {
            var months = new Dictionary<string, string>()
                            {
                                { "1", "Jan" },
                                { "2", "Feb" },
                                { "3", "Mar" },
                                { "4", "Apr" },
                                { "5", "May" },
                                { "6", "Jun" },
                                { "7", "Jul" },
                                { "8", "Aug" },
                                { "9", "Sep" },
                                { "01", "Jan" },
                                { "02", "Feb" },
                                { "03", "Mar" },
                                { "04", "Apr" },
                                { "05", "May" },
                                { "06", "Jun" },
                                { "07", "Jul" },
                                { "08", "Aug" },
                                { "09", "Sep" },
                                { "10", "Oct" },
                                { "11", "Nov" },
                                { "12", "Dec" }

                            };

            string ip = dateInput; // MM DD YYYY
            string[] dateValue = ip.Split('/');


            string currentMonthYear = AngularFunction.currentMonth() + " " + AngularFunction.currentYear();
            By currentMonYear = By.XPath("//span[text()='" + currentMonthYear + "']");

            By year = By.XPath("(//span[text()='" + AngularFunction.currentYear() + "'])[2]");
            By mid = By.XPath("//span[text()='1970']");

            string firsthreechar = AngularFunction.firstthreecharsofYear(dateValue[2]) + "0";     // Year First 3 char       
            By firstthreecharsofYear = By.XPath("//span[contains(.,'" + firsthreechar + "')]");
            if (Convert.ToInt32(dateValue[2]) > 2030)
            {
                dateValue[2] = "2030";

            }
            By expYear1 = By.XPath("(//span[contains(.,'" + dateValue[2] + "')])[1]"); // Year
            By expYear2 = By.XPath("(//span[text()='" + dateValue[2] + "'])[1]"); // Year
            string mon = months[dateValue[0]];
            By expMon = By.XPath("(//span[contains(.,'" + mon + "')])[1]");

            if (dateValue[1].StartsWith("0"))
            {
                dateValue[1] = dateValue[1].Substring(1);
            }
            By expDay = By.XPath("//kendo-calendar//span[text()='" + dateValue[1] + "']");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(datepicker);

            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(currentMonYear);
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(year);

            tmsWait.Hard(2);
            if (Int32.Parse(dateValue[2]) < 1960)
            {
                try
                {
                    By todayUI = By.XPath("//span[contains(.,'1960')]");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(todayUI);

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(mid);
                    tmsWait.Hard(2);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(firstthreecharsofYear);
                    tmsWait.Hard(2);
                }
                catch (Exception e)
                {
                    //fw.ConsoleReport(" Catch" + e);
                }
            }
            else
            {
                UIMODUtilFunctions.clickOnWebElementUsingLocators(firstthreecharsofYear);
                tmsWait.Hard(2);

            }
            try
            {
                UIMODUtilFunctions.clickOnWebElementUsingLocators(expYear2);
            }
            catch
            {
                UIMODUtilFunctions.clickOnWebElementUsingLocators(expYear1);
            }
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(expMon);
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(expDay);


        }





        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        /// 
        public static void enterDate(IWebElement datepicker, string dateInput)
        {
            var months = new Dictionary<string, string>()
        {
            { "1", "Jan" },
            { "2", "Feb" },
            { "3", "Mar" },
            { "4", "Apr" },
            { "5", "May" },
            { "6", "Jun" },
            { "7", "Jul" },
            { "8", "Aug" },
            { "9", "Sep" },
            { "01", "Jan" },
            { "02", "Feb" },
            { "03", "Mar" },
            { "04", "Apr" },
            { "05", "May" },
            { "06", "Jun" },
            { "07", "Jul" },
            { "08", "Aug" },
            { "09", "Sep" },
            { "10", "Oct" },
            { "11", "Nov" },
            { "12", "Dec" }

        };

            string ip = dateInput; // MM DD YYYY
            string[] dateValue = ip.Split('/');


            string currentMonthYear = AngularFunction.currentMonth() + " " + AngularFunction.currentYear();
            By currentMonYear = By.XPath("//span[text()='" + currentMonthYear + "']");

            By year = By.XPath("(//span[contains(.,'" + AngularFunction.currentYear() + "')])[2]");
            By mid = By.XPath("//span[text()='1970']");

            string firsthreechar = AngularFunction.firstthreecharsofYear(dateValue[2]) + "0";     // Year First 3 char       
            By firstthreecharsofYear = By.XPath("//span[contains(.,'" + firsthreechar + "')]");
            if (Convert.ToInt32(dateValue[2]) > 2030)
            {
                dateValue[2] = "2030";

            }
            By expYear1 = By.XPath("(//span[text()='" + dateValue[2] + "'])[1]"); // Year
            By expYear2 = By.XPath("(//span[text()='" + dateValue[2] + "'])[2]"); // Year
            string mon = months[dateValue[0]];
            By expMon = By.XPath("(//span[contains(.,'" + mon + "')])[1]");

            if (dateValue[1].StartsWith("0"))
            {
                dateValue[1] = dateValue[1].Substring(1);
            }
            By expDay = By.XPath("//kendo-calendar//span[text()='" + dateValue[1] + "']");


            fw.ExecuteJavascript(datepicker);
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(currentMonYear);
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(year);
            tmsWait.Hard(2);
            if (Int32.Parse(dateValue[2]) < 1960)
            {
                try
                {
                    By todayUI = By.XPath("//span[contains(.,'1960')]");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(todayUI);

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(mid);
                    tmsWait.Hard(2);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(firstthreecharsofYear);
                    tmsWait.Hard(2);
                }
                catch (Exception e)
                {
                    fw.ConsoleReport(" Catch" + e);
                }
            }
            //if (dateValue[2].EndsWith("0"))
            //{

            //    UIMODUtilFunctions.clickOnWebElementUsingLocators(firstthreecharsofYear);
            //    tmsWait.Hard(2);
            //    UIMODUtilFunctions.clickOnWebElementUsingLocators(expYear1);
            //}
            else
            {
                UIMODUtilFunctions.clickOnWebElementUsingLocators(firstthreecharsofYear);
                tmsWait.Hard(2);
                //UIMODUtilFunctions.clickOnWebElementUsingLocators(expYear2);

            }
            try
            {
                UIMODUtilFunctions.clickOnWebElementUsingLocators(expYear2);
            }
            catch
            {
                UIMODUtilFunctions.clickOnWebElementUsingLocators(expYear1);
            }
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(expMon);
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(expDay);

        }
        public static string currentMonth()
        {

            string month = DateTime.Now.Month.ToString();
            int monthFullname = Int32.Parse(month);

            return CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(monthFullname);
        }

        public static string firstthreecharsofYear(string ip)
        {
            return ip.Substring(0, 3).ToString();
        }

        public static string currentYear()
        {
            return DateTime.Now.Year.ToString();
        }
        public static void clickonNextLink()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("a[title='Go to the next page']")));

        }

        public static void clickFirstPageLink()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("a[title='Go to the first page']")));

        }

        public static void clickonPreviousLink()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("a[title='Go to the previous page']")));
        }

        public static void clickonLastpageLink()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("a[title='Go to the last page']")));
        }



        public static String getToasterMessage()
        {
            return Browser.Wd.FindElement(By.XPath("//div[@class='k-notification-content']")).Text;
        }
        public static void selectDropDownValue(By loc, string value)
        {

            By drpValue = By.XPath("//li[text()='" + value + "']");
            By drpValue1 = By.XPath("//li[contains(.,'" + value + "')]");
            AngularFunction.clickOnElement(loc);
            tmsWait.Hard(3);
            try
            {
                AngularFunction.clickOnElement(drpValue);
            }
            catch
            {
                AngularFunction.clickOnElement(drpValue1);
            }

        }

      

        public static void selectDropDownValue(IWebElement loc, string value)
        {

            By drpValue = By.XPath("//li[text()='" + value + "']");
            By drpValue1 = By.XPath("//li[contains(.,'" + value + "')]");
            AngularFunction.clickOnElement(loc);
            tmsWait.Hard(3);
            try
            {
                AngularFunction.clickOnElement(drpValue);
            }
            catch
            {
                AngularFunction.clickOnElement(drpValue1);
            }

        }

        public static void sendKeysWithClear(By loc, string value)
        {
            Browser.Wd.FindElement(loc).Clear();

            Browser.Wd.FindElement(loc).SendKeys(value);
        }

        public static void sendKeysWithClear(IWebElement ele, string value)
        {
            ele.Clear();

            ele.SendKeys(value);
        }

        public static void sendKeysWithOutClear(By loc, string value)
        {


            Browser.Wd.FindElement(loc).SendKeys(value);
        }

        public static void sendKeysWithOutClear(IWebElement ele, string value)
        {


            ele.SendKeys(value);
        }
        public static void selectValueFromMultiSelect(IWebElement ele, string value)
        {
                       
            AngularFunction.sendKeysWithOutClear(ele, value);

            By ele1 = By.XPath("//li[contains(.,'" + value + "')]");
            AngularFunction.clickOnElement(ele1);

        }

        public static string getAttributeValue(By loc, string strValue)
        {
            IWebElement ele = Browser.Wd.FindElement(loc);
            string actual_value = ele.GetAttribute("value");
            return actual_value;
        }
        public static string getAttributeValue(By loc)
        {
            IWebElement ele = Browser.Wd.FindElement(loc);
            string actual_value = ele.GetAttribute("value");
            return actual_value;
        }
        //public static void enterDate(By date, string strValue)
        //{

        //    string[] value = strValue.Split('/');
        //    Browser.Wd.FindElement(date).Clear();
        //    Browser.Wd.FindElement(date).SendKeys(value[0]);
        //    Browser.Wd.FindElement(date).SendKeys(value[1]);
        //    Browser.Wd.FindElement(date).SendKeys(value[2]);

        //    //string value = strValue.Replace("/", "");            
        //    //Browser.Wd.FindElement(date).Clear();
        //    //Browser.Wd.FindElement(date).SendKeys(value);

        //    tmsWait.Hard(3);

        //}
        //public static void enterDate(IWebElement date, string strValue)
        //{
        //    string[] value = strValue.Split('/');
        //  date.Clear();
        //    date.SendKeys(value[0]);
        //    date.SendKeys(value[1]);
        //    date.SendKeys(value[2]);
        //    //string value = strValue.Replace("/", "");
        //    //date.Clear();
        //    //date.SendKeys(value);

        //    tmsWait.Hard(3);

        //}

        public static string getText(IWebElement ele)
        {
            return ele.Text;
        }
        public static string getText(By loc)
        {
            IWebElement ele = Browser.Wd.FindElement(loc);
            return ele.Text;
        }


        public static void selectKendoDropDownValue(By loc, string value)
        {

            Browser.Wd.FindElement(loc); 

            By drpValue = By.XPath("//li[text()='" + value + "']");
            By drpValue1 = By.XPath("//li[contains(.,'" + value + "')]");


            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            tmsWait.Hard(3);
            try
            {
                UIMODUtilFunctions.clickOnWebElementUsingLocators(drpValue);
            }
            catch
            {
                UIMODUtilFunctions.clickOnWebElementUsingLocators(drpValue1);
            }

        }
        public static void selectKendoDropDownValue(IWebElement loc, string value)
        {

            By drpValue = By.XPath("//li[text()='" + value + "']");
            By drpValue1 = By.XPath("//li[contains(.,'" + value + "')]");


            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            tmsWait.Hard(3);
            try
            {
                UIMODUtilFunctions.clickOnWebElementUsingLocators(drpValue);
            }
            catch
            {
                UIMODUtilFunctions.clickOnWebElementUsingLocators(drpValue1);
            }

        }

        public static void clickOnElement(By loc)
        {
            tmsWait.Hard(2);
            IWebElement element = Browser.Wd.FindElement(loc);

            IJavaScriptExecutor js = Browser.Wd as IJavaScriptExecutor;

            js.ExecuteScript("arguments[0].click();", element);
            tmsWait.Hard(2);

        }
        public static void clickOnElement(IWebElement element)
        {
            tmsWait.Hard(2);
            IJavaScriptExecutor js = Browser.Wd as IJavaScriptExecutor;

            js.ExecuteScript("arguments[0].click();", element);
            tmsWait.Hard(2);

        }


        public static void elementPresenceUsingLocators(By loc)
        {
            try
            {
                fw.ScrollWindowToViewElement(Browser.Wd.FindElement(loc));
                bool presence = Browser.Wd.FindElement(loc).Displayed;
                Assert.IsTrue(presence, " Expected Element is not displayed");
            }
            catch
            {
                Assert.Fail("Element is not present");
            }
        }

        public static void elementPresenceUsingWebElement(IWebElement ele)
        {
            try
            {
                fw.ScrollWindowToViewElement(ele);
                bool presence = ele.Displayed;
                Assert.IsTrue(presence, " Expected Element is not displayed");
            }
            catch
            {
                Assert.Fail("Element is not present");
            }
        }
        public static void elementEnableUsingLocators(By loc)
        {
            try
            {
                fw.ScrollWindowToViewElement(Browser.Wd.FindElement(loc));
                bool presence = Browser.Wd.FindElement(loc).Enabled;
                Assert.IsTrue(presence, " Expected Element is not enabled");
            }
            catch
            {
                Assert.Fail("Element is  enabled");
            }
        }

        public static void elementDisableUsingLocators(By loc)
        {
            try
            {
                fw.ScrollWindowToViewElement(Browser.Wd.FindElement(loc));
                bool presence = Browser.Wd.FindElement(loc).Enabled;
                Assert.IsFalse(presence, " Expected Element is  enabled");
            }
            catch
            {
                Assert.Fail("Element is  Not Present");
            }
        }

        public static void elementNotPresenceUsingLocators(By loc)
        {
            try
            {
                bool presence = Browser.Wd.FindElement(loc).Displayed;
                Assert.IsFalse(presence, " Expected Element is displayed");
            }
            catch
            {
                Assert.IsTrue(true, "Element is not present");
            }
        }
        public static void elementNotPresenceUsingLocators(IWebElement loc)
        {
            try
            {
                bool presence = loc.Displayed;
                Assert.IsFalse(presence, " Expected Element is displayed");
            }
            catch
            {
                Assert.IsTrue(true, "Element is not present");
            }
        }

        public static void CheckBoxOperations(By xpath, string TypeOfAction)
        {
            tmsWait.Hard(2);
            IWebElement element = Browser.Wd.FindElement(xpath);

            if (TypeOfAction.ToLower().Equals("checked"))
            {
                if (!element.Selected)
                {
                    fw.ExecuteJavascript(element);

                }
            }
            else
            {
                if (element.Selected)
                {
                    fw.ExecuteJavascript(element);
                }
            }
        }

        public static void enterTodayAsDate(IWebElement datepicker)
        {
            By todayDate = By.XPath("//span[contains(.,'TODAY')]");

            fw.ExecuteJavascript(datepicker); // Click on Calendar icon
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(todayDate); // Click on TODAY
            tmsWait.Hard(2);
        }

        public static void enterTodayAsDate(By datepicker)
        {
            By todayDate = By.XPath("//span[contains(.,'TODAY')]");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(datepicker);
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(todayDate);
            tmsWait.Hard(2);
        }
    }
}
