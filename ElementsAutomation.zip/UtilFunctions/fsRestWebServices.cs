﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Windows;
using System.Drawing;
//using System.Windows.Forms;
using System.Windows.Input;
using System.IO;
using OpenQA.Selenium.Support.UI;
using System.Net;
//using System.Web.Script.Serialization;
using System.Xml;



namespace TMSoR1
{
    [Binding]
    class fsRestWebServices
    {

        [Given(@"Variable ""(.*)"" is response from ""(.*)"" Service Request ""(.*)""")]
        [When(@"Variable ""(.*)"" is response from ""(.*)"" Service Request ""(.*)""")]
        public void GivenVariableIsResponseFromServiceRequest(string p0, string p1, string p2)
        {
            string variableName = tmsCommon.GenerateData(p0);
            string serviceRequestType = tmsCommon.GenerateData(p1);
            string URL = tmsCommon.GenerateData(p2);
            string DATA = @"{""object"":{""name"":""Name""}}";
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL);
            request.Method = "POST";
            switch (serviceRequestType.ToLower())
            {
                case "json":
                    {
                        request.ContentType = "application/json";
                        break;
                    }
                case "xml":
                    {
                        request.ContentType = "application/xml";
                        request.Accept = "application/xml";
                        break;
                    }
            }
            request.ContentLength = DATA.Length;
            using (Stream webStream = request.GetRequestStream())
            using (StreamWriter requestWriter = new StreamWriter(webStream, System.Text.Encoding.ASCII))
            {
                requestWriter.Write(DATA);
                tmsWait.Hard(1);
            }

            try
            {
                WebResponse webResponse = request.GetResponse();
                WebHeaderCollection header = webResponse.Headers;

                using (Stream webStream = webResponse.GetResponseStream())
                {
                    if (webStream != null)
                    {
                        using (StreamReader responseReader = new StreamReader(webStream))
                        {
                            string response = responseReader.ReadToEnd();
                            fw.setVariable(variableName, response);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.Out.WriteLine("-----------------");
                Console.Out.WriteLine(e.Message);
            }

        }

        public class Response
        {

            public string lat { get; set; }
            public string short_name { get; set; }
        }
    }
}