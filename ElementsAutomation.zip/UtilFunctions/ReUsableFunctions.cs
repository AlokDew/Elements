﻿using Microsoft.Office.Interop.Excel;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;

using System.Text;
using System.Threading.Tasks;
//using System.Windows.Forms;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode
{
    class ReUsableFunctions
    {
        public static string downloadFolderPath = System.IO.Path.Combine(Environment.ExpandEnvironmentVariables("%userprofile%"), "Downloads");
        public static void reportAuthenticationHandler()
        {
            try
            {
                if (ConfigFile.BrowserType.ToString().ToLower().Equals("chrome"))
                {
                    //    IWebElement chromeWindow = Browser.winium.FindElementByXPath(".//Window[contains(@ClassName,'Chrome') ]");

                    //    IWebElement SecurityPopupWindow = chromeWindow.FindElement(By.Name("Sign in"));

                    //    SecurityPopupWindow.FindElement(By.XPath(".//Edit[@Name='Username']")).Clear();
                    //    SecurityPopupWindow.FindElement(By.XPath(".//Edit[@Name='Username']")).SendKeys(ConfigFile.PDMDB);//To Enter User Id 
                    //    SecurityPopupWindow.FindElement(By.XPath(".//Edit[@Name='Password']")).Clear();
                    //    SecurityPopupWindow.FindElement(By.XPath(".//Edit[@Name='Password']")).SendKeys(ConfigFile.PDMDBPassword);//To Enter Password 
                    //    SecurityPopupWindow.FindElement(By.XPath(".//Button[@Name='Log in']")).Click();//To click Log in

                    ///*******************************************************
                    //tmsWait.Hard(1);
                    //Browser.winium.FindElementByName("Username").SendKeys(ConfigFile.PDMDB);
                    //tmsWait.Hard(2);
                    //System.Windows.Forms.SendKeys.SendWait("{TAB}");
                    //Browser.winium.FindElementByName("Password").SendKeys(ConfigFile.PDMDBPassword);
                    //tmsWait.Hard(2);
                    //System.Windows.Forms.SendKeys.SendWait("{TAB}");
                    //tmsWait.Hard(2);
                    //System.Windows.Forms.SendKeys.SendWait("{ENTER}");
                    //Browser.winium.FindElementByName("Sign in").Click();
                    //tmsWait.Hard(1);
                }
                if (ConfigFile.BrowserType.ToString().ToLower().Equals("ff"))
                {

                    Browser.winium.FindElement(By.Name("User Name:")).SendKeys(ConfigFile.PDMDB);
                  //  //System.Windows.Forms.SendKeys.SendWait("{TAB}");
                    Browser.winium.FindElement(By.Name("Password:")).SendKeys(ConfigFile.PDMDBPassword);
                   // //System.Windows.Forms.SendKeys.SendWait("{TAB}");
                    ////System.Windows.Forms.SendKeys.SendWait("{ENTER}");
                }
            }
            catch
            {
                fw.ConsoleReport(" There is no Authentication required dialog ");
            }
        }
        public static string getCurrentURLandReplaceAWord(int index , char seprator,string oldvalue, string newvalue)
        {
            String url = Browser.Wd.Url;
            String[] s = url.Split(seprator);
            String sqlserver = s[index].ToString().Replace(oldvalue, newvalue);
            return sqlserver;

        }
        public static int getTotalPages()
        {

            String str = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Page')]")).Text;
            string[] Count = str.Split(' ');
           int totalPagesIntheGrid = Int32.Parse(Count[1]);
            return totalPagesIntheGrid;


        }

        public static string getTotalItems()
        {

            String str = Browser.Wd.FindElement(By.XPath("//kendo-pager-info[contains(.,'items')]")).Text;
            string[] Count = str.Split(' ');
            string totalPagesIntheGrid = (Count[4]);
            return totalPagesIntheGrid;


        }

        public static string getPerPageItems()
        {

            String str = Browser.Wd.FindElement(By.XPath("//kendo-pager-info[contains(.,'items')]")).Text;
            string[] Count = str.Split(' ');
            string totalPagesIntheGrid = (Count[2]);
            return totalPagesIntheGrid;


        }
        //kendo-pager-info[contains(.,'items')]

        public static void selectValueFromDropDown(IWebElement element, String Value)
        {

            //SelectElement drp = new SelectElement(element);
            //drp.SelectByText(Value);

            By Drp = By.XPath("//kendo-dropdownlist[@test-id='pirResponse-select-unconfirmedSuspects']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + Value + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }
        public static void selectValueFromDropDownAngJS(IWebElement element, String Value)
        {
            By Drp = By.XPath("(//label[text()='Plan ID']/parent::div//span)[4]");
            By typeapp = By.XPath("//li[text()='" + Value + "']");




            UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

        }
        public static void selectValueFromDropDownAngJS(string element, string Value)
        {
            By Drp = By.XPath("//label[text()='"+ element + "']/parent::div//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + Value + "']");




            UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

        }


        public static void legacyDropDownListSelection(IWebElement element, String Value)
        {

            SelectElement drp = new SelectElement(element);
            drp.SelectByValue(Value);

        }
        /// <summary>
        ///  Read Excel sheet content using specific Sheet, record column - Venkatesh P
        /// </summary>
        /// <param name="sourceXLSFilePath"></param>
        /// <param name="targetCSVFilePath"></param>
        /// <param name="sheetindex"></param>
        /// <param name="recordColumn"></param>
        /// <returns></returns>

        public static List<string> ReadSpecificSheet_SpecificIndex_Data_XLSFile(string sourceXLSFilePath, string targetCSVFilePath,int sheetindex,int recordColumn)
        {
            fw.ConsoleReport(sourceXLSFilePath + " is downloaded");
            Microsoft.Office.Interop.Excel.Application xls = new Microsoft.Office.Interop.Excel.Application();
            Workbook workbook = xls.Workbooks.Open(sourceXLSFilePath);
            object v = workbook.Worksheets.get_Item(sheetindex);
            string sheetName = (string)v;
            Worksheet ws = (Worksheet)workbook.Sheets[sheetName];

            //Conversion of XLS frile to CSV file
            ws.SaveAs(targetCSVFilePath, XlFileFormat.xlCSV);
            fw.ConsoleReport(" Now Excel file is converted to CSV format to read file content");
            // Deleting Source XLS file after saving in to .CSV format

            string[] fileExtensions = { ".XLS", ".xls" };

            string downloadPath = System.IO.Path.Combine(Environment.ExpandEnvironmentVariables("%userprofile%"), "Downloads");
            DirectoryInfo di = new DirectoryInfo(downloadPath);
            FileInfo[] oldDownloadedFiles = di.EnumerateFiles().Where(p => fileExtensions.Contains(p.Extension, StringComparer.InvariantCultureIgnoreCase)).ToArray();


            foreach (var oldFile in oldDownloadedFiles)
            {
                oldFile.Attributes = FileAttributes.Normal;
                File.Delete(oldFile.FullName);
            }
            //Releasing and killing XLS object
            Marshal.ReleaseComObject(ws);
            workbook.Close(0);
            xls.Quit();
            Marshal.ReleaseComObject(xls);
            Process[] process = Process.GetProcessesByName("Excel");
            foreach (Process p in process)
            {
                if (!string.IsNullOrEmpty(p.ProcessName))
                {
                    try
                    {
                        p.Kill();
                    }
                    catch { }
                }
            }

            fw.ConsoleReport(targetCSVFilePath + " is downloaded");
            StreamReader streamReader = new StreamReader(targetCSVFilePath);
            List<string> csvData = new List<string>();
            string strline = "";
            string[] _values = null;
            int x = 0;
            while (!streamReader.EndOfStream)
            {
                x++;
                strline = streamReader.ReadLine();
                _values = strline.Split(',');

                try
                {
                    csvData.Add(_values[recordColumn - 1]); //  Record Column
                }
                catch
                {
                    fw.ConsoleReport(" There is no Expected Column");
                }
                
            }
            streamReader.Close();
            return csvData;

            //Reading data from CSV file
            // return ReadCSVFile(targetCSVFilePath);
        }

        /// <summary>
        ///  Convert int list to String list Venkatesh P
        /// </summary>
        /// <param name="queryResultInt"></param>
        /// <returns></returns>
        public static List<string> convertIntToArray(List<int> queryResultInt)
        {

            var queryResult = queryResultInt.ConvertAll<string>(delegate (int i)
            {
                return i.ToString();
            });

            return queryResult;
        }
        /// <summary>
        ///  One List content contains another List content Venkatesh P
        /// </summary>
        /// <param name="OneList"></param>
        /// <param name="anotherList"></param>
        /// <returns></returns>
        
        public static bool OneListContentContainsOnAnotherList(List<string> OneList,List<string> anotherList)
        {
            bool match = false;
            if (OneList.Intersect(anotherList).Any())
            {
                Console.WriteLine("matched");
                match = true;
            }
            else
            {
                Console.WriteLine("not matched");
                match = true;
            }
            return match;
        }

        public string TodayDateMMDDYYYY()
        {
            return DateTime.Now.ToString("M/d/yyyy").ToString();
        }
        /// <summary>
        ///  Compare Two List
        /// </summary>
        /// <param name="drpValues"></param>
        /// <param name="dbValues"></param>
        /// <returns></returns>
        public static List<string> compareTwoList(List<string> drpValues, List<string> dbValues)
        {
            List<string> resultantList = new List<string>();

            //Console.WriteLine("Difference in the Drop Down List and DB value lists...");
            IEnumerable<string> list3;
            list3 = drpValues.Except(dbValues);

            foreach (string value in list3)
            {
                resultantList.Add(value);
            }
            return resultantList;
        }

        public static List<int> compareTwoIntList(List<int> drpValues, List<int> dbValues)
        {
            List<int> resultantList = new List<int>();

            //Console.WriteLine("Difference in the Drop Down List and DB value lists...");
            IEnumerable<int> list3;
            list3 = drpValues.Except(dbValues);

            foreach (int value in list3)
            {
                resultantList.Add(value);
            }
            return resultantList;
        }

       

        /// <summary>
        ///  return recently generated File name
        /// </summary>
        /// <param name="PathofGeneratedFiles"></param>
        /// <param name="fileExtension"></param>
        /// <returns></returns>
        public static string latestGeneratedFileName(string PathofGeneratedFiles,string fileExtension)
        {
         var newFilePaths = Directory.GetFiles(@"" + PathofGeneratedFiles + "", "*_*."+ fileExtension + "");
        
        // Adding File Info details like Creation Time etc to sort by latest
        List<FileInfo> lst = new List<FileInfo>();
            foreach (var item in newFilePaths)
            {
                var srcFile = Path.Combine(PathofGeneratedFiles, item);
        lst.Add(new FileInfo(srcFile));
            }

    var latestFileName = lst.OrderByDescending(x => x.CreationTime).FirstOrDefault().FullName;
            return latestFileName;
}

        public static void CheckBoxStatus(IWebElement element, string TypeOfAction)
        {
            tmsWait.Hard(3);
            if (TypeOfAction.ToLower().Equals("checked"))
            {
                Assert.IsTrue(element.Selected);

            }
            else
            {
                Assert.IsFalse(element.Selected);
            }
        }
        /// <summary>
        /// Return Number of records presence on File ( CSV or Text) if you want to exclude header then use -1 on your program
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public static int fileRecordCount(string fileName)
        {
            return File.ReadLines(fileName).Count();
        }

     public static void CheckBoxOperations(IWebElement element,string TypeOfAction)
        {
            tmsWait.Hard(2);

            if (TypeOfAction.ToLower().Equals("checked"))
            {
                if (!element.Selected)
                {
                    fw.ExecuteJavascript(element);

                }
            }
            else
            {
                if (element.Selected)
                {
                    fw.ExecuteJavascript(element);
                }
            }
        }
        public static void CheckBoxOperations(By xpath, string TypeOfAction)
        {
            tmsWait.Hard(2);
            IWebElement element = Browser.Wd.FindElement(xpath);

            if (TypeOfAction.ToLower().Equals("checked"))
            {
                if (!element.Selected)
                {
                    fw.ExecuteJavascript(element);

                }
            }
            else
            {
                if (element.Selected)
                {
                    fw.ExecuteJavascript(element);
                }
            }
        }

        static string oevswitch;
        public static void SwitchONOFFButton(string SwitchStatus)
            {
            if (SwitchStatus.ToLower().Equals("checked") || SwitchStatus.ToLower().Equals("on"))
            {
                oevswitch = "on";
            }
            else
            {
                oevswitch = "off";
            }

            bool iselementpresent = false;
            By buttonStatus = By.XPath("//div[@id='mainSwitchButtonArea']//span[contains(@class,'switch-" + oevswitch + "')]");
            if (oevswitch.Equals("on"))
            {
                try
                {
                    iselementpresent = Browser.Wd.FindElement(buttonStatus).Displayed;
                    fw.ConsoleReport(" Switch is already in ON Status");
                }
                catch
                {
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-container km-switch-container'])[1]")));
                    tmsWait.Hard(2);
                }
            }

            else if (oevswitch.Equals("off"))

            {
                try
                {
                    iselementpresent = Browser.Wd.FindElement(buttonStatus).Displayed;
                    fw.ConsoleReport(" Switch is already in OFF Status");
                }
                catch
                {
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-container km-switch-container'])[1]")));
                    tmsWait.Hard(2);
                }
            }

        }
        public static void checkBoxOperationsWithMsgVarification(By xpath, string TypeOfAction, string msg)
        {
            tmsWait.Hard(2);
            IWebElement element = Browser.Wd.FindElement(xpath);
            string expectedvalue = msg.ToString();
            if (TypeOfAction.ToLower().Equals("checked"))
            {
                if (!element.Selected)
                {
                    fw.ExecuteJavascript(element);

                    string actualvalue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                    Assert.IsTrue(actualvalue.Contains(expectedvalue), "Message is not displayed");

                }
            }
            else
            {
                if (element.Selected)
                {
                    fw.ExecuteJavascript(element);
                    string actualvalue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                    Assert.IsTrue(actualvalue.Contains(expectedvalue), "Message is not displayed");
                }
            }

        }
        public static bool CheckBoxGetStatus(By xpath, string TypeOfAction)
        {
            tmsWait.Hard(2);
            IWebElement element = Browser.Wd.FindElement(xpath);
            string status = element.GetAttribute("ng-checked").ToString();
            if (TypeOfAction.ToLower().Equals("checked"))
            {
                
                 
                if (status.Equals("true"))
                {
                    return true;
                }
                
            }
            else if(status.Equals("false"))
            {

                return true;
                
            }
            return false;
        }
        
        public static void deleteFilesFromDownloadFolder()
        {
            tmsWait.Hard(4);
            fw.ConsoleReport(" Deleting download Folder contents");
            string[] fileExtensions = { ".xml",".CSV", ".XLS", ".PDF", ".pdf", ".xls", ".csv", ".XLSX",".txt" };
            DirectoryInfo di = new DirectoryInfo(downloadFolderPath);
            FileInfo[] oldDownloadedFiles = di.EnumerateFiles().Where(p => fileExtensions.Contains(p.Extension, StringComparer.InvariantCultureIgnoreCase)).ToArray();

            try
            {
                foreach (var oldFile in oldDownloadedFiles)
                {
                    oldFile.Attributes = FileAttributes.Normal;
                    File.Delete(oldFile.FullName);
                }
            }
            catch
            {
                fw.ConsoleReport(" There is no file to delete");
            }
        }

        public static void deleteFilesFromTempFolder()
        {
            tmsWait.Hard(4);
            fw.ConsoleReport(" Deleting temp Folder contents");
            string[] fileExtensions = { ".xml", ".CSV", ".XLS", ".PDF", ".pdf", ".xls", ".csv", ".XLSX", ".txt" };
            DirectoryInfo di = new DirectoryInfo("c:\\temp\\");
            FileInfo[] oldDownloadedFiles = di.EnumerateFiles().Where(p => fileExtensions.Contains(p.Extension, StringComparer.InvariantCultureIgnoreCase)).ToArray();
            // Delete Files
            try
            {
                foreach (var oldFile in oldDownloadedFiles)
                {
                    oldFile.Attributes = FileAttributes.Normal;
                    File.Delete(oldFile.FullName);
                }
                // Delete Folder
                foreach (DirectoryInfo dir in di.GetDirectories())
                {
                    dir.Delete(true);
                }
            }

            catch
            {
                fw.ConsoleReport(" Thee is no file to delete");
            }
        }
      

        static string downloadPath = System.IO.Path.Combine(Environment.ExpandEnvironmentVariables("%userprofile%"), "Downloads");
        /// <summary>
        /// Helpful to return recently generaed File from Download folder
        /// </summary>
        /// <returns></returns>
        public static string getRecentlyDownloadedCSVFileFromDownloadFolder()
        {
           
        var files = new DirectoryInfo(downloadPath).GetFiles("*.csv");
            string latestfile = "";
            DateTime lastupdated = DateTime.MinValue;
            foreach (FileInfo file in files)
            {
                if (file.LastWriteTime > lastupdated)
                {
                    lastupdated = file.LastWriteTime;
                    latestfile = file.Name;
                }
            }
            return latestfile;
        }

        /// <summary>
        /// Helpful to return recently generaed File from specific folder ( *.csv or *.txt etc)
        /// </summary>
        /// <param name="folderPath"></param>
        /// <param name="fileExtension"></param>
        /// <returns></returns>
        public static string getRecentFileFromSpecifiedFolder(string folderPath,string fileExtension)
        {

            var files = new DirectoryInfo(folderPath).GetFiles(fileExtension);
            string latestfile = "";
            DateTime lastupdated = DateTime.MinValue;
            foreach (FileInfo file in files)
            {
                if (file.LastWriteTime > lastupdated)
                {
                    lastupdated = file.LastWriteTime;
                    latestfile = file.Name;
                }
            }
            return latestfile;
        }
        public static string getRecentFileFromSpecifiedFolderWithFolderPath(string folderPath, string fileExtension)
        {

            var files = new DirectoryInfo(folderPath).GetFiles(fileExtension);
            string latestfile = "";
            DateTime lastupdated = DateTime.MinValue;
            foreach (FileInfo file in files)
            {
                if (file.LastWriteTime > lastupdated)
                {
                    lastupdated = file.LastWriteTime;
                    latestfile = file.Name;
                }
            }
            return folderPath+latestfile;
        }

        /// <summary>
        ///  Taking Snapshots
        /// </summary>
        public static void takingSnapshots()
        {
            try
            {
                //string fileNameBase = string.Format("{0}_{1}",
                //                     ScenarioContext.Current.ScenarioInfo.Title,
                //                     DateTime.Now.ToString("yyyyMMdd_HHmmss"));
                string fileNameBase = (ScenarioContext.Current.ScenarioInfo.Tags)[0].ToString()+".png";
                                     
                // Create a Specific Folder
                var artifactDirectory = @"C:\TMS\";
                if (!Directory.Exists(artifactDirectory))  //  Verify Specific Folder Exists, if No then Create it.
                {
                    Directory.CreateDirectory(artifactDirectory);
                }
                artifactDirectory = System.IO.Path.Combine(System.IO.Path.Combine(Environment.ExpandEnvironmentVariables("%SystemDrive%")) + "\\TMS\\");
                DirectoryInfo di = new DirectoryInfo(artifactDirectory);
                di.Attributes &= ~FileAttributes.ReadOnly;
                ITakesScreenshot takesScreenshot = Browser.Wd as ITakesScreenshot;
                var snapshotdestinationFolder = @"C:\TMS\";
                if (takesScreenshot != null)
                {
                    var screenshot = takesScreenshot.GetScreenshot();
                    string screenshotFilePath = System.IO.Path.Combine(artifactDirectory, fileNameBase);
                    screenshot.SaveAsFile(fileNameBase, OpenQA.Selenium.ScreenshotImageFormat.Jpeg);
                    try
                    {
                        File.Move(fileNameBase, snapshotdestinationFolder + "\\" + fileNameBase);
                    }
                    catch
                    {
                      
                    }
                    Console.WriteLine("Screenshot: {0}", new Uri(screenshotFilePath));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error while taking screenshot: {0}", ex);
            }

        }
        /// <summary>
        ///  This will return TMS Shared Fodler for EAM, you can customize based on your Need
        /// </summary>
        /// <returns></returns>

        public static string returnTMSSharedInputFolder(string EAM)
        {
             string[] URLParts = ConfigFile.URL.Split('/');
        string currentTenant = (URLParts[2].Split('.'))[0];
        string appServer = (URLParts[2].Split('.'))[1];
        string destinatinLoc = "\\\\" + appServer + "\\TMSShareFolder\\" + currentTenant + "\\" + EAM + "\\Input\\";
            return destinatinLoc;
      }
        public static string returnCurrentTenant()
        {
            string[] URLParts = ConfigFile.URL.Split('/');
            string currentTenant = (URLParts[2].Split('.'))[0];
            return currentTenant;
           
        }

            public static bool elementPresence(By element)
        {
            try
            {
                Browser.Wd.FindElement(element);
                return true;
            }

            catch
            {
                return false;
            }
        }
        public static bool elementDisplayed(By element)
        {
            try
            {
                return Browser.Wd.FindElement(element).Displayed;
                 
            }

            catch
            {
                return false;
            }
        }

        public static bool elementVisible(By element)
        {
            try
            {
                return Browser.Wd.FindElement(element).Enabled;

            }

            catch
            {
                return false;
            }
        }
        public static void enterValueOnWebElement(IWebElement element,String Value)
        {
            try
            {
                tmsWait.Hard(2);
                element.Clear();
                tmsWait.Hard(1);
                element.Click();
                tmsWait.Hard(2);
                element.SendKeys(Value);
                tmsWait.Hard(1);
            }
            catch
            {
                fw.ConsoleReport(" Element is not interactive");
            }
         
        }

        public static void enterValueOnWebElement(By loc, String Value)
        {
            try
            {
                tmsWait.Hard(2);
                Browser.Wd.FindElement(loc).Clear();
                tmsWait.Hard(1);
                Browser.Wd.FindElement(loc).Click();
                tmsWait.Hard(2);
                Browser.Wd.FindElement(loc).SendKeys(Value);
                tmsWait.Hard(1);
            }
            catch
            {
                fw.ConsoleReport(" Element is not interactive");
            }

        }
        public static void enterValueOnWebElementWithoutClear(IWebElement element, String Value)
        {
   
            tmsWait.Hard(3);
          String  Value1 = tmsCommon.GenerateData(Value);
        //    fw.ExecuteJavascriptScroll(element);
          //  fw.ExecuteJavascriptSetText(element, Value1);
            
            element.SendKeys(Value1);
            element.SendKeys(OpenQA.Selenium.Keys.Tab);
        }

        public static void enterDateUsingAngularChanges(By loc,string orgValue)
        {
            tmsWait.Hard(3);
            string modValue = orgValue.Replace("/", "");
          
            Browser.Wd.FindElement(loc).Clear();

            Browser.Wd.FindElement(loc).SendKeys(modValue);

           
        }
        public static void enterDateUsingAngularChanges(IWebElement ele, string orgValue)
        {
            tmsWait.Hard(3);
            string modValue = orgValue.Replace("/", "");

            ele.Clear();

            ele.SendKeys(modValue);


        }

        public static void selectDropDownValueUsingAngularChanges(IWebElement loc, string valueLoc)
        {

            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            tmsWait.Hard(3);
            By typeofValue = By.XPath("//li[text()='" + valueLoc + "']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeofValue);
        }

        public static void selectDropDownValueUsingContainsTextAngularChanges(IWebElement loc, string valueLoc)
        {

            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            tmsWait.Hard(3);
            By typeofValue = By.XPath("//li[contains(.,'" + valueLoc + "')]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeofValue);
        }
        public static void selectDropDownValueUsingAngularChanges(By loc, By valueLoc)
        {
            
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(valueLoc);
        }
        public static void selectDropDownValueUsingAngularChanges(IWebElement loc, By valueLoc)
        {

            fw.ExecuteJavascript(loc);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(valueLoc);
        }
        public static void enterValueOnWebElementWithClear(IWebElement element, string Value)
        {

            tmsWait.Hard(3);
            string Value1 = tmsCommon.GenerateData(Value);
           element.Clear();
            element.SendKeys(Value1);
            element.SendKeys(OpenQA.Selenium.Keys.Tab);
        }
        public static void enterValueOnWebElementWithClear(string element, string value)
        {
           
                value = value.Replace("/", "");
                By Drp = By.XPath("//label[text()='"+element+"']/parent::div//input");
        Browser.Wd.FindElement(Drp).Clear();

        Browser.Wd.FindElement(Drp).SendKeys(value);

        tmsWait.Hard(3);        


            }
    public static void ScrollingInToSpecicElementView(IWebElement element)
        {
            IJavaScriptExecutor js = Browser.Wd as IJavaScriptExecutor;
            js.ExecuteScript("arguments[0].scrollIntoView(true);", element);
       
        }


        public static void clickOnWebElementAfterScrollingInToSpecicElementView(IWebElement element)
        {
            IJavaScriptExecutor js = Browser.Wd as IJavaScriptExecutor;
            js.ExecuteScript("arguments[0].scrollIntoView(true);", element);
            js.ExecuteScript("arguments[0].click();", element);
        }

      
        public static void toasterMessageDisplay(string expValue)
        {
           // tmsWait.Hard(1);
           // By toastMsg = By.XPath("//div[@class='toast-message'][contains(.,'" + expValue + "')]");

          //  OpenQA.Selenium.Interactions.Actions actions = new OpenQA.Selenium.Interactions.Actions(Browser.Wd);       
           // actions.Build();
          //  actions.MoveToElement(Browser.Wd.FindElement(toastMsg));
           // actions.Perform();

           /// bool msgDisplay = Browser.Wd.FindElement(toastMsg).Displayed;
            //Assert.IsTrue(msgDisplay, expValue + " is not displayed");
          //  actions.Release();

        }
        public static bool checkElementDisplayinGrid(By xpath)
        {

            //string mbi = tmsCommon.GenerateData(p0);
            bool elementSearch = false;
           // By mbiBy = By.XPath("//div[@test-id='legacyMember-grid-legacyMemberGrid']//tbody[contains(.,'" + mbi + "')]");
            By nextPage = By.XPath("//a[@title='Go to the next page']");

            while (!elementSearch)
            {
                elementSearch = elementPresence(xpath);
                tmsWait.Hard(3);
                if (!elementSearch)
                {
                    try
                    {
                        fw.ScrollWindowToViewElement(Browser.Wd.FindElement(nextPage));
                        Browser.Wd.FindElement(nextPage).Click();
                    }
                    catch
                    {
                        Assert.Fail(" Expected Element is not present in grid results");
                        
                    }

                }
               



            }
            return elementSearch;
        }
        public static void toasterMessageDisplayVerificationWithWAIT(string expValue)
        {
            tmsWait.Hard(1);
            By toastMsg = By.XPath("//div[@class='toast-message']");


            OpenQA.Selenium.Interactions.Actions actions = new OpenQA.Selenium.Interactions.Actions(Browser.Wd);
            actions.Build();
            actions.MoveToElement(Browser.Wd.FindElement(toastMsg));
            actions.Perform();


            string actValue = Browser.Wd.FindElement(toastMsg).Text;

            Assert.AreEqual(expValue, actValue, expValue + " is not displayed");
            actions.Release();

        }

        public static void toasterMessageDisplayVerification(string expValue)
        {
            // tmsWait.Hard(1);

            By toastMsg;
             if (ConfigFile.tenantType.Equals("tmsx"))
            {

                 toastMsg = By.XPath("//div[@class='k-notification-content']");

            }
             else
            {
                toastMsg = By.XPath("//div[@class='toast-message']");
            }
            

            OpenQA.Selenium.Interactions.Actions actions = new OpenQA.Selenium.Interactions.Actions(Browser.Wd);
            actions.Build();
            actions.MoveToElement(Browser.Wd.FindElement(toastMsg));
            actions.Perform();

            string actValue = Browser.Wd.FindElement(toastMsg).Text;
            
           Assert.AreEqual(expValue, actValue, expValue + " is not displayed");
            actions.Release();

        }
        public static void ErrorMessageDisplay(string errValue)
        {
            //tmsWait.Hard(1);
            By errMsg = By.XPath("//span[contains(.,'" + errValue + "')]");

            OpenQA.Selenium.Interactions.Actions actions = new OpenQA.Selenium.Interactions.Actions(Browser.Wd);
            actions.Build();
            actions.MoveToElement(Browser.Wd.FindElement(errMsg));
            actions.Perform();

            bool msgDisplay = Browser.Wd.FindElement(errMsg).Displayed;
            Assert.IsTrue(msgDisplay, errValue + " is not displayed");
            actions.Release();

        }


        public static void toasterMessageDisplayWithoutWait(string expValue)
        {
      
            By toastMsg = By.XPath("//div[@class='toast-message'][contains(.,'" + expValue + "')]");

            OpenQA.Selenium.Interactions.Actions actions = new OpenQA.Selenium.Interactions.Actions(Browser.Wd);
            actions.Build();
            actions.MoveToElement(Browser.Wd.FindElement(toastMsg));
            actions.Perform();

            bool msgDisplay = Browser.Wd.FindElement(toastMsg).Displayed;
            Assert.IsTrue(msgDisplay, expValue + " is not displayed");
            actions.Release();

        }



        public static string returnSubStringValue(string input,int startPos,int length)
        {
            string value = input.Substring(startPos, length);
            return value;
        }

        public static void clearContentOnWebElement(IWebElement element)
        {
            element.Clear();
        }

        public static void verifyComponentDisabled(IWebElement element)
        {
            Assert.IsFalse(element.Enabled, " Element is enabled");
        }

        public static void clickOnWebElement(IWebElement element)
        {
            fw.ExecuteJavascript(element);
        }
       
        public static void clickOnWebElementAngJS(IWebElement element,string strValue)
        {
            fw.ExecuteJavascript(element);
            //li[contains(text(),'ALASKA')]
            By typeapp = By.XPath("//li[contains(text(),'" + strValue + "')]");




           // UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
        }

        public static void clickOnSearchMMP()
        {
            //fw.ExecuteJavascript(element);
            By search = By.XPath("//button[@test-id='sccMapping-btn-search']");
            IWebElement actElement = Browser.Wd.FindElement(search);

            fw.ExecuteJavascript(actElement);



      
        }
        public static bool verifyGridElementPresence(string xpath)
        {
            bool hasrow = false;
            int totalPagesIntheGrid = ReUsableFunctions.getTotalPages();
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {

                    tmsWait.Hard(5);
                    hasrow = Browser.Wd.FindElement(By.XPath(xpath)).Displayed;
                   // ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath(xpath)));
                    //break;
                }
                catch
                {

                    //tmsWait.Hard(5);
                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);

                    tmsWait.Hard(5);
                }

            }
            return hasrow;

        }

        public static bool clickOnGridElement(string xpath)
        {
            bool hasrow = false;
            int totalPagesIntheGrid = ReUsableFunctions.getTotalPages();
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {

                    tmsWait.Hard(15);
                    hasrow = Browser.Wd.FindElement(By.XPath(xpath)).Displayed;
                    Browser.Wd.FindElement(By.XPath(xpath)).Click();
                    //ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath(xpath)));
                    break;
                }
                catch
                {

                   tmsWait.Hard(10);
                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);

                    tmsWait.Hard(10);
                }

            }
            return hasrow;

        }

        public static void compareExpectedStringActualWebElementStringValue(string expected,IWebElement actElement)
        {
            Assert.AreEqual(expected, actElement.Text, "Both values are not matching");
        }

        public static void compareExpectedStringActualWebElementGetTextMethod(string expected, IWebElement actElement)
        {
            Assert.AreEqual(expected, actElement.Text, "Both values are not matching");
        }


        public static void compareExpectedValueWithKendoDropDownValue(string expected, IWebElement actElement)
        {
            Assert.AreEqual(expected, actElement.Text, "Both values are not matching");
        }

        public static void compareExpectedValueWithKendoDropDownValue(string expected, By by)
        {
            IWebElement actElement = Browser.Wd.FindElement(by);
            Assert.AreEqual(expected, actElement.Text, "Both values are not matching");
        }

        public static void compareExpectedStringActualWebElementAttributeStringValue(string expected, IWebElement actualElement)
        {
            tmsWait.Hard(7);
            Console.WriteLine(actualElement.GetAttribute("value"));

            string actual = actualElement.GetAttribute("value");
          
          
                Assert.AreEqual(expected, actual, "Both values are not matching");
          
           
        }
        public static void AngularcompareExpectedStringActualWebElementAttributeStringValue(string expected, IWebElement actualElement)
        {
            tmsWait.Hard(7);
            Console.WriteLine(actualElement.GetAttribute("value"));

            string actual = actualElement.GetAttribute("value");


            Assert.AreEqual(expected, actual, "Both values are not matching");


        }

        public static void compareExpectedActualValuesUsingDefaultSelectedDropDownlistValue(string expectedValue, IWebElement actualElement)
        {
            string actualValue=new SelectElement(actualElement).SelectedOption.Text;
            Assert.AreEqual(expectedValue, actualValue, expectedValue + " values are not matching with " + actualValue);
        }
        public static void verifyStringContainsOnWebElement(string expected, IWebElement actualElement)
        {
            bool results = actualElement.Displayed;

            Assert.IsTrue(results,"Expected Elements are not found");
        }

        public static void CompareTwoStrings(string exp,string act)
        {
            Assert.AreEqual(exp, act, exp+" values are not matching with "+act);

        }

        public static void selectDateEndDateField(string p0)
        {
            tmsWait.Hard(2);
            string dateValue = tmsCommon.GenerateData(p0);
            string date = tmsCommon.GenerateData(dateValue).Split(' ')[0];
            string mon = "01";  //date.Split('/')[0];
            string dayValue = "01"; //date.Split('/')[1];
            string yearValue = (Convert.ToInt32(date.Split('/')[2]) - 1).ToString();

            string monthvalue = "";
            switch (mon)
            {
                case "01":
                case "1":
                    monthvalue = "January";
                    break;
                case "02":
                case "2":
                    monthvalue = "January";
                    break;
                case "03":
                case "3":
                    monthvalue = "March";
                    break;
                case "04":
                case "4":
                    monthvalue = "April";
                    break;
                case "05":
                case "5":
                    monthvalue = "May";
                    break;
                case "06":
                case "6":
                    monthvalue = "June";
                    break;
                case "07":
                case "7":
                    monthvalue = "July";
                    break;
                case "08":
                case "8":
                    monthvalue = "August";
                    break;
                case "09":
                case "9":
                    monthvalue = "September";
                    break;
                case "10":
                    monthvalue = "October";
                    break;
                case "11":
                    monthvalue = "November";
                    break;
                case "12":
                    monthvalue = "December";
                    break;
            }



            // click on calendar icon
            IWebElement selectedDate = Browser.Wd.FindElement(By.XPath("//button[@class='btn btn-default reportsCalendar ']"));
            fw.ExecuteJavascript(selectedDate);
            // click on calendar Head Title
            IWebElement title = Browser.Wd.FindElement(By.XPath("//button[@class='btn btn-default btn-sm uib-title']"));
            fw.ExecuteJavascript(title);

            // Click on Left 
            By leftArrow = By.XPath("//button[@class='btn btn-default btn-sm pull-left uib-left']");
            By rightArrow = By.XPath("//button[@class='//button[@class='btn btn-default btn-sm pull-right uib-right']']");

            By expectedYearLoc;
            By expectedMonthLoc;
            By expectedDayLoc;

            expectedMonthLoc = By.XPath("//table[@role='grid']/tbody/tr[contains(.,'" + monthvalue + "')]//button");
            expectedYearLoc = By.XPath("//button[@role='heading']/strong[.='" + yearValue + "']");
            expectedDayLoc = By.XPath("(//div[@datepicker-options='datepickerOptions']//table/tbody//button/span[contains(.,'" + dayValue + "')])[1]");


            bool elementFound = foundDate(expectedYearLoc, leftArrow);
            if (elementFound)
            {
                fw.ConsoleReport(" Year found");
            }
            bool MonthFound = foundDate(expectedMonthLoc, leftArrow);
            if (MonthFound)
            {

                fw.ExecuteJavascript(Browser.Wd.FindElement(expectedMonthLoc));
                fw.ConsoleReport(" Month found");
            }
            bool DayFound = foundDate(expectedDayLoc, leftArrow);

            if (DayFound)
            {

                fw.ExecuteJavascript(Browser.Wd.FindElement(expectedDayLoc));
                fw.ConsoleReport(" Day found");
            }


        }

        public static void selectDateFromDateField(string p0)
        {
            tmsWait.Hard(2);
            string dateValue = tmsCommon.GenerateData(p0);
            string date = tmsCommon.GenerateData(dateValue).Split(' ')[0];
            string mon = "01";  //date.Split('/')[0];
            string dayValue = "01"; //date.Split('/')[1];
            string yearValue = (Convert.ToInt32(date.Split('/')[2]) - 1).ToString();

            string monthvalue = "";
            switch (mon)
            {
                case "01":
                case "1":
                    monthvalue = "January";
                    break;
                case "02":
                case "2":
                    monthvalue = "January";
                    break;
                case "03":
                case "3":
                    monthvalue = "March";
                    break;
                case "04":
                case "4":
                    monthvalue = "April";
                    break;
                case "05":
                case "5":
                    monthvalue = "May";
                    break;
                case "06":
                case "6":
                    monthvalue = "June";
                    break;
                case "07":
                case "7":
                    monthvalue = "July";
                    break;
                case "08":
                case "8":
                    monthvalue = "August";
                    break;
                case "09":
                case "9":
                    monthvalue = "September";
                    break;
                case "10":
                    monthvalue = "October";
                    break;
                case "11":
                    monthvalue = "November";
                    break;
                case "12":
                    monthvalue = "December";
                    break;
            }



            // click on calendar icon
            IWebElement selectedDate = Browser.Wd.FindElement(By.XPath("//button[@class='btn btn-default reportsCalendar']"));
            fw.ExecuteJavascript(selectedDate);
            // click on calendar Head Title
            IWebElement title = Browser.Wd.FindElement(By.XPath("//button[@class='btn btn-default btn-sm uib-title']"));
            fw.ExecuteJavascript(title);

            // Click on Left 
            By leftArrow = By.XPath("//button[@class='btn btn-default btn-sm pull-left uib-left']");
            By rightArrow = By.XPath("//button[@class='//button[@class='btn btn-default btn-sm pull-right uib-right']']");

            By expectedYearLoc;
            By expectedMonthLoc;
            By expectedDayLoc;

            expectedMonthLoc = By.XPath("//table[@role='grid']/tbody/tr[contains(.,'" + monthvalue + "')]//button");
            expectedYearLoc = By.XPath("//button[@role='heading']/strong[.='" + yearValue + "']");
            expectedDayLoc = By.XPath("(//div[@datepicker-options='datepickerOptions']//table/tbody//button/span[contains(.,'" + dayValue + "')])[1]");


            bool elementFound = foundDate(expectedYearLoc, leftArrow);
            if (elementFound)
            {
                fw.ConsoleReport(" Year found");
            }
            bool MonthFound = foundDate(expectedMonthLoc, leftArrow);
            if (MonthFound)
            {

                fw.ExecuteJavascript(Browser.Wd.FindElement(expectedMonthLoc));
                fw.ConsoleReport(" Month found");
            }
            bool DayFound = foundDate(expectedDayLoc, leftArrow);

            if (DayFound)
            {

                fw.ExecuteJavascript(Browser.Wd.FindElement(expectedDayLoc));
                fw.ConsoleReport(" Day found");
            }
            

        }
        
        public static bool foundDate(By loc, By leftArrow)
        {
            bool elementFound = false;
            while (!elementFound)
            {
                try
                {

                    bool elementDisp = Browser.Wd.FindElement(loc).Displayed;
                    if (!elementDisp)
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(leftArrow));
                        elementFound = true;
                    }
                    else if (elementDisp)
                    {

                        elementFound = true;
                    }
                }
                catch
                {
                    fw.ExecuteJavascript(Browser.Wd.FindElement(leftArrow));

                }


            }
            return elementFound;
        }

        public static void verifyMessageText(IWebElement element, string ExpMsg)
        {
            tmsWait.Hard(2);
            string fieldValue = element.Text;
            Console.WriteLine("Verify Message Text: Expected [{0}], Actual [{1}]", ExpMsg, fieldValue);
            Assert.IsTrue(fieldValue.Contains(ExpMsg), "Expected Message is displayed");
         }


        public static void ExecuteSimpleSQLQuery(string SqlString, string DB_NAME)
        {
            Dictionary<int, string[]> table = new Dictionary<int, string[]>();
            SqlCommand thisCommand = null;

            List<string> list = new List<string>();
            try
            {
                SqlConnection DBConn = new SqlConnection();
                //string thisConnectionString = "user id=pdmadmin;" +
                //           "password=pdmrox;" +
                //           "Server=" + ConfigFile.DataServer + ";" +
                //           "Trusted_Connection = yes; " +
                //           "database=" + DB_NAME + "; " +
                //           "connection timeout=30";

                string thisConnectionString = "server=" + ConfigFile.DataServer + ";" + "database=" + DB_NAME + ";" + "user id=" + ConfigFile.DBUser + ";" + "password=" + ConfigFile.DBPassword + ";" + "Max Pool Size=9000;" + "Connection Timeout=150;" + "Min Pool Size=2";
                DBConn.ConnectionString = thisConnectionString;
                DBConn.Open();
                thisCommand = new SqlCommand(SqlString, DBConn);
                SqlDataReader newReader = thisCommand.ExecuteReader();
            }
            catch (Exception e)
            {
                fw.ConsoleReport("Failed read record");
            }
        }
        public static string ExecuteSimpleSQLQueryReturnValue(string SqlString, string DB_NAME)
        {
            string thisConnectionString = null;
            SqlConnection DBConn;
            SqlDataAdapter adapter;
            DataSet ds = new DataSet();
            int i = 0, j = 0;
            ArrayList list = new ArrayList();
            try
            {

                //thisConnectionString = "user id=pdmadmin;" +
                //       "password=pdmrox;" +
                //       "Server=" + ConfigFile.DataServer + ";" +
                //       "Trusted_Connection = yes; " +
                //       "database=" + DB_NAME + "; " +
                //       "connection timeout=30";

                 thisConnectionString = "server=" + ConfigFile.DataServer + ";" + "database=" + DB_NAME + ";" + "user id=" + ConfigFile.DBUser + ";" + "password=" + ConfigFile.DBPassword + ";" + "Max Pool Size=9000;" + "Connection Timeout=150;" + "Min Pool Size=2";

                DBConn = new SqlConnection(thisConnectionString);
                DBConn.Open();
                adapter = new SqlDataAdapter(SqlString, DBConn);
                adapter.Fill(ds);
               
                
                Console.Write("Column Count ==> "+ds.Tables[0].Columns.Count);
                Console.Write("Rown Count ==> "+ds.Tables[0].Rows.Count);

                //DBConn.Close();
                for (i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                {
                    //Console.WriteLine(ds.Tables[0].Rows[i].ItemArray.GetValue(0).ToString());
                    for (j = 0; j <= ds.Tables[0].Rows[i].ItemArray.Count() - 1; j++)
                    {
                        list.Add(ds.Tables[0].Rows[i].ItemArray[j].ToString());
                    }
                }

            }
            catch (Exception e)
            {
                Console.WriteLine("Failed read record: [" + e + "] Query [" + SqlString + "]");
            }
            return list[0].ToString();
            DBConn.Close();
        }

        public static string ExecuteSimpleSQLQueryReturnValueusingWarehouse(string SqlString)
        {
            string thisConnectionString = null;
            SqlConnection DBConn;
            SqlDataAdapter adapter;
            DataSet ds = new DataSet();
            int i = 0, j = 0;
            ArrayList list = new ArrayList();
            try
            {

                //thisConnectionString = "user id=pdmadmin;" +
                //       "password=pdmrox;" +
                //       "Server=" + ConfigFile.DataServer + ";" +
                //       "Trusted_Connection = yes; " +
                //       "database=" + ConfigFile.Warehousedb + "; " +
                //       "connection timeout=30";

                 thisConnectionString = "server=" + ConfigFile.DataServer + ";" + "database=" + ConfigFile.Warehousedb + ";" + "user id=" + ConfigFile.DBUser + ";" + "password=" + ConfigFile.DBPassword + ";" + "Max Pool Size=9000;" + "Connection Timeout=150;" + "Min Pool Size=2";


                DBConn = new SqlConnection(thisConnectionString);
                DBConn.Open();
                adapter = new SqlDataAdapter(SqlString, DBConn);
                adapter.Fill(ds);


                Console.Write("Column Count ==> " + ds.Tables[0].Columns.Count);
                Console.Write("Rown Count ==> " + ds.Tables[0].Rows.Count);

                //DBConn.Close();
                for (i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                {
                    //Console.WriteLine(ds.Tables[0].Rows[i].ItemArray.GetValue(0).ToString());
                    for (j = 0; j <= ds.Tables[0].Rows[i].ItemArray.Count() - 1; j++)
                    {
                        list.Add(ds.Tables[0].Rows[i].ItemArray[j].ToString());
                    }
                }

            }
            catch (Exception e)
            {
                Console.WriteLine("Failed read record: [" + e + "] Query [" + SqlString + "]");
            }
            return list[0].ToString();
            DBConn.Close();
        }

    }
}
