﻿using FileHelpers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace TMSoR1.FrameworkCode
{
   
        [DelimitedRecord(",")]
        [IgnoreEmptyLines()]
        [IgnoreFirst()]
        public class CSVFileContent
        {
        
            public string MemberID { get; set; }
            //Description, this attribute will handle the double quotes issue
            //[FieldQuoted('"', QuoteMode.OptionalForBoth)]
            public string HCC { get; set; }
            public string PaymentYear { get; set; }
            
            public string ProviderID { get; set; }
            public string ProviderName { get; set; }

        }


  


    class UIMODUtilFunctions
    {
        /// <summary>
        ///  this is draft version. You can customize this functions based on your file name, Input data.
        /// </summary>
        public static void CreateCSVFile()
        {

            try
            {
              

                IList<CSVFileContent> studentList = new List<CSVFileContent>() {
                    new CSVFileContent(){ MemberID="MEM00002715",HCC="3",PaymentYear="2018",ProviderID="1155484",ProviderName=" "},
                    new CSVFileContent(){ MemberID="MEM00002715",HCC="4",PaymentYear="2018",ProviderID="1155484",ProviderName=" "},
            };
                //filehelper object
                FileHelperEngine engine = new FileHelperEngine(typeof(CSVFileContent));
                //csv object
                List<CSVFileContent> csv = new List<CSVFileContent>();
                //convert any datasource to csv based object
                CSVFileContent temp = new CSVFileContent();
                foreach (var item in studentList)
                {


                    temp.MemberID = item.MemberID;
                    temp.HCC = item.HCC;
                    temp.PaymentYear = item.PaymentYear;
                    temp.ProviderID = item.ProviderID;
                    temp.ProviderName = item.ProviderName;
                    csv.Add(temp);

                }
                //give file a name and header text
                string filename = "C:\\temp\\CIS_Suspects_20190207_12345.csv";
                engine.HeaderText = "Member ID,HCC,Payment Year,Provider ID,Provider Name";
                //save file locally
                engine.WriteFile(filename, csv);

            }
            catch (Exception ex)
            {
                
            }
        }


        /// <summary>
        /// Enter Value on WebElement using Locators
        /// </summary>
        /// <param name="element"></param>
        /// <param name="Value"></param>
        public static void enterValueOnWebElementUsingLocators(By element, String Value)
        {
            Browser.Wd.FindElement(element).Clear();
            tmsWait.Hard(2);
            Browser.Wd.FindElement(element).SendKeys(Value);
            Browser.Wd.FindElement(element).SendKeys(Keys.Tab);
        }

        public IWebElement getAngularWebElement(string str)
        {
            By loc = By.XPath("//label[text()='"+str+"']/parent::div/input");

            IWebElement ele = Browser.Wd.FindElement(loc);

            return ele;

        }

        public static void enterValueOnWebElementUsingWebElement(IWebElement element, String Value)
        {
            element.Clear();
            tmsWait.Hard(2);
            element.SendKeys(Value);
            element.SendKeys(Keys.Tab);
        }

        public static void enterValueOnWebElementUsingWebElementWithoutClear(IWebElement element, String Value)
        {
           
            tmsWait.Hard(2);
            element.SendKeys(Value);
            element.SendKeys(Keys.Tab);
        }
        public static void clickOnWebElementUsingLocators(By element)
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(element));
            tmsWait.Hard(2);

        }
        public static void clickOnWebElementUsingLocators(IWebElement element)
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(element);
            tmsWait.Hard(2);

        }

        public static void acceptEdgeChromeCertificateErrors()
        {

            if (ConfigFile.BrowserType.Equals("edge") || ConfigFile.BrowserType.Equals("chrome") || ConfigFile.BrowserType.Equals("edgelegacy") || ConfigFile.BrowserType.Equals("edgechrome"))
            {
                try
                {
                    IWebElement advancedButton = Browser.Wd.FindElement(By.CssSelector("[id='details-button']"));
                    fw.ExecuteJavascript(advancedButton);
                    tmsWait.Hard(5);

                    IWebElement acceptRiskBtn = Browser.Wd.FindElement(By.CssSelector("[id='proceed-link']"));
                    fw.ExecuteJavascript(acceptRiskBtn);
                    tmsWait.Hard(10);

                    IWebElement advancedButton1 = Browser.Wd.FindElement(By.CssSelector("[id='details-button']"));
                    fw.ExecuteJavascript(advancedButton1);
                    tmsWait.Hard(5);

                    IWebElement acceptRiskBtn1 = Browser.Wd.FindElement(By.CssSelector("[id='proceed-link']"));
                    fw.ExecuteJavascript(acceptRiskBtn1);

                }
                catch
                {
                    try
                    {
                        IWebElement continueBtn = Browser.Wd.FindElement(By.PartialLinkText("Continue to this webpage"));
                        fw.ExecuteJavascript(continueBtn);
                        tmsWait.Hard(5);
                    }
                    catch
                    {

                        fw.ConsoleReport("There is no Certiicate Warning");
                    }
                }
            }


        }
        public static void sendTABUsingSelenium(By element)
        {
            tmsWait.Hard(2);
           Browser.Wd.FindElement(element).SendKeys(Keys.Tab);
            tmsWait.Hard(2);

        }
        public static void TOASTERMESSAGEVERIFY(string msg)
        {
            string actualValue = Browser.Wd.FindElement(By.XPath("//div[@class='toast-message']")).GetAttribute("aria-label");
            Assert.IsTrue(actualValue.Contains(msg));
        }

        public static void selectTransDrpValue(string value)
        {
            tmsWait.Hard(2);
            By Value = By.XPath("//li[.='"+value+"']");
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(Value));
        }

        public static void selectTransDrpValue1(string value)
        {
            By Value = By.XPath("//li[.,'" + value + "']");
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(Value));
        }
        public static void selectTransDrpValueWithScroll(string value)
        {
            By Value = By.XPath("//span[.='" + value + "']");
            tmsWait.Hard(2);
            fw.ExecuteJavascriptScroll(Browser.Wd.FindElement(Value));
        }
        

        public static void ToasterMessageVerification(string expMsg)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By toastMsg = By.XPath("//div[@class='k-notification-content']");
                string actValue = Browser.Wd.FindElement(toastMsg).Text;
                Assert.IsTrue(actValue.Contains(expMsg));
            }
            else
            {
                string actualMsg = Browser.Wd.FindElement(By.XPath("//div[@class='toast-message']")).GetAttribute("aria-label");
                fw.ConsoleReport(actualMsg);
                Assert.AreEqual(expMsg, actualMsg, " Both message are not matching");
            }
        }

        public static void clickOnConfirmationYesDialog()
        {
            By loc = By.XPath("//button[@id='confirmationDialogYes']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(loc));
        }

        public static void selectPlanID(string planID)
        {
            IWebElement drp = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='ddlplanId_listbox']"));
            fw.ExecuteJavascript(drp);

            tmsWait.Hard(2);
            IWebElement element = Browser.Wd.FindElement(By.XPath("//ul[@id='ddlplanId_listbox']/li[contains(.,'" + planID + "')]"));
            fw.ExecuteJavascript(element);
        }
        public static void selectPBPID(string pbpID)
        {
            IWebElement drppbp = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='ddlPbpId_listbox']"));
            fw.ExecuteJavascript(drppbp);

            tmsWait.Hard(2);
            IWebElement elementpbp = Browser.Wd.FindElement(By.XPath("//ul[@id='ddlPbpId_listbox']/li[contains(.,'" + pbpID + "')]"));
            fw.ExecuteJavascript(elementpbp);

        }

        public static void selectSegmentID(string segment)
        {
            IWebElement drppbp = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='ddlSegmentId_listbox']"));
            fw.ExecuteJavascript(drppbp);

            tmsWait.Hard(2);
            IWebElement elementpbp = Browser.Wd.FindElement(By.XPath("//ul[@id='ddlSegmentId_listbox']/li[contains(.,'" + segment + "')]"));
            fw.ExecuteJavascript(elementpbp);

        }

        public static void clickOnConfirmationNoOrCancelDialog()
        {
            By loc = By.XPath("//button[@id='confirmationDialogNo']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(loc));
        }
        /// <summary>
        /// Return WebElement Attribute value
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        public static string returnValuefromWebComponentUsingGetAttribute(IWebElement element)
        {
            string value=element.GetAttribute("value");
            return value;
        }
        /// <summary>
        /// Return current date in MM/DD/YYYY (02/05/2019 ) format
        /// </summary>
        /// <returns></returns>
        public static string returnDateFormatDDMMYYYY()
        {
            string currentDate = DateTime.Now.ToString("MM/dd/yyyy").ToString();
            return currentDate;
        }
        /// <summary>
        /// Pass Select WebElement and Value as arguments
        /// </summary>
        /// <param name="element"></param>
        /// <param name="value"></param>
        public static void selectDropDownValueFromGendoUI(IWebElement element,string value)
        {
            IWebElement drpValue;
            if (ConfigFile.tenantType == "tmsx")
            {
                drpValue = Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + value + "')]"));
               
            }
            else {
                string idAttribute = element.GetAttribute("aria-owns");
                drpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='" + idAttribute + "']/li[contains(.,'" + value + "')]"));
            }
                fw.ExecuteJavascript(drpValue);
        }

        public static void selectDropDownValueFromKendoDropDown(By drp, string value)
        {
           
           
            By typeapp = By.XPath("//li[text()='" + value + "']");


            UIMODUtilFunctions.clickOnWebElementUsingLocators(drp);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
        }
        public static void selectDropDownValueFromKendoDropDown(IWebElement drp, string value)
        {


            By typeapp = By.XPath("//li[text()='" + value + "']");
            fw.ExecuteJavascript(drp);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
        }
        public static void selectDropDownValueFromGendoUI(string element, string value, int index)
        {
            By xpath = By.XPath("(//label[text()='" +element+"']/parent::div//span)["+index+"]");
            By typeapp = By.XPath("//li[text()='" + value + "']");




            UIMODUtilFunctions.clickOnWebElementUsingLocators(xpath);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
        }
        public static void selectDropDownValueAngJS(string element, string value)
        {
            By xpath = By.XPath("//label[normalize-space(text())='" + element + "']/parent::div//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + value + "']");




            UIMODUtilFunctions.clickOnWebElementUsingLocators(xpath);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
        }
        public static void selectDropDownValueFromKendo(string element, string value)
        {
            By xpath = By.XPath(element);
            By typeapp = By.XPath("//li[text()='" + value + "']");




            UIMODUtilFunctions.clickOnWebElementUsingLocators(xpath);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
        }
        public static void selectDropDownValueUsingAngularContains(string element, string value)
        {
            By xpath = By.XPath(element);
            By typeapp = By.XPath("//li[contains(.,'" + value + "')]");




            UIMODUtilFunctions.clickOnWebElementUsingLocators(xpath);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
        }
        public static void selectDropDownValueUsingAngularExactText(string element, string value)
        {
            By xpath = By.XPath(element);
            By typeapp = By.XPath("//li[text()='" + value + "']");




            UIMODUtilFunctions.clickOnWebElementUsingLocators(xpath);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
        }
        public static string verifyDropDownValueIsDisabled(string trc)
        {
            By xpath=null;
            switch (trc.ToLower()){

                case "trc":
                xpath = By.XPath("//kendo-dropdownlist[@test-id='mmpManagement-select-ddlTrc']/span");
                    break;

        }
        string b = Browser.Wd.FindElement(xpath).GetAttribute("aria-disabled");

            return b; 
        }
    

        public static void selectDropDownValueFromGendoUI(By loc, string value)
        {
            string idAttribute = Browser.Wd.FindElement(loc).GetAttribute("aria-owns");
            IWebElement drpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='" + idAttribute + "']/li[contains(.,'" + value + "')]"));
            fw.ExecuteJavascript(drpValue);
        }
        public static void selectDropDownIndexFromGendoUI(string value)
        {

            IWebElement drpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='" + value + "']/li[2]"));
            fw.ExecuteJavascript(drpValue);
        }
        // Below One is common Statement to create a BEQ response file.
        static StreamWriter sw = null;
        public static void executeStoredProcedure()
        {

            string datetime = DateTime.Now.ToString("yyyyMMddHHmmss");
            string LogFolder = @"C:\temp\";
            try
            {

                //Declare Variables and provide values
                string FileNamePart = "EFTO.RH9999.#BQN4.D090214.T0123456";//Datetime will be added to it
                //EFTO.R(1 alphabet)(4 digits).#BQN4.(any).(any)
                string DestinationFolder = @"C:\temp\";
                string StoredProcedureName = "dbo.BEQResponse_Generator '7X77C00CK03','ProcessedFlag=Y;CurrentEnrlSrcTypeCodePartCD=A;CurrentEnrlSrcTypeCodePartC=D;BeneficiaryMatchFlag=Y;MedPartAEntStartDate=20010901;MedPartBEntStartDate=20010901;PartDEligibilityStartDate=20160701'";//Provide SP name,you Can provide with Parameter if you like
                string FileDelimiter = ","; //You can provide comma or pipe or whatever you like
                string FileExtension = ".txt"; //Provide the extension you like such as .txt or .csv

                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                //Create Connection to SQL Server in which you like to load files
                SqlConnection SQLConnection = new SqlConnection(sb.ToString());
                SQLConnection.InfoMessage += OnInfoMessageGenerated;
                SQLConnection.ConnectionString = "user id=pdmadmin;" +
                       "password=pdmrox;" +
                       "Data Source=asp-tms-SQL-177,1433;" +
                       "Network Library=DBMSSOCN;" +
                       "Initial Catalog=EAM; " +
                       "connection timeout=30";

                //Execute Stored Procedure and save results in data table
                string query = "EXEC " + StoredProcedureName;
                SqlCommand cmd = new SqlCommand(query, SQLConnection);
                SQLConnection.Open();
                string FileFullPath = DestinationFolder + "\\" + FileNamePart + "_" + datetime + FileExtension;

               
                sw = new StreamWriter(FileFullPath, true);               
                using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                {
                    using (DataSet set = new DataSet())
                    {
                        adapter.Fill(set);
                        
                    }
                }
                sw.Close();
            }
            catch (Exception exception)
            {
                // Create Log File for Errors
                using (StreamWriter sw = File.CreateText(LogFolder
                    + "\\" + "ErrorLog_" + datetime + ".log"))
                {
                    sw.WriteLine(exception.ToString());

                }
            }
        }

        private static void OnInfoMessageGenerated(object sender, SqlInfoMessageEventArgs args)
        {
            Console.WriteLine("{0}", args.Message);

            sw.WriteLine(args.Message.ToString());
            sw.Write(sw.NewLine);
        }
        public static bool verifyDropDownValueFromGendoUI(IWebElement element, string value)
        {
            string idAttribute = element.GetAttribute("aria-owns");
            IList<IWebElement> list = Browser.Wd.FindElements(By.XPath("//ul[@id='" + idAttribute + "']/li"));

            bool present = true;
                for (int i = 0; i < list.Count; i++)
            {
                if (list[i].Text.ToUpper().Equals(value))
                {
                    present = false;
                    Console.WriteLine("drop down contains Value", value);
                }
            
            }
            return present;
        }


        public static void selectDropDownValueFromGendoUIWithoutAriaOwns(IWebElement element, string value)
        {
            fw.ExecuteJavascript(element);
            By drpValue = By.XPath("//div[@class='k-animation-container']//li[contains(.,'"+value+"')]");
            
            fw.ExecuteJavascript(Browser.Wd.FindElement(drpValue));
        }
        public static void selectDropDownValFromGendoUI(IWebElement element, string value)
        {
            
  
            By drpValue = By.XPath("//span[@role='listbox']/span//span[contains(., '" + value + "')]");
           
            fw.ExecuteJavascript(Browser.Wd.FindElement(drpValue));
        }
    
        public static string returnCurrentDateAndTime()
        {
           string datetime = DateTime.Now.ToString("M/d/yyyy");
            return datetime;
        }

        public static bool rowPresenceUsingLocators(string code, string source, string desc, string checkbox, string mapto)
        {
            string xpath = null;
            tmsWait.Hard(5);

            bool hasrow = false;
            int totalPagesIntheGrid = 0;


            totalPagesIntheGrid = ReUsableFunctions.getTotalPages();
            checkbox = "active";
           // string xpath1 = "//table[@role='presentation']//div[contains(.,'" + mmpstate + "')]//parent::td/following-sibling::td/div[contains(.,'" + planid + "')]//parent::td/following-sibling::td/div[contains(.,'" + pbp + "')]//parent::td/following-sibling::td/div[contains(.,'" + transactioncode + "')]//parent::td/following-sibling::td/div[contains(.,'" + transactionstatus + "')]";
            // xpath = "//table[@role='presentation']//td[contains(.,'" + mmpstate + "')]/following-sibling::td[contains(.,'" + planid + "')]/following-sibling::td[contains(.,'" + pbp + "')]/following-sibling::td[contains(.,'" + transactioncode + "')]/following-sibling::td[contains(.,'" + transactionstatus + "')]/following-sibling::td[contains(.,'" + trc + "')]/following-sibling::td[contains(.,'" + effectivedate + "')]/following-sibling::td[contains(.,'" + terminationdate + "')]";
            xpath = "//*[@role='presentation']//td[normalize-space(text())='"+code+"']/following-sibling::td[normalize-space(text())='"+source+"']/following-sibling::td[normalize-space(text())='"+desc+"']/following-sibling::td/input[@name='"+checkbox+"']/parent::td/following-sibling::td/div[contains(.,'"+mapto+"')]";

            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {

                    tmsWait.Hard(5);
                    hasrow = Browser.Wd.FindElement(By.XPath(xpath)).Displayed;
                    break;
                }
                catch
                {

                    //tmsWait.Hard(5);
                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);

                    tmsWait.Hard(5);
                }

            }
            return hasrow;
        }


        public static bool rowPresenceUsingLocators(string mmpstate,string planid ,string pbp,string transactioncode,string transactionstatus,string trc,string effectivedate ,string terminationdate )
        {
            string xpath = null;
            tmsWait.Hard(5);
            
            bool hasrow = false;
            int totalPagesIntheGrid = 0;
           

                totalPagesIntheGrid = ReUsableFunctions.getTotalPages();
           string xpath1 = "//table[@role='presentation']//div[contains(.,'" + mmpstate + "')]//parent::td/following-sibling::td/div[contains(.,'" + planid + "')]//parent::td/following-sibling::td/div[contains(.,'" + pbp + "')]//parent::td/following-sibling::td/div[contains(.,'" + transactioncode + "')]//parent::td/following-sibling::td/div[contains(.,'" + transactionstatus + "')]";
            xpath = "//table[@role='presentation']//td[contains(.,'" + mmpstate + "')]/following-sibling::td[contains(.,'" + planid + "')]/following-sibling::td[contains(.,'" + pbp + "')]/following-sibling::td[contains(.,'" + transactioncode + "')]/following-sibling::td[contains(.,'" + transactionstatus + "')]/following-sibling::td[contains(.,'" + trc + "')]/following-sibling::td[contains(.,'"+effectivedate+ "')]/following-sibling::td[contains(.,'"+terminationdate+"')]";


            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {

                    tmsWait.Hard(5);
                    hasrow = Browser.Wd.FindElement(By.XPath(xpath)).Displayed;
                    break;
                }
                catch
                {

                    //tmsWait.Hard(5);
                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);

                    tmsWait.Hard(5);
                }

            }
            return hasrow;
        }

            public static void elementPresenceUsingLocators(By loc)
        {
            try {
                fw.ScrollWindowToViewElement(Browser.Wd.FindElement(loc));
            bool presence = Browser.Wd.FindElement(loc).Displayed;
            Assert.IsTrue(presence, " Expected Element is displayed");
            }
            catch
            {
                Assert.Fail("Element is not present");
            }
        }
         public static void elementEnableUsingLocators(By loc)
        {
            try {
                fw.ScrollWindowToViewElement(Browser.Wd.FindElement(loc));
            bool presence = Browser.Wd.FindElement(loc).Enabled;
            Assert.IsTrue(!presence, " Expected Element is  enabled");
            }
            catch
            {
                Assert.Fail("Element is  enabled");
            }
        }
        public static void elementDisableUsingLocators(By loc)
        {
            try
            {
                fw.ScrollWindowToViewElement(Browser.Wd.FindElement(loc));
                bool presence = Browser.Wd.FindElement(loc).Enabled;
                Assert.IsTrue(presence, " Expected Element is  enabled");
            }
            catch
            {
                Assert.Fail("Element is  enabled");
            }
        }
        public static void elementNotPresenceUsingLocators(By loc)
        {
            try
            {
                bool presence = Browser.Wd.FindElement(loc).Displayed;
                Assert.IsFalse(presence, " Expected Element is displayed");
            }
            catch
            {
                Assert.IsTrue(true,"Element is not present");
            }
        }

        public static string returnTextUsingLocators(By loc)
        {
            return Browser.Wd.FindElement(loc).Text;
        }
        public static string returnTextUsingWebElement(IWebElement ele)
        {
            return ele.Text;
        }
        public static void elementPresenceUsingWebElement(IWebElement ele)
        {
            try
            {
                bool presence = ele.Displayed;
                Assert.IsTrue(presence, " Expected Element is not displayed");
            }
            catch
            {
                Assert.IsFalse(true);
            }

        }

        public static void elementisNotPresentUsingWebElement(IWebElement ele)
        {
            try
            {
                bool presence = ele.Displayed;
                Assert.IsFalse(presence, " Expected Element is displayed");
            }
            catch
            {
                Assert.IsTrue(true,"Element is not present");
            }

        }

     

        public static void setValueAttributeAfterScrollingInToComponent(IWebElement element,String value)
        {
           
            IJavaScriptExecutor js = Browser.Wd as IJavaScriptExecutor;
            js.ExecuteScript("arguments[0].scrollIntoView(true);", element);
            js.ExecuteScript("arguments[0].setAttribute('value','"+value+"')", element);
        }

    }

}

