﻿//using System;
//using Microsoft.VisualStudio.TestTools.UnitTesting;
//using System.Collections;
//using TechTalk.SpecFlow;
//using OpenQA.Selenium;
//using OpenQA.Selenium.Firefox;
//using OpenQA.Selenium.Support.UI;
//using System.Collections.Generic;
//using System.Diagnostics;
//using System.Windows;
//using System.Drawing;
//using System.Windows.Forms;

//namespace TMSoR1
//{

//    [Binding]
//    public class EAMTransactionsNewTrans
//    {
//        [When(@"Transactions New Disen Reason Glossary Icon is clicked")]
//        public void WhenTransactionsNewDisenReasonGlossaryIconIsClicked()
//        {
//            EAM.TransactionsNew.DisenReasonIcon.Click();
//            tmsWait.Hard(1);
//        }
//        [Then(@"Transactions New Disenrollment Reason PopUp Close Icon is clicked")]
//        public void ThenTransactionsNewDisenrollmentReasonPopUpCloseIconIsClicked()
//        {
//            EAM.TransactionsNew.DisenReasonTableClose.Click();
//            tmsWait.Hard(1);
//        }
//        [When(@"Transactions New Trans Trans Code is set to ""(.*)""")]
//        public void WhenTransactionsNewTransTransCodeIsSetTo(string p0)
//        {
//            tmsWait.Hard(1);
//            string GeneratedData = tmsCommon.GenerateData(p0);
//            SelectElement dropDownElement = new SelectElement(EAM.TransactionsNew.TransCode);
//            dropDownElement.SelectByText(GeneratedData);
//        }
        
//        [When(@"Transactions New Trans PlanID is set to ""(.*)""")]
//        public void WhenTransactionsNewTransPlanIDIsSetTo(string p0)
//        {
//            tmsWait.Hard(1);
//            string GeneratedData = tmsCommon.GenerateData(p0);
//            SelectElement dropDownElement = new SelectElement(EAM.TransactionsNew.PlanID);
//            dropDownElement.SelectByText(GeneratedData);
//        }

//        [Then(@"Verify Transactions New Trans Disen\.Reason field does not have value ""(.*)""")]
//        public void ThenVerifyTransactionsNewTransDisen_ReasonFieldDoesNotHaveValue(string p0)
//        {
//            tmsWait.Hard(1);
//            string fieldName = "Disen Reason";
//            string GeneratedData = tmsCommon.GenerateData(p0);
//            SelectElement dropDownElement = new SelectElement(EAM.TransactionsNew.DisenReason);
//            IList<IWebElement> dropDownOptions = dropDownElement.Options;
//            Boolean bFoundOptionInList = false;
//            string optionCollection = "";
//            foreach (IWebElement thisOption in dropDownOptions)
//            {
//                optionCollection += thisOption.Text + "  ";
//                if (thisOption.Text == GeneratedData)
//                {
//                    bFoundOptionInList = true;
//                }
//            }
//            if (bFoundOptionInList)
//            {
//                Assert.AreEqual(true, false, "Field " + fieldName + " expected to not find [" + GeneratedData + "], in option list [" + optionCollection + "]");
//                fw.ConsoleReport("Field " + fieldName + " expected to not find [" + GeneratedData + "], in option list [" + optionCollection + "]");
//            }
//            else
//            {
//                Assert.AreEqual(true, true, "Field " + fieldName + " expected to not find [" + GeneratedData + "], in option list [" + optionCollection + "]");
//                fw.ConsoleReport("Field " + fieldName + " expected to not find [" + GeneratedData + "], in option list [" + optionCollection + "]");
//            }
//        }

//        [Then(@"Verify Transactions New Trans Disen\.Reason field has value ""(.*)""")]
//        public void ThenVerifyTransactionsNewTransDisen_ReasonFieldHasValue(string p0)
//        {
//            tmsWait.Hard(1);
//            string fieldName = "Disen Reason";
//            string GeneratedData = tmsCommon.GenerateData(p0);
//            SelectElement dropDownElement = new SelectElement(EAM.TransactionsNew.DisenReason);
//            IList<IWebElement> dropDownOptions = dropDownElement.Options;
//            Boolean bFoundOptionInList = false;
//            string optionCollection = "";
//            foreach (IWebElement thisOption in dropDownOptions)
//            {
//                optionCollection += thisOption.Text + "  ";
//                if (thisOption.Text == GeneratedData)
//                {
//                    bFoundOptionInList = true;
//                }
//            }
//            if (bFoundOptionInList)
//            {
//                Assert.AreEqual(true, true, "Field " + fieldName + " expected to find [" + GeneratedData + "], in option list [" + optionCollection + "]");
//                fw.ConsoleReport("Field " + fieldName + " expected to find [" + GeneratedData + "], in option list [" + optionCollection + "]");
//            }
//            else
//            {
//                Assert.AreEqual(true, false, "Field " + fieldName + " expected to find [" + GeneratedData + "], in option list [" + optionCollection + "]");
//                fw.ConsoleReport("Field " + fieldName + " expected to find [" + GeneratedData + "], in option list [" + optionCollection + "]");
//            }
//        }


//        [Then(@"Verify Transactions New Disenrollment Reason PopUp does not have row")]
//        public void ThenVerifyTransactionsNewDisenrollmentReasonPopUpDoesNotHaveRow(Table table)
//        {
//            //Establish the next page link for flipping pages as necessary
//            Boolean bNotAtLastPageOfRecords = true;
//            Boolean bHaveGoodPageLink = true;
//            //Get the Table Header off of the test script Gherkin table
//            ICollection<string> thisTH = table.Header;
//            int thCount = thisTH.Count;
//            string[] thisHeader = new string[thisTH.Count];
//            thisTH.CopyTo(thisHeader, 0);   //copies the header to an array

//            //Set up an array of classes to hold the table data, first one (0) will be the header info
//            //The class has flags for this data row being a header, data and if we have yet matched it in our trials
//            TableRow[] thisTableArr = new TableRow[table.RowCount + 1];
//            thisTableArr[0] = new TableRow();
//            thisTableArr[0].RowIsHeader = true;
//            thisTableArr[0].RowIsData = false;
//            thisTableArr[0].RowIsMatched = false;
//            //Add the header data to the array 0 table row instance
//            foreach (string thisString in thisHeader)
//            {
//                thisTableArr[0].Row.Add(thisString);
//            }
//            int iCounter = 1;
//            //Add the Gherkin table row data to the array of rows.  These are all data, not headers, not matched yet.
//            foreach (var row in table.Rows)
//            {
//                thisTableArr[iCounter] = new TableRow();
//                thisTableArr[iCounter].RowIsHeader = false;
//                thisTableArr[iCounter].RowIsData = true;
//                thisTableArr[iCounter].RowIsMatched = false;

//                for (int c = 0; c < row.Count; c++)
//                {
//                    thisTableArr[iCounter].Row.Add(row[c]);
//                }
//                iCounter++;
//            }
//            //While we have not matched all rows yet
//            //and we are not on the last page of records..
//            while (thisTableArr[0].AllRowsMatched(thisTableArr) == false && bNotAtLastPageOfRecords)
//            {
//                bNotAtLastPageOfRecords = false;
//                //Get the table object again, since the page refreshes we need to get it fresh
//                IWebElement baseTable = EAM.TransactionsNew.DisenReasonTable;
//                ICollection<IWebElement> myRows = baseTable.FindElements(By.TagName("tr"));
//                int RowCount = myRows.Count;
//                //Establish an array of table rows for the page data.
//                TableRow[] thisDataArr = new TableRow[RowCount];
//                int EstablishedRowItemCount = 0;
//                int iRowCounter = 0;
//                IWebElement lastElementHolder = null;
//                foreach (IWebElement thisRow in myRows)
//                {
//                    //For each new data row we look at, add a new instance of the class to the array.
//                    thisDataArr[iRowCounter] = new TableRow();
//                    thisDataArr[iRowCounter].RowIsHeader = true;
//                    thisDataArr[iRowCounter].RowIsData = false;
//                    thisDataArr[iRowCounter].RowIsMatched = false;
//                    //Get all of the elements from the row (<td>)
//                    ICollection<IWebElement> myElements = null;
//                    if (iRowCounter == 0)
//                    {
//                        myElements = thisRow.FindElements(By.TagName("td"));
//                    }
//                    else
//                    {
//                        myElements = thisRow.FindElements(By.TagName("td"));
//                    }
//                    //Row 0 is the header
//                    //The rest of the rows are data
//                    int elementCount = 0;
//                    foreach (IWebElement thisElement in myElements)
//                    {
//                        elementCount++;
//                        lastElementHolder = thisElement;
//                        if (iRowCounter == -1)
//                        {
//                            //Finding the normal item count because the page numbers are a data row.
//                            //Row 0 is the header
//                            EstablishedRowItemCount = myElements.Count;
//                            thisDataArr[iRowCounter].RowIsHeader = true;
//                            thisDataArr[iRowCounter].RowIsData = false;
//                        }
//                        else
//                        {
//                            //Other rows are data
//                            thisDataArr[iRowCounter].RowIsHeader = false;
//                            thisDataArr[iRowCounter].RowIsData = true;
//                            thisDataArr[iRowCounter].Row.Add(thisElement.Text.ToString());
//                        }
//                    }
//                    iRowCounter++;
//                }
//                int iTableCounter = 0;
//                //for each row in the Gherkin table, start flipping through all the rows in the page data.
//                foreach (TableRow TTA in thisTableArr)
//                {
//                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.
//                    if (TTA.RowIsMatched == false)
//                    {
//                        //Convert the row to an array so we can do an element by element match.
//                        string[] ta = TTA.Row.ToArray();

//                        //For each row in the page data
//                        foreach (TableRow TDA in thisDataArr)
//                        {
//                            //Convert page data to array elements
//                            string[] td = TDA.Row.ToArray();
//                            int iElementCounter = 0;
//                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.
//                            foreach (string tde in td)
//                            {
//                                //if (iElementCounter > 0 && TDA.RowIsData)
//                                if (TDA.RowIsData)
//                                {
//                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
//                                    //                                    Console.WriteLine("["+ iElementCounter +"] Matching page data ["+ ta[iElementCounter] +"] with gherkin ["+ tde +"]");
//                                    if (tde != ta[iElementCounter] && ta[iElementCounter].ToLower() != "[skip]" && iElementCounter != 5)
//                                    {
//                                        bThisRowMatches = false;
//                                    }
//                                }
//                                else
//                                {
//                                    //Also fail row match if the element count of the page data row is 0
//                                    if (iElementCounter > 0)
//                                    {
//                                        bThisRowMatches = false;
//                                    }
//                                }
//                                iElementCounter++;
//                            }
//                            if (td.Length == 0)
//                            {
//                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
//                                bThisRowMatches = false;
//                            }
//                            //Instance of TableRow Class for reporting functions
//                            var TableRow = new TMSString();

//                            if (bThisRowMatches)
//                            {
//                                //Report the match, first convert the array back to a string we can read.
//                                thisTableArr[iTableCounter].RowIsMatched = true;
//                                string TR0 = TableRow.ArrayToString(td);
//                                string TR1 = TableRow.ArrayToString(ta);
//                                Console.WriteLine("Expected Row Data --- " + TR1);
//                                Console.WriteLine("Found Row Data --- " + TR0);

//                            }
//                        }
//                    }
//                    iTableCounter++;
//                }
//                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
//                Boolean fullMatching = thisTableArr[0].AllRowsMatched(thisTableArr);
//                if (fullMatching)
//                {
//                    Console.WriteLine("All rows are matched, step completed as passed");
//                }
//                baseTable = EAM.TransactionsNew.DisenReasonTable;

//                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
//                //Time to boil it down and report which rows didn't get matched.
//                //Also to fail because we were planning to match the rows.
//                if (!fullMatching)
//                {
//                    int iCount = 0;
//                    var TableRow = new TMSString();
//                    foreach (TableRow thisTR in thisTableArr)
//                    {
//                        if (thisTR.RowIsMatched == false && thisTR.RowIsHeader == false)
//                        {
//                            string thisRowData = TableRow.ArrayToString(thisTR.Row.ToArray());
//                            Console.WriteLine("Unmatched Data Row -- " + thisRowData);
//                        }
//                        iCount++;
//                    }
//                    Assert.AreEqual(true, true, "As expected, rows in the Gherkin test table were not found in the page table data rows.");
//                    Console.WriteLine( "As expected, rows in the Gherkin test table were not found in the page table data rows.");
//                }
//            }
//        }
          


//        [Then(@"Verify Transactions New Disenrollment Reason PopUp has row")]
//        public void ThenVerifyTransactionsNewDisenrollmentReasonPopUpHasRow(Table table)
//        {
//            //Establish the next page link for flipping pages as necessary
//            Boolean bNotAtLastPageOfRecords = true;
//            Boolean bHaveGoodPageLink = true;
//            //Get the Table Header off of the test script Gherkin table
//            ICollection<string> thisTH = table.Header;
//            int thCount = thisTH.Count;
//            string[] thisHeader = new string[thisTH.Count];
//            thisTH.CopyTo(thisHeader, 0);   //copies the header to an array

//            //Set up an array of classes to hold the table data, first one (0) will be the header info
//            //The class has flags for this data row being a header, data and if we have yet matched it in our trials
//            TableRow[] thisTableArr = new TableRow[table.RowCount + 1];
//            thisTableArr[0] = new TableRow();
//            thisTableArr[0].RowIsHeader = true;
//            thisTableArr[0].RowIsData = false;
//            thisTableArr[0].RowIsMatched = false;
//            //Add the header data to the array 0 table row instance
//            foreach (string thisString in thisHeader)
//            {
//                thisTableArr[0].Row.Add(thisString);
//            }
//            int iCounter = 1;
//            //Add the Gherkin table row data to the array of rows.  These are all data, not headers, not matched yet.
//            foreach (var row in table.Rows)
//            {
//                thisTableArr[iCounter] = new TableRow();
//                thisTableArr[iCounter].RowIsHeader = false;
//                thisTableArr[iCounter].RowIsData = true;
//                thisTableArr[iCounter].RowIsMatched = false;

//                for (int c = 0; c < row.Count; c++)
//                {
//                    thisTableArr[iCounter].Row.Add(row[c]);
//                }
//                iCounter++;
//            }
//            //While we have not matched all rows yet
//            //and we are not on the last page of records..
//            while (thisTableArr[0].AllRowsMatched(thisTableArr) == false && bNotAtLastPageOfRecords)
//            {
//                bNotAtLastPageOfRecords = false;
//                //Get the table object again, since the page refreshes we need to get it fresh
//                IWebElement baseTable = EAM.TransactionsNew.DisenReasonTable;
//                ICollection<IWebElement> myRows = baseTable.FindElements(By.TagName("tr"));
//                int RowCount = myRows.Count;
//                //Establish an array of table rows for the page data.
//                TableRow[] thisDataArr = new TableRow[RowCount];
//                int EstablishedRowItemCount = 0;
//                int iRowCounter = 0;
//                IWebElement lastElementHolder = null;
//                foreach (IWebElement thisRow in myRows)
//                {
//                    //For each new data row we look at, add a new instance of the class to the array.
//                    thisDataArr[iRowCounter] = new TableRow();
//                    thisDataArr[iRowCounter].RowIsHeader = true;
//                    thisDataArr[iRowCounter].RowIsData = false;
//                    thisDataArr[iRowCounter].RowIsMatched = false;
//                    //Get all of the elements from the row (<td>)
//                    ICollection<IWebElement> myElements = null;
//                    if (iRowCounter == 0)
//                    {
//                        myElements = thisRow.FindElements(By.TagName("td"));
//                    }
//                    else
//                    {
//                        myElements = thisRow.FindElements(By.TagName("td"));
//                    }
//                    //Row 0 is the header
//                    //The rest of the rows are data
//                    int elementCount = 0;
//                    foreach (IWebElement thisElement in myElements)
//                    {
//                        elementCount++;
//                        lastElementHolder = thisElement;
//                        if (iRowCounter == -1)
//                        {
//                            //Finding the normal item count because the page numbers are a data row.
//                            //Row 0 is the header
//                            EstablishedRowItemCount = myElements.Count;
//                            thisDataArr[iRowCounter].RowIsHeader = true;
//                            thisDataArr[iRowCounter].RowIsData = false;
//                        }
//                        else
//                        {
//                            //Other rows are data
//                            thisDataArr[iRowCounter].RowIsHeader = false;
//                            thisDataArr[iRowCounter].RowIsData = true;
//                            thisDataArr[iRowCounter].Row.Add(thisElement.Text.ToString());
//                        }
//                    }
//                    iRowCounter++;
//                }
//                int iTableCounter = 0;
//                //for each row in the Gherkin table, start flipping through all the rows in the page data.
//                foreach (TableRow TTA in thisTableArr)
//                {
//                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.
//                    if (TTA.RowIsMatched == false)
//                    {
//                        //Convert the row to an array so we can do an element by element match.
//                        string[] ta = TTA.Row.ToArray();

//                        //For each row in the page data
//                        foreach (TableRow TDA in thisDataArr)
//                        {
//                            //Convert page data to array elements
//                            string[] td = TDA.Row.ToArray();
//                            int iElementCounter = 0;
//                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.
//                            foreach (string tde in td)
//                            {
//                                //if (iElementCounter > 0 && TDA.RowIsData)
//                                if (TDA.RowIsData)
//                                {
//                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
//                                    //                                    Console.WriteLine("["+ iElementCounter +"] Matching page data ["+ ta[iElementCounter] +"] with gherkin ["+ tde +"]");
//                                    if (tde != ta[iElementCounter] && ta[iElementCounter].ToLower() != "[skip]" && iElementCounter != 5)
//                                    {
//                                        bThisRowMatches = false;
//                                    }
//                                }
//                                else
//                                {
//                                    //Also fail row match if the element count of the page data row is 0
//                                    if (iElementCounter > 0)
//                                    {
//                                        bThisRowMatches = false;
//                                    }
//                                }
//                                iElementCounter++;
//                            }
//                            if (td.Length == 0)
//                            {
//                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
//                                bThisRowMatches = false;
//                            }
//                            //Instance of TableRow Class for reporting functions
//                            var TableRow = new TMSString();

//                            if (bThisRowMatches)
//                            {
//                                //Report the match, first convert the array back to a string we can read.
//                                thisTableArr[iTableCounter].RowIsMatched = true;
//                                string TR0 = TableRow.ArrayToString(td);
//                                string TR1 = TableRow.ArrayToString(ta);
//                                Console.WriteLine("Expected Row Data --- " + TR1);
//                                Console.WriteLine("Found Row Data --- " + TR0);

//                            }
//                        }
//                    }
//                    iTableCounter++;
//                }
//                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
//                Boolean fullMatching = thisTableArr[0].AllRowsMatched(thisTableArr);
//                if (fullMatching)
//                {
//                    Console.WriteLine("All rows are matched, step completed as passed");
//                }
//                baseTable = EAM.TransactionsNew.DisenReasonTable;

//                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
//                //Time to boil it down and report which rows didn't get matched.
//                //Also to fail because we were planning to match the rows.
//                if (bHaveGoodPageLink == false && !fullMatching)
//                {
//                    int iCount = 0;
//                    var TableRow = new TMSString();
//                    foreach (TableRow thisTR in thisTableArr)
//                    {
//                        if (thisTR.RowIsMatched == false && thisTR.RowIsHeader == false)
//                        {
//                            string thisRowData = TableRow.ArrayToString(thisTR.Row.ToArray());
//                            Console.WriteLine("Unmatched Data Row -- " + thisRowData);
//                        }
//                        iCount++;
//                    }
//                    Assert.AreEqual(true, false, "Not all expected rows in the Gherkin test table were found in the page table data rows.");
//                }
//            }
//        }
//    }

//}