﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using TMSoR1.FrameworkCode;
using System.IO;
using System.Collections;

namespace TMSoR1
{
    [Binding]
    class fsFacetsConfigurations
    {
        string documentPath = Path.Combine(Environment.ExpandEnvironmentVariables("%userprofile%"), "My Documents");
        string downloadPath = Path.Combine(Environment.ExpandEnvironmentVariables("%userprofile%"), "Downloads");
        [Then(@"Verify Plan Defined Fields section Use Mapping Check box is checked")]
        public void ThenVerifyPlanDefinedFieldsSectionUseMappingCheckBoxIsChecked()
        {
            IWebElement check = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-chk-useMapping']"));

            string expStatus = check.GetAttribute("checked").ToString();
            Assert.AreEqual(expStatus, "true", " Check box is not checked");

        }
        [Then(@"Verify Plan Defined Fields section Use Mapping Check box is un checked")]
        public void ThenVerifyPlanDefinedFieldsSectionUseMappingCheckBoxIsUnChecked()
        {
            IWebElement check = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-chk-useMapping']"));

            string expStatus = check.Selected.ToString();
            Assert.AreEqual(expStatus, "False", " Check box is checked");
        }

        [When(@"Plan Defined Fields section Use Mapping Check box is ""(.*)"" and Clicked Save button")]
        public void WhenPlanDefinedFieldsSectionUseMappingCheckBoxIsAndClickedSaveButton(string p0)
        {
            By check = By.CssSelector("[test-id='planDefinedFields-chk-useMapping']");
            ReUsableFunctions.CheckBoxOperations(check, p0);

            IWebElement save = Browser.Wd.FindElement(By.CssSelector("[test-id='memberViewEdit-btn-save']"));
            fw.ExecuteJavascript(save);
            tmsWait.Hard(4);
        }


        [Then(@"Verify Plan Defined Fields section Use Mapping Check box is ""(.*)""")]
        public void ThenVerifyPlanDefinedFieldsSectionUseMappingCheckBoxIs(string action)
        {
            By check = By.CssSelector("[test-id='planDefinedFields-chk-useMapping']");
            ReUsableFunctions.CheckBoxOperations(check, action);
        }



        [Then(@"Verify Plan Defined Fields section Source displayed as ""(.*)""")]
        public void ThenVerifyPlanDefinedFieldsSectionSourceDisplayedAs(string exp)
        {
            IWebElement check = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-input-entrySource']"));
            string act = check.GetAttribute("value").ToString();
            Assert.AreEqual(exp, act, " Both values are not matching");


        }


        [Then(@"Verify SQL Query returns value as ""(.*)""")]
        public void ThenVerifySQLQueryReturnsValueAs(string p0)
        {
            string actValue = tmsCommon.GenerateData(p0);
            Assert.AreEqual("0", actValue, " Both values are not matching");
        }


        [Then(@"Verify Include in Mapping Fields Optional section displayed ""(.*)""")]
        public void ThenVerifyIncludeInMappingFieldsOptionalSectionDisplayed(string p0)
        {
            List<string> actList = p0.Split(',').ToList();
            List<string> expList = new List<string>();


            ArrayList actArrayList = new ArrayList();
            var webValues = new SelectElement(Browser.Wd.FindElement(By.Id("lbEamOptionalFields"))).Options;

            foreach (IWebElement temp in webValues)
            {
                expList.Add(temp.Text);
            }

            Console.WriteLine("Difference in the Drop Down List and DB value lists...");
            List<string> resultantList = new List<string>();
            IEnumerable<string> list3;
            list3 = actList.Except(expList);
            foreach (string value in list3)
            {
                resultantList.Add(value);
            }
            if (resultantList.Count > 0)
            {
                Assert.Fail(" Include in Mapping Filds Optional Section is not having expected values");
            }


        }


        [Then(@"Verify Member Manager Source Override table OverrideFlagStatus coulmn displayed value as ""(.*)""")]
        public void ThenVerifyMemberManagerSourceOverrideTableOverrideFlagStatusCoulmnDisplayedValueAs(string p0)
        {
            string actualRes = tmsCommon.GenerateData(p0);

            Assert.AreEqual("False", actualRes, " Both are not matching");

        }

        [Then(@"Plan Defined Fields section Use Mapping Check box is Un checked")]
        public void ThenPlanDefinedFieldsSectionUseMappingCheckBoxIsUnChecked()
        {
            IWebElement check = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-chk-useMapping']"));
            fw.ExecuteJavascript(check);
        }


        [Then(@"Verify Compare Enrolled Member Count ""(.*)"" with Member Manager Source Override count ""(.*)""")]
        public void ThenVerifyCompareEnrolledMemberCountWithMemberManagerSourceOverrideCount(string p0, string p1)
        {

            string res1 = tmsCommon.GenerateData(p0);
            string res2 = tmsCommon.GenerateData(p1);
            Assert.AreEqual(res1, res2, " Both counts are not matching");
        }
        [When(@"Add New Transaction page Core Eligibility Details section Use Mapping Check box is ""(.*)""")]
        public void WhenAddNewTransactionPageCoreEligibilityDetailsSectionUseMappingCheckBoxIs(string p0)
        {
            tmsWait.Hard(3);
            string checkStatus = tmsCommon.GenerateData(p0);

            IWebElement mapCheck = Browser.Wd.FindElement(By.CssSelector("[test-id='CoreEligibilityDetailsUseMapping']"));
            ReUsableFunctions.CheckBoxOperations(mapCheck, checkStatus);
        }

        [When(@"Add New Transaction page Optional Supplemental Benefits Information section Medical OSB check box is ""(.*)""")]
        public void WhenAddNewTransactionPageOptionalSupplementalBenefitsInformationSectionMedicalOSBCheckBoxIs(string p0)
        {
            tmsWait.Hard(3);
            string Status = tmsCommon.GenerateData(p0);

            IWebElement Check = Browser.Wd.FindElement(By.CssSelector("[test-id='OptionalSupplementalBenefitsOSBInformationMedicalOSB']"));
            ReUsableFunctions.CheckBoxOperations(Check, Status);
        }

        [When(@"Add New Transaction page Optional Supplemental Benefits Information section Dental OSB check box is ""(.*)""")]
        public void WhenAddNewTransactionPageOptionalSupplementalBenefitsInformationSectionDentalOSBCheckBoxIs(string p0)
        {
            tmsWait.Hard(3);
            string Status = tmsCommon.GenerateData(p0);

            IWebElement Check = Browser.Wd.FindElement(By.CssSelector("[test-id='OptionalSupplementalBenefitsOSBInformationDentalOSB']"));
            ReUsableFunctions.CheckBoxOperations(Check, Status);
        }

        [When(@"Add New Transaction page Optional Supplemental Benefits Information section Vision OSB check box is ""(.*)""")]
        public void WhenAddNewTransactionPageOptionalSupplementalBenefitsInformationSectionVisionOSBCheckBoxIs(string p0)
        {
            tmsWait.Hard(3);
            string Status = tmsCommon.GenerateData(p0);

            IWebElement Check = Browser.Wd.FindElement(By.CssSelector("[test-id='OptionalSupplementalBenefitsOSBInformationVisionOSB']"));
            ReUsableFunctions.CheckBoxOperations(Check, Status);
        }

        [When(@"Add New Transaction page Optional Supplemental Benefits Information section Other OSB check box is ""(.*)""")]
        public void WhenAddNewTransactionPageOptionalSupplementalBenefitsInformationSectionOtherOSBCheckBoxIs(string p0)
        {
            tmsWait.Hard(3);
            string Status = tmsCommon.GenerateData(p0);

            IWebElement Check = Browser.Wd.FindElement(By.CssSelector("[test-id='OptionalSupplementalBenefitsOSBInformationOtherOSB']"));
            ReUsableFunctions.CheckBoxOperations(Check, Status);
        }

        [When(@"Rule Mapping page ""(.*)"" drop down is set to ""(.*)""")]
        public void WhenRuleMappingPageDropDownIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(2);
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);

            switch (field)
            {
                case "Plan ID":
                    ReUsableFunctions.selectDropDownValueUsingContainsTextAngularChanges(Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='manageRules-select-ddlPlanId']//span[@class='k-select']")), value);
                    
                    break;
                case "PBP ID":
                    ReUsableFunctions.selectDropDownValueUsingContainsTextAngularChanges(Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='manageRules-select-ddlPbpId']//span[@class='k-select']")), value);
                    break;
                case "Status":
                    ReUsableFunctions.selectDropDownValueUsingContainsTextAngularChanges(Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='manageRules-select-ddlStatus']//span[@class='k-select']")), value);
                    break;
                default:
                    Assert.Fail(" Please provide correct field value");
                    break;
            }
        }




        [When(@"Configure Eligible Transactions page TC as ""(.*)"" Passed BEQ check box is ""(.*)"" Accepted by CMS check box is ""(.*)""")]
        public void WhenConfigureEligibleTransactionsPageTCAsPassedBEQCheckBoxIsAcceptedByCMSCheckBoxIs(string p0, string p1, string p2)
        {
            string TC = tmsCommon.GenerateData(p0);
            string PassedBEQStatus = tmsCommon.GenerateData(p1);
            string acceptedbycmsSatus = tmsCommon.GenerateData(p2);

            IWebElement passCheck = Browser.Wd.FindElement(By.XPath("//kendo-grid-list[@role='presentation']//td[contains(.,'" + TC + "')]/following-sibling::td/input[@name='isPassedBEQ']"));
            IWebElement acceptedCheck = Browser.Wd.FindElement(By.XPath("//kendo-grid-list[@role='presentation']//td[contains(.,'" + TC + "')]/following-sibling::td//input[@name='isAcceptedByCMS']"));
            ReUsableFunctions.CheckBoxOperations(passCheck, PassedBEQStatus);
            ReUsableFunctions.CheckBoxOperations(acceptedCheck, acceptedbycmsSatus);

        }

        [Then(@"Master Configuration page Save button is Clicked Successfully")]
        public void ThenMasterConfigurationPageSaveButtonIsClickedSuccessfully()
        {
            IWebElement left = Browser.Wd.FindElement(By.CssSelector("[test-id='masterRule-btn-save']"));
            fw.ExecuteJavascript(left);
            tmsWait.Hard(2);
        }

        [Then(@"Verify System displayed Confirmation dialog with message as ""(.*)""")]
        public void ThenVerifySystemDisplayedConfirmationDialogWithMessageAs(string p0)
        {
            try
            {
                UIMODUtilFunctions.clickOnConfirmationYesDialog();
                tmsWait.Hard(2);
                string actMsg = Browser.Wd.FindElement(By.XPath("//span[@ng-bind-html='message']")).Text;
                string expMsg = tmsCommon.GenerateData(p0);

                Assert.AreEqual(expMsg, actMsg, " Both are not matching");
            }
            catch
            {
                fw.ConsoleReport(" There is no confirmation dialog");
            }



        }

        [Then(@"Master Configuration page Reset button is Clicked")]
        public void ThenMasterConfigurationPageResetButtonIsClicked()
        {
            IWebElement reset = Browser.Wd.FindElement(By.CssSelector("[test-id='masterRule-btn-reset']"));
            fw.ExecuteJavascript(reset);
            tmsWait.Hard(2);
        }

        [When(@"I refresh the Browser page")]
        public void WhenIRefreshTheBrowserPage()
        {
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(15);
        }



        [Then(@"Master Configuration page Save button is Clicked")]
        public void ThenMasterConfigurationPageSaveButtonIsClicked()
        {
            tmsWait.Hard(5);
            IWebElement left = Browser.Wd.FindElement(By.CssSelector("[test-id='masterRule-btn-save']"));
            fw.ScrollWindowToViewElement(left);
            fw.ExecuteJavascript(left);

            tmsWait.Hard(5);
            try
            {
                UIMODUtilFunctions.clickOnConfirmationYesDialog();
            }
            catch
            { fw.ConsoleReport(" there is no dialog");
            }


            fw.RefreshUsingJavascript();
            tmsWait.Hard(20);
        }

        [When(@"Rules Mapping page Upload Rules Link is Clicked")]
        public void WhenRulesMappingPageUploadRulesLinkIsClicked()
        {
            tmsWait.Hard(5);
            IWebElement left = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Upload Rules')]"));
            fw.ExecuteJavascript(left);
            tmsWait.Hard(5);
        }

        [When(@"Rules Mapping page Manage Rules Link is Clicked")]
        public void WhenRulesMappingPageManageRulesLinkIsClicked()
        {
            IWebElement left = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Manage Rules')]"));
            fw.ExecuteJavascript(left);
            tmsWait.Hard(5);
        }


        [Then(@"Verify Add Rule page Eligible EAM Fields ""(.*)"" Fields are disabled")]
        public void ThenVerifyAddRulePageEligibleEAMFieldsFieldsAreDisabled(string p0)
        {

            string field = tmsCommon.GenerateData(p0);
            bool Value = false;
            IWebElement drp;
            bool res;
            switch (field)
            {

                case "Segment ID":
                    drp = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@id='ddlSegmentId']//span[@class='k-select']"));
                    res = drp.Selected;
                    Assert.IsFalse(res, " Segment Id Dropdown not disabled");
                    break;

                case "SCC":
                    drp = Browser.Wd.FindElement(By.XPath("//kendo-combobox[@id='ddlSscId']//span[@class='k-select']"));
                    res = drp.Selected;
                    Assert.IsFalse(res, " SCC is not disabled");
                    break;
            }

        }
        [When(@"Add Rule page Eligible EAM Fields ""(.*)"" is set to ""(.*)""")]
        public void WhenAddRulePageEligibleEAMFieldsIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            IWebElement drppbp;
            IWebElement elementpbp;
            switch (field)
            {
                case "Plan ID":

                    UIMODUtilFunctions.selectPlanID(value);

                    break;
                case "PBP ID":
                    UIMODUtilFunctions.selectPBPID(value);
                    break;
                case "Segment ID":
                    UIMODUtilFunctions.selectSegmentID(value);
                    break;
                case "SCC":
                    Browser.Wd.FindElement(By.CssSelector("[id='txtScc']")).SendKeys(value);
                    Browser.Wd.FindElement(By.CssSelector("[id='txtScc']")).SendKeys(Keys.Tab);
                    break;
                case "LIS Level":
                    drppbp = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='ddlLisLevel_listbox']"));
                    fw.ExecuteJavascript(drppbp);

                    tmsWait.Hard(2);
                    elementpbp = Browser.Wd.FindElement(By.XPath("//ul[@id='ddlLisLevel_listbox']/li[contains(.,'" + value + "')]"));
                    fw.ExecuteJavascript(elementpbp);
                    break;
                case "LIS Copay category":
                    drppbp = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='ddlLisCopayCategory_listbox']"));
                    fw.ExecuteJavascript(drppbp);

                    tmsWait.Hard(2);
                    elementpbp = Browser.Wd.FindElement(By.XPath("//ul[@id='ddlLisCopayCategory_listbox']/li[contains(.,'" + value + "')]"));
                    fw.ExecuteJavascript(elementpbp);
                    break;



            }
        }


        [Then(@"Verify Rules Mapping page Uload Rules Link is Displayed")]
        public void ThenVerifyRulesMappingPageUloadRulesLinkIsDisplayed()
        {
            By ele = By.CssSelector("[test-id='configuration-li-ruleFileUpload']");
            UIMODUtilFunctions.elementPresenceUsingLocators(ele);
        }

        [Then(@"Verify Facets Configuration menu displayed sub menu ""(.*)""")]
        public void ThenVerifyFacetsConfigurationMenuDisplayedSubMenu(string p0)
        {
            By ele = By.CssSelector("[title='" + p0 + "']");
            UIMODUtilFunctions.elementPresenceUsingLocators(ele);
        }
        [Then(@"Verify Admin menu displayed sub menu ""(.*)""")]
        public void ThenVerifyAdminMenuDisplayedSubMenu(string p0)
        {
            By ele = By.XPath("//span[contains(.,'" + p0 + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(ele);
        }


        [When(@"Click on EAM Fields section Include in Mapping Tool tip verify message as ""(.*)""")]
        public void WhenClickOnEAMFieldsSectionIncludeInMappingToolTipVerifyMessageAs(string p0)
        {
            By loc = By.XPath("//label[@test-id='masterLevel-lbl-optinalEamMapping']/i");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);

            By ele = By.XPath("//label[@test-id='masterLevel-lbl-optinalEamMapping']/i[contains(@uib-tooltip,'" + p0 + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(ele);
        }
        [When(@"Click on Facets Fields section Include in Mapping Tool tip verify message as ""(.*)""")]
        public void WhenClickOnFacetsFieldsSectionIncludeInMappingToolTipVerifyMessageAs(string p0)
        {
            By loc = By.XPath("//label[@test-id='masterLevel-lbl-optinalEamMapping']/i");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);

            By ele = By.XPath("//label[@test-id='masterLevel-lbl-optinalEamMapping']/i[contains(@uib-tooltip,'" + p0 + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(ele);
        }

        [When(@"Click on Facets Fields section Exclude in Mapping Tool tip verify message as ""(.*)""")]
        public void WhenClickOnFacetsFieldsSectionExcludeInMappingToolTipVerifyMessageAs(string p0)
        {
            By loc = By.XPath("//label[@test-id=masterLevel-lbl-excludeFacetMapping']/i");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);

            By ele = By.XPath("//label[@test-id='masterLevel-lbl-excludeFacetMapping']/i[contains(@uib-tooltip,'" + p0 + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(ele);
        }


        [When(@"Click on EAM Fields section Exclude in Mapping Tool tip verify message as ""(.*)""")]
        public void WhenClickOnEAMFieldsSectionExcludeInMappingToolTipVerifyMessageAs(string p0)
        {
            By loc = By.XPath("//label[@test-id='masterLevel-lbl-excludeEamMapping']/i");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);

            By ele = By.XPath("//label[@test-id='masterLevel-lbl-excludeEamMapping']/i[contains(@uib-tooltip,'" + p0 + "')] ");
            UIMODUtilFunctions.elementPresenceUsingLocators(ele);
        }


        [Then(@"Verify Rules Mapping page Manage Rules Link is Displayed")]
        public void ThenVerifyRulesMappingPageManageRulesLinkIsDisplayed()
        {
            By ele = By.XPath("//span[contains(.,'Manage Rules')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(ele);
        }

        [Then(@"Verify Upload Rules section Select File button is displayed")]
        public void ThenVerifyUploadRulesSectionSelectFileButtonIsDisplayed()
        {

            By ele = By.XPath("//div[@role='button']");
            UIMODUtilFunctions.elementPresenceUsingLocators(ele);
        }

        [Then(@"Verify Upload Rules section Upload button is displayed")]
        public void ThenVerifyUploadRulesSectionUploadButtonIsDisplayed()
        {

            By ele = By.CssSelector("[id='btnUploadFiles']");
            UIMODUtilFunctions.elementPresenceUsingLocators(ele);
        }

        [Then(@"Verify File Processing Summary section is displayed")]
        public void ThenVerifyFileProcessingSummarySectionIsDisplayed()
        {
            By ele = By.XPath("//label[contains(.,'File Processing Summary')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(ele);
        }

        [Then(@"Verify File Processing Summary section Refresh button is displayed")]
        public void ThenVerifyFileProcessingSummarySectionRefreshButtonIsDisplayed()
        {
            By ele = By.CssSelector("[id='btnRefresh']");
            UIMODUtilFunctions.elementPresenceUsingLocators(ele);
        }

        [Then(@"Verify File Processing Summary section File Name Column is displayed")]
        public void ThenVerifyFileProcessingSummarySectionFileNameColumnIsDisplayed()
        {
            By ele = By.XPath("//kendo-grid[@test-id='ruleUploadFile-grid']//th[contains(.,'File Name')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(ele);
        }

        [Then(@"Verify File Processing Summary section Total Records Column is displayed")]
        public void ThenVerifyFileProcessingSummarySectionTotalRecordsColumnIsDisplayed()
        {
            By ele = By.XPath("//kendo-grid[@test-id='ruleUploadFile-grid']//th[contains(.,'Total Records')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(ele);
        }

        [Then(@"Verify File Processing Summary section User Column is displayed")]
        public void ThenVerifyFileProcessingSummarySectionUserColumnIsDisplayed()
        {
            By ele = By.XPath("//kendo-grid[@test-id='ruleUploadFile-grid']//th[contains(.,'User')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(ele);
        }

        [Then(@"Verify File Processing Summary section Date Column is displayed")]
        public void ThenVerifyFileProcessingSummarySectionDateColumnIsDisplayed()
        {
            By ele = By.XPath("//kendo-grid[@test-id='ruleUploadFile-grid']//th[contains(.,'Date')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(ele);
        }


        [Then(@"Verify Manage Rules section Plan ID drop down list is displayed")]
        public void ThenVerifyManageRulesSectionPlanIDDropDownListIsDisplayed()
        {
            By ele = By.XPath("//kendo-dropdownlist[@id='ddlPlanId']//span[@class='k-select']");
            UIMODUtilFunctions.elementPresenceUsingLocators(ele);
        }

        [Then(@"Verify Manage Rules section PBP ID drop down list is displayed")]
        public void ThenVerifyManageRulesSectionPBPIDDropDownListIsDisplayed()
        {
            By ele = By.XPath("//kendo-dropdownlist[@id='ddlPbpId']//span[@class='k-select']");
            UIMODUtilFunctions.elementPresenceUsingLocators(ele);
        }

        [Then(@"Verify Manage Rules section Min Effective Date drop down list is displayed")]
        public void ThenVerifyManageRulesSectionMinEffectiveDateDropDownListIsDisplayed()
        {
            By ele = By.XPath("//kendo-datepicker[@test-id='manageRules-date-dtEffDate']//span/input");
            UIMODUtilFunctions.elementPresenceUsingLocators(ele);
        }

        [Then(@"Verify Manage Rules section Max Effective Date drop down list is displayed")]
        public void ThenVerifyManageRulesSectionMaxEffectiveDateDropDownListIsDisplayed()
        {
            By ele = By.XPath("//kendo-datepicker[@test-id='manageRules-date-dtEndDate']//span/input");
            UIMODUtilFunctions.elementPresenceUsingLocators(ele);
        }

        [Then(@"Verify Manage Rules section Status drop down list is displayed")]
        public void ThenVerifyManageRulesSectionStatusDropDownListIsDisplayed()
        {
            By ele = By.XPath("//kendo-dropdownlist[@id='ddlStatus']//span[@class='k-select']");
            UIMODUtilFunctions.elementPresenceUsingLocators(ele);
        }

        [Then(@"Verify Manage Rules section Export button is displayed")]
        public void ThenVerifyManageRulesSectionExportButtonIsDisplayed()
        {
            By ele = By.CssSelector("[test-id='manageRules-btn-export']");
            UIMODUtilFunctions.elementPresenceUsingLocators(ele);
        }

        [Then(@"Verify Manage Rules section Reset button is displayed")]
        public void ThenVerifyManageRulesSectionResetButtonIsDisplayed()
        {
            By ele = By.CssSelector("[test-id='manageRules-btn-reset']");
            UIMODUtilFunctions.elementPresenceUsingLocators(ele);
        }

        [Then(@"Verify Manage Rules section Search button is displayed")]
        public void ThenVerifyManageRulesSectionSearchButtonIsDisplayed()
        {
            By ele = By.CssSelector("[test-id='manageRules-btn-search']");
            UIMODUtilFunctions.elementPresenceUsingLocators(ele);
        }

        [Then(@"Verify Manage Rules section Deactivate Rules button is displayed")]
        public void ThenVerifyManageRulesSectionDeactivateRulesButtonIsDisplayed()
        {
            By ele = By.CssSelector("[test-id='manageRules-btn-deleteRules']");
            UIMODUtilFunctions.elementPresenceUsingLocators(ele);
        }

        [Then(@"Verify Manage Rules section ""(.*)"" column is displayed")]
        public void ThenVerifyManageRulesSectionColumnIsDisplayed(string p0)
        {
            By ele = By.XPath("//kendo-grid[@test-id='facetsRules-grid-grdFacetsRules']//th[contains(.,'" + p0 + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(ele);
        }

        [Then(@"Verify Manage Rules section ""(.*)"" column is displayed successfully")]
        public void ThenVerifyManageRulesSectionColumnIsDisplayedSuccessfully(string p0)
        {
            tmsWait.Hard(2);
            By ele = By.CssSelector("[data-field='" + p0 + "']");
            fw.ScrollWindowToViewElement(Browser.Wd.FindElement(ele));
            UIMODUtilFunctions.elementPresenceUsingLocators(ele);
        }


        [When(@"Add Rule page Eligible Facets Fields ""(.*)"" is set to ""(.*)""")]
        public void WhenAddRulePageEligibleFacetsFieldsIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);

            switch (field)
            {
                case "Group":

                    Browser.Wd.FindElement(By.CssSelector("[aria-owns='txtGroup_listbox']")).SendKeys(value);
                    Browser.Wd.FindElement(By.CssSelector("[aria-owns='txtGroup_listbox']")).SendKeys(Keys.Tab);

                    break;
                case "Sub Group":
                    Browser.Wd.FindElement(By.CssSelector("[aria-owns='txtSubgroup_listbox']")).SendKeys(value);
                    Browser.Wd.FindElement(By.CssSelector("[aria-owns='txtSubgroup_listbox']")).SendKeys(Keys.Tab);
                    break;
                case "Class":
                    Browser.Wd.FindElement(By.CssSelector("[aria-owns='txtClass_listbox']")).SendKeys(value);
                    Browser.Wd.FindElement(By.CssSelector("[aria-owns='txtClass_listbox']")).SendKeys(Keys.Tab);
                    break;
                case "Product ID Vision":
                    Browser.Wd.FindElement(By.CssSelector("[aria-owns='txtProductIdVision_listbox']")).SendKeys(value);
                    Browser.Wd.FindElement(By.CssSelector("[aria-owns='txtProductIdVision_listbox']")).SendKeys(Keys.Tab);
                    break;
                case "Product ID Dental":
                    Browser.Wd.FindElement(By.CssSelector("[aria-owns='txtProductIdDental_listbox']")).SendKeys(value);
                    Browser.Wd.FindElement(By.CssSelector("[aria-owns='txtProductIdDental_listbox']")).SendKeys(Keys.Tab);
                    break;
                case "Product ID Medical":
                    Browser.Wd.FindElement(By.CssSelector("[aria-owns='txtProductIdMedical_listbox']")).SendKeys(value);
                    Browser.Wd.FindElement(By.CssSelector("[aria-owns='txtProductIdMedical_listbox']")).SendKeys(Keys.Tab);
                    break;
                case "Product ID Pharmacy":
                    Browser.Wd.FindElement(By.CssSelector("[aria-owns='txtProductIdPharmacy_listbox']")).SendKeys(value);
                    Browser.Wd.FindElement(By.CssSelector("[aria-owns='txtProductIdPharmacy_listbox']")).SendKeys(Keys.Tab);
                    break;
                case "Min Eff Date":
                    Browser.Wd.FindElement(By.CssSelector("[aria-owns='txtEffectiveDate_dateview']")).SendKeys(value);
                    Browser.Wd.FindElement(By.CssSelector("[aria-owns='txtEffectiveDate_dateview']")).SendKeys(Keys.Tab);
                    break;
                case "Max Eff Date":
                    Browser.Wd.FindElement(By.CssSelector("[aria-owns='txtEndDate_dateview']")).SendKeys(value);
                    Browser.Wd.FindElement(By.CssSelector("[aria-owns='txtEndDate_dateview']")).SendKeys(Keys.Tab);
                    break;
            }

        }

        [When(@"Eligible EAM Fields ""(.*)"" checkbox is ""(.*)""")]
        public void WhenEligibleEAMFieldsCheckboxIs(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string checkboxStatus = tmsCommon.GenerateData(p1);
            IWebElement ele;
            switch (field)
            {
                case "OSB Dental":
                    ele = Browser.Wd.FindElement(By.CssSelector("[test-id='addEditFacetsRule-chk-OsbDental']"));
                    ReUsableFunctions.CheckBoxOperations(ele, checkboxStatus);
                    break;
                case "OSB Vision":
                    ele = Browser.Wd.FindElement(By.CssSelector("[test-id='addEditFacetsRule-chk-osbVision']"));
                    ReUsableFunctions.CheckBoxOperations(ele, checkboxStatus);
                    break;
                case "OSB Medical":
                    ele = Browser.Wd.FindElement(By.CssSelector("[test-id='addEditFacetsRule-chk-osbMedical']"));
                    ReUsableFunctions.CheckBoxOperations(ele, checkboxStatus);
                    break;
                case "OSB Other":
                    ele = Browser.Wd.FindElement(By.CssSelector("[test-id='addEditFacetsRule-chk-osbOther']"));
                    ReUsableFunctions.CheckBoxOperations(ele, checkboxStatus);
                    break;

            }

        }


        [When(@"Add Rule page ADD button is Clicked")]
        public void WhenAddRulePageADDButtonIsClicked()
        {
            IWebElement add = Browser.Wd.FindElement(By.CssSelector("[test-id='addEditFacetsRule-btn-add']"));
            fw.ExecuteJavascript(add);
        }


        [When(@"Rules Mapping page Click on Add Rule Button is Clicked")]
        public void WhenRulesMappingPageClickOnAddRuleButtonIsClicked()
        {
            IWebElement btn = Browser.Wd.FindElement(By.CssSelector("[test-id='manageRules-btn-addRule']"));
            fw.ExecuteJavascript(btn);
            tmsWait.Hard(2);
        }

        [When(@"EAM Manage Rules link Status drop down list is set to ""(.*)""")]
        public void WhenEAMManageRulesLinkStatusDropDownListIsSetTo(string p0)
        {
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='manageRules-select-ddlStatus']//span[@class='k-select']"));
            string value = tmsCommon.GenerateData(p0);
            AngularFunction.selectDropDownValue(ele, value);
                       

        }

        [When(@"EAM Manage Rules link Search Button is Clicked")]
        public void WhenEAMManageRulesLinkSearchButtonIsClicked()
        {
            IWebElement left = Browser.Wd.FindElement(By.CssSelector("[test-id='manageRules-btn-search']"));
            fw.ExecuteJavascript(left);
            tmsWait.Hard(5);

        }

        [Then(@"Verify Maping Rules grid displayed ""(.*)"" Plan count as ""(.*)""")]
        public void ThenVerifyMapingRulesGridDisplayedPlanCountAs(string PlanID, int expecedCount)
        {
            tmsWait.Hard(5);
            IWebElement page = Browser.Wd.FindElement(By.XPath("//span[@class='k-pager-input k-label']"));
            int pagecount = Convert.ToInt32((page.Text.Split(' '))[1]);
            int navigationCount = 1;
            int count = 0;
            bool elementFound = false;
            bool alreadyNavivate = false;
            IWebElement next = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));


            while (pagecount >= navigationCount)
            {
                try
                {
                    IWebElement element = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='facetsRules-grid-grdFacetsRules']//td[contains(.,'" + PlanID + "')]"));
                    IList<IWebElement> elements = Browser.Wd.FindElements(By.XPath("//kendo-grid[@test-id='facetsRules-grid-grdFacetsRules']//td[contains(.,'" + PlanID + "')]"));
                    count = count + elements.Count;
                    elementFound = true;
                    fw.ExecuteJavascript(next);
                    tmsWait.Hard(5);
                    navigationCount++;
                    alreadyNavivate = true;
                }
                catch
                {
                    try
                    {
                        if (!alreadyNavivate)
                        {
                            fw.ExecuteJavascript(next);
                            tmsWait.Hard(5);
                            navigationCount++;
                        }
                        
                        IWebElement element = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='facetsRules-grid-grdFacetsRules']//td[contains(.,'" + PlanID + "')]"));
                        IList<IWebElement> elements = Browser.Wd.FindElements(By.XPath("//kendo-grid[@test-id='facetsRules-grid-grdFacetsRules']//td[contains(.,'" + PlanID + "')]"));
                        count = count + elements.Count;
                        elementFound = true;
                    }
                    catch
                    {
                        if(elementFound)
                        {
                            navigationCount++;
                            fw.ConsoleReport(" Element has Found already ");
                        }
                        else
                        {
                            navigationCount++;
                            elementFound = false;
                        }
                        
                    }
                }
               
            }




            if (elementFound)
            {
                Assert.AreEqual(expecedCount,count," Both counts are not matching");
            }
            else
            {
                                Assert.AreEqual(count, expecedCount, " Both counts are not matching");
            }

            tmsWait.Hard(5);

        }


        [Then(@"Verify Rules Mapping page Plan ID as ""(.*)"" PBP ID as ""(.*)"" Segment ID as ""(.*)"" SCC as ""(.*)"" LIS Level as ""(.*)"" LIS Copay Category as ""(.*)"" OSB Dental as ""(.*)"" OSB Vision as ""(.*)"" OSB Medical as ""(.*)"" OSB Other as ""(.*)"" Group as ""(.*)"" Sub Group as ""(.*)"" Class as ""(.*)"" Product ID Dental as ""(.*)"" Product ID Vision as ""(.*)"" Product ID Medical as ""(.*)"" Product ID Pharmacy as ""(.*)""")]
        public void ThenVerifyRulesMappingPagePlanIDAsPBPIDAsSegmentIDAsSCCAsLISLevelAsLISCopayCategoryAsOSBDentalAsOSBVisionAsOSBMedicalAsOSBOtherAsGroupAsSubGroupAsClassAsProductIDDentalAsProductIDVisionAsProductIDMedicalAsProductIDPharmacyAs(string p0, string p1, string p2, string p3, string p4, string p5, string p6, string p7, string p8, string p9, string p10, string p11, string p12, string p13, string p14, string p15, string p16)
        {
            By loc = By.XPath("//kendo-grid[@test-id='facetsRules-grid-grdFacetsRules']//td[contains(.,'" + p0+"')]/following-sibling::td[contains(.,'"+p1+"')]/following-sibling::td[contains(.,'"+p2+"')]/following-sibling::td[contains(.,'"+p3+"')]/following-sibling::td[contains(.,'"+p4+"')]/following-sibling::td[contains(.,'"+p5+"')]/following-sibling::td[contains(.,'"+p6+"')]/following-sibling::td[contains(.,'"+p7+"')]/following-sibling::td[contains(.,'"+p8+"')]/following-sibling::td[contains(.,'"+p9+"')]/following-sibling::td[contains(.,'"+p10+"')]/following-sibling::td[contains(.,'"+p11+"')]/following-sibling::td[contains(.,'"+p12+"')]/following-sibling::td[contains(.,'"+p13+"')]/following-sibling::td[contains(.,'"+p14+"')]/following-sibling::td[contains(.,'"+p15+"')]/following-sibling::td[contains(.,'"+p16+"')]");
            try
            {
                UIMODUtilFunctions.elementPresenceUsingLocators(loc);
            }
            catch
            {
                int totalPagesIntheGrid = ReUsableFunctions.getTotalPages();
                for (int i = 1; i <= totalPagesIntheGrid; i++)
                {
                    try
                    {
                        UIMODUtilFunctions.elementPresenceUsingLocators(loc);
                        break;
                    }
                    catch
                    {

                        IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                        ReUsableFunctions.clickOnWebElement(nextpage);
                    }
                }
            }

        }

        [Then(@"Verify Rules Mapping page Plan ID as ""(.*)"" PBP ID as ""(.*)"" Segment ID as ""(.*)"" SCC as ""(.*)"" LIS Level as ""(.*)"" LIS Copay Category as ""(.*)"" OSB Dental as ""(.*)"" OSB Vision as ""(.*)"" OSB Medical as ""(.*)"" OSB Other as ""(.*)"" Group as ""(.*)"" Sub Group as ""(.*)"" Class as ""(.*)"" Product ID Dental as ""(.*)"" Product ID Vision as ""(.*)"" Product ID Medical as ""(.*)"" Product ID Pharmacy as ""(.*)"" row is not present")]
        public void ThenVerifyRulesMappingPagePlanIDAsPBPIDAsSegmentIDAsSCCAsLISLevelAsLISCopayCategoryAsOSBDentalAsOSBVisionAsOSBMedicalAsOSBOtherAsGroupAsSubGroupAsClassAsProductIDDentalAsProductIDVisionAsProductIDMedicalAsProductIDPharmacyAsRowIsNotPresent(string p0, string p1, string p2, string p3, string p4, string p5, string p6, string p7, string p8, string p9, string p10, string p11, string p12, string p13, string p14, string p15, string p16)
        {

        By loc = By.XPath("//div[@test-id='facetsRules-grid-grdFacetsRules']//td[contains(.,'" + p0 + "')]/following-sibling::td[contains(.,'" + p1 + "')]/following-sibling::td[contains(.,'" + p2 + "')]/following-sibling::td[contains(.,'" + p3 + "')]/following-sibling::td[contains(.,'" + p4 + "')]/following-sibling::td[contains(.,'" + p5 + "')]/following-sibling::td[contains(.,'" + p6 + "')]/following-sibling::td[contains(.,'" + p7 + "')]/following-sibling::td[contains(.,'" + p8 + "')]/following-sibling::td[contains(.,'" + p9 + "')]/following-sibling::td[contains(.,'" + p10 + "')]/following-sibling::td[contains(.,'" + p11 + "')]/following-sibling::td[contains(.,'" + p12 + "')]/following-sibling::td[contains(.,'" + p13 + "')]/following-sibling::td[contains(.,'" + p14 + "')]/following-sibling::td[contains(.,'" + p15 + "')]/following-sibling::td[contains(.,'" + p16 + "')]");
            UIMODUtilFunctions.elementNotPresenceUsingLocators(loc);
        }


        [Then(@"Verify the Rules Mapping page Plan ID as ""(.*)"" PBP ID as ""(.*)"" Segment ID as ""(.*)"" SCC as ""(.*)"" LIS Level as ""(.*)"" LIS Copay Category as ""(.*)"" OSB Dental as ""(.*)"" OSB Vision as ""(.*)"" OSB Medical as ""(.*)"" OSB Other as ""(.*)"" Group as ""(.*)"" Sub Group as ""(.*)"" Class as ""(.*)"" Product ID Dental as ""(.*)"" Product ID Vision as ""(.*)"" Product ID Medical as ""(.*)"" Product ID Pharmacy as ""(.*)"" Min as ""(.*)"" Max as ""(.*)""")]
        public void ThenVerifyTheRulesMappingPagePlanIDAsPBPIDAsSegmentIDAsSCCAsLISLevelAsLISCopayCategoryAsOSBDentalAsOSBVisionAsOSBMedicalAsOSBOtherAsGroupAsSubGroupAsClassAsProductIDDentalAsProductIDVisionAsProductIDMedicalAsProductIDPharmacyAsMinAsMaxAs(string p0, string p1, string p2, string p3, string p4, string p5, string p6, string p7, string p8, string p9, string p10, string p11, string p12, string p13, string p14, string p15, string p16, string p17, string p18)
        {
            try
            {
                By loc = By.XPath("//div[@test-id='facetsRules-grid-grdFacetsRules']//td[contains(.,'" + p0 + "')]/following-sibling::td[contains(.,'" + p1 + "')]/following-sibling::td[contains(.,'" + p2 + "')]/following-sibling::td[contains(.,'" + p3 + "')]/following-sibling::td[contains(.,'" + p4 + "')]/following-sibling::td[contains(.,'" + p5 + "')]/following-sibling::td[contains(.,'" + p6 + "')]/following-sibling::td[contains(.,'" + p7 + "')]/following-sibling::td[contains(.,'" + p8 + "')]/following-sibling::td[contains(.,'" + p9 + "')]/following-sibling::td[contains(.,'" + p10 + "')]/following-sibling::td[contains(.,'" + p11 + "')]/following-sibling::td[contains(.,'" + p12 + "')]/following-sibling::td[contains(.,'" + p13 + "')]/following-sibling::td[contains(.,'" + p14 + "')]/following-sibling::td[contains(.,'" + p15 + "')]/following-sibling::td[contains(.,'" + p16 + "')]/following-sibling::td[contains(.,'" + p17 + "')]/following-sibling::td[contains(.,'" + p18 + "')]");
                fw.ScrollWindowToViewElement(Browser.Wd.FindElement(loc));
                UIMODUtilFunctions.elementPresenceUsingLocators(loc);
            }
            catch
            {
                IWebElement left = Browser.Wd.FindElement(By.XPath("(//a[@aria-label='Go to the next page'])[2]"));
                fw.ExecuteJavascript(left);
                tmsWait.Hard(2);

                try
                {
                    By loc = By.XPath("//div[@test-id='facetsRules-grid-grdFacetsRules']//td[contains(.,'" + p0 + "')]/following-sibling::td[contains(.,'" + p1 + "')]/following-sibling::td[contains(.,'" + p2 + "')]/following-sibling::td[contains(.,'" + p3 + "')]/following-sibling::td[contains(.,'" + p4 + "')]/following-sibling::td[contains(.,'" + p5 + "')]/following-sibling::td[contains(.,'" + p6 + "')]/following-sibling::td[contains(.,'" + p7 + "')]/following-sibling::td[contains(.,'" + p8 + "')]/following-sibling::td[contains(.,'" + p9 + "')]/following-sibling::td[contains(.,'" + p10 + "')]/following-sibling::td[contains(.,'" + p11 + "')]/following-sibling::td[contains(.,'" + p12 + "')]/following-sibling::td[contains(.,'" + p13 + "')]/following-sibling::td[contains(.,'" + p14 + "')]/following-sibling::td[contains(.,'" + p15 + "')]/following-sibling::td[contains(.,'" + p16 + "')]/following-sibling::td[contains(.,'" + p17 + "')]/following-sibling::td[contains(.,'" + p18 + "')]");
                    fw.ScrollWindowToViewElement(Browser.Wd.FindElement(loc));
                    UIMODUtilFunctions.elementPresenceUsingLocators(loc);
                }
                catch
                {
                    Assert.Fail(" Your expected value is not found");
                }
            }
        }

        [When(@"I Clicked on Next Page link")]
        public void WhenIClickedOnNextPageLink()
        {
            IWebElement left = Browser.Wd.FindElement(By.XPath("(//a[@aria-label='Go to the next page'])[2]"));
            fw.ExecuteJavascript(left);
            tmsWait.Hard(2);
        }

        IWebElement allCheck;
        [When(@"Mapping Rules table Select all rules check box and Click on Deactive Rules button")]
        public void WhenMappingRulesTableSelectAllRulesCheckBoxAndClickOnDeactiveRulesButton()
        {
           
            try
            {
                 allCheck = Browser.Wd.FindElement(By.XPath("//input[@id='checkAll']"));
                fw.ExecuteJavascript(allCheck);
                tmsWait.Hard(1);
                IWebElement deactivate = Browser.Wd.FindElement(By.CssSelector("[test-id='manageRules-btn-deleteRules']"));
                fw.ExecuteJavascript(deactivate);

                UIMODUtilFunctions.clickOnConfirmationYesDialog();
            }
            catch
            {
                fw.ConsoleReport(" there is no record");
            }
           
            fw.ExecuteJavascript(allCheck);

        }

        [When(@"Mapping Rules table Select Some rules check box and Click on Deactive Rules button")]
        public void WhenMappingRulesTableSelectSomeRulesCheckBoxAndClickOnDeactiveRulesButton()
        {

            IList<IWebElement> allcheckbox = Browser.Wd.FindElements(By.XPath("//input[@id='checkAll']"));
         
            int i = 0;
            foreach(IWebElement temp in allcheckbox)
            {
                if (i < 3)
                {
                    i++;
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//input[@id='checkAll'])[" + i+"]")));
                }

            }

            tmsWait.Hard(1);
            IWebElement deactivate = Browser.Wd.FindElement(By.CssSelector("[test-id='manageRules-btn-deleteRules']"));
            fw.ExecuteJavascript(deactivate);

            UIMODUtilFunctions.clickOnConfirmationYesDialog();
        }

        string actualStatus;
        [When(@"Rules Mapping Page Upload Rules section File Processing Summary File Name ""(.*)"" is set to ""(.*)""")]
        public void WhenRulesMappingPageUploadRulesSectionFileProcessingSummaryFileNameIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(5);
            string fileupload = tmsCommon.GenerateData(p0);

                   
            By xpath = By.XPath("//kendo-grid-list[@role='presentation']//td[contains(.,'" + fileupload + "')]/following-sibling::td[1]/div");
            IWebElement refresh = Browser.Wd.FindElement(By.Id("btnRefresh"));

            tmsWait.Hard(5);  // As scripts is failing on file processing page, used below statement
            int count = 0;
            while (count < 6)
            {
                try
                {
                    fw.ConsoleReport(" Clicking on Refresh button -- Count "+ count);
                    fw.ExecuteJavascript(refresh);
                    tmsWait.Hard(15);
                }
                catch
                {
                    fw.ConsoleReport(" Clicking on Refresh button -- Count " + count);
                    fw.ExecuteJavascript(refresh);
                    tmsWait.Hard(15);
                }
                count++;
            }
            

           
            try
            {
                actualStatus = Browser.Wd.FindElement(xpath).Text.ToString();

                fw.ConsoleReport(" Current Status"+actualStatus);
            }
            catch
            {
                fw.ConsoleReport(" Clicking on Refresh button for Third Time - Catch Block");
                fw.ExecuteJavascript(refresh);
                tmsWait.Hard(5);

                actualStatus = Browser.Wd.FindElement(xpath).Text.ToString();
                tmsWait.Hard(6);
                fw.ConsoleReport(" Current Status - Catch Block" + actualStatus);
            }
            int ReturnStatus = StatusValidation(actualStatus);
            fw.ConsoleReport(" Clicking on Refresh button for Fourth Time");
            fw.ExecuteJavascript(refresh);
            tmsWait.Hard(15);
            while (ReturnStatus != 0)
            {
                fw.ConsoleReport(" Clicking on Refresh button for Fifth Time");
                fw.ExecuteJavascript(refresh);
                tmsWait.Hard(15);
                actualStatus = Browser.Wd.FindElement(xpath).Text.ToString();
                ReturnStatus = StatusValidation(actualStatus);
                         
                tmsWait.Hard(20);

            }




        }



        public int StatusValidation(string actualStatus)
        {
            if (actualStatus.Equals("Pending"))
            {
                tmsWait.Hard(2);
                return 1;
            }
            else if (actualStatus.Equals("Executing"))
            {
                return 1;
            }
            else if (actualStatus.Equals("In-progress"))
            {
                return 1;
            }

            else if (actualStatus.Equals("Failed"))
            {
                Assert.Fail(" Job Processing is failed");
                return 0;
            }
            else if (actualStatus.Equals("Completed"))
            {

                return 0;
            }

            return 0;
        }

        [When(@"Rules Mapping Page Upload Rules section File Processing Summary File Name as ""(.*)""  Total Records as ""(.*)"" Fallout Records as ""(.*)""")]
        public void WhenRulesMappingPageUploadRulesSectionFileProcessingSummaryFileNameAsTotalRecordsAsFalloutRecordsAs(string p0, string p1, string p2)
        {
            tmsWait.Hard(5);
            string fileupload = tmsCommon.GenerateData(p0);
            string totalrecords = tmsCommon.GenerateData(p1);
            string falloutrecords = tmsCommon.GenerateData(p2);

            By xpath = By.XPath("//kendo-grid-list[@role='presentation']//td[contains(.,'" + fileupload + "')]/following-sibling::td[@aria-colindex='3'][contains(.,'" + totalrecords + "')]/following-sibling::td[@aria-colindex='4'][contains(.,'" + falloutrecords + "')]");
            bool results = Browser.Wd.FindElement(xpath).Displayed;

            Assert.IsTrue(results, " Facet Rules Records files are not processed");
        }

        [When(@"Verify Fallout report File ""(.*)"" is Clicked")]
        public void WhenVerifyFalloutReportFileIsClicked(string p0)
        {
            ReUsableFunctions.deleteFilesFromDownloadFolder();
            string fileName = tmsCommon.GenerateData(p0);

            tmsWait.Hard(5);
            IWebElement fileLink = Browser.Wd.FindElement(By.XPath("//kendo-grid-list[@role='presentation']//td[contains(.,'" + fileName + "')]/following-sibling::td/a"));
            fw.ExecuteJavascript(fileLink);
            tmsWait.Hard(5);
        }

        [Then(@"Verify Fallout report File ""(.*)"" has reason as ""(.*)""")]
        public void ThenVerifyFalloutReportFileHasReasonAs(string p0, string p1)
        {
            string fileName = tmsCommon.GenerateData(p0);
            string fileContent = tmsCommon.GenerateData(p1);            

            tmsWait.Hard(5);    //Wait for download, save and reading purpose
          
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.csv");

            var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
            string fileReadedContent = File.ReadAllText(srcFile);
            bool valueFoundonFile = false;
           
            if(fileReadedContent.Contains(fileContent))
            {
                valueFoundonFile = true;
            }
            else
            {
                valueFoundonFile = false;
            }

            Assert.IsTrue(valueFoundonFile, " Expected Value are not present on File");
        }


        [When(@"Rules Mapping Page Upload Rules section File Processing Summary File Name as ""(.*)"" Click on Fall out file and Verify file contains ""(.*)"" rules with ""(.*)"" Plan ID")]
        public void WhenRulesMappingPageUploadRulesSectionFileProcessingSummaryFileNameAsClickOnFallOutFileAndVerifyFileContainsRulesWithPlanID(string p0, string p1, string p2)
        {
            tmsWait.Hard(5);
            string fileupload = tmsCommon.GenerateData(p0);

            ReUsableFunctions.deleteFilesFromDownloadFolder();

            By xpath = By.XPath("//kendo-grid[@test-id='ruleUploadFile-grid']//td[contains(.,'" + fileupload + "')]/following-sibling::td/a");
            tmsWait.Hard(5);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(xpath);


            string expRuleCount = tmsCommon.GenerateData(p1);
            string PlanID = tmsCommon.GenerateData(p2);

            tmsWait.Hard(5);    //Wait for download, save and reading purpose
            var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.csv");

            var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            int filerecordCount = 0;
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
                var values = line.Split(',');
                if (count > 1)
                {
                    if (line.Contains(PlanID))
                    {
                        filerecordCount++;

                    }

                }
            }
            reader.Close();

            Assert.AreEqual(expRuleCount, filerecordCount.ToString(), " Both counts are not matching");
            ReUsableFunctions.deleteFilesFromDownloadFolder();

        }




        [Then(@"Execute Rules Button is Clicked")]
        public void ThenExecuteRulesButtonIsClicked()
        {
            try
            {
                IWebElement execute = Browser.Wd.FindElement(By.CssSelector("[test-id='executeRules-btn-execute']"));
                fw.ExecuteJavascript(execute);
                UIMODUtilFunctions.clickOnConfirmationYesDialog();
            }
            catch
            {
                fw.ConsoleReport(" There is no rules to execute");

            }
        }
        [When(@"Framework Application Jobs section Filter by Job Drop down is set to ""(.*)""")]
        public void WhenFrameworkApplicationJobsSectionFilterByJobDropDownIsSetTo(string value)
        {
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='jobs-select-filteredbyjob']"));
            ReUsableFunctions.selectValueFromDropDown(ele, value);
        }

        [Then(@"Verify Job Description as ""(.*)"" is set to Status as ""(.*)""")]
        public void ThenVerifyJobDescriptionAsIsSetToStatusAs(string p0, string p1)
        {
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(20);
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(20);
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(20);

            By loc = By.XPath("//div[@test-id='jobs-grid-grdJobsDetails']//td[contains(.,'" + p0 + "')]/following-sibling::td[contains(.,'" + p1 + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);

        }

        [When(@"Configure Eligible Fields Add Facets Fields ""(.*)"" Include in Mandatory Fields")]
        public void WhenConfigureEligibleFieldsAddFacetsFieldsIncludeInMandatoryFields(string p0)
        {
            try
            {
                IWebElement fields = Browser.Wd.FindElement(By.XPath("//select[@id='lbFacetOptionalFields']"));
                new SelectElement(fields).SelectByText(p0);
                //fw.ExecuteJavascript(fields);
                tmsWait.Hard(2);
                IWebElement right = Browser.Wd.FindElement(By.CssSelector("[test-id='masterLevel-btn-transferFacetField-right']"));
                fw.ExecuteJavascript(right);

            }
            catch
            {
                fw.ConsoleReport(p0+" Fields are already in Facets Fields Mandatory section");
            }
        }


        [When(@"Configure Eligible Fields Add Facets Fields ""(.*)"" Include in Mapping Fields Optional")]
        public void WhenConfigureEligibleFieldsAddFacetsFieldsIncludeInMappingFieldsOptional(string p0)
        {
            try
            {
                IWebElement fields = Browser.Wd.FindElement(By.Id("lbFacetMandatoryFields"));
                new SelectElement(fields).SelectByText(p0);
                //fw.ExecuteJavascript(fields);
                tmsWait.Hard(2);
                IWebElement left = Browser.Wd.FindElement(By.CssSelector("[test-id='masterLevel-btn-transferFacetField-left']"));
                fw.ExecuteJavascript(left);

            }
            catch
            {
                fw.ConsoleReport(p0+" Fields are Already in Facets Fields Optional section");
            }
        }

        [Then(@"Verify Configure Eligible Fields EAM Fields displayed ""(.*)"" Include in Mapping Fields Optional")]
        public void ThenVerifyConfigureEligibleFieldsEAMFieldsDisplayedIncludeInMappingFieldsOptional(string p0)
        {
            try
            {
                IWebElement fields = Browser.Wd.FindElement(By.XPath("//select[@id='lbEamOptionalFields']"));
                new SelectElement(fields).SelectByText(p0);               

            }
            catch
            {
                Assert.Fail(p0+" Fields are not listed on EAM Fields");
            }
        }

        [When(@"Plan Defined Fields Section ""(.*)"" Drop down is set to ""(.*)""")]
        public void WhenPlanDefinedFieldsSectionDropDownIsSetTo(string p0, string p1)
        {
            string drpType = tmsCommon.GenerateData(p0);
            string Value = tmsCommon.GenerateData(p1);
            string actValue = tmsCommon.GenerateData(p1);
            IWebElement dropdownEle = null;
           

            switch (drpType)
            {
                case "Group":
                    dropdownEle = Browser.Wd.FindElement(By.CssSelector("[aria-owns='group_listbox']"));
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(dropdownEle, Value);
                    break;
                case "Sub Group":
                    dropdownEle = Browser.Wd.FindElement(By.CssSelector("[aria-owns='subGroup_listbox']"));
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(dropdownEle, Value);
                    break;
                case "Class":
                    dropdownEle = Browser.Wd.FindElement(By.CssSelector("[aria-owns='class_listbox']"));
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(dropdownEle, Value);
                    break;
            }
            }

       

        [Then(@"Verify Member View Edit page Plan Defined Fields Section ""(.*)"" Drop down is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditPagePlanDefinedFieldsSectionDropDownIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(3);
            string drpType = tmsCommon.GenerateData(p0);
            string expValue = tmsCommon.GenerateData(p1);
            string actValue = null;
            IWebElement expectedElement = null;
            bool valuePresence = false;

            switch (drpType)
            {
                case "Group":
                    actValue = Browser.Wd.FindElement(By.CssSelector("[aria-owns='group_listbox']")).Text;
                    ReUsableFunctions.CompareTwoStrings(expValue, actValue);
                    break;
                case "Sub Group":
                    actValue = Browser.Wd.FindElement(By.CssSelector("[aria-owns='subGroup_listbox']")).Text;
                    ReUsableFunctions.CompareTwoStrings(expValue, actValue);
                    break;
                case "Class":
                    actValue = Browser.Wd.FindElement(By.CssSelector("[aria-owns='class_listbox']")).Text;
                    ReUsableFunctions.CompareTwoStrings(expValue, actValue);
                    break;
                case "Medical ID":
                    actValue = Browser.Wd.FindElement(By.CssSelector("[aria-owns='medicalProductId_listbox']")).Text;
                    ReUsableFunctions.CompareTwoStrings(expValue, actValue);
                    break;
                case "Pharmacy ID":
                    actValue = Browser.Wd.FindElement(By.CssSelector("[aria-owns='pharmacyId_listbox']")).Text;
                    ReUsableFunctions.CompareTwoStrings(expValue, actValue);
                    break;
                case "Dental ID":
                    actValue = Browser.Wd.FindElement(By.CssSelector("[aria-owns='dentalId_listbox']")).Text;
                    ReUsableFunctions.CompareTwoStrings(expValue, actValue);
                    break;
                case "Vision ID":
                    actValue = Browser.Wd.FindElement(By.CssSelector("[aria-owns='visionId_listbox']")).Text;
                    ReUsableFunctions.CompareTwoStrings(expValue, actValue);
                    break;
            }

        }


        [When(@"Configure Eligible Fields Add EAM Fields ""(.*)"" Include in Mapping Fields Optional")]
        public void WhenConfigureEligibleFieldsAddEAMFieldsIncludeInMappingFieldsOptional(string p0)
        {
            try
            {
                IWebElement fields = Browser.Wd.FindElement(By.Id("lbEamExcludedFields"));
                new SelectElement(fields).SelectByText(p0);
                //fw.ExecuteJavascript(fields);
                tmsWait.Hard(2);
                IWebElement left = Browser.Wd.FindElement(By.CssSelector("[test-id='masterLevel-btn-transferEamField-left']"));
                fw.ExecuteJavascript(left);

            }
            catch
            {
                fw.ConsoleReport(p0+" ---> Fields are Already in EAM Fields Optional section");
            }
        }


        [When(@"Configure Eligible Fields Add EAM Fields ""(.*)"" Exclude in Mapping Fields")]
        public void WhenConfigureEligibleFieldsAddEAMFieldsExcludeInMappingFields(string p0)
        {
            try
            {
                IWebElement fields = Browser.Wd.FindElement(By.XPath("//select[@id='lbEamOptionalFields']"));
                new SelectElement(fields).SelectByText(p0);
                //fw.ExecuteJavascript(fields);
                tmsWait.Hard(2);
                IWebElement left = Browser.Wd.FindElement(By.CssSelector("[test-id='masterLevel-btn-transferEamField-right']"));
                fw.ExecuteJavascript(left);

            }
            catch
            {
                fw.ConsoleReport(p0+" --> Fields are Already in EAM Fields Exclude section");
            }
        }

        [When(@"EAM EGWP Configuration ""(.*)"" button is clicked")]
        public void GivenEAMEGWPConfigurationButtonIsClicked(string p0)
        {
            string fieldname = tmsCommon.GenerateData(p0);

            switch (fieldname.ToLower())
            {
                case "addegwp": fw.ExecuteJavascript(EAM.EGWPConfiguration.ADDEGWPButton); tmsWait.Hard(2); break;
                case "saveegwpadd": fw.ExecuteJavascript(EAM.EGWPConfiguration.ADDSaveEGWPButton); break;
            }

        }

      


        [When(@"EAM EGWP Configuration Add ""(.*)"" is set to ""(.*)""")]
        public void GivenEAMEGWPConfigurationAddIsSetTo(string p0, string p1)
        {
            string fieldname= tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (fieldname.ToLower())
            {
                case "employer number": EAM.EGWPConfiguration.ADDEmployerGroupNumber.SendKeys(value); tmsWait.Hard(2); break;
                case "employer name": EAM.EGWPConfiguration.ADDEmployerGroupName.SendKeys(value); tmsWait.Hard(2); break;
                case "start date": AngularFunction.enterDate(EAM.EGWPConfiguration.ADDEmployerStartDate,value); tmsWait.Hard(2); break;
                case "end date": AngularFunction.enterDate(EAM.EGWPConfiguration.ADDEmployeeEndDate,value); tmsWait.Hard(2); break;
            }
        }


        [When(@"EAM EGWP Association ""(.*)"" button is clicked")]
        public void GivenEAMEGWPAssociationButtonIsClicked(string p0)
        {
            string fieldname = tmsCommon.GenerateData(p0);
            switch (fieldname.ToLower())
            {
                case "associate egwp add": fw.ExecuteJavascript(EAM.EGWPConfiguration.AssociateEGWPButton); tmsWait.Hard(2); break;
                case "associate egwp save": fw.ExecuteJavascript(EAM.EGWPConfiguration.AddAssociateEGWPButton); tmsWait.Hard(2); break;
                case "back to record": fw.ExecuteJavascript(EAM.EGWPConfiguration.AssociateEGWPBackToRecord); tmsWait.Hard(2); break;
            }
            tmsWait.Hard(3);
        }

        [When(@"EAM EGWP Association Add ""(.*)"" is set to ""(.*)""")]
        public void GivenEAMEGWPAssociationAddIsSetTo(string p0, string p1)
        {
            string fieldname = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (fieldname.ToLower())
            {
                case "employer group id":
                    By Drp = By.XPath("//kendo-dropdownlist[@test-id='addEgwpAssociation-select-ddlEmployerGroupId']//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + value + "']");
                    fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                    fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp)); break;
                case "saveegwpadd": break;
            }
        }


        [When(@"EAM EGWP Association checkbox for PlanId ""(.*)"" and PBP ""(.*)"" and SegmentId ""(.*)"" is clicked")]
        public void WhenEAMEGWPAssociationCheckboxForPlanIdAndPBPAndSegmentIdIsClicked(string p0, string p1, string p2)
        {
            string planid = tmsCommon.GenerateData(p0);
            string pbpid =  tmsCommon.GenerateData(p1.ToString());
            string segid = tmsCommon.GenerateData(p2.ToString());
            string tpage = Browser.Wd.FindElement(By.XPath("(//kendo-pager-input/span)[2]")).Text;
            string[] tsplitpage = tpage.Split("of");
            int totalPagesIntheGrid = Int32.Parse(tsplitpage[1].Trim());
            bool hasrow;
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {

                    tmsWait.Hard(3);
                    hasrow = Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='egwpAssociation-Grid'])[2]//td[contains(.,'"+planid+"')]/following-sibling::td[contains(.,'"+pbpid+"')]/following-sibling::td[contains(.,'"+segid+"')]/parent::tr/child::td/input")).Displayed;
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='egwpAssociation-Grid'])[2]//td[contains(.,'" + planid + "')]/following-sibling::td[contains(.,'" + pbpid + "')]/following-sibling::td[contains(.,'" + segid + "')]/parent::tr/child::td/input")));
                    tmsWait.Hard(1);
                    break;
                }
                catch
                {

                    //tmsWait.Hard(5);
                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("(//a[@title='Go to the next page'])[2]"));
                    ReUsableFunctions.clickOnWebElement(nextpage);

                    tmsWait.Hard(5);
                }

            }
        }
   



        //[Given(@"EAM EGWP Association checkbox for PlanId ""(.*)"" and PBP ""(.*)"" is clicked")]
        //public void GivenEAMEGWPAssociationCheckboxForPlanIdAndPBPIsClicked(string p0, int p1)
        //{
        //    string planid = tmsCommon.GenerateData(p0);
        //    string pbpid = tmsCommon.GenerateData(p1.ToString());
        //    string tpage = Browser.Wd.FindElement(By.XPath("(//kendo-numerictextbox[@class='k-widget k-numerictextbox'])[2]")).Text;
        //    string[] tsplitpage = tpage.Split("of");
        //    int totalPagesIntheGrid = Int32.Parse(tsplitpage[1].Trim());
        //    for (int i = 1; i <= totalPagesIntheGrid; i++)
        //    {
        //        try
        //        {

        //            tmsWait.Hard(5);
        //            hasrow = Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='egwpAssociation-Grid'])[2]//td[contains(.,'H1002')]/following-sibling::td[contains(.,'009')]/following-sibling::td[contains(.,'001')]/parent::tr/child::td/input")).Displayed;
        //            break;
        //        }
        //        catch
        //        {

        //            //tmsWait.Hard(5);
        //            IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
        //            ReUsableFunctions.clickOnWebElement(nextpage);

        //            tmsWait.Hard(5);
        //        }

        //    }
        //}


    }
}

