﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.EAM
{
    [Binding]
    public class fsTenantConfiguration
    {
        [Given(@"Tenant Configuration page Tenant is selected as ""(.*)""")]
        public void GivenTenantConfigurationPageTenantIsSelectedAs(string p0)
        {
            string tenant = tmsCommon.GenerateData(p0);
            SelectElement tenantDD = new SelectElement(TmsFramework.TenantConfiguration.TenantDropdown);
            tenantDD.SelectByText(tenant);
        }

        [Given(@"Tenant Configuration page Application is selected as ""(.*)""")]
        public void GivenTenantConfigurationPageApplicationIsSelectedAs(string p0)
        {
            string application = tmsCommon.GenerateData(p0);
            SelectElement applicationtDD = new SelectElement(TmsFramework.TenantConfiguration.ApplicationDropdown);
            applicationtDD.SelectByText(application);
        }

        [Given(@"Tenant Configuration page Application is added")]
        public void GivenTenantConfigurationPageApplicationIsAdded()
        {
            fw.ExecuteJavascript(TmsFramework.TenantConfiguration.AddButton);
            tmsWait.Hard(10);
        }

        [Given(@"Tenant Configuration page Edit button is clicked for DB ""(.*)""")]
        public void GivenTenantConfigurationPageEditButtonIsClickedForDB(string p0)
        {
            string db = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + db + "')]/parent::td/following-sibling::td//a[contains(@class,'Edit')]")));
        }

        [Given(@"Application Detail page Application DB is selected as ""(.*)""")]
        public void GivenApplicationDetailPageApplicationDBIsSelectedAs(string p0)
        {
            string db = tmsCommon.GenerateData(p0);
            SelectElement appDD = new SelectElement(TmsFramework.TenantConfiguration.ApplicationDBDropdown);
            appDD.SelectByText(db);
        }

        [Given(@"Application Detail page Save button is clicked")]
        public void GivenApplicationDetailPageSaveButtonIsClicked()
        {
            fw.ExecuteJavascript(TmsFramework.TenantConfiguration.SaveButton);
        }

    }
}
