﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.TMSFrameworkUIMode
{
    [Binding]
    class cfTMSFrameworkNavigation
    {
        [When(@"I have navigated to TMSFramework ""(.*)""")]
        public void WhenIHaveNavigatedToTMSFramework(string menu)
        {
            tmsWait.Hard(5);
            IWebElement link = null;
            if (menu == "Internal Databases" || menu == "Tenant Configuration")
            {
                fw.ExecuteJavascript(TmsFramework.TMSFrameworkHomepage.TenantAdminmenu);
                tmsWait.Hard(3);
            }

            link = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + menu + "')]"));
            fw.ExecuteJavascript(link);
            tmsWait.Hard(5);
        }


        [Then(@"Verify TMSFramework ""(.*)"" page is displayed")]
        public void ThenVerifyTMSFrameworkPageIsDisplayed(string page)
        {
            string VerifyTitle = page.ToString();
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//div[contains(.,'" + VerifyTitle + "')]"));
            AngularFunction.elementPresenceUsingWebElement(ele);
        }

        [Then(@"Framework will be closed")]
        [When(@"Framework will be closed")]
        public void ThenFrameworkWillBeClosed()
        {
            //Browser.Wd.Close();
            //Browser.CloseWebDriver();
        }

        [When(@"I am logging out from TMSFramework")]
        [Given(@"I am logging out from TMSFramework")]
        [Then(@"I am logging out from TMSFramework")]

        public void WhenIAmLoggingOutFromTMSFramework()
        {
            fw.ExecuteJavascript(TmsFramework.TMSFrameworkHomepage.UserProfile);
            tmsWait.Hard(2);
            Browser.Wd.Manage().Cookies.DeleteAllCookies();
            fw.ExecuteJavascript(TmsFramework.TMSFrameworkHomepage.Logout);
        }

        [When(@"I have navigated to Framework ""(.*)""")]
        public void WhenIHaveNavigatedToFramework(string menu)
        {

            tmsWait.Hard(5);
            IWebElement link = null;
            switch (menu)
            {
                case "Root Administration":
                    fw.ExecuteJavascript(TmsFramework.TMSFrameworkHomepage.RoottAdminmenu);
                    tmsWait.Hard(3);
                    break;
                case "External Systems":
                    link = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + menu + "')]"));
                    fw.ExecuteJavascript(link);
                    tmsWait.Hard(5);
                    break;

                case "Workflow Engine":
                    link = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + menu + "')]"));
                    fw.ExecuteJavascript(link);
                    tmsWait.Hard(5);
                    break;

                case "Tenant Set-up":
                    link = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + menu + "')]"));
                    fw.ExecuteJavascript(link);
                    tmsWait.Hard(5);
                    break;


            }

            }

       


    }
}
