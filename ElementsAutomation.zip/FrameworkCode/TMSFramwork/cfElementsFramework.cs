﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;
using TechTalk.SpecFlow;

namespace TMSoR1
{
    class cfElementsFramework
    {
        public static DBVersions DBVersions { get { return new DBVersions(); } }
        public static FrameworkAdministration FrameworkAdministration { get { return new FrameworkAdministration(); } }
        
    }


    [Binding]
    public class DBVersions
    {
        public IWebElement DBVersionSection { get { return Browser.Wd.FindElement(By.CssSelector("[title='DB Versions']")); } }
        public IWebElement DBVersionTitle { get { return Browser.Wd.FindElement(By.XPath("//div[@class='flex-fill']/div")); } }

        
    }

    [Binding]
    public class FrameworkAdministration
    {
        public IWebElement MenuLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='header-btn-expanMenu']")); } }
    }

}
