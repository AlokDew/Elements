﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using TechTalk.SpecFlow;
using TMSoR1.FrameworkCode;

namespace TMSoR1
{
    [Binding]
    class fsInternalDatabses
    {
        [When(@"Internaldatabases page Tenant ""(.*)"" is selected")]
        public void WhenInternaldatabasesPageTenantIsSelected(string SelectedTenant)
        {
            string GeneratedData = tmsCommon.GenerateData(SelectedTenant);
            SelectElement Tenant = new SelectElement(TmsFramework.InternalDatabses.SelectTenant);
            Tenant.SelectByText(GeneratedData);
            tmsWait.Hard(4);
        }

        [When(@"Internaldatabases foundation configurationName is set to ""(.*)""")]
        public void WhenInternaldatabasesFoundationConfigurationNameIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            TmsFramework.InternalDatabses.FoundationConfigName.SendKeys(GeneratedData);
        }

        [When(@"Internaldatabases application configurationName is set to ""(.*)""")]
        public void WhenInternaldatabasesApplicationConfigurationNameIsSetTo(string appconfigname)
        {
            string GeneratedData = tmsCommon.GenerateData(appconfigname);
            TmsFramework.InternalDatabses.ApplicationConfigName.SendKeys(GeneratedData);
        }

        [When(@"Internaldatabases warehouse configurationName is set to ""(.*)""")]
        public void WhenInternaldatabasesWarehouseConfigurationNameIsSetTo(string dwconfigname)
        {
            string GeneratedData = tmsCommon.GenerateData(dwconfigname);
            TmsFramework.InternalDatabses.DwConfigName.SendKeys(GeneratedData);
        }



        [When(@"Internaldatabases page Staging Tab is clicked")]
        public void WhenInternaldatabasesPageStagingTabIsClicked()
        {
            TmsFramework.InternalDatabses.StagingTab.Click();
            tmsWait.Hard(1);
        }

        [When(@"Internaldatabases page Operational Tab is clicked")]
        public void WhenInternaldatabasesPageOperationalTabIsClicked()
        {
            fw.ExecuteJavascript(TmsFramework.InternalDatabses.OperationalTab);//.Click();
            tmsWait.Hard(3);
        }
        [When(@"Internaldatabases page Foundation Accordion is clicked")]
        public void WhenInternaldatabasesPageFoundationAccordionIsClicked()
        {
         
            fw.ExecuteJavascript(TmsFramework.InternalDatabses.FoundationAccordion);
            tmsWait.Hard(1);
        }

        [When(@"Internaldatabases page Application Accordion is clicked")]
        public void WhenInternaldatabasesPageApplicationAccordionIsClicked()
        {
            fw.ExecuteJavascript(TmsFramework.InternalDatabses.ApplicationAccordion);
            tmsWait.Hard(2);

        }

        [When(@"Internaldatabases page Warehouse Tab is clicked")]
        public void WhenInternaldatabasesPageWarehouseTabIsClicked()
        {
            // fw.ExecuteJavascript(TmsFramework.InternalDatabses.WarehouseTab);
            TmsFramework.InternalDatabses.WarehouseTab.Click();
            tmsWait.Hard(2);
        }


        [When(@"Internaldatabases staging tab database name is set to ""(.*)""")]
        public void WhenInternaldatabasesStagingTabDatabaseNameIsSetTo(string sdbname)
        {
            string p0 = tmsCommon.GenerateData(sdbname);
            TmsFramework.InternalDatabses.StagingdbName.Clear();
            TmsFramework.InternalDatabses.StagingdbName.SendKeys(p0);
            tmsWait.Hard(1);
        }

        [When(@"Internaldatabases foundation database name is set to ""(.*)""")]
        public void WhenInternaldatabasesFoundationTabDatabaseNameIsSetTo(string fdbname)
        {
            string p0 = tmsCommon.GenerateData(fdbname);
            TmsFramework.InternalDatabses.FoundationdbName.SendKeys(p0);
            tmsWait.Hard(1);
        }

        [When(@"Internaldatabases application database name is set to ""(.*)""")]
        public void WhenInternaldatabasesApplicationDatabaseNameIsSetTo(string dbname)
        {
            string p0 = tmsCommon.GenerateData(dbname);
            TmsFramework.InternalDatabses.ApplicationdbName.SendKeys(p0);
        }

        [When(@"Internaldatabases warehouse database name is set to ""(.*)""")]
        public void WhenInternaldatabasesWarehouseDatabaseNameIsSetTo(string db)
        {
            string p0 = tmsCommon.GenerateData(db);
            TmsFramework.InternalDatabses.DwdbName.SendKeys(p0);
        }


        //[When(@"Internaldatabases warehouse Tab database name is set to ""(.*)""")]
        //public void WhenInternaldatabaseswarehousetabDatabaseNameIsSetTo(string wdbName)
        //{
        //    TmsFramework.InternalDatabses.DwdbName.SendKeys(wdbName);
        //    tmsWait.Hard(1);
        //}

        [When(@"Internaldatabases staging tab database server is set to ""(.*)""")]
        public void WhenInternaldatabasesStagingTabDatabaseServerIsSetTo(string p0)
        {
            string sdbserver = tmsCommon.GenerateData(p0);
            //string mydbserver = ConfigFile.DataServer;
            TmsFramework.InternalDatabses.StagingdbServer.Clear();
            TmsFramework.InternalDatabses.StagingdbServer.SendKeys(sdbserver);
            tmsWait.Hard(1);
        }

        [When(@"Internaldatabases staging tab database server is set from config file")]
        public void WhenInternaldatabasesStagingTabDatabaseNameIsSetFromConfigFile()
        {
            string mydbserver = ConfigFile.DataServer;
            TmsFramework.InternalDatabses.StagingdbServer.SendKeys(mydbserver);
            tmsWait.Hard(1);
        }


        [When(@"Internaldatabases foundation database server is set to ""(.*)""")]
        public void WhenInternaldatabasesFoundationTabDatabaseServerIsSetTo(string fdbserver)
        {
            string p0 = tmsCommon.GenerateData(fdbserver);
            TmsFramework.InternalDatabses.FoundationdbServer.SendKeys(p0);
            tmsWait.Hard(1);
        }

        [When(@"Internaldatabases application database server is set to ""(.*)""")]
        public void WhenInternaldatabasesApplicationDatabaseServerIsSetTo(string dbserver)
        {
            string p0 = tmsCommon.GenerateData(dbserver);
            TmsFramework.InternalDatabses.ApplicationdbServer.SendKeys(p0);
            tmsWait.Hard(2);
        }

        [When(@"Internaldatabases warehouse database server is set to ""(.*)""")]
        public void WhenInternaldatabasesWarehouseDatabaseServerIsSetTo(string dbserver)
        {
            string p0 = tmsCommon.GenerateData(dbserver);
            TmsFramework.InternalDatabses.DwdbServer.SendKeys(p0);
        }

        [When(@"Internaldatabases staging tab Database user value is set to ""(.*)""")]
        public void WhenInternaldatabasesStagingTabDatabaseUserValueIsSetTo(string dbserver)
        {
            string p0 = tmsCommon.GenerateData(dbserver);
            IWebElement DBUser = Browser.Wd.FindElement(By.CssSelector("[test-id='internalDatabases-input-databaseUser']"));
            DBUser.SendKeys(p0);
        }


        [When(@"Internaldatabases staging tab Password value is set to ""(.*)""")]
        public void WhenInternaldatabasesStagingTabPasswordValueIsSetTo(string dbserver)
        {
            string p0 = tmsCommon.GenerateData(dbserver);
            IWebElement DBPwd = Browser.Wd.FindElement(By.CssSelector("[test-id='internalDatabases-input-Password']"));
            DBPwd.SendKeys(p0);
        }

        [When(@"Internaldatabases staging tab Database user value is set from config file")]
        public void WhenInternaldatabasesStagingTabDatabaseUserValueIsSetFromConfigFile()
        {
            string dbusername = ConfigFile.DBUser;
            IWebElement DBUser = Browser.Wd.FindElement(By.CssSelector("[test-id='internalDatabases-input-databaseUser']"));
            DBUser.SendKeys(dbusername);

        }

        [When(@"Internaldatabases staging tab Database Password value is set from config file")]
        public void WhenInternaldatabasesStagingTabDatabasePasswordValueIsSetFromConfigFile()
        {
            string dbpassword = ConfigFile.DBPassword;
            IWebElement DBPwd = Browser.Wd.FindElement(By.CssSelector("[test-id='internalDatabases-input-Password']"));
            DBPwd.SendKeys(dbpassword);
        }

        [When(@"Internaldatabases staging tab Configuration Name is set to ""(.*)""")]
        public void WhenInternaldatabasesStagingTabConfigurationNameIsSetTo(string dbserver)
        {
            string p0 = tmsCommon.GenerateData(dbserver);
            IWebElement Config = Browser.Wd.FindElement(By.CssSelector("[test-id='internalDatabases-input-configurationName']"));
            Config.SendKeys(p0);
            
        }


        [When(@"Internaldatabases staging tab authentication ""(.*)"" is selected")]
        public void WhenInternaldatabasesStagingTabAuthenticationIsSelected(string sauthentication)
        {
            SelectElement sAuth = new SelectElement(TmsFramework.InternalDatabses.StagingAuthentication);
            sAuth.SelectByText(sauthentication);
        }

        [When(@"Internaldatabases foundation authentication ""(.*)"" is selected")]
        public void WhenInternaldatabasesFoundationAuthenticationIsSelected(string fauthentication)
        {
            SelectElement fAuth = new SelectElement(TmsFramework.InternalDatabses.FoundationAuthentication);
            fAuth.SelectByText(fauthentication);
        }

        [When(@"Internaldatabases application authentication ""(.*)"" is selected")]
        public void WhenInternaldatabasesApplicationAuthenticationIsSelected(string Authentication)
        {
            SelectElement appauth = new SelectElement(TmsFramework.InternalDatabses.ApplicationAuthentication);
            appauth.SelectByText(Authentication);
        }

        [When(@"Internaldatabases warehouse authentication ""(.*)"" is selected")]
        public void WhenInternaldatabasesWarehouseAuthenticationIsSelected(string Authentication)
        {
            SelectElement auth = new SelectElement(TmsFramework.InternalDatabses.DwAuthentication);
            auth.SelectByText(Authentication);
        }



        [When(@"Internaldatabases staging tab database user is set to ""(.*)""")]
        public void WhenInternaldatabasesStagingTabDatabaseUserIsSetTo(string sdbuser)
        {
            TmsFramework.InternalDatabses.FounationdbUser.SendKeys(sdbuser);
        }


        [When(@"Internaldatabases foundation database user is set to ""(.*)""")]
        public void WhenInternaldatabasesFoundationDatabaseUserIsSetTo(string fdbuser)
        {
            TmsFramework.InternalDatabses.FounationdbUser.SendKeys(fdbuser);
        }




        [When(@"Internaldatabases staging tab password is set to ""(.*)""")]
        public void WhenInternaldatabasesStagingTabPasswordIsSetTo(string sdbpassword)
        {
            TmsFramework.InternalDatabses.StagingdbPassword.SendKeys(sdbpassword);
        }

        [When(@"Internaldatabases foundation passsword is set to ""(.*)""")]
        public void WhenInternaldatabasesFoundationPassswordIsSetTo(string fdbpassword)
        {
            string dbpassword = ConfigFile.DBPassword;
            TmsFramework.InternalDatabses.FoundationdbPassword.Clear();
            TmsFramework.InternalDatabses.FoundationdbPassword.SendKeys(fdbpassword);
        }

        [When(@"Internaldatabases staging tab test connection button is clicked")]
        public void WhenInternaldatabasesStagingTabTestConnectionButtonIsClicked()
        {
            fw.ExecuteJavascript(TmsFramework.InternalDatabses.StagingTestConnectionBtn);
            tmsWait.Hard(1);
        }

        [When(@"Internaldatabases foundation test connection button is clicked")]
        public void WhenInternaldatabasesFoundationTestConnectionButtonIsClicked()
        {
            fw.ExecuteJavascript(TmsFramework.InternalDatabses.FoundationTestConnectionBtn);
            //tmsWait.Hard(1);
        }

        [When(@"Internaldatabases application test connection button is clicked")]
        public void WhenInternaldatabasesApplicationTestConnectionButtonIsClicked()
        {
            fw.ExecuteJavascript(TmsFramework.InternalDatabses.ApplicationTestConnectionBtn);

        }


        [When(@"Internaldatabases staging tab save button is clicked")]
        public void WhenInternaldatabasesStagingTabSaveButtonIsClicked()
        {
            fw.ExecuteJavascript(TmsFramework.InternalDatabses.StaginSaveBtn);
            tmsWait.Hard(1);
        }

        [When(@"Internaldatabases foundation save button is clicked")]
        public void WhenInternaldatabasesFoundationSaveButtonIsClicked()
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(TmsFramework.InternalDatabses.FoundationSaveBtn);
            tmsWait.Hard(1);
        }
          

        [When(@"Internaldatabases application save button is clicked")]
        public void WhenInternaldatabasesApplicationSaveButtonIsClicked()
        {
            fw.ExecuteJavascript(TmsFramework.InternalDatabses.ApplicationSaveBtn);
        }


        [Then(@"Verify InternalDatabases page GreenTick mark on successfull test connection is displayed")]
        public void ThenVerifyInternalDatabasesPageGreenTickMarkOnSuccessfullTestConnectionIsDisplayed()
        {
            //bool isPresentMark;
        }

        [Then(@"Verify InternalDatabases Databse Grid ""(.*)"" is displayed")]
        public void ThenVerifyInternalDatabasesDatabseGridIsDisplayed(string dbName)
        {
            bool dbnamedisplayed = false;
            IWebElement GridValue = Browser.Wd.FindElement(By.XPath("//div[@id='grdFoundationDb']//span[contains(., '" + dbName + "')]"));
            if (GridValue.Displayed)
            {
                dbnamedisplayed = true;
            }
            else
            {
                dbnamedisplayed = false;
            }

            Assert.IsTrue(dbnamedisplayed);

        }

        [Then(@"Verify InternalDatabases ""(.*)"" Databse Grid ""(.*)"" is displayed")]
        public void ThenVerifyInternalDatabasesDatabseGridIsDisplayed(string dbtype, string dbName)
        {
            bool dbnamedisplayed = false;
            IWebElement GridValue = Browser.Wd.FindElement(By.XPath("//div[@id='grd" + dbtype + "Db']//span[contains(., '" + dbName + "')]"));
            if (GridValue.Displayed)
            {
                dbnamedisplayed = true;
            }
            else
            {
                dbnamedisplayed = false;
            }

            Assert.IsTrue(dbnamedisplayed);

        }

        [Then(@"Verify TmsFramework displays Message ""(.*)""")]
        public void ThenVerifyTmsFrameworkDisplaysMessage(string p0)
        {
            tmsWait.Hard(30);
            bool msg = Browser.Wd.FindElement(By.XPath("//div[@class='toast-message'][contains(.,'"+p0+"')]")).Displayed;
            Assert.IsTrue(msg, "Expected message is not getting displayed");
        }

        [Then(@"Verify TMSFramework displays Connection Failed Icon")]
        public void ThenVerifyTMSFrameworkDisplaysConnectionFailedIcon()
        {
            tmsWait.Hard(25);
           // AngularFunction.elementPresenceUsingWebElement(TmsFramework.TenantConfiguration.DangerIcon);
        }

        [When(@"Internaldatabases staging tab Test connection is clicked")]
        public void WhenInternaldatabasesStagingTabTestConnectionIsClicked()
        {
            IWebElement testcon = Browser.Wd.FindElement(By.CssSelector("[test-id='internalDatabases-btn-TestConnection']"));
            fw.ExecuteJavascript(testcon);
        }

        [When(@"Internaldatabases staging tab Test connection is clicked and Verify message as ""(.*)""")]
        public void WhenInternaldatabasesStagingTabTestConnectionIsClickedAndVerifyMessageAs(string p0)
        {
            IWebElement testcon = Browser.Wd.FindElement(By.CssSelector("[test-id='internalDatabases-btn-TestConnection']"));
            fw.ExecuteJavascript(testcon);

            bool msg = Browser.Wd.FindElement(By.XPath("//div[contains(@aria-label,'" + p0 + "')]")).Displayed;
            Assert.IsTrue(msg, "Expected message is not getting displayed");
        }


        [Then(@"Verify TmsFramework Message ""(.*)""")]
        public void ThenVerifyTmsFrameworkMessage(string p0)
        {
            //tmsWait.Hard(1);
            //IWebElement toaster = Browser.Wd.FindElement(By.XPath("//div[@class='toast-message'][contains(.,'" + p0 + "')]"));
            By toastMsg = By.XPath("//div[@class='k-notification-content']");
            string actValue = Browser.Wd.FindElement(toastMsg).Text;
            Assert.IsTrue(actValue.Contains(p0), "Expected Toaster message is not getting displayed");
        }

        [Then(@"Verify TmsFramework page display Danger Icon")]
        public void ThenVerifyTmsFrameworkPageDisplayDangerIcon()
        {
            //AngularFunction.elementPresenceUsingWebElement(TmsFramework.TenantConfiguration.DangerIcon);
            tmsWait.Hard(5);
        }

        [Then(@"Verify TmsFramework page display Success Icon")]
        public void ThenVerifyTmsFrameworkPageDisplaySuccessIcon()
        {
           // AngularFunction.elementPresenceUsingWebElement(TmsFramework.TenantConfiguration.SuccessIcon);
        }


        [Then(@"Verify Framework Msg ""(.*)""")]
        public void ThenVerifyFrameworkMsg(string toastmessage)
        {
            bool toastMsg = false;
            if (Browser.Wd.FindElement(By.XPath("//div[starts-with(.,'" + toastmessage + "')]")).Displayed)
            {
                toastMsg = true;
            }
            else
            {
                toastMsg = false;
            }

            Assert.IsTrue(toastMsg);
            tmsWait.Hard(5);
        }

        //[Then(@"Verify TmsFramework Message ""(.*)""")]
        //public void ThenVerifyInternalDatabasesPageMessage(string toastmessage)
        //{
        //    bool toastMsg = false;
        //    if (Browser.Wd.FindElement(By.XPath("//div[starts-with(.,'"+ toastmessage +"')]")).Displayed)
        //    {
        //        toastMsg = true;
        //    }
        //    else
        //    {
        //        toastMsg = false;
        //    }

        //    Assert.IsTrue(toastMsg);
        //    tmsWait.Hard(5);

        //}


        //[When(@"Internaldatabases page Save button is clicked")]
        //public void WhenInternaldatabasesPageSaveButtonIsClicked()
        //{
        //    tmsWait.Hard(2);
        //    TmsFramework.InternalDatabses.Save.Click();

        //}

        [Then(@"Verify Internaldatabases foundation database user field is disabled")]
        public void ThenVerifyInternaldatabasesFoundationDatabaseUserFieldIsDisabled()
        {
            bool isdisplayed = false;
            if (TmsFramework.InternalDatabses.FounationdbUser.Enabled)
            {
                isdisplayed = false;
            }
            else
            {
                isdisplayed = true;
            }

            Assert.IsTrue(isdisplayed);
        }

        [Then(@"Verify Internaldatabases foundation database password field is disabled")]
        public void ThenVerifyInternaldatabasesFoundationDatabasePasswordFieldIsDisabled()
        {
            bool isdisplayed = false;
            if (TmsFramework.InternalDatabses.FoundationdbPassword.Enabled)
            {
                isdisplayed = false;
            }
            else
            {
                isdisplayed = true;
            }

            Assert.IsTrue(isdisplayed);
        }

        [Then(@"Verify Internaldatabases application database user field is disabled")]
        public void ThenVerifyInternaldatabasesApplicationDatabaseUserFieldIsDisabled()
        {
            bool isdisplayed = false;
            if (TmsFramework.InternalDatabses.ApplicationdbUser.Enabled)
            {
                isdisplayed = false;
            }
            else
            {
                isdisplayed = true;
            }

            Assert.IsTrue(isdisplayed);

        }

        [Then(@"Verify Internaldatabases warehouse database user field is disabled")]
        public void ThenVerifyInternaldatabasesWarehouseDatabaseUserFieldIsDisabled()
        {
            bool isdisplayed = false;
            if (TmsFramework.InternalDatabses.DwdbUser.Enabled)
            {
                isdisplayed = false;
            }
            else
            {
                isdisplayed = true;
            }

            Assert.IsTrue(isdisplayed);
        }



        [Then(@"Verify Internaldatabases application database password field is disabled")]
        public void ThenVerifyInternaldatabasesApplicationDatabasePasswordFieldIsDisabled()
        {

            bool isdisplayed = false;
            if (TmsFramework.InternalDatabses.ApplicationdbPassword.Enabled)
            {
                isdisplayed = false;
            }
            else
            {
                isdisplayed = true;
            }

            Assert.IsTrue(isdisplayed);
        }

        [Then(@"Verify Internaldatabases warehouse database password field is disabled")]
        public void ThenVerifyInternaldatabasesWarehouseDatabasePasswordFieldIsDisabled()
        {
            bool isdisplayed = false;
            if (TmsFramework.InternalDatabses.DwdbPassword.Enabled)
            {
                isdisplayed = false;
            }
            else
            {
                isdisplayed = true;
            }

            Assert.IsTrue(isdisplayed);
        }


        [Then(@"TenantSetup Add new Tenant is set to ""(.*)""")]
        public void WhenTenantSetupAddNewTenantIsSetTo(string newtenant)
        {
            string GeneratedData = tmsCommon.GenerateData(newtenant);
            TmsFramework.TenantSetup.AddNewTenantTextbox.SendKeys(GeneratedData);
        }


        [Given(@"TMS Identity Manager page Add User section Role is set as ""(.*)""")]
        public void GivenTMSIdentityManagerPageAddUserSectionRoleIsSetAs(string p0)
        {
          

        tmsWait.Hard(2);
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.UserAdministrationCrudUser.TmsServerList);
            select.SelectByText(GeneratedData);
            tmsWait.Hard(2);
        }

        [When(@"User clicked on ""(.*)"" link from information menus")]
        public void WhenUserClickedOnLinkFromInformationMenus(string p0)
        {
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//a[@test-id='header-btn-userMenu']"));
            MouseFunctions.MouseMoveToElement(ele);
            tmsWait.Hard(4);
            IWebElement help = Browser.Wd.FindElement(By.XPath("//button[contains(.,'" + p0.ToUpper() + "')]/i"));
            fw.ExecuteJavascript(help);
            tmsWait.Hard(2);
        }


        [When(@"User clicks on ""(.*)"" link from information menus")]
        public void WhenUserClicksOnLinkFromInformationMenus(string p0)
        {
            if(p0.Contains("LOGOUT") || p0.Contains("Change Password"))
            {
                IWebElement ele = Browser.Wd.FindElement(By.XPath("//a[@test-id='header-btn-userMenu']"));
                MouseFunctions.MouseMoveToElement(ele);
                tmsWait.Hard(4);
            }
            tmsWait.Hard(2);
            IWebElement help = Browser.Wd.FindElement(By.XPath("//button[contains(.,'" + p0.ToUpper() + "')]/i"));
            fw.ExecuteJavascript(help);
            tmsWait.Hard(2);

        }
        [Then(@"Verify logged page displayed""(.*)""")]
        public void ThenVerifyLoggedPageDisplayed(string p0)
        {
            IWebElement loggedout = Browser.Wd.FindElement(By.XPath("//h4[contains(.,'" + p0 + "')]"));
            Assert.IsTrue(loggedout.Displayed, p0 + "is not getting displayed");
        }
        [Then(@"Verify Change Password screen displayed ""(.*)""")]
        public void ThenVerifyChangePasswordScreenDisplayed(string p0)
        {
            tmsWait.Hard(8);
            //commenting below code as can see its opening change password in same page and not in another tab 
            //Browser.SwitchToChildWindow();
            //tmsWait.Hard(5);
            IWebElement changepass = Browser.Wd.FindElement(By.XPath("//*[contains(.,'" + p0 + "')]"));
            Assert.IsTrue(changepass.Displayed, p0 + "is not getting displayed");
        }

        [Then(@"Verify new tab page displayed about ""(.*)""")]
        public void ThenVerifyNewTabPageDisplayedAbout(string p0)
        {
            System.Collections.Generic.IList<string> str = Browser.Wd.WindowHandles;
            Browser.Wd.SwitchTo().ActiveElement();
            // string window = Browser.Wd.SwitchTo().Window(str[1]).Title;
            IWebElement version = Browser.Wd.FindElement(By.XPath("//h5[contains(.,'" + p0 + "')]"));
            Assert.IsTrue(version.Displayed, p0 + "is not getting displayed");
            Browser.Wd.Navigate().Back();
            tmsWait.Hard(2);
        }

        [Then(@"Verify new tab page displayed ""(.*)""")]
        public void ThenVerifyNewTabPageDisplayed(string p0)
        {
            System.Collections.Generic.IList<string> str = Browser.Wd.WindowHandles;
            Browser.Wd.SwitchTo().ActiveElement();
          string window=  Browser.Wd.SwitchTo().Window(str[1]).Title;
            Assert.IsTrue(window.Contains(p0),p0 + "is not getting displayed");
            Browser.Wd.SwitchTo().Window(str[0]);
            tmsWait.Hard(2);
        }
        [When(@"User mouseOver on ""(.*)"" link from information menus and Verify connection information display ""(.*)"" and ""(.*)"" currentDate")]
        public void WhenUserMouseOverOnLinkFromInformationMenusAndVerifyConnectionInformationDisplayAndCurrentDate(string p0, string p1, string p2)
        {


            string date = tmsCommon.GenerateData(p2);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//a[@test-id='header-btn-userMenu']"));
            fw.ExecuteJavascript(ele);
            tmsWait.Hard(4);
            // Due to Obsolete it comments

            //IWebElement info = Browser.Wd.FindElement(By.XPath("//a[contains(.,'" + p0 + "')]"));
            //MouseFunctions.MouseMoveToElementt(info);
            //tmsWait.Hard(2);
            //IWebElement infomore = Browser.Wd.FindElement(By.XPath("//div[@class='card-text'][contains(.,'"+p1+"')]"));
            IWebElement infomore = Browser.Wd.FindElement(By.XPath("//kendo-popup//div[contains(text(),'" + p1 + "')]"));
            tmsWait.Hard(1);
            Assert.IsTrue(infomore.Displayed, p1 + "is not getting displayed");

    // Due to TExt Format, comment this statement as it will leads to lots of failure
            //IWebElement dateelement = Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + date + "')]"));

            //Assert.IsTrue(dateelement.Displayed, p1 + "is not getting displayed");
        }

        [Then(@"Verify Default Application Name displayed ""(.*)""")]
        public void ThenVerifyDefaultApplicationNameDisplayed(string p0)
        {
            tmsWait.Hard(3);
            IWebElement name = Browser.Wd.FindElement(By.XPath("//div[contains(.,'" + p0 + "')]"));
            Assert.IsTrue(name.Displayed, p0 + "is not getting displayed");
        }

        [Then(@"Verify Application Name displayed ""(.*)""")]
        public void ThenVerifyApplicationNameDisplayed(string p0)
        {

        tmsWait.Hard(15);
            IWebElement name = Browser.Wd.FindElement(By.XPath("//div[@class='navbar-text border-left border-right border-blue flex-fill'][contains(.,'" + p0+"')]"));
            Assert.IsTrue(name.Displayed, p0 + "is not getting displayed");
        }
        [Then(@"Verify user not able to view ""(.*)"" application")]
        public void ThenVerifyUserNotAbleToViewApplication(string p0)
        {
            IWebElement switch1 = Browser.Wd.FindElement(By.XPath("//button[@test-id='header-btn-productDetails']"));
            switch1.Click();
            tmsWait.Hard(1);
            IWebElement name = Browser.Wd.FindElement(By.XPath("//span[contains(.,'FRM')]/parent::div"));
            string color_hex =  name.GetCssValue("color");
            IWebElement name2 = Browser.Wd.FindElement(By.XPath("//span[contains(.,'CDM')]"));
            string color_hex12 = name.GetCssValue("color");
            IWebElement name4 = Browser.Wd.FindElement(By.XPath("//span[contains(.,'RAM')]/parent::div"));
            string color_hex11 = name.GetCssValue("color");
            name4.Click();
            Assert.IsFalse(name.Enabled, "RAM" + "is  getting displayed");
        }

        [Then(@"Verify user able to view All assigned application")]
        public void ThenVerifyUserAbleToViewAllAssignedApplication()
        {
            IWebElement switch1 = Browser.Wd.FindElement(By.XPath("//button[@test-id='header-btn-productDetails']"));
            switch1.Click();
            tmsWait.Hard(1);
            IWebElement name = Browser.Wd.FindElement(By.XPath("//span[contains(.,'EAM')]"));
            Assert.IsTrue(name.Enabled, "EAM" + "is not getting displayed");
            tmsWait.Hard(1);
            IWebElement RAM = Browser.Wd.FindElement(By.XPath("//span[contains(.,'RAM')]"));
            Assert.IsTrue(RAM.Enabled, "RAM" + "is not getting displayed");
            tmsWait.Hard(1);
            IWebElement RxM = Browser.Wd.FindElement(By.XPath("//span[contains(.,'RxM')]"));
            Assert.IsTrue(RxM.Enabled, "Rxm" + "is not getting displayed");
            tmsWait.Hard(1);
            IWebElement FRM = Browser.Wd.FindElement(By.XPath("//span[contains(.,'FRM')]"));
            Assert.IsTrue(FRM.Enabled, "FRM" + "is not getting displayed");
            tmsWait.Hard(1);
            IWebElement PDEM = Browser.Wd.FindElement(By.XPath("//span[contains(.,'PDEM')]"));
            Assert.IsTrue(PDEM.Enabled, "PDEM" + "is not getting displayed");
            tmsWait.Hard(1);
            IWebElement RAMX = Browser.Wd.FindElement(By.XPath("//span[contains(.,'RAMX')]"));
            Assert.IsTrue(RAMX.Enabled, "RAMX" + "is not getting displayed");
            tmsWait.Hard(1);
            IWebElement DLM = Browser.Wd.FindElement(By.XPath("//span[contains(.,'DLM')]"));
            Assert.IsTrue(DLM.Enabled, "DLM" + "is not getting displayed");

            
        }

        [When(@"User clicks on information icon and user can view options ""(.*)"" and ""(.*)"" and ""(.*)"" and ""(.*)"" and ""(.*)""")]
        public void WhenUserClicksOnInformationIconAndUserCanViewOptionsAndAndAndAnd(string p0, string p1, string p2, string p3, string p4)
        {
            tmsWait.Hard(5);
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("a[test-id='header-btn-userMenu']"));
            MouseFunctions.MouseMoveToElement(ele);
            //fw.ExecuteJavascript(ele);
            tmsWait.Hard(5);
            IWebElement help = Browser.Wd.FindElement(By.XPath("//button[contains(.,'" + p0.ToUpper() + "')]"));
            Assert.IsTrue(help.Displayed, p0 + "is not getting displayed");
            // Comment due to obsolte in Application
            //IWebElement info = Browser.Wd.FindElement(By.XPath("//button[contains(.,'" + p1 + "')]"));
            //Assert.IsTrue(info.Displayed, p1 + "is not getting displayed");
            IWebElement changepass = Browser.Wd.FindElement(By.XPath("//button[contains(.,'" + p2.ToUpper() + "')]"));
            Assert.IsTrue(changepass.Displayed, p2 + "is not getting displayed");
            IWebElement about = Browser.Wd.FindElement(By.XPath("//button[contains(.,'" + p3.ToUpper() + "')]"));
            Assert.IsTrue(about.Displayed, p3 + "is not getting displayed");
            IWebElement logout = Browser.Wd.FindElement(By.XPath("//button[contains(.,'" + p4.ToUpper() + "')]"));
            Assert.IsTrue(logout.Displayed, p4 + "is not getting displayed");
// fw.ExecuteJavascript(ele);
        }
        [Then(@"I clicked on ""(.*)"" under Actions")]
        public void ThenIClickedOnUnderActions(string p0)
        {
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@title='Tasks']"));
            fw.ExecuteJavascript(ele);
            IWebElement actions = Browser.Wd.FindElement(By.LinkText("Actions"));

            MouseFunctions.MouseMoveToElementt(actions);

            IWebElement manual = Browser.Wd.FindElement(By.XPath("//span[contains(text(),'" + p0 + "')]"));
            MouseFunctions.DoubleClickOnElement(manual);
        }


        [Then(@"Verify under Actions submenus displayed ""(.*)"" and ""(.*)"" and ""(.*)"" and ""(.*)""")]
        public void ThenVerifyUnderActionsSubmenusDisplayedAndAndAnd(string p0, string p1, string p2, string p3)
        {
            //IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@title='Tasks']"));
            //fw.ExecuteJavascript(ele);
            //tmsWait.Hard(4);
            //IWebElement actions = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Actions')]"));

            //fw.ExecuteJavascript(actions);

            IWebElement manual = Browser.Wd.FindElement(By.XPath("//span[contains(text(),'" + p0 + "')]"));
            MouseFunctions.MouseMoveToElementt(manual);

            bool m = manual.Displayed;
            IWebElement force = Browser.Wd.FindElement(By.XPath("//span[contains(text(),'" + p1 + "')]"));
            MouseFunctions.MouseMoveToElementt(force);

            bool f = force.Displayed;
            IWebElement po = Browser.Wd.FindElement(By.XPath("//span[contains(text(),'" + p2 + "')]"));
            MouseFunctions.MouseMoveToElementt(po);

            bool p = manual.Displayed;
            IWebElement last = Browser.Wd.FindElement(By.XPath("//span[contains(text(),'" + p3 + "')]"));
MouseFunctions.MouseMoveToElementt(last);

            bool l = manual.Displayed;
            // MouseFunctions.MouseMoveToElement(name);
            tmsWait.Hard(1);
            Assert.IsTrue(m, p0 + "is not getting displayed");
            Assert.IsTrue(f, p0 + "is not getting displayed");
            Assert.IsTrue(p, p0 + "is not getting displayed");
            Assert.IsTrue(l, p0 + "is not getting displayed");
        }

        [Then(@"Verify Actions submenus displayed ""(.*)""")]
        public void ThenVerifyActionsSubmenusDisplayed(string p0)
        {
            // MouseFunctions.MouseMoveToElement(Browser.Wd.FindElement(By.XPath("//span[contains(text(),'Actions')]/parent::a/i")));
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(text(),'Actions')]/parent::a/i")));
            //tmsWait.Hard(1);
            //MouseFunctions.MouseMoveToElement(Browser.Wd.FindElement(By.XPath("//span[contains(text(),'Actions')]/parent::a/i")));
            // tmsWait.Hard(3);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@title='Tasks']"));
            fw.ExecuteJavascript(ele);
            IWebElement actions = Browser.Wd.FindElement(By.LinkText("Actions"));
            //fw.ExecuteJavascript(actions);
             //tmsWait.Hard(1);
            MouseFunctions.MouseMoveToElement(actions);
            // tmsWait.Hard(3);
            IWebElement name = Browser.Wd.FindElement(By.XPath("//span[contains(text(),'"+p0+"')]"));
            MouseFunctions.MouseMoveToElement(name);
           
            bool b = Browser.Wd.FindElement(By.XPath("//span[contains(text(),'" + p0 + "')]")).Displayed;
            // MouseFunctions.MouseMoveToElement(name);
            tmsWait.Hard(1);
            Assert.IsTrue(b, p0 + "is not getting displayed");
        }
       

        [Then(@"Verify TriZetto Elements User Login page display Error message ""(.*)""")]
        public void ThenVerifyTriZettoElementsUserLoginPageDisplayErrorMessage(string p0)
        {
            tmsWait.Hard(3);
            IWebElement name = Browser.Wd.FindElement(By.XPath("//div[@ng-show='model.errorMessage']/text()[contains(.,'"+p0+"')]"));
            Assert.AreEqual(p0,name.Text, p0 + "is not getting displayed");

        }


        [When(@"TenantSetup Add button is clicked")]
        public void WhenTenantSetupAddButtonIsClicked()
        {
            //string toastmessage = "Tenant added successfully";
            fw.ExecuteJavascript(TmsFramework.TenantSetup.AddTenantButton);
            //if (Browser.Wd.FindElement(By.XPath("//div[starts-with(.,'" + toastmessage + "')]")).Displayed)
            //{
            //    Assert.IsTrue(true, "Toast Message is displayed");
            //}
            //else
            //{
            //    Assert.IsFalse(false, "Toast Message is not displayed");
            //}
        }

        [When(@"Internaldatabases delete foundation database ""(.*)""")]
        public void WhenInternaldatabasesDeleteFoundationDatabase(string deldatabase)
        {
            IWebElement deldb = Browser.Wd.FindElement(By.XPath("//div[@id='grdFoundationDb']//span[contains(.,'" + deldatabase + "')]/parent::td//following-sibling::td/a/span[@class=' fa fa-trash']"));
            fw.ExecuteJavascript(deldb);
            tmsWait.Hard(2);
            fw.ExecuteJavascript(TmsFramework.InternalDatabses.AlertAccpetForDeleteDb);
            tmsWait.Hard(1);

        }

        [When(@"Internaldatabases delete application database ""(.*)""")]
        public void WhenInternaldatabasesDeleteApplicationDatabase(string delappdb)
        {
            IWebElement deldb = Browser.Wd.FindElement(By.XPath("//div[@id='grdApplicationsDb']//span[contains(.,'" + delappdb + "')]/parent::td//following-sibling::td/a/span[@class=' fa fa-trash']"));
            fw.ExecuteJavascript(deldb);
            tmsWait.Hard(2);
            fw.ExecuteJavascript(TmsFramework.InternalDatabses.AlertAccpetForDeleteDb);
            tmsWait.Hard(1);
        }

        [When(@"Internaldatabases delete warehouse database ""(.*)""")]
        public void WhenInternaldatabasesDeleteWarehouseDatabase(string deldwdb)
        {
            IWebElement deldb = Browser.Wd.FindElement(By.XPath("//div[@id='grdWarehouseDb']//span[contains(.,'" + deldwdb + "')]/parent::td//following-sibling::td/a/span[@class=' fa fa-trash']"));
            fw.ExecuteJavascript(deldb);
            tmsWait.Hard(2);
            fw.ExecuteJavascript(TmsFramework.InternalDatabses.AlertAccpetForDeleteDb);
            tmsWait.Hard(1);
        }


        [Then(@"Verify InternalDatabases Database Grid ""(.*)"" is not available")]
        public void ThenVerifyInternalDatabasesDatabaseGridIsNotAvailable(string dbName)
        {
            bool dbnamedisplayed = false;
            //IWebElement GridValue = Browser.Wd.FindElement(By.XPath("//div[@id='grdFoundationDb']//span[contains(., '" + dbName + "')]"));
            if (TmsFramework.InternalDatabses.FoundationGridNoItemdisplayMsg.Displayed)
            {
                dbnamedisplayed = true;
            }
            else
            {
                dbnamedisplayed = false;
            }

            Assert.IsTrue(dbnamedisplayed);
        }

        [Then(@"Verify InternalDatabases Application Database Grid ""(.*)"" is not available")]
        public void ThenVerifyInternalDatabasesApplicationDatabaseGridIsNotAvailable(string p0)
        {
           
        }


        [When(@"Internaldatabases edit icon is clicked for database ""(.*)""")]
        public void WhenInternaldatabasesEditIconIsClickedForDatabase(string dbname)
        {
            IWebElement editdb = Browser.Wd.FindElement(By.XPath("//div[@id='grdFoundationDb']//span[contains(.,'" + dbname + "')]/parent::td//following-sibling::td/a/span[@class=' fa fa-pencil']"));
            fw.ExecuteJavascript(editdb);
        }

        [When(@"Internaldatabases ""(.*)"" edit icon is clicked for database ""(.*)""")]
        public void WhenInternaldatabasesEditIconIsClickedForDatabase(string Dbtype, string dbName)
        {
            IWebElement editdb = Browser.Wd.FindElement(By.XPath("//div[@id= 'grd" + Dbtype + "']//span[contains(.,'" + dbName + "')]/parent::td//following-sibling::td/a/span[@class=' fa fa-pencil']"));
            fw.ExecuteJavascript(editdb);
        }


        [When(@"Internaldatabases foundation update button is clicked")]
        public void WhenInternaldatabasesFoundationUpdateButtonIsClicked()
        {
            fw.ExecuteJavascript(TmsFramework.InternalDatabses.FoundationUpdateBtn);
            //tmsWait.Hard(1);
        }

        [When(@"Internaldatabases application update button is clicked")]
        public void WhenInternaldatabasesApplicationUpdateButtonIsClicked()
        {
            fw.ExecuteJavascript(TmsFramework.InternalDatabses.ApplicationUpdateBtn);
        }

        [When(@"Internaldatabases warehouse database user is set to ""(.*)""")]
        public void WhenInternaldatabasesWarehouseDatabaseUserIsSetTo(string p0)
        {
            TmsFramework.InternalDatabses.DwdbUser.SendKeys(p0);
        }

        [When(@"Internaldatabases warehouse passsword is set to ""(.*)""")]
        public void WhenInternaldatabasesWarehousePassswordIsSetTo(string p0)
        {
            TmsFramework.InternalDatabses.DwdbPassword.SendKeys(p0);
        }

        [When(@"Internaldatabases warehouse test connection button is clicked")]
        public void WhenInternaldatabasesWarehouseTestConnectionButtonIsClicked()
        {
            fw.ExecuteJavascript(TmsFramework.InternalDatabses.DwTestConnection);
            tmsWait.Hard(1);
        }

        [When(@"Internaldatabases warehouse save button is clicked")]
        public void WhenInternaldatabasesWarehouseSaveButtonIsClicked()
        {
            fw.ExecuteJavascript(TmsFramework.InternalDatabses.DwSaveBtn);
            tmsWait.Hard(2);
        }

        [When(@"Internaldatabases warehouse update button is clicked")]
        public void WhenInternaldatabasesWarehouseUpdateButtonIsClicked()
        {
            fw.ExecuteJavascript(TmsFramework.InternalDatabses.DwUpdateBtn);

        }

        [Given(@"Internal Databases Tenant selected as ""(.*)""")]
        public void GivenInternalDatabasesTenantSelectedAs(string p0)
        {
            tmsWait.WaitForElement(By.CssSelector("select[test-id='internalDatabases-select-tenant']"), 300);
            string tenant = tmsCommon.GenerateData(p0);
            SelectElement tenantDD = new SelectElement(TmsFramework.InternalDatabses.TenantDropdown);
            tenantDD.SelectByText(tenant);
        }

        [Given(@"Internal Databases ""(.*)"" Section is selected")]
        public void GivenInternalDatabasesSectionIsSelected(string section)
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[contains(.,'" + section + "')]")));
        }

        [Given(@"Internal Databases Application Section is expanded")]
        public void GivenInternalDatabasesApplicationSectionIsExpanded()
        {
            fw.ExecuteJavascript(TmsFramework.InternalDatabses.ExpandApplication);
        }

        [Given(@"Internal Databases Configuration Name is set as ""(.*)""")]
        public void GivenInternalDatabasesConfigurationNameIsSetAs(string p0)
        {
            tmsWait.WaitForElement(By.XPath("//input[@test-id='internalDatabases-input-configurationName']"), 300);
            string configName = tmsCommon.GenerateData(p0);
            var configNameInput = Browser.Wd.FindElements(By.XPath("//input[@test-id='internalDatabases-input-configurationName']"));
            for (int element = 0; element < configNameInput.Count + 1; element++)
            {
                if (configNameInput[element].Displayed)
                {
                    configNameInput[element].SendKeys(configName);
                    break;
                }
            }
        }

        [Given(@"Internal Databases DB Name is set as ""(.*)""")]
        public void GivenInternalDatabasesDBNameIsSetAs(string p0)
        {
            string dbName = tmsCommon.GenerateData(p0);
            var dbInput = Browser.Wd.FindElements(By.XPath("//input[@test-id='internalDatabases-input-databasesName']"));
            for (int element = 0; element < dbInput.Count + 1; element++)
            {
                if (dbInput[element].Displayed)
                {
                    dbInput[element].SendKeys(dbName);
                    break;
                }
            }
        }

        [Given(@"Internal Databases DB Server is set as ""(.*)""")]
        public void GivenInternalDatabasesDBServerIsSetAs(string p0)
        {
            string dbServer = tmsCommon.GenerateData(p0);
            var dbServerInput = Browser.Wd.FindElements(By.XPath("//input[@test-id='internalDatabases-input-databaseServer']"));
            for (int element = 0; element < dbServerInput.Count + 1; element++)
            {
                if (dbServerInput[element].Displayed)
                {
                    dbServerInput[element].SendKeys(dbServer);
                    break;
                }
            }
        }

        [Given(@"Internal Databases Authentication is set as ""(.*)""")]
        public void GivenInternalDatabasesAuthenticationIsSetAs(string value)
        {
            var dbAuthSelect = Browser.Wd.FindElements(By.XPath("//select[@test-id='internalDatabases-select-Authentication']"));
            for (int element = 0; element < dbAuthSelect.Count + 1; element++)
            {
                if (dbAuthSelect[element].Displayed)
                {
                    SelectElement authDD = new SelectElement(dbAuthSelect[element]);
                    authDD.SelectByText(value);
                    break;
                }
            }
        }

        [Given(@"Internal Databases Configuration is saved")]
        public void GivenInternalDatabasesConfigurationIsSaved()
        {
            var saveButton = Browser.Wd.FindElements(By.XPath("//button[@test-id='internalDatabases-btn-Save']"));
            for (int element = 0; element < saveButton.Count + 1; element++)
            {
                if (saveButton[element].Displayed)
                {
                    saveButton[element].Click();
                    break;
                }
            }
            Assert.IsTrue(TmsFramework.InternalDatabses.ToastMessage.Text.Contains("Configuration added successfully"));

        }

    }
}
