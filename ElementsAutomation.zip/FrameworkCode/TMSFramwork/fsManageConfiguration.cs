﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using TechTalk.SpecFlow;

namespace TMSoR1
{
    [Binding]
    public class fsManageConfiguration
    {
        [Given(@"Manage Configuration page SSRS is set as ""(.*)""")]
        public void GivenManageConfigurationPageSSRSIsSetAs(string ssrs)
        {
            tmsWait.Hard(2);
            fw.KendoSelectByValue(Browser.Wd, TmsFramework.ManageConfiguration.SSRSDropdown, ssrs);
        }

        [Given(@"Manage Configuration page SSIS is set as ""(.*)""")]
        public void GivenManageConfigurationPageSSISIsSetAs(string ssis)
        {
            tmsWait.Hard(2);
            fw.KendoSelectByValue(Browser.Wd, TmsFramework.ManageConfiguration.SSISDropdown, ssis);
        }


        [When(@"Root Administration menu External Systems sub menu Identity Server submenu is Clicked")]
        public void WhenRootAdministrationMenuExternalSystemsSubMenuIdentityServerSubmenuIsClicked()
        {
            IWebElement ra = Browser.Wd.FindElement(By.XPath("//a[@title='Root Administration']"));
            fw.ExecuteJavascript(ra);

            IWebElement ssrs = Browser.Wd.FindElement(By.XPath("//a[@title='Identity Server']"));
            fw.ExecuteJavascript(ssrs);
        }

        [When(@"Root Administration menu External Systems sub menu Redis submenu is Clicked")]
        public void WhenRootAdministrationMenuExternalSystemsSubMenuRedisSubmenuIsClicked()
        {
            IWebElement ra = Browser.Wd.FindElement(By.XPath("//a[@title='Root Administration']"));
            fw.ExecuteJavascript(ra);

            IWebElement ssrs = Browser.Wd.FindElement(By.XPath("//a[@title='Redis']"));
            fw.ExecuteJavascript(ssrs);
        }

        [When(@"Root Administration menu External Systems sub menu Elastic Search submenu is Clicked")]
        public void WhenRootAdministrationMenuExternalSystemsSubMenuElasticSearchSubmenuIsClicked()
        {
            IWebElement ra = Browser.Wd.FindElement(By.XPath("//a[@title='Root Administration']"));
            fw.ExecuteJavascript(ra);

            IWebElement ssrs = Browser.Wd.FindElement(By.XPath("//a[@title='Elastic Search']"));
            fw.ExecuteJavascript(ssrs);
        }



        [When(@"Root Administration menu External Systems sub menu SSRS submenu is Clicked")]
        public void WhenRootAdministrationMenuExternalSystemsSubMenuSSRSSubmenuIsClicked()
        {
            IWebElement ra = Browser.Wd.FindElement(By.XPath("//a[@title='Root Administration']"));
            fw.ExecuteJavascript(ra);

            IWebElement ssrs = Browser.Wd.FindElement(By.XPath("//a[@title='SSRS']"));
            fw.ExecuteJavascript(ssrs);

        }

        [When(@"Root Administration menu External Systems sub menu SSIS submenu is Clicked")]
        public void WhenRootAdministrationMenuExternalSystemsSubMenuSSISSubmenuIsClicked()
        {
            IWebElement ra = Browser.Wd.FindElement(By.XPath("//a[@title='Root Administration']"));
            fw.ExecuteJavascript(ra);

            IWebElement ssis = Browser.Wd.FindElement(By.XPath("//a[@title='SSIS']"));
            fw.ExecuteJavascript(ssis);
        }

        [When(@"Root Administration menu External Systems sub menu Workflow Engine submenu is Clicked")]
        public void WhenRootAdministrationMenuExternalSystemsSubMenuWorkflowEngineSubmenuIsClicked()
        {
            IWebElement ra = Browser.Wd.FindElement(By.XPath("//a[@title='Root Administration']"));
            fw.ExecuteJavascript(ra);

            IWebElement we = Browser.Wd.FindElement(By.XPath("//a[@title='Workflow Engine']"));
            fw.ExecuteJavascript(we);
        }


        [When(@"External Systems SSRS page Configuration Name is set to ""(.*)""")]
        public void WhenExternalSystemsSSRSPageConfigurationNameIsSetTo(string p0)
        {
            string ssrs = tmsCommon.GenerateData(p0);
            IWebElement ra = Browser.Wd.FindElement(By.CssSelector("[test-id='ssrs-txt-configurationname']"));
            ra.SendKeys(ssrs);
        }

        [When(@"External Systems Identity Server page Configuration Name is set to ""(.*)""")]
        public void WhenExternalSystemsIdentityServerPageConfigurationNameIsSetTo(string p0)
        {
            string ssrs = tmsCommon.GenerateData(p0);
            IWebElement ra = Browser.Wd.FindElement(By.CssSelector("[test-id='identityserver-txt-configurationname']"));
            ra.SendKeys(ssrs);
        }

        [When(@"External Systems Elastic Search page Configuration Name is set to ""(.*)""")]
        public void WhenExternalSystemsElasticSearchPageConfigurationNameIsSetTo(string p0)
        {
            string ssrs = tmsCommon.GenerateData(p0);
            IWebElement ra = Browser.Wd.FindElement(By.CssSelector("[test-id='elasticsearch-txt-configurationname']"));
            ra.SendKeys(ssrs);
        }


        [When(@"External Systems Redis page Configuration Name is set to ""(.*)""")]
        public void WhenExternalSystemsRedisPageConfigurationNameIsSetTo(string p0)
        {
            string config = tmsCommon.GenerateData(p0);
            IWebElement ra = Browser.Wd.FindElement(By.CssSelector("[test-id='redis-txt-configurationname']"));
            ra.SendKeys(config);
        }

        [When(@"External Systems Identity Server page Discovery URL is entered")]
        public void WhenExternalSystemsIdentityServerPageDiscoveryURLIsEntered()
        {
            IWebElement Dis = Browser.Wd.FindElement(By.CssSelector("[test-id='identityserver-txt-discoverurl']"));
            Dis.SendKeys(ConfigFile.URL);

        }

        [When(@"External Systems Redis page User Name is entered")]
        public void WhenExternalSystemsRedisPageUserNameIsEntered()
        {
            IWebElement Dis = Browser.Wd.FindElement(By.CssSelector("[test-id='redis-txt-userName']"));
            Dis.SendKeys(ConfigFile.UserId);
        }
        [When(@"External Systems Elastic Search page User Name is entered")]
        public void WhenExternalSystemsElasticSearchPageUserNameIsEntered()
        {
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='elasticsearch-txt-userName']"));
            ele.SendKeys(ConfigFile.UserId);
        }

        [When(@"External Systems Elastic Search page Password is entered")]
        public void WhenExternalSystemsElasticSearchPagePasswordIsEntered()
        {
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='elasticsearch-txt-passWord']"));
            ele.SendKeys(ConfigFile.Password);
        }

        [When(@"External Systems Redis page Password is entered")]
        public void WhenExternalSystemsRedisPagePasswordIsEntered()
        {
            IWebElement Dis = Browser.Wd.FindElement(By.CssSelector("[test-id='redis-txt-passWord']"));
            Dis.SendKeys(ConfigFile.Password);
        }

        [When(@"External Systems Redis page Save button is Clicked")]
        public void WhenExternalSystemsRedisPageSaveButtonIsClicked()
        {
            IWebElement Dis = Browser.Wd.FindElement(By.CssSelector("[test-id='redis-btn-Save']"));
            fw.ExecuteJavascript(Dis);
        }
        [When(@"External Systems Elastic Search page Save button is Clicked")]
        public void WhenExternalSystemsElasticSearchPageSaveButtonIsClicked()
        {
            IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='elasticsearch-btn-save']"));
            fw.ExecuteJavascript(elem);
        }


        [When(@"External Systems Identity Server page Administration URL is entered")]
        public void WhenExternalSystemsIdentityServerPageAdministrationURLIsEntered()
        {
            IWebElement admin = Browser.Wd.FindElement(By.CssSelector("[test-id='identityserver-txt-applicationurl']"));
            admin.SendKeys(ConfigFile.URL);
        }

        [When(@"External Systems Identity Server page Change Password URL is entered")]
        public void WhenExternalSystemsIdentityServerPageChangePasswordURLIsEntered()
        {
            IWebElement admin = Browser.Wd.FindElement(By.CssSelector("[test-id='identityserver-txt-changePasswordUrl']"));
            admin.SendKeys(ConfigFile.URL);
        }

        [When(@"External Systems Identity Server page Save button is Clicked")]
        public void WhenExternalSystemsIdentityServerPageSaveButtonIsClicked()
        {

            IWebElement save = Browser.Wd.FindElement(By.CssSelector("[test-id='identityserver-btn-save']"));
            fw.ExecuteJavascript(save);
        }


        [When(@"External Systems SSRS page Reporting Services Server is Entered")]
        public void WhenExternalSystemsSSRSPageReportingServicesServerIsEntered()
        {
            IWebElement rss = Browser.Wd.FindElement(By.CssSelector("[test-id='ssrs-txt-reportingservicesserver']"));
            string reportingserver = ConfigFile.URL.Split('/')[2].Split('.')[1];
            rss.SendKeys(reportingserver);

        }

        [When(@"External Systems SSRS page Reporting Services URL is Entered")]
        public void WhenExternalSystemsSSRSPageReportingServicesURLIsEntered()
        {
            IWebElement rss = Browser.Wd.FindElement(By.CssSelector("[test-id='ssrs-txt-reportingservicesurl']"));
            string reportingserver = "http://"+ConfigFile.URL.Split('/')[2].Split('.')[1]+ ".dev.trizetto.com/ReportServer/ReportService2005.asmx";
            rss.SendKeys(reportingserver);
        }

        [Then(@"Verify SSIS page displayed Configuration Name Text box")]
        public void ThenVerifySSISPageDisplayedConfigurationNameTextBox()
        {
            IWebElement config = Browser.Wd.FindElement(By.CssSelector("[test-id='ssis-txt-configurationname']"));
            Assert.IsTrue(config.Displayed, "Expected Toaster message is not getting displayed");
        }

        [Then(@"Verify Workflow Engine page displayed Configuration Name Text box")]
        public void ThenVerifyWorkflowEnginePageDisplayedConfigurationNameTextBox()
        {
            IWebElement config = Browser.Wd.FindElement(By.CssSelector("[test-id='workflowEngine-txt-configurationName']"));
            Assert.IsTrue(config.Displayed, "Expected compoent is not getting displayed");
        }

        [Then(@"Verify Workflow Engine page displayed Application URL Text box")]
        public void ThenVerifyWorkflowEnginePageDisplayedApplicationURLTextBox()
        {
            IWebElement config = Browser.Wd.FindElement(By.CssSelector("[test-id='workflowEngine-txt-applicationUrl']"));
            Assert.IsTrue(config.Displayed, "Expected compoent is not getting displayed");
        }

        [Then(@"Verify Workflow Engine page displayed Service Endpoint URL Text box")]
        public void ThenVerifyWorkflowEnginePageDisplayedServiceEndpointURLTextBox()
        {
            IWebElement config = Browser.Wd.FindElement(By.CssSelector("[test-id='workflowEngine-txt-serviceEndpointUrl']"));
            Assert.IsTrue(config.Displayed, "Expected compoent is not getting displayed");
        }

        [Then(@"Verify Workflow Engine page displayed Save button")]
        public void ThenVerifyWorkflowEnginePageDisplayedSaveButton()
        {
            IWebElement config = Browser.Wd.FindElement(By.CssSelector("[test-id='workflowEngine-button-search']"));
            Assert.IsTrue(config.Displayed, "Expected compoent is not getting displayed");
        }


        [When(@"SSIS page Configuration Name is set to ""(.*)""")]
        public void WhenSSISPageConfigurationNameIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            IWebElement config = Browser.Wd.FindElement(By.CssSelector("[test-id='ssis-txt-configurationname']"));
            config.SendKeys(value);
        }

        [When(@"SSIS page Integration Services Server is entered")]
        public void WhenSSISPageIntegrationServicesServerIsEntered()
        {
            IWebElement iss = Browser.Wd.FindElement(By.CssSelector("[test-id='ssis-txt-integrationservicesserver']"));
            string isserver = ConfigFile.URL.Split('/')[2].Split('.')[1];
            iss.SendKeys(isserver);

        }


        [Then(@"Verify SSIS page displayed Integration Services Server Text box")]
        public void ThenVerifySSISPageDisplayedIntegrationServicesServerTextBox()
        {
            IWebElement config = Browser.Wd.FindElement(By.CssSelector("[test-id='ssis-txt-integrationservicesserver']"));
            Assert.IsTrue(config.Displayed, "Expected Toaster message is not getting displayed");
        }

        [Then(@"Verify SSIS page displayed Save button")]
        public void ThenVerifySSISPageDisplayedSaveButton()
        {
            IWebElement save = Browser.Wd.FindElement(By.CssSelector("[test-id='ssis-btn-save']"));
            Assert.IsTrue(save.Displayed, "Expected Toaster message is not getting displayed");
        }

        [When(@"SSIS page save button is Clicked")]
        public void WhenSSISPageSaveButtonIsClicked()
        {
            IWebElement save = Browser.Wd.FindElement(By.CssSelector("[test-id='ssis-btn-save']"));
            fw.ExecuteJavascript(save);
        }



        [When(@"External Systems SSRS page Save button is Clicked")]
        public void WhenExternalSystemsSSRSPageSaveButtonIsClicked()
        {
            IWebElement save = Browser.Wd.FindElement(By.CssSelector("[test-id='ssrs-btn-save']"));
            fw.ExecuteJavascript(save);
        }

        [Then(@"Verify Application displayed ""(.*)""")]
        public void ThenVerifyApplicationDisplayed(string p0)
        {
            tmsWait.Hard(1);
            IWebElement toaster = Browser.Wd.FindElement(By.XPath("//div[@class='toast-message'][contains(.,'"+p0+"')]"));
            Assert.IsTrue(toaster.Displayed, "Expected Toaster message is not getting displayed");

        }


        [Given(@"Manage Configuration page Workflow Engine is set as ""(.*)""")]
        public void GivenManageConfigurationPageWorkflowEngineIsSetAs(string wf)
        {
            tmsWait.Hard(2);
            fw.KendoSelectByValue(Browser.Wd, TmsFramework.ManageConfiguration.WFEngineDropdown, wf);
        }

        [When(@"Manage Configuration page Core System is set as ""(.*)""")]
        [Given(@"Manage Configuration page Core System is set as ""(.*)""")]
        public void GivenManageConfigurationPageCoreSystemIsSetAs(string cs)
        {
            tmsWait.Hard(2);
            fw.KendoSelectByValue(Browser.Wd, TmsFramework.ManageConfiguration.CoreSystemDropdown, cs);
        }

        [Given(@"Manage Configuration page TCS is set as ""(.*)""")]
        public void GivenManageConfigurationPageTCSIsSetAs(string tcs)
        {
            tmsWait.Hard(2);
            fw.KendoSelectByValue(Browser.Wd, TmsFramework.ManageConfiguration.TCSDropdown, tcs);
        }

        [Given(@"Manage Configuration page Identity Server is set as ""(.*)""")]
        public void GivenManageConfigurationPageIdentityServerIsSetAs(string identity)
        {
            tmsWait.Hard(2);
            fw.KendoSelectByValue(Browser.Wd, TmsFramework.ManageConfiguration.IdentityServerDropdown, identity);
        }

        [Given(@"Manage Configuration page Redis is set as ""(.*)""")]
        public void GivenManageConfigurationPageRedisIsSetAs(string redis)
        {
            tmsWait.Hard(2);
            fw.KendoSelectByValue(Browser.Wd, TmsFramework.ManageConfiguration.RedisDropdown, redis);
        }

        [Given(@"Manage Configuration page File Root Path is set")]
        [When(@"Manage Configuration page File Root Path is set")]
        public void GivenManageConfigurationPageFileRootPathIsSet()
        {
            tmsWait.WaitForElement(By.Id("txtfileRootPath"),300);
            string appServerUrl = ConfigFile.URL;
            int index = appServerUrl.IndexOf('/');
            int index2 = appServerUrl.IndexOf('/', index + 1);

            string subs = appServerUrl.Substring(index2 + 1, 32);
            string[] path=subs.Split('.');
            TmsFramework.ManageConfiguration.FileRootPathTextbpx.Clear();
            TmsFramework.ManageConfiguration.FileRootPathTextbpx.SendKeys("\\\\" + path[1] + "\\TMSShareFolder\\");
        }

        [Given(@"Manage Configuration page Back button is clicked")]
        [When(@"Manage Configuration page Back button is clicked")]
        public void GivenManageConfigurationPageBackButtonIsClicked()
        {
            fw.ExecuteJavascript(TmsFramework.ManageConfiguration.BackToRecordButton);
        }

        [Given(@"Manage Configuration page Save button is clicked")]
        [When(@"Manage Configuration page Save button is clicked")]
        public void GivenManageConfigurationPageSaveButtonIsClicked()
        {
            fw.ExecuteJavascript(TmsFramework.ManageConfiguration.SaveButton);
        }

        [Given(@"Root Administration External Systems link is expand")]
        public void GivenRootAdministrationExternalSystemsLinkIsExpand()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//i[@test-id='menu-26']")));
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'External Systems ')]")));
        }


        [Then(@"Verfiy that ""(.*)"" page displayed")]
        public void ThenVerfiyThatPageDisplayed(string p0)
        {
            tmsWait.Hard(4);
            string actualText = TmsFramework.ManageConfiguration.adminTitle.Text;
            Assert.AreEqual(actualText, p0.ToString(), "Admin Title wrong displayed");
        }

        [When(@"Root Administration - External Systems page ""(.*)"" radio button is selected")]
        public void WhenRootAdministration_ExternalSystemsPageRadioButtonIsSelected(string p0)
        {
           
            fw.ExecuteJavascript(TmsFramework.ManageConfiguration.radioQnxt1);
            tmsWait.Hard(2);
        }
        [When(@"Root Administration - External Systems page ""(.*)"" button is clicked")]
        public void WhenRootAdministration_ExternalSystemsPageButtonIsClicked(string p0)
        {
            
            IWebElement edit = Browser.Wd.FindElement(By.XPath("//td[@aria-colindex='2']/a[1]"));
            fw.ExecuteJavascript(edit);
        }


        [When(@"Root Administration - External Systems page Configuration Name enter as ""(.*)""")]
        public void WhenRootAdministration_ExternalSystemsPageConfigurationNameEnterAs(string p0)
        {
            string Configname = tmsCommon.GenerateData(p0);
            TmsFramework.ManageConfiguration.configurationnameqnext.Clear();
            TmsFramework.ManageConfiguration.configurationnameqnext.SendKeys(Configname);
        }
        [When(@"Root Administration - External Systems page URL enter as ""(.*)""")]
        public void WhenRootAdministration_ExternalSystemsPageURLEnterAs(string p0)
        {
            string URL = tmsCommon.GenerateData(p0);
            TmsFramework.ManageConfiguration.txtURL.Clear();
            TmsFramework.ManageConfiguration.txtURL.SendKeys(URL);
        }

        [When(@"Root Administration - External Systems page QNEXT page Save button clicked")]
        public void WhenRootAdministration_ExternalSystemsPageQNEXTPageSaveButtonClicked()
        {
            fw.ExecuteJavascript(TmsFramework.ManageConfiguration.coresystemSaveButton);
            tmsWait.Hard(5);
        }

        [Then(@"Verfiy that Root Administration - External Systems page displayed the ""(.*)""")]
        public void ThenVerfiyThatRootAdministration_ExternalSystemsPageDisplayedThe(string p0)
        {
           string confgName = tmsCommon.GenerateData(p0);
           string configname_xpath = "//td[@role='gridcell'][contains(.,'" + confgName + "')]";
           Assert.IsTrue(Browser.Wd.FindElement(By.XPath(configname_xpath)).Displayed);
           
        }


    }
}
