﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using TechTalk.SpecFlow;

namespace TMSoR1
{
    [Binding]
    class fsTMSAdmin
    {
        [Given(@"I am logged in TMS Administration by Userid ""(.*)"" and password is ""(.*)""")]
        public void GivenIAmLoggedInTMSAdministrationByUseridAndPasswordIs(string p0, string p1)
        {
            string GeneratedUserID = tmsCommon.GenerateData(p0);
            Navigation.navigate();
            TmsFramework.TMSLogin.UserNameTextbox.Clear();
            TmsFramework.TMSLogin.UserNameTextbox.SendKeys(GeneratedUserID);
            TmsFramework.TMSLogin.PasswordTextbox.Clear();
            TmsFramework.TMSLogin.PasswordTextbox.SendKeys(p1);
            TmsFramework.TMSLogin.LoginButton.Click();
        }

        [Given(@"I have navigated to ""(.*)"" page")]
        public void GivenIHaveNavigatedToPage(string page)
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + page + "')]")));
            
            tmsWait.Hard(5);
        }

        [When(@"Root Administration page External Systems menu ""(.*)"" submenu is Clicked")]
        public void WhenRootAdministrationPageExternalSystemsMenuSubmenuIsClicked(string p0)
        {
            tmsWait.Hard(5);
            //IWebElement menu = Browser.Wd.FindElement(By.XPath("//a[@title='Root Administration']"));
            //fw.ExecuteJavascript(menu);

            
            IWebElement submenu = Browser.Wd.FindElement(By.XPath("//a[@title='"+p0+"']"));
            fw.ExecuteJavascript(submenu);
        }

        [When(@"Root Administration - External Systems page Current Tenant configuration name Action is Clicked")]
        public void WhenRootAdministration_ExternalSystemsPageCurrentTenantConfigurationNameActionIsClicked()
        {
            IWebElement Next = null;
            bool nextPage = false;
            string AppURL = ConfigFile.URL;
            string[] lines = AppURL.Split('.');
            string tenantName = lines[0].Substring(8);
            do
            {
                nextPage = verifyActionPresence(tenantName); // First verify Element presence
                if (nextPage)
                {
                    Next = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    fw.ExecuteJavascript(Next);
                }

            } while (nextPage);

            IWebElement tenantAction = Browser.Wd.FindElement(By.XPath("(//div[@test-id='identityserver-grid-grdidentityserver']//td/span[contains(.,'" + tenantName + "')]/parent::td/following-sibling::td/a)[1]"));
            fw.ExecuteJavascript(tenantAction);

            tmsWait.Hard(5);                     
            Browser.SwitchToWindow(1);
            string childwindow = Browser.Wd.Title;

        }
        /// <summary>
        /// It will verify Element presence on Web page
        /// </summary>
        /// <param name="tenantName"></param>
        /// <returns></returns>
        public bool verifyActionPresence(string tenantName)
        {
            try
            {
                if (Browser.Wd.FindElement(By.XPath("(//div[@test-id='identityserver-grid-grdidentityserver']//td/span[contains(.,'" + tenantName + "')]/parent::td/following-sibling::td/a)[1]")).Displayed)
                {
                    // If Element is presence, It will return false to proceed Next Iteration

                    return false;

                }
            }
            catch (Exception ex)
            {
                // If Element is not presence, It will return true to exit from while loop
                return true;
            }
            return true;

        }


        [Then(@"Verify Error Page contains Message ""(.*)""")]
        public void ThenVerifyErrorPageContainsMessage(string p0)
        {
            string expectedMessage = tmsCommon.GenerateData(p0);
            bool ispresent = false;
            try
            {
                ispresent = Browser.Wd.FindElement(By.XPath("//p[contains(.,'"+expectedMessage+"')]")).Displayed;
            }

            catch
            {

            }

            Assert.IsTrue(ispresent, "Expected Message is not displayed");
            
        }

        [When(@"Error Page Logout button is clicked")]
        public void WhenErrorPageLogoutButtonIsClicked()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[contains(@href,'logout')]")));
            tmsWait.Hard(5);
        }

        [Then(@"Verify TMS Application Logout page is displayed with Message ""(.*)"" and Message ""(.*)""")]
        public void ThenVerifyTMSApplicationLogoutPageIsDisplayedWithMessageAndMessage(string p0, string p1)
        {
            string expectedMessage_1 = tmsCommon.GenerateData(p0);
            string expectedMessage_2 = tmsCommon.GenerateData(p1);
            bool ispresent_1 = false;
            bool ispresent_2 = false;
            try
            {
                ispresent_1 = Browser.Wd.FindElement(By.XPath("//h4[contains(.,'" + expectedMessage_1 + "')]")).Displayed;
                ispresent_2 = Browser.Wd.FindElement(By.XPath("//a[contains(.,'here')]/parent::div[contains(.,'"+ expectedMessage_2 + "')]")).Displayed;
            }
            
            catch
            {

            }

            Assert.IsTrue(ispresent_1, "Expected Message is not displayed");
            Assert.IsTrue(ispresent_2, "Expected Message is not displayed");
        }


        [When(@"TMS Application Logout page Click here link is clicked")]
        public void WhenTMSApplicationLogoutPageClickHereLinkIsClicked()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[contains(.,'here')]")));
            tmsWait.Hard(5);
        }

        [Then(@"Verify TMS Application Login page is displayed")]
        public void ThenVerifyTMSApplicationLoginPageIsDisplayed()
        {
            bool ispresent = false;
            try
            {
                ispresent = Browser.Wd.FindElement(By.XPath("(//button[contains(.,'Login')])[1]")).Displayed;
            }

            catch
            {

            }

            Assert.IsTrue(ispresent, "Expected Message is not displayed");
        }


    }
}
