﻿using OpenQA.Selenium;
using TechTalk.SpecFlow;

namespace TMSoR1
{
    class TmsFramework
    {
        public static TMSFrameworkHomepage TMSFrameworkHomepage { get { return new TMSFrameworkHomepage(); } }
        public static InternalDatabses InternalDatabses {  get { return new InternalDatabses(); } }
        public static TenantSetup TenantSetup {  get { return new TenantSetup(); } }
        public static TMSLogin TMSLogin { get { return new TMSLogin(); } }
        public static ManageConfiguration ManageConfiguration { get { return new ManageConfiguration(); } }
        public static TenantConfiguration TenantConfiguration { get { return new TenantConfiguration(); } }
        
    }

    [Binding]
    public class TMSFrameworkHomepage
    {
         public IWebElement MenuLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='header-btn-expanMenu']")); } }
         public IWebElement TzLogo { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='header-img-TZLogo']")); } }
         public IWebElement MenuDashboard { get { return Browser.Wd.FindElement(By.XPath("//span[contains(., 'Dashboard')]")); } }
         public IWebElement MenuRootAdministration { get { return Browser.Wd.FindElement(By.XPath("//span[contains(., 'Root Administration')]")); } } 
         public IWebElement MenuTenantAdministration { get { return Browser.Wd.FindElement(By.XPath("//span[contains(., 'Tenant Administration')]")); } }
         public IWebElement MenuDBVersion { get { return Browser.Wd.FindElement(By.XPath("//span[contains(., 'DB Versions')]")); } }
         public IWebElement MenuJobs { get { return Browser.Wd.FindElement(By.XPath("//span[contains(., 'Jobs')]")); } }
         public IWebElement UserProfile { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='header-txt-profileInfo']")); } }
         public IWebElement Help { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='header-btn-help']")); } }
         public IWebElement Info { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='header-btn-information']")); } }
         public IWebElement  Logout { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='header-btn-logOut']")); } }
        public IWebElement TenantAdminmenu { get { return Browser.Wd.FindElement(By.XPath("//div[@title='Tenant Administration']")); } }
        public IWebElement RoottAdminmenu { get { return Browser.Wd.FindElement(By.XPath("//div[@title='Root Administration']")); } }

    }
    [Binding]
    public class ExternalSystems
    {
        public IWebElement TCSSubMenu { get { return Browser.Wd.FindElement(By.XPath("//li[@test-id ='subMenuEx-10']/a")); } }
        public IWebElement TCSPageheader { get { return Browser.Wd.FindElement(By.XPath("//div[contains(text(),'Root Administration - External Systems')]")); } }
        public IWebElement TCSPageTitlebar { get { return Browser.Wd.FindElement(By.XPath("//div[contains(text(),'Root Administration - External Systems')]/following-sibling::div//span[contains(text() ,'TCS') ]")); } }
        public IWebElement TCSConfigTable { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='grdTcsConfiguration']/table")); } }
        public IWebElement TCSConfigName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='configurationNames-txt-configurationName']")); } }
        public IWebElement TCSConfigUrl { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'tcs-txt-applicationUrl']")); } }
        public IWebElement TCSSAVEBtnl { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'tcs-button-search']")); } }
        public IWebElement TCSForm { get { return Browser.Wd.FindElement(By.Id("TcsFrm")); } }
    }

    [Binding]
    public class TenantSetup
    {
        public IWebElement Title {  get { return Browser.Wd.FindElement(By.XPath("//span[contains(., 'Tenant Setup')]")); } }
        public IWebElement AddNewTenantTextbox {  get { return Browser.Wd.FindElement(By.CssSelector("[test-id='tenantSetup-txt-tenantName']")); } }
        public IWebElement AddTenantButton {  get { return Browser.Wd.FindElement(By.CssSelector("[test-id='tenantSetup-btn-save']")); } }
        public IWebElement BtnReset {  get { return Browser.Wd.FindElement(By.CssSelector("[test-id='tenantSetup-btn-reset']")); } }
        public IWebElement ToastMessage { get { return Browser.Wd.FindElement(By.CssSelector("div[class='toast-message']")); } }
        public IWebElement tenanatSetUpMenuLink { get { return Browser.Wd.FindElement(By.XPath("//ul[@test-id = 'subMenu-titleList']//a[@title= 'Tenant Set-up']")); } }
        public IWebElement tenanatSetUpTable { get { return Browser.Wd.FindElement(By.XPath("//*[@id='grdTenantSetUp']//table")); } }
        public IWebElement TCSDropdwnTenantSetUp { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='ddlTcs_listbox']")); } }
    }


    [Binding]
    public class TMSLogin
    {
        public IWebElement UserNameTextbox { get { return Browser.Wd.FindElement(By.Id("username")); } }
        public IWebElement PasswordTextbox { get { return Browser.Wd.FindElement(By.Id("password")); } }
        public IWebElement LoginButton { get { return Browser.Wd.FindElement(By.CssSelector("button[test-id='login-btn-login']")); } }
    }


    [Binding]
    public class InternalDatabses
    {

        public IWebElement TenantDropdown { get { return Browser.Wd.FindElement(By.CssSelector("select[test-id='internalDatabases-select-tenant']")); } }
        public IWebElement ExpandApplication { get { return Browser.Wd.FindElement(By.CssSelector("div[test-id='internalDatabases-accordion-Application'] i")); } }
        public IWebElement ConfigurationNameTextbox { get { return Browser.Wd.FindElement(By.XPath("//*[@id='mainContant']/div[1]/div/div/div[2]/div/div[3]/div/div/div[2]/div/accordion/div/div[2]/div[2]/div/database-authentication/div/div[1]/div[1]/div/div/input")); } }
        public IWebElement DatabaseNameTextbox { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='internalDatabases-lbl-databasesName']/parent::div/div/input[@test-id='internalDatabases-input-databasesName']")); } }
        public IWebElement DatabaseServerTextbox { get { return Browser.Wd.FindElement(By.CssSelector("input[test-id='internalDatabases-input-databaseServer']")); } }
        public IWebElement AuthenticationDropdown { get { return Browser.Wd.FindElement(By.CssSelector("input[test-id='internalDatabases-select-Authentication']")); } }
        public IWebElement SaveButton { get { return Browser.Wd.FindElement(By.CssSelector("input[test-id='internalDatabases-btn-Save']")); } }
        public IWebElement ToastMessage { get { return Browser.Wd.FindElement(By.CssSelector("div[class='toast-message']")); } }
        public IWebElement Title {  get { return Browser.Wd.FindElement(By.CssSelector("[test-id='internalDatabases-span-internalDatabase']")); } }
        public IWebElement SelectTenant {  get { return Browser.Wd.FindElement(By.CssSelector("[test-id='internalDatabases-select-tenant']")); } }
        //public IWebElement FoundationAccordion { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='internalDatabases-span-Foundation']")); } }
        public IWebElement FoundationAccordion { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Foundation')]")); } }
        public IWebElement ApplicationAccordion { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='internalDatabases-span-Application']")); } }
        public IWebElement Tenant {  get { return Browser.Wd.FindElement(By.CssSelector("[test-id='internalDatabases-select-tenant']")); } }
        public IWebElement StagingTab {  get { return Browser.Wd.FindElement(By.CssSelector("[test-id='internalDatabases-tab-Staging']")); } }
        public IWebElement OperationalTab { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Operational')]")); } }
        public IWebElement WarehouseTab { get { return Browser.Wd.FindElement(By.CssSelector("[id='k-tabstrip-tab-2']")); } }
        public IWebElement StagingConfigName {  get { return Browser.Wd.FindElement(By.XPath("(//input[@test-id='internalDatabases-input-configurationName'])[1]")); } }
        public IWebElement StagingdbName { get { return Browser.Wd.FindElement(By.XPath("(//input[@test-id= 'internalDatabases-input-databasesName'])[1]")); } }
        public IWebElement StagingdbServer { get { return Browser.Wd.FindElement(By.XPath("(//input[@test-id= 'internalDatabases-input-databaseServer'])[1]")); } }
        public IWebElement StagingAuthentication { get { return Browser.Wd.FindElement(By.XPath("(//select[@test-id= 'internalDatabases-select-Authentication'])[1]")); } }
        public IWebElement StagingdbUser { get { return Browser.Wd.FindElement(By.XPath("(//input[@test-id= 'internalDatabases-input-databaseUser'])[1]")); } }
        public  IWebElement StagingdbPassword { get { return Browser.Wd.FindElement(By.XPath("(//input[@test-id='internalDatabases-input-Password'])[1]")); } }
        public IWebElement StagingTestConnectionBtn { get { return Browser.Wd.FindElement(By.XPath("(//button[@test-id='internalDatabases-btn-TestConnection'])[3]")); } }
        public IWebElement StaginSaveBtn { get { return Browser.Wd.FindElement(By.XPath("(//button[@test-id='internalDatabases-btn-Save'])[1]")); } }
        public IWebElement StagingResetBtn { get { return Browser.Wd.FindElement(By.XPath("(//button[@test-id='internalDatabases-btn-Reset'])[1]")); } }
        public IWebElement FoundationConfigName { get { return Browser.Wd.FindElement(By.XPath("(//input[@test-id='internalDatabases-input-configurationName'])[2]")); } }
        public IWebElement FoundationdbName { get { return Browser.Wd.FindElement(By.XPath("(//input[@test-id= 'internalDatabases-input-databasesName'])[2]")); } }
        public IWebElement FoundationdbServer { get { return Browser.Wd.FindElement(By.XPath("(//input[@test-id= 'internalDatabases-input-databaseServer'])[2]")); } }
        public IWebElement FoundationAuthentication { get { return Browser.Wd.FindElement(By.XPath("(//select[@test-id= 'internalDatabases-select-Authentication'])[2]")); } }
        public IWebElement FounationdbUser { get { return Browser.Wd.FindElement(By.XPath("(//input[@test-id= 'internalDatabases-input-databaseUser'])[2]")); } }
        public IWebElement FoundationdbPassword { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='internalDatabases-input-Password']")); } }
        public IWebElement FoundationTestConnectionBtn { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='internalDatabases-btn-TestConnection']")); } }
        public IWebElement FoundationSaveBtn { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='internalDatabases-btn-Save']")); } }
        public IWebElement FoundationResetBtn { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='internalDatabases-btn-Reset']")); } }
        public IWebElement ApplicationConfigName { get { return Browser.Wd.FindElement(By.XPath("(//input[@test-id='internalDatabases-input-configurationName'])[3]")); } }
        public IWebElement ApplicationdbName { get { return Browser.Wd.FindElement(By.XPath("(//input[@test-id= 'internalDatabases-input-databasesName'])[3]")); } }
        public IWebElement ApplicationdbServer { get { return Browser.Wd.FindElement(By.XPath("(//input[@test-id= 'internalDatabases-input-databaseServer'])[3]")); } }
        public IWebElement ApplicationAuthentication { get { return Browser.Wd.FindElement(By.XPath("(//select[@test-id= 'internalDatabases-select-Authentication'])[3]")); } }
        public IWebElement ApplicationdbUser { get { return Browser.Wd.FindElement(By.XPath("(//input[@test-id= 'internalDatabases-input-databaseUser'])[3]")); } }
        public IWebElement ApplicationdbPassword { get { return Browser.Wd.FindElement(By.XPath("(//input[@test-id='internalDatabases-input-Password'])[3]")); } }
        public IWebElement ApplicationTestConnectionBtn { get { return Browser.Wd.FindElement(By.XPath("(//button[@test-id='internalDatabases-btn-TestConnection'])[3]")); } }
        public IWebElement ApplicationSaveBtn { get { return Browser.Wd.FindElement(By.XPath("(//button[@test-id='internalDatabases-btn-Save'])[3]")); } }
        public IWebElement ApplicationResetBtn { get { return Browser.Wd.FindElement(By.XPath("(//button[@test-id='internalDatabases-btn-Reset'])[3]")); } }
        public IWebElement ApplicationUpdateBtn {  get { return Browser.Wd.FindElement(By.XPath("//div[@test-id='internalDatabases-accordion-Application']//button[contains(., 'UPDATE')]")); } }
        public IWebElement DwConfigName { get { return Browser.Wd.FindElement(By.XPath("(//input[@test-id='internalDatabases-input-configurationName'])[4]")); } }
        public IWebElement DwdbName { get { return Browser.Wd.FindElement(By.XPath("(//input[@test-id= 'internalDatabases-input-databasesName'])[4]")); } }
        public IWebElement DwdbServer { get { return Browser.Wd.FindElement(By.XPath("(//input[@test-id= 'internalDatabases-input-databaseServer'])[4]")); } }
        public IWebElement DwAuthentication { get { return Browser.Wd.FindElement(By.XPath("(//select[@test-id= 'internalDatabases-select-Authentication'])[4]")); } }
        public IWebElement DwdbUser { get { return Browser.Wd.FindElement(By.XPath("(//input[@test-id= 'internalDatabases-input-databaseUser'])[4]")); } }
        public IWebElement DwdbPassword { get { return Browser.Wd.FindElement(By.XPath("(//input[@test-id='internalDatabases-input-Password'])[4]")); } }
        public IWebElement DwTestConnection { get { return Browser.Wd.FindElement(By.XPath("(//button[@test-id='internalDatabases-btn-TestConnection'])[4]")); } }
        public IWebElement DwSaveBtn { get { return Browser.Wd.FindElement(By.XPath("(//button[@test-id='internalDatabases-btn-Save'])[4]")); } }
        public IWebElement DwResetBtn { get { return Browser.Wd.FindElement(By.XPath("(//button[@test-id='internalDatabases-btn-Reset'])[4]")); } }
        public IWebElement DwUpdateBtn { get { return Browser.Wd.FindElement(By.XPath("//div[@test-id='internalDatabases-accordion-Warehouse']//button[contains(., 'UPDATE')]")); } }
        public IWebElement GreenMark {  get { return Browser.Wd.FindElement(By.CssSelector("//span[contains(@class, 'ng-scope')]")); } }
        public IWebElement SaveBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='internalDatabases-btn-Save']")); } }
        public IWebElement ResetBtn {  get { return Browser.Wd.FindElement(By.CssSelector("[test-id='internalDatabases-btn-Reset']")); } }
        public IWebElement DatabaseGrid { get { return Browser.Wd.FindElement(By.CssSelector("//div[@test-id='internalDatabases-grid-foundation']")); } }
        public IWebElement TestConnectionSuccessfull { get { return Browser.Wd.FindElement(By.XPath(".//div[@id='toast-container'][contains(., 'Test connection successfull')]")); } }
        public IWebElement FailedToLoginErrorMsg { get { return Browser.Wd.FindElement(By.XPath(".//div[@id='toast-container'][contains(., 'Failed to login to the specified database. Please verify')]")); } }
        public IWebElement UpdateConfigurationMsg { get { return Browser.Wd.FindElement(By.XPath(".//div[@id='toast-container'][contains(., 'Configuration updated successfully')]")); } }
        public IWebElement AlertAccpetForDeleteDb {  get { return Browser.Wd.FindElement(By.CssSelector("[test-id='confirmationDialog-btn-Yes']")); } }
        public IWebElement FoundationGridNoItemdisplayMsg {  get { return Browser.Wd.FindElement(By.XPath("//div[@id='grdFoundationDb']//span[contains(.,'No items to display')]")); } }
        public IWebElement FoundationUpdateBtn { get { return Browser.Wd.FindElement(By.XPath("//div[@test-id='internalDatabases-accordion-Foundation']//button[contains(., 'UPDATE')]")); } }
    }


    [Binding]
    public class ManageConfiguration
    {
        public IWebElement FileRootPathTextbpx { get { return Browser.Wd.FindElement(By.Id("txtfileRootPath")); } }
        public IWebElement BackToRecordButton { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Back To Record')]")); } }
         public IWebElement adminTitle { get { return Browser.Wd.FindElement(By.XPath("//div[contains(@class,'adminTitle formGroup')]")); } }
        public IWebElement SaveButton { get { return Browser.Wd.FindElement(By.CssSelector("button[test-id='manageConfiguration-btn-save']")); } }
        public IWebElement SSRSDropdown { get { return Browser.Wd.FindElement(By.Id("ddlSSRS")); } }
        public IWebElement SSISDropdown { get { return Browser.Wd.FindElement(By.Id("ddlSSIS")); } }
        public IWebElement WFEngineDropdown { get { return Browser.Wd.FindElement(By.Id("ddlWorkFlow")); } }
        public IWebElement CoreSystemDropdown { get { return Browser.Wd.FindElement(By.Id("ddlCoreSystems")); } }
        public IWebElement TCSDropdown { get { return Browser.Wd.FindElement(By.Id("ddlTcs")); } }
        public IWebElement IdentityServerDropdown { get { return Browser.Wd.FindElement(By.Id("ddlIdentityServer")); } }
        public IWebElement RedisDropdown { get { return Browser.Wd.FindElement(By.Id("ddlRedis")); } }
        public IWebElement radioQnxt { get { return Browser.Wd.FindElement(By.CssSelector("input[test-id='coresystem-radio-qnxt']")); } }
        public IWebElement radioQnxt1 { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='coresystem-radio-qnxt']")); } }
        
        public IWebElement radioFacets { get { return Browser.Wd.FindElement(By.CssSelector("input[test-id='coresystem-radio-facets']")); } }
        public IWebElement configurationnameqnext { get { return Browser.Wd.FindElement(By.CssSelector("input[test-id='coresystem-txt-configurationnameqnext']")); } }
        public IWebElement txtURL { get { return Browser.Wd.FindElement(By.CssSelector("input[test-id='coresystem-txt-url']")); } }
        
        public IWebElement coresystemSaveButton { get { return Browser.Wd.FindElement(By.CssSelector("button[test-id='coresystem-btn-save']")); } }
    }


    [Binding]
    public class TenantConfiguration
    {
        public IWebElement TenantDropdown { get { return Browser.Wd.FindElement(By.CssSelector("select[test-id='tenantConfiguration-select-tenant']")); } }
        public IWebElement ApplicationDropdown { get { return Browser.Wd.FindElement(By.CssSelector("select[test-id='tenantConfiguration-select-application']")); } }
        public IWebElement AddButton { get { return Browser.Wd.FindElement(By.CssSelector("button[test-id='tenantConfiguration-btn-add']")); } }
        public IWebElement ApplicationDBDropdown { get { return Browser.Wd.FindElement(By.CssSelector("select[test-id='applicationLevelConfiguration-select-applicationDatabases']")); } }
        public IWebElement SaveButton { get { return Browser.Wd.FindElement(By.Id("btnSave")); } }
        public IWebElement DangerIcon { get { return Browser.Wd.FindElement(By.XPath("//h5[@class='fas fa-times-circle ml-2 text-danger']")); } }
        public IWebElement SuccessIcon { get { return Browser.Wd.FindElement(By.XPath("//h5[@class='fas fa-check-circle ml-2 text-success']")); } }

        
    }

    [Binding]
    public class TMSFrameworkJobs
    {
        public IWebElement FilterByJobDrpdwn { get{ return Browser.Wd.FindElement(By.CssSelector("[test-id='jobs-select-filteredbyjob']")); } }
        public IWebElement JobsResultGrid { get { return Browser.Wd.FindElement(By.XPath(".//div[@id = 'grdJobsDetails']/table")); } }
    }
}
