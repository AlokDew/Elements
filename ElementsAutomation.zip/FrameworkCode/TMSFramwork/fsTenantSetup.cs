﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.EAM
{
    [Binding]
    class fsTenantSetup
    {
        [Given(@"Tenant Setup page Add New Tenant is set to ""(.*)""")]
        [When(@"Tenant Setup page Add New Tenant is set to ""(.*)""")]
        public void GivenTenantSetupPageAddNewTenantIsSetTo(string p0)
        {
            bool nextPage = false;
            bool flagTenant = false;
            bool flagEnadPage = false;
            tmsWait.WaitForElement(By.Id("txtTenantName"), 300);
            string tenant = tmsCommon.GenerateData(p0);
            
            do
            {
                flagTenant = false;
                flagEnadPage = false;
                nextPage = VerifyTenant(tenant);
                if (!nextPage)
                {
                    flagTenant = true;
                    break;
                }
                string text = Browser.Wd.FindElement(By.CssSelector(".k-pager-info.k-label")).Text;
                string[] pages = text.Split(' ');
                if (pages[2].ToString() == pages[4].ToString())
                {
                    flagEnadPage = true;
                }
                else
                {
                    Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']")).Click();
                    flagEnadPage = false;
                }
            } while (!flagEnadPage);

            if(!flagTenant)
            {
                TmsFramework.TenantSetup.AddNewTenantTextbox.SendKeys(tenant);
                fw.ExecuteJavascript(TmsFramework.TenantSetup.AddTenantButton);
            }
        }

        [Given(@"Tenant Setup page New Tenant Add button is clicked")]
        public void GivenTenantSetupPageNewTenantAddButtonIsClicked()
        {
            fw.ExecuteJavascript(TmsFramework.TenantSetup.AddTenantButton);
            Assert.IsTrue(TmsFramework.TenantSetup.ToastMessage.Text.Contains("Tenant added successfully"));
        }

        [Then(@"Verify New Window is displayed with Title ""(.*)""")]
        public void ThenVerifyNewWindowIsDisplayedWithTitle(string expected)
        {
            tmsWait.Hard(2);
            Browser.SwitchToWindow(1);
            tmsWait.Hard(4);
            string actual = Browser.Wd.Title;
            Assert.AreEqual(actual, expected, "Both are not matching");
        }

        [When(@"TMS Framework page ""(.*)"" section is Clicked")]
        public void WhenTMSFrameworkPageSectionIsClicked(string p0)
        {
            IWebElement element = Browser.Wd.FindElement(By.XPath("//a[@title='"+p0+"']"));
            fw.ExecuteJavascript(element);
        }

        [When(@"TMS Framework page ""(.*)"" section is Displayed")]
        public void WhenTMSFrameworkPageSectionIsDisplayed(string p0)
        {
            IWebElement element = Browser.Wd.FindElement(By.XPath("//a[@title='" + p0 + "']"));
            Assert.IsTrue(element.Displayed, "Menu is not Present");
        }


        [When(@"TMS Framework page Identity Server link is Clicked")]
        public void WhenTMSFrameworkPageIdentityServerLinkIsClicked()
        {
            IWebElement element = Browser.Wd.FindElement(By.XPath("//a/span[@class='NavigateIcon NavigateIcon']"));
            fw.ExecuteJavascript(element);
        }


        [Then(@"Verify Login page displayed error mesage ""(.*)""")]
        public void ThenVerifyLoginPageDisplayedErrorMesage(string p0)
        {
            tmsWait.Hard(2);
            IWebElement element = Browser.Wd.FindElement(By.XPath("//div[contains(.,'"+p0+"')]"));
            bool actualresults = element.Displayed;
            Assert.IsTrue(actualresults, "Expected results are not getting displayed");

        }

        [Given(@"Tenant Setup page Manage Configuration link is clicked for ""(.*)""")]
        [When(@"Tenant Setup page Manage Configuration link is clicked for ""(.*)""")]
        public void GivenTenantSetupPageManageConfigurationLinkIsClickedFor(string p0)
        {
            string tenant = tmsCommon.GenerateData(p0).ToUpper();
            bool nextPage = true;
            do
            {
                nextPage = VerifyTenant(tenant.ToUpper());
                if (nextPage)
                {
                    Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']")).Click();
                }
            } while (nextPage);
            Browser.Wd.FindElement(By.XPath("//span[contains(.,'"+tenant+"')]/parent::td/following-sibling::td/a[contains(.,'Manage Configuration')]")).Click();
        }

        public bool VerifyTenant(string tenant)
        {
            try
            {
                if (Browser.Wd.FindElement(By.XPath("//span[(text()='" + tenant + "')]")).Displayed)
                {
                    return false;
                }
            }
            catch (Exception)
            {
                return true;
            }
            return true;
        }

        [When(@"Internaldatabases staging tab Edit icon is clicked for PDMUpload")]
        public void WhenInternaldatabasesStagingTabEditIconIsClickedForPDMUpload()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='internalDatabases-grid-staging']//td//span[@class='fas fa-pencil-alt'])[1]")));
            tmsWait.Hard(2);
        }

        [When(@"Internaldatabases operational tab Edit icon is clicked for TMSOperational")]
        public void WhenInternaldatabasesOperationalTabEditIconIsClickedForTMSOperational()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='internalDatabases-grid-foundation']//td/a/span[@class='fas fa-pencil-alt']")));
            tmsWait.Hard(2);
        }

        [Then(@"Internaldatabases tenant drop down is displayed")]
        public void ThenInternaldatabasesTenantDropDownIsDisplayed()
        {
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='internalDatabases-select-tenant']")).Displayed);
            tmsWait.Hard(1);
        }

        

        [Then(@"Internaldatabases ""(.*)"" Tab is displayed")]
        public void ThenInternaldatabasesTabIsDisplayed(string taB)
        {
            switch (taB.ToLower())
            {

                case "staging":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//li[@id='k-tabstrip-tab-0']/span ")).Displayed);
                    break;
                case "operational":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//li[@id='k-tabstrip-tab-1']/span")).Displayed);
                    break;
                case "warehouse":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//li[@id='k-tabstrip-tab-2']/span")).Displayed);
                    break;
            }
        }


    }
}
