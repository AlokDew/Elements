﻿using System;
using System.Collections.Generic;
using System.Text;
using TechTalk.SpecFlow;
using TMSoR1.FrameworkCode;

namespace TMSoR1
{
    [Binding]
    class fsElementsFramework
    {
        [When(@"Framework Administration page DB Versions section is Clicked")]
        public void WhenFrameworkAdministrationPageDBVersionsSectionIsClicked()
        {
            AngularFunction.clickOnElement(cfElementsFramework.DBVersions.DBVersionSection);
            
            
        }

        [Then(@"Verify Administration application displayed Title as ""(.*)""")]
        public void ThenVerifyAdministrationApplicationDisplayedTitleAs(string expectedResults)
        {
           string actualResults= AngularFunction.getText(cfElementsFramework.DBVersions.DBVersionTitle);

            AngularFunction.compareExpectedValueWithActual(actualResults, expectedResults);
            
        }

    }
}
