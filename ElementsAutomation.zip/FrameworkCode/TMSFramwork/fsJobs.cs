﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using TechTalk.SpecFlow;
using System;
using TMSoR1.FrameworkCode;

namespace TMSoR1
{
    [Binding]
    public class fsJobs
    {
        [Then(@"Verify Job status for the Job created for Tenant ""(.*)"" Job Description as ""(.*)"" is ""(.*)""")]
        public void ThenVerifyJobStatusForTheJobCreatedForTenantJobDescriptionAsIs(string tenant, string job, string status)
        {
            tmsWait.Hard(10);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + tenant + "')]/following-sibling::td[contains(.,'" + job + "')]/following-sibling::td[contains(.,'" + status + "')]")).Displayed);
        }

        [When(@"Job Scheduler page ""(.*)"" drop down is set to ""(.*)""")]
        public void WhenJobSchedulerPageDropDownIsSetTo(string menu, string value)
        {
            string dropDownPath = "";

            switch (menu)
            {
                case "Tenant":
                    dropDownPath = "//kendo-dropdownlist[@test-id='jobScheduler-txt-tenentDetails']//span[@class='k-select']";
                    break;
                case "Job Group":
                    dropDownPath = "//kendo-dropdownlist[@test-id='jobScheduler-txt-ddlJobGroups']//span[@class='k-select']";
                    break;
                case "Job":
                    dropDownPath = "//kendo-dropdownlist[@test-id='jobScheduler-txt-ddlJobs']//span[@class='k-select']";
                    break;
                default:
                    Console.WriteLine("Value was not specified for drop down, exiting function without setting a drop-down value");
                    return;
            }

            By Drp = By.XPath(dropDownPath);
            By typeapp = By.XPath("//li[text()='" + value + "']");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
        }

        [When(@"Job Scheduler page ""(.*)"" button is clicked")]
        public void WhenJobSchedulerPageButtonIsClicked(string button)
        {
            switch (button)
            {
                case "Reset":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='jobScheduler-btn-reset']")));
                    break;
                case "Search":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='jobScheduler-btn-search']")));
                    break;
                case "Schedule Job":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='jobScheduler-btn-schedule']")));
                    break;
                case "UPDATE":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='joEditScheduler-button-update']")));
                    break;
                case "SCHEDULE":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='jobAddScheduler-button-schedule']")));
                    break;
                default:
                    Console.WriteLine("Button was not specified, exiting function without clicking a button");
                    return;
            }

            tmsWait.Hard(3);
        }

        [When(@"Job Scheduler page Active checkbox is clicked and message ""(.*)"" appears")]
        public void WhenJobSchedulerPageActiveCheckboxIsClickedAndMessageAppears(string p0)
        {
           // string expMsg = tmsCommon.GenerateData(p0);

            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//input[@type='checkbox'])[1]")));
            tmsWait.Hard(1);

            //string actualMsg = Browser.Wd.FindElement(By.XPath("//div[@class='k-notification-content']")).Text;

            //fw.ConsoleReport(actualMsg);
            //Assert.AreEqual(expMsg, actualMsg, " Both are not matching");
            //tmsWait.Hard(5);
        }

        [When(@"Job Scheduler page Edit button is clicked for the first row and message ""(.*)"" appears")]
        public void WhenJobSchedulerPageEditButtonIsClickedForTheFirstRowAndMessageAppears(string p0)
        {
            string expMsg = tmsCommon.GenerateData(p0);

            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//tr//td//a[@role='button']/span)[1]")));
            tmsWait.Hard(1);

            string actualMsg = Browser.Wd.FindElement(By.XPath("//div[@class='k-notification-content']")).Text;

            fw.ConsoleReport(actualMsg);
            Assert.AreEqual(expMsg, actualMsg, " Both are not matching");
            tmsWait.Hard(5);
        }

        [Then(@"Job Scheduler page message ""(.*)"" appears")]
        public void WhenJobSchedulerPageMessageAppears(string p0)
        {
            string expMsg = tmsCommon.GenerateData(p0);

            tmsWait.Hard(1);

            string actualMsg = Browser.Wd.FindElement(By.XPath("//div[@class='k-notification-content']")).Text;

            fw.ConsoleReport(actualMsg);
            Assert.AreEqual(expMsg, actualMsg, " Both are not matching");
            tmsWait.Hard(5);
        }

        [When(@"Job Scheduler page Edit button is clicked for the first row and Update popup appears")]
        public void WhenJobSchedulerPageEditButtonIsClickedForTheFirstRowAndUpdatePopupAppears()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//tr//td//a[@role='button']/span)[1]")));
            tmsWait.Hard(1);

            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//div[contains(.,'Update Job Details')])[1]")).Displayed);
        }

        [When(@"Job Scheduler page Update Job Details ""(.*)"" field is set to ""(.*)""")]
        public void WhenJobSchedulerPageUpdateJobDetailsFieldIsSetTo(string p0, string p1)
        {
            switch (p0)
            {
                case "Cron Expression":
                    By chron = By.CssSelector("[test-id='joEditScheduler-select-cornExpression']");
                    Browser.Wd.FindElement(chron).Clear();
                    Browser.Wd.FindElement(chron).SendKeys(p1);
                    Browser.Wd.FindElement(chron).SendKeys(Keys.Tab);
                    break;

                case "Active":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//input[@name='isActive']")));
                    break;
            }

            tmsWait.Hard(1);
        }

        [Then(@"Verify Job Scheduler page Schedule New Job dialog ""(.*)"" field is set to ""(.*)""")]
        public void ThenVerifyJobSchedulerPageScheduleNewJobDialogFieldIsSetTo(string p0, string p1)
        {
            string expectedValue = tmsCommon.GenerateData(p1);
            string actualValue;
            By testField;

            switch (p0)
            {
                case "Job Group":
                    tmsWait.Hard(3);

                    testField = By.XPath("//label[text()='Job Group:']/parent::div//span[@class='k-input']");
                    actualValue = Browser.Wd.FindElement(testField).Text;
                    Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");
                    break;

                case "Job":
                    tmsWait.Hard(3);

                    testField = By.XPath("//label[text()='Job:']/parent::div//span[@class='k-input']");
                    actualValue = Browser.Wd.FindElement(testField).Text;
                    Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");
                    break;

                case "Name":
                    testField = By.CssSelector("[test-id='jobAddScheduler-txt-scheduleName']");
                    actualValue = Browser.Wd.FindElement(testField).GetAttribute("value");
                    Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");
                    break;

                case "Description":
                    testField = By.CssSelector("[test-id='jobAddScheduler-txt-scheduleDescription']");
                    actualValue = Browser.Wd.FindElement(testField).GetAttribute("value");
                    Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");
                    break;

                case "Cron Expression":
                    testField = By.CssSelector("[test-id='jobAddScheduler-txt-cronExpression']");
                    actualValue = Browser.Wd.FindElement(testField).GetAttribute("value");
                    Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");
                    break;

                default:
                    break;
            }

            tmsWait.Hard(1);
        }

        [Then(@"Verify Job Scheduler page Schedule New Job dialog Schedule button is ""(.*)""")]
        public void ThenVerifyJobSchedulerPageScheduleNewJobDialogScheduleButtonIs(string p0)
        {
            string expectedValue = tmsCommon.GenerateData(p0);
            By testField = By.XPath("//button[@test-id='jobAddScheduler-button-schedule']");
            Boolean enabled = Browser.Wd.FindElement(testField).Enabled;

            expectedValue = expectedValue.ToLower();

            switch(expectedValue)
            {
                case "disabled":
                    Assert.IsFalse(enabled, "Button is enabled but is expected to be disabled");
                    break;

                case "enabled":
                    Assert.IsTrue(enabled, "Button is disabled but is expected to be enabled");
                    break;

                default:
                    break;
            }

            tmsWait.Hard(1);
        }

        [When(@"Job Scheduler page Schedule New Job dialog ""(.*)"" field is set to ""(.*)""")]
        public void WhenJobSchedulerPageScheduleNewJobDialogFieldIsSetTo(string p0, string p1)
        {
            string fieldValue = tmsCommon.GenerateData(p1);
            By testField;
            By typeapp;

            switch (p0)
            {
                case "Job Group":
                    tmsWait.Hard(3);

                    testField = By.XPath("//label[text()='Job Group:']/parent::div//span[@class='k-select']");
                    typeapp = By.XPath("//li[text()='" + fieldValue + "']");

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(testField);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

                    break;

                case "Job":
                    tmsWait.Hard(3);

                    testField = By.XPath("//label[text()='Job:']/parent::div//span[@class='k-select']");
                    typeapp = By.XPath("//li[text()='" + fieldValue + "']");

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(testField);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

                    break;

                case "Name":
                    testField = By.CssSelector("[test-id='jobAddScheduler-txt-scheduleName']");
                    Browser.Wd.FindElement(testField).Clear();
                    Browser.Wd.FindElement(testField).SendKeys(fieldValue);
                    Browser.Wd.FindElement(testField).SendKeys(Keys.Tab);
                    break;

                case "Description":
                    testField = By.CssSelector("[test-id='jobAddScheduler-txt-scheduleDescription']");
                    Browser.Wd.FindElement(testField).Clear();
                    Browser.Wd.FindElement(testField).SendKeys(fieldValue);
                    Browser.Wd.FindElement(testField).SendKeys(Keys.Tab);
                    break;

                case "Cron Expression":
                    testField = By.CssSelector("[test-id='joEditScheduler-select-cornExpression']");
                    Browser.Wd.FindElement(testField).Clear();
                    Browser.Wd.FindElement(testField).SendKeys(fieldValue);
                    Browser.Wd.FindElement(testField).SendKeys(Keys.Tab);
                    break;

                default:
                    break;
            }

            tmsWait.Hard(1);
        }

        [Then(@"Verify Job Scheduler page Schedule New Job dialog Parameter table Key as ""(.*)"" Value as ""(.*)"" is displayed")]
        public void ThenVerifyJobSchedulerPageScheduleNewJobDialogParameterTableKeyAsValueAsIsDisplayed(string p0, string p1)
        {
            tmsWait.Hard(1);

            By testField = By.XPath("//kendo-grid[@test-id='jobProcessingStatus-grid-jobs']//td[contains(.,'" + p0 + "')]/following-sibling::td[contains(.,'" + p1 + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(testField);

            tmsWait.Hard(1);
        }

        [When(@"Job Scheduler page Schedule New Job dialog Parameter table ""(.*)"" field is set to ""(.*)""")]
        public void WhenJobSchedulerPageScheduleNewJobDialogParameterTableFieldIsSetTo(string p0, string p1)
        {
            string fieldValue = tmsCommon.GenerateData(p1);

            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='jobProcessingStatus-grid-jobs']//td[contains(.,'" + p0 + "')]//following-sibling::td/button/span[@class='fas fa-pencil-alt']")));
            tmsWait.Hard(1);

            By testField = By.XPath("//kendo-grid[@test-id='jobProcessingStatus-grid-jobs']//input");
            Browser.Wd.FindElement(testField).Clear();
            Browser.Wd.FindElement(testField).SendKeys(fieldValue);

            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='jobProcessingStatus-grid-jobs']//td[contains(.,'" + p0 + "')]//following-sibling::td/button/span[@class='fas fa-save']")));
            tmsWait.Hard(1);
        }
    }
}
