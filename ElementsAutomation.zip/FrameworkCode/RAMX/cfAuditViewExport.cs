﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.RAMX
{
    [Binding]
    class cfAuditViewExport
    {
        public static AuditViewExportPage AuditViewExportPage { get { return new AuditViewExportPage(); } }


    }

    [Binding]
    public class AuditViewExportPage
    {
        public IWebElement MemberLookup { get { return Browser.Wd.FindElement(By.XPath("//a[@test-id='deleteSubmittedDiagnosis-a-providerLookup']")); } }
        public IWebElement MemberIDTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='member-txt-memberid']")); } }
        public IWebElement SearchBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='member-btn-search']")); } }
        public IWebElement AddBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='member-btn-add']")); } }
        public IWebElement AuditExportSearchBtn { get { return Browser.Wd.FindElement(By.XPath("//button[@id='btnSearch'][contains(.,'SEARCH')]")); } }
        public IWebElement AuditExportPageExportButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='audit-btn-export']")); } }
        public IWebElement AuditViewExportPageSearchButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='audit-btn-search']")); } }

        




    }
}