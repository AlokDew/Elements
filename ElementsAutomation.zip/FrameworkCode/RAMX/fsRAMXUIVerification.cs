﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using TMSoR1.FrameworkCode;
using TMSoR1.FrameworkCode.RAMX;
using TMSoR1.FrameworkCode.HCC_RAM;
using System.IO;
using FileHelpers;
using System.Xml;

namespace TMSoR1.FrameworkCode.HCC_RAM
{
    [DelimitedRecord("|")]
    [IgnoreEmptyLines()]
   
    public class CSVFileContent
    {

        public string ControlNumber { get; set; }
        //Description, this attribute will handle the double quotes issue
        //[FieldQuoted('"', QuoteMode.OptionalForBoth)]
        public string MemberID { get; set; }
        public string ProviderID { get; set; }
        public string DOS { get; set; }
        public string DiagnosCode { get; set; }
        public string coderID { get; set; }
        public string Reason { get; set; }
        public string ClaimID { get; set; }
        public string KeptOnHold { get; set; }
        public string OnHoldReason { get; set; }
        public string reviewResource { get; set; }

    }
    [Binding]
    class fsRAMXUIVerification
    {
        /// <summary>
        ///  This is Sample step defnition
        /// </summary>
        [When(@"Read XML file from specified download folder")]
        public void WhenReadXMLFileFromSpecifiedDownloadFolder()
        {
            string path = @"D:\temp\Test\Edge_4.xml";
            var document = new XmlDocument();
            document.Load(path);
            var nsmgr = new XmlNamespaceManager(document.NameTable);
            nsmgr.AddNamespace("ns1", "http://vo.edge.fm.cms.hhs.gov");

            // XmlNodeList nl = document.SelectNodes("//ns1:includedSupplementalDiagnosisDetail/ns1:recordIdentifier", nsmgr);
            XmlNodeList nl = document.SelectNodes("//ns1:includedSupplementalDiagnosisDetail", nsmgr);

            foreach (XmlElement ele in nl)
            {

                Console.Write(ele.OuterXml + " ---> " + ele.InnerText);
                Console.WriteLine("\n");
            }

            //XPathDocument doc = new XPathDocument(path);
            //XPathNavigator nav = doc.CreateNavigator();

            //// Compile a standard XPath expression
            //XPathExpression expr;
            //expr = nav.Compile("//ns1:includedSupplementalDiagnosisIssuer");
            //XPathNodeIterator iterator = nav.Select(expr);
            //try
            //{
            //    while (iterator.MoveNext())
            //    {

            //    }
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}
        }

        [When(@"Prepare PIR Response File with multi record ""(.*)"" using Control Number ""(.*)"" Member ID ""(.*)"" Provider ""(.*)"" DOS ""(.*)"" Diag Code ""(.*)"" Coder ID ""(.*)"" Reason ""(.*)"" Claim ""(.*)"" KeptOnHold ""(.*)"" OnHoldReason ""(.*)"" Review Resource ""(.*)""")]
        public void WhenPreparePIRResponseFileWithMultiRecordUsingControlNumberMemberIDProviderDOSDiagCodeCoderIDReasonClaimKeptOnHoldOnHoldReasonReviewResource(string p0, string p1, string p2, string p3, string p4, string p5, string p6, string p7, string p8, string p9, string p10, string p11)
        {
            string fileName = tmsCommon.GenerateData(p0);
            string control = tmsCommon.GenerateData(p1);
            string mem = tmsCommon.GenerateData(p2);
            string provider = tmsCommon.GenerateData(p3);
            string dos = tmsCommon.GenerateData(p4);
            string diagcode = tmsCommon.GenerateData(p5);
            string coder = tmsCommon.GenerateData(p6);
            string reason = tmsCommon.GenerateData(p7);
            string claim = tmsCommon.GenerateData(p8);
            string keptonHold = tmsCommon.GenerateData(p9);
            string onHoldReason = tmsCommon.GenerateData(p10);
            string reviewresource = tmsCommon.GenerateData(p11);
            string diagcode1 = GlobalRef.PageDiagCodeID1.ToString();
            string diagcode2 = GlobalRef.PageDiagCodeID2.ToString();
            string diagcode3 = GlobalRef.PageDiagCodeID3.ToString();


            try
            {
                IList<CSVFileContent> studentList = new List<CSVFileContent>()
                                             {
                    new CSVFileContent()
                       {
                        ControlNumber =control,
                        MemberID =mem,
                        ProviderID =provider,
                        DOS =dos,
                        DiagnosCode =diagcode1,
                        coderID =coder,
                        Reason =reason,
                        ClaimID =claim,
                        KeptOnHold =keptonHold
                        ,OnHoldReason=onHoldReason,
                        reviewResource =reviewresource
                         },
                     new CSVFileContent()
                       {
                        ControlNumber =control,
                        MemberID =mem,
                        ProviderID =provider,
                        DOS =dos,
                        DiagnosCode =diagcode2,
                        coderID =coder,
                        Reason =reason,
                        ClaimID =claim,
                        KeptOnHold =keptonHold
                        ,OnHoldReason=onHoldReason,
                        reviewResource =reviewresource
                         },
                      new CSVFileContent()
                       {
                        ControlNumber =control,
                        MemberID =mem,
                        ProviderID =provider,
                        DOS =dos,
                        DiagnosCode =diagcode3,
                        coderID =coder,
                        Reason =reason,
                        ClaimID =claim,
                        KeptOnHold =keptonHold
                        ,OnHoldReason=onHoldReason,
                        reviewResource =reviewresource
                         },
                          };
                //filehelper object
                FileHelperEngine engine = new FileHelperEngine(typeof(CSVFileContent));
                //csv object
                List<CSVFileContent> csv = new List<CSVFileContent>();
                //convert any datasource to csv based object
               
                foreach (var item in studentList)
                {

                    CSVFileContent temp = new CSVFileContent();
                    temp.ControlNumber = item.ControlNumber;
                    temp.MemberID = item.MemberID;
                    temp.ProviderID = item.ProviderID;
                    temp.DOS = item.DOS;
                    temp.DiagnosCode = item.DiagnosCode;
                    temp.coderID = item.coderID;
                    temp.Reason = item.Reason;
                    temp.ClaimID = item.ClaimID;
                    temp.KeptOnHold = item.KeptOnHold;
                    temp.OnHoldReason = item.OnHoldReason;
                    temp.reviewResource = item.reviewResource;
                    csv.Add(temp);

                }
                
                string filename = "C:\\temp\\" + fileName;

                engine.WriteFile(filename, csv);

            }
            catch (Exception ex)
            {

            }
        }

        [When(@"Prepare PIR Response File ""(.*)"" using Control Number ""(.*)"" Member ID ""(.*)"" Provider ""(.*)"" DOS ""(.*)"" Diag Code ""(.*)"" Coder ID ""(.*)"" Reason ""(.*)"" Claim ""(.*)"" KeptOnHold ""(.*)"" OnHoldReason ""(.*)"" Review Resource ""(.*)""")]
        public void WhenPreparePIRResponseFileUsingControlNumberMemberIDProviderDOSDiagCodeCoderIDReasonClaimKeptOnHoldOnHoldReasonReviewResource(string p0, string p1, string p2, string p3, string p4, string p5, string p6, string p7, string p8, string p9, string p10, string p11)
        {
            
            string fileName= tmsCommon.GenerateData(p0);
            string control = tmsCommon.GenerateData(p1);
            string mem = tmsCommon.GenerateData(p2);
            string provider = tmsCommon.GenerateData(p3);
            string dos = tmsCommon.GenerateData(p4);
            string diagcode = tmsCommon.GenerateData(p5);
            string coder = tmsCommon.GenerateData(p6);
            string reason = tmsCommon.GenerateData(p7);
            string claim = tmsCommon.GenerateData(p8);
            string keptonHold = tmsCommon.GenerateData(p9);
            string onHoldReason = tmsCommon.GenerateData(p10);
            string reviewresource = tmsCommon.GenerateData(p11);

            try
            {
                IList<CSVFileContent> studentList = new List<CSVFileContent>()
                                             {
                    new CSVFileContent()
                       {
                        ControlNumber =control,
                        MemberID =mem,
                        ProviderID =provider,
                        DOS =dos,
                        DiagnosCode =diagcode,
                        coderID =coder,
                        Reason =reason,
                        ClaimID =claim,
                        KeptOnHold =keptonHold
                        ,OnHoldReason=onHoldReason,
                        reviewResource =reviewresource
                         },
                          };
                //filehelper object
                FileHelperEngine engine = new FileHelperEngine(typeof(CSVFileContent));
                //csv object
                List<CSVFileContent> csv = new List<CSVFileContent>();
                //convert any datasource to csv based object
                CSVFileContent temp = new CSVFileContent();
                foreach (var item in studentList)
                {


                    temp.ControlNumber = item.ControlNumber;
                    temp.MemberID = item.MemberID;
                    temp.ProviderID = item.ProviderID;
                    temp.DOS = item.DOS;
                    temp.DiagnosCode = item.DiagnosCode;
                    temp.coderID = item.coderID;
                    temp.Reason = item.Reason;
                    temp.ClaimID = item.ClaimID;
                    temp.KeptOnHold = item.KeptOnHold;
                    temp.OnHoldReason = item.OnHoldReason;
                    temp.reviewResource = item.reviewResource;
                    csv.Add(temp);

                }
                
                string filename = "C:\\temp\\"+ fileName;
                
                engine.WriteFile(filename, csv);

            }
            catch (Exception ex)
            {

            }
        }

        [When(@"Load PIR Response File """"(.*)"" and Click on Import button")]
        public void WhenLoadPIRResponseFileAndClickOnImportButton(string p0)
        {
            string fileLoc ="c:\\temp\\"+tmsCommon.GenerateData(p0);

            By selectFile = By.CssSelector("[test-id='import-input-fileUpload']");
            
            By UploadBtn = By.XPath("//button[contains(.,'Upload')]");
            By import = By.CssSelector("[test-id='import-btn-import']");
            Browser.Wd.FindElement(selectFile).SendKeys(fileLoc);
            tmsWait.Hard(1);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(UploadBtn);
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(import);
        }



        [When(@"Prepare PIR response file based on above Control Number ""(.*)"" Member ID ""(.*)"" Provider ""(.*)"" DOS ""(.*)"" Diag Code ""(.*)""")]
        public void WhenPreparePIRResponseFileBasedOnAboveControlNumberMemberIDProviderDOSDiagCode(string p0, string p1, string p2, string p3, string p4)
        {
            string control = tmsCommon.GenerateData(p0);
            string mem = tmsCommon.GenerateData(p1);
            string provider = tmsCommon.GenerateData(p2);
            string dos = tmsCommon.GenerateData(p3);
            string diagcode = tmsCommon.GenerateData(p4);

            try
            {
                IList<CSVFileContent> studentList = new List<CSVFileContent>() {
                    new CSVFileContent(){ ControlNumber=control,MemberID=mem,ProviderID=provider,DOS=dos,DiagnosCode=diagcode,coderID="",Reason="Visit Note Not Signed",ClaimID="",KeptOnHold="N",OnHoldReason="",reviewResource="Other"},
                    
            };
                //filehelper object
                FileHelperEngine engine = new FileHelperEngine(typeof(CSVFileContent));
                //csv object
                List<CSVFileContent> csv = new List<CSVFileContent>();
                //convert any datasource to csv based object
                CSVFileContent temp = new CSVFileContent();
                foreach (var item in studentList)
                {


                    temp.ControlNumber = item.ControlNumber;
                    temp.MemberID = item.MemberID;
                    temp.ProviderID = item.ProviderID;
                    temp.DOS = item.DOS;
                    temp.DiagnosCode = item.DiagnosCode;
                    temp.coderID = item.coderID;
                    temp.Reason = item.Reason;
                    temp.ClaimID = item.ClaimID;
                    temp.KeptOnHold = item.KeptOnHold;
                    temp.OnHoldReason = item.OnHoldReason;
                    temp.reviewResource = item.reviewResource;
                    csv.Add(temp);

                }
                //give file a name and header text
                string filename = "C:\\temp\\CIS_Suspects_20190207_12345.csv";
                //engine.HeaderText = "Member ID,HCC,Payment Year,Provider ID,Provider Name";
                //save file locally
                engine.WriteFile(filename, csv);

            }
            catch (Exception ex)
            {

            }

        }

        [When(@"Scrolled to PIR Page Additional Diagnosis section")]
        public void WhenScrolledToPIRPageAdditionalDiagnosisSection()
        {
            By loc = By.CssSelector("[test-id='searchDiag-txt-txtDiagCode']");
            fw.ScrollWindowToViewElementUsingLocators(loc);
            tmsWait.Hard(2);
        }


        [When(@"PIR Page Additional Diagnosis link is Clicked")]
        public void WhenPIRPageAdditionalDiagnosisLinkIsClicked()
        {
            By loc = By.XPath("(//label[contains(@class,'cursorLink ml-2')])[2]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            tmsWait.Hard(5);
        }

        [When(@"PIR Page Addional diagnosis page Uncheck all On Hold Diagnosis codes and Click on Update")]
        public void WhenPIRPageAddionalDiagnosisPageUncheckAllOnHoldDiagnosisCodesAndClickOnUpdate()
        {
            By onHold = By.CssSelector("[test-id='searchDiag-chk-chkonHoldReason']");            
            By Update = By.CssSelector("[test-id='searchDiag-btn-add']");
            try
            {
                IReadOnlyCollection<IWebElement> edits = Browser.Wd.FindElements(By.XPath("//div[@test-id='pirResponse-grid-additionalDiagnosesGrid']//td/a[1][@role='button']"));
                foreach (IWebElement temp in edits)
                {
                    fw.ExecuteJavascript(temp);
                    tmsWait.Hard(2);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(onHold));
                    tmsWait.Hard(1);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(Update));
                    tmsWait.Hard(1);

                }
            }
            catch
            {
                fw.ConsoleReport(" There is Diag code details on Additional sections");
            }
        }


        [When(@"RAMX PIR Page Potential Related Diagnosis section link is Clicked")]
        public void WhenRAMXPIRPagePotentialRelatedDiagnosisSectionLinkIsClicked()
        {
            By loc = By.XPath("(//i[@class='fas fa-plus-square cursorLink text-secondary ng-star-inserted'])[1]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            tmsWait.Hard(1);
        }

        [Then(@"Verify PIR response file displayed on Fallout Folder with Fallout Reason ""(.*)""")]
        public void ThenVerifyPIRResponseFileDisplayedOnFalloutFolderWithFalloutReason(string p0)
        {
            string falloutFolderPath = GlobalRef.falloutReportPath.ToString();
            string recentFile = ReUsableFunctions.getRecentFileFromSpecifiedFolderWithFolderPath(falloutFolderPath, "*.txt");
            bool valueFound = false;
            int row = 0;
            var reader = new StreamReader(File.OpenRead(@"" + recentFile + ""));
            while (!reader.EndOfStream)
            {
                var line = reader.ReadLine();
                if (row >0)
                {
                    
                    var values = line.Split(',');
                    if (values[4].Trim().Equals(p0))
                    {
                        valueFound = true;
                        break;
                    }
                }
                row++;
            }
            if(valueFound)
            {
                Assert.IsTrue(true, " Expected Value is found");
            }
        }


        [When(@"RAMX PIR Page Potential Related Diagnosis section Action link is Clicked")]
        public void WhenRAMXPIRPagePotentialRelatedDiagnosisSectionActionLinkIsClicked()
        {
            //By loc = By.XPath("(//kendo-grid[@test-id='pirResponse-grid-potentialRelatedDiagnosesGrid']//td//button[contains(@class,'edit-command')])[1]");
            tmsWait.Hard(2);
            By loc = By.XPath("//kendo-grid[@test-id='pirResponse-grid-potentialRelatedDiagnosesGrid']//table//tr[1]//td//button[contains(@class,'edit-command')]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            tmsWait.Hard(2);
        }

        [When(@"RAMX PIR Page Potential Related Diagnosis section Add checkbox is Clicked")]
        public void WhenRAMXPIRPagePotentialRelatedDiagnosisSectionAddCheckboxIsClicked()
        {
            By loc = By.XPath("(//div[@test-id='pirResponse-grid-potentialRelatedDiagnosesGrid']//tr/td/input[@type='checkbox'])[1]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            tmsWait.Hard(1);
        }
        [When(@"RAMX PIR Page Potential Related Diagnosis section Add checkbox is ""(.*)""")]
        public void WhenRAMXPIRPagePotentialRelatedDiagnosisSectionAddCheckboxIs(string p0)
        {
            By loc = By.XPath("(//kendo-grid[@test-id='pirResponse-grid-potentialRelatedDiagnosesGrid']//tr/td/input[@type='checkbox'])[1]");
            ReUsableFunctions.CheckBoxOperations(Browser.Wd.FindElement(loc),p0);
        }


        [When(@"RAMX PIR Page Potential Related Diagnosis section On Hold checkbox is Clicked")]
        public void WhenRAMXPIRPagePotentialRelatedDiagnosisSectionOnHoldCheckboxIsClicked()
        {
            By loc = By.XPath("(//div[@test-id='pirResponse-grid-potentialRelatedDiagnosesGrid']//tr/td/input[@type='checkbox'])[2]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            tmsWait.Hard(1);
        }
        [When(@"RAMX PIR Page Potential Related Diagnosis section On Hold checkbox is ""(.*)""")]
        public void WhenRAMXPIRPagePotentialRelatedDiagnosisSectionOnHoldCheckboxIs(string p0)
        {
            By loc = By.XPath("(//kendo-grid[@test-id='pirResponse-grid-potentialRelatedDiagnosesGrid']//tr/td/input[@type='checkbox'])[2]");
            ReUsableFunctions.CheckBoxOperations(Browser.Wd.FindElement(loc), p0);
        }

        [When(@"RAMX PIR Page Potential Related Diagnosis section On Hold Reason should not display ""(.*)""")]
        public void WhenRAMXPIRPagePotentialRelatedDiagnosisSectionOnHoldReasonShouldNotDisplay(string p0)
        {
            string expectedValue = tmsCommon.GenerateData(p0);
            bool found = false;
            IWebElement drp = Browser.Wd.FindElement(By.CssSelector("//div[@test-id='pirResponse-grid-potentialRelatedDiagnosesGrid']//span[@role='listbox']"));
            fw.ExecuteJavascript(drp);
            tmsWait.Hard(4);
            IReadOnlyCollection<IWebElement> drpValues = Browser.Wd.FindElements(By.XPath("(//li[contains(.,'" + expectedValue + "')])[3]"));

            foreach (IWebElement temp in drpValues)
            {
                if (temp.Text.Equals(expectedValue))
                {
                    found = true;
                }
            }

            if (found)
            {
                Assert.Fail("Inactive On Hold Reason should not present");
            }
        }

        [When(@"RAMX PIR Page Additional Diagnosis section On Hold Reason should not display ""(.*)""")]
        public void WhenRAMXPIRPageAdditionalDiagnosisSectionOnHoldReasonShouldNotDisplay(string p0)
        {
            string expectedValue = tmsCommon.GenerateData(p0);
            bool found = false;
            IWebElement drp = Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlonHoldReason_listbox']"));
            fw.ExecuteJavascript(drp);
            tmsWait.Hard(4);
            IReadOnlyCollection<IWebElement> drpValues = Browser.Wd.FindElements(By.XPath("//ul[@id='ddlonHoldReason_listbox']/li"));

            foreach (IWebElement temp in drpValues)
            {
                if (temp.Text.Equals(expectedValue))
                {
                    found = true;
                }
            }

            if (found)
            {
                Assert.Fail("Inactive On Hold Reason should not present");
            }
        }


        [When(@"RAMX PIR Page Potential Related Diagnosis section On Hold Reason is set to ""(.*)""")]
        public void WhenRAMXPIRPagePotentialRelatedDiagnosisSectionOnHoldReasonIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            By Drp = By.XPath("//kendo-dropdownlist[@id='onHoldReason']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + value + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }

        [When(@"RAMX PIR Page Potential Related Diagnosis section Save Button is Clicked")]
        public void WhenRAMXPIRPagePotentialRelatedDiagnosisSectionSaveButtonIsClicked()
        {
            By Loc = By.XPath("(//kendo-grid[@test-id='pirResponse-grid-potentialRelatedDiagnosesGrid']//td//span[@class='fas fa-save'])[1]");
            //fw.ExecuteJavascript(Browser.Wd.FindElement(Loc));
            Browser.Wd.FindElement(Loc).Click();
            tmsWait.Hard(5);
        }


        [When(@"RAMX PIR Page Potential Related Diagnosis section Chart Review Source is set to ""(.*)""")]
        public void WhenRAMXPIRPagePotentialRelatedDiagnosisSectionChartReviewSourceIsSetTo(string p0)
        {
            string chart_review_value = tmsCommon.GenerateData(p0);
            //SelectElement chart_review_source = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@test-id='pirResponse-select-source']")));
            //chart_review_source.SelectByText(chart_review_value);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='pirResponse-select-source']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + chart_review_value + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

        }

        [When(@"RAMX PIR Page ""(.*)"" is set to ""(.*)""")]
        public void WhenRAMXPIRPageIsSetTo(string p0, string p1)
        {
            string reason = tmsCommon.GenerateData(p1);
            //SelectElement reason_list = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@test-id='pirResponse-select-unconfirmedSuspects']")));
            //reason_list.SelectByText(reason);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='pirResponse-select-unconfirmedSuspects']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + reason + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }




        [When(@"PIR Page Coder ID is selected as ""(.*)""")]
        public void WhenPIRPageCoderIDIsSelectedAs(string p0)
        {
            string code = tmsCommon.GenerateData(p0);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='pirResponse-select-coders']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + code + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(2);
        }



        [When(@"RAMX PIR Page Potential Related Diagnosis section Submit Button is Clicked")]
        public void WhenRAMXPIRPagePotentialRelatedDiagnosisSectionSubmitButtonIsClicked()
        {
            By Loc = By.CssSelector("[test-id='pirResponse-btn-add']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Loc));
            tmsWait.Hard(10);
        }


        [Then(@"Verify RAMX PIR Page Confirmation message ""(.*)"" is displayed")]
        public void ThenVerifyRAMXPIRPageConfirmationMessageIsDisplayed(string p0)
        {
            tmsWait.Hard(20);
            string expected_Message = tmsCommon.GenerateData(p0);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[contains(.,'" + expected_Message + "')]")).Displayed, "confirmation dialog box message is incorrect or unavailable");
        }

        [Then(@"Verify Review Chart Source ""(.*)"" and ""(.*)"" are same")]
        public void ThenVerifyReviewChartSourceAndAreSame(string p0, string p1)
        {
            string expected_value = tmsCommon.GenerateData(p0);
            string actual_value =  tmsCommon.GenerateData(p1);
            Assert.IsTrue(actual_value.Contains(expected_value), "Expected and Actual Values are not same");
        }

        [When(@"Back to Record button is Clicked")]
        public void WhenBackToRecordButtonIsClicked()
        {
            By Loc = By.CssSelector("[test-id='pirResponse-span-back']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Loc));
            tmsWait.Hard(5);
        }


        [Then(@"RAMX Application PIR Page Warning dialog Confirmation dialog Yes button is Clicked")]
        public void ThenRAMXApplicationPIRPageWarningDialogConfirmationDialogYesButtonIsClicked()
        {
            tmsWait.Hard(2);
            try
            {
                UIMODUtilFunctions.clickOnConfirmationYesDialog();
            }
            catch { }
        }

        [Then(@"Verify New Record is created under Table tbClaimOnHold for Claim Number ""(.*)""")]
        public void ThenVerifyNewRecordIsCreatedUnderTableTbClaimOnHoldForClaimNumber(string p0)
        {
            tmsWait.Hard(2);
            string expClaim = tmsCommon.GenerateData(p0);
            
            string actClaimnumber = singleColumnQueryExecutionSelectRecordBasedOnIndex("select txtPlanClaimID from[RAMX].dbo.tbClaimOnHold where txtPlanClaimID = '" + expClaim + "'", ConfigFile.RAMdb, 0);
            tmsWait.Hard(2);
            
            Assert.AreEqual(expClaim, actClaimnumber, " Claim Number entry it not present");
            
        }

        [Then(@"Verify New Additional Diagnosis Record is created under Table tbDiagsId for Member ""(.*)""")]
        public void ThenVerifyNewAdditionalDiagnosisRecordIsCreatedUnderTableTbDiagsIdForMember(string p0)
        {
          
            tmsWait.Hard(2);
            string expMember = tmsCommon.GenerateData(p0);

            string actMember = singleColumnQueryExecutionSelectRecordBasedOnIndex("select top 1 tbDiagsId from [RAMX].dbo.tbDiags where bntMemberID=(select bntMemberID from [RAMX].dbo.tbClaim where txtMemberId = '" + expMember + "' and intClaimType = 4)", ConfigFile.RAMdb, 0);
            tmsWait.Hard(2);

            Assert.AreEqual(expMember, actMember, " Claim Number entry it not present");

        }

        [Then(@"Verify New Record is created under Table tbClaimOnHold ""(.*)"" for ClaimID ""(.*)""")]
        public void ThenVerifyNewRecordIsCreatedUnderTableTbClaimOnHoldForClaimID(string p0, string p1)
        {
           
            tmsWait.Hard(2);
            string expValue = tmsCommon.GenerateData(p0);
            string actValue = tmsCommon.GenerateData(p1);            

            Assert.AreEqual(expValue, actValue, " Claim Number entry it not present");
        }

        [Then(@"Verify UI Plan Value ""(.*)"" is matching with Table tbTransactions_PlanValues ""(.*)""")]
        public void ThenVerifyUIPlanValueIsMatchingWithTableTbTransactions_PlanValues(string p0, string p1)
        {
            tmsWait.Hard(2);
            string expValue = tmsCommon.GenerateData(p0);
            string actValue = tmsCommon.GenerateData(p1);

            Assert.AreEqual(expValue, actValue, " Both Plan Values are not matching");
        }


        [Then(@"Verify New Additional Diagnosis Record is created under Table tbDiagsId for ReferenceInfo ""(.*)""")]
        public void ThenVerifyNewAdditionalDiagnosisRecordIsCreatedUnderTableTbDiagsIdForReferenceInfo(string p0)
        {
           
            string refinfo = tmsCommon.GenerateData(p0);
            bool result = string.IsNullOrEmpty(refinfo);

            Assert.IsTrue(!result, " New Diag Code entry is  not present");
        }

        [Then(@"Verify tbDiags table contains new Diag entry ""(.*)"" for tbDiagsId column")]
        public void ThenVerifyTbDiagsTableContainsNewDiagEntryForTbDiagsIdColumn(string p0)
        {
           
            string diag = tmsCommon.GenerateData(p0);
            bool result = string.IsNullOrEmpty(diag);

            Assert.IsTrue(!result, " New Diag Code entry is  not present");
        }

        [Then(@"Verify tbExceptionLetters table intStatus column ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyTbExceptionLettersTableIntStatusColumnIsSetTo(string p0, string p1)
        {
            
            string actValue = tmsCommon.GenerateData(p0);
            string expValue = p1;
            Assert.AreEqual(expValue, actValue, "Both  values are not matching");
        }

        [Then(@"Verify elecAppFile table IsProcessed column ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyElecAppFileTableIsProcessedColumnIsSetTo(string p0, string p1)
        {
            string actValue = tmsCommon.GenerateData(p0);
            string expValue = p1;
            Assert.AreEqual(expValue, actValue, "Both  values are not matching");
        }

        [Then(@"Verify elecAppFile table column ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyElecAppFileTableColumnIsSetTo(string p0, string p1)
        {
            string actValue = tmsCommon.GenerateData(p0);
            string expValue = p1;
            Assert.AreEqual(expValue, actValue, "Both  values are not matching");
        }


        [When(@"View Edit Member Page Member ID is readed and Assign to ""(.*)""")]
        public void WhenViewEditMemberPageMemberIDIsReadedAndAssignTo(string p0)
        {
            By mem = By.CssSelector("[test-id='memberInfo-txt-memberId']");
            string memid = AngularFunction.getAttributeValue(mem);

            fw.setVariable(p0, memid);
        }

        [Then(@"Verify table column value ""(.*)"" is matched with expected Value ""(.*)""")]
        public void ThenVerifyTableColumnValueIsMatchedWithExpectedValue(string p0, string p1)
        {
            string actValue = tmsCommon.GenerateData(p0);
            string expValue = tmsCommon.GenerateData(p1); 
            Assert.AreEqual(expValue, actValue, "Both  values are not matching");
        }


        [Then(@"Verify tbTransactions table TransStatus column ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyTbTransactionsTableTransStatusColumnIsSetTo(string p0, string p1)
        {
            string actValue = tmsCommon.GenerateData(p0);
            string expValue = p1;
            Assert.AreEqual(expValue, actValue, "Both  values are not matching");
        }

        [Then(@"Verify EnrollmentManagerFalloutReasons table Value column ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyEnrollmentManagerFalloutReasonsTableValueColumnIsSetTo(string p0, string p1)
        {
            string actValue = tmsCommon.GenerateData(p0);
            string expValue = p1;
            Assert.AreEqual(expValue, actValue, "Both  values are not matching");
        }


        [Then(@"Verify AspNetUsers table ForcePasswordChange column ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyAspNetUsersTableForcePasswordChangeColumnIsSetTo(string p0, string p1)
        {
            string actValue = tmsCommon.GenerateData(p0);
            string expValue = p1;
            Assert.AreEqual(expValue, actValue, "Both  values are not matching");
        }


        [Then(@"Verify tbClaimOnHold table isblocked column ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyTbClaimOnHoldTableIsblockedColumnIsSetTo(string p0, string p1)
        {
            string actValue = tmsCommon.GenerateData(p0);
            string expValue = p1;
            Assert.AreEqual(expValue, actValue, "Both  values are not matching");
        }
        [Then(@"Verify tbClaimOnHold table isdeleted column ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyTbClaimOnHoldTableIsdeletedColumnIsSetTo(string p0, string p1)
        {
            string actValue = tmsCommon.GenerateData(p0);
            string expValue = p1;
            Assert.AreEqual(expValue, actValue, "Both  values are not matching");
        }


        [Then(@"Verify tbClaimOnHold table pirstatus column ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyTbClaimOnHoldTablePirstatusColumnIsSetTo(string p0, string p1)
        {
            string actValue = tmsCommon.GenerateData(p0);
            string expValue = p1;
            Assert.AreEqual(expValue, actValue, "Both  values are not matching");
        }

        [Then(@"Verify tbClaim table intClaimType column ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyTbClaimTableIntClaimTypeColumnIsSetTo(string p0, string p1)
        {
            
            string actValue = tmsCommon.GenerateData(p0);
            string expValue = tmsCommon.GenerateData(p1);
            Assert.AreEqual(expValue, actValue, "Both  values are not matching");
        }
        [Then(@"Verify tbClaimOnHold table AuditStatus column ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyTbClaimOnHoldTableAuditStatusColumnIsSetTo(string p0, string p1)
        {
            string actValue = tmsCommon.GenerateData(p0);
            string expValue = tmsCommon.GenerateData(p1);
            Assert.AreEqual(expValue, actValue, "Both  values are not matching");
        }

        [Then(@"Verify ENRL_RESUBMIT_FILES table File_NAME column ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyENRL_RESUBMIT_FILESTableFile_NAMEColumnIsSetTo(string p0, string p1)
        {
            string actValue = tmsCommon.GenerateData(p0);
            string expValue = tmsCommon.GenerateData(p1);
            Assert.AreEqual(expValue, actValue, "Both  values are not matching");
        }

        [Then(@"Verify Provider ID column ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyProviderIDColumnIsSetTo(string p0, string p1)
        {
            string actValue = tmsCommon.GenerateData(p0);
            string expValue = tmsCommon.GenerateData(p1);
            Assert.AreEqual(expValue, actValue, "Both  values are not matching");
        }

        [Then(@"Verify ""(.*)"" column is set to ""(.*)""")]
        public void ThenVerifyColumnIsSetTo(string p0, string p1)
        {
            string actValue = tmsCommon.GenerateData(p0);
            string expValue = tmsCommon.GenerateData(p1);
            Assert.AreEqual(expValue, actValue, "Both  values are not matching");
        }


        [Then(@"Verify DB Table Fallout Values ""(.*)"" is matching with ""(.*)""")]
        public void ThenVerifyDBTableFalloutValuesIsMatchingWith(string p0, string p1)
        {
            string actValue = tmsCommon.GenerateData(p0);
            string expValue = tmsCommon.GenerateData(p1);
            bool results = actValue.Contains(expValue);

            Assert.IsTrue(results, "Both  values are not matching");
        }

        [Then(@"Verify Downloaded Legacy Transaction file record count ""(.*)"" matched with DB Count ""(.*)""")]
        public void ThenVerifyDownloadedLegacyTransactionFileRecordCountMatchedWithDBCount(string p0, string p1)
        {
            string actValue = tmsCommon.GenerateData(p0);
            string expValue = tmsCommon.GenerateData(p1);
            Assert.AreEqual(expValue, actValue, "Both  values are not matching");
        }

        [Then(@"Verify tbClaimOnHold table IsDeleted column ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyTbClaimOnHoldTableIsDeletedColumnIsSetTo(string p0, string p1)
        {
            string actValue = tmsCommon.GenerateData(p0);
            Assert.AreEqual(actValue,"True", "Expected column is not present");
           // string expValue = tmsCommon.GenerateData(p1);
            //Assert.AreEqual(expValue, actValue, "Both  values are not matching");
        }


        [Then(@"Verify tbClaimOnHold table OnHold column ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyTbClaimOnHoldTableOnHoldColumnIsSetTo(string p0, string p1)
        {
           
            string actValue = tmsCommon.GenerateData(p0);
            string expValue= tmsCommon.GenerateData(p1);
            Assert.AreEqual(expValue, actValue, "Both  values are not matching");
        }

        [Then(@"Verify tbMemberHCC table intKnownStatus column ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyTbMemberHCCTableIntKnownStatusColumnIsSetTo(string p0, string p1)
        {
           
            string actValue = tmsCommon.GenerateData(p0);
            string expValue = p1;
            Assert.AreEqual(expValue, actValue, "Both  values are not matching");
        }



        [Then(@"Verify New Additional Diagnosis Record is created under Table tbDiagsId With Member ""(.*)"" and ReferenceInfo ""(.*)""")]
        public void ThenVerifyNewAdditionalDiagnosisRecordIsCreatedUnderTableTbDiagsIdWithMemberAndReferenceInfo(string p0, string p1)
        {
            tmsWait.Hard(2);
            string expMember = tmsCommon.GenerateData(p0);
            string refinfo = tmsCommon.GenerateData(p1);
            string newDiagCodeEntry = singleColumnQueryExecutionSelectRecordBasedOnIndex("select tbDiagsId from [RAMX].dbo.tbDiags where ReferenceInfo='"+refinfo+"'","RAMX", 0);
            tmsWait.Hard(2);
            bool result = string.IsNullOrEmpty(newDiagCodeEntry);

            Assert.IsTrue(!result, " New Diag Code entry is  not present");
            
        }


        public string singleColumnQueryExecutionSelectRecordBasedOnIndex(string SqlString, string DB, int recordIndex)
        {
            ArrayList actList = new ArrayList();
            fsRSMLogin DBquery = new fsRSMLogin();
            actList = DBquery.ExecuteSQLQuery(SqlString, DB);
            string output = actList[recordIndex].ToString();
            return output;
        }
        [When(@"RAMX PIR Page Potential Related Diagnosis section Claim Number is set to ""(.*)""")]
        public void WhenRAMXPIRPagePotentialRelatedDiagnosisSectionClaimNumberIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            By loc = By.CssSelector("[name='claimNumber']");
            ReUsableFunctions.enterValueOnWebElementWithClear(Browser.Wd.FindElement(loc), value);
        }

        [When(@"RAMX PIR Page Potential Related Diagnosis section Risk Assessment Code is set to ""(.*)""")]
        public void WhenRAMXPIRPagePotentialRelatedDiagnosisSectionRiskAssessmentCodeIsSetTo(string p0)
        {
             string value = tmsCommon.GenerateData(p0);
            By loc = By.CssSelector("[id='riskAssessCode']");
            ReUsableFunctions.enterValueOnWebElementWithClear(Browser.Wd.FindElement(loc), value);
        }


        [When(@"RAMX PIR Page Potential Related Diagnosis section Encounter Date is set to ""(.*)""")]
        public void WhenRAMXPIRPagePotentialRelatedDiagnosisSectionEncounterDateIsSetTo(string value)
        {
            tmsWait.Hard(3);
            string dateValue = tmsCommon.GenerateData(value);
            string modValue = (Convert.ToInt32(((dateValue.Split(' '))[0].Split('/'))[2])).ToString();
            string finalValue = "01/01/" + modValue + "";
            //By loc = By.XPath("//div[@test-id='pirResponse-grid-potentialRelatedDiagnosesGrid']//input[@data-role='datepicker']");

            IWebElement Addcheckbox= Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='pirResponse-grid-potentialRelatedDiagnosesGrid']//tr/td/input[@type='checkbox'])[1]"));
            Addcheckbox.SendKeys(Keys.Tab);
            IWebElement Drp = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@id='txtFromDate']//input"));
            string[] value1 = finalValue.Split('/');
            Drp.SendKeys(value1[0]);
            Drp.SendKeys(value1[1]);
            Drp.SendKeys(value1[2]);
            //ele.SendKeys(Keys.Tab);


            // ReUsableFunctions.enterValueOnWebElementWithClear(Browser.Wd.FindElement(loc), finalValue);
            //By Drp = By.XPath("//kendo-datepicker[@id='txtFromDate']//input");
            //AngularFunction.enterDate(Drp, finalValue);
            //Browser.Wd.FindElement(Drp).Clear();
            //Browser.Wd.FindElement(Drp).SendKeys(finalValue);
            tmsWait.Hard(3);
        }

        [Then(@"Verify RAMX PIR Page ""(.*)""")]
        [Then(@"Verify RAMX PIR Page displayed Toaster message as ""(.*)""")]
        public void ThenVerifyRAMXPIRPage(string msg)
        {
            ReUsableFunctions.toasterMessageDisplayVerification(msg);
        }

        [When(@"RAMX Enter New Diagnosis Data page Enter Claim Number ""(.*)""")]
        public void WhenRAMXEnterNewDiagnosisDataPageEnterClaimNumber(string p0)
        {
            string claim = tmsCommon.GenerateData(p0);
            GlobalRef.CLAIMID = claim;
            By claimID = By.CssSelector("[test-id='searchDiag-txt-txtPlanClaimId']");
            Browser.Wd.FindElement(claimID).SendKeys(claim);
        }

      

        [When(@"RAM Enter New Diagnosis Data page Enable On Hold checkbox is ""(.*)""")]
        [When(@"RAMX Enter New Diagnosis Data page Enable On Hold checkbox is ""(.*)""")]
        public void WhenRAMXEnterNewDiagnosisDataPageEnableOnHoldCheckboxIs(string value)
        {
            IWebElement onhold = Browser.Wd.FindElement(By.CssSelector("[test-id='searchDiag-chk-chkonHoldReason']"));
            ReUsableFunctions.CheckBoxOperations(onhold, value);
        }

      

        [When(@"RAM Enter New Diagnosis Data page Reason drop down list is set to ""(.*)""")]
        [When(@"RAMX Enter New Diagnosis Data page Reason drop down list is set to ""(.*)""")]
        public void WhenRAMXEnterNewDiagnosisDataPageReasonDropDownListIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            string reason = tmsCommon.GenerateData(p0);
            GlobalRef.Reason = reason;
            //By claimID = By.CssSelector("[aria-owns='ddlonHoldReason_listbox']");
            //UIMODUtilFunctions.selectDropDownValueFromGendoUI(Browser.Wd.FindElement(claimID), reason);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='searchDiag-txt-ddlonHoldReason']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + reason + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }

        [When(@"RAMX Enter New Diagnosis Data page Select Provider ID ""(.*)""")]
        public void WhenRAMXEnterNewDiagnosisDataPageSelectProviderID(string p0)
        {
            string provid = tmsCommon.GenerateData(p0);
            By pro = By.CssSelector("[test-id='searchDiag-txt-txtProviderId']");
            UIMODUtilFunctions.enterValueOnWebElementUsingLocators(pro, provid);
            Browser.Wd.FindElement(pro).SendKeys(Keys.Tab);
        }


        [When(@"RAMX Enter New Diagnosis Data page Select Provider ID ""(.*)"" from Provider ID look up")]
        public void WhenRAMXEnterNewDiagnosisDataPageSelectProviderIDFromProviderIDLookUp(string p0)
        {
            string provid = tmsCommon.GenerateData(p0);
            GlobalRef.PROVID = provid;
        By providerLookup = By.CssSelector("[test-id='searchDiag-link-provider']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(providerLookup));
            tmsWait.Hard(5);


            By providerID = By.CssSelector("[test-id='searchProvider-txt-ProviderID']");
            Browser.Wd.FindElement(providerID).SendKeys(provid);

            By memberLookupSearchBtn = By.CssSelector("[test-id='searchProvider-btn-search']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(memberLookupSearchBtn));
            tmsWait.Hard(5);

            By selectRecord = By.XPath("(//button[@title='Add'])[1]");
            fw.ExecuteJavascript(Browser.Wd.FindElement(selectRecord));
        }

        [When(@"PIR Page Additional Diagnosis section Enable On Hold Checkbox is ""(.*)""")]
        public void WhenPIRPageAdditionalDiagnosisSectionEnableOnHoldCheckboxIs(string Ops)
        {
            By checkbox = By.CssSelector("[test-id='searchDiag-chk-chkonHoldReason']");
            ReUsableFunctions.CheckBoxOperations(Browser.Wd.FindElement(checkbox),Ops);
        }

        [When(@"RAMX Enter New Diagnosis Data page Reason drop down list should not display ""(.*)""")]
        public void WhenRAMXEnterNewDiagnosisDataPageReasonDropDownListShouldNotDisplay(string p0)
        {
            string expectedValue = tmsCommon.GenerateData(p0);
            bool found = false;
            IWebElement drp = Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlonHoldReason_listbox']"));
            fw.ExecuteJavascript(drp);
            tmsWait.Hard(4);
            IReadOnlyCollection<IWebElement> drpValues = Browser.Wd.FindElements(By.XPath("//ul[@id='ddlonHoldReason_listbox']/li"));

            foreach (IWebElement temp in drpValues)
            {
                if (temp.Text.Equals(expectedValue))
                {
                    found = true;
                }
            }

            if (found)
            {
                Assert.Fail("Inactive On Hold Reason should not present");
            }
        }

        [Then(@"Verify PIR Page Additional Diagnosis section On Hold reason ""(.*)"" is displayed")]
        public void ThenVerifyPIRPageAdditionalDiagnosisSectionOnHoldReasonIsDisplayed(string p0)
        {
            string expectedValue = tmsCommon.GenerateData(p0);
            bool found = false;
            IWebElement drp = Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlonHoldReason_listbox']"));
            fw.ExecuteJavascript(drp);
            tmsWait.Hard(4);
            IReadOnlyCollection<IWebElement> drpValues = Browser.Wd.FindElements(By.XPath("//ul[@id='ddlonHoldReason_listbox']/li"));

            foreach (IWebElement temp in drpValues)
            {
                if (temp.Text.Equals(expectedValue))
                {
                    found = true;
                }
            }

            if (found)
            {
                Assert.IsTrue(true,"Inactive On Hold Reason is not present on Additonal diag section");
            }
            else if(!found)
            {
                Assert.Fail("Inactive On Hold Reason is not displayed on Additonal diag section");

            }
        }


        [Then(@"Verify PIR Page Additional Diagnosis section On Hold reason ""(.*)"" is not displayed")]
        public void ThenVerifyPIRPageAdditionalDiagnosisSectionOnHoldReasonIsNotDisplayed(string p0)
        {
            string expectedValue = tmsCommon.GenerateData(p0);
            bool found = false;
            IWebElement drp = Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlonHoldReason_listbox']"));
            fw.ExecuteJavascript(drp);
            tmsWait.Hard(4);
           IReadOnlyCollection<IWebElement> drpValues = Browser.Wd.FindElements(By.XPath("//ul[@id='ddlonHoldReason_listbox']/li"));

            foreach(IWebElement temp in drpValues)
            {
                if(temp.Text.Equals(expectedValue))
                {
                    found = true;
                }
            }

            if(found)
            {
                Assert.Fail("Inactive On Hold Reason should not present");
            }
        }


        [When(@"PIR Page Additional Diagnosis section ""(.*)"" is set to ""(.*)""")]
        public void WhenPIRPageAdditionalDiagnosisSectionIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(2);
            string field=tmsCommon.GenerateData(p0); ;
            string value = tmsCommon.GenerateData(p1);
            switch(field)
            {
                case "Diagnosis Code":
                    ReUsableFunctions.enterValueOnWebElement(RAM.PIRPage.DiagCode, value);                   
                    break;
                case "Encounter From Date":

                    tmsWait.Hard(3);

                    string dateValue = tmsCommon.GenerateData(value);
                    string modValue = (Convert.ToInt32(((dateValue.Split(' '))[0].Split('/'))[2])).ToString();
                    string finalValue = "01/01/" + modValue + "";
                    //ReUsableFunctions.enterValueOnWebElementWithoutClear(RAM.PIRPage.EncounterFromDate, finalValue);
                    AngularFunction.enterDate(RAM.PIRPage.EncounterFromDate, finalValue);
                    //RAM.PIRPage.DiagCode.SendKeys(Keys.Tab);
                    //string fromDateValue = finalValue.Replace("/", "");
                    //IWebElement fromDate = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='searchMember-txt-encounterFromDate']//input[@class='k-input']"));
                    //string[] value12 = value.Split('/');
                    //string[] value13 = value12[2].Split(' ');
                    //fromDate.SendKeys(value12[0]);
                    //fromDate.SendKeys(value12[1]);
                    //fromDate.SendKeys(value13[0]);

                    //Browser.Wd.FindElement(fromDate).Clear();
                    //Browser.Wd.FindElement(fromDate).SendKeys(fromDateValue);
                    // AngularFunction.enterDate(fromDate, finalValue);


                    break;
                case "Encounter To Date":
                    tmsWait.Hard(3);

                    string dateValue1 = tmsCommon.GenerateData(value);
                    string modValue1 = (Convert.ToInt32(((dateValue1.Split(' '))[0].Split('/'))[2])).ToString();
                    string finalValue1 = "01/01/" + modValue1 + "";
                    //fw.ExecuteJavascript(RAM.PIRPage.EncounterToDate);
                    string tdate = DateTime.Today.Date.ToString();
                    string[] value01 = tdate.Split(' ');
                    IWebElement ele1 = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='searchMember-txt-encounterToDate']//span/input"));
                    string[] value1 = value01[0].Split('/');
                    ele1.SendKeys(value1[0]);
                    ele1.SendKeys(value1[1]);
                    ele1.SendKeys(value1[2]);
                    //ele1.Clear();

                    AngularFunction.enterDate(RAM.PIRPage.EncounterToDate, finalValue1);
                    //RAM.PIRPage.EncounterToDate.Clear();
                    //ReUsableFunctions.enterValueOnWebElementWithoutClear(RAM.PIRPage.EncounterToDate, value);
                    //IWebElement ele1 = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='searchMember-txt-encounterToDate']//span/input"));
                    //string value1 = value.Replace("/", "");
                    //ele1.Clear();
                    //ele1.SendKeys(value1);
                    tmsWait.Hard(3);
                    break;
                case "EncounterFromDate":
                    RAM.PIRPage.EncounterToDate.Clear();
                    ReUsableFunctions.enterValueOnWebElementWithoutClear(RAM.PIRPage.EncounterFromDate, value);
                    break;
                case "Provider ID":
                    ReUsableFunctions.enterValueOnWebElement(RAM.PIRPage.ProviderID, value);
                    break;
                case "Reference Information":
                    tmsWait.Hard(2);
                    ReUsableFunctions.enterValueOnWebElement(RAM.PIRPage.ReferenceInformation, value);
                    break;
                case "Type of Service":
                    //UIMODUtilFunctions.selectDropDownValueFromGendoUI(RAM.PIRPage.TypeOfServiceDropdownlist, value);     
                    By Drp = By.XPath("//kendo-dropdownlist[@test-id='searchDiag-txt-ddlTypeofservice']//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + value + "']");
                    fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                    fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                    break;
                case "Reason":
                    //UIMODUtilFunctions.selectDropDownValueFromGendoUI(RAM.PIRPage.OnHoldReasonDrpdownlist, value);
                    By Drpreason = By.XPath("//kendo-dropdownlist[@test-id='searchDiag-txt-ddlonHoldReason']//span[@class='k-select']");
                    By typeappreason = By.XPath("//li[text()='" + value + "']");
                    fw.ExecuteJavascript(Browser.Wd.FindElement(Drpreason));
                    fw.ExecuteJavascript(Browser.Wd.FindElement(typeappreason));
                    break;
                case "Claim Number":
                    ReUsableFunctions.enterValueOnWebElement(RAM.PIRPage.ClaimNumber, value);
                    break;
            }
        }

        [When(@"PIR Page Save button is Clicked")]
        public void WhenPIRPageSaveButtonIsClicked()
        {
            tmsWait.Hard(3);          
            fw.ExecuteJavascript(RAM.PIRPage.SaveButton);
            
        }

        [When(@"PIR Page Save button is Clicked and Verify Message ""(.*)""")]
        public void WhenPIRPageSaveButtonIsClickedAndVerifyMessage(string p0)
        {
            tmsWait.Hard(3);
            fw.ExecuteJavascript(RAM.PIRPage.SaveButton);
            tmsWait.Hard(1);
            //By toastMsg = By.XPath("//div[@class='toast-message'][contains(.,'" + p0 + "')]");
            //tmsWait.WaitForElement(toastMsg);
            //ReUsableFunctions.toasterMessageDisplay(p0);
            By toastMsg = By.XPath("//div[@class='k-notification-content']");
            string actValue = Browser.Wd.FindElement(toastMsg).Text;
            Assert.IsTrue(actValue.Contains(p0));
        }


        [Then(@"Verify RAMX Application PIR page dislayed error toaster message as ""(.*)""")]
        public void ThenVerifyRAMXApplicationPIRPageDislayedErrorToasterMessageAs(string p0)
        {
            try
            {
                By toastMsg = By.XPath("//div[@class='toast-message'][contains(.,'" + p0 + "')]");
                tmsWait.WaitForElement(toastMsg);
                ReUsableFunctions.toasterMessageDisplay(p0);
            }
            catch (NoSuchElementException) {
                tmsWait.Hard(1);
                ReUsableFunctions.toasterMessageDisplay(p0);
            }
            
        }

        [When(@"PIR page Reason for Unconfirmed Suspect drop down list is set to ""(.*)""")]
        public void WhenPIRPageReasonForUnconfirmedSuspectDropDownListIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            By loc = By.CssSelector("[test-id='pirResponse-select-unconfirmedSuspects']");
            ReUsableFunctions.selectValueFromDropDown(Browser.Wd.FindElement(loc), p0);
        }

        [When(@"PIR page Submit Button is Clicked")]
        public void WhenPIRPageSubmitButtonIsClicked()
        {
            By loc = By.CssSelector("[test-id='pirResponse-btn-add']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
        }
        [When(@"PIR Page Warning dialog Are you sure you are completed with this record\? This PIR record will remain open as none of the diagnosis codes are confirmed OK Button is Clicked")]
        public void WhenPIRPageWarningDialogAreYouSureYouAreCompletedWithThisRecordThisPIRRecordWillRemainOpenAsNoneOfTheDiagnosisCodesAreConfirmedOKButtonIsClicked()
        {
            UIMODUtilFunctions.clickOnConfirmationYesDialog();
        }
        [Then(@"Verify PIR Page displayed Information message as ""(.*)""")]
        public void ThenVerifyPIRPageDisplayedInformationMessageAs(string p0)
        {
            By loc = By.XPath("//label[contains(.,'"+p0+"')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }
        [Then(@"Verify On Hold and Diagnosis Review page displayed Diag Code as ""(.*)"" Provider ID as ""(.*)"" Reference Info as ""(.*)"" Member ID as ""(.*)"" On Hold Reason as ""(.*)"" Status as ""(.*)""")]
        public void ThenVerifyOnHoldAndDiagnosisReviewPageDisplayedDiagCodeAsProviderIDAsReferenceInfoAsMemberIDAsOnHoldReasonAsStatusAs(string p0, string p1, string p2, string p3, string p4, string status)
        {
            tmsWait.Hard(2);
            string dia= tmsCommon.GenerateData(p0);
            string pro= tmsCommon.GenerateData(p1);
            string refer= tmsCommon.GenerateData(p2);
            string mem= tmsCommon.GenerateData(p3);
            string reason = tmsCommon.GenerateData(p4);
            By loc = By.XPath("//kendo-grid[@test-id='viewOnHoldDiagnosis-grid-resultsGrid']//td[contains(.,'" + dia + "')]/following-sibling::td[contains(.,'" + pro + "')]/following-sibling::td[contains(.,'"+ refer + "')]/following-sibling::td[contains(.,'"+mem+"')]/following-sibling::td[contains(.,'" + reason + "')]/following-sibling::td[contains(.,'" + status + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);

        }
        [Then(@"Verify On Hold and Diagnosis Review page displayed Diag Code as ""(.*)"" Provider ID as ""(.*)"" Reference Info as ""(.*)"" Member ID as ""(.*)"" On Hold Reason as ""(.*)"" Status as ""(.*)"" is not present")]
        public void ThenVerifyOnHoldAndDiagnosisReviewPageDisplayedDiagCodeAsProviderIDAsReferenceInfoAsMemberIDAsOnHoldReasonAsStatusAsIsNotPresent(string p0, string p1, string p2, string p3, string p4, string status)
        {
            string dia = tmsCommon.GenerateData(p0);
            string pro = tmsCommon.GenerateData(p1);
            string refer = tmsCommon.GenerateData(p2);
            string mem = tmsCommon.GenerateData(p3);
            string reason = tmsCommon.GenerateData(p4);
            By loc = By.XPath("//kendo-grid[@test-id='viewOnHoldDiagnosis-grid-resultsGrid']//td[contains(.,'" + dia + "')]/following-sibling::td[contains(.,'" + pro + "')]/following-sibling::td[contains(.,'" + refer + "')]/following-sibling::td[contains(.,'" + mem + "')]/following-sibling::td[contains(.,'" + reason + "')]/following-sibling::td[contains(.,'" + status + "')]");
            UIMODUtilFunctions.elementNotPresenceUsingLocators(loc);
        }

        [Then(@"Verify PIR Page displayed ""(.*)"" message")]
        public void ThenVerifyPIRPageDisplayedMessage(string p0)
        {
            By msg = By.XPath("//label[contains(.,'"+p0+"')]");
            UIMODUtilFunctions.elementNotPresenceUsingLocators(msg);
        }

        [When(@"on Audit View Export page Action is selected as ""(.*)""")]
        public void WhenOnAuditViewExportPageActionIsSelectedAs(string p0)
        {
            //By Drp = By.XPath("//label[contains(.,'Action')]/parent::div//span[@class='k-select']");
            //fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            //By typeapp = By.XPath("//li[text()='" + p0 + "']");
            //fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

            IWebElement elecType = Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='audit-drp-actions']//input"));

            elecType.SendKeys(p0);
            tmsWait.Hard(3);
            elecType.SendKeys(OpenQA.Selenium.Keys.Enter);

            tmsWait.Hard(3);
        }


        [When(@"Audit View Export page Member ID ""(.*)"" is selected from Member ID Lookup")]
        public void WhenAuditViewExportPageMemberIDIsSelectedFromMemberIDLookup(string p0)
        {
            string mem = tmsCommon.GenerateData(p0);
           // fw.ExecuteJavascript(cfAuditViewExport.AuditViewExportPage.MemberLookup);
           // tmsWait.Hard(3);
            ReUsableFunctions.enterValueOnWebElement(cfAuditViewExport.AuditViewExportPage.MemberIDTextbox, mem);
            //fw.ExecuteJavascript(cfAuditViewExport.AuditViewExportPage.SearchBtn);
            //By res = By.XPath("//kendo-grid[@test-id='audit-partial-auditgrd']//td[contains(.,'" + mem+"')]/preceding-sibling::td/input");
            //UIMODUtilFunctions.clickOnWebElementUsingLocators(res);
            //fw.ExecuteJavascript(cfAuditViewExport.AuditViewExportPage.AddBtn);

        }

        [When(@"Audit View Export page Search Button is Clicked")]
        public void WhenAuditViewExportPageSearchButtonIsClicked()
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(cfAuditViewExport.AuditViewExportPage.AuditViewExportPageSearchButton);
            tmsWait.Hard(2);
        }

        [Then(@"Verify Audit View Export page displayed Member ID ""(.*)"" Activity ""(.*)""")]
        public void ThenVerifyAuditViewExportPageDisplayedMemberIDActivity(string p0, string p1)
        {
            string mem = tmsCommon.GenerateData(p0);
            string activity = tmsCommon.GenerateData(p1);
            By component = By.XPath("(//kendo-grid[@test-id='audit-partial-auditgrd']//tbody//tr/td[contains(.,'"+ mem + "')]/following-sibling::td[contains(.,'"+ activity + "')])[1]");
            AngularFunction.elementPresenceUsingLocators(component);

        }


        [When(@"Audit View Export page ""(.*)"" is set to ""(.*)""")]
        public void WhenAuditViewExportPageIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);

            switch(field.ToLower())
            {
                case "activity": /*fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//multiselect[@test-id='audit-drp-activity']//button")));
                                 tmsWait.Hard(1);
                                 fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//multiselect[@test-id='audit-drp-activity']//ul//li/a[contains(.,'"+ value +"')]"))); */

                                    IWebElement elecType = Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='audit-drp-activity']//input"));

                                    elecType.SendKeys(value);
                                    tmsWait.Hard(3);
                                    elecType.SendKeys(OpenQA.Selenium.Keys.Enter);
                                    break;
                case "action":   fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//multiselect[@test-id='audit-drp-actions']//button")));
                                 tmsWait.Hard(1);
                                 fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//multiselect[@test-id='audit-drp-actions']//ul//li[contains(.,'Add')]")));
                                 break;
                case "fromdate": IWebElement fromdate = Browser.Wd.FindElement(By.XPath("//input[@test-id='audit-txt-fromdate']"));
                                 fromdate.Clear();
                                 fromdate.SendKeys(value);
                                 break;
                case "todate":   IWebElement T0date = Browser.Wd.FindElement(By.XPath("//input[@test-id='audit-txt-todate']"));
                                 T0date.Clear();
                                 tmsWait.Hard(1);
                                 T0date.SendKeys(value);
                                 break;
            }
        }




        [Then(@"Verify Audit View Export page displayed Member as ""(.*)"" Activity as ""(.*)"" Field as ""(.*)"" Before as ""(.*)"" After as ""(.*)"" Action as ""(.*)""")]
        public void ThenVerifyAuditViewExportPageDisplayedMemberAsActivityAsFieldAsBeforeAsAfterAsActionAs(string p0, string p1, string p2, string p3, string p4, string p5)
        {
            tmsWait.Hard(3);
            string mem = tmsCommon.GenerateData(p0);
            string act = tmsCommon.GenerateData(p1);
            string field = tmsCommon.GenerateData(p2);
            string before = tmsCommon.GenerateData(p3);
            string after = tmsCommon.GenerateData(p4);
            string action = tmsCommon.GenerateData(p5);
            By loc = By.XPath("(//kendo-grid[@test-id='audit-partial-auditgrd']//td[contains(.,'" + mem+"')]/following-sibling::td[contains(.,'"+act+"')]/following-sibling::td[contains(.,'"+field+"')]/following-sibling::td[contains(.,'"+before+"')]/following-sibling::td[contains(.,'"+after+"')]//following-sibling::td[contains(.,'Add')])[1]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }

        [When(@"Audit View Export page Member ID ""(.*)"" On Hold reason record is Exported")]
        public void WhenAuditViewExportPageMemberIDOnHoldReasonRecordIsExported(string p0)
        {
            string memb = tmsCommon.GenerateData(p0);
            By loc = By.XPath("(//div[@test-id='audit-partial-auditgrd']//td[contains(.,'" + memb + "')]/following-sibling::td[contains(.,'onHoldReasonId')]/preceding-sibling::td/input)[1]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            tmsWait.Hard(2);
            fw.ExecuteJavascript(cfAuditViewExport.AuditViewExportPage.AuditExportPageExportButton);
            tmsWait.Hard(4);
        }


        [When(@"Edit Diagnosis Code Detail page Status drop down list is set to ""(.*)""")]
        public void WhenEditDiagnosisCodeDetailPageStatusDropDownListIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            By status = By.XPath("(//label[contains(.,'Status')]/parent::div//span[@class='k-select'])[2]");
            By statusValue = By.XPath("//li[text()='" + value + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(status));
            fw.ExecuteJavascript(Browser.Wd.FindElement(statusValue));
            tmsWait.Hard(3);
        }

        [When(@"Edit Diagnosis Code Detail page Update button is Clicked")]
        public void WhenEditDiagnosisCodeDetailPageUpdateButtonIsClicked()
        {
            fw.ExecuteJavascript(cfRAMXOnHoldDiagnosisReview.EditDiagnosisDetails.Update);
            tmsWait.Hard(3);
        }

        [When(@"on Edit Diagnosis Code Detail page claim number is edited to ""(.*)""")]
        public void WhenOnEditDiagnosisCodeDetailPageClaimNumberIsEditedTo(string p0)
        {
            string claimNumber = tmsCommon.GenerateData(p0);
            cfRAMXOnHoldDiagnosisReview.EditDiagnosisDetails.ClaimID.SendKeys(claimNumber);
            tmsWait.Hard(2);
        }

        [When(@"Verify Edit Diagnosis Code Detail page ""(.*)"" is selected to ""(.*)""")]
        public void WhenVerifyEditDiagnosisCodeDetailPageIsSelectedTo(string p0, string p1)
        {
            IWebElement ddele = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='editOnHoldDiagnosis-txt-ddlCoderId']//span[@class='k-select']"));
            string actual_value = tmsCommon.GenerateData(p1);
            AngularFunction.selectKendoDropDownValue(ddele, actual_value);
        }

        [Then(@"Verify Edit Diagnosis Code Detail page ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyEditDiagnosisCodeDetailPageIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(3);
            string field = tmsCommon.GenerateData(p0);
            string expValue = tmsCommon.GenerateData(p1);
            string actualValue;
            switch(field)
            {
                case "Diagnosis Code":
                    actualValue = cfRAMXOnHoldDiagnosisReview.EditDiagnosisDetails.Diagnosis.GetAttribute("value");
                    ReUsableFunctions.CompareTwoStrings(expValue, actualValue);
                    break;

                case "Provider ID":
                    actualValue = cfRAMXOnHoldDiagnosisReview.EditDiagnosisDetails.Provider.GetAttribute("value");
                    ReUsableFunctions.CompareTwoStrings(expValue, actualValue);
                    break;

                case "Claim Number":
                    actualValue = cfRAMXOnHoldDiagnosisReview.EditDiagnosisDetails.ClaimID.GetAttribute("value");
                    ReUsableFunctions.CompareTwoStrings(expValue, actualValue);
                    break;

                case "Member ID":
                    actualValue = cfRAMXOnHoldDiagnosisReview.EditDiagnosisDetails.MemberID.GetAttribute("value");
                    ReUsableFunctions.CompareTwoStrings(expValue, actualValue);
                    break;
                case "Coder ID":
                    IWebElement ddele = Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Coder ID')]/parent::div//span[@class='k-input'])[2]"));
                    string actual_value = ddele.Text;
                    Assert.AreEqual(expValue, actual_value, "Coder ID is matched with expected one");
                    tmsWait.Hard(3);
                    break;

                case "Chart ID":
                    actualValue = cfRAMXOnHoldDiagnosisReview.EditDiagnosisDetails.ChartID.GetAttribute("value");
                    ReUsableFunctions.CompareTwoStrings(expValue, actualValue);
                    break;

                case "On Hold Reason":
                    IWebElement onHold =Browser.Wd.FindElement(By.XPath("(//label[contains(.,'On-Hold Reason')]/parent::div//span[@class='k-input'])[2]"));
                     actual_value = onHold.Text;
                    Assert.AreEqual(expValue, actual_value);
                    tmsWait.Hard(3);
                    break;

                case "Status":
                    IWebElement status = Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Status')]/parent::div//span[@class='k-input'])[2]"));
                    actual_value = status.Text;
                    Assert.AreEqual(expValue, actual_value);
                    tmsWait.Hard(3);
                    break;
            }
        }

        [Then(@"Verify Edit Diagnosis Code Detail page Status is set to ""(.*)""")]
        public void ThenVerifyEditDiagnosisCodeDetailPageStatusIsSetTo(string p0)
        {
            tmsWait.Hard(7);
            string status = tmsCommon.GenerateData(p0);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='ddlStatus_listbox']/span/span[contains(.,'" + status + "')]"));
            fw.ScrollWindowToViewElement(ele);
            tmsWait.Hard(3);
            Assert.IsTrue(ele.Displayed, " Expected status is not displayed");
        }


        [When(@"On Hold and Diagnosis Review page Edit displayed Diag Code as ""(.*)"" Provider ID as ""(.*)"" Reference Info as ""(.*)"" Member ID as ""(.*)"" On Hold Reason as ""(.*)"" Status as ""(.*)"" data")]
        public void WhenOnHoldAndDiagnosisReviewPageEditDisplayedDiagCodeAsProviderIDAsReferenceInfoAsMemberIDAsOnHoldReasonAsStatusAsData(string p0, string p1, string p2, string p3, string p4, string status)
        {
            string dia = tmsCommon.GenerateData(p0);
            string pro = tmsCommon.GenerateData(p1);
            string refer = tmsCommon.GenerateData(p2);
            string mem = tmsCommon.GenerateData(p3);
            string reason = tmsCommon.GenerateData(p4);
            IWebElement edit = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='viewOnHoldDiagnosis-grid-resultsGrid']//td[contains(.,'" + dia + "')]/following-sibling::td[contains(.,'" + pro + "')]/following-sibling::td[contains(.,'" + refer + "')]/following-sibling::td[contains(.,'" + mem + "')]/following-sibling::td[contains(.,'" + reason + "')]/following-sibling::td[contains(.,'" + status + "')]//parent::td//following-sibling::td/a/span[@class='cursorLink fas fa-edit']"));
           // UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            fw.ExecuteJavascript(edit);
            tmsWait.Hard(2);
        }

        [Then(@"Verify RAMX PIR Page Potential Related Diagnosis section displayed Claim ID as ""(.*)"" On Hold Reason as ""(.*)""")]
        public void ThenVerifyRAMXPIRPagePotentialRelatedDiagnosisSectionDisplayedClaimIDAsOnHoldReasonAs(string p0, string p1)
        {
            string claim = tmsCommon.GenerateData(p0);
            string reason = tmsCommon.GenerateData(p1);
            By loc = By.XPath("//kendo-grid[@test-id='pirResponse-grid-potentialRelatedDiagnosesGrid']//td[contains(.,'" + claim + "')]/following-sibling::td[contains(.,'"+ reason + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }

        [Then(@"Verify RAMX PIR Page Additional Diagnosis section section displayed Claim ID as ""(.*)"" On Hold Reason as ""(.*)""")]
        public void ThenVerifyRAMXPIRPageAdditionalDiagnosisSectionSectionDisplayedClaimIDAsOnHoldReasonAs(string p0, string p1)
        {
            string claim = tmsCommon.GenerateData(p0);
            string reason = tmsCommon.GenerateData(p1);
            By loc = By.XPath("//kendo-grid-list[@role='presentation']//td[contains(.,'" + claim + "')]/following-sibling::td[contains(.,'" + reason + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }

        [When(@"PIR Page Coder ID drop is set to ""(.*)"" Reason is set to ""(.*)""")]
        [Given(@"PIR Page Coder ID drop is set to ""(.*)"" Reason is set to ""(.*)""")]
        public void WhenPIRPageCoderIDDropIsSetToReasonIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(4);
            string coderID = tmsCommon.GenerateData(p0);
            string reason = tmsCommon.GenerateData(p1);
            //TMSoR1.FrameworkCode.HCC_RAM.PIRPage

            if (coderID != "")
            {
                //new SelectElement(Browser.Wd.FindElement(By.CssSelector("[test-id='pirResponse-select-coders']"))).SelectByText(coderID);
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='pirResponse-select-coders']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + coderID + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

            }
            else {
                //new SelectElement(Browser.Wd.FindElement(By.CssSelector("[test-id='pirResponse-select-coders']"))).SelectByIndex(1);
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='pirResponse-select-coders']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + coderID + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            }
                tmsWait.Hard(1);
            
            //new SelectElement(Browser.Wd.FindElement(By.CssSelector("[test-id='pirResponse-select-unconfirmedSuspects']"))).SelectByText(reason);
            //tmsWait.Hard(1);
        }
       


        [Then(@"Verify On Hold and Diagnosis Review page ""(.*)"" link is present")]
        public void ThenVerifyOnHoldAndDiagnosisReviewPageLinkIsPresent(string p0)
        {
            By loc = By.XPath("//span[contains(.,'"+p0+"')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }



        [When(@"On Hold and Diagnosis Review page ""(.*)"" link is clicked")]
        public void WhenOnHoldAndDiagnosisReviewPageLinkIsClicked(string p0)
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'Pending for Coder Correction')]")));
            tmsWait.Hard(2);
        }


        [Then(@"Verify On Hold and Diagnosis Review page displayed Diag Code as ""(.*)"" and ChartId ""(.*)""")]
        public void ThenVerifyOnHoldAndDiagnosisReviewPageDisplayedDiagCodeAsAndChartId(string p0, string p1)
        {
            string diagcode = tmsCommon.GenerateData(p0);
            string chart_id = tmsCommon.GenerateData(p1.ToString());
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@id='onHoldDiagnosisGrid']//tbody//td[contains(.,'" + diagcode + "')]/parent::tr//td[contains(.,'" + chart_id + "')]")).Displayed, "Record is not displayed");
        }

        [Then(@"Verify RAM On Hold and Diagnosis Review page displayed Diag Code as ""(.*)"" and ChartId ""(.*)""")]
        public void ThenVerifyRAMOnHoldAndDiagnosisReviewPageDisplayedDiagCodeAsAndChartId(string p0, string p1)
        {
            string diagcode = tmsCommon.GenerateData(p0);
            string chart_id = tmsCommon.GenerateData(p1.ToString());
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='viewOnHoldDiagnosis-grid-resultsGrid']//td[contains(.,'" + diagcode + "')]/parent::tr//td[contains(.,'" + chart_id + "')]")).Displayed, "Record is not displayed");
        }


        [Then(@"Verify On Hold and Diagnosis Review page Not displayed Diag Code as ""(.*)"" and ChartId ""(.*)""")]
        public void ThenVerifyOnHoldAndDiagnosisReviewPageNotDisplayedDiagCodeAsAndChartId(string p0, string p1)
        {
            string diagcode = tmsCommon.GenerateData(p0);
            string chart_id = tmsCommon.GenerateData(p1.ToString());
            tmsWait.Hard(3);
             bool isNotDisplayed = false;
            try
            {
                Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@id='onHoldDiagnosisGrid']//tbody//td[contains(.,'" + diagcode + "')]/parent::tr//td[contains(.,'" + chart_id + "')]")).Displayed, "Record is not displayed");
                isNotDisplayed = true;
            }
            catch
            {

            }

            Assert.IsFalse(isNotDisplayed, "Expected Row is exist as it should not");
            
        }

        [When(@"On Hold and Diagnosis Review page Chart ID is set to ""(.*)""")]
        public void WhenOnHoldAndDiagnosisReviewPageChartIDIsSetTo(string p0)
        {
            string chart = tmsCommon.GenerateData(p0);
            By loc = By.CssSelector("[test-id='viewOnHolDiagnosis-txt-chartId']");
            UIMODUtilFunctions.enterValueOnWebElementUsingLocators(loc, chart);
        }



        [When(@"On Hold and Diagnosis Review page Member ID is set to ""(.*)""")]
        public void WhenOnHoldAndDiagnosisReviewPageMemberIDIsSetTo(string p0)
        {
            string mem = tmsCommon.GenerateData(p0);
            By loc = By.CssSelector("[test-id='viewOnHolDiagnosis-txt-txtMemberId']");
            UIMODUtilFunctions.enterValueOnWebElementUsingLocators(loc, mem);
        }

        [When(@"On Hold and Diagnosis Review page Search button is Clicked")]
        public void WhenOnHoldAndDiagnosisReviewPageSearchButtonIsClicked()
        {
            By loc = By.CssSelector("[test-id='viewOnHolDiagnosis-button-search']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
        }

        [When(@"On Hold and Diagnosis Review page ""(.*)"" button is clicked")]
        public void WhenOnHoldAndDiagnosisReviewPageButtonIsClicked(string p0)
        {
            string button_name = tmsCommon.GenerateData(p0);
            switch(button_name.ToLower())
            {
                case "release from on hold": fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='viewOnHoldDiagnosis-btn-releaseFromOnHold']")));
                    tmsWait.Hard(2); fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']"))); break;
                case "reject from on hold":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='viewOnHoldDiagnosis-btn-rejectFromOnHold']")));
                    tmsWait.Hard(2); fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']"))); break;
            }
        }


        [Then(@"Verify RAMX AuditStatus in Database ""(.*)"" is equal to ""(.*)""")]
        public void ThenVerifyRAMXAuditStatusInDatabaseIsEqualTo(string p0, string p1)
        {
            string actual_status = tmsCommon.GenerateData(p0);
            string expected_status = tmsCommon.GenerateData(p1.ToString());
            Assert.IsTrue(actual_status.Contains(expected_status));
        }


        [Then(@"Verify RAMX DiagnosisCode in Database ""(.*)"" is equal to ""(.*)""")]
        public void ThenVerifyRAMXDiagnosisCodeInDatabaseIsEqualTo(string p0, string p1)
        {
            string actual_diagc = tmsCommon.GenerateData(p0);
            string expected_diagc = tmsCommon.GenerateData(p1.ToString());
            Assert.IsTrue(actual_diagc.Contains(expected_diagc));
        }



        [Then(@"Verify RAMX Application dislayed error toaster message as ""(.*)""")]
        public void ThenVerifyRAMXApplicationDislayedErrorToasterMessageAs(string p0)
        {
            ReUsableFunctions.toasterMessageDisplayVerification(p0);
        }
        [Then(@"RAMX Application PIR Page Back to Record button is Clicked")]
        public void ThenRAMXApplicationPIRPageBackToRecordButtonIsClicked()
        {
            By back = By.CssSelector("[test-id='pirResponse-span-back']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(back);
            tmsWait.Hard(2);
        }

        [Then(@"RAMX Application Manage Suspects page displayed Provider as ""(.*)""")]
        public void ThenRAMXApplicationManageSuspectsPageDisplayedProviderAs(string p0)
        {
            string prov = tmsCommon.GenerateData(p0);
            By record = By.XPath("//kendo-grid[@test-id='manageSuspects-grid-providerResult']//td[contains(.,'" + prov + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(record);
        }

        [Then(@"RAMX Application Manage Suspects page displayed Member as ""(.*)""")]
        public void ThenRAMXApplicationManageSuspectsPageDisplayedMemberAs(string p0)
        {
            string mem = tmsCommon.GenerateData(p0);
            By record = By.XPath("//kendo-grid[@test-id='manageSuspects-grid-memberResult']//td[contains(.,'" + mem + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(record);
        }

        [Then(@"Verify RAMX Application Manage Suspects page displayed toaster message as ""(.*)""")]
        public void ThenVerifyRAMXApplicationManageSuspectsPageDisplayedToasterMessageAs(string p0)
        {
            //ReUsableFunctions.toasterMessageDisplay(p0);
            //ReUsableFunctions.toasterMessageDisplay(p0);
            tmsWait.Hard(2);
            By toastMsg = By.XPath("//div[@class='k-notification-content']");
            string actValue = Browser.Wd.FindElement(toastMsg).Text;
            Assert.IsTrue(actValue.Contains(p0));
        }
        [Given(@"variable ""(.*)"" is set to from RAMX Dashboard page")]
        public void GivenVariableIsSetToFromRAMXDashboardPage(string p0)
        {
            tmsWait.Hard(5);
            string variableType = tmsCommon.GenerateData(p0);
            string dataloadDateStr = Browser.Wd.FindElement(By.CssSelector("[id='lblLastDataLoad']")).Text;
            if(dataloadDateStr.Contains("Not available"))
            {
                Assert.Fail(" Failed due to Non availability of Data Load");
            }
            else
            {
                string finalDataLoadDate = (dataloadDateStr.Split(' '))[0];
                fw.setVariable(variableType, finalDataLoadDate);
            }
            
        }


        [When(@"variable ""(.*)"" is set to ""(.*)"" from PIR Page")]
        public void WhenVariableIsSetToFromPIRPage(string variableType, string p1)
        {
            tmsWait.Hard(5);
            string returnValue;
            switch(variableType)
            {
                case "ProviderID":
                    returnValue = Browser.Wd.FindElement(By.CssSelector("[test-id='pirResponse-span-providerIdTxt']")).Text;
                    //returnValue = Browser.Wd.FindElement(By.CssSelector("[test-id='manageSuspects-txt-providerId']")).Text;
                    fw.setVariable(p1, returnValue);
                    break;
                case "PageDiagID1":
                    By plus = By.CssSelector("[ng-hide='!potentialDivHideFlag']");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(plus);
                    tmsWait.Hard(3);
                    returnValue = Browser.Wd.FindElement(By.XPath("(//div[@id='potentialDiagnosesGrid']//table//span[@ng-bind='dataItem.code'])[1]")).Text;
                    GlobalRef.PageDiagCodeID1 = returnValue;
                    fw.setVariable(p1, returnValue);
                    break;
                case "PageDiagID2":
                    
                    tmsWait.Hard(3);
                    returnValue = Browser.Wd.FindElement(By.XPath("(//div[@id='potentialDiagnosesGrid']//table//span[@ng-bind='dataItem.code'])[2]")).Text;
                    GlobalRef.PageDiagCodeID2 = returnValue;
                    fw.setVariable(p1, returnValue);
                    break;
                case "PageDiagID3":
                   
                    tmsWait.Hard(3);
                    returnValue = Browser.Wd.FindElement(By.XPath("(//div[@id='potentialDiagnosesGrid']//table//span[@ng-bind='dataItem.code'])[3]")).Text;
                    GlobalRef.PageDiagCodeID3 = returnValue;
                    fw.setVariable(p1, returnValue);
                    break;
                case "MemberID":
                    returnValue = Browser.Wd.FindElement(By.CssSelector("[test-id='pirResponse-span-memberIdTxt']")).Text;
                    GlobalRef.MEMID = returnValue;
                    fw.setVariable(p1, returnValue);
                    break;
                case "MemberName":
                    returnValue = Browser.Wd.FindElement(By.CssSelector("[test-id='pirResponse-span-memberNameTxt']")).Text;
                    GlobalRef.MEMName = returnValue;
                    fw.setVariable(p1, returnValue);
                    break;
                case "ProviderID1":
                    returnValue = Browser.Wd.FindElement(By.CssSelector("[test-id='pirResponse-span-providerIdTxt']")).Text;
                    fw.setVariable(p1, returnValue);
                    break;
                case "MemberID1":
                    returnValue = Browser.Wd.FindElement(By.CssSelector("[test-id='pirResponse-span-memberIdTxt']")).Text;
                    fw.setVariable(p1, returnValue);
                    break;
                case "EncounterFromDate":
                    returnValue = Browser.Wd.FindElement(By.XPath("(//span[@test-id='pirResponse-span-dosTxt'])[1]")).Text;
                    fw.setVariable(p1, returnValue);
                    break;
                case "DOS":
                    returnValue = Browser.Wd.FindElement(By.CssSelector("[test-id='pirResponse-span-dosTxt']")).Text;
                    fw.setVariable(p1, returnValue);
                    break;
                case "HCC Probability":
                    returnValue = Browser.Wd.FindElement(By.CssSelector("[test-id='pirResponse-span-suspectHccDescriptionTxt']")).Text;
                    fw.setVariable(p1, returnValue);
                    break;
                case "HCC Name":
                    returnValue = Browser.Wd.FindElement(By.CssSelector("[test-id='pirResponse-span-suspectHccNameTxt']")).Text;
                    fw.setVariable(p1, returnValue);
                    break;
                case "HCC Description":
                    returnValue = Browser.Wd.FindElement(By.CssSelector("[test-id='pirResponse-span-suspectHccDescriptionTxt']")).Text;
                    fw.setVariable(p1, returnValue);
                    break;
                case "Top HCC":
                    returnValue = Browser.Wd.FindElement(By.XPath("//div[@id='topKnownHccGrid']/table/tbody/tr/td[1]/span")).Text;
                    fw.setVariable(p1, returnValue);
                    break;
                case "Submitted Code":
                    returnValue = Browser.Wd.FindElement(By.CssSelector("[test-id='pirResponse-span-diagnosisTxt']")).Text;
                    fw.setVariable(p1, returnValue);
                    break;



            }

        }



    }
}
