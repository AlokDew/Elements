﻿using OpenQA.Selenium;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.RAMX
{
    class RAMX
    {
        public static RAMXHomePage RAMXHomePage { get { return new RAMXHomePage(); } }
        public static RAMXDashboardPage RAMXDashboardPage { get { return new RAMXDashboardPage(); } }
        public static RAMXAdmin RAMXAdmin { get { return new RAMXAdmin(); } }
        public static RAMXManageSuspectsPage RAMXManageSuspectsPage { get { return new RAMXManageSuspectsPage(); } }
    }

    [Binding]
    public class RAMXHomePage
    {
        public IWebElement RAMXHomePageTitle { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='header-title-applicationName']")); } }
        public IWebElement RAMXDashboard { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='ramxDashboard-span-dashboard']")); } }
        public IWebElement RAMXMenu_Hamburger { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='header-btn-expanMenu']")); } }
        public IWebElement RAMTitle { get { return Browser.Wd.FindElement(By.XPath("//span[@test-id='header-title-applicationName']")); } }

    }

    [Binding]
    public class RAMXManageSuspectsPage
    {
        public IWebElement PIRControlNum { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='manageSuspects-input-pitControlNumber']")); } }
       
    }


    [Binding]
    public class RAMXDashboardPage
    {
        public IWebElement RAMXSuspectSummaryGrid { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ramxDashboard-grid-suspectSummary']")); } }
            
        public IWebElement RAMXProviderSummaryGrid { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ramDashboard-lbl-providerSummary']")); } }
        public IWebElement RAMXApp { get { return Browser.Wd.FindElement(By.XPath(".//nav[contains(.,'Risk Adjustment Manager for Exchanges')]/div[@class='navbar-text border-left border-right border-white flex-fill']")); } }
    }

    public class RAMXAdmin
    {
        public IWebElement RAMXOnHoldDiagReview_MemID { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='viewOnHolDiagnosis-txt-txtMemberId']")); } }
        public IWebElement RAMXOnHoldDiagReview_ProviderID { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='viewOnHolDiagnosis-txt-providerId']")); } }
        public IWebElement RAMXOnHoldDiagReview_Status { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='viewOnHolDiagnosis-select-status']")); } }
        public IWebElement RAMXOnHoldDiagReview_OnHoldReason { get { return Browser.Wd.FindElement(By.XPath("//span[@test-id='viewOnHolDiagnosis-select-reason']")); } }

        public IWebElement RAMXConfig_ModelYear { get { return Browser.Wd.FindElement(By.XPath("//[@test-id='configuration-txt-modelYear']")); } }
        public IWebElement RAMXConfig_AuditorConfigCheckbox { get { return Browser.Wd.FindElement(By.XPath("//[@test-id='configuration-lbl-auditorConfiguration']")); } }
        public IWebElement RAMXConfig_ExecZoneCode { get { return Browser.Wd.FindElement(By.XPath("//[@test-id='configuration-txt-executionZoneCode']")); } }
        public IWebElement RAMXConfig_SubmissionTypeCode { get { return Browser.Wd.FindElement(By.XPath("//[@test-id='configuration-txt-submissionTypeCode']")); } }

        public IWebElement RAMXConfig_ReleaseNumber { get { return Browser.Wd.FindElement(By.XPath("//[@test-id='configuration-txt-releaseNumber']")); } }
        public IWebElement RAMXConfig_DeleteVoidCode { get { return Browser.Wd.FindElement(By.XPath("//[@test-id='configuration-txt-addDeleteVoidCode']")); } }
        public IWebElement RAMXConfig_SourceCode { get { return Browser.Wd.FindElement(By.XPath("//[@test-id='configuration-txt-sourceCode']")); } }
    }



}

