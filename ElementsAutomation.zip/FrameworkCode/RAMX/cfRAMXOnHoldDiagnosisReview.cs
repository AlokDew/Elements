﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.RAMX
{
    class cfRAMXOnHoldDiagnosisReview
    {
        public static OnHoldDiagnosisReview RAMXHomePage { get { return new OnHoldDiagnosisReview(); } }
        public static EditDiagnosisDetails EditDiagnosisDetails { get { return new EditDiagnosisDetails(); } }
        

    }
    [Binding]
    public class EditDiagnosisDetails
    {
        public IWebElement Diagnosis { get { return Browser.Wd.FindElement(By.Id("txtDiagCode")); } }
        public IWebElement Provider { get { return Browser.Wd.FindElement(By.Id("txtProviderId")); } }
        public IWebElement MemberID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='editOnHoldDiagnosis-txt-txtMemberId']")); } }
        public IWebElement ClaimID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='editOnHoldDiagnosis-txt-txtPlanClaimId']")); } }
        public IWebElement ChartID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='editOnHoldDiagnosis-txt-txtClartId']")); } }
        public IWebElement CoderID { get { return Browser.Wd.FindElement(By.XPath("(//span[@aria-owns='ddlCoderId_listbox']/span/span)[1]")); } }
        public IWebElement OnHoldReason { get { return Browser.Wd.FindElement(By.XPath("(//span[@aria-owns='ddlonHoldReason_listbox']/span/span)[1]")); } }
        public IWebElement Status { get { return Browser.Wd.FindElement(By.XPath("(//span[@aria-owns='ddlStatus_listbox']/span/span)[1]")); } }
        public IWebElement StatusDrp { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlStatus_listbox']")); } }
        public IWebElement Update { get { return Browser.Wd.FindElement(By.Id("btnSave")); } }
        public IWebElement Reference { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='editOnHoldDiagnosis-txt-txtReferenceInformation']")); } }
    }


    [Binding]
    public class OnHoldDiagnosisReview
    {
        public IWebElement MemberID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='viewOnHolDiagnosis-lbl-member']")); } }
        public IWebElement ProviderID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='viewOnHolDiagnosis-txt-providerId']")); } }
        public IWebElement ChartID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='viewOnHolDiagnosis-txt-chartId']")); } }
        public IWebElement CoderIDDrpdown { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='viewOnHolDiagnosis-select-coderId']")); } }
        public IWebElement StatusDrpdown { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='viewOnHolDiagnosis-select-status']")); } }
        public IWebElement ReasonDrpdown { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='viewOnHolDiagnosis-select-reason']")); } }
        public IWebElement SearchBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='viewOnHolDiagnosis-button-search']")); } }
        public IWebElement ResetBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='viewOnHolDiagnosis-button-resetSearch']")); } }

        public IWebElement PendingforOnHoldLink { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='viewOnHolDiagnosis-label-lblQuickLinks']/parent::div/span[1]")); } }
        public IWebElement PendingforCoderCorrectionLink { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='viewOnHolDiagnosis-label-lblQuickLinks']/parent::div/span[2]")); } }


    }
}
