﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.RAMX
{
    [Binding]
    class fsRAMXMenuNavigation
    {
        Actions builder = new Actions(Browser.Wd);
        public string downloadPath = System.IO.Path.Combine(Environment.ExpandEnvironmentVariables("%userprofile%"), "Downloads");

        [When(@"I Moved ""(.*)"" sub menu")]
        public void WhenIMovedSubMenu(string p0)
        {
            string menu = p0.ToString();

            switch (menu)
            {
                case "Manage Suspects Assignment":
                    builder.MoveToElement(Browser.Wd.FindElement(By.CssSelector("[test-id='subMenu-21']"))).Build().Perform();
                     break;
                case "Prospective Evaluation":
                    builder.MoveToElement(Browser.Wd.FindElement(By.CssSelector("a[title='Prospective Evaluation']"))).Build().Perform();
                    break;
                case "Import":
                    builder.MoveToElement(Browser.Wd.FindElement(By.CssSelector("[test-id='subMenu-23']"))).Build().Perform();
                    break;
                case "Export":
                    builder.MoveToElement(Browser.Wd.FindElement(By.CssSelector("[test-id='subMenu-24']"))).Build().Perform();
                    break;

            }
        }

        [Given(@"Verify application title name ""(.*)""")]
        [When(@"Verify application title name ""(.*)""")]
        [Then(@"Verify application title name ""(.*)""")]
        public void GivenVerifyApplicationTitleName(string p0)
        {
            tmsWait.Hard(3);
            string expText = tmsCommon.GenerateData(p0);
            //string actualText = RAMX.RAMXDashboardPage.RAMXApp.Text;
            //Assert.AreEqual(expText, actualText, "Application title is not as expected");
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[contains(.,'" + expText + "')]")).Displayed);
        }
        
        [Given(@"Verify Dashboard page is loaded")]
        public void GivenVerifyDashboardPageIsLoaded()
        {
            bool isDisplayed = RAMX.RAMXHomePage.RAMXDashboard.Displayed;
            Assert.IsTrue(true, "Dashboard page is not displayed");
        }
        
        //Gurdeep Arora
        [Given(@"I click on ""(.*)"" menu and verify the page")]
        [When(@"I click on ""(.*)"" menu and verify the page")]
        [Then(@"I click on ""(.*)"" menu and verify the page")]
        public void GivenIClickOnMenuAndVerifyThePage(string p0)
        {
            tmsWait.Hard(5);
            string option = p0.ToString();
            //Browser.Wd.FindElement(By.XPath("//div[@title='" + option + "']")).Click();
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@title='" + option + "']")));
            switch (option)
            {
                case "Dashboard":
                    //RAMX.RAMXHomePage.RAMXDashboard.Click();
                    IWebElement paymentYear_dd = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='ramxDashboard-select-paymentYear']"));
                    Assert.IsTrue(paymentYear_dd.Displayed, "Payment Year dropdown is not displayed");
                    IWebElement lastdataload = Browser.Wd.FindElement(By.XPath("//*[@test-id='ramxDashboard-lbl-lastDataLoad']"));
                    Assert.IsTrue(lastdataload.Displayed, "Last Data Load Date is not displayed");
                    IWebElement ProviderSummary = Browser.Wd.FindElement(By.XPath("//*[@test-id='ramxDashboard-lbl-providerSummary']"));
                    Assert.IsTrue(ProviderSummary.Displayed, "Payment Year dropdown is not displayed");
                    IWebElement SuspectsSummary = Browser.Wd.FindElement(By.XPath("//*[@test-id='ramxDashboard-lbl-suspectSummary']"));
                    Assert.IsTrue(SuspectsSummary.Displayed, "Payment Year dropdown is not displayed");
                break;

                case "Job Processing Status":
                    string[] columnNames = new string[] { "Job Group", "Job", "Status", "Start Date", "End Date", "User Name", "Actions", "More" };
                    tmsWait.Hard(5);
                    foreach (string column in columnNames)
                    {
                        IWebElement gridElement= Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='jobProcessingStatus-grid-jobs']//tr/th[contains(.,'" + column + "')]"));
                        tmsWait.Hard(2);
                        Assert.IsTrue(gridElement.Displayed, "Column Name : "+ column+ " is not displayed in file processing grid ");
                    }
                    break;

                case "Report Manager":
                    IWebElement reportName_dd = Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='reportManager-select-multiSelectReports']"));
                    Assert.IsTrue(reportName_dd.Displayed, "Report Name dropdown is not displayed");
                    IWebElement planID_dd = Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='reportManager-select-multiSelectPlans']"));
                    Assert.IsTrue(planID_dd.Displayed, "Plan ID dropdown is not displayed");
                    IWebElement startDate = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='reportManager-txt-startdate']")); 
                    Assert.IsTrue(startDate.Displayed, "Start Date is not displayed");
                    IWebElement throughDate = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='reportManager-txt-throughdate']"));
                    Assert.IsTrue(throughDate.Displayed, "Through Date dropdown is not displayed");
                    IWebElement UserBy = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='reportManafer-ddl-ddlUser']"));
                    Assert.IsTrue(UserBy.Displayed, "User By dropdown is not displayed");
                    IWebElement resetButton = Browser.Wd.FindElement(By.XPath("//*[@test-id='reportManager-btn-reset']"));
                    Assert.IsTrue(resetButton.Displayed, "Reset button is not displayed");
                    IWebElement searchButton = Browser.Wd.FindElement(By.XPath("//*[@test-id='reportManager-btn-search']"));
                    Assert.IsTrue(searchButton.Displayed, "Search button is not displayed");
                break;

                case "Reports":
                    string[] expReportNames = new string[] { "Data Load Detail Report", "Members with Confirmed Suspects by HCC", "PIR Results Summary By Provider", "PIR Results Summary By User/Coder", "PIR By Member", "PIR By Provider", "PIR By Group", "PIR By Control No.", "PIR By PCP" };
                    tmsWait.Hard(3);
                    foreach (string report in expReportNames)
                    {
                       string actualReportName= Browser.Wd.FindElement(By.XPath("//span[@test-id='"+report+"']")).Text;
                       Assert.AreEqual(report, actualReportName, "Report Name : " + report + " is not displayed");
                    }
                    break;
            }
        }

        //Gurdeep Arora
        [Then(@"on RAMX Report Manager page verify Report Name dropdown values")]
        public void ThenOnRAMXReportManagerPageVerifyReportNameDropdownValues()
        {
            tmsWait.Hard(3);
            string[] expReportNames = new string[] { "All", "Data Load Detail Report", "Members with Confirmed Suspects by HCC", "PIR Results Summary By Provider", "PIR Results Summary By User/Coder", "PIR By Member", "PIR By Provider", "PIR By Group", "PIR By Control No.", "PIR By PCP" };
            tmsWait.Hard(3);
            Browser.Wd.FindElement(By.XPath("(//div[@class='k-widget k-multiselect k-header form-control multiselectKendo k-multiselect-clearable']/div[1])[1]")).Click();

            tmsWait.Hard(1);

            foreach (string report in expReportNames)
            {
                IWebElement option = Browser.Wd.FindElement(By.XPath("//*[@id='multiSelectReports_listbox']/li[contains(.,'" + report + "')]"));
                string actualtext = option.Text;
                Assert.AreEqual(report, actualtext, "Report Name dropdown values are not correct. Report Name : " + report + " is not found in the dropdown");
            }
            // Browser.Wd.FindElement(By.XPath("//*[@aria-owns='multiSelectReports_taglist multiSelectReports_listbox']")).Click();
            //tmsWait.Hard(1);
           // Browser.Wd.FindElement(By.XPath("(//div[@class='k-widget k-multiselect k-header form-control multiselectKendo k-multiselect-clearable']/div[1])[1]")).SendKeys(Keys.Tab);
            tmsWait.Hard(2);
        }

       
        

        //Gurdeep Arora     
        [Then(@"on RAMX Report Manager page verify Plan ID dropdown values")]
        public void ThenOnRAMXReportManagerPageVerifyPlanIDDropdownValues()
        {
            string DBName = "FileNameQuery";
            db.CreateConnRAMX(DBName);
            string dbQuery = tmsCommon.GenerateData("select txtPlanID from ramx.dbo.tbplans");
            db.AddDBQuery(DBName, dbQuery);
            IList<string> PlanID_DBValues = db.OutputDBResultsToList(DBName);
            PlanID_DBValues.Insert(0, "All");

            Browser.Wd.FindElement(By.XPath("//*[@aria-owns='multiSelectPlans_taglist multiSelectPlans_listbox']")).Click();
            tmsWait.Hard(2);

            foreach (string expPlanID in PlanID_DBValues)
            {
                Console.Write("expPlanID " + expPlanID);
                IWebElement option = Browser.Wd.FindElement(By.XPath("//*[@id='multiSelectPlans_listbox']/li[contains(.,'" + expPlanID + "')]"));
                string actualPlanId = option.Text;
                Console.Write("actualPlanId " + actualPlanId);
                Assert.AreEqual(expPlanID, actualPlanId, "Plan ID dropdown values are not correct. Plan Id : " + expPlanID + " not found in the dropdown");
            }
           
         
        }

        //Gurdeep Arora
        [Then(@"on RAMX Report Manager page verify Reset option resets all the values to default values")]
        public void ThenOnRAMXReportManagerPageVerifyResetOptionResetsAllTheValuesToDefaultValues()
        {

            //Browser.Wd.FindElement(By.XPath("(//div[@class='k-widget k-multiselect k-header form-control multiselectKendo']/div[1])[1]")).Click();
            Browser.Wd.FindElement(By.XPath("//*[@aria-owns='multiSelectReports_taglist multiSelectReports_listbox']")).Click();
            tmsWait.Hard(1);
            IWebElement Reprtname_option = Browser.Wd.FindElement(By.XPath("//*[@id='multiSelectReports_listbox']/li[contains(.,'Data Load Detail Report')]"));
            Reprtname_option.Click();
            tmsWait.Hard(1);

            Browser.Wd.FindElement(By.XPath("//*[@aria-owns='multiSelectPlans_taglist multiSelectPlans_listbox']")).Click();
            //Browser.Wd.FindElement(By.XPath("(//div[@class='k-widget k-multiselect k-header form-control multiselectKendo']/div[1])[2]")).Click();
            tmsWait.Hard(1);
            IWebElement PlanId_option = Browser.Wd.FindElement(By.XPath("//*[@id='multiSelectPlans_listbox']/li[2]"));
            PlanId_option.Click();
            tmsWait.Hard(1);

            Browser.Wd.FindElement(By.XPath("//*[@aria-owns='users_listbox']")).Click();
            tmsWait.Hard(1);
            IWebElement user_option = Browser.Wd.FindElement(By.XPath("//*[@id='users_listbox']/li[2]"));
            user_option.Click();
            tmsWait.Hard(1);

            IWebElement resetBtn = Browser.Wd.FindElement(By.XPath("//*[@test-id='reportManager-btn-reset']"));
            resetBtn.Click();
            tmsWait.Hard(5);

            string PlanID_default = Browser.Wd.FindElement(By.XPath("//*[@id='multiSelectPlans_taglist']/li/span[1]")).Text;
            string ReportName_default = Browser.Wd.FindElement(By.XPath("//*[@id='multiSelectReports_taglist']/li/span[1]")).Text;
            string Users_default = Browser.Wd.FindElement(By.XPath("//*[@aria-owns='users_listbox']/span/span")).Text;
   
            Assert.AreEqual("All", PlanID_default, "Plan Id value was not defaulted to original value after clicking Reset button.");
            Assert.AreEqual("All", ReportName_default, "Report Name value was not defaulted to original value after clicking Reset button.");
           // Assert.AreEqual("tmsadmin", Users_default, "User By value was not defaulted to original value after clicking Reset button.");
        }


        //Gurdeep Arora
        [Then(@"on RAMX Report Manager page click on Search button and verify grid options")]
        public void ThenOnRAMXReportManagerPageClickOnSearchButtonAndVerifyGridOptions()
        {
        
            IWebElement searchBtn = Browser.Wd.FindElement(By.XPath("//*[@test-id='reportManager-btn-search']"));
            // searchBtn.Click();
            tmsWait.Hard(5);
            fw.ExecuteJavascript(searchBtn);
            tmsWait.Hard(5);
            string[] columnNames = new string[] { "Report Name", "Modified Date", "Format", "User Note", "Download"};
            foreach (string column in columnNames)
            {
                IWebElement gridElement = Browser.Wd.FindElement(By.XPath("//*[@test-id='reportManager-grid-dgReportManager']//tr/th[contains(.,'" + column + "')]"));
                Assert.IsTrue(gridElement.Displayed, "Column Name : " + column + " is not displayed in file processing grid ");
            }
        }

        //Gurdeep Arora
        [Then(@"on RAMX Report Manager page click on Delete button and verify message ""(.*)""")]
        public void ThenOnRAMXReportManagerPageClickOnDeleteButtonAndVerifyMessage(string p0)
        {
            string expToastMsgText = tmsCommon.GenerateData(p0);
            IWebElement deleteBtn = Browser.Wd.FindElement(By.XPath("//*[@test-id='reportManager-btn-delete']"));
            //deleteBtn.Click();
            fw.ExecuteJavascript(deleteBtn);
            tmsWait.Hard(1);
        }


        [When(@"on Reports Manager page download button is Clicked")]
        [Then(@"on Reports Manager page download button is Clicked")]
        public void WhenOnReportsManagerPageDownloadButtonIsClicked()
        {
            tmsWait.Hard(2);

            //Deleting already saved PDF, XLS and CSV files from doanload folder.
            string[] fileExtensions = { ".CSV", ".XLS", ".PDF", ".pdf", ".xls", ".csv", ".XLSX" };

            System.IO.DirectoryInfo di = new DirectoryInfo(downloadPath);
            FileInfo[] oldDownloadedFiles = di.EnumerateFiles().Where(p => fileExtensions.Contains(p.Extension, StringComparer.InvariantCultureIgnoreCase)).ToArray();


            foreach (var oldFile in oldDownloadedFiles)
            {
                oldFile.Attributes = FileAttributes.Normal;
                File.Delete(oldFile.FullName);
            }

            IWebElement download = Browser.Wd.FindElement(By.XPath("//a[@title='Download'][1]"));

            //Based on Borwser type perform doanload action and verify report from download folder
            if (ConfigFile.BrowserType.ToLower().Equals("chrome"))
            {
                tmsWait.Hard(4);
                fw.ExecuteJavascript(download);
                tmsWait.Hard(2);
            }
            if (ConfigFile.BrowserType.ToLower().Equals("ff"))
            {
                tmsWait.Hard(4);
                fw.ExecuteJavascript(download);
                tmsWait.Hard(2);
            }
            if (ConfigFile.BrowserType.ToLower().Equals("ie"))
            {
                tmsWait.Hard(4);
                fw.ExecuteJavascript(download);
                tmsWait.Hard(1);
                IWebElement securityWindow = Browser.winium.FindElement(By.Name("Save"));
                tmsWait.Hard(1);
                securityWindow.Click();
            }

            //Verify downloaded file exists in Downloads folder
            string fileName = Browser.Wd.FindElement(By.XPath("(//*[@test-id= 'reportManager-grid-dgReportManager']//table//tr//td)[1]")).Text;
            string format = Browser.Wd.FindElement(By.XPath("(//*[@test-id= 'reportManager-grid-dgReportManager']//table//tr//td)[3]")).Text;
            fileName = fileName + format;
            Console.Write("fileName " + fileName);

            DirectoryInfo fileinfo = new DirectoryInfo(downloadPath);
            foreach (FileInfo f in fileinfo.GetFiles())
            {
                if (f.Name.Contains(fileName))
                {
                    Console.Write(f.Name + " file exists in Downloads Folder: ");
                    break;
                }
            }
        }

        [When(@"on Reports Manager page select a report to delete and verify warning message text ""(.*)""")]
        [Then(@"on Reports Manager page select a report to delete and verify warning message text ""(.*)""")]
        public void ThenOnReportsManagerPageSelectAReportToDeleteAndVerifyWarningMessageText(string p0)
        {
            string alertText_exp = tmsCommon.GenerateData(p0);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("(//*[@test-id='reportManager-grid-dgReportManager']//tbody//input[@type='checkbox'])[1]"));
            fw.ExecuteJavascript(ele);
            tmsWait.Hard(1);
            IWebElement deleteBtn = Browser.Wd.FindElement(By.XPath("//*[@test-id='reportManager-btn-delete']"));
            fw.ExecuteJavascript(deleteBtn);
            tmsWait.Hard(1);
            IWebElement alertOKbtn = Browser.Wd.FindElement(By.XPath("//*[@test-id='confirmationDialog-btn-Yes']"));
            fw.ExecuteJavascript(alertOKbtn);
        }


        [Then(@"on report manager page, verify pagination of the reports grid")]
        public void ThenOnReportManagerPageVerifyPaginationOfTheReportsGrid()
        {
            tmsWait.Hard(2);
            IWebElement pagination = Browser.Wd.FindElement(By.XPath("(//kendo-pager)[1]"));
            bool elementPresence = pagination.Displayed;

            Assert.IsTrue(elementPresence, " Pagination is not getting displayed");
        }



        [Given(@"verify ""(.*)"" is displayed")]
        public void GivenVerifyIsDisplayed(string p0)
        {
            string option = p0.ToString();
            bool isDisplayed;
            IWebElement ele = null;
            switch (option)
            {
                case "Dashboard":
                    ele = RAMX.RAMXHomePage.RAMXDashboard;
                    break;
                case "Menu":
                    ele = RAMX.RAMXHomePage.RAMXMenu_Hamburger;
                    break;
            }
            isDisplayed = ele.Displayed;
            Assert.IsTrue(true, "Dashboard page is not displayed");
        }

      

        [When(@"verify menu ""(.*)"" should be displayed")]
        [Given(@"verify menu ""(.*)"" should be displayed")]
        [Then(@"verify menu ""(.*)"" should be displayed")]
        public void ThenVerifyMenuShouldBeDisplayed(string p0)
        {
            string menuItem = tmsCommon.GenerateData(p0);
            bool isDisplayed = Browser.Wd.FindElement(By.CssSelector("[title='"+ menuItem + "']")).Displayed;
            Assert.IsTrue(isDisplayed, "Menu item " +menuItem+ " is not displayed");
        }

        [Given(@"I click on ""(.*)"" menu")]
        public void GivenIClickOnMenu(string p0)
        {
            tmsWait.Hard(3);
            string menuItem = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='" + menuItem + "']")));
            tmsWait.Hard(1);
        }


        [Given(@"verify sub-menu ""(.*)"" should be displayed")]
        public void GivenVerifySub_MenuShouldBeDisplayed(string p0)
        {
            tmsWait.Hard(1);
            string submenuItem = tmsCommon.GenerateData(p0);
            bool isDisplayed = Browser.Wd.FindElement(By.XPath("//div[contains(.,'" + p0 + "')]")).Displayed;
            Assert.IsTrue(isDisplayed, "Menu item " + submenuItem + " is not displayed");
        }

        [Given(@"I click on sub-item ""(.*)"" in ""(.*)"" menu")]
        public void GivenIClickOnSub_ItemInMenu(string p0, string p1)
        {
            string menuItem = tmsCommon.GenerateData(p1);
            string submenuItem = tmsCommon.GenerateData(p0);
            tmsWait.Hard(3);
            Browser.Wd.FindElement(By.XPath("//li[@class='ng-scope']//a[@title='" + menuItem + "']")).Click();
            tmsWait.Hard(2);
            Browser.Wd.FindElement(By.XPath("//li[@class='dropdown-submenu ng-scope']//a[@title='" + submenuItem + "']")).Click();
            tmsWait.Hard(2);
        }


        [Given(@"verify menu ""(.*)"" should not be displayed")]
        public void GivenVerifyMenuShouldNotBeDisplayed(string p0)
        {
            string menuItem = tmsCommon.GenerateData(p0);
            try
            {
                Assert.IsFalse(Browser.Wd.FindElement(By.XPath("//li[@class='ng-scope']//a[@title='" + menuItem + "']")).Displayed, "Menu item " + menuItem + " is not displayed");
            }
            catch(Exception e){
                Console.Write("Menu item " + menuItem + " is not displayed");

            }
        }

        

        [Then(@"i click on ""(.*)"" menu and verify submenu items")]
        [When(@"i click on ""(.*)"" menu and verify submenu items")]
        [Given(@"i click on ""(.*)"" menu and verify submenu items")]
        public void ThenIClickOnMenuAndVerifySubmenuItems(string p0)
        {
            string menuName = tmsCommon.GenerateData(p0);
            string actualSubmenuItem;
            string[] expSubmenuItems;
            tmsWait.Hard(5);
            switch (menuName)
            {
                case "Main":
                    expSubmenuItems = new string[] { "Manage Suspects", "Enter New Diagnosis Data" };
                    
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@title='Main']")));
                    foreach (string expSubmenuItem in expSubmenuItems)
                    {
                        actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//div[contains(@test-id,'submenu')]//span[contains(.,'"+ expSubmenuItem + "')]")).Text;
                        Assert.AreEqual(expSubmenuItem, actualSubmenuItem, "Submenu " + expSubmenuItem + " does not exist under " + menuName + " menu");
                    }
                    break;

                case "Tasks":
                    expSubmenuItems = new string[] { "Import", "Export", "Audit-View/Export", "On-Hold and Diagnosis Review" };
                    Browser.Wd.FindElement(By.XPath("//div[@title='Tasks']")).Click();
                    foreach (string expSubmenuItem in expSubmenuItems)
                    {
                        actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//div[contains(@test-id,'submenu')]//span[contains(.,'" + expSubmenuItem + "')]")).Text;
                        Assert.AreEqual(expSubmenuItem, actualSubmenuItem, "Submenu " + expSubmenuItem + " does not exist under " + menuName + " menu");
                    }
                    break;

                case "Administration":
                    expSubmenuItems = new string[] { "Add Diagnosis Codes", "Add Reasons", "Add Coder IDs", "Add Payment Year", "Exclude/Include Provider", "Customize PIR Cover Letter", "Audit Configuration", "Auditor Review", "Flag for Auditor Review", "Add Chart Review Source", "RAMX Configuration", "Add On Hold Reasons" };
                    Browser.Wd.FindElement(By.XPath("//div[@title='Administration']")).Click();
                    foreach (string expSubmenuItem in expSubmenuItems)
                    {
                        actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//div[contains(@test-id,'submenu')]//span[contains(.,'" + expSubmenuItem + "')]")).Text;
                        Assert.AreEqual(expSubmenuItem, actualSubmenuItem, "Submenu " + expSubmenuItem + " does not exist under " + menuName + " menu");
                    }
                    break;

            }
        }



        [Then(@"Verify RAMX Dashboard page ""(.*)"" section is displayed")]
        public void ThenVerifyRAMXDashboardPageSectionIsDisplayed(string p0)
        {
            string grid = p0.ToString();
            switch (grid)
            {
                case "Suspect Summary":
                    Assert.IsTrue(RAMX.RAMXDashboardPage.RAMXSuspectSummaryGrid.Displayed, grid + "section is not getting displayed");
                    string[] expTableCols = {"Plan ID", "Suspect Count", "Financial Impact" };
                    IList<IWebElement> actualTableCols = Browser.Wd.FindElements(By.XPath("//kendo-grid[@test-id='ramxDashboard-grid-suspectSummary']//th"));

                    for (int i=0; i< actualTableCols.Count; i++)
                    {
                     Assert.AreEqual(expTableCols[i], actualTableCols[i].Text, "Expected column is not displayed in Suspect Summary table");
                    }
                    break;

                case "Provider Summary":
                    Assert.IsTrue(RAMX.RAMXDashboardPage.RAMXProviderSummaryGrid.Displayed, grid + "section is not getting displayed");
                    break;
                //case "RiskScore":
                //    Assert.IsTrue(RAM.RAMDashboardPage.RiskScore.Displayed, grid + "section is not getting displayed");
                //    break;
                //case "Revenue":
                //    Assert.IsTrue(RAM.RAMDashboardPage.Revenue.Displayed, grid + "section is not getting displayed");
                //    break;

            }
        }



    [Then(@"Verify Administration menu displayed ""(.*)"" submenu")]
        public void ThenVerifyAdministrationMenuDisplayedSubmenu(string p0)
        {


            IList<string> expected = p0.Split(',').ToList();
            foreach (string verfiy in expected)
            {

                if (Browser.Wd.FindElement(By.XPath("//li[@test-id='menu-23']//ul//a[@title='" + verfiy + "']/span")).Displayed)
                {
                    Assert.IsTrue(true, verfiy + " is found on RAM Menu");

                }
                else
                {
                    Assert.IsFalse(false, verfiy + " is not found on RAM Menu");
                }
            }

        }

    }
}
