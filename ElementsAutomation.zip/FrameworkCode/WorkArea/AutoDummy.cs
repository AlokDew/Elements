﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;


//AD
namespace TMSoR1.FrameworkCode.WorkArea
{
    [Binding]
    class AutoDummy
    {
    }
}
