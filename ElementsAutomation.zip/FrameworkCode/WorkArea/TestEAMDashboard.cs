﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.WorkArea
{
    [Binding]
    class TestEAMDashboard
    {
        [Then(@"Verify EAM Application ""(.*)"" is displayed successfully")]
        public void ThenVerifyEAMApplicationIsDisplayedSuccessfully(string p0)
        {
            string expectedRes = p0;

            By dashboard = By.XPath("//span[@test-id='eamDashboard-span-title']");

            string actualres=UIMODUtilFunctions.returnTextUsingLocators(dashboard);

            Assert.AreEqual(expectedRes, actualres, " Expected results are not matching");
        }

    }
}
