﻿using Microsoft.Office.Interop.Excel;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.WorkArea
{
    [Binding]
    class AutomationDaily
    {
        //Created by AD
        [When(@"FindHighLigted Fields")]
        public void WhenFindHighLigtedFields()
        {
            //IWebDriver driver;
            //driver = new ChromeDriver("c:\\");
            //driver.Url = "https://tms-qa.asp-tms-app-73.dev.trizetto.com/tms/";
            //tmsWait.Hard(3);



            IList<IWebElement> options = Browser.Wd.FindElements(By.XPath("//input[contains(@class,'invalid')]/parent::div/label"));
            for (int i = 0; i <= options.Count - 1; i++)
            {
                if (options[i].GetAttribute("value") == "")
                {
                    //flag = true;
                    break;
                }
            }
        }
    }
}
