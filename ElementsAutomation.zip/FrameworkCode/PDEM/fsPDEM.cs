﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.PDEM
{
    [Binding]
    class fsPDEM
    {
        public string downloadPath = System.IO.Path.Combine(Environment.ExpandEnvironmentVariables("%userprofile%"), "Downloads");
        [When(@"When PDEDataManager page PDE Management ""(.*)"" submenu is Clicked")]
        public void WhenWhenPDEDataManagerPagePDEManagementSubmenuIsClicked(string p0)
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]")));
            tmsWait.Hard(5);
            //IWebElement submenu = Browser.Wd.FindElement(By.XPath("//a[@id='ctl00_RadMenu1_m0_m1']/span[contains(.,'"+ p0 + "')]"));
            //fw.ExecuteJavascript(submenu);
        }

        [When(@"PDEDataManager page PDE Management Main menu ""(.*)"" submenu is Clicked")]
        public void WhenPDEDataManagerPagePDEManagementMainMenuSubmenuIsClicked(string p0)
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]")));
            tmsWait.Hard(5);
            //IWebElement submenu = Browser.Wd.FindElement(By.XPath("//a[@id='ctl00_RadMenu1_m0_m3']/span[contains(.,'" + p0 + "')]"));
            //fw.ExecuteJavascript(submenu);
        }

        [When(@"View Edit PDE ""(.*)"" is set to ""(.*)""")]
        public void WhenViewEditPDEIsSetTo(string field, string p1)
        {
            tmsWait.Hard(3);
            string value = tmsCommon.GenerateData(p1);

            switch (field)
            {
                case "MBI":
                    
                    ReUsableFunctions.enterValueOnWebElementWithoutClear(PDEM.ViewEditPDE.MBI, value);
                    PDEM.ViewEditPDE.MBI.SendKeys(Keys.Tab);
                    break;
                case "Status":
                    By DrpST = By.XPath("//label[text()='Status']/parent::div//span[@class='k-select']");
                    By typeappst = By.XPath("//li[text()='" + value + "']");

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(DrpST);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeappst);

                    //UIMODUtilFunctions.selectDropDownValueFromGendoUI(PDEM.ViewEditPDE.StatusDropdownlist, value);
                                       
                    break;

                case "Year":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Advanced Search')]")));
                    tmsWait.Hard(2);
                    By DrpYR = By.XPath("//label[text()='Year']/parent::div//span[@class='k-select']");
                    By typeappyr = By.XPath("//li[text()='" + value + "']");

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(DrpYR);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeappyr);

                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Advanced Search')]")));
                    break;
                case "Files Loaded":
                    By DrpFL = By.XPath("//label[text()='Files Loaded']/parent::div//span[@class='k-select']");
                    By typeappfl = By.XPath("//li[text()='" + value + "']");

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(DrpFL);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeappfl);
                    break;

                case "Claim Control Number":
                    ReUsableFunctions.enterValueOnWebElementWithoutClear(PDEM.ViewEditPDE.ClaimControlNumber, value);
                    PDEM.ViewEditPDE.ClaimControlNumber.SendKeys(Keys.Tab);
                    break;
            }
           
            
        }

        [When(@"Advanced Search Button is Clicked")]
        public void WhenAdvancedSearchButtonIsClicked()
        {
            fw.ExecuteJavascript(PDEM.ViewEditPDE.SearchButton);
            tmsWait.Hard(5);
        }

        [Then(@"Note Search results record count")]
        public void ThenNoteSearchResultsRecordCount()
        {
            string[] records = PDEM.ViewEditPDE.TotalItems.Text.Split(' ');
            int totalrecordnum = Convert.ToInt32(records[4]);

            ScenarioContext.Current["PDEMRecCount"] = totalrecordnum;
        }

        [Then(@"Note Search results record count and set to ""(.*)""")]
        public void ThenNoteSearchResultsRecordCountAndSetTo(string p0)
        {

            string[] records = PDEM.ViewEditPDE.TotalItems.Text.Split(' ');
            int totalrecordnum = Convert.ToInt32(records[4]);

            fw.setVariable(p0, totalrecordnum.ToString());
        }

        [When(@"View Edit PDE page View All Error Codes and Flags link is Clicked")]
        public void WhenViewEditPDEPageViewAllErrorCodesAndFlagsLinkIsClicked()
        {
            fw.ExecuteJavascript(PDEM.ViewEditPDE.viewEditPdeLink);
            tmsWait.Hard(5);
        }

        [Then(@"Click on Warning Flags Tab and Compare UI Message ""(.*)"" with DB Message ""(.*)""")]
        public void ThenClickOnWarningFlagsTabAndCompareUIMessageWithDBMessage(string p0, string p1)
        {
            string uimsg = tmsCommon.GenerateData(p0);
            string dbmsg = tmsCommon.GenerateData(p1);
            fw.ExecuteJavascript(PDEM.ViewEditPDE.WarnFlagsTab);
            tmsWait.Hard(5);

            Assert.AreEqual(uimsg, dbmsg, " Both are not matching");
        }

        [Then(@"Click on Warning Flags Tab displayed Message ""(.*)""")]
        public void ThenClickOnWarningFlagsTabDisplayedMessage(string p0)
        {
            string msg = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(PDEM.ViewEditPDE.WarnFlagsTab);
            tmsWait.Hard(5);
            By loc = By.XPath("//kendo-grid[@test-id='pdeErrorData-grid']//td[contains(.,'" + msg + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);

            
        }

        [Then(@"Click on Reset button and Verify Error Code is set to ""(.*)""")]
        public void ThenClickOnResetButtonAndVerifyErrorCodeIsSetTo(string p0)
        {
            string expResults = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(PDEM.ViewEditPDE.ResetButtonOnErrorCode);
            tmsWait.Hard(5);
            By loc = By.CssSelector("[test-id='pdeErrorDetail-txt-errorCode']");

            string actResults = Browser.Wd.FindElement(loc).GetAttribute("value");

            Assert.AreEqual(expResults, actResults, " Both results are not matching");
            

        }

        [When(@"Click on Back to record button on View All Error Codes and Flags page")]
        public void WhenClickOnBackToRecordButtonOnViewAllErrorCodesAndFlagsPage()
        {
            fw.ExecuteJavascript(PDEM.ViewEditPDE.BackToRecordButtonOnErrorCode);
            tmsWait.Hard(5);

            
        }


        [Then(@"Click on Error Code Tab Error code ""(.*)"" displayed Message ""(.*)""")]
        public void ThenClickOnErrorCodeTabErrorCodeDisplayedMessage(string p0, string p1)
        {
          
            string msg = tmsCommon.GenerateData(p1);
            string ErrorCode = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(PDEM.ViewEditPDE.PDEErrorCodeTab);
            tmsWait.Hard(2);

            ReUsableFunctions.enterValueOnWebElementWithClear(PDEM.ViewEditPDE.ErrorCode, ErrorCode);
            tmsWait.Hard(5);
            fw.ExecuteJavascript(PDEM.ViewEditPDE.ErrorCodeSearchButton);
            tmsWait.Hard(5);
            By loc = By.XPath("//kendo-grid[@test-id='pdeErrorData-grid']//td[contains(.,'" + msg + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }


        [Then(@"Verify Search results count ""(.*)"" is matching with DB records count ""(.*)""")]
        public void ThenVerifySearchResultsCountIsMatchingWithDBRecordsCount(string p0, string p1)
        {
            string dbcount = tmsCommon.GenerateData(p1);
            string appcount = tmsCommon.GenerateData(p0);

            fw.ConsoleReport(" DB Records --> " + dbcount);
            fw.ConsoleReport(" App Records -- > " + appcount);

            Assert.AreEqual(dbcount, appcount, " Boht records not matching");


        }

        [When(@"View Edit PDE page Error Codes lookup is Clicked")]
        public void WhenViewEditPDEPageErrorCodesLookupIsClicked()
        {
            fw.ExecuteJavascript(PDEM.ViewEditPDE.errorCodeLookup);
            tmsWait.Hard(5);
        }

        [When(@"Error Codes page is set to ""(.*)""")]
        public void WhenErrorCodesPageIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            ReUsableFunctions.enterValueOnWebElementWithClear(PDEM.ViewEditPDE.errorCodeTextbox, value);
        }

        [When(@"Error Codes page Search Button is Clicked")]
        public void WhenErrorCodesPageSearchButtonIsClicked()
        {
            ReUsableFunctions.clickOnWebElement(PDEM.ViewEditPDE.errorCodeSearchButton);
        }

        [Then(@"Verify Error Code displayed as ""(.*)""")]
        public void ThenVerifyErrorCodeDisplayedAs(string p0)
        {
            By loc = By.XPath("//kendo-grid[@test-id='errorCodes-grid-errorCodes']//td[contains(.,'" + p0+"')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }

        [Then(@"Error Codes page Reset Button is Clicked")]
        public void ThenErrorCodesPageResetButtonIsClicked()
        {
            ReUsableFunctions.clickOnWebElement(PDEM.ViewEditPDE.ResetButtonOnErrorCode);
        }


        [When(@"View Edit PDE page Error Codes is set to ""(.*)""")]
        public void WhenViewEditPDEPageErrorCodesIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            ReUsableFunctions.enterValueOnWebElementWithClear(PDEM.ViewEditPDE.errorCodeTextbox, value);
            ReUsableFunctions.clickOnWebElement(PDEM.ViewEditPDE.errorCodeSearchButton);
            ReUsableFunctions.clickOnWebElement(PDEM.ViewEditPDE.FirstCheckbox);
            ReUsableFunctions.clickOnWebElement(PDEM.ViewEditPDE.ADDBtn);
            tmsWait.Hard(5);
        }


        [When(@"Advanced Search Plus Button is Clicked")]
        public void WhenAdvancedSearchPlusButtonIsClicked()
        {
            fw.ExecuteJavascript(PDEM.ViewEditPDE.AdvancedSearchPlusButton);
        }

        [When(@"View Edit PDE ""(.*)"" button is clicked")]
        public void WhenViewEditPDEButtonIsClicked(string p0)
        {
            string button = tmsCommon.GenerateData(p0);
            tmsWait.Hard(3);
            switch(button.ToLower())
            {
                case "search": fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='viewEditPde-btn-search']/span[contains(.,'SEARCH')]"))); break;
                case "reset": fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button/span[contains(.,'RESET')]"))); break;
                case "export": fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='viewEditPde-btn-export']/span[contains(.,'EXPORT')]"))); break;
            }

            tmsWait.Hard(8);
        }

        [Then(@"Verify View Edit PDE Active Filters ""(.*)"" is displayed")]
        public void ThenVerifyViewEditPDEActiveFiltersIsDisplayed(string p0)
        {
            string filter_name = tmsCommon.GenerateData(p0);
            bool ispresent = false;
            try {
                ispresent = Browser.Wd.FindElement(By.XPath("//label[@test-id='activefiltercomponent-lbl-filterName'][contains(.,'" + filter_name + "')]")).Displayed;
                }
            catch
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.Id("btnSearch")));
                ispresent = Browser.Wd.FindElement(By.XPath("//label[@test-id='activefiltercomponent-lbl-filterName'][contains(.,'" + filter_name + "')]")).Displayed;
            }
            
            Assert.IsTrue(ispresent, "Active Filter is not displayed");
        }

        [When(@"View Edit PDE Edit Icon is Clicked for First Result")]
        public void WhenViewEditPDEEditIconIsClickedForFirstResult()
        {
            tmsWait.Hard(10);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='pdemBasicAndAdvanceSearch-grid-pdes']//tr[1]//a[@title='Edit']")));
            tmsWait.Hard(5);
        }

        [When(@"View Edit PDE page ""(.*)"" is set to ""(.*)""")]
        public void WhenViewEditPDEPageIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch(field.ToLower())
            {
                case "workflow status":
                    if (Browser.Wd.FindElement(By.XPath("//i[@test-id='workflow-info-workflowStatusCollapse']")).Displayed)
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[contains(.,'WorkFlow Assignment')]")));
                    }
                    tmsWait.Hard(1);
                    By DrpWS = By.XPath("//kendo-dropdownlist[@test-id='editPde-select-workflowstatus']//span[@class='k-select']");
                    By typeappws = By.XPath("//li[text()='" + value + "']");

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(DrpWS);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeappws);

                    //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[contains(.,'WorkFlow Assignment')]")));
                    break;
                case "save format":
                    if (value.Equals("Excel"))
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Excel')]/preceding-sibling::input")));
                    }
                    else 
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[contains(.,'CMS Format')]/preceding-sibling::input")));
                    }
                    tmsWait.Hard(1);

                    break;
                case "error type":
                    if (value.Equals("Front-End Errors"))
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Front-End Errors')]/preceding-sibling::input")));
                    }
                    else
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[contains(.,'CMS Errors')]/preceding-sibling::input")));
                    }
                    tmsWait.Hard(1);

                    break;
                default:
                    break;

            }
        }

        [Then(@"Verify View PDE Edit page ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyViewPDEEditPageIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string expected_value = tmsCommon.GenerateData(p1);
            string actual_value = "";
            switch(field.ToLower())
            {
                case "workflow status":
                    if (Browser.Wd.FindElement(By.XPath("//i[@test-id='workflow-info-workflowStatusCollapse']")).Displayed)
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[contains(.,'WorkFlow Assignment')]")));
                    }
                    tmsWait.Hard(1);
                    actual_value = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='editPde-select-workflowstatus']//span[@class='k-input']")).Text;
                    //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[contains(.,'WorkFlow Assignment')]")));
                    break;
            }

            Assert.AreEqual(expected_value, actual_value, "Expected value is not displayed");

        }


        [Then(@"Verify View Edit PDE page ""(.*)"" field is displayed")]
        public void ThenVerifyViewEditPDEPageFieldIsDisplayed(string p0)
        {
            string field = tmsCommon.GenerateData(p0);
            switch (p0)
            {
                case "Status":
                    UIMODUtilFunctions.elementPresenceUsingWebElement(PDEM.ViewEditPDE.StatusDropdownlist);
                    break;
                case "Files Loaded":
                    UIMODUtilFunctions.elementPresenceUsingWebElement(PDEM.ViewEditPDE.FileLoadedDropdownlist);
                    break;
                case "Submitter ID":
                    UIMODUtilFunctions.elementPresenceUsingWebElement(PDEM.ViewEditPDE.SubmitterDropdownlist);
                    break;

                case "Year":
                    UIMODUtilFunctions.elementPresenceUsingWebElement(PDEM.ViewEditPDE.YearDropdownlist);
                    break;

                case "Plan ID":
                    UIMODUtilFunctions.elementPresenceUsingWebElement(PDEM.ViewEditPDE.PlanIDDropdownlist);
                    break;

                case "P2P Plan":
                    UIMODUtilFunctions.elementPresenceUsingWebElement(PDEM.ViewEditPDE.P2PPlanDropdownlist);
                    break;

                case "PBP ID":
                    UIMODUtilFunctions.elementPresenceUsingWebElement(PDEM.ViewEditPDE.PBPDropdownlist);
                    break;

                case "Workflow Status":
                    UIMODUtilFunctions.elementPresenceUsingWebElement(PDEM.ViewEditPDE.WorkflowDropdownlist);
                    break;

                case "Assigned User":
                    UIMODUtilFunctions.elementPresenceUsingWebElement(PDEM.ViewEditPDE.UsersDropdownlist);
                    break;

                case "Aging":
                    UIMODUtilFunctions.elementPresenceUsingWebElement(PDEM.ViewEditPDE.AgeingDropdownlist);
                    break;

                case "Loaded Batch":
                    UIMODUtilFunctions.elementPresenceUsingWebElement(PDEM.ViewEditPDE.LoadedBatchesDropdownlist);
                    break;

                case "Response Files":
                    UIMODUtilFunctions.elementPresenceUsingWebElement(PDEM.ViewEditPDE.ResponseFileDropdownlist);
                    break;
            }

        }


        [When(@"Advanced Search ""(.*)"" is set to ""(.*)""")]
        public void WhenAdvancedSearchIsSetTo(string p0, string p1)
        {
            string value = tmsCommon.GenerateData(p1);
            switch(p0)
            {
                case "Year":
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(PDEM.ViewEditPDE.YearDropdownlist);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(By.XPath("//li[text()='" + value + "']"));
                    break;
                case "Submitter ID":
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(PDEM.ViewEditPDE.SubmitterDropdownlist);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(By.XPath("//li[text()='" + value + "']"));
                    break;
                case "Plan ID":
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(PDEM.ViewEditPDE.PlanIDDropdownlist);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(By.XPath("//li[text()='" + value + "']"));
                    break;
                case "P2P Plan":
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(PDEM.ViewEditPDE.P2PPlanDropdownlist);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(By.XPath("//li[text()='" + value + "']"));
                    break;
                case "PBP ID":
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(PDEM.ViewEditPDE.PBPDropdownlist);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(By.XPath("//li[text()='" + value + "']"));
                    break;
                case "Workflow Status":
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(PDEM.ViewEditPDE.WorkflowDropdownlist);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(By.XPath("//li[text()='" + value + "']"));
                    break;
                case "Assigned User":
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(PDEM.ViewEditPDE.UsersDropdownlist);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(By.XPath("//li[text()='" + value + "']"));
                    break;
                case "Aging":
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(PDEM.ViewEditPDE.AgeingDropdownlist);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(By.XPath("//li[text()='" + value + "']"));
                    break;
                case "Loaded Batch":
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(PDEM.ViewEditPDE.LoadedBatchesDropdownlist);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(By.XPath("//li[text()='" + value + "']"));
                    break;
                case "Response Files":
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(PDEM.ViewEditPDE.ResponseFileDropdownlist);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(By.XPath("//li[text()='" + value + "']"));
                    break;
                default:
                    break;
            }
            
        }


        [When(@"PDEDataManager page Files Menu Batches submenu ""(.*)"" submenu is Clicked")]
        public void WhenPDEDataManagerPageFilesMenuBatchesSubmenuSubmenuIsClicked(string p0)
        {
            IWebElement submenu = Browser.Wd.FindElement(By.XPath("//a/span[contains(.,'"+p0+"')]"));
            fw.ExecuteJavascript(submenu);
        }

        [When(@"Submitted Files page ""(.*)"" button is Clicked")]
        public void WhenSubmittedFilesPageButtonIsClicked(string p0)
        {
            IWebElement plan = Browser.Wd.FindElement(By.Id("btn" + p0 + ""));
            fw.ExecuteJavascript(plan);
        }

        [When(@"Submitted Files page ""(.*)"" field is set to ""(.*)""")]
        public void WhenSubmittedFilesPageFieldIsSetTo(string p0, string value)
        {
            string strValue = tmsCommon.GenerateData(value);
            By dropDown = null;

            switch (p0)
            {
                case "cboFileName":
                    dropDown = By.XPath("//kendo-dropdownlist[@test-id='batches-select-fileId']//span[@class='k-select']");
                    break;
                case "cboPlan":
                    dropDown = By.XPath("//kendo-dropdownlist[@test-id='batches-select-planId']//span[@class='k-select']");
                    break;
                case "cboPBP":
                    dropDown = By.XPath("//kendo-dropdownlist[@test-id='batches-select-pbpIds']//span[@class='k-select']");
                    break;
                case "cboUser":
                    dropDown = By.XPath("//kendo-dropdownlist[@test-id='batches-select-userIds']//span[@class='k-select']");
                    break;
                case "SubmitterIDDropdown":
                    dropDown = By.XPath("//kendo-dropdownlist[@test-id='batches-select-submitterId']//span[@class='k-select']");
                    break;
                default:
                    break;
            }
            By typeapp = By.XPath("//li[text()='" + strValue + "']");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(dropDown);
            tmsWait.Hard(1);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

            //IWebElement plan = Browser.Wd.FindElement(By.CssSelector(id));
            //selectDropdownByText(plan, value);
        }

        [Then(@"Verify Submitted Files page ""(.*)"" field is set to ""(.*)""")]
        public void ThenVerifySubmittedFilesPageFieldIsSetTo(string p0, string expected) 
        {
            string id = "";

            tmsWait.Hard(2);
            switch (p0)
            {
                case "cboFileName":
                    id = "batches-select-fileId";
                    break;
                case "cboPlan":
                    id = "batches-select-planId";
                    break;
                case "cboPBP":
                    id = "batches-select-pbpIds";
                    break;
                case "cboUser":
                    id = "batches-select-userIds";
                    break;
                case "SubmitterIDDropdown":
                    id = "batches-select-submitterId";
                    break;
                default:
                    break;
            }
            By plan = By.XPath("//kendo-dropdownlist[@test-id='" + id + "']//span[@class='k-input']");
            string act = Browser.Wd.FindElement(plan).Text;
            //string act = UIMODUtilFunctions.returnTextUsingLocators(plan);

            //IWebElement ele = Browser.Wd.FindElement(By.CssSelector(id));
            //string actual = ele.Text;
            Assert.AreEqual(expected, act, expected + "is not getting displayed");
            //SelectElement drp = new SelectElement(ele);
            //Assert.AreEqual(Exp, drp.SelectedOption.Text, "Both values not matching");
        }

        public void selectDropdownByText(IWebElement element,string value)
        {
            SelectElement select = new SelectElement(element);
            select.SelectByText(value);
        }

        [When(@"P(.*)P AR Management page ""(.*)"" button is Clicked")]
        public void WhenPPARManagementPageButtonIsClicked(int p0, string p1)
        {
            string id = "";
            switch (p1)
            {
                case "SearchPage":
                    id = "p2pArManagement-btnSearch-parameter";
                    break;
                case "ResetFilters":
                    id = "p2pArManagement-btnReset";
                    break;
                case "ExportP2P":
                    id = "p2pAManagement-btnExport-parameter";
                    break;
                default:
                    break;
            }
            IWebElement button = Browser.Wd.FindElement(By.Id(id));
            fw.ExecuteJavascript(button);
        }


        [When(@"P(.*)P AR Managetment page ""(.*)"" link is clicked")]
        public void WhenPPARManagetmentPageLinkIsClicked(int p0, string p1)
        {
            string linkname = tmsCommon.GenerateData(p1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the "+ linkname.ToLower()+" page']")));
        }

        [Then(@"Verify page number ""(.*)"" is displayed")]
        public void ThenVerifyPageNumberIsDisplayed(int p0)
        {
            string expected_pageno = tmsCommon.GenerateData(p0.ToString());
            string actual_pageno = Browser.Wd.FindElement(By.XPath("//kendo-numerictextbox[@class='k-widget k-numerictextbox']//input")).GetAttribute("aria-valuenow");
            Assert.AreEqual(actual_pageno, expected_pageno, " expected page number is not displayed");
        }


        [When(@"P(.*)P AR Management page ""(.*)"" button is Clicked and Verify Message ""(.*)""")]
        public void WhenPPARManagementPageButtonIsClickedAndVerifyMessage(int p0, string p1, string p2)
        {
            string field = tmsCommon.GenerateData(p1);
            string expvalue = tmsCommon.GenerateData(p2);
            string id="";
            switch (field)
            {
                case "SearchPage":  id ="p2pArManagement-btnSearch-parameter"; 
                    break;
                case "Export":
                    id = "p2pAManagement-btnExport-parameter";
                    break;
            }
           
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.Id(id)));
            By toastMsg = By.XPath("//div[@class='k-notification-content']");
            string actValue = Browser.Wd.FindElement(toastMsg).Text;
            Assert.IsTrue(actValue.Contains(expvalue), "Expected Message is displayed");
        }


        [Then(@"Verify P(.*)P AR Management Search results page displayed updated Paid status with MBI")]
        public void ThenVerifyPPARManagementSearchResultsPageDisplayedUpdatedPaidStatusWithMBI(int p0)
        {
            string PDEMMBI=ScenarioContext.Current["PDEMMBI"].ToString();
            By mbiValue = By.XPath("//td[contains(.,'" + PDEMMBI + "')]/following-sibling::td[contains(.,'Paid')]");

            UIMODUtilFunctions.elementNotPresenceUsingLocators(mbiValue);
            
        }

        [When(@"P(.*)P AR Management Search results Click Open Status, Update to Close status")]
        public void WhenPPARManagementSearchResultsClickOpenStatusUpdateToCloseStatus(int p0)
        {
            By mbiValue = By.XPath("//kendo-grid[@test-id='ArManagement-grid']//tr[1]//td[contains(.,'Open')]/preceding-sibling::td[7]");
            string PDEMMBI = Browser.Wd.FindElement(mbiValue).Text;

            ScenarioContext.Current["PDEMMBI"] = PDEMMBI;

            By edit = By.XPath("//kendo-grid[@test-id='ArManagement-grid']//tr[1]//td[contains(.,'Open')]/following-sibling::td/button[1]");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(edit);
            tmsWait.Hard(5);

            By Open = By.XPath("//kendo-dropdownlist[@test-id='beqrOverlayBusinessRuleFieldLevelConfiguration-select-gdDdlUserField']//span[@class='k-select']");
            By paid = By.XPath("//li[text()='Close']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(Open);
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(paid);

            tmsWait.Hard(2);

            By save = By.XPath("//kendo-dropdownlist[@test-id='beqrOverlayBusinessRuleFieldLevelConfiguration-select-gdDdlUserField']/parent::td/following-sibling::td/button[2]");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(save);
            tmsWait.Hard(2);
        }

        [Then(@"Verify P(.*)P AR Management Search results page displayed updated Close status with MBI")]
        public void ThenVerifyPPARManagementSearchResultsPageDisplayedUpdatedCloseStatusWithMBI(int p0)
        {
            tmsWait.Hard(2);
            string PDEMMBI = ScenarioContext.Current["PDEMMBI"].ToString();
            By mbiValue = By.XPath("//td[contains(.,'" + PDEMMBI + "')]/following-sibling::td[contains(.,'Close')]");

            UIMODUtilFunctions.elementNotPresenceUsingLocators(mbiValue);
        }

        [When(@"P(.*)P AR Management Search results Click Under Review Status, Update to Paid status")]
        public void WhenPPARManagementSearchResultsClickUnderReviewStatusUpdateToPaidStatus(int p0)
        {
            By mbiValue = By.XPath("(//kendo-grid[@test-id='ArManagement-grid']//tr//td[contains(.,'Under Review')]/preceding-sibling::td[7])[1]");
            string PDEMMBI = Browser.Wd.FindElement(mbiValue).Text;

            ScenarioContext.Current["PDEMMBI"] = PDEMMBI;

            By edit = By.XPath("(//kendo-grid[@test-id='ArManagement-grid']//tr//td[contains(.,'Under Review')]/following-sibling::td/button[1])[1]");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(edit);
            tmsWait.Hard(5);

            By Open = By.XPath("//kendo-dropdownlist[@test-id='beqrOverlayBusinessRuleFieldLevelConfiguration-select-gdDdlUserField']//span[@class='k-select']");
            By paid = By.XPath("//li[text()='Paid']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(Open);
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(paid);

            tmsWait.Hard(2);

            By save = By.XPath("//kendo-dropdownlist[@test-id='beqrOverlayBusinessRuleFieldLevelConfiguration-select-gdDdlUserField']/parent::td/following-sibling::td/button[2]");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(save);
            tmsWait.Hard(2);

        }

        [When(@"P(.*)P AR Management Search results Click Open Status and Update to Under Review status")]
        public void WhenPPARManagementSearchResultsClickOpenStatusAndUpdateToUnderReviewStatus(int p0)
        {
            By mbiValue = By.XPath("(//kendo-grid[@test-id='ArManagement-grid']//tr//td[contains(.,'Open')]/preceding-sibling::td[7])[1]");
            string PDEMMBI = Browser.Wd.FindElement(mbiValue).Text;

            fw.ConsoleReport(" Found MBI " + PDEMMBI);

            ScenarioContext.Current["PDEMMBI"] = PDEMMBI;

            By edit = By.XPath("(//kendo-grid[@test-id='ArManagement-grid']//tr//td[contains(.,'Open')]/following-sibling::td/button[1])[1]");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(edit);
            tmsWait.Hard(5);

            By Open = By.XPath("//kendo-dropdownlist[@test-id='beqrOverlayBusinessRuleFieldLevelConfiguration-select-gdDdlUserField']//span[@class='k-select']");
            By paid = By.XPath("//li[text()='Under Review']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(Open);
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(paid);

            tmsWait.Hard(2);

            By save = By.XPath("//kendo-dropdownlist[@test-id='beqrOverlayBusinessRuleFieldLevelConfiguration-select-gdDdlUserField']/parent::td/following-sibling::td/button[2]");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(save);
            tmsWait.Hard(2);
        }


        [When(@"P(.*)P AR Management Search results Click Open Status, Update to Under Review status")]
        public void WhenPPARManagementSearchResultsClickOpenStatusUpdateToUnderReviewStatus(int p0)
        {
            By mbiValue = By.XPath("(//kendo-grid[@test-id='ArManagement-grid']//tr//td[contains(.,'Open')]/preceding-sibling::td[7])[1]");
            string PDEMMBI = Browser.Wd.FindElement(mbiValue).Text;

           // ScenarioContext.Current["PDEMMBI"] = PDEMMBI;

            By edit = By.XPath("(//kendo-grid[@test-id='ArManagement-grid']//tr//td[contains(.,'Open')]/following-sibling::td/button[1])[1]");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(edit);
            tmsWait.Hard(5);

            By Open = By.XPath("//kendo-dropdownlist[@test-id='beqrOverlayBusinessRuleFieldLevelConfiguration-select-gdDdlUserField']//span[@class='k-select']");
            By paid = By.XPath("//li[text()='Under Review']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(Open);
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(paid);

            tmsWait.Hard(2);

            By save = By.XPath("//kendo-dropdownlist[@test-id='beqrOverlayBusinessRuleFieldLevelConfiguration-select-gdDdlUserField']/parent::td/following-sibling::td/button[2]");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(save);
            tmsWait.Hard(2);
        }

        [Then(@"Verify P(.*)P AR Management page Search results Grid displayed updated Under Review status with MBI")]
        public void ThenVerifyPPARManagementPageSearchResultsGridDisplayedUpdatedUnderReviewStatusWithMBI(int p0)
        {
            tmsWait.Hard(2);
            string PDEMMBI = ScenarioContext.Current["PDEMMBI"].ToString();
            By mbiValue = By.XPath("//td[contains(.,'" + PDEMMBI + "')]/following-sibling::td[contains(.,'Under Review')]");

            UIMODUtilFunctions.elementNotPresenceUsingLocators(mbiValue);
        }

        [Then(@"Verify P(.*)P AR Management Search results page displayed updated Under Review status with MBI")]
        public void ThenVerifyPPARManagementSearchResultsPageDisplayedUpdatedUnderReviewStatusWithMBI(int p0)
        {
            tmsWait.Hard(2);
            string PDEMMBI = ScenarioContext.Current["PDEMMBI"].ToString();
            By mbiValue = By.XPath("//td[contains(.,'" + PDEMMBI + "')]/following-sibling::td[contains(.,'Under Review')]");

            UIMODUtilFunctions.elementNotPresenceUsingLocators(mbiValue);
        }


        [When(@"P(.*)P AR Management Search results Click Open Status, Update to Paid status")]
        public void WhenPPARManagementSearchResultsClickOpenStatusUpdateToPaidStatus(int p0)
        {
            By mbiValue = By.XPath("(//div[@test-id='ArManagement-grid']//td[contains(.,'Open')]/preceding-sibling::td/span[@ng-bind='dataItem.mbi'])[1]");
            string PDEMMBI = Browser.Wd.FindElement(mbiValue).Text;

            ScenarioContext.Current["PDEMMBI"] = PDEMMBI;

            By edit = By.XPath("(//div[@test-id='ArManagement-grid']//td[contains(.,'Open')]/following-sibling::td/a)[1]");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(edit);
            tmsWait.Hard(5);

            By Open = By.XPath("//span[@class='k-widget k-dropdown k-header']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(Open);
            tmsWait.Hard(2);
            By paid = By.XPath("(//li[contains(.,'Paid')])[2]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(paid);

            tmsWait.Hard(2);

            By save = By.XPath("//a[@role='button']/span[@class='k-i-check fa fa-floppy-o']");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(save);
            tmsWait.Hard(2);
        }


        [When(@"P(.*)P AR Management Search results ID ""(.*)"" is Clicked and Selected value as ""(.*)"" Clicked Updated Button")]
        public void WhenPPARManagementSearchResultsIDIsClickedAndSelectedValueAsClickedUpdatedButton(int p0, string p1, string p2)
        {
            IWebElement submenu = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='ArManagement-grid']//tr[1]//td[contains(.,'" + p1+"')]/following-sibling::td/button[1]"));
            By paid = By.XPath("//li[text()='" + p2 + "']");

            fw.ExecuteJavascript(submenu);
            tmsWait.Hard(5);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(By.XPath("//kendo-dropdownlist[@test-id='beqrOverlayBusinessRuleFieldLevelConfiguration-select-gdDdlUserField']//span[@class='k-select']"));
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(paid);
            //SelectElement drp = new SelectElement(Browser.Wd.FindElement(By.XPath("//div[@id='arManagementGrid']//td[contains(.,'listbox')]")));
            //drp.SelectByText(p2);
            tmsWait.Hard(3);
            IWebElement update = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='ArManagement-grid']//tr[1]//td[contains(.,'" + p1 + "')]/following-sibling::td/button[2]"));
            fw.ExecuteJavascript(update);

            //fw.ExecuteJavascript(update);     

        }

        [Then(@"Verify P(.*)P AR Management Search results ID ""(.*)"" value is set to ""(.*)""")]
        public void ThenVerifyPPARManagementSearchResultsIDValueIsSetTo(int p0, string p1, string p2)
        {
            //IWebElement button = Browser.Wd.FindElement(By.Id("ctl00_MainContent_SearchPage"));
            //fw.ExecuteJavascript(button);
            tmsWait.Hard(5);
            IWebElement value = Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + p1+"')]/following-sibling::td[contains(.,'"+p2+"')]"));
            Assert.IsTrue(value.Displayed, p2 + " is not found on Serch results");
        }

        [Then(@"Verify P(.*)P AR Management Search results Grid displayed HICN as ""(.*)""")]
        public void ThenVerifyPPARManagementSearchResultsGridDisplayedHICNAs(int p0, string p1)
        {
            tmsWait.Hard(10);
            By loc=By.XPath("//kendo-grid[@test-id='ArManagement-grid']//td[contains(.,'" + p1 + "')]");

            UIMODUtilFunctions.elementPresenceUsingLocators(loc);

        }


        [Then(@"Verify P(.*)P AR Management Search results displayed HICN as ""(.*)""")]
        public void ThenVerifyPPARManagementSearchResultsDisplayedHICNAs(int p0, string p1)
        {
            bool hasrow = false;
            int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));

            //IWebElement button = Browser.Wd.FindElement(By.Id("p2pArManagement-btnSearch-parameter"));
            //fw.ExecuteJavascript(button);
            tmsWait.Hard(5);

            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {

                    hasrow = Browser.Wd.FindElement(By.XPath("//div[@id='arManagementGrid']//td[contains(.,'" + p1 + "')]")).Displayed;
                    break;
                }
                catch
                {

                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);
                }

            }

            Assert.IsTrue(hasrow, "There is no such row Present");
        }

        public void DropdownDefaultValueIsSetTo(IWebElement ele,string Act)
        {
            SelectElement drp = new SelectElement(ele);
            Assert.AreEqual(Act, drp.SelectedOption.Text, "Both values not matching");
        }

        [Then(@"Verify P(.*)P AR Management page ""(.*)"" value is set to ""(.*)""")]
        public void ThenVerifyPPARManagementPageValueIsSetTo(int p0, string field, string value)
        {
            IWebElement ele = null;

            tmsWait.Hard(5);
            switch (field)
            {
                case "Planid":
                    ele = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='p2pArManagement-selectplanId']//span[@class='k-input']"));
                    break;
                case "Submitter Planid":
                    ele = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='p2pArManagement-select-submitterPlanId']//span[@class='k-input']"));
                    break;
                case "PBP":
                    ele = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='p2pArManagement-select-pbp']//span[@class='k-input']"));
                    break;
                case "P2P Status":
                    ele = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='p2pArManagement-select-p2pStatus']//span[@class='k-input']"));
                    break;
                case "DOS Year":
                    ele = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='p2pArManagement-select-dosYear']//span[@class='k-input']"));
                    break;
                default:
                    break;
            }
            string actual = ele.Text;
            Assert.AreEqual(value, actual, " Both values are not matching");

        }

        [When(@"P(.*)P AR Management page ""(.*)"" is set to ""(.*)""")]
        public void WhenPPARManagementPageIsSetTo(int p0, string field, string value)
        {
            string strValue = tmsCommon.GenerateData(value);
            By typeapp = By.XPath("//li[text()='" + strValue + "']");

            switch (field)
            {
                case "Planid":
                    //UIMODUtilFunctions.clickOnWebElementUsingLocators(By.XPath("//kendo-dropdownlist[@test-id='p2pArManagement-selectplanId']//span[@class='k-select']"));
                    //tmsWait.Hard(1);
                    //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                    //tmsWait.Hard(4);
                    // UIMODUtilFunctions.sendTABUsingSelenium(By.XPath("//span[@aria-owns='planIds_listbox']"));

                    By Drp = By.XPath("//kendo-dropdownlist[@test-id='p2pArManagement-selectplanId']//span[@class='k-select']");
                    //By typeapp = By.XPath("//li[text()='" + strValue + "']");
                    fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                    fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));




                    break;
                case "Submitter Planid":
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(By.XPath("//kendo-dropdownlist[@test-id='p2pArManagement-select-submitterPlanId']//span[@class='k-select']"));
                    tmsWait.Hard(1);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                    tmsWait.Hard(4);
                    break;
                case "PBP":
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(By.XPath("//kendo-dropdownlist[@test-id='p2pArManagement-select-pbp']//span[@class='k-select']"));
                    tmsWait.Hard(1);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                    tmsWait.Hard(4);
                  //  UIMODUtilFunctions.sendTABUsingSelenium(By.XPath("//span[@aria-owns='pbpIds_listbox']"));
                    break;
                case "P2P Status":
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(By.XPath("//kendo-dropdownlist[@test-id='p2pArManagement-select-p2pStatus']//span[@class='k-select']"));
                    tmsWait.Hard(1);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                    tmsWait.Hard(4);
// UIMODUtilFunctions.sendTABUsingSelenium(By.XPath("//span[@aria-owns='p2pArManagement-select-p2pStatus_listbox']"));
                    break;
                case "DOS Year":
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(By.XPath("//kendo-dropdownlist[@test-id='p2pArManagement-select-dosYear']//span[@class='k-select']"));
                    tmsWait.Hard(1);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                    tmsWait.Hard(4);
                    // UIMODUtilFunctions.sendTABUsingSelenium(By.XPath("//span[@aria-owns='dosYears_listbox']"));

                    By Drp1 = By.XPath("//kendo-dropdownlist[@test-id='p2pArManagement-select-dosYear']//span[@class='k-select']");
                    //By typeapp = By.XPath("//li[text()='" + strValue + "']");
                    fw.ExecuteJavascript(Browser.Wd.FindElement(Drp1));
                    fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                    break;
                case "Start Date":
                    //value = value.Replace("/", "");
                    By startdate = By.XPath("//kendo-datepicker[@id='txtStartDate']//span[@role='button']");
                    AngularFunction.enterDate(startdate, value);
                    //Browser.Wd.FindElement(startdate).Clear();
                    //Browser.Wd.FindElement(startdate).SendKeys(value);
                    //IWebElement start = Browser.Wd.FindElement(By.Id("txtStartDate"));
                    //fw.ExecuteJavascriptSetText(start, value);
                    break;
                case "End Date":
                    //value = value.Replace("/", "");
                    By enddate = By.XPath("//kendo-datepicker[@id='txtEndDate']//span[@role='button']");
                    AngularFunction.enterDate(enddate, value);
                    //Browser.Wd.FindElement(enddate).Clear();
                    //Browser.Wd.FindElement(enddate).SendKeys(value);
                    //IWebElement end = Browser.Wd.FindElement(By.Id("txtEndDate"));
                    //fw.ExecuteJavascriptSetText(end, value);
                    break;
                default:
                    break;
            }
            tmsWait.Hard(1);

           
        }

        [When(@"View PDE Records page ""(.*)"" button is clicked")]
        public void WhenViewPDERecordsPageButtonIsClicked(string p0)
        {
            IWebElement field = null;

            switch (p0)
            {
                case "Search":
                    field = Browser.Wd.FindElement(By.XPath("//button[@test-id='viewEditPde-btn-search']/span[contains(.,'SEARCH')]"));
                    break;
            }
            fw.ExecuteJavascript(field);
            tmsWait.Hard(5);
        }

        [Then(@"Verify View PDE Records page displays Claim Control Number as ""(.*)""")]
        public void ThenVerifyViewPDERecordsPageDisplaysClaimControlNumberAs(string p0)
        {
            IWebElement element = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_MainContent_SearchFilterPanel1_PagedDataGrid_ctl01']//td[contains(.,'"+p0+"')]"));
            Assert.IsTrue(element.Displayed, p0 + " is not getting displayed");
        }


        [When(@"View PDE Records page Claim Control Number ""(.*)"" data is Edited")]
        public void WhenViewPDERecordsPageClaimControlNumberDataIsEdited(string p0)
        {
            IWebElement field = Browser.Wd.FindElement(By.XPath("//td[contains(.,'"+p0+ "')]/following-sibling::td//a"));
           // IWebElement field= Browser.Wd.FindElement(By.XPath(""))
            ReUsableFunctions.clickOnWebElement(field);
            //fw.ExecuteJavascript(field);

            tmsWait.Hard(5);
            //Browser.SwitchToWindow(1);
            //tmsWait.Hard(5);
        }

        [When(@"View PDE Records page ID ""(.*)"" data is Edited")]
        public void WhenViewPDERecordsPageIDDataIsEdited(string p0)
        {
            IWebElement field = Browser.Wd.FindElement(By.XPath("//td[contains(.,'"+p0+ "')]/following-sibling::td//a"));
            fw.ExecuteJavascript(field);
            tmsWait.Hard(5);
            Browser.SwitchToWindow(1);
            tmsWait.Hard(5);
        }

        [Then(@"Verify My Reports page displays ""(.*)"" drop down list")]
        public void ThenVerifyMyReportsPageDisplaysDropDownList(string p0)
        {
            string field = "ctl00_MainContent_lst"+p0+"";
            IWebElement element = Browser.Wd.FindElement(By.Id(field));
            Assert.IsTrue(element.Displayed, p0 + " is not getting displayed");
        }

        [When(@"PDEDataManager page ""(.*)"" menu is Clicked")]
        public void WhenPDEDataManagerPageMenuIsClicked(string p0)
        {
            IWebElement field = Browser.Wd.FindElement(By.XPath("//div[@title='" + p0 + "']"));
            //IWebElement field = Browser.Wd.FindElement(By.XPath("//a[contains(.,'"+p0+"')]"));
            fw.ExecuteJavascript(field);
        }

        [When(@"Verify My Reports page ""(.*)"" button is Clicked")]
        public void WhenVerifyMyReportsPageButtonIsClicked(string p0)
        {
            IWebElement field = Browser.Wd.FindElement(By.XPath("//input[@value='"+p0+"']"));
            fw.ExecuteJavascript(field);
        }

        [When(@"My Reports page ""(.*)"" report ""(.*)"" report is clicked and Verify ""(.*)"" text presence")]
        public void WhenMyReportsPageReportReportIsClickedAndVerifyTextPresence(string reportname, string format, string text)
        {
            tmsWait.Hard(20);
            //Deleting already saved PDF, XLS and CSV files from doanload folder.
            string[] fileExtensions = { ".pdf", ".xls", ".csv" };
            DirectoryInfo di = new DirectoryInfo(downloadPath);
            FileInfo[] oldDownloadedFiles = di.EnumerateFiles().Where(p => fileExtensions.Contains(p.Extension, StringComparer.InvariantCultureIgnoreCase)).ToArray();
            foreach (var oldFile in oldDownloadedFiles)
            {
                oldFile.Attributes = FileAttributes.Normal;
                File.Delete(oldFile.FullName);
            }

            string edit = "(//td[contains(.,'"+format+"')]/preceding-sibling::td[contains(.,'"+ reportname + "')]/preceding-sibling::td/a)[1]";
            IWebElement field = Browser.Wd.FindElement(By.XPath(edit));
            fw.ExecuteJavascript(field);

            if (ConfigFile.BrowserType.ToLower().Equals("chrome"))
            {
                Console.WriteLine("Reports are downloaded automatically");
                tmsWait.Hard(5);
            }
            else if (ConfigFile.BrowserType.ToLower().Equals("ie"))
            {
               
                tmsWait.Hard(1);
                DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_TAB, 0, 0, 0);
                tmsWait.Hard(1);
                DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_TAB, 0, 0, 0);
                tmsWait.Hard(1);
                DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_RETURN, 0, 0, 0);
            }

            if (format.ToUpper().Equals("PDF"))
            {
                tmsWait.Hard(5);
                string pdfText = ReadFileFunctions.ReadPDFFile(downloadPath + "\\" + reportname + ".PDF");
                Assert.IsTrue(pdfText.Contains(text), "PDF File missed some data. Failed...");
            }
            else if (format.ToUpper().Equals("CSV"))
            {
                tmsWait.Hard(5);
                var csvData = ReadFileFunctions.ReadCSVFile(downloadPath + "\\" + "" + reportname + ".CSV");
                VerifyText(csvData, text, format);
            }
            else
            {
                tmsWait.Hard(5);
                var excelData = ReadFileFunctions.ReadXLSFile(downloadPath + "\\" + "" + reportname + ".XLS", downloadPath + "\\" + "" + reportname + ".CSV");
                VerifyText(excelData, text, format);
            }
        }


        public void VerifyText(List<string> dataFromFile, string reportName, string format)
        {
            bool flag = false;
            foreach (string data in dataFromFile)
            {
                if (data.Contains(reportName))
                {
                    flag = true;
                }
            }
            if (format.ToUpper().Equals("CSV"))
            {
                //For CSV there is Report Name is not getting displayed. File is getting dreated successfully...
            }
            else
            {
                Assert.IsTrue(flag, format + " File has missed some data. Failed...");
            }
        }

        [Then(@"Verify PDEDataManager page ""(.*)"" section is displayed")]
        public void ThenVerifyPDEDataManagerPageSectionIsDisplayed(string p0)
        {
            string testId = null;
            switch (p0)
            {
                case "Batch Admin":
                    testId = "[test-id='batchAdmin-txt-errorcodes']";
                    break;
                case "Duplicate Records":
                    testId = "[test-id='duplicateRecords-select-planId']";
                    break;
                case "P2P AR Management":
                    testId = "[test-id='p2pArManagement-selectplanId']";
                    break;
                case "View PDE Records":
                    testId = "[test-id='viewEditPde-link-viewErrorCodes']";
                    break;
                default:
                    break;
            }
            IWebElement element = Browser.Wd.FindElement(By.CssSelector(testId));
            //IWebElement element = Browser.Wd.FindElement(By.XPath("//div[@id='ModuleHeader']//h1[contains(.,'"+p0+"')]"));
            Assert.IsTrue(element.Displayed, p0 + " is not getting displayed");
        }

        [When(@"View PDE Records page Advanced Search Button is Clicked")]
        public void WhenViewPDERecordsPageAdvancedSearchButtonIsClicked()
        {
            By loc = By.XPath("(//label[contains(.,'Advanced Search')]/parent::div/i)[2]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            tmsWait.Hard(3);
        }

        [When(@"View PDE Records page DOSYear drop down list is set to ""(.*)""")]
        public void WhenViewPDERecordsPageDOSYearDropDownListIsSetTo(string p0)
        {
            By loc = By.CssSelector("[aria-owns='formInputBoxDos_listbox']");
            UIMODUtilFunctions.selectDropDownValueFromGendoUI(Browser.Wd.FindElement(loc), p0);
            tmsWait.Hard(3);
        }

        [When(@"View PDE Records page SubmitterID drop down list is set to ""(.*)""")]
        public void WhenViewPDERecordsPageSubmitterIDDropDownListIsSetTo(string p0)
        {
            By loc = By.CssSelector("[aria-owns='formInputBoxSubmitterId_listbox']");
            UIMODUtilFunctions.selectDropDownValueFromGendoUI(Browser.Wd.FindElement(loc), p0);
            tmsWait.Hard(3);
        }


        [When(@"View PDE Records page ""(.*)"" drop down list is set to ""(.*)""")]
        public void WhenViewPDERecordsPageDropDownListIsSetTo(string p0, string p1)
        {
            string strValue = tmsCommon.GenerateData(p1);
            By typeapp = By.XPath("//li[text()='" + strValue + "']");

            switch (p0)
            {
                case "PlanId":
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(By.XPath("//kendo-dropdownlist[@test-id='batchAdmin-select-planId']//span[@class='k-select']"));
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                    break;
                case "PBP":
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(By.XPath("//kendo-dropdownlist[@test-id='batchAdmin-select-pbp']//span[@class='k-select']"));
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                    break;
                case "P2P Plan":
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(By.XPath("//kendo-dropdownlist[@test-id='batchAdmin-select-p2PPlan']//span[@class='k-select']"));
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                    break;
                case "DOSYearDropDownList":
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(By.XPath("//kendo-dropdownlist[@test-id='batchAdmin-select-yearOfDos']//span[@class='k-select']"));
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                    break;
                case "SubmitterID":
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(By.XPath("//kendo-dropdownlist[@test-id='batchAdmin-select-submitterId']//span[@class='k-select']"));
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                    break;
                default:
                    break;
            }

            //string id = "ctl00_MainContent_SearchFilterPanel1_" + p0;
            //IWebElement field = Browser.Wd.FindElement(By.Id(id));
            //SelectElement drp = new SelectElement(field);
            //drp.SelectByText(p1);
        }

        [When(@"View PDE Records page Advanced Search is Clicked")]
        public void WhenViewPDERecordsPageAdvancedSearchisClicked()
        {
            IWebElement field = Browser.Wd.FindElement(By.ClassName("cursorLink"));
            fw.ExecuteJavascript(field);

            tmsWait.Hard(2);
        }

        [When(@"View PDE Records page ""(.*)"" drop down list is selected and set to ""(.*)""")]
        public void WhenViewPDERecordsPageDropDownListIsSelectedAndSetTo(string p0, string p1)
        {
            IWebElement field = Browser.Wd.FindElement(By.Id("otherCriteriaSearchMenu"));
            IWebElement txtbox = Browser.Wd.FindElement(By.CssSelector("[placeholder='"+ p0 + "']"));
            SelectElement drp = new SelectElement(field);
            drp.SelectByText(p0);
            tmsWait.Hard(2);
            txtbox.SendKeys(p1);

        }


        [When(@"Edit View PDE Record page ""(.*)"" drop down list is set to ""(.*)""")]
        public void WhenEditViewPDERecordPageDropDownListIsSetTo(string p0, string p1)
        {
            string strValue = tmsCommon.GenerateData(p1);

            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(By.XPath("//kendo-dropdownlist[@id='" + p0+ "']//span[@class='k-select']"));
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(By.XPath("//li[text()='" + strValue + "']"));

            //string id = "ctl00_MainContent_" + p0;
            //IWebElement field = Browser.Wd.FindElement(By.Id(id));
            //SelectElement drp = new SelectElement(field);
            //drp.SelectByText(p1);
        }
        [When(@"Edit View PDE Record page Adjustment Reason Code is set to ""(.*)""")]
        public void WhenEditViewPDERecordPageAdjustmentReasonCodeIsSetTo(string p0)
        {
            IWebElement field = Browser.Wd.FindElement(By.Id("adjCode"));
            field.Clear();
            field.SendKeys(p0);
            tmsWait.Hard(5);
        }


        [When(@"Edit View PDE Record page ""(.*)"" check box is Clicked")]
        public void WhenEditViewPDERecordPageCheckBoxIsClicked(string p0)
        {
            IWebElement field = Browser.Wd.FindElement(By.XPath("//label[contains(.,'"+p0+ "')]/parent::div/input[@type='radio']"));
            fw.ExecuteJavascript(field);
        }
        [When(@"Edit View PDE Record page ""(.*)"" is set to ""(.*)""")]
        public void WhenEditViewPDERecordPageIsSetTo(string p0, string p1)
        {
            string date = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            //By dropDown = null;

            switch (date)
            {
                case "DOB":
                    By dob = By.XPath("//kendo-datepicker[@id='txtDob']//span[@role='button']");
                    AngularFunction.enterDate(dob, value);
                    break;
                case "PaidDate":
                    By PaidDate = By.XPath("//kendo-datepicker[@id='paidDate']//span[@role='button']");
                    AngularFunction.enterDate(PaidDate, value);
                    break;
            }
        }

        [When(@"Edit View PDE Record page ""(.*)"" button is Clicked")]
        public void WhenEditViewPDERecordPageButtonIsClicked(string p0)
        {
            IWebElement field = Browser.Wd.FindElement(By.Id("btn"+p0+""));
            fw.ExecuteJavascript(field);
        }

        [When(@"Edit View PDE Record page Back to Record button is Clicked")]
        public void WhenEditViewPDERecordPageBackToRecordButtonIsClicked()
        {
            IWebElement field = Browser.Wd.FindElement(By.XPath("//span[@test-id='editPde-span-back']"));
            fw.ExecuteJavascript(field);
            tmsWait.Hard(1);
        }

        [Then(@"Verify Edit View PDE Record page displays message ""(.*)""")]
        public void ThenVerifyEditViewPDERecordPageDisplaysMessage(string p0)
        {
            
            IWebElement field = Browser.Wd.FindElement(By.XPath("//span[contains(.,'"+p0+"')]"));

            bool res = field.Displayed;
            Assert.IsTrue(res, p0+" message is not getting displayed");
        }

        [Then(@"Verify View PDE Records page displays Claim Control Number value as ""(.*)"" and HIC Number as ""(.*)""")]
        public void ThenVerifyViewPDERecordsPageDisplaysClaimControlNumberValueAsAndHICNumberAs(string p0, string p1)
        {
            IWebElement field = Browser.Wd.FindElement(By.XPath("//td[contains(.,'"+p0+"')]/following-sibling::td[contains(.,'"+p1+"')]"));

            bool res = field.Displayed;
            Assert.IsTrue(res, p0 + " message is not getting displayed");
        }

        [Then(@"Verify View PDE Records page displays Results Grid")]
        public void ThenVerifyViewPDERecordsPageDisplaysResultsGrid()
        {
            IWebElement field = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='pdemBasicAndAdvanceSearch-grid-pdes']"));

            bool res = field.Displayed;
            Assert.IsTrue(res, "PDE results grid is not getting displayed");
        }

        [When(@"PDEDataManager page PDE Management Main menu View and Edit PDE submenu is Clicked")]
        public void WhenPDEDataManagerPagePDEManagementMainMenuViewAndEditPDESubmenuIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'View Edit PDE')]")));
            tmsWait.Hard(5);
            //IWebElement field = Browser.Wd.FindElement(By.XPath("//a[@id='ctl00_RadMenu1_m0_m0']/span"));
            //fw.ExecuteJavascript(field);
        }

        [When(@"Batch Admin page ""(.*)"" field is set to ""(.*)""")]
        public void WhenBatchAdminPageFieldIsSetTo(string p0, string p1)
        {
            string id = "ctl00_MainContent_SearchFilterPanel1_" + p0;
            IWebElement field = Browser.Wd.FindElement(By.Id(id));
            SelectElement drp = new SelectElement(field);
            drp.SelectByText(p1);
        }

        [When(@"Duplicate Records page DOS Year drop down is set to ""(.*)""")]
        public void WhenDuplicateRecordsPageDOSYearDropDownIsSetTo(string p0)
        {
            By dos = By.XPath("//kendo-dropdownlist[@test-id='duplicateRecords-select-dosYears']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + p0 + "']");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(dos);
            tmsWait.Hard(1);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

            //By value = By.XPath("(//li[contains(.,'All')])[3]");

            //fw.ExecuteJavascript(Browser.Wd.FindElement(value));
        }


        [When(@"Duplicate Records page ""(.*)"" drop down is set to ""(.*)""")]
        public void WhenDuplicateRecordsPageDropDownIsSetTo(string p0, string p1)
        {
            string id = tmsCommon.GenerateData(p1);
            By dropDown = null;

            switch (p0)
            {
                case "drpPlanid":
                    dropDown = By.XPath("//kendo-dropdownlist[@test-id='duplicateRecords-select-planId']//span[@class='k-select']");
                    break;
                case "drpdwnPBP":
                    dropDown = By.XPath("//kendo-dropdownlist[@test-id='duplicateRecords-select-pbpIds']//span[@class='k-select']");
                    break;
                case "drpdwnDOS":
                    dropDown = By.XPath("//kendo-dropdownlist[@test-id='duplicateRecords-select-dosYears']//span[@class='k-select']"); //By.CssSelector("[test-id='duplicateRecords-select-dosYears']");
                    break;
                default:
                    break;
            }
            By typeapp = By.XPath("//li[text()='" + id + "']");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(dropDown);
            tmsWait.Hard(1);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

            //IWebElement field = Browser.Wd.FindElement(By.Id(id));
            //SelectElement drp = new SelectElement(field);
            //drp.SelectByText(p1);
        }

        [When(@"Duplicate Records page ""(.*)"" button is clicked")]
        public void WhenDuplicateRecordsPageButtonIsClicked(string p0)
        {
            string id = "btn" + p0;
            IWebElement field = Browser.Wd.FindElement(By.Id(id));
            fw.ExecuteJavascript(field);
            tmsWait.Hard(5);
        }


        [Then(@"Verify Duplicate Record Page first record details and assigned to ""(.*)"" ""(.*)"" ""(.*)"" ""(.*)"" ""(.*)"" ""(.*)"" ""(.*)"" ""(.*)""")]
        public void ThenVerifyDuplicateRecordPageFirstRecordDetailsAndAssignedTo(string p0, string p1, string p2, string p3, string p4, string p5, string p6, string p7)
        {
            string duplicateId = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='duplicateRecords-grid-duplicateRecordsResult']//tr[1]/td[1]")).Text;
            string planID = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='duplicateRecords-grid-duplicateRecordsResult']//tr[1]/td[2]")).Text;
            string pbpID = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='duplicateRecords-grid-duplicateRecordsResult']//tr[1]/td[3]")).Text;
            string MBI = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='duplicateRecords-grid-duplicateRecordsResult']//tr[1]/td[4]")).Text;
            string dos = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='duplicateRecords-grid-duplicateRecordsResult']//tr[1]/td[6]")).Text;
            string prn = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='duplicateRecords-grid-duplicateRecordsResult']//tr[1]/td[7]")).Text;
            string piq = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='duplicateRecords-grid-duplicateRecordsResult']//tr[1]/td[8]")).Text;
            string spi = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='duplicateRecords-grid-duplicateRecordsResult']//tr[1]/td[9]")).Text;

            fw.setVariable(p0, duplicateId);
            fw.setVariable(p1, planID);
            fw.setVariable(p2, pbpID);
            fw.setVariable(p3, MBI);
            fw.setVariable(p4, dos);
            fw.setVariable(p5, prn);
            fw.setVariable(p6, piq);
            fw.setVariable(p7, spi);
            
        }


        [When(@"Duplicate Record page View link is clicked for first record")]
        public void WhenDuplicateRecordPageViewLinkIsClickedForFirstRecord()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='duplicateRecords-grid-duplicateRecordsResult']//tr[1]//i")));
            tmsWait.Hard(5);
        }


        [When(@"Duplicate Records Search results Prescription Service ReferenceNo ""(.*)"" is Clicked")]
        public void WhenDuplicateRecordsSearchResultsPrescriptionServiceReferenceNoIsClicked(string p0)
        {
            
            IWebElement field = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='duplicateRecords-grid-duplicateRecordsResult']//td[contains(.,'" + p0 + "')]//following-sibling::td//a"));
            ReUsableFunctions.clickOnWebElement(field);
            tmsWait.Hard(5);

            //fw.ExecuteJavascript(field);
            //tmsWait.Hard(5);
            //Browser.SwitchToWindow(1);
        }


        [Then(@"Verify view Single Item Duplicate Record page ""(.*)"" field is set to ""(.*)""")]
        public void ThenVerifyViewSingleItemDuplicateRecordPageFieldIsSetTo(string p0, string p1)
        {
            string id = "pdeRecordDetail-lbl-" + p0 + "Info";
            string value = tmsCommon.GenerateData(p1);
            IWebElement field = Browser.Wd.FindElement(By.CssSelector("[test-id='" + id +"']"));

            string act = field.Text;
            //string act = field.GetAttribute("value").ToString();
            Assert.AreEqual(value,act, "Both values are not matching");
        }

        [When(@"View Single Item Duplicate Record page ""(.*)"" field i icon is clicked")]
        [Then(@"View Single Item Duplicate Record page ""(.*)"" field i icon is clicked")]
        public void WhenViewSingleItemDuplicateRecordPageFieldiIconIsClicked(string p0)
        {
            string id = "pdeRecordDetail-lbl-" + p0;
            IWebElement field = Browser.Wd.FindElement(By.XPath("//label[@test-id='" + id + "']/following-sibling::i"));

            ReUsableFunctions.clickOnWebElement(field);
        }

        [Then(@"Verify Duplicate Record page ""(.*)"" information window exists")]
        public void ThenVerifyViewSingleItemDuplicateRecordPageInformationWindowExists(string p0)
        {
            string id = "lookupData-span-lookupDataTitle";
            string value = tmsCommon.GenerateData(p0);
            IWebElement field = Browser.Wd.FindElement(By.XPath("//span[@test-id='" + id + "']"));

            Assert.IsTrue(field.Displayed, p0 + "is not displayed");
            string act = field.Text;
            //string act = field.GetAttribute("value").ToString();
            Assert.AreEqual(value, act, "Both values are not matching");
        }

        [Then(@"Verify ""(.*)"" on UI is matches with database value ""(.*)""")]
        public void ThenVerifyOnUIIsMatchesWithDatabaseValue(string p0, string p1)
        {
            string DuplicateId_In_UI = tmsCommon.GenerateData(p0);
            string DuplicateId_In_Database = tmsCommon.GenerateData(p1);

            Assert.AreEqual(DuplicateId_In_Database, DuplicateId_In_Database, "Expected value from DB and UI does not match");
        }


        [Then(@"Verify Duplicate Records Search results display HICN as ""(.*)""")]
        public void ThenVerifyDuplicateRecordsSearchResultsDisplayHICNAs(string p0)
        {
            tmsWait.Hard(5);

            By totalPageAvailable = By.XPath("//kendo-numerictextbox[@class='k-widget k-numerictextbox']/span[@class='k-numeric-wrap']/input");
            string totalpage = Browser.Wd.FindElement(totalPageAvailable).GetAttribute("aria-valuemax");

            int length = totalpage.Length;

            

            

           IReadOnlyCollection<IWebElement> webElementList= Browser.Wd.FindElements(By.XPath("//kendo-grid[@test-id='duplicateRecords-grid-duplicateRecordsResult']//table[@class='k-grid-table']/tbody/tr"));
            bool match = false;
            int i = 1;
            while(i<=Int32.Parse(totalpage)) {

                for (int k = 1; k <= webElementList.Count; k++) {

                    IWebElement field = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='duplicateRecords-grid-duplicateRecordsResult']//table[@class='k-grid-table']/tbody/tr["+k+"]/td[4]"));


                    if (field.Text.Equals(p0)) {
                        match = true;
                        Assert.IsTrue(field.Displayed, "is not displayed");
                        break;
                    }
                }

                if (match == false) {
                    i++;
                    Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']/span[@class='k-icon k-i-arrow-e']")).Click();
                    tmsWait.Hard(3);
                }

                if (match == true) { break; }
            
            }


            //IWebElement field = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='duplicateRecords-grid-duplicateRecordsResult']//td[contains(.,'" + p0+"')]"));
            
            
        }


        [Then(@"Verify Duplicate Record page ""(.*)"" information window display ""(.*)"" for ""(.*)""")]
        public void ThenVerifyDuplicateRecordPageInformationWindowDisplayFor(string p0, string p1, string p2)
        {
           
            string value = tmsCommon.GenerateData(p1);
            string descritpion = tmsCommon.GenerateData(p2);
            bool isclick = false;

            //clicking on information icon

            while (!isclick)
            {
                try
                {
                    isclick = Browser.Wd.FindElement(By.XPath("//kendo-grid-list//td[contains(.,'" + value + "')]/following-sibling::td[contains(.,'" + descritpion + "')]")).Displayed;
                    break;
                }
                catch {
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//*[@title='Go to the next page'])[2]")));
                    tmsWait.Hard(3);
                }

                
            }
           

            //IWebElement InformationTable = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='lookupData-grid-lookupDataGrid']//div/table/tbody"));
            //IReadOnlyCollection<IWebElement> TotalRows = InformationTable.FindElements(By.TagName("tr"));
            //bool ispresent = false;
            //bool finalpage = false;

            ///*do-while loop is meant to paginate through tables with more than five entries, this needs to be fleshed out once angular changes are stable*/
            ////do
            ////{
            //    foreach (var row in TotalRows)
            //    {
            //        string actualvalue = row.FindElement(By.XPath("td[1]")).Text;
            //        string actualDescription = row.FindElement(By.XPath("td[2]")).Text;

            //        if (actualvalue == value)
            //        {
            //            if (actualDescription == descritpion)
            //            {
            //                ispresent = true;
            //                break;
            //            }
            //        }
            //    }

            //    /*Check if there are more pages, click to the next page and update number of rows if yes, exit function if no*/
            //    try
            //    {
            //        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//kendo-pager-next-buttons/a[@class='k-link k-pager-nav']")));
            //    }
            //    catch
            //    {
            //        finalpage = true;
            //    }

            //    tmsWait.Hard(2);

            //    if (finalpage)
            //    {
            //        InformationTable = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='lookupData-grid-lookupDataGrid']//div/table/tbody"));
            //        TotalRows = InformationTable.FindElements(By.TagName("tr"));
            //    }
            //} while (!finalpage);

           // Assert.IsTrue(ispresent, "Details on " + field + " information window are not appropriate");
        }


        [When(@"Duplicate Record page Information Window is closed")]
        public void WhenDuplicateRecordPageInformationWindowIsClosed()
        {
            //IWebElement CloseWindow = Browser.Wd.FindElement(By.XPath("(//kendo-dialog-titlebar//div/a)[2]"));
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//kendo-dialog-titlebar//div/a/span[@class])[3]")));
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + field + "')]/following-sibling::i")));

            // Browser.Wd.FindElement(By.XPath("(//kendo-dialog-titlebar//div/a/span[@class])[3]")).SendKeys(Keys.Escape);

            tmsWait.Hard(4);
        }

        [When(@"Duplicate Record page Information ""(.*)"" icon is Clicked")]
        public void WhenDuplicateRecordPageInformationIconIsClicked(string p0)
        {
            try
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + p0 + "')]/i")));
            }
            catch
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + p0 + "')]/following-sibling::i")));
            }
         }



        [Then(@"Verify Duplicate Records page ""(.*)"" drop down value is set to ""(.*)""")]
        public void ThenVerifyDuplicateRecordsPageDropDownValueIsSetTo(string p0, string value)
        {
            string id = "";
            string strValue = tmsCommon.GenerateData(value);

            tmsWait.Hard(2);
            switch (p0)
            {
                case "drpPlanid":
                    id = "//kendo-dropdownlist[@test-id='duplicateRecords-select-planId']//span[@class='k-input']";
                    break;
                case "drpdwnPBP":
                    id = "//kendo-dropdownlist[@test-id='duplicateRecords-select-pbpIds']//span[@class='k-input']";
                    break;
                case "drpdwnDOS":
                    id = "//kendo-dropdownlist[@test-id='duplicateRecords-select-dosYears']//span[@class='k-input']";
                    break;
                default:
                    break;
            }

            string ele = Browser.Wd.FindElement(By.XPath(id)).Text;
            Assert.AreEqual(strValue, ele, " Both values are not matching");

            //IWebElement field = Browser.Wd.FindElement(By.Id(id));
            //SelectElement drp = new SelectElement(field);
            //string act = drp.SelectedOption.Text;
            //Assert.AreEqual(value, act, "Both values are not matching");
        }


        [When(@"Batch Admin page ""(.*)"" button is Clicked")]
        public void WhenBatchAdminPageButtonIsClicked(string p0)
        {
            string id = "";

            switch (p0)
            {
                case "Search":
                    id = "[@test-id='viewEditPde-btn-search']/span[contains(.,'SEARCH')]";
                    break;
                case "Reset":
                    id = "[contains(.,'RESET')]";
                    break;
                default:
                    break;
            }
            IWebElement field = Browser.Wd.FindElement(By.XPath("//button" + id + ""));
            //IWebElement field = Browser.Wd.FindElement(By.Id(id));
            fw.ExecuteJavascript(field);
            tmsWait.Hard(5);
        }

      
        [When(@"Batch Admin page Reset button Clicked")]
        public void WhenBatchAdminPageResetButtonClicked()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[contains(.,'RESET')]")));
            tmsWait.Hard(3);
        }



        [Then(@"Verify Search results display ""(.*)""")]
        public void ThenVerifySearchResultsDisplay(Decimal p0)
        {
            tmsWait.Hard(5);
            IWebElement field = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='pdemBasicAndAdvanceSearch-grid-pdes']"));
            //IWebElement field = Browser.Wd.FindElement(By.XPath("//div[@id='pdemBasicAndAdvanceSearchDataGrid']//tr//td[contains(.,'" + p0 + "')]"));
            Assert.IsTrue(field.Displayed, p0 + "is not displayed");
            
        }
        [When(@"When PDEDataManager page PDE Management Main menu ""(.*)"" submenu is Clicked")]
        public void WhenWhenPDEDataManagerPagePDEManagementMainMenuSubmenuIsClicked(string p0)
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]")));
            tmsWait.Hard(5);

            //IWebElement submenu = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]"));
            //fw.ExecuteJavascript(submenu);
        }

        [When(@"PDEDataManager page Report menu is Clicked")]
        public void WhenPDEDataManagerPageReportMenuIsClicked()
        {
            IWebElement submenu = Browser.Wd.FindElement(By.XPath("//div[@title='Reports']"));
            fw.ExecuteJavascript(submenu);
        }

        [When(@"PDE Manager page Reports menu ""(.*)"" submenu is Clicked")]
        public void WhenPDEManagerPageReportsMenuSubmenuIsClicked(string p0)
        {
            IWebElement submenu = Browser.Wd.FindElement(By.XPath("//span[@test-id='" + p0+ "']"));
            fw.ExecuteJavascript(submenu);
        }

        [When(@"Report page ""(.*)"" checkbox is checked")]
        public void WhenReportPageCheckboxIsChecked(string p0)
        {
            string id = "ctl00_MainContent_" + p0;
            IWebElement submenu = Browser.Wd.FindElement(By.Id(id));
            fw.ExecuteJavascript(submenu);
        }

        [When(@"Report page Run Report button is Clicked")]
        public void WhenReportPageRunReportButtonIsClicked()
        {
            IWebElement submenu = Browser.Wd.FindElement(By.Id("ctl00_MainContent_cmdSubmitAsync"));
            fw.ExecuteJavascript(submenu);
            tmsWait.Hard(5);
            ReUsableFunctions.reportAuthenticationHandler();

        }

        [When(@"""(.*)"" menu is Clicked")]
        public void WhenMenuIsClicked(string p0)
        {
            tmsWait.Hard(5);
            IWebElement submenu = Browser.Wd.FindElement(By.XPath("//div[@id='ctl00_RadMenu1']//a/span[contains(.,'"+p0+"')]"));
            fw.ExecuteJavascript(submenu);
        }

        [When(@"My Reports page ""(.*)"" is selected as ""(.*)""")]
        public void WhenMyReportsPageIsSelectedAs(string p0, string value)
        {

            string id = "ctl00_MainContent_lst" + p0;
            IWebElement field = Browser.Wd.FindElement(By.Id(id));

            SelectElement drp = new SelectElement(field);
            drp.DeselectAll();
            tmsWait.Hard(2);
            drp.SelectByText(value);
        }

        [When(@"My Reports page Search button is Clicked")]
        public void WhenMyReportsPageSearchButtonIsClicked()
        {
            tmsWait.Hard(100);
            IWebElement submenu = Browser.Wd.FindElement(By.Id("ctl00_MainContent_btnSearchData"));
            fw.ExecuteJavascript(submenu);
            tmsWait.Hard(5);
        }

        [When(@"My Reports page ""(.*)"" Reports ""(.*)"" format is ""(.*)"" and Verify Title ""(.*)"" presence")]
        public void WhenMyReportsPageReportsFormatIsAndVerifyTitlePresence(string report, string format, string download, string Title)
        {
            
        //Deleting already saved PDF, XLS and CSV files from doanload folder.
        string[] fileExtensions = { ".pdf", ".xls", ".csv" };
            DirectoryInfo di = new DirectoryInfo(downloadPath);
            FileInfo[] oldDownloadedFiles = di.EnumerateFiles().Where(p => fileExtensions.Contains(p.Extension, StringComparer.InvariantCultureIgnoreCase)).ToArray();
            foreach (var oldFile in oldDownloadedFiles)
            {
                oldFile.Attributes = FileAttributes.Normal;
                File.Delete(oldFile.FullName);
            }
            tmsWait.Hard(20);

            IWebElement submenu = Browser.Wd.FindElement(By.XPath("//td[contains(.,'"+report+"')]/following-sibling::td[contains(.,'"+ format + "')]/preceding-sibling::td//img[@alt='"+ download + "']"));
            fw.ExecuteJavascript(submenu);
            tmsWait.Hard(2);

             if (ConfigFile.BrowserType.ToLower().Equals("ie"))
            {
                
                IWebElement securityWindow = Browser.winium.FindElement(By.Name("Save"));
                securityWindow.Click();
            }
                //DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_TAB, 0, 0, 0);
                //tmsWait.Hard(2);
                //DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_TAB, 0, 0, 0);
                //tmsWait.Hard(2);
                //DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_RETURN, 0, 0, 0);

                if (format.ToUpper().Equals(".PDF"))
            {
                tmsWait.Hard(5);
                string pdfText = ReadFileFunctions.ReadPDFFile(downloadPath + "\\" + report + ".PDF");
                Assert.IsTrue(pdfText.Contains(Title), "PDF File missed some data. Failed...");
            }
            else if (format.ToUpper().Equals(".CSV"))
            {
                tmsWait.Hard(5);
                var csvData = ReadFileFunctions.ReadCSVFile(downloadPath + "\\" + "" + report + ".CSV");
                VerifyText(csvData, Title, format);
            }
            else
            {
                tmsWait.Hard(5);
                var excelData = ReadFileFunctions.ReadXLSFile(downloadPath + "\\" + "" + report + ".XLS", downloadPath + "\\" + "" + report + ".CSV");
                VerifyText(excelData, Title, format);
            }
        }


        [Then(@"Verify File Processing page ""(.*)"" Report displays Processing Status as ""(.*)""")]
        public void ThenVerifyFileProcessingPageReportDisplaysProcessingStatusAs(string p0, string p1)
        {
            IWebElement link = Browser.Wd.FindElement(By.LinkText("file processing status page"));
            fw.ExecuteJavascript(link);
            tmsWait.Hard(5);
            IWebElement status = null;
            do
            {
                status = Browser.Wd.FindElement(By.XPath("//td[contains(.,'Workflow Tracking Summary')]/preceding-sibling::td[contains(.,'Complete')]"));
            }
            while (status.Displayed);
          
        }

        [Then(@"Verify View Edit PDE page File Processing page message is displayed")]
        public void ThenVerifyViewEditPDEpageFileProcessingPageMessageIsDisplayed()
        {
            tmsWait.Hard(5);
            IWebElement status =  Browser.Wd.FindElement(By.XPath("//span[contains(.,'File Processing Status page')]"));
            
            while (status.Displayed);
        }

        [Then(@"Verify PDEM Report displays ""(.*)"" successfully")]
        public void ThenVerifyPDEMReportDisplaysSuccessfully(string p0)
        {
            tmsWait.Hard(5);
            Browser.SwitchToChildWindow();
            Browser.SwitchToIFrame();
            IWebElement text = Browser.Wd.FindElement(By.XPath("//table[@id='ReportViewerControl_fixedTable']//*[contains(.,'"+p0+"')]"));
            tmsWait.Hard(5);
            Assert.IsTrue(text.Displayed,p0+" is not geting displayed");
        }


        [When(@"Report page ""(.*)"" dropdown list is set to ""(.*)""")]
        public void WhenReportPageDropdownListIsSetTo(string p0, string value)
        {
            string id = "ctl00_MainContent_" + p0;
            IWebElement field = Browser.Wd.FindElement(By.Id(id));

            SelectElement drp = new SelectElement(field);
            drp.SelectByText(value);

        }

        [Then(@"Verify PDEM Report page display ""(.*)"" dropdown list value as ""(.*)""")]
        public void ThenVerifyPDEMReportPageDisplayDropdownListValueAs(string field, string value)
        {
            IWebElement drp = Browser.Wd.FindElement(By.Id("ctl00_MainContent_" + field + ""));
            IList<IWebElement> act = drp.FindElements(By.TagName("option"));

            string[] exp = value.Split(',');
            for(int i=0;i<act.Count;i++)
            {
                if(exp[i].Equals(act[i].Text))
                {
                    Console.WriteLine(act[i].Text + " values are matching Expected value "+exp[i]);
                }
                else
                {
                    Assert.Fail(" Expected values are not matching with actual values");
                }
            }

        
           
        }

        [When(@"PDEDataManager page PDE Management ""(.*)"" menu is Clicked")]
        public void WhenWhenPDEDataManagerPagePDEManagementMenumenuIsClicked(string p0)
        {
            tmsWait.Hard(4);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@title='" + p0 + "']")));
        }

        [When(@"When PDEDataManager page PDE Management menu ""(.*)"" submenu is Clicked")]
        public void WhenWhenPDEDataManagerPagePDEManagementMenuSubmenuIsClicked(string p0)
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]")));
            tmsWait.Hard(5);

            //IWebElement submenu = Browser.Wd.FindElement(By.XPath("//a[@id='ctl00_RadMenu1_m0_m2']/span[contains(.,'" + p0 + "')]"));
            //fw.ExecuteJavascript(submenu);
        }


        [When(@"PDE Audit History page ""(.*)"" drop down is set to ""(.*)""")]
        public void WhenPDEAuditHistoryPageDropDownIsSetTo(string p0, string value)
        {
            string id = "";
            switch (p0)
            {
                case "cboUser":
                    id = "test-id='auditHistory-select-user']";
                    break;
                case "cboLoadFile":
                    id = "test-id='auditHistory-select-file']";
                    break;
                case "SubmitterIDDropdown":
                    id = "test-id='auditHistory-select-submitterId']";
                    break;
                case "cboTransType":
                    id = "test-id='auditHistory-select-status']";
                    break;
                case "FeildDrpdwn":
                    id = "test-id='auditHistory-select-field']";
                    break;
                default:
                    break;
            }
            By plan = By.XPath("//kendo-dropdownlist[@" + id + "//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + value + "']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(plan);
            tmsWait.Hard(1);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

            //IWebElement field = Browser.Wd.FindElement(By.Id(id));

            //SelectElement drp = new SelectElement(field);
            //drp.SelectByText(value);
        }

        [When(@"PDE Audit History page ""(.*)"" button is Clicked")]
        public void WhenPDEAuditHistoryPageButtonIsClicked(string p0)
        {
            tmsWait.Hard(4);
            string id = "";

            switch (p0)
            {
                case "Search":
                    id = "[test-id='auditHistory-btn-search']";
                    break;
                case "Reset":
                    id = "[test-id='auditHistory-btn-reset']";
                    break;
                default:
                    break;
            }
            IWebElement field = Browser.Wd.FindElement(By.CssSelector(id));
            //IWebElement field = Browser.Wd.FindElement(By.Id(id));
            fw.ExecuteJavascript(field);
        }

        [When(@"PDE Audit History page ""(.*)"" button is Clicked Successfully")]
        public void WhenPDEAuditHistoryPageButtonIsClickedSuccessfully(string p0)
        {
            p0 = p0.ToLower();

        tmsWait.Hard(4);
            string id = "[test-id='auditHistory-btn-" + p0 + "']";
            IWebElement field = Browser.Wd.FindElement(By.CssSelector(id));
            fw.ExecuteJavascript(field);
            tmsWait.Hard(2);
        }

        [Then(@"Verify PDE Audit History page Search results displays value ""(.*)""")]
        public void ThenVerifyPDEAuditHistoryPageSearchResultsDisplaysValue(string p0)
        {
            try
            {
                IWebElement element = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='auditHistory-grid']//tr[1]//td[contains(.,'" + p0 + "')]"));
                Assert.IsTrue(element.Displayed, p0 + " is not getting displayed");
            }
            catch
            {
                Console.WriteLine("There is no data for the current criteria, table is not displayed, this behavior is correct");
            }
        }
        public List<string> dbValues;
        string[,] array2Db;
        List<int> dbIntValues;
        List<int> dbIntValues1;
        List<int> dbIntValues2;

        List<DateTime> dbDateValues;
        [When(@"Execute Query on DB ""(.*)"" get all the values from Tablee")]
        [When(@"Execute Query on DB ""(.*)"" get all the values from Table")]
        public void WhenExecuteQueryOnDBGetAllTheValuesFromTable(string dbname)
        {
            tmsWait.Hard(15); // Reason for more Wait is Table field updation is taking time. please do not remove this wait

            dbIntValues = db.returnSQLQueryresultsWithCompleteIntegerRowsInArrayFormat(dbname);

        }
        [When(@"Execute Query on DB ""(.*)"" get all the values from ReportParamTypes Tablee")]
        public void WhenExecuteQueryOnDBGetAllTheValuesFromReportParamTypesTablee(string p0)
        {
            tmsWait.Hard(15); // Reason for more Wait is Table field updation is taking time. please do not remove this wait

            dbIntValues2 = db.returnSQLQueryresultsWithCompleteIntegerRowsInArrayFormat(p0);

        }
        [Then(@"verify both tables has same ""(.*)"" values")]
        public void ThenVerifyBothTablesHasSameValues(string p0)
        {
            List<int> intList;
            intList = compareTwoListint(dbIntValues1, dbIntValues2);


            Assert.IsTrue(intList.Count.Equals(0), " All values are matched");


        }

        private List<int> compareTwoListint(List<int> dbIntValues1, List<int> dbIntValues2)
        {
            List<int> resultantList = new List<int>();
            List<int> intValues = new List<int>();
            foreach (int temp in dbIntValues1)
            {
                intValues.Add(temp);
            }

            Console.WriteLine("Difference in the Drop Down List and DB value lists...");
            IEnumerable<int> list3;
            list3 = dbIntValues2.Except(intValues);
            foreach (int value in list3)
            {
                resultantList.Add(value);
            }
            return resultantList;
        }

        [When(@"Execute Query on DB ""(.*)"" get all the values from  ReportParams Tablee")]
        public void WhenExecuteQueryOnDBGetAllTheValuesFromReportParamsTablee(string p0)
        {
           

        tmsWait.Hard(15); // Reason for more Wait is Table field updation is taking time. please do not remove this wait

            dbIntValues1 = db.returnSQLQueryresultsWithCompleteIntegerRowsInArrayFormat(p0);

        }
        [When(@"Execute Query on DB new ""(.*)"" get all the values from Table")]
        public void WhenExecuteQueryOnDBNewGetAllTheValuesFromTable(string p0)
        {
                tmsWait.Hard(15); // Reason for more Wait is Table field updation is taking time. please do not remove this wait

               dbIntValues = db.returnSQLQueryresultsWithCompleteIntegerRowsInArrayFormat16(p0);
        }


        //[When(@"I execute Query on DB ""(.*)"" get all the values from Table")]
        //public void WhenIExecuteQueryOnDBGetAllTheValuesFromTable(string p0)
        //{
        //    tmsWait.Hard(15); // Reason for more Wait is Table field updation is taking time. please do not remove this wait

        //    dbIntValues = db.returnSQLQueryresultsWithCompleteIntegerRowsInArrayFormat16(p0);
        //}


        [When(@"I execute Query on DB ""(.*)"" get all the values from Table")]
        public void WhenIExecuteQueryOnDBGetAllTheValuesFromTable(string p0)
        {
            tmsWait.Hard(15); // Reason for more Wait is Table field updation is taking time. please do not remove this wait

            dbIntValues = db.returnSQLQueryresultsWithCompleteIntegerRowsInArrayFormat16(p0);
        }

        [When(@"Execute Query on DB ""(.*)"" get all the string values from DataBaseTable")]
        public void WhenExecuteQueryOnDBGetAllTheStringValuesFromDataBaseTable(string p0)
        {
           

        tmsWait.Hard(15);
            dbValues = db.returnSQLQueryresultsWithCompleteRowsInArrayFormat(p0);
        }
        public List<string> ConvertWebElementInToString(IList<IWebElement> webdrpValues)
        {
            List<string> temp = new List<string>();
            Console.WriteLine(" List of Values in Drop Down list");
            foreach (IWebElement t in webdrpValues)
            {
                temp.Add(t.Text);
                Console.WriteLine(t.GetAttribute("innerHTML"));
            }
            return temp;

        }
        public List<string> ConvertWebElementInToStringByInnerHTML(IList<IWebElement> webdrpValues)
        {
            List<string> temp = new List<string>();
            Console.WriteLine(" List of Values in Drop Down list");
            for(int i=1;i<=webdrpValues.Count-1; i++) { 
                temp.Add(webdrpValues[i].GetAttribute("innerHTML"));
                Console.WriteLine(webdrpValues[i].GetAttribute("innerHTML"));
            }
            return temp;

        }
        [Then(@"Verify PDE Audit History page ""(.*)"" values matched with Database Code values")]
        public void ThenVerifyPDEAuditHistoryPageValuesMatchedWithDatabaseCodeValues(string p0)
        {
            string id = "";
            switch (p0)
            {
                case "cboUser":
                    id = "aria-owns='auditHistory-select-User_listbox']";
                    break;
                case "cboLoadFile":
                    id = "//ul[@id='auditHistory-select-File_listbox']//li";
                    break;
                case "SubmitterIDDropdown":
                    id = "//ul[@id='auditHistory-select-submitterId_listbox']//li";
                    break;
                case "cboTransType":
                    id = "//ul[@id='auditHistory-select-status_listbox']//li";
                    break;
                case "FeildDrpdwn":
                    id = "aria-owns='auditHistory-select-field_listbox']";
                    break;
                default:
                    break;
            }
            IList<IWebElement> stringdrpValues = new List<IWebElement>();
            List<string> stringValues;
            List<string> stringDBValues = dbValues;
            IList<IWebElement> code;
            tmsWait.Hard(2);
            stringdrpValues = Browser.Wd.FindElements(By.XPath(id));
           
                stringValues = ConvertWebElementInToStringByInnerHTML(stringdrpValues);
                
               

           
            List<string> resultantString = compareTwoList(stringDBValues, stringValues);

            Assert.IsTrue((resultantString.Count == 0), "Values are not matching");
        }
        List<string> compareTwoList(List<string> drpValues, List<string> dbValues)
        {
            List<string> resultantList = new List<string>();

            //Console.WriteLine("Difference in the Drop Down List and DB value lists...");
            IEnumerable<string> list3;
            list3 = drpValues.Except(dbValues);

            foreach (string value in list3)
            {
                resultantList.Add(value);
            }
            return resultantList;
        }
        
        [Then(@"Verify PDE Audit History page ""(.*)"" drop down value is reset to ""(.*)""")]
        public void ThenVerifyPDEAuditHistoryPageDropDownValueIsResetTo(string p0, string value)
        {
            tmsWait.Hard(5);
            string id = "";

            switch (p0)
            {
                case "cboUser":
                    id = "test-id='auditHistory-select-user']";
                    break;
                case "cboLoadFile":
                    id = "test-id='auditHistory-select-file']";
                    break;
                case "SubmitterIDDropdown":
                    id = "test-id='auditHistory-select-submitterId']";
                    break;
                case "cboTransType":
                    id = "test-id='auditHistory-select-status']";
                    break;
                case "FeildDrpdwn":
                    id = "test-id='auditHistory-select-field']";
                    break;
                default:
                    break;
            }
            By plan = By.XPath("//kendo-dropdownlist[@" + id + "//span[@class='k-input']"); 
            string act = Browser.Wd.FindElement(plan).Text;

            //IWebElement field = Browser.Wd.FindElement(By.Id(id));
            //SelectElement drp = new SelectElement(field);
            //string act = drp.SelectedOption.Text;
            Assert.AreEqual(value, act, "Both values are not matching");
        }

        [When(@"PDEDataMaanger page Files Menu ""(.*)"" submenu is Clicked")]
        public void WhenPDEDataMaangerPageFilesMenuSubmenuIsClicked(string p0)
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]")));
            tmsWait.Hard(5);

            //IWebElement field = Browser.Wd.FindElement(By.XPath("//a/span[contains(.,'"+p0+"')]"));
            //fw.ExecuteJavascript(field);

        }

        [When(@"PDEDataMaanger page Files Menu ""(.*)"" option is Clicked")]
        public void WhenPDEDataMaangerPageFilesMenuOptionIsClicked(string p0)
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + p0 + "')]")));
            tmsWait.Hard(4);

            //switch (p0)
            //{
            //    case "DDPS File":
            //        fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[test-id='import-li-joblist']")));
            //        break;
            //    default:
            //        break;
            //}
        }

        [When(@"Files menu Raw Data Files submenu ""(.*)"" submenu is Clicked")]
        public void WhenFilesMenuRawDataFilesSubmenuSubmenuIsClicked(string p0)
        {
            IWebElement field = Browser.Wd.FindElement(By.XPath("//span[contains(.,'"+p0+"')]"));
            fw.ExecuteJavascript(field);

        }

        [Then(@"Verify PDEM App ""(.*)"" page is displayed")]
        public void ThenVerifyPDEMAppPageIsDisplayed(string p0)
        {
            tmsWait.Hard(4);
            IWebElement field = Browser.Wd.FindElement(By.XPath("//h1[contains(.,'"+p0+"')]"));
            Assert.IsTrue(field.Displayed, p0 + "is not getting dispalyed");

        
        }



        [Then(@"Verify Welcome to PDE Manager page Last File Loaded section displays File name ""(.*)""")]
        public void ThenVerifyWelcomeToPDEManagerPageLastFileLoadedSectionDisplaysFileName(string p0)
        {
            tmsWait.Hard(5);
            IWebElement field = Browser.Wd.FindElement(By.XPath("//label[@test-id='pdemDashboard-span-llfileLoadedFileName']"));
            Assert.IsTrue(field.Displayed, p0 + "is not getting displayed");
        }


        [When(@"PDEM Home page is Clicked")]
        public void WhenPDEMHomePageIsClicked()
        {
            IWebElement field = Browser.Wd.FindElement(By.XPath("//div[@title='Dashboard']"));
            fw.ExecuteJavascript(field);
        }


        [When(@"PDEDataMaanger page Files Menu Raw Data Files submenu ""(.*)"" submenu is Clicked")]
        public void WhenPDEDataMaangerPageFilesMenuRawDataFilesSubmenuSubmenuIsClicked(string p0)
        {
            IWebElement field = Browser.Wd.FindElement(By.XPath("//a/span[contains(.,'" + p0 + "')]"));
            fw.ExecuteJavascript(field);
        }

        [Then(@"Verify PDE Files Output List page displays ""(.*)"" files under File Name grid")]
        public void ThenVerifyPDEFilesOutputListPageDisplaysFilesUnderFileNameGrid(string p0)
        {
            tmsWait.Hard(10);
            string[] exp = p0.Split(',').ToArray();

            foreach(string temp in exp)
            {
                Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_MainContent_DataGridOutputFiles_ctl01']//tr[contains(.,'" + temp + "')]")).Displayed, temp + "is not displayed on File Name");
            }
            

        }


        [When(@"Export page Export Format ""(.*)"" option is Clicked")]
        public void WhenExportPageExportFormatOptionIsClicked(string p0)
        {
            IWebElement field = Browser.Wd.FindElement(By.XPath("//label[contains(.,'"+p0+"')]"));
            fw.ExecuteJavascript(field);
        }

        [When(@"Export page Error Type ""(.*)"" option is Clicked")]
        public void WhenExportPageErrorTypeOptionIsClicked(string p0)
        {
            IWebElement field = Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + p0 + "')]"));
            fw.ExecuteJavascript(field);
        }

        [When(@"Export page ""(.*)"" is set to ""(.*)""")]
        public void WhenExportPageIsSetTo(string p0, string value)
        {
            string id = "ctl00_MainContent_SearchFilterPanel1_" + p0;
            IWebElement field = Browser.Wd.FindElement(By.Id(id));
            SelectElement drp = new SelectElement(field);          
            tmsWait.Hard(2);
            drp.SelectByText(value);

        }


        [When(@"Export page ""(.*)"" button is Clicked")]
        public void WhenExportPageButtonIsClicked(string p0)
        {
            IWebElement field = Browser.Wd.FindElement(By.XPath("//input[@value='"+p0+"']"));
            fw.ExecuteJavascript(field);
            tmsWait.Hard(10);
        }

        [Then(@"Verify Export page displays ""(.*)"" Search results")]
        public void ThenVerifyExportPageDisplaysSearchResults(string exp)
        {
            string act = Browser.Wd.FindElements(By.XPath("//table[@id='ctl00_MainContent_SearchFilterPanel1_PagedDataGrid_ctl01']/tbody/tr")).Count.ToString();

            Assert.AreEqual(exp, act, exp + " records is not getting displayed");

            

           
        }


        [When(@"Export page ""(.*)"" link is Clicked")]
        public void WhenExportPageLinkIsClicked(string p0)
        {
            IWebElement field = Browser.Wd.FindElement(By.LinkText("file processing status page"));
            fw.ExecuteJavascript(field);
            tmsWait.Hard(20);
        }


        [Then(@"Verify PDE Audit History page ""(.*)"" field displayed")]
        public void ThenVerifyPDEAuditHistoryPageFieldDisplayed(string p0)
        {
            string id = "";

            switch (p0)
            {
                case "txtRxID":
                    id = "[test-id='auditHistory-txt-rxId']";
                    break;
                case "cboUser":
                    id = "[test-id='auditHistory-select-user']";
                    break;
                case "cboLoadFile":
                    id = "[test-id='auditHistory-select-file']";
                    break;
                case "SubmitterIDDropdown":
                    id = "[test-id='auditHistory-select-submitterId']";
                    break;
                case "cboTransType":
                    id = "[test-id='auditHistory-select-status']";
                    break;
                case "FeildDrpdwn":
                    id = "[test-id='auditHistory-select-field']";
                    break;
                case "cmdSearch":
                    id = "[test-id='auditHistory-btn-search']";
                    break;
                case "CmdReset":
                    id = "[test-id='auditHistory-btn-reset']";
                    break;
                case "FileId":
                    id = "[test-id='FileId']";
                    break;
     //Both of the following cases are necessary, as some page elements use the first version of capitalization and others use the second and the scripts consider them to be distinct
                case "PlanID":
                    id = "[test-id='PlanID']";
                    break;
                case "PlanId":
                    id = "[test-id='PlanId']";
                    break;
                case "UserID":
                    id = "[test-id='UserID']";
                    break;
                case "PBP":
                    id = "[test-id='PBP']";
                    break;
                case "PBPID":
                    id = "[test-id='PBPID']";
                    break;
                case "SubmitDate":
                    id = "[test-id='SubmitDate']";
                    break;
                case "ThroughDate":
                    id = "[test-id='ThroughDate']";
                    break;
                case "StartDate":
                    id = "[test-id='StartDate']";
                    break;
                case "EndDate":
                    id = "[test-id='EndDate']";
                    break;
                case "SubmitterID":
                    id = "[test-id='SubmitterID']";
                    break;
                case "SubmittedPlanID":
                    id = "[test-id='SubmittedPlanID']";
                    break;
                case "DOSYear":
                    id = "[test-id='DOSYear']";
                    break;
                case "P2PStatus":
                    id = "[test-id='P2PStatus']";
                    break;
                case "RxID":
                    id = "[test-id='RxID']";
                    break;
                case "Fileid":
                    id = "[test-id='Fileid']";
                    break;
                case "TransType":
                    id = "[test-id='TransType']";
                    break;
                case "Field":
                    id = "[test-id='Field']";
                    break;
                case "MBI":
                    id = "[test-id='HIC']";
                    break;
                case "Aging_ID":
                    id = "[test-id='Aging_ID']";
                    break;
                case "Statusid":
                    id = "[test-id='Statusid']";
                    break;
                case "Status":
                    id = "[test-id='Status']";
                    break;
                default:
                    break;
            }
            IWebElement field = Browser.Wd.FindElement(By.CssSelector(id));
            //IWebElement field = Browser.Wd.FindElement(By.Id(id));
            Assert.IsTrue(field.Displayed, p0 + " is not getting displayed");
        }


        [Then(@"Verify Welcome to PDE Manager page Year dropdown list is set to ""(.*)""")]
        public void ThenVerifyWelcomeToPDEManagerPageYearDropdownListIsSetTo(string expected)
        {
            IWebElement year = PDEM.WelcometoPDEManager.YearDropdownlist;

            string actual=year.Text;

            By Drp = By.XPath("//kendo-dropdownlist[@test-id='admin-select-defaultDosYear']//span[@class='k-input']");
            string actualValue = Browser.Wd.FindElement(Drp).Text;
            Assert.AreEqual(expected, actualValue, " Both values are not matching");

            Assert.AreEqual(expected, actual, expected + "is not getting displayed");
            tmsWait.Hard(10);
        }


        [When(@"I click on information icon and Verify message text ""(.*)""")]
        public void WhenIClickOnInformationIconAndVerifyMessageText(string p0)
        {

            By loc = By.XPath("//label[@test-id='admin-lbl-coderId']/i");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);

            IWebElement icon = PDEM.WelcometoPDEManager.InformationIconToolTip;
            string actual = icon.Text;
            Assert.IsTrue(actual.Contains(p0), p0 + "is not getting displayed");

            tmsWait.Hard(2);

        }


        [When(@"I information icon popup window Close button is clicked")]
        public void WhenIInformationIconPopupWindowCloseButtonIsClicked()
        {
            ReUsableFunctions.clickOnWebElement(PDEM.WelcometoPDEManager.InformationIconWindowCloseBtn);
            tmsWait.Hard(2);
        }




        [Then(@"Verify PDEM page ""(.*)"" drop down values matched with Database values")]
        public void ThenVerifyPDEMPageDropDownValuesMatchedWithDatabaseValues(string p0)
        {
            IList<IWebElement> webdrpValues;
            List<int> integerDBValues;
            List<string> resultantString;
            switch (p0)
            {
                case "DOSYear":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@aria-owns='ddlDefaultDosYear_listbox']/span")));
                    tmsWait.Hard(2);
                    webdrpValues = Browser.Wd.FindElements(By.XPath("//ul[@id='ddlDefaultDosYear_listbox']/li"));
                    tmsWait.Hard(2);
                    int listcount = webdrpValues.Count();
                    List<string> dosYearList = new List<string>();
                    for (int i = 0; i < listcount; i++)
                    {
                        string[] split_value = webdrpValues[i].Text.Split('-');
                        tmsWait.Hard(2);
                            dosYearList.Add(split_value[0].Trim());
                    }

                    integerDBValues = dbIntValues;
                    tmsWait.Hard(2);
                    resultantString = compareTwoList(dosYearList, integerDBValues);

                    if (resultantString.Count == 0)
                    {
                        Assert.IsTrue(true, " All values are matched");
                        break;
                    }
                    else
                    {
                        Assert.Fail(" DB values and Drop down values are not matching");
                    }
                    break;
            }
        }


        List<string> compareTwoList(List<string> drpValues, List<int> dbValues)
        {
            List<string> resultantList = new List<string>();
            List<string> stringdrpValues = new List<string>();
            foreach (int temp in dbValues)
            {
                stringdrpValues.Add(temp.ToString());
            }

            Console.WriteLine("Difference in the Drop Down List and DB value lists...");
            IEnumerable<string> list3;
            list3 = drpValues.Except(stringdrpValues);
            foreach (string value in list3)
            {
                resultantList.Add(value);
            }
            return resultantList;
        }

        [Then(@"Verify PDEM Message ""(.*)""")]
        public void ThenVerifyPdemMessage(string p0)
        {
            tmsWait.Hard(2);
            IWebElement toaster = Browser.Wd.FindElement(By.XPath("//div[@class='toast-message'][contains(.,'" + p0 + "')]"));
            Assert.IsTrue(toaster.Displayed, "Expected Toaster message is not getting displayed");

        }

        [When(@"PDE Manager Administration page Set Default DOS Year Filter tab ""(.*)"" is Clicked")]
        public void WhenPDEManagerAdministrationPageSetDefaultDOSYearFilterTabIsClicked(string button)
        {
           switch(button)
            {
                case "Set Year":
                    fw.ExecuteJavascript(PDEM.PDEManagerAdministration.SetYear);
                    break;
                case "Reset":
                    fw.ExecuteJavascript(PDEM.PDEManagerAdministration.Reset);
                    break;
                case "Home":
                    fw.ExecuteJavascript(PDEM.PDEManagerAdministration.Home);
                    break;
            }
        }

        [When(@"PDE Manager Administration page Set Default DOS Year Filter tab ""(.*)"" option is Clicked")]
        public void WhenPDEManagerAdministrationPageSetDefaultDOSYearFilterTabOptionIsClicked(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0);
            By plan = By.XPath("//kendo-dropdownlist[@test-id='admin-select-defaultDosYear']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + strValue + "']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(plan);
            tmsWait.Hard(1);
            //UIMODUtilFunctions.selectTransDrpValue(strValue);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

            //IWebElement tab = Browser.Wd.FindElement(By.XPath("//label[contains(.,'"+p0+"')]"));
            //fw.ExecuteJavascript(tab);

        }

        [When(@"I have navigated to link ""(.*)""")]
        public void WhenIHaveNavigatedToLink(string p0)
        {
            if((ConfigFile.EnvType.Equals("ESI")) && (p0.Equals("Administration")))
            {
                IWebElement tab = Browser.Wd.FindElement(By.CssSelector("[title='PDE Manager Administration']"));              
                fw.ExecuteJavascript(tab);
                tmsWait.Hard(2);
                
            }
            else if (p0.Equals("Administration"))
            {
                IWebElement tab = Browser.Wd.FindElement(By.CssSelector("[title='Administration']"));
                fw.ExecuteJavascript(tab);
                tmsWait.Hard(2);
            }

            else 
            { 
                IWebElement tab = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]"));
                fw.ExecuteJavascript(tab);
                tmsWait.Hard(2);
            }

        }

        [When(@"I have navigated to sub link ""(.*)""")]
        public void WhenIHaveNavigatedToSubLink(string p0)
        {
            if ((ConfigFile.EnvType.Equals("ESI")) && (p0.Equals("Administration")))
            {
                IWebElement tab = Browser.Wd.FindElement(By.CssSelector("[title='PDE Manager Administration']"));
                fw.ExecuteJavascript(tab);
                tmsWait.Hard(2);

            }
            else
            {
                IWebElement tab = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]"));
                //IWebElement tab = Browser.Wd.FindElement(By.LinkText(p0));
                fw.ExecuteJavascript(tab);
                tmsWait.Hard(2);

            }


        }

        [When(@"I click on load data link ""(.*)""")]
        public void WhenIClickOnLoadDataLink(string linktext)
        {
            IWebElement loadDatalink = Browser.Wd.FindElement(By.XPath(" //*[contains(text(), '"+linktext+"')]"));
            fw.ExecuteJavascript(loadDatalink);
        }


        [When(@"Current Workflow Status Values table ""(.*)"" is edited and set to ""(.*)""")]
        public void WhenCurrentWorkflowStatusValuesTableIsEditedAndSetTo(string p0, string p1)
        {
            string oldstatus = tmsCommon.GenerateData(p0);
            string newstatus = tmsCommon.GenerateData(p1);
            IWebElement tab = Browser.Wd.FindElement(By.XPath("//td[contains(.,'"+ oldstatus + "')]/following-sibling::td/button/span[@class='fas fa-pencil-alt']"));
            fw.ExecuteJavascript(tab); 

            tmsWait.Hard(5);
            PDEM.PDEManagerAdministration.EditWorkflowStatusTextbox.Clear();
            PDEM.PDEManagerAdministration.EditWorkflowStatusTextbox.SendKeys(newstatus);
            PDEM.PDEManagerAdministration.EditWorkflowStatusTextbox.SendKeys(Keys.Tab);
            tmsWait.Hard(2);
        }

        [Then(@"Verify Current Workflow Status Tab has Value ""(.*)""")]
        public void ThenVerifyCurrentWorkflowStatusTabHasValue(string p0)
        {
            string status = tmsCommon.GenerateData(p0);
            bool ispresent = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='admin-table-workflowStatus']//td[contains(.,'" + status + "')]")).Displayed;
            Assert.IsTrue(ispresent, "Workflow Status is not available");

        }


        [Then(@"Verify Current Workflow Status Tab Does Not have Value ""(.*)""")]
        public void ThenVerifyCurrentWorkflowStatusTabDoesNotHaveValue(string p0)
        {
            string status = tmsCommon.GenerateData(p0);
            
            By loc = By.XPath("//div[@test-id='admin-table-workflowStatus']//td[contains(.,'" + status + "')]");
            UIMODUtilFunctions.elementNotPresenceUsingLocators(loc);
        }


        [Then(@"Verify Loaded Files Search results table has below row")]
        public void ThenVerifyLoadedFilesSearchResultsTableHasBelowRow(Table table)
        {

            tmsWait.Hard(5);
            try
            {
                IWebElement objWebTable = PDEM.LoadedFiles.LoadedFilesSearchResultsTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Loaded Files Search results Table has row: {0}", e.Message);
            }
        }


        [Then(@"Verify Current Workflow Status Values Table has below row")]
        public void ThenVerifyCurrentWorkflowStatusValuesTableHasBelowRow(Table table)
        {
            tmsWait.Hard(5);
            try
            {
                IWebElement objWebTable = PDEM.PDEManagerAdministration.AddModifyNewWorkflowTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Current Workflow Status Values Table has row: {0}", e.Message);
            }

        }


        [Then(@"Verify PDE Submission Deadline Table has below row")]
        public void ThenVerifyPDESubmissionDeadlineTableHasBelowRow(Table table)
        {

            try
            {
                IWebElement objWebTable = PDEM.PDEManagerAdministration.PDESubmissionDeadlineTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("PDEM Manager Administration Table has row: {0}", e.Message);
            }
        }

        [When(@"PDEM Administration Workflow Status Tab Edit Icon is clicked for Existing status and Verify Message ""(.*)""")]
        public void WhenPDEMAdministrationWorkflowStatusTabEditIconIsClickedForExistingStatusAndVerifyMessage(string p0)
        {
            string expected_Message = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='admin-table-workflowStatus']//td[contains(.,'New')]/following-sibling::td/button/span[@class='fas fa-pencil-alt']")));
            tmsWait.Hard(2);
            string actual_Message = Browser.Wd.FindElement(By.ClassName("k-notification-content")).Text;
            Assert.IsTrue(actual_Message.Contains(expected_Message), "Expected Message is not displayed");
        }


        [When(@"Add Workflow Status tab Workflow Status Textbox is set to ""(.*)""")]
        public void WhenAddWorkflowStatusTabWorkflowStatusTextboxIsSetTo(string p0)
        {
            string status = tmsCommon.GenerateData(p0);
            PDEM.PDEManagerAdministration.AddWorkflowStatusTextbox.SendKeys(status);
        }

        [Then(@"Loaded Files page ""(.*)"" button is Clicked")]
        public void ThenLoadedFilesPageButtonIsClicked(string p0)
        {
            tmsWait.Hard(5);
            var button = Browser.Wd.FindElement(By.Id("btn" + p0 + ""));
            fw.ExecuteJavascript(button);
        }

        [Then(@"Verify Loaded Files Search results table displays ""(.*)"" records")]
        public void ThenVerifyLoadedFilesSearchResultsTableDisplaysRecords(string expectedcount)
        {
            tmsWait.Hard(5);
            int tablecount = Browser.Wd.FindElements(By.XPath("//table[@id='ctl00_MainContent_DataGridSubmitted_ctl01']/tbody//tr")).Count;
            Assert.AreEqual(expectedcount,tablecount.ToString(), "Expected count is not getting displayed");

        }

        [Then(@"Verify Loaded Files Search results table displays Nothing")]
        public void ThenVerifyLoadedFilesSearchResultsTableDisplaysNothing()
        {
            tmsWait.Hard(5);
            try
            {
                var element = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='loadedBatches-grid-loadedBatchesResult']")).Displayed;
                Assert.Fail("Search results table are getting displayed");
            }
            catch(NoSuchElementException e)
            {
                Assert.IsTrue(true, "Search results table are not getting displayed");
            }

            
        }


        [Then(@"Verify Loaded Files page ""(.*)"" button is displayed")]
        public void ThenVerifyLoadedFilesPageButtonIsDisplayed(string p0)
        {
            var button = Browser.Wd.FindElement(By.Id("btn" + p0)).Displayed;
            //var button = Browser.Wd.FindElement(By.XPath("//input[@value='"+p0+"']")).Displayed;
            Assert.IsTrue(button, p0 + "is not getting displayed");
            
        }

        [When(@"Loaded Files page ""(.*)"" is set to ""(.*)""")]
        public void WhenLoadedFilesPageIsSetTo(string field, string value)
        {
            string strValue = tmsCommon.GenerateData(value);
            By dropDown = null;

            switch (field)
            {
                case "Page Size":
                    dropDown = By.Id("ctl00_MainContent_cboPageSize");
                     //new SelectElement(PDEM.LoadedFiles.PageSize).SelectByText(value);                    
                    break;
                case "Plan ID":
                    dropDown = By.XPath("//kendo-dropdownlist[@test-id='batches-select-planId']//span[@class='k-select']");
                    //new SelectElement(PDEM.LoadedFiles.PlanID).SelectByText(value);
                    break;
                case "PBP":
                    dropDown = By.XPath("//kendo-dropdownlist[@test-id='batches-select-pbpIds']//span[@class='k-select']");
                    //new SelectElement(PDEM.LoadedFiles.PBP).SelectByText(value);
                    break;
                case "User ID":
                    dropDown = By.XPath("//kendo-dropdownlist[@test-id='batches-select-userIds']//span[@class='k-select']");
                    //new SelectElement(PDEM.LoadedFiles.UserID).SelectByText(value);                    
                    break;
                case "Submitter ID":
                    dropDown = By.XPath("//kendo-dropdownlist[@test-id='batches-select-submitterId']//span[@class='k-select']");
                    //new SelectElement(PDEM.LoadedFiles.Submitter).SelectByText(value);                  
                    break;
            }
            By typeapp = By.XPath("//li[text()='" + strValue + "']");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(dropDown);
            tmsWait.Hard(1);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
        }


        [Then(@"Verify Loaded Files page ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyLoadedFilesPageIsSetTo(string field, string expected)
        {
            string actual=null;
          switch(field)
            {
                case "Page Size":
                    actual=new SelectElement(PDEM.LoadedFiles.PageSize).SelectedOption.Text;
                    Assert.AreEqual(actual, expected, expected + "is not geting displayed");
                        break;
                case "Plan ID":
                    actual = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='batches-select-planId']//span[@class='k-input']")).Text;
                    break;
                case "PBP":
                    actual = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='batches-select-pbpIds']//span[@class='k-input']")).Text;
                    break;
                case "User ID":
                    actual = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='batches-select-userIds']//span[@class='k-input']")).Text;
                    break;
                case "Submitter ID":
                    actual = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='batches-select-submitterId']//span[@class='k-input']")).Text;
                    break;
            }
            Assert.AreEqual(expected, actual, " Both values are not matching");
        }



        [Then(@"Verify PDEM Batches page ""(.*)"" label or field is displayed")]
        public void ThenVerifyPDEMBatchesPageLabelOrFieldIsDisplayed(string p0)
        {
            string fieldLabel = tmsCommon.GenerateData(p0);
            bool ispresent = false;
            try
            {

                switch (fieldLabel.ToLower())
                {

                    case "loaded tab": ispresent = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Loaded')]")).Displayed; break;
                    case "submitted tab": ispresent = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Submitted')]")).Displayed; break;
                    case "search by": ispresent = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Search By')]")).Displayed; break;
                    case "reset button": ispresent = Browser.Wd.FindElement(By.XPath("//button[@test-id='batches-button-resetSearch']")).Displayed; break;
                    case "search button": ispresent = Browser.Wd.FindElement(By.XPath("//button[@test-id='batches-button-search']")).Displayed; break;
                }
            }
            catch { }

            Assert.IsTrue(ispresent, "Field or label is not displayed");
        }


        [When(@"PDEM Batches page ""(.*)"" is set to ""(.*)""")]
        public void WhenPDEMBatchesPageIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            By ele = null;  //Browser.Wd.FindElement(By.XPath(""));

            switch (field.ToLower())
            {
                case "plan id":  ele = By.XPath("//kendo-dropdownlist[@test-id='batches-select-planId']//span[@class='k-select']");
                                 break;
                case "pbp id":  ele = By.XPath("//kendo-dropdownlist[@test-id='batches-select-pbpIds']//span[@class='k-select']");
                                 break;
                case "user id":  ele = By.XPath("//kendo-dropdownlist[@test-id='batches-select-userIds']//span[@class='k-select']");
                                 break;
                case "submitter id":  ele = By.XPath("//kendo-dropdownlist[@test-id='batches-select-submitterId']//span[@class='k-select']");
                                 break;
            }
            By typeapp = By.XPath("//li[text()='" + value + "']");


            if (value!="firstvalue")
            {
                UIMODUtilFunctions.clickOnWebElementUsingLocators(ele);
                tmsWait.Hard(1);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
            }
            //The code below for choosing the first option needs to be addressed at a later time. Until then just specify a value

            //else
            //{
            //    fw.ExecuteJavascript(ele);
            //    if(field.ToLower()=="plan id")
            //    {
            //        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//ul[@id='planIds_listbox']/li[2])[1]")));
            //    }

            //    if(field.ToLower()=="pbp id")
            //    {
            //        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//ul[@id='pbpIds_listbox']/li[2])[1]")));
            //    }

            //    if (field.ToLower() == "user id")
            //    {
            //        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//ul[@id='userIds_listbox']/li[2])[1]")));
            //    }

            //    if (field.ToLower() == "submitter id")
            //    {
            //        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//ul[@id='submitterIds_listbox']/li[2])[1]")));
            //    }
            //}


            tmsWait.Hard(3);
        }



        [Then(@"Verify PDEM Batches page ""(.*)"" displayed with selected value ""(.*)""")]
        public void ThenVerifyPDEMBatchesPageDisplayedWithSelectedValue(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string expectedvalue = tmsCommon.GenerateData(p1);
            string actualvalue = "";
            switch(field.ToLower())
            {
                case "plan id": actualvalue = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='batches-select-planId']//span[@class='k-input']")).Text; break;
                case "pbp id": actualvalue = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='batches-select-pbpIds']//span[@class='k-input']")).Text;  break;
                case "user id": actualvalue = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='batches-select-userIds']//span[@class='k-input']")).Text;  break;
                case "submitter id": actualvalue = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='batches-select-submitterId']//span[@class='k-input']")).Text; break;
            }

            Assert.AreEqual(expectedvalue, actualvalue, "Selected Values is not similar to expected value");
        }


        [Then(@"Verify PDEM Batches page ""(.*)"" values matches with ""(.*)""")]
        public void ThenVerifyPDEMBatchesPageValuesMatchesWith(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string expectedvalue = tmsCommon.GenerateData(p1);
            string actualvalue = "";
            switch (field.ToLower())
            {
                case "plan id": fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@aria-owns='planIds_listbox']/span")));
                      IWebElement planiddd = Browser.Wd.FindElement(By.XPath("//ul[@id='planIds_listbox']"));
                      IReadOnlyCollection<IWebElement> TotalPlans = planiddd.FindElements(By.TagName("li"));
                      int totalplancount = TotalPlans.Count()-1;
                      actualvalue = totalplancount.ToString();
                    break;
                case "pbp id": fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@aria-owns='pbpIds_listbox']/span")));
                    IWebElement pbpidd = Browser.Wd.FindElement(By.XPath("//ul[@id='pbpIds_listbox']"));
                    IReadOnlyCollection<IWebElement> Totalpbp = pbpidd.FindElements(By.TagName("li"));
                    int totalpbpcount = Totalpbp.Count() - 1;
                    actualvalue = totalpbpcount.ToString();
                    break;
                case "user id":fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@aria-owns='userIds_listbox']/span")));
                     IWebElement useridd = Browser.Wd.FindElement(By.XPath("//ul[@id='userIds_listbox']"));
                     IReadOnlyCollection<IWebElement> Totaluser = useridd.FindElements(By.TagName("li"));
                     int totalusercount = Totaluser.Count() - 1;
                     actualvalue = totalusercount.ToString();
                     break;
                case "submitter id": fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@aria-owns='submitterIds_listbox']/span")));
                                     IWebElement submitterid = Browser.Wd.FindElement(By.XPath("//ul[@id='submitterIds_listbox']"));
                                     IReadOnlyCollection<IWebElement> Totalsubmitter = submitterid.FindElements(By.TagName("li"));
                                     int totalsubmittercount = Totalsubmitter.Count() - 1;
                                     actualvalue = totalsubmittercount.ToString();
                    break;
            }

            Assert.AreEqual(expectedvalue, actualvalue, "Total " + field + " are not matching with databse values");
        }

        [When(@"PDEM Batches page ""(.*)"" Button is clicked")]
        public void WhenPDEMBatchesPageButtonIsClicked(string p0)
        {
            string field = tmsCommon.GenerateData(p0);
            switch(field.ToLower())
            {
                case "reset": fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='batches-button-resetSearch']"))); break;
                case "search": fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='batches-button-search']"))); break;
            }
        }

        [When(@"PDEM Batches page ""(.*)"" Button is clicked and Verify Message ""(.*)""")]
        public void WhenPDEMBatchesPageButtonIsClickedAndVerifyMessage(string p0, string p1)
        {
            string expectedMessage = tmsCommon.GenerateData(p1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='batches-button-search']")));
            tmsWait.Hard(1);
            By toastMsg = By.XPath("//div[@class='k-notification-content']");
            string actualMessage = Browser.Wd.FindElement(toastMsg).Text;
            Assert.IsTrue(actualMessage.Contains(expectedMessage), "Expected Message is not displayed");

        }


        [Then(@"Verify PDEM Batches page Search Result Grid is displayed")]
        public void ThenVerifyPDEMBatchesPageSearchResultGridIsDisplayed()
        {
            tmsWait.Hard(2);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='loadedBatches-grid-loadedBatchesResult']")).Displayed, "Search Result Grid is not displayed Please check your search parameter");
        }

        [When(@"PDEM Batches page get the total number of records on the result grid and assigned to variable ""(.*)""")]
        public void WhenPDEMBatchesPageGetTheTotalNumberOfRecordsOnTheResultGridAndAssignedToVariable(string p0)
        {
            string trecords = Browser.Wd.FindElement(By.XPath("//kendo-pager-info[@class='k-pager-info k-label ng-star-inserted']")).Text;
            string[] totalRecords = trecords.Split(' ');
            fw.setVariable(p0, totalRecords[4]);

        }

       

        [When(@"P(.*)P AR Managetment page get the total number of records on the result grid and assigned to variable ""(.*)""")]
        public void WhenPPARManagetmentPageGetTheTotalNumberOfRecordsOnTheResultGridAndAssignedToVariable(int p0, string p1)
        {
            string trecords = Browser.Wd.FindElement(By.XPath("//kendo-pager-info[@class='k-pager-info k-label']")).Text;
            string[] totalRecords = trecords.Split(' ');
            fw.setVariable(p1, totalRecords[4]);
        }


        [Then(@"Verify PDEM Batches page ""(.*)"" are same as ""(.*)""")]
        public void ThenVerifyPDEMBatchesPageAreSameAs(string p0, string p1)
        {
            string trecords_UI = tmsCommon.GenerateData(p0);
            string trecords_DB = tmsCommon.GenerateData(p1);
            Assert.AreEqual(trecords_UI, trecords_DB, "Results displayed on database and UI are same");
        }



        [Then(@"Verify ""(.*)"" page is getting displayed")]
        public void ThenVerifyPageIsGettingDisplayed(string p0)
        {
            var page = Browser.Wd.FindElement(By.XPath("//h1[contains(.,'"+p0+"')]")).Displayed;
            Assert.IsTrue(page, p0 + "is not getting displayed");
        }


        [When(@"Add Workflow Status tab ""(.*)"" button is Clicked")]
        public void WhenAddWorkflowStatusTabButtonIsClicked(string p0)
        {
            IWebElement tab = null;
            tmsWait.Hard(15);
            switch (p0)
            {
                case "Add/Modify New Workflow Status":
                case "Add":
                    tab = Browser.Wd.FindElement(By.CssSelector("[test-id='admin-btn-save']"));
                    fw.ExecuteJavascript(tab);
                    break;
                case "Save":
                    IWebElement saveicon = Browser.Wd.FindElement(By.XPath("//input[@name='workStatusDescription']/parent::td/following-sibling::td//span[@class='fas fa-save']"));
                    fw.ExecuteJavascript(saveicon);
                    tmsWait.Hard(5);
                    break;
                case "Cancel":
                    IWebElement cancelicon = Browser.Wd.FindElement(By.XPath("//input[@name='workStatusDescription']/parent::td/following-sibling::td//span[@class='fas fa-ban']"));
                    fw.ExecuteJavascript(cancelicon);
                    tmsWait.Hard(1);
                    break;
                case "Update":
                    IWebElement Updateicon = Browser.Wd.FindElement(By.XPath("//input[@name='workStatusDescription']/parent::td/following-sibling::td/a[2]"));
                    fw.ExecuteJavascript(Updateicon);
                    tmsWait.Hard(1);
                    break;
                default:
                    break;
            }
            //IWebElement tab = Browser.Wd.FindElement(By.XPath("//input[@value='"+p0+"']"));
            try
            {
                UIMODUtilFunctions.clickOnConfirmationYesDialog();
                tmsWait.Hard(3);
            }
            catch
            {
                tmsWait.Hard(3);
            }
        }


        [When(@"Add Workflow Status tab ""(.*)"" button is Clicked and Verify Message ""(.*)""")]
        public void WhenAddWorkflowStatusTabButtonIsClickedAndVerifyMessage(string p0, string p1)
        {
            string expected_Message = tmsCommon.GenerateData(p1);
            IWebElement tab = Browser.Wd.FindElement(By.CssSelector("[test-id='admin-btn-save']"));
            fw.ExecuteJavascript(tab);
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnConfirmationYesDialog();
            tmsWait.Hard(1);
            string actual_Message = Browser.Wd.FindElement(By.ClassName("k-notification-content")).Text;
            
            Assert.AreEqual(expected_Message, actual_Message, "Expected Message is not displayed");
        }

        [When(@"Add Workflow Status tab ""(.*)"" button is Clicked and Confirmation Dialog No is Clicked")]
        public void WhenAddWorkflowStatusTabButtonIsClickedAndConfirmationDialogNoIsClicked(string p0)
        {
            IWebElement tab = Browser.Wd.FindElement(By.CssSelector("[test-id='admin-btn-addWorkflowStatus']"));
            fw.ExecuteJavascript(tab);
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnConfirmationNoOrCancelDialog();
            tmsWait.Hard(1);
        }

        [Then(@"Verify Add Workflow Validation Message ""(.*)""")]
        public void ThenVerifyAddWorkflowValidationMessage(string p0)
        {
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[@id='txtxtWorkflowStatusMbi-error-msg']")).Displayed, "Expected validation message is not displayed");
        }


        [When(@"PDE Data Manager Application page I Clicked ""(.*)"" menu")]
        public void WhenPDEDataManagerApplicationPageIClickedMenu(string p0)
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]")));
            tmsWait.Hard(5);

            //var element = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]"));
            //fw.ExecuteJavascript(element);
        }

        [When(@"PDE Data Manager Application page I Clicked ""(.*)"" tab")]
        public void WhenPDEDataManagerApplicationPageIClickedTab(string p0)
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]")));
            tmsWait.Hard(5);

            //var element = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]"));
            //fw.ExecuteJavascript(element);
        }

        [When(@"PDE Data Manager Application page I Moved ""(.*)"" menu ""(.*)"" submenu ""(.*)"" submenu")]
        public void WhenPDEDataManagerApplicationPageIMovedMenuSubmenuSubmenu(string p0, string p1, string p2)
        {
                   
            var element1 = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]"));
            var element2 = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p1 + "')]"));
            var element3 = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p2 + "')]"));
            Actions action = new Actions(Browser.Wd);
            tmsWait.Hard(5);
            action.MoveToElement(element1).MoveToElement(element2).MoveToElement(element3).Build().Perform();
        }


        [When(@"PDE Data Manager Application page I Moved ""(.*)"" menu")]
        public void WhenPDEDataManagerApplicationPageIMovedMenu(string p0)
        {
          

        tmsWait.Hard(5);
            WebDriverWait wait = new WebDriverWait(Browser.Wd, TimeSpan.FromSeconds(10));
            var element = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("//span[contains(.,'"+p0+"')]")));
            Actions action = new Actions(Browser.Wd);
            tmsWait.Hard(5);
            action.MoveToElement(element).Build().Perform();
        }


        [Then(@"Verify Add Workflow Status tab displays Static message as ""(.*)""")]
        public void ThenVerifyAddWorkflowStatusTabDisplaysStaticMessageAs(string expected)
        {
            tmsWait.Hard(3);
            Assert.AreEqual(PDEM.PDEManagerAdministration.AddWorkflowStatusLabel.Text, expected, expected + "is not getting displayed");
        }

        [Then(@"Verify Add Workflow Status Textbox is set to ""(.*)""")]
        public void ThenVerifyAddWorkflowStatusTextboxIsSetTo(string expected)
        {
            tmsWait.Hard(3);
            Assert.AreEqual(PDEM.PDEManagerAdministration.AddWorkflowStatusTextbox.Text, expected,"Text box is getting displayed with some values");
        }

        [Then(@"Verify Add Workflow Status tab displays message as ""(.*)""")]
        public void ThenVerifyAddWorkflowStatusTabDisplaysMessageAs(string expected)
        {
            tmsWait.Hard(3);
            Assert.AreEqual(PDEM.PDEManagerAdministration.AddWorkflowStatusStaticMessage.Text, expected, expected + "is not getting displayed");
        }
        

        [When(@"PDE Manager Administration page ""(.*)"" tab is clicked")]
        public void WhenPDEManagerAdministrationPageTabIsClicked(string p0)
        {

            IWebElement loc = Browser.Wd.FindElement(By.XPath("(//div[contains(.,'PDE Manager Administration')])[3]"));
            fw.ExecuteJavascript(loc);
            tmsWait.Hard(2);

            switch (p0)
            {
                case "Add Workflow Status":
                    IWebElement tab = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Add Workflow Status')]"));
                    fw.ExecuteJavascript(tab);
                    tmsWait.Hard(4);
                    break;
                case "Edit Cut-Off Dates":
                    IWebElement tab1 = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Edit Cut-Off Dates')]"));
                    fw.ExecuteJavascript(tab1);
                    tmsWait.Hard(4);
                    break;
                case "Set Default DOS Year Filter":
                    IWebElement tab2 = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Set Default DOS Year Filter')]"));
                    fw.ExecuteJavascript(tab2);
                    tmsWait.Hard(4);
                    break;
                case "PDE Settings":
                    IWebElement tab3 = Browser.Wd.FindElement(By.XPath("//span[contains(.,'PDE Settings')]"));
                    fw.ExecuteJavascript(tab3);
                    tmsWait.Hard(4);
                    break;
                default:
                    break;
            }
        }

        [Then(@"PDEM Administration ""(.*)"" Tab is displayed")]
        public void ThenPDEMAdministrationTabIsDisplayed(string p0)
        {
            string expected_Tab = tmsCommon.GenerateData(p0);
            bool ispresent = false;
            /* Angular changes standardized tabs around text, new code to handle ispresent below
            switch(expected_Tab.ToLower())
            {
                case "edit cutoff dates": ispresent = Browser.Wd.FindElement(By.XPath("//span[@test-id='configurationTab-tab-EditCutOffDates']")).Displayed; break;
                case "add workflow status": ispresent = Browser.Wd.FindElement(By.XPath("//span[@test-id='configurationTab-tab-addStatus']")).Displayed; break;
                case "set default dos year filter": ispresent= Browser.Wd.FindElement(By.XPath("//span[@test-id='configurationTab-tab-setDefaultDosYearFilter']")).Displayed; break;
                case "pde settings": ispresent = Browser.Wd.FindElement(By.XPath("//span[@test-id='configurationTab-tab-pdeSettings']")).Displayed; break;
            }*/

            ispresent = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + expected_Tab + "')]")).Displayed;

            Assert.IsTrue(ispresent, "Expected Tab under administration is not displayed");
        }


        [Then(@"Verify PDE Manager Administration page displays message as ""(.*)""")]
        public void ThenVerifyPDEManagerAdministrationPageDisplaysMessageAs(string expected)
        {

            string actual = PDEM.PDEManagerAdministration.SetDefaultDOSYearFilterLabel.Text;
            Assert.AreEqual(expected, actual, expected + "is not getting displayed");
        }

        [When(@"Edit Cut Off Dates tab PDE Submission Deadline table DOS Year ""(.*)"" is Edited")]
        public void WhenEditCutOffDatesTabPDESubmissionDeadlineTableDOSYearIsEdited(string p0)
        {
            tmsWait.Hard(5);

            IWebElement editicon = Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + p0 + "')]/following-sibling::td[2]/button[1]"));
            ReUsableFunctions.clickOnWebElement(editicon);

            //IWebElement edit = Browser.Wd.FindElement(By.XPath("//span[contains(.,'"+p0+"')]/parent::td/preceding-sibling::td/input"));
            //fw.ExecuteJavascript(edit);
            tmsWait.Hard(5);
        }

        [When(@"PDE Submission Deadline is set to ""(.*)""")]
        public void WhenPDESubmissionDeadlineIsSetTo(string p0)
        {
            string deadline = tmsCommon.GenerateData(p0);

            tmsWait.Hard(2);
            //PDEM.PDEManagerAdministration.EditCutOffDatesPDESubmissionDeadlineTxtbox.Clear();
            //PDEM.PDEManagerAdministration.EditCutOffDatesPDESubmissionDeadlineTxtbox.SendKeys(p0);
            string value = deadline.Replace("/", "");
            By Drp = By.XPath("//kendo-datepicker[@id='txtsubmissionDeadline']//span//input");
            Browser.Wd.FindElement(Drp).Clear();
            Browser.Wd.FindElement(Drp).SendKeys(value);

            tmsWait.Hard(3);

        }

        [When(@"PDE Manager Administration page ""(.*)"" button is Clicked")]
        public void WhenPDEManagerAdministrationPageButtonIsClicked(string p0)
        {
            string field = tmsCommon.GenerateData(p0);

            tmsWait.Hard(2);
            switch (field)
            {
                case "Save":
                    IWebElement saveicon = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@id='txtsubmissionDeadline']/parent::td/following-sibling::td/button[2]"));
                    ReUsableFunctions.clickOnWebElement(saveicon);
                    tmsWait.Hard(1);
                    break;
                case "Cancel":
                    IWebElement cancelicon = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@id='txtsubmissionDeadline']/parent::td/following-sibling::td/button[3]"));
                    ReUsableFunctions.clickOnWebElement(cancelicon);
                    tmsWait.Hard(1);
                    break;
            }

            //IWebElement edit = Browser.Wd.FindElement(By.XPath("//input[@value='"+p0+"']"));
            //fw.ExecuteJavascript(edit);

        }

        [When(@"Verify PDE Manager Administration page displays message as ""(.*)""")]
        public void WhenVerifyPDEManagerAdministrationPageDisplaysMessageAs(string expected)
        {
            tmsWait.Hard(5);
            Assert.AreEqual(PDEM.PDEManagerAdministration.SuccessMessage.Text, expected, expected + "is not getting displayed");
        }


        [Then(@"Verify PDE Manager Administration page Edit Cut Off Dates tab displays message as ""(.*)""")]
        public void ThenVerifyPDEManagerAdministrationPageEditCutOffDatesTabDisplaysMessageAs(string expected)
        {
            if (expected.Contains("Click the icon"))
            {
                Assert.AreEqual(PDEM.PDEManagerAdministration.EditCutOffDatesLabel1.Text, expected, expected + "is not getting displayed");
            }
            else if(expected.Contains("Edit the date"))
            {
                Assert.AreEqual(PDEM.PDEManagerAdministration.EditCutOffDatesLabel2.Text, expected, expected + "is not getting displayed");
            }
        }

        [Then(@"Verify DOS Year Text box is disabled")]
        public void ThenVerifyDOSYearTextBoxIsDisabled()
        {
            Assert.IsFalse(PDEM.PDEManagerAdministration.DOSYear.Enabled, "Text box is Enabled");
        }


        [Then(@"Verify PDE Manager Administration page displays ""(.*)"" button")]
        public void ThenVerifyPDEManagerAdministrationPageDisplaysButton(string p0)
        {
            bool display = false;
            switch(p0)
            {
                case "Set Year":
                    display = PDEM.PDEManagerAdministration.SetYear.Displayed;
                    Assert.IsTrue(display, p0 + "is not displayed");
                    break;
                case "Reset":
                    display = PDEM.PDEManagerAdministration.Reset.Displayed;
                    Assert.IsTrue(display, p0 + "is not displayed");
                    break;
            }
        }

        [Then(@"Verify PDEM Edit Cut-Off Dates result grid row with DOS Year ""(.*)"" and PDE Submission Deadline ""(.*)"" is displayed")]
        public void ThenVerifyPDEMEditCutOffDatesResultGridRowWithDOSYearandPDESubmissionDeadlineIsDisplayed(string p0, string p1)
        {
            string dosYear = tmsCommon.GenerateData(p0);
            string deadline = tmsCommon.GenerateData(p1);
            bool hasrow = false;
            //int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
            //for (int i = 1; i <= totalPagesIntheGrid; i++)
            do
            {
                try
                {

                    hasrow = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='admin-grid-grdCutOffDates']//td[contains(.,'" + dosYear + "')]/following-sibling::td[contains(.,'" + deadline + "')]")).Displayed;
                    break;
                }
                catch
                {
                    if (Browser.Wd.FindElement(By.XPath("//a[@class='k-link k-pager-nav k-state-disabled k-pager-last']")).Displayed)
                    { //break loop if we've reached the last page
                        break;
                    }
                    else
                    {
                        IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//span[@aria-label='Go to the next page']"));
                        ReUsableFunctions.clickOnWebElement(nextpage);
                    }
                }

            } while (!hasrow);
            Assert.IsTrue(hasrow, "There is no such row Present");
        }

        [Then(@"Verify PDEM Edit Cut-Off Dates table is displayed")]
        public void ThenVerifyPDEMEditCutOffDatesTableIsDisplayed()
        {
            string testId = "[test-id='admin-grid-grdCutOffDates']";

            IWebElement element = Browser.Wd.FindElement(By.CssSelector(testId));
            //IWebElement element = Browser.Wd.FindElement(By.XPath("//div[@id='ModuleHeader']//h1[contains(.,'"+p0+"')]"));
            Assert.IsTrue(element.Displayed, "PDEM Edit Cut-off Dates table is not getting displayed");
        }

        [Then(@"Verify PDEM Add Workflow Status result grid row with Workflow Status ""(.*)"" is displayed")]
        public void ThenVerifyPDEMEAddWorkflowStatusResultGridRowWithWorkflowStatusIsDisplayed(string p0)
        {
            string workflowStatus = tmsCommon.GenerateData(p0);
            bool hasrow = false;
            hasrow = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='admin-table-workflowStatus']//td[contains(.,'" + workflowStatus + "')]")).Displayed;
            
            Assert.IsTrue(hasrow, "There is no such row Present");
        }

        [Then(@"Verify PDEM Batches Loaded result grid row with Client File ""(.*)"" and Plan ID ""(.*)"" and PBP ""(.*)"" and Type ""(.*)"" is displayed")]
        public void ThenVerifyPDEMBatchesLaodedResultGridRowIsDisplayed(string p0, string p1, string p2, string p3)
        {
            string clientFile = tmsCommon.GenerateData(p0);
            string planID = tmsCommon.GenerateData(p1);
            string pbp = tmsCommon.GenerateData(p2);
            string type = tmsCommon.GenerateData(p3);
            string totalPage = Browser.Wd.FindElement(By.XPath("//kendo-numerictextbox[@class='k-widget k-numerictextbox']/span[@class='k-numeric-wrap']/input")).GetAttribute("aria-valuemax");
            bool hasrow = false;

            IReadOnlyCollection<IWebElement> webElementList = Browser.Wd.FindElements(By.XPath("//kendo-grid-list[@class='k-grid-container ng-star-inserted']//table[@class='k-grid-table']/tbody/tr"));


            int i = 1;
            while (i <= Int32.Parse(totalPage)) {
                for (int k = 1; k <= webElementList.Count; k++)
                {
                    string fieldClientFile = Browser.Wd.FindElement(By.XPath("//kendo-grid-list[@class='k-grid-container ng-star-inserted']//table[@class='k-grid-table']/tbody/tr[" + k + "]/td[2]/div/p")).Text;
                    string fieldPlanID = Browser.Wd.FindElement(By.XPath("//kendo-grid-list[@class='k-grid-container ng-star-inserted']//table[@class='k-grid-table']/tbody/tr[" + k + "]/td[4]")).Text;
                    string fieldPBPID = Browser.Wd.FindElement(By.XPath("//kendo-grid-list[@class='k-grid-container ng-star-inserted']//table[@class='k-grid-table']/tbody/tr[" + k + "]/td[5]")).Text;
                    string fieldType = Browser.Wd.FindElement(By.XPath("//kendo-grid-list[@class='k-grid-container ng-star-inserted']//table[@class='k-grid-table']/tbody/tr[1]/td[14]/div/p")).Text;

                    if (fieldClientFile.Equals(p0) && fieldPlanID.Equals(p1) && fieldPBPID.Equals(p2) && fieldType.Equals(p3))
                    {
                        hasrow = true;
                        Assert.IsTrue(true, "the required element not displayed");
                        break;

                    }
                }

                if (hasrow == false)
                {

                    i++;
                    Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']/span")).Click();
                    tmsWait.Hard(5);

                }
                else { break; }
                
                
                }



            }

            //int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
            //for (int i = 1; i <= totalPagesIntheGrid; i++)
            //{
                //try
                /*{
                    hasrow = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='loadedBatches-grid-loadedBatchesResult']//tr//td[contains(.,'" + clientFile + "')]/following-sibling::td[contains(.,'" + planID + "')]/following-sibling::td[contains(.,'" + pbp + "')]/following-sibling::td[contains(.,'" + type + "')]")).Displayed;                    
                    //break;
                }
                catch
                {

                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);
                }*/

            //}



        [Then(@"verify Edit CutOff Dates Result Grid with Coulmn ""(.*)"" ""(.*)"" and ""(.*)"" is displayed")]
        public void ThenVerifyEditCutOffDatesResultGridWithCoulmnAndIsDisplayed(string p0, string p1, string p2)
        {
            string column_dos = tmsCommon.GenerateData(p0);
            string coulmn_pde_sub_date = tmsCommon.GenerateData(p1);
            string column_edit = tmsCommon.GenerateData(p2);
            bool ispresent = false;

            try
            {
                ispresent = Browser.Wd.FindElement(By.XPath("//div[@id='frmEditCutOffDates']//th[contains(.,'DOS Year')]/following-sibling::th[contains(.,'PDE Submission Deadline')]/following-sibling::th[contains(.,'Edit')]")).Displayed;
            }

            catch
            {

            }

            Assert.IsTrue(ispresent, "Expected Columns are not displayed");
        }


        [Then(@"Verify Edit CutOff Dates DOS Year has Current Year plus one is displayed")]
        public void ThenVerifyEditCutOffDatesDOSYearHasCurrentYearPlusOneIsDisplayed()
        {
            int current_year= DateTime.Now.Year;
            int expected_dos = current_year + 1;
            bool ispresent = false;
            string totalPage = Browser.Wd.FindElement(By.XPath("//kendo-numerictextbox[@class='k-widget k-numerictextbox']/span/input")).GetAttribute("aria-valuemax");
            int i = 1;
            try
            {
                while (i <= Int32.Parse(totalPage))
                {

                    IReadOnlyCollection<IWebElement> listElement = Browser.Wd.FindElements(By.XPath("//kendo-grid-list[@class='k-grid-container ng-star-inserted']//table[@class='k-grid-table']/tbody/tr"));
                    for (int k = 1; k <= listElement.Count; k++)
                    {
                        string actualyear = Browser.Wd.FindElement(By.XPath("//kendo-grid-list[@class='k-grid-container ng-star-inserted']//table[@class='k-grid-table']/tbody/tr[" + k + "]/td[1]")).Text;

                        if (actualyear.Equals(expected_dos.ToString()))
                        {
                            ispresent = true;
                            break;

                        }

                    }
                    if (ispresent) { break; }
                    else
                    {

                        i++;
                        Browser.Wd.FindElement(By.XPath("//kendo-pager-next-buttons[@class='ng-star-inserted']/a/span")).Click();
                        tmsWait.Hard(3);

                    }

                }


                Browser.Wd.FindElement(By.XPath("//kendo-pager-prev-buttons[@class='ng-star-inserted']/a[@title='Go to the first page']/span")).Click();
                tmsWait.Hard(3);
            }

            catch
            {

            }

            /*try
            {
                ispresent = Browser.Wd.FindElement(By.XPath("//div[@id='frmEditCutOffDates']//td[contains(.,'" + expected_dos + "')]")).Displayed;
            }

            */

            Assert.IsTrue(ispresent, "Current year plus one year is not display in the result grid");

        }



        [Then(@"Verify Edit CutOff Dates PDE Submission deadline is Editable")]
        public void ThenVerifyEditCutOffDatesPDESubmissionDeadlineIsEditable()
        {
            int current_year = DateTime.Now.Year;

            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + current_year + "')]/following-sibling::td/button[1]")));
            tmsWait.Hard(2);
            bool iseditable = false;
            try
            {
                iseditable = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@id='txtsubmissionDeadline']")).Displayed;
            }

            catch
            {

            }

            Assert.IsTrue(iseditable, "PDE Submission Date field is editable");
            IWebElement Cancel_Icon = Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + current_year + "')]/following-sibling::td/button[3]"));
            fw.ExecuteJavascript(Cancel_Icon);
            tmsWait.Hard(3);

        }




        [Then(@"Verify Edit CutOff Dates Error Message ""(.*)"" When enters Invalid Date")]
        public void ThenVerifyEditCutOffDatesErrorMessageWhenEntersInvalidDate(string p0)
        {
            string expected_Msg = tmsCommon.GenerateData(p0);
            int current_year = DateTime.Now.Year;
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + current_year + "')]/following-sibling::td/a[1]")));
            tmsWait.Hard(2);
            //IWebElement pde_date = Browser.Wd.FindElement(By.XPath("//input[@type='text']"));
            //pde_date.Clear();
            //pde_date.SendKeys("invalid");

            string value = "12";
            By Drp = By.XPath("//kendo-datepicker[@id='txtsubmissionDeadline']//span//input");
            Browser.Wd.FindElement(Drp).Clear();
            //Browser.Wd.FindElement(Drp).SendKeys(Keys.Delete);
            
            IWebElement Update_Icon = Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + current_year + "')]/following-sibling::td/a[2]"));
            //fw.ExecuteJavascript(Update_Icon);
            Update_Icon.Click();
            //string actualMsg = Browser.Wd.FindElement(By.XPath("//div[@class='toast-message']")).GetAttribute("aria-label");
            string actualMsg = Browser.Wd.FindElement(By.XPath("//span[@id='txtsubmissionDeadline-error-msg']")).Text;

            fw.ConsoleReport(actualMsg);
            Assert.AreEqual(expected_Msg, actualMsg, " Both message are not matching");

            IWebElement Cancel_Icon = Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + current_year + "')]/following-sibling::td/a[3]"));
            fw.ExecuteJavascript(Cancel_Icon);
            tmsWait.Hard(2);
        }





        [When(@"Edit CutOff Dates Modify PDE Submission Date as ""(.*)"" for DOS ""(.*)""")]
        public void WhenEditCutOffDatesModifyPDESubmissionDateAsForDOS(string p0, string p1)
        {
            string pde_date = tmsCommon.GenerateData(p0);

            int current_year = DateTime.Now.Year;
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + current_year + "')]/following-sibling::td/button[1]")));
            tmsWait.Hard(2);
            //IWebElement pde_date_element = Browser.Wd.FindElement(By.XPath("//input[@type='text']"));
            //pde_date_element.Clear();
            //pde_date_element.SendKeys(pde_date);
            //pde_date_element.SendKeys(Keys.Tab);

            string value = pde_date.Replace("/", "");
            By Drp = By.XPath("//kendo-datepicker[@id='txtsubmissionDeadline']//span//input");
            Browser.Wd.FindElement(Drp).Clear();
            Browser.Wd.FindElement(Drp).SendKeys(value);
            tmsWait.Hard(2);
            IWebElement Update_Icon = Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + current_year + "')]/following-sibling::td/button[2]"));
            fw.ExecuteJavascript(Update_Icon);
            tmsWait.Hard(5);
           
        }

        //[Then(@"Verify View Edit PDE ""(.*)"" field is displayed")]
        //public void ThenVerifyViewEditPDEFieldIsDisplayed(string p0)
        //{
        //    switch(p0)
        //    {
        //        case "Status":

        //            UIMODUtilFunctions.elementPresenceUsingWebElement(PDEM.ViewEditPDE.YearDropdownlist.);
        //            break;
        //    }
        //}

        [When(@"View Edit PDE Search results First record is Clicked")]
        public void WhenViewEditPDESearchResultsFirstRecordIsClicked()
        {
            By loc = By.XPath("(//a[@title='Edit'])[1]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            tmsWait.Hard(10);
        }
        [When(@"View Edit PDE Search results ""(.*)"" record is Clicked")]
        public void WhenViewEditPDESearchResultsRecordIsClicked(int p0)
        {
            By loc = By.XPath("//table/tbody/tr["+p0+"]/td[11]//a");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            tmsWait.Hard(10);
           
        }

        [Then(@"Verify PDE Details page is displayed")]
        public void ThenVerifyPDEDetailsPageIsDisplayed()
        {

            By loc = By.XPath("//label[contains(.,'PDE Details')]");

            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }
        [When(@"View Edit PDE Details page ""(.*)"" and ""(.*)"" and ""(.*)"" and ""(.*)"" and  ""(.*)"" is Noted")]
        public void WhenViewEditPDEDetailsPageAndAndAndAndIsNoted(string p0, string p1, string p2, string p3, string p4)
        {
           


        string id = Browser.Wd.FindElement(By.XPath("//label[@test-id='editPde-lbl-idInfo']")).Text;

            fw.setVariable(p0, id);

            string submitter = Browser.Wd.FindElement(By.XPath("//label[@test-id='editPde-lbl-submitterInfo']")).Text;

            fw.setVariable(p1, submitter);

            string file = Browser.Wd.FindElement(By.XPath("//label[@test-id='editPde-lbl-fileNameInfo']")).Text;

            fw.setVariable(p2, file);

            string date = Browser.Wd.FindElement(By.XPath("//label[@test-id='editPde-lbl-fileLoadDateInfo']")).Text;
            DateTime d  = DateTime.Parse(date);
            Console.WriteLine(d);
            fw.setVariable(p3, d.ToString());
            Console.WriteLine(p3);
            string status = Browser.Wd.FindElement(By.XPath("//label[@test-id='editPde-lbl-rxInfo']")).Text;

            fw.setVariable(p4, status);
        }

        [When(@"View Edit PDE Details page ""(.*)"" is noted")]
        public void WhenViewEditPDEDetailsPageIsNoted(string p0)
        {
            string ClaimControlNumber = Browser.Wd.FindElement(By.Id("claimControlNoInfo")).Text;
            fw.setVariable(p0, ClaimControlNumber);
        }


        [When(@"Click on Workflow Assignment Plus Button")]
        public void WhenClickOnWorkflowAssignmentPlusButton()
        {
            fw.ExecuteJavascript(PDEM.PDEDetail.WorkflowAssignmentPlus);
        }

        [When(@"Work Flow Status drop down status is set to ""(.*)""")]
        public void WhenWorkFlowStatusDropDownStatusIsSetTo(string value)
        {

            UIMODUtilFunctions.clickOnWebElementUsingLocators(PDEM.PDEDetail.WorkflowstatusDropdown);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(By.XPath("//li[text()='" + value + "']"));
        }

        [When(@"Assign User drop down status is set to ""(.*)""")]
        public void WhenAssignUserDropDownStatusIsSetTo(string value)
        {
            UIMODUtilFunctions.clickOnWebElementUsingLocators(PDEM.PDEDetail.AssignedUserDropdown);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(By.XPath("//li[text()='" + value + "']"));
        }

        [When(@"Workflow Assignment ASSIGN WORKFLOW button is Clicked")]
        public void WhenWorkflowAssignmentASSIGNWORKFLOWButtonIsClicked()
        {
            fw.ExecuteJavascript(PDEM.PDEDetail.AssignWorkflowButton);
        }

        [Then(@"Verify Toaster message displayed as ""(.*)""")]
        public void ThenVerifyToasterMessageDisplayedAs(string msg)
        {
           
        string actualValue = Browser.Wd.FindElement(By.XPath("//div[@class='k-notification-content']")).Text;
            Assert.IsTrue(actualValue.Contains(msg));

            tmsWait.Hard(5);
        }


        [Then(@"PDE Details Back to Record Button is Clicked")]
        public void ThenPDEDetailsBackToRecordButtonIsClicked()
        {
            By loc = By.XPath("//span[@test-id='editPde-span-back']/i");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            tmsWait.Hard(5);
        }

        [When(@"Advanced Reset Button is Clicked")]
        public void WhenAdvancedResetButtonIsClicked()
        {
            By loc = By.XPath("//button/span[contains(.,'RESET')]");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            tmsWait.Hard(5);
        }


        [Then(@"Note MBI Number and Assign it to ""(.*)""")]
        public void ThenNoteMBINumberAndAssignItTo(string p0)
        {
            string notedmbi = Browser.Wd.FindElement(By.XPath("//input[@test-id='pdeRecordDetail-lbl-hicnInfo']")).GetAttribute("value");

            fw.setVariable(p0, notedmbi);
        }

        [Then(@"Verify ""(.*)"" Records displayed with ""(.*)"" Status")]
        public void ThenVerifyRecordsDisplayedWithStatus(string p0, string p1)
        {
            string mbi = tmsCommon.GenerateData(p0);
            tmsWait.Hard(5);
            By loc = By.XPath("//kendo-grid[@test-id='pdemBasicAndAdvanceSearch-grid-pdes']//td[contains(.,'" + mbi+"')]/following-sibling::td[contains(.,'"+ p1 + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }

        [Then(@"Verify View Edit PDE Details Search results are getting displayed")]
        public void ThenVerifyViewEditPDEDetailsSearchResultsAreGettingDisplayed()
        {
            By loc = By.XPath("//kendo-grid[@test-id='pdemBasicAndAdvanceSearch-grid-pdes']");

            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }



        [Then(@"Verify Edit CutOff Dates PDE Submission Date is Displayed as ""(.*)"" for DOS ""(.*)""")]
        public void ThenVerifyEditCutOffDatesPDESubmissionDateIsDisplayedAsForDOS(string p0, string p1)
        {

            string pde_date = tmsCommon.GenerateData(p0);
            int current_year = DateTime.Now.Year;
            bool ispresent = false;

            try
            {
                ispresent = Browser.Wd.FindElement(By.XPath("//div[@id='frmEditCutOffDates']//td[contains(.,'" + current_year + "')]/following-sibling::td[contains(.,'" + pde_date + "')]")).Displayed;

            }

            catch
            {

            }

            Assert.IsTrue(ispresent, "Modified Date is not displayed on the grid");
        }


        [Then(@"Verify Batch Admin page ""(.*)"" is displayed")]
        public void ThenVerifyBatchAdminPageIsDisplayed(string p0)
        {
            string fieldToVerfiy = tmsCommon.GenerateData(p0);
            bool ispresent = false;

            switch(fieldToVerfiy.ToLower())
            {
                case "search by label": ispresent = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Search By')]")).Displayed; break;
                case "workflow assignment label": ispresent = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Workflow Assignment')]")).Displayed; break;
                case "action label": ispresent = Browser.Wd.FindElement(By.XPath("//b[contains(.,'Action')]")).Displayed; break;
                case "view all error codes and flags label": ispresent = Browser.Wd.FindElement(By.XPath("//span[contains(.,'View All Error Codes and Flags')]")).Displayed; break;
                case "search button": ispresent = Browser.Wd.FindElement(By.XPath("//button[@test-id='viewEditPde-btn-search']")).Displayed; break;
                case "reset button": ispresent = Browser.Wd.FindElement(By.XPath("//button[contains(.,'RESET')]")).Displayed; break;
                case "allow eligibility resubmission checkbox":ispresent = Browser.Wd.FindElement(By.XPath("//input[@test-id='batchAdmin-ErrorTypeSelectionGroupErrGrpOptions']")).Displayed;break;
             }

            Assert.IsTrue(ispresent, "Expected item is not displayed");

        }

        [Then(@"Verify Batch Admin page ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyBatchAdminPageIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string expectedvalue = tmsCommon.GenerateData(p1);
            string actualvalue = "";
            bool ispresent = false;
            switch(field.ToLower())
            {
                case "action drop down":
                    actualvalue = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='batchAdmin-select-action']//span[@class='k-input']")).Text;
                    break;
                case "allow eligibility resubmission checkbox":
                    IWebElement ele = Browser.Wd.FindElement(By.XPath("//input[@test-id='batchAdmin-ErrorTypeSelectionGroupErrGrpOptions']"));
                    ReUsableFunctions.CheckBoxStatus(ele, expectedvalue);
                    actualvalue = "Unchecked";
                    //try
                    //{
                    //    ispresent = Browser.Wd.FindElement(By.XPath("//input[contains(@class,'ng-not-empty')]")).Displayed;
                    //}
                    //catch { }
                    //if (!ispresent)
                    //{
                    //    actualvalue = "Unchecked";
                    //}
                    break;
                case "workflow status":
                    actualvalue = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='batchUpdate-select-workFlowAssignedStatus']//span[@class='k-input']")).Text;
                    break;
                case "assigned user":
                    actualvalue = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='batchUpdate-select-workFlowAssignedUsers']//span[@class='k-input']")).Text;
                    break;
                case "assigned workflow button":
                    try
                    {
                        ispresent = Browser.Wd.FindElement(By.XPath("//button[@test-id='batchUpdate-btn-assignWorkflow']")).Enabled;
                    }

                    catch { }
                    if (ispresent)
                    {
                        actualvalue = "Enabled";
                    }
                    break;
                case "status drop down":
                    actualvalue = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='batchAdmin-select-status']//span[@class='k-input']")).Text;
                    break;
            }

            Assert.AreEqual(expectedvalue, actualvalue, "Expected value is not equal to actual value");
        }

        [When(@"Batch Admin page Workflow Assignment section is ""(.*)""")]
        public void WhenBatchAdminPageWorkflowAssignmentSectionIs(string p0)
        {
            string action = tmsCommon.GenerateData(p0);
            IWebElement Workflow_assignment = Browser.Wd.FindElement(By.XPath("//div[@test-id='batchUpdate-span-workflowAssignment']/i[2]"));
            if (action == "expand")
            {
                fw.ExecuteJavascript(Workflow_assignment);
            }
            else
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Advanced Search')]/preceding-sibling::i[2]")));
            }
            //string current_action = Workflow_assignment.GetProperty("hidden").ToString();
            //if(current_action.Contains("false") && action=="expand")
            //{
            //    fw.ExecuteJavascript(Workflow_assignment);
            //}
            //else 
            //{
            //    if(action=="collapse" && current_action=="true")
            //    {
            //        fw.ExecuteJavascript(Workflow_assignment);
            //    }

            //}
            tmsWait.Hard(2);

        }

        [When(@"Batch Admin page Advance Search section is ""(.*)""")]
        public void WhenBatchAdminPageAdvanceSearchSectionIs(string p0)
        {
            string action = tmsCommon.GenerateData(p0);
            IWebElement Workflow_assignment = Browser.Wd.FindElement(By.XPath("//label[contains(.,' Advanced Search')]/parent::div/i[2]"));
            if(action=="expand")
            { fw.ExecuteJavascript(Workflow_assignment); }
            else
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Advanced Search')]/preceding-sibling::i[2]")));
            }
            
        }



        [When(@"Batch Admin page ""(.*)"" button is clicked and Verify Message ""(.*)""")]
        public void WhenBatchAdminPageButtonIsClickedAndVerifyMessage(string p0, string p1)
        {
            string button = tmsCommon.GenerateData(p0);
            string expected_Message = tmsCommon.GenerateData(p1);
            string actual_Message = "";
            switch(button.ToLower())
            {
                case "assigned workflow":
                    ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("//button[@test-id='batchUpdate-btn-assignWorkflow']")));
                    tmsWait.Hard(1);
                    actual_Message = Browser.Wd.FindElement(By.ClassName("k-notification-content")).Text;
                   break;
                
                case "search":
                    ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("//button[@test-id='viewEditPde-btn-search']/span[contains(.,'SEARCH')]")));
                    tmsWait.Hard(2);
                    actual_Message = Browser.Wd.FindElement(By.ClassName("k-notification-content")).Text;
                     break;
            }
            Assert.IsTrue(actual_Message.Contains(expected_Message), "Expected Message is not displayed");
            tmsWait.Hard(5);
        }

        [When(@"Batch Admin page MBI noted from result grid and assigned to ""(.*)""")]
        public void WhenBatchAdminPageMBINotedFromResultGridAndAssignedTo(string p0)
        {
            tmsWait.Hard(10);
            string mbi = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='pdemBasicAndAdvanceSearch-grid-pdes']//tr[1]/td[7]")).Text;
            fw.setVariable(p0, mbi);
        }

        [When(@"Batch Admin page new new ""(.*)"" is set to ""(.*)""")]
        public void WhenBatchAdminPageNewNewIsSetTo(string p0, string p1)
        {
            string testid = "";
            switch (p0)
            {
                case "Submitter Id":
                    testid = "@test-id='batchAdmin-select-submitterId'";
                    break;
            }
            By Drp = By.XPath("//kendo-dropdownlist[" + testid + "]//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + p1 + "']");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@aria-owns='formInputBoxSubmitterId_listbox']")));
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//ul[@id='formInputBoxSubmitterId_listbox']/li)[3]")));
        }

        [When(@"Batch Admin page new ""(.*)"" is set to ""(.*)""")]
        public void WhenBatchAdminPageNewIsSetTo(string p0, string p1)
        {
            string testid = "";
            switch (p0)
            {
                case "Submitter Id":
                    testid = "@test-id='batchAdmin-select-submitterId'";
                    break;
            }
            By Drp = By.XPath("//kendo-dropdownlist[" + testid + "]//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + p1 + "']");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
        }

        [When(@"View PDE Records page ""(.*)"" new drop down list is set to ""(.*)""")]
        public void WhenViewPDERecordsPageNewDropDownListIsSetTo(string p0, string p1)
        {
            By Drp = null;
            By typeapp = By.XPath("//li[text()='" + p1 + "']");

            switch (p0)
            {
                case "DOSYearDropDownList":
                    Drp = By.XPath("//kendo-dropdownlist[@test-id='batchAdmin-select-yearOfDos']//span[@class='k-select']");
                    break;
            }

            UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@aria-owns='formInputBoxDos_listbox']/span")));
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//ul[@id='formInputBoxDos_listbox']/li[contains(.,'All')]")));
        }


        [When(@"Batch Admin page ""(.*)"" is set to ""(.*)""")]
        public void WhenBatchAdminPageIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            tmsWait.Hard(8);
            switch (field.ToLower())
            {
                case "workflow status":
                    By DrpWS = By.XPath("//kendo-dropdownlist[@test-id='batchUpdate-select-workFlowAssignedStatus']//span[@class='k-select']");
                    By typeappws = By.XPath("//li[text()='" + value + "']");


                    UIMODUtilFunctions.clickOnWebElementUsingLocators(DrpWS);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeappws);
                     break;
                case "assigned user":
                    By DrpAU = By.XPath("//kendo-dropdownlist[@test-id='batchUpdate-select-workFlowAssignedUsers']//span[@class='k-select']");
                    By typeappau = By.XPath("//li[text()='" + value + "']");


                    UIMODUtilFunctions.clickOnWebElementUsingLocators(DrpAU);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeappau);
                     break;
                case "status":
                    By DrpST = By.XPath("//kendo-dropdownlist[@test-id='batchAdmin-select-status']//span[@class='k-select']");
                    By typeappst = By.XPath("//li[text()='" + value + "']");


                    UIMODUtilFunctions.clickOnWebElementUsingLocators(DrpST);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeappst);
                    break;
                case "submitter id":
                    By DrpSID = By.XPath("//kendo-dropdownlist[@test-id='batchAdmin-select-submitterId']//span[@class='k-select']");
                    By typeappsid = By.XPath("//li[text()='" + value + "']");


                    UIMODUtilFunctions.clickOnWebElementUsingLocators(DrpSID);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeappsid);
                    break;
                case "mbi": fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@test-id='deleteSubmittedDiagnosis-a-providerLookup']")));
                            tmsWait.Hard(8);
                            Browser.Wd.FindElement(By.XPath("//input[@test-id='member-txt-hic']")).SendKeys(value);
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='member-btn-search']")));
                            tmsWait.Hard(3);
                            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//input[@id='"+value+"']")));
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + value + "')]/preceding-sibling::td/input")));
                            tmsWait.Hard(2);
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='member-btn-add']")));
                            tmsWait.Hard(2);
                    break;
                case "year":
                    By DrpYR = By.XPath("//kendo-dropdownlist[@test-id='batchAdmin-select-yearOfDos']//span[@class='k-select']");
                    By typeappyr = By.XPath("//li[text()='" + value + "']");


                    UIMODUtilFunctions.clickOnWebElementUsingLocators(DrpYR);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeappyr);
                    //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Advanced Search')]")));
                    //tmsWait.Hard(2);
                    //UIMODUtilFunctions.selectDropDownValueFromGendoUI(Browser.Wd.FindElement(By.XPath("//span[@aria-owns='formInputBoxDos_listbox']")), value);
                    //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Advanced Search')]")));
                    break;

            }
        }

        [Then(@"Verify PDE View Edit page result grid display workflow status value as ""(.*)""")]
        public void ThenVerifyPDEViewEditPageResultGridDisplayWorkflowStatusValueAs(string p0)
        {
            tmsWait.Hard(5);
            string expected_status = tmsCommon.GenerateData(p0);
            string actual_stauts = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='pdemBasicAndAdvanceSearch-grid-pdes']//tr[1]/td[9]")).Text;
            Assert.AreEqual(expected_status, actual_stauts, "Expected Status is not displayed");
        }




    }
}
 