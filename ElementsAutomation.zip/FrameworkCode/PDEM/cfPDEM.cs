﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using TMSoR1;

namespace TMSoR1.FrameworkCode.PDEM
{
         [Binding]   
        public class PDEM
        {
            public static PDEManagerAdministration PDEManagerAdministration { get { return new PDEManagerAdministration(); } }
            public static WelcometoPDEManager WelcometoPDEManager { get { return new WelcometoPDEManager(); } }
            public static LoadedFiles LoadedFiles { get { return new LoadedFiles(); } }
        public static ViewEditPDE ViewEditPDE { get { return new ViewEditPDE(); } }
        public static PDEDetail PDEDetail { get { return new PDEDetail(); } }
    }

}



[Binding]
public class PDEDetail
{
    public IWebElement WorkflowAssignmentPlus { get { return Browser.Wd.FindElement(By.XPath("//i[@test-id='workflow-info-workflowStatusCollapse']")); } }
    public IWebElement WorkflowstatusDropdown { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='editPde-select-workflowstatus']//span[@class='k-select']")); } }
    public IWebElement AssignedUserDropdown { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='editPde-select-assignuser']//span[@class='k-select']")); } }
    public IWebElement AssignWorkflowButton { get { return Browser.Wd.FindElement(By.XPath("//button[contains(.,'ASSIGN WORKFLOW')]")); } }

}

    [Binding]
public class ViewEditPDE
{
    public IWebElement MBI { get { return Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='orsearch-mutisel-modeldisplay']//input")); } }

    public IWebElement AdvancedSearchPlusButton { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Advanced Search')]")); } }
    public IWebElement SearchButton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='viewEditPde-btn-search']/span[contains(.,'SEARCH')]")); } }
    public IWebElement ResetButton { get { return Browser.Wd.FindElement(By.XPath("//button[@class='btn  validateButton']")); } }
    public IWebElement YearDropdownlist { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='batchAdmin-select-yearOfDos']//span[@class='k-select']")); } }
    public IWebElement TotalItems { get { return Browser.Wd.FindElement(By.XPath("//kendo-pager/kendo-pager-info")); } }

    public IWebElement StatusDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[id='formInputBoxStatus']")); } }
    public IWebElement FileLoadedDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[id='formInputBoxFilesLoaded']")); } }
    public IWebElement SubmitterDropdownlist { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='batchAdmin-select-submitterId']//span[@class='k-select']")); } }
    public IWebElement PlanIDDropdownlist { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='batchAdmin-select-planId']//span[@class='k-select']")); } }
    public IWebElement P2PPlanDropdownlist { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='batchAdmin-select-p2PPlan']//span[@class='k-select']")); } }
    public IWebElement PBPDropdownlist { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='batchAdmin-select-pbp']//span[@class='k-select']")); } }
    public IWebElement WorkflowDropdownlist { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='batchAdmin-select-workflowStatus']//span[@class='k-select']")); } }
    public IWebElement UsersDropdownlist { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='batchAdmin-select-workflowUsers']//span[@class='k-select']")); } }
    public IWebElement AgeingDropdownlist { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='batchAdmin-select-aging']//span[@class='k-select']")); } }
    public IWebElement LoadedBatchesDropdownlist { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='batchAdmin-select-loadedBatches']//span[@class='k-select']")); } }
    public IWebElement ResponseFileDropdownlist { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='batchAdmin-select-responseFiles']//span[@class='k-select']")); } }
    public IWebElement advancedPdeCreateDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='viewEditPde-btn-advancedPdeCreate']")); } }

    public IWebElement errorCodeLookup { get { return Browser.Wd.FindElement(By.XPath("//a[@test-id='batchAdmin-a-errorCodesLookup']")); } }
    public IWebElement errorCodeTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='errorCodes-txt-ErrorCode']")); } }
    public IWebElement errorCodeSearchButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='errorCodes-btn-search']")); } }
    public IWebElement FirstCheckbox { get { return Browser.Wd.FindElement(By.XPath("(//input[@type='checkbox'])[1]")); } }
    public IWebElement ADDBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='errorCodes-btn-add']")); } }

    public IWebElement viewEditPdeLink { get { return Browser.Wd.FindElement(By.XPath("//span[@test-id='viewEditPde-link-viewErrorCodes']")); } }

    public IWebElement PDEErrorCodeTab { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'PDE Error Codes')]")); } }
    public IWebElement WarnFlagsTab { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Warning Flags')]")); } }
    public IWebElement ErrorCode { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pdeErrorDetail-txt-errorCode']")); } }
    public IWebElement ErrorCodeSearchButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='search-btn-search']")); } }

    public IWebElement ResetButtonOnErrorCode { get { return Browser.Wd.FindElement(By.XPath("//button[@id='btnReset']")); } }
    public IWebElement ResetButtonOnSearchErrorCodes { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='errorCodes-btn-reset']")); } }


    public IWebElement BackToRecordButtonOnErrorCode{ get { return Browser.Wd.FindElement(By.XPath("//span[@test-id='pdeErrorDetail-span-back']/i")); } }

    public IWebElement ClaimControlNumber { get { return Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='otherCriteriasearch-mutisel-modelDisplay']//kendo-searchbar//input")); } }
}

[Binding]
public class LoadedFiles
{
    public IWebElement PageSize { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_cboPageSize")); } }
    public IWebElement PlanID { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='planIds_listbox']")); } }
    public IWebElement PBP { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='pbpIds_listbox']")); } }
    public IWebElement UserID { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='userIds_listbox']")); } }
    public IWebElement Submitter { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='submitterIds_listbox']")); } }
    public IWebElement LoadedFilesSearchResultsTable { get { return Browser.Wd.FindElement(By.Id("loadedBatchGrid")); } }

    

}
    [Binding]
public class PDEManagerAdministration
{
    public IWebElement SetDefaultDOSYearFilterLabel { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_TabContainer1_SetDOSYearPanel_DOSLabel")); } }
    public IWebElement SetYear { get { return Browser.Wd.FindElement(By.Id("btnSaveDefaultDosYear")); } }
    public IWebElement Reset { get { return Browser.Wd.FindElement(By.Id("btnResetDefaultDosYear")); } }
    public IWebElement Home { get { return Browser.Wd.FindElement(By.XPath("//a[contains(.,'Home')]")); } }
    public IWebElement EditCutOffDatesLabel1 { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_TabContainer1_CutOffPanel_lblStep1")); } }
    public IWebElement EditCutOffDatesLabel2 { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_TabContainer1_CutOffPanel_Label1")); } }
    public IWebElement EditCutOffDatesPDESubmissionDeadlineTxtbox { get { return Browser.Wd.FindElement(By.CssSelector("[data-role='datepicker']")); } }
    public IWebElement SaveButton { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_TabContainer1_CutOffPanel_btnSave")); } }
    public IWebElement CancelButton { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_TabContainer1_CutOffPanel_btnCancel")); } }
    public IWebElement SuccessMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_TabContainer1_CutOffPanel_lblMsg")); } }
    public IWebElement PDESubmissionDeadlineTable { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_TabContainer1_CutOffPanel_dgDateGrid")); } }
    public IWebElement DOSYear { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_TabContainer1_CutOffPanel_txtDOSYear")); } }

    public IWebElement AddWorkflowStatusLabel { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_TabContainer1_WorkFlowPanel_Label2")); } }
    public IWebElement AddWorkflowStatusStaticMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_TabContainer1_WorkFlowPanel_WFlblMsg")); } }
    public IWebElement EditWorkflowStatusTextbox { get { return Browser.Wd.FindElement(By.Name("workStatusDescription"));  } }
    public IWebElement AddWorkflowStatusTextbox { get { return Browser.Wd.FindElement(By.Id("txtWorkflowStatus")); } }
    public IWebElement AddModifyNewWorkflowStatusButton { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_TabContainer1_WorkFlowPanel_AddNewWorkflowButton")); } }
    public IWebElement AddModifyNewWorkflowResetButton { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_TabContainer1_WorkFlowPanel_ResetAddNewWorkflowButton")); } }
    public IWebElement AddModifyNewWorkflowTable { get { return Browser.Wd.FindElement(By.Id("pdemWorkflowStatusGrid")); } }

}
[Binding]
public class WelcometoPDEManager
{
    public IWebElement YearDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='admin-select-defaultDosYear']")); } }

    public IWebElement InformationIconToolTip { get { return Browser.Wd.FindElement(By.XPath("//*[text()[contains(.,'Note if there is only one DOS Year value in the database that DOS Year will automatically')]]")); } }
    
    public IWebElement InformationIconWindowCloseBtn { get { return Browser.Wd.FindElement(By.XPath("/html/body/div[3]/div/div[1]/a")); } }
}