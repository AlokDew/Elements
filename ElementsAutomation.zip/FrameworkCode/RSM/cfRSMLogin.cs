﻿using OpenQA.Selenium;
using TechTalk.SpecFlow;

namespace TMSoR1
{
    public class RSM
    {
        public static RSMHomePage RSMHomePage { get { return new RSMHomePage(); } }
        public static Admininistration Admininistration { get { return new Admininistration(); } }
        public static CMSSweepsRiskCutOverDates CMSSweepsRiskCutOverDates { get { return new CMSSweepsRiskCutOverDates(); } }
        public static HCCRxHCCReport HCCRxHCCReport { get { return new HCCRxHCCReport(); } }
        public static RiskScoreTrendReport RiskScoreTrendReport { get { return new RiskScoreTrendReport(); } }
        public static RiskAssessmentReport RiskAssessmentReport { get { return new RiskAssessmentReport(); } }
        public static OtherReport OtherReport { get { return new OtherReport(); } }
        public static HCCDiscrepancy HCCDiscrepancy { get { return new HCCDiscrepancy(); } }
        public static HCCBeneficiaries HCCBeneficiaries { get { return new HCCBeneficiaries(); } }
        public static CMSHCCDiseaseGroupPrevelance CMSHCCDiseaseGroupPrevelance { get { return new CMSHCCDiseaseGroupPrevelance(); } }
        public static CMSHCCRXDiseaseGroupPrevelance CMSHCCRXDiseaseGroupPrevelance { get { return new CMSHCCRXDiseaseGroupPrevelance(); } }
        public static RXHCCBeneficiaries RXHCCBeneficiaries { get { return new RXHCCBeneficiaries(); } }
        public static MemberMissingHCC MemberMissingHCC { get { return new MemberMissingHCC(); } }
        public static HCCDetailsBlended HCCDetailsBlended { get { return new HCCDetailsBlended(); } }
        public static MemberMissingRXHCC MemberMissingRXHCC { get { return new MemberMissingRXHCC(); } }
        public static RiskAdjustmentProfile RiskAdjustmentProfile { get { return new RiskAdjustmentProfile(); } }
        public static RiskScoreEstimatedReceivable RiskScoreEstimatedReceivable { get { return new RiskScoreEstimatedReceivable(); } }
        public static RiskScoreEstimatedReceivablePartD RiskScoreEstimatedReceivablePartD { get { return new RiskScoreEstimatedReceivablePartD(); } }
        public static DiagnosisAlertDetailsPartC DiagnosisAlertDetailsPartC { get { return new DiagnosisAlertDetailsPartC(); } }
        public static DataLoadSummary DataLoadSummary { get { return new DataLoadSummary(); } }
        public static RiskScoreTrendDetails RiskScoreTrendDetails { get { return new RiskScoreTrendDetails(); } }
        public static Lookups Lookups { get { return new Lookups(); } }
        public static LookupsIcons LookupsIcons { get { return new LookupsIcons(); } }
        public static HCCDetails HCCDetails { get { return new HCCDetails(); } }
        public static MemberDiscrepancy MemberDiscrepancy { get { return new MemberDiscrepancy(); } }
        public static MemberHCCDetail MemberHCCDetai { get { return new MemberHCCDetail(); } }
        public static RSMMemberHCCExtract RSMMemberHCCExtract { get { return new RSMMemberHCCExtract(); } }
        public static Archive Archive { get { return new Archive(); } }
        public static MinimumEnrollMonths MinimumEnrollMonths { get { return new MinimumEnrollMonths(); } }
        public static RAPSDrilldown RAPSDrilldown { get { return new RAPSDrilldown(); } }
        public static RSMDashboard RSMDashboard { get { return new RSMDashboard(); } }
        public static RiskScoreTrendPCPPartD RiskScoreTrendPCPPartD { get { return new RiskScoreTrendPCPPartD(); } }
        public static ReportManager ReportManager { get { return new ReportManager(); } }
        public static ReportCommanComponant ReportCommanComponant { get { return new ReportCommanComponant(); } }
    }

    [Binding]
    public class RAPSDrilldown
    {
        public IWebElement BackToRecord { get { return Browser.Wd.FindElement(By.XPath("//span[@test-id='clinicalDrillDownGrid-lbl-back']/i")); } }
        public IWebElement Close { get { return Browser.Wd.FindElement(By.XPath("//span[@class='k-icon k-i-x']")); } }

    }

    [Binding]
    public class ReportManager
    {
        public IWebElement ReportName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='multiSelectReports']")); } }
        public IWebElement PlanId { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='multiSelectPlans']")); } }
        public IWebElement SearchButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='reportManager-btn-search']")); } }

        public IWebElement DownloadButton { get { return Browser.Wd.FindElement(By.CssSelector(".fa.fa-download")); } }
        
    }

    [Binding]
    public class MinimumEnrollMonths
    {
        public IWebElement CurrentMinimumEnrollmentMonths { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'9')]")); } }
        public IWebElement ApplyButton { get { return Browser.Wd.FindElement(By.Id("btnApply")); } }
        public IWebElement NewMinimumEnrollmentMonthsdDropdownlist { get { return Browser.Wd.FindElement(By.XPath("//select[@ng-model='minMonths.selectedVal']")); } }
    }

    [Binding]
    public class Archive
    {
        public IWebElement SubmitJob { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='archive-btn-Reset']")); } }
        public IWebElement ArchiveYear { get { return Browser.Wd.FindElement(By.CssSelector(".changeHeight.ng-pristine.ng-untouched.ng-valid")); } }
        public IWebElement PageSize { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='archive-txt-PageSize']")); } }
        public IWebElement LastPageLink { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='archivePaging']//a[contains(text(), 'Last')]")); } }


    }


    [Binding]
    public class RSMMemberHCCExtract
    {
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccExtract-slct-planID']")); } }
        public IWebElement PaymentYear { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccExtract-slct-paymentYear']")); } }
        public IWebElement Reset { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccExtract-btn-Reset']")); } }
        public IWebElement Export { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccExtract-lbl-Export']")); } }
        public IWebElement PlanIDLabel { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccExtract-lbl-planID']")); } }
        public IWebElement PaymentYearLabel { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccExtract-lbl-paymentYear']")); } }
        public IWebElement MessageLable { get { return Browser.Wd.FindElement(By.CssSelector(".toast-message")); } }
        
    }

    [Binding]
    public class MemberHCCDetail
    {
        public IWebElement HICN { get { return Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='hccDetails-select-mbi']//input")); } }
        public IWebElement MemberID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccDetails-txt-memberid']")); } }
        public IWebElement Year { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccDetails-slct-year']")); } }
        public IWebElement YearType { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccDetails-slct-planID']")); } }
        public IWebElement Reset { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberSearch-btn-reset']")); } }
        public IWebElement Search { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberSearch-btn-search']")); } }
        public IWebElement Title { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Search Member HCC details by MBI or Member ID:')]")); } }
        public IWebElement HICNLookup { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'MBI')]/following-sibling::div//i")); } }
        public IWebElement MemberSearchCriteriaTable { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberlookup-grid-memberResultGrid']")); } }
        public IWebElement MemberSearchCriteriaPagination { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberlookup-Page-Pagination']")); } }
        public IWebElement ResultAccordion { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberHccDetail-acrdn-Grp2'] [test-id='memberHccDetail-spn-Search']")); } }
        public IWebElement SearchAccordion { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberHccDetail-acrdn-Grp1'] [test-id='memberHccDetail-spn-Search']")); } }
        public IWebElement ResultSectionHICNvalue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccDetails-span-hicn']")); } }
        public IWebElement ResultSectionHICN { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccDetails-span-hicn']")); } }
        public IWebElement ResultSectionMembervalue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccDetails-span-memberId']")); } }
        public IWebElement ResultSectionMember { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccDetails-lbl-memberId']")); } }
        public IWebElement ResultSectionLastNamevalue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccDetails-span-Lname']")); } }
        public IWebElement ResultSectionLastName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccDetails-lbl-Lname']")); } }
        public IWebElement ResultSectionFirstNamevalue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccDetails-span-Fname']")); } }
        public IWebElement ResultSectionFirstName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccDetails-lbl-Fname']")); } }
        public IWebElement ResultSectionDOBvalue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccDetails-span-dob']")); } }
        public IWebElement ResultSectionDOB { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccDetails-lbl-dob']")); } }
        public IWebElement ResultSectionPlanIDvalue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccDetails-span-planid']")); } }
        public IWebElement ResultSectionPlanID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccDetails-lbl-planid']")); } }
        public IWebElement ResultSectionPlanNamevalue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccDetails-span-Pname']")); } }
        public IWebElement ResultSectionPlanName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccDetails-lbl-PName']")); } }
        public IWebElement ResultSectionPCPvalue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccDetails-span-pcp']")); } }
        public IWebElement ResultSectionPCP { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccDetails-lbl-pcp']")); } }
        public IWebElement ResultSectionIPAgroupvalue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccDetails-span-IPAGroup']")); } }
        public IWebElement ResultSectionIPAgroup { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccDetails-lbl-IPAGroup']")); } }
        public IWebElement ResultSectionPBPvalue { get { return Browser.Wd.FindElement(By.XPath(".//label[@test-id='hccDetails-lbl-Pbp']/following-sibling::span")); } }
        public IWebElement ResultSectionPBP { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccDetails-lbl-Pbp']")); } }
        public IWebElement ResultSectionSCCvalue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccDetails-span-Scc']")); } }
        public IWebElement ResultSectionSCC { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccDetails-lbl-Scc']")); } }
        public IWebElement ResultSectionCountryvalue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccDetails-span-County']")); } }
        public IWebElement ResultSectionCountry { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccDetails-lbl-County']")); } }
        public IWebElement ResultSectionStatevalue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccDetails-Span-State']")); } }
        public IWebElement ResultSectionState { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccDetails-lbl-State']")); } }
        public IWebElement ResultSectionRiskScoreGrid { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='riskScoreGrid']")); } }
        public IWebElement ResultSectionDemographicGrid { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='demographic-grid-demographicGrid']")); } }
        public IWebElement RAPSDrillDownClinicalTable { get { return Browser.Wd.FindElement(By.XPath("//div[@test-id='clinicalDrillDownGrid']")); } }
        
        public IWebElement ClinicalHCCsonFileforMemberTitle { get { return Browser.Wd.FindElement(By.XPath("//div[@test-id='clinicalHcc-grid-clinicalHccGrid']")); } }
        public IWebElement RiskScoreRiskAdjustmentFactorTypTitle { get { return Browser.Wd.FindElement(By.XPath("//div[@test-id='riskScore-grd-riskScoreGrid']/preceding-sibling::div")); } }
        public IWebElement clinicalHccsonFileforMemberPagination { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Clinicallookup-Paging-Pagination']")); } }
        public IWebElement RiskScoreRiskAdjustmentFactorTypePageSize { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='RiskScorelookup-txt-PageSize']")); } }
        public IWebElement clinicalHccsonFileforMember { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='clinicalHcc-grid-clinicalHccGrid']")); } }
        public IWebElement DemographicHCCsonFileforMemberTable { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='demographic-grid-demographicGrid']")); } }
        public IWebElement DemographicHCCsonFileforMemberPagination { get { return Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='demographic-grid-demographicGrid']//span//input")); } }
       

        

    }

    [Binding]
    public class MemberDiscrepancy
    {
        public IWebElement memberDetailsClinicalTitle { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'RAPS Drill-Down - Clinical')]")); } }
        public IWebElement SearchResultsGrid { get { return Browser.Wd.FindElement(By.XPath("//div[@test-id='memberDiscrepancy-grid-resultMemberDiscrepancyGrid']")); } }
        public IWebElement ResetButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMemberDiscrepancy-btn-reset']")); } }
        public IWebElement topFiftyPaging { get { return Browser.Wd.FindElement(By.Id("topFiftyPaging")); } }
        public IWebElement resultMemberDiscrepancyclinicalGrid { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDiscrepancy-grid-clinicalGrid']")); } }
        public IWebElement resultMemberDiscrepancyrapsGrid { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rapsDrillDown-grid-rapsGrid']")); } }
        public IWebElement resultMemberDiscrepancyGrid { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDiscrepancy-grid-resultMemberDiscrepancyGrid']")); } }
        public IWebElement SearchButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMemberDiscrepancy-btn-save']")); } }
        public IWebElement RiskScoreDiscrepancyOnlyCheckbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMemberDiscrepancy-cb-riskScoreDiscrepancyOnly']")); } }
        public IWebElement NewEnrollmentNoneOption { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMemberDiscrepancy-rd-enrollmentNone']")); } }
        public IWebElement NewEnrollmentExcludeOption { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMemberDiscrepancy-rd-enrollmentExclude']")); } }
        public IWebElement PrimaryCarePhysicianLookup { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='searchMemberDiscrepancy-lbl-pcp']/following-sibling::div//i")); } }
        public IWebElement RxHCCLookup { get { return Browser.Wd.FindElement(By.XPath("//label[@id='lblRxHcc']/following-sibling::div//i")); } }
        public IWebElement IPAMedicalGroupLookup { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='searchMemberDiscrepancy-lbl-ipa']/following-sibling::div//i")); } }
        public IWebElement HCCLookup { get { return Browser.Wd.FindElement(By.XPath("//label[@id='lblHcc']/following-sibling::div//i")); } }
        public IWebElement SCCLookup { get { return Browser.Wd.FindElement(By.XPath("//label[@id='lblScc']/following-sibling::div//i")); } }
        public IWebElement Enrollment { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMemberDiscrepancy-slct-enrollment']")); } }
        public IWebElement PaymentYear { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMemberDiscrepancy-slct-paymentYear']")); } }
        public IWebElement HICLookup { get { return Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='searchMemberDiscrepancy-select-mbi']/parent::div/following-sibling::div//i")); } }
        public IWebElement MemberDiscrepancyLink { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Member Discrepancy')]")); } }
        public IWebElement ViewRSMLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='menu-10']")); } }
        public IWebElement PlanId { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMemberDiscrepancy-slct-plan']")); } }
        public IWebElement PBP { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMemberDiscrepancy-slct-pbp']")); } }
        public IWebElement searchMemberDiscrepancyPlanId { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMemberDiscrepancy-lbl-plan']")); } }
        public IWebElement searchMemberDiscrepancyPBP { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMemberDiscrepancy-lbl-pbp']")); } }
        public IWebElement discrepancytype { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMemberDiscrepancy-slct-discrepancyType']")); } }
        public IWebElement yearType { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMemberDiscrepancy-slct-yearType']")); } }
        public IWebElement Title { get { return Browser.Wd.FindElement(By.XPath("//div[@class='flex-fill']/div[contains(.,'Member Discrepancy')]")); } }
        public IWebElement RapsDrillDownTitle { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rapsDrillDown-title-raps']")); } }
        public IWebElement PlanIDdefaultvalue { get { return Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@id='multiSelectPlans']//kendo-taglist//span[@class='ng-star-inserted']")); } }
        public IWebElement PBPdefaultvalue { get { return Browser.Wd.FindElement(By.XPath(".//kendo-multiselect[@test-id='searchMemberDiscrepancy-select-pbp']//kendo-taglist//span[contains(.,'All')]")); } }

        public IWebElement discrepancyTypedefaultvalue { get { return Browser.Wd.FindElement(By.XPath(".//multiselect[@test-id='searchMemberDiscrepancy-slct-discrepancyType']//button[contains(.,'All')]")); } }
        public IWebElement yearTypedefaultvalue { get { return Browser.Wd.FindElement(By.XPath(".//multiselect[@test-id='searchMemberDiscrepancy-slct-yearType']//button[contains(.,'All')]")); } }
        public IWebElement memberDetailsHIC { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-lbl-hic']")); } }
        public IWebElement memberDetailsHICvalue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-span-hic']")); } }
        public IWebElement memberDetailsPlan { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-lbl-plan']")); } }
        public IWebElement memberDetailsPlanvalue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-span-plan']")); } }
        public IWebElement memberDetailsmemberId { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-lbl-memberId']")); } }
        public IWebElement memberDetailsmemberIdValue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-span-memberId']")); } }
        public IWebElement memberDetailslastName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-lbl-lastName']")); } }
        public IWebElement memberDetailslastNameValue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-span-lastName']")); } }
        public IWebElement memberDetailsfirstName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-lbl-firstName']")); } }
        public IWebElement memberDetailsfirstNameValue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-span-firstName']")); } }
        public IWebElement memberDetailsplan { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-lbl-plan']")); } }
        public IWebElement memberDetailsplanValue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-span-plan']")); } }
        public IWebElement memberDetailspbp { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-lbl-pbp']")); } }
        public IWebElement memberDetailspbpValue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-span-pbp']")); } }
        public IWebElement memberDetailsplanScc { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-lbl-planScc']")); } }
        public IWebElement memberDetailsplanSccValue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-span-planScc']")); } }
        public IWebElement memberDetailsplanState { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-lbl-planState']")); } }
        public IWebElement memberDetailsplanStateValue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-span-planState']")); } }
        public IWebElement memberDetailsplanCountry { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-lbl-planCounty']")); } }
        public IWebElement memberDetailsplanCountryValue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-span-planCounty']")); } }
        public IWebElement memberDetailsplanRaft { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-lbl-planRaft']")); } }
        public IWebElement memberDetailsplanRaftValue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-span-planRaft']")); } }
        public IWebElement memberDetailsplanRiskScore { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-lbl-planRiskScore']")); } }
        public IWebElement memberDetailsplanRiskScoreValue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-span-planRiskScore']")); } }
        public IWebElement memberDetailsplanRiskScoreD { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-lbl-planRiskScoreD']")); } }
        public IWebElement memberDetailsplanRiskScoreDValue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-span-planRiskScoreD']")); } }
        public IWebElement memberDetailsplanName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-lbl-planName']")); } }
        public IWebElement memberDetailsplanNameValue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-span-planName']")); } }
        public IWebElement memberDetailspcp { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-lbl-pcp']")); } }
        public IWebElement memberDetailspcpValue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-span-pcp']")); } }
        public IWebElement memberDetailscmsRaft { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-lbl-cmsRaft']")); } }
        public IWebElement memberDetailscmsRaftValue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-span-cmsRaft']")); } }
        public IWebElement memberDetailscmsRiskScore { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-lbl-cmsRiskScore']")); } }
        public IWebElement memberDetailscmsRiskScoreValue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-span-cmsRiskScore']")); } }
        public IWebElement memberDetailscmsRiskScoreD { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-lbl-cmsRiskScoreD']")); } }
        public IWebElement memberDetailscmsRiskScoreDValue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-span-cmsRiskScoreD']")); } }
        public IWebElement memberDetailspartCOnly { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-lbl-partCOnly']")); } }
        public IWebElement memberDetailspartCOnlyValue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-span-partCOnly']")); } }
        public IWebElement memberDetailsipa { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-lbl-ipa']")); } }
        public IWebElement memberDetailsipaValue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDetails-span-ipa']")); } }
        public IWebElement ClinicalHCCPageSize { get { return Browser.Wd.FindElement(By.XPath("//div[@test-id='memberDiscrepancy-pagination-clinicalGrid']//span[contains(.,'Page Size:')]//input")); } }
        public IWebElement searchMemberDiscrepancyHICLable { get { return Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='searchMemberDiscrepancy-select-mbi']/parent::div/parent::div/preceding-sibling::label")); } }
        public IWebElement searchMemberDiscrepancyHICText { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMemberDiscrepancy-select-mbi']")); } }
        public IWebElement searchMemberDiscrepancydiscrepancyTypeLable { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMemberDiscrepancy-lbl-discrepancyType']")); } }
        public IWebElement searchMemberDiscrepancydiscrepancyTypeText { get { return Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='searchMemberDiscrepancy-select-discrepancyType']//span[contains(.,'All')]")); } }
        public IWebElement searchMemberDiscrepancypaymentYearLable { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMemberDiscrepancy-lbl-paymentYear']")); } }
        public IWebElement searchMemberDiscrepancypaymentYearText { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMemberDiscrepancy-slct-paymentYear']")); } }
        public IWebElement searchMemberDiscrepancyyearTypeLable { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMemberDiscrepancy-lbl-yearType']")); } }
        public IWebElement searchMemberDiscrepancyyearTypeText { get { return Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='searchMemberDiscrepancy-select-yearType']//span[contains(.,'All')]")); } }
        public IWebElement searchMemberDiscrepancyenrollmentLable { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMemberDiscrepancy-lbl-enrollment']")); } }
        public IWebElement searchMemberDiscrepancyenrollmentText { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMemberDiscrepancy-select-enrollment']")); } }
        public IWebElement searchMemberDiscrepancysccLable { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMemberDiscrepancy-lbl-scc']")); } }
        public IWebElement searchMemberDiscrepancysccText { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMemberDiscrepancy-txt-scc']")); } }
        public IWebElement searchMemberDiscrepancyhccLable { get { return Browser.Wd.FindElement(By.Id("lblHcc")); } }
        public IWebElement searchMemberDiscrepancyhccText { get { return Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='searchMemberDiscrepancy-txt-hcc']")); } }
        public IWebElement searchMemberDiscrepancyrxhccLable { get { return Browser.Wd.FindElement(By.Id("lblRxHcc")); } }
        public IWebElement searchMemberDiscrepancyrxhccText { get { return Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='searchMemberDiscrepancy-txt-rxhcc']")); } }
        public IWebElement searchMemberDiscrepancyipaLable { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMemberDiscrepancy-lbl-ipa']")); } }
        public IWebElement searchMemberDiscrepancypcpLable { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMemberDiscrepancy-lbl-pcp']")); } }
        public IWebElement searchMemberDiscrepancynewEnrollmentLable { get { return Browser.Wd.FindElement(By.Id("lblNewEnrollment")); } }
        public IWebElement searchMemberDiscrepancyriskScoreDiscrepancyOnlyLable { get { return Browser.Wd.FindElement(By.Id("lblriskScoreDiscrepancyOnly")); } }
        public IWebElement riskScoreDiscrepancyOnlycheckbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMemberDiscrepancy-cb-riskScoreDiscrepancyOnly']")); } }
        public IWebElement BackToRecordRapsDrillButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rapsDrillDown-img-BackToRecord']")); } }
        public IWebElement closeRapsDrillButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rapsDrillDown-btn-close']")); } }
        public IWebElement RxHCCfield { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMemberDiscrepancy-txt-hcc']")); } }



    }


    [Binding]
    public class Lookups
    {
        public GroupIDLookUp GroupIDLookUp { get { return new GroupIDLookUp(); } }
        public PCPLookUp PCPLookUp { get { return new PCPLookUp(); } }
        public HCCLookUp HCCLookUp { get { return new HCCLookUp(); } }
        public RXHCCLookUp RXHCCLookUp { get { return new RXHCCLookUp(); } }
        public HICLookUp HICLookUp { get { return new HICLookUp(); } }
        public SCCLookUp SCCLookUp { get { return new SCCLookUp(); } }

    }

    [Binding]
    public class LookupsIcons
    {
        public IWebElement GruopIDLookupicon { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-link-group'] a")); } }
        public IWebElement PCPLookupicon { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-link-pcp'] a")); } }
        public IWebElement SCCLookupicon { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-link-ssc'] a")); } }
        public IWebElement HICLookupicon { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-link-hicN'] a")); } }

    }


    [Binding]
    public class GroupIDLookUp
    {
        public IWebElement GrouppageTitle { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='groupLookup-title-searchCriteria']")); } }
        public IWebElement GroupID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='grouplookup-txt-GroupId']")); } }
        public IWebElement Groupname { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='grouplookup-txt-GroupName']")); } }
        public IWebElement GroupReset { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='grouplookup-btn-Reset']")); } }
        public IWebElement GroupSearch { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='grouplookup-btn-Search']")); } }
        public IWebElement GroupLoookupGrid { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='grouplookup-grid-searchresult']")); } }
        public IWebElement GroupLoookBackToRecord { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='grouplookup-img-BackToRecord']")); } }
        public IWebElement topFiftyPaging { get { return Browser.Wd.FindElement(By.Id("topFiftyPaging")); } }
        public IWebElement GroupSearchPagination { get { return Browser.Wd.FindElement(By.Id("groupLookupPaging")); } }

        

    }
  
    [Binding]
    public class HICLookUps
    {
        public IWebElement HICTitle { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberLookup-title-searchCriteria']")); } }
        public IWebElement HIC { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberlookup-txt-Hic']")); } }
        public IWebElement MemberID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberLookup-txt-memberId']")); } }
        public IWebElement LastName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberLookup-txt-LastName']")); } }
        public IWebElement FirstName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberLookup-txt-FirstName']")); } }
        public IWebElement HICBackToRecord { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberLookup-img-BackToRecord']")); } }
        public IWebElement HICSearch { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberLookup-btn-Search']")); } }
        public IWebElement HICReset { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberLookup-btn-Reset']")); } }
    }

    [Binding]
    public class PCPLookUp
    {
        public IWebElement PCPpageTitle { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pcpLookup-title-pcpSearch']")); } }
        public IWebElement ProviderID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pcpLookup-txt-providerId']")); } }
        public IWebElement ProviderFirst { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pcpLookup-txt-providerFirst']")); } }
        public IWebElement ProviderLast { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pcpLookup-txt-providerLast']")); } }
        public IWebElement ProviderName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pcpLookup-txt-providerName']")); } }
        public IWebElement PCPLookupReset { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pcpLookup-btn-reset']")); } }
        public IWebElement PCPLookupSearch { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pcpLookup-btn-search']")); } }
        public IWebElement PCPLoookupGrid { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='lookup-grid-searchresult']")); } }
        public IWebElement PCPLoookBackToRecord { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pcpLookup-txt-backToRecord']")); } }
        public IWebElement topFiftyPaging { get { return Browser.Wd.FindElement(By.Id("topFiftyPaging")); } }
        public IWebElement PCPLoookPageSize { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pcpLookup-txt-pageSize']")); } }
        public IWebElement PCPLookupPaginationNext { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='topFiftyPaging']/li[3]/a")); } }
     


    }

    [Binding]
    public class HCCLookUp
    {
        public IWebElement HCCName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hcclookup-txt-HccName']")); } }
        public IWebElement HCCDescription { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hcclookup-txt-HccDescription']")); } }
        public IWebElement HCCPaymentYear { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hcclookup-slct-PaymentYear']")); } }
        public IWebElement HCCSearchButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hcclookup-btn-Search']")); } }
        public IWebElement HCCResetButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hcclookup-btn-Reset']")); } }
        public IWebElement HCCLoookupGrid { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hcclookup-grid-ResultGrid']")); } }
        public IWebElement HCCLoookupTitle { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccLookup-title-searchCriteria']")); } }
        public IWebElement HCCLoookupPageSize { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hcclookup-txt-PageSize']")); } }
        public IWebElement HCCBackToRecord { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hccLookup-img-BackToRecord']")); } }

        public IWebElement HCCLookupPaginationFirst { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='hccLookupGird']//a[@title='Go to the first page']")); } }
        public IWebElement HCCLookupPaginationPrevious { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='hccLookupGird']//a[@title='Go to the previous page']")); } }
        public IWebElement HCCLookupPaginationNext { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='hccLookupGird']//a[@title='Go to the next page']")); } }
        public IWebElement HCCLookupPaginationLast { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='hccLookupGird']//a[@title='Go to the last page']")); } }

        



    }

    public class RXHCCLookUp
    {
        public IWebElement RXHCCName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rxhcclookup-txt-rxhccName']")); } }
        public IWebElement RXHCCDescription { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rxhcclookup-txt-rxhccDescription']")); } }
        public IWebElement RXHCCPaymentYear { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rxhcclookup-slct-rxhccPaymentYear']")); } }
        public IWebElement RXHCCPaymentYearDrpdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[id='PaymentYear']")); } }
        public IWebElement RXHCCSearchButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rxhcclookup-btn-rxhccSearch']")); } }
        public IWebElement RXHCCResetButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rxhcclookup-btn-rxhccReset']")); } }
        public IWebElement RXHCCLoookupGrid { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rxhcclookup-grid-ResultGrid']")); } }
        public IWebElement topFiftyPaging { get { return Browser.Wd.FindElement(By.Id("RxhccPaging")); } }
        public IWebElement RXHCCLoookupBackToRecord { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rxhcclookup-img-BackToRecord']")); } }
        public IWebElement RxHCCLoookupTitle { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rxhcclookup-title-searchCriteria']")); } }
        public IWebElement RxHCCLoookupPageSize { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rxhcclookup-txt-rxhccPagesize']")); } }

        public IWebElement RXHCCLookupPaginationFirst { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='RxhccPaging']/li[1]/a")); } }
        public IWebElement RXHCCLookupPaginationPrevious { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='RxhccPaging']/li[2]/a")); } }
        public IWebElement RXHCCLookupPaginationNext { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='RxhccPaging']/li[3]/a")); } }
        public IWebElement RXHCCLookupPaginationLast { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='RxhccPaging']/li[4]/a")); } }
        public IWebElement RXHCCLookupPagination { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rxhcclookup-page-rxhccPagination']")); } }




    }
    public class HICLookUp
    {
        public IWebElement HICTitle { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Member Search Criteria')]")); } }
        public IWebElement HIC { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberlookup-txt-Hic']")); } }
        public IWebElement MemberID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberlookup-txt-memberId']")); } }
        public IWebElement LastName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberlookup-txt-LastName']")); } }
        public IWebElement FirstName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberlookup-txt-FirstName']")); } }
        public IWebElement HICBackToRecord { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberlookup-img-BackToRecord']")); } }
        public IWebElement HICSearch { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberlookup-btn-Search']")); } }
        public IWebElement HICReset { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberlookup-btn-Reset']")); } }
        public IWebElement HICResultGrid { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberlookup-grid-memberResultGrid']")); } }
        public IWebElement pageSizeTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberlookup-txt-PageSize']")); } }
        public IWebElement HICLookupPaginationFirst { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='MemberPaging']/li[1]/a")); } }
        public IWebElement HICLookupPaginationPrevious { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='MemberPaging']/li[2]/a")); } }
        public IWebElement HICLookupPaginationNext { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='MemberPaging']/li[3]/a")); } }
        public IWebElement HICLookupPaginationLast { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='MemberPaging']/li[4]/a")); } }
        public IWebElement HICLookupPagination { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberlookup-Page-Pagination']")); } }
        public IWebElement hicLookupGird { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberlookup-grid-ResultGrid']")); } }
        public IWebElement topFiftyPaging { get { return Browser.Wd.FindElement(By.XPath("//a[@title='Go to the first page']")); } }
        public IWebElement HCILookupPagenumber { get { return Browser.Wd.FindElement(By.XPath("//div[@id='MemberPopUp']//span[@class='pull-left ng-binding']")); } }
        
    }
    public class SCCLookUp
    {

        public IWebElement SCCTitle { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='scclookup-title-sccSearch']")); } }
        public IWebElement SCC { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='scclookup-txt-Scc']")); } }
        public IWebElement CountyName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='scclookup-txt-County']")); } }
        public IWebElement StateName { get { return Browser.Wd.FindElement(By.CssSelector("input[test-id='scclookup-txt-StateName']")); } }
        public IWebElement SCCBackToRecord { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='scclookup-txt-BackToRecod']")); } }
        public IWebElement SCCSearch { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='scclookup-btn-Search']")); } }
        public IWebElement SCCReset { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='scclookup-btn-Reset']")); } }
        public IWebElement sccLookupGird { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='sccLookupGird']")); } }
        public IWebElement topFiftyPaging { get { return Browser.Wd.FindElement(By.Id("topFiftyPaging")); } }
        public IWebElement sccText { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='sccLookupGird']")); } }
        public IWebElement CountyText { get { return Browser.Wd.FindElement(By.CssSelector("input[test-id='scclookup-txt-County']")); } }
        public IWebElement StateNameText { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='scclookup-lbl-StateName']")); } }
        public IWebElement sccLoookupGrid { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='scclookup-grid-sccResultGrid']")); } }
        public IWebElement sccpageSizeTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='scclookup-txt-PageSize']")); } }
        public IWebElement SCCLookupPaginationFirst { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='sccLookupPaging']/li[1]/a")); } }
        public IWebElement SCCLookupPaginationPrevious { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='sccLookupPaging']/li[2]/a")); } }
        public IWebElement SCCLookupPaginationNext { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='sccLookupPaging']/li[3]/a")); } }
        public IWebElement SCCLookupPaginationLast { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='sccLookupPaging']/li[4]/a")); } }


    }

    [Binding]
    public class OtherReport
    {
        public IWebElement DataLoadSummaryLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Data Load Summary']")); } }
        public IWebElement BeginDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='BeginDate']")); } }
        public IWebElement EndDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='EndDate']")); } }

    }

    [Binding]
    public class RiskAssessmentReport
    {
        public IWebElement RiskScoreEstimatedReceivablePartDLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Risk Score Estimated Receivable - Part D']")); } }
        public IWebElement RiskAdjustmentProfileLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Risk Adjustment Profile']")); } }
        public IWebElement RiskScoreEstimatedReceivableLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Risk Score Estimated Receivable']")); } }
        public IWebElement DiagnosisAlertDetailsPartCLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Diagnosis Alert Details PartC']")); } }
    }

    [Binding]
    public class RiskScoreTrendReport
    {
        public IWebElement RiskScoreTrendLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Risk Score Trend']")); } }
        public IWebElement RiskScoreTrendPartDLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Risk Score Trend - Part D']")); } }
        public IWebElement RiskScoreTrendPCPLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Risk Score Trend PCP']")); } }
        public IWebElement RiskScoreTrendPCPPartDLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Risk Score Trend PCP - Part D']")); } }
        public IWebElement RiskScoreTrendDetailsLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Risk Score Trend Details']")); } }
        public IWebElement RiskScoreCalculationDetailsLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Risk Score Calculation Details']")); } }
        public IWebElement RiskScoreCalculationDetailsPartDLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Risk Score Calculation Details - Part D']")); } }
        public IWebElement RiskScoreTrendDetailsPartDLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Risk Score Trend Details - Part D']")); } }
    }


    [Binding]
    public class HCCRxHCCReport
    {
        public IWebElement HCCDiscrepancyLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='HCC Discrepancy']")); } }
        public IWebElement HCCDetailsLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='HCC Details']")); } }
        public IWebElement HCCBeneficiariesLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='HCC Beneficiaries']")); } }
        public IWebElement CMSHCCDiseaseGroupPrevelanceLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='CMS HCC Disease Group Prevalence']")); } }
        public IWebElement CMSRXDiseaseGroupPrevelanceLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='CMS RX HCC Disease Group Prevalence']")); } }
        public IWebElement MemberMissingHCCLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Member Missing HCC']")); } }
        public IWebElement MemberMissingRXHCCLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Member Missing RX HCC']")); } }
        public IWebElement RXHCCBeneficiariesLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='RX HCC Beneficiaries']")); } }
        public IWebElement HCCDetailsBlendedLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='HCC Details Blended']")); } }


    }
    [Binding]
    public class HCCDiscrepancy
    {
        public IWebElement DiscrepancyType { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='DISCRP_TYPE']")); } }
        public IWebElement planID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PLAN_ID']")); } }
        public IWebElement PaymentYear { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id='PAY_YEAR']")); } }
        public IWebElement PBP { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PBP']")); } }
        public IWebElement ResubmitStatus { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ResubmitStatus']")); } }
        public IWebElement YearType { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='YEAR_TYPE']")); } }
        public IWebElement SortBy { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='sort']")); } }
        public IWebElement Enrollment { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='MONTH_ID']")); } }
        public IWebElement RaftType { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='RaftType']")); } }
        public IWebElement RunReport { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-runReport']")); } }
        public IWebElement ResetReport { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-reset']")); } }
    }

    //Risk Score Trend PCP - Part D
    [Binding]
    public class RiskScoreTrendPCPPartD
    {
        
        public IWebElement reportTitle { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-title-searchCriteria']")); } }
        public IWebElement planID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PLAN_ID']")); } }
        public IWebElement PaymentYear { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PAY_YEAR']")); } }
        public IWebElement PBP { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PBP']")); } }
        public IWebElement YearType { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='YEAR_TYPE']")); } }
        public IWebElement Enrollment { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='MONTH_ID']")); } }
        public IWebElement groupIDLookup { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='GROUP']")); } }
        public IWebElement SCCLookup { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='SCC_ID']")); } }
        public IWebElement PCPLookup { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PCP_ID']")); } }
        public IWebElement RunReport { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-runReport']")); } }
        public IWebElement ResetReport { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-reset']")); } }
    }
    [Binding]
    public class HCCDetails
    {
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PLAN_ID']")); } }
        public IWebElement PBP { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PBP']")); } }
        public IWebElement PaymentYear { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PAY_YEAR']")); } }
        public IWebElement YearType { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='YEAR_TYPE']")); } }
        public IWebElement GroupID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='GROUP']")); } }
        public IWebElement PCPID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PCP_ID']")); } }
        public IWebElement RAFT { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='RAFT']")); } }
        public IWebElement RiskType { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='RISK']")); } }
        public IWebElement SortBy { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='sort']")); } }
        public IWebElement SCC { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='SCC_ID']")); } }
        public IWebElement HCC { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='HCC_ID']")); } }
       
        public IWebElement Enrollment { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Month_ID']")); } }
        public IWebElement RXHCC { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='RX_HCC_ID']")); } }
        public IWebElement RunReport { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-runReport']")); } }
        public IWebElement ResetReport { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-reset']")); } }
    }
    public class HCCBeneficiaries
    {
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='<<TBD>>']")); } }
        public IWebElement PaymentYear { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PAY_YEAR']")); } }
        public IWebElement YearType { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='YEAR_TYPE']")); } }
        public IWebElement GroupID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='GROUP']")); } }
        public IWebElement PBP { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PBP']")); } }
        public IWebElement RunReport { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-runReport']")); } }
        public IWebElement ResetReport { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-reset']")); } }
    }
    //public IWebElement GroupIDLookup { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-link-group']")); } }

    [Binding]
    public class ReportCommanComponant
    {
        public IWebElement RunReport { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-runReport']")); } }
        public IWebElement ResetReport { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-reset']")); } }
        public IWebElement RunInteractiveNo { get { return Browser.Wd.FindElement(By.Id("lblInteractiveNo")); } }
        public IWebElement RunInteractiveYes { get { return Browser.Wd.FindElement(By.Id("lblInteractiveYes'")); } }
        public By ReportMainViewBy { get { return By.Id("ReportViewerControl_fixedTable"); } }
        public IWebElement SaveFormatXLS { get { return Browser.Wd.FindElement(By.Id("1")); } }
        public IWebElement SaveFormatCSV { get { return Browser.Wd.FindElement(By.Id("2")); } }
        public IWebElement SaveFormatPDF { get { return Browser.Wd.FindElement(By.Id("3")); } }
    }

    [Binding]
    public class RiskAdjustmentProfile
    {
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PLAN_ID']")); } }
        public IWebElement PaymentYear { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PAY_YEAR']")); } }
        public IWebElement GroupID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='GROUP']")); } }
        public IWebElement PCPID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PCP_ID']")); } }
        public IWebElement RiskType { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='RISK']")); } }
        public IWebElement PBP { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PBP']")); } }
        public IWebElement RunReportButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-runReport']")); } }
        public IWebElement ResetReportButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-reset']")); } }
    }
    public class RiskScoreTrendDetails
    {
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PLAN_ID']")); } }
        public IWebElement YearType { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='YEAR_TYPE']")); } }
        public IWebElement PaymentYear { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PAY_YEAR']")); } }
        public IWebElement RAFT { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='RAFT']")); } }
        public IWebElement GroupID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='GROUP']")); } }
        public IWebElement PCPID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PCP_ID']")); } }
        public IWebElement HIC { get { return Browser.Wd.FindElement(By.XPath("(//tags-input[@test-id='txtHICN']//span)[1]")); } }
        public IWebElement PBP { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PBP']")); } }
        public IWebElement SortBy { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='sort']")); } }
        public IWebElement Enrollment { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Month_ID']")); } }
        public IWebElement RunReportButton { get { return Browser.Wd.FindElement(By.CssSelector("button[test-id='report-btn-runReport']")); } }
        public IWebElement ResetReportButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-reset']")); } }
    }
    public class CMSHCCDiseaseGroupPrevelance
    {
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PLAN_ID']")); } }
        public IWebElement PlanIDdefaultvalue { get { return Browser.Wd.FindElement(By.XPath(".//multiselect[@test-id='PLAN_ID']//button[contains(.,'All')]")); } }
        public IWebElement PBPdefaultvalue { get { return Browser.Wd.FindElement(By.XPath(".//multiselect[@test-id='PBP']//button[contains(.,'All')]")); } }
        public IWebElement PaymentYear { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PAY_YEAR']")); } }
        public IWebElement YearType { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='YEAR_TYPE']")); } }
        public IWebElement GroupID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='GROUP']")); } }
        public IWebElement PCPID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PCP_ID']")); } }
        public IWebElement PBP { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PBP']")); } }
        public IWebElement SCC { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='SCC_ID']")); } }
        public IWebElement RunReport { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-runReport']")); } }
        public IWebElement ResetReport { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-reset']")); } }
        public IWebElement paymentYearLable { get { return Browser.Wd.FindElement(By.XPath(".//label[contains(.,'Payment Year')]")); } }
        public IWebElement paymentYearText { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PAY_YEAR']")); } }
        public IWebElement yearTypeLable { get { return Browser.Wd.FindElement(By.XPath(".//label[contains(.,'Year Type')]")); } }
        public IWebElement yearTypeText { get { return Browser.Wd.FindElement(By.XPath("//multiselect[@test-id='YEAR_TYPE']//button[contains(.,'All')]")); } }
        public IWebElement sccLable { get { return Browser.Wd.FindElement(By.XPath("[//label[conatins(.,'SCC ID')]")); } }
        public IWebElement sccText { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMemberDiscrepancy-txt-scc']")); } }
        public IWebElement sscreportLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-link-ssc']")); } }
        public IWebElement groupreportLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-link-group']")); } }
        public IWebElement pcpreportLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-link-pcp']")); } }

    }
    public class CMSHCCRXDiseaseGroupPrevelance
    {
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='<<TBD>>']")); } }
        public IWebElement PaymentYear { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PAY_YEAR']")); } }
        public IWebElement YearType { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='YEAR_TYPE']")); } }
        public IWebElement GroupID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='GROUP']")); } }
        public IWebElement PCPID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PCP_ID']")); } }
        public IWebElement PBP { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PBP']")); } }
        public IWebElement SCC { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='SCC_ID']")); } }
        public IWebElement RunReport { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-runReport']")); } }
        public IWebElement ResetReport { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-reset']")); } }
    }
    public class MemberMissingHCC
    {
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='<<TBD>>']")); } }
        public IWebElement GroupID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='GROUP']")); } }
        public IWebElement PaymentYearType { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PAY_YEAR']")); } }
        public IWebElement SortBy { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='sort']")); } }
        public IWebElement PBP { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PBP']")); } }
        public IWebElement PaymentYear { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PAY_YEAR']")); } }
        public IWebElement RunReport { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-runReport']")); } }
        public IWebElement ResetReport { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-reset']")); } }
    }

    public class MemberMissingRXHCC
    {
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='<<TBD>>']")); } }
        public IWebElement GroupID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='GROUP']")); } }
        public IWebElement PaymentYearType { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PAY_YEAR']")); } }
        public IWebElement SortBy { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='sort']")); } }
        public IWebElement PBP { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PBP']")); } }
        public IWebElement RunReport { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-runReport']")); } }
        public IWebElement ResetReport { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-reset']")); } }
    }

    [Binding]
    public class RiskScoreEstimatedReceivable
    {
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PLAN_ID']")); } }
        public IWebElement PaymentYear { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PAY_YEAR']")); } }
        public IWebElement Enrollment { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='MONTH_ID']")); } }
        public IWebElement RunReportButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-runReport']")); } }
        public IWebElement ResetReportButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-reset']")); } }
        public IWebElement SelectedPlanID { get { return Browser.Wd.FindElement(By.XPath("//div[contains(.,'Plan ID')]/select/option[@selected='selected']")); } }
        public IWebElement SelectedPaymentYear { get { return Browser.Wd.FindElement(By.XPath("//div[contains(.,'Payment Year')]/select/option[@selected='selected']")); } }
        public IWebElement PlanIDonReport { get { return Browser.Wd.FindElement(By.XPath("//table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[1]/td[5]/table/tbody/tr/td/div")); } }
        public IWebElement PaymentYearonReport { get { return Browser.Wd.FindElement(By.XPath("//table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[1]/td[6]/table/tbody/tr/td/div")); } }
    }

    public class RXHCCBeneficiaries
    {
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='<<TBD>>']")); } }
        public IWebElement PaymentYear { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PAY_YEAR']")); } }
        public IWebElement PBP { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PBP']")); } }
        public IWebElement YearType { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='YEAR_TYPE']")); } }
        public IWebElement GroupID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='GROUP']")); } }
        public IWebElement RunReport { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-runReport']")); } }
        public IWebElement ResetReport { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-reset']")); } }
    }
    public class HCCDetailsBlended
    {
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PlanID']")); } }
        public IWebElement PaymentYear { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PaymentYear']")); } }
        public IWebElement SortBy { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='SortBy']")); } }
        public IWebElement PBP { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PBP']")); } }
        public IWebElement YearType { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='YearType']")); } }
        public IWebElement RunReport { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-runReport']")); } }
        public IWebElement ResetReport { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-reset']")); } }
    }


    [Binding]
    public class RiskScoreEstimatedReceivablePartD
    {
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='<<TBD>>']")); } }
        public IWebElement PaymentYear { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PAY_YEAR']")); } }

        public IWebElement RunReportButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-runReport']")); } }
        public IWebElement ResetReportButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-reset']")); } }

    }


    [Binding]
    public class DiagnosisAlertDetailsPartC
    {
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='<<TBD>>']")); } }
        public IWebElement PaymentYear { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PAY_YEAR']")); } }
        public IWebElement PCPID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PCP_ID']")); } }
        public IWebElement HIC { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='HCC_ID']")); } }
        public IWebElement RunReportButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-runReport']")); } }
        public IWebElement ResetReportButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-reset']")); } }

    }


    [Binding]
    public class DataLoadSummary
    {
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='<<TBD>>']")); } }
        public IWebElement BeginDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='BeginDate']")); } }
        public IWebElement EndDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='EndDate']")); } }
        public IWebElement SortType { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Sort']")); } }
        public IWebElement RunReportButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-runReport']")); } }
        public IWebElement ResetReportButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-reset']")); } }

    }

    [Binding]
    public class RSMDashboard
    {


        public IWebElement FRMRiskscorecutoverperiodTable { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id='dashBoard-div-workflowTrackingPartCdata']")); } }
        public IWebElement PaymentYearDropdown { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rsmDashboard-slct-paymentYear']")); } }
        public IWebElement rsmDashboardtitle { get { return Browser.Wd.FindElement(By.XPath("//div[@class='flex-fill']/div[contains(.,'Dashboard')]")); } }
        public IWebElement YearTypeDropdown { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rsmDashboard-slct-yearType']")); } }
        public IWebElement TrendPartCButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rsmDashboard-btn-trendPartC']")); } }
        public IWebElement TrendPartDButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rsmDashboard-btn-trendPartD']")); } }
        public IWebElement EstimatedPartCButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rsmDashboard-btn-estimatedPartC']")); } }
        public IWebElement EstimatedPartDButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rsmDashboard-btn-estimatedPartD']")); } }
        public IWebElement EnrollMonthsText { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rsmDashboard-span-enrollMonths']")); } }
        public IWebElement CutoffDatesText { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rsmDashboard-span-cutOffDates']")); } }
        public IWebElement CurrentMinimumEnrollmentMonths { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='rsmDashboard-span-enrollMonths']/strong")); } }
        public IWebElement CutoffdatesTable { get { return Browser.Wd.FindElement(By.XPath("//table[@class='table table-bordered table-hover table-condensed table-striped col-lg-12 col-md-12 col-sm-12 col-xs-12 marginBottom0']")); } }
        public IWebElement RiskScoreTrendDetailsGraph { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rsmDashboard-cnvs-trendChart']")); } }
        public IWebElement RiskScoreEstimatedReceivableGraph { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rsmDashboard-cnvs-estimatedReceivableChart']")); } }
        public IWebElement FRMenrolledMonthsRiskCalculationLabel { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='mainContant']//label[starts-with(.,'FRM enrolled months risk calculation')]")); } }
        public IWebElement FRMenrolledMonthsRiskCalculationText { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rsmDashboard-span-enrollMonths']")); } }
        public IWebElement FRMenrolledMonthsRiskCalculationTextValue { get { return Browser.Wd.FindElement(By.XPath("//span[@test-id='rsmDashboard-span-enrollMonths']//strong")); } }
        public IWebElement FRMRiskScorecutoverPeriodLabel { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='mainContant']//label[starts-with(.,'FRM Risk score cutover period')]")); } }
        
    }

    [Binding]

    public class CMSSweepsRiskCutOverDates
    {
        public IWebElement PageTitle { get { return Browser.Wd.FindElement(By.CssSelector("span.padding0")); } }
        public IWebElement SweepsDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rsmSweepsRisk-txt-transEnd']")); } }
        public IWebElement DateType { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'CMS Sweeps/ Risk Cut Over Dates:')]")); } }
        
        public IWebElement RiskScoreCutOverDates { get { return Browser.Wd.FindElement(By.XPath(".//input[@test-id='rsmSweepsRisk-rd-riskCutoverDate']//following-sibling::label//span")); } }
        public IWebElement RiskScorePaymentYear { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Payment Year')]")); } }
        public IWebElement SweepsPaymentYear { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Year Type')]")); } }
        public IWebElement SweepsYearType { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rsmSweepsRisk-slct-yearType']")); } }
        public IWebElement SweepsEndDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rsmSweepsRisk-txt-transEnd']")); } }
        public IWebElement SweepsEndDateText { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Sweeps End Date')]")); } }
        public IWebElement SweepsReset { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rsmSweepsRisk-btn-reset1']")); } }
        public IWebElement SweepsSave { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rsmSweepsRisk-btn-save1']")); } }
        public IWebElement RiskScoreSave { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rsmSweepsRisk-btn-save2']")); } }
        public IWebElement RiskScoreReset { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rsmSweepsRisk-btn-reset2']")); } }
        //public IWebElement FiscalLabel { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rsmSweepsRisk-txt-startDateFiscal']")); } }
        public IWebElement FiscalStartDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rsmSweepsRisk-txt-startDateFiscal']")); } }
        public IWebElement FiscalEndDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rsmSweepsRisk-txt-endDateFiscal']")); } }
        public IWebElement CalendarStartDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rsmSweepsRisk-txt-startDateCalendar']")); } }
        public IWebElement CalendarEndDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rsmSweepsRisk-txt-endDateCalendar']")); } }
        public IWebElement FinalStartDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rsmSweepsRisk-txt-startDateFinal']")); } }
        public IWebElement FinalEndDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rsmSweepsRisk-txt-endDateFinal']")); } }

    }

    [Binding]

    public class Admininistration
    {
        public IWebElement SweepsRiskCutOverDatessubmenu { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Sweeps/ Risk Cut Over Dates')]")); } }
        public IWebElement ArchiveSubmenu { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Archive')]")); } }
        public IWebElement EditMinimumEnrollMonthsSubmenu { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Minimum Enroll Months')]")); } }

    }



    [Binding]
    public class RSMHomePage
    {
        public IWebElement RSMExpandMenu { get { return Browser.Wd.FindElement(By.CssSelector("button[test-id='header-btn-expanMenu']")); } }
        public IWebElement RSMApplicationTitle { get { return Browser.Wd.FindElement(By.XPath("//div[contains(.,'Risk Score Manager')]")); } }
        public IWebElement RSMHeading { get { return Browser.Wd.FindElement(By.XPath("//div[contains(.,'Risk Score Manager')]")); } }
        public IWebElement ViewRSM { get { return Browser.Wd.FindElement(By.CssSelector("[title='Main']")); } }
        public IWebElement Reports { get { return Browser.Wd.FindElement(By.CssSelector("[title='Reports']")); } }
        public IWebElement Administration { get { return Browser.Wd.FindElement(By.CssSelector("[title='Administration']")); } }
        public IWebElement Dashboard { get { return Browser.Wd.FindElement(By.CssSelector("[title='Dashboard']")); } }
        public IWebElement ReportManager { get { return Browser.Wd.FindElement(By.CssSelector("[title='Report Manager']")); } }
        public IWebElement FileProcessing { get { return Browser.Wd.FindElement(By.CssSelector("[title='File Processing Status']")); } }

        public IWebElement FileProcessing1 { get { return Browser.Wd.FindElement(By.CssSelector("a[title='Job Processing Status']")); } }
        public IWebElement ProductMenudrpdown { get { return Browser.Wd.FindElement(By.CssSelector("button[test-id='menu-btn-productDetails']")); } }
        public IWebElement ProductMenudrpdownText { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='menu-btn-productDetails'] span:nth-of-type(1)")); } }        
        public IWebElement ProductMenuApplicationDetails { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='header-dropdown-informationDetails '] li")); } }
        public IWebElement ProfileInfolink { get { return Browser.Wd.FindElement(By.CssSelector("button[test-id='header-txt-profileInfo']")); } }
        public IWebElement Logout { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='header-btn-logout']")); } }
        public IWebElement Information { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='header-btn-information']")); } }
        public IWebElement Help { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='header-page-content-btn-help']")); } }
        public IWebElement GeneralSearchSearchResults { get { return Browser.Wd.FindElement(By.XPath("//div[@class='grid ui-grid ng-isolate-scope']")); } }
        public IWebElement InformationLastLogin { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='header-dropdown-lastLogin']")); } }
        public IWebElement InformationDatabase { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='header-dropdown-database']")); } }
        public IWebElement MemberDiscrepancy { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Member Discrepancy')]")); } }
        public IWebElement MemberHCCDetail { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Member HCC Details')]")); } }
        public IWebElement RSMMemberHCCExtract { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'RSM Member HCC Extract')]")); } }




    }
}



