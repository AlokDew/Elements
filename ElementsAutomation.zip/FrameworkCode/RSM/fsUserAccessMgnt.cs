﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using TechTalk.SpecFlow;

namespace TMSoR1
{
    [Binding]
    class fsUserAccessMgnt
    {
        [Given(@"Verify ""(.*)"" labels with icon ""(.*)""")]
        public void GivenVerifyLabelsWithIcon(string menu, string status)
        {
            tmsWait.Hard(5);
            try 
            {
                if (status.ToLower().Equals("is displayed"))
                    Assert.IsTrue(Browser.Wd.FindElement(By.CssSelector("[title= '" + menu + "']")).Displayed, menu + " is displayed");
                else
                    Assert.IsFalse(Browser.Wd.FindElement(By.CssSelector("[title= '" + menu + "']")).Displayed, menu + " is displayed");
            }
            catch (Exception ex)
            {
                fw.ConsoleReport(menu + " is not displayed on home page.");
            }
        }


        [When(@"I expand Menu grid")]
        public void WhenIExpandMenuGrid()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='header-btn-expanMenu']")));
            tmsWait.Hard(1);
        }




        [Given(@"Verify under ""(.*)"" labels submenu should be displayed")]
        public void GivenVerifyUnderLabelsSubmenuShouldBeDisplayed(string menu)
        {
            switch (menu.ToLower())
            {
                case "administration":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("li>a[title='" + menu + "']")));
                    Assert.IsTrue(Browser.Wd.FindElement(By.CssSelector("li>a[title='Sweeps/ Risk Cut Over Dates']")).Displayed, "Sweeps/ Risk Cut Over Dates submenu is not displayed.");
                    // Assert.IsTrue(Browser.Wd.FindElement(By.CssSelector("li>a[title='Archive']")).Displayed, "Archive submenu is not displayed.");
                    Assert.IsTrue(Browser.Wd.FindElement(By.CssSelector("li>a[title='Minimum Enroll Months']")).Displayed, "Minimum Enroll Months submenu is not displayed.");
                    break;
                case "main":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='" + menu + "']")));
                    Assert.IsTrue(Browser.Wd.FindElement(By.CssSelector("[title='Member Discrepancy']")).Displayed, "Member Discrepancy submenu is not displayed.");
                    Assert.IsTrue(Browser.Wd.FindElement(By.CssSelector("[title='Member HCC Details']")).Displayed, "Member HCC Details submenu is not displayed.");
                    Assert.IsTrue(Browser.Wd.FindElement(By.CssSelector("[title='RSM Member HCC Extract']")).Displayed, "RSM Member HCC Extract submenu is not displayed.");
                    break;
            }
        }

        [When(@"""(.*)"" submenu option under Administration menu is clicked")]
        public void WhenSubmenuOptionUnderAdministrationMenuIsClicked(string menu)
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + menu + "')]")));
            tmsWait.Hard(10);
        }

        [Then(@"Verify RSM Member HCC Extract page displayed Default values")]
        public void ThenVerifyRSMMemberHCCExtractPageDisplayedDefaultValues()
        {
            tmsWait.Hard(3);
            IWebElement plan = Browser.Wd.FindElement(By.CssSelector("[test-id='hccExtract-slct-planID']"));
            IWebElement pay = Browser.Wd.FindElement(By.CssSelector("[test-id='hccExtract-slct-paymentYear']"));
            string finalPlan = new SelectElement(plan).SelectedOption.Text;
            string finalYear = new SelectElement(pay).SelectedOption.Text;

            string initPlan = GlobalRef.PLAN1.ToString();
                 string initYear = GlobalRef.PAYYEAR1.ToString();

            Assert.AreEqual(initPlan, finalPlan, " Both plan values are not matching");
            Assert.AreEqual(initYear, finalYear, " Both Pay year values are not matching");
        }


        [Then(@"Verify View RSM page Plan ID drop down is displayed")]
        public void ThenVerifyViewRSMPagePlanIDDropDownIsDisplayed()
        {
            IWebElement element = Browser.Wd.FindElement(By.CssSelector("[test-id='hccExtract-slct-planID']"));
            bool elementDisplay = element.Displayed;
            Assert.IsTrue(elementDisplay, " Expected Element is not displayed");
        }

        [Then(@"Verify View RSM page Payment Year drop down is displayed")]
        public void ThenVerifyViewRSMPagePaymentYearDropDownIsDisplayed()
        {
            IWebElement element = Browser.Wd.FindElement(By.CssSelector("[test-id='hccExtract-slct-paymentYear']"));
            bool elementDisplay = element.Displayed;
            Assert.IsTrue(elementDisplay, " Expected Element is not displayed");
        }

        [Then(@"Verify View RSM page Reset button is displayed")]
        public void ThenVerifyViewRSMPageResetButtonIsDisplayed()
        {
            IWebElement element = Browser.Wd.FindElement(By.CssSelector("[test-id='hccExtract-btn-Reset']"));
            bool elementDisplay = element.Displayed;
            Assert.IsTrue(elementDisplay, " Expected Element is not displayed");
        }

        [Then(@"Verify View RSM page Export button is displayed")]
        public void ThenVerifyViewRSMPageExportButtonIsDisplayed()
        {
            IWebElement element = Browser.Wd.FindElement(By.CssSelector("[test-id='hccExtract-lbl-Export']"));
            bool elementDisplay = element.Displayed;
            Assert.IsTrue(elementDisplay, " Expected Element is not displayed");
        }
        [When(@"Verify View RSM page Reset button is Clicked")]
        public void WhenVerifyViewRSMPageResetButtonIsClicked()
        {
            IWebElement element = Browser.Wd.FindElement(By.CssSelector("[test-id='hccExtract-btn-Reset']"));
            fw.ExecuteJavascript(element);
        }



        [When(@"CMS Sweeps Risk Cut Over Dates page Payment Year drop down list is set to ""(.*)""")]
        public void WhenCMSSweepsRiskCutOverDatesPagePaymentYearDropDownListIsSetTo(string p0)
        {
            By Drp = By.XPath("//*[@test-id='rsmSweepsRisk-slct-paymentYear']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + p0 + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
        }

        [When(@"CMS Sweeps Risk Cut Over Dates page Year Type drop down list is set to ""(.*)""")]
        public void WhenCMSSweepsRiskCutOverDatesPageYearTypeDropDownListIsSetTo(string p0)
        {
            By Drp = By.XPath("//*[@test-id='rsmSweepsRisk-slct-yearType']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + p0 + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
        }

        [When(@"CMS Sweeps Risk Cut Over Dates page Risk Cut Over Dates Payment Year drop down list is set to ""(.*)""")]
        public void WhenCMSSweepsRiskCutOverDatesPageRiskCutOverDatesPaymentYearDropDownListIsSetTo(string p0)
        {
            IWebElement element = Browser.Wd.FindElement(By.CssSelector("[test-id='rsmSweepsRisk-slct-paymentYear1']"));
            new SelectElement(element).SelectByText(p0);
        }


        [When(@"CMS Sweeps Risk Cut Over Dates page Save button is Clicked")]
        public void WhenCMSSweepsRiskCutOverDatesPageSaveButtonIsClicked()
        {
            tmsWait.Hard(5);
            IWebElement element = Browser.Wd.FindElement(By.CssSelector("[test-id='rsmSweepsRisk-btn-save1']"));
            fw.ExecuteJavascript(element);


        }

        [Then(@"CMS Sweeps Risk Cut Over Dates page Save button is Clicked and Verify error message ""(.*)""")]
        public void ThenCMSSweepsRiskCutOverDatesPageSaveButtonIsClickedAndVerifyErrorMessage(string p0)
        {
            tmsWait.Hard(1);
            IWebElement element = Browser.Wd.FindElement(By.CssSelector("[test-id='rsmSweepsRisk-btn-save1']"));
            //fw.ExecuteJavascript(element);
            element.Click();

            By toastMsg = By.XPath("//div[@class='k-notification-content']");
            string actValue = Browser.Wd.FindElement(toastMsg).Text;
            Assert.IsTrue(actValue.Contains(p0));
        }


        [When(@"CMS Sweeps Risk Cut Over Dates page Risk Cut Over Dates Save button is Clicked")]
        public void WhenCMSSweepsRiskCutOverDatesPageRiskCutOverDatesSaveButtonIsClicked()
        {
            tmsWait.Hard(7);
            IWebElement element = Browser.Wd.FindElement(By.CssSelector("[test-id='rsmSweepsRisk-btn-save2']"));
            fw.ExecuteJavascript(element);
        }


        [Then(@"Verify CMS Sweeps Risk Cut Over Dates page displayed error message as ""(.*)""")]
        public void ThenVerifyCMSSweepsRiskCutOverDatesPageDisplayedErrorMessageAs(string p0)
        {
            tmsWait.Hard(1);

            IWebElement element = Browser.Wd.FindElement(By.XPath("//div[contains(.,'" + p0 + "')]"));
            bool display = element.Displayed;
            Assert.IsTrue(display, p0 + " is not getting displayed");
        }

        [When(@"CMS Sweeps Risk Cut Over Dates page Risk Cut Over Dates Fiscal year End Date is set to ""(.*)""")]
        public void WhenCMSSweepsRiskCutOverDatesPageRiskCutOverDatesFiscalYearEndDateIsSetTo(string p0)
        {
            IWebElement element = Browser.Wd.FindElement(By.CssSelector("[test-id='rsmSweepsRisk-txt-endDateFiscal']"));
            tmsWait.Hard(2);
            element.Clear();
            tmsWait.Hard(2);
            element.SendKeys(p0);
        }

        [When(@"CMS Sweeps Risk Cut Over Dates page Risk Cut Over Dates Calendar year End Date is set to ""(.*)""")]
        public void WhenCMSSweepsRiskCutOverDatesPageRiskCutOverDatesCalendarYearEndDateIsSetTo(string p0)
        {
            IWebElement element = Browser.Wd.FindElement(By.CssSelector("[test-id='rsmSweepsRisk-txt-endDateCalendar']"));
            tmsWait.Hard(2);
            element.Clear();
            tmsWait.Hard(2);
            element.SendKeys(p0);
        }


        [When(@"CMS Sweeps Risk Cut Over Dates page Sweeps End Date is set to ""(.*)""")]
        public void WhenCMSSweepsRiskCutOverDatesPageSweepsEndDateIsSetTo(string p0)
        {
            IWebElement element = Browser.Wd.FindElement(By.CssSelector("[test-id='rsmSweepsRisk-txt-transEnd']"));
            tmsWait.Hard(2);
            element.Clear();
            tmsWait.Hard(2);
            element.SendKeys(p0);
        }


        [When(@"CMS Sweeps Risk Cut Over Dates page ""(.*)"" Option button is Clicked")]
        public void WhenCMSSweepsRiskCutOverDatesPageOptionButtonIsClicked(string button)
        {
            IWebElement element;
            if (button.Equals("Sweeps Date"))
            {
                element = Browser.Wd.FindElement(By.CssSelector("[test-id='rsmSweepsRisk-rd-sweepsDate']"));
                fw.ExecuteJavascript(element);

            }
            else if (button.Equals("RiskScoreCutOverDates"))
            {
                element = Browser.Wd.FindElement(By.XPath("//label[@for='rdbtnRisk']"));
                fw.ExecuteJavascript(element);
            }
        }


        [Then(@"Verify on RSM Member Discrepancy page is displayed")]
        public void ThenVerifyOnRSMMemberDiscrepancyPageIsDisplayed()
        {
            tmsWait.Hard(5);
            IWebElement title = Browser.Wd.FindElement(By.XPath("(//div[contains(.,'Member Discrepancy')])[4]"));
            Assert.IsTrue(title.Text.Contains("Member Discrepancy"), " Page Title mismatched.");
        }


        [Then(@"Verify on RSM ""(.*)"" page is displayed")]
        public void ThenVerifyOnRSMPageIsDisplayed(string title)
        {
            tmsWait.Hard(4);
            if (title.Equals("Member HCC Details Information"))
            {
                String actual = Browser.Wd.FindElement(By.XPath("(//div[contains(.,'Member HCC Details')])[4]")).Text;
                Assert.AreEqual(title, actual, "Title is not getting matched");
            }
            else if (title.Equals("RSM Member HCC Extract"))
            {
                String actual = Browser.Wd.FindElement(By.XPath("(//div[contains(.,'RSM Member HCC Extract')])[4]")).Text;
                Assert.AreEqual(title, actual, "Title is not getting matched");
            }
            else {
                Assert.IsTrue(RSM.CMSSweepsRiskCutOverDates.PageTitle.Text.Contains(title), "Title mismatched.");
            }
        }


        [Then(@"Verify RSM ""(.*)"" page is displayed")]
        public void ThenVerifyRSMPageIsDisplayed(string p0)
        {
            tmsWait.Hard(4);
            // IWebElement element = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]"));
            IWebElement element = Browser.Wd.FindElement(By.XPath("(//div[contains(.,'" + p0 + "')])[4]"));
            Assert.IsTrue(element.Displayed, p0 + "is not getting displayed");

        }

        [Then(@"Verify RSM Main ""(.*)"" page is displayed")]
        public void ThenVerifyRSMMainPageIsDisplayed(string p0)
        {
            tmsWait.Hard(4);
            IWebElement element = Browser.Wd.FindElement(By.XPath("(//div[contains(.,'" + p0 + "')])[4]"));
            string el = element.Text;
            tmsWait.Hard(1);
            Assert.IsTrue(element.Displayed, "is not getting displayed");
        }


    }
}

