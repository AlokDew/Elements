﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
//using System.Windows.Forms;
using System.Collections.ObjectModel;
using Microsoft.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Data;
using System.Collections;
using TMSoR1.FrameworkCode;

namespace TMSoR1
{
    [Binding]
    class fsRSMLogin

    {
        public static string GeneratedUserID;
        public string downloadPath = System.IO.Path.Combine(Environment.ExpandEnvironmentVariables("%userprofile%"), "Downloads");
        public HCCDetails ReportName { get; private set; }

        [Given(@"TMS RSM Application Home section is Clicked")]
        public void GivenTMSRSMApplicationHomeSectionIsClicked()
        {
            tmsWait.Hard(2);
            FRM.FRMAdministrator.FRMHomemenu.Click();
            tmsWait.Hard(2);

        }

        /*[Then(@"Verify TMS ""(.*)"" page is displayed")]
        public void ThenVerifyTMSPageIsDisplayed(string p0)
        {
            tmsWait.Hard(5);
            string expected = p0.ToString();
            string actual = RSM.RSMHomePage.RSMHeading.Text;

            Assert.AreEqual(expected, actual, " Both values are getting matched");
        }*/

        [When(@"Administration page Minimum Enroll Months section New Minimum Enrollment Months dropdown value is set to ""(.*)""")]
        public void WhenAdministrationPageMinimumEnrollMonthsSectionNewMinimumEnrollmentMonthsDropdownValueIsSetTo(string p0)
        {
            By Drp = By.XPath("//*[@test-id='rsmMinEnroll-slct-months']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + p0 + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
        }

        [When(@"Administration page Minimum Enroll Months section Apply button is Clicked")]
        public void WhenAdministrationPageMinimumEnrollMonthsSectionApplyButtonIsClicked()
        {
            fw.ExecuteJavascript(RSM.MinimumEnrollMonths.ApplyButton);
        }

        [Then(@"Verify Administration page Minimum Enroll Months section Current Minimum Enrollment Months value is set to ""(.*)""")]
        public void ThenVerifyAdministrationPageMinimumEnrollMonthsSectionCurrentMinimumEnrollmentMonthsValueIsSetTo(string expectedMon)
        {
            tmsWait.Hard(5);
          Assert.AreEqual(expectedMon,RSM.MinimumEnrollMonths.CurrentMinimumEnrollmentMonths.Text, expectedMon+" Month is not getting displayed");
        }


        [When(@"Administration section ""(.*)"" submenu is Clicked")]
        public void WhenAdministrationSectionSubmenuIsClicked(string p0)
        {
            string adminsubmenu = p0.ToString();
            switch (adminsubmenu)
            {
                case "Minimum Enroll Months":
                    fw.ExecuteJavascript(RSM.Admininistration.EditMinimumEnrollMonthsSubmenu);
                    tmsWait.Hard(3);
                    break;
                case "Archive":
                    fw.ExecuteJavascript(RSM.Admininistration.ArchiveSubmenu);
                    tmsWait.Hard(3);
                    break;
                case "Sweeps Risk Cut Over Dates":
                    fw.ExecuteJavascript(RSM.Admininistration.SweepsRiskCutOverDatessubmenu);
                    tmsWait.Hard(3);
                    break;
            }
        }

        [Then(@"Verify Administration page ""(.*)"" section ""(.*)"" dropdown is displayed")]
        public void ThenVerifyAdministrationPageSectionDropdownIsDisplayed(string p0, string p1)
        {
            tmsWait.Hard(5);
            string page = p0.ToString();
            string component = p1.ToString();

            switch(page) // This case for Page handling
            {
                case "Minimum Enroll Months":

                    switch(component) //  This case for Component handling
                    {
                        case "New Minimum Enrollment Months":
                            By Drp = By.XPath("//*[@test-id='rsmMinEnroll-slct-months']//span[@class='k-select']");
                            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                            tmsWait.Hard(3);
                            break;                       
                    }

                    break;

            }
           
        }

        [Then(@"Verify Dashboard page Current Minimum Enrollment Months value is set to ""(.*)""")]
        public void ThenVerifyDashboardPageCurrentMinimumEnrollmentMonthsValueIsSetTo(string expMonth)
        {
            tmsWait.Hard(5);
            Assert.AreEqual(expMonth, RSM.RSMDashboard.CurrentMinimumEnrollmentMonths.Text, expMonth + " is not getting displayed");
        }


        [Then(@"Verify Administration page Minimum Enroll Months section New Minimum Enrollment Months dropdown has data ""(.*)""")]
        public void ThenVerifyAdministrationPageMinimumEnrollMonthsSectionNewMinimumEnrollmentMonthsDropdownHasData(string dropdownvalues)
        {
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='rsmMinEnroll-slct-months']//span[@class='k-select']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
        }




        [Then(@"Verify Administration page ""(.*)"" section ""(.*)"" button is displayed")]
        public void ThenVerifyAdministrationPageSectionButtonIsDisplayed(string p0, string p1)
        {

            string page = p0.ToString();
            string component = p1.ToString();

            switch (page) // This case for Page handling
            {
                case "Minimum Enroll Months":

                    switch (component) //  This case for Component handling
                    {
                        case "Apply":
                            Assert.IsTrue(RSM.MinimumEnrollMonths.ApplyButton.Displayed, component + " is not getting displayed");

                            break;
                    }

                    break;

            }
        }

        [When(@"View RSM section ""(.*)"" submenu is Clicked")]

        public void WhenViewRSMSectionSubmenuIsClicked(string p0)
        {
            string viewrsmsubmenu = p0.ToString();
            switch(viewrsmsubmenu)
            {
                case "Member Discrepancy":
                    fw.ExecuteJavascript(RSM.RSMHomePage.MemberDiscrepancy);
                    break;
                case "Member HCC Detail":
                    fw.ExecuteJavascript(RSM.RSMHomePage.MemberHCCDetail);
                    break;
                case "RSM Member HCC Extract":
                    fw.ExecuteJavascript(RSM.RSMHomePage.RSMMemberHCCExtract);
                    break;

            }
        }


        [Then(@"Verify RSM Member HCC Extract page Plan ID field displays ""(.*)""")]
        public void ThenVerifyRSMMemberHCCExtractPagePlanIDFieldDisplays(string p0)
        {
            string arrPlanID = p0.ToString();
            string[] expPlanIDs = arrPlanID.Split(',');
            List<string> actPlanIDlists = new List<string>();

            IWebElement planID = Browser.Wd.FindElement(By.Id("drpPlanId"));
            IList<IWebElement> drp = planID.FindElements(By.TagName("option"));
          foreach(IWebElement ele in drp)
            {

                actPlanIDlists.Add(ele.Text);
            }
            string[] actPlanIDs = actPlanIDlists.ToArray();

            var results = expPlanIDs.Except(actPlanIDs);
            if(results.Count()==0)
             {
                Assert.IsTrue(true," Expected Plan ID is not getting matched with Actual Plan ID's");

            }
            else
            {
                Assert.Fail(" Expected Plan ID is not getting matched with Actual Plan ID's");

            }

        }

        [Then(@"Verify RSM Member HCC Extract page Payment Year field displays ""(.*)""")]
        public void ThenVerifyRSMMemberHCCExtractPagePaymentYearFieldDisplays(string p0)
        {
          
            List<Int32> expyearsList = new List<Int32>();
         
            DateTime thisyear = DateTime.Now;
          int current=Convert.ToInt32(thisyear.Year);

           for(int i=0;i<3;i++)
            {
                expyearsList.Add(current);
                current=current - 1;

            }
            Int32[] expyears = expyearsList.ToArray();

            List<Int32> actYearlists = new List<Int32>();
            IWebElement years = Browser.Wd.FindElement(By.Id("drpPaymentYear"));
            IList<IWebElement> drp = years.FindElements(By.TagName("option"));
            foreach (IWebElement ele in drp)
            {

                actYearlists.Add(Convert.ToInt32(ele.Text));
            }
            Int32[] actYears = actYearlists.ToArray();

            var results = actYears.Except(expyears);
            if (results.Count() == 0)
            {
                Assert.IsTrue(true," Expected Plan ID is not getting matched with Actual Plan ID's");

            }
            else
            {
                Assert.Fail(" Expected Plan ID is not getting matched with Actual Plan ID's");

            }

        }


        [Then(@"Verify Member HCC Details Information page ""(.*)"" field is set to ""(.*)""")]
        public void ThenVerifyMemberHCCDetailsInformationPageFieldIsSetTo(string p0, string p1)
        {
            string fieldname = p0.ToString();
            string expvalue = p1.ToString();
            string actualvalue = null;
            bool elementpresence = false;

            switch (fieldname)
            {
                case "HICN":
                     actualvalue = RSM.MemberHCCDetai.HICN.Text;
                    Assert.AreEqual(expvalue, actualvalue, "Both values not getting matched");
                    break;

                case "Member ID":
                   actualvalue = RSM.MemberHCCDetai.MemberID.Text;
                    Assert.AreEqual(expvalue, actualvalue, "Both values not getting matched");
                    break;

                case "Year Type":
                    elementpresence = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@id='hccDetailYearType']//span[contains(.,'" + expvalue + "')]")).Displayed;
                    Assert.IsTrue(elementpresence, "Element is not present");
                    break;

                case "Year":
                    elementpresence = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@id='hccDetailYear']//span[contains(.,'" + expvalue + "')]")).Displayed;
                    Assert.IsTrue(elementpresence, "Element is not present");
                    break;
            }

        }

        [When(@"Member HCC Details Information page ""(.*)"" field is set to ""(.*)""")]
        public void WhenMemberHCCDetailsInformationPageFieldIsSetTo(string p0, string p1)
        {
            string fieldname = p0.ToString();
            //string value = p1.ToString();
            string value = tmsCommon.GenerateData(p1);


            switch (fieldname)
            {
                case "Member ID":
                    RSM.MemberHCCDetai.MemberID.SendKeys(value);
                    break;
                case "Year":
                    //if (value.ToString().Equals("Current Year-1"))
                    //{
                    //   var year = (DateTime.Today.Year - 1).ToString();

                    //    By DrpY = By.XPath("//label[text()='Year']/parent::div//span[@class='k-select']");
                    //    By typeappY = By.XPath("//li[text()='" + value + "']");

                    //    UIMODUtilFunctions.clickOnWebElementUsingLocators(DrpY);
                    //    tmsWait.Hard(3);
                    //    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeappY);

                    //    //new SelectElement(RSM.MemberHCCDetai.Year).SelectByText(year);
                        
                    //}

                    By Drp1 = By.XPath("//label[text()='Year']/parent::div//span[@class='k-select']");
                    By typeapp1 = By.XPath("//li[text()='" + value + "']");
                    fw.ExecuteJavascript(Browser.Wd.FindElement(Drp1));
                    fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp1));
                    tmsWait.Hard(3);



                    break;

                case "Year Type":
                    //By Drp = By.XPath("//label[contains(.,'Year Type')]/parent::div//span[@class='k-select']");
                    //By typeapp = By.XPath("//li[text()='" + value + "']");

                    //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    //tmsWait.Hard(3);
                    //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

                    By Drp = By.XPath("//label[contains(.,'Year Type')]/parent::div//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + value + "']");
                    fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                    fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                    tmsWait.Hard(3);
                    break;
            }
           
        }


        [Then(@"Verify Member HCC Details Information page Demographic HCCs on File for Member table has row")]
        public void ThenVerifyMemberHCCDetailsInformationPageDemographicHCCsOnFileForMemberTableHasRow(Table table)
        {


            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;            
                
                //Get the table object again, since the page refreshes we need to get it fresh
                      IWebElement baseTable = RSM.MemberHCCDetai.DemographicHCCsonFileforMemberTable;
                IWebElement paginationSystem = RSM.MemberHCCDetai.DemographicHCCsonFileforMemberPagination;

               

                //Look for a next page link.  We will set 'last page of records' here also.
                //thisTP.LoadNextPageLink(baseTable);
                thisTP.LoadDIVNextPageLink(paginationSystem, "pagination-next ng-scope");

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                //   thisTP.LoadPageTable(baseTable, "td", "td");
                thisTP.LoadRSMApplicationTable(baseTable, "ui-grid-row", "ui-grid-cell", "Demographic HCCs on File for Member");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 2)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[2];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = RSM.MemberHCCDetai.DemographicHCCsonFileforMemberTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }



        }

        public void ClickonElement(string Explink, ReadOnlyCollection<IWebElement> ActLink)
        {

            string[] Explinkcollection = Explink.Split(',');

            for (int i = 0; i < Explinkcollection.Length; i++)
            {
                foreach (IWebElement link in ActLink)
                {
                    Browser.Wd.FindElement(By.LinkText(link.Text)).Click();
                    tmsWait.Hard(10);
                    if (Browser.Wd.FindElement(By.XPath("//span[contains(.,'Drill Down - Clinical')]")).Text.Contains("Drill Down - Clinical"))
                    {
                        //GeneratedUserID = tmsCommon.GenerateData(PlanHCC);
                        fw.setVariable("PlanHCC", link.Text);
                        break;
                    }
                    else {
                        Assert.Fail("Hyperlink is not clickable and does not display title for model pop");
                    }
                   
                   
                }
            }

        }

        public void CheckClickableElement(string Explink, ReadOnlyCollection<IWebElement> ActLink)
        {
            string[] Explinkcollection = Explink.Split(',');
           
            for (int i=0;i< Explinkcollection.Length;i++)
            {
                foreach (IWebElement link in ActLink)
                {
                    if (Explinkcollection[i].Equals(link.Text))
                    {
                        Console.WriteLine(Explinkcollection[i]+" value is found");

                        bool clickable = Browser.Wd.FindElement(By.LinkText(Explinkcollection[i].ToString())).Displayed;
                        Assert.IsTrue(clickable, Explinkcollection[i] + " is not Clickable");
                        Console.WriteLine(Explinkcollection[i] + " Element is Clickable");
                        break;
                    }
                }
            }
        }

        [Then(@"Verify RSM Application RAPS Drill Down page ""(.*)"" button is displayed")]
        public void ThenVerifyRSMApplicationRAPSDrillDownPageButtonIsDisplayed(string p0)
        {
            string component = p0.ToString();
            switch(component)
            {
                case "Back to Record":

                    Assert.IsTrue(RSM.RAPSDrilldown.BackToRecord.Displayed, component + " is not getting displayed");
                    break;
                case "Close":

                    Assert.IsTrue(RSM.RAPSDrilldown.Close.Displayed, component + " is not getting displayed");
                    break;
            }
        }


        [Then(@"Verify RSM Application displays page Title as ""(.*)"" with HCC ""(.*)""")]
        public void ThenVerifyRSMApplicationDisplaysPageTitleAsWithHCC(string p0, string p1)
        {

        tmsWait.Hard(3);
            string HCC= tmsCommon.GenerateData(p1);
            string expTitle = p0.ToString();
            bool title = Browser.Wd.FindElement(By.XPath("//span[contains(.,'"+expTitle+"')]")).Displayed;
            //string actTitle = Browser.Wd.FindElement(By.XPath(".//div[@id='clinicalInfo']/clinical-drill-down-data/div/div/div[1]/div/div/div/span[2]")).Text;         
            Assert.IsTrue(title, " Title is not getting displayed");
        }

        [Then(@"Verify RSM Application RAPS Drill Down Clinical table has row")]
        public void ThenVerifyRSMApplicationRAPSDrillDownClinicalTableHasRow(Table table)
        {


            tmsWait.Hard(10);
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = RSM.MemberHCCDetai.RAPSDrillDownClinicalTable;
                    

                //Look for a next page link.  We will set 'last page of records' here also.
                //            thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.loadRSMAngularTable(baseTable);

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 2)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[2];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                //else
                //{
                //    //Click next page link and start over.
                //    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                //    {
                //        thisTP.bNotAtLastPageOfRecords = true;
                //        thisTP.NPL.Click();
                //        tmsWait.Hard(2);
                //    }
                //}
                baseTable = RSM.MemberHCCDetai.RAPSDrillDownClinicalTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }



        }

        [Then(@"Verify Member HCC Details Information page Clinical HCCs on File for Member section CMS RX HCCs column ""(.*)"" data is Clicked")]
        public void ThenVerifyMemberHCCDetailsInformationPageClinicalHCCsOnFileForMemberSectionCMSRXHCCsColumnDataIsClicked(string p0)
        {
            tmsWait.Hard(2);
            IWebElement cmshcc = Browser.Wd.FindElement(By.XPath("(//a[@title='Prostate and Other Cancers and Tumors'])[2]"));
            fw.ExecuteJavascript(cmshcc);
            tmsWait.Hard(5);
        }

        [Then(@"Verify Member HCC Details Information page Clinical HCCs on File for Member section CMS HCCs column ""(.*)"" data is Clicked")]
        public void ThenVerifyMemberHCCDetailsInformationPageClinicalHCCsOnFileForMemberSectionCMSHCCsColumnDataIsClicked(string p0)
        {
            tmsWait.Hard(2);
            string hcc = tmsCommon.GenerateData(p0);
            IWebElement cmshcc = Browser.Wd.FindElement(By.XPath("(//a[contains(.,'"+ hcc + "')])[2]"));
            fw.ExecuteJavascript(cmshcc);
            tmsWait.Hard(5);
        }

        [Then(@"Verify Member HCC Details Information page Clinical HCCs on File for Member section Plan HCCs column ""(.*)"" data is Clicked")]
        public void ThenVerifyMemberHCCDetailsInformationPageClinicalHCCsOnFileForMemberSectionPlanHCCsColumnDataIsClicked(string p0)
        {
            tmsWait.Hard(2);
            IWebElement cmshcc = Browser.Wd.FindElement(By.XPath("(//a[text()='HCC18'])[1]"));
            fw.ExecuteJavascript(cmshcc);
            tmsWait.Hard(5);
        }

        [Then(@"Verify Member HCC Details Information page Clinical HCCs on File for Member section Plan RX HCCs column ""(.*)"" data is Clicked")]
        public void ThenVerifyMemberHCCDetailsInformationPageClinicalHCCsOnFileForMemberSectionPlanRXHCCsColumnDataIsClicked(string p0)
        {
            tmsWait.Hard(2);
            IWebElement cmshcc = Browser.Wd.FindElement(By.XPath("(//a[contains(.,'RXHCC14')])[1]"));
            fw.ExecuteJavascript(cmshcc);
            tmsWait.Hard(5);

        }


        [Then(@"Verify Member HCC Details Information page Clinical HCCs on File for Member section ""(.*)"" column ""(.*)"" data is Clicked")]
        public void ThenVerifyMemberHCCDetailsInformationPageClinicalHCCsOnFileForMemberSectionColumnDataIsClicked(string p0, string p1)
        {
            ReadOnlyCollection<IWebElement> planHCCsWebElement = null;
            string section = p0.ToString();
            string data = tmsCommon.GenerateData(p1);

            switch (section)
            {
                case "Plan HCCs":
                    // planHCCsWebElement = Browser.Wd.FindElements(By.XPath("(//kendo-grid[@test-id='clinicalHcc-grid']//tr//td[3]//a)[1]"));
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='clinicalHcc-grid']//tr//td[3]//a)[1]")));
                   
                    tmsWait.Hard(3);
                  
                    break;
                case "Plan RX HCCs":
                    
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='clinicalHcc-grid']//tr//td[5]//a)[1]")));

                    tmsWait.Hard(3);
                   
                    break;
                case "CMS HCCs":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='clinicalHcc-grid']//tr//td[7]//a")));

                    tmsWait.Hard(3);
                    
                    break;

                case "CMS RX HCCs":
                    
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='clinicalHcc-grid']//tr//td[9]//a")));
                    tmsWait.Hard(3);
                
                    break;
            }

            }

        [Then(@"Verify Member HCC Details Information page Clinical HCCs on File for Member section ""(.*)"" column ""(.*)"" data is Clickable")]
        public void ThenVerifyMemberHCCDetailsInformationPageClinicalHCCsOnFileForMemberSectionColumnDataIsClickable(string p0, string p1)
        {
            tmsWait.Hard(3);
            ReadOnlyCollection<IWebElement> planHCCsWebElement = null;
            string section = p0.ToString();
            string data = tmsCommon.GenerateData(p1);

            switch (section)
            {
                case "Plan HCCs":
                   // planHCCsWebElement = Browser.Wd.FindElements(By.XPath("(//kendo-grid[@test-id='clinicalHcc-grid']//tr//td[3]//a)[1]"));
                     fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='clinicalHcc-grid']//tr//td[3]//a)[1]")));
                    // ClickonElement(data, planHCCsWebElement);
                    // fw.ExecuteJavascript(planHCCsWebElement);

                    tmsWait.Hard(5);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'Back to Record')]")));
                    break;
                case "Plan RX HCCs":
                  // planHCCsWebElement = Browser.Wd.FindElements(By.XPath("(//kendo-grid[@test-id='clinicalHcc-grid']//tr//td[5]//a)[1]"));
                  //  ClickonElement(data, planHCCsWebElement);

                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='clinicalHcc-grid']//tr//td[5]//a)[1]")));

                    tmsWait.Hard(5);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'Back to Record')]")));
                    break;
                case "CMS HCCs":
                    //planHCCsWebElement = Browser.Wd.FindElements(By.XPath("//kendo-grid[@test-id='clinicalHcc-grid']//tr//td[7]//a"));
                    //ClickonElement(data, planHCCsWebElement);

                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='clinicalHcc-grid']//tr//td[7]//a")));

                    tmsWait.Hard(5);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'Back to Record')]")));
                    break;

                case "CMS RX HCCs":
                    //planHCCsWebElement = Browser.Wd.FindElements(By.XPath("//kendo-grid[@test-id='clinicalHcc-grid']//tr//td[9]//a"));
                    //ClickonElement(data, planHCCsWebElement);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='clinicalHcc-grid']//tr//td[9]//a")));
                    tmsWait.Hard(5);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'Back to Record')]")));
                    break;
            }
            tmsWait.Hard(1);
        }

        [Then(@"Verify Member HCC Details Information page displayed section Title as ""(.*)""")]
        public void ThenVerifyMemberHCCDetailsInformationPageDisplayedSectionTitleAs(string p0)
        {
            string expTitle = p0.ToString();
            
            bool presence = Browser.Wd.FindElement(By.XPath("//strong[contains(.,'" + expTitle + "')]")).Displayed;

            Assert.IsTrue(presence, "Expected Title is not gettign displayed");

            
        }

        [Then(@"Verify Member HCC Details Information page displayed ""(.*)"" section displayed Pagination")]
        public void ThenVerifyMemberHCCDetailsInformationPageDisplayedSectionDisplayedPagination(string p0)
        {
            string section = p0.ToString();

            switch(section)
            {
                case "Clinical HCCs on File for Member":
                    Assert.IsTrue(RSM.MemberHCCDetai.clinicalHccsonFileforMemberPagination.Displayed, section + " Pagination is not getting displayed ");
                    break;
            }

        
    }

        [Then(@"Verify Member HCC Details Information page ""(.*)"" section is displayed")]
        public void ThenVerifyMemberHCCDetailsInformationPageSectionIsDisplayed(string p0)
        {
            string expTitle = p0.ToString();

            bool presence = Browser.Wd.FindElement(By.XPath("//div[contains(text(),'Risk Score/Risk Adjustment Factor Type')]")).Displayed;
            Assert.IsTrue(presence, "Expected section is not getting displayed");

            //Assert.AreEqual(expTitle, RSM.MemberHCCDetai.RiskScoreRiskAdjustmentFactorTypTitle.Text, expTitle + " is not getting displayed");
        }

        [Then(@"Verify Member HCC Details Information page Risk Score Risk Adjustment Fator Type section Page size is set to ""(.*)""")]
        public void ThenVerifyMemberHCCDetailsInformationPageRiskScoreRiskAdjustmentFatorTypeSectionPageSizeIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string expectedSize = p0.ToString();

            Assert.AreEqual(expectedSize, RSM.MemberHCCDetai.RiskScoreRiskAdjustmentFactorTypePageSize.GetAttribute("value"), expectedSize + " is not getting displayed");


        }

        [Then(@"Verify Group Search Criteria lookup window has data and Selected")]
        public void ThenVerifyGroupSearchCriteriaLookupWindowHasDataAndSelected(Table table)
        {

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = RSM.Lookups.GroupIDLookUp.GroupLoookupGrid;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)

                thisTP.LoadGroupdSearchGrid(baseTable, "td", "td");
                //               Boolean bTransStatusMatching = false;
                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {

                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //if(AppTableRow.Equals(GherkinTableArray[iElementCounter])
                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (appTD.Equals("Canceled"))
                                //{

                                //    Assert.IsTrue(appTD.Equals("Canceled"));
                                //    bTransStatusMatching = true;
                                //    //Console.WriteLine("TC 61 status is found as Canceled");
                                //}

                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //    //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }


                        }

                    }
                    iTableCounter++;
                    //if (bTransStatusMatching)
                    //{
                    //    Console.WriteLine("Transaction status is updated to Canceled in Transaction History");
                    //}
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                //if (bTransStatusMatching)
                //{
                //    Console.WriteLine("Member Info page Transaction status is updated to Canceled in Transaction History table");
                //}

                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                //baseTable = EAM.MemberInformation.TransactionHistoryTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }


        }


        [Then(@"Verify Member Discrepancy page Search results table has data")]
        public void ThenVerifyMemberDiscrepancyPageSearchResultsTableHasData(Table table)
        {
            tmsWait.Hard(5);

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = RSM.MemberDiscrepancy.SearchResultsGrid;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                
                thisTP.LoadSearchGrid(baseTable, "td", "td");
                //               Boolean bTransStatusMatching = false;
                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {

                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //if(AppTableRow.Equals(GherkinTableArray[iElementCounter])
                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (appTD.Equals("Canceled"))
                                //{

                                //    Assert.IsTrue(appTD.Equals("Canceled"));
                                //    bTransStatusMatching = true;
                                //    //Console.WriteLine("TC 61 status is found as Canceled");
                                //}

                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //    //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }


                        }

                    }
                    iTableCounter++;
                    //if (bTransStatusMatching)
                    //{
                    //    Console.WriteLine("Transaction status is updated to Canceled in Transaction History");
                    //}
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                //if (bTransStatusMatching)
                //{
                //    Console.WriteLine("Member Info page Transaction status is updated to Canceled in Transaction History table");
                //}

                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                //baseTable = EAM.MemberInformation.TransactionHistoryTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }



        }

       

        [Then(@"Verify Group Search Criteria page Pagination is displayed")]
        public void ThenVerifyGroupSearchCriteriaPagePaginationIsDisplayed()
        {

            bool pagination = RSM.Lookups.GroupIDLookUp.GroupSearchPagination.Displayed;

            Assert.IsTrue(pagination, " Pagination is not getting displayed");
        }



        [When(@"Member HCC Details Information ""(.*)"" is Clicked")]
        public void WhenMemberHCCDetailsInformationIsClicked(string p0)
        {
            tmsWait.Hard(5);
            string field = p0.ToString();
            switch(field)
            {
                case "HICN Lookup":
                    tmsWait.Hard(5);
                    fw.ExecuteJavascript(RSM.MemberHCCDetai.HICNLookup);
                   // RSM.MemberHCCDetai.HICNLookup.Click();
                  
                    break;

                case "Reset":
                    fw.ExecuteJavascript(RSM.MemberHCCDetai.Reset);
                    tmsWait.Hard(5);
                    break;
                case "Search":
                    tmsWait.Hard(5);
                    fw.ExecuteJavascript(RSM.MemberHCCDetai.Search);
                   
                    break;
                case "Result Accordion":
                    fw.ExecuteJavascript(RSM.MemberHCCDetai.ResultAccordion);
                    tmsWait.Hard(5);
                    break;
                    
            }
            tmsWait.Hard(10);
        }

        [Then(@"Verify Member HCC Details Information page Clinical HCCs on File for Member table has row")]
        public void ThenVerifyMemberHCCDetailsInformationPageClinicalHCCsOnFileForMemberTableHasRow(Table table)
        {


            tmsWait.Hard(5);
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {

                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = RSM.MemberHCCDetai.clinicalHccsonFileforMember;
                IWebElement paginationSystem = RSM.MemberHCCDetai.clinicalHccsonFileforMemberPagination;

                //Look for a next page link.  We will set 'last page of records' here also.
                //thisTP.LoadNextPageLink(baseTable);
                thisTP.LoadDIVNextPageLink(paginationSystem, "pagination-next ng-scope");

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                //   thisTP.LoadPageTable(baseTable, "td", "td");
                thisTP.LoadRSMApplicationTable(baseTable, "ui-grid-row", "ui-grid-cell", "Clinical HCCs on File for Member");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 2)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[2];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                //else
                //{
                //    //Click next page link and start over.
                //    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                //    {
                //        thisTP.bNotAtLastPageOfRecords = true;
                //        thisTP.NPL.Click();
                //        tmsWait.Hard(2);
                //    }
                //}
                baseTable = RSM.MemberHCCDetai.clinicalHccsonFileforMember;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }


        }



        [Then(@"RSM Application Member Search Criteria table following data is Clicked")]
        public void ThenRSMApplicationMemberSearchCriteriaTableFollowingDataIsClicked(Table table)
        {
         


        //Create Storage for the Gherkin table and the page data
        GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = RSM.MemberHCCDetai.MemberSearchCriteriaTable;
                IWebElement paginationSystem = RSM.MemberHCCDetai.MemberSearchCriteriaPagination;

                //Look for a next page link.  We will set 'last page of records' here also.
                //thisTP.LoadNextPageLink(baseTable);
                thisTP.LoadDIVNextPageLink(paginationSystem, "pagination-next ng-scope");

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                //   thisTP.LoadPageTable(baseTable, "td", "td");
              //  thisTP.LoadRSMMemberSearchPageTable(baseTable, "ui-grid-row", "ui-grid-cell");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 2)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[2];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");


                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = FRM.FRMMainPage.GeneralSearchSearchResults;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }


        }
        public IWebElement RSMFirst, RSMPrevious, RSMNext, RSMLast = null;

        [Then(@"Verify RSM Application ""(.*)"" page Pagination ""(.*)"" link is ""(.*)""")]
        public void ThenVerifyRSMApplicationPagePaginationLinkIs(string section, string link, string status)
        {
            
          if (section.Equals("Demographic HCCs on File for Member"))
            {

                RSMFirst = Browser.Wd.FindElement(By.XPath("//ul[@test-id='Demographiclookup-Paging-Pagination']/li[1]/a"));
                RSMPrevious = Browser.Wd.FindElement(By.XPath("//ul[@test-id='Demographiclookup-Paging-Pagination']/li[2]/a"));
                RSMNext = Browser.Wd.FindElement(By.XPath("//ul[@test-id='Demographiclookup-Paging-Pagination']/li[3]/a"));
                RSMLast = Browser.Wd.FindElement(By.XPath("//ul[@test-id='Demographiclookup-Paging-Pagination']/li[4]/a"));
            }
            switch(link)
            {
                case "First":
                    if (status.Equals("Enabled"))
               
                        Assert.IsTrue(RSMFirst.Enabled, link + " is Disabled");
                
                    else if (status.Equals("Disabled"))

                        Assert.IsFalse(RSMFirst.Enabled, link + " is Enabled");
                    break;

                case "Next":
                    if (status.Equals("Enabled"))

                        Assert.IsTrue(RSMNext.Enabled, link + " is Disabled");

                    else if (status.Equals("Disabled"))

                        Assert.IsFalse(RSMNext.Enabled, link + " is Enabled");
                    break;

                case "Previous":
                    if (status.Equals("Enabled"))

                        Assert.IsTrue(RSMPrevious.Enabled, link + " is Disabled");

                    else if (status.Equals("Disabled"))

                        Assert.IsFalse(RSMPrevious.Enabled, link + " is Enabled");
                    break;
                case "Last":
                    if (status.Equals("Enabled"))

                        Assert.IsTrue(RSMLast.Enabled, link + " is Disabled");

                    else if (status.Equals("Disabled"))

                        Assert.IsFalse(RSMLast.Enabled, link + " is Enabled");
                    break;

            }
        }

        [Then(@"Verify RSM Application ""(.*)"" page Pagination is displayed")]
        public void ThenVerifyRSMApplicationPagePaginationIsDisplayed(string p0)
        {
         if(p0.ToString().Equals("Demographic HCCs on File for Member"))
            {
                bool pagination=RSM.MemberHCCDetai.DemographicHCCsonFileforMemberPagination.Displayed;
                Assert.IsTrue(pagination, p0 + "Pagination is not getting displayed");
            }
        }


        [Then(@"Verify Member HCC Details Information page Demographic HCCs on File for Member table has ""(.*)""")]
        public void ThenVerifyMemberHCCDetailsInformationPageDemographicHCCsOnFileForMemberTableHas(string field)
        {
            IWebElement element = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='demographic-grid-demographicGrid']//span[contains(.,'" + field + "')]"));
            Assert.IsTrue(element.Displayed,field+"is not displayed");
        }



        [Then(@"Verify Member HCC Details Information page Results section ""(.*)"" field is set to ""(.*)""")]
        public void ThenVerifyMemberHCCDetailsInformationPageResultsSectionFieldIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(3);
            string fieldname = p0.ToString();
            string expected = p1.ToString();
            string actual = null;

            switch (fieldname)
            {
                case "HICN":
                    actual = RSM.MemberHCCDetai.ResultSectionHICNvalue.Text;
                    Assert.AreEqual(expected,actual, expected + " field value is not displayed");
                    break;
                case "Member ID":
                    actual = RSM.MemberHCCDetai.ResultSectionMembervalue.Text;
                    Assert.AreEqual(expected, actual, expected + " field value is not displayed");
                    break;
                case "Last Name":
                    actual = RSM.MemberHCCDetai.ResultSectionLastNamevalue.Text;
                    Assert.AreEqual(expected, actual, expected + " field value is not displayed");
                    break;
                case "First Name":
                    actual = RSM.MemberHCCDetai.ResultSectionFirstNamevalue.Text;
                    Assert.AreEqual(expected, actual, expected + " field value is not displayed");
                    break;
                    
            }

        }


        [Then(@"Verify Member HCC Details Information page displays ""(.*)"" field as ""(.*)""")]
        public void ThenVerifyMemberHCCDetailsInformationPageDisplaysFieldAs(string p0, string p1)
        {
            tmsWait.Hard(5);
            string fieldname = p0.ToString();
            string expected = p1.ToString();
            string actual = null;
            bool elementpresence = false;

            switch (fieldname)
            {
                case "Title":
                    Assert.AreEqual(expected, RSM.MemberHCCDetai.Title.Text, expected + " Title is not displayed");
                    break;
                case "HICN":
                    Assert.IsTrue(RSM.MemberHCCDetai.HICN.Displayed, fieldname + " is not Displayed");
                    break;
                case "Member ID":
                    Assert.IsTrue(RSM.MemberHCCDetai.MemberID.Displayed, fieldname + " is not Displayed");
                    break;
                case "Year Type":
                    elementpresence = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@id='hccDetailYearType']//span[contains(.,'" + expected + "')]")).Displayed;
                    Assert.IsTrue(elementpresence, "Element is not present");
                    break;
                case "Year":
                    elementpresence = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@id='hccDetailYear']//span[contains(.,'" + expected + "')]")).Displayed;
                    Assert.IsTrue(elementpresence, "Element is not present");
                    break;
                case "Reset":
                    Assert.IsTrue(RSM.MemberHCCDetai.Reset.Displayed, fieldname + " value is not Displayed");
                    break;

                case "HICN Lookup":
                    Assert.IsTrue(RSM.MemberHCCDetai.Search.Displayed, fieldname + " value is not Displayed");
                    break;
            }
        }
        
        public ArrayList ExecuteSQLQueryUsingSQL2017(string sqlString, string DB_NAME)
        {


            
            SqlConnection DBConn;
            SqlDataAdapter adapter;
            DataSet ds = new DataSet();
            int i = 0, j = 0;
            ArrayList list = new ArrayList();
            try
            {
                //string thisConnectionString = null;
                //thisConnectionString = "user id=pdmadmin;" +
                //       "password=pdmrox;" +
                //       "Server=" + ConfigFile.DataServer + ";" +
                //       "Trusted_Connection = yes; " +
                //       "database=" + DB_NAME + "; " +
                //       "connection timeout=30";

                string thisConnectionString = "server=" + ConfigFile.DataServer + ";" + "database=" + DB_NAME + ";" + "user id=" + ConfigFile.DBUser + ";" + "password=" + ConfigFile.DBPassword + ";" + "Max Pool Size=9000;" + "Connection Timeout=150;" + "Min Pool Size=2";
                DBConn = new SqlConnection(thisConnectionString);
                DBConn.Open();
                adapter = new SqlDataAdapter(sqlString, DBConn);
                adapter.Fill(ds);
                //Console.Write(ds.Tables.Count);
                //Console.Write(ds.Tables[0].ToString());
                Console.Write(" Column Count "+ds.Tables[0].Columns.Count);
                Console.Write(" Row Count " + ds.Tables[0].Rows.Count);

                //DBConn.Close();
                for (i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                {
                    //Console.WriteLine(ds.Tables[0].Rows[i].ItemArray.GetValue(0).ToString());
                    for (j = 0; j <= ds.Tables[0].Rows[i].ItemArray.Count() - 1; j++)
                    {
                        list.Add(ds.Tables[0].Rows[i].ItemArray[j].ToString());
                    }
                }

            }
            catch (Exception e)
            {
                Console.WriteLine("Failed read record: [" + e + "] Query [" + sqlString + "]");
            }
            return list;

        }

        public ArrayList ExecuteSQLQuery(string sqlString, string DB_NAME)
        {

          
            string thisConnectionString = null;
            SqlConnection DBConn;
            SqlDataAdapter adapter;
            DataSet ds = new DataSet();
            int i = 0,j=0;
            ArrayList list = new ArrayList();
            try
            {
                 
                 thisConnectionString = "user id="+ ConfigFile.DBUser+ ";" +
                           "password="+ ConfigFile.DBPassword + ";" +
                           "Server=" + ConfigFile.DataServer + ";" +
                           "Trusted_Connection = yes; " +
                           "database=" + DB_NAME + "; " +
                           "connection timeout=30";
                DBConn = new SqlConnection(thisConnectionString);
                DBConn.Open();
                adapter = new SqlDataAdapter(sqlString, DBConn);
                adapter.Fill(ds);
               // Console.Write(ds.Tables.Count);
               // Console.Write(ds.Tables[0].ToString());
                //Console.Write(ds.Tables[0].Columns.Count);
                // Console.Write(ds.Tables[0].Rows.Count);
               
                DBConn.Close();
                for (i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                {
                    //Console.WriteLine(ds.Tables[0].Rows[i].ItemArray.GetValue(0).ToString());
                    for (j = 0; j <= ds.Tables[0].Rows[i].ItemArray.Count() - 1; j++)
                    {
                        list.Add(ds.Tables[0].Rows[i].ItemArray[j].ToString());
                    }
                }
            
            }
            catch (Exception e)
            {
                Console.WriteLine("Failed read record: [" + e + "] Query [" + sqlString + "]");
            }
            return list;

        }

     
        public Dictionary<int, string[]> ExecuteSingleQuery(string SqlString, string DB_NAME, int numberOfColumn)
        {
            Dictionary<int, string[]> table = new Dictionary<int, string[]>();
            SqlCommand thisCommand = null;
            
            List<string> list = new List<string>();
            try { 
            SqlConnection DBConn = new SqlConnection();
            //string thisConnectionString = "user id=tmsservice;" +
            //           "password=TriZetto456;" +
            //           "Server="+ConfigFile.DataServer+";" +
            //           "Trusted_Connection = yes; "+
            //           "database=" +DB_NAME+"; " +
            //           "connection timeout=30";



                string thisConnectionString = "server=" + ConfigFile.DataServer + ";" + "database=" + DB_NAME + ";" + "user id=" + ConfigFile.DBUser + ";" + "password=" + ConfigFile.DBPassword + ";" + "Max Pool Size=9000;" + "Connection Timeout=150;" + "Min Pool Size=2";
                DBConn.ConnectionString = thisConnectionString;
            DBConn.Open();
             thisCommand = new SqlCommand(SqlString, DBConn);
                SqlDataReader reader = thisCommand.ExecuteReader();
                int numberOfRows = (reader.FieldCount + 1) / numberOfColumn;
                    if (reader.HasRows)
                    {
                        int j = 0;
                        while (reader.Read())
                        {
                            
                            list.Clear();
                           for (int i = 0; i < numberOfColumn; i++)
                                list.Add(reader.GetValue(i).ToString());
                            List<string> copyList = list;
                            table.Add(j, copyList.ToArray());
                            
                            j++;
                        }
                }
                DBConn.Close();
            } 
            catch (Exception e)
                    {
                Assert.IsTrue(true,"Failed read record: [" + e + "] Query [" + SqlString + "]");
            }           
            return table;

}
        [When(@"TMS RSM Application Administration Section is Clicked")]
        public void WhenTMSRSMApplicationAdministrationSectionIsClicked()
        {
            fw.ExecuteJavascript(RSM.RSMHomePage.Administration);
            tmsWait.Hard(2);
        }

        [Then(@"Verify Dashboard page FRM Risk score cutover period table has data")]
        public void ThenVerifyDashboardPageFRMRiskScoreCutoverPeriodTableHasData(Table table)
        {


            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = RSM.RSMDashboard.CutoffdatesTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");
                //               Boolean bTransStatusMatching = false;
                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {

                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //if(AppTableRow.Equals(GherkinTableArray[iElementCounter])
                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (appTD.Equals("Canceled"))
                                //{

                                //    Assert.IsTrue(appTD.Equals("Canceled"));
                                //    bTransStatusMatching = true;
                                //    //Console.WriteLine("TC 61 status is found as Canceled");
                                //}

                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //    //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }


                        }

                    }
                    iTableCounter++;
                    //if (bTransStatusMatching)
                    //{
                    //    Console.WriteLine("Transaction status is updated to Canceled in Transaction History");
                    //}
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                //if (bTransStatusMatching)
                //{
                //    Console.WriteLine("Member Info page Transaction status is updated to Canceled in Transaction History table");
                //}

                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                //baseTable = EAM.MemberInformation.TransactionHistoryTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }


        }

        [Then(@"Verify Dashboard page Year Type dropdown list has data ""(.*)"" by Executing SQL Query")]
        public void ThenVerifyDashboardPageYearTypeDropdownListHasDataByExecutingSQLQuery(string yeartype)
        {
            string[] expValues = yeartype.Split(',');

        }


        [Then(@"Verify Dashboard page Year Type dropdown list has data ""(.*)""")]
        public void ThenVerifyDashboardPageYearTypeDropdownListHasData(string year)
        {
          
            
            SelectElement drp = new SelectElement(RSM.RSMDashboard.YearTypeDropdown);

            IList<IWebElement> actValues = drp.AllSelectedOptions;

            string[] expValues = year.Split(',');

            foreach (IWebElement actual in actValues)
            {
                foreach (string exp in expValues)
                {
                    if (exp.Equals(actual.Text))
                    {
                        Console.WriteLine(exp + " value is present on Drop down liast");
                    }
                }
            }

        }


        [Then(@"Verify Dashboard page ""(.*)"" graph is displayed")]
        public void ThenVerifyDashboardPageGraphIsDisplayed(string graph)
        {
            switch(graph)
            {
                case "Risk Score Trend Details":
                   
                    Assert.IsTrue(RSM.RSMDashboard.RiskScoreTrendDetailsGraph.Displayed, graph + " is not geting displayed");
                    break;
                case "Risk Score Estimated Receivable":
                   
                    Assert.IsTrue(RSM.RSMDashboard.RiskScoreEstimatedReceivableGraph.Displayed, graph + " is not geting displayed");
                    break;
            }
            

        }

        [Then(@"Verify File Processing page ""(.*)"" field is displayed")]
        public void ThenVerifyFileProcessingPageFieldIsDisplayed(string p0)
        {
            tmsWait.Hard(1);
            IWebElement element = Browser.Wd.FindElement(By.XPath("//kendo-grid//th[contains(.,'" + p0+"')]"));
            bool actualResults = element.Displayed;

            Assert.IsTrue(actualResults, p0 + "is not getting displayed");
        }
        [Then(@"Verify Job Processing page ""(.*)"" field is displayed")]
        public void ThenVerifyJobProcessingPageFieldIsDisplayed(string p0)
        {
            tmsWait.Hard(1);
            IWebElement element = Browser.Wd.FindElement(By.XPath("//th[.='" + p0 + "']"));
            bool actualResults = element.Displayed;

            Assert.IsTrue(actualResults, p0 + "is not getting displayed");
        }


        [Then(@"Verify Report Manager page Report Name drop down list is displayed")]
        public void ThenVerifyReportManagerPageReportNameDropDownListIsDisplayed()
        {
            tmsWait.Hard(1);
            IWebElement element = Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='reportManager-select-multiSelectReports']"));
            bool actualResults = element.Displayed;

            Assert.IsTrue(actualResults,"Expected element is not getting displayed");
        }

        [Then(@"Verify Report Manager page ""(.*)"" button is displayed")]
        public void ThenVerifyReportManagerPageButtonIsDisplayed(string p0)
        {
            tmsWait.Hard(1);
            IWebElement element = Browser.Wd.FindElement(By.XPath("//button[contains(.,'"+p0+"')]"));
            bool actualResults = element.Displayed;

            Assert.IsTrue(actualResults, p0 + "is not getting displayed");
        }

        [Then(@"Verify Report Manager page Plan ID drop down list is displayed")]
        public void ThenVerifyReportManagerPagePlanIDDropDownListIsDisplayed()
        {
            tmsWait.Hard(1);
            IWebElement element = Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='reportManager-select-multiSelectPlans']"));
            bool actualResults = element.Displayed;

            Assert.IsTrue(actualResults, "Expected element is not getting displayed");
        }

        [Then(@"Verify Report Manager page Start Date is displayed")]
        public void ThenVerifyReportManagerPageStartDateIsDisplayed()
        {
            tmsWait.Hard(1);
            IWebElement element = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@id='txtStartDate']"));
            bool actualResults = element.Displayed;

            Assert.IsTrue(actualResults, "Expected element is not getting displayed");
        }

        [When(@"TMS RSM Application ""(.*)"" Section is Clicked")]
        [When(@"TMS EAM Application ""(.*)"" Section is Clicked")]
        public void WhenTMSRSMApplicationSectionIsClicked(string p0)
        {
            string section = p0.ToString();

            switch (section.ToUpper())
            {
                case "MAIN":
                    fw.ExecuteJavascript(RSM.RSMHomePage.ViewRSM);               
                    tmsWait.Hard(2);
                    break;
                case "REPORTS":
                    GlobalRef.ReportName = "Reports";
                    fw.ExecuteJavascript(RSM.RSMHomePage.Reports);
                    break;
                case "ADMINISTRATION":
                    fw.ExecuteJavascript(RSM.RSMHomePage.Administration);
                    break;
                case "DASHBOARD":
                    fw.ExecuteJavascript(RSM.RSMHomePage.Dashboard);
                    tmsWait.Hard(5);
                    break;
                case "REPORT MANAGER":
                    fw.ExecuteJavascript(RSM.RSMHomePage.ReportManager);
                    tmsWait.Hard(5);
                    break;
                case "FILE PROCESSING STATUS":
                    fw.ExecuteJavascript(RSM.RSMHomePage.FileProcessing);
                    tmsWait.Hard(5);
                    break;

                case "JOB PROCESSING STATUS":
                    fw.ExecuteJavascript(RSM.RSMHomePage.FileProcessing);
                    tmsWait.Hard(5);
                    break;
            }
        }

        [When(@"Reports Manager page report name as ""(.*)"" is selected")]
        [Then(@"Reports Manager page report name as ""(.*)"" is selected")]
        public void WhenReportsManagerPageReportNameAsIsSelected(string reportName)
        {
            tmsWait.Hard(3);
            string[] valuesFromDD = reportName.ToString().Split(',');
            string GeneratedData = tmsCommon.GenerateData(reportName);
            string xpathstring = "//multiselect[@test-id='multiSelectReports']//a[contains(.,'" + GeneratedData + "')]/span";
            fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
            obj.SelectDropDownValues(xpathstring);
        }

        [Then(@"Reports Manager page report name is selected as ""(.*)""")]
        public void ThenReportsManagerPageReportNameIsSelectedAs(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement ele = new SelectElement(Browser.Wd.FindElement(By.XPath("//*[@id='multiSelectReports_taglist']/li[contains(.,'" + GeneratedData + "')]/span")));
            ele.SelectByText(GeneratedData);
            tmsWait.Hard(2);

        }



        [Then(@"Reports Manager page Search button is clicked")]
        [When(@"Reports Manager page Search button is clicked")]
        public void ThenReportsManagerPageSearchButtonIsClicked()
        {
            RSM.ReportManager.SearchButton.Click();
        }

        [When(@"Reports Manager page for report save button is Clicked")]
        public void WhenReportsManagerPageForReportSaveButtonIsClicked()
        {
            //Browser.callWiniumDesktopDriver();
            tmsWait.Hard(2);
            IWebElement download = Browser.Wd.FindElement(By.XPath("//a[@title='Download'][1]"));
            fw.ExecuteJavascript(download);
           
            //IWebElement securityWindow = Browser.winium.FindElement(By.Name("Save"));
            //tmsWait.Hard(1);
            //securityWindow.Click();

           
        }

      
        [When(@"Verify Reports Manager page for report ""(.*)"" Download format for ""(.*)"" button is clicked Fetch ""(.*)"" Diag Code as ""(.*)"" Source as ""(.*)"" displayed in report")]
        public void WhenVerifyReportsManagerPageForReportDownloadFormatForButtonIsClickedFetchDiagCodeAsSourceAsDisplayedInReport(string reportName, string format, string MemberID, string Diag, string TypeSource)
        {
            string memberID = GlobalRef.MEMID.ToString();
            string DiagCode = tmsCommon.GenerateData(Diag);
            string Source = tmsCommon.GenerateData(TypeSource);
            tmsWait.Hard(8);
            //Deleting already saved PDF, XLS and CSV files from doanload folder.
            string[] fileExtensions = { ".CSV", ".XLS", ".PDF", ".pdf", ".xls", ".csv", ".XLSX" };

            DirectoryInfo di = new DirectoryInfo(downloadPath);
            FileInfo[] oldDownloadedFiles = di.EnumerateFiles().Where(p => fileExtensions.Contains(p.Extension, StringComparer.InvariantCultureIgnoreCase)).ToArray();


            foreach (var oldFile in oldDownloadedFiles)
            {
                oldFile.Attributes = FileAttributes.Normal;
                File.Delete(oldFile.FullName);
            }

            IWebElement reportElement = Browser.Wd.FindElement(By.XPath("(//tr[contains(.,'" + reportName + "')][contains(.,'" + format + "')]//a)[1]"));
            //Based on Borwser type perform doanload action and verify report from download folder
            if (ConfigFile.BrowserType.ToLower().Equals("chrome"))
            {
                tmsWait.Hard(4);
                fw.ExecuteJavascript(reportElement);
                tmsWait.Hard(2);
            }
            if (ConfigFile.BrowserType.ToLower().Equals("ff"))
            {
                tmsWait.Hard(4);
                fw.ExecuteJavascript(reportElement);
                tmsWait.Hard(2);
            }
            if (ConfigFile.BrowserType.ToLower().Equals("ie"))
            {
                tmsWait.Hard(4);
                fw.ExecuteJavascript(reportElement);
                tmsWait.Hard(1);
                IWebElement securityWindow = Browser.winium.FindElement(By.Name("Save"));
                tmsWait.Hard(1);
                securityWindow.Click();

                //Below code is replaced with Winium Driver */
                //DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_TAB, 0, 0, 0);
                //tmsWait.Hard(1);
                //DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_TAB, 0, 0, 0);
                //tmsWait.Hard(1);
                //DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_RETURN, 0, 0, 0); 
            }
           
            char splchar = '/';
           
                           
            if (reportName.Contains(splchar))
            {
                reportName = reportName.Replace(splchar, '_');
            }

            if (format.ToUpper().Equals("PDF"))
            {
                tmsWait.Hard(10);
                string pdfText = ReadFileFunctions.ReadPDFFile(downloadPath + "\\" + reportName + ".PDF");
                Assert.IsTrue(pdfText.ToUpper().Contains(DiagCode.ToUpper()), "PDF File missed some data. Failed...");
                Assert.IsTrue(pdfText.ToUpper().Contains(Source.ToUpper()), "PDF File missed some data. Failed...");
                Assert.IsTrue(pdfText.ToUpper().Contains(memberID.ToUpper()), "PDF File missed some data. Failed...");
            }
            else if (format.ToUpper().Equals("CSV"))
            {
                tmsWait.Hard(7);
                var csvData = ReadFileFunctions.ReadCSVFile(downloadPath + "\\" + "" + reportName + ".CSV");
                VerifyText(csvData, DiagCode, format);                
                VerifyText(csvData, Source, format);
                VerifyText(csvData, memberID, format);
            }
            else if (format.ToUpper().Equals("XLS"))
            {
                tmsWait.Hard(7);
                var excelData = ReadFileFunctions.ReadXLSFile(downloadPath + "\\" + "" + reportName + ".XLS", downloadPath + "\\" + "" + reportName + ".CSV");
                VerifyText(excelData, DiagCode, format);
                VerifyText(excelData, Source, format);
                VerifyText(excelData, memberID, format);
            }
            else if (format.ToUpper().Equals("XLSX"))
            {
                tmsWait.Hard(7);
                var excelData = ReadFileFunctions.ReadXLSFile(downloadPath + "\\" + "" + reportName + ".XLSX", downloadPath + "\\" + "" + reportName + ".CSV");
                VerifyText(excelData, DiagCode, format);
                VerifyText(excelData, Source, format);
                VerifyText(excelData, memberID, format);
            }
        }

        [When(@"Reports Manager page for report ""(.*)"" Download format for ""(.*)"" button is clicked and ""(.*)"" text and  CMS File displayed in report")]
        public void WhenReportsManagerPageForReportDownloadFormatForButtonIsClickedAndTextAndCMSFileDisplayedInReport(string reportName, string format, string ReportValidationText)
        {
            //string FileProcessingCMSFILEID = ScenarioContext.Current["CMSFILEID"].ToString();
            //fw.ConsoleReport(" CMS File ID ==> " + FileProcessingCMSFILEID);

            tmsWait.Hard(8);
            //Deleting already saved PDF, XLS and CSV files from doanload folder.
            string[] fileExtensions = { ".CSV", ".XLS", ".PDF", ".pdf", ".xls", ".csv", ".XLSX" };

            DirectoryInfo di = new DirectoryInfo(downloadPath);
            FileInfo[] oldDownloadedFiles = di.EnumerateFiles().Where(p => fileExtensions.Contains(p.Extension, StringComparer.InvariantCultureIgnoreCase)).ToArray();


            foreach (var oldFile in oldDownloadedFiles)
            {
                oldFile.Attributes = FileAttributes.Normal;
                File.Delete(oldFile.FullName);
            }

            IWebElement reportElement = Browser.Wd.FindElement(By.XPath("(//tr[contains(.,'" + reportName + "')][contains(.,'" + format + "')]//a)[1]"));
            //Based on Borwser type perform doanload action and verify report from download folder
            if (ConfigFile.BrowserType.ToLower().Equals("chrome"))
            {
                tmsWait.Hard(4);
                fw.ExecuteJavascript(reportElement);
                tmsWait.Hard(2);
            }
            if (ConfigFile.BrowserType.ToLower().Equals("ff"))
            {
                tmsWait.Hard(4);
                fw.ExecuteJavascript(reportElement);
                tmsWait.Hard(2);
            }
            if (ConfigFile.BrowserType.ToLower().Equals("ie"))
            {
                tmsWait.Hard(4);
                fw.ExecuteJavascript(reportElement);
                tmsWait.Hard(1);
                IWebElement securityWindow = Browser.winium.FindElement(By.Name("Save"));
                tmsWait.Hard(1);
                securityWindow.Click();

                //Below code is replaced with Winium Driver */
                //DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_TAB, 0, 0, 0);
                //tmsWait.Hard(1);
                //DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_TAB, 0, 0, 0);
                //tmsWait.Hard(1);
                //DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_RETURN, 0, 0, 0); 
            }
            //else
            //{
            //    tmsWait.Hard(4);
            //    fw.ExecuteJavascript(reportElement);
            //    tmsWait.Hard(2);
            //}

            char splchar = '/';
            if (!ReportValidationText.Equals("Date"))
            {
                ReportValidationText = tmsCommon.GenerateData(ReportValidationText);
            }
            if (reportName.Contains(splchar))
            {
                reportName = reportName.Replace(splchar, '_');
            }

            if (format.ToUpper().Equals("PDF"))
            {
                tmsWait.Hard(10);
                string pdfText = ReadFileFunctions.ReadPDFFile(downloadPath + "\\" + reportName + ".PDF");
                Assert.IsTrue(pdfText.ToUpper().Contains(ReportValidationText.ToUpper()), "PDF File missed some data. Failed...");
            }
            else if (format.ToUpper().Equals("CSV"))
            {
                tmsWait.Hard(7);
                var csvData = ReadFileFunctions.ReadCSVFile(downloadPath + "\\" + "" + reportName + ".CSV");
                VerifyText(csvData, ReportValidationText, format);
            }
            else if (format.ToUpper().Equals("XLS"))
            {
                tmsWait.Hard(7);
                var excelData = ReadFileFunctions.ReadXLSFile(downloadPath + "\\" + "" + reportName + ".XLS", downloadPath + "\\" + "" + reportName + ".CSV");
                VerifyText(excelData, ReportValidationText, format);
            }
            else if (format.ToUpper().Equals("XLSX"))
            {
                tmsWait.Hard(7);
                var excelData = ReadFileFunctions.ReadXLSFile(downloadPath + "\\" + "" + reportName + ".XLSX", downloadPath + "\\" + "" + reportName + ".CSV");
                VerifyText(excelData, ReportValidationText, format);
                //VerifyText(excelData, FileProcessingCMSFILEID, format);
            }
        }

        [Given(@"Verify Downloaded CSV File displayed Member ID as ""(.*)""")]
        [When(@"Verify Downloaded CSV File displayed Member ID as ""(.*)""")]
        [When(@"Verify Downloaded CSV File displayed Member ID as ""(.*)""")]
        public void GivenVerifyDownloadedCSVFileDisplayedMemberIDAs(string p0)
        {
             tmsWait.Hard(8);

            string ReportValidationText = tmsCommon.GenerateData(p0);

            string filename = ReUsableFunctions.getRecentlyDownloadedCSVFileFromDownloadFolder();
            var csvData = ReadFileFunctions.ReadCSVFile(downloadPath + "\\" + "" + filename);
                VerifyText(csvData, ReportValidationText, "CSV");
           
        }
        [When(@"Delete Old Downloaded files from Download Folder")]
        public void WhenDeleteOldDownloadedFilesFromDownloadFolder()
        {


        //Deleting already saved PDF, XLS and CSV files from doanload folder.
        string[] fileExtensions = { ".CSV", ".XLS", ".PDF", ".pdf", ".xls", ".csv", ".XLSX" };

            DirectoryInfo di = new DirectoryInfo(downloadPath);
            FileInfo[] oldDownloadedFiles = di.EnumerateFiles().Where(p => fileExtensions.Contains(p.Extension, StringComparer.InvariantCultureIgnoreCase)).ToArray();


            foreach (var oldFile in oldDownloadedFiles)
            {
                oldFile.Attributes = FileAttributes.Normal;
                File.Delete(oldFile.FullName);
            }

        }

        [Then(@"Verify CSV Report ""(.*)"" displayed content ""(.*)""")]
        public void ThenVerifyCSVReportDisplayedContent(string reportName, string content)
        {

            tmsWait.Hard(8);
            string ReportValidationText = tmsCommon.GenerateData(content);

            char splchar = '/';
            if (!ReportValidationText.Equals("Date"))
            {
                ReportValidationText = tmsCommon.GenerateData(ReportValidationText);
            }
            if (reportName.Contains(splchar))
            {
                reportName = reportName.Replace(splchar, '_');
            }
            tmsWait.Hard(7);
            var csvData = ReadFileFunctions.ReadCSVFile(downloadPath + "\\" + "" + reportName + ".CSV");
            VerifyText(csvData, ReportValidationText, "CSV");

        }


        [Then(@"Verify PDF Report ""(.*)"" displayed content ""(.*)""")]
        public void ThenVerifyPDFReportDisplayedContent(string reportName, string content)
        {          

        tmsWait.Hard(8);
            string ReportValidationText = tmsCommon.GenerateData(content);       
                      
            char splchar = '/';
            if (!ReportValidationText.Equals("Date"))
            {
                ReportValidationText = tmsCommon.GenerateData(ReportValidationText);
            }
            if (reportName.Contains(splchar))
            {
                reportName = reportName.Replace(splchar, '_');
            }

        
                tmsWait.Hard(10);
                string pdfText = ReadFileFunctions.ReadPDFFile(downloadPath + "\\" + reportName + ".PDF");
                Assert.IsTrue(pdfText.ToUpper().Contains(ReportValidationText.ToUpper()), "PDF File missed some data. Failed...");
           
          
        }

        [Then(@"Verify XLS Report ""(.*)"" displayed content ""(.*)""")]
        public void ThenVerifyXLSReportDisplayedContent(string reportName, string content)
        {
            tmsWait.Hard(8);
            string ReportValidationText = tmsCommon.GenerateData(content);

            char splchar = '/';
            if (!ReportValidationText.Equals("Date"))
            {
                ReportValidationText = tmsCommon.GenerateData(ReportValidationText);
            }
            if (reportName.Contains(splchar))
            {
                reportName = reportName.Replace(splchar, '_');
            }

            tmsWait.Hard(7);
            var excelData = ReadFileFunctions.ReadXLSFile(downloadPath + "\\" + "" + reportName + ".XLSX", downloadPath + "\\" + "" + reportName + ".CSV");
            VerifyText(excelData, ReportValidationText, "XLSX");

        }
        [Then(@"When EAM Actions page """"(.*)"" section ""(.*)"" button is clicked and File Exportd file has correct data")]
        public void ThenWhenEAMActionsPageSectionButtonIsClickedAndFileExportdFileHasCorrectData(string p0, string p1)
        {
            tmsWait.Hard(8);

        string  totalrecord = GlobalRef.TotalAction.ToString() ;

            //Deleting already saved PDF, XLS and CSV files from doanload folder.
            string[] fileExtensions = { ".CSV", ".XLS", ".PDF", ".pdf", ".xls", ".csv", ".XLSX" };

            DirectoryInfo di = new DirectoryInfo(downloadPath);
            FileInfo[] oldDownloadedFiles = di.EnumerateFiles().Where(p => fileExtensions.Contains(p.Extension, StringComparer.InvariantCultureIgnoreCase)).ToArray();


            foreach (var oldFile in oldDownloadedFiles)
            {
                oldFile.Attributes = FileAttributes.Normal;
               // File.Delete(oldFile.FullName);
            }

           IWebElement reportElement = Browser.Wd.FindElement(By.XPath("//button[@test-id='reviewQueue-btn-export']"));
            //Based on Borwser type perform doanload action and verify report from download folder
            if (ConfigFile.BrowserType.ToLower().Equals("chrome"))
            {
                tmsWait.Hard(4);
                fw.ExecuteJavascript(reportElement);
                tmsWait.Hard(20);
            }
            if (ConfigFile.BrowserType.ToLower().Equals("ff"))
            {
                tmsWait.Hard(4);
                fw.ExecuteJavascript(reportElement);
                tmsWait.Hard(2);
            }
            if (ConfigFile.BrowserType.ToLower().Equals("ie"))
            {
                tmsWait.Hard(4);
                fw.ExecuteJavascript(reportElement);
                tmsWait.Hard(1);
                IWebElement securityWindow = Browser.winium.FindElement(By.Name("Save"));
                tmsWait.Hard(1);
                securityWindow.Click();


            }
            DateTime date = DateTime.Now;
            string d = date.ToString("Mddyyyy");
            string reportName = "ManualReview_tmsadmin_7292020";
            

             
            
                tmsWait.Hard(7);
                var csvData = ReadFileFunctions.ReadCSVFile(downloadPath + "\\" + "" + reportName + ".CSV");


        }


        [Given(@"Reports Manager page for report ""(.*)"" Download format for ""(.*)"" button is clicked")]
        [When(@"Reports Manager page for report ""(.*)"" Download format for ""(.*)"" button is clicked")]
        [Then(@"Reports Manager page for report ""(.*)"" Download format for ""(.*)"" button is clicked")]
        [When(@"Reports Manager page for report ""(.*)"" Download format for ""(.*)"" button is clicked and ""(.*)"" text displayed in report")]
        [Then(@"Reports Manager page for report ""(.*)"" Download format for ""(.*)"" button is clicked and ""(.*)"" text displayed in report")]
        [Given(@"Reports Manager page for report ""(.*)"" Download format for ""(.*)"" button is clicked and ""(.*)"" text displayed in report")]
        public void WhenReportsManagerPageForReportDownloadFormatForButtonIsClickedAndTextDisplayedInReport(string reportName, string format, string content)
        {           
            tmsWait.Hard(8);
            string ReportValidationText_1 = tmsCommon.GenerateData(content);
            string[] split_content = ReportValidationText_1.Split(' ');
            string ReportValidationText = split_content[0];

            //Deleting already saved PDF, XLS and CSV files from doanload folder.
            string[] fileExtensions = {".CSV",".XLS",".PDF",".pdf",".xls",".csv",".XLSX"};

            DirectoryInfo di = new DirectoryInfo(downloadPath);
            FileInfo[] oldDownloadedFiles = di.EnumerateFiles().Where(p => fileExtensions.Contains(p.Extension, StringComparer.InvariantCultureIgnoreCase)).ToArray();


            foreach (var oldFile in oldDownloadedFiles)
            {
                oldFile.Attributes = FileAttributes.Normal;
                File.Delete(oldFile.FullName);
            }

            IWebElement reportElement = Browser.Wd.FindElement(By.XPath("//tr[1]//td[contains(.,'" + reportName + "')]//following-sibling::td[2][contains(.,'" + format + "')]//following-sibling::td//a"));
            //Based on Borwser type perform doanload action and verify report from download folder
            if (ConfigFile.BrowserType.ToLower().Equals("chrome"))
            {
                tmsWait.Hard(4);
                fw.ExecuteJavascript(reportElement);
                tmsWait.Hard(20);
            }
            if (ConfigFile.BrowserType.ToLower().Equals("ff"))
            {
                tmsWait.Hard(4);
                fw.ExecuteJavascript(reportElement);
                tmsWait.Hard(2);
            }
             if (ConfigFile.BrowserType.ToLower().Equals("ie"))
            {
                tmsWait.Hard(4);
                fw.ExecuteJavascript(reportElement);
                tmsWait.Hard(1);
                IWebElement securityWindow = Browser.winium.FindElement(By.Name("Save"));
                tmsWait.Hard(1);
                securityWindow.Click();

                //Below code is replaced with Winium Driver */
                //DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_TAB, 0, 0, 0);
                //tmsWait.Hard(1);
                //DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_TAB, 0, 0, 0);
                //tmsWait.Hard(1);
                //DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_RETURN, 0, 0, 0); 
            }
            //else
            //{
            //    tmsWait.Hard(4);
            //    fw.ExecuteJavascript(reportElement);
            //    tmsWait.Hard(2);
            //}

            char splchar = '/';
            if (!ReportValidationText.Equals("Date"))
            {
                ReportValidationText = tmsCommon.GenerateData(ReportValidationText);
            }
            if (reportName.Contains(splchar))
            {
                reportName = reportName.Replace(splchar, '_');
            }
             
            if (format.ToUpper().Equals("PDF"))
            {
                tmsWait.Hard(10);
                string pdfText = ReadFileFunctions.ReadPDFFile(downloadPath + "\\" + "" + reportName + ".PDF");
                Assert.IsTrue(pdfText.ToUpper().Contains(ReportValidationText.ToUpper()), "PDF File missed some data. Failed...");
            }
            else if (format.ToUpper().Equals("CSV"))
            {
                tmsWait.Hard(7);
                var csvData = ReadFileFunctions.ReadCSVFile(downloadPath + "\\" + "" + reportName + ".CSV");
                VerifyText(csvData, ReportValidationText, format);
            }
            else if (format.ToUpper().Equals("XLS"))
            {
                try
                {
                    tmsWait.Hard(7);
                    var excelData = ReadFileFunctions.ReadXLSFile(downloadPath + "\\" + "" + reportName + ".XLS", downloadPath + "\\" + "" + reportName + ".CSV");
                    VerifyText(excelData, ReportValidationText, format);
                }
                catch
                {
                    Console.WriteLine("Excel is not installed on this machine, file cannot be read.");
                }
            }
            else if (format.ToUpper().Equals("XLSX"))
            {
                try
                { 
                    tmsWait.Hard(7);
                    string xlsxfileName = AngularFunction.getRecent_FilefromSpecialFolderUsingExtension(downloadPath, "XLSX");
                    string csvFileName = downloadPath + "\\" + "" + reportName + ".CSV";
                    var excelData = ReadFileFunctions.ReadXLSFile(xlsxfileName, csvFileName);
                    VerifyText(excelData, ReportValidationText, format);
                }
                catch(Exception e)
                {

                    Console.WriteLine(e.Message);
                    Console.WriteLine("Excel is not installed on this machine, file cannot be read.");
                }
            }
        }



        public void VerifyText(List<string> dataFromFile, string reportName, string format)
        {
            bool flag = false;
            tmsWait.Hard(5);

            foreach (string data in dataFromFile)
            {
                
                if (data.ToUpper().Contains(reportName.ToUpper()))
                {
                    flag = true;
                    break;
                }
            }
            if (format.ToUpper().Equals("CSV"))
            {

                Assert.IsTrue(flag, format + " File has missed some data. Failed..."); //For CSV there is Report Name is not getting displayed. File is getting dreated successfully...
            }
            if (format.ToUpper().Equals("XLS"))
            {
                Assert.IsTrue(flag, format + " File has missed some data. Failed...");
            }
            if (format.ToUpper().Equals("XLSX"))
            {
                Assert.IsTrue(flag, format + " File has missed some data. Failed...");
            }
        }



        [When(@"Report ""(.*)"" Download format for ""(.*)"" button is clicked and ""(.*)"" tet displayed in report")]
        public void WhenReportDownloadFormatForButtonIsClickedAndTetDisplayedInReport(string p0, string p1, string p2)
        {
            
        }


        [When(@"HCC Discrepancy report RunReport button is Clicked")]
        public void WhenHCCDiscrepancyReportRunReportButtonIsClicked()
        {

            RSM.HCCDiscrepancy.RunReport.Click();
            tmsWait.Hard(5);
        }


        [When(@"Verify the reports name list under ""(.*)"" report group name")]
        public void WhenVerifyTheReportsNameListUnderReportGroupName(string reportGroup)
        {
            switch (reportGroup.ToLower())
            {
                case "hcc/rxhcc":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'HCC/RxHCC Report')]")).Displayed, "HCC/RxHCC Report is not displayed.");
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'HCC Discrepancy')]")).Displayed, "HCC Discrepancy link is not displayed.");
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'HCC Details')]")).Displayed, "HCC Details link is not displayed.");
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'HCC Beneficiaries')]")).Displayed, "HCC Beneficiaries link is not displayed.");
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'CMS HCC Disease Group Prevalence')]")).Displayed, "CMS HCC Disease Group Prevelance link is not displayed.");
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'CMS RX HCC Disease Group Prevalence')]")).Displayed, "CMS RX Disease Group Prevelance link is not displayed.");
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Member Missing HCC')]")).Displayed, "Member Missing HCC link is not displayed.");
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Member Missing RX HCC')]")).Displayed, "Member Missing RX HCC link is not displayed.");
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'RX HCC Beneficiaries')]")).Displayed, "RX HCC Beneficiaries link is not displayed.");
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'HCC Details Blended')]")).Displayed, "HCC Details Blended link is not displayed.");
                    break;
                case "risk score trend":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Risk Score Trend Report')]")).Displayed, "Risk Score Trend Report is not displayed.");
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Risk Score Trend')]")).Displayed, "Risk Score Trend link is not displayed.");
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Risk Score Trend - Part D')]")).Displayed, "Risk Score Trend - Part D link is not displayed.");
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Risk Score Trend PCP')]")).Displayed, "Risk Score Trend PCP link is not displayed.");
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Risk Score Trend PCP - Part D')]")).Displayed, "Risk Score Trend PCP - Part D link is not displayed.");
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Risk Score Trend Details')]")).Displayed, "Risk Score Trend Details link is not displayed.");
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Risk Score Calculation Details')]")).Displayed, "Risk Score Calculation Details link is not displayed.");
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Risk Score Calculation Details - Part D')]")).Displayed, "Risk Score Calculation Details - Part D link is not displayed.");
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Risk Score Trend Details - Part D')]")).Displayed, "Risk Score Trend Details - Part D link is not displayed.");
                    break;
                case "risk assessment":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Risk Assessment Report')]")).Displayed, "Risk Assessment Report is not displayed.");
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Risk Adjustment Profile')]")).Displayed, "Risk Adjustment Profile link is not displayed.");
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Risk Score Estimated Receivable')]")).Displayed, "Risk Score Estimated Receivable link is not displayed.");
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Risk Score Estimated Receivable - Part D')]")).Displayed, "Risk Score Estimated Receivable - Part D link is not displayed.");
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Diagnosis Alert Details PartC')]")).Displayed, "Diagnosis Alert Details PartC link is not displayed.");
                    break;
                case "others":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Others')]")).Displayed, "Others Reports is not displayed.");
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Data Load Summary')]")).Displayed, "Data Load Summary link is not displayed.");
                    break;
            }
        }


        [When(@"""(.*)"" ""(.*)"" listbox is set to ""(.*)""")]
       [When(@"HCC Discrepancy report ""(.*)"" dropdown value is set to ""(.*)""")]
        public void WhenHCCDiscrepancyReportDropdownValueIsSetTo(string p0, string p1)
        {
            string dropdown = p0.ToString();
            string value = p1.ToString();

            switch (dropdown)
            {
                case "Discrepancy Type":
                    SelectElement type = new SelectElement(RSM.HCCDiscrepancy.DiscrepancyType);
                    type.SelectByText(value);
                    break;
                case "Payment Year":
                    SelectElement year = new SelectElement(RSM.HCCDiscrepancy.PaymentYear);
                    year.SelectByText(value);
                    break;
                case "PBP":
                    SelectElement pbp = new SelectElement(RSM.HCCDiscrepancy.PBP);
                    pbp.SelectByText(value);
                    break;

                case "Resubmit Status":
                    SelectElement status = new SelectElement(RSM.HCCDiscrepancy.ResubmitStatus);
                    status.SelectByText(value);
                    break;
                case "Raft Type":
                    SelectElement RaftType = new SelectElement(RSM.HCCDiscrepancy.RaftType);
                    RaftType.SelectByText(value);
                    break;
                case "Enrollment":
                    SelectElement Enrollment = new SelectElement(RSM.HCCDiscrepancy.Enrollment);
                    Enrollment.SelectByText(value);
                    break;
                case "Sort By":
                    SelectElement SortBy = new SelectElement(RSM.HCCDiscrepancy.SortBy);
                    SortBy.SelectByText(value);
                    break;
                case "Year Type":
                    SelectElement YearType = new SelectElement(RSM.HCCDiscrepancy.YearType);
                    YearType.SelectByText(value);
                    break;

            }

        }

     

        [When(@"Report section""(.*)"" link is Clicked")]
        [When(@"Report ""(.*)"" link is Clicked")]
        [When(@"HCC/RxHCC Report section ""(.*)"" link is Clicked")]
        public void WhenHCCRxHCCReportSectionLinkIsClicked(string link)
        {
            //string link = p0.ToLower();
            tmsWait.Hard(5);
            //IWebElement expandAll = Browser.Wd.FindElement(By.CssSelector("[test-id='report-button-expandcolaps']"));
            //fw.ExecuteJavascript(expandAll);

            tmsWait.Hard(1);
            IWebElement reportlink = Browser.Wd.FindElement(By.CssSelector("[test-id='" + link + "']"));
            fw.ExecuteJavascript(reportlink);
            tmsWait.Hard(3);
        }

        [Then(@"Verify RSM Home page Product menu displays ""(.*)""")]
        public void ThenVerifyRSMHomePageProductMenuDisplays(string p0)
        {
            string expected = p0.ToString();
            Assert.AreEqual(expected, RSM.RSMHomePage.ProductMenudrpdownText.Text, p0 + " is not getting displayed");
        }

        [Then(@"Verify RSM Home page displayed with Title ""(.*)""")]
        public void ThenVerifyRSMHomePageDisplayedWithTitle(string p0)
        {
            tmsWait.Hard(10);
            string expectedTitle = p0.ToString().Trim();
           
            Assert.AreEqual(expectedTitle, RSM.RSMHomePage.RSMApplicationTitle.Text, " Application is not displayed Expected Title");
        }

        [Then(@"Verify FRM Home page displayed with Title ""(.*)""")]
        public void ThenVerifyFRMHomePageDisplayedWithTitle(string p0)
        {
            string expectedTitle = p0.ToString().Trim();

            Assert.AreEqual(expectedTitle, FRM.FRMMainmenu.FRMTitleHeader.Text, " Application is not displayed Expected Title");
        }

        [Then(@"Verify EAM Home page displayed with Title ""(.*)""")]
        public void ThenVerifyEAMHomePageDisplayedWithTitle(string p0)
        {
            string expectedTitle = p0.ToString().Trim();

            Assert.AreEqual(expectedTitle,EAM.EAMHomePage.EAMTitle.Text, " Application is not displayed Expected Title");
        }


        [When(@"RSM Home page Product Menu dropdown list is Clicked")]
        public void WhenRSMHomePageProductMenuDropdownListIsClicked()
        {
           
            RSM.RSMHomePage.ProductMenudrpdown.Click();
        }

        [When(@"RSM Home page Expand Menu is Clicked")]
        public void WhenRSMHomePageExpandMenuIsClicked()
        {
            RSM.RSMHomePage.RSMExpandMenu.Click();
        }


        [Then(@"RSM Home page Product menu dropdown list ""(.*)"" Application is selected")]
        public void ThenRSMHomePageProductMenuDropdownListApplicationIsSelected(string p0)
        {

            string Application = p0.ToString();
            switch (Application)
            {
                case "TMSAdministration":
                    IWebElement testAdmin = Browser.Wd.FindElement(By.XPath("//small[contains(., 'Administration')]"));
                    fw.ExecuteJavascript(testAdmin);
                    break;

                case "FRM":
                    IWebElement testFRM = Browser.Wd.FindElement(By.XPath("//small[contains(., '" + ConfigFile.FRMdb + "')]"));
                    fw.ExecuteJavascript(testFRM);
                    break;
                case "EAM":
                    IWebElement testEAM = Browser.Wd.FindElement(By.XPath("//small[contains(., '" + ConfigFile.EAMdb + "')]"));
                    fw.ExecuteJavascript(testEAM);
                    break;
                case "RSM":

                    IWebElement testRSM = Browser.Wd.FindElement(By.XPath("//small[contains(., '" + ConfigFile.RSMdb + "')]"));
                    fw.ExecuteJavascript(testRSM);
                    break;
            }
        }


        //[When(@"RSM Home page Product menu dropdown list ""(.*)"" Application is selected")]
        //public void WhenRSMHomePageProductMenuDropdownListApplicationIsSelected(string p0)
        //{



        //}

        [Given(@"RSM Home page Information button is clicked")]
        public void GivenRSMHomePageInformationButtonIsClicked()
        {
            tmsWait.Hard(5);
            IWebElement profile = Browser.Wd.FindElement(By.CssSelector("[test-id='header-btn-userMenu']"));
            fw.ExecuteJavascript(profile);
            tmsWait.Hard(5);
           // fw.ExecuteJavascript(RSM.RSMHomePage.Information);
            

        }

        [Then(@"Verify RSM Home page Information details window displayed ""(.*)""")]
        public void ThenVerifyRSMHomePageInformationDetailsWindowDisplayed(string p0)
        {
            
            tmsWait.Hard(2);
            string infodetails = p0.ToString();             

            string[] actualDB = RSM.RSMHomePage.InformationDatabase.Text.Replace("\r\n", "|").Split('|');
            string[] lastlogin = RSM.RSMHomePage.InformationLastLogin.Text.Replace("\r\n", "|").Split('|');
            char[] test = { ' ' };
            string[] actualLastLogin = lastlogin[1].Split(test,2);
            switch (infodetails)
            {
                case "Database":
                    Assert.AreEqual(actualDB[1], ConfigFile.RSMdb, ConfigFile.RSMdb + " database is not displayed");                     
                    break;
                case "Last Login":

                    Assert.AreEqual(actualLastLogin[0].Trim(), DateTime.Now.ToString("MM/dd/yyyy"), DateTime.Now.ToString("MM/dd/yyyy") + " is not displayed");
                    break;
            }
        }

        [Then(@"RSM Logout button is clicked")]
        public void ThenRSMLogoutButtonIsClicked()
        {
            fw.ExecuteJavascript(RSM.RSMHomePage.Logout);
        }

        [When(@"TMS RSM Main page Question Mark icon is Clicked")]
        public void WhenTMSRSMMainPageQuestionMarkIconIsClicked()
        {
            int maxWait = 7;
            int counter = 0;
            Boolean bDone = false;
            while (!bDone)
            {
                try
                {
                    counter++;
                   // RSM.RSMHomePage.ProfileInfolink.Click();
                    fw.ExecuteJavascript(RSM.RSMHomePage.Help);

                    bDone = true;
                }
                catch
                {
                    tmsWait.Hard(6);
                }
                if (counter == maxWait)
                {
                    bDone = true;
                }
            }
        }


        [Then(@"Verify TriZetto Medicare Solutions Login page ""(.*)"" text box is displayed")]
        public void ThenVerifyTriZettoMedicareSolutionsLoginPageTextBoxIsDisplayed(string p0)
        {
            string field = p0.ToString();

            switch(field)
            {
                case "UserID":
                    Assert.IsTrue(EAM.EAMLogin.UserID.Displayed, p0+" Text box is displayed");
                    break;

                case "Password":
                    Assert.IsTrue(EAM.EAMLogin.Password.Displayed, p0 + " Text box is displayed");
                    break;

            }
            

        }


        [Then(@"Verify Product Menu dropdown list displays ""(.*)"" application detail")]
        public void ThenVerifyProductMenuDropdownListDisplaysApplicationDetail(string p0)
        {
            string Application = p0.ToString();
            switch (Application)
            {
                case "TMSAdministration":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//small[contains(., 'Administration')]")).Displayed, p0 + " is not displayed in Product Menu");
                    break;

                case "FRM":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//small[contains(., '" + ConfigFile.FRMdb + "')]")).Displayed, p0 + " is not displayed in Product Menu");
                    break;
                case "EAM":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//small[contains(., '" + ConfigFile.EAMdb + "')]")).Displayed, p0 + " is not displayed in Product Menu");
                    break;
                case "RSM":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//small[contains(., '" + ConfigFile.RSMdb + "')]")).Displayed, p0 + " is not displayed in Product Menu");
                    break;
            }
        }





        [Then(@"""(.*)"" page Pagination ""(.*)"" link is clicked")]
        public void ThenPagePaginationLinkIsClicked(string lookuPage, string linkName)
        {
            switch (lookuPage)
            {
                case "Member Search Criteria":
                    switch (linkName)
                    {
                        case "First":
                            RSM.Lookups.HICLookUp.HICLookupPaginationFirst.Click();
                            break;
                        case "Previous":
                            RSM.Lookups.HICLookUp.HICLookupPaginationPrevious.Click();
                            break;
                        case "Next":
                            RSM.Lookups.HICLookUp.HICLookupPaginationNext.Click();
                            break;
                        case "Last":
                            RSM.Lookups.HICLookUp.HICLookupPaginationLast.Click();
                            break;
                    }

                    break;
            }
        }
        [Then(@"Verify ""(.*)"" user is a last page when Last button is clicked for page size ""(.*)""")]
        public void ThenVerifyUserIsALastPageWhenLastButtonIsClickedForPageSize(string lookupPage, int pageSize)
        {
            IWebElement Pagenumber = null;
            switch (lookupPage)
            {
                case "Member Search Criteria":
                    Pagenumber = RSM.Lookups.HICLookUp.HCILookupPagenumber;
                    break;
            }
            string value = Pagenumber.Text;
            int currentPageNumber = 0;
            int totalItems = 0;
            char[] delim1 = { '(' };
            char[] delim2 = { ' ' };
            string[] values = value.Split(delim1);
            string[] pagenumbervalues = values[0].Split(delim2);
            string[] totalItem = values[1].Split(delim2);
            int numVal = Int32.Parse("-105");
             currentPageNumber = Int32.Parse(pagenumbervalues[2]);
             totalItems = Int32.Parse(totalItem[0]);
            int TotalAppItems = Convert.ToInt32(currentPageNumber * pageSize);
            int var = TotalAppItems.CompareTo(totalItems);
            Assert.IsTrue(var==0, "total number of rows displayed is not equal to the total number of items");
        }



        [When(@"variable PCP ""(.*)"" is set to ""(.*)""")]
        public void WhenVariablePCPIsSetTo(string p0, string p1)
        {
            GeneratedUserID = tmsCommon.GenerateData(p1);
            fw.setVariable(p0, GeneratedUserID);
        }

        [Then(@"Select the record ""(.*)"" from look up page")]
        [When(@"Select the record ""(.*)"" from look up page")]
        public void WhenSelectTheRecordFromLookUpPage(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            tmsWait.Hard(2);
            //string lookup = p1.ToString();
            String xpathcust = "//div[contains(.,'" + GeneratedData + "')]/div/following-sibling::div/div/a";
            Browser.Wd.FindElement(By.XPath(xpathcust)).Click();
        }

        [When(@"Provider ID Number is set to ""(.*)""")]
        public void WhenNumberIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            RSM.Lookups.PCPLookUp.ProviderID.SendKeys(GeneratedData);
        }


        [When(@"Select the records ""(.*)"" from ""(.*)"" look up page")]
        public void WhenLookUpPageViewEditTableEditIconIsClickedForRow(string p0, string p1)
        {
            string lookupname = p0.ToString();

            switch (lookupname)
            {
                case "GroupID":
                    ClickOnSelect(p1);
                    break;
                case "PCP":
                    ClickOnSelect(p1);
                    break;
                case "SSC":
                    ClickOnSelect(p1);
                    break;
                case "HIC":
                    ClickOnSelect(p1);
                    break;
              
            }
        }

        [Then(@"Verify number of rows displayed on ""(.*)"" page is ""(.*)""")]
        public void ThenVerifyNumberOfRowsDisplayedOnPageIs(string lookupPage, int expectedRows)
        {
            int rowCountApp = 0;
            switch (lookupPage.ToLower().Trim())
            {
                case "member search criteria":
                    rowCountApp = Browser.Wd.FindElements(By.XPath("//div[@id='memberLookupGird']//a[@title='Select']")).Count;
                    break;
            }
            if(expectedRows == rowCountApp)Console.WriteLine(" number of rows is matched with the application table");
            else Console.WriteLine(" number of rows is not matched with the application table");
        }

        
        public void ClickOnSelect(string IdString)
        {
            string IDRecord;

            string[] IDArray = new string[10];

            if (IdString.Contains(","))
            {
                IDArray = IdString.Split(',');
                for (int i = 0; i <= IDArray.Length; i++)
                {
                    IDRecord = IDArray[i];
                    WhenSelectTheRecordFromLookUpPage(IDRecord);
                }
            }
            else
            {
                IDRecord = IdString;
                WhenSelectTheRecordFromLookUpPage(IDRecord);
            }
        }

       
        public void TableValidation(Table table, IWebElement p1, IWebElement p2)
        {
            try
            {
                //Create Storage for the Gherkin table and the page data
                GherkinTable thisGT = new GherkinTable();
                TablePaging thisTP = new TablePaging();

                //Load the Gherkin table into the storage
                thisGT.LoadGherkinTable(table);
                int headercnt=table.Header.Count;
                //The big loop.  Keep working until all the Gherkin table rows are marked as matched
                //Or until we are on the last page of records, then we also quit looking.
                while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
                {
                    //Start out with the assumption we are not on the last page of records.  We will check later.
                    thisTP.bNotAtLastPageOfRecords = true;

                    //Get the table object again, since the page refreshes we need to get it fresh
                    IWebElement baseTable = p1;
                    IWebElement paginationSystem = p2;

                    thisTP.LoadRSMGrid(baseTable, headercnt, "ui-grid-row", "ui-grid-cell");

                    int iTableCounter = 0;
                   // string expectedTableCheckboxValue = "";
                    //for each row in the Gherkin table, start flipping through all the rows in the page data.
                    foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                    {
                        //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                        //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                        if (GherkinTableRow == null)
                        {
                            break;
                        }

                        //If this Gherkin table row is not yet matched, proceed.
                        if (GherkinTableRow.RowIsMatched == false)
                        {
                            //Convert the row to an array so we can do an element by element match.
                            string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                            //For each row in the page data
                            //App function chalu hotey
                            foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                            {
                                //Convert page data to array elements
                                //Only work with the loaded element rows.  The first unloaded one will be null.
                                if (ApplicationRow == null)
                                {
                                    break;
                                }

                                //Convert the page row to array so we can pair up by elements.
                                string[] AppTableRow = ApplicationRow.Row.ToArray();
                                int iElementCounter = 0;
                                Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                                //In here as we pair up the data you will have custom matching.
                                //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                                foreach (string appTD in AppTableRow)
                                {

                                    //if (iElementCounter > 0 && TDA.RowIsData)
                                    if (ApplicationRow.RowIsData)
                                    {
                                        //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                        if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                        {

                                            bThisRowMatches = false;
                                        }
                                        //if (iElementCounter == 5)
                                        //{
                                        //    expectedTableCheckboxValue = GherkinTableArray[5];
                                        //}
                                    }
                                    else
                                    {
                                        //Also fail row match if the element count of the page data row is 0
                                        if (iElementCounter > 0)
                                        {
                                            bThisRowMatches = false;
                                        }
                                    }
                                    iElementCounter++;
                                }

                                if (AppTableRow.Length == 0)
                                {
                                    //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                    bThisRowMatches = false;
                                }
                                //Instance of TableRow Class for reporting functions
                                var TableRow = new TMSString();
                                //If we get here and we still match, then the array elements were the same

                                if (bThisRowMatches)
                                {
                                    //report the success stuff.  Puts out the row data, etc.
                                    thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                                    break; 
                                }
                               // break;
                            }
                        }
                        iTableCounter++;
                    }
                    //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                    Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);

                    if (fullMatching)
                    {
                        Console.WriteLine("All rows are matched, step completed as passed");
                    }
                    else
                    {
                        //Click next page link and start over.
                        if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                        {
                            thisTP.bNotAtLastPageOfRecords = true;
                            thisTP.NPL.Click();
                            tmsWait.Hard(2);
                        }
                    }
                    baseTable = p1;

                    //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                    //Time to boil it down and report which rows didn't get matched.
                    //Also to fail because we were planning to match the rows.
                    if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                    {
                        thisTP.ReportNotMatching(thisGT.GTable);
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Members View Edit Table has row: {0}", e.Message);
            }
        }

        [Then(@"Verify Member HCC Details Information page pagination is displayed for ""(.*)""")]
        public void ThenVerifyMemberHCCDetailsInformationPagePaginationIsDisplayedFor(string p0)
        {
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//strong[1]")).Displayed);
        }

        [Then(@"RSM will be closed")]
        [Then(@"CDM will be closed")]        
        public void ThenRSMWillBeClosed()
        {
           //Browser.CloseWebDriver();
        }


        [When(@"Member HCC Details Information page Demographic HCCs on File for Member Sort link is clicked for column ""(.*)""")]
        public void WhenMemberHCCDetailsInformationPageDemographicHCCsOnFileForMemberSortLinkIsClickedForColumn(string p0)
        {
            string columnName = tmsCommon.GenerateData(p0);

            switch (columnName.ToLower())
            {
                case "payment year":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='demographic-grid-demographicGrid']//span[contains(.,'Payment Year')]/span")));
                    break;
            }

        }

        [Then(@"Verify Member HCC Details Information page Demographic HCCs on File table is sorted and ""(.*)"" is displayed in ""(.*)"" order")]
        public void ThenVerifyMemberHCCDetailsInformationPageDemographicHCCsOnFileTableIsSortedAndIsDisplayedInOrder(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string expectedorder = tmsCommon.GenerateData(p1);
            bool sort_flag = false;
            switch(field.ToLower())
            {
                case "payment year":
                    IWebElement p_1 = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='demographic-grid-demographicGrid']//tbody/tr[1]/td[1]"));
                    IWebElement p_2 = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='demographic-grid-demographicGrid']//tbody/tr[2]/td[1]"));


                    int PaymentYear_First = Int32.Parse(p_1.Text);
                    int PaymentYear_Second = Int32.Parse(p_2.Text);
                    if (expectedorder.ToLower().Equals("asending"))
                    {
                        IWebElement selected_asending = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='demographic-grid-demographicGrid']//span[contains(.,'Payment Year')]/span"));
                        if (selected_asending.Displayed)
                        {
                            if (PaymentYear_First < PaymentYear_Second)
                            {
                                sort_flag = true;
                            }
                        }
                    }
                    else if (expectedorder.ToLower().Equals("desending"))
                    {
                        IWebElement selected_desending = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='demographic-grid-demographicGrid']//span[contains(.,'Payment Year')]/span"));
                        if (selected_desending.Displayed)
                        {
                            if (PaymentYear_First > PaymentYear_Second)
                            {
                                sort_flag = true;
                            }
                        }
                    }
                    break;
            }

            Assert.IsTrue(sort_flag, "Payment Year Column is sorted successfully");
        }

    }

}
