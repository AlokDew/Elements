﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
//using System.Windows.Forms;
using TechTalk.SpecFlow;

namespace TMSoR1
{
    [Binding]
    class fsAdmin_CMS_Sweeps_Dates
    {
        string inputValue, actualValue, expectedValue;

        [Then(@"Verify Administration page should displayed with title ""(.*)""")]
        public void ThenVerifyAdministrationPageShouldDisplayedWithTitle(string p0)
        {
            expectedValue = p0.ToString();
            actualValue = RSM.CMSSweepsRiskCutOverDates.PageTitle.Text.ToString();
            Assert.AreEqual(actualValue,expectedValue,"Both value are macthing");
        }

        [Then(@"Verify Administration page should displayed with title ""(.*)"" label")]
        public void ThenVerifyAdministrationPageShouldDisplayedWithTitleLabel(string p0)
        {
            expectedValue = p0.ToString();
            Assert.IsTrue(RSM.CMSSweepsRiskCutOverDates.DateType.Displayed, "Date Type label is displayed");
        }

        [Then(@"Verify CMS Sweeps/Risk Cut Over Dates label page ""(.*)"" text should displayed")]
        public void ThenVerifyCMSSweepsRiskCutOverDatesLabelPageTextShouldDisplayed(string p0)
        {
            expectedValue = p0.ToString();
            actualValue = RSM.CMSSweepsRiskCutOverDates.SweepsEndDateText.Text;
            Assert.AreEqual(expectedValue,actualValue,"Both value are matched");
            Assert.IsTrue(RSM.CMSSweepsRiskCutOverDates.SweepsDate.Displayed, "Sweeps Dates text box is displayed");
        }


        [Then(@"Verify CMS Sweeps/Risk Cut Over Dates label page ""(.*)"" dropdown Lable should be displayed")]
        public void ThenVerifyCMSSweepsRiskCutOverDatesLabelPageDropdownLableShouldBeDisplayed(string p0)
        {
            tmsWait.Hard(5);
            inputValue = p0.ToString();
            switch (inputValue) {
                case "Date Type":
                    ////
                    break;
                case "Payment Year":
                    Assert.IsTrue(RSM.CMSSweepsRiskCutOverDates.RiskScorePaymentYear.Displayed, "Payment year drop down is displayed");
                    break;
                case "Sweeps Date/Payment Year":
                    Assert.IsTrue(RSM.CMSSweepsRiskCutOverDates.SweepsPaymentYear.Displayed, "Payment year drop down is displayed");
                    break;
                case "Sweeps Date/Year Type":
                    Assert.IsTrue(RSM.CMSSweepsRiskCutOverDates.SweepsYearType.Displayed, "Year year drop down is displayed");
                    break;
            }
        }

        [Then(@"Verify the CMS Sweeps/Risk Cut Over Dates page Date Type should selected Sweeps Date radio button by default")]
        public void ThenVerifyTheCMSSweepsRiskCutOverDatesPageDateTypeShouldSelectedSweepsDateRadioButtonByDefault()
        {
            var pp = RSM.CMSSweepsRiskCutOverDates.SweepsDate.Selected;
            var ss = RSM.CMSSweepsRiskCutOverDates.RiskScoreCutOverDates.Selected;
           // Assert.IsTrue(RSM.CMSSweepsRiskCutOverDates.SweepsDate.Selected, "Sweeps Date Radio Button is selected");
        }


        [Then(@"Verify CMS Sweeps/Risk Cut Over Dates label page ""(.*)"" radio button is clicked")]
        [When(@"Verify CMS Sweeps/Risk Cut Over Dates label page ""(.*)"" radio button is clicked")]
        public void ThenVerifyCMSSweepsRiskCutOverDatesLabelPageRadioButtonIsClicked(string p0)
        {
            tmsWait.Hard(2);
            inputValue = p0.ToString();
            switch (inputValue) {
                case "Sweeps Date":
                    
                    RSM.CMSSweepsRiskCutOverDates.SweepsDate.Click();
                    break;
                case "Risk Score Cut Over Dates":
                    
                    RSM.CMSSweepsRiskCutOverDates.RiskScoreCutOverDates.Click();
                    break;
            }
        }

        [Then(@"Verify CMS Sweeps/Risk Cut Over Dates label page ""(.*)"" label displayed with Start Date and End Date text box as blank")]
        public void ThenVerifyCMSSweepsRiskCutOverDatesLabelPageLabelDisplayedWithStartDateAndEndDateTextBoxAsBlank(string p0)
        {
            inputValue = p0.ToString();
            switch (inputValue) {
                case "FISCAL":
                    //var hh = RSM.CMSSweepsRiskCutOverDates.FiscalStartDate.Displayed;
                    Assert.IsTrue(RSM.CMSSweepsRiskCutOverDates.FiscalStartDate.Displayed, "FISCAL Start Date displayed");
                    Assert.IsTrue(RSM.CMSSweepsRiskCutOverDates.FiscalEndDate.Displayed, "FISCAL End Date displayed");
                    break;
                case "CALENDAR":
                    Assert.IsTrue(RSM.CMSSweepsRiskCutOverDates.CalendarStartDate.Displayed, "CALENDAR Start Date displayed");
                    Assert.IsTrue(RSM.CMSSweepsRiskCutOverDates.CalendarEndDate.Displayed, "CALENDAR End Date displayed");
                    break;
                case "FINAL":
                    Assert.IsTrue(RSM.CMSSweepsRiskCutOverDates.FinalStartDate.Displayed, "FINAL Start Date displayed");
                    Assert.IsTrue(RSM.CMSSweepsRiskCutOverDates.FinalEndDate.Displayed, "FINAL End Date displayed");
                    break;
            }
        }
        [Then(@"Verify CMS Sweeps/Risk Cut Over Dates label page ""(.*)"" lable Start Date and End Date text box should be readonly")]
        public void ThenVerifyCMSSweepsRiskCutOverDatesLabelPageLableStartDateAndEndDateTextBoxShouldBeReadonly(string p0)
        {
            IWebElement FinalStartDate = RSM.CMSSweepsRiskCutOverDates.FinalStartDate;
            string FinalStartDatereadonly = FinalStartDate.GetAttribute("readonly");
            Assert.IsNotNull(FinalStartDatereadonly);

            IWebElement FinalEndDate = RSM.CMSSweepsRiskCutOverDates.FinalEndDate;
            string readonlyFinalEndDate = FinalStartDate.GetAttribute("readonly");
            Assert.IsNotNull(readonlyFinalEndDate);

        }

        [Then(@"Verify CMS Sweeps/Risk Cut Over Dates label page ""(.*)"" button should be displayed")]
        public void ThenVerifyCMSSweepsRiskCutOverDatesLabelPageButtonShouldBeDisplayed(string p0)
        {
            string buttonName = p0.ToString();
            switch (buttonName) {
                case "RiskScore/Save":
                    Assert.IsTrue(RSM.CMSSweepsRiskCutOverDates.RiskScoreSave.Displayed, "Save Button is dispalyed");
                    break;
                case "RiskScore/Reset":
                    Assert.IsTrue(RSM.CMSSweepsRiskCutOverDates.RiskScoreReset.Displayed, "Save Button is dispalyed");
                    break;
                case "Sweeps Date/Reset":
                    //var dd = RSM.CMSSweepsRiskCutOverDates.SweepReset.Displayed;
                    Assert.IsTrue(RSM.CMSSweepsRiskCutOverDates.SweepsReset.Displayed,"Reset Button is displayed");
                    break;
                case "Sweeps Date/Save":
                    Assert.IsTrue(RSM.CMSSweepsRiskCutOverDates.SweepsSave.Displayed, "Save Button is displayed");
                    break;
            }
        }

        [When(@"CMS Sweeps/Risk Cut Over Dates page Payment Year dropdown is set to ""(.*)""")]
        [Then(@"CMS Sweeps/Risk Cut Over Dates page Payment Year dropdown is set to ""(.*)""")]
        public void WhenCMSSweepsRiskCutOverDatesPagePaymentYearDropdownIsSetTo(int p0)
        {
            string paymentYearValue = p0.ToString();
            SelectElement paymentYear = new SelectElement(RSM.CMSSweepsRiskCutOverDates.RiskScorePaymentYear);
            paymentYear.SelectByText(paymentYearValue);
            
        }

        [When(@"CMS Sweeps/Risk Cut Over Dates page Payment Year dropdown is set to Sweeps Date ""(.*)""")]
        public void WhenCMSSweepsRiskCutOverDatesPagePaymentYearDropdownIsSetToSweepsDate(int p0)
        {

            string paymentYearValue = p0.ToString();
            SelectElement paymentYear = new SelectElement(RSM.CMSSweepsRiskCutOverDates.SweepsPaymentYear);
            paymentYear.SelectByText(paymentYearValue);
        }


        [When(@"CMS Sweeps/Risk Cut Over Dates page Year Type dropdown is set to ""(.*)""")]
        public void WhenCMSSweepsRiskCutOverDatesPageYearTypeDropdownIsSetTo(string p0)
        {
            string YearTypeValue = p0.ToString();
            SelectElement YearType = new SelectElement(RSM.CMSSweepsRiskCutOverDates.SweepsYearType);
            YearType.SelectByText(YearTypeValue);
        }

        [When(@"CMS Sweeps/Risk Cut Over Dates page Sweeps End Date row set to ""(.*)""")]
        public void WhenCMSSweepsRiskCutOverDatesPageSweepsEndDateRowSetTo(string p0)
        {
            IWebElement element = Browser.Wd.FindElement(By.CssSelector("[test-id='rsmSweepsRisk-txt-transEnd']"));
            tmsWait.Hard(2);
            element.Clear();
            tmsWait.Hard(2);
            element.SendKeys(p0);
        }

        [When(@"CMS Sweeps/Risk Cut Over Dates page Sweeps valid End Date row set")]
        public void WhenCMSSweepsRiskCutOverDatesPageSweepsValidEndDateRowSet()
        {
            DateTime inputValue1 = DateTime.Now;
            DateTime dd = inputValue1.AddDays(-3);
            string[]  ddd = dd.ToString().Split(' ');
            string[] dddd = ddd[0].Split('/');
            RSM.CMSSweepsRiskCutOverDates.SweepsEndDate.Clear();
            
            if (dddd[0].Length != 2 || dddd[1].Length != 2)
            {
                if (dddd[0].Length != 2)
                {
                    if (dddd[0].Length == 1)
                    {
                        dddd[0] = "0" + dddd[0];
                    }
                }
                if (dddd[1].Length != 2)
                {
                    dddd[1] = "0" + dddd[1];
                }

                tmsWait.Hard(1);
                string adate = dddd[0] + "/" + dddd[1] + "/" + dddd[2];
                RSM.CMSSweepsRiskCutOverDates.SweepsEndDate.SendKeys(adate);
            }
            else
            {
                tmsWait.Hard(1);
                RSM.CMSSweepsRiskCutOverDates.SweepsEndDate.SendKeys(ddd[0]);
            }
            

            
        }


        [When(@"CMS Sweeps/Risk Cut Over Dates page ""(.*)"" row set to ""(.*)""")]
        [Then(@"CMS Sweeps/Risk Cut Over Dates page ""(.*)"" row set to ""(.*)""")]
        public void WhenCMSSweepsRiskCutOverDatesPageRowSetTo(string p0, string p1)
        {
            tmsWait.Hard(2);
            string yeartype = p0.ToString();
            string EndDate = p1.ToString();
            switch (yeartype) {
                case "FISCAL":
                    RSM.CMSSweepsRiskCutOverDates.FiscalEndDate.Clear();
                    RSM.CMSSweepsRiskCutOverDates.FiscalEndDate.Click();
                    RSM.CMSSweepsRiskCutOverDates.FiscalEndDate.SendKeys(EndDate);
                    break;
                case "CALENDAR":
                    RSM.CMSSweepsRiskCutOverDates.CalendarEndDate.Clear();
                    RSM.CMSSweepsRiskCutOverDates.CalendarEndDate.Click();
                    RSM.CMSSweepsRiskCutOverDates.CalendarEndDate.SendKeys(EndDate);
                    break;
            }
        }

        [When(@"CMS Sweeps/Risk Cut Over Dates page ""(.*)"" button is clicked")]
        [Then(@"CMS Sweeps/Risk Cut Over Dates page ""(.*)"" button is clicked")]
        public void WhenCMSSweepsRiskCutOverDatesPageButtonIsClicked(string p0)
        {
            tmsWait.Hard(4);
            switch (p0.ToString()) {
                case "Save":
                    tmsWait.Hard(1);
                    fw.ExecuteJavascript(RSM.CMSSweepsRiskCutOverDates.RiskScoreSave);
                    break;
                case "Reset":
                    fw.ExecuteJavascript(RSM.CMSSweepsRiskCutOverDates.RiskScoreReset);
                    break;
                case "Sweeps Date/Save":
                    //var hh = RSM.CMSSweepsRiskCutOverDates.SweepsSave;
                    fw.ExecuteJavascript(RSM.CMSSweepsRiskCutOverDates.SweepsSave);
                    break;
                case "Sweeps Date/Reset":
                    fw.ExecuteJavascript(RSM.CMSSweepsRiskCutOverDates.SweepsReset);
                    break;
            }
        }

        [Then(@"Verify CMS Sweeps/Risk Cut Over Dates page ""(.*)"" error message should be displayed")]
        public void ThenVerifyCMSSweepsRiskCutOverDatesPageErrorMessageShouldBeDisplayed(string p0)
        {
            expectedValue = p0.ToString();
            //UnhandledAlertException alertText = UnhandledAlertException.GetAlertText();
            actualValue = Browser.Wd.FindElement(By.XPath("//div[starts-with(.,'"+expectedValue+"')]")).Text;
            Assert.AreEqual(expectedValue,actualValue,"Both value are matched");
        }
        [Then(@"Verify CMS Sweeps/Risk Cut Over Dates page ""(.*)"" message should be displayed")]
        public void ThenVerifyCMSSweepsRiskCutOverDatesPageMessageShouldBeDisplayed(string p0)
        {
            expectedValue = p0.ToString();
            actualValue = Browser.Wd.FindElement(By.XPath("//div[starts-with(.,'"+ expectedValue+"')]")).Text;
            Assert.AreEqual(expectedValue, actualValue, "Both value are matched");

            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(10);
        }

        [Then(@"Verify CMS Sweeps/Risk Cut Over Dates page ""(.*)"" message should be displayed properly")]
        public void ThenVerifyCMSSweepsRiskCutOverDatesPageMessageShouldBeDisplayedProperly(string expectedValue)
        {
            IWebElement element = Browser.Wd.FindElement(By.CssSelector("[test-id='rsmSweepsRisk-btn-save1']"));
            fw.ExecuteJavascript(element);

            By toastMsg = By.XPath("//div[@class='k-notification-content']");
            string actValue = Browser.Wd.FindElement(toastMsg).Text;
            Assert.IsTrue(actValue.Contains(expectedValue));
        }


        [Then(@"Verify CMS Sweeps/Risk Cut Over Dates page ""(.*)"" button is disabled")]
        public void ThenVerifyCMSSweepsRiskCutOverDatesPageButtonIsDisabled(string p0)
        {
            //var saveButton = RSM.CMSSweepsRiskCutOverDates.Save.Selected;
            Assert.IsFalse(RSM.CMSSweepsRiskCutOverDates.RiskScoreSave.Selected,"Save Button is disabled");
        }

        [Then(@"Verify CMS Sweeps/Risk Cut Over Dates page FINAL Start Date value")]
        public void ThenVerifyCMSSweepsRiskCutOverDatesPageFINALStartDateValue()
        {
            try
            {
                if (RSM.CMSSweepsRiskCutOverDates.FinalStartDate.Displayed)
                {

                    IWebElement StartDate = Browser.Wd.FindElement(By.CssSelector("input[ng-model='srcd.risk.final.startDate']"));
                    //var InitialstartDate = StartDate.GetAttribute("value");
                    GlobalRef.InitialstartDate = StartDate.GetAttribute("value");
                    Console.WriteLine("Initial start date of Final year is : " + GlobalRef.InitialstartDate.ToString());
                }
            }
            catch (NoSuchElementException ex)
            {
                GlobalRef.InitialstartDate = "0";
                Console.WriteLine(" start date of Final year is not displayed on Home page." + GlobalRef.InitialstartDate.ToString());
            }
        }

        [Then(@"Verify CMS Sweeps/Risk Cut Over Dates page FINAL Start Date value get updated with respect to year entered")]
        public void ThenVerifyCMSSweepsRiskCutOverDatesPageFINALStartDateValueGetUpdatedWithRespectToYearEntered()
        {
            tmsWait.Hard(2);
            int Calenderyear = 0, Finalyear= 0;
            try
            {
                if (RSM.CMSSweepsRiskCutOverDates.FinalStartDate.Displayed)
                {
                    IWebElement CalendarEndDateObject = Browser.Wd.FindElement(By.CssSelector("input[ng-model='srcd.risk.calendar.endDate']"));
                    GlobalRef.CalendarEndDate = CalendarEndDateObject.GetAttribute("value");
                    Console.WriteLine("Final start date of FINAL year is : " + GlobalRef.CalendarEndDate.ToString());
                    var CalendarEndDate = GlobalRef.CalendarEndDate;
                    string CalendarEndDateArray = Convert.ToString(CalendarEndDate);
                    if (CalendarEndDateArray.Contains('/'))
                    {
                        string[] CalenderDateArray = CalendarEndDateArray.Split('/');
                        Calenderyear = Convert.ToInt32(CalenderDateArray[2]);
                    }
                    else
                    {
                        Assert.Fail("Date is either empty from FINAL Start Date text box or in invalid format");
                    }


                    // Code to fetch the Final year start date

                    IWebElement FinalStartDateObject = Browser.Wd.FindElement(By.CssSelector("input[ng-model='srcd.risk.final.startDate']"));
                    GlobalRef.FinalstartDate = FinalStartDateObject.GetAttribute("value");
                    Console.WriteLine("Final start date of FINAL year is : " + GlobalRef.FinalstartDate.ToString());
                    var FinalStartDate = GlobalRef.FinalstartDate;
                    string FinalStartDateArray = Convert.ToString(FinalStartDate);
                    if (FinalStartDateArray.Contains('/'))
                    {
                        string[] FinalDateArray = FinalStartDateArray.Split('/');
                        Finalyear = Convert.ToInt32(FinalDateArray[2]);
                    }
                    else
                    {
                        Assert.Fail("Date is either empty from FINAL Start Date text box or in invalid format");
                    }

                     Assert.IsTrue(Finalyear > Calenderyear, "Final Year date is changed as per functionality");
                }
            }
            catch (NoSuchElementException ex)
            {
                bool res = (Finalyear == Calenderyear);
                Assert.IsTrue(res, "Final Year date is not changed as per functionality");
            }
        }


    }
}
