﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
//using System.Windows.Forms;
using TechTalk.SpecFlow;
using TMSoR1.FrameworkCode;

namespace TMSoR1
{
    [Binding]
    class fsArchive
    {
        [When(@"Archive page Archive Year is selected as ""(.*)""")]
        public void WhenArchivePageArchiveYearIsSelectedAs(string year)
        {
            SelectElement archive = new SelectElement(RSM.Archive.ArchiveYear);
            archive.SelectByText(year);
        }

        [Then(@"Archive page Submit Job is clicked")]
        public void ThenArchivePageSubmitJobIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(RSM.Archive.SubmitJob);
            tmsWait.Hard(5);
        }

        [Then(@"Verify the Archive page has data ""(.*)""")]
        public void ThenVerifyTheArchivePageHasData(string datatable)
        {
            int actualCount = 0;
            int index = 1;
            Regex pattern = new Regex(@"\((?<name>.+?)=(?<value>.+?)\)");
            var archiveTable = Enumerable.Cast<Match>(pattern.Matches(datatable)).ToDictionary(m => m.Groups["name"].Value, m => m.Groups["value"].Value);
            foreach (KeyValuePair<string, string> pair in archiveTable)
            {
                for (; index <= archiveTable.Count;)
                {
                    if (Browser.Wd.FindElement(By.XPath("//*[@id='archiveGird']//div[2]//div[" + index + "]/div/div[2]/div")).Text.Equals(pair.Key) && Browser.Wd.FindElement(By.XPath("//*[@id='archiveGird']//div[2]//div[" + index + "]/div/div[6]/div")).Text.Equals(pair.Value))
                    {
                        actualCount++;
                        index++;
                        break;
                    }
                    else
                    {
                        actualCount--;
                        index++;
                        break;
                    }
                }
            }
            Assert.IsTrue(actualCount == archiveTable.Count, "Archive table data is not completed...");
        }


        [Then(@"Archive page Page of size ""(.*)"" is entered")]
        public void ThenArchivePagePageOfSizeIsEntered(string size)
        {
            RSM.Archive.PageSize.Clear();
            RSM.Archive.PageSize.SendKeys(size);
            
           // SendKeys.SendWait("{ENTER}");
            

            DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_RETURN, 0, 0, 0);

        }

        

        [Then(@"Verify Manage Provider Specialty page displays No Record")]
        public void ThenVerifyManageProviderSpecialtyPageDisplaysNoRecord()
        {
            tmsWait.Hard(3);
            By loc = By.XPath("//span[@class='k-pager-info k-label'][contains(.,'No items to display')]");
            UIMODUtilFunctions.elementNotPresenceUsingLocators(loc);
        }
        [Then(@"Verify Member Look up message ""(.*)""")]
        public void ThenVerifyMemberLookUpMessage(string expectedValue)
        {
            By toastMsg = By.XPath("(//td[contains(.,'" + expectedValue + "')])[2]");
            AngularFunction.elementPresenceUsingLocators(toastMsg);
        }


        [Then(@"Verify Message ""(.*)""")]
        public void ThenVerifyMessage(string expectedValue)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By toastMsg = By.XPath("//div[@class='k-notification-content']");
                string actValue = Browser.Wd.FindElement(toastMsg).Text;
                Assert.IsTrue(actValue.Contains(expectedValue));
            }          
            else
            {
                string actualValue = Browser.Wd.FindElement(By.XPath("//div[@class='toast-message']")).GetAttribute("aria-label");
                Assert.IsTrue(actualValue.Contains(expectedValue));
            }
        }
        [Then(@"CDM Manage Provider Specialty page Filtering logic switch is clicked and Verify Message")]
        [When(@"CDM Manage Provider Specialty page Filtering logic switch is clicked and Verify Message")]
        public void ThenCDMManageProviderSpecialtyPageFilteringLogicSwitchIsClickedAndVerifyMessage()
        {
            tmsWait.Hard(2);
            //   Browser.Wd.FindElement(By.XPath("//*[@id='mainContant']/div[1]/div/div/div[2]/div[1]/span/span[2]")).Click();
            //Browser.Wd.FindElement(By.XPath("//span[contains(@class,'k-switch-handle km-switch-handle')]")).Click();
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(@class,'k-switch-handle')]"))); 
            //tmsWait.Hard(1);
        }


        [Then(@"Verify Message New ""(.*)""")]
        public void ThenVerifyMessageNew(string expectedValue)
        {
            // tmsWait.Hard(1);
            // string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
            ReUsableFunctions.toasterMessageDisplayWithoutWait(expectedValue);
            //  Assert.IsTrue(actualValue.Contains(expectedValue));
            //Assert.AreEqual(expectedValue, actualValue, "Job is not submitted");
        }

        [Then(@"Verify Expected Member ""(.*)"" is not displayed")]
        public void ThenVerifyExpectedMemberIsNotDisplayed(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
           
                ReUsableFunctions.enterValueOnWebElementWithoutClear(cfUIMODViewEditMember.MemberLookup.MBI, value);
                //ReUsableFunctions.clickOnWebElement(cfUIMODViewEditMember.ViewEditMemberPage.MBILookup);
               tmsWait.Hard(3);
            //ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODViewEditMember.MemberLookup.MBI, GeneratedData);
            ReUsableFunctions.clickOnWebElement(cfUIMODViewEditMember.ViewEditMemberPage.SearchBtn);
            tmsWait.Hard(1);
            By toastMsg = By.XPath("//div[@class='k-notification-content']");
            string actValue = Browser.Wd.FindElement(toastMsg).Text;
            Assert.IsTrue(actValue.Contains("No records to display"), "Record is displayed which is not the expected one");
            //ReUsableFunctions.clickOnWebElement(cfUIMODViewEditMember.MemberLookup.SearchBtn);
            //tmsWait.Hard(1);

            //By mbiValue = By.XPath("//div[@role='presentation'][contains(.,'No records available.')]");
            //UIMODUtilFunctions.elementNotPresenceUsingLocators(mbiValue);

            //By closeButton = By.CssSelector("[test-id='member-btn-cancel']");
            //UIMODUtilFunctions.clickOnWebElementUsingLocators(closeButton);



            // string mbi = tmsCommon.GenerateData(p0);
            // Browser.Wd.FindElement(By.XPath("//input[@placeholder='Add MBI']")).SendKeys(mbi);
            // fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='memberSearch-btn-search']")));
            //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@id='membersDataGrid']//span[contains(.,'No items to display')]")).Displayed);

        }


        [Then(@"Archive page Last page is clicked")]
        public void ThenArchivePageLastPageIsClicked()
        {
            fw.ExecuteJavascript(RSM.Archive.LastPageLink);
        }

        [Then(@"Verify Total number rows archived is """"(.*)""(.*)""")]
        public void ThenVerifyTotalNumberRowsArchivedIs(int rows, int year)
        {
            

        }

        [Then(@"Verify Total number rows archived is ""(.*)"" for year ""(.*)""")]
        public void ThenVerifyTotalNumberRowsArchivedIsForYear(int expectedrow, int expectedyear)
        {
            Boolean ispresent = false;
            string totalrows = Browser.Wd.FindElement(By.XPath(".//div[Starts-with(text(), '0')]")).Text;
            string years = Browser.Wd.FindElement(By.XPath(".//div[Starts-with(text(), '2013')]")).Text;
            int actualrow = Int32.Parse(totalrows);
            int actualyear = Int32.Parse(years);
            if (actualyear == expectedyear && actualrow == expectedrow)
            {
                ispresent = true;
            }

            Assert.IsTrue(ispresent);
        }


    }
}
