﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;

using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using System.Windows.Forms;
using TechTalk.SpecFlow;
using TMSoR1.FrameworkCode;

namespace TMSoR1
{
    [Binding]
    class fsMemberDiscrepancy
    {
        string inputlookupvalue, xpath;
        [When(@"RSM Application Reports Section is Clicked")]
        public void WhenRSMApplicationReportsSectionIsClicked()
        {
            fw.ExecuteJavascript(RSM.RSMHomePage.Reports);
            tmsWait.Hard(5);
        }


        [When(@"Report List section ""(.*)"" link is Clicked")]
        public void WhenReportListSectionLinkIsClicked(string p0)
        {
            tmsWait.Hard(2);
            string report = p0.ToString();
            switch (report)
            {
                case "HCC Details":
                    fw.ExecuteJavascript(RSM.HCCRxHCCReport.HCCDetailsLink);
                    break;
                case "Risk Score Trend Details":
                    fw.ExecuteJavascript(RSM.RiskScoreTrendReport.RiskScoreTrendDetailsLink);
                    break;

            }
            tmsWait.Hard(5);
        }

        [Then(@"Verify PCP Search Criteria page displays Toaster message as ""(.*)""")]
        public void ThenVerifyPCPSearchCriteriaPageDisplaysToasterMessageAs(string p0)
        {
            string expected = p0.ToString();
            string actual = Browser.Wd.FindElement(By.XPath("//div[@class='toast-message']")).Text;

            Assert.AreEqual(expected, actual, expected + "is not getting displayed");
        }


        [Then(@"PCP Search Criteria ""(.*)"" value is set to ""(.*)""")]
        public void ThenPCPSearchCriteriaValueIsSetTo(string p0, string p1)
        {
            fw.ExecuteJavascript(RSM.Lookups.PCPLookUp.PCPLoookBackToRecord);
        }

        [Then(@"Verify Risk Score Trend Details report page ""(.*)"" field is set to ""(.*)""")]
        public void ThenVerifyRiskScoreTrendDetailsReportPageFieldIsSetTo(string field, string names)
        {

           
            string[] namesArray = names.Split(',');
            bool elementpresence = false;
            switch (field)
            {
                case "PCP":
                    if ((namesArray.Length == 1) && (namesArray[0].Equals("")))
                    {
                        elementpresence = true;

                        Assert.IsTrue(elementpresence);
                        fw.ConsoleReport(" There is no Element Present");

                    }
                    else if (namesArray.Length >= 1)
                    {

                        foreach (string name in namesArray)
                        {

                            elementpresence = Browser.Wd.FindElement(By.XPath("//*[@test-id='PCP_ID']//ul/li[contains(.,'" + name + "')]")).Displayed;
                            Assert.IsTrue(elementpresence, name + " is not Found");
                            fw.ConsoleReport(name + " is Found");

                        }
                    }
                    break;

                case "HCC":

                    if ((namesArray.Length == 1) && (namesArray[0].Equals("")))
                    {

                        IReadOnlyCollection<IWebElement> elementPre = Browser.Wd.FindElements(By.XPath("//tags-input[@test-id='searchMemberDiscrepancy-txt-hcc']//ul"));
                        foreach (IWebElement element in elementPre)
                        {
                            if (element.Text.Equals(namesArray[0]))
                            {
                                elementpresence = true;
                            }
                        }

                        Assert.IsTrue(elementpresence, "Element is found");
                        fw.ConsoleReport(" There is no Element Present");

                    }
                    else if (namesArray.Length > 1)
                    {

                        foreach (string name in namesArray)
                        {
                            elementpresence = Browser.Wd.FindElement(By.XPath("//tags-input[@test-id='searchMemberDiscrepancy-txt-hcc']//ul/li[contains(.,'" + name + "')]")).Displayed;
                            Assert.IsTrue(elementpresence, name + " is not Found");
                            fw.ConsoleReport(name + " is Found");

                        }
                    }
                    break;
            }


        }


        string parentwindow = null;
        [Then(@"Risk Score Trend Details page Run Report button is Clicked")]
        public void ThenRiskScoreTrendDetailsPageRunReportButtonIsClicked()
        {
            string newurl = null;
             parentwindow = Browser.Wd.CurrentWindowHandle;
            tmsWait.Hard(2);
            RSM.RiskScoreTrendDetails.RunReportButton.Click();

            //System.Windows.Forms.SendKeys.Send("myUser");

            //System.Windows.Forms.SendKeys.Send("{TAB}");
            //System.Windows.Forms.SendKeys.Send("MyPassword");
            //System.Windows.Forms.SendKeys.Send("~"); // Enter
        
            IAlert alert = Browser.Wd.SwitchTo().Alert();

            //alert.SendKeys("tmsremote");
            //DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_TAB, 0x8f, 0, 0);
            //    DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_TAB, 0x8f, 0, 0);



            //    //System.Windows.Forms.SendKeys.SendWait("{TAB}");


            //    alert.SendKeys("TriZetto456");
            alert.Dismiss();
         
            System.Collections.ObjectModel.ReadOnlyCollection<string> handles = Browser.Wd.WindowHandles;
            foreach (string handle in handles)
            {

                if(Browser.Wd.SwitchTo().Window(handle).Title.Equals(""))
                {                 
                    string url = Browser.Wd.Url;
                     newurl=url.Insert(8, "tmsremote:TriZetto456@");
                    Browser.Wd.SwitchTo().Window(handle).Close();
                      break;
                }
                //if(Browser.Wd.SwitchTo().Window(handle).Title.Equals("TMS"))
                //{
                //    Browser.Wd.SwitchTo().Window(handle);
                //   // Browser.Wd.FindElement(By.CssSelector("body")).SendKeys(OpenQA.Selenium.Keys.Control + "t");
                //    Browser.Wd.SwitchTo().Window(handle).Navigate().GoToUrl(newurl);

                //    // //System.Windows.Forms.SendKeys.SendWait("^{T}");
                //}
            }

            Browser.Wd.SwitchTo().Window(parentwindow).Navigate().GoToUrl(newurl);


        }

        [When(@"HCC Details Report accordion section ""(.*)"" link is Clicked")]
        public void WhenHCCDetailsReportAccordionSectionLinkIsClicked(string p0)
        {
            fw.ExecuteJavascript(RSM.LookupsIcons.GruopIDLookupicon);
            tmsWait.Hard(10);
        }

        [Then(@"Verify Risk Score Trend Details Report page displayed HIC value as ""(.*)""")]
        public void ThenVerifyRiskScoreTrendDetailsReportPageDisplayedHICValueAs(string p0)
        {
            string HIC = tmsCommon.GenerateData(p0);
            IWebElement hic = Browser.Wd.FindElement(By.XPath(string.Format("//div[text()='{0}']", HIC)));
            Assert.IsTrue(hic.Displayed, p0 + " HIC Number is not displayed");
        }

        [Then(@"Verify Risk Score Trend Details Report page displayed selected HIC value")]
        [When(@"Verify Risk Score Trend Details Report page displayed selected HIC value")]
        public void ThenVerifyRiskScoreTrendDetailsReportPageDisplayedSelectedHICValue()
        {
            var hicMemberSearch = GlobalRef.HICMemberSearchCriteria;
            Browser.SwitchToChildWindow();
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//input[@id='ReportViewerControl_ctl04_ctl13_txtValue']")).GetAttribute("value").Equals(hicMemberSearch));
        }

        [When(@"I Clicked on ""(.*)"" Expand Menu")]
        public void WhenIClickedOnExpandMenu(string p0)
        {
            string menustring = "//div[@test-id='menu-ddl-applicationNavigation"+p0+"Icon1']";
            tmsWait.Hard(5);
            IWebElement expand = Browser.Wd.FindElement(By.CssSelector("[test-id='header-btn-productDetails']"));
            fw.ExecuteJavascript(expand);
            tmsWait.Hard(5);
            IWebElement menu = Browser.Wd.FindElement(By.XPath(menustring));
            fw.ExecuteJavascript(menu);
            tmsWait.Hard(10);
        }


        [When(@"I Clicked on Elements Expand Menu")]
        
        [When(@"I Clicked on RSM Expand Menu")]
        public void WhenIClickedOnRSMExpandMenu()
        {
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(5);
            //fw.ExecuteJavascript(RSM.RSMHomePage.Reports);
            fw.ExecuteJavascript(RSM.RSMHomePage.RSMExpandMenu);
        }


        [When(@"Member Search Criteria page Page size field is set to ""(.*)""")]
        public void WhenMemberSearchCriteriaPagePageSizeFieldIsSetTo(string size)
        {
         
            RSM.Lookups.HICLookUp.pageSizeTextbox.Clear();
            RSM.Lookups.HICLookUp.pageSizeTextbox.SendKeys(size);
            RSM.Lookups.HICLookUp.HICSearch.Click();


        }
        [When(@"PCP Search Criteria page Page size field is set to ""(.*)""")]
        public void WhenPCPSearchCriteriaPagePageSizeFieldIsSetTo(string p0)
        {
            RSM.Lookups.PCPLookUp.PCPLoookPageSize.Clear();
            RSM.Lookups.PCPLookUp.PCPLoookPageSize.SendKeys(p0);
            RSM.Lookups.PCPLookUp.PCPLookupSearch.Click();
        }


        [When(@"SCC Search Criteria page Page size field is set to ""(.*)""")]
        public void WhenSCCSearchCriteriaPagePageSizeFieldIsSetTo(string size)
        {
            tmsWait.Hard(5);
            RSM.Lookups.SCCLookUp.sccpageSizeTextbox.Clear();
            RSM.Lookups.SCCLookUp.sccpageSizeTextbox.SendKeys(size);
            

        }

        [When(@"RxHCC Search Criteria page Page size field is set to ""(.*)""")]
        public void WhenRxHCCSearchCriteriaPagePageSizeFieldIsSetTo(string p0)
        {
            fw.ExecuteJavascript(RSM.Lookups.RXHCCLookUp.RXHCCSearchButton);
            tmsWait.Hard(5);
            RSM.Lookups.RXHCCLookUp.RxHCCLoookupPageSize.Clear();
            RSM.Lookups.RXHCCLookUp.RxHCCLoookupPageSize.SendKeys(p0);
        }



        [When(@"HCC Search Criteria page Page size field is set to ""(.*)""")]
        public void WhenHCCSearchCriteriaPagePageSizeFieldIsSetTo(string size)
        {
            tmsWait.Hard(5);
            RSM.Lookups.HCCLookUp.HCCLoookupPageSize.Clear();
            RSM.Lookups.HCCLookUp.HCCLoookupPageSize.SendKeys(size);
        }

        [Then(@"Verify RxHCC Search Criteria page displayed ""(.*)"" Search results")]
        public void ThenVerifyRxHCCSearchCriteriaPageDisplayedSearchResults(string expRecords)
        {
            var actRecords = Browser.Wd.FindElements(By.XPath(".//*[@id='rxhccLookupGird']//div[@class='ui-grid-cell-contents ng-binding ng-scope']")).Count;
            string finalactRecords = (Convert.ToInt32(actRecords) / 2).ToString();


            Assert.AreEqual(finalactRecords, expRecords, expRecords + "is not getting displayed");
        }

        [Then(@"Verify HCC Search Criteria page displayed ""(.*)"" Search results")]
        public void ThenVerifyHCCSearchCriteriaPageDisplayedSearchResults(string expRecords)
        {
            tmsWait.Hard(5);
            var actRecords = Browser.Wd.FindElements(By.XPath(".//*[@id='hccLookupGird']//div[@class='ui-grid-cell-contents ng-binding ng-scope']")).Count;
            string finalactRecords = (Convert.ToInt32(actRecords) / 2).ToString();


            Assert.AreEqual(finalactRecords, expRecords, expRecords + "is not getting displayed");
        }

        [When(@"HCC Search Criteria page ""(.*)"" field is set to ""(.*)""")]
        public void WhenHCCSearchCriteriaPageFieldIsSetTo(string p0, string p1)
        {
            string field = p0.ToString();
            string value = p1.ToString();
            switch(field)
            {
                case "HCC Name":
                    RSM.Lookups.HCCLookUp.HCCName.SendKeys(value);
                    break;
                
            }
        }

        [When(@"HCC Search Criteria page ""(.*)"" button is Clicked")]
        public void WhenHCCSearchCriteriaPageButtonIsClicked(string p0)
        {
            string button = p0.ToString();
            switch(button)
            {
                case "Search":
                    fw.ExecuteJavascript(RSM.Lookups.HCCLookUp.HCCSearchButton);
                    break;
            }
            
        }

        [When(@"RX HCC Search Criteria page Search button is Clicked")]
        public void WhenRXHCCSearchCriteriaPageSearchButtonIsClicked()
        {
            RSM.Lookups.RXHCCLookUp.RXHCCSearchButton.Click();
        }


        [Then(@"Verify HCC Search Criteria page displayed Toaster message ""(.*)""")]
        public void ThenVerifyHCCSearchCriteriaPageDisplayedToasterMessage(string expected)
        {
            string actual = Browser.Wd.FindElement(By.XPath("//div[@on='allowHtml']/div")).Text;

            Assert.AreEqual(expected, actual, expected+" Toaster message is not getting displayed");
        }

        [When(@"RX HCC Search Criteria page ""(.*)"" is set to ""(.*)""")]
        public void WhenRXHCCSearchCriteriaPageIsSetTo(string p0, string p1)
        {
            string field = p0.ToString();
            string value = p1.ToString();
            switch(field)
            {
                case "RX HCC Name":
                    RSM.Lookups.RXHCCLookUp.RXHCCName.Clear();
                    RSM.Lookups.RXHCCLookUp.RXHCCName.SendKeys(value);
                    break;

                case "RX HCC Description":
                    RSM.Lookups.RXHCCLookUp.RXHCCDescription.Clear();
                    RSM.Lookups.RXHCCLookUp.RXHCCDescription.SendKeys(value);
                    break;

                case "Payment Year":
                    By Drp = By.XPath("//kendo-dropdownlist[@test-id='rxhcclookup-slct-rxhccPaymentYear']//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + value + "']");

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

                    //SelectElement year = new SelectElement(RSM.Lookups.RXHCCLookUp.RXHCCPaymentYear);
                    //year.SelectByText(value);
                    break;
            }
        }



        [When(@"SCC search criteria page ""(.*)"" field is set to ""(.*)""")]
        public void WhenSCCSearchCriteriaPageFieldIsSetTo(string p0, string p1)
        {
            string field = p0.ToString();
            string value = p1.ToString();

            switch(field)
            {
                case "SCC":
                    RSM.Lookups.SCCLookUp.SCC.SendKeys(value);
                    break;

                case "State Name":
                    RSM.Lookups.SCCLookUp.StateName.SendKeys(value);
                    break;
                case "County":
                    RSM.Lookups.SCCLookUp.CountyText.SendKeys(value);
                    break;

            }
        }


        [Then(@"Verify HCC Details report page ""(.*)"" field is set to ""(.*)""")]
        public void ThenVerifyHCCDetailsReportPageFieldIsSetTo(string field, string names)
        {
        
            string[] namesArray = names.Split(',');
            bool elementpresence = false;
            switch (field)
            {
                case "SCC":
                    if ((namesArray.Length == 1) && (namesArray[0].Equals("")))
                    {
                        elementpresence = true;

                        Assert.IsTrue(elementpresence);
                        fw.ConsoleReport(" There is no Element Present");

                    }
                    else if (namesArray.Length > 1)
                    {

                        foreach (string name in namesArray)
                        {

                            elementpresence = Browser.Wd.FindElement(By.XPath("//*[@test-id='SCC_ID']//ul/li[contains(.,'" + name + "')]")).Displayed;
                            Assert.IsTrue(elementpresence, name + " is not Found");
                            fw.ConsoleReport(name + " is Found");

                        }
                    }
                    break;

                case "HCC":

                    if ((namesArray.Length == 1) && (namesArray[0].Equals("")))
                    {
                        
                        IReadOnlyCollection<IWebElement> elementPre = Browser.Wd.FindElements(By.XPath("//kendo-multiselect[@test-id='searchMemberDiscrepancy-txt-hcc']//ul"));
                        foreach(IWebElement element in elementPre)
                        {
                            if(element.Text.Equals(namesArray[0]))
                            {
                                elementpresence = true;
                            }
                        }
                        
                        Assert.IsTrue(elementpresence,"Element is found");
                        fw.ConsoleReport(" There is no Element Present");

                    }
                    else if (namesArray.Length > 1)
                    {

                        foreach (string name in namesArray)
                        {
                            elementpresence = Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='searchMemberDiscrepancy-txt-hcc']//ul/li[contains(.,'" + name + "')]")).Displayed;
                            Assert.IsTrue(elementpresence, name + " is not Found");
                            fw.ConsoleReport(name + " is Found");

                        }
                    }
                    break;
            }

      

        }


        [Then(@"Verify HCC Search Criteria page Pagination ""(.*)"" button is displayed")]
        public void ThenVerifyHCCSearchCriteriaPagePaginationButtonIsDisplayed(string p0)
        {
            string button = p0.ToString();

            switch (button)
            {
                case "Next":

                    Assert.IsTrue(RSM.Lookups.HCCLookUp.HCCLookupPaginationNext.Displayed, button + " is not displayed");
                    break;
            }

        }

        [Then(@"Verify RxHCC Search Criteria page Pagination ""(.*)"" button is displayed")]
        public void ThenVerifyRxHCCSearchCriteriaPagePaginationButtonIsDisplayed(string p0)
        {
            string button = p0.ToString();

            switch (button)
            {
                case "Next":

                    Assert.IsTrue(RSM.Lookups.RXHCCLookUp.RXHCCLookupPaginationNext.Displayed, button + " is not displayed");
                    break;
            }
        }


        [When(@"HCC Search Criteria page Pagination ""(.*)"" button is Clicked")]
        public void WhenHCCSearchCriteriaPagePaginationButtonIsClicked(string p0)
        {
            RSM.Lookups.HCCLookUp.HCCLookupPaginationNext.Click();
        }
        [When(@"RxHCC Search Criteria page Pagination ""(.*)"" button is Clicked")]
        public void WhenRxHCCSearchCriteriaPagePaginationButtonIsClicked(string p0)
        {
            RSM.Lookups.RXHCCLookUp.RXHCCLookupPaginationNext.Click();
        }



        [Then(@"Verify Member Search Criteria page displayed ""(.*)"" Search results")]
        public void ThenVerifyMemberSearchCriteriaPageDisplayedSearchResults(string expRecords)
        {
            var actRecords = Browser.Wd.FindElements(By.XPath(".//*[@id='memberLookupGird']//div[@class='ui-grid-cell-contents ng-binding ng-scope']")).Count;
            string finalactRecords = (Convert.ToInt32(actRecords) / 2).ToString();


            Assert.AreEqual(finalactRecords, expRecords, expRecords +"is not getting displayed");
            
        }

        [Then(@"Verify PCP Search Criteria page displayed ""(.*)"" Search results")]
        public void ThenVerifyPCPSearchCriteriaPageDisplayedSearchResults(string expRecords)
        {
            var actRecords = Browser.Wd.FindElements(By.XPath(".//*[@id='pcpLookupGird']//div[@class='ui-grid-cell-contents ng-binding ng-scope']")).Count;
            string finalactRecords = (Convert.ToInt32(actRecords) / 2).ToString();


            Assert.AreEqual(finalactRecords, expRecords, expRecords + "is not getting displayed");
        }

        [Then(@"Verify SCC Search Criteria page displayed ""(.*)"" Search results")]
        public void ThenVerifySCCSearchCriteriaPageDisplayedSearchResults(string expRecords)
        {
            var actRecords = Browser.Wd.FindElements(By.XPath(".//*[@id='sccLookupGird']//div[@class='ui-grid-cell-contents ng-binding ng-scope']")).Count;
            string finalactRecords = (Convert.ToInt32(actRecords) / 3).ToString();


            Assert.AreEqual(finalactRecords, expRecords, expRecords + "is not getting displayed");
        }

        [Then(@"Verify PCP Search Criteria page Pagination ""(.*)"" button is displayed")]
        public void ThenVerifyPCPSearchCriteriaPagePaginationButtonIsDisplayed(string p0)
        {

            string button = p0.ToString();

            switch (button)
            {
                case "Next":

                    Assert.IsTrue(RSM.Lookups.PCPLookUp.PCPLookupPaginationNext.Displayed, button + " is not displayed");
                    break;
            }

        }


        [Then(@"Verify Member Search Criteria page Pagination ""(.*)"" button is displayed")]
        public void ThenVerifyMemberSearchCriteriaPagePaginationButtonIsDisplayed(string p0)
        {

            string button = p0.ToString();

            switch (button)
            {
                case "Next":

                    Assert.IsTrue(RSM.Lookups.HICLookUp.HICLookupPaginationNext.Displayed, button + " is not displayed");
                    break;
            }

        }

        [Then(@"Verify SCC Search Criteria page Pagination ""(.*)"" button is displayed")]
        public void ThenVerifySCCSearchCriteriaPagePaginationButtonIsDisplayed(string p0)
        {

            string button = p0.ToString();

            switch (button)
            {
                case "Next":

                    Assert.IsTrue(RSM.Lookups.SCCLookUp.SCCLookupPaginationNext.Displayed, button + " is not displayed");
                    break;
            }
        }

        [When(@"SCC Search Criteria page Pagination ""(.*)"" button is Clicked")]
        public void WhenSCCSearchCriteriaPagePaginationButtonIsClicked(string p0)
        {

            string button = p0.ToString();

            switch (button)
            {
                case "Next":
                    fw.ExecuteJavascript(RSM.Lookups.SCCLookUp.SCCLookupPaginationNext);
                    break;
            }

        }

        [When(@"PCP Search Criteria page Pagination ""(.*)"" button is Clicked")]
        public void WhenPCPSearchCriteriaPagePaginationButtonIsClicked(string p0)
        {


            string button = p0.ToString();

            switch (button)
            {
                case "Next":
                    fw.ExecuteJavascript(RSM.Lookups.PCPLookUp.PCPLookupPaginationNext);
                    break;
            }
        }


        [When(@"Member Search Criteria page Pagination ""(.*)"" button is Clicked")]
        public void WhenMemberSearchCriteriaPagePaginationButtonIsClicked(string p0)
        {

            string button = p0.ToString();

            switch (button)
            {
                case "Next":
                    fw.ExecuteJavascript(RSM.Lookups.HICLookUp.HICLookupPaginationNext);
                    break;
            }
        }

        [Then(@"Verify SCC Search Criteria page ""(.*)"" field is displayed")]
        public void ThenVerifySCCSearchCriteriaPageFieldIsDisplayed(string p0)
        {

            string field = p0.ToString();

            switch (field)
            {
                case "SCC":
                    bool isSCCdisplayed = RSM.Lookups.SCCLookUp.SCC.Displayed;
                    Assert.IsTrue(isSCCdisplayed, field + " is not displayed");
                    break;

                case "County Name":
                    bool isCountydisplayed = RSM.Lookups.SCCLookUp.CountyName.Displayed;
                    Assert.IsTrue(isCountydisplayed, field + " is not displayed");
                    break;

                case "State Name":
                    bool isStateNameisplayed = RSM.Lookups.SCCLookUp.StateName.Displayed;
                    Assert.IsTrue(isStateNameisplayed, field + " is not displayed");
                    break;

                case "Reset button":
                    bool isResetdisplayed = RSM.Lookups.SCCLookUp.SCCReset.Displayed;
                    Assert.IsTrue(isResetdisplayed, field + " is not displayed");
                    break;
                case "Search button":
                    bool isSearchdisplayed = RSM.Lookups.SCCLookUp.SCCSearch.Displayed;
                    Assert.IsTrue(isSearchdisplayed, field + " is not displayed");
                    break;


            }
        }

        [Then(@"Verify HCC Search Criteria page ""(.*)"" field is displayed")]
        public void ThenVerifyHCCSearchCriteriaPageFieldIsDisplayed(string p0)
        {
            string field = p0.ToString();

            switch (field)
            {
                case "HCC Name":
                    bool isHCCdisplayed = RSM.Lookups.HCCLookUp.HCCName.Displayed;
                    Assert.IsTrue(isHCCdisplayed, field + " is not displayed");
                    break;

                case "HCC Description":
                    bool isHCCDisdisplayed = RSM.Lookups.HCCLookUp.HCCDescription.Displayed;
                    Assert.IsTrue(isHCCDisdisplayed, field + " is not displayed");
                    break;

                case "Payment Year":
                    bool isPaymentYeardisplayed = RSM.Lookups.HCCLookUp.HCCPaymentYear.Displayed;
                    Assert.IsTrue(isPaymentYeardisplayed, field + " is not displayed");
                    break;
                
                case "Reset button":
                    bool isResetdisplayed = RSM.Lookups.HCCLookUp.HCCResetButton.Displayed;
                    Assert.IsTrue(isResetdisplayed, field + " is not displayed");
                    break;
                case "Search button":
                    bool isSearchdisplayed = RSM.Lookups.HCCLookUp.HCCSearchButton.Displayed;
                    Assert.IsTrue(isSearchdisplayed, field + " is not displayed");
                    break;


            }
        }


        [Then(@"Verify Member Search Criteria page ""(.*)"" field is displayed")]
        public void ThenVerifyMemberSearchCriteriaPageFieldIsDisplayed(string p0)
        {
            string field = p0.ToString();

            switch(field)
            {
                case "HIC":
                    bool isHICdisplayed = RSM.Lookups.HICLookUp.HIC.Displayed;
                    Assert.IsTrue(isHICdisplayed, field+ " is not displayed");
                    break;

                case "Member ID":
                    bool isMemIDdisplayed = RSM.Lookups.HICLookUp.MemberID.Displayed;
                    Assert.IsTrue(isMemIDdisplayed, field + " is not displayed");
                    break;
                   
                case "First Name":
                    bool isFnamedisplayed = RSM.Lookups.HICLookUp.FirstName.Displayed;
                    Assert.IsTrue(isFnamedisplayed, field + " is not displayed");
                    break;
                  
                case "Last Name":
                    bool isLnamedisplayed = RSM.Lookups.HICLookUp.LastName.Displayed;
                    Assert.IsTrue(isLnamedisplayed, field + " is not displayed");
                    break;
                case "Reset button":
                    bool isResetdisplayed = RSM.Lookups.HICLookUp.HICReset.Displayed;
                    Assert.IsTrue(isResetdisplayed, field + " is not displayed");
                    break;
                case "Search button":
                    bool isSearchdisplayed = RSM.Lookups.HICLookUp.HICSearch.Displayed;
                    Assert.IsTrue(isSearchdisplayed, field + " is not displayed");
                    break;
                    
                        
            }
        }


        [When(@"Risk Score Trend Details page Notify ""(.*)"" value")]
        public void WhenRiskScoreTrendDetailsPageNotifyValue(string p0)
        {
            string MBISelectedFromLookup = Browser.Wd.FindElement(By.XPath("//tr[1]/td[2]/span")).Text;
            GlobalRef.MBISelected = MBISelectedFromLookup;
        }


        [Then(@"Verify Risk Score Trend Details Search Criteria page displayed HIC as ""(.*)""")]
        public void ThenVerifyRiskScoreTrendDetailsSearchCriteriaPageDisplayedHICAs(string p0)
        {
            //string expected = tmsCommon.GenerateData(p0);
            string expectedMBI = GlobalRef.MBINAME.ToString();
            string actualresult = Browser.Wd.FindElement(By.XPath("//tags-input[@test-id='txtHICN']//span[@class='ng-binding ng-scope']")).Text;
            Assert.AreEqual(expectedMBI, actualresult, expectedMBI + " MBI is not found");
        }


        [Then(@"Verify ""(.*)"" is closed successfully")]
        [When(@"Verify ""(.*)"" is closed successfully")]
        public void ThenVerifyIsClosedSuccessfully(string p0)
        {
            Browser.Wd.Close();
            Browser.SwitchToParentWindow();
        }


        public void CloseReport(string titleWin)
        {

            List<string> w = new List<string>(Browser.Wd.WindowHandles);

            for (int i = 0; i < w.Count; i++)
            {
                if (Browser.Wd.SwitchTo().Window(w[i]).Title.Equals(titleWin))
                {

                    Browser.Wd.SwitchTo().Window(w[i]).Close();
                    fw.ConsoleReport(titleWin + "Report was Closed");
                    Browser.Wd.SwitchTo().Window(parentwindow);
                    break;
                }
            }


        }





        [Then(@"Verify ""(.*)"" is Opened successfully")]
        public void ThenVerifyIsOpenedSuccessfully(string p0)
        {
            tmsWait.Hard(5);
            string titleWin = "cr_RiskScoreTrend_Details - Report Viewer";

            //Add ids of all the opened window on screen.These ids will be set to specific windows which are opened in order.
            List<string> w = new List<string>(Browser.Wd.WindowHandles);


            // Set window id and switch to any window
            for (int i = 0; i < w.Count; i++)
            {
                if (Browser.Wd.SwitchTo().Window(w[i]).Title.Equals(titleWin))
                {

                    fw.ConsoleReport(titleWin + "Report was opened");
                    break;
                }
            }
        }


        [When(@"HCC Details accordion section ""(.*)"" link is Clicked")]
        public void WhenHCCDetailsAccordionSectionLinkIsClicked(string p0)
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(RSM.LookupsIcons.SCCLookupicon);
        }

        [When(@"PCP Search Criteria page Search button is Clicked")]
        public void WhenPCPSearchCriteriaPageSearchButtonIsClicked()
        {
            fw.ExecuteJavascript(RSM.Lookups.PCPLookUp.PCPLookupSearch);
        }


        [When(@"PCP Search Criteria ""(.*)"" value is set to ""(.*)""")]
        public void WhenPCPSearchCriteriaValueIsSetTo(string p0, string p1)
        {
            string field = p0.ToString();
            string value = tmsCommon.GenerateData(p1);
            switch(field)
            {
                case "Provider ID":
                    RSM.Lookups.PCPLookUp.ProviderID.SendKeys(value);
                    break;
                case "Provider Last Name":
                    RSM.Lookups.PCPLookUp.ProviderLast.SendKeys(value);
                    break;
                case "Provider First Name":
                    RSM.Lookups.PCPLookUp.ProviderFirst.SendKeys(value);
                    break;

                    
            }

            tmsWait.Hard(5);
        }


        [Then(@"Verify PCP Search Criteria page ""(.*)"" field is displayed")]
        public void ThenVerifyPCPSearchCriteriaPageFieldIsDisplayed(string p0)
        {
            string field = p0.ToString();

            switch(field)
            {
                case "Provider ID":
                    Assert.IsTrue(RSM.Lookups.PCPLookUp.ProviderID.Displayed, field + " is not displayed");
                        break;
                case "Provider First Name":
                    Assert.IsTrue(RSM.Lookups.PCPLookUp.ProviderFirst.Displayed, field + " is not displayed");
                    break;
                case "Provider Last Name":
                    Assert.IsTrue(RSM.Lookups.PCPLookUp.ProviderLast.Displayed, field + " is not displayed");
                    break;
                case "Reset button":
                    Assert.IsTrue(RSM.Lookups.PCPLookUp.PCPLookupReset.Displayed, field + " is not displayed");
                    break;
                case "Search button":
                    Assert.IsTrue(RSM.Lookups.PCPLookUp.PCPLookupSearch.Displayed, field + " is not displayed");
                    break;
            }
        }


        [When(@"Risk Score Trend Details accordion section ""(.*)"" link is Clicked")]
        public void WhenRiskScoreTrendDetailsAccordionSectionLinkIsClicked(string p0)
        {
            tmsWait.Hard(2);
            string field = p0.ToString();

            switch(field)
            {
                case "HIC":
                    fw.ExecuteJavascript(RSM.LookupsIcons.HICLookupicon);
                    break;
                case "PCP ID":
                    fw.ExecuteJavascript(RSM.LookupsIcons.PCPLookupicon);
                    break;
            }
            tmsWait.Hard(5);
        }

        [When(@"RSM Application ""(.*)"" Section is Clicked")]
        public void WhenRSMApplicationSectionIsClicked(string p0)
        {
            // tmsWait.elementToBeClickable(RSM.MemberDiscrepancy.ViewRSMLink);
            tmsWait.Hard(5);
            fw.ExecuteJavascript(RSM.MemberDiscrepancy.ViewRSMLink);
        }

        [Then(@"Verify ""(.*)"" sub menu is displayed")]
        public void ThenVerifySubMenuIsDisplayed(string p0)
        {
            tmsWait.Hard(5);
            String ActualInput = RSM.MemberDiscrepancy.MemberDiscrepancyLink.Text.ToString();
            Assert.AreEqual(p0, ActualInput, " Both values are getting matched");
        }

        [When(@"RSM Application ""(.*)"" sub menu is Clicked")]
        public void WhenRSMApplicationSubMenuIsClicked(string p0)
        {
            tmsWait.Hard(1);
            fw.ExecuteJavascript(RSM.MemberDiscrepancy.MemberDiscrepancyLink);
        }

        [When(@"Member Discrepancy page Payment Year is set to ""(.*)""")]
        public void WhenMemberDiscrepancyPagePaymentYearIsSetTo(string p0)
        {
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='searchMemberDiscrepancy-slct-paymentYear']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + p0 + "']");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

            //SelectElement year = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@test-id='searchMemberDiscrepancy-slct-paymentYear']")));
            //year.SelectByText(p0);
        }

        [When(@"Member Discrepancy page PlanId is set to ""(.*)""")]
        public void WhenMemberDiscrepancyPagePlanIdIsSetTo(string p0)
        {
            By Drp = By.XPath("//kendo-multiselect[@id='multiSelectPlans']//input");
            Browser.Wd.FindElement(Drp).SendKeys(p0);
            Browser.Wd.FindElement(Drp).SendKeys(OpenQA.Selenium.Keys.Enter);

            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@id='multiSelectPlans-list']")));
            //tmsWait.Hard(1);
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//ul[@id='multiSelectPlans_listbox']/li[contains(.,'"+ p0 +"')]")));
        }


        [When(@"Member Discrepancy ""(.*)"" button is clicked")]
        [Then(@"Member Discrepancy ""(.*)"" button is clicked")]
        public void ThenMemberDiscrepancyButtonIsClicked(string p0)
        {
            tmsWait.Hard(5);
            string Buttonname = p0.ToString().ToLower();
            switch (Buttonname)
            {
                case "search":
                    fw.ExecuteJavascript(RSM.MemberDiscrepancy.SearchButton);
                    
                    break;
                case "reset":
                    fw.ExecuteJavascript(RSM.MemberDiscrepancy.ResetButton);
                 
                    break;
            }
            tmsWait.Hard(3);
        }

        [Then(@"Verify Member Discrepancy search results displayed")]
        public void ThenVerifyMemberDiscrepancySearchResultsDisplayed()
        {
            Boolean ispresent = false;
            IWebElement viewicon = Browser.Wd.FindElement(By.XPath(".//*[@test-id='encounter-grid-encounters']"));
            if(viewicon.Displayed)
            {
                ispresent = true;
            }

            Assert.IsTrue(ispresent);
        }


        [Then(@"Member Discrepancy page ""(.*)"" look up ""(.*)"" button is clicked")]
        [When(@"""(.*)"" look up page ""(.*)"" button is clicked")]
        public void ThenMemberDiscrepancyPageLookUpButtonIsClicked(string p0, string p1)
        {
            string Lookup = p0.ToString();
            string buttonname = p1.ToString().ToLower();
            switch (Lookup)
            {
                case "HIC":
                    switch (buttonname)
                    {
                        case "search":
                            fw.ExecuteJavascript(RSM.Lookups.HICLookUp.HICSearch);
                            break;
                        case "reset":
                            fw.ExecuteJavascript(RSM.Lookups.HICLookUp.HICReset);
                            break;
                        case "back to record":
                            fw.ExecuteJavascript(RSM.Lookups.HICLookUp.HICBackToRecord);
                            break;

                    }
                    break;

                case "SCC":
                    switch (buttonname)
                    {
                        case "search":
                            fw.ExecuteJavascript(RSM.Lookups.SCCLookUp.SCCSearch);
                            break;
                        case "reset":
                            fw.ExecuteJavascript(RSM.Lookups.SCCLookUp.SCCReset);
                            break;
                        case "Back to Record":
                            fw.ExecuteJavascript(RSM.Lookups.SCCLookUp.SCCBackToRecord);
                            break;
                    }
                    break;

                case "HCC":
                    switch (buttonname)
                    {
                        case "search":
                            fw.ExecuteJavascript(RSM.Lookups.HCCLookUp.HCCSearchButton);
                            break;
                        case "reset":
                            fw.ExecuteJavascript(RSM.Lookups.HCCLookUp.HCCResetButton);
                            break;
                        case "Back to Record":
                            // RSM.Lookups.HCCLookUp..Click();
                            break;
                    }
                    break;

                case "RXHCC":
                    switch (buttonname)
                    {
                        case "search":
                            fw.ExecuteJavascript(RSM.Lookups.RXHCCLookUp.RXHCCSearchButton);
                            break;
                        case "reset":
                            fw.ExecuteJavascript(RSM.Lookups.RXHCCLookUp.RXHCCResetButton);
                            break;
                    }
                    break;

                case "IPA/Medical Group":
                    switch (buttonname)
                    {
                        case "search":
                            fw.ExecuteJavascript(RSM.Lookups.GroupIDLookUp.GroupSearch);
                            break;
                        case "reset":
                            fw.ExecuteJavascript(RSM.Lookups.GroupIDLookUp.GroupReset);
                            break;
                    }
                    break;

                case "Primary Care Physician":
                    switch (buttonname)
                    {
                        case "search":
                            fw.ExecuteJavascript(RSM.Lookups.PCPLookUp.PCPLookupSearch);
                            break;
                        case "reset":
                            fw.ExecuteJavascript(RSM.Lookups.PCPLookUp.PCPLookupReset);
                            break;
                    }
                    break;
            }
        }

        [Then(@"Verify Member Discrepancy search results table displays ""(.*)""")]
        public void ThenVerifyMemberDiscrepancySearchResultsTableDisplays(string p0)
        {
            tmsWait.Hard(3);
            string exp = tmsCommon.GenerateData(p0);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//tr[contains(.,'" + exp + "')]")).Displayed, exp + "value is not found");
        }


        [Then(@"Verify Clinical HCC's table displays ""(.*)""")]
        public void ThenVerifyClinicalHCCSTableDisplays(string p0)
        {
            tmsWait.Hard(3);
            string exp = tmsCommon.GenerateData(p0);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//*[@test-id='memberDiscrepancy-grid-clinicalGrid']//div[contains(.,'"+exp+"')]")).Displayed,exp+"value is not found");

        }


        [When(@"Member Discrepancy page view icon associated with ""(.*)"" is checked")]
        public void WhenMemberDiscrepancyPageAssociatedViewOptionIsClicked(string p0)
        {
            tmsWait.Hard(5);
            inputlookupvalue = tmsCommon.GenerateData(p0);
            xpath = "//kendo-grid[@test-id='encounter-grid-encounters']//tr[contains(.,'" + inputlookupvalue+ "')]//td//span[@title='View']";
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(xpath)));
            
        }

        [Then(@"Clinical HCC's table view icon associated with ""(.*)"" is clicked")]
        [When(@"Clinical HCC's table view icon associated with ""(.*)"" is clicked")]
        public void ThenClinicalHCCSTableViewIconAssociatedWithIsClicked(string p0)
        {
            inputlookupvalue = tmsCommon.GenerateData(p0);
            xpath = "//kendo-grid[@test-id='memberDiscrepancy-grid-clinicalEdpsGrid']//tr[contains(.,'" + inputlookupvalue + "')]//td//a";
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(xpath)));
            tmsWait.Hard(5);
        }

        [Then(@"Verify the RAPS Drill-Down - Clinical page displayed ""(.*)"" button")]
        public void ThenVerifyTheRAPSDrill_Down_ClinicalPageDisplayedButton(string p0)
        {
            inputlookupvalue = p0.ToString();
            switch (inputlookupvalue)
            {
                case "Back to Record":
                    Assert.IsTrue(RSM.MemberDiscrepancy.BackToRecordRapsDrillButton.Displayed, "Back to Record Button is displayed");
                    break;
                case "closed":
                    Assert.IsTrue(RSM.MemberDiscrepancy.closeRapsDrillButton.Displayed, "Close Button is displayed");
                    break;
            }
        }

        [When(@"RAPS Drill-Down - Clinical page ""(.*)"" button clicked")]
        public void WhenRAPSDrill_Down_ClinicalPageButtonClicked(string p0)
        {
            inputlookupvalue = p0.ToString();
            switch (inputlookupvalue)
            {
                case "Back to Record":
                    RSM.MemberDiscrepancy.BackToRecordRapsDrillButton.Click();
                    break;
                case "Close":
                    RSM.MemberDiscrepancy.closeRapsDrillButton.Click();
                    break;
            }
        }


        [Then(@"Verify Member Discrepancy page member Details ""(.*)"" field is dispalyed with value ""(.*)""")]
        public void ThenVerifyMemberDiscrepancyPageMemberDetailsFieldIsDispalyedWithValue(string p0, string p1)
        {
            tmsWait.Hard(5);
            string ExpectedlabelName = p0.ToString();
            string ExpectedlableValue = p1.ToString();
            string ActualLableName = null;
            string ActualLableValue = null;
            switch (ExpectedlabelName)
            {
                case "Plan":
                    ActualLableName = RSM.MemberDiscrepancy.memberDetailsPlan.Text.ToString();
                    ActualLableValue = RSM.MemberDiscrepancy.memberDetailsPlanvalue.Text.ToString();
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    Assert.AreEqual(ExpectedlableValue, ActualLableValue, "Both values are getting matched");
                    break;
                case "MBI":
                    ActualLableName = RSM.MemberDiscrepancy.memberDetailsHIC.Text.ToString();
                    ActualLableValue = RSM.MemberDiscrepancy.memberDetailsHICvalue.Text.ToString();
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    Assert.AreEqual(ExpectedlableValue, ActualLableValue, "Both values are getting matched");
                    break;
                case "Member ID":
                    ActualLableName = RSM.MemberDiscrepancy.memberDetailsmemberId.Text.ToString();
                    ActualLableValue = RSM.MemberDiscrepancy.memberDetailsmemberIdValue.Text.ToString();
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    Assert.AreEqual(ExpectedlableValue, ActualLableValue, "Both values are getting matched");
                    break;
                case "Last Name":
                    ActualLableName = RSM.MemberDiscrepancy.memberDetailslastName.Text.ToString();
                    ActualLableValue = RSM.MemberDiscrepancy.memberDetailslastNameValue.Text.ToString();
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    Assert.AreEqual(ExpectedlableValue, ActualLableValue, "Both values are getting matched");
                    break;
                case "First Name":
                    ActualLableName = RSM.MemberDiscrepancy.memberDetailsfirstName.Text.ToString();
                    ActualLableValue = RSM.MemberDiscrepancy.memberDetailsfirstNameValue.Text.ToString();
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    Assert.AreEqual(ExpectedlableValue, ActualLableValue, "Both values are getting matched");
                    break;
                case "PBP":
                    ActualLableName = RSM.MemberDiscrepancy.memberDetailspbp.Text.ToString();
                    ActualLableValue = RSM.MemberDiscrepancy.memberDetailspbpValue.Text.ToString();
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    Assert.AreEqual(ExpectedlableValue, ActualLableValue, "Both values are getting matched");
                    break;
                case "Plan SCC":
                    ActualLableName = RSM.MemberDiscrepancy.memberDetailsplanScc.Text.ToString();
                    ActualLableValue = RSM.MemberDiscrepancy.memberDetailsplanSccValue.Text.ToString();
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    Assert.AreEqual(ExpectedlableValue, ActualLableValue, "Both values are getting matched");
                    break;
                case "Plan State":
                    ActualLableName = RSM.MemberDiscrepancy.memberDetailsplanState.Text.ToString();
                    ActualLableValue = RSM.MemberDiscrepancy.memberDetailsplanStateValue.Text.ToString();
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    Assert.AreEqual(ExpectedlableValue, ActualLableValue, "Both values are getting matched");
                    break;
                case "Plan County":
                    ActualLableName = RSM.MemberDiscrepancy.memberDetailsplanCountry.Text.ToString();
                    ActualLableValue = RSM.MemberDiscrepancy.memberDetailsplanCountryValue.Text.ToString();
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    Assert.AreEqual(ExpectedlableValue, ActualLableValue, "Both values are getting matched");
                    break;
                case "Plan Raft":
                    ActualLableName = RSM.MemberDiscrepancy.memberDetailsplanRaft.Text.ToString();
                    ActualLableValue = RSM.MemberDiscrepancy.memberDetailsplanRaftValue.Text.ToString();
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    Assert.AreEqual(ExpectedlableValue, ActualLableValue, "Both values are getting matched");
                    break;
                case "Plan Risk Score":
                    ActualLableName = RSM.MemberDiscrepancy.memberDetailsplanRiskScore.Text.ToString();
                    ActualLableValue = RSM.MemberDiscrepancy.memberDetailsplanRiskScoreValue.Text.ToString();
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    Assert.AreEqual(ExpectedlableValue, ActualLableValue, "Both values are getting matched");
                    break;
                case "Plan Risk Score D":
                    ActualLableName = RSM.MemberDiscrepancy.memberDetailsplanRiskScoreD.Text.ToString();
                    ActualLableValue = RSM.MemberDiscrepancy.memberDetailsplanRiskScoreDValue.Text.ToString();
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    Assert.AreEqual(ExpectedlableValue, ActualLableValue, "Both values are getting matched");
                    break;
                case "Plan Name":
                    ActualLableName = RSM.MemberDiscrepancy.memberDetailsplanName.Text.ToString();
                    ActualLableValue = RSM.MemberDiscrepancy.memberDetailsplanNameValue.Text.ToString();
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    Assert.AreEqual(ExpectedlableValue, ActualLableValue, "Both values are getting matched");
                    break;
                case "PCP":
                    ActualLableName = RSM.MemberDiscrepancy.memberDetailspcp.Text.ToString();
                    ActualLableValue = RSM.MemberDiscrepancy.memberDetailspcpValue.Text.ToString();
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    Assert.AreEqual(ExpectedlableValue, ActualLableValue, "Both values are getting matched");
                    break;
                case "CMS Raft":
                    ActualLableName = RSM.MemberDiscrepancy.memberDetailscmsRaft.Text.ToString();
                    ActualLableValue = RSM.MemberDiscrepancy.memberDetailscmsRaftValue.Text.ToString();
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    Assert.AreEqual(ExpectedlableValue, ActualLableValue, "Both values are getting matched");
                    break;
                case "CMS Risk Score":
                    ActualLableName = RSM.MemberDiscrepancy.memberDetailscmsRiskScore.Text.ToString();
                    ActualLableValue = RSM.MemberDiscrepancy.memberDetailscmsRiskScoreValue.Text.ToString();
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    Assert.AreEqual(ExpectedlableValue, ActualLableValue, "Both values are getting matched");
                    break;
                case "CMS Risk Score D":
                    ActualLableName = RSM.MemberDiscrepancy.memberDetailscmsRiskScoreD.Text.ToString();
                    ActualLableValue = RSM.MemberDiscrepancy.memberDetailscmsRiskScoreDValue.Text.ToString();
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    Assert.AreEqual(ExpectedlableValue, ActualLableValue, "Both values are getting matched");
                    break;
                case "Part C Only":
                    ActualLableName = RSM.MemberDiscrepancy.memberDetailspartCOnly.Text.ToString();
                    ActualLableValue = RSM.MemberDiscrepancy.memberDetailspartCOnlyValue.Text.ToString();
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    Assert.AreEqual(ExpectedlableValue, ActualLableValue, "Both values are getting matched");
                    break;
                case "IPA / Medical Group":
                    ActualLableName = RSM.MemberDiscrepancy.memberDetailsipa.Text.ToString();
                    ActualLableValue = RSM.MemberDiscrepancy.memberDetailsipaValue.Text.ToString();
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    Assert.AreEqual(ExpectedlableValue, ActualLableValue, "Both values are getting matched");
                    break;
            }
        }



        [Then(@"Member Discrepancy page select the ""(.*)"" look up icon")]
        public void ThenMemberDiscrepancyPageSelectTheLookUpIcon(string p0)
        {
            string lookup = p0.ToString();
            switch (lookup)
            {
                case "HIC":
                    RSM.MemberDiscrepancy.HICLookup.Click();
                    break;
                case "RXHCC":
                    RSM.MemberDiscrepancy.RxHCCLookup.Click();
                    break;
                case "HCC":
                    RSM.MemberDiscrepancy.HCCLookup.Click();
                    break;
                case "SCC":
                    RSM.MemberDiscrepancy.SCCLookup.Click();
                    break;
                case "IPA/Medical Group":
                    RSM.MemberDiscrepancy.IPAMedicalGroupLookup.Click();
                    break;
                case "Primary Care Physician":
                    RSM.MemberDiscrepancy.PrimaryCarePhysicianLookup.Click();
                    break;
            }
        }

        [Then(@"RX HCC Search Criteria ""(.*)"" value is set to ""(.*)""")]
        public void ThenRXHCCSearchCriteriaValueIsSetTo(string p0, string p1)
        {
            fw.ExecuteJavascript(RSM.Lookups.RXHCCLookUp.RXHCCLoookupBackToRecord);
        }

        [Then(@"Verify Member Discrepancy page ""(.*)"" field displayed values ""(.*)""")]
        public void ThenVerifyMemberDiscrepancyPageFieldDisplayedValues(string p0, string p1)
        {
            string field = p0.ToString();
            string names = p1.ToString();

            string[] namesArray = names.Split(',');
            bool elementpresence = false;

            switch (field)
            {
                case "RxHCC":
                    if ((namesArray.Length == 1) && (namesArray[0].Equals("")))
                    {
                        elementpresence = true;

                        Assert.IsTrue(elementpresence);
                        fw.ConsoleReport(" There is no Element Present");

                    }
                    else if ((namesArray.Length >= 1) && !(namesArray[0].Equals("")))
                    {

                        foreach (string name in namesArray)
                        {

                            elementpresence = Browser.Wd.FindElement(By.XPath("//span[contains(.,'"+ name + "')]")).Displayed;
                            Assert.IsTrue(elementpresence, name + " is not Found");
                            fw.ConsoleReport(name + " is Found");

                        }
                    }
                    break;
                   
            }
        }


        [When(@"Member Discrepancy page ""(.*)"" look up is clicked")]
        public void WhenMemberDiscrepancyPageLookUpIsClicked(string p0)
        {
            string InputLookup = p0.ToString();
            switch (InputLookup)
            {
                case "HIC":
                    tmsWait.Hard(5);
                    fw.ExecuteJavascript(RSM.MemberDiscrepancy.HICLookup);
                    break;
                case "SCC":
                    tmsWait.Hard(5);
                    fw.ExecuteJavascript(RSM.MemberDiscrepancy.SCCLookup);
                    break;
                case "HCC":
                    tmsWait.Hard(5);
                    fw.ExecuteJavascript(RSM.MemberDiscrepancy.HCCLookup);
                    break;
                case "RXHCC":
                    tmsWait.Hard(5);
                    fw.ExecuteJavascript(RSM.MemberDiscrepancy.RxHCCLookup);
                    break;
            }
            tmsWait.Hard(5);
        }


        //[When(@"Member Discrepancy page ""(.*)"" look up is set to ""(.*)""")]
        // [Then(@"Member Discrepancy page ""(.*)"" look up is set to ""(.*)""")]
        [When(@"""(.*)"" Look up page view icon associated with ""(.*)"" is checked")]
        public void ThenMemberDiscrepancyPageLookUpIsSetTo(string p0, string p1)
        {
            string inputlookupname = p0.ToString();
            //string inputlookupvalue = p1.ToString();
            string inputlookupvalue = tmsCommon.GenerateData(p1);
            switch (inputlookupname)
            {
                case "HIC":

                    // below function is tp select the particular value from HIC table
                    SelectValue(RSM.Lookups.HICLookUp.hicLookupGird, inputlookupvalue);
                    break;
                case "RxHCC":
                    SelectValue(RSM.Lookups.RXHCCLookUp.RXHCCLoookupGrid, inputlookupvalue);
                    break;
                case "HCC":
                    SelectValue(RSM.Lookups.HCCLookUp.HCCLoookupGrid, inputlookupvalue);
                    break;
                case "SCC":
                    SelectValue(RSM.Lookups.SCCLookUp.sccLookupGird, inputlookupvalue);
                    break;
                case "IPA/Medical Group":
                    SelectValue(RSM.Lookups.GroupIDLookUp.GroupLoookupGrid, inputlookupvalue);
                    break;
                case "Primary Care Physician":
                    SelectValue(RSM.Lookups.PCPLookUp.PCPLoookupGrid, inputlookupvalue);
                    break;
            }
        }

        public void SelectValue(IWebElement locator, string inputlookupvalue)
        {
            if (inputlookupvalue.Contains(","))
            {
                string[] inputlookupvaluearray = inputlookupvalue.Split(',');
                for (int i = 0; i <= inputlookupvaluearray.Length; i++)
                {
                    ClickONLookuppage(inputlookupvaluearray[i], locator);
                }
            }
            else
            {
                ClickONLookuppage(inputlookupvalue, locator);
            }

        }

        public void ClickONLookuppage(string inputlookupvalue, IWebElement locator)
        {

            TablePaging thisTP = new TablePaging();

            IWebElement baseTable = locator;
            int headercnt = 2;
            int rowcount = 0;
            int matchrecord = 0;
            thisTP.LoadRSMGrid(baseTable, headercnt, "ui-grid-row", "ui-grid-cell");

            foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
            {
                if (matchrecord == 1)
                {
                    break;
                }
                rowcount = rowcount + 1;
                string[] AppTableRow = ApplicationRow.Row.ToArray();
                for (int j = 0; j <= AppTableRow.Length - 1; j++)
                {
                    if (AppTableRow[j].Contains(inputlookupvalue))
                    {
                        rowcount = rowcount - 1;
                        // string customxpath = ".//*[@id='memberLookupGird']/div[1]/div[1]/div/div[2]/div/div[" + rowcount + "]/div/div/div/div/div";
                         string customxpath = ".//*[@test-id='memberlookup-grid-ResultGrid']//table//td[text()='" + inputlookupvalue + "']/preceding-sibling::td/input";
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(customxpath)));
                       
                        matchrecord = 1;
                        break;
                    }

                }

            }
        }

        [When(@"Look up page ""(.*)"" is set to ""(.*)""")]
        public void WhenLookUpPageIsSetTo(string p0, string p1)
        {
            string lookupName = p0.ToString();
            string InputValue = tmsCommon.GenerateData(p1);
            //p1.ToString();
            switch (lookupName)
            {
                case "HIC":
                    tmsWait.Hard(2);
                    RSM.Lookups.HICLookUp.HIC.Click();
                    RSM.Lookups.HICLookUp.HIC.SendKeys(InputValue);
                    //RSM.Lookups.HICLookUp.HICSearch.Click();
                    break;
                case "HCC":
                    tmsWait.Hard(2);
                    RSM.Lookups.HCCLookUp.HCCName.Click();
                    RSM.Lookups.HCCLookUp.HCCName.SendKeys(InputValue);
                    //RSM.Lookups.HCCLookUp.HCCSearchButton.Click();
                    break;
            }
        }

        [When(@"Look up page Payment Year drop down is set to ""(.*)""")]
        public void WhenLookUpPagePaymentYearDropDownIsSetTo(string p0)
        {
            IWebElement drp = Browser.Wd.FindElement(By.CssSelector("[test-id='searchMemberDiscrepancy-slct-paymentYear']"));

            SelectElement drpyear = new SelectElement(drp);
            drpyear.SelectByText(p0);
        }

        [When(@"Look up page ""(.*)"" button is clicked")]
        public void WhenLookUpPageButtonIsClicked(string p0)
        {
            string lookupName = p0.ToString();
            switch (lookupName)
            {
                case "Search":
                    fw.ExecuteJavascript(RSM.Lookups.HICLookUp.HICSearch);
                    tmsWait.Hard(5);
                    break;
            }
        }

        [Then(@"Verify Member Discrepancy page ""(.*)"" field is dispalyed with value ""(.*)""")]
        public void ThenVerifyMemberDiscrepancyPageFieldIsDispalyedWithValue(string p0, string p1)
        {

            string ExpectedlabelName = p0.ToString();
            string ExpectedlableValue = p1.ToString();
            string ActualLableName, ActualLableValue;
            switch (ExpectedlabelName)
            {
                case "Plan":
                    ActualLableName = RSM.MemberDiscrepancy.searchMemberDiscrepancyPlanId.Text.ToString();
                    //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@id='multiSelectPlans-list']")));
//tmsWait.Hard(1);
                    ActualLableValue = RSM.MemberDiscrepancy.PlanIDdefaultvalue.Text.ToString();
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    Assert.AreEqual(ExpectedlableValue, ActualLableValue, "Both values are getting matched");
                    break;
                case "PBP":
                    ActualLableName = RSM.MemberDiscrepancy.searchMemberDiscrepancyPBP.Text.ToString();
                    ActualLableValue = RSM.MemberDiscrepancy.PBPdefaultvalue.Text.ToString();
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    Assert.AreEqual(ExpectedlableValue, ActualLableValue, "Both values are getting matched");
                    break;
                case "HIC":
                    ActualLableName = RSM.MemberDiscrepancy.searchMemberDiscrepancyHICLable.Text.ToString();
                    ActualLableValue = RSM.MemberDiscrepancy.searchMemberDiscrepancyHICText.Text.ToString();
                    Assert.IsTrue(RSM.MemberDiscrepancy.HICLookup.Displayed, "HIC icon link is displayed");
                    Assert.IsTrue(RSM.MemberDiscrepancy.searchMemberDiscrepancyHICText.Displayed, "Textbox is displayed");
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    //Assert.AreEqual(ExpectedlableValue, ActualLableValue, "Both values are getting matched");
                    break;
                case "Discrepancy Type":
                    ActualLableName = RSM.MemberDiscrepancy.searchMemberDiscrepancydiscrepancyTypeLable.Text.ToString();
                    ActualLableValue = RSM.MemberDiscrepancy.searchMemberDiscrepancydiscrepancyTypeText.Text.ToString();
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    Assert.AreEqual(ExpectedlableValue, ActualLableValue, "Both values are getting matched");
                    break;
                case "Payment Year":
                    tmsWait.Hard(2);
                    ActualLableName = RSM.MemberDiscrepancy.searchMemberDiscrepancypaymentYearLable.Text.ToString();
                    //select = new SelectElement(RSM.MemberDiscrepancy.searchMemberDiscrepancypaymentYearText);
                    ActualLableValue = Browser.Wd.FindElement(By.XPath("//*[@test-id='searchMemberDiscrepancy-slct-paymentYear']//span[@class='k-input']")).Text;
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    Assert.AreEqual(ExpectedlableValue, ActualLableValue, ActualLableValue + "values are getting dispalyed");
                    break;
                case "Year Type":
                    ActualLableName = RSM.MemberDiscrepancy.searchMemberDiscrepancyyearTypeLable.Text.ToString();
                    ActualLableValue = RSM.MemberDiscrepancy.searchMemberDiscrepancyyearTypeText.Text.ToString();
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    Assert.AreEqual(ExpectedlableValue, ActualLableValue, "Both values are getting matched");
                    break;
                case "Enrollment":
                    tmsWait.Hard(2);
                    ActualLableName = RSM.MemberDiscrepancy.searchMemberDiscrepancyenrollmentLable.Text.ToString();
                    //select = new SelectElement(RSM.MemberDiscrepancy.searchMemberDiscrepancyenrollmentText);
                    ActualLableValue = Browser.Wd.FindElement(By.XPath("//*[@test-id='searchMemberDiscrepancy-select-enrollment']//span[@class='k-input']")).Text;
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    Assert.AreEqual(ExpectedlableValue, ActualLableValue, ActualLableValue + "values are getting dispalyed");
                    break;

                case "SCC":
                    ActualLableName = RSM.MemberDiscrepancy.searchMemberDiscrepancysccLable.Text.ToString();
                    ActualLableValue = RSM.MemberDiscrepancy.searchMemberDiscrepancysccText.Text.ToString();
                    Assert.IsTrue(RSM.MemberDiscrepancy.searchMemberDiscrepancysccText.Displayed, "Textbox is displayed");
                    Assert.IsTrue(RSM.MemberDiscrepancy.SCCLookup.Displayed, "icon link is displayed");
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    break;

                case "HCC":
                    ActualLableName = RSM.MemberDiscrepancy.searchMemberDiscrepancyhccLable.Text.ToString();
                    ActualLableValue = RSM.MemberDiscrepancy.searchMemberDiscrepancyhccText.Text.ToString();
                    Assert.IsTrue(RSM.MemberDiscrepancy.searchMemberDiscrepancyhccText.Displayed, "Textbox is displayed");
                    Assert.IsTrue(RSM.MemberDiscrepancy.HCCLookup.Displayed, "icon link is displayed");
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    break;

                case "RxHCC":
                    ActualLableName = RSM.MemberDiscrepancy.searchMemberDiscrepancyrxhccLable.Text.ToString();
                    ActualLableValue = RSM.MemberDiscrepancy.searchMemberDiscrepancyrxhccText.Text.ToString();
                    Assert.IsTrue(RSM.MemberDiscrepancy.searchMemberDiscrepancyrxhccText.Displayed, "Textbox is displayed");
                    Assert.IsTrue(RSM.MemberDiscrepancy.RxHCCLookup.Displayed, "icon link is displayed");
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    break;
                case "IPA/ Medical Group":
                    ActualLableName = RSM.MemberDiscrepancy.searchMemberDiscrepancyipaLable.Text.ToString();
                    Assert.IsTrue(RSM.MemberDiscrepancy.IPAMedicalGroupLookup.Displayed, "icon link is displayed");
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    break;
                case "Primary Care Physician":
                    ActualLableName = RSM.MemberDiscrepancy.searchMemberDiscrepancypcpLable.Text.ToString();
                    Assert.IsTrue(RSM.MemberDiscrepancy.PrimaryCarePhysicianLookup.Displayed, "icon link is displayed");
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    break;
                case "New Enrollment":
                    ActualLableName = RSM.MemberDiscrepancy.searchMemberDiscrepancynewEnrollmentLable.Text.ToString();
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    //Assert.IsTrue(RSM.MemberDiscrepancy.NewEnrollmentNoneOption.Displayed, "radio button is displayed");
                   // Assert.IsTrue(RSM.MemberDiscrepancy.NewEnrollmentExcludeOption.Displayed, "radio button is displayed");
                    break;
                case "Risk Score Discrepancy Only":
                    ActualLableName = RSM.MemberDiscrepancy.searchMemberDiscrepancyriskScoreDiscrepancyOnlyLable.Text.ToString();
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are not getting matched");
                    //Assert.IsTrue(RSM.MemberDiscrepancy.riskScoreDiscrepancyOnlycheckbox.Displayed, "Checkbox button is not displayed");
                    break;
            }
        }

        [Then(@"Verify Member Discrepancy page ""(.*)"" button is dispalyed")]
        public void ThenVerifyMemberDiscrepancyPageButtonIsDispalyed(string p0)
        {
            string ButtonName = p0.ToString();
            switch (ButtonName)
            {
                case "Search":
                    Assert.IsTrue(RSM.MemberDiscrepancy.SearchButton.Displayed, "Search button is not displayed");
                    break;
                case "Reset":
                    Assert.IsTrue(RSM.MemberDiscrepancy.ResetButton.Displayed, "Reset button is not displayed");
                    break;
            }
        }


        [Then(@"Member Discrepancy page Plan ID is set from dropdown")]
        public void ThenMemberDiscrepancyPagePlanIDIsSetFromDropdown()
        {
            //tmsWait.Hard(2);
            //IWebElement planID = Browser.Wd.FindElement(By.XPath("(//button[@title='All'])[1]"));
            //fw.ExecuteJavascript(planID);
            tmsWait.Hard(2);
            string xpathstring = "//multiselect[@test-id='searchMemberDiscrepancy-slct-plan']//ul//li[2]/a";
            SelectDropDownValues(xpathstring);
            tmsWait.Hard(2);           
            //fw.ExecuteJavascript(planID);
        }

        [Then(@"Member Discrepancy page PBP ID is set from dropdown")]
        public void ThenMemberDiscrepancyPagePBPIDIsSetFromDropdown()
        {
            string xpathstring = "//kendo-multiselect[@id='pbp']//input";
            SelectDropDownValues(xpathstring);
        }



        [When(@"Member Discrepancy page ""(.*)"" is set to ""(.*)""")]
        [Then(@"Member Discrepancy page ""(.*)"" Dropdown is set to ""(.*)""")]
        [Then(@"Member Discrepancy page ""(.*)"" is set to ""(.*)""")]
        public void ThenMemberDiscrepancyPageDropdownIsSetTo(string p0, string p1)
        {
            string inputtext = p0.ToLower();
            string inputvalue = p1;
            string xpathstring = null;
            string[] multipleinputvalue = null;
            //locator="";
            switch (inputtext)
            {
                case "plan id":
                    if (inputvalue.Contains(","))
                    {
                        multipleinputvalue = inputvalue.Split(',');
                        for (int i = 0; i <= multipleinputvalue.Length - 1; i++)
                        {
                            xpathstring = "//multiselect[@test-id='searchMemberDiscrepancy-slct-plan']//a[contains(.,'" + multipleinputvalue[i] + "')]/span";
                            SelectDropDownValues(xpathstring);
                        }
                    }
                    else
                    {
                        xpathstring = "//multiselect[@test-id='searchMemberDiscrepancy-slct-plan']//a[contains(.,'" + inputvalue + "')]/span";
                        SelectDropDownValues(xpathstring);
                    }

                    break;
                case "discrepancy type":
                    if (inputvalue.Contains(','))
                    {
                        multipleinputvalue = inputvalue.Split(',');
                        for (int i = 0; i <= multipleinputvalue.Length - 1; i++)
                        {
                            xpathstring = "//kendo-multiselect[@test-id='searchMemberDiscrepancy-select-discrepancyType']//input";
                            Browser.Wd.FindElement(By.XPath(xpathstring)).SendKeys(multipleinputvalue[i]);
                            Browser.Wd.FindElement(By.XPath(xpathstring)).SendKeys(OpenQA.Selenium.Keys.Enter);

                            //SelectDropDownValues(xpathstring);
                        }
                    }
                    else
                    {
                        xpathstring = "//kendo-multiselect[@test-id='searchMemberDiscrepancy-select-discrepancyType']//input";
                        Browser.Wd.FindElement(By.XPath(xpathstring)).SendKeys(inputvalue);
                        Browser.Wd.FindElement(By.XPath(xpathstring)).SendKeys(OpenQA.Selenium.Keys.Enter);

                        //SelectDropDownValues(xpathstring);
                    }

                    break;
                case "pbp":
                    if (inputvalue.Contains(','))
                    {
                        multipleinputvalue = inputvalue.Split(',');
                        for (int i = 0; i <= 1; i++)
                        {
                            Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@id='pbp']//input")).SendKeys(multipleinputvalue[i]);
                            Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@id='pbp']//input")).SendKeys(OpenQA.Selenium.Keys.Enter);

                            //xpathstring = "//multiselect[@test-id='searchMemberDiscrepancy-slct-pbp']//a[contains(.,'" + multipleinputvalue[i] + "')]/span";
                            //SelectDropDownValues(xpathstring);
                        }
                    }
                    else
                    {
                        Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@id='pbp']//input")).SendKeys(inputvalue);
                        Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@id='pbp']//input")).SendKeys(OpenQA.Selenium.Keys.Enter);

                        //xpathstring = "//multiselect[@test-id='searchMemberDiscrepancy-slct-pbp']//a[contains(.,'" + inputvalue + "')]/span";
                        //SelectDropDownValues(xpathstring);
                    }

                    break;
                case "year type":
                    if (inputvalue.Contains(','))
                    {
                        multipleinputvalue = inputvalue.Split(',');
                        for (int i = 0; i <= multipleinputvalue.Length - 1; i++)
                        {
                            xpathstring = "//kendo-multiselect[@test-id='searchMemberDiscrepancy-select-yearType']//input";
                            Browser.Wd.FindElement(By.XPath(xpathstring)).SendKeys(multipleinputvalue[i]);
                            Browser.Wd.FindElement(By.XPath(xpathstring)).SendKeys(OpenQA.Selenium.Keys.Enter);
                            //SelectDropDownValues(xpathstring);
                        }
                    }
                    else
                    {
                        xpathstring = "//kendo-multiselect[@test-id='searchMemberDiscrepancy-select-yearType']//input";
                        Browser.Wd.FindElement(By.XPath(xpathstring)).SendKeys(inputvalue);
                        Browser.Wd.FindElement(By.XPath(xpathstring)).SendKeys(OpenQA.Selenium.Keys.Enter);
                        //SelectDropDownValues(xpathstring);
                    }

                    break;
                case "payment year":
                    By Drp = By.XPath("//label[text()='Payment Year']/parent::div//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + inputvalue + "']");

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

                    //SelectValue(inputvalue, RSM.MemberDiscrepancy.PaymentYear);
                    break;
                case "enrollment":
                    By DrpEN = By.XPath("//label[text()='Enrollment']/parent::div//span[@class='k-select']");
                    By typeappEN = By.XPath("//li[text()='" + inputvalue + "']");

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(DrpEN);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeappEN);

                    //SelectValue(inputvalue, RSM.MemberDiscrepancy.Enrollment);
                    break;
                case "new enrollment":
                    if (inputvalue.Equals("Exclude"))
                    {
                        RSM.MemberDiscrepancy.NewEnrollmentExcludeOption.Click();
                    }
                    else
                    {
                        RSM.MemberDiscrepancy.NewEnrollmentNoneOption.Click();
                    }
                    break;
                case "risk score discrepancy only":
                    if (inputvalue.Equals("checked"))
                    {
                        RSM.MemberDiscrepancy.RiskScoreDiscrepancyOnlyCheckbox.Click();
                    }
                    break;

            }

        }
        public void SelectDropDownValues(string xpathstring)
        {
            IWebElement test = Browser.Wd.FindElement(By.XPath(xpathstring));
            fw.ExecuteJavascript(test);
        }

        public void SelectValue(string inputvalue, IWebElement locator)
        {
            SelectElement select = new SelectElement(locator);
            select.SelectByText(inputvalue);
        }


        [Then(@"Member Discrepancy page dispalyed ""(.*)"" dropdown with deafult value ""(.*)""")]
        public void ThenMemberDiscrepancyPageDispalyedDropdownWithDeafultValue(string p0, string p1)
        {
            string dropdown = p0.ToString();
            string expectedvalue = p1.ToString();
            switch (dropdown)
            {
                case "plan id":
                    if (RSM.MemberDiscrepancy.PlanId.Displayed && RSM.MemberDiscrepancy.PlanId.Enabled)
                    {
                        string actualvalue = RSM.MemberDiscrepancy.PlanIDdefaultvalue.ToString();
                        Assert.AreEqual(expectedvalue, actualvalue, " Both values are getting matched");
                    }
                    break;
                case "pbp":
                    if (RSM.MemberDiscrepancy.PBP.Displayed && RSM.MemberDiscrepancy.PBP.Enabled)
                    {
                        string actualvalue = RSM.MemberDiscrepancy.PBPdefaultvalue.ToString();
                        Assert.AreEqual(expectedvalue, actualvalue, " Both values are getting matched");
                    }
                    break;
                case "discrepancy type":
                    if (RSM.MemberDiscrepancy.discrepancytype.Displayed && RSM.MemberDiscrepancy.discrepancytype.Enabled)
                    {
                        string actualvalue = RSM.MemberDiscrepancy.discrepancyTypedefaultvalue.ToString();
                        Assert.AreEqual(expectedvalue, actualvalue, " Both values are getting matched");
                    }
                    break;
                case "year type":
                    if (RSM.MemberDiscrepancy.yearType.Displayed && RSM.MemberDiscrepancy.yearType.Enabled)
                    {
                        string actualvalue = RSM.MemberDiscrepancy.yearTypedefaultvalue.ToString();
                        Assert.AreEqual(expectedvalue, actualvalue, " Both values are getting matched");
                    }
                    break;
                case "payment year":
                    if (RSM.MemberDiscrepancy.PaymentYear.Displayed && RSM.MemberDiscrepancy.PaymentYear.Enabled)
                    {
                        //string actualvalue = RSM.MemberDiscrepancy.PaymentYear.ToString();
                        SelectElement select = new SelectElement(RSM.MemberDiscrepancy.PaymentYear);

                        //Assert.AreEqual(expectedvalue, actualvalue, " Both values are getting matched");
                    }
                    break;
            }
        }

        [Then(@"Member Discrepancy page dispalyed ""(.*)"" radio button with deafult value ""(.*)""")]
        public void ThenMemberDiscrepancyPageDispalyedRadioButtonWithDeafultValue(string p0, string p1)
        {
            string defaultstatus = p1.ToString();
            switch (p0.ToString())
            {
                case "NewEnrollmentNone":
                    if (defaultstatus.Contains("checked"))
                    {
                        Assert.IsTrue(RSM.MemberDiscrepancy.NewEnrollmentNoneOption.Selected, "Check box is checked");
                    }
                    break;
                case "NewEnrollmentExclude":
                    if (defaultstatus.Contains("unchecked"))
                    {
                        Assert.IsFalse(RSM.MemberDiscrepancy.NewEnrollmentExcludeOption.Selected, "Check box is un-checked");
                    }
                    break;
            }

        }

        [When(@"Member Discrepancy page ""(.*)"" drop down is clicked")]
        public void WhenMemberDiscrepancyPageDropDownIsClicked(string p0)
        {
            string inputName = p0.ToString();
            switch (inputName)
            {
                case "PlanID":
                    RSM.MemberDiscrepancy.PlanId.Click();
                    break;
            }
        }

        [Then(@"Verify TMS ""(.*)"" title is displayed")]
        public void ThenVerifyTMSTitleIsDisplayed(string p0)
        {
            string actual = RSM.MemberDiscrepancy.memberDetailsClinicalTitle.Text;
            Assert.IsTrue(actual.Contains(p0), "Title does not match");
        }

        [Then(@"Verify the Clinical HCC's table Details column should displayed the hyperlink to open the record")]
        public void ThenVerifyTheClinicalHCCSTableDetailsColumnShouldDisplayedTheHyperlinkToOpenTheRecord()
        {
            string xpath = "//div[@test-id='memberDiscrepancy-grid-clinicalGrid' and contains(.,'HCC')]//following-sibling::div//div//a";
            var countOfRows = Browser.Wd.FindElements(By.XPath(xpath)).Count;
            Assert.IsTrue(countOfRows > 1, "View icon link is displayed under Details column");
        }

        [Then(@"Member Discrepancy page Clinical HCC's table page is set to ""(.*)""")]
        public void ThenMemberDiscrepancyPageClinicalHCCSTablePageIsSetTo(int p0)
        {
            string pageSize = p0.ToString();
            RSM.MemberDiscrepancy.ClinicalHCCPageSize.Click();
            RSM.MemberDiscrepancy.ClinicalHCCPageSize.Clear();
            RSM.MemberDiscrepancy.ClinicalHCCPageSize.SendKeys(pageSize);
            RSM.MemberDiscrepancy.ClinicalHCCPageSize.SendKeys(OpenQA.Selenium.Keys.Enter);

        }

        [Then(@"Verify RSM Application ""(.*)"" from Member details page Pagination ""(.*)"" is dispalyed")]
        public void ThenVerifyRSMApplicationFromMemberDetailsPagePaginationIsDispalyed(string p0, string p1)
        {
            string tablename = p0.ToString();
            string buttonString = p1.ToString();
            switch (tablename)
            {
                case "Clinical HCCs":
                    ValidationOfClinicalHCCsBottomTable("memberDiscrepancy-grid-clinicalGrid", buttonString);
                    break;
                case "Member Discrepancy result grid":
                    ValidationOfClinicalHCCsBottomTable("memberDiscrepancy-pagination-resultMemberDiscrepancyGrid", buttonString);
                    break;
            }
        }

        public void ValidationOfClinicalHCCsBottomTable(string tableGridName, string buttonString)
        {
            string[] ArrayOfButton = buttonString.Split('/');
            string tableGrid = tableGridName;
            for (int i = 0; i <= ArrayOfButton.Length; i++)
            {
                switch (ArrayOfButton[i])
                {
                    case "First":
                        ValidationOfPaginationTableButtons(tableGrid, ArrayOfButton[i]);
                        break;
                    case "Next":
                        ValidationOfPaginationTableButtons(tableGrid, ArrayOfButton[i]);
                        break;
                    case "Previous":
                        ValidationOfPaginationTableButtons(tableGrid, ArrayOfButton[i]);
                        break;
                    case "Page Size":
                        ValidationOfPaginationTableButtons(tableGrid, ArrayOfButton[i]);
                        break;
                }
            }
        }

        public void ValidationOfPaginationTableButtons(string tableGrid, string buttonName)
        {
            string xpath = "//div[@test-id='" + tableGrid + "']//div[contains(.,'" + buttonName + "')]//li[1]//a";
            IWebElement Button = Browser.Wd.FindElement(By.XPath(xpath));
            Assert.IsTrue(Button.Displayed, buttonName + " is Displayed");
        }


        [When(@"Member Discrepancy page ""(.*)"" result table ""(.*)"" button is clicked")]
        public void WhenMemberDiscrepancyPageResultTableButtonIsClicked(string p0, string p1)
        {
            string tableName = p0.ToString();
            string buttonName = p1.ToString();
            switch (tableName)
            {
                case "Clinical HCCs":
                    Browser.Wd.FindElement(By.XPath("//div[@test-id='memberDiscrepancy-pagination-resultMemberDiscrepancyGrid']//div[contains(.,'" + buttonName + "')]")).Click();
                    break;
                case "Demographic HCCs":
                    break;
            }
        }

        [Then(@"Verify Member Discrepancy page ""(.*)"" result table ""(.*)"" button is ""(.*)""")]
        public void ThenVerifyMemberDiscrepancyPageResultTableButtonIs(string p0, string p1, string p2)
        {
            string resultTableName = p0.ToString();
            string buttonName = p1.ToString();
            string buttonStatus = p2.ToString();
            IWebElement ClinicalButton;
            switch (resultTableName)
            {
                case "Clinical HCCs":
                    ClinicalButton = Browser.Wd.FindElement(By.XPath("//div[@test-id='memberDiscrepancy-pagination-resultMemberDiscrepancyGrid']//div[contains(.,'" + buttonName + "')]"));
                    if (buttonStatus.Equals("Enabled"))
                    {
                        Assert.IsTrue(ClinicalButton.Enabled, buttonName + " is Disabled");
                    }
                    else if (buttonStatus.Equals("Disabled"))
                    {
                        Assert.IsFalse(ClinicalButton.Enabled, buttonName + " is Enabled");
                    }
                    break;
            }


        }

        [Then(@"Verify below ""(.*)"" Result table is dispalyed on Member Discrepancy page")]
        public void ThenVerifyBelowResultTableIsDispalyedOnMemberDiscrepancyPage(string p0, Table table)
        {
            string TableName = p0.ToString();

            switch (TableName)
            {
                case "RAPS Drill-Down":
                    TableValidation(table, RSM.MemberDiscrepancy.resultMemberDiscrepancyrapsGrid);
                    break;
                case "Clinical":
                    TableValidation(table, RSM.MemberDiscrepancy.resultMemberDiscrepancyclinicalGrid);
                    break;
                case "Member Discrepancy":
                    TableValidation(table, RSM.MemberDiscrepancy.resultMemberDiscrepancyGrid);
                    break;

            }
        }

        public void TableValidation(Table table, IWebElement p1)
        {
            try
            {
                //Create Storage for the Gherkin table and the page data
                GherkinTable thisGT = new GherkinTable();
                TablePaging thisTP = new TablePaging();

                //Load the Gherkin table into the storage
                thisGT.LoadGherkinTable(table);
                int headercnt = table.Header.Count;
                //The big loop.  Keep working until all the Gherkin table rows are marked as matched
                //Or until we are on the last page of records, then we also quit looking.
                while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
                {
                    //Start out with the assumption we are not on the last page of records.  We will check later.
                    thisTP.bNotAtLastPageOfRecords = true;

                    //Get the table object again, since the page refreshes we need to get it fresh
                    IWebElement baseTable = p1;
                    //IWebElement paginationSystem = p2;

                    thisTP.LoadRSMGrid(baseTable, headercnt, "ui-grid-row", "ui-grid-cell");

                    int iTableCounter = 0;
                    // string expectedTableCheckboxValue = "";
                    //for each row in the Gherkin table, start flipping through all the rows in the page data.
                    foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                    {
                        //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                        //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                        if (GherkinTableRow == null)
                        {
                            break;
                        }

                        //If this Gherkin table row is not yet matched, proceed.
                        if (GherkinTableRow.RowIsMatched == false)
                        {
                            //Convert the row to an array so we can do an element by element match.
                            string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                            //For each row in the page data
                            //App function chalu hotey
                            foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                            {
                                //Convert page data to array elements
                                //Only work with the loaded element rows.  The first unloaded one will be null.
                                if (ApplicationRow == null)
                                {
                                    break;
                                }

                                //Convert the page row to array so we can pair up by elements.
                                string[] AppTableRow = ApplicationRow.Row.ToArray();
                                int iElementCounter = 0;
                                Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                                //In here as we pair up the data you will have custom matching.
                                //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                                foreach (string appTD in AppTableRow)
                                {

                                    //if (iElementCounter > 0 && TDA.RowIsData)
                                    if (ApplicationRow.RowIsData)
                                    {
                                        //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                        if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                        {

                                            bThisRowMatches = false;
                                        }
                                        //if (iElementCounter == 5)
                                        //{
                                        //    expectedTableCheckboxValue = GherkinTableArray[5];
                                        //}
                                    }
                                    else
                                    {
                                        //Also fail row match if the element count of the page data row is 0
                                        if (iElementCounter > 0)
                                        {
                                            bThisRowMatches = false;
                                        }
                                    }
                                    iElementCounter++;
                                }

                                if (AppTableRow.Length == 0)
                                {
                                    //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                    bThisRowMatches = false;
                                }
                                //Instance of TableRow Class for reporting functions
                                var TableRow = new TMSString();
                                //If we get here and we still match, then the array elements were the same

                                if (bThisRowMatches)
                                {
                                    //report the success stuff.  Puts out the row data, etc.
                                    thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                                    break;
                                }
                                // break;
                            }
                        }
                        iTableCounter++;
                    }
                    //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                    Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);

                    if (fullMatching)
                    {
                        Console.WriteLine("All rows are matched, step completed as passed");
                    }
                    else
                    {
                        //Click next page link and start over.
                        if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                        {
                            thisTP.bNotAtLastPageOfRecords = true;
                            thisTP.NPL.Click();
                            tmsWait.Hard(2);
                        }
                    }
                    baseTable = p1;

                    //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                    //Time to boil it down and report which rows didn't get matched.
                    //Also to fail because we were planning to match the rows.
                    if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                    {
                        thisTP.ReportNotMatching(thisGT.GTable);
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Members View Edit Table has row: {0}", e.Message);
            }
        }


        [Then(@"Member Discrepancy page dispalyed ""(.*)"" Lookup along with magnifying icon")]
        public void ThenMemberDiscrepancyPageDispalyedLookupAlongWithMagnifyingIcon(string p0)
        {
            string Lookupinput = p0.ToString();
            tmsWait.Hard(1);
            string GenerateData = tmsCommon.GenerateData(p0);
            string setOptionbutton = GenerateData.ToLower();
            string fieldName = null;
            bool actual = false;
            string expected = "false";
            switch (Lookupinput)
            {
                case "HIC":
                    fieldName = setOptionbutton;
                    actual = RSM.MemberDiscrepancy.HICLookup.Displayed;
                    expected = "True";
                    Assert.IsTrue(actual, "Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "]");
                    fw.ConsoleReport("Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
                    break;

                case "SCC":
                    fieldName = setOptionbutton;
                    actual = RSM.MemberDiscrepancy.SCCLookup.Displayed;
                    expected = "True";
                    Assert.IsTrue(actual, "Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "]");
                    fw.ConsoleReport("Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
                    break;

                case "HCC":
                    fieldName = setOptionbutton;
                    actual = RSM.MemberDiscrepancy.HCCLookup.Displayed;
                    expected = "True";
                    Assert.IsTrue(actual, "Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "]");
                    fw.ConsoleReport("Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
                    break;

                case "RXHCC":
                    fieldName = setOptionbutton;
                    actual = RSM.MemberDiscrepancy.RxHCCLookup.Displayed;
                    expected = "True";
                    Assert.IsTrue(actual, "Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "]");
                    fw.ConsoleReport("Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
                    break;

                case "IPA/Medical Group":
                    fieldName = setOptionbutton;
                    actual = RSM.MemberDiscrepancy.IPAMedicalGroupLookup.Displayed;
                    expected = "True";
                    Assert.IsTrue(actual, "Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "]");
                    fw.ConsoleReport("Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
                    break;
                case "Primary Care Physician":
                    fieldName = setOptionbutton;
                    actual = RSM.MemberDiscrepancy.PrimaryCarePhysicianLookup.Displayed;
                    expected = "True";
                    Assert.IsTrue(actual, "Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "]");
                    fw.ConsoleReport("Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
                    break;
            }
        }


        [Then(@"Verify Dashboard page  is displayed with title ""(.*)""")]
        public void ThenVerifyDashboardPageIsDisplayedWithTitle(string p0)
        {
            IWebElement hhh = RSM.RSMDashboard.RiskScoreTrendDetailsGraph;
            Console.Write("Hello");
        }


        [Then(@"Verify Framework Administration page display ""(.*)""")]
        public void ThenVerifyFrameworkAdministrationPageDisplay(string p0)
        {
            switch(p0.ToLower())
            {
                case "application version":
                     Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//label)[1]")).Text.Contains(p0), "Application version label is not displayed");
                     break;

                case "database version":
                     Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//label)[2]")).Text.Contains(p0), "Database version label is not displayed");
                     break;

                case "server version":
                     Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//label)[3]")).Text.Contains(p0), "Server version label is not displayed");
                    break;
            }
        }

    }

   

}
