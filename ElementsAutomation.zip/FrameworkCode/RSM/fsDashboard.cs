﻿
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using TechTalk.SpecFlow;

namespace TMSoR1
{
    [Binding]
    class fsDashboard
    {
        [When(@"Part C button of Risk Score Estimated Receivable graph is clicked")]
        public void WhenPartCButtonOfRiskScoreEstimatedReceivableGraphIsClicked()
        {
            tmsWait.Hard(5);
            new Actions(Browser.Wd).MoveToElement(RSM.RSMDashboard.RiskScoreEstimatedReceivableGraph, 0, 100).MoveByOffset(0, 100).Click().Build().Perform();
            tmsWait.Hard(5);
        }

        [When(@"Risk Score Estimated Receivable report page Run Report button is clicked")]
        public void WhenRiskScoreEstimatedReceivableReportPageRunReportButtonIsClicked()
        {
            RSM.RiskScoreEstimatedReceivable.RunReportButton.Click();
        }

        [Then(@"Verify Part C Risk Score Estimated Receivable report is generated")]
        public void ThenVerifyPartCRiskScoreEstimatedReceivableReportIsGenerated()
        {
            Browser.SwitchToChildWindow();
            string expectedPlanID = "Plan ID:" + RSM.RiskScoreEstimatedReceivable.SelectedPlanID.Text;
            string expectedPayYear = "Pay Year:" + RSM.RiskScoreEstimatedReceivable.SelectedPaymentYear.Text;

            string actualPlanID = RSM.RiskScoreEstimatedReceivable.PlanIDonReport.Text;
            string actualPayYear = RSM.RiskScoreEstimatedReceivable.PaymentYearonReport.Text;

            Assert.AreEqual(expectedPlanID, actualPlanID, "Plan ID is mismatch.");
            Assert.AreEqual(expectedPayYear, actualPayYear, "Pay Year is mismatch.");

            Browser.Wd.Close();
        }

    }
}
