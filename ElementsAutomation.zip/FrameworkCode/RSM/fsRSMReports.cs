﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
//using System.Windows.Forms;
using System.Globalization;
using System.IO;
using TMSoR1.FrameworkCode;
using System.Xml;

namespace TMSoR1
{
    [Binding]
    class fsRSMReports
    {
        public static string GeneratedUserID;
        public static string GeneratedFirstName;
        public static string GeneratedLastName;
        [Then(@"verify HIC Information ""(.*)"" value on Member HCC Details Result page from DB for ""(.*)""")]
        public void ThenVerifyHICInformationValueOnMemberHCCDetailsResultPageFromDBFor(string fieldName, string queryParameter)
        {
            List<string> list = new List<string>();
            Dictionary<int, string[]> table = new Dictionary<int, string[]>();
            string GeneratedData = tmsCommon.GenerateData(queryParameter);
            string DB = ConfigFile.RSMdb;
            fsRSMLogin DBquery = new fsRSMLogin();
            string SqlString = "SELECT TOP 1 pf.PlanId,p.PlanName,pf.CLAIM,pf.GRP1,pf.PBP,pf.SCC ,m.LastName,m.FirstName,pf.PCP1,sc.State, sc.County,pf.DOB FROM [" + DB + "].[dbo].[tbPlanFlags] pf INNER JOIN [" + DB + "].[dbo].[tbPlans] p ON pf.PlanID = p.PlanID INNER JOIN [" + DB + "].[dbo].[tbPDMMembers] m ON m.HICNumber = pf.Claim LEFT OUTER JOIN[" + DB + "].[dbo].[tbProviderGroup] pg ON pf.GRP1 = pg.GroupNum LEFT OUTER JOIN[" + DB + "].[dbo].[tbStateCounty] sc ON sc.SCCode = pf.SCC WHERE Claim = '" + GeneratedData + "'";
            // string SqlString = "SELECT TOP 1 pf.PlanId,p.PlanName,pf.CLAIM,pf.GRP1,pf.PBP,pf.SCC ,m.LastName,m.FirstName,pf.PCP1,sc.State, sc.County,pf.DOB FROM tbPlanFlags pf INNER JOIN tbPlans p ON pf.PlanID = p.PlanID INNER JOIN tbPDMMembers m ON m.HICNumber = pf.Claim LEFT OUTER JOIN tbProviderGroup pg ON pf.GRP1 = pg.GroupNum LEFT OUTER JOIN tbStateCounty sc ON sc.SCCode = pf.SCC WHERE Claim = '" + GeneratedData + "'";
            table = DBquery.ExecuteSingleQuery(SqlString, DB, 12);//values contains the row returned from DB query
            //SqlDataReader reader = thisCommand.ExecuteReader();
            //if (reader.HasRows)
            //{
            //    while (reader.Read())
            //    {
            //        for(int i=0;i<reader.FieldCount;i++)
            //        list.Add(reader.GetValue(i).ToString());
            //    }
            //}
            //string[] values = list.ToArray();//values contains the row returned from DB query
            string[] values = table[0];
            switch (fieldName.ToLower().Trim())
            {
                case "hic":
                    Assert.IsTrue(RSM.MemberHCCDetai.ResultSectionHICN.Displayed, fieldName + " is not displayed");
                    //Assert.IsTrue(RSM.MemberHCCDetai.ResultSectionHICNvalue.Text.Equals(values[2].Trim()), "Expected value" + values[2] + " did not matched actual value displayed" + RSM.MemberHCCDetai.ResultSectionHICNvalue.Text);
                    Assert.IsTrue(values.Contains(RSM.MemberHCCDetai.ResultSectionHICNvalue.Text), "");
                    break;
                case "last name":
                    Assert.IsTrue(RSM.MemberHCCDetai.ResultSectionLastName.Displayed, fieldName + " is not displayed");
                    Assert.IsTrue(RSM.MemberHCCDetai.ResultSectionLastNamevalue.Text.Equals(values[6].Trim()), "Expected value" + values[6] + " did not matched actual value displayed" + RSM.MemberHCCDetai.ResultSectionLastNamevalue.Text);
                    break;
                case "first name":
                    Assert.IsTrue(RSM.MemberHCCDetai.ResultSectionFirstName.Displayed, fieldName + " is not displayed");
                    Assert.IsTrue(RSM.MemberHCCDetai.ResultSectionFirstNamevalue.Text.Equals(values[7].Trim()), "Expected value" + values[7] + " did not matched actual value displayed" + RSM.MemberHCCDetai.ResultSectionFirstNamevalue.Text);
                    break;
                case "dob":
                    Assert.IsTrue(RSM.MemberHCCDetai.ResultSectionDOB.Displayed, fieldName + " is not displayed");
                    string[] dateandtime = values[11].Split(' ');
                    string expecteddate = dateandtime[0];
                    string[] expecteddateSplit = expecteddate.Split('/');
                    string actualdate = RSM.MemberHCCDetai.ResultSectionDOBvalue.Text;
                    string[] actualdatesplit = actualdate.Split('/');
                    Assert.IsTrue(actualdatesplit[0].Contains(expecteddateSplit[0]), "Expected value" + values[11] + " did not matched actual value displayed" + RSM.MemberHCCDetai.ResultSectionDOBvalue.Text);
                    Assert.IsTrue(actualdatesplit[1].Contains(expecteddateSplit[1]), "Expected value" + values[11] + " did not matched actual value displayed" + RSM.MemberHCCDetai.ResultSectionDOBvalue.Text);
                    Assert.IsTrue(actualdatesplit[2].Contains(expecteddateSplit[2]), "Expected value" + values[11] + " did not matched actual value displayed" + RSM.MemberHCCDetai.ResultSectionDOBvalue.Text);
                    break;

            }
        }
        [Then(@"verify Plan Information ""(.*)"" value on Member HCC Details Result page from DB for ""(.*)""")]
        public void ThenVerifyPlanInformationValueOnMemberHCCDetailsResultPageFromDBFor(string fieldName, string queryParameter)
        {
            List<string> list = new List<string>();
            Dictionary<int, string[]> table = new Dictionary<int, string[]>();
            string GeneratedData = tmsCommon.GenerateData(queryParameter);
            fsRSMLogin DBquery = new fsRSMLogin();
            string SqlString = "SELECT TOP 1 pf.PlanId,p.PlanName,pf.CLAIM,pf.GRP1,pf.PBP,pf.SCC ,m.LastName,m.FirstName,pf.PCP1,sc.State, sc.County,pf.DOB FROM [RSM].[dbo].[tbPlanFlags] pf INNER JOIN [RSM].[dbo].[tbPlans] p ON pf.PlanID = p.PlanID INNER JOIN [RSM].[dbo].[tbPDMMembers] m ON m.HICNumber = pf.Claim LEFT OUTER JOIN[RSM].[dbo].[tbProviderGroup] pg ON pf.GRP1 = pg.GroupNum LEFT OUTER JOIN[RSM].[dbo].[tbStateCounty] sc ON sc.SCCode = pf.SCC   WHERE   Claim = '" + GeneratedData + "'";
            table = DBquery.ExecuteSingleQuery(SqlString, "RSM", 12);
            string[] values = table[0];
            switch (fieldName.ToLower().Trim())
            {
                case "plan id":
                    Assert.IsTrue(RSM.MemberHCCDetai.ResultSectionPlanID.Displayed, fieldName + " is not displayed");
                    Assert.IsTrue(RSM.MemberHCCDetai.ResultSectionPlanIDvalue.Text.Equals(values[0].Trim()), "Expected value" + values[0] + " did not matched actual value displayed" + RSM.MemberHCCDetai.ResultSectionPlanIDvalue.Text);
                    break;
                case "plan name":
                    Assert.IsTrue(RSM.MemberHCCDetai.ResultSectionPlanName.Displayed, fieldName + " is not displayed");
                    Assert.IsTrue(RSM.MemberHCCDetai.ResultSectionPlanNamevalue.Text.Equals(values[1].Trim()), "Expected value" + values[1] + " did not matched actual value displayed" + RSM.MemberHCCDetai.ResultSectionPlanNamevalue.Text);
                    break;
                case "pcp":
                    Assert.IsTrue(RSM.MemberHCCDetai.ResultSectionPCP.Displayed, fieldName + " is not displayed");
                    Assert.IsTrue(RSM.MemberHCCDetai.ResultSectionPCPvalue.Text.Equals(values[8].Trim()), "Expected value" + values[8] + " did not matched actual value displayed" + RSM.MemberHCCDetai.ResultSectionHICNvalue.Text);
                    break;
                case "ipa/group":
                    Assert.IsTrue(RSM.MemberHCCDetai.ResultSectionIPAgroup.Displayed, fieldName + " is not displayed");
                    if (values[3].Trim().Equals(""))
                        Assert.IsTrue(RSM.MemberHCCDetai.ResultSectionIPAgroupvalue.Text.Equals("--"), "Expected value" + values[3] + " did not matched actual value displayed" + RSM.MemberHCCDetai.ResultSectionIPAgroupvalue.Text);
                    else Assert.IsTrue(RSM.MemberHCCDetai.ResultSectionIPAgroupvalue.Text.Equals(values[3].Trim()), "Expected value" + values[3] + " did not matched actual value displayed" + RSM.MemberHCCDetai.ResultSectionIPAgroupvalue.Text);
                    break;
                case "pbp":
                    Assert.IsTrue(RSM.MemberHCCDetai.ResultSectionPBP.Displayed, fieldName + " is not displayed");
                    Assert.IsTrue(RSM.MemberHCCDetai.ResultSectionPBPvalue.Text.Equals(values[4].Trim()), "Expected value" + values[4] + " did not matched actual value displayed" + RSM.MemberHCCDetai.ResultSectionPCPvalue.Text);
                    break;

                case "scc":
                    Assert.IsTrue(RSM.MemberHCCDetai.ResultSectionSCC.Displayed, fieldName + " is not displayed");
                    Assert.IsTrue(RSM.MemberHCCDetai.ResultSectionSCCvalue.Text.Equals(values[5].Trim()), "Expected value" + values[5] + " did not matched actual value displayed" + RSM.MemberHCCDetai.ResultSectionSCCvalue.Text);
                    break;
                case "state":
                    Assert.IsTrue(RSM.MemberHCCDetai.ResultSectionState.Displayed, fieldName + " is not displayed");
                    Assert.IsTrue(RSM.MemberHCCDetai.ResultSectionStatevalue.Text.Equals(values[9].Trim()), "Expected value" + values[9] + " did not matched actual value displayed" + RSM.MemberHCCDetai.ResultSectionStatevalue.Text);
                    break;
                case "country":
                    Assert.IsTrue(RSM.MemberHCCDetai.ResultSectionCountry.Displayed, fieldName + " is not displayed");
                    Assert.IsTrue(RSM.MemberHCCDetai.ResultSectionCountryvalue.Text.Equals(values[10].Trim()), "Expected value" + values[10] + " did not matched actual value displayed" + RSM.MemberHCCDetai.ResultSectionCountryvalue.Text);
                    break;

            }
        }
        [Then(@"Compare Demographic HCC's on File for Member table value from DB for ""(.*)""")]
        public void ThenCompareDemographicHCCSOnFileForMemberTableValueFromDBFor(string queryParameter)
        {
            string GeneratedData = tmsCommon.GenerateData(queryParameter);
            fsRSMLogin DBquery = new fsRSMLogin();
            Dictionary<int, string[]> table = new Dictionary<int, string[]>();
            int rowsfromtable = 0;
            string SqlString = "";
            string[] rowFromDB = null;
            TablePaging thisTP = new TablePaging();

            thisTP.LoadRSMGrid(RSM.MemberHCCDetai.ResultSectionDemographicGrid, 15, "ui-grid-row", "ui-grid-cell");
            SqlString = "SELECT distinct PAY_YEAR,SEX,AGE,MCAID,DISABLE,PREV_DISABLE,LIN_FLAG,LTI_flag,CMS_SEX, CMS_AGE,CMS_MCAID,CMS_DISABLE,CMS_PREV_DISABLE,LIN_FLAG,LTI_flag from MEMBER_PLAN_YEAR_PCP mp where mp.HIC = '" + GeneratedData + "' and LIN_FLAG is not NULL and LTI_flag is not NULL";
            table = DBquery.ExecuteSingleQuery(SqlString, "RSM", 15);
            rowsfromtable = table.Count;
            foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
            {
                if (ApplicationRow == null) break;
                string[] AppTableRow = ApplicationRow.Row.ToArray();
                int rowmatched = 1;
                if (AppTableRow[0] == "Payment Year")
                { }
                else
                {
                    for (int j = 0; j < rowsfromtable; j++)
                    {
                        if (AppTableRow.Length == table[j].Length)
                            rowFromDB = table[j];
                        if (rowFromDB[6].Trim() == "1") rowFromDB[6] = "Y"; else rowFromDB[6] = "N";
                        if (rowFromDB[7].Trim() == "1") rowFromDB[7] = "Y"; else rowFromDB[7] = "N";
                        if (rowFromDB[13].Trim() == "1") rowFromDB[13] = "Y"; else rowFromDB[13] = "N";
                        if (rowFromDB[14].Trim() == "1") rowFromDB[14] = "Y"; else rowFromDB[14] = "N";
                        string ApptableRowStr = string.Join(",", AppTableRow);
                        string rowFromDBStr = string.Join(",", rowFromDB);
                        if (ApptableRowStr.Equals(rowFromDBStr))
                        {
                            rowmatched = 0;
                            Assert.IsTrue(true, ApptableRowStr + " from application matched with" + rowFromDBStr + "  from DB");

                            Console.WriteLine(ApptableRowStr + " from application matched with" + rowFromDBStr + " +from DB");
                            break;
                        }
                    }
                    Assert.IsTrue(rowmatched == 0, "Rows from Db did not matched row from UI");
                }
            }

        }
        [Then(@"Compare ""(.*)"" table value from DB for ""(.*)""")]
        public void ThenCompareTableValueFromDBFor(string p0, string queryParameter)
        {
            string GeneratedData = tmsCommon.GenerateData(queryParameter);
            fsRSMLogin DBquery = new fsRSMLogin();
            Dictionary<int, string[]> table = new Dictionary<int, string[]>();
            int rowsfromtable = 0;
            string SqlString = "";
            string[] rowFromDB = null;

            TablePaging thisTP = new TablePaging();

            thisTP.LoadRSMGrid(RSM.MemberHCCDetai.ResultSectionRiskScoreGrid, 9, "ui-grid-row", "ui-grid-cell");
            SqlString = "Select distinct mp.PAY_YEAR,prs.YEAR_TYPE_ID,mp.Enroll_Months, mp.PLAN_RAFT,mp.CMS_RAFT,rs.RISK_SCORE, mp.CMS_RISK_A,prs.RISK_SCORE,mp.CMS_RISK_D from MEMBER_PLAN_YEAR_PCP mp INNER JOIN PLAN_RISK_SCORE_D prs ON prs.HIC = mp.HIC AND prs.PAYMENT_YEAR = mp.PAY_YEAR INNER JOIN PLAN_RISK_SCORE rs ON rs.HIC = mp.HIC AND rs.PAYMENT_YEAR = mp.PAY_YEAR where prs.HIC = '" + GeneratedData + "' AND prs.YEAR_TYPE_ID IN(1, 2, 4) and prs.RISK_SCORE != 0";
            table = DBquery.ExecuteSingleQuery(SqlString, "RSM", 9);
            rowsfromtable = table.Count;
            foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
            {


                if (ApplicationRow == null) break;
                string[] AppTableRow = ApplicationRow.Row.ToArray();
                int rowmatched = 1;
                if (AppTableRow[0] == "Payment Year")
                { }
                else
                {
                    for (int j = 0; j < rowsfromtable; j++)
                    {
                        if (AppTableRow.Length == table[j].Length)
                            rowFromDB = table[j];
                        if (rowFromDB[1] == "1") rowFromDB[1] = "Fiscal";
                        if (rowFromDB[1] == "2") rowFromDB[1] = "Calendar";
                        if (rowFromDB[1] == "4") rowFromDB[1] = "Final";
                        rowFromDB[3] = rowFromDB[3].Trim();
                        rowFromDB[4] = rowFromDB[4].Trim();
                        rowFromDB[5] = Math.Round(Decimal.Parse(rowFromDB[5].ToString()), 3).ToString();
                        rowFromDB[6] = Math.Round(Decimal.Parse(rowFromDB[6].ToString()), 3).ToString();
                        rowFromDB[8] = Math.Round(Decimal.Parse(rowFromDB[8].ToString()), 2, MidpointRounding.AwayFromZero).ToString();
                        string ApptableRowStr = string.Join(",", AppTableRow);
                        string rowFromDBStr = string.Join(",", rowFromDB);
                        if (ApptableRowStr.Equals(rowFromDBStr))
                        {
                            rowmatched = 0;
                            Assert.IsTrue(true, ApptableRowStr + " from application matched with" + rowFromDBStr + "  from DB");

                            Console.WriteLine(ApptableRowStr + " from application matched with" + rowFromDBStr + " +from DB");
                            break;
                        }
                    }
                    Assert.IsTrue(rowmatched == 0, "Rows from Db did not matched row from UI");
                }
            }
        }

        [When(@"Select first record from ""(.*)"" page")]
        public void WhenSelectFirstRecordFromPage(string p0)
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//input[@type='checkbox'])[1]")));
            GlobalRef.HICMemberSearchCriteria = Browser.Wd.FindElement(By.XPath("(//div[@id='memberLookupGird']//td/input[@type='checkbox']/parent::td/following-sibling::td[2]/span)[1]")).Text;
            GlobalRef.MBINAME = Browser.Wd.FindElement(By.XPath("(//div[@id='memberLookupGird']//td/input[@type='checkbox']/parent::td/following-sibling::td[1]/span)[1]")).Text;



        }

        [Then(@"Verify Risk Score Manager page ""(.*)"" is displayed")]
        public void ThenVerifyRiskScoreManagerPageIsDisplayed(string field)
        {

            switch (field)
            {
                case "Dashboard":
                    Assert.IsTrue(RSM.RSMDashboard.rsmDashboardtitle.Displayed, field + "is not displayed");
                    break;
                case "Payment Year dropdown":
                    Assert.IsTrue(RSM.RSMDashboard.PaymentYearDropdown.Displayed, field + "is not displayed");
                    break;
                case "Year Type dropdown":
                    Assert.IsTrue(RSM.RSMDashboard.YearTypeDropdown.Displayed, field + "is not displayed");
                    break;
            }
        }

        [Then(@"Verify Risk Score Manager page Risk Score Trend Details section ""(.*)"" is displayed")]
        public void ThenVerifyRiskScoreManagerPageRiskScoreTrendDetailsSectionIsDisplayed(string field)
        {
            if (field.Equals("Part C button"))
            {
                Assert.IsTrue(RSM.RSMDashboard.TrendPartCButton.Displayed, field + "is not displayed");
            }
            else if (field.Equals("Part D button"))
            {
                Assert.IsTrue(RSM.RSMDashboard.TrendPartDButton.Displayed, field + "is not displayed");
            }
        }

        [Then(@"Verify Risk Score Manager page Risk Score Estimated Receivable section ""(.*)"" is displayed")]
        public void ThenVerifyRiskScoreManagerPageRiskScoreEstimatedReceivableSectionIsDisplayed(string field)
        {


            if (field.Equals("Part C button"))
            {
                Assert.IsTrue(RSM.RSMDashboard.EstimatedPartCButton.Displayed, field + "is not displayed");
            }
            else if (field.Equals("Part D button"))
            {
                Assert.IsTrue(RSM.RSMDashboard.EstimatedPartCButton.Displayed, field + "is not displayed");
            }
        }

        [Then(@"Verify Risk Score Manager page FRM Risk score cutover period table is displayed")]
        public void ThenVerifyRiskScoreManagerPageFRMRiskScoreCutoverPeriodTableIsDisplayed()
        {
            Assert.IsTrue(RSM.RSMDashboard.FRMRiskscorecutoverperiodTable.Displayed, " Risk Score Manager page FRM Risk score cutover period table is not displayed");
        }

        [Then(@"Administrations page Warehouse Configuration section Reset button is Clicked")]
        public void ThenAdministrationsPageWarehouseConfigurationSectionResetButtonIsClicked()
        {
            EAM.TmsOperationalConfiguration.Reset.Click();
        }


        [Then(@"Verify Administrations page Warehouse Configuration section ""(.*)"" field is set to ""(.*)""")]
        public void ThenVerifyAdministrationsPageWarehouseConfigurationSectionFieldIsSetTo(string field, string expValue)
        {
            switch (field)
            {
                case "Database Name":

                    Assert.AreEqual(expValue, EAM.TmsOperationalConfiguration.DBName.Text, expValue + "is not getting displayed");
                    break;
                case "Database Server":
                    Assert.AreEqual(expValue, EAM.TmsOperationalConfiguration.DBServer.Text, expValue + "is not getting displayed");

                    break;
                case "Database User":
                    Assert.AreEqual(expValue, EAM.TmsOperationalConfiguration.DBUser.Text, expValue + "is not getting displayed");

                    break;
                case "Password":
                    Assert.AreEqual(expValue, EAM.TmsOperationalConfiguration.Password.Text, expValue + "is not getting displayed");

                    break;
            }

        }


        [Then(@"Administrations page Warehouse Configuration section ""(.*)"" field is set to ""(.*)""")]
        public void ThenAdministrationsPageWarehouseConfigurationSectionFieldIsSetTo(string field, string p1)
        {
            switch (field)
            {
                case "Database Name":
                    EAM.TmsOperationalConfiguration.DBName.SendKeys(p1);
                    break;
                case "Database Server":
                    EAM.TmsOperationalConfiguration.DBServer.SendKeys(p1);
                    break;
                case "Database User":
                    EAM.TmsOperationalConfiguration.DBUser.SendKeys(p1);
                    break;
                case "Password":
                    EAM.TmsOperationalConfiguration.Password.SendKeys(p1);
                    break;
            }
        }

        [Then(@"Verify HCC Field has value ""(.*)""")]
        public void ThenVerifyHCCFieldHasValue(string p0)
        {
            string hccvalue = tmsCommon.GenerateData(p0);
            //Assert.AreEqual(hccvalue, RSM.HCCDiscrepancy.);
        }

        [Then(@"Select MBI from Member Search Criteria page")]
        public void ThenSelectMBIFromMemberSearchCriteriaPage()
        {
            IWebElement search = Browser.Wd.FindElement(By.CssSelector("[test-id='memberlookup-btn-Search']"));
            fw.ExecuteJavascript(search);
            tmsWait.Hard(2);
            IWebElement selctMBI = Browser.Wd.FindElement(By.CssSelector("[test-id='memberlookup-btn-Search']"));
            fw.ExecuteJavascript(selctMBI);
            tmsWait.Hard(2);

        }


        [When(@"Select the record ""(.*)"" from ""(.*)"" page")]
        [Then(@"Select the record ""(.*)"" from ""(.*)"" page")]
        [Given(@"Select the record ""(.*)"" from ""(.*)"" page")]
        public void ThenSelectTheRecordFromPage(string valueToSearch, string pageName)
        {
            tmsWait.Hard(5);
            IWebElement checkbox1;
            switch (pageName)
            {
                case "PCP Search Criteria":
                    checkbox1 = Browser.Wd.FindElement(By.XPath("//*[@id='pcpLookupGrid']/div[2]/table/tbody/tr[1]/td[1]/input[@type='checkbox']"));
                    fw.ExecuteJavascript(checkbox1);
                    break;

                case "Member Search Criteria":
                    checkbox1 = Browser.Wd.FindElement(By.XPath("//*[@test-id='memberlookup-grid-ResultGrid']//table//tr//td//input[@type='checkbox']"));
                    fw.ExecuteJavascript(checkbox1);
                    break;
                case "Group Search Criteria":
                    checkbox1 = Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='grouplookup-grid-searchresult']//td/input)[1]"));
                    fw.ExecuteJavascript(checkbox1);
                    break;
                case "rxhcc search criteria":
                    checkbox1 = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='rxhcclookup-grid-ResultGrid']//td/input"));
                    checkbox1.Click();
                    break;
                case "HCC Search Criteria":
                    checkbox1 = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='hcclookup-grid-ResultGrid']//td[text()='" + valueToSearch +"']/preceding-sibling::td/input"));
                    checkbox1.Click();
                    break;


            }

            tmsWait.Hard(1);
        }


        [When(@"Group Search Criteria ""(.*)"" value is set to ""(.*)""")]
        public void WhenGroupSearchCriteriaValueIsSetTo(string p0, string p1)
        {
            fw.ExecuteJavascript(RSM.Lookups.GroupIDLookUp.GroupSearch);
            tmsWait.Hard(3);
        }


        [Then(@"Verify Group Search Criteria page displays Group ID ""(.*)"" Group Name ""(.*)""")]
        public void ThenVerifyGroupSearchCriteriaPageDisplaysGroupIDGroupName(string p0, string p1)
        {
            string gid = tmsCommon.GenerateData(p0);
            string gname = tmsCommon.GenerateData(p1);
            KendoUIFunctions.ResultGridTextValidation(gid);
            KendoUIFunctions.ResultGridTextValidation(gname);
        }

        [Then(@"Verify Member Search Criteria page displays MBI ID ""(.*)"" Name ""(.*)""")]
        public void ThenVerifyMemberSearchCriteriaPageDisplaysMBIIDName(string p0, string p1)
        {
            string gid = tmsCommon.GenerateData(p0);
            string gname = tmsCommon.GenerateData(p1);
            KendoUIFunctions.ResultGridTextValidation(gid);
            KendoUIFunctions.ResultGridTextValidation(gname);
        }


        [When(@"Verify CMS HCC Disease Group Prevelance Report page ""(.*)"" field is dispalyed with value ""(.*)""")]
        public void WhenVerifyCMSHCCDiseaseGroupPrevelanceReportPageFieldIsDispalyedWithValue(string p0, string p1)
        {
            string ExpectedlabelName = p0.ToString();
            string ExpectedlableValue = p1.ToString();
            string ActualLableName, ActualLableValue;
            SelectElement select;
            switch (ExpectedlabelName)
            {
                case "Plan ID":
                    ActualLableValue = RSM.CMSHCCDiseaseGroupPrevelance.PlanIDdefaultvalue.Text.ToString();
                    //Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    Assert.AreEqual(ExpectedlableValue, ActualLableValue, "Both values are getting matched");
                    break;
                case "PBP":
                    //ActualLableName = RSM.CMSHCCDiseaseGroupPrevelance.PBP.Text.ToString();
                    select = new SelectElement(RSM.CMSHCCDiseaseGroupPrevelance.PBP);
                    ActualLableValue = select.SelectedOption.Text;
                    //Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    Assert.AreEqual(ExpectedlableValue, ActualLableValue, "Both values are getting matched");
                    break;

                case "Payment Year":
                    tmsWait.Hard(2);
                    //ActualLableName = RSM.CMSHCCDiseaseGroupPrevelance.paymentYearLable.Text.ToString();
                    select = new SelectElement(RSM.CMSHCCDiseaseGroupPrevelance.paymentYearText);
                    ActualLableValue = select.SelectedOption.Text;
                    //Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    Assert.AreEqual(ExpectedlableValue, ActualLableValue, ActualLableValue + "values are getting dispalyed");
                    break;
                case "Year Type":
                    ActualLableName = RSM.CMSHCCDiseaseGroupPrevelance.yearTypeLable.Text.ToString();
                    select = new SelectElement(RSM.CMSHCCDiseaseGroupPrevelance.YearType);
                    ActualLableValue = select.SelectedOption.Text;
                    Assert.AreEqual(ExpectedlabelName, ActualLableName, "Both values are getting matched");
                    Assert.AreEqual(ExpectedlableValue, ActualLableValue, "Both values are getting matched");
                    break;

                case "SCC ID":
                    Assert.IsTrue(RSM.CMSHCCDiseaseGroupPrevelance.sscreportLink.Displayed, "icon link is displayed");
                    break;

                case "Group ID":
                    Assert.IsTrue(RSM.CMSHCCDiseaseGroupPrevelance.groupreportLink.Displayed, "icon link is displayed");
                    break;

                case "PCP ID":
                    Assert.IsTrue(RSM.CMSHCCDiseaseGroupPrevelance.pcpreportLink.Displayed, "icon link is displayed");
                    break;

            }
        }

        [When(@"Verify CMS HCC Disease Group Prevelance Report ""(.*)"" button is dispalyed")]
        public void WhenVerifyCMSHCCDiseaseGroupPrevelanceReportButtonIsDispalyed(string p0)
        {
            switch (p0.ToString().ToLower())
            {
                case "run report":
                    Assert.IsTrue(RSM.CMSHCCDiseaseGroupPrevelance.RunReport.Displayed, "Run Report button is not displayed on report page");
                    break;
                case "reset":
                    Assert.IsTrue(RSM.CMSHCCDiseaseGroupPrevelance.ResetReport.Displayed, "Run Report button is not displayed on report page");
                    break;
            }

        }


        [Then(@"Verify ""(.*)"" Result Panel displays Search results")]
        public void ThenVerifyLookupPageResultPanelDisplaysSearchResults(string p0, Table table)
        {
            tmsWait.Hard(5);
            string lookupname = p0.ToString();

            switch (lookupname)
            {
                case "GroupIDLookuppage":
                    TableValidation(table, RSM.Lookups.GroupIDLookUp.GroupLoookupGrid, RSM.Lookups.GroupIDLookUp.GroupSearchPagination);
                    break;
                case "PCPLookuppage":
                    TableValidation(table, RSM.Lookups.PCPLookUp.PCPLoookupGrid, RSM.Lookups.PCPLookUp.topFiftyPaging);
                    break;
                case "SSCLookuppage":
                    TableValidation(table, RSM.Lookups.SCCLookUp.sccLookupGird, RSM.Lookups.SCCLookUp.topFiftyPaging);
                    break;
                case "HICLookuppage":
                    TableValidation(table, RSM.Lookups.HICLookUp.hicLookupGird, RSM.Lookups.HICLookUp.topFiftyPaging);
                    break;
                case "Risk Score/Risk Adjustment Factor Type":
                    TableValidation(table, RSM.MemberHCCDetai.ResultSectionRiskScoreGrid, RSM.Lookups.HICLookUp.topFiftyPaging);
                    break;
                case "Demographic HCC's on File for Member":
                    TableValidation(table, RSM.MemberHCCDetai.ResultSectionDemographicGrid, RSM.Lookups.HICLookUp.topFiftyPaging);
                    break;
                case "RXHCCLookuppage":
                    TableValidation(table, RSM.Lookups.RXHCCLookUp.RXHCCLoookupGrid, RSM.Lookups.RXHCCLookUp.topFiftyPaging);
                    break;

            }
        }
        [Then(@"Verify number of rows displayed on ""(.*)"" page is ""(.*)""")]
        public void ThenVerifyNumberOfRowsDisplayedOnPageIs(string lookupPage, int expectedRows)
        {
            int rowCountApp = 0;
            switch (lookupPage.ToLower().Trim())
            {
                case "member search criteria":
                    rowCountApp = Browser.Wd.FindElements(By.XPath("//div[@id='memberLookupGird']//a[@title='Select']")).Count;
                    break;
            }
            if (expectedRows == rowCountApp) Console.WriteLine(" number of rows is matched with the application table");
            else Console.WriteLine(" number of rows is not matched with the application table");
        }
        public void TableValidation(Table table, IWebElement p1, IWebElement p2)
        {
            try
            {
                //Create Storage for the Gherkin table and the page data
                GherkinTable thisGT = new GherkinTable();
                TablePaging thisTP = new TablePaging();

                //Load the Gherkin table into the storage
                thisGT.LoadGherkinTable(table);
                int headercnt = table.Header.Count;
                //The big loop.  Keep working until all the Gherkin table rows are marked as matched
                //Or until we are on the last page of records, then we also quit looking.
                while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
                {
                    //Start out with the assumption we are not on the last page of records.  We will check later.
                    thisTP.bNotAtLastPageOfRecords = true;

                    //Get the table object again, since the page refreshes we need to get it fresh
                    IWebElement baseTable = p1;
                    IWebElement paginationSystem = p2;

                    thisTP.LoadRSMGrid(baseTable, headercnt, "ui-grid-row", "ui-grid-cell");

                    int iTableCounter = 0;
                    // string expectedTableCheckboxValue = "";
                    //for each row in the Gherkin table, start flipping through all the rows in the page data.
                    foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                    {
                        //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                        //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                        if (GherkinTableRow == null)
                        {
                            break;
                        }

                        //If this Gherkin table row is not yet matched, proceed.
                        if (GherkinTableRow.RowIsMatched == false)
                        {
                            //Convert the row to an array so we can do an element by element match.
                            string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                            //For each row in the page data
                            //App function chalu hotey
                            foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                            {
                                //Convert page data to array elements
                                //Only work with the loaded element rows.  The first unloaded one will be null.
                                if (ApplicationRow == null)
                                {
                                    break;
                                }

                                //Convert the page row to array so we can pair up by elements.
                                string[] AppTableRow = ApplicationRow.Row.ToArray();
                                int iElementCounter = 0;
                                Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                                //In here as we pair up the data you will have custom matching.
                                //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                                foreach (string appTD in AppTableRow)
                                {

                                    //if (iElementCounter > 0 && TDA.RowIsData)
                                    if (ApplicationRow.RowIsData)
                                    {
                                        //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                        if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                        {

                                            bThisRowMatches = false;
                                        }
                                        //if (iElementCounter == 5)
                                        //{
                                        //    expectedTableCheckboxValue = GherkinTableArray[5];
                                        //}
                                    }
                                    else
                                    {
                                        //Also fail row match if the element count of the page data row is 0
                                        if (iElementCounter > 0)
                                        {
                                            bThisRowMatches = false;
                                        }
                                    }
                                    iElementCounter++;
                                }

                                if (AppTableRow.Length == 0)
                                {
                                    //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                    bThisRowMatches = false;
                                }
                                //Instance of TableRow Class for reporting functions
                                var TableRow = new TMSString();
                                //If we get here and we still match, then the array elements were the same

                                if (bThisRowMatches)
                                {
                                    //report the success stuff.  Puts out the row data, etc.
                                    thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                                    break;
                                }
                                // break;
                            }
                        }
                        iTableCounter++;
                    }
                    //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                    Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);

                    if (fullMatching)
                    {
                        Console.WriteLine("All rows are matched, step completed as passed");
                    }
                    else
                    {
                        //Click next page link and start over.
                        if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                        {
                            thisTP.bNotAtLastPageOfRecords = true;
                            thisTP.NPL.Click();
                            tmsWait.Hard(2);
                        }
                    }
                    baseTable = p1;

                    //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                    //Time to boil it down and report which rows didn't get matched.
                    //Also to fail because we were planning to match the rows.
                    if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                    {
                        thisTP.ReportNotMatching(thisGT.GTable);
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Members View Edit Table has row: {0}", e.Message);
            }
        }

        [When(@"variable PCP ""(.*)"" is set to ""(.*)""")]
        public void WhenVariablePCPIsSetTo(string p0, string p1)
        {
            GeneratedUserID = tmsCommon.GenerateData(p1);
            fw.setVariable(p0, GeneratedUserID);
        }


        [When(@"Provider ID Number is set to ""(.*)""")]
        public void WhenNumberIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            RSM.Lookups.PCPLookUp.ProviderID.SendKeys(GeneratedData);
        }

        [Then(@"Verfiy ""(.*)"" get dispalyed on report home page")]
        public void ThenVerfiyGetDispalyedOnReportHomePage(string textToVerify)
        {
            string ExpectedResult = null;
            string[] valueArray = textToVerify.Split(',');
            for (int i = 0; i < valueArray.Length; i++)
            {
                if (valueArray[0].Contains("Generate"))
                    ExpectedResult = tmsCommon.GenerateData(textToVerify);
                ExpectedResult = tmsCommon.GenerateData(valueArray[i]);
                string xpathstr = "//tags-input[@test-id='hccDetails-txt-hicn']//ng-include/span";
                string actualresult = Browser.Wd.FindElement(By.XPath(xpathstr)).Text.ToString().Trim();
                Assert.IsTrue(actualresult.Contains(ExpectedResult), ExpectedResult, ExpectedResult + "is not dispalyed");

            }
            //    string ExpectedResult = tmsCommon.GenerateData(textToVerify);
            //string xpathstr = "//span[contains(.,'" + ExpectedResult + "')]";
            //string actualresult = Browser.Wd.FindElement(By.XPath(xpathstr)).Text.ToString().Trim();
            //Assert.IsTrue(actualresult.Equals(ExpectedResult), ExpectedResult, ExpectedResult + "is not dispalyed");
        }

        [When(@"Report page ""(.*)"" button is clicked")]
        public void WhenReportPageButtonIsClicked(string p0)
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(RSM.RiskScoreTrendDetails.RunReportButton);
            tmsWait.Hard(10);

            try
            {
                string reporttype = GlobalRef.winium.ToString();
                if (reporttype.Equals("Interactive"))
                {
                    ReUsableFunctions.reportAuthenticationHandler();
                }
            }

            catch
            {
                Console.WriteLine(" There is no Authentiction Dialog ");
            }

        }

        [When(@"Risk Score Trend Details page Run Report button is Clicked")]
        public void WhenRiskScoreTrendDetailsPageRunReportButtonIsClicked()
        {
            RSM.RiskScoreTrendDetails.RunReportButton.Click();
            tmsWait.Hard(5);

            tmsWait.Hard(10);


            try
            {
                string reporttype = GlobalRef.winium.ToString();
                if (reporttype.Equals("Interactive"))
                {
                    ReUsableFunctions.reportAuthenticationHandler();
                }
            }

            catch
            {
                Console.WriteLine(" There is no Authentiction Dialog ");
            }

        }

        [Then(@"Verify the Report page should get dispalyed ""(.*)""")]
        public void ThenVerifyTheReportPageShouldGetDispalyed(string values)
        {
            tmsWait.Hard(2);
            Browser.SwitchToChildWindow();
            string pagesounce = Browser.Wd.FindElement(By.TagName("body")).Text;
            string[] reportTxt = values.Split(',');

            foreach (string temp in reportTxt)
            {


                if (pagesounce.Contains(temp))
                {
                    Assert.IsTrue(true);
                }
                else
                {
                    Assert.Fail("Report title is incorrect...");
                }
            }

        }


        [Given(@"Tasks menu ""(.*)"" submenu is Clicked")]
        public void GivenTasksMenuSubmenuIsClicked(string p0)
        {
            IWebElement Tasks = Browser.Wd.FindElement(By.CssSelector("[title='Tasks']"));
            fw.ExecuteJavascript(Tasks);

            tmsWait.Hard(2);
            IWebElement menu = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Export')]"));
            fw.ExecuteJavascript(menu);
            GlobalRef.ReportName = menu.Text;
        }
        [Given(@"RAPS page ""(.*)"" is Clicked")]
        [When(@"RAPS page ""(.*)"" is Clicked")]
        public void GivenRAPSPageIsClicked(string p0)
        {
            tmsWait.Hard(2);
            IWebElement menu = Browser.Wd.FindElement(By.CssSelector("[test-id='exports-rd-icdfileLayout']"));
            fw.ExecuteJavascript(menu);
        }


        [Given(@"Export List RAPS link is clicked")]
        public void GivenExportListRAPSLinkIsClicked()
        {
            tmsWait.Hard(2);
            IWebElement menu = Browser.Wd.FindElement(By.CssSelector("[test-id='16']"));
            fw.ExecuteJavascript(menu);
        }
        [Given(@"RAPS page Export button is Clicked")]
        public void GivenRAPSPageExportButtonIsClicked()
        {
            tmsWait.Hard(2);
            IWebElement menu = Browser.Wd.FindElement(By.CssSelector("[test-id='export-btn-runReport']"));
            fw.ExecuteJavascript(menu);
        }

        [Given(@"RAPS page Clicked on ""(.*)"" link")]
        [When(@"RAPS page Clicked on ""(.*)"" link")]
        public void GivenRAPSPageClickedOnLink(string p0)
        {
            tmsWait.Hard(2);
            IWebElement menu = Browser.Wd.FindElement(By.LinkText(p0));
            fw.ExecuteJavascript(menu);
        }

        [Then(@"Verify Report page displayed ""(.*)"" field")]
        public void ThenVerifyReportPageDisplayedField(string p0)
        {
            tmsWait.Hard(2);
            IWebElement element = Browser.Wd.FindElement(By.CssSelector("[test-id='" + p0 + "']"));

            Assert.IsTrue(element.Displayed, p0 + " is not getting displayed");
        }

        [Then(@"Verify Administration page ""(.*)"" menu is displayed")]
        public void ThenVerifyAdministrationPageMenuIsDisplayed(string p0)
        {
            tmsWait.Hard(5);
            string elementStr = "[title='" + p0 + "']";
            bool elementPresence = Browser.Wd.FindElement(By.CssSelector(elementStr)).Displayed;
            Assert.IsTrue(elementPresence, p0 + " is not getting displayed");
        }

        [Then(@"Verify the Report page should get displayed with title ""(.*)""")]
        public void ThenVerifyTheReportPageShouldGetDisplayedWithTitle(string titleOfPage)
        {
            tmsWait.Hard(5);
            Browser.SwitchToChildWindow();
            tmsWait.Hard(5);
            string pagesource = Browser.Wd.Title;
            if (pagesource.Contains(titleOfPage))
            {
                Assert.IsTrue(true);
            }
            else
            {
                Assert.Fail("Report title is incorrect...");
            }
        }


        [Then(@"Verify the Report page should get dispalyed with title ""(.*)""")]
        public void ThenVerifyTheReportPageShouldGetDispalyedWithTitle(string titleOfPage)
        {
            tmsWait.Hard(6);
            Browser.SwitchToChildWindow();
            tmsWait.Hard(2);
            titleOfPage = tmsCommon.GenerateData(titleOfPage);
            //Browser.SwitchToIFrame();
            string pagesource = Browser.Wd.FindElement(By.TagName("body")).Text;
            tmsWait.Hard(5);

            if (pagesource.Contains(titleOfPage))
            {
                Assert.IsTrue(true);
            }
            else
            {
                Assert.Fail("Report title is incorrect...");
            }
        }

        [Then(@"Verify the report page search criteria ""(.*)"" should displayed as ""(.*)""")]
        public void ThenVerifyTheReportPageSearchCriteriaShouldDisplayedAs(string p0, string p1)
        {
            string LabelName = p0.ToString().ToLower();
            string ExpectedLabelValue = p1.ToString();
            string Value = null;
            string LabelValue = tmsCommon.GenerateData(ExpectedLabelValue);
            //xpath = ".//table[contains(@class,'_1_r10')]//tr[1]";
            //IList<IWebElement> thisOptionCollection = Browser.Wd.FindElements(By.XPath(xpath));
            switch (LabelName)
            {
                case "planid":
                    Value = "Plan ID: " + LabelValue + "";
                    ValidationOfReportPage(Value);
                    break;
                case "paymentyear":
                    Value = "Pay Year: " + LabelValue + "";
                    ValidationOfReportPage(Value);
                    break;
                case "yeartype":
                    Value = "Year Type: " + LabelValue + "";
                    ValidationOfReportPage(Value);
                    break;
                case "pbp":
                    Value = "PBP ID: " + LabelValue + "";
                    ValidationOfReportPage(Value);
                    break;
            }
        }

        [When(@"Report Page Control Number is set to ""(.*)""")]
        public void WhenReportPageControlNumberIsSetTo(string controlnum)
        {
            tmsWait.Hard(2);
            string p0 = tmsCommon.GenerateData(controlnum);
            Browser.Wd.FindElement(By.CssSelector("[test-id='ControlNum']")).SendKeys(p0);
        }

        [When(@"Report page Save Format option ""(.*)"" is selected")]
        [Then(@"Report page Save Format option ""(.*)"" is selected")]
        [Given(@"Report page Save Format option ""(.*)"" is selected")]
        public void WhenReportPageSaveFormatOptionIsSelected(string format)
        {
            //tmsWait.Hard(2);
            //IWebElement saveformat = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + format + "')]/parent::div/input"));
            //fw.ExecuteJavascript(saveformat);

            IWebElement test;
            switch (format.ToString().ToLower())
            {
                case "pdf":
                    test = Browser.Wd.FindElement(By.XPath(".//*[@id='3']"));
                    fw.ExecuteJavascript(test);
                    GlobalRef.AutoIT = "NonInteractive";
                    break;
                case "csv":
                    test = Browser.Wd.FindElement(By.XPath(".//*[@id='2']"));
                    fw.ExecuteJavascript(test);
                    GlobalRef.AutoIT = "NonInteractive";
                    break;
                case "xlsx":
                    test = Browser.Wd.FindElement(By.XPath(".//*[@id='4']"));
                    fw.ExecuteJavascript(test);
                    GlobalRef.AutoIT = "NonInteractive";
                    break;
            }
        }

        [Then(@"Verify FRM Report page ""(.*)"" is dispalyed")]
        public void ThenVerifyFRMReportPageIsDispalyed(string p0)
        {

            string expectedValue = p0.ToString();
            bool actualvalue = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Please check')]")).Displayed;
            Assert.IsTrue(actualvalue, expectedValue + " value are not getting displayed");
        }


        [Then(@"Verify the Report page ""(.*)"" is dispalyed")]
        public void ThenVerifyTheReportPageIsDispalyed(string p0)
        {

            //tmsWait.WaitForElement(By.XPath(".//*[@id='reportsBlock']//span[contains(.,'Please check')]"),30);
            tmsWait.WaitForElement(By.XPath(".//*[@id='mainContant']//span[contains(., 'Please check')]"), 30);
            string expectedValue = p0.ToString();
            string actualvalue = Browser.Wd.FindElement(By.XPath(".//*[@id='mainContant']//span[contains(., 'Please check')]")).Text.ToString();
            Assert.AreEqual(expectedValue, actualvalue, "Both value are not matching");
        }
        [When(@"Report page ""(.*)"" link is clicked")]
        public void WhenReportPageLinkIsClicked(string p0)
        {
            tmsWait.Hard(23);
            IWebElement test;
            if(ConfigFile.EnvType.Equals("ESI"))
            {
                 test = Browser.Wd.FindElement(By.LinkText("Job Processing Status page"));
            }
            else
            {
                try
                {
                    test = Browser.Wd.FindElement(By.XPath("//*[@id='fileStatusEnrollmentID']"));
                }
                catch
                {
                    test = Browser.Wd.FindElement(By.XPath("//*[@id='fileStatusEnrollmentID']"));
                }
            }
            fw.ExecuteJavascript(test);
            tmsWait.Hard(10);
        }

        [When(@"TMS Admin Output Folder path is set for ""(.*)"" and updated successfully")]
        public void WhenTMSAdminOutputFolderPathIsSetForAndUpdatedSuccessfully(string p0)
        {
            //Getting Output folder
            string[] url = ConfigFile.URL.Split('/');
            string[] surl = url[2].Split('.');
            string outputpath = @"\\" + surl[1] + @"\" + "TMSShareFolder" + @"\" + ConfigFile.FRMdb + @"\" + "Output";
            GlobalRef.OutputFolderPath = outputpath;
            IWebElement app = Browser.Wd.FindElement(By.XPath("//*[@id='DetailsView1']//td[contains(.,'" + ConfigFile.FRMdb + "')]/preceding-sibling::td//input[@type='image'][1]"));
            tmsWait.Hard(5);
            // Application is edited
            if (p0.ToString().Equals("FRM"))
            {
                fw.ExecuteJavascript(app);
            }

            //Output fodler path is set
            IWebElement output = Browser.Wd.FindElement(By.Id("OutputFolder"));
            output.Clear();
            output.SendKeys(outputpath);
            IWebElement pass = Browser.Wd.FindElement(By.Id("EditDatabasePasswordTextBox"));
            pass.SendKeys(ConfigFile.DBPassword);
            IWebElement update = Browser.Wd.FindElement(By.XPath("//input[@value='Update Database']"));
            update.Click();

            Browser.Wd.SwitchTo().Alert().Accept();
            tmsWait.Hard(5);

        }

        [Then(@"Verify ""(.*)"" file presence")]
        public void ThenVerifyFilePresence(string p0)
        {
            tmsWait.Hard(5);
            string[] url = ConfigFile.URL.Split('/');
            string[] surl = url[2].Split('.');
            string outputpath = @"\\" + surl[1] + @"\" + "TMSShareFolder" + @"\" + ConfigFile.FRMdb + @"\" + "Output";
            bool filepresence = false;
            var FolderPath = outputpath; 
            DirectoryInfo di = new DirectoryInfo(FolderPath);
            FileInfo[] TXTFiles = di.GetFiles("*.txt");
            if (TXTFiles.Length == 0)
            {
                Console.WriteLine("No File Exists");
                Assert.Fail("No File Exists");

            }

            foreach (var temp in TXTFiles)
            {
                if (temp.ToString().Contains(p0))
                {
                    filepresence = true;
                    break;
                }
            }
            Assert.IsTrue(filepresence, p0 + " extract file is not present on Output Folder");

        }

        [When(@"Framework page Filter By Job drop down list is set to ""(.*)""")]
        public void WhenFrameworkPageFilterByJobDropDownListIsSetTo(string value)
        {
            IWebElement FilterByJob = Browser.Wd.FindElement(By.CssSelector("[test-id='jobs-select-filteredbyjob']"));
            new SelectElement(FilterByJob).SelectByText(value);
            tmsWait.Hard(5);
        }

        [Then(@"Verify Framework page ""(.*)"" job status is set to ""(.*)""")]
        public void ThenVerifyFrameworkPageJobStatusIsSetTo(string job, string status)
        {

            string xpathString = "//div[@test-id='jobs-grid-grdJobsDetails']//td[contains(.,'" + job + "')]/following-sibling::td[1]/span";
            //div[@test-id='jobs-grid-grdJobsDetails']//td[contains(.,'Importing Cluster Deletes file')]/following-sibling::td[1]/span
            //  IWebElement jobStatus = Browser.Wd.FindElement(By.XPath("//div[@test-id='jobs-grid-grdJobsDetails']//td[contains(.,'"+ job + "')]/following-sibling::td[3]/span"));
            string currentJobStatus;

            string actualJobStatus = Browser.Wd.FindElement(By.XPath(xpathString)).Text.ToString();
            int ReturnStatus = StatusValidation(actualJobStatus);

            while (ReturnStatus != 0)
            {
                currentJobStatus = Browser.Wd.FindElement(By.XPath(xpathString)).Text.ToString();
                ReturnStatus = StatusValidation(currentJobStatus);
            }

        }


        [Then(@"Verify Framework page Generating Letters job status is set to ""(.*)""")]
        [Given(@"Verify Framework page Generating Letters job status is set to ""(.*)""")]
        [When(@"Verify Framework page Generating Letters job status is set to ""(.*)""")]
        public void ThenVerifyFrameworkPageGeneratingLettersJobStatusIsSetTo(string p0)
        {
            tmsWait.Implicit(20);
            IWebElement FilterByJob = Browser.Wd.FindElement(By.XPath("//*[@test-id='jobs-select-filteredbyjob']"));
            new SelectElement(FilterByJob).SelectByText("Generating Letters");
            tmsWait.Hard(2);

            string job = GlobalRef.JobID.ToString().Trim();
            fw.ConsoleReport("Expected Letter Generation Job ID -->" + job);
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(15);
            string xpathString = "//div[@test-id='jobs-grid-grdJobsDetails']//td[contains(.,'" + job + "')]/following-sibling::td[3]/span";
            //  IWebElement jobStatus = Browser.Wd.FindElement(By.XPath("//div[@test-id='jobs-grid-grdJobsDetails']//td[contains(.,'"+ job + "')]/following-sibling::td[3]/span"));
            string currentJobStatus;

            string actualJobStatus = Browser.Wd.FindElement(By.XPath(xpathString)).Text.ToString();
            int ReturnStatus = StatusValidation(actualJobStatus);

            while (ReturnStatus != 0)
            {
                currentJobStatus = Browser.Wd.FindElement(By.XPath(xpathString)).Text.ToString();
                ReturnStatus = StatusValidation(currentJobStatus);
            }
          
        }



        [When(@"Verify Framework Jobs page Letters status is set to ""(.*)""")]
        public void WhenVerifyFrameworkJobsPageLettersStatusIsSetTo(string p0)
        {
            IWebElement FilterByJob = Browser.Wd.FindElement(By.CssSelector("[test-id='jobs-select-filteredbyjob']"));
            new SelectElement(FilterByJob).SelectByText("Generating Letters");
            tmsWait.Hard(2);

            string job = GlobalRef.JobID.ToString().Trim();
            fw.ConsoleReport("Expected Letter Generation Job ID -->" + job);
            string xpathString = "//div[@test-id='jobs-grid-grdJobsDetails']//td[contains(.,'" + job + "')]/following-sibling::td[3]/span";

            string currentJobStatus;
            string actualJobStatus = Browser.Wd.FindElement(By.XPath(xpathString)).Text.ToString();
            int ReturnStatus = StatusValidation(actualJobStatus);

            while (ReturnStatus != 0)
            {
                currentJobStatus = Browser.Wd.FindElement(By.XPath(xpathString)).Text.ToString();
                ReturnStatus = StatusValidation(currentJobStatus);
                Browser.Wd.Navigate().Refresh();
                tmsWait.Hard(20);
                new SelectElement(FilterByJob).SelectByText("Generating Letters");
            }

        }

        [Then(@"Verify the File Processing Status page displayed ""(.*)"" status is ""(.*)""")]
        public void ThenVerifyTheFileProcessingStatusPageDisplayedStatusIs(string p0, string p1)
        {
            tmsWait.Hard(40);
            string actualStatus;
            tmsWait.Hard(5);
            string reportName = p0.ToString();
            string reportStatus = p1.ToString();

            string xpath = "//tr[contains(.,'" + reportName + "')]//parent::tr//td[2]";


            actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
            int ReturnStatus = StatusValidation(actualStatus);

            while (ReturnStatus != 0)
            {
                xpath = "//tr[contains(.,'" + reportName + "')]//parent::tr//td[2]";
                actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                ReturnStatus = StatusValidation(actualStatus);
            }
        }
        [When(@"RAMX ""(.*)"" File Processing Status is set to ""(.*)"" With Note ""(.*)""")]
        public void WhenRAMXFileProcessingStatusIsSetToWithNote(string p0, string p1, string p2)
        {
            tmsWait.Hard(40);
            string actualStatus;
            tmsWait.Hard(5);
            string reportName = p0.ToString();
            string reportStatus = p1.ToString();
            string Notes = p2.ToString();
            string xpath = "//tr[contains(.,'" + reportName + "')]//parent::tr//td[2]";


            actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
            int ReturnStatus = StatusValidation(actualStatus);

            while (ReturnStatus != 0)
            {
                xpath = "//tr[contains(.,'" + reportName + "')]//parent::tr//td[2]";
                actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                ReturnStatus = StatusValidation(actualStatus);
            }
            string xpath1 = "(//tr[contains(.,'N/A')]//parent::tr//td[5])[1]";
            actualStatus = Browser.Wd.FindElement(By.XPath(xpath1)).Text.ToString();
            Assert.IsTrue(actualStatus.Contains(Notes), Notes + "not displayed on  page");
        }

        string downloadPath = Path.Combine(Environment.ExpandEnvironmentVariables("%userprofile%"), "Downloads");
        [When(@"RAMX ""(.*)"" File Processing Status is set to ""(.*)"" Edge Server XML Format file is Clicked and Record count is noted")]
       
        
        [When(@"RAM ""(.*)"" File Processing Status is set to ""(.*)"" Edge Server XML Format file is Clicked and Record count is noted")]
        public void WhenRAMFileProcessingStatusIsSetToEdgeServerXMLFormatFileIsClickedAndRecordCountIsNoted(string p0, string p1)
        {
            //ReUsableFunctions.deleteFilesFromDownloadFolder();
            //tmsWait.Hard(5);
            //IWebElement file = Browser.Wd.FindElement(By.XPath("(//td[contains(.,'CMS Extract')]/preceding-sibling::td/a/p[contains(.,'Edge')])[1]"));
            //fw.ExecuteJavascript(file);
            //tmsWait.Hard(5);

            string path = GlobalRef.cmsextractPath.ToString();





            var newFilePaths = Directory.GetFiles(@"" + path + "", "*_*.xml");
           
            // Adding File Info details like Creation Time etc to sort by latest
            List<FileInfo> lst = new List<FileInfo>();
            foreach (var item in newFilePaths)
            {
                var srcFile = Path.Combine(path, item);
                lst.Add(new FileInfo(srcFile));
            }

            var latestFileName = lst.OrderByDescending(x => x.CreationTime).FirstOrDefault().FullName;


            var reader = new StreamReader(File.OpenRead(@"" + latestFileName + ""));

           
            int filecount = newFilePaths.Length;
            tmsWait.Hard(2);

            GlobalRef.EDGE_SERVER_XML_FILE = latestFileName;
        }

        [When(@"RAM ""(.*)"" File Processing Status is set to ""(.*)"" EData Format file is Clicked and Record count is noted")]
        public void WhenRAMFileProcessingStatusIsSetToEDataFormatFileIsClickedAndRecordCountIsNoted(string p0, string p1)
        {
            ReUsableFunctions.deleteFilesFromDownloadFolder();
            tmsWait.Hard(5);
            IWebElement file = Browser.Wd.FindElement(By.XPath("(//td[contains(.,'CMS Extract')]/preceding-sibling::td/a/p[contains(.,'EData')])[1]"));
            fw.ExecuteJavascript(file);
            tmsWait.Hard(5);

            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
            GlobalRef.EDATA_FORMAT_FILE = newFilePaths.ToString();
            int filecount = newFilePaths.Length;
            tmsWait.Hard(2);
            var srcFile = Path.Combine(downloadPath, newFilePaths[filecount - 1]);
            GlobalRef.NUMRECORD = File.ReadAllLines(srcFile).Length.ToString();
            fw.ConsoleReport("Total Number of EData Format file Processed Records " + File.ReadAllLines(srcFile).Length.ToString());
        }


        [When(@"RAM ""(.*)"" File Processing Status is set to ""(.*)"" RAPS file is Clicked and Record count is noted")]
        public void WhenRAMFileProcessingStatusIsSetToRAPSFileIsClickedAndRecordCountIsNoted(string p0, string p1)
        {
            ReUsableFunctions.deleteFilesFromDownloadFolder();
            tmsWait.Hard(5);
            IWebElement file = Browser.Wd.FindElement(By.XPath("(//td[contains(.,'CMS Extract')]/preceding-sibling::td/a/p[contains(.,'raps')])[1]"));
            fw.ExecuteJavascript(file);
            tmsWait.Hard(5);

            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
            int filecount = newFilePaths.Length;
            tmsWait.Hard(2);
            var srcFile = Path.Combine(downloadPath, newFilePaths[filecount - 1]);
            GlobalRef.NUMRECORD = File.ReadAllLines(srcFile).Length.ToString();
            fw.ConsoleReport("Total Number of Processed Records " + File.ReadAllLines(srcFile).Length.ToString());
        }

        [When(@"RAM ""(.*)"" File Processing Status is set to ""(.*)"" record is Clicked and Record count is noted")]
        public void WhenRAMFileProcessingStatusIsSetToRecordIsClickedAndRecordCountIsNoted(string p0, string p1)
        {
            ReUsableFunctions.deleteFilesFromDownloadFolder();
            tmsWait.Hard(2);
            IWebElement file = Browser.Wd.FindElement(By.XPath("(//kendo-grid-list[@role='presentation']//td//a[@class='cursorLink text-secondary'])[1]"));
            fw.ExecuteJavascript(file);
            tmsWait.Hard(2);

            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
            int filecount = newFilePaths.Length;
            tmsWait.Hard(2);
            var srcFile = Path.Combine(downloadPath, newFilePaths[filecount - 1]);
            GlobalRef.NUMRECORD = File.ReadAllLines(srcFile).Length.ToString();
            fw.ConsoleReport("Total Number of Processed Records " + File.ReadAllLines(srcFile).Length.ToString());

            string CMSFile = Browser.Wd.FindElement(By.XPath("(//kendo-grid-list[@role='presentation']//td//a[@class='cursorLink text-secondary'])[1]")).Text;
            GlobalRef.CMSFILEID = (CMSFile.Split('_'))[0];
        }

        [Then(@"Verify RAMX Edge Server XML file displayed Diagnosis Code ""(.*)"" on XML ""(.*)""")]
        public void ThenVerifyRAMXEdgeServerXMLFileDisplayedDiagnosisCodeOnXML(string p0, string p1)
        {
            string expDiagnosisCode = tmsCommon.GenerateData(p0);
            string xpath = p1;
            string XMLFile = GlobalRef.EDGE_SERVER_XML_FILE.ToString();
            //var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.xml");
            //int filecount = newFilePaths.Length;
            var srcFile = Path.Combine(downloadPath, XMLFile);
          
            var document = new XmlDocument();
            document.Load(srcFile);
            var nsmgr = new XmlNamespaceManager(document.NameTable);
            nsmgr.AddNamespace("ns1", "http://vo.edge.fm.cms.hhs.gov");
           
            XmlNodeList nl = document.SelectNodes(xpath, nsmgr);

            foreach (XmlElement ele in nl)
            {
                string actDiagnosisCode = ele.InnerText;
                Assert.AreEqual(expDiagnosisCode, actDiagnosisCode, " Both were not matching");
                fw.ConsoleReport(" Actual Dia code -->" + actDiagnosisCode);
                break;
                
            }

        }

        [Then(@"Verify RAMX Edge Server XML file displayed new Diagnosis Code ""(.*)"" on XML ""(.*)""")]
public void ThenVerifyRAMXEdgeServerXMLFileDisplayedNewDiagnosisCodeOnXML(string p0, string p1)
{
            string expDiagnosisCode = tmsCommon.GenerateData(p0);
            string xpath = p1;
            string XMLFile = GlobalRef.EDGE_SERVER_XML_FILE.ToString();
            //var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.xml");
            //int filecount = newFilePaths.Length;
            var srcFile = Path.Combine(downloadPath, XMLFile);

            var document = new XmlDocument();
            document.Load(srcFile);
            var nsmgr = new XmlNamespaceManager(document.NameTable);
            nsmgr.AddNamespace("ns1", "http://vo.edge.fm.cms.hhs.gov");

            XmlNodeList nl = document.SelectNodes(xpath, nsmgr);

            Boolean flag = false;
            foreach (XmlElement ele in nl)
            {
                string actDiagnosisCode = ele.InnerText;
                if (expDiagnosisCode.Equals(actDiagnosisCode))
                {
                    flag = true;
                    break;

                }
                fw.ConsoleReport(" Actual Dia code -->" + actDiagnosisCode);

            }
            Assert.IsTrue(flag, " Both were not matching");
        }


        [Then(@"Verify RAM ""(.*)"" extracted File displayed ""(.*)""")]
        public void ThenVerifyRAMExtractedFileDisplayed(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p1);
            string planID = GlobalRef.PlanID.ToString();
            string memberID = GlobalRef.MEMID.ToString();
            string diagnosisCode = GlobalRef.DIAGCODE.ToString();

            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
            int filecount = newFilePaths.Length;
            var srcFile = Path.Combine(downloadPath, newFilePaths[filecount - 1]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            while (!reader.EndOfStream)
            {

                var line = reader.ReadLine();

                if (field.Equals("Plan ID"))
                {
                    if (line.Contains(planID))
                    {
                        Assert.IsTrue(true, "Expected Value is not displayed");
                        fw.ConsoleReport("Plan ID is found "+ planID);
                        break;
                    }
                }
                if (field.Equals("Member ID"))
                {
                    if (line.Contains(memberID))
                    {
                        Assert.IsTrue(true, "Expected Value is not displayed");
                        fw.ConsoleReport("Member ID is found " + memberID);
                        break;
                    }
                }
                if (field.Equals("Diagnosis Code"))
                {
                    if (line.Contains(diagnosisCode))
                    {
                        Assert.IsTrue(true, "Expected Value is not displayed");
                        fw.ConsoleReport("Diagnosis Code is found " + diagnosisCode);
                        break;
                    }
                }

            }
            reader.Close();


        }

        [Then(@"RAMX File Processing page Audit History File is Clicked and Downloaded")]
        public void ThenRAMXFileProcessingPageAuditHistoryFileIsClickedAndDownloaded()
        {

            ReUsableFunctions.deleteFilesFromDownloadFolder();

            By loc = By.XPath("(//div[@test-id='file-grid-fileProcessStatusGrid']//td[contains(.,'Audit_History_RAMX_')]/a)[1]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            tmsWait.Hard(3);
        }

        [Then(@"Verify RAM Application page ""(.*)"" File Processing Status is set to ""(.*)""")]
        public void ThenVerifyRAMApplicationPageFileProcessingStatusIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(48);
            string actualStatus;
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(28);
            string exportType = p0.ToString();
            string exportStatus = p1.ToString();
            //  tmsWait.WaitForElement(By.XPath("(//tr[contains(.,'Member HCC Extract')]//parent::tr//td[2]/span)[1]"));
            string xpath = "(//tr[contains(.,'"+p0+"')]//parent::tr//td[2]/span)[1]";
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(25);
            actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
            fw.ConsoleReport(" Current Status  --> " + actualStatus);
            int ReturnStatus = StatusValidation(actualStatus);
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(25);
            // Do not comment this code, as File processing will take much time depends of environment
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(25);
            ReturnStatus = StatusValidation(actualStatus);

            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(25);
            ReturnStatus = StatusValidation(actualStatus);

            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(25);
            ReturnStatus = StatusValidation(actualStatus);

            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(20);
            Browser.Wd.Navigate().Refresh();
            ReturnStatus = StatusValidation(actualStatus);
            Browser.Wd.Navigate().Refresh();
            while (ReturnStatus != 0)
            {

                Browser.Wd.Navigate().Refresh();
                tmsWait.Hard(25);
                xpath = "(//tr[contains(.,'" + exportType + "')]//parent::tr//td[2]/span)[1]";
                try
                {
                    actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                }
                catch
                {
                    tmsWait.Hard(4);
                    IWebElement ram = Browser.Wd.FindElement(By.CssSelector("[test-id='menu-ddl-applicationNavigationRAMIcon1']"));
                    fw.ExecuteJavascript(ram);

                    tmsWait.Hard(4);
                    IWebElement xpath1 = Browser.Wd.FindElement(By.LinkText("File Processing Status page"));
                    fw.ExecuteJavascript(xpath1);
                    tmsWait.Hard(6);
                    actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                }
                fw.ConsoleReport(" Current Status  --> " + actualStatus);
                ReturnStatus = StatusValidation(actualStatus);
                Browser.Wd.Navigate().Refresh();
            }


            Assert.AreEqual(actualStatus, exportStatus, " Both status were not matching");

        }


        [Then(@"Verify RAM Application ""(.*)"" File Processing Status is set to ""(.*)""")]
        public void ThenVerifyRAMApplicationFileProcessingStatusIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(48);
            string actualStatus;
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(28);
            string exportType = p0.ToString();
            string exportStatus = p1.ToString();
          //  tmsWait.WaitForElement(By.XPath("(//tr[contains(.,'Member HCC Extract')]//parent::tr//td[2]/span)[1]"));
            string xpath = "(//tr[contains(.,'Member HCC Extract')]//parent::tr//td[4])[1]";
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(5);
            actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
            fw.ConsoleReport(" Current Status  --> " + actualStatus);
            int ReturnStatus = StatusValidation(actualStatus);
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(5);
            // Do not comment this code, as File processing will take much time depends of environment
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(25);
            ReturnStatus = StatusValidation(actualStatus);

            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(25);
            ReturnStatus = StatusValidation(actualStatus);

            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(25);
            ReturnStatus = StatusValidation(actualStatus);

            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(20);
            Browser.Wd.Navigate().Refresh();
            ReturnStatus = StatusValidation(actualStatus);
            Browser.Wd.Navigate().Refresh();
            while (ReturnStatus != 0)
            {

                Browser.Wd.Navigate().Refresh();
                tmsWait.Hard(25);
                xpath = "(//tr[contains(.,'" + exportType + "')]//parent::tr//td[4][1]";
                try
                {
                    actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                }
                catch
                {
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//a[@test-id='header-btn-expanMenu'])[2]")));
                    tmsWait.Hard(4);
                    IWebElement ram = Browser.Wd.FindElement(By.CssSelector("[test-id='menu-ddl-applicationNavigationRAMIcon1']"));
                    fw.ExecuteJavascript(ram);

                    tmsWait.Hard(4);
                    IWebElement xpath1 = Browser.Wd.FindElement(By.CssSelector("[title='Job Processing Status']"));
                    fw.ExecuteJavascript(xpath1);
                    tmsWait.Hard(6);
                    actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                }
                fw.ConsoleReport(" Current Status  --> " + actualStatus);
                ReturnStatus = StatusValidation(actualStatus);
                Browser.Wd.Navigate().Refresh();
            }

            if (exportType != "CIS File Upload Job for RAMX")
            {
                xpath = "(//tr[contains(.,'" + exportType + "')]//parent::tr//td[3])[1]";
                string fileName = Browser.Wd.FindElement(By.XPath(xpath)).Text;
                GlobalRef.FileName = fileName;
            }

            By ExpandBtn = By.XPath("(//tr[contains(.,'" + exportType + "')]//a[@title='Expand Details'])[1]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(ExpandBtn); /*Expand row just in case following function needs to read notes*/
        }

        [When(@"CDM Job Processing page displayed ""(.*)"" job Status ""(.*)""")]
        public void WhenCDMJobProcessingPageDisplayedJobStatus(string p0, string p1)
        {
            tmsWait.Hard(48);
            string actualStatus;
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(28);
            
            string jobName = p0.ToString();
            string exportStatus = p1.ToString();
           
            string xpath = "(//kendo-grid[@test-id='file-grid-fileProcessStatusGrid']//td[contains(.,'"+ jobName + "')]/preceding-sibling::td[2]//div)[1]";
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(5);
            actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
            int ReturnStatus = StatusValidation(actualStatus);
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(5);
            // Do not comment this code, as File processing will take much time depends of environment
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(25);
            ReturnStatus = StatusValidation(actualStatus);

            while (ReturnStatus != 0)
            {

                Browser.Wd.Navigate().Refresh();
                tmsWait.Hard(25);
                xpath = "(//kendo-grid[@test-id='file-grid-fileProcessStatusGrid']//td[contains(.,'"+ jobName + "')]/preceding-sibling::td[2]//div)[1]";
                actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                ReturnStatus = StatusValidation(actualStatus);
                Browser.Wd.Navigate().Refresh();
            }


        }


        //Gurdeep Arora
        [Then(@"Verify RAM ""(.*)"" File with filename as ""(.*)"" Processing Status is set to ""(.*)""")]
        public void ThenVerifyRAMFileWithFilenameAsProcessingStatusIsSetTo(string p0, string p1, string p2)
        {
            tmsWait.Hard(48);
            string actualStatus;
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(28);
            string exportType = p0.ToString();
            string fileName = p1.ToString();
            string exportStatus = p2.ToString();
            tmsWait.WaitForElement(By.XPath("(//td[contains(.,'" + exportType + "')]/following::td[@aria-colindex='4'])[1]"));
            string xpath = "(//td[contains(.,'" + exportType + "')]/following::td[@aria-colindex='4'])[1]";
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(5);
            actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
            int ReturnStatus = StatusValidation(actualStatus);
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(5);
            // Do not comment this code, as File processing will take much time depends of environment
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(25);
            ReturnStatus = StatusValidation(actualStatus);

            while (ReturnStatus != 0)
            {

                Browser.Wd.Navigate().Refresh();
                tmsWait.Hard(25);
                xpath = "(//td[contains(.,'" + exportType + "')]/following::td[@aria-colindex='4'])[1]";
                actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                ReturnStatus = StatusValidation(actualStatus);
                Browser.Wd.Navigate().Refresh();
            }

           
        }

        [Then(@"Verify RAM Job Processing page Information icon is clicked for ""(.*)""")]
        public void ThenVerifyRAMJobProcessingPageInformationIconIsClickedFor(string p0)
        {
        
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='jobProcessingStatus-grid-jobs']//td[contains(.,'"+ p0 +"')]/following-sibling::td//a[@title='More'])[1]")));
            tmsWait.Hard(2);
        }


        [Then(@"Verify RAM Job Processing page Information icon ""(.*)"" is displayed")]
        public void ThenVerifyRAMJobProcessingPageInformationIconIsDisplayed(string p0)
        {
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]")).Displayed,"Expected Element is not displayed");
        }


        [When(@"RAM Job Processing page Information icon Back to Record link is clicked")]
        public void WhenRAMJobProcessingPageInformationIconBackToRecordLinkIsClicked()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@test-id='jobDetails-span-back']")));
            tmsWait.Hard(2);
        }



        [Then(@"Verify RAM ""(.*)"" File Processing Status is set to ""(.*)""")]
        public void ThenVerifyRAMFileProcessingStatusIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(48);
            string actualStatus="";
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(28);
            string exportType = p0.ToString();
            string exportStatus = p1.ToString();
            try
            {
                tmsWait.WaitForElement(By.XPath("(//tr[contains(.,'" + exportType + "')]//parent::tr//td[4])[1]"));
                string xpath = "(//tr[contains(.,'" + exportType + "')]//parent::tr//td[4][1]";
                Browser.Wd.Navigate().Refresh();
                tmsWait.Hard(5);
                actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                int ReturnStatus = StatusValidation(actualStatus);
                Browser.Wd.Navigate().Refresh();
                tmsWait.Hard(5);
                // Do not comment this code, as File processing will take much time depends of environment
                Browser.Wd.Navigate().Refresh();
                tmsWait.Hard(25);
                ReturnStatus = StatusValidation(actualStatus);

                Browser.Wd.Navigate().Refresh();
                tmsWait.Hard(25);
                ReturnStatus = StatusValidation(actualStatus);

                Browser.Wd.Navigate().Refresh();
                tmsWait.Hard(25);
                ReturnStatus = StatusValidation(actualStatus);

                //Praneeth -- We do not need to refresh the page so many times 

                //Browser.Wd.Navigate().Refresh();
                //tmsWait.Hard(20);
                //Browser.Wd.Navigate().Refresh();
                //ReturnStatus = StatusValidation(actualStatus);
                //Browser.Wd.Navigate().Refresh();
                while (ReturnStatus != 0)
                {

                    Browser.Wd.Navigate().Refresh();
                    tmsWait.Hard(25);
                    xpath = "(//tr[contains(.,'" + exportType + "')]//parent::tr//td[4])[1]";
                    actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                    ReturnStatus = StatusValidation(actualStatus);
                    Browser.Wd.Navigate().Refresh();
                }

                if (exportType != "CIS File Upload Job for RAMX")
                {
                    tmsWait.Hard(10);
                    xpath = "(//tr[contains(.,'" + exportType + "')]//parent::tr//td[3])[1]";
                    string fileName = Browser.Wd.FindElement(By.XPath(xpath)).Text;
                    GlobalRef.FileName = fileName;
                }
            }
            catch
            {
                var imports="";
                fw.ConsoleReport("------------------>This is new Job Processing page <---------------------------------");

                if (exportStatus.Contains("Complete"))
                {
                    exportStatus = "Success";
                }

                if(exportType.Equals("Client Identified Suspects"))
                {
                    imports = "Cis File";
                }
                // Select Job Type
                //IWebElement jobType = Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlJobName_listbox']"));
               
                //    string idAttribute = jobType.GetAttribute("aria-owns");
                //    IWebElement drpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='" + idAttribute + "']/li[contains(., '" + imports + "')]"));

                //    tmsWait.Hard(1);
                //    fw.ExecuteJavascript(drpValue);

                By Drp = By.XPath("//kendo-dropdownlist[@test-id='jobProcessingStatus-txt-ddlJobName']//span[@class='k-select']");

                if (exportType.Equals("CMS Extract") || exportType.Equals("PIR Mail Extract") || exportType.Equals("Member HCC Extract") || exportType.Equals("Suspect By Coder Extract") || exportType.Equals("PIR Extract") || exportType.Equals("PIR Extract By Control Number"))
                {
                    By typeapp = By.XPath("//li[text()='Ram Exports']");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                }
                else if (exportType.Equals("PIR Response File") ) 
                {
                    By typeapp = By.XPath("//li[text()='PIR Response File']");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                }
                else if (exportType.Equals("Client Identified Suspects"))
                {
                    By typeapp = By.XPath("//li[text()='Client Identified Suspects File']");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                }

                else if ((exportType.Equals("CMS File Detail Report")) || (exportType.Equals("CMS File Extract Summary")))
                {
                    By typeapp = By.XPath("//li[text()='Ram Reports']");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                }

                else if ((exportType.Equals("PE Project Extract Job")))
                {
                    By typeapp = By.XPath("//li[text()='PE Project Extract Job']");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                }

                By SearchBtn = By.CssSelector("[test-id='jobProcessingStatus-button-search']");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(SearchBtn);

                string xpath = "(//tr[contains(.,'" + exportType + "')]//td[4])[1]";


                try
                {

                    actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                    fw.ConsoleReport(" Initial Job Processing status" + actualStatus);
                }
                catch
                {

                }
                int ReturnStatus = StatusValidation(actualStatus);

                while (ReturnStatus != 0)
                {

                    fw.ExecuteJavascript(Browser.Wd.FindElement(SearchBtn));

                    tmsWait.Hard(7); // We put this wait intentionally as File processing is taking time for ESI
                    actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                    fw.ConsoleReport(" Current Job Processing status --> " + actualStatus);
                    ReturnStatus = StatusValidation(actualStatus);
                }


                Assert.AreEqual(exportStatus, actualStatus, " Both are not matching");
            }

            By ExpandBtn = By.XPath("(//tr[contains(.,'" + exportType + "')]//a[@title='Expand Details'])[1]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(ExpandBtn); /*Expand row just in case following function needs to read notes*/

        }

        [Then(@"Verify RAMX ""(.*)"" File Processing Status is set to ""(.*)""")]
        [When(@"Verify RAMX ""(.*)"" File Processing Status is set to ""(.*)""")]
        [Given(@"Verify RAMX ""(.*)"" File Processing Status is set to ""(.*)""")]
        public void ThenVerifyRAMXFileProcessingStatusIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(48);
            string actualStatus = "";
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(28);
            string exportType = p0.ToString();
            string exportStatus = p1.ToString();
            try
            {
                tmsWait.WaitForElement(By.XPath("(//tr[contains(.,'" + exportType + "')]//parent::tr//td[4])[1]"));
                string xpath = "(//tr[contains(.,'" + exportType + "')]//parent::tr//td[4][1]";
                Browser.Wd.Navigate().Refresh();
                tmsWait.Hard(5);
                actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                int ReturnStatus = StatusValidation(actualStatus);
                Browser.Wd.Navigate().Refresh();
                tmsWait.Hard(5);
                // Do not comment this code, as File processing will take much time depends of environment
                Browser.Wd.Navigate().Refresh();
                tmsWait.Hard(25);
                ReturnStatus = StatusValidation(actualStatus);

                Browser.Wd.Navigate().Refresh();
                tmsWait.Hard(25);
                ReturnStatus = StatusValidation(actualStatus);

                Browser.Wd.Navigate().Refresh();
                tmsWait.Hard(25);
                ReturnStatus = StatusValidation(actualStatus);

                //Praneeth -- We do not need to refresh the page so many times 

                //Browser.Wd.Navigate().Refresh();
                //tmsWait.Hard(20);
                //Browser.Wd.Navigate().Refresh();
                //ReturnStatus = StatusValidation(actualStatus);
                //Browser.Wd.Navigate().Refresh();
                while (ReturnStatus != 0)
                {

                    Browser.Wd.Navigate().Refresh();
                    tmsWait.Hard(25);
                    xpath = "(//tr[contains(.,'" + exportType + "')]//parent::tr//td[4])[1]";
                    actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                    ReturnStatus = StatusValidation(actualStatus);
                    Browser.Wd.Navigate().Refresh();
                }

                if (exportType != "CIS File Upload Job for RAMX")
                {
                    tmsWait.Hard(10);
                    xpath = "(//tr[contains(.,'" + exportType + "')]//parent::tr//td[3])[1]";
                    string fileName = Browser.Wd.FindElement(By.XPath(xpath)).Text;
                    GlobalRef.FileName = fileName;
                }
            }
            catch
            {
                var imports = "";
                fw.ConsoleReport("------------------>This is new Job Processing page <---------------------------------");

                if (exportStatus.Contains("Complete"))
                {
                    exportStatus = "Success";
                }

                if (exportType.Equals("Client Identified Suspects"))
                {
                    imports = "Cis File";
                }
                // Select Job Type
                //IWebElement jobType = Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlJobName_listbox']"));

                //    string idAttribute = jobType.GetAttribute("aria-owns");
                //    IWebElement drpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='" + idAttribute + "']/li[contains(., '" + imports + "')]"));

                //    tmsWait.Hard(1);
                //    fw.ExecuteJavascript(drpValue);

                By Drp = By.XPath("//kendo-dropdownlist[@test-id='jobProcessingStatus-txt-ddlJobName']//span[@class='k-select']");

                if (exportType.Equals("CMS Extract") || exportType.Equals("PIR Mail Extract") || exportType.Equals("Member HCC Extract") || exportType.Equals("Suspect By Coder Extract") || exportType.Equals("PIR Extract") || exportType.Equals("PIR Extract By Control Number"))
                {
                    By typeapp = By.XPath("//li[text()='Ramx Exports']");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                }
                else if (exportType.Equals("PIR Response File"))
                {
                    By typeapp = By.XPath("//li[text()='PIR Response File']");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                }
                else if (exportType.Equals("Client Identified Suspects"))
                {
                    By typeapp = By.XPath("//li[text()='Client Identified Suspects File']");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                }

                else if ((exportType.Equals("CMS File Detail Report")) || (exportType.Equals("CMS File Extract Summary")))
                {
                    By typeapp = By.XPath("//li[text()='Ramx Reports']");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                }

                By SearchBtn = By.CssSelector("[test-id='jobProcessingStatus-button-search']");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(SearchBtn);

                string xpath = "(//tr[contains(.,'" + exportType + "')]//td[4])[1]";


                try
                {

                    actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                    fw.ConsoleReport(" Initial Job Processing status" + actualStatus);
                }
                catch
                {

                }
                int ReturnStatus = StatusValidation(actualStatus);

                while (ReturnStatus != 0)
                {

                    fw.ExecuteJavascript(Browser.Wd.FindElement(SearchBtn));

                    tmsWait.Hard(7); // We put this wait intentionally as File processing is taking time for ESI
                    actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                    fw.ConsoleReport(" Current Job Processing status --> " + actualStatus);
                    ReturnStatus = StatusValidation(actualStatus);
                }


                Assert.AreEqual(exportStatus, actualStatus, " Both are not matching");
            }

            By ExpandBtn = By.XPath("(//tr[contains(.,'" + exportType + "')]//a[@title='Expand Details'])[1]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(ExpandBtn); /*Expand row just in case following function needs to read notes*/

        }

        //Gurdeep Arora
        [Then(@"Verify RAMX ""(.*)"" File Processing Status is ""(.*)"" with FileName as ""(.*)"" and Notes as ""(.*)""")]
        public void ThenVerifyRAMXFileProcessingStatusIsWithFileNameAsAndNotesAs(string p0, string p1, string p2, string p3)
        {
            tmsWait.Hard(48);
            string actualStatus;
            string expFileName = tmsCommon.GenerateData(p2);
            string expNotesText = tmsCommon.GenerateData(p3);
            tmsWait.Hard(8);
            string exportType = p0.ToString();
            string exportStatus = p1.ToString();
           // tmsWait.WaitForElement(By.XPath("(//tr[contains(.,'" + exportType + "')]//parent::tr//td[2]/span)[1]"));
            string xpath = "(//td[contains(.,'" + exportType + "')]/following-sibling::td)[1]";

            actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(20);
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(15);
            //Browser.Wd.Navigate().Refresh();
            //tmsWait.Hard(20);
            int ReturnStatus = StatusValidation(actualStatus);
            while (ReturnStatus != 0)
            {
                Browser.Wd.Navigate().Refresh();
                tmsWait.Hard(20);
                xpath = "(//tr[contains(.,'" + exportType + "')]//parent::tr//td[2]/span)[1]";
                actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                ReturnStatus = StatusValidation(actualStatus);
            }
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//a[@title='Expand Details'])[1]")));
            string fileName = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='jobProcessingStatus-grid-grdJobRequestInfo']//td[contains(.,'Success')]/preceding-sibling::td//p")).Text;
            Assert.AreEqual(expFileName, fileName, "File Name is not as expected");
            string notesText = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='jobProcessingStatus-grid-grdJobRequestInfo']//td[contains(.,'Success')]//following-sibling::td//p")).Text;
            Assert.AreEqual(expNotesText, notesText, "Notes text is not expected");
            GlobalRef.FileName = fileName;
        }


        [When(@"verify job details on the pop up page")]
        public void WhenVerifyJobDetailsOnThePopUpPage()
        {
            tmsWait.Hard(2);
            
            //IWebElement ReqId = Browser.Wd.FindElement(By.XPath("//div[@class='modal-body']//label[contains(.,'" + expReqID + "')]"));
            IWebElement ReqId = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='jobs-grid-jobParameters']//td[contains(.,'RequestId')]"));
            Assert.IsTrue(ReqId.Displayed, "Request ID is not showing as expected");

            //IWebElement startDate = Browser.Wd.FindElement(By.XPath("//div[@class='modal-body']//span[contains(.,'Start Date')]"));
            //IWebElement startDate = Browser.Wd.FindElement(By.XPath("//form[@class='ng-untouched ng-pristine ng-valid ng-tns-c35-1 ng-star-inserted']//span[contains(.,'Start Date')]"));
            //Assert.IsTrue(startDate.Displayed, "Start Date is not showing as expected");

            //IWebElement endDate = Browser.Wd.FindElement(By.XPath("//form[@class='ng-untouched ng-pristine ng-valid ng-tns-c35-1 ng-star-inserted']//span[contains(.,'End Date')]"));
            //Assert.IsTrue(endDate.Displayed, "End Date is not showing as expected");

            tmsWait.Hard(2);
            IWebElement jobReportsLink = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Job Reports')]/preceding-sibling::i"));
            jobReportsLink.Click();
            tmsWait.Hard(2);
            string[] jobReportsColumns = new string[] { "TimeStamp", "Type", "Text" };
            foreach (string column in jobReportsColumns)
            {
                IWebElement gridElement = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='JobReports-grid-grdjobreports']//th[contains(.,'" + column + "')]"));
                Assert.IsTrue(gridElement.Displayed, "Column Name : " + column + " is not displayed in file processing grid ");
            }

            tmsWait.Hard(2);
            //IWebElement jobDetailsLink = Browser.Wd.FindElement(By.XPath("//*[@id='jobDetailsBlock']/div[1]/i[2]"));
            //jobDetailsLink.Click();
            tmsWait.Hard(2);
            string[] jobDetailscolumns = new string[] { "Name", "Value" };
            foreach (string column in jobDetailscolumns)
            {
                IWebElement gridElement = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='jobParameters-grid-jobparameterslist']//th[contains(.,'" + column + "')]"));
                Assert.IsTrue(gridElement.Displayed, "Column Name : " + column + " is not displayed in file processing grid ");
            }
            tmsWait.Hard(2);
            IWebElement ApplicationParametersLink = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Application Parameters')]/preceding-sibling::i"));
            ApplicationParametersLink.Click();
            tmsWait.Hard(2);
            string[] AppParamsColumns = new string[] { "Name", "Value" };
            foreach (string column in AppParamsColumns)
            {
                IWebElement gridElement = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='applicationParameters-grid-applicationParameterslist']//th[contains(.,'" + column + "')]"));
                Assert.IsTrue(gridElement.Displayed, "Column Name : " + column + " is not displayed in file processing grid ");
            }

            //click on "Back To Jobs" link
            Browser.Wd.FindElement(By.XPath("//span[@test-id='jobDetails-span-back']")).Click();
            tmsWait.Hard(1);
           // IWebElement pagination = Browser.Wd.FindElement(By.XPath("//*[@id='fileProcessStatusGrid']/div[@data-role='pager']"));

            //Click on Pagination buttons
            string pageNum;
            IWebElement ele = Browser.Wd.FindElement(By.XPath("(//input[@role='spinbutton'])[3]"));
            string totalPages = ele.GetAttribute("aria-valuemax");
            //totalPages = totalPages.Replace("Pageof", "").Trim().ToString();

            //Browser.Wd.FindElement(By.XPath("//*[@aria-label='Go to the next page']")).Click();
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@aria-label='Go to the next page']")));
            tmsWait.Hard(2);
            pageNum = Browser.Wd.FindElement(By.XPath("//input[@class='k-input k-formatted-value']")).GetAttribute("aria-valuenow").ToString();
            Assert.AreEqual("2", pageNum, "Attempt to navigate to the next page failed");

            //Browser.Wd.FindElement(By.XPath("//*[@aria-label='Go to the last page']")).Click();
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@aria-label='Go to the last page']")));
            tmsWait.Hard(2);
            pageNum = Browser.Wd.FindElement(By.XPath("//input[@class='k-input k-formatted-value']")).GetAttribute("aria-valuenow").ToString();
            Assert.AreEqual(totalPages, pageNum, "Attempt to navigate to the last page failed");

            //Browser.Wd.FindElement(By.XPath("//*[@aria-label='Go to the previous page']")).Click();
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@aria-label='Go to the previous page']")));
            tmsWait.Hard(2);
            pageNum = Browser.Wd.FindElement(By.XPath("//input[@class='k-input k-formatted-value']")).GetAttribute("aria-valuenow").ToString();
            int expPageNum = Convert.ToInt32(totalPages) - 1;
            Assert.AreEqual(expPageNum.ToString(), pageNum, "Attempt to navigate to the Previous page failed");

            //Browser.Wd.FindElement(By.XPath("//*[@aria-label='Go to the first page']")).Click();
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@aria-label='Go to the first page']")));
            tmsWait.Hard(2);
            pageNum = Browser.Wd.FindElement(By.XPath("//input[@class='k-input k-formatted-value']")).GetAttribute("aria-valuenow").ToString();
            Assert.AreEqual("1", pageNum, "Attempt to navigate to the first page failed");
            tmsWait.Hard(2);
        }


        [When(@"verify sorting order for each header in file processing grid")]
        public void WhenVerifySortingOrderForEachHeaderInFileProcessingGrid()
        {
            tmsWait.Implicit(120);
            tmsWait.Hard(5);
            string[] columnNames = new string[] { "Request Id", "Processing Status", "File Name", "Description", "Notes", "User Name", "Date" };
            foreach (string column in columnNames)
            {
                tmsWait.Hard(2);
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@test-id='file-grid-fileProcessStatusGrid']//tr/th[contains(.,'" + column + "')]")));
                tmsWait.Hard(1);
                IWebElement gridElement_ascendingIcon = Browser.Wd.FindElement(By.XPath("//span[@class='k-icon k-i-sort-asc-sm']"));
                Assert.IsTrue(gridElement_ascendingIcon.Displayed, "Jobs are not sorted in Acesending Order by Column Name : " + column + " in file processing grid ");

                tmsWait.Hard(1);
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@test-id='file-grid-fileProcessStatusGrid']//tr/th[contains(.,'" + column + "')]")));
                tmsWait.Hard(1);
                IWebElement gridElement_descendingIcon = Browser.Wd.FindElement(By.XPath("//span[@class='k-icon k-i-sort-desc-sm']"));
                Assert.IsTrue(gridElement_descendingIcon.Displayed, "Jobs are not sorted in Acesending Order by Column Name : " + column + " in file processing grid ");

                tmsWait.Hard(2);
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@test-id='file-grid-fileProcessStatusGrid']//tr/th[contains(.,'" + column + "')]")));
                tmsWait.Hard(1);
            }

            tmsWait.Hard(1);
        }

        [When(@"I clicked on Jon Group as ""(.*)"" Job as ""(.*)"" filename ""(.*)"" on Job processing status page")]
        public void WhenIClickedOnJonGroupAsJobAsFilenameOnJobProcessingStatusPage(string p0, string p1, string p2)
        {
            string jobgroup = tmsCommon.GenerateData(p0);
            string job = tmsCommon.GenerateData(p1);
            string filename = tmsCommon.GenerateData(p2);

            // jobgroup Drop down 
            By jobgroupdrp = By.XPath("//kendo-dropdownlist[@test-id='jobProcessingStatus-txt-ddlJobGroupDefault']//span[@class='k-select']");
            AngularFunction.selectDropDownValue(jobgroupdrp, jobgroup);

            // job Drop down 
            By jobdrp = By.XPath("//kendo-dropdownlist[@test-id='jobProcessingStatus-txt-ddlJobName']//span[@class='k-select']");
            AngularFunction.selectDropDownValue(jobdrp, job);

            By search = By.XPath("//span[contains(.,'SEARCH')]");
            AngularFunction.clickOnElement(search);

            By plus = By.XPath("(//td[contains(.,'CMS Extract')]/preceding-sibling::td/a)[1]");
            AngularFunction.clickOnElement(plus);

            ReUsableFunctions.deleteFilesFromDownloadFolder();
            By textexport = By.XPath("//a[contains(.,'"+ filename + "')]");
            AngularFunction.clickOnElement(textexport);
            

        }

        [Then(@"Verify RAM Dual Extract file displayed Diangosis code ""(.*)"" character value as ""(.*)"" on Position ""(.*)""")]
        public void ThenVerifyRAMDualExtractFileDisplayedDiangosisCodeCharacterValueAsOnPosition(string p0, string p1, int p2)
        {
            string expchar = tmsCommon.GenerateData(p1);
            string expdiag = tmsCommon.GenerateData(p0);

            string downloadPath = AngularFunction.returnSystemdownloadFolderPath();
            bool valueFound = false;
            var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
            int filecount = newFilePaths.Length;
            var srcFile = Path.Combine(downloadPath, newFilePaths[filecount - 1]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
                char[] values = line.ToCharArray();
                //if (count > 2)
                //{
                string actdiag = line.Substring(111, 4);
                //(values[111].ToString() + values[112].ToString() + values[113].ToString() + values[114].ToString() + values[115].ToString()).ToString();
                if (values[p2 - 1].ToString().Contains(expchar) && line.Contains(expdiag))
                {
                    valueFound = true;
                    Assert.IsTrue(true);
                    fw.ConsoleReport(expchar + " found on RAPS Report");
                    break;
                }

            }

        }

            [Then(@"Verify RAM CMS Extract file displayed Diangosis code ""(.*)"" character value with Value ""(.*)"" on Position ""(.*)""")]
            public void ThenVerifyRAMCMSExtractFileDisplayedDiangosisCodeCharacterValueWithValueOnPosition(string p0, string p1, int p2)
            {

            string expchar = tmsCommon.GenerateData(p1);
            string expdiag = tmsCommon.GenerateData(p0);

            string downloadPath = AngularFunction.returnSystemdownloadFolderPath();
            bool valueFound = false;
            var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
            int filecount = newFilePaths.Length;
            var srcFile = Path.Combine(downloadPath, newFilePaths[filecount - 1]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
                char[] values = line.ToCharArray();
                //if (count > 2)
                //{
                    string actdiag = line.Substring(111, 4);
                    //(values[111].ToString() + values[112].ToString() + values[113].ToString() + values[114].ToString() + values[115].ToString()).ToString();
                    if (values[p2 - 1].ToString().Contains(expchar) && line.Contains(expdiag))
                    {
                        valueFound = true;
                        Assert.IsTrue(true);
                        fw.ConsoleReport(expchar + " found on RAPS Report");
                        break;
                    }


                //}
            }

            Assert.IsTrue(valueFound, " Expected Diag is not present ");
        }



        [Then(@"Verify CMS Extract file displayed Diangosis code ""(.*)""")]
        public void ThenVerifyCMSExtractFileDisplayedDiangosisCode(string p0)
        {
            string expdiag = tmsCommon.GenerateData(p0);
            string downloadPath = AngularFunction.returnSystemdownloadFolderPath();
            bool valueFound = false;
            var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
            int filecount = newFilePaths.Length;
            var srcFile = Path.Combine(downloadPath, newFilePaths[filecount - 1]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
               // char[] values = line.ToCharArray();              
                   
                    if (line.Contains(expdiag))
                    {
                        valueFound = true;
                        Assert.IsTrue(true);
                        fw.ConsoleReport(expdiag + " found on CMS Report");
                        break;
                    }
                
            }
            Assert.IsTrue(valueFound, " Expected Diag is not present ");
        }


        [Then(@"Verify CMS Extract file displayed Diangosis code as ""(.*)""")]
        public void ThenVerifyCMSExtractFileDisplayedDiangosisCodeAs(string p0)
        {
         
            string expdiag = tmsCommon.GenerateData(p0);

            string downloadPath = AngularFunction.returnSystemdownloadFolderPath();
            bool valueFound = false;
            var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
            int filecount = newFilePaths.Length;
            var srcFile = Path.Combine(downloadPath, newFilePaths[filecount - 1]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
              //  var values = line.ToCharArray();
                
                //if (count > 1)
                //{
                 //   string actdiag = line.Substring(111, 4);
                    //string actdiag = (values[111].ToString() + values[112].ToString() + values[113].ToString() + values[114].ToString() + values[115].ToString()).ToString();
                    if (line.Contains(expdiag))
                    {
                        valueFound = true;
                        Assert.IsTrue(true);
                        fw.ConsoleReport(expdiag + " found on CMS Report");
                        break;
                    }


                //}
            }

            Assert.IsTrue(valueFound, " Expected Diag is not present ");
        }


        [When(@"Verify RAM App CMS Extract file displayed Diangosis code as ""(.*)"" character value as ""(.*)"" on Position ""(.*)""")]
        public void WhenVerifyRAMAppCMSExtractFileDisplayedDiangosisCodeAsCharacterValueAsOnPosition(string p0, string p1, int p2)
        {
            string expchar = tmsCommon.GenerateData(p1);
            string expdiag = tmsCommon.GenerateData(p0);

            string downloadPath = AngularFunction.returnSystemdownloadFolderPath();
            bool valueFound = false;
            var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
            int filecount = newFilePaths.Length;
            var srcFile = Path.Combine(downloadPath, newFilePaths[filecount - 1]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
                char[] values = line.ToCharArray();
                //if (count > 2)
                //{
                // string actdiag = line.Substring(111, 4);

                if (values[p2 - 1].ToString().Contains(expchar) && line.Contains(expdiag))
                {
                    valueFound = true;
                    Assert.IsTrue(true);
                    fw.ConsoleReport(expchar + " found on RAPS Report");
                    break;
                }


                //}
            }
            Assert.IsTrue(valueFound, " Expected Diag is not present ");
        }



        [Then(@"Verify CMS Extract file displayed Diangosis code ""(.*)"" character value as ""(.*)"" on Position ""(.*)""")]
            public void ThenVerifyCMSExtractFileDisplayedDiangosisCodeCharacterValueAsOnPosition(string p0, string p1, int p2)
            {
             
            string expchar = tmsCommon.GenerateData(p1);
            string expdiag = tmsCommon.GenerateData(p0);

            string downloadPath = AngularFunction.returnSystemdownloadFolderPath();
            bool valueFound = false;
            var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
            int filecount = newFilePaths.Length;
            var srcFile = Path.Combine(downloadPath, newFilePaths[filecount - 1]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
                char[] values = line.ToCharArray();
                //if (count > 2)
                //{
                   // string actdiag = line.Substring(111, 4);
                    
                    if (values[p2-1].ToString().Contains(expchar) && line.Contains(expdiag))
                    {
                        valueFound = true;
                        Assert.IsTrue(true);
                        fw.ConsoleReport(expchar + " found on RAPS Report");
                        break;
                    }


                //}
            }
            Assert.IsTrue(valueFound, " Expected Diag is not present ");
        }

        [When(@"Verify RAM Export CMS Extract file displayed Diangosis code ""(.*)"" character value as ""(.*)"" on Position ""(.*)""")]
        public void WhenVerifyRAMExportCMSExtractFileDisplayedDiangosisCodeCharacterValueAsOnPosition(string p0, string p1, int p2)
        {
          
            string expchar = tmsCommon.GenerateData(p1);
            string expdiag = tmsCommon.GenerateData(p0);

            string downloadPath = AngularFunction.returnSystemdownloadFolderPath();
            bool valueFound = false;
            var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
            int filecount = newFilePaths.Length;
            var srcFile = Path.Combine(downloadPath, newFilePaths[filecount - 1]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
                char[] values = line.ToCharArray();
                //if (count > 0)
                //{
                    ///string actdiag = (values[118].ToString() + values[119].ToString() + values[120].ToString() + values[121].ToString()).ToString();
                    //string actdiag = line.Substring(118, 4);
                    if (values[p2 - 1].ToString().Contains(expchar) && line.Contains(expdiag))
                    {

                        valueFound = true;
                        Assert.IsTrue(true);
                        fw.ConsoleReport(expchar + " found on RAPS Report");
                        break;
                    }


                //}
            }

            Assert.IsTrue(valueFound, " Expected Diag is not present ");

        }


        [Then(@"Verify CMS Extract file displayed Diangosis code as ""(.*)"" character value as ""(.*)"" on Position ""(.*)""")]
        public void ThenVerifyCMSExtractFileDisplayedDiangosisCodeAsCharacterValueAsOnPosition(string p0, string p1, int p2)
        {
            string expchar = tmsCommon.GenerateData(p1);
            string expdiag = tmsCommon.GenerateData(p0);

            string downloadPath = AngularFunction.returnSystemdownloadFolderPath();
            bool valueFound = false;
            var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
            int filecount = newFilePaths.Length;
            var srcFile = Path.Combine(downloadPath, newFilePaths[filecount - 1]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
                char[] values = line.ToCharArray();
                //if (count > 0)
                //{
                    //string actdiag = (values[118].ToString() + values[119].ToString() + values[120].ToString() + values[121].ToString()).ToString();
                    string actdiag = line.Substring(118, 4);
                    if (values[p2 - 1].ToString().Contains(expchar) && line.Contains(expdiag))
                    {

                        valueFound = true;
                        Assert.IsTrue(true);
                        fw.ConsoleReport(expchar + " found on RAPS Report");
                        break;
                    }


                //}
            }

            Assert.IsTrue(valueFound, " Expected Diag is not present ");
        }



        [Then(@"Verify RAPS Extract displayed value as ""(.*)""")]
        public void ThenVerifyRAPSExtractDisplayedValueAs(string p0)
        {
            string diag = tmsCommon.GenerateData(p0);

            string downloadPath = AngularFunction.returnSystemdownloadFolderPath();
            bool valueFound = false;
            var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
            int filecount = newFilePaths.Length;
            var srcFile = Path.Combine(downloadPath, newFilePaths[filecount - 1]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
                var values = line.Split(',');
                //if (count > 1)
                //{
                    if(line.Contains(diag))
                    {
                        valueFound = true;
                        Assert.IsTrue(true);
                        fw.ConsoleReport(diag+ " found on RAPS Report");
                        break;
                    }
                  

                //}
            }

            Assert.IsTrue(valueFound, "expected diag is not found ");

        }



        //Gurdeep Arora
        [Then(@"I click on a filename ""(.*)"" to download on file processing status page")]
        public void ThenIClickOnAFilenameToDownloadOnFileProcessingStatusPage(string p0)
        {
            string xpath = "//*[@id='fileProcessStatusGrid']/div[2]/table/tbody/tr";
            string fileName;
            string actualStatus;
            bool isDownloaded = false;
            IList<IWebElement> allRows = Browser.Wd.FindElements(By.XPath(xpath));
            bool flag = false;
            for (int i = 0; i < allRows.Count; i++)
            {
                int j = i + 1;
                actualStatus = Browser.Wd.FindElement(By.XPath("//*[@id='fileProcessStatusGrid']/div[2]/table/tbody/tr[" + j + "]//td[2]/span")).Text;
                fileName = Browser.Wd.FindElement(By.XPath("//*[@id='fileProcessStatusGrid']/div[2]/table/tbody/tr[" + j + "]//td[3]/a/p")).Text;
                if (actualStatus == "Complete" && fileName != "N/A")
                {

                    string[] fileExtensions = { ".CSV", ".XLS", ".PDF", ".pdf", ".xls", ".csv", ".XLSX", ".txt" };

                    System.IO.DirectoryInfo di = new DirectoryInfo(downloadPath);
                    FileInfo[] oldDownloadedFiles = di.EnumerateFiles().Where(p => fileExtensions.Contains(p.Extension, StringComparer.InvariantCultureIgnoreCase)).ToArray();


                    foreach (var oldFile in oldDownloadedFiles)
                    {
                        oldFile.Attributes = FileAttributes.Normal;
                        File.Delete(oldFile.FullName);
                    }
                    tmsWait.Hard(2);
                    Browser.Wd.FindElement(By.XPath("//*[@id='fileProcessStatusGrid']/div[2]/table/tbody/tr[" + j + "]//td[3]/a")).Click();
                    tmsWait.Hard(1);
                    isDownloaded = true;
                    //Verify file is saved in Downloads folder
                    string DownloadsFolderPath = System.IO.Path.Combine(Environment.ExpandEnvironmentVariables("%userprofile%"), "Downloads");
                    DirectoryInfo fileinfo = new DirectoryInfo(DownloadsFolderPath);
                    foreach (FileInfo f in fileinfo.GetFiles().OrderByDescending(f => fileinfo.LastWriteTime))
                    {
                        if (f.Name.Contains(fileName))
                        {
                            Console.Write("This file " + f.Name + " has been downloaded: ");
                            flag = true;
                            tmsWait.Hard(2);
                            break;
                        }
                    }
                }

                tmsWait.Hard(2);
                if (isDownloaded == true)
                {
                    break;
                }
            }
            if (flag == false)
                Console.Write("No file is available to download");
        }



        [Then(@"i click on a file to download on File Processing Page")]
        public void ThenIClickOnAFileToDownloadOnFileProcessingPage()
        {

            string xpath = "//*[@id='fileProcessStatusGrid']/div[2]/table/tbody/tr";
            string fileName;
            string actualStatus;
            bool isDownloaded = false;
            IList<IWebElement> allRows = Browser.Wd.FindElements(By.XPath(xpath));
            bool flag = false;
            for (int i = 0; i < allRows.Count; i++)
            {
                int j = i + 1;
                actualStatus = Browser.Wd.FindElement(By.XPath("//*[@id='fileProcessStatusGrid']/div[2]/table/tbody/tr[" + j + "]//td[2]/span")).Text;
                fileName = Browser.Wd.FindElement(By.XPath("//*[@id='fileProcessStatusGrid']/div[2]/table/tbody/tr[" + j + "]//td[3]/a/p")).Text;
                if (actualStatus == "Complete" && fileName != "N/A")
                {

                    string[] fileExtensions = { ".CSV", ".XLS", ".PDF", ".pdf", ".xls", ".csv", ".XLSX" };

                    System.IO.DirectoryInfo di = new DirectoryInfo(downloadPath);
                    FileInfo[] oldDownloadedFiles = di.EnumerateFiles().Where(p => fileExtensions.Contains(p.Extension, StringComparer.InvariantCultureIgnoreCase)).ToArray();


                    foreach (var oldFile in oldDownloadedFiles)
                    {
                        oldFile.Attributes = FileAttributes.Normal;
                        File.Delete(oldFile.FullName);
                    }
                    tmsWait.Hard(2);
                    Browser.Wd.FindElement(By.XPath("//*[@id='fileProcessStatusGrid']/div[2]/table/tbody/tr[" + j + "]//td[3]/a")).Click();
                    tmsWait.Hard(1);
                    isDownloaded = true;
                    //Verify file is saved in Downloads folder
                    string DownloadsFolderPath = System.IO.Path.Combine(Environment.ExpandEnvironmentVariables("%userprofile%"), "Downloads");
                    DirectoryInfo fileinfo = new DirectoryInfo(DownloadsFolderPath);
                    foreach (FileInfo f in fileinfo.GetFiles().OrderByDescending(f => fileinfo.LastWriteTime))
                    {
                        if (f.Name.Contains(fileName))
                        {
                            Console.Write("This file " + f.Name + " has been downloaded: ");
                            flag = true;
                            tmsWait.Hard(2);
                            break;
                        }
                    }
                }

                tmsWait.Hard(2);
                if (isDownloaded == true)
                {
                    break;
                }
            }
            if (flag == false)
                Console.Write("No file is available to download");

        }



        [Then(@"Verify CMS Extract file displayed Diagnosis Code ""(.*)"" Member ID ""(.*)""")]
        public void ThenVerifyCMSExtractFileDisplayedDiagnosisCodeMemberID(string p0, string p1)
        {
            string diagcode = tmsCommon.GenerateData(p0);
            string Member = tmsCommon.GenerateData(p1);
            //Getting Output folder
            string[] url = ConfigFile.URL.Split('/');
            string[] surl = url[2].Split('.');
            string outputpath = @"\\" + surl[1] + @"\" + "TMSShareFolder" + @"\" + surl[0] + @"\" + "RAMX" + @"\" + "Output";

            //Check for the file
            string fileName = GlobalRef.FileName.ToString();
            if (fileName != "N/A")
            {
                DirectoryInfo fileinfo = new DirectoryInfo(outputpath);
                foreach (FileInfo f in fileinfo.GetFiles("*.txt"))
                {
                    if (f.Name.Contains(fileName))
                    {
                        Console.Write(f.Name + " file exists in Output Folder: ");
                                              
                        var reader = new StreamReader(File.OpenRead(@"" + outputpath + "\\"+f.Name + ""));
                        while (!reader.EndOfStream)
                        {
                         
                            var line = reader.ReadLine();                           

                            if (line.Contains(diagcode))
                            {
                                Assert.IsTrue(true, "Expected Diagcode is not getting Displayed.");
                                if (line.Contains(Member))
                                {
                                    Assert.IsTrue(true, "Expected Member is not getting Displayed.");
                                    break;
                                }
                               
                            }

                           
                        }
                        reader.Close();
                    }


                }
            }


        }



        [Then(@"verify generated file exists in output folder for RAMX application")]
        public void ThenVerifyGeneratedFileExistsInOutputFolderForRAMXApplication()
        {
            //Getting Output folder
            string[] url = ConfigFile.URL.Split('/');
            string[] surl = url[2].Split('.');
            string server = surl[0].ToUpper();
            string outputpath = @"\\" + surl[1] + @"\" + "TMSShareFolder" + @"\" + server + @"\" + ConfigFile.RAMXdb + @"\" + "Output";

            //Check for the file
            string fileName = GlobalRef.FileName.ToString();
            if (fileName != "N/A")
            {
                DirectoryInfo fileinfo = new DirectoryInfo(outputpath);
                foreach (FileInfo f in fileinfo.GetFiles("*.txt"))
                {
                    if (f.Name.Contains(fileName))
                    {
                        Console.Write(f.Name + " file exists in Output Folder: ");
                        break;
                    }
                }
            }
            else
            {
                Console.Write("No file was generated");
            }
        }

        string jobName;
        string actualstatus = "";
        By xpath;
        string actualStatus;
        string currentAppName;
        [Then(@"Verify the File Processing Status page report ""(.*)"" status is ""(.*)""")]
        [When(@"Verify the File Processing Status page report ""(.*)"" status is ""(.*)""")]
        public void ThenVerifyTheFileProcessingStatusPageReportStatusIs(string p0, string p1)
        {
         // Make sure that you Gherkin step defnition is carrying below values   
            var reports = GlobalRef.ReportName.ToString();
            try
            {
                 currentAppName = GlobalRef.ApplicationName.ToString();
            }
            catch
            {

            }
           
         
            string reportName = p0.ToString();
            string reportStatus = p1.ToString();

            if (p0.Equals("LICS") ||p0.Equals("CMS Rejected Clusters by Error Code Detail") || p0.Equals("MLR") || p0.Equals("Member Distribution") || p0.Equals("ReInsure") || p0.Equals("ReInsure") || p0.Equals("RiskShare") || p0.Equals("Troop") || p0.Equals("Utilization") || p0.Equals("File Status Summary") || p0.Equals("HCC Beneficiaries")) //HCC Beneficiaries
            {

                
                string fileName = reportName;
                string procesingStatus = reportStatus;
              
                string xpath = "(//kendo-grid[@test-id='file-grid-fileProcessStatusGrid']//td[contains(.,'" + reportName + "')]/preceding-sibling::td[@aria-colindex='2']/div)[1]"; // Indicate Complete Status
                actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                int ReturnStatus = StatusValidation(actualStatus);
                fw.ConsoleReport(" Processing File Name -->" + fileName);
                while (ReturnStatus != 0)
                {

                    tmsWait.Hard(20);
                    actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                    ReturnStatus = StatusValidation(actualStatus);
                }
            }

            else
            {

                if (reportName.Contains("PIR Extract"))
                {
                    jobName = "Ram Exports";
                }
                else if (reportName.Contains("PIRResponse") || reportName.Contains("PIR Response File"))
                {
                    jobName = "PIR Response File";
                }
                else if (reportName.Contains("PIRResponse") || reportName.Contains("PIR Response File"))
                {
                    jobName = "PIR Response File";
                }
                else if (currentAppName.Equals("RAMX") || reportName.Contains("Reports"))
                {
                    jobName = "Ramx Reports";
                }
                else if (currentAppName.Equals("EAM") || reportName.Contains("Reports"))
                {
                    jobName = "Eam Reports";
                }
                else if (currentAppName.Equals("FRM") || reportName.Contains("Reports"))
                {
                    jobName = "Frm Reports";
                }
                else if (currentAppName.Equals("RAM") || reportName.Contains("Reports") || reportName.Contains("CMS File Extract Summary"))
                {
                    jobName = "Ram Reports";
                }
                else if (reportName.Contains("Client Identified Suspects File"))
                {
                    jobName = "Client Identified Suspects File";
                }
                else
                {
                    jobName = reportName;
                }

                By Drp = By.XPath("//kendo-dropdownlist[@test-id='jobProcessingStatus-txt-ddlJobName']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + jobName + "']");

                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

                AngularFunction.clickOnElement(cfJobProcessing.RAMJobProcessing.SearchButton);
                tmsWait.Hard(3);

                if ( reportName.Contains("CMS File Extract Summary"))
                {
                    xpath = By.XPath("(//td[contains(.,'" + reportName + "')]/following-sibling::td[@aria-colindex='4'])[1]");
                }
                else
                {
                    xpath = By.XPath("(//td[contains(.,'" + reportName + "')]/following-sibling::td[@aria-colindex='4'])[1]");
                }

            


                fw.ConsoleReport("------------------>This is new Job Processing page <---------------------------------");

                if (reportStatus.Contains("Complete"))
                {
                    if (currentAppName.Equals("RAM") || currentAppName.Equals("RAMX"))
                    {
                        reportStatus = "Success"; /*File Processing Status page uses word Complete for success outside of RAM and RAMX now, this code is only necessary for RAM(X)*/
                    }
                }




                try
                {

                    //actualstatus = AngularFunction.getText(xpath);
                    actualstatus = Browser.Wd.FindElement(xpath).Text.ToString();
                    fw.ConsoleReport(" Initial Job Processing status" + actualstatus);
                }
                catch
                {

                }
                int ReturnStatus = StatusValidation(actualstatus);


                while (ReturnStatus != 0)
                {

                    fw.ExecuteJavascript(cfJobProcessing.RAMJobProcessing.SearchButton);
                    tmsWait.Hard(8); // We put this wait intentionally as File processing is taking time for ESI
                    //actualstatus = AngularFunction.getText(xpath);
                    actualstatus = Browser.Wd.FindElement(xpath).Text.ToString();
                    fw.ConsoleReport(" Current File Processing status --> " + actualstatus);
                    ReturnStatus = StatusValidation(actualstatus);
                }

                fw.ConsoleReport(reportName + "  --> Job Processing status --> " + actualstatus);

                Assert.AreEqual(reportStatus, actualstatus);


            }
        }



        [Then(@"Verify the File Processing Status page report ""(.*)"" Note is ""(.*)""")]
        public void ThenVerifyTheFileProcessingStatusPageReportNoteIs(string reportName, string note)
        {
            tmsWait.WaitForElement(By.XPath("//div[@tooltip='" + reportName + "']//parent::div/preceding-sibling::div//span[contains(.,'Failed')]"), 360);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@tooltip='PIR Extract']//parent::div/following-sibling::div/div/div[contains(.,'" + note + "')]")).Displayed);
        }


        public int StatusValidation(string actualStatus)
        {
            if (actualStatus.Equals("Pending"))
            {
                tmsWait.Hard(2);
                return 1;
            }
            else if (actualStatus.Equals("Executing"))
            {
                return 1;
            }

            else if (actualStatus.Equals("Failed"))
            {
                Assert.Fail("Report Generation Job is failed");
                return 0;
            }
            else if (actualStatus.Equals("Disabled"))
            {
                Assert.Fail("Report Generation Job is Disabled");
                return 0;
            }
            else if (actualStatus.Equals("Complete"))
            {

                return 0;
            }
            else if (actualStatus.Equals("Success"))
            {
              
                return 0;
            }
            else if (actualStatus.Equals("Complete/No Updates"))
            {

                return 0;
            }

            return 0;
        }


        public void ValidationOfReportPage(string Value)
        {
            string xpath = string.Format("//*[text()='{0}']", Value);
            IWebElement WebElement = Browser.Wd.FindElement(By.XPath(xpath));
            Assert.IsTrue(WebElement.Displayed, Value + "not displayed on report page");
        }

        [When(@"Report Manager page Report Name ""(.*)"" is selected")]
        public void WhenReportManagerPageReportNameIsSelected(string p0)
        {
            tmsWait.Hard(10);

            IWebElement elecType = Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='reportManager-select-multiSelectReports']//input"));

            elecType.SendKeys(p0);
            tmsWait.Hard(3);
            elecType.SendKeys(OpenQA.Selenium.Keys.Enter);

        }

        [When(@"Report Manager page Plan ID listbox is set to ""(.*)""")]
        public void WhenReportManagerPagePlanIDListboxIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0.ToString());
            string xpathstring = "//multiselect[@test-id='multiSelectPlans']//a[contains(.,'" + GeneratedData + "')]/span";
            fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
            obj.SelectDropDownValues(xpathstring);
        }

        [When(@"Report Manager page Search button is clicked")]
        public void WhenReportManagerPageSearchButtonIsClicked()
        {
            fw.ExecuteJavascript(RSM.ReportManager.SearchButton);
            tmsWait.Hard(5);
        }

        [Then(@"Verify Report Manager page Result Panel displays Search results")]
        public void ThenVerifyReportManagerPageResultPanelDisplaysSearchResults(Table table)
        {
            //TableValidation(table, RSM.Lookups.GroupIDLookUp.GroupLoookupGrid, RSM.Lookups.GroupIDLookUp.topFiftyPaging);
        }

        [Then(@"Verify ReportManager title ""(.*)"" is displayed")]
        public void ThenVerifyReportManagerTitleIsDisplayed(string p0)
        {
            Assert.AreEqual(Browser.Wd.FindElement(By.XPath("//div[@class='adminTitle ng-scope']//span")).Text, p0, "Title is incorrect");
        }

        [Then(@"Verify ReportManager Label ""(.*)"" is displayed")]
        public void ThenVerifyReportManagerLabelIsDisplayed(string p0)
        {
            switch (p0.ToLower())
            {
                case "report name":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//div[@id='mainContant']//label)[1]")).Text.Contains(p0));
                    break;
                case "plan id":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//div[@id='mainContant']//label)[2]")).Text.Contains(p0));
                    break;
            }
        }


        [When(@"Report page ""(.*)"" radio button set to ""(.*)""")]
        public void WhenReportPageRadioButtonSetTo(string filter, string status)
        {
            tmsWait.Hard(5);
            string newStatus = CultureInfo.CurrentCulture.TextInfo.ToTitleCase(status.ToLower());
            IWebElement element = Browser.Wd.FindElement(By.XPath("//label[@for='rdInteractive" + newStatus + "']/parent::div/input"));
            fw.ExecuteJavascript(element);

            if (status.ToLower().Equals("yes"))
            {
                GlobalRef.winium = "Interactive";

            }
            else if (status.ToLower().Equals("no"))
            {
                GlobalRef.winium = "NonInteractive";
            }
        }


        [When(@"Report page Save Format ""(.*)"" radio button is clicked")]
        public void WhenReportPageSaveFormatRadioButtonIsClicked(string format)
        {
            //tmsWait.Hard(3);
            //Browser.Wd.FindElement(By.XPath("//input[@data-ng-model='selectedCriteria.selectedReportFormat' and @value='" + saveFormat.ToUpper() + "']/parent::label/label/span")).Click();

            tmsWait.Hard(2);
            IWebElement saveformat = Browser.Wd.FindElement(By.XPath("//input[@value='" + format + "']"));
            fw.ExecuteJavascript(saveformat);
        }


        [Then(@"Verify in Reports Manager page ""(.*)"" report is displayed as ""(.*)""")]
        public void ThenVerifyInReportsManagerPageReportIsDisplayedAs(string reportName, string status)
        {
            if (Browser.Wd.FindElement(By.XPath("//div[text()='" + reportName + "']/parent::div/preceding-sibling::div//span[text()='" + status + "']")).Displayed)
            {
                Assert.IsTrue(true,reportName + " Report is displayed in Report Manager Page.");
            }
            else
            {
                Assert.Fail(reportName + " Report is not displayed in Report Manager Page");
            }
        }

        [Then(@"Risk Score Trend page Source drop down list is set to ""(.*)""")]
        public void ThenRiskScoreTrendPageSourceDropDownListIsSetTo(string p0)
        {
            tmsWait.Hard(5);

            SelectElement source = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@test-id='Source']")));
            source.SelectByText(p0);
        }


        [Then(@"Select the first record from lookup")]
        public void ThenSelectTheFirstRecordFromLookup()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(".//tr[@data-uid='72f1857c-cb30-4f7c-8d57-1661c17f32e0']//input[@type='checkbox']")));
            tmsWait.Hard(1);
        }


        [When(@"""(.*)"" Lookup page Back To Record button is clicked")]
        [Then(@"""(.*)"" Lookup page Back To Record button is clicked")]
        public void ThenBackToRecordButtonIsClicked(string p0)
        {

            // string xpath = "//span[@test-id='pcpLookup-txt-backToRecord']/i";

            //No need of swich case here to click on Back to Record bbutton.

            //tmsWait.Hard(5);
            string lookup = p0.ToString().Trim().ToLower();
            switch (lookup)
            {
                case "groupid":
                    fw.ExecuteJavascript(RSM.Lookups.GroupIDLookUp.GroupLoookBackToRecord);
                    break;
                case "pcp":
                    fw.ExecuteJavascript(RSM.Lookups.PCPLookUp.PCPLoookBackToRecord);
                    break;
                case "scc":
                    fw.ExecuteJavascript(RSM.Lookups.SCCLookUp.SCCBackToRecord);
                    break;
                case "hic":
                    fw.ExecuteJavascript(RSM.Lookups.HICLookUp.HICBackToRecord);
                    break;
                case "hcc":
                    fw.ExecuteJavascript(RSM.Lookups.HCCLookUp.HCCBackToRecord);
                    break;
            }

            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(xpath)));
            tmsWait.Hard(2);
        }


        [When(@"RX HCC Beneficiaries Report ""(.*)"" Dropdown is set to ""(.*)""")]
        public void WhenRXHCCBeneficiariesReportDropdownIsSetTo(string p0, string p1)
        {
            string dropdown = p0.ToString();
            string value = p1.ToString();

            switch (dropdown.ToLower().Trim())
            {
                case "plan id":
                    SelectElement year = new SelectElement(RSM.RiskScoreTrendDetails.PaymentYear);
                    year.SelectByText(value);
                    break;
                case "payment year":
                    SelectElement RaftType = new SelectElement(RSM.RiskScoreTrendDetails.RAFT);
                    RaftType.SelectByText(value);
                    break;
                case "year type":
                    SelectElement Enrollment = new SelectElement(RSM.RiskScoreTrendDetails.Enrollment);
                    Enrollment.SelectByText(value);
                    break;
                case "group id":
                    SelectElement SortBy = new SelectElement(RSM.RiskScoreTrendDetails.SortBy);
                    SortBy.SelectByText(value);
                    break;
                case "pbp":
                    SelectElement pbp = new SelectElement(RSM.RiskScoreTrendDetails.SortBy);
                    pbp.SelectByText(value);
                    break;

            }
        }


        [When(@"Risk Score Trend Details - Part D RAFT dropdown has option ""(.*)""")]
        public void WhenRiskScoreTrendDetails_PartDRAFTDropdownHasOption(string p0)
        {
            IWebElement raftele = Browser.Wd.FindElement(By.XPath("//select[@test-id='RAFT']"));
            SelectElement raft = new SelectElement(raftele);
            raft.SelectByText(p0);
        }

        [Then(@"Verify Reports page ""(.*)"" field is displayed")]
        public void ThenVerifyReportsPageFieldIsDisplayed(string p0)
        {
            tmsWait.Hard(1);
            IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='" + p0 + "']"));
            bool elementDisplay = elem.Displayed;
            Assert.IsTrue(elementDisplay, " Expected Element is not displayed");
        }


        [When(@"""(.*)"" RAFT dropdown has option ""(.*)""")]
        public void WhenRAFTDropdownHasOption(string p0, string option)
        {
            tmsWait.Hard(5);
            IWebElement multi = Browser.Wd.FindElement(By.XPath("//multiselect[@test-id='RAFT']//button"));
            fw.ExecuteJavascript(multi);
            tmsWait.Hard(5);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//multiselect[@test-id='RAFT']//a[contains(.,'" + option + "')]")).Displayed);
            fw.ExecuteJavascript(multi);
        }

        [When(@"Risk Score Trend Details report page Source dropdown list is set to ""(.*)""")]
        public void WhenRiskScoreTrendDetailsReportPageSourceDropdownListIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            SelectElement drp = new SelectElement(Browser.Wd.FindElement(By.CssSelector("[test-id='Source']")));
            drp.SelectByText(p0);
        }


        [When(@"Risk Score Trend report page Source dropdown list is set to ""(.*)""")]
        public void WhenRiskScoreTrendReportPageSourceDropdownListIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            SelectElement drp = new SelectElement(Browser.Wd.FindElement(By.CssSelector("[test-id='Source']")));
            drp.SelectByText(p0);
        }

        [Then(@"Verify Risk Score Trend page Source dropdown displays value as ""(.*)""")]
        public void ThenVerifyRiskScoreTrendPageSourceDropdownDisplaysValueAs(string p0)
        {

            bool elementPresence = false;
            string[] values = p0.Split(',');
            foreach (string temp in values)
            {
                tmsWait.Hard(2);
                elementPresence = Browser.Wd.FindElement(By.XPath("//select[@test-id='Source']/option[contains(.,'" + temp + "')]")).Displayed;
                Assert.IsTrue(elementPresence, temp + "Is not Present");

            }

        }


        [When(@"""(.*)"" ""(.*)"" listbox is set to ""(.*)""")]
        [When(@"""(.*)"" ""(.*)"" multiple select drop down is set to ""(.*)""")]
        public void WhenMultipleSelectDropDownIsSetTo(string reportName, string filter, string values)
        {
            tmsWait.Hard(5);
            //reportName = tmsCommon.GenerateData(reportName);
            string DropDownName = filter.ToString();
            string[] valuesFromDD = values.ToString().Split(',');
            string xpathstring = null;
            string GeneratedData = null;
            switch (reportName.ToString())
            {
                case "HCC Discrepancy":
                    {
                        switch (DropDownName)
                        {
                            case "PlanID":
                                if (values.ToLower() == "single")
                                {
                                    xpathstring = "//multiselect/div/ul/li[2]/a";
                                    fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                    obj.SelectDropDownValues(xpathstring);
                                }
                                else
                                {
                                    for (int i = 2; i < 3; i++)
                                    {
                                        xpathstring = "//multiselect/div/ul/li[" + i + "]/a";
                                        fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                        obj.SelectDropDownValues(xpathstring);
                                    }
                                }
                                break;
                            case "PaymentYear":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PaymentYear = new SelectElement(RSM.HCCDiscrepancy.PaymentYear);
                                    PaymentYear.SelectByText(GeneratedData);
                                }
                                break;
                            case "YearType":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement YearType = new SelectElement(RSM.HCCDiscrepancy.YearType);
                                    YearType.SelectByText(GeneratedData);
                                }
                                break;
                            case "PBP":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PBP = new SelectElement(RSM.HCCDiscrepancy.PBP);
                                    PBP.SelectByIndex(0);
                                }
                                break;
                            case "Enrollment":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement Enrollment = new SelectElement(RSM.HCCDiscrepancy.Enrollment);
                                    Enrollment.SelectByText(GeneratedData);
                                }
                                break;
                            case "DiscrepancyType":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement DiscrepancyType = new SelectElement(RSM.HCCDiscrepancy.DiscrepancyType);
                                    DiscrepancyType.SelectByText(GeneratedData);
                                }
                                break;
                            case "SortBy":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement SortBy = new SelectElement(RSM.HCCDiscrepancy.SortBy);
                                    SortBy.SelectByText(GeneratedData);
                                }
                                break;
                            case "RaftType":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement RaftType = new SelectElement(RSM.HCCDiscrepancy.RaftType);
                                    RaftType.SelectByIndex(0);
                                }
                                break;
                            case "ResubmitStatus":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement ResubmitStatus = new SelectElement(RSM.HCCDiscrepancy.ResubmitStatus);
                                    ResubmitStatus.SelectByText(GeneratedData);
                                }
                                break;
                        }
                    }
                    break;

                case "Risk Adjustment Profile":
                    {
                        switch (DropDownName)
                        {
                            case "PlanID":
                                if (values.ToLower() == "single")
                                {
                                    xpathstring = "//multiselect/div/ul/li[2]/a";
                                    fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                    obj.SelectDropDownValues(xpathstring);
                                }
                                else
                                {
                                    for (int i = 2; i < 3; i++)
                                    {
                                        xpathstring = "//multiselect/div/ul/li[" + i + "]/a";
                                        fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                        obj.SelectDropDownValues(xpathstring);
                                    }
                                }
                                break;
                            case "PaymentYear":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PaymentYear = new SelectElement(RSM.RiskAdjustmentProfile.PaymentYear);
                                    PaymentYear.SelectByText(GeneratedData);
                                }
                                break;

                            case "PBP":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PBP = new SelectElement(RSM.RiskAdjustmentProfile.PBP);
                                    PBP.SelectByIndex(0);
                                }
                                break;
                            case "GroupID":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    xpathstring = "//multiselect[@test-id='GROUP']//a[contains(.,'" + GeneratedData + "')]/span";
                                    fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                    obj.SelectDropDownValues(xpathstring);
                                }
                                break;
                            case "RiskType":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement RiskType = new SelectElement(RSM.RiskAdjustmentProfile.RiskType);
                                    RiskType.SelectByText(GeneratedData);
                                }
                                break;

                        }
                    }
                    break;

                case "HCC Details":
                    {
                        switch (DropDownName)
                        {
                            case "PlanID":
                                if (values.ToLower() == "single")
                                {
                                    xpathstring = "//multiselect/div/ul/li[2]/a";
                                    fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                    obj.SelectDropDownValues(xpathstring);
                                }
                                else
                                {
                                    for (int i = 2; i < 3; i++)
                                    {
                                        xpathstring = "//multiselect/div/ul/li[" + i + "]/a";
                                        fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                        obj.SelectDropDownValues(xpathstring);
                                    }
                                }
                                break;
                            case "PaymentYear":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PaymentYear = new SelectElement(RSM.HCCDetails.PaymentYear);
                                    PaymentYear.SelectByText(GeneratedData);
                                }
                                break;
                            case "YearType":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement YearType = new SelectElement(RSM.HCCDetails.YearType);
                                    YearType.SelectByText(GeneratedData);
                                }
                                break;
                            case "PBP":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PBP = new SelectElement(RSM.HCCDetails.PBP);
                                    PBP.SelectByIndex(0);
                                }
                                break;
                            case "Enrollment":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement Enrollment = new SelectElement(RSM.HCCDetails.Enrollment);
                                    Enrollment.SelectByText(GeneratedData);
                                }
                                break;
                            case "RXHCC":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement RXHCC = new SelectElement(RSM.HCCDetails.RXHCC);
                                    RXHCC.SelectByText(GeneratedData);
                                }
                                break;
                            case "HCC":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement HCC = new SelectElement(RSM.HCCDetails.HCC);
                                    HCC.SelectByText(GeneratedData);
                                }
                                break;
                            case "RAFT":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    xpathstring = "//multiselect[@test-id='RAFT']//a[contains(.,'" + GeneratedData + "')]/span";
                                    fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                    obj.SelectDropDownValues(xpathstring);
                                }
                                break;
                            case "RiskType":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement RiskType = new SelectElement(RSM.HCCDetails.RiskType);
                                    RiskType.SelectByText(GeneratedData);
                                }
                                break;
                        }
                    }
                    break;

                case "HCC Beneficiaries":
                    {

                        switch (DropDownName)
                        {
                            case "PlanID":
                                if (values.ToLower() == "single")
                                {
                                    xpathstring = "//multiselect/div/ul/li[2]/a";
                                    fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                    obj.SelectDropDownValues(xpathstring);
                                }
                                else
                                {
                                    for (int i = 2; i < 3; i++)
                                    {
                                        xpathstring = "//multiselect/div/ul/li[" + i + "]/a";
                                        fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                        obj.SelectDropDownValues(xpathstring);
                                    }
                                }
                                break;
                            case "PaymentYear":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PaymentYear = new SelectElement(RSM.HCCDiscrepancy.PaymentYear);
                                    PaymentYear.SelectByText(GeneratedData);
                                }
                                break;
                            case "YearType":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement YearType = new SelectElement(RSM.HCCDiscrepancy.YearType);
                                    YearType.SelectByText(GeneratedData);
                                }
                                break;
                            case "PBP":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PBP = new SelectElement(RSM.HCCDiscrepancy.PBP);
                                    PBP.SelectByIndex(0);
                                }
                                break;

                        }

                    }
                    break;

                case "RX HCC Beneficiaries":
                    {

                        switch (DropDownName)
                        {
                            case "PlanID":
                                if (values.ToLower() == "single")
                                {
                                    xpathstring = "//multiselect/div/ul/li[2]/a";
                                    fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                    obj.SelectDropDownValues(xpathstring);
                                }
                                else
                                {
                                    for (int i = 2; i < 3; i++)
                                    {
                                        xpathstring = "//multiselect/div/ul/li[" + i + "]/a";
                                        fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                        obj.SelectDropDownValues(xpathstring);
                                    }
                                }
                                break;
                            case "PaymentYear":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PaymentYear = new SelectElement(RSM.HCCDiscrepancy.PaymentYear);
                                    PaymentYear.SelectByText(GeneratedData);
                                }
                                break;
                            case "YearType":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement YearType = new SelectElement(RSM.HCCDiscrepancy.YearType);
                                    YearType.SelectByText(GeneratedData);
                                }
                                break;
                            case "PBP":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PBP = new SelectElement(RSM.HCCDiscrepancy.PBP);
                                    PBP.SelectByIndex(0);
                                }
                                break;

                        }

                    }
                    break;

                case "CMS HCC Disease Group Prevalence":

                    {
                        switch (DropDownName)
                        {
                            case "PlanID":
                                if (values.ToLower() == "single")
                                {
                                    xpathstring = "//multiselect/div/ul/li[2]/a";
                                    fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                    obj.SelectDropDownValues(xpathstring);
                                }
                                else
                                {
                                    for (int i = 2; i < 3; i++)
                                    {
                                        xpathstring = "//multiselect/div/ul/li[" + i + "]/a";
                                        fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                        obj.SelectDropDownValues(xpathstring);
                                    }
                                }
                                break;
                            case "YearType":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement YearType = new SelectElement(RSM.CMSHCCDiseaseGroupPrevelance.YearType);
                                    YearType.SelectByText(GeneratedData);
                                }
                                break;
                            case "PBP":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PBP = new SelectElement(RSM.CMSHCCDiseaseGroupPrevelance.PBP);
                                    PBP.SelectByIndex(0);
                                }
                                break;
                        }
                    }
                    break;

                case "Risk Score Trend PCP":

                    {
                        switch (DropDownName)
                        {
                            case "PlanID":
                                if (values.ToLower() == "single")
                                {
                                    xpathstring = "//multiselect/div/ul/li[2]/a";
                                    fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                    obj.SelectDropDownValues(xpathstring);
                                }
                                else
                                {
                                    for (int i = 2; i < 3; i++)
                                    {
                                        xpathstring = "//multiselect/div/ul/li[" + i + "]/a";
                                        fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                        obj.SelectDropDownValues(xpathstring);
                                    }
                                }
                                break;
                            case "PaymentYear":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PaymentYear = new SelectElement(RSM.RiskScoreTrendPCPPartD.PaymentYear);
                                    PaymentYear.SelectByText(GeneratedData);
                                }
                                break;
                            case "YearType":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement YearType = new SelectElement(RSM.RiskScoreTrendPCPPartD.YearType);
                                    YearType.SelectByText(GeneratedData);
                                }
                                break;
                            case "PBP":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PBP = new SelectElement(RSM.RiskScoreTrendPCPPartD.PBP);
                                    PBP.SelectByText(GeneratedData);
                                }
                                break;
                            case "Enrollment":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PBP = new SelectElement(RSM.RiskScoreTrendPCPPartD.Enrollment);
                                    PBP.SelectByText(GeneratedData);
                                }
                                break;
                        }
                    }
                    break;

                case "Risk Score Trend":

                    {
                        switch (DropDownName)
                        {
                            case "PlanID":
                                if (values.ToLower() == "single")
                                {
                                    xpathstring = "//multiselect/div/ul/li[2]/a";
                                    fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                    obj.SelectDropDownValues(xpathstring);
                                }
                                else
                                {
                                    for (int i = 2; i < 3; i++)
                                    {
                                        xpathstring = "//multiselect/div/ul/li[" + i + "]/a";
                                        fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                        obj.SelectDropDownValues(xpathstring);
                                    }
                                }
                                break;
                            case "PaymentYear":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PaymentYear = new SelectElement(RSM.RiskScoreTrendPCPPartD.PaymentYear);
                                    PaymentYear.SelectByText(GeneratedData);
                                }
                                break;
                            case "YearType":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement YearType = new SelectElement(RSM.RiskScoreTrendPCPPartD.YearType);
                                    YearType.SelectByText(GeneratedData);
                                }
                                break;
                            case "PBP":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PBP = new SelectElement(RSM.RiskScoreTrendPCPPartD.PBP);
                                    PBP.SelectByIndex(0);
                                }
                                break;
                            case "Enrollment":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PBP = new SelectElement(RSM.RiskScoreTrendPCPPartD.Enrollment);
                                    PBP.SelectByText(GeneratedData);
                                }
                                break;
                        }
                    }
                    break;

                case "Risk Score Trend - Part D":

                    {
                        switch (DropDownName)
                        {
                            case "PlanID":
                                if (values.ToLower() == "single")
                                {
                                    xpathstring = "//multiselect/div/ul/li[2]/a";
                                    fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                    obj.SelectDropDownValues(xpathstring);
                                }
                                else if (values.ToLower() == "multiple")
                                {
                                    for (int i = 2; i <= 3; i++)
                                    {
                                        xpathstring = "//multiselect/div/ul/li[" + i + "]/a";
                                        fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                        obj.SelectDropDownValues(xpathstring);
                                    }
                                }
                                break;
                            case "PaymentYear":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PaymentYear = new SelectElement(RSM.RiskScoreTrendPCPPartD.PaymentYear);
                                    PaymentYear.SelectByText(GeneratedData);
                                }
                                break;
                            case "YearType":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement YearType = new SelectElement(RSM.RiskScoreTrendPCPPartD.YearType);
                                    YearType.SelectByText(GeneratedData);
                                }
                                break;
                            case "PBP":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PBP = new SelectElement(RSM.RiskScoreTrendPCPPartD.PBP);
                                    PBP.SelectByIndex(0);
                                }
                                break;
                            case "Enrollment":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PBP = new SelectElement(RSM.RiskScoreTrendPCPPartD.Enrollment);
                                    PBP.SelectByText(GeneratedData);
                                }
                                break;
                        }
                    }
                    break;
                case "Risk Score Trend PCP - Part D":

                    {
                        switch (DropDownName)
                        {
                            case "PlanID":
                                if (values.ToLower() == "single")
                                {
                                    xpathstring = "//multiselect/div/ul/li[2]/a";
                                    fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                    obj.SelectDropDownValues(xpathstring);
                                }
                                else
                                {
                                    for (int i = 2; i < 3; i++)
                                    {
                                        xpathstring = "//multiselect/div/ul/li[" + i + "]/a";
                                        fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                        obj.SelectDropDownValues(xpathstring);
                                    }
                                }
                                break;
                            case "PaymentYear":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PaymentYear = new SelectElement(RSM.RiskScoreTrendPCPPartD.PaymentYear);
                                    PaymentYear.SelectByText(GeneratedData);
                                }
                                break;
                            case "YearType":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement YearType = new SelectElement(RSM.RiskScoreTrendPCPPartD.YearType);
                                    YearType.SelectByText(GeneratedData);
                                }
                                break;
                            case "PBP":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PBP = new SelectElement(RSM.RiskScoreTrendPCPPartD.PBP);
                                    PBP.SelectByIndex(0);
                                }
                                break;
                            case "Enrollment":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PBP = new SelectElement(RSM.RiskScoreTrendPCPPartD.Enrollment);
                                    PBP.SelectByText(GeneratedData);
                                }
                                break;
                        }
                    }
                    break;

                case "Risk Score Trend Details":

                    {
                        switch (DropDownName)
                        {
                            case "PlanID":
                                if (values.ToLower() == "single")
                                {
                                    xpathstring = "//multiselect/div/ul/li[2]/a";
                                    fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                    obj.SelectDropDownValues(xpathstring);
                                }
                                else
                                {
                                    for (int i = 2; i < 3; i++)
                                    {
                                        xpathstring = "//multiselect/div/ul/li[" + i + "]/a";
                                        fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                        obj.SelectDropDownValues(xpathstring);
                                    }
                                }
                                break;
                            case "PaymentYear":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PaymentYear = new SelectElement(RSM.RiskScoreTrendDetails.PaymentYear);
                                    PaymentYear.SelectByText(GeneratedData);
                                }
                                break;
                            case "YearType":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement YearType = new SelectElement(RSM.RiskScoreTrendDetails.YearType);
                                    YearType.SelectByText(GeneratedData);
                                }
                                break;
                            case "PBP":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PBP = new SelectElement(RSM.RiskScoreTrendDetails.PBP);
                                    PBP.SelectByIndex(0);
                                }
                                break;
                            case "Enrollment":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PBP = new SelectElement(RSM.RiskScoreTrendDetails.Enrollment);
                                    PBP.SelectByText(GeneratedData);
                                }
                                break;
                            case "RAFT":
                                GeneratedData = tmsCommon.GenerateData(values);
                                SelectElement RAFT = new SelectElement(RSM.RiskScoreTrendDetails.RAFT);
                                RAFT.SelectByText(GeneratedData);
                                break;
                            case "SortBy":
                                GeneratedData = tmsCommon.GenerateData(values);
                                SelectElement SortBy = new SelectElement(RSM.RiskScoreTrendDetails.RAFT);
                                SortBy.SelectByText(GeneratedData);
                                break;
                        }
                    }
                    break;

                case "CMS RX Disease Group Prevelance":
                    {
                        if (DropDownName == "PlanID")
                            if (values.ToLower() == "single")
                            {
                                xpathstring = "//multiselect/div/ul/li[2]/a";
                                fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                obj.SelectDropDownValues(xpathstring);
                            }
                            else
                            {
                                for (int i = 2; i < 3; i++)
                                {
                                    xpathstring = "//multiselect/div/ul/li[" + i + "]/a";
                                    fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                    obj.SelectDropDownValues(xpathstring);
                                }
                            }

                    }
                    break;

                case "Risk Score Calculation Details":
                    {
                        switch (DropDownName)
                        {
                            case "YearType":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    xpathstring = "//multiselect[@test-id='YEAR_TYPE']//a[contains(.,'" + GeneratedData + "')]/span";
                                    fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                    obj.SelectDropDownValues(xpathstring);
                                }
                                break;
                            case "PaymentYear":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    xpathstring = "//multiselect[@test-id='PAY_YEAR']//a[contains(.,'" + GeneratedData + "')]/span";
                                    fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                    obj.SelectDropDownValues(xpathstring);
                                }
                                break;

                        }


                    }
                    break;
                case "Member Missing HCC":
                    {
                        switch (DropDownName)
                        {
                            case "PlanID":
                                if (values.ToLower() == "single")
                                {
                                    xpathstring = "//multiselect/div/ul/li[2]/a";
                                    fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                    obj.SelectDropDownValues(xpathstring);
                                }
                                else
                                {
                                    for (int i = 2; i < 3; i++)
                                    {
                                        xpathstring = "//multiselect/div/ul/li[" + i + "]/a";
                                        fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                        obj.SelectDropDownValues(xpathstring);
                                    }
                                }
                                break;
                            case "PaymentYear":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PaymentYear = new SelectElement(RSM.MemberMissingHCC.PaymentYear);
                                    PaymentYear.SelectByText(GeneratedData);
                                }
                                break;

                            case "PBP":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PBP_value = new SelectElement(RSM.MemberMissingHCC.PBP);
                                    PBP_value.SelectByIndex(0);
                                }
                                break;
                            case "SortBy":
                                GeneratedData = tmsCommon.GenerateData(values);
                                SelectElement PBP = new SelectElement(RSM.MemberMissingHCC.SortBy);
                                PBP.SelectByText(GeneratedData);
                                break;
                        }
                    }
                    break;
                case "Member Missing RX HCC":
                    {
                        switch (DropDownName)
                        {
                            case "PlanID":
                                if (values.ToLower() == "single")
                                {
                                    xpathstring = "//multiselect/div/ul/li[2]/a";
                                    fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                    obj.SelectDropDownValues(xpathstring);
                                }
                                else
                                {
                                    for (int i = 2; i < 3; i++)
                                    {
                                        xpathstring = "//multiselect/div/ul/li[" + i + "]/a";
                                        fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                        obj.SelectDropDownValues(xpathstring);
                                    }
                                }
                                break;
                            case "PaymentYear":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PaymentYear = new SelectElement(RSM.MemberMissingHCC.PaymentYear);
                                    PaymentYear.SelectByText(GeneratedData);
                                }
                                break;

                            case "PBP":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PBP_value = new SelectElement(RSM.MemberMissingHCC.PBP);
                                    PBP_value.SelectByIndex(0);
                                }
                                break;
                            case "SortBy":
                                GeneratedData = tmsCommon.GenerateData(values);
                                SelectElement PBP = new SelectElement(RSM.MemberMissingHCC.SortBy);
                                PBP.SelectByText(GeneratedData);
                                break;
                        }
                    }
                    break;
                case "HCC Details Blended":
                    {
                        switch (DropDownName)
                        {
                            case "PlanID":
                                if (values.ToLower() == "single")
                                {
                                    xpathstring = "//multiselect/div/ul/li[2]/a";
                                    fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                    obj.SelectDropDownValues(xpathstring);
                                }
                                else
                                {
                                    for (int i = 2; i < 3; i++)
                                    {
                                        xpathstring = "//multiselect/div/ul/li[" + i + "]/a";
                                        fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                        obj.SelectDropDownValues(xpathstring);
                                    }
                                }
                                break;
                            case "PaymentYear":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PaymentYear = new SelectElement(RSM.HCCDetailsBlended.PaymentYear);
                                    PaymentYear.SelectByText(GeneratedData);
                                }
                                break;
                            case "YearType":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement YearType = new SelectElement(RSM.HCCDetailsBlended.YearType);
                                    YearType.SelectByText(GeneratedData);
                                }
                                break;
                            case "PBP":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement PBP = new SelectElement(RSM.HCCDetailsBlended.PBP);
                                    PBP.SelectByIndex(0);
                                }
                                break;

                            case "SortBy":
                                foreach (string value in valuesFromDD)
                                {
                                    GeneratedData = tmsCommon.GenerateData(value);
                                    SelectElement SortBy = new SelectElement(RSM.HCCDetailsBlended.SortBy);
                                    SortBy.SelectByText(GeneratedData);
                                }
                                break;
                        }
                    }
                    break;
                case "Diagnosis Alert Details PartC":
                    switch (DropDownName)
                    {
                        case "PlanID":
                            if (values.ToLower() == "single")
                            {
                                xpathstring = "//multiselect/div/ul/li[2]/a";
                                fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                obj.SelectDropDownValues(xpathstring);
                            }
                            else
                            {
                                for (int i = 2; i < 3; i++)
                                {
                                    xpathstring = "//multiselect/div/ul/li[" + i + "]/a";
                                    fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
                                    obj.SelectDropDownValues(xpathstring);
                                }
                            }
                            break;
                        case "PaymentYear":
                            foreach (string value in valuesFromDD)
                            {
                                GeneratedData = tmsCommon.GenerateData(value);
                                SelectElement PaymentYear = new SelectElement(RSM.DiagnosisAlertDetailsPartC.PaymentYear);
                                PaymentYear.SelectByText(GeneratedData);
                            }
                            break;
                    }
                    break;

                case "Risk Score Estimated Receivable":
                    switch (DropDownName)
                    {
                        case "PlanID":
                            SelectElement select = new SelectElement(RSM.RiskScoreEstimatedReceivable.PlanID);
                            select.SelectByText(values);
                            break;
                        case "PaymentYear":
                            foreach (string value in valuesFromDD)
                            {
                                GeneratedData = tmsCommon.GenerateData(value);
                                SelectElement PaymentYear = new SelectElement(RSM.RiskScoreEstimatedReceivable.PaymentYear);
                                PaymentYear.SelectByText(GeneratedData);
                            }
                            break;
                    }
                    break;
            }
        }

        [Then(@"Risk Score Trend Details Report ""(.*)"" Dropdown is set to ""(.*)""")]
        [When(@"Risk Score Trend Details Report ""(.*)"" Dropdown is set to ""(.*)""")]
        public void WhenRiskScoreTrendDetailsReportDropdownIsSetTo(string filterName, string valueToSet)
        {
            string dropdown = filterName.ToString();
            string value = valueToSet;

            switch (dropdown.ToLower().Trim())
            {
                case "payment year":
                    if (value.ToLower().Trim() == "current year")
                    {
                        //DateTime today = DateTime.Today;
                        //value = today.Year.ToString();
                        value = DateTime.Now.ToString("yyyy");
                    }
                    SelectElement year = new SelectElement(RSM.RiskScoreTrendDetails.PaymentYear);
                    year.SelectByText(value);
                    break;
                case "raft":
                    SelectElement RaftType = new SelectElement(RSM.RiskScoreTrendDetails.RAFT);
                    RaftType.SelectByText(value);
                    break;
                case "enrollment":
                    SelectElement Enrollment = new SelectElement(RSM.RiskScoreTrendDetails.Enrollment);
                    Enrollment.SelectByText(value);
                    break;
                case "sort by":
                    SelectElement SortBy = new SelectElement(RSM.RiskScoreTrendDetails.SortBy);
                    SortBy.SelectByText(value);
                    break;

            }
        }

        [Then(@"Verify New Pagination is getting displayed")]
        public void ThenVerifyNewPaginationIsGettingDisplayed()
        {
            tmsWait.Hard(5);
            IWebElement pagination = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));

            Assert.IsTrue(pagination.Displayed, "Pagination is not getting displayed");
        }


        [When(@"Member Search Criteria ""(.*)"" value is set to ""(.*)""")]
        [Then(@"Member Search Criteria ""(.*)"" value is set to ""(.*)""")]
        public void WhenMemberSearchCriteriaValueIsSetTo(string fieldName, string valueToSet)
        {
            string GeneratedData = tmsCommon.GenerateData(valueToSet);

            switch (fieldName)
            {
                case "HICNumber":
                    tmsWait.Hard(5);

                    bool isdisplayed = RSM.Lookups.HICLookUp.HIC.Displayed;
                    RSM.Lookups.HICLookUp.HIC.Click();
                    RSM.Lookups.HICLookUp.HIC.SendKeys(GeneratedData);
                    break;
                case "Member ID":
                    RSM.Lookups.HICLookUp.MemberID.SendKeys(GeneratedData);
                    break;
                case "Last Name":
                    RSM.Lookups.HICLookUp.LastName.SendKeys(GeneratedData);
                    break;
                case "First Name":
                    RSM.Lookups.HICLookUp.FirstName.SendKeys(GeneratedData);
                    break;
                case "Name":

                    break;
                case "RESET":
                    {
                        if (valueToSet.Equals("Clicked"))
                        {
                            if (RSM.Lookups.HICLookUp.HICReset.Displayed) RSM.Lookups.HICLookUp.HICReset.Click();
                            else Assert.Fail("Reset button is not shown at Lookup page");
                        }
                    }
                    break;
                case "SEARCH":
                    {
                        tmsWait.Hard(6);
                        if (valueToSet.Equals("Clicked"))
                        {
                            //if (RSM.Lookups.HICLookUp.HICSearch.Displayed)
                            RSM.Lookups.HICLookUp.HICSearch.Click();
                            //else Assert.Fail("Search button is not shown at Lookup page");
                        }
                    }
                    break;
                case "Back To Record":
                    {
                        if (valueToSet.Equals("Clicked"))
                        {
                            if (RSM.Lookups.HICLookUp.HICBackToRecord.Displayed)
                            {
                                tmsWait.Hard(3);
                                RSM.Lookups.HICLookUp.HICBackToRecord.Click();
                            }
                            else Assert.Fail("Back To Record button is not shown at Lookup page");
                        }
                    }
                    break;
            }
            tmsWait.Hard(5);
        }



        [Then(@"Verify the RX HCC dropdown should be disabled")]
        public void ThenVerifyTheRXHCCDropdownShouldBeDisabled()
        {
            IWebElement RXHCC = RSM.HCCDetails.RXHCC;
            string RXHCC_disabled = RXHCC.GetAttribute("disabled");
            Assert.AreEqual(RXHCC_disabled, "true", "Rx HCC drop down is enabled");
        }

        [Then(@"Verify the HCC dropdown should be disabled")]
        public void ThenVerifyTheHCCDropdownShouldBeDisabled()
        {
            IWebElement HCC = RSM.HCCDetails.HCC;
            string HCC_disabled = HCC.GetAttribute("disabled");
            Assert.AreEqual(HCC_disabled, "true", "HCC drop down is enabled");
        }


        [When(@"""(.*)"" Page Size text box is set to ""(.*)""")]
        public void WhenPageSizeTextBoxIsSetTo(string lookupPage, int pageSize)
        {
            if (lookupPage == "Member Search Criteria")
            {

                RSM.Lookups.HICLookUp.pageSizeTextbox.Clear();
                tmsWait.Hard(5);
                //string jQuery = "pageChangedMemberGrd().get();";
                //string jQuery = "document.getElementsByClass('ng-valid.ng-dirty.ng-touched').value";
                //var value = fw.ExecuteJavascript1(jQuery);
                //tmsWait.Hard(4);
                RSM.Lookups.HICLookUp.pageSizeTextbox.SendKeys("5");
                //System.Windows.Forms.SendKeys.SendWait("{ENTER}");
                string txt = RSM.Lookups.HICLookUp.pageSizeTextbox.Text;
                tmsWait.Hard(2);
            }

        }
        public bool PaginationPageLinkStatus(IWebElement pageSystem, string PageClass)
        {
            ICollection<IWebElement> pageLIs = pageSystem.FindElements(By.TagName("li"));
            foreach (IWebElement thisLI in pageLIs)
            {
                if (thisLI.Displayed)
                {
                    string thisPageClass = thisLI.GetAttribute("class");
                    if (thisLI.GetAttribute("class") == PageClass)
                    {
                        if (thisLI.GetAttribute("class").Contains("disabled"))
                            return true;
                    }
                }

            }
            return false;
        }



        [Then(@"Verify ""(.*)"" page Pagination ""(.*)"" link is ""(.*)""")]

        public void ThenVerifyPagePaginationLinkIs(string lookuPage, string linkName, string valueToCheck)
        {
            TablePaging thisTP = new TablePaging();
            IWebElement paginationSystem = null;
            switch (lookuPage)
            {
                case "Member Search Criteria":
                    paginationSystem = RSM.Lookups.HICLookUp.HICLookupPagination;
                    switch (linkName)
                    {
                        case "First":

                            if (valueToCheck == "enabled")
                            { if (PaginationPageLinkStatus(paginationSystem, "pagination-first ng-scope") == false) Console.Write(linkName + "is enabled"); }

                            if (valueToCheck == "disabled")
                            { if (PaginationPageLinkStatus(paginationSystem, "pagination-first ng-scope disabled")) Console.Write(linkName + "is Disabled"); }
                            break;

                        case "Previous":
                            if (valueToCheck == "enabled")
                            { if (PaginationPageLinkStatus(paginationSystem, "pagination-prev ng-scope") == false) Console.Write(linkName + "is enabled"); }

                            if (valueToCheck == "disabled")
                            { if (PaginationPageLinkStatus(paginationSystem, "pagination-prev ng-scope disabled")) Console.Write(linkName + "is Disabled"); }
                            break;
                        case "Next":

                            if (valueToCheck == "enabled")
                            { if (PaginationPageLinkStatus(paginationSystem, "pagination-next ng-scope") == false) Console.Write(linkName + "is enabled"); }

                            if (valueToCheck == "disabled")
                            { if (PaginationPageLinkStatus(paginationSystem, "pagination-next ng-scope disabled")) Console.Write(linkName + "is Disabled"); }
                            break;
                        case "Last":

                            if (valueToCheck == "enabled")
                            { if (PaginationPageLinkStatus(paginationSystem, "pagination-last ng-scope") == false) Console.Write(linkName + "is enabled"); }

                            if (valueToCheck == "disabled")
                            { if (PaginationPageLinkStatus(paginationSystem, "pagination-last ng-scope disabled")) Console.Write(linkName + "is Disabled"); }
                            break;
                    }
                    break;
            }
        }

        [Then(@"""(.*)"" page Pagination ""(.*)"" link is clicked")]
        public void ThenPagePaginationLinkIsClicked(string lookuPage, string linkName)
        {
            switch (lookuPage)
            {
                case "Member Search Criteria":
                    switch (linkName)
                    {
                        case "First":
                            RSM.Lookups.HICLookUp.HICLookupPaginationFirst.Click();
                            break;
                        case "Previous":
                            RSM.Lookups.HICLookUp.HICLookupPaginationPrevious.Click();
                            break;
                        case "Next":
                            RSM.Lookups.HICLookUp.HICLookupPaginationNext.Click();
                            break;
                        case "Last":
                            RSM.Lookups.HICLookUp.HICLookupPaginationLast.Click();
                            break;
                    }

                    break;
            }
        }
        [Then(@"Verify ""(.*)"" user is a last page when Last button is clicked for page size ""(.*)""")]
        public void ThenVerifyUserIsALastPageWhenLastButtonIsClickedForPageSize(string lookupPage, int pageSize)
        {
            IWebElement Pagenumber = null;
            switch (lookupPage)
            {
                case "Member Search Criteria":
                    Pagenumber = RSM.Lookups.HICLookUp.HCILookupPagenumber;
                    break;
            }
            string value = Pagenumber.Text;
            int currentPageNumber = 0;
            int totalItems = 0;
            char[] delim1 = { '(' };
            char[] delim2 = { ' ' };
            string[] values = value.Split(delim1);
            string[] pagenumbervalues = values[0].Split(delim2);
            string[] totalItem = values[1].Split(delim2);
            int numVal = Int32.Parse("-105");
            currentPageNumber = Int32.Parse(pagenumbervalues[2]);
            totalItems = Int32.Parse(totalItem[0]);
            int TotalAppItems = Convert.ToInt32(currentPageNumber * pageSize);
            int var = TotalAppItems.CompareTo(totalItems);
            Assert.IsTrue(var == 0, "total number of rows displayed is not equal to the total number of items");
        }

        [When(@"From ""(.*)"" look up page Search button from look up page is clicked")]
        [When(@"""(.*)"" look up page Search button from look up page is clicked")]
        [Then(@"""(.*)"" look up page Search button from look up page is clicked")]
        [Then(@"""(.*)"" look up page Search button from look up page is clicked")]
        public void ThenLookUpPageSearchButtonFromLookUpPageIsClicked(string p0)
        {
            string inputValue = p0.ToString();
            switch (inputValue)
            {
                case "PCP":
                    fw.ExecuteJavascript(RSM.Lookups.PCPLookUp.PCPLookupSearch);
                    break;
                case "SCC":
                    fw.ExecuteJavascript(RSM.Lookups.SCCLookUp.SCCSearch);
                    break;
                case "GroupId":
                    fw.ExecuteJavascript(RSM.Lookups.GroupIDLookUp.GroupSearch);
                    break;
                case "HCC":
                    fw.ExecuteJavascript(RSM.Lookups.HCCLookUp.HCCSearchButton);
                    break;
                case "RXHCC":
                    fw.ExecuteJavascript(RSM.Lookups.RXHCCLookUp.RXHCCSearchButton);
                    break;
                case "HIC":
                    fw.ExecuteJavascript(RSM.Lookups.HICLookUp.HICSearch);
                    break;
            }
            tmsWait.Hard(10);
        }


        [When(@"""(.*)"" Report page Run Report button clicked")]
        public void WhenReportPageRunReportButtonClicked(string p0)
        {
            switch (p0.ToLower())
            {
                case "RX HCC Beneficiaries":
                    RSM.RXHCCBeneficiaries.RunReport.Click();
                    break;
                case "HCC Details Blended":
                    RSM.HCCDetailsBlended.RunReport.Click();
                    break;
            }

        }


        [When(@"Report page ""(.*)"" look up icon is clicked")]
        public void WhenReportPageLookUpIconIsClicked(string p0)
        {
            tmsWait.Hard(10);
            string lookup = p0.ToString().ToLower();

            switch (lookup)
            {
                case "groupid":
                    fw.ExecuteJavascript(RSM.LookupsIcons.GruopIDLookupicon);
                    break;
                case "pcp":
                    fw.ExecuteJavascript(RSM.LookupsIcons.PCPLookupicon);
                    break;
                case "hic":
                    fw.ExecuteJavascript(RSM.LookupsIcons.HICLookupicon);
                    break;
                case "scc":
                    fw.ExecuteJavascript(RSM.LookupsIcons.SCCLookupicon);

                    break;

            }
        }



        [Then(@"Verify the ""(.*)"" look up page is displayed with ""(.*)"" field name")]
        public void ThenVerifyTheLookUpPageIsDisplayedWithFieldName(string p0, string p1)
        {
            string lookupPageName = p0.ToString();
            string inputfieldactualName = p1.ToString();
            string ExpectedfieldName;
            switch (lookupPageName)
            {
                case "SCC Search Criteria":
                    switch (inputfieldactualName)
                    {
                        case "SCC:":
                            ExpectedfieldName = RSM.Lookups.SCCLookUp.sccText.Text.ToString();
                            Assert.AreEqual(ExpectedfieldName, inputfieldactualName, "Both values are matched");
                            break;
                        case "County:":
                            ExpectedfieldName = RSM.Lookups.SCCLookUp.CountyText.Text.ToString();
                            Assert.AreEqual(ExpectedfieldName, inputfieldactualName, "Both values are matched");
                            break;
                        case "State Name:":
                            ExpectedfieldName = RSM.Lookups.SCCLookUp.StateNameText.Text.ToString();
                            Assert.AreEqual(ExpectedfieldName, inputfieldactualName, "Both values are matched");
                            break;
                    }
                    break;
                case "HIC":
                    break;
            }
        }

        [Then(@"Verify the ""(.*)"" look up page is displayed with ""(.*)"" button name")]
        public void ThenVerifyTheLookUpPageIsDisplayedWithButtonName(string p0, string p1)
        {
            string lookupPageName = p0.ToString();
            string inputfieldactualName = p1.ToString();
            switch (lookupPageName)
            {
                case "Search":
                    Assert.IsTrue(RSM.Lookups.SCCLookUp.SCCSearch.Displayed, "Search is not displayed");
                    break;
                case "Reset":
                    Assert.IsTrue(RSM.Lookups.SCCLookUp.SCCReset.Displayed, "Reset is not displayed");
                    break;
                case "Back To record":
                    Assert.IsTrue(RSM.Lookups.SCCLookUp.SCCBackToRecord.Displayed, "BackToRecord is not displayed");
                    break;
            }
        }

        [Then(@"Verify Group Search Criteria page ""(.*)"" field is displayed")]
        public void ThenVerifyGroupSearchCriteriaPageFieldIsDisplayed(string p0)
        {


            string field = p0.ToString();
            bool visiblity;

            switch (field)
            {

                case "Group Name":
                    visiblity = RSM.Lookups.GroupIDLookUp.Groupname.Displayed;
                    Assert.IsTrue(visiblity, field + " Is not displayed");
                    break;
                case "Group ID":
                    visiblity = RSM.Lookups.GroupIDLookUp.GroupID.Displayed;
                    Assert.IsTrue(visiblity, field + " Is not displayed");
                    break;
                case "Reset button":
                    visiblity = RSM.Lookups.GroupIDLookUp.GroupReset.Displayed;
                    Assert.IsTrue(visiblity, field + " Is not displayed");
                    break;
                case "Search button":
                    visiblity = RSM.Lookups.GroupIDLookUp.GroupSearch.Displayed;
                    Assert.IsTrue(visiblity, field + " Is not displayed");
                    break;
                case "Back to Record":
                    visiblity = RSM.Lookups.GroupIDLookUp.GroupLoookBackToRecord.Displayed;
                    Assert.IsTrue(visiblity, field + " Is not displayed");
                    break;

            }

        }


        [Then(@"Verify RX HCC Search Criteria page ""(.*)"" field is displayed")]
        public void ThenVerifyRXHCCSearchCriteriaPageFieldIsDisplayed(string p0)
        {
            string field = p0.ToString();
            bool visiblity;

            switch (field)
            {

                case "RX HCC Name":
                    visiblity = RSM.Lookups.RXHCCLookUp.RXHCCName.Displayed;
                    Assert.IsTrue(visiblity, field + " Is not displayed");
                    break;
                case "RX HCC Description":
                    visiblity = RSM.Lookups.RXHCCLookUp.RXHCCDescription.Displayed;
                    Assert.IsTrue(visiblity, field + " Is not displayed");
                    break;
                case "Reset button":
                    visiblity = RSM.Lookups.RXHCCLookUp.RXHCCResetButton.Displayed;
                    Assert.IsTrue(visiblity, field + " Is not displayed");
                    break;
                case "Search button":
                    visiblity = RSM.Lookups.RXHCCLookUp.RXHCCSearchButton.Displayed;
                    Assert.IsTrue(visiblity, field + " Is not displayed");
                    break;
                case "Back to Record":
                    visiblity = RSM.Lookups.RXHCCLookUp.RXHCCLoookupBackToRecord.Displayed;
                    Assert.IsTrue(visiblity, field + " Is not displayed");
                    break;
                case "Payment Year":
                    visiblity = RSM.Lookups.RXHCCLookUp.RXHCCPaymentYearDrpdownlist.Displayed;
                    Assert.IsTrue(visiblity, field + " Is not displayed");
                    break;
            }

        }

        [When(@"HCC Details page ""(.*)"" look up icon clicked")]
        public void WhenHCCDetailsPageLookUpIconClicked(string field)
        {
            switch (field)
            {
                case "GroupID":
                    fw.ExecuteJavascript(RSM.HCCDetails.GroupID);
                    break;

            }
        }

        [Then(@"Group Search Criteria page ""(.*)"" field is set to ""(.*)""")]
        public void ThenGroupSearchCriteriaPageFieldIsSetTo(string p0, string p1)
        {
            string field = p0.ToString();
            string value = tmsCommon.GenerateData(p1);
            switch (field)
            {

                case "Group ID":
                    RSM.Lookups.GroupIDLookUp.GroupID.Clear();
                    RSM.Lookups.GroupIDLookUp.GroupID.SendKeys(value);
                    break;
                case "Group Name":
                    RSM.Lookups.GroupIDLookUp.Groupname.Clear();
                    RSM.Lookups.GroupIDLookUp.Groupname.SendKeys(value);
                    break;
            }
        }

        [Then(@"Group Search Criteria page Back To Record button is Clicked")]
        public void ThenGroupSearchCriteriaPageBackToRecordButtonIsClicked()
        {
            fw.ExecuteJavascript(RSM.Lookups.GroupIDLookUp.GroupLoookBackToRecord);
        }


        [Then(@"Verify HCC Details page ""(.*)"" field value is set to ""(.*)""")]
        public void ThenVerifyHCCDetailsPageFieldValueIsSetTo(string p0, string names)
        {
            string field = p0.ToString();
            string[] namesArray = names.Split(',');
            bool elementpresence = false;
            switch (field)
            {
                case "Group ID":
                    if ((namesArray.Length == 1) && (namesArray[0].Equals("")))
                    {
                        elementpresence = true;

                        Assert.IsTrue(elementpresence);
                        fw.ConsoleReport(" There is no Element Present");

                    }
                    else if (namesArray.Length >= 1)
                    {

                        foreach (string name in namesArray)
                        {

                            elementpresence = Browser.Wd.FindElement(By.XPath("//*[@test-id='GROUP']//ul/li[contains(.,'" + name + "')]")).Displayed;
                            Assert.IsTrue(elementpresence, name + " is not Found");
                            fw.ConsoleReport(name + " is Found");

                        }
                    }
                    break;


            }

        }




        [Given(@"variable ""(.*)"" from RSM database is set to ""(.*)""")]
        public void GivenVariableFromRSMDatabaseIsSetTo(string p0, string p1)
        {
            string MemberID = Browser.ExecuteSingleQuery(p1, ConfigFile.RSMdb, 1, 0);
            fw.setVariable(p0, MemberID);
        }



        // generic function written to verify the title or text validation from page
        [Then(@"Verify TMS ""(.*)"" page is displayed")]
        [Then(@"Verify Title text ""(.*)"" page is displayed")]
        [Given(@"Verify TMS ""(.*)"" page is displayed")]
        public void ThenVerifyLookUpPageIsDisplayed(string p0)
        {
            String actual;
            tmsWait.Hard(10);
            // string title = p0.ToString();
            string expected = p0.ToString();
            switch (expected)
            {
                case "Group Search Criteria":
                    actual = RSM.Lookups.GroupIDLookUp.GrouppageTitle.Text;
                    Assert.AreEqual(expected, actual, " Both values are getting matched");
                    break;

                case "Medicare Solutions | Risk Score Manager":
                    actual = RSM.RSMHomePage.RSMHeading.Text;
                    Assert.AreEqual(expected, actual, " Both values are getting matched");
                    break;
                case "SCC Search Criteria":
                    actual = RSM.Lookups.SCCLookUp.SCCTitle.Text;
                    Assert.AreEqual(expected, actual, " Both values are getting matched");
                    break;
                case "PCP Search Criteria":
                    actual = RSM.Lookups.PCPLookUp.PCPpageTitle.Text;
                    Assert.AreEqual(expected, actual, " Both values are getting matched");
                    break;
                case "HCC Search Criteria":
                    actual = RSM.Lookups.HCCLookUp.HCCLoookupTitle.Text;
                    Assert.AreEqual(expected, actual, " Both values are getting matched");
                    break;
                case "RxHCC Search Criteria":
                    actual = RSM.Lookups.RXHCCLookUp.RxHCCLoookupTitle.Text;
                    Assert.AreEqual(expected, actual, " Both values are getting matched");
                    break;
                case "Member Search Criteria":
                    actual = RSM.Lookups.HICLookUp.HICTitle.Text.Trim();
                    Assert.AreEqual(expected, actual, " Both values are getting matched");
                    break;
                case "Member Discrepancy":
                    actual = RSM.MemberDiscrepancy.Title.Text.Trim();
                    Assert.AreEqual(expected, actual, " Both values are not getting matched");
                    break;
                case "RAPS Drill-Down - Clinical RXHCC15":
                    actual = RSM.MemberDiscrepancy.RapsDrillDownTitle.Text.Trim();
                    Assert.AreEqual(expected, actual, " Both values are not getting matched");
                    break;
            }
            tmsWait.Hard(10);
        }

        [When(@"Data load Summary page Begin Date is selected as ""(.*)""")]
        public void WhenDataLoadSummaryPageBeginDateIsSelectedAs(string p0)
        {
            DateTime date = DateTime.Now;
            string currentDate = date.ToString("MM/dd/yyyy");
            tmsWait.Hard(2);
            fw.ExecuteJavascriptSetText(RSM.OtherReport.BeginDate, currentDate);
        }

        [When(@"Data load Summary page New End Date is selected as ""(.*)""")]
        public void WhenDataLoadSummaryPageNewEndDateIsSelectedAs(string p0)
        {
            fw.ExecuteJavascriptSetText(RSM.OtherReport.EndDate, p0);
        }


        [When(@"Data load Summary page End Date is selected as ""(.*)""")]
        public void WhenDataLoadSummaryPageEndDateIsSelectedAs(string p0)
        {
            DateTime date = DateTime.Now;
            DateTime firstDayOfMonth = new DateTime(date.Year, date.Month, 1);
            string startDate = firstDayOfMonth.ToString("MM/dd/yyyy");
            tmsWait.Hard(2);
            fw.ExecuteJavascriptSetText(RSM.OtherReport.EndDate, startDate);
        }


        [When(@"Report page Error message is displayed as ""(.*)""")]
        public void WhenReportPageErrorMessageIsDisplayedAs(string error)
        {
            tmsWait.Hard(2);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + error + "')]")).Displayed);
        }


        [When(@"Report page Planid ""(.*)"" is selected")]
        public void WhenReportPagePlanidIsSelected(string p0)
        {
            SelectElement pid = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@test-id='Plan_Number']")));
            pid.SelectByText(p0);
        }




        [When(@"ClusterStatusSummary Report page Planid ""(.*)"" is selected")]
        public void WhenClusterStatusSummaryReportPagePlanidIsSelected(string p0)
        {
            SelectElement pid = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@test-id='PlanNumberValue']")));
            pid.SelectByText(p0);
        }


        [When(@"Report page ProviderType ""(.*)"" is selected")]
        public void WhenReportPageProviderTypeIsSelected(string p0)
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//button[@title='ALL'])[1]")));
            tmsWait.Hard(1);
            switch (p0.ToUpper())
            {
                case "I":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//ul[@class='dropdown-menu']//li[2]/a)[1]")));
                    break;
                case "O":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//ul[@class='dropdown-menu']//li[3])[1]")));
                    break;
                case "P":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//ul[@class='dropdown-menu']//li[4])[1]")));
                    break;
            }

            tmsWait.Hard(1);
        }

    }
}

