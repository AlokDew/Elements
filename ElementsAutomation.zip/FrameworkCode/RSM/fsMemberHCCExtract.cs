﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Support.UI;
using TechTalk.SpecFlow;

namespace TMSoR1
{
    [Binding]
    class fsMemberHCCExtract
    {
        [When(@"Member HCC Extract ""(.*)"" button is clicked")]
        public void WhenMemberHCCExtractButtonIsClicked(string action)
        {
            switch (action.ToLower())
            {
                case "export":
                    fw.ExecuteJavascript(RSM.RSMMemberHCCExtract.Export);
                    break;
                case "reset":
                    RSM.RSMMemberHCCExtract.Reset.Click();
                    break;
            }
        }

        [When(@"RSM Member HCC Extract ""(.*)"" is selected as ""(.*)""")]
        public void WhenRSMMemberHCCExtractIsSelectedAs(string criteria, string value)
        {
            tmsWait.Hard(5);
            switch (criteria.ToLower())
            {
                case "plan id":
                    SelectElement planidSelect = new SelectElement(RSM.RSMMemberHCCExtract.PlanID);
                    planidSelect.SelectByIndex(1);
                    break;
                case "payment year":
                    SelectElement payementYearSelect = new SelectElement(RSM.RSMMemberHCCExtract.PaymentYear);
                    payementYearSelect.SelectByIndex(1);
                    break;
            }
        }


        [When(@"Member HCC Extract ""(.*)"" is selected as ""(.*)""")]
        public void WhenMemberHCCExtractIsSelectedAs(string criteria, string value)
        {
            tmsWait.Hard(5);
            switch(criteria.ToLower())
            {
                case "plan id":
                    SelectElement planidSelect = new SelectElement(RSM.RSMMemberHCCExtract.PlanID);
                    planidSelect.SelectByText(value);
                    break;
                case "payment year":
                    SelectElement payementYearSelect = new SelectElement(RSM.RSMMemberHCCExtract.PaymentYear);
                    payementYearSelect.SelectByText(value);
                    break;
            }
        }


        [Then(@"An information message ""(.*)"" for Export should be displayed")]
        public void ThenAnInformationMessageForExportShouldBeDisplayed(string message)
        {
            if (RSM.RSMMemberHCCExtract.MessageLable.Text.Contains(message))
            {
                Assert.IsTrue(true, "Message is correct");
            }
            else if(RSM.RSMMemberHCCExtract.MessageLable.Text.Contains("Export Job is requested on"))
            {
                Assert.IsTrue(true, "Export job is requested");
            }
            else
            {
                Assert.IsFalse(true, "Message is incorrect");
            }
        }

    }
}
