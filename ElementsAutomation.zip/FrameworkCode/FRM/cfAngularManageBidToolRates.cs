﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using TechTalk.SpecFlow;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using System.Diagnostics;
using System.Windows;


namespace TMSoR1
{
    [Binding]
    public class cfAngularManageBidToolRates
    {
        public static ManageBidToolRates ManageBidToolRates { get { return new ManageBidToolRates(); } }
        public static PartCBidRatesGrid PartCBidRatesGrid { get { return new PartCBidRatesGrid(); } }
        public static PartDBidRatesGrid PartDBidRatesGrid { get { return new PartDBidRatesGrid(); } }
        public static PartCMemberPremiumGrid PartCMemberPremiumGrid { get { return new PartCMemberPremiumGrid(); } }
    }

    [Binding]
    public class PartCMemberPremiumGrid
    {
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Plan Id')]/parent::div/div)[2]")); } }
        public IWebElement PBP { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'PBP')]/parent::div/div)[2]")); } }
        public IWebElement SegmentID { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Segment Id')]/parent::div/div)[2]")); } }
        public IWebElement BasicPremium { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Basic Premium')]/parent::div/div)[1]")); } }

        public IWebElement DBuyDownSupply { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'D Buy Down Supply')]/parent::div/div)[1]")); } }
        public IWebElement ABMandSuppl { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'AB Mand Suppl')]/parent::div/div)[1]")); } }
        public IWebElement PartBBuyDown { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Part B Buy Down')]/parent::div/div)[1]")); } }
        public IWebElement PartDBuyDown { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Part D Buy Down')]/parent::div/div)[1]")); } }
        public IWebElement ReduceABCostShare { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'CostShare')]/parent::div/div)[1]")); } }

        public IWebElement EffectiveDate { get { return Browser.Wd.FindElement(By.XPath("(//kendo-datepicker//span[@role='button'])[1]")); } }

        public IWebElement ExpiryDate { get { return Browser.Wd.FindElement(By.XPath("(//kendo-datepicker//span[@role='button'])[2]")); } }


    }

    [Binding]
    public class PartDBidRatesGrid
    {
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Plan Id')]/parent::div/div)[3]")); } }
        public IWebElement PBP { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'PBP')]/parent::div/div)[3]")); } }

        public IWebElement DrugBidType { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Drug Bid Type')]/parent::div/div)[1]")); } }
        public IWebElement BidAmountat { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Bid Amount at')]/parent::div/div)[1]")); } }
        public IWebElement ReinsuranceatPlanRisk { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Reinsurance at Plan Risk')]/parent::div/div)[1]")); } }

        public IWebElement LICSatPlanRisk { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'LICS at Plan Risk')]/parent::div/div)[1]")); } }

        public IWebElement Non_RoundedBasicPremium { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Non-Rounded Basic Premium')]/parent::div/div)[1]")); } }
        public IWebElement Non_RoundedSupplPremium { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Non-Rounded Suppl Premium')]/parent::div/div)[1]")); } }

        public IWebElement CoverageGapDiscountAmount { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Coverage Gap Discount Amount')]/parent::div/div)[1]")); } }

        public IWebElement EffectiveDate { get { return Browser.Wd.FindElement(By.XPath("(//kendo-datepicker//span[@role='button'])[1]")); } }

        public IWebElement ExpiryDate { get { return Browser.Wd.FindElement(By.XPath("(//kendo-datepicker//span[@role='button'])[2]")); } }
    }

    [Binding]
    public class PartCBidRatesGrid
    {
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Plan Id')]/parent::div/div)[1]")); } }
        public IWebElement PBP { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'PBP')]/parent::div/div)[1]")); } }

        public IWebElement SegmentID { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Segment Id')]/parent::div/div)[1]")); } }
        public IWebElement SCC { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'SCC')]/parent::div/div)[1]")); } }
        public IWebElement AgedPartA { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Aged Part A')]/parent::div/div)[1]")); } }

        public IWebElement AgedPartB { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Aged Part B')]/parent::div/div)[1]")); } }

        public IWebElement DisabledPartA { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Disabled Part A')]/parent::div/div)[1]")); } }
        public IWebElement DisabledPartB { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Disabled Part B')]/parent::div/div)[1]")); } }

        public IWebElement PartA { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Part A')]/parent::div/div)[3]")); } }

        public IWebElement PartB { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Part B')]/parent::div/div)[3]")); } }
        public IWebElement EffectiveDate { get { return Browser.Wd.FindElement(By.XPath("(//kendo-datepicker//span[@role='button'])[1]")); } }

        public IWebElement ExpiryDate { get { return Browser.Wd.FindElement(By.XPath("(//kendo-datepicker//span[@role='button'])[2]")); } }
    }

    [Binding]
    public class ManageBidToolRates
    {
        public IWebElement PartCBidRatesTAB { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Part C Bid Rates')]")); } }
        public IWebElement PartCBidRatesADDBtn { get { return Browser.Wd.FindElement(By.XPath("(//button[contains(.,'ADD')])[1]")); } }
        public IWebElement PartCBidRatesEDITBtn { get { return Browser.Wd.FindElement(By.XPath("(//button[contains(.,'EDIT')])[1]")); } }
        public IWebElement PartCBidRatesREMOVEBtn { get { return Browser.Wd.FindElement(By.XPath("(//button[contains(.,'REMOVE')])[1]")); } }
        public IWebElement PartCBidRatesRESETBtn { get { return Browser.Wd.FindElement(By.XPath("(//button[contains(.,'RESET')])[1]")); } }
        public IWebElement PartCBidRatesSEARCHBtn { get { return Browser.Wd.FindElement(By.XPath("(//button[contains(.,'SEARCH')])[1]")); } }
        public IWebElement PartCBidRatesYearDropdown { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Year')]/parent::div//span[@class='k-select'])[1]")); } }
        public IWebElement PartCBidRatesPlanIDDropdown { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Plan Id')]/parent::div//span[@class='k-select'])[1]")); } }
        public IWebElement PartCBidRatesPBPDropdown { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'PBP')]/parent::div//span[@class='k-select'])[1]")); } }




        public IWebElement PartCMemberPremiumTAB { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Part C Member Premium')]")); } }
        public IWebElement PartCMemberPremiumADDBtn { get { return Browser.Wd.FindElement(By.XPath("(//button[contains(.,'ADD')])[2]")); } }
        public IWebElement PartCMemberPremiumsEDITBtn { get { return Browser.Wd.FindElement(By.XPath("(//button[contains(.,'EDIT')])[2]")); } }
        public IWebElement PartCMemberPremiumREMOVEBtn { get { return Browser.Wd.FindElement(By.XPath("(//button[contains(.,'REMOVE')])[2]")); } }
        public IWebElement PartCMemberPremiumRESETBtn { get { return Browser.Wd.FindElement(By.XPath("(//button[contains(.,'RESET')])[2]")); } }
        public IWebElement PartCMemberPremiumSEARCHBtn { get { return Browser.Wd.FindElement(By.XPath("(//button[contains(.,'SEARCH')])[2]")); } }
        public IWebElement PartCMemberPremiumYearDropdown { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Year')]/parent::div//span[@class='k-select'])[2]")); } }
        public IWebElement PartCMemberPremiumPlanIDDropdown { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Plan Id')]/parent::div//span[@class='k-select'])[2]")); } }
        public IWebElement PartCMemberPremiumPBPDropdown { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'PBP')]/parent::div//span[@class='k-select'])[2]")); } }





        public IWebElement PartDBidRatesTAB { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Part D Bid Rates')]")); } }
        public IWebElement PartDBidRatesADDBtn { get { return Browser.Wd.FindElement(By.XPath("(//button[contains(.,'ADD')])[3]")); } }
        public IWebElement PartDBidRatesEDITBtn { get { return Browser.Wd.FindElement(By.XPath("(//button[contains(.,'EDIT')])[3]")); } }
        public IWebElement PartDBidRatesREMOVEBtn { get { return Browser.Wd.FindElement(By.XPath("(//button[contains(.,'REMOVE')])[3]")); } }
        public IWebElement PartDBidRatesRESETBtn { get { return Browser.Wd.FindElement(By.XPath("(//button[contains(.,'RESET')])[3]")); } }
        public IWebElement PartDBidRatesSEARCHBtn { get { return Browser.Wd.FindElement(By.XPath("(//button[contains(.,'SEARCH')])[3]")); } }
        public IWebElement PartDBidRatesYearDropdown { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Year')]/parent::div//span[@class='k-select'])[3]")); } }
        public IWebElement PartDBidRatesPlanIDDropdown { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Plan Id')]/parent::div//span[@class='k-select'])[3]")); } }
        public IWebElement PartDBidRatesPBPDropdown { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'PBP')]/parent::div//span[@class='k-select'])[3]")); } }



        public IWebElement NewBidRatesDialogPlanID { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Plan Id')]/parent::div//input")); } }
        public IWebElement NewBidRatesDialogPBP { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'PBP')]/parent::div//input")); } }
        public IWebElement NewBidRatesDialogSegmentID { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Segment Id')]/parent::div//input")); } }
        public IWebElement NewBidRatesDialogSCC { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'SCC')]/parent::div//input")); } }
        public IWebElement NewBidRatesDialogAgedPartA { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Aged Part A')]/parent::div//input")); } }
        public IWebElement NewBidRatesDialogAgedPartB { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Aged Part B')]/parent::div//input")); } }
        public IWebElement NewBidRatesDialogDisabledPartA { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Disabled Part A')]/parent::div//input")); } }
        public IWebElement NewBidRatesDialogDisabledPartB { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Disabled Part B')]/parent::div//input")); } }
        public IWebElement NewBidRatesDialogPartA { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Part A')]/parent::div//input)[3]")); } }
        public IWebElement NewBidRatesDialogPartB { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Part B')]/parent::div//input)[3]")); } }
        public IWebElement NewBidRatesDialogDrugBidType { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Drug Bid Type')]/parent::div//input")); } }
        public IWebElement NewBidRatesDialogBidAmountat1_0 { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Bid Amount at')]/parent::div//input")); } }
        public IWebElement NewBidRatesDialogFederalReinsuranceatPlanRisk { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Federal Reinsurance at Plan Risk')]/parent::div//input")); } }
        public IWebElement NewBidRatesDialogLICSatPlanRisk { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'LICS at Plan Risk')]/parent::div//input")); } }
        public IWebElement NewBidRatesDialogNon_RoundedBasicPremium { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Non-Rounded Basic Premium')]/parent::div//input")); } }
        public IWebElement NewBidRatesDialogNon_RoundedSupplPremium { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Non-Rounded Suppl Premium')]/parent::div//input")); } }
        public IWebElement NewBidRatesDialogCoverageGapDiscountAmount { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Coverage Gap Discount Amount')]/parent::div//input")); } }

        public IWebElement NewBidRatesDialogDBuyDwnSupply { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'D BuyDwn Supply')]/parent::div//input")); } }

        public IWebElement NewBidRatesDialogABMandSuppl { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'AB Mand Suppl')]/parent::div//input")); } }

        public IWebElement NewBidRatesDialogPartBBuyDown { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Part B BuyDown')]/parent::div//input")); } }

        public IWebElement NewBidRatesDialogPartDBuyDown { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Part D BuyDown')]/parent::div//input")); } }
        public IWebElement NewBidRatesDialogReduceABCostShare { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Reduce A/B CostShare')]/parent::div//input")); } }






        public IWebElement NewBidRatesDialogEffectiveDate { get { return Browser.Wd.FindElement(By.XPath("(//kendo-datepicker//span[@role='button'])[1]")); } }
        public IWebElement NewBidRatesDialogExpiryDate { get { return Browser.Wd.FindElement(By.XPath("(//kendo-datepicker//span[@role='button'])[2]")); } }


        public IWebElement NewBidRatesDialogSAVE { get { return Browser.Wd.FindElement(By.XPath("//button[contains(.,'SAVE')]")); } }
        public IWebElement NewBidRatesDialogCANCEL { get { return Browser.Wd.FindElement(By.XPath("//button[contains(.,'CANCEL')]")); } }
        public IWebElement NewBidRatesDialogUPDATE { get { return Browser.Wd.FindElement(By.XPath("//button[contains(.,'UPDATE')]")); } }



    }



}