﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1
{
    [Binding]
    public class fsMemberPaymentSummary
    {
        [When(@"Member Payment Summary Part ""(.*)"" is clicked")]
        public void WhenMemberPaymentSummaryPartIsClicked(string part)
        {
            if (part.ToLower().Equals("c"))
            {
                FRM.FRMMemberPaymentSummary.PartC.Click();
            }
            else
            {
                FRM.FRMMemberPaymentSummary.PartD.Click();
            }
        }


        [Then(@"Verify Member Payment Summary page Payment Month Bar and Generate button are displayed")]
        public void ThenVerifyMemberPaymentSummaryPagePaymentMonthBarAndGenerateButtonAreDisplayed()
        {
            tmsWait.Hard(10);
            Assert.IsTrue(FRM.FRMMemberPaymentSummary.GenerateReport.Displayed, "Generate Report button is not displayed.");
            Assert.IsTrue(FRM.FRMMemberPaymentSummary.PaymentMonthBar.Displayed, "Payment Month bar is not displayed.");
        }


    }
}
