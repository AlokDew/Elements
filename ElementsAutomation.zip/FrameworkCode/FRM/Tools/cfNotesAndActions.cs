﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using TechTalk.SpecFlow;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using System.Diagnostics;
using System.Windows;


namespace TMSoR1
{
    [Binding]
    public class NotesAndActionsSearch
    {
        public IWebElement EnterClaimHICNumber { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_txtHICNumber")); } }
        public IWebElement OK { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_btnOK")); } }
    }
    public class NotesAndActionsCreateNewNote
    {
        public IWebElement UserName { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_uclNotesActions_tabContainer_tabDetails_drpdwnUserID")); } }
        public IWebElement Search { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_uclNotesActions_tabContainer_tabDetails_SearchNotesButton")); } }
        public IWebElement ResponseMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_uclNotesActions_tabContainer_tabDetails_lblMessage")); } }
    }
}