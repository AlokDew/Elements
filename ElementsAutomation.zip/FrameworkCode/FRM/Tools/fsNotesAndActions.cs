﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows;
using System.Drawing;
using OpenQA.Selenium.Support.UI;


namespace TMSoR1
{
    [Binding]
    public class FRMNotesAndActionsSteps
    {
        [When(@"Notes And Actions Enter Claim Hic Number is set to ""(.*)""")]
        public void WhenNotesAndActionsEnterClaimHicNumberIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            FRM.NotesAndActionsSearch.EnterClaimHICNumber.SendKeys(value);
        }
        [When(@"Notes And Actions OK button is clicked")]
        public void WhenNotesAndActionsOKButtonIsClicked()
        {
            FRM.NotesAndActionsSearch.OK.Click();
            tmsWait.Hard(1); 
        }
        [When(@"Notes And Actions User Name is set to ""(.*)""")]
        public void WhenNotesAndActionsUserNameIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(FRM.NotesAndActionsCreateNewNote.UserName);
            select.SelectByText(value);
            tmsWait.Hard(2);
        }
        [When(@"Notes And Actions Search Button is clicked")]
        public void WhenNotesAndActionsSearchButtonIsClicked()
        {
            FRM.NotesAndActionsCreateNewNote.Search.Click();
            tmsWait.Hard(2);
        }
        [Then(@"Verify Notes And Actions Response Message is ""(.*)""")]
        public void ThenVerifyNotesAndActionsResponseMessageIs(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string fieldName = "Notes And Actions Create New Note Response Message";
            string thisFieldValue = FRM.NotesAndActionsCreateNewNote.ResponseMessage.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [When(@"FRM Main page ""(.*)"" tab is Clicked")]
        public void WhenFRMMainPageTabIsClicked(string p0)
        {
            tmsWait.Hard(5);
            IWebElement link = Browser.Wd.FindElement(By.LinkText("" + p0 + ""));
            fw.ExecuteJavascript(link);
        }

        [When(@"HIC Name Search HIC is set to ""(.*)""")]
        public void WhenHICNameSearchHICIsSetTo(string p0)
        {
            IWebElement link = Browser.Wd.FindElement(By.CssSelector("[test-id='hicNameSearchCriteria-inp-txtHic']"));
            link.SendKeys(p0);

        }

        [When(@"HIC Name Search page Search button is Clicked")]
        public void WhenHICNameSearchPageSearchButtonIsClicked()
        {
            IWebElement link = Browser.Wd.FindElement(By.CssSelector("[test-id='hicNameSearchCriteria-btn-btnSearch']"));
            fw.ExecuteJavascript(link);
            tmsWait.Hard(5);
        }


        [When(@"TOP (.*) Over Under Payment section Search button is Clicked")]
        public void WhenTOPOverUnderPaymentSectionSearchButtonIsClicked(int p0)
        {
            IWebElement button = Browser.Wd.FindElement(By.CssSelector("[test-id='topFiftyPaymnts-btn-topfiftySearch']"));
            fw.ExecuteJavascript(button);
            tmsWait.Hard(5);
        }

        [When(@"Search Results ""(.*)"" button is Clicked")]
        public void WhenSearchResultsButtonIsClicked(string p0)
        {
            IWebElement button = Browser.Wd.FindElement(By.XPath("(//a[@title='"+p0+"'])[1]"));
            fw.ExecuteJavascript(button);
            tmsWait.Hard(10);
        }

        [Then(@"Verify Member Summary page ""(.*)"" link is displayed")]
        public void ThenVerifyMemberSummaryPageLinkIsDisplayed(string p0)
        {
            tmsWait.Hard(2);
            IWebElement button = Browser.Wd.FindElement(By.XPath("//div[@id='MemberSumary']//a[contains(.,'"+p0+"')]"));
            Assert.IsTrue(button.Displayed, p0 + "is not getting displayed");
        }




    }
}