﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using TechTalk.SpecFlow;

using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using System.Diagnostics;
using System.Windows;
using System.Collections.ObjectModel;


namespace TMSoR1
{

    [Binding]
    public class FRMNavigation
    {

        [When(@"I have navigated to FRM ""(.*)"" Menu")]
        public void WhenIHaveNavigatedToFRMMenu(string title)
        {
            // tmsWait.WaitForElement(By.XPath("//a[@title='" + title + "']"), 10); 
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Reports']")));
            GlobalRef.ReportName = "Reports";
        }
        [When(@"I have navigated to FRM Reports Menu")]
        public void WhenIHaveNavigatedToFRMReportsMenu()
        {
            GlobalRef.ReportName = "Reports";
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Reports']")));
        }


        public static void ClickLink(string strNavigation)
        {
            //Function is for clicking on the Navigation links.
            //
            //November 2014 - Daron Spicher
            //
            //Design is to have the user put the link in as it shows
            //in complete format from the application.
            //
            //The function then uses the Switch statement to handle the 
            //click.   In each case, we have linkTextValue.  This is 
            //the link text as you see it in the application.
            //
            //The code grabs all the links on the page which have that text.
            //A lot of them come back with 1 match.   Others have multiples.
            //For ones with multiples, we need a second identifier.
            //
            //The second identifier is the 'id', but that comes with problems too.
            //Some links have different 'id's depending on which page you are already on.
            //For that reason, each case has a string array with it.
            //
            //It would be very difficult to identify all the different possible 'id's
            //up front, so I imagine we will see a period of time when a running test case 
            //will fail on a menu navigation.   At that point, you can run the test
            //to the fail point and see what that menu item id is at that point.
            //
            //Add the id to the string array by putting a comma behind the last value, 
            //and putting the new id in the next string after.   Run again, it should work.
            string[] arrIDs = new string[] { };
            string linkTextValue = "";
            Boolean bFoundLink = false;
            Boolean bHandledInCase = false;
            switch (strNavigation)
            {
                case "Tools":
                    {
                        linkTextValue = "Tools";
                        string[] IDs = new string[]
                        {
                            "ctl00_RadMenu1_m3"
                        }; arrIDs = IDs; break;
                    }
                case "NotesandActions":
                    {
                        linkTextValue = "Notes and Actions";
                        string[] IDs = new string[]
                        {
                            "ctl00_RadMenu1_m3_m0"
                        }; arrIDs = IDs; break;
                    }
                case "ReportManager":
                    {
                        linkTextValue = "Report Manager";
                        string[] IDs = new string[]
                        {
                            "ctl00_RadMenu1_m6"
                        }; arrIDs = IDs; break;
                    }
                case "File":
                    {
                        linkTextValue = "File";
                        string[] IDs = new string[]
                        {
                            "ctl00_RadMenu1_m0"
                        }; arrIDs = IDs; break;
                    }
                case "EDIT":
                    {
                        linkTextValue = "File";
                        string[] IDs = new string[]
                        {
                            "ctl00_RadMenu1_m0"
                        }; arrIDs = IDs; break;
                    }
                case "Display Adjustment Wizard":
                    {
                        linkTextValue = "File";
                        string[] IDs = new string[]
                        {
                            "ctl00_RadMenu1_m0"
                        }; arrIDs = IDs; break;
                    }
                case "Disply Enroll/Disenroll Wizard":
                    {
                        linkTextValue = "File";
                        string[] IDs = new string[]
                        {
                            "ctl00_RadMenu1_m0"
                        }; arrIDs = IDs; break;
                    }
                default:
                    {
                        Assert.AreEqual(false, true, "The Menu item [" + strNavigation + "] was not matched");
                        break;
                    }
            }
            ReadOnlyCollection<OpenQA.Selenium.IWebElement> myCollection = Browser.Wd.FindElements(By.LinkText(linkTextValue));
            foreach (IWebElement thisElement in myCollection)
            {
                bFoundLink = false;
                try
                {
                    bFoundLink = false;
                    string strThisHref = thisElement.GetAttribute("href");
                    string strThisID = thisElement.GetAttribute("id");
                    if (myCollection.Count == 1)
                    {
                        thisElement.Click();
                        bFoundLink = true;
                        break;
                    }
                    else
                    {
                        for (int i = 0; i <= arrIDs.Length; i++)
                        {
                            if (arrIDs[i] == strThisID)
                            {
                                thisElement.Click();
                                bFoundLink = true;
                                break;
                            }
                        }
                        if (bFoundLink) { break; }
                    }
                }
                catch
                {
                }
            }
            if (!bFoundLink && !bHandledInCase)
            {
                Assert.AreEqual(bFoundLink, true, "The Menu item with link text [" + linkTextValue + "] was not matched and clicked on.");
            }
        }
    }
}