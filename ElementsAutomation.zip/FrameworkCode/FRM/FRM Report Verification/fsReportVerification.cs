﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using OpenQA.Selenium.Support.UI;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using TechTalk.SpecFlow;
using TMSoR1.FrameworkCode;

namespace TMSoR1
{
    [Binding]
    public class fsReportVerification
    {
        public string downloadPath = Path.Combine(Environment.ExpandEnvironmentVariables("%userprofile%"), "Downloads");
        [Given(@"FRM Report page ""(.*)"" report is clicked from Report List")]
        [When(@"FRM Report page ""(.*)"" report is clicked from Report List")]
        public void GivenFRMReportPageReportIsClickedFromReportList(string link)
        {
            //tmsWait.WaitForElement(By.XPath("//label[contains(.,'" + link + "')]"));
            //tmsWait.Hard(5);
            //IWebElement expandAll = Browser.Wd.FindElement(By.CssSelector("[test-id='report-button-expandcolaps']"));
            //fw.ExecuteJavascript(expandAll);
           
            tmsWait.Hard(1);
            IWebElement reportlink = Browser.Wd.FindElement(By.CssSelector("[test-id='"+ link + "']"));
            fw.ExecuteJavascript(reportlink);           
            
            //tmsWait.WaitForElement(By.CssSelector("span[test-id='report-title-searchCriteria']"));
            tmsWait.Hard(10);//wait to load for complete report page
        }


        [Given(@"Verify that ""(.*)"" and ""(.*)"" fields are blank by default")]
        public void GivenVerifyThatAndFieldsAreBlankByDefault(string p0, string p1)
        {
            var datePicker = Browser.Wd.FindElements(By.CssSelector(".ng-pristine.ng-untouched.ng-valid.ng-isolate-scope.ng-valid-date"));
            foreach (IWebElement date in datePicker)
            {
                Assert.IsTrue(date.Text.Equals(""), "Date Picker is not blank by default.");
            }
        }

        [Given(@"""(.*)"" date is entered as ""(.*)""")]
        public void GivenDateIsEnteredAs(string dateField, string date)
        {
            tmsWait.Hard(5);
            switch (dateField.ToLower())
            {
                case "payment month start":
                    fw.ExecuteJavascriptSetText(FRM.FRMReport.PaymentMonthStartDate, date);
                    //Browser.SetNewUICalendar(FRM.FRMReport.PaymentMonthStartDate, date);
                    //FRM.FRMReport.PaymentMonthStartDate.Click();
                    //tmsWait.Hard(2);
                    //Browser.Wd.FindElement(By.XPath(".//*[@id='reportsBlock']/accordion/div/div[2]/div[2]/div/div/div[5]/div/ul/li/div/table/thead/tr[1]/th[1]/button")).Click();
                    //tmsWait.Hard(2);
                    //Browser.Wd.FindElement(By.XPath("//button/span[contains(.,'07')]")).Click();
                    break;
                case "payment month end":
                    fw.ExecuteJavascriptSetText(FRM.FRMReport.PaymentMonthEndDate, date);
                    //FRM.FRMReport.PaymentMonthEndDate.Click();
                    //tmsWait.Hard(2);
                    //Browser.Wd.FindElement(By.XPath(".//*[@id='reportsBlock']/accordion/div/div[2]/div[2]/div/div/div[6]/div/ul/li/div/table/thead/tr[1]/th[1]/button")).Click();
                    //tmsWait.Hard(2);
                    //Browser.Wd.FindElement(By.XPath("//button/span[contains(.,'07')]")).Click();
                    break;
            }
        }
        

        [When(@"I store database ""(.*)"" results to the output file")]
        [Given(@"I store database ""(.*)"" results to the output file")]
        public void WhenIStoreDatabaseResultsToTheOutputFile(string p0)
        {
            List<string> list = new List<string>();
            db.StoreDBResults(p0, list);
        }

        [When(@"Payment Detail - MMR Adjustments report page compare CMS Adjustment Type with db")]
        [Given(@"Payment Detail - MMR Adjustments report page compare CMS Adjustment Type with db")]
        public void WhenPaymentDetail_MMRAdjustmentsReportPageCompareCMSAdjustmentTypeWithDb()
        {
            List<string> reasonList = new List<string>();
            IReadOnlyCollection<IWebElement> reasons = FRM.FRMReport.CMDAdjustTypeDD.FindElements(By.TagName("option"));
            foreach (var reason in reasons)
            {
                reasonList.Add(reason.Text);
            }
            List<string> dbreasonlst = (List<string>)ScenarioContext.Current["List"];

            if (!reasonList.Count.Equals(dbreasonlst.Count))
            {
                Assert.Fail("Reasons are mismatch in UI and DB");
            }
            else
            {
                for (int i = 0; i < reasonList.Count; i++)
                {
                    if (!reasonList[i].Equals(dbreasonlst[i]))
                    {
                        Assert.Fail("Reasons are mismatch in UI and DB");
                    }
                }
            }
            Assert.IsTrue(true);
        }

        [Given(@"Verify Sort Details By dropdown present with ""(.*)"" options")]
        public void GivenVerifySortDetailsByDropdownPresentWithOptions(string expectedSortOptions)
        {
            char[] separator = { ',' };
            string[] options = expectedSortOptions.Split(separator);
            List<string> optionList = new List<string>();
            IReadOnlyCollection<IWebElement> actualOptions = FRM.FRMReport.SortDetailsByeDD.FindElements(By.TagName("option"));
            foreach (var option in actualOptions)
            {
                optionList.Add(option.Text);
            }
            if (!options.Length.Equals(optionList.Count))
            {
                Assert.Fail("Sort Details options are mismatch in UI.");
            }
            else
            {
                for (int i = 0; i < optionList.Count; i++)
                {
                    if (!optionList[i].Equals(options[i]))
                    {
                        Assert.Fail(optionList[i].ToString() + " option is missing on UI...");
                    }
                }
            }
            Assert.IsTrue(true);
        }


        [Given(@"Verify Save Format displayed ""(.*)"" formats")]
        public void GivenVerifySaveFormatDisplayedFormats(string expectedSaveFormats)
        {
            char[] separator = { ',' };
            string[] expSaveFormats = expectedSaveFormats.Split(separator);
            IReadOnlyCollection<IWebElement> saveFormatElements = Browser.Wd.FindElements(By.XPath("//*[@data-ng-model='selectedCriteria.selectedReportFormat']"));
            List<string> saveFormatList = new List<string>();
            foreach (var format in saveFormatElements)
            {
                saveFormatList.Add(format.GetAttribute("value"));
            }

            if (!expSaveFormats.Length.Equals(saveFormatList.Count))
            {
                Assert.Fail("Formats are mismatch in UI.");
            }
            else
            {
                for (int i = 0; i < saveFormatList.Count; i++)
                {
                    if (!saveFormatList[i].Equals(expSaveFormats[i]))
                    {
                        Assert.Fail(saveFormatList[i].ToString() + " format is missing on UI...");
                    }
                }
            }
        }


        [Given(@"Verify Sort Direction dropdown displayed ""(.*)"" formats")]
        public void GivenVerifySortDirectionDropdownDisplayedFormats(string expectedSortoptions)
        {
            char[] separator = { ',' };
            string[] expSortDirection= expectedSortoptions.Split(separator);
            IReadOnlyCollection<IWebElement> sortDirectionEle = FRM.FRMReport.SortDirection.FindElements(By.TagName("option"));
            List<string> sortDirectionList = new List<string>();
            foreach (var sortDirection in sortDirectionEle)
            {
                sortDirectionList.Add(sortDirection.Text);
            }

            if (!expSortDirection.Length.Equals(sortDirectionList.Count))
            {
                Assert.Fail("Formats are mismatch in UI.");
            }
            else
            {
                for (int i = 0; i < sortDirectionList.Count; i++)
                {
                    if (!sortDirectionList[i].Equals(expSortDirection[i]))
                    {
                        Assert.Fail(sortDirectionList[i].ToString() + " sort direction is missing on UI...");
                    }
                }
            }
        }

        [Given(@"Search Criteria page Run Interactively ""(.*)"" is checked")]
        [When(@"Search Criteria page Run Interactively ""(.*)"" is checked")]
        public void GivenSearchCriteriaPageRunInteractivelyIsChecked(string option)
        {
            IWebElement elem = Browser.Wd.FindElement(By.Id("lblInteractive" + option + ""));
            fw.ExecuteJavascript(elem);
            tmsWait.Hard(5);
            //fw.ExecuteJavascript(FRM.FRMReport.RunReportButton);
            //tmsWait.Hard(10);      


            if (option.ToLower().Equals("yes"))
            {
                GlobalRef.winium = "Interactive";

            }
            else if (option.ToLower().Equals("no"))
            {
                GlobalRef.winium = "NonInteractive";
            }
        }

        [Given(@"Search Criteria page User Note is entered as ""(.*)""")]
        [When(@"Search Criteria page User Note is entered as ""(.*)""")]
        public void GivenSearchCriteriaPageUserNoteIsEnteredAs(string usernote)
        {
            tmsWait.Hard(2);
            FRM.FRMReport.UserNotesTextbox.SendKeys(usernote);
        }

        [Then(@"Search Criteria page User Note is ""(.*)""")]
        public void ThenSearchCriteriaPageUserNoteIs(string p0)
        {
            tmsWait.Hard(2);
            Assert.IsFalse(FRM.FRMReport.UserNotesTextbox.Enabled);
        }

        [Given(@"Search Criteria page Save Format is selected as ""(.*)""")]
        [When(@"Search Criteria page Save Format is selected as ""(.*)""")]
        public void GivenSearchCriteriaPageSaveFormatIsSelectedAs(string format)
        {
            tmsWait.Hard(2);
            IWebElement saveformat = Browser.Wd.FindElement(By.XPath("//input[@value='"+format+"']"));
            fw.ExecuteJavascript(saveformat);
            
        }

        [Given(@"Search Criteria page Run Report button is clicked")]
        [When(@"Search Criteria page Run Report button is clicked")]
        public void GivenSearchCriteriaPageRunReportButtonIsClicked()
        {
            tmsWait.Hard(10);
            fw.ExecuteJavascript(FRM.FRMReport.RunReportButton);
            tmsWait.Hard(10);

            string reporttype = GlobalRef.winium.ToString();
            if (reporttype.Equals("Interactive"))
            {
                ReUsableFunctions.reportAuthenticationHandler();
            }
           
        }

        [When(@"Search Criteria page Reset Button is clicked")]
        public void WhenSearchCriteriaPageResetButtonIsClicked()
        {
            fw.ExecuteJavascript(FRM.FRMReport.ReportResetButton);
        }

        

        [Then(@"Verify the File Processing Status page ""(.*)"" status is ""(.*)""")]
        public void ThenVerifyTheFileProcessingStatusPageStatusIs(string p0, string p1)
        {
            tmsWait.Hard(15);
            string actualStatus;
            string reportName = p0.ToString();
            string reportStatus = p1.ToString();
            //string xpath = "//div[text()='" + reportName + "']//parent::div/preceding-sibling::div//span[1]";
            //string xpath = "//div[@tooltip='" + reportName + "']//parent::div/preceding-sibling::div//span[contains(.,'Complete')]";
            //string xpath = "(//div[@test-id='file-grid-fileProcessStatusGrid']//td/span[contains(.,'"+ reportName + "')]/parent::td/preceding-sibling::td/span[contains(.,'Complete')])[1]";
            //string xpath= "(//div[@test-id='file-grid-fileProcessStatusGrid']//td/span[contains(.,'"+ reportName+"')]/parent::td/preceding-sibling::td[2]/span)[1]";
            string xpath = "(//kendo-grid[@test-id='jobProcessingStatus-grid-jobs']//td[contains(.,'" + reportName + "')]/following-sibling::td)[1]";
            actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
            int ReturnStatus = StatusValidation(actualStatus);

            while (ReturnStatus != 0)
            {
                actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                ReturnStatus = StatusValidation(actualStatus);
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='jobProcessingStatus-button-search']")));
                tmsWait.Hard(3);
            }
        }

        /// <summary>
        /// Report Status Validation on File Processing Status page
        /// </summary>
        /// <param name="actualStatus">Status of report</param>
        /// <returns>Value based on status</returns>
        public int StatusValidation(string actualStatus)
        {
            if (actualStatus.Equals("Pending"))
            {
                tmsWait.Hard(2);
                return 1;
            }
            else if (actualStatus.Equals("Executing"))
            {
                return 1;
            }
            else if (actualStatus.Equals("Failed"))
            {
                Assert.Fail("Report Generation Job is failed");
                return 0;
            }
            else if (actualStatus.Equals("Complete"))
            {
                return 0;
            }
            return 0;
        }

        
        [Then(@"Report Manager page Report ""(.*)"" is selected")]
        [Given(@"Report Manager page Report ""(.*)"" is selected")]
        public void ThenReportManagerPageReportIsSelected(string report)
        {
            tmsWait.Hard(2);

            IWebElement multi = Browser.Wd.FindElement(By.XPath("(//input[@class='k-input'])[1]"));
            multi.SendKeys(report);
            // fw.ExecuteJavascript(multi);
            tmsWait.Hard(2);
            IWebElement drp = Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + report + "')]"));
            fw.ExecuteJavascript(drp);

            //string xpathstring = "//multiselect[@test-id='multiSelectReports']//a[contains(.,'" + report + "')]/span";
            //fsMemberDiscrepancy obj = new fsMemberDiscrepancy();
            //obj.SelectDropDownValues(xpathstring);
        }

        [Then(@"Report Manager Search button is clicked")]
        [Given(@"Report Manager Search button is clicked")]
        public void ThenReportManagerSearchButtonIsClicked()
        {
            fw.ExecuteJavascript(FRM.FRMReport.SearchButton);
        }

        [Then(@"Reports Manager page for ""(.*)"" Download format for ""(.*)"" button is clicked and ""(.*)"" text displayed in report")]
        public void ThenReportsManagerPageForDownloadFormatForButtonIsClickedAndTextDisplayedInReport(string reportName, string format, string ReportValidationText)
        {
            tmsWait.Hard(5);
            //Deleting already saved PDF, XLS and CSV files from doanload folder.
            string[] fileExtensions = { ".pdf", ".xls", ".csv" };
            //downloadPath = @"C:\\Users\\swapnil.ghadage\\";
            DirectoryInfo di = new DirectoryInfo(downloadPath);
            FileInfo[] oldDownloadedFiles = di.EnumerateFiles().Where(p => fileExtensions.Contains(p.Extension, StringComparer.InvariantCultureIgnoreCase)).ToArray();
            foreach (var oldFile in oldDownloadedFiles)
            {
                oldFile.Attributes = FileAttributes.Normal;
                File.Delete(oldFile.FullName);
            }

            //IWebElement test = Browser.Wd.FindElement(By.XPath("//div[contains(.,'" + reportName + "')]//parent::div[@class='ng-isolate-scope']/div[contains(.,'" + format + "')]//following-sibling::div//a[@title='Download']"));
            IWebElement test = Browser.Wd.FindElement(By.CssSelector("a[title = 'Download']"));
            if (reportName.Contains("/"))
            {
                reportName = reportName.Replace("/", "_");
            }
            tmsWait.Hard(5);
            //Based on Borwser type perform doanload action and verify report from download folder
            if (ConfigFile.BrowserType.ToLower().Equals("chrome"))
            {
                fw.ExecuteJavascript(test);
            }
            else if (ConfigFile.BrowserType.ToLower().Equals("ie"))
            {
                //RSM.ReportManager.DownloadButton.Click();

                fw.ExecuteJavascript(test);
                tmsWait.Hard(3);
                DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_MENU, 0, 0, 0);
                tmsWait.Hard(2);
                DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_S, 0, 0, 0);
            }
            else
            {
                fw.ExecuteJavascript(test);
                tmsWait.Hard(5);
                DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_RETURN, 0, 0, 0);
            }
            if (format.ToUpper().Equals("PDF"))
            {
                tmsWait.Hard(10);
                string pdfText = ReadFileFunctions.ReadPDFFile(downloadPath + "\\" + reportName + ".PDF");
                Assert.IsTrue(pdfText.Contains(ReportValidationText), "PDF File missed some data. Failed...");
            }
            else if (format.ToUpper().Equals("CSV"))
            {
                tmsWait.Hard(10);
                var csvData = ReadFileFunctions.ReadCSVFile(downloadPath + "\\" + "" + reportName + ".CSV");
                VerifyText(csvData, ReportValidationText, format);
            }
            else
            {
                tmsWait.Hard(10);
                var excelData = ReadFileFunctions.ReadXLSFile(downloadPath + "\\" + "" + reportName + ".XLSX", downloadPath + "\\" + "" + reportName + ".CSV");
                VerifyText(excelData, ReportValidationText, format);
            }
        }

        /// <summary>
        /// Verify Text
        /// </summary>
        /// <param name="dataFromFile">Data to be checked in file</param>
        /// <param name="reportName">Name of report</param>
        /// <param name="format">Format of saved report</param>
        public void VerifyText(List<string> dataFromFile, string reportName, string format)
        {
            bool flag = false;
            foreach (string data in dataFromFile)
            {
                if (data.Contains(reportName))
                {
                    flag = true;
                }
            }
            Assert.IsTrue(flag, format + " File has missed some data. Failed...");
        }

        [Then(@"Verify EAM reports displayed ""(.*)""")]
        public void ThenVerifyEAMReportsDisplayed(string textToVerify)
        {
            tmsWait.Hard(10);
            tmsWait.WaitForWindowToOpen();
            Browser.SwitchToChildWindow();
            if (Browser.Wd.PageSource.Contains(textToVerify))
            {
                Assert.IsTrue(true);
            }
            Browser.Wd.Close();
            tmsWait.WaitForWindowToClose();
            Browser.SwitchToParentWindow();
            if (Browser.Wd.WindowHandles.Count == 1)
            {
                Assert.IsTrue(true);
            }
            else
            {
                Assert.Fail("Report window is not opened. Failed....");
            }
        }


        [Then(@"Verify EAM Application Code Level Details report name as '(.*)' displayed Title")]
        public void ThenVerifyEAMApplicationCodeLevelDetailsReportNameAsDisplayedTitle(string textToVerify)
        {
           
            tmsWait.Hard(10);
            tmsWait.WaitForWindowToOpen();
            Browser.SwitchToChildWindow();
            if (Browser.Wd.PageSource.Contains(textToVerify))
            {
                Assert.IsTrue(true);
            }
            Browser.Wd.Close();
            tmsWait.WaitForWindowToClose();
            Browser.SwitchToParentWindow();
            if (Browser.Wd.WindowHandles.Count == 1)
            {
                Assert.IsTrue(true);
            }
            else
            {
                Assert.Fail("Report window is not opened. Failed....");
            }
        }


       


        [Given(@"Verify the Report page title as ""(.*)"" is displayed")]
        [When(@"Verify the Report page title as ""(.*)"" is displayed")]
        [Then(@"Verify the Report page title as ""(.*)"" is displayed")]
        public void GivenVerifyTheReportPageTitleAsIsDisplayed(string textToVerify)
        {
            tmsWait.Hard(10);
            //tmsWait.WaitForWindowToOpen();
            Browser.SwitchToChildWindow();
            if(Browser.Wd.PageSource.Contains(textToVerify))
            {
                Assert.IsTrue(true);
                fw.ConsoleReport(textToVerify + " Report Window is Opened");
            }
            Browser.Wd.Close();
            //tmsWait.WaitForWindowToClose();
            Browser.SwitchToParentWindow();
            if(Browser.Wd.WindowHandles.Count==1)
            {
                Assert.IsTrue(true);
            }
            else
            {
                Assert.Fail("Report window is not opened. Failed....");
            }
        }

        [Given(@"Verify Report Manager search result page")]
        [Then(@"Verify Report Manager search result page")]
        public void GivenVerifyReportManagerSearchResultPage()
        {
            GlobalRef.InitialCount = Browser.Wd.FindElements(By.XPath("//i[@class='icon-delete_24px']")).Count;
        }


        [Then(@"Report Manager search page report is checkbox is checked")]
        public void ThenReportManagerSearchPageReportIsCheckboxIsChecked()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//td/input[@type='checkbox']")));
        }


        [Given(@"Report Manager search page Delete button is clicked")]
        [Then(@"Report Manager search page Delete button is clicked")]
        public void GivenReportManagerSearchPageDeleteButtonIsClicked()
        {
            fw.ExecuteJavascript(FRM.FRMReport.DeleteButton);
        }

        [Given(@"Report Manager on Alert ""(.*)"" button is clicked")]
        [Then(@"Report Manager on Alert ""(.*)"" button is clicked")]
        public void GivenReportManagerOnAlertButtonIsClicked(string action)
        {
            tmsWait.Hard(5);
            // tmsWait.WaitForElement(By.CssSelector("button[test-id='confirmationDialog-btn-" + action + "']"));
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("button[test-id='confirmationDialog-btn-" + action + "']")));

           
        }

        [Given(@"Verify Report Manager search result page for ""(.*)"" functionality")]
        [Then(@"Verify Report Manager search result page for ""(.*)"" functionality")]
        public void GivenVerifyReportManagerSearchResultPageForFunctionality(string action)
        {
            if (action.ToLower() == "no")
            {
                int initialCount = Convert.ToInt32(GlobalRef.InitialCount);
                int cancelButtonCount = Browser.Wd.FindElements(By.XPath("//a[@role='button']")).Count;
                Assert.AreEqual(initialCount, cancelButtonCount, "Count mismatched...");
            }
            else
            {
                tmsWait.Hard(5);
                int initialCount = Convert.ToInt32(GlobalRef.InitialCount);
                int yesButtonCount = Browser.Wd.FindElements(By.XPath("//a[@role='button']")).Count;
                Assert.AreEqual((initialCount - 1), yesButtonCount, "Count mismatched...");
            }
        }

        [Given(@"Search criteria page Discrepancy Type is selected as ""(.*)""")]
        public void GivenSearchCriteriaPageDiscrepancyTypeIsSelectedAs(string types)
        {
            char[] split = { ',' };
            string[] typelist = types.Split(split);
            foreach (string type in typelist)
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[contains(.,'" + type + "')]/parent::li//span")));
            }
            FRM.FRMReport.DiscrepancyTypeMultiselect.Click();
        }

        [Given(@"FRM Report page get all lists of reports")]
        public void GivenFRMReportPageGetAllListsOfReports()
        {
            List<string> reportList = new List<string>();
            reportList.Add("All");
            var allreports= Browser.Wd.FindElements(By.XPath("//*[@role='tree']/li[@role='treeitem']"));
            foreach(var report in allreports)
            {
                reportList.Add(report.Text);
            }
            ScenarioContext.Current.Add("ExpectedList", reportList);
        }

        [When(@"""(.*)"" Search Criteria Accordion section Part ""(.*)"" ""(.*)"" is selected")]
        public void WhenSearchCriteriaAccordionSectionPartIsSelected(string reportName, string field, string value)
        {
            string temp = tmsCommon.GenerateData(value);
            switch(reportName)
            {
                case "Discrepancy Type - Flag Part C - By Claim":
                    {
                        switch (field)
                        {
                            case "Plan ID":
                                IWebElement plainId = Browser.Wd.FindElement(By.XPath("//select[@test-id='Planid']"));
                                SelectElement planIddrp = new SelectElement(plainId);
                                planIddrp.SelectByText(tmsCommon.GenerateData(value));
                                break;

                            case "Discrep Type":
                                //IWebElement discrpType = Browser.Wd.FindElement(By.XPath("//button[@class'btn btn-small col-xs-12 dropdown-toggle ng-binding']"));
                                //SelectElement discrpTypedrp = new SelectElement(discrpType);
                                //discrpTypedrp.SelectByText(tmsCommon.GenerateData(value));
                                break;

                            case "Sort By Details":
                                IWebElement sortdtls = Browser.Wd.FindElement(By.XPath("//select[@test-id='SortBy']"));
                                SelectElement sortdtlsdrp = new SelectElement(sortdtls);
                                sortdtlsdrp.SelectByText(tmsCommon.GenerateData(value));
                                break;

                            case "Discrepancy Status":
                                IWebElement discrpStatus = Browser.Wd.FindElement(By.XPath("//select[@test-id='DiscrepStatus']"));
                                SelectElement discrpStatusdrp = new SelectElement(discrpStatus);
                                discrpStatusdrp.SelectByText(tmsCommon.GenerateData(value));
                                break;

                            case "Sort Direction":
                                IWebElement sortDirection = Browser.Wd.FindElement(By.XPath("//select[@test-id='Sortorder']"));
                                SelectElement sortDirectiondrp = new SelectElement(sortDirection);
                                sortDirectiondrp.SelectByText(tmsCommon.GenerateData(value));
                                break;
                        }
                        break;
                    }
                case "Bid Tool Part C - By SCC":
                    {
                        switch (field)
                        {
                            case "Year":
                                IWebElement yearId = Browser.Wd.FindElement(By.XPath("//select[@test-id='Year']"));
                                SelectElement yearIddrp = new SelectElement(yearId);
                                yearIddrp.SelectByText(tmsCommon.GenerateData(value));
                                break;

                            case "Plan ID":
                                IWebElement plainId = Browser.Wd.FindElement(By.XPath("//select[@test-id='Planid']"));
                                SelectElement planIddrp = new SelectElement(plainId);
                                planIddrp.SelectByText(tmsCommon.GenerateData(value));
                                break;

                            case "PBP ID":
                                IWebElement pbpId = Browser.Wd.FindElement(By.XPath("//select[@test-id='PBP']"));
                                SelectElement pbpIddrp = new SelectElement(pbpId);
                                pbpIddrp.SelectByText(tmsCommon.GenerateData(value));
                                break;

                            case "SCC":
                                IWebElement scc = Browser.Wd.FindElement(By.XPath("//select[@test-id='SCC']"));
                                SelectElement sccdrp = new SelectElement(scc);
                                sccdrp.SelectByText(tmsCommon.GenerateData(value));
                                break;
                        }
                        break;
                    }
                case "CMS 45 Day Compliance Report - Plan vs. CMS - By Claim":
                    {
                        switch (field)
                        {
                            case "Plan ID":
                                IWebElement plainId = Browser.Wd.FindElement(By.XPath("//select[@test-id='Planid']"));
                                SelectElement planIddrp = new SelectElement(plainId);
                                planIddrp.SelectByText(tmsCommon.GenerateData(value));
                                break;

                            case "Discrep Type":
                                //IWebElement discrpType = Browser.Wd.FindElement(By.XPath("//button[@class'btn btn-small col-xs-12 dropdown-toggle ng-binding']"));
                                //SelectElement discrpTypedrp = new SelectElement(discrpType);
                                //discrpTypedrp.SelectByText(tmsCommon.GenerateData(value));
                                break;

                            case "Sort By Details":
                                IWebElement sortdtls = Browser.Wd.FindElement(By.XPath("//select[@test-id='SortBy']"));
                                SelectElement sortdtlsdrp = new SelectElement(sortdtls);
                                sortdtlsdrp.SelectByText(tmsCommon.GenerateData(value));
                                break;

                            case "Discrepancy Status":
                                IWebElement discrpStatus = Browser.Wd.FindElement(By.XPath("//select[@test-id='DiscrepStatus']"));
                                SelectElement discrpStatusdrp = new SelectElement(discrpStatus);
                                discrpStatusdrp.SelectByText(tmsCommon.GenerateData(value));
                                break;

                            case "Sort Direction":
                                IWebElement sortDirection = Browser.Wd.FindElement(By.XPath("//select[@test-id='Sortorder']"));
                                SelectElement sortDirectiondrp = new SelectElement(sortDirection);
                                sortDirectiondrp.SelectByText(tmsCommon.GenerateData(value));
                                break;
                        }
                        break;
                    }
               

            }           
        }

        [When(@"Verify CMS(.*) day Complaince Report by Discrepency type Search Criteria Accordion section Part ""(.*)"" ""(.*)"" is selected")]
        public void WhenVerifyCMSDayComplainceReportByDiscrepencyTypeSearchCriteriaAccordionSectionPartIsSelected(int p0, string field, string value)
        {
            string expectedValue = tmsCommon.GenerateData(value);
            string actualValue = null;
            switch (field)
            {
                case "PlanID":
                    IWebElement plainId = Browser.Wd.FindElement(By.XPath("//select[@test-id='Planid']"));
                    SelectElement planIddrp = new SelectElement(plainId);
                    actualValue = planIddrp.SelectedOption.Text;
                    Assert.AreEqual(actualValue, expectedValue);

                    //planIddrp.SelectByText(tmsCommon.GenerateData(value));                  
                    break;

                case "Discrep Type":
                    //IWebElement discrpType = Browser.Wd.FindElement(By.XPath("//button[@class'btn btn-small col-xs-12 dropdown-toggle ng-binding']"));
                    //SelectElement discrpTypedrp = new SelectElement(discrpType);
                    //discrpTypedrp.SelectByText(tmsCommon.GenerateData(value));
                    break;

                case "Sort By Details":
                    IWebElement sortdtls = Browser.Wd.FindElement(By.XPath("//select[@test-id='SortBy']"));
                    SelectElement sortdtlsdrp = new SelectElement(sortdtls);
                    actualValue = sortdtlsdrp.SelectedOption.Text;
                    Assert.AreEqual(actualValue, expectedValue);
                    break;

                case "Discrepancy Status":
                    IWebElement discrpStatus = Browser.Wd.FindElement(By.XPath("//select[@test-id='DiscrepStatus']"));
                    SelectElement discrpStatusdrp = new SelectElement(discrpStatus);
                    actualValue = discrpStatusdrp.SelectedOption.Text;
                    Assert.AreEqual(actualValue, expectedValue);
                    break;

                case "Sort Direction":
                    IWebElement sortDirection = Browser.Wd.FindElement(By.XPath("//select[@test-id='Sortorder']"));
                    SelectElement sortDirectiondrp = new SelectElement(sortDirection);
                    actualValue = sortDirectiondrp.SelectedOption.Text;
                    Assert.AreEqual(actualValue, expectedValue);
                    break;
            }

        }

        [When(@"Verify CMS (.*) Day Compliance Report - Plan vs\. CMS - By Claim Search Criteria Accordion section Part ""(.*)"" ""(.*)"" is selected")]
        public void WhenVerifyCMSDayComplianceReport_PlanVs_CMS_ByClaimSearchCriteriaAccordionSectionPartIsSelected(int p0, string field, string value)
        {
            string expectedValue = tmsCommon.GenerateData(value);
            string actualValue = null;
            switch (field)
            {
                case "PlanID":
                    IWebElement plainId = Browser.Wd.FindElement(By.XPath("//select[@test-id='Planid']"));
                    SelectElement planIddrp = new SelectElement(plainId);
                    actualValue = planIddrp.SelectedOption.Text;
                    Assert.AreEqual(actualValue, expectedValue);

                    //planIddrp.SelectByText(tmsCommon.GenerateData(value));                  
                    break;

                case "Discrep Type":
                    //IWebElement discrpType = Browser.Wd.FindElement(By.XPath("//button[@class'btn btn-small col-xs-12 dropdown-toggle ng-binding']"));
                    //SelectElement discrpTypedrp = new SelectElement(discrpType);
                    //discrpTypedrp.SelectByText(tmsCommon.GenerateData(value));
                    break;

                case "Sort By Details":
                    IWebElement sortdtls = Browser.Wd.FindElement(By.XPath("//select[@test-id='SortBy']"));
                    SelectElement sortdtlsdrp = new SelectElement(sortdtls);
                    actualValue = sortdtlsdrp.SelectedOption.Text;
                    Assert.AreEqual(actualValue, expectedValue);
                    break;

                case "Discrepancy Status":
                    IWebElement discrpStatus = Browser.Wd.FindElement(By.XPath("//select[@test-id='DiscrepStatus']"));
                    SelectElement discrpStatusdrp = new SelectElement(discrpStatus);
                    actualValue = discrpStatusdrp.SelectedOption.Text;
                    Assert.AreEqual(actualValue, expectedValue);
                    break;

                case "Sort Direction":
                    IWebElement sortDirection = Browser.Wd.FindElement(By.XPath("//select[@test-id='Sortorder']"));
                    SelectElement sortDirectiondrp = new SelectElement(sortDirection);
                    actualValue = sortDirectiondrp.SelectedOption.Text;
                    Assert.AreEqual(actualValue, expectedValue);
                    break;
            }
        }

        [When(@"Verify Bid Tool Part C - By SCC Report by Discrepency type Search Criteria Accordion section Part ""(.*)"" ""(.*)"" is selected")]
        public void WhenVerifyBidToolPartC_BySCCReportByDiscrepencyTypeSearchCriteriaAccordionSectionPartIsSelected(string field, string value)
        {
            string expectedValue = tmsCommon.GenerateData(value);
            string actualValue = null;
            switch (field)
            {
                case "Plan ID":
                    IWebElement plainId = Browser.Wd.FindElement(By.XPath("//select[@test-id='Planid']"));
                    SelectElement planIddrp = new SelectElement(plainId);
                    actualValue = planIddrp.SelectedOption.Text;
                    Assert.AreEqual(actualValue, expectedValue);

                    //planIddrp.SelectByText(tmsCommon.GenerateData(value));                  
                    break;

                case "Year":
                    IWebElement yearId = Browser.Wd.FindElement(By.XPath("//select[@test-id='Year']"));
                    SelectElement yearIddrp = new SelectElement(yearId);
                    actualValue = yearIddrp.SelectedOption.Text;
                    Assert.AreEqual(actualValue, expectedValue);
                    break;

                case "PBP ID":
                    IWebElement pbpId = Browser.Wd.FindElement(By.XPath("//select[@test-id='PBP']"));
                    SelectElement pbpIdDrp = new SelectElement(pbpId);
                    actualValue = pbpIdDrp.SelectedOption.Text;
                    Assert.AreEqual(actualValue, expectedValue);
                    break;

                case "SCC":
                    IWebElement sccId = Browser.Wd.FindElement(By.XPath("//select[@test-id='SCC']"));
                    SelectElement sccIddrp = new SelectElement(sccId);
                    actualValue = sccIddrp.SelectedOption.Text;
                    Assert.AreEqual(actualValue, expectedValue);
                    break;
            }

        }

        [When(@"Verify CMS(.*) day Complaince Report by Discrepency type Search Criteria Accordion section Part Run Interactively ""(.*)"" is checked")]
        public void WhenVerifyCMSDayComplainceReportByDiscrepencyTypeSearchCriteriaAccordionSectionPartRunInteractivelyIsChecked(int p0, string p1)
        {
            
        }


        [Given(@"Report Manager page report names list is compared")]
        public void GivenReportManagerPageReportNamesListIsCompared()
        {
            List<string> actualReportList = new List<string>();
           int reportManager = (Browser.Wd.FindElements(By.XPath("//select[@id='multiSelectReports']//option")).Count);

            IWebElement reportsList = Browser.Wd.FindElement(By.XPath("//div[@title='Reports']"));
            fw.ExecuteJavascript(reportsList);
            tmsWait.Hard(5);
            int allReports = Browser.Wd.FindElements(By.XPath("//span[@class='ng-binding ng-scope']")).Count;
            Assert.AreEqual(reportManager, allReports," Both Reports counts are not getting matched");


            
            
        }


    }
}
