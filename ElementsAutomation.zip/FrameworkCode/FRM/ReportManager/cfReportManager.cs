﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using TechTalk.SpecFlow;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using System.Diagnostics;
using System.Windows;


namespace TMSoR1
{
    [Binding]
    public class ReportManagerSearch
    {
        public IWebElement Search { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_btnSearchData")); } }
        public IWebElement ReportType { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_lstReportName")); } }
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_lstPlanID")); } }
        public IWebElement PBP { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_lstPBP")); } }
        public IWebElement DataGrid { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_DataGridReports_ctl01")); } }
        
    }


    
}