﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;
using TMSoR1.FrameworkCode;

namespace TMSoR1
{
    [Binding]
    public class fsReportManager
    {

        public string setCheckboxTo;

        [When(@"Manage Plan Adjustment Reasons page Add Reason button is clicked")]
        public void WhenManagePlanAdjustmentReasonsPageAddReasonButtonIsClicked()
        {
            tmsWait.Hard(5);
            //old client code
            //fw.ExecuteJavascript(FRM.FRMAdministrator.ManagePlanAdjustmentReasonsAddReasonButton);

            //new angular client code
            IWebElement AddReasonButton = Browser.Wd.FindElement(By.XPath("//*[@test-id='managePlanAdjReason-grid-managePlanAdjReasonGrid']/kendo-grid-toolbar/a"));
            fw.ExecuteJavascript(AddReasonButton);
            tmsWait.Hard(2);
        }

        [When(@"Manage Plan Adjustment Reasons page New Adjustment Reasons is set to ""(.*)""")]
        public void WhenManagePlanAdjustmentReasonsPageNewAdjustmentReasonsIsSetTo(string p0)
        {
            string reason = tmsCommon.GenerateData(p0);

            //old client code
            //FRM.FRMAdministrator.ManagePlanAdjustmentReasonsNewReasonTextbox.SendKeys(reason);

            //new angular client code
            IWebElement NewReason = Browser.Wd.FindElement(By.XPath("//input[@value='dataItem.Value']"));
            NewReason.SendKeys(reason);
        }

        [When(@"Manage Plan Adjustment Reasons page Save button is Clicked")]
        public void WhenManagePlanAdjustmentReasonsPageSaveButtonIsClicked()
        {
            //old client code
            //fw.ExecuteJavascript(FRM.FRMAdministrator.ManagePlanAdjustmentReasonsSaveButton);

            //new angular client code
            IWebElement SaveButton = Browser.Wd.FindElement(By.XPath("//span[@class='fas fa-save']"));
            fw.ExecuteJavascript(SaveButton);
        }


        [When(@"FRM Next Page Administrator Section Manage Plan Adjustment Reasons menu is Clicked")]
        public void WhenFRMNextPageAdministratorSectionManagePlanAdjustmentReasonsMenuIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(FRM.FRMAdministrator.FRMAdministratorManagePlanAdjustmentReasonsmenu);
        }

        [Given(@"variable ""(.*)"" is set to value from FRM database ""(.*)""")]
        public void GivenVariableIsSetToValueFromFRMDatabase(string p0, string p1)
        {
            string Dbcontent = null;
            int index = 0;
            string oldhic = null;

            Dictionary<int, string[]> table = new Dictionary<int, string[]>();
            string query = p1.ToString();

            fsWorkflow obj = new fsWorkflow();
           
            table = Browser.ExecuteSingleQuery(query, ConfigFile.RSMdb, 2, 0, "0");

            Dbcontent = string.Join(",", table[index]);

            string[] DbRowStringt = Dbcontent.Split(',');

            switch (p0.ToLower())
            {
                case "oldhic":
                    oldhic = DbRowStringt[0];
                    fw.setVariable(p0, oldhic);
                    break;
            }
        }



        [Then(@"Verify Manage Plan Adjustment Reasons page Existing Adjustment Reasons table has data ""(.*)""")]
        public void ThenVerifyManagePlanAdjustmentReasonsPageExistingAdjustmentReasonsTableHasData(string p0)
        {
            string code = tmsCommon.GenerateData(p0).ToUpper();
            IWebElement pagesize = Browser.Wd.FindElement(By.CssSelector("[test-id='managePlanAdjReas-txt-sliceAdjReason']"));
            pagesize.Clear();
            pagesize.SendKeys("100");

            tmsWait.Hard(2);

            IWebElement element = Browser.Wd.FindElement(By.XPath("//table[@test-id='managePlanAdjReas-table-managePlanAdjReasns'][contains(.,'"+code+"')]"));
            Assert.IsTrue(element.Displayed, code + "is not getting displayed");



        }


        [Then(@"Verify Manage Plan Adjustment Reasons page Existing Adjustment Reasons table has row")]
        public void ThenVerifyManagePlanAdjustmentReasonsPageExistingAdjustmentReasonsTableHasRow(Table table)
        {


            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = FRM.FRMAdministrator.ManagePlanAdjustmentReasonsTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                //            thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 2)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[2];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                //else
                //{
                //    //Click next page link and start over.
                //    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                //    {
                //        thisTP.bNotAtLastPageOfRecords = true;
                //        thisTP.NPL.Click();
                //        tmsWait.Hard(2);
                //    }
                //}
                baseTable = FRM.FRMAdministrator.ManagePlanAdjustmentReasonsTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }



        }

        [When(@"FRM Next Page Administrator Section Manage Discrepancy Status Code menu is Clicked")]
        public void WhenFRMNextPageAdministratorSectionManageDiscrepancyStatusCodeMenuIsClicked()
        {
            fw.ExecuteJavascript(FRM.FRMAdministrator.FRMAdministratorManageDiscrepancyStatusCodemenu);
        }

        [When(@"FRM Next Page Administrator Section Plan Star Ratings menu is Clicked")]
        public void WhenFRMNextPageAdministratorSectionPlanStarRatingsMenuIsClicked()
        {
          
            tmsWait.Hard(2);
            fw.ExecuteJavascript(FRM.FRMAdministrator.PlanStarRatingsmenu);
        }


        [Then(@"FRM Next page ""(.*)"" is displayed")]
        public void ThenFRMNextPageIsDisplayed(string title)
        {
            //tmsWait.Hard(3);
            //Assert.IsTrue(FRM.FRMMainmenu.FRMPageTitle.Text.Contains(title));

            By loc = By.XPath("//div[contains(.,'Plan Star Ratings')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
            tmsWait.Hard(5);
        }

        [Then(@"Verify Plan Star Ratings page cancel the changes")]
        public void ThenVerifyPlanStarRatingsPageCancelTheChanges()
        {
            tmsWait.Hard(2);
            By loc = By.XPath("");
            try
            {
                Assert.IsTrue(!FRM.FRMAdministrator.PlanStarDropdown.Displayed);
            }
            catch (Exception ex)
            {
                Assert.IsTrue(true);
            }
        }


        [When(@"Plan Star Rating page Page Size text box is set to ""(.*)""")]
        public void WhenPlanStarRatingPagePageSizeTextBoxIsSetTo(string p0)
        {
            FRM.FRMAdministrator.PlanStarRatingPaginationTextRight.Clear();
            tmsWait.Hard(4);
            FRM.FRMAdministrator.PlanStarRatingPaginationTextRight.SendKeys(p0);
            tmsWait.Hard(2);
        }

        [Then(@"Verify Plan Star Rating page Pagination ""(.*)"" link is enabled")]
        public void ThenVerifyPlanStarRatingPagePaginationLinkIsEnabled(string p0)
        {
            tmsWait.Hard(2);
            string link = p0.ToString();

            switch (link)
            {


                case "Next":
                    Assert.IsTrue(FRM.FRMAdministrator.PlanStarRatingPaginationNext.Enabled, p0 + " link is enabled");

                    break;
                case "First":
                    Assert.IsTrue(FRM.FRMAdministrator.PlanStarRatingPaginationFirst.Enabled, p0 + " link is enabled");

                    break;
                case "Last":
                    Assert.IsTrue(FRM.FRMAdministrator.PlanStarRatingPaginationLast.Enabled, p0 + " link is enabled");

                    break;
                case "Previous":
                    Assert.IsTrue(FRM.FRMAdministrator.PlanStarRatingPaginationPrevious.Enabled, p0 + " link is enabled");

                    break;
            }
        }

        [Then(@"Verify Plan Star Rating page Pagination ""(.*)"" link is Clicked")]
        public void ThenVerifyPlanStarRatingPagePaginationLinkIsClicked(string p0)
        {
            tmsWait.Hard(2);
            string link = p0.ToString();

            switch (link)
            {


                case "Next":
                    fw.ExecuteJavascript(FRM.FRMAdministrator.PlanStarRatingPaginationNext);

                    break;
                case "First":
                    fw.ExecuteJavascript(FRM.FRMAdministrator.PlanStarRatingPaginationFirst);

                    break;
                case "Last":
                    fw.ExecuteJavascript(FRM.FRMAdministrator.PlanStarRatingPaginationLast);

                    break;
                case "Previous":
                    fw.ExecuteJavascript(FRM.FRMAdministrator.PlanStarRatingPaginationPrevious);

                    break;
            }
        }


        [Then(@"Verify Plan Star Rating Page Plan ID Drop down list is displayed")]
        public void ThenVerifyPlanStarRatingPagePlanIDDropDownListIsDisplayed()
        {
            // Assert.IsTrue(FRM.FRMAdministrator.PlanStarPlanID.Displayed, " Plan ID Drop down is displayed");
            By Drp = By.XPath("//label[contains(.,'Plan ID')]/parent::div//span[@class='k-select']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            tmsWait.Hard(2); tmsWait.Hard(3);
        }

        [When(@"Plan Star Ratings page Plan ID drop down is set to ""(.*)""")]
        public void WhenPlanStarRatingsPagePlanIDDropDownIsSetTo(string p0)
        {
            //tmsWait.Hard(2);
            //SelectElement planid = new SelectElement(FRM.FRMAdministrator.PlanStarPlanID);
            //planid.SelectByText(p0);

            string plan = tmsCommon.GenerateData(p0);
            By Drp1 = By.XPath("//kendo-dropdownlist[@id='planId']//span[@class='k-select']");
            AngularFunction.selectDropDownValue(Drp1, plan);
            tmsWait.Hard(3);
        }

        [When(@"Plan Star Ratings page Year drop down is set to ""(.*)""")]
        public void WhenPlanStarRatingsPageYearDropDownIsSetTo(string p0)
        {
            // tmsWait.Hard(2);


            //SelectElement planid = new SelectElement(FRM.FRMAdministrator.PlanStarYear);
            //// planid.SelectByText(p0);
            //planid.SelectByIndex(1);
            //GlobalRef.Year = planid.SelectedOption.Text;

            By Drp = By.XPath("//kendo-dropdownlist[@id='ratingYear']//span[@class='k-select']");
           // By typeapp = By.XPath("//li[text()='" + p0 + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
         //   fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);


        //IWebElement Drp = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@id='ratingYear']//span[@class='k-select']"));

        //new SelectElement(Drp).SelectByIndex(2);
    }

        [When(@"Plan Star Ratings page Go Button is Clicked")]
        public void WhenPlanStarRatingsPageGoButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(FRM.FRMAdministrator.PlanStarGoButton);
            tmsWait.Hard(2);
        }

       


        [Then(@"Verify Plan Star Rating Page Year Drop down list is displayed")]
        public void ThenVerifyPlanStarRatingPageYearDropDownListIsDisplayed()
        {

          //Assert.IsTrue(FRM.FRMAdministrator.PlanStarYear.Displayed, " Year  Drop down is displayed");
            By Drp = By.XPath("//label[contains(.,'Year')]/parent::div//span[@class='k-select']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            tmsWait.Hard(2); tmsWait.Hard(3);
        }

        [Then(@"Verify Plan Star Rating Page Go Button is displayed")]
        public void ThenVerifyPlanStarRatingPageGoButtonIsDisplayed()
        {
            Assert.IsTrue(FRM.FRMAdministrator.PlanStarGoButton.Displayed, " Year  Drop down is displayed");
        }

        [Then(@"Verify Plan Star Rating Page Reset button is displayed")]
        public void ThenVerifyPlanStarRatingPageResetButtonIsDisplayed()
        {
            Assert.IsTrue(FRM.FRMAdministrator.PlanStarResetButton.Displayed, " Year  Drop down is displayed");
        }


        [When(@"FRM Next Page Plan Star Ratings page Edit icon is Clicked")]
        public void WhenFRMNextPagePlanStarRatingsPageEditIconIsClicked()
        {
            tmsWait.Hard(2);
            //fw.ExecuteJavascript(FRM.FRMAdministrator.PlanStarEditIconButton);

            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//span[@class='fas fa-pencil-alt'])[1]")));
            tmsWait.Hard(1);
        }


        [When(@"Plan Star Ratings page Plan Star Rating drop down list is set to ""(.*)""")]
        public void WhenPlanStarRatingsPagePlanStarRatingDropDownListIsSetTo(string p0)
        {
           

            By Drp = By.XPath("//*[@id='StarRating']//span[@class='k-select']");
            AngularFunction.selectDropDownValue(Drp, p0);
            tmsWait.Hard(3);

        }

        [When(@"Plan Star Ratings page Edit icon is clicked for first record")]
        public void WhenPlanStarRatingsPageEditIconIsClickedForFirstRecord()
        {
          
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//span[@class='fas fa-pencil-alt'])[1]")));
            tmsWait.Hard(1);
        }

        [Then(@"Plan Star Ratings page Message ""(.*)""")]
        public void ThenPlanStarRatingsPageMessage(string p0)
        {
           
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[@test-id='planStarRating-span-Message']")).Text.Contains(p0), "Plan star ratings not updated");
        }


        [When(@"Plan Star Ratings page Save button is Clicked")]
        public void WhenPlanStarRatingsPageSaveButtonIsClicked()
        {
            fw.ExecuteJavascript(FRM.FRMAdministrator.PlanStarRatingSavebutton);
        }


        [When(@"Plan Star Ratings page Cancel button is Clicked")]
        public void WhenPlanStarRatingsPageCancelButtonIsClicked()
        {
            fw.ExecuteJavascript(FRM.FRMAdministrator.PlanStarRatingCancelbutton);
        }



        [Then(@"Verify Plan Star Ratings page table data is Clicked")]
        public void ThenVerifyPlanStarRatingsPageTableDataIsClicked(Table table)
        {
            tmsWait.Hard(5);
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = FRM.FRMAdministrator.PlanStarRatingsTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                //            thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPlanStarPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 2)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[2];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    tmsWait.Hard(5);
                    IWebElement but = Browser.Wd.FindElement(By.XPath("//i[@class='fa fa-edit']"));
                    fw.ExecuteJavascript(but);
                    
                }
                //else
                //{
                //    //Click next page link and start over.
                //    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                //    {
                //        thisTP.bNotAtLastPageOfRecords = true;
                //        thisTP.NPL.Click();
                //        tmsWait.Hard(2);
                //    }
                //}
                baseTable = FRM.FRMAdministrator.PlanStarRatingsTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }



        }


        [Then(@"Verify Plan Star Ratings page table has Plan ID as ""(.*)"" Plan Star Rating as ""(.*)"" Application Effective Date as ""(.*)"" Application Expiry Date as ""(.*)""")]
        public void ThenVerifyPlanStarRatingsPageTableHasPlanIDAsPlanStarRatingAsApplicationEffectiveDateAsApplicationExpiryDateAs(string p0, string p1, string p2, string p3)
        {
            string planID = tmsCommon.GenerateData(p0);
            string effDate= tmsCommon.GenerateData(p2);
            string xpathEle = "//*[@id='planStarRatingGrid']//tr/td[contains(.,'" + p0+"')]/following-sibling::td[contains(.,'"+p1+"')]/following-sibling::td[contains(.,'"+p2+"')]/following-sibling::td[contains(.,'"+p3+"')]";
            bool elementPresence = Browser.Wd.FindElement(By.XPath(xpathEle)).Displayed;
            Assert.IsTrue(elementPresence, "Expected Element is not present");
        }

        [Then(@"Verify Plan Star Ratings page displayed Search results")]
        public void ThenVerifyPlanStarRatingsPageDisplayedSearchResults()
        {
            tmsWait.Hard(5);
            By loc = By.XPath("//kendo-grid[@test-id='planStarRating-table-planStarRatingg']//tr[2]");
            AngularFunction.elementPresenceUsingLocators(loc);
        }


        [Then(@"Verify Plan Star Ratings page displayed Plan ID in results Grid ""(.*)""")]
        public void ThenVerifyPlanStarRatingsPageDisplayedPlanIDInResultsGrid(string p0)
        {
            string plan = tmsCommon.GenerateData(p0);
            By loc = By.XPath("//kendo-grid[@test-id='planStarRating-table-planStarRatingg']//td[contains(.,'"+ plan + "')]");
            AngularFunction.elementPresenceUsingLocators(loc);
        }

        [Then(@"Verify Plan Star Ratings Effective year in the Result Grid is set to ""(.*)""")]
        public void ThenVerifyPlanStarRatingsEffectiveYearInTheResultGridIsSetTo(string p0)
        {
            string dateis = Browser.Wd.FindElement(By.XPath("(//span[@test-id='planStarRating-span-ExpiryDate'])[1]")).Text;
            string [] yearis=dateis.Split('/');
            string expectedYear = GlobalRef.Year.ToString();
            Assert.AreEqual(expectedYear, yearis[2], "Effective year is not displayed as per selection");
        }
    

        [Then(@"Verify Plan Star Ratings page table Plan ID as ""(.*)"" Plan Star Rating as ""(.*)"" Application Effective Date as ""(.*)"" Application Expiry Date as ""(.*)"" data is Clicked")]
        public void ThenVerifyPlanStarRatingsPageTablePlanIDAsPlanStarRatingAsApplicationEffectiveDateAsApplicationExpiryDateAsDataIsClicked(string p0, string p1, string p2, string p3)
        {

            string xpathEle = "//table[@test-id='planStarRating-table-planStarRatingg']//tr/td[contains(.,'" + p0 + "')]/following-sibling::td[contains(.,'" + p1 + "')]/following-sibling::td[contains(.,'" + p2 + "')]/following-sibling::td[contains(.,'" + p3 + "')]/preceding-sibling::td//i[@test-id='planStarRating-i-shw']";
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(xpathEle)));

        }



        [Then(@"Verify Plan Star Ratings page table has row")]
        public void ThenVerifyPlanStarRatingsPageTableHasRow(Table table)
        {

            tmsWait.Hard(5);
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = FRM.FRMAdministrator.PlanStarRatingsTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                //            thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPlanStarPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 2)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[2];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                //else
                //{
                //    //Click next page link and start over.
                //    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                //    {
                //        thisTP.bNotAtLastPageOfRecords = true;
                //        thisTP.NPL.Click();
                //        tmsWait.Hard(2);
                //    }
                //}
                baseTable = FRM.FRMAdministrator.PlanStarRatingsTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }



        }


        [Then(@"Verify Manage Plan Adjustment Reasons page Manage Discrepancy Status Code table has row")]
        public void ThenVerifyManagePlanAdjustmentReasonsPageManageDiscrepancyStatusCodeTableHasRow(Table table)
        {
            tmsWait.Hard(2);
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = FRM.FRMAdministrator.ManageDiscrepancyStatusCodeTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                //            thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 2)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[2];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                //else
                //{
                //    //Click next page link and start over.
                //    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                //    {
                //        thisTP.bNotAtLastPageOfRecords = true;
                //        thisTP.NPL.Click();
                //        tmsWait.Hard(2);
                //    }
                //}
                baseTable = FRM.FRMAdministrator.ManageDiscrepancyStatusCodeTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }

        }

        [When(@"Export Monthly Extract to file Export button is Clicked")]
        public void WhenExportMonthlyExtractToFileExportButtonIsClicked()
        {
            IWebElement menu = Browser.Wd.FindElement(By.CssSelector("[test-id='expMonExtr-btn-export']"));
            fw.ExecuteJavascript(menu);
            //tmsWait.Hard(2);
            //IWebElement link = Browser.Wd.FindElement(By.PartialLinkText("File Processing Status page"));
            //fw.ExecuteJavascript(link);
        }


        [When(@"MMR Export button is Clicked")]
        public void WhenMMRExportButtonIsClicked()
        {
            tmsWait.Hard(2);
            IWebElement menu = Browser.Wd.FindElement(By.CssSelector("[test-id='mmrExtract-btn-EXPORT']"));
            //fw.ExecuteJavascript(menu);
            menu.Click();
            tmsWait.Hard(2);
            IWebElement link = Browser.Wd.FindElement(By.XPath("//span[@test-id='mmrExtract-span-MMRExtractJobb']/a"));
            fw.ExecuteJavascript(link);
        }

        [When(@"Member Premium Extract Export button is Clicked")]
        public void WhenMemberPremiumExtractExportButtonIsClicked()
        {
            tmsWait.Hard(3);
            IWebElement menu = Browser.Wd.FindElement(By.CssSelector("[test-id='premiumMemExt-btn-EXPORT']"));
            //fw.ExecuteJavascript(menu);
            menu.Click();
            tmsWait.Hard(4);
            IWebElement link = Browser.Wd.FindElement(By.XPath("//span[@test-id='premiumMemExt-span-MemberPremiumExtractJob']/a"));
            tmsWait.Hard(3);
            fw.ExecuteJavascript(link);
        }


        [When(@"Administration menu ""(.*)"" submenu is Clicked")]
        public void WhenAdministrationMenuSubmenuIsClicked(string p0)
        {
            IWebElement menu = Browser.Wd.FindElement(By.XPath("//a[@title='" + p0 + "']"));
            fw.ExecuteJavascript(menu);
        }

        [When(@"Export Monthly Extract to file page Start Date is set to ""(.*)""")]
        public void WhenExportMonthlyExtractToFilePageStartDateIsSetTo(string p0)
        {
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='expMonExtr-txt-fromDate']"));
            ele.SendKeys(p0);
        }

        [When(@"Export Monthly Extract to file page End Date is set to ""(.*)""")]
        public void WhenExportMonthlyExtractToFilePageEndDateIsSetTo(string p0)
        {
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='expMonExtr-txt-toDate']"));
            ele.SendKeys(p0);
        }


        [When(@"Extracts menu ""(.*)"" submenu is Clicked")]
        public void WhenExtractsMenuSubmenuIsClicked(string p0)
        {
            tmsWait.Hard(1);
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'Extracts')]")));
            Browser.Wd.FindElement(By.XPath("//span[contains(.,'Extracts')]")).Click();
            tmsWait.Hard(1);
            IWebElement menu = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]"));
            fw.ExecuteJavascript(menu);
        }

        [When(@"FRM Next page Administrator Extracts section is Clicked")]
        public void WhenFRMNextPageAdministratorExtractsSectionIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(FRMMainNavigation.FRMAdministratorExtracts);
            tmsWait.Hard(2);
        }

        [When(@"DLM page Tasks section is Clicked")]
        public void WhenDLMPageTasksSectionIsClicked()
        {
            IWebElement tasks = Browser.Wd.FindElement(By.CssSelector("[title='Tasks']"));
            fw.ExecuteJavascript(tasks);

    }

        [When(@"A meets B")]
        public void WhenAMeetsB()
        {
           
        }


        [When(@"FRM Next page Administrator section is Clicked")]
        public void WhenFRMNextPageAdministratorSectionIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(FRMMainNavigation.FRMAdministratormenu);
            tmsWait.Hard(2);
        }

        [Then(@"Administration page Manage Discrepancy Status Code section ""(.*)"" Delete button is clicked")]
        public void ThenAdministrationPageManageDiscrepancyStatusCodeSectionDeleteButtonIsClicked(string p0)
        {
            string reason = tmsCommon.GenerateData(p0);
            By LOC = By.XPath("//kendo-grid[@test-id='manageDiscrStatusCode-grid-manageDiscrepancyStatusCodeGrid']//td[contains(.,'"+reason+"')]//following-sibling::td//span[@class='fas fa-trash-alt']");
            AngularFunction.clickOnElement(LOC);
            tmsWait.Hard(3);
            fw.ExecuteJavascript(FRMMainNavigation.confirmationDialog);
        }

        [Then(@"Administration page Manage Discrepancy Status Code section Delete button is clicked")]
        public void ThenAdministrationPageManageDiscrepancyStatusCodeSectionDeleteButtonIsClicked()
        {
            FRM.ManageDiscrepancyStatusCode.Deletebutton.Click();
            tmsWait.Hard(3);
            fw.ExecuteJavascript(FRMMainNavigation.confirmationDialog);
            

            //IAlert delete = Browser.Wd.SwitchTo().Alert();
            //delete.Accept();
            tmsWait.Hard(3);



        }
        [Then(@"Administration page Manage Discrepancy Status Code ""(.*)"" Delete button is clicked but Operation is cancelled")]
        public void ThenAdministrationPageManageDiscrepancyStatusCodeDeleteButtonIsClickedButOperationIsCancelled(string p0)
        {
            string code = tmsCommon.GenerateData(p0.ToString());
            IWebElement delete = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='manageDiscrStatusCode-grid-manageDiscrepancyStatusCodeGrid']//td[contains(.,'"+ code + "')]"));
            tmsWait.Hard(3);          
            fw.ExecuteJavascript(delete);
            try
            {
                AngularFunction.clickOnNOonConfirmationDialog();
            tmsWait.Hard(1);
            }
            catch
            {

            }
        }


        [Then(@"Administration page Manage Discrepancy Status Code section Delete button is clicked but Operation is cancelled")]
        public void ThenAdministrationPageManageDiscrepancyStatusCodeSectionDeleteButtonIsClickedButOperationIsCancelled()
        {

            fw.ExecuteJavascript(FRM.ManageDiscrepancyStatusCode.Deletebutton);
            tmsWait.Hard(1);

            IAlert delete = Browser.Wd.SwitchTo().Alert();
            delete.Dismiss();
            tmsWait.Hard(1);
        }


        [When(@"Administration menu Manage Discrepancy Status Code submenu is Clicked")]
        [Then(@"Administration menu Manage Discrepancy Status Code submenu is Clicked")]
        public void WhenAdministrationMenuManageDiscrepancyStatusCodeSubmenuIsClicked()
        {
            fw.ExecuteJavascript(FRMMainNavigation.FRMAdministartormenumanageDiscrepancyStatusCode);
            //FRMMainNavigation.FRMAdministartormenumanageDiscrepancyStatusCode.Click();
            tmsWait.Hard(4);

        }

        [Then(@"Verify Administration page Manage Discrepancy Status Code section table has no row")]
        public void ThenVerifyAdministrationPageManageDiscrepancyStatusCodeSectionTableHasNoRow(Table table)
        {
            tmsWait.Hard(2);

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = FRM.ManageDiscrepancyStatusCode.ManageDiscrepancyStatusCodeTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }


                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    Assert.IsFalse(fullMatching, "Expected results are not found on Table");
                    fw.ConsoleReport(" Expected row is not found");
                    break;
                }
                baseTable = FRM.ManageDiscrepancyStatusCode.ManageDiscrepancyStatusCodeTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    Assert.IsFalse(fullMatching, "Expected results are not found on Table");
                    fw.ConsoleReport(" Expected row is not found");
                }
            }
        }

        [Then(@"Verify Administration page Manage Discrepancy Status Code section table has no ""(.*)"" data")]
        public void ThenVerifyAdministrationPageManageDiscrepancyStatusCodeSectionTableHasNoData(string statusCode)
        {
            string[] codes = statusCode.Split(',');
            try
            {
                foreach (string code in codes)
                {
                    Assert.IsFalse(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='manageDiscrStatusCode-grid-manageDiscrepancyStatusCodeGrid']//td[contains(.,'"+ code + "')]")).Displayed, code + " Code is found on Manage Discrepancy Status Code table.");
                }
            }catch(Exception ex)
            {
                Assert.IsTrue(true);
                fw.ConsoleReport(statusCode + " is not added in Manage Discrepancy Status Code table.");
            }
        }

        [Then(@"Verify Administration page Manage Discrepancy Status Code section table has data ""(.*)""")]
        public void ThenVerifyAdministrationPageManageDiscrepancyStatusCodeSectionTableHasData(string statusCode)
        {
            bool nextPage = false;
            string strValue = tmsCommon.GenerateData(statusCode.ToString());
            do
            {
                nextPage = VerifyDiscrepancyStatusCode(strValue);
                if (nextPage)
                {

                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@aria-label='Go to the next page']")));
                    tmsWait.Hard(1);
                }
            } while (nextPage);
            string[] codes = strValue.Split(',');
            foreach (string code in codes)
            {
                Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='manageDiscrStatusCode-grid-manageDiscrepancyStatusCodeGrid']//td[contains(.,'" + code + "')]")).Displayed, code + " Code is missing from Manage Discrepancy Status Code table.");
            }
        }

        public bool VerifyDiscrepancyStatusCode(string code)
        {
            try
            {
                if (Browser.Wd.FindElement(By.XPath("//*[@test-id='manageDiscrStatusCode-grid-manageDiscrepancyStatusCodeGrid']//div[@role='presentation']//td[contains(.,'" + code + "')]")).Displayed)
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                return true;
            }
            return true;
        }


        [Then(@"Verify Administration page Manage Discrepancy Status Code section table has below row")]
        public void ThenVerifyAdministrationPageManageDiscrepancyStatusCodeSectionTableHasBelowRow(Table table)
        {
            tmsWait.Hard(2);

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = FRM.ManageDiscrepancyStatusCode.ManageDiscrepancyStatusCodeTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            //try
                            //{
                            //    if (bThisRowMatches)
                            //    {
                            //        IWebElement thisEditTD = ApplicationRow.Element[0];
                            //        IWebElement thisEditLink = thisEditTD.FindElement(By.XPath("//a[contains(@href,'reports/reportmain_letterqueue.aspx?code=030&type=2')]"));
                            //        tmsWait.Hard(2);
                            //        thisEditLink.Click();



                            //    }
                            //}
                            //catch
                            //{
                            //    GlobalRef.LetterCount = 0;
                            //}


                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = FRM.ManageDiscrepancyStatusCode.ManageDiscrepancyStatusCodeTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }


        }

        [When(@"Verify Manage Plan Adjustment Reasons page Manage Plan Adjustment Reasons is set to ""(.*)"" code")]
        public void WhenVerifyManagePlanAdjustmentReasonsPageManagePlanAdjustmentReasonsIsSetToCode(string p0)
        {
            string code = tmsCommon.GenerateData(p0);
            tmsWait.Hard(15);
            fw.ExecuteJavascript(FRM.FRMAdministrator.ManagePlanAdjustmentReasonsAddReasonButton);
            tmsWait.Hard(15);
            FRM.FRMAdministrator.ManagePlanAdjustmentReasonsNewReasonTextbox.SendKeys(code);
            tmsWait.Hard(15);
            fw.ExecuteJavascript(FRM.FRMAdministrator.ManagePlanAdjustmentReasonsSaveButton);
        }


        [When(@"Verify Manage Plan Adjustment Reasons page Manage Plan Adjustment Reasons table has ""(.*)"" code")]
        public void WhenVerifyManagePlanAdjustmentReasonsPageManagePlanAdjustmentReasonsTableHasCode(string code1)
        {
            tmsWait.Hard(10);
            string code = tmsCommon.GenerateData(code1);
            try
            {
                if (Browser.Wd.FindElement(By.CssSelector("tr>td:nth-of-type(1)>span.ng-scope.ng-binding.editable")).Displayed)
                {
                    bool flag = false;
                    int codeindex = Browser.Wd.FindElements(By.CssSelector("tr>td:nth-of-type(1)>span.ng-scope.ng-binding.editable")).Count;
                    for (int index = 1; index < codeindex + 1; index++)
                    {
                        if (Browser.Wd.FindElement(By.CssSelector("tr:nth-of-type(" + index + ")>td:nth-of-type(1)>span.ng-scope.ng-binding.editable")).Text.Equals(code))
                        {
                            flag = true;
                            break;
                        }
                    }
                    if (!flag)
                    {
                        //tmsWait.Hard(2);
                        //fw.ExecuteJavascript(FRM.FRMAdministrator.ManagePlanAdjustmentReasonsAddReasonButton);
                        //tmsWait.Hard(5);
                        //FRM.FRMAdministrator.ManagePlanAdjustmentReasonsNewReasonTextbox.SendKeys(code);
                        //tmsWait.Hard(1);
                        //fw.ExecuteJavascript(FRM.FRMAdministrator.ManagePlanAdjustmentReasonsSaveButton);

                        IWebElement AddReasonButton = Browser.Wd.FindElement(By.XPath("//*[@test-id='managePlanAdjReason-grid-managePlanAdjReasonGrid']/kendo-grid-toolbar/a"));
                        fw.ExecuteJavascript(AddReasonButton);
                        tmsWait.Hard(2);

                        IWebElement NewReason = Browser.Wd.FindElement(By.XPath("//input[@value='dataItem.Value']"));
                        NewReason.SendKeys(code);
                    }
                }
            }
            catch (Exception ex)
            {

                IWebElement AddReasonButton = Browser.Wd.FindElement(By.XPath("//*[@test-id='managePlanAdjReason-grid-managePlanAdjReasonGrid']/kendo-grid-toolbar/a"));
                fw.ExecuteJavascript(AddReasonButton);
                tmsWait.Hard(2);

                IWebElement NewReason = Browser.Wd.FindElement(By.XPath("//input[@value='dataItem.Value']"));
                NewReason.SendKeys(code);
            }
        }


        [When(@"Administration page Manage Discrepancy Status Code section Add code button is Clicked")]
        public void WhenAdministrationPageManageDiscrepancyStatusCodeSectionAddCodeButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(FRM.ManageDiscrepancyStatusCode.AddCodeButton);
            tmsWait.Hard(5);
        }

        [When(@"Administration page Manage Discrepancy Status Code section Existing Status code is set to ""(.*)""")]
        [Then(@"Administration page Manage Discrepancy Status Code section Existing Status code is set to ""(.*)""")]
        public void WhenAdministrationPageManageDiscrepancyStatusCodeSectionExistingStatusCodeIsSetTo(string p0)
        {
            tmsWait.Hard(10);
            string strValue = tmsCommon.GenerateData(p0.ToString());
            try
            {
                if (!Browser.Wd.FindElement(By.CssSelector("span[title='" + strValue + "']'")).Displayed)
                {
                    fw.ExecuteJavascript(FRM.ManageDiscrepancyStatusCode.AddCodeButton);
                    FRM.ManageDiscrepancyStatusCode.StatusCodeTextbox.Clear();
                    FRM.ManageDiscrepancyStatusCode.StatusCodeTextbox.SendKeys(strValue);
                    fw.ExecuteJavascript(FRM.ManageDiscrepancyStatusCode.SaveButton);
                }
            }
            catch (Exception)
            {
                fw.ExecuteJavascript(FRM.ManageDiscrepancyStatusCode.AddCodeButton);
                FRM.ManageDiscrepancyStatusCode.StatusCodeTextbox.Clear();
                FRM.ManageDiscrepancyStatusCode.StatusCodeTextbox.SendKeys(strValue);
                fw.ExecuteJavascript(FRM.ManageDiscrepancyStatusCode.SaveButton);
            }
        }

        [When(@"Administration page Manage Discrepancy Status Code section Status code is set to ""(.*)""")]
        public void WhenAdministrationPageManageDiscrepancyStatusCodeSectionStatusCodeIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            string strValue = tmsCommon.GenerateData(p0.ToString());
            fw.ExecuteJavascript(FRM.ManageDiscrepancyStatusCode.AddCodeButton);
            FRM.ManageDiscrepancyStatusCode.StatusCodeTextbox.Clear();
            FRM.ManageDiscrepancyStatusCode.StatusCodeTextbox.SendKeys(strValue);
        }


        [When(@"Administration page Manage Discrepancy Status Code section First record Edit button is Clicked")]
        public void WhenAdministrationPageManageDiscrepancyStatusCodeSectionFirstRecordEditButtonIsClicked()
        {
            fw.ExecuteJavascript(FRM.ManageDiscrepancyStatusCode.FirstRecordEditbutton);
            tmsWait.Hard(1);
        }

        [When(@"Administration page Manage Discrepancy Status Code section ""(.*)"" record Edit button is Clicked")]
        public void WhenAdministrationPageManageDiscrepancyStatusCodeSectionRecordEditButtonIsClicked(string code1)
        {
            tmsWait.Hard(3);
            string wf = tmsCommon.GenerateData(code1);
            bool elementSearch = false;

            By mbiBy = By.XPath("//kendo-grid[@test-id='manageDiscrStatusCode-grid-manageDiscrepancyStatusCodeGrid']//td[contains(., '" + wf + "')]");
        
            By nextPage = By.XPath("//kendo-grid[@test-id='manageDiscrStatusCode-grid-manageDiscrepancyStatusCodeGrid']//span[@aria-label='Go to the next page']");

            while (!elementSearch)
            {
                elementSearch = elementPresence(mbiBy);
                tmsWait.Hard(3);
                if (!elementSearch)
                {
                    try
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(nextPage));
                    }
                    catch
                    {
                        Assert.Fail(" Expected Descrepancy code is not present on Export Search results");
                    }
                }

                if (elementSearch)
                {

                    tmsWait.Hard(2);
                    IWebElement edit = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='manageDiscrStatusCode-grid-manageDiscrepancyStatusCodeGrid']//td[contains(.,'"+ wf + "')]/following-sibling::td//span[@class='fas fa-pencil-alt']"));
                    fw.ExecuteJavascript(edit);


                }
            }
        }
        public bool elementPresence(By mbiBy)
        {

            try
            {
                Browser.Wd.FindElement(mbiBy);
                return true;
            }
            catch
            {
                return false;
            }
        }

        [When(@"Administration page Manage Discrepancy Status Code section Existing Status code""(.*)"" is Modified to ""(.*)""")]
        public void WhenAdministrationPageManageDiscrepancyStatusCodeSectionExistingStatusCodeIsModifiedTo(string code, string codenew)
        {
            string p0 = tmsCommon.GenerateData(code);
            string p2 = tmsCommon.GenerateData(codenew);
            IWebElement rec = Browser.Wd.FindElement(By.XPath("//input[@value='dataItem.Value']"));
            rec.Clear();
            rec.SendKeys(p2);
        }


        [When(@"Administration page Manage Discrepancy Status Code section Cancel button")]
        public void WhenAdministrationPageManageDiscrepancyStatusCodeSectionCancelButton()
        {
            tmsWait.Hard(1);
            fw.ExecuteJavascript(FRM.ManageDiscrepancyStatusCode.Cancelbutton);
        }

        [When(@"Administration page Manage Discrepancy Status Code section Save button is clicked")]
        [Then(@"Administration page Manage Discrepancy Status Code section Save button is clicked")]
        public void WhenAdministrationPageManageDiscrepancyStatusCodeSectionSaveButtonIsClicked()
        {
            tmsWait.Hard(1);
            fw.ExecuteJavascript(FRM.ManageDiscrepancyStatusCode.SaveButton);
            tmsWait.Hard(5);
        }

        [Then(@"Verify Administration page Manage Discrepancy Status Code section displays ""(.*)""")]
        public void ThenVerifyAdministrationPageManageDiscrepancyStatusCodeSectionDisplays(string p0)
        {       
            //By toastMsg = By.XPath("//div[@class='k-notification-content']");
            //string actValue = Browser.Wd.FindElement(toastMsg).Text;
            ////string actual = AngularFunction.getToasterMessage();
            //string expected = p0.ToString();
            //Assert.AreEqual(expected, actValue, p0 + " message is displayed");

        }




        [When(@"FRM Next Page Administrator Section Workflow Assignment menu is Clicked")]
        public void WhenFRMNextPageAdministratorSectionWorkflowAssignmentMenuIsClicked()
        {
            fw.ExecuteJavascript(FRMMainNavigation.FRMAdministartormenuworkFlowAssignment);
            tmsWait.Hard(5);
        }

        [When(@"WorkFlow Assignment page Discrepancy Type list view Multiple Options are selected")]
        public void WhenWorkFlowAssignmentPageDiscrepancyTypeListViewMultipleOptionsAreSelected()
        {
            //IWebElement discrepancyType = Browser.Wd.FindElement(By.XPath("//*[@id='workflowDiscrepancyTypeSelectID']//tr[22]/td"));
            //fw.ExecuteJavascript(discrepancyType);
            //tmsWait.Hard(2);
        }

        [When(@"WorkFlow Assignment page ""(.*)"" drop down list ""(.*)"" is Selected")]
        public void WhenWorkFlowAssignmentPageDropDownListIsSelected(string p0, string p1)
        {
            string field = p0.ToString();
            string value = p1.ToString();

            switch (field)
            {
                case "Plan ID":
                    tmsWait.Hard(5);
                    //Old code for pre 5.8 R2 tms tenant
                    //SelectElement plan = new SelectElement(FRM.FRMAdministrator.WorkFlowAssignmentPlanID);
                    //plan.SelectByIndex(0);

                    //New code post 5.8R2 tenant
                    By Drp = By.XPath("//kendo-dropdownlist[@test-id='workFlowAssignmnt-select-PlanId']//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + value + "']");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                    tmsWait.Hard(3);
                    break;
                case "PBP":
                    tmsWait.Hard(5);
                    //Old code for pre 5.8 R2 tms tenant
                    //SelectElement pbp = new SelectElement(FRM.FRMAdministrator.WorkFlowAssignmentPBPID);
                    //pbp.SelectByText(value);

                    //New code post 5.8R2 tenant
                    By Drp1 = By.XPath("//kendo-dropdownlist[@test-id='workFlowAssignmnt-select-Pbp']//span[@class='k-select']");
                    By typeapp1 = By.XPath("//li[text()='" + value + "']");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp1);
                   UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp1);
                    tmsWait.Hard(3);
                    break;
                case "Age of Discrepancy":
                    tmsWait.Hard(5);
                    //Old code for pre 5.8 R2 tms tenant
                    //SelectElement age = new SelectElement(FRM.FRMAdministrator.WorkFlowAssignmentAgeofDescrepancy);
                    //age.SelectByText(value);

                    //New code post 5.8R2 tenant
                    By Drp2 = By.XPath("//kendo-dropdownlist[@test-id='workFlowAssignmnt-select-workflowAgeSelectID']//span[@class='k-select']");
                    By typeapp2 = By.XPath("//li[text()='" + value + "']");

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp2);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp2);
                    tmsWait.Hard(3);
                    break;
                case "FRM User":
                    tmsWait.Hard(5);
                    //Old code for pre 5.8 R2 tms tenant
                    //SelectElement user = new SelectElement(FRM.FRMAdministrator.WorkFlowAssignmentAssignedUser);
                    //user.SelectByText(value);

                    //New code post 5.8R2 tenant
                    By Drp3 = By.XPath("//kendo-dropdownlist[@test-id='workFlowAssignmnt-select-workflowUserFrmSelectID']//span[@class='k-select']");
                    By typeapp3 = By.XPath("//li[text()='" + value + "']");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp3);
                    tmsWait.Hard(3);
                    break;
                case "Status":
                    tmsWait.Hard(5);
                    //Old code for pre 5.8 R2 tms tenant
                    //SelectElement status = new SelectElement(FRM.FRMAdministrator.WorkFlowAssignmentStatus);
                    //status.SelectByText(value);

                    //New code post 5.8R2 tenant
                    By Drp4 = By.XPath("//kendo-dropdownlist[@test-id='workFlowAssignmnt-select-Statusw']//span[@class='k-select']");
                    By typeapp4 = By.XPath("//li[text()='" + value + "']");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp4);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp4);
                    tmsWait.Hard(3);
                    break;

                case "Discrepancy Status":
                    tmsWait.Hard(5);
                    //Old code for pre 5.8 R2 tms tenant
                    //SelectElement dis = new SelectElement(FRM.FRMAdministrator.WorkFlowAssignmentDiscrepancyStatus);
                    //dis.SelectByText(value);

                    //New code post 5.8R2 tenant
                    By Drp5 = By.XPath("//label[contains(.,'Discrepancy Status')]/parent::div//kendo-dropdownlist[@test-id='workFlowAssignmnt-select-workflowUserFrmSelectID']//span[@class='k-select']");
                    By typeapp5 = By.XPath("//li[text()='" + value + "']");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp5);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp5);
                    tmsWait.Hard(3);
                    break;

            }

        }


        [When(@"WorkFlow Assignment page Save button is clicked")]
        public void WhenWorkFlowAssignmentPageSaveButtonIsClicked()
        {
            fw.ExecuteJavascript(FRM.FRMAdministrator.WorkFlowAssignmentSavebutton);
            tmsWait.Hard(25); // Reason for more wait , In ESI FRM, huge records were there.
        }

        [Then(@"Verify Workflow Assignment page ""(.*)"" message is displayed")]
        public void ThenVerifyWorkflowAssignmentPageMessageIsDisplayed(string p0)
        {
            
            //tmsWait.Hard(10);
            //fw.ExecuteJavascript(FRM.FRMAdministrator.WorkFlowAssignmentSavebutton);
            //string expectedmsg = p0.ToString();
            //tmsWait.Hard(10);
            //tmsWait.WaitForElement(By.XPath("//label[@test-id='workFlowAssignmnt-lbl-SuccessMessage']"), 60);
            //IWebElement msg = Browser.Wd.FindElement(By.XPath("//label[@test-id='workFlowAssignmnt-lbl-Success'][contains(.,'"+p0+"')]"));
            string msg = Browser.Wd.FindElement(By.XPath("//label[@test-id='workFlowAssignmnt-lbl-SuccessMessage']")).Text;
            //Assert.IsTrue(msg.Displayed, p0 + " is not geting dislayed");
            Assert.IsTrue(msg.Contains(p0));

           // Assert.AreEqual(expectedmsg, FRM.FRMAdministrator.WorkFlowAssignmentStaticMsg.Text, p0 + " Message is displayed");
        }

        [Then(@"Verify Workflow Assignment page Close button is Clicked")]
        public void ThenVerifyWorkflowAssignmentPageCloseButtonIsClicked()
        {
            tmsWait.Hard(1);
            fw.ExecuteJavascript(FRM.FRMAdministrator.WorkFlowAssignmentCrossButton);
        }


        [When(@"WorkFlow Assignment page ""(.*)"" Option is Selected")]
        public void WhenWorkFlowAssignmentPageOptionIsSelected(string p0)
        {

            string option = p0.ToString();

            switch (option)
            {

                case "Batch of Discrepancies":
                    if (FRM.FRMAdministrator.WorkFlowAssignmentBatchofDes.Selected == true)
                    {
                        break;
                    }
                    else
                    {
                        fw.ExecuteJavascript(FRM.FRMAdministrator.WorkFlowAssignmentBatchofDes);
                        break;
                    }

                case "Assign to Specific User":

                    if (FRM.FRMAdministrator.WorkFlowAssignmentAssignSpecUser.Selected == true)
                    {
                        break;
                    }

                    else
                    {
                        fw.ExecuteJavascript(FRM.FRMAdministrator.WorkFlowAssignmentAssignSpecUser);
                        break;
                    }

                case "Batch of Members":
                    tmsWait.Hard(1);
                    fw.ExecuteJavascript(FRM.FRMAdministrator.WorkFlowAssignmentBatchofMembers);
                    tmsWait.Hard(1);
                    break;

                case "Update Status":
                    tmsWait.Hard(1);
                    fw.ExecuteJavascript(FRM.FRMAdministrator.WorkFlowAssignmentUpdateStatus);
                    break;

                case "Assign to a specified user and update status":
                    tmsWait.Hard(1);
                    fw.ExecuteJavascript(FRM.FRMAdministrator.WorkFlowAssignmentAssignSpecUserAndUpdatetatus);
                    break;

                case "Discrepancy to Specific User":
                    tmsWait.Hard(1);
                    fw.ExecuteJavascript(FRMWorkFlowPage.DiscrepancytoSpecificUser);
                    tmsWait.Hard(1);
                    break;
                case "Discrepancy Status":
                    tmsWait.Hard(1);
                    fw.ExecuteJavascript(FRMWorkFlowPage.DiscrepancyStatusNew);
                    tmsWait.Hard(1);
                    break;
                case "Update Discrepancy Status and assign to Specific User":
                    tmsWait.Hard(1);
                    fw.ExecuteJavascript(FRMWorkFlowPage.UpdateDiscrepancyStatusandassigntoSpecificUser);
                    break;
            }
        }



        [Then(@"Verify Administration page Plan Star Ratings table dislayed row")]
        public void ThenVerifyAdministrationPagePlanStarRatingsTableDislayedRow(Table table)
        {



            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = FRM.FRMAdministrator.PlanStarRatingsTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                //            thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 2)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[2];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                //else
                //{
                //    //Click next page link and start over.
                //    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                //    {
                //        thisTP.bNotAtLastPageOfRecords = true;
                //        thisTP.NPL.Click();
                //        tmsWait.Hard(2);
                //    }
                //}
                baseTable = FRM.FRMAdministrator.PlanStarRatingsTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }

        }



        [Then(@"Administrator section page ""(.*)"" submenu is Clicked")]
        public void ThenAdministratorSectionPageSubmenuIsClicked(string p0)
        {
            string submenu = p0.ToString();

            switch (submenu)
            {

                case "Plan Star Ratings":
                    FRMMainNavigation.FRMAdministartormenuplanStarRatings.Click();
                    break;

            }
        }


        [When(@"Administrator menu ""(.*)"" submenu is Clicked")]
        [Then(@"Administrator menu ""(.*)"" submenu is Clicked")]
        public void WhenAdministratorMenuSubmenuIsClicked(string p0)
        {
            tmsWait.Hard(2);
            String expectedMenu = p0.ToString();
            switch (expectedMenu)
            {
                case "Batch Enroll/Disenroll":
                    FRMMainNavigation.FRMAdministartormenubatchEnrollDisenroll.Click();
                    break;
                case "Export Monthly Extract":
                    fw.ExecuteJavascript(FRMMainNavigation.FRMAdministartormenuexportMonthlyExtract);
                    break;
                case "Batch Update":
                    FRMMainNavigation.FRMAdministartormenubatchUpdate.Click();
                    break;
                default:
                    fw.ConsoleReport(" Please provide correct Menu details");
                    break;
            }
        }


        [When(@"FRM Next Page Administrator Section Change Plan ID menu is Clicked")]
        public void WhenFRMNextPageAdministratorSectionChangePlanIDMenuIsClicked()
        {
            FRM.FRMAdministrator.ChangePlanIDmenu.Click();
        }

        [Then(@"Verify Change Plan ID page HIC Number text box is displayed")]
        public void ThenVerifyChangePlanIDPageHICNumberTextBoxIsDisplayed()
        {

            bool actual = FRM.FRMAdministrator.ChangePlanHICNumber.Displayed;

            Assert.IsTrue(actual, "Change Plan ID page HIC Number text box is displayed");
        }

        [Then(@"Verify Change Plan ID page Part C Option button is displayed")]
        public void ThenVerifyChangePlanIDPagePartCOptionButtonIsDisplayed()
        {
            bool actual = FRM.FRMAdministrator.ChangePlanPartC.Displayed;

            Assert.IsTrue(actual, "Change Plan ID page Part C option is displayed");
        }

        [Then(@"Verify Change Plan ID page Part D Option button is displayed")]
        public void ThenVerifyChangePlanIDPagePartDOptionButtonIsDisplayed()
        {
            bool actual = FRM.FRMAdministrator.ChangePlanPartD.Displayed;

            Assert.IsTrue(actual, "Change Plan ID page Part C option is displayed");
        }

        [Then(@"Verify Change Plan ID page New Plan ID Drop down list is displayed")]
        public void ThenVerifyChangePlanIDPageNewPlanIDDropDownListIsDisplayed()
        {
            bool actual = FRM.FRMAdministrator.NewPlanIDDropdown.Displayed;

            Assert.IsTrue(actual, "Change Plan ID page New Plan ID Drop down list is displayed");
        }

        [Then(@"Verify Change Plan ID page Add button is displayed")]
        public void ThenVerifyChangePlanIDPageAddButtonIsDisplayed()
        {
            bool actual = FRM.FRMAdministrator.ChangePlanAddButton.Displayed;

            Assert.IsTrue(actual, "Change Plan ID page Add Button is displayed");
        }

        [Then(@"Verify Change Plan ID page Remove button is displayed")]
        public void ThenVerifyChangePlanIDPageRemoveButtonIsDisplayed()
        {
            bool actual = FRM.FRMAdministrator.ChangePlanRemoveButton.Displayed;

            Assert.IsTrue(actual, "Change Plan ID page Remove Button is displayed");
        }

        [Then(@"Verify Change Plan ID page Add New button is displayed")]
        public void ThenVerifyChangePlanIDPageAddNewButtonIsDisplayed()
        {
            bool actual = FRM.FRMAdministrator.ChangePlanAddNewbutton.Displayed;

            Assert.IsTrue(actual, "Change Plan ID page Add New Button is displayed");
        }

        [Then(@"Verify Change Plan ID page Reset button is displayed")]
        public void ThenVerifyChangePlanIDPageResetButtonIsDisplayed()
        {
            bool actual = FRM.FRMAdministrator.ChangePlanReset.Displayed;

            Assert.IsTrue(actual, "Change Plan ID page Reset Button is displayed");
        }

        [Then(@"Verify Change Plan ID page Save button is displayed")]
        public void ThenVerifyChangePlanIDPageSaveButtonIsDisplayed()
        {
            bool actual = FRM.FRMAdministrator.ChangePlanSave.Displayed;

            Assert.IsTrue(actual, "Change Plan ID page Save Button is displayed");
        }


        [When(@"FRM Next Page Administrator Section Change Individual HIC menu is Clicked")]
        public void WhenFRMNextPageAdministratorSectionChangeIndividualHICMenuIsClicked()
        {
            fw.ExecuteJavascript(FRM.FRMAdministrator.FRMAdministratorChangeIndividualHICmenu);
                //FRM.FRMAdministrator.FRMAdministratorChangeIndividualHICmenu.Click();
        }

        [When(@"Change Individual HIC page Existing HIC Number text box is set to ""(.*)""")]
        public void WhenChangeIndividualHICPageExistingHICNumberTextBoxIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            IWebElement MBI_Lookup_Icon = Browser.Wd.FindElement(By.XPath("//a[@test-id='deleteSubmittedDiagnosis-a-providerLookup']"));
            fw.ExecuteJavascript(MBI_Lookup_Icon);
            tmsWait.Hard(10);
            IWebElement MBI_TxtBox_onLookup = Browser.Wd.FindElement(By.XPath("//input[@test-id='member-txt-hic']"));
            MBI_TxtBox_onLookup.SendKeys(value);
            IWebElement MBI_Lookup_searchBtn = Browser.Wd.FindElement(By.XPath("//button[@test-id='member-btn-search']"));
            fw.ExecuteJavascript(MBI_Lookup_searchBtn);
            tmsWait.Hard(3);
            IWebElement MBI_checkbox = Browser.Wd.FindElement(By.XPath("(//input[@type='checkbox'])[1]"));
            fw.ExecuteJavascript(MBI_checkbox);
            tmsWait.Hard(1);
            IWebElement MBI_AddBtn = Browser.Wd.FindElement(By.XPath("//button[@test-id='member-btn-add']"));
            fw.ExecuteJavascript(MBI_AddBtn);
            tmsWait.Hard(1);
            //FRMAdministrator.ExistingNumberHicID.SendKeys(value);
        }


        [When(@"Change Individual HIC page New HIC Number text box is set to ""(.*)""")]
        public void WhenChangeIndividualHICPageNewHICNumberTextBoxIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            FRMAdministrator.NewNumberHicID.SendKeys(value);
        }

        [When(@"Warning dialog Yes Change HIC button is Clicked")]
        public void WhenWarningDialogYesChangeHICButtonIsClicked()
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(FRM.FRMAdministrator.ChangeHICWarningYes);

            tmsWait.Hard(10);
        }

        [When(@"Change Individual MBI page Reason is set to ""(.*)""")]
        public void WhenChangeIndividualMBIPageReasonIsSetTo(string p0)
        {
            String reason = tmsCommon.GenerateData(p0).ToUpper();
            AngularFunction.selectDropDownValue(FRMAdministrator.ReasonDropdown,reason);
            
        }


        [When(@"Change Individual HIC page Update button is Clicked")]
        public void WhenChangeIndividualHICPageUpdateButtonIsClicked()
        {
           
            tmsWait.Hard(5);
            fw.ExecuteJavascript(FRM.FRMAdministrator.Updatebutton);
        }


        [When(@"Change Individual HIC page Reason drop down list ""(.*)"" is selected")]
        public void WhenChangeIndividualHICPageReasonDropDownListIsSelected(string pp)
        {
            tmsWait.Hard(1);
            string p0 = tmsCommon.GenerateData(pp).ToUpper();
            AngularFunction.selectDropDownValue(FRMAdministrator.ReasonDropdown, p0);
            

        }


        [Then(@"Verify Change Individual HIC page ""(.*)"" message is displayed")]
        public void ThenVerifyChangeIndividualHICPageMessageIsDisplayed(string p0)
        {
            tmsWait.Hard(2);
            string fieldName = "Change Individual HIC Page Message";
            string expected = tmsCommon.GenerateData(p0);
            string actual = FRM.FRMAdministrator.Errormessage.Text;
            Assert.AreEqual(expected, actual, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
            tmsWait.Hard(1);
        }

        [Then(@"Verify Change Individual HIC page ""(.*)"" sucess message is displayed")]
        public void ThenVerifyChangeIndividualHICPageSucessMessageIsDisplayed(string p0)
        {
            tmsWait.Hard(15);
            string fieldName = "Change Individual HIC Page Message";
            string expected = tmsCommon.GenerateData(p0);
            string oldMBI = Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='orsearch-mutisel-modeldisplay']//span[@class='ng-star-inserted']")).Text;
            string newMBI= Browser.Wd.FindElement(By.CssSelector("[id='newNumberHicID']")).GetAttribute("value");
            string actualFinal = oldMBI + expected + newMBI;
            string actualXpath = "//label[@test-id='changeIndHIC-lbl-oldHic'][contains(.,'"+ actualFinal + "')]";
            tmsWait.Hard(30);
            bool presence = Browser.Wd.FindElement(By.XPath(actualXpath)).Displayed;
            
            Assert.IsTrue(presence,"Expected value is not displayed");
          
        }

        [When(@"Change Individual HIC page Reset button is Clicked")]
        public void WhenChangeIndividualHICPageResetButtonIsClicked()
        {
            fw.ExecuteJavascript(FRM.FRMAdministrator.ChangeIndividualHICResetbutton);
        }

        [Then(@"Verify Change Individual HIC page Change Individual HIC page Existing HIC Number text box is set to ""(.*)""")]
        public void ThenVerifyChangeIndividualHICPageChangeIndividualHICPageExistingHICNumberTextBoxIsSetTo(string p0)
        {
            string fieldName = "Change Individual HIC Page Existing HICNumber TextBox";
            string expected = tmsCommon.GenerateData(p0);
            tmsWait.Hard(1);
            string actual = Browser.Wd.FindElement(By.XPath("//kendo-searchbar//input")).GetAttribute("value");//FRMAdministrator.ExistingNumberHicID.Text;
            Assert.AreEqual(expected, actual, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
            tmsWait.Hard(1);
        }

        [Then(@"Verify Change Individual HIC page New HIC Number text box is set to ""(.*)""")]
        public void ThenVerifyChangeIndividualHICPageNewHICNumberTextBoxIsSetTo(string p0)
        {
            string fieldName = "Change Individual HIC Page New HIC Number TextBox";
            string expected = tmsCommon.GenerateData(p0);
            tmsWait.Hard(1);
            string actual = FRMAdministrator.NewNumberHicID.Text;
            Assert.AreEqual(expected, actual, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
            tmsWait.Hard(1);
        }

        [Then(@"Verify Change Individual HIC page Reason drop down list is set to ""(.*)""")]
        public void ThenVerifyChangeIndividualHICPageReasonDropDownListIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string fieldName = " Change Individual HIC Page Reason Drop down list";
            By drpDefaultValue = By.XPath("//kendo-dropdownlist[@test-id='changeIndHIC-select-reasonHicID']//span[@class='k-input'][contains(.,'Select')]");
            string actual = Browser.Wd.FindElement(drpDefaultValue).Text;
            string expected = tmsCommon.GenerateData(p0);
            Assert.AreEqual(expected, actual, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
            tmsWait.Hard(1);
        }



        [Then(@"Verify Change Individual HIC page Existing HIC Number text box is displayed")]
        public void ThenVerifyChangeIndividualHICPageExistingHICNumberTextBoxIsDisplayed()
        {

            tmsWait.Hard(2);
            bool actual = FRMAdministrator.ExistingNumberHicID.Displayed;

            Assert.IsTrue(actual, "Change Individual MBI page Existing MBI Number text box is displayed");

        }


        [Then(@"Verify Change Individual HIC page Existing MBI Lookup is displayed")]
        public void ThenVerifyChangeIndividualHICPageExistingMBILookupIsDisplayed()
        {
            IWebElement MBI_Lookup_Icon = Browser.Wd.FindElement(By.XPath("//a[@test-id='deleteSubmittedDiagnosis-a-providerLookup']"));
            fw.ExecuteJavascript(MBI_Lookup_Icon);
            tmsWait.Hard(10);
           
            bool actual = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Search Existing MBI')]")).Displayed;

            Assert.IsTrue(actual, "Change Individual MBI page Existing MBI Number text box is displayed");

            By cancel = By.CssSelector("[test-id='member-btn-cancel']");
            AngularFunction.clickOnElement(cancel);
            tmsWait.Hard(4);
        }




        [Then(@"Verify Change Individual HIC page New HIC Number text box is displayed")]
        public void ThenVerifyChangeIndividualHICPageNewHICNumberTextBoxIsDisplayed()
        {
            tmsWait.Hard(2);
            bool actual = FRMAdministrator.NewNumberHicID.Displayed;

            Assert.IsTrue(actual, "Change Individual HIC page New Number HIC ID text box is displayed");
        }

        [Then(@"Verify Change Individual HIC page Reason drop down list is displayed")]
        public void ThenVerifyChangeIndividualHICPageReasonDropDownListIsDisplayed()
        {
            tmsWait.Hard(2);
            bool actual = FRM.FRMAdministrator.ReasonHicID.Displayed;

            Assert.IsTrue(actual, "Change Individual HIC page Reason HIC ID Drop down list is displayed");
        }




        [When(@"FRM ReportManager Search Button is clicked")]
        public void WhenIClickOnReportManagerClickButton()
        {
            FRM.ReportManagerSearch.Search.Click();
            tmsWait.Hard(1);
        }

        [When(@"FRM ReportManager Report Type value is set to ""(.*)""")]
        public void WhenISelectReportManagerReportType(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            FRM.ReportManagerSearch.ReportType.SendKeys(value);
            tmsWait.Hard(1);
        }

        [When(@"FRM ReportManager PlanID value is set to ""(.*)""")]
        public void WhenISelectReportManagerPlanID(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            FRM.ReportManagerSearch.PlanID.SendKeys(value);
            tmsWait.Hard(1);
        }

        [When(@"FRM ReportManager PBP value is set to ""(.*)""")]
        public void WhenISelectReportManagerPBP(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            FRM.ReportManagerSearch.PBP.SendKeys(value);
            tmsWait.Hard(1);
        }

        [Then(@"FRM Report Manager Reports are displayed")]
        public void ThenFRMReportManagerReportsAreDisplayed()
        {
            Assert.AreEqual(true, FRM.ReportManagerSearch.DataGrid.Displayed, "ReportManager search shows no datagrid.");
            Console.WriteLine("ReportManager search shows datagrid.");

        }


        [Given(@"I am logged in to TMS FRM with Config File Parameters")]
        public void GivenIAmLoggedInToTMSFRMWithConfigFileParameters()
        {
            ConfigFile.ReadFromConfigFile();
            Browser.SetWebdriverType(ConfigFile.BrowserType);
            Browser.Wd.Navigate().GoToUrl(ConfigFile.URL);
            Browser.Wd.Manage().Window.Maximize();
            tmsWait.Implicit(20);
        }

        [Then(@"Verify General Search page Search Criteria Accordion section Restore Previous Search checkbox is displayed")]
        public void ThenVerifyGeneralSearchPageSearchCriteriaAccordionSectionRestorePreviousSearchCheckboxIsDisplayed()
        {
            string fieldName = "Restore Previous Search check box";
            bool actual = FRM.FRMMainPage.GeneralSearchRestorePrevSearch.Displayed;
            string expected = "True";
            Assert.IsTrue(actual, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }

        [When(@"I noted One MBI from Search results")]
        public void WhenINotedOneMBIFromSearchResults()
        {
            tmsWait.Hard(4);
            IWebElement mbi = Browser.Wd.FindElement(By.XPath("(//div[@test-id='genSearchCrt-grid-generalGrid']//table/tbody/tr/td[2]/span)[3]"));
            GlobalRef.FRMMBI = mbi.Text;
            
        }


        [When(@"FRM Next page HIC Name Search tab is clicked")]
        public void WhenFRMNextPageHICNameSearchTabIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(FRM.FRMMainPage.HICNameSearchTab);
        }

        [When(@"HIC Name Search page Search Criteria Accordion section Claim HIC Text box is set ""(.*)""")]
        public void WhenHICNameSearchPageSearchCriteriaAccordionSectionClaimHICTextBoxIsSet(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            tmsWait.Hard(3);
            string mbi = GlobalRef.FRMMBI.ToString();
            FRM.FRMMainPage.HICNameSearchClaimHIC.SendKeys(mbi);
        }

        [When(@"HIC Name Search page Search Criteria Accordion section Claim HIC Text box is set to Variable ""(.*)""")]
        public void WhenHICNameSearchPageSearchCriteriaAccordionSectionClaimHICTextBoxIsSettoVariable(string parameter)
        {
            string value;
         
            switch (parameter)
            {
                case "MBI":
                    value = GlobalRef.MBI.ToString();
                    FRM.FRMMainPage.HICNameSearchClaimHIC.SendKeys(value);
                    break;
            }
        }

        [When(@"MBI Name Search page Search Criteria Accordion section Claim MBI Text box is set ""(.*)""")]
        public void WhenMBINameSearchPageSearchCriteriaAccordionSectionClaimMBITextBoxIsSet(string p0)
        {
            string value = tmsCommon.GenerateData(p0);

            FRM.FRMMainPage.HICNameSearchClaimHIC.SendKeys(value);
            tmsWait.Hard(1);
        }

        [When(@"MBI Name Search page Search Criteria Accordion section Partial MBI Text box is set ""(.*)""")]
        public void WhenMBINameSearchPageSearchCriteriaAccordionSectionPartialMBITextBoxIsSet(string p0)
        {
            string value = tmsCommon.GenerateData(p0);

            FRM.FRMMainPage.HICNameSearchClaimHIC.SendKeys(value.Substring(0,4));
            tmsWait.Hard(1);
        }

        [When(@"MBI Name Search page Claim MBI Text box is set ""(.*)""")]
        public void WhenMBINameSearchPageClaimMBITextBoxIsSet(string p0)
        {
            string value = tmsCommon.GenerateData(p0);

            FRM.FRMMainPage.HICNameSearchClaimHIC.SendKeys(value);
            tmsWait.Hard(1);
        }


        [When(@"MBI Name Search page Search Criteria Accordion section Claim MBI Text box is set to Variable ""(.*)""")]
        public void WhenMBINameSearchPageSearchCriteriaAccordionSectionClaimMBITextBoxIsSettoVariable(string parameter)
        {
            string value;

            switch (parameter)
            {
                case "MBI":
                    value = GlobalRef.MBI.ToString();
                    FRM.FRMMainPage.HICNameSearchClaimHIC.SendKeys(value);
                    break;
            }
        }


        [When(@"Verify HIC Name Search page Search Criteria Accordion section  Records From Previous General Search option button is selected")]
        public void WhenVerifyHICNameSearchPageSearchCriteriaAccordionSectionRecordsFromPreviousGeneralSearchOptionButtonIsSelected()
        {
            tmsWait.Hard(1);
            fw.ExecuteJavascript(FRM.FRMMainPage.HICNameSearchRecordsFromPrevGenSrch);
        }

        [When(@"Verify HIC Name Search page Search Criteria Accordion section Search button is Clicked")]
        public void WhenVerifyHICNameSearchPageSearchCriteriaAccordionSectionSearchButtonIsClicked()
        {
            fw.ExecuteJavascript(FRM.FRMMainPage.HICNameSearchSearchbutton);
            tmsWait.Hard(10);
        }

        [Then(@"Verify FRM Next page HIC Name Search Result Panel displays results")]
        public void ThenVerifyFRMNextPageHICNameSearchResultPanelDisplaysResults()
        {
            bool flag = false;
           
                IWebElement mbisearchtable = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='hicNameSearchgrid-grid-hicnameGridPreviousSearch']"));
                IReadOnlyCollection<IWebElement> rows = mbisearchtable.FindElements(By.TagName("tr"));
                int rowcount = rows.Count();
                if (rowcount >= 1)
                {
                    flag = true;
                }
           

            Assert.IsTrue(flag, "MBI search does not have the results. Please adjust your search criteria");
        }


        [Then(@"Verify FRM Next page HIC Name Search Result Panel displays Search results ""(.*)""")]
        public void ThenVerifyFRMNextPageHICNameSearchResultPanelDisplaysSearchResults(string p0)
        {
            tmsWait.Hard(3);
            string mbi = tmsCommon.GenerateData(p0);
            IWebElement elementPresence = Browser.Wd.FindElement(By.XPath("//div[@test-id='hicNameSearchgrid-grid-hicnameGrid']//div[contains(.,'"+mbi+"')]"));
            Assert.IsTrue(elementPresence.Displayed, mbi + "is not getting displaued");
        }

        [When(@"Verify HIC Name Search page Search Criteria Accordion section Records From Complete Database option button is selected")]
        public void WhenVerifyHICNameSearchPageSearchCriteriaAccordionSectionRecordsFromCompleteDatabaseOptionButtonIsSelected()
        {
            tmsWait.Hard(1);
            fw.ExecuteJavascript(FRM.FRMMainPage.HICNameSearchRecordsFromCompleteDB);
        }

        [When(@"HIC Name Search page Search Criteria Accordion section Last Name Text box is set to ""(.*)""")]
        public void WhenHICNameSearchPageSearchCriteriaAccordionSectionLastNameTextBoxIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            string mbi = tmsCommon.GenerateData(p0).Substring(0,2);
            FRM.FRMMainPage.HICNameSearchLastName.SendKeys(mbi);
        }
        [When(@"MBI Name Search page Search Criteria Accordion section Partial Last Name Text box is set ""(.*)""")]
        public void WhenMBINameSearchPageSearchCriteriaAccordionSectionPartialLastNameTextBoxIsSet(string p0)
        {
            tmsWait.Hard(1);
            string name = tmsCommon.GenerateData(p0).Substring(0, 2);
            FRM.FRMMainPage.HICNameSearchLastName.SendKeys(name);
        }


        [When(@"HIC Name Search page Search Criteria Accordion section Records From Complete Database option is selected")]
        public void WhenHICNameSearchPageSearchCriteriaAccordionSectionRecordsFromCompleteDatabaseOptionIsSelected()
        {
            fw.ExecuteJavascript(FRM.FRMMainPage.HICNameSearchRecordsFromCompleteDB);

        }
        [When(@"MBI Name Search section MBI Text box is set to ""(.*)""")]
        public void WhenMBINameSearchSectionMBITextBoxIsSetTo(string p0)
        {
            string mbi = tmsCommon.GenerateData(p0);
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='hicNameSearchCriteria-inp-txtHic']"));          
            ele.SendKeys(mbi);
        }


        [When(@"HIC Name Search page Search Criteria Accordion section is Clicked")]
        public void WhenHICNameSearchPageSearchCriteriaAccordionSectionIsClicked()
        {
            tmsWait.Hard(3);
            fw.ExecuteJavascript(FRM.FRMMainPage.HICNameSearchSearchCriteriaNEWAccordion);
            tmsWait.Hard(1);
        }


        [When(@"HIC Name Search page Search Criteria Accordion section Reset button is Clicked")]
        public void WhenHICNameSearchPageSearchCriteriaAccordionSectionResetButtonIsClicked()
        {
            fw.ExecuteJavascript(FRM.FRMMainPage.HICNameSearchResetbutton);
        }

        [Then(@"Verify HIC Name Search page Search Criteria Accordion section Claim HIC Text box value is""(.*)"" displayed")]
        public void ThenVerifyHICNameSearchPageSearchCriteriaAccordionSectionClaimHICTextBoxValueIsDisplayed(string p0)
        {

            tmsWait.Hard(2);
            string fieldName = " HIC Name Search page Search Criteria Accordion section Claim HIC Text box value";
            String actual = FRM.FRMMainPage.HICNameSearchClaimHIC.Text;
            string expected = tmsCommon.GenerateData(p0);
            Assert.AreEqual(expected, actual, "Field " + fieldName + " Expected is [" + expected + "], Actual [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " Expected is [" + expected + "], Actual [" + actual + "] - They are expected to match.");
            tmsWait.Hard(1);

        }


        [When(@"Verify HIC Name Search page Search Criteria Accordion section Search button is displayed")]
        public void WhenVerifyHICNameSearchPageSearchCriteriaAccordionSectionSearchButtonIsDisplayed()
        {
            tmsWait.Hard(2);
            string fieldName = " HIC Name Search page Search Criteria Accordion section Search button";
            bool actual = FRM.FRMMainPage.HICNameSearchSearchbutton.Displayed;
            string expected = "True";
            Assert.IsTrue(actual, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }




        [Then(@"Verify HIC Name Search page Search Criteria Accordion section Last Name Text box value is""(.*)"" displayed")]
        public void ThenVerifyHICNameSearchPageSearchCriteriaAccordionSectionLastNameTextBoxValueIsDisplayed(string p0)
        {
            tmsWait.Hard(2);
            string fieldName = " HIC Name Search page Search Criteria Accordion section Last Name Text box value";
            String actual = FRM.FRMMainPage.HICNameSearchLastName.Text;
            string expected = tmsCommon.GenerateData(p0);
            Assert.AreEqual(expected, actual, "Field " + fieldName + " Expected is [" + expected + "], Actual [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " Expected is [" + expected + "], Actual [" + actual + "] - They are expected to match.");
            tmsWait.Hard(1);

        }

        [Then(@"Verify HIC Name Search page Search Criteria Accordion section Claim HIC Text box is displayed")]
        public void ThenVerifyHICNameSearchPageSearchCriteriaAccordionSectionClaimHICTextBoxIsDisplayed()
        {

            string fieldName = "HIC Name Search page Search Criteria Accordion section Claim HIC Text box";
            bool actual = FRM.FRMMainPage.HICNameSearchClaimHIC.Displayed;
            string expected = "True";
            Assert.IsTrue(actual, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }

        [Then(@"Verify HIC Name Search page Search Criteria Accordion section Last Name Text box is displayed")]
        public void ThenVerifyHICNameSearchPageSearchCriteriaAccordionSectionLastNameTextBoxIsDisplayed()
        {

            string fieldName = "HIC Name Search page Search Criteria Accordion section Last Name Text box";
            bool actual = FRM.FRMMainPage.HICNameSearchLastName.Displayed;
            string expected = "True";
            Assert.IsTrue(actual, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }

        [Then(@"Verify HIC Name Search page Search Criteria Accordion section  ""(.*)"" option button is displayed")]
        public void ThenVerifyHICNameSearchPageSearchCriteriaAccordionSectionOptionButtonIsDisplayed(string p0)
        {

            tmsWait.Hard(1);
            string GenerateData = tmsCommon.GenerateData(p0);

            String setOptionbutton = GenerateData.ToLower();


            if (setOptionbutton.Equals("records from complete database"))
            {

                string fieldName = "Records from Complete Database ";
                bool actual = FRM.FRMMainPage.HICNameSearchRecordsFromCompleteDB.Enabled;

                string expected = "true";

                Assert.IsTrue(actual, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
                fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");



            }
            else if (setOptionbutton.Equals("records from previous general search"))
            {

                string fieldName = "Records from Previous General search ";

                bool actual = FRM.FRMMainPage.HICNameSearchRecordsFromPrevGenSrch.Enabled;

                string expected = "true";

                Assert.IsTrue(actual, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
                fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");

            }
        }

        [Then(@"Verify HIC Name Search page Search Criteria Accordion section Search button is displayed")]
        public void ThenVerifyHICNameSearchPageSearchCriteriaAccordionSectionSearchButtonIsDisplayed()
        {

            string fieldName = "HIC Name Search page Search Criteria Accordion section Search button";
            bool actual = FRM.FRMMainPage.HICNameSearchSearchbutton.Displayed;
            string expected = "True";
            Assert.IsTrue(actual, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], Actual [" + actual + "] - They are expected to match.");
        }

        [Then(@"Verify HIC Name Search page Search Criteria Accordion section Reset button is displayed")]
        public void ThenVerifyHICNameSearchPageSearchCriteriaAccordionSectionResetButtonIsDisplayed()
        {
            tmsWait.Hard(1);
            string fieldName = "HIC Name Search page Search Criteria Accordion section Reset button";
            bool actual = FRM.FRMMainPage.HICNameSearchResetbutton.Displayed;
            string expected = "True";
            Assert.IsTrue(actual, "Field " + fieldName + " value is [" + expected + "], Actual [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], Actual [" + actual + "] - They are expected to match.");
        }


        [Then(@"Verify General Search page Search Criteria Accordion section Part ""(.*)"" Option is displayed")]
        public void ThenVerifyGeneralSearchPageSearchCriteriaAccordionSectionPartOptionIsDisplayed(string p0)
        {
            tmsWait.Hard(2);
            string GenerateData = tmsCommon.GenerateData(p0);

            String setOptionbutton = GenerateData.ToLower();


            if (setOptionbutton.Equals("all"))
            {

                fw.ExecuteJavascript(FRM.FRMMainPage.GeneralSearchPartAllOption);
                tmsWait.Hard(1);
                string fieldName = "Part ";
                bool actual = FRM.FRMMainPage.GeneralSearchPartAllOption.Displayed;

                string expected = "true";

                Assert.IsTrue(actual, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
                fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");



            }
            else if (setOptionbutton.Equals("c"))
            {

                fw.ExecuteJavascript(FRM.FRMMainPage.GeneralSearchPartPartCOption);
                    tmsWait.Hard(5);
                    string fieldName = "Part ";

                     bool actual = FRM.FRMMainPage.GeneralSearchPartPartCOption.Displayed;

                    string expected = "true";

                    Assert.IsTrue(actual, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
                    fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
               
            }

            else if (setOptionbutton.Equals("d"))
            {

                fw.ExecuteJavascript(FRM.FRMMainPage.GeneralSearchPartPartDOption);
                tmsWait.Hard(1);
                string fieldName = "Part ";

                bool actual = FRM.FRMMainPage.GeneralSearchPartPartDOption.Displayed;
                string expected = "true";
                Assert.IsTrue(actual, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
                fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");

            }
        }

        [Then(@"Verify General Search page Search Criteria Accordion section ""(.*)"" drop downlist is displayed")]
        public void ThenVerifyGeneralSearchPageSearchCriteriaAccordionSectionDropDownlistIsDisplayed(string p0)
        {
            tmsWait.Hard(1);
            string GenerateData = tmsCommon.GenerateData(p0);

            String setOptionbutton = GenerateData.ToLower();


            if (setOptionbutton.Equals("from"))
            {

                string fieldName = setOptionbutton;
                bool actual = FRM.FRMMainPage.GeneralSearchPaymentMonthsFromDropdown.Displayed;

                string expected = "True";

                Assert.IsTrue(actual, "Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "]");
                fw.ConsoleReport("   Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");


            }
            else if (setOptionbutton.Equals("to"))
            {

                string fieldName = setOptionbutton;
                bool actual = FRM.FRMMainPage.GeneralSearchPaymentMonthsToDropdown.Displayed;
                string expected = "True";
                Assert.IsTrue(actual, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
                fw.ConsoleReport("   Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");

            }
            else if (setOptionbutton.Equals("discrepancy type"))
            {

                string fieldName = setOptionbutton;
                bool actual = FRM.FRMMainPage.GeneralSearchDiscrepancyTypeAllDropdown.Displayed;
                string expected = "True";
                Assert.IsTrue(actual, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
                fw.ConsoleReport("   Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");

            }
            else if (setOptionbutton.Equals("to"))
            {

                string fieldName = setOptionbutton;
                bool actual = FRM.FRMMainPage.GeneralSearchPaymentMonthsToDropdown.Displayed;
                string expected = "True";
                Assert.IsTrue(actual, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
                fw.ConsoleReport("   Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");

            }
            else if (setOptionbutton.Equals("planid"))
            {

                string fieldName = setOptionbutton;
                bool actual = FRM.FRMMainPage.GeneralSearchPlanIDDropdown.Displayed;
                string expected = "True";
                Assert.IsTrue(actual, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
                fw.ConsoleReport("   Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");

            }
            else if (setOptionbutton.Equals("pbp"))
            {

                string fieldName = setOptionbutton;
                bool actual = FRM.FRMMainPage.GeneralSearchPBPDropdown.Displayed;
                string expected = "True";
                Assert.IsTrue(actual, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
                fw.ConsoleReport("   Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");

            }

            else if (setOptionbutton.Equals("grp/ipa"))
            {

                string fieldName = setOptionbutton;
                bool actual = FRM.FRMMainPage.GeneralSearchGRPIPADropdown.Displayed;
                string expected = "True";
                Assert.IsTrue(actual, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
                fw.ConsoleReport("   Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");

            }
            else if (setOptionbutton.Equals("status"))
            {

                string fieldName = setOptionbutton;
                bool actual = FRM.FRMMainPage.GeneralSearchStatusDropdown.Displayed;
                string expected = "True";
                Assert.IsTrue(actual, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
                fw.ConsoleReport("   Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");

            }

            else if (setOptionbutton.Equals("age of discrepancy"))
            {

                string fieldName = setOptionbutton;
                bool actual = FRM.FRMMainPage.GeneralSearchAgeofDiscrepancyDropdown.Displayed;
                string expected = "True";
                Assert.IsTrue(actual, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
                fw.ConsoleReport("   Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");

            }

            else if (setOptionbutton.Equals("user"))
            {

                string fieldName = setOptionbutton;
                bool actual = FRM.FRMMainPage.GeneralSearchUserDropdown.Displayed;
                string expected = "True";
                Assert.IsTrue(actual, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
                fw.ConsoleReport("   Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");

            }


        }

        [Then(@"Verify General Search page Search Criteria Accordion section Reset button is displayed")]
        public void ThenVerifyGeneralSearchPageSearchCriteriaAccordionSectionResetButtonIsDisplayed()
        {
            string fieldName = "Reset Button";
            bool actual = FRM.FRMMainPage.GeneralSearchSearchButton.Displayed;
            string expected = "True";
            Assert.IsTrue(actual, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }

        [Then(@"Verify General Search page Search Criteria Accordion section Search button is displayed")]
        public void ThenVerifyGeneralSearchPageSearchCriteriaAccordionSectionSearchButtonIsDisplayed()
        {
            string fieldName = "Search Button";
            bool actual = FRM.FRMMainPage.GeneralSearchSearchButton.Displayed;
            string expected = "True";
            Assert.IsTrue(actual, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }

        [When(@"FRM Next page Top (.*) Over Under Payment tab is clicked")]
        public void WhenFRMNextPageTopOverUnderPaymentTabIsClicked(int p0)
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(FRM.FRMMainPage.Top50OverUnderPaymentTab);
        }

        [When(@"Top (.*) Over Under Payment page Discrepancy Type is set to ""(.*)""")]
        public void WhenTopOverUnderPaymentPageDiscrepancyTypeIsSetTo(int p0, string value)
        {
            IWebElement discrepancy = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='topFiftyPaymnts-select-topfiftyDiscrepancyType']//span[@class='k-select']"));
            AngularFunction.selectDropDownValue(discrepancy, value);
            tmsWait.Hard(1);
        }

        [When(@"Top (.*) Over Under Payment page Plan ID is set to ""(.*)""")]
        public void WhenTopOverUnderPaymentPagePlanIDIsSetTo(int p0, string value)
        {
            IWebElement discrepancy = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='topFiftyPaymnts-select-topfiftyPlanId']//span[@class='k-select']"));
            AngularFunction.selectDropDownValue(discrepancy, value);
            tmsWait.Hard(1);
        }

        [When(@"Top (.*) Over Under Payment page Payment Month From is set to ""(.*)""")]
        public void WhenTopOverUnderPaymentPagePaymentMonthFromIsSetTo(int p0, string value)
        {

            IWebElement discrepancy = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='topFiftyPaymnts-select-topfiftyFromMonth']//span[@class='k-select']"));
            AngularFunction.selectDropDownValue(discrepancy, value);
            tmsWait.Hard(1);
          
        }
        [When(@"Top (.*) Over Under Payment page Payment Month To is set to ""(.*)""")]
        public void WhenTopOverUnderPaymentPagePaymentMonthToIsSetTo(int p0, string value)
        {
            IWebElement discrepancy = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='topFiftyPaymnts-select-topfiftyToMonth']//span[@class='k-select']"));
            AngularFunction.selectDropDownValue(discrepancy, value);
            tmsWait.Hard(1);
          
        }

        [When(@"Top (.*) Over Under Payment page Search buttion is Clicked")]
        public void WhenTopOverUnderPaymentPageSearchButtionIsClicked(int p0)
        {
            IWebElement button = Browser.Wd.FindElement(By.CssSelector("[test-id='topFiftyPaymnts-btn-topfiftySearch']"));
            fw.ExecuteJavascript(button);
            tmsWait.Hard(4);
        }

        [When(@"FRM Next page General Search button is clicked")]
        public void WhenFRMNextPageGeneralSearchButtonIsClicked()
        {
            tmsWait.Hard(2);
            IWebElement all = Browser.Wd.FindElement(By.CssSelector("[test-id='genSearchCrt-inp-partValue1']"));
            fw.ExecuteJavascript(all);
            tmsWait.Hard(2);
          
            IWebElement button = Browser.Wd.FindElement(By.CssSelector("[test-id='genSearchCrt-btn-btnSearch']"));
            fw.ExecuteJavascript(button);
            tmsWait.Hard(4);
        }

        [Then(@"Verify Compare Flags Plan vs CMS page displayed Part C option button")]
        public void ThenVerifyCompareFlagsPlanVsCMSPageDisplayedPartCOptionButton()
        {
            bool presence = Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainCmprFlag-lbl-radioPartc']")).Displayed;
            Assert.IsTrue(presence, " Expected element is not getting displayed");
            tmsWait.Hard(2);
        }

        [Then(@"Verify Compare Flags Plan vs CMS page displayed Part D option button")]
        public void ThenVerifyCompareFlagsPlanVsCMSPageDisplayedPartDOptionButton()
        {
            bool presence = Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainCmprFlag-lbl-radioPartd']")).Displayed;
            Assert.IsTrue(presence, " Expected element is not getting displayed");
            tmsWait.Hard(2);
        }
        [Then(@"Verify Compare Flags Plan vs CMS page displayed Flag Type option button")]
        public void ThenVerifyCompareFlagsPlanVsCMSPageDisplayedFlagTypeOptionButton()
        {
            bool presence = Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainCmprFlag-lbl-flagType']")).Displayed;
            Assert.IsTrue(presence, " Expected element is not getting displayed");
        }

        [Then(@"Verify Compare Flags Plan vs CMS page displayed Payment Month option button")]
        public void ThenVerifyCompareFlagsPlanVsCMSPageDisplayedPaymentMonthOptionButton()
        {
            bool presence = Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainCmprFlag-lbl-paymentMonth1']")).Displayed;
            Assert.IsTrue(presence, " Expected element is not getting displayed");
        }
        [Then(@"Verify Compare Flags Plan vs CMS page displayed Indicator Type drop down list")]
        public void ThenVerifyCompareFlagsPlanVsCMSPageDisplayedIndicatorTypeDropDownList()
        {
            By Drp = By.XPath("//label[contains(.,'Indicator (Flag) Type')]/parent::div//span[@class='k-select']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            tmsWait.Hard(3);
        }

        [When(@"Member Payment Summary page Generate Report button is Clicked")]
        public void WhenMemberPaymentSummaryPageGenerateReportButtonIsClicked()
        {
            IWebElement button = Browser.Wd.FindElement(By.CssSelector("[test-id='membrPaySumry-btn-generateReport']"));
            fw.ExecuteJavascript(button);
            tmsWait.Hard(5);
        }


        //[When(@"Member Summary page ""(.*)"" link is Clicked")]
        //public void WhenMemberSummaryPageLinkIsClicked(string p0)
        //{
        //    IWebElement button = Browser.Wd.FindElement(By.LinkText(p0));
        //    fw.ExecuteJavascript(button);
        //    tmsWait.Hard(4);
        //}

        [Then(@"Verify system displayed ""(.*)"" page")]
        public void ThenVerifySystemDisplayedPage(string p0)
        {
            tmsWait.Hard(4);
            string GenerateData = tmsCommon.GenerateData(p0);
            bool presence = Browser.Wd.FindElement(By.XPath("//span[contains(.,'"+p0+"')]")).Displayed;
            Assert.IsTrue(presence, p0 + "is not getting displayed");
        }




        [Then(@"Verify Top (.*) Over Under Payment page Search Criteria Accordion section ""(.*)"" drop downlist is displayed")]
        public void ThenVerifyTopOverUnderPaymentPageSearchCriteriaAccordionSectionDropDownlistIsDisplayed(int p0, string p1)
        {

            tmsWait.Hard(1);
            string GenerateData = tmsCommon.GenerateData(p1);

            String setOptionbutton = GenerateData.ToLower();


            if (setOptionbutton.Equals("discrepancy type"))
            {

                string fieldName = setOptionbutton;
                bool actual = FRM.FRMMainPage.Top50DiscrepancyTypeDropdown.Displayed;

                string expected = "True";

                Assert.IsTrue(actual, "Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "]");
                fw.ConsoleReport("   Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");

            }
            else if (setOptionbutton.Equals("planid"))
            {

                string fieldName = setOptionbutton;
                bool actual = FRM.FRMMainPage.Top50PlanIDDropdown.Displayed;

                string expected = "True";

                Assert.IsTrue(actual, "Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "]");
                fw.ConsoleReport("   Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");

            }
        }

        [Then(@"Verify Top (.*) Over Under Payment page Search Criteria Accordion section Payment Months""(.*)"" drop downlist is displayed")]
        public void ThenVerifyTopOverUnderPaymentPageSearchCriteriaAccordionSectionPaymentMonthsDropDownlistIsDisplayed(int p0, string p1)
        {
            tmsWait.Hard(1);
            string GenerateData = tmsCommon.GenerateData(p1);

            String setOptionbutton = GenerateData.ToLower();


            if (setOptionbutton.Equals("from"))
            {

                string fieldName = setOptionbutton;
                bool actual = FRM.FRMMainPage.Top50PaymentMonthsFromDropdown.Displayed;

                string expected = "True";

                Assert.IsTrue(actual, "Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "]");
                fw.ConsoleReport("   Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");

            }
            else if (setOptionbutton.Equals("to"))
            {

                string fieldName = setOptionbutton;
                bool actual = FRM.FRMMainPage.Top50PaymentMonthsToDropdown.Displayed;

                string expected = "True";

                Assert.IsTrue(actual, "Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "]");
                fw.ConsoleReport("   Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");

            }
        }

        [Then(@"Verify Top (.*) Over Under Payment page Search Criteria Accordion section Reset button is displayed")]
        public void ThenVerifyTopOverUnderPaymentPageSearchCriteriaAccordionSectionResetButtonIsDisplayed(int p0)
        {
            string fieldName = "Reset Button";
            bool actual = FRM.FRMMainPage.Top50ResetButton.Displayed;
            string expected = "True";
            Assert.IsTrue(actual, "Field " + fieldName + " value is [" + expected + "], Actual [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], Actual [" + actual + "] - They are expected to match.");
        }

        [Then(@"Verify Top (.*) Over Under Payment page Search Criteria Accordion section Search button is displayed")]
        public void ThenVerifyTopOverUnderPaymentPageSearchCriteriaAccordionSectionSearchButtonIsDisplayed(int p0)
        {
            string fieldName = "Reset Button";
            bool actual = FRM.FRMMainPage.Top50SearchButton.Displayed;
            string expected = "True";
            Assert.IsTrue(actual, "Field " + fieldName + " value is [" + expected + "], Actual [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], Actual [" + actual + "] - They are expected to match.");
        }


        [Then(@"Verify Top (.*) Over Under Payment page Search Criteria Accordion section Discrepancy Type default value is ""(.*)""")]
        public void ThenVerifyTopOverUnderPaymentPageSearchCriteriaAccordionSectionDiscrepancyTypeDefaultValueIs(int p0, string p1)
        {
            tmsWait.Hard(2);
            string fieldName = " TOP 50 Over Under Payment Discrepancy Type Default value";


            string expected = tmsCommon.GenerateData(p1);

            IWebElement ddele = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@name='topfiftyDiscrepancyType']//span[@class='k-input']"));
            string actual = AngularFunction.getText(ddele).Trim();
          
            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }

        [Then(@"Verify Top (.*) Over Under Payment page Search Criteria Accordion section PlanID default value is ""(.*)""")]
        public void ThenVerifyTopOverUnderPaymentPageSearchCriteriaAccordionSectionPlanIDDefaultValueIs(int p0, string p1)
        {
            tmsWait.Hard(2);
            string fieldName = " TOP 50 Over Under Payment Plan ID Default value";

            string expected = tmsCommon.GenerateData(p1);

            IWebElement ddele = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@name='topfiftyPlanId']//span[@class='k-input']"));
            string actual = AngularFunction.getText(ddele).Trim();

            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }


        [Then(@"Verify FRM Next page ""(.*)"" tab is displayed")]
        public void ThenVerifyFRMNextPageTabIsDisplayed(string p0)
        {
            if (p0.Equals("Top 50 Over/Under Payment"))
            {
                fw.ExecuteJavascript(FRM.FRMMainPage.Top50OverUnderPaymentTab);
                tmsWait.Hard(1);
                string GenerateData = tmsCommon.GenerateData(p0);
                string fieldName = GenerateData;
                string actual = FRM.FRMMainPage.Top50OverUnderPaymentTab.Text;
                string expected = fieldName;
                Assert.AreEqual(actual, expected, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
                fw.ConsoleReport("   Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
            }
            else if (p0.Equals("MBI/Name Search"))
            {

                fw.ExecuteJavascript(FRM.FRMMainPage.HICNameSearchTab);
                tmsWait.Hard(1);
                string GenerateData = tmsCommon.GenerateData(p0);
                string fieldName = GenerateData;
                string actual = FRM.FRMMainPage.HICNameSearchTab.Text;
                string expected = fieldName;
                Assert.AreEqual(actual, expected, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
                fw.ConsoleReport("   Verification Point: Field " + fieldName.ToUpper() + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
            }

        }


        [Given(@"TMS FRM Application Home section is Clicked")]
        [When(@"TMS FRM Application Home section is Clicked")]
        public void GivenTMSFRMApplicationHomeSectionIsClicked()
        {
            tmsWait.Hard(12);
            fw.ExecuteJavascript(FRM.FRMAdministrator.FRMHomemenu);
            tmsWait.Hard(2);
        }


        [Given(@"FRM Next page General Search section Search Criteria Accordion Part ""(.*)"" is selected")]
        [When(@"FRM Next page General Search section Search Criteria Accordion Part ""(.*)"" is selected")]
        public void GivenFRMNextPageGeneralSearchSectionSearchCriteriaAccordionPartIsSelected(string p0)
        {
            tmsWait.Hard(2);
            string GenerateData = tmsCommon.GenerateData(p0);

            String setOptionbutton = GenerateData.ToLower();
            tmsWait.Hard(5);

            if (setOptionbutton.ToLower().Equals("all"))
            {

                fw.ExecuteJavascript(FRM.FRMMainPage.GeneralSearchPartAllOption);

            }
            else if (setOptionbutton.ToLower().Equals("c"))
            {
                tmsWait.Hard(2);
                fw.ExecuteJavascript(FRM.FRMMainPage.GeneralSearchPartPartCOption);
            }

            else if (setOptionbutton.ToLower().Equals("d"))
            {
                fw.ExecuteJavascript(FRM.FRMMainPage.GeneralSearchPartPartDOption);
            }

        }


        [Given(@"FRM Next page General Search section Search Criteria Accordion Discrepancy Type ""(.*)"" is selected")]
        [When(@"FRM Next page General Search section Search Criteria Accordion Discrepancy Type ""(.*)"" is selected")]
        public void GivenFRMNextPageGeneralSearchSectionSearchCriteriaAccordionDiscrepancyTypeIsSelected(string value)
        {

            //By Drp = By.XPath("//label[contains(.,'Discrepancy Type')]/parent::div//span[@class='k-select']");

            By Drp = By.XPath("//kendo-dropdownlist[@test-id='genSearchCrt-select-drpDescType']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + value + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            //AngularFunction.selectDropDownValue(Drp, p0);
         
            tmsWait.Hard(3);
        }

        [Given(@"FRM Next page General Search section Search Criteria Accordion Payment Months From ""(.*)"" is selected")]
        [When(@"FRM Next page General Search section Search Criteria Accordion Payment Months From ""(.*)"" is selected")]
        public void GivenFRMNextPageGeneralSearchSectionSearchCriteriaAccordionPaymentMonthsFromIsSelected(string p0)
        {
            By Drp = By.XPath("//kendo-dropdownlist[@id='drpPayFrom']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + p0 + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);

        }

        [When(@"Main page General Search tab Part D option is Clicked")]
        public void WhenMainPageGeneralSearchTabPartDOptionIsClicked()
        {
            By Drp = By.CssSelector("[test-id='genSearchCrt-inp-partValue3']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
            tmsWait.Hard(3);
        }


        [Given(@"FRM Next page General Search section Search Criteria Accordion Payment Months To ""(.*)"" is selected")]
        [When(@"FRM Next page General Search section Search Criteria Accordion Payment Months To ""(.*)"" is selected")]
        public void GivenFRMNextPageGeneralSearchSectionSearchCriteriaAccordionPaymentMonthsToIsSelected(string p0)
        {
            By Drp = By.XPath("//kendo-dropdownlist[@id='drpPayTo']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + p0 + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
        }

        [Given(@"FRM Next page General Search section Search Criteria Accordion PlanID ""(.*)"" is selected")]
        [When(@"FRM Next page General Search section Search Criteria Accordion PlanID ""(.*)"" is selected")]
        public void GivenFRMNextPageGeneralSearchSectionSearchCriteriaAccordionPlanIDIsSelected(string p0)
        {
            By Drp = By.XPath("//label[contains(.,'Plan ID')]/parent::div//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + p0 + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
        }

        [Given(@"FRM Next page General Search section Search Criteria Accordion PBP ""(.*)"" is selected")]
        [When(@"FRM Next page General Search section Search Criteria Accordion PBP ""(.*)"" is selected")]
        public void GivenFRMNextPageGeneralSearchSectionSearchCriteriaAccordionPBPIsSelected(string p0)
        {
            By Drp = By.XPath("//label[contains(.,'PBP')]/parent::div//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + p0 + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
        }

        [Given(@"FRM Next page General Search section Search Criteria Accordion GRP/IPA ""(.*)"" is selected")]
        [When(@"FRM Next page General Search section Search Criteria Accordion GRP/IPA ""(.*)"" is selected")]
        public void GivenFRMNextPageGeneralSearchSectionSearchCriteriaAccordionGRPIPAIsSelected(string p0)
        {
            By Drp = By.XPath("//label[contains(.,'GRP/IPA')]/parent::div//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + p0 + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
        }

        [Then(@"Verify General Search page displayed ""(.*)"" option is selected as Default")]
        public void ThenVerifyGeneralSearchPageDisplayedOptionIsSelectedAsDefault(string p0)
        {
            string section = p0.ToString();
            bool elementSelected;
            By loc;
            switch (section)
            {
                case "Part C":
                    loc = By.XPath("//input[@test-id='genSearchCrt-inp-partValue2']");
                    elementSelected = Browser.Wd.FindElement(loc).Selected;
                    Assert.IsTrue(elementSelected, "Elements is not slected");
                    break;
                case "Part D":
                    loc = By.XPath("//input[@test-id='genSearchCrt-inp-partValue3']");
                    elementSelected = Browser.Wd.FindElement(loc).Selected;
                    Assert.IsTrue(elementSelected, "Elements is not slected");
                    break;
            }
        }


        [Given(@"FRM Next page General Search section Search Criteria Accordion Status ""(.*)"" is selected")]
        [When(@"FRM Next page General Search section Search Criteria Accordion Status ""(.*)"" is selected")]
        public void GivenFRMNextPageGeneralSearchSectionSearchCriteriaAccordionStatusIsSelected(string p0)
        {
            By Drp = By.XPath("//label[contains(.,'Status')]/parent::div//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + p0 + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
        }

        [Given(@"FRM Next page General Search section Search Criteria Accordion Age of Discrepancy ""(.*)"" is selected")]
        [When(@"FRM Next page General Search section Search Criteria Accordion Age of Discrepancy ""(.*)"" is selected")]
        public void GivenFRMNextPageGeneralSearchSectionSearchCriteriaAccordionAgeOfDiscrepancyIsSelected(string p0)
        {
            By Drp = By.XPath("//label[contains(.,'Age of Discrepancy')]/parent::div//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + p0 + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
        }

        [Given(@"FRM Next page General Search section Search Criteria Accordion User ""(.*)"" is selected")]
        [When(@"FRM Next page General Search section Search Criteria Accordion User ""(.*)"" is selected")]
        public void GivenFRMNextPageGeneralSearchSectionSearchCriteriaAccordionUserIsSelected(string p0)
        {
            By Drp = By.XPath("//label[contains(.,'User')]/parent::div//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + p0 + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
        }


        [Then(@"Verify FRM Next page General Search section Search Criteria Accordion Part value is set to ""(.*)""")]
        public void ThenVerifyFRMNextPageGeneralSearchSectionSearchCriteriaAccordionPartValueIsSetTo(string p0)
        {
            String expected = p0.ToString();
            string actual = null;
            tmsWait.Hard(1);
            string fieldName = "FRM Main General Search Part ";
            actual = FRM.FRMMainPage.GeneralSearchPartAllOption.Text;
            Assert.AreEqual(actual, expected, "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }

        [Then(@"Verify FRM Next page General Search section Search Criteria Accordion Part value is set to ""(.*)"" option")]
        public void ThenVerifyFRMNextPageGeneralSearchSectionSearchCriteriaAccordionPartValueIsSetToOption(string p0)
        {
            String expected = p0.ToString();            
            tmsWait.Hard(1);
            string fieldName = "FRM Main General Search Part ";
            bool actual = FRM.FRMMainPage.GeneralSearchPartPartDOptionBtn.Selected;

            Assert.IsTrue(actual, " General Search Part D Option is not selected as Default");
        }

        [Then(@"Verify FRM Next page General Search section Search Criteria Accordion Discrepancy Type value is set to ""(.*)"" value")]
        public void ThenVerifyFRMNextPageGeneralSearchSectionSearchCriteriaAccordionDiscrepancyTypeValueIsSetToValue(string p0)
        {
            string fieldName = "FRM Main General Search Discrepancy Type ";
            string actual = tmsCommon.GenerateData(p0);
            SelectElement dis = new SelectElement(FRM.FRMMainPage.GeneralSearchDiscrepancyTypeDropdown_ESI);
            string expected = dis.SelectedOption.Text.Trim();
            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }


        [Then(@"Verify FRM Next page General Search section Search Criteria Accordion Discrepancy Type value is set to ""(.*)""")]
        public void ThenVerifyFRMNextPageGeneralSearchSectionSearchCriteriaAccordionDiscrepancyTypeValueIsSetTo(string p0)
        {
            string fieldName = "FRM Main General Search Discrepancy Type ";
            string expected = tmsCommon.GenerateData(p0);

            //IWebElement ddele = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@id='drpDescType']//span[@class='k-select']"));
            //string actual=AngularFunction.getText(ddele).Trim();          
            //GlobalRef.Year = actual;          
            //Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            //fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");



            bool elementpresence = false;
            elementpresence = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@id='drpDescType']//span[contains(.,'" + expected + "')]")).Displayed;
            Assert.IsTrue(elementpresence, "Reset fucnctionality is not working");



        }

        [Then(@"Verify FRM Next page General Search section Search Criteria Accordion PlanID is set to ""(.*)""")]
        public void ThenVerifyFRMNextPageGeneralSearchSectionSearchCriteriaAccordionPlanIDIsSetTo(string p0)
        {
            string fieldName = "FRM Main General Search PlanID ";
            string expected = tmsCommon.GenerateData(p0);

            //IWebElement ddele = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='genSearchCrt-select-drpPlan']//span[@class='k-input']"));
            //string actual = AngularFunction.getText(ddele).Trim();
           
            //Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            //fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");

            bool elementpresence = false;
            elementpresence = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='genSearchCrt-select-drpPlan']//span[contains(.,'" + expected + "')]")).Displayed;
            Assert.IsTrue(elementpresence, "Reset fucnctionality is not working");
        }

        [Then(@"Verify FRM Next page General Search section Search Criteria Accordion PBP is set to ""(.*)""")]
        public void ThenVerifyFRMNextPageGeneralSearchSectionSearchCriteriaAccordionPBPIsSetTo(string p0)
        {
            string fieldName = "FRM Main General Search PBPID ";

            string expected = tmsCommon.GenerateData(p0);

            //IWebElement ddele = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='genSearchCrt-select-drpPbp']//span[@class='k-input']"));
            //string actual = AngularFunction.getText(ddele).Trim();

            //Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            //fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");

            bool elementpresence = false;
            elementpresence = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='genSearchCrt-select-drpPbp']//span[contains(.,'" + expected + "')]")).Displayed;
            Assert.IsTrue(elementpresence, "Reset fucnctionality is not working");
        }

        [Then(@"Verify FRM Next page General Search section Search Criteria Accordion GRP/IPA is set to ""(.*)""")]
        public void ThenVerifyFRMNextPageGeneralSearchSectionSearchCriteriaAccordionGRPIPAIsSetTo(string p0)
        {
            string fieldName = "FRM Main General Search GRP IPA ";

            string expected = tmsCommon.GenerateData(p0);

            //IWebElement ddele = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='genSearchCrt-select-drpIpa']//span[@class='k-input']"));
            //string actual = AngularFunction.getText(ddele).Trim();

            //Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            //fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");

            bool elementpresence = false;
            elementpresence = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='genSearchCrt-select-drpIpa']//span[contains(.,'" + expected + "')]")).Displayed;
            Assert.IsTrue(elementpresence, "Reset fucnctionality is not working");
        }

        [Then(@"Verify FRM Next page General Search section Search Criteria Accordion Status is set to ""(.*)""")]
        public void ThenVerifyFRMNextPageGeneralSearchSectionSearchCriteriaAccordionStatusIsSetTo(string p0)
        {
            string fieldName = "FRM Main General Search Status ";

            string expected = tmsCommon.GenerateData(p0);

            //IWebElement ddele = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='genSearchCrt-select-drpStatus']//span[@class='k-input']"));
            //string actual = AngularFunction.getText(ddele).Trim();

            //Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            //fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");

            bool elementpresence = false;
            elementpresence = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='genSearchCrt-select-drpStatus']//span[contains(.,'" + expected + "')]")).Displayed;
            Assert.IsTrue(elementpresence, "Reset fucnctionality is not working");
        }

        [Then(@"Verify FRM Next page General Search section Search Criteria Accordion Age of Discrepancy is set to ""(.*)""")]
        public void ThenVerifyFRMNextPageGeneralSearchSectionSearchCriteriaAccordionAgeOfDiscrepancyIsSetTo(string p0)
        {
            string fieldName = "FRM Main General Search Age of Discrepancy ";
            string expected = tmsCommon.GenerateData(p0);

            //IWebElement ddele = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='genSearchCrt-select-drpAge']//span[@class='k-input']"));
            //string actual = AngularFunction.getText(ddele).Trim();

            //Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            //fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");

            bool elementpresence = false;
            elementpresence = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='genSearchCrt-select-drpAge']//span[contains(.,'" + expected + "')]")).Displayed;
            Assert.IsTrue(elementpresence, "Reset fucnctionality is not working");
        }

        [Then(@"Verify FRM Next page General Search section Search Criteria Accordion User is set to ""(.*)""")]
        public void ThenVerifyFRMNextPageGeneralSearchSectionSearchCriteriaAccordionUserIsSetTo(string p0)
        {
            string fieldName = "FRM Main General Search User ";

            string expected = tmsCommon.GenerateData(p0);

            //IWebElement ddele = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='genSearchCrt-select-drpUser']//span[@class='k-input']"));
            //string actual = AngularFunction.getText(ddele).Trim();

            //Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            //fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");

            bool elementpresence = false;
            elementpresence = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='genSearchCrt-select-drpUser']//span[contains(.,'" + expected + "')]")).Displayed;
            Assert.IsTrue(elementpresence, "Reset fucnctionality is not working");
        }

        [Given(@"FRM Next page Top (.*) OverUnder Payment tab is Clicked")]
        public void GivenFRMNextPageTopOverUnderPaymentTabIsClicked(int p0)
        {
            tmsWait.Hard(2); // It will wait for FRM App to load
            fw.ExecuteJavascript(FRM.FRMMainPage.Top50OverUnderPaymentTab);
            tmsWait.Hard(2);
        }

        [Given(@"FRM Next page Top 50 OverUnder Payment section Search Criteria Accordion Discrepancy Type ""(.*)"" is selected")]
        public void GivenFRMNextPageTop50OverUnderPaymentSectionSearchCriteriaAccordionDiscrepancyTypeIsSelected(string discrepancyType)
        {
            tmsWait.Hard(1);
            AngularFunction.selectDropDownValue(FRM.FRMMainPage.Top50DiscrepancyTypeDropdown, discrepancyType);
           
        }

        [Given(@"FRM Next page Top 50 OverUnder Payment section Search Criteria Accordion Payment Months From ""(.*)"" is selected")]
        public void GivenFRMNextPageTop50OverUnderPaymentSectionSearchCriteriaAccordionPaymentMonthsFromIsSelected(string planID)
        {
            tmsWait.Hard(1);
            AngularFunction.selectDropDownValue(FRM.FRMMainPage.Top50PaymentMonthsFromDropdown, planID);
           
        }

        [Given(@"FRM Next page Top 50 OverUnder Payment section Search Criteria Accordion Payment Months To ""(.*)"" is selected")]
        public void GivenFRMNextPageTop50OverUnderPaymentSectionSearchCriteriaAccordionPaymentMonthsToIsSelected(string p1)
        {
            tmsWait.Hard(1);
            AngularFunction.selectDropDownValue(FRM.FRMMainPage.Top50PaymentMonthsToDropdown, p1);


           
        }

        [Given(@"FRM Next page Top 50 OverUnder Payment section Search Criteria Accordion Plan ID ""(.*)"" is selected")]
        public void GivenFRMNextPageTop50OverUnderPaymentSectionSearchCriteriaAccordionPlanIDIsSelected(string p1)
        {
            tmsWait.Hard(1);

            AngularFunction.selectDropDownValue(FRM.FRMMainPage.Top50PlanIDDropdown, p1);
           
        }

        [When(@"FRM Next page Top (.*) OverUnder Payment section Under Payment button button is clicked")]
        public void WhenFRMNextPageTopOverUnderPaymentSectionUnderPaymentButtonButtonIsClicked(int p0)
        {
            fw.ExecuteJavascript(FRM.FRMMainPage.Top50SearchUnderPaymentButton);
            tmsWait.Hard(2);
        }

        [Then(@"FRM Next page Top (.*) OverUnder Payment section Over Payment button button is clicked")]
        public void ThenFRMNextPageTopOverUnderPaymentSectionOverPaymentButtonButtonIsClicked(int p0)
        {
            fw.ExecuteJavascript(FRM.FRMMainPage.Top50SearchOverPaymentButton);
            tmsWait.Hard(2); ;
        }


        [When(@"FRM Next page Top 50 OverUnder Payment section Search Criteria Accordion Reset button is clicked")]
        public void WhenFRMNextPageTop50OverUnderPaymentSectionSearchCriteriaAccordionResetButtonIsClicked()
        {
            fw.ExecuteJavascript(FRM.FRMMainPage.Top50ResetButton);
        }
        [When(@"FRM Next page Top (.*) OverUnder Payment section Search Criteria Accordion Search button is clicked")]
        public void WhenFRMNextPageTopOverUnderPaymentSectionSearchCriteriaAccordionSearchButtonIsClicked(int p0)
        {
            tmsWait.Hard(1);
            fw.ExecuteJavascript(FRM.FRMMainPage.Top50SearchButton);
        }

        [Then(@"Verify FRM Next page Top (.*) OverUnder Payment section Search Result displayed")]
        public void ThenVerifyFRMNextPageTopOverUnderPaymentSectionSearchResultDisplayed(int p0)
        {
            bool flag = false;
                IWebElement overpaymenttable = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='topFiftyRslts-grid-topfiftyGd']"));
                IReadOnlyCollection<IWebElement> rows = overpaymenttable.FindElements(By.TagName("tr"));
                int rowcount = rows.Count();
                if (rowcount > 2)
                {
                    flag = true;
                }
            

            Assert.IsTrue(flag, "Overpayment table does not have the results");
        }

        [Then(@"Verify FRM Next page Top (.*) ""(.*)"" Payment section Search Result displayed")]
        public void ThenVerifyFRMNextPageTopPaymentSectionSearchResultDisplayed(int p0, string p1)
        {
            string paymode = tmsCommon.GenerateData(p1);
            bool flag = false;
                IWebElement overpaymenttable = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='topFiftyRslts-grid-topfiftyGd']"));
                IReadOnlyCollection<IWebElement> rows = overpaymenttable.FindElements(By.TagName("tr"));
                int rowcount = rows.Count();
                if (rowcount > 2)
                {
                    flag = true;
                }
           

            Assert.IsTrue(flag, "Overpayment table does not have the results");
        }


        [Then(@"Verify FRM Next page Top (.*) Over Under Payment section Previous button is disabled")]
        public void ThenVerifyFRMNextPageTopOverUnderPaymentSectionPreviousButtonIsDisabled(int p0)
        {

            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the previous page']")).GetAttribute("class").Contains("disabled"));
            //TablePaging thisTP = new TablePaging();

            //IWebElement baseTable = FRM.FRMMainPage.Top50SearchUnderOverPaymentResults;
            //IWebElement paginationSystem = FRM.FRMMainPage.Top50SearchPagination;
            //thisTP.PreviousPageLinkDisable(paginationSystem, "pagination-prev ng-scope disabled");


        }

        [Then(@"Verify HIC Name Search page Search Criteria Accordion section Search button is Clicked")]
        public void ThenVerifyHICNameSearchPageSearchCriteriaAccordionSectionSearchButtonIsClicked()
        {
            fw.ExecuteJavascript(FRM.FRMMainPage.HICNameSearchSearchbutton);

        }


        [Then(@"Payment History table has displayed row")]
        public void ThenPaymentHistoryTableHasDisplayedRow(Table table)
        {


            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = FRM.FRMMainPage.PaymentHistoryTable;
                IWebElement paginationSystem = FRM.FRMMainPage.NotesPaging;

                //Look for a next page link.  We will set 'last page of records' here also.
                //thisTP.LoadNextPageLink(baseTable);
                thisTP.LoadDIVNextPageLink(paginationSystem, "pagination-next ng-scope");

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                //   thisTP.LoadPageTable(baseTable, "td", "td");
                thisTP.LoadDIVPageTable(baseTable, "ui-grid-row", "ui-grid-cell");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 2)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[2];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = FRM.FRMMainPage.PaymentHistoryTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

        [When(@"Member Summary Page Reason Codes look up link is Clicked")]
        public void WhenMemberSummaryPageReasonCodesLookUpLinkIsClicked()
        {
            fw.ExecuteJavascript(FRM.FRMMainPage.MemberSummaryReasonCode);
            tmsWait.Hard(4);
        }

        //[Then(@"Discrepancy Reason Code table has data ""(.*)""")]
        //public void ThenDiscrepancyReasonCodeTableHasData(string reasons)
        //{
        //    string[] reason = reasons.Split(';');
        //    string[] code = reason[0].Split(',');
        //    string[] description = reason[1].Split(',');
        //    for (int i = 0; i < code.Length; i++)
        //    {
        //        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//table[contains(@class,'table-condensed')]//td[text()='" + code[i] + "']/following-sibling::td[text()='" + description[i] + "']")).Displayed, "Code:- " + code[i] + " and Description:- " + description[i] + " are missing.");
        //    }
        //}


        [Then(@"Discrepancy Reason Code table has data ""(.*)""")]
        public void ThenDiscrepancyReasonCodeTableHasData(string reasons)
        {
            Regex pattern = new Regex(@"\((?<name>.+?)=(?<value>.+?)\)");
            var d = Enumerable.Cast<Match>(pattern.Matches(reasons)).ToDictionary(m => m.Groups["name"].Value, m => m.Groups["value"].Value);
            foreach (KeyValuePair<string, string> pair in d)
            {
                
                Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='reasonCodes-grid-reasonCodesGrid']//td[contains(.,'" + pair.Key +"')]")).Displayed, "Code:- "+ pair.Key +" is missing");

                Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='reasonCodes-grid-reasonCodesGrid']//td[contains(.,'" + pair.Value +"')]")).Displayed, "Value:- " + pair.Value + " is missing");
            }
        }


        [Then(@"Discrepancy Reason Code table has below row")]
        public void ThenDiscrepancyReasonCodeTableHasBelowRow(Table table)
        {


            tmsWait.Hard(2);

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;
                tmsWait.Hard(2);
                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = FRM.ManageDiscrepancyStatusCode.DiscrepancyReasonCode;

                //Look for a next page link.  We will set 'last page of records' here also.
                //            thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 2)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[2];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                //else
                //{
                //    //Click next page link and start over.
                //    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                //    {
                //        thisTP.bNotAtLastPageOfRecords = true;
                //        thisTP.NPL.Click();
                //        tmsWait.Hard(2);
                //    }
                //}
                baseTable = FRM.ManageDiscrepancyStatusCode.DiscrepancyReasonCode;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }


        }


        [Then(@"Verify Member Summary Page Reason Codes look up table has Reason Code ""(.*)"" with Definition ""(.*)""")]
        public void ThenVerifyMemberSummaryPageReasonCodesLookUpTableHasReasonCodeWithDefinition(string p0, string p1)
        {
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//*[@id='auditMembersListGrid']//td[contains(.,'" + p0+ "')]")).Displayed);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//*[@id='auditMembersListGrid']//td[contains(.,'" + p1 + "')]")).Displayed);
        }



        [Then(@"Verify Member Summary Page Reason Codes look up table has row")]
        public void ThenVerifyMemberSummaryPageReasonCodesLookUpTableHasRow(Table table)
        {

            tmsWait.Hard(5);

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = FRM.FRMMainPage.MemberSummaryReasonCodeTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                //            thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 2)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[2];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                //else
                //{
                //    //Click next page link and start over.
                //    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                //    {
                //        thisTP.bNotAtLastPageOfRecords = true;
                //        thisTP.NPL.Click();
                //        tmsWait.Hard(2);
                //    }
                //}
                baseTable = FRM.FRMMainPage.MemberSummaryReasonCodeTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }





        }

        [When(@"Payment History Notes section Add New button button is Clicked")]
        public void WhenPaymentHistoryNotesSectionAddNewButtonButtonIsClicked()
        {
           
            tmsWait.Hard(4);
            
        IWebElement note = Browser.Wd.FindElement(By.XPath("//i[@class='fas fa-plus-square text-secondary cursorLink']"));
            fw.ExecuteJavascript(note);
            fw.ExecuteJavascript(FRM.FRMMainPage.AddNoteButton);

            //tmsWait.Hard(4);
            //if (tmsWait.IsAlertPresent())
            //{
            //    Browser.Wd.SwitchTo().Alert().Accept();
            //}



        }

        [When(@"Notes section ""(.*)"" field is set to ""(.*)""")]
        public void WhenNotesSectionFieldIsSetTo(string p0, string p1)
        {


            string field = p0.ToString();
            //string setValue = p1.ToString();
            string setValue = tmsCommon.GenerateData(p1);

            switch (field)
            {
                case "Notes Summary":
                    FRM.FRMMainPage.AddNoteTextArea.SendKeys(setValue);
                    break;

                case "Date Due":
                    FRM.FRMMainPage.ActionDueDate.SendKeys(setValue);
                    break;

                case "Date Completed":

                    FRM.FRMMainPage.ActionCompleteDate.SendKeys(DateTime.Today.ToString("MM/dd/yyyy"));
                    break;

                default:
                    fw.ConsoleReport(" There is no Link available");
                    break;

            }
        }



        [When(@"Notes section Save button is Clicked")]
        public void WhenNotesSectionSaveButtonIsClicked()
        {
            FRM.FRMMainPage.NotesSaveButton.Click();
            tmsWait.Hard(5);
        }

        [When(@"TMS FRM Member Summary page Back To List button is Clicked")]
        public void WhenTMSFRMMemberSummaryPageBackToListButtonIsClicked()
        {
            Browser.Wd.FindElement(By.CssSelector("a.popupTextHeader")).Click();
            tmsWait.Hard(2);
        }


        [Then(@"Note Summary table displayed row is edited")]
        public void ThenNoteSummaryTableDisplayedRowIsEdited(Table table)
        {
            //IJavaScriptExecutor jse = (IJavaScriptExecutor)Browser.Wd;
            //jse.ExecuteScript("window.scrollBy(0,250)", "");

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = FRM.FRMMainPage.NotesTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                //            thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 2)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[2];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same

                            if (bThisRowMatches)
                            {
                                tmsWait.Hard(1);

                                Browser.Wd.FindElement(By.XPath("//button[@title='edit']")).Click();

                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                //else
                //{
                //    //Click next page link and start over.
                //    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                //    {
                //        thisTP.bNotAtLastPageOfRecords = true;
                //        thisTP.NPL.Click();
                //        tmsWait.Hard(2);
                //    }
                //}
                baseTable = FRM.FRMMainPage.NotesTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }

            }
        }


        [Then(@"Verify Note Summary table displayed data as ""(.*)""")]
        public void ThenVerifyNoteSummaryTableDisplayedDataAs(string p0)
        {
            tmsWait.Hard(3);
            string note = tmsCommon.GenerateData(p0);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//td[contains(.,'"+note+"')]")).Displayed, note + " is not displayed.");
        }


        [Then(@"Verify Note Summary table displayed row")]
        public void ThenVerifyNoteSummaryTableDisplayedRow(Table table)
        {
            //IJavaScriptExecutor jse = (IJavaScriptExecutor)Browser.Wd;
            //jse.ExecuteScript("window.scrollBy(0,250)", "");

            tmsWait.Hard(5);

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = FRM.FRMMainPage.NotesTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                //            thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 2)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[2];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                //else
                //{
                //    //Click next page link and start over.
                //    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                //    {
                //        thisTP.bNotAtLastPageOfRecords = true;
                //        thisTP.NPL.Click();
                //        tmsWait.Hard(2);
                //    }
                //}
                baseTable = FRM.FRMMainPage.NotesTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }



        }

        [When(@"HIC Change History page Back to Record button is Clicked")]
        public void WhenHICChangeHistoryPageBackToRecordButtonIsClicked()
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(FRM.FRMHICChangeHistory.HICChangeHistoryBackToRecordbutton);
        }

        [When(@"HIC Name Search page Search Results section View Link for ""(.*)"" is clicked")]
        public void WhenHICNameSearchPageSearchResultsSectionViewLinkForIsClicked(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try { 
                tmsWait.Hard(5);
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + value + "')]/parent::td/following-sibling::td[3]/a")));
                    break
                              ;      }
                catch
                {
                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    FrameworkCode.ReUsableFunctions.clickOnWebElement(nextpage);
                }
                tmsWait.Hard(5);

            }

           

        }

        [When(@"HIC Name Search page Search Results section View Link is clicked")]
        public void WhenHICNameSearchPageSearchResultsSectionViewLinkIsClicked()
        {
            tmsWait.Hard(5);
            try
            {
                fw.ExecuteJavascript(FRM.FRMMainPage.HICNameSearchResultsPaneViewLink);
            }

            catch
            {
               
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a/span[@title='View']")));
            }
            tmsWait.Hard(10);
        }

        [When(@"Member Summary page More link is Clicked")]
        public void WhenMemberSummaryPageMoreLinkIsClicked()
        {
            tmsWait.Hard(3);
            IWebElement link = Browser.Wd.FindElement(By.XPath("(//span[@title='View'])[1]"));
            fw.ExecuteJavascript(link);
            tmsWait.Hard(3);

        }

        [When(@"Member Payment History details Flag option is Clicked")]
        public void WhenMemberPaymentHistoryDetailsFlagOptionIsClicked()
        {
            IWebElement link = Browser.Wd.FindElement(By.XPath("[test-id='payMonPartDtls-anc-tabFlags']"));
            fw.ExecuteJavascript(link);
            tmsWait.Hard(5);
        }

        [When(@"Member Payment History details Payment option is Clicked")]
        public void WhenMemberPaymentHistoryDetailsPaymentOptionIsClicked()
        {
            IWebElement link = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Payments')]"));
            fw.ExecuteJavascript(link);
            tmsWait.Hard(5);
        }

        [When(@"Member Payment History details ""(.*)"" Notes is Clicked")]
        public void WhenMemberPaymentHistoryDetailsNotesIsClicked(string section)
        {
            IWebElement link;
            switch (section)
            {
                case "Flags":
                     link = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Flags(Indicators)')]"));
                     fw.ExecuteJavascript(link);
                     tmsWait.Hard(10);
                     break;


                case "Payments":
                    link = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Payments')]"));
                    fw.ExecuteJavascript(link);
                    tmsWait.Hard(3);
                    break;

                case "WorkStatus":
                    link = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Work Status')]"));
                    fw.ExecuteJavascript(link);
                    tmsWait.Hard(3);
                    break;

                case "EAMData":
                    link = Browser.Wd.FindElement(By.XPath("//span[contains(.,'EAM Data')]"));
                    fw.ExecuteJavascript(link);
                    tmsWait.Hard(3);
                    break;
            }
           
        }

        [When(@"Enter Notes Summary as ""(.*)""")]
        public void WhenEnterNotesSummaryAs(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            IWebElement notes = Browser.Wd.FindElement(By.Id("note"));
            notes.SendKeys(value);
            tmsWait.Hard(3);
            notes.SendKeys(Keys.Enter);
           
        }

        [When(@"Note Section Save button is Clicked")]
        public void WhenNoteSectionSaveButtonIsClicked()
        {
            IWebElement link = Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='frm-grid-notesGrid']//span[@class='fas fa-save'])[1]"));
            fw.ExecuteJavascript(link);
            
        }
        [When(@"Member Payment History details WorkStatus option is Clicked")]
        public void WhenMemberPaymentHistoryDetailsWorkStatusOptionIsClicked()
        {
            IWebElement link = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Work Status')]"));
            fw.ExecuteJavascript(link);
        }

        [When(@"Member Payment History details EAMData option is Clicked")]
        public void WhenMemberPaymentHistoryDetailsEAMDataOptionIsClicked()
        {
            IWebElement link = Browser.Wd.FindElement(By.XPath("//span[contains(.,'EAM Data')]"));
            fw.ExecuteJavascript(link);
        }


        [When(@"Member Payment History details ""(.*)"" Add New Record button is Clicked")]
        public void WhenMemberPaymentHistoryDetailsAddNewRecordButtonIsClicked(string section)
        {
            tmsWait.Hard(5);
            IWebElement link;
            switch (section)
            {
                case "Flags":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//i[@class='fas fa-minus-square text-secondary cursorLink'])[2]")));
                    link = Browser.Wd.FindElement(By.XPath("//button[contains(.,'ADD NEW RECORD')]"));
                    fw.ExecuteJavascript(link);
                    tmsWait.Hard(3);
                    break;


                case "Payments":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//i[@class='fas fa-minus-square text-secondary cursorLink'])[2]")));
                    link = Browser.Wd.FindElement(By.XPath("//button[contains(.,'ADD NEW RECORD')]"));
                    fw.ExecuteJavascript(link);
                    tmsWait.Hard(3);
                    break;

                case "WorkStatus":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//i[@class='fas fa-minus-square text-secondary cursorLink'])[2]")));
                    link = Browser.Wd.FindElement(By.XPath("//button[contains(.,'ADD NEW RECORD')]"));
                    fw.ExecuteJavascript(link);
                    tmsWait.Hard(3);
                    break;

                case "EAMData":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//i[@class='fas fa-minus-square text-secondary cursorLink'])[2]")));
                    link = Browser.Wd.FindElement(By.XPath("//button[contains(.,'ADD NEW RECORD')]"));
                    fw.ExecuteJavascript(link);
                    tmsWait.Hard(3);
                    break;
            }

         
            
        }



        [When(@"Top (.*) Over Under Payment Search results page View Link is Clicked")]
        public void WhenTopOverUnderPaymentSearchResultsPageViewLinkIsClicked(int p0)
        {
            IWebElement search = Browser.Wd.FindElement(By.XPath("(//span[@title='View'])[1]"));
            fw.ExecuteJavascript(search);
            tmsWait.Hard(3);
        }

        [When(@"FRM Next page General Search tab is clicked")]
        public void WhenFRMNextPageGeneralSearchTabIsClicked()
        {
            IWebElement tab = Browser.Wd.FindElement(By.XPath("(//span[contains(.,'General Search')])[1]"));
            fw.ExecuteJavascript(tab);
            tmsWait.Hard(3);
        }


        [When(@"MMR History page Back to Record button is Clicked")]
        public void WhenMMRHistoryPageBackToRecordButtonIsClicked()
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(FRM.FRMMMRHistory.MMRHistoryBackToRecordbutton);
        }

        [Then(@"Verify ESI FRM Batch Enrollment/Disenrollment page Flag Update Batch Enrollment Disenrollment Requirement details ""(.*)""")]
        public void ThenVerifyESIFRMBatchEnrollmentDisenrollmentPageFlagUpdateBatchEnrollmentDisenrollmentRequirementDetails(string p0)
        {
            Assert.IsTrue(Browser.Wd.FindElement(By.CssSelector("span[test-id='batchUpdate-span-excel2']")).Text.Contains("Excel file (xlsx) only. Must have exactly 8 columns A - H"));
            Assert.IsTrue(Browser.Wd.FindElement(By.CssSelector("span[test-id='batchUpdate-span-columnA2']")).Text.Contains("Column A - the (5) char Plan Id"));
            Assert.IsTrue(Browser.Wd.FindElement(By.CssSelector("span[test-id='batchUpdate-span-columnB2']")).Text.Contains("Column B - the MBI"));
            Assert.IsTrue(Browser.Wd.FindElement(By.CssSelector("span[test-id='batchUpdate-span-columnC2']")).Text.Contains("Column C - the (5) char change type"));
            Assert.IsTrue(Browser.Wd.FindElement(By.CssSelector("span[test-id='batchUpdate-span-columnD']")).Text.Contains("Column D - the change value"));
            Assert.IsTrue(Browser.Wd.FindElement(By.CssSelector("span[test-id='batchUpdate-span-columnE']")).Text.Contains("Column E - the apply period start date"));
            Assert.IsTrue(Browser.Wd.FindElement(By.CssSelector("span[test-id='batchUpdate-span-columnF']")).Text.Contains("Column F - the apply period end date"));
            Assert.IsTrue(Browser.Wd.FindElement(By.CssSelector("span[test-id='batchUpdate-span-columnG']")).Text.Contains("Column G - a single char value of C, D or B, meaning applies to PartC, PartD or Both"));
            Assert.IsTrue(Browser.Wd.FindElement(By.CssSelector("span[test-id='batchUpdate-span-columnH']")).Text.Contains("Column H - the letter Y, if the flag value should be applied to future payment months"));
        }

        [Then(@"Verify Batch Enrollment/Disenrollment page Flag Update Batch Enrollment Disenrollment Requirement details ""(.*)""")]
        public void ThenVerifyBatchEnrollmentDisenrollmentPageFlagUpdateBatchEnrollmentDisenrollmentRequirementDetails(string p0)
        {
            Assert.IsTrue(Browser.Wd.FindElement(By.CssSelector("span[test-id='batchUpdate-span-excel2']")).Text.Contains("Excel file (xlsx) only. Must have exactly 8 columns A - H"));
            Assert.IsTrue(Browser.Wd.FindElement(By.CssSelector("span[test-id='batchUpdate-span-columnA2']")).Text.Contains("Column A - the (5) char Plan Id"));
            Assert.IsTrue(Browser.Wd.FindElement(By.CssSelector("span[test-id='batchUpdate-span-columnB2']")).Text.Contains("Column B - the MBI"));
            Assert.IsTrue(Browser.Wd.FindElement(By.CssSelector("span[test-id='batchUpdate-span-columnC2']")).Text.Contains("Column C - the (5) char change type"));
            Assert.IsTrue(Browser.Wd.FindElement(By.CssSelector("span[test-id='batchUpdate-span-columnD']")).Text.Contains("Column D - the change value"));
            Assert.IsTrue(Browser.Wd.FindElement(By.CssSelector("span[test-id='batchUpdate-span-columnE']")).Text.Contains("Column E - the apply period start date"));
            Assert.IsTrue(Browser.Wd.FindElement(By.CssSelector("span[test-id='batchUpdate-span-columnF']")).Text.Contains("Column F - the apply period end date"));
            Assert.IsTrue(Browser.Wd.FindElement(By.CssSelector("span[test-id='batchUpdate-span-columnG']")).Text.Contains("Column G - a single char value of C, D or B, meaning applies to PartC, PartD or Both"));
            Assert.IsTrue(Browser.Wd.FindElement(By.CssSelector("span[test-id='batchUpdate-span-columnH']")).Text.Contains("Column H - the letter Y, if the flag value should be applied to future payment months"));
        }

        [Then(@"Verify Batch Enrollment/Disenrollment page Batch Enrollment Disenrollment Requirement details ""(.*)""")]
        public void ThenVerifyBatchEnrollmentDisenrollmentPageBatchEnrollmentDisenrollmentRequirementDetails(string p0)
        {
            string expectedText = p0.ToString();
            string appText = FRM.BatchEnrollDisEnroll.BatchFlagChangeFileRequirements.Text;
            string finalText = appText.Replace("\r\n", string.Empty);
            Assert.AreEqual(expectedText, finalText, " Expected Text and Actual Text are matching");
        }

        [Then(@"Verify Batch Enrollment/Disenrollment page HIC Change Batch Enrollment Disenrollment Requirement details ""(.*)""")]
        public void ThenVerifyBatchEnrollmentDisenrollmentPageHICChangeBatchEnrollmentDisenrollmentRequirementDetails(string p0)
        {
            string asp= Browser.Wd.FindElement(By.CssSelector("span[test-id='batchUpdate-span-excel']")).Text;
            Assert.IsTrue(Browser.Wd.FindElement(By.CssSelector("span[test-id='batchUpdate-span-excel']")).Text.Contains("Input file (xlsx or csv) only. Must have exactly 2 columns A & B:"));
            Assert.IsTrue(Browser.Wd.FindElement(By.CssSelector("span[test-id='batchUpdate-span-columnA']")).Text.Contains("oldmbi - the list of MBIs to be changed (oldmbi)"));
            Assert.IsTrue(Browser.Wd.FindElement(By.CssSelector("span[test-id='batchUpdate-span-columnB']")).Text.Contains("newmbi - the list of MBIs to change to (newmbi)"));
            //Assert.IsTrue(Browser.Wd.FindElement(By.CssSelector("span[test-id='batchUpdate-span-maximum']")).Text.Contains("Values within columns should NOT be enclosed by single or double quotes."));
            Assert.IsTrue(Browser.Wd.FindElement(By.CssSelector("span[test-id='batchUpdate-span-values']")).Text.Contains("Values within columns should NOT be enclosed by single or double quotes."));
        }

        [When(@"Member Payment Summary page Back to Record button is Clicked")]
        public void WhenMemberPaymentSummaryPageBackToRecordButtonIsClicked()
        {
            FRM.FRMMemberPaymentSummary.BackToRecordbutton.Click();
            tmsWait.Hard(2);
        }

        [When(@"Member Payment Summary page CMS Payment Month graph record is Hovered")]
        public void WhenMemberPaymentSummaryPageCMSPaymentMonthGraphRecordIsHovered()
        {
            IWebElement element = Browser.Wd.FindElement(By.XPath("//div[@aria-label='A chart.']"));
            Actions builder = new Actions(Browser.Wd);
            builder.MoveToElement(element).MoveByOffset(181, 389).Build().Perform();

        }

        [Then(@"Verify Member Payment Summary page CMS Payment Month graph displays ""(.*)""")]
        public void ThenVerifyMemberPaymentSummaryPageCMSPaymentMonthGraphDisplays(string p0)
        {


        }


        [Then(@"Verify Member Payment Summary page display ""(.*)"" button")]
        public void ThenVerifyMemberPaymentSummaryPageDisplayButton(string p0)
        {
            string field = p0.ToString();

            switch (field)

            {
                case "Back to Record":

                    Assert.IsTrue(FRM.FRMMemberPaymentSummary.BackToRecordbutton.Enabled, field + " field is displayed");

                    break;

                case "PART C":
                    Assert.IsTrue(FRM.FRMMemberPaymentSummary.PartC.Enabled, field + " field is displayed");
                    break;

                case "PART D":
                    Assert.IsTrue(FRM.FRMMemberPaymentSummary.PartD.Enabled, field + " field is displayed");

                    break;

                case "Generate Report":
                    Assert.IsTrue(FRM.FRMMemberPaymentSummary.GenerateReport.Enabled, field + " field is displayed");

                    break;
            }


        }


        [Then(@"Verify Member Payment Summary page display ""(.*)"" as ""(.*)""")]
        public void ThenVerifyMemberPaymentSummaryPageDisplayAs(string p0, string p1)
        {
            tmsWait.Hard(10);
            string field = p0.ToString();
            string expectedValue = p1.ToString();
            switch (field)
            {

                case "HIC Number":
                    Assert.AreEqual(FRM.FRMMemberPaymentSummary.HICNumber.Text, expectedValue, field + " Field displays " + FRM.FRMMemberPaymentSummary.HICNumber.Text);
                    break;
                case "Name":
                    Assert.AreEqual(FRM.FRMMemberPaymentSummary.Name.Text, expectedValue, field + " Field displays " + FRM.FRMMemberPaymentSummary.Name.Text);
                    break;

            }


        }

        [When(@"TMS FRM Application page File Processing menu is Clicked")]
        public void WhenTMSFRMApplicationPageFileProcessingMenuIsClicked()
        {
            tmsWait.WaitForElement(By.CssSelector("a[title='File Processing Status']"), 300);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("a[title='File Processing Status']")));
            tmsWait.Hard(2);
        }


        [Then(@"TMS FRM page ""(.*)"" Back to Record button is Clicked")]
        public void ThenTMSFRMPageBackToRecordButtonIsClicked(string p0)
        {
            string backtorecord = p0.ToString();
            tmsWait.Hard(2);
            switch (backtorecord)
            {
                case "Member Information":
                    fw.ExecuteJavascript(FRM.FRMMemberInfo.BackToRecord);
                    break;
                case "Member Payment Summary":
                    fw.ExecuteJavascript(FRM.FRMMemberPaymentSummary.BackToRecordbutton);
                    break;
                case "Compare Flags":
                    fw.ExecuteJavascript(FRM.CompareFlags.BackToRecord);
                    break;
                case "MBI Change History":
                    fw.ExecuteJavascript(FRM.FRMHICChangeHistory.HICChangeHistoryBackToRecordbutton);
                    break;
                case "MMR History":
                    fw.ExecuteJavascript(FRM.FRMMMRHistory.BackToRecord);
                    break;
                case "Enroll/Disenroll Member":
                    fw.ExecuteJavascript(FRMEnrollDisenrollMember.BackToRecord);
                    break;
                case "Adjust Discrepancy":
                    fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.AdjustDiscrepancyBackToRecord);
                    break;
            }
        }

      

        [When(@"TMS FRM Main page ""(.*)"" icon is Clicked")]
        public void WhenTMSFRMMainPageIconIsClicked(string p0)
        {
            string field = p0.ToString();

            switch(field)
            {
                case "Question Mark":
                    fw.ExecuteJavascript(FRM.FRMLogin.Help);
                    break;
                case "Log Out":
                    fw.ExecuteJavascript(FRM.FRMLogin.Logout);
                    break;


            }


        }

        [When(@"TMS FRM page Batch Update Processing section File Processing Status link is clicked")]
        public void WhenTMSFRMPageBatchUpdateProcessingSectionFileProcessingStatusLinkIsClicked()
        {
            fw.ExecuteJavascript(FRM.BatchUpdateProcessing.FileProcessingStatusLink);

            tmsWait.Hard(10);

        }

        [Then(@"Verify TMS FRM page File Processing status Table has row")]
        public void ThenVerifyTMSFRMPageFileProcessingStatusTableHasRow(Table table)
        {

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = FRM.BatchUpdateProcessing.FileProcessingStatusTable;
                IWebElement paginationSystem = FRM.BatchUpdateProcessing.FileProcessingStatusPagination;

                //Look for a next page link.  We will set 'last page of records' here also.
                //thisTP.LoadNextPageLink(baseTable);
                thisTP.LoadDIVNextPageLink(paginationSystem, "pagination-next ng-scope");

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                //   thisTP.LoadPageTable(baseTable, "td", "td");
                thisTP.LoadDIVPageTable(baseTable, "ui-grid-row", "ui-grid-cell");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 2)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[2];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");


                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = FRM.BatchUpdateProcessing.FileProcessingStatusTable; 

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }


        }



        [Then(@"Verify Batch Update Processing page ""(.*)"" Success message is displayed")]
        public void ThenVerifyBatchUpdateProcessingPageSuccessMessageIsDisplayed(string p0)
        {
            tmsWait.Hard(2);
            string expected = p0.ToString();
            string actual = FRM.BatchUpdateProcessing.SucsessMessage.Text;
            Assert.AreEqual(expected, actual, p0 + " message is getting displayed");

        }

        [Then(@"Verify FRM Batch Update Processing page ""(.*)"" message is displayed")]
        public void ThenVerifyFRMBatchUpdateProcessingPageMessageIsDisplayed(string p0)
        {

            tmsWait.Hard(10);
            string expectedPage = p0.ToString();
            IWebElement presence = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + expectedPage + "')]"));
            
            Assert.IsTrue(presence.Displayed, p0 + " MESSAGE IS NOT GETTING DISPLAYED");
        }


        [Then(@"Verify Batch Update Processing page ""(.*)"" error message is displayed")]
        public void ThenVerifyBatchUpdateProcessingPageErrorMessageIsDisplayed(string p0)
        {
            tmsWait.Hard(5);
            string expectedPage = p0.ToString();
            IWebElement presence = Browser.Wd.FindElement(By.XPath("//span[contains(.,'"+expectedPage+"')]"));

           // string actual = FRM.BatchUpdateProcessing.ErrorMessage.Text;
            Assert.IsTrue(presence.Displayed,p0+" MESSAGE IS NOT GETTING DISPLAYED");
            //switch (expectedPage)
            //{
            //    case "Incorrect number of columns in worksheet 1 of file 'BatchupdateHICChangeAdditionalColumn.xls' Must be (2).|":
            //        {
            //            tmsWait.Hard(5);
            //            string actual = FRM.BatchUpdateProcessing.ErrorMessage.Text;
            //            Assert.AreEqual(expectedPage, actual, expectedPage + " Page is displayed");
            //            break;
            //        }
            //    case "Specified cast is not valid.|":
            //        {
            //            tmsWait.Hard(5);
            //            string actual = FRM.BatchUpdateProcessing.ErrorMessage.Text;
            //            Assert.AreEqual(expectedPage, actual, expectedPage + " Page is displayed");
            //            break;
            //        }
            //    case "Please select an Excel file to upload.|":
            //        {
            //            tmsWait.Hard(5);
            //            string actual = FRM.BatchUpdateProcessing.ErrorMessage.Text;
            //            Assert.AreEqual(expectedPage, actual, expectedPage + " Page is displayed");
            //            break;
            //        }
            //    case "There are no data rows in worksheet 1 of file 'Batchupdateenroll-disenrollBlankData.xls'|":
            //        {
            //            tmsWait.Hard(5);
            //            string actual = FRM.BatchUpdateProcessing.ErrorMessage.Text;
            //            Assert.AreEqual(expectedPage, actual, expectedPage + " Page is displayed");
            //            break;
            //        }
            //    case "The string was not recognized as a valid DateTime. There is an unknown word starting at index 0.|":
            //        {
            //            tmsWait.Hard(5);
            //            string actual = FRM.BatchUpdateProcessing.ErrorMessage.Text;
            //            Assert.AreEqual(expectedPage, actual, expectedPage + " Page is displayed");
            //            break;
            //        }
            //    case "Incorrect number of columns in worksheet 1 of file 'Batchupdate enroll-disenrollAdditionalColumn.xls' Must be (6).|":
            //        {
            //            tmsWait.Hard(5);
            //            string actual = FRM.BatchUpdateProcessing.ErrorMessage.Text;
            //            Assert.AreEqual(expectedPage, actual, expectedPage + " Page is displayed");
            //            break;
            //        }
            //    default:
            //        fw.ConsoleReport(" Expected Error message is not getting displayed");
            //        break;
            //}
        }

        [Then(@"Enroll/ Disenroll Member page Close Button is Clicked")]
        public void ThenEnrollDisenrollMemberPageCloseButtonIsClicked()
        {
            IWebElement close = Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainEnrollDisenroll-btn-btnClose']"));
            fw.ExecuteJavascript(close);
        }

        [When(@"Extract submenu ""(.*)"" is Clicked")]
        public void WhenExtractSubmenuIsClicked(string menu)
        {
            IWebElement sub = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + menu + "')]"));
            fw.ExecuteJavascript(sub);
        }

        [Then(@"""(.*)"" button is Clicked")]
        public void ThenButtonIsClicked(string button)
        {
           switch(button)
            {
                case "MMRExtract Export":
                    fw.ExecuteJavascript(FRM.MMRExtract.EXPORT);
                    break;
                case "Member Premium Extract Export":
                    fw.ExecuteJavascript(FRM.MemberPremiumExtract.EXPORT);
                    break;
            }
        }



        [Then(@"Verify ""(.*)"" page is displayed")]
        public void ThenVerifyPageIsDisplayed(string page)
        {
            string expectedPage = page.ToString();
            tmsWait.Hard(3);

            switch (expectedPage)
            {

                case "TriZetto Customer Exchange":
                    {

                        tmsWait.Hard(2);
                        // Switch to Newly Opened Tab
                        Browser.Wd.SwitchTo().Window(Browser.Wd.WindowHandles[1]);
                        string actual = Browser.Wd.Title;

                        Assert.AreEqual(actual, expectedPage, expectedPage + " Page is displayed");
                        break;
                    }
                case "Cognizant Customer Exchange":
                    {

                        tmsWait.Hard(2);
                        // Switch to Newly Opened Tab
                        Browser.Wd.SwitchTo().Window(Browser.Wd.WindowHandles[1]);
                        string actual = Browser.Wd.Title;

                        Assert.AreEqual(actual, expectedPage, expectedPage + " Page is displayed");
                        break;
                    }
                case "TriZetto Medicare Solutions Login":
                    {

                        tmsWait.Hard(2);

                        string actual = Browser.Wd.Title;

                        Assert.AreEqual(actual, expectedPage, expectedPage + " Page is displayed");
                        break;
                    }
                case "Member Payment Summary":
                    {

                        tmsWait.Hard(2);

                        Assert.AreEqual(FRM.FRMMemberPaymentSummary.PageTitle.Text, expectedPage, expectedPage + " Page is displayed");
                        break;
                    }

                case "Member Information":
                    {

                        tmsWait.Hard(5);

                        Assert.AreEqual(FRM.FRMMemberInfo.PageTitle.Text, expectedPage, expectedPage + " Page is displayed");
                        break;
                    }
                case "Batch Update Processing":
                    {

                        tmsWait.Hard(2);

                        Assert.AreEqual(FRM.BatchEnrollDisEnroll.BatchUpdateProcessingTitle.Text, expectedPage, expectedPage + " Page is displayed");
                        break;
                    }

                case "MBI Change History":
                    {

                        tmsWait.Hard(3);
                        //Assert.IsTrue(tmsWait.IsElementPresent(By.XPath(".//*[@id='lblHicChangeHistory'][@class='modal-title']")));

                        Assert.AreEqual(FRM.FRMHICChangeHistory.HICChangeHistoryTitle.Text, expectedPage, expectedPage + " Page is displayed");
                        break;
                    }
                case "Member Summary:":
                    {

                        Assert.IsTrue(tmsWait.IsElementPresent(By.XPath("//span[contains(.,'Member Summary:')]")));

                        Assert.AreEqual(FRM.FRMMemberSummary.MemberSummaryTitle.Text, expectedPage, expectedPage + " Page is displayed");
                        break;
                    }


                case "MMR History":
                    {
                        tmsWait.Hard(10);
                        // Assert.IsTrue(tmsWait.IsElementPresent(By.XPath(".//*[@class='modal fade in']//h4[@id='myLargeModalLabel']")));
                        // 10/10/16 - Updated Test scripts as There is a HTML Component Alignment changes -Venkatesh P
                        Assert.AreEqual(FRM.FRMMMRHistory.MMRHistoryTitle.Text, expectedPage, expectedPage + " Page is displayed");
                        break;
                    }

                case "Adjust Discrepancy":
                    {
                        tmsWait.Hard(10);
                        // Assert.IsTrue(tmsWait.IsElementPresent(By.XPath(".//*[@class='modal fade in']//h4[@id='myLargeModalLabel']")));

                        Assert.IsTrue(FRM.AdjustDiscrepancy.AdjustDiscrepancyTitle.Displayed, expectedPage + " Page is not getting displayed");
                        tmsWait.Hard(5);
                        break;
                    }

                case "File Processing Status":
                    {
                        tmsWait.Hard(2);
                        // Assert.IsTrue(tmsWait.IsElementPresent(By.XPath(".//*[@class='modal fade in']//h4[@id='myLargeModalLabel']")));

                        Assert.AreEqual(FRM.FRMFilesProcessingStatus.PageTitle.Text, expectedPage, expectedPage + " Page is displayed");
                        break;
                    }

                case "Batch Enrollment/Disenrollment":
                    {
                        Assert.IsTrue(tmsWait.IsElementPresent(By.CssSelector(".col-lg-12.col-md-12.col-sm-12.col-xs-12.padding0")));
                        Assert.AreEqual(FRMMainNavigation.PageTitle.Text, expectedPage, expectedPage + "is displayed when clicks on sub-menu");
                        break;
                    }

                case "Export Monthly Extract to file":
                    {
                        tmsWait.Hard(2);
                        By location1 = By.XPath("//div[contains(.,'Export Monthly Extract to file')]");
                        UIMODUtilFunctions.elementPresenceUsingLocators(location1);
                        break;
                    }

                case "Generate Report":
                    {

                        tmsWait.Hard(2);
                        Assert.AreEqual(FRM.GenerateReport.PageTitle.Text, expectedPage, expectedPage + "is displayed ");
                        break;

                    }

                case "Compare Flags: Plan vs CMS":
                    {

                        tmsWait.Hard(2);
                        Assert.AreEqual(FRM.CompareFlags.PageTitle.Text, expectedPage, expectedPage + "is displayed ");
                        break;

                    }

                case "Member Discrepancy":
                    {

                        tmsWait.Hard(2);
                        string actualValue = RSM.MemberDiscrepancy.Title.Text.ToString();
                        Assert.AreEqual(actualValue, expectedPage, expectedPage + "is displayed ");
                        break;

                    }

                case "Enroll/ Disenroll Member":
                    tmsWait.Hard(2);
                    By loc = By.XPath("//span[contains(.,'Enroll/ Disenroll Member')]");
                    UIMODUtilFunctions.elementPresenceUsingLocators(loc);
                    break;

                case "Member Premium Extract":
                    tmsWait.Hard(2);

                    Assert.IsTrue(FRM.MemberPremiumExtract.Title.Text.Contains(expectedPage), expectedPage + "is not geting displayed");
                    break;

                case "MMR Extract":
                    
                    tmsWait.Hard(2);
                    By location = By.XPath("//div[contains(.,'MMR Extract')]//div[@class='main-content-header d-flex']");
                    UIMODUtilFunctions.elementPresenceUsingLocators(location);
                    break;

                case "Log Out":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//small[contains(.,'You are now logged out')]")).Displayed);
                    break;
                default:
                    fw.ConsoleReport(" There is no page displayed");
                    break;
            }
        }

        [Then(@"Verify ""(.*)"" page is displayed successfully")]
        public void ThenVerifyPageIsDisplayedSuccessfully(string p0)
        {
            tmsWait.Hard(8);
            string exepcted = p0.ToString();

            string actual = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Adjust Discrepancy')]")).Text;

            Assert.AreEqual(exepcted, actual, exepcted + " is not getting displayed");
        }

        string MSMBI;
        string MSSurName;
        string MSMemberID;
        string MSRXId;
        [When(@"Member Summary page MBI Number is noted")]
        public void WhenMemberSummaryPageMBINumberIsNoted()
        {
            MSMBI = Browser.Wd.FindElement(By.XPath("//*[@test-id='memberSummary-spn-mbiValue']")).Text;
            GlobalRef.FRMMBI = MSMBI;
        }

        [When(@"Member Summary page Surname is noted")]
        public void WhenMemberSummaryPageSurnameIsNoted()
        {
            MSSurName = Browser.Wd.FindElement(By.XPath("//*[@test-id='memberSummary-spn-surNameValue']")).Text;
            GlobalRef.FRMSurName = MSSurName;
        }

        [When(@"Member Summary page Member Id is noted")]
        public void WhenMemberSummaryPageMemberIdIsNoted()
        {
            MSMemberID = Browser.Wd.FindElement(By.Id("spnmemberID")).Text;
            GlobalRef.FRMMemberID = MSMemberID;
        }

        [When(@"Member Summary page Rx Id is noted")]
        public void WhenMemberSummaryPageRxIdIsNoted()
        {
            MSRXId = Browser.Wd.FindElement(By.XPath("//*[@test-id='memberSummary-spn-partDunderOverValue']")).Text;
            GlobalRef.FRMRXId = MSRXId;
        }

        [Then(@"Verify Noted MBI is matching with Member Information page MBI")]
        public void ThenVerifyNotedMBIIsMatchingWithMemberInformationPageMBI()
        {
            string MBI = Browser.Wd.FindElement(By.CssSelector("[test-id='membrInfo-div-hic']")).Text;
            string[] finalMBI = MBI.Split(':');
            string finalMBITrimmed = finalMBI[1].Trim();
            string MSMBI = GlobalRef.FRMMBI.ToString();
            Assert.AreEqual(MSMBI, finalMBITrimmed);
        }
       
        [Then(@"Verify Noted Member ID is matching with Member Information page Member ID")]
        public void ThenVerifyNotedMemberIDIsMatchingWithMemberInformationPageMemberID()
        {
            string memberID = Browser.Wd.FindElement(By.CssSelector("[test-id='membrInfo-div-memberId']")).Text;
            string[] finalMember = memberID.Split(':');
            string finalMemberTrimmed = finalMember[1].Trim();
            string MSMemberID = GlobalRef.FRMMemberID.ToString();
            Assert.AreEqual(MSMemberID, finalMemberTrimmed);
        }


        [Then(@"Verify Noted Rx Id is matching with Member Information page Rx Id")]
        public void ThenVerifyNotedRxIdIsMatchingWithMemberInformationPageRxId()
        {
            string rxID = Browser.Wd.FindElement(By.XPath("//label[Contains(.,'Rx Id')]")).Text;
            string[] finalrxID = rxID.Split('\n');
            string MSRXId = GlobalRef.FRMRXId.ToString();
            Assert.AreEqual(MSRXId, finalrxID[1]);
        }


        [Then(@"Verify Noted SurName is matching with Member Information page SurName")]
        public void ThenVerifyNotedSurNameIsMatchingWithMemberInformationPageSurName()
        {
            string sur = Browser.Wd.FindElement(By.CssSelector("[test-id='membrInfo-div-lName']")).Text;
            string[] finalsur = sur.Split(':');
            string finalsurUpper = finalsur[1].ToUpper();
            string finalsurTrimmed = finalsurUpper.Trim();
            string MSSurName = GlobalRef.FRMSurName.ToString();
            Assert.AreEqual(MSSurName, finalsurTrimmed);
        }
        [Then(@"Verify Label display ""(.*)"" under Dashboard")]
        public void ThenVerifyLabelDisplayUnderDashboard(string p0)
        {
            IWebElement label = Browser.Wd.FindElement(By.XPath("//label[contains(.,'"+p0+"')]"));
            Assert.IsTrue(label.Displayed, p0 + "is not getting displayed");
        }

        [Then(@"Verify Label display ""(.*)"" under Dashboard Top sections")]
        public void ThenVerifyLabelDisplayUnderDashboardTopSections(string p0)
        {
            IWebElement label = Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + p0 + "')]"));
            Assert.IsTrue(label.Displayed, p0 + "is not getting displayed");
        }


        [When(@"Member Summary page ""(.*)"" link is Clicked")]
        public void WhenMemberSummaryPageLinkIsClicked(string p0)
        {
            tmsWait.Hard(1);
            string expectedLink = p0.ToString();

            switch (expectedLink)
            {
                case "Member Information":
                    fw.ExecuteJavascript(FRM.FRMMainPage.MemberSummaryViewMemberInfo);
                    tmsWait.Hard(1);
                    break;
                case "Member Payment Summary":
                    fw.ExecuteJavascript(FRM.FRMMainPage.MemberSummaryViewMemberPaymentSummary);
                    tmsWait.Hard(1);
                    break;
                case "Compare Flags":
                    fw.ExecuteJavascript(FRM.FRMMainPage.MemberSummaryViewCompareFlags);
                    break;
                case "MBI Change History":
                    fw.ExecuteJavascript(FRM.FRMMainPage.MemberSummaryViewHICChangeHistory);
                    break;
                case "Adjust Discrepancy":
                    fw.ExecuteJavascript(FRM.FRMMainPage.MemberSummaryToolsAdjustDiscrepancy);
                    break;
                case "Enroll/Disenroll Member":
                    fw.ExecuteJavascript(FRM.FRMMainPage.MemberSummaryToolsEnrollDisenroll);
                    break;
                case "Generate Report":
                    fw.ExecuteJavascript(FRM.FRMMainPage.MemberSummaryToolGenerateReport);
                    break;
                case "MMR History":
                    tmsWait.Hard(2);
                    fw.ExecuteJavascript(FRM.FRMMainPage.MemberSummaryViewMMRHistory);
                    break;
                default:
                    fw.ConsoleReport("Provided Input is Wrong");
                    break;
            }
            tmsWait.Hard(3);
        }


        [When(@"Member Summary page Member Information link is Clicked")]
        public void WhenMemberSummaryPageMemberInformationLinkIsClicked()
        {
            fw.ExecuteJavascript(FRM.FRMMainPage.MemberSummaryViewMemberInfo);
        }
        [Then(@"Verify Member Information page ""(.*)"" is set to variable ""(.*)""")]
        public void ThenVerifyMemberInformationPageIsSetToVariable(string parameter, string value)
        {
            string actValue;
            IWebElement ele;
            switch (parameter)
            {
                case "MBI":
                    ele = Browser.Wd.FindElement(By.XPath("//div[@test-id='membrInfo-div-hic']"));
                    actValue = ele.Text.Split('\n')[1];
                  value = GlobalRef.MBI.ToString();
                    Assert.AreEqual(actValue, value, parameter + " is expected as " + value);
                    break;
                case "Surname":
                    tmsWait.Hard(29);
                    ele = Browser.Wd.FindElement(By.XPath("//div[@test-id='membrInfo-div-lName']"));
                    value = GlobalRef.Surname.ToString();
                    actValue = ele.Text.Split('\n')[1];
                    Assert.AreEqual(actValue, value, parameter + " is expected as " + value);

                    break;
            }
        }

        [Then(@"Verify Member Information page ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyMemberInformationPageIsSetTo(string parameter, string p0)
        {
            //.//*[@id='memberInformation']//label[@id='Label2'] use this code
            string actValue;
            string value = tmsCommon.GenerateData(p0);
            IWebElement ele;
            tmsWait.Hard(15);
            switch (parameter)
            {
                case "HIC Number":
                    string MBI = Browser.Wd.FindElement(By.CssSelector("[test-id='membrInfo-div-hic']")).Text;
                    string[] finalMBI = MBI.Split(':');
                    string finalMBITrimmed = finalMBI[1].Trim();
                    Assert.AreEqual(value, finalMBITrimmed);
                    break;
                case "Surname":
                    string surName = Browser.Wd.FindElement(By.CssSelector("[test-id='membrInfo-div-lName']")).Text;
                    string[] finalsurName = surName.Split(':');
                    string finalsurNameTrimmed = finalsurName[1].Trim();
                    Assert.AreEqual(value, finalsurNameTrimmed);
                    break;
                case "First Name":
                    string firstName = Browser.Wd.FindElement(By.CssSelector("[test-id='membrInfo-div-firstName']")).Text;
                    string[] finalfirstName = firstName.Split(':');
                    string finalfirstNameTrimmed = finalfirstName[1].Trim();
                    Assert.AreEqual(value, finalfirstNameTrimmed);
                    break;
                case "Member ID":
                    string memberId = Browser.Wd.FindElement(By.CssSelector("[test-id='membrInfo-div-memberId']")).Text;
                    string[] finalmemberId = memberId.Split(':');
                    string finalmemberIdTrimmed = finalmemberId[1].Trim();
                    Assert.AreEqual(value, finalmemberIdTrimmed);
                    break;
                case "RX ID":
                    string rxId = Browser.Wd.FindElement(By.CssSelector("[test-id='membrInfo-div-rxGroupId']")).Text;
                    string[] finalrxId = rxId.Split(':');
                    string finalrxIdTrimmed = finalrxId[1].Trim();
                    Assert.AreEqual(value, finalrxIdTrimmed);
                    break;
                case "DOB":
                    string dob = Browser.Wd.FindElement(By.CssSelector("[test-id='membrInfo-div-dob']")).Text;
                    string[] finaldob = dob.Split(':');
                    string finaldobTrimmed = finaldob[1].Trim();
                    Assert.AreEqual(value, finaldobTrimmed);
                    break;
                case "SSN":
                    string ssn = Browser.Wd.FindElement(By.CssSelector("[test-id='membrInfo-div-ssn']")).Text;
                    string[] finalssn = ssn.Split(':');
                    string finalssnTrimmed = finalssn[1].Trim();
                    Assert.AreEqual(value, finalssnTrimmed);
                    break;
                case "Sex":
                    string sex = Browser.Wd.FindElement(By.CssSelector("[test-id='membrInfo-div-']")).Text;
                    string[] finalsex = sex.Split(':');
                    string finalsexTrimmed = finalsex[1].Trim();
                    Assert.AreEqual(value, finalsexTrimmed);
                    break;
            }
        }

        [When(@"Member Information page Back to Record button is Clicked")]
        public void WhenMemberInformationPageBackToRecordButtonIsClicked()
        {
            tmsWait.Hard(2);
            FRM.FRMMainPage.MemberInfoBackToRecordButton.Click();
        }

        [Then(@"Verify Member Summary page ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyMemberSummaryPageIsSetTo(string parameter, string value)
        {
           
            IWebElement ele;
            switch (parameter)
            {
                case "HIC Number":
                    ele = Browser.Wd.FindElement(By.CssSelector("[test-id='memberSummary-spn-mbiValue']"));
                     Assert.AreEqual(ele.Text.Trim(), value, parameter + " is expected as " + value);
                    break;
                case "Surname":
                    ele = Browser.Wd.FindElement(By.CssSelector("[id='spnsurName']"));
                    Assert.AreEqual(ele.Text.Trim(), value, parameter + " is expected as " + value);
                    break;
                case "FI":
                    ele = Browser.Wd.FindElement(By.CssSelector("[id='spnfi']"));
                    Assert.AreEqual(ele.Text.Trim(), value, parameter + " is expected as " + value);
                    break;
                case "Member ID":
                    ele = Browser.Wd.FindElement(By.CssSelector("[id='spnmemberID']"));
                    Assert.AreEqual(ele.Text.Trim(), value, parameter + " is expected as " + value);
                    break;
                case "RX ID":
                    ele = Browser.Wd.FindElement(By.CssSelector("[id='spnrxId']"));
                    Assert.AreEqual(ele.Text.Trim(), value, parameter + " is expected as " + value);
                    break;

            }

                    
        }
        [Then(@"Verify FRM Application display ""(.*)""")]
        public void ThenVerifyFRMApplicationDisplay(string expectedresults)
        {
            tmsWait.Hard(4);
            IWebElement page = Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainCmprFlag-span-compareFlags']"));
            string actualresults = page.Text;

            Assert.AreEqual(expectedresults, actualresults, "Both values are not matching");
        }

        [When(@"FRM Member Summary page ""(.*)"" link is clicked")]
        public void WhenFRMMemberSummaryPageLinkIsClicked(string p0)
        {
          

        IWebElement link = Browser.Wd.FindElement(By.CssSelector("[test-id='membrPayDetail-anc-compareFlags']"));
            fw.ExecuteJavascript(link);
        }


        [Then(@"Verify Member Summary page ""(.*)"" Section displayed ""(.*)"" link")]
        public void ThenVerifyMemberSummaryPageSectionDisplayedLink(string p0, string p1)
        {


            string section = p0.ToString();
            string expectedLink = p1.ToString();
            string actualLink;

            if (section == "View")
            {

                switch (expectedLink)
                {
                    case "Member Info.":
                        actualLink = FRM.FRMMainPage.MemberSummaryViewMemberInfo.Text;

                        Assert.AreEqual(expectedLink, actualLink, "Member Summary Page View Section Member Info link is displayed");
                        break;
                    case "Compare Flags":
                        actualLink = FRM.FRMMainPage.MemberSummaryViewCompareFlags.Text;

                        Assert.AreEqual(expectedLink, actualLink, "Member Summary Page View Section Compare Flags link is displayed");
                        break;
                    case "Member Payment Summary":
                        actualLink = FRM.FRMMainPage.MemberSummaryViewMemberPaymentSummary.Text;

                        Assert.AreEqual(expectedLink, actualLink, "Member Summary Page View Section Member Payment Summary link is displayed");
                        break;

                    case "MBI Change History":
                        actualLink = FRM.FRMMainPage.MemberSummaryViewHICChangeHistory.Text;

                        Assert.AreEqual(expectedLink, actualLink, "Member Summary Page View Section HIC Change History link is displayed");
                        break;

                    case "MMR History":
                        actualLink = FRM.FRMMainPage.MemberSummaryViewMMRHistory.Text;

                        Assert.AreEqual(expectedLink, actualLink, "Member Summary Page View Section MMR History link is displayed");
                        break;

                    default:
                        fw.ConsoleReport(" There is no Link available");
                        break;

                }
            }

            else if (section == "Tools")
            {

                switch (expectedLink)
                {
                    case "Adjust Discrepancy":
                        actualLink = FRM.FRMMainPage.MemberSummaryToolsAdjustDiscrepancy.Text;

                        Assert.AreEqual(expectedLink, actualLink, "Member Summary Page Tools Section Adjust Discrepancy link is displayed");
                        break;
                    case "Enroll/Disenroll Member":
                        actualLink = FRM.FRMMainPage.MemberSummaryToolsEnrollDisenroll.Text;

                        Assert.AreEqual(expectedLink, actualLink, "Member Summary Page Tools Section Enroll/Disenroll Member link is displayed");
                        break;
                    case "Generate Report":
                        actualLink = FRM.FRMMainPage.MemberSummaryToolGenerateReport.Text;

                        Assert.AreEqual(expectedLink, actualLink, "Member Summary Page Tools Section Generate Report Summary link is displayed");
                        break;

                    default:
                        fw.ConsoleReport(" There is no Link available");
                        break;

                }

            }



        }


        [Then(@"Verify FRM Next page HIC Name Search section Previous button is disabled")]
        public void ThenVerifyFRMNextPageHICNameSearchSectionPreviousButtonIsDisabled()
        {
            IWebElement prevlink = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the previous page']"));
            bool prev = prevlink.GetAttribute("class").Contains("disabled");
            Assert.IsTrue(prev, "Previous link is not disabled");
            //if (prev)
            //{
            //    fw.ExecuteJavascript(FRMHICorNameSearch.HICNextLink);
            //    prev = prevlink.GetAttribute("class").Contains("disabled");
            //    //tmsWait.WaitForElement(By.LinkText("Last"), 300);
            //    //TablePaging thisTP = new TablePaging();

            //    //IWebElement baseTable = FRM.FRMMainPage.HICNameSearchResults;
            //    //IWebElement paginationSystem = FRM.FRMMainPage.HICNameSearchPagination;
            //    //thisTP.PreviousPageLinkDisable(paginationSystem, "pagination-prev ng-scope disabled");
            
        }

        [When(@"FRM Next page HIC Name Search section Last button is Clicked")]
        public void WhenFRMNextPageHICNameSearchSectionLastButtonIsClicked()
        {

            fw.ExecuteJavascript(FRMHICorNameSearch.HICLastButton);
            //TablePaging thisTP = new TablePaging();

            //IWebElement baseTable = FRM.FRMMainPage.HICNameSearchResults;
            //IWebElement paginationSystem = FRM.FRMMainPage.HICNameSearchPagination;
            //thisTP.LoadDIVLastPageLink(paginationSystem, "pagination-last ng-scope");
        }

        [Then(@"Verify FRM Next page HIC Name Search section Last button is disabled")]
        public void ThenVerifyFRMNextPageHICNameSearchSectionLastButtonIsDisabled()
        {
            IWebElement lastpagenavigation = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']"));
            bool last = lastpagenavigation.GetAttribute("class").Contains("disabled");
            Assert.IsTrue(last,"last page navigation link is not disabled");
            //TablePaging thisTP = new TablePaging();

            //IWebElement baseTable = FRM.FRMMainPage.HICNameSearchResults;
            //IWebElement paginationSystem = FRM.FRMMainPage.HICNameSearchPagination;
            //thisTP.LastPageLinkDisable(paginationSystem, "pagination-next ng-scope disabled");
        }


        [Then(@"FRM Next page Top (.*) Over Under Payment section Last button is Clicked")]
        public void ThenFRMNextPageTopOverUnderPaymentSectionLastButtonIsClicked(int p0)
        {

            TablePaging thisTP = new TablePaging();

            IWebElement baseTable = FRM.FRMMainPage.Top50SearchUnderOverPaymentResults;
            IWebElement paginationSystem = FRM.FRMMainPage.Top50SearchPagination;
            thisTP.LoadDIVLastPageLink(paginationSystem, "pagination-last ng-scope");
        }


        [Then(@"FRM Next page TopFifty Over Under Payment section Last button is Clicked")]
        public void ThenFRMNextPageTopFiftyOverUnderPaymentSectionLastButtonIsClicked()
        {
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']"));
            fw.ExecuteJavascript(ele);
            tmsWait.Hard(2);
        }



        [Then(@"Verify FRM Next page Top (.*) Over Under Payment section Last button is disabled")]
        public void ThenVerifyFRMNextPageTopOverUnderPaymentSectionLastButtonIsDisabled(int p0)
        {
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("class").Contains("disabled"));
            //TablePaging thisTP = new TablePaging();
            //IWebElement baseTable = FRM.FRMMainPage.Top50SearchUnderOverPaymentResults;
            //IWebElement paginationSystem = FRM.FRMMainPage.Top50SearchPagination;
            //thisTP.LastPageLinkDisable(paginationSystem, "pagination-next ng-scope disabled");
        }

        [When(@"FRM Next page Top (.*) OverUnder Payment section Result Criteria Accordion Over Payment tab is Clicked")]
        public void WhenFRMNextPageTopOverUnderPaymentSectionResultCriteriaAccordionOverPaymentTabIsClicked(int p0)
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(FRM.FRMMainPage.Top50SearchOverPaymentButton);
            tmsWait.Hard(5);
        }

        [When(@"FRM Next page Top (.*) OverUnder Payment section Result Criteria Accordion Under Payment tab is Clicked")]
        public void WhenFRMNextPageTopOverUnderPaymentSectionResultCriteriaAccordionUnderPaymentTabIsClicked(int p0)
        {
            tmsWait.Hard(1);

            fw.ExecuteJavascript(FRM.FRMMainPage.Top50SearchUnderPaymentButton);
        }


        [Then(@"Verify FRM Next page Result Panel displays Search results for Over Payment")]
        public void ThenVerifyFRMNextPageResultPanelDisplaysSearchResultsForOverPayment(Table table)
        {

            bool value = FRM.FRMMainPage.Top50SearchOverPaymentButton.GetAttribute("class").Contains("activeToggle");
            bool flag = false;
            if (value)
            {
                IWebElement overpaymenttable = Browser.Wd.FindElement(By.XPath("(//div[@id='topfiftyGrid']//table)[2]"));
                IReadOnlyCollection<IWebElement> rows = overpaymenttable.FindElements(By.TagName("tr"));
                int rowcount = rows.Count();
                if(rowcount > 2)
                {
                    flag = true;
                }
            }

            Assert.IsTrue(flag, "Overpayment table does not have the results");
        }


        [Then(@"Verify FRM Next page Result Panel displays Search results for Under Payment")]
        public void ThenVerifyFRMNextPageResultPanelDisplaysSearchResultsForUnderPayment(Table table)
        {


            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = FRM.FRMMainPage.Top50SearchUnderOverPaymentResults;
                IWebElement paginationSystem = FRM.FRMMainPage.Top50SearchPagination;

                //Look for a next page link.  We will set 'last page of records' here also.
                //thisTP.LoadNextPageLink(baseTable);
                thisTP.LoadDIVNextPageLink(paginationSystem, "pagination-next ng-scope");

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                //   thisTP.LoadPageTable(baseTable, "td", "td");
                thisTP.LoadTOPFiftyDIVPageTable(baseTable, "ui-grid-row", "ui-grid-cell");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 2)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[2];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = FRM.FRMMainPage.Top50SearchUnderOverPaymentResults;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }










        [Then(@"Verify FRM Next page Top 50 OverUnder Payment section Search Criteria Accordion Plan ID is set to""(.*)""")]
        public void ThenVerifyFRMNextPageTopOverUnderPaymentSectionSearchCriteriaAccordionPlanIDIsSetTo(string p1)
        {
            string fieldName = "FRM Main TOP 50 Over Under Payment PlanID ";

            string expected = tmsCommon.GenerateData(p1);

            IWebElement ddele = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@name='topfiftyPlanId']//span[@class='k-input']"));
            string actual = AngularFunction.getText(ddele).Trim();
           
            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }

        [Then(@"Verify FRM Next page Top 50 OverUnder Payment section Search Criteria Accordion Discrepancy Type  is set to""(.*)""")]
        public void ThenVerifyFRMNextPageTopOverUnderPaymentSectionSearchCriteriaAccordionDiscrepancyTypeIsSetTo(string p1)
        {
            string fieldName = "FRM Main TOP 50 Over Under Payment Discrepancy Type ";

            string expected = tmsCommon.GenerateData(p1);

            IWebElement ddele = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@name='topfiftyDiscrepancyType']//span[@class='k-input']"));
            string actual = AngularFunction.getText(ddele).Trim();

            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }




        [When(@"FRM Next page General Search section Search Criteria Accordion Reset button is Clicked")]
        public void WhenFRMNextPageGeneralSearchSectionSearchCriteriaAccordionResetButtonIsClicked()
        {

            tmsWait.Hard(1);
            fw.ExecuteJavascript(FRM.FRMMainPage.GeneralSearchResetButton);
        }

        [Then(@"Verify that Search results are displayed")]
        public void ThenVerifyThatSearchResultsAreDisplayed()
        {
            tmsWait.Hard(15);
            By res = By.XPath("(//a[@title='View'])[1]");
            bool results = Browser.Wd.FindElement(res).Displayed;
            Assert.IsTrue(results," Search results are not displaued");
        }

        [When(@"FRM Next page General Search section Search Criteria Accordion Search button is Clicked")]
        [Given(@"FRM Next page General Search section Search Criteria Accordion Search button is Clicked")]
        public void WhenFRMNextPageGeneralSearchSectionSearchCriteriaAccordionSearchButtonIsClicked()
        {
            tmsWait.Hard(2);
            //IWebElement all = Browser.Wd.FindElement(By.CssSelector("[test-id='genSearchCrt-inp-partValue1']"));
            //fw.ExecuteJavascript(all);
            //tmsWait.Hard(2);
            fw.ExecuteJavascript(FRM.FRMMainPage.GeneralSearchSearchButton);
            tmsWait.Hard(20);
        }

        [Then(@"Verify FRM Next page General Search section result ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyFRMNextPageGeneralSearchSectionResultIsSetTo(string p0, string p1)
        {
            string expectedMBI = GlobalRef.MBI.ToString();
            string acutalMBI = Browser.Wd.FindElement(By.XPath("//span[@test-id='memberSummary-spn-mbiValue']")).Text;
            Assert.AreEqual(expectedMBI, acutalMBI, "Member Information is mismatch");

        }


        [Then(@"variable ""(.*)"" Is Stored First HIC From Search Result")]
        public void ThenVariableIsStoredFirstHICFromSearchResult(string p0)
        {

            IWebElement page = Browser.Wd.FindElement(By.XPath("//div[@test-id='genSearchCrt-grid-generalGrid']//div[@class='ui-grid-cell ng-scope ui-grid-coluiGrid-001W']"));
            string actualresults = page.Text;
            GlobalRef.MBI = actualresults;
        }

        [Then(@"first HIC From Search Result is stored into variable ""(.*)""")]
        public void ThenFirstHICFromSearchResultIsStoredIntoVariable(string p0)
        {
            // IWebElement page = Browser.Wd.FindElement(By.XPath("//div[@test-id='genSearchCrt-grid-generalGrid']//div[@class='ui-grid-cell ng-scope ui-grid-coluiGrid-002E']"));
            IWebElement page = Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='genSearchCrt-grid-generalGrid']//td[@aria-colindex='2'])[1]"));
            string actualresults = page.Text;
            GlobalRef.MBI = actualresults;
            fw.setVariable(p0, actualresults);

        }


      

        [Then(@"Member Details variable ""(.*)"" ""(.*)"" Is Stored from Member Summary page")]
        public void ThenMemberDetailsVariableIsStoredFromMemberSummaryPage(string MBI, string Surname)
        {
            IWebElement mbi = Browser.Wd.FindElement(By.XPath("//span[@test-id='membrSummry-span-hic']"));
            string actualmbi = mbi.Text;
            GlobalRef.MBI = actualmbi;
            IWebElement surname = Browser.Wd.FindElement(By.XPath("//span[@test-id='membrSummry-span-surName']"));
            string actualsurname = surname.Text;
            GlobalRef.Surname = actualsurname;
        }


        [Then(@"Verify FRM Next page General Result Panel displays Search results successfully")]
        public void ThenVerifyFRMNextPageGeneralResultPanelDisplaysSearchResultsSuccessfully()
        {
            tmsWait.Hard(10);
            bool searchresults = false;
            ReadOnlyCollection<IWebElement> rowcount = Browser.Wd.FindElements(By.XPath("//kendo-grid[@test-id='genSearchCrt-grid-generalGrid']//tr"));
            if (rowcount.Count > 2)
            {
                searchresults = true;
            }
            Assert.IsTrue(searchresults, " Search results are not getting displayed");


        }
        [When(@"Enroll Disenroll Member page Avaiable To Delete section First Record is Clicked")]
        [When(@"Enroll Disenroll Member page Avaiable To Delete section ""(.*)"" is Clicked")]
        public void WhenEnrollDisenrollMemberPageAvaiableToDeleteSectionIsClicked(string p0)
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//*[@id='availablePayMonths']//input)[2]")));
        }
       
        [When(@"Enroll Disenroll Member page Reason for Adjustment ""(.*)"" is selected")]
        public void WhenEnrollDisenrollMemberPageReasonForAdjustmentIsSelected(string p0)
        {
            string reason = tmsCommon.GenerateData(p0).ToUpper();
            By Drp = By.XPath("//label[contains(.,'Reason for Adjustment')]/parent::div//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + reason + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
        }

        [Then(@"Verify Enroll Disenroll Member page displays message ""(.*)""")]
        public void ThenVerifyEnrollDisenrollMemberPageDisplaysMessage(string expected)
        {
            tmsWait.Hard(4);
            IWebElement label = Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainEnrollDisenroll-lbl-fromMembers']"));
            Assert.AreEqual(label.Text, expected, expected + "is not getting displayed");
        }


        [When(@"Enroll Disenroll Member page ""(.*)"" button is Clicked")]
        public void WhenEnrollDisenrollMemberPageButtonIsClicked(string button)
        {
            IWebElement ele = null;

            switch(button)
            {
                case "ADD":
                    ele = Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainEnrollDisenroll-btn-btnAdd']"));
                    fw.ExecuteJavascript(ele);
                    break;
                   
                case "REMOVE":
                    ele = Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainEnrollDisenroll-btn-btnRemove']"));
                    fw.ExecuteJavascript(ele);                   
                    break;

                case "SAVE":
                    ele = Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainEnrollDisenroll-btn-btnSave']"));
                    fw.ExecuteJavascript(ele);
                    break;
                case "CMS":
                    tmsWait.Hard(5);
                    ele = Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainEnrollDisenroll-btn-btnCmsEnrl']"));
                    fw.ExecuteJavascript(ele);
                    tmsWait.Hard(3);
                    break;
            }
        }

        [When(@"Enroll Disenroll Member page CMS Button is Clicked")]
        public void WhenEnrollDisenrollMemberPageCMSButtonIsClicked()
        {
            IWebElement optionbutton = Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainEnrollDisenroll-btn-btnCmsEnrl']"));
                    fw.ExecuteJavascript(optionbutton);
        }


        [When(@"Enroll Disenroll Member page ""(.*)"" Option is Clicked")]
        public void WhenEnrollDisenrollMemberPageOptionIsClicked(string p0)
        {
            tmsWait.Hard(5);
            IWebElement optionbutton = null;
            string option = p0.ToString();
            switch(option)
            {
                case "Part C":
                    optionbutton = Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainEnrollDisenroll-rdo-partChange1']"));
                    fw.ExecuteJavascript(optionbutton);
                    break;
                case "Part D":
                    optionbutton = Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainEnrollDisenroll-rdo-partChange2']"));
                    fw.ExecuteJavascript(optionbutton);
                    break;
                case "Enroll":
                    optionbutton = Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainEnrollDisenroll-rdo-partChang2']"));
                    fw.ExecuteJavascript(optionbutton);
                    break;
                case "DisEnroll":
                    optionbutton = Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainEnrollDisenroll-rdo-frmEnrollDisenrollScopeD']"));
                    fw.ExecuteJavascript(optionbutton);
                    break;
            }

        }

        [Then(@"Verify ""(.*)"" page Graph is displayed")]
        public void ThenVerifyPageGraphIsDisplayed(string p0)
        {
            tmsWait.Hard(5);
            IWebElement temp = Browser.Wd.FindElement(By.CssSelector("[test-id='membrPaySumry-cnvs-myChart']"));
            Assert.IsTrue(temp.Displayed, p0 + " Graph is not displayed");
        }

        [When(@"""(.*)"" page Part C button is Clicked")]
        public void WhenPagePartCButtonIsClicked(string p0)
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//span[@title='View'])[1]")));
        }

        [When(@"""(.*)"" page Part D button is Clicked")]
        public void WhenPagePartDButtonIsClicked(string p0)
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.Id("btnPartD")));
        }

       

        [When(@"member-paymentsumary page ""(.*)"" button is Clicked")]
        public void WhenMember_PaymentsumaryPageButtonIsClicked(string p0)
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[test-id='membrPaySumry-btn-btnPartC']")));
        }


        [Then(@"Verify ""(.*)"" report opened successfully")]
        public void ThenVerifyReportOpenedSuccessfully(string p0)
        {
            Browser.SwitchToChildWindow();
            tmsWait.Hard(6);
            //Assert.IsTrue(Browser.Wd.PageSource.Contains(p0), p0 + "is not getting displayed");
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@id='ReportViewerControl']//td[contains(.,'" + p0 + "')]")).Displayed);
        }



        [When(@"FRM Main ""(.*)"" tab Member Summary section ""(.*)"" link is Clicked")]
        public void WhenFRMMainTabMemberSummarySectionLinkIsClicked(string p0, string p1)
        {
            tmsWait.Hard(10);
            IWebElement element = null;

            if (p0.ToString().Equals("General Search"))
            {
                switch (p1)
                {
                    case "adjustDiscrepancy":
                        element = Browser.Wd.FindElement(By.CssSelector("[test-id='membrPayDetail-anc-adjustDiscrepancy']"));
                        tmsWait.WaitForElement(By.CssSelector("[test-id='membrPayDetail-anc-adjustDiscrepancy']"), 20);
                        fw.ExecuteJavascript(element);
                        break;
                    case "Member Information":
                        element = Browser.Wd.FindElement(By.CssSelector("[test-id='membrPayDetail-anc-memInfo']"));
                        fw.ExecuteJavascript(element);
                        break;
                    case "PayMentSummary":
                        element = Browser.Wd.FindElement(By.CssSelector("[test-id='membrPayDetail-anc-memPaySumm']"));
                        fw.ExecuteJavascript(element);
                        break;
                }
            }
            // As test-id is implemented, Script development Approach is changed
            else if (p0.ToString().Equals("HIC Name Search"))
            {
                Browser.Wd.FindElement(By.XPath("//a[@test-id='membrPayDetail-anc-adjustDiscrepancy']")).Click();
            }
        }


        [When(@"FRM Main General Search results HIC Number ""(.*)"" view link is clicked")]
        public void WhenFRMMainGeneralSearchResultsHICNumberViewLinkIsClicked(string HICNumber)
        {
            tmsWait.Hard(5);
            bool nextPage;
            //IWebElement view = Browser.Wd.FindElement(By.XPath("//div[@class='ui-grid-cell-contents ng-binding ng-scope'][contains(.,'HICN000015')]/parent::div/following-sibling::div//a"));

            do
            {
                nextPage = clickonHICNumberViewLink(HICNumber);
                if (nextPage)
                {
                    Browser.Wd.FindElement(By.LinkText("Next")).Click();
                }
            } while (nextPage);

        }
        public bool clickonHICNumberViewLink(string HIC)
        {
            try
            {
                if (Browser.Wd.FindElement(By.XPath("//div[@class='ui-grid-cell-contents ng-binding ng-scope'][contains(.,'" + HIC + "')]/parent::div/following-sibling::div//a")).Displayed)
                {

                    Browser.Wd.FindElement(By.XPath("//div[@class='ui-grid-cell-contents ng-binding ng-scope'][contains(.,'" + HIC + "')]/parent::div/following-sibling::div//a")).Click();
                    return false;

                }
            }
            catch (Exception ex)
            {
                return true;
            }
            return true;
        }

        [When(@"FRM Main General Search results View link is clicked")]
        public void WhenFRMMainGeneralSearchResultsViewLinkIsClicked()
        {
            tmsWait.WaitForElement(By.CssSelector("a[title='View']"), 300);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("a[title='View']")));
        }

        [When(@"General Search results View link is Clicked")]
        public void WhenGeneralSearchResultsViewLinkIsClicked()
        {
            tmsWait.WaitForElement(By.CssSelector("a[title='View']"), 300);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("a[title='View']")));
        }


        [When(@"Search Results Last Name Title is Clicked for Sorting")]
        public void WhenSearchResultsLastNameTitleIsClickedForSorting()
        {
            fw.ExecuteJavascript(FRMMainGeneralSearch.GeneralSearchLastNameSortLink);
            tmsWait.Hard(2);
            Browser.Wd.FindElement(By.LinkText("First")).Click();
        }

        [When(@"FRM Next page Result Panel View Icon is clicked for row")]
        public void WhenFRMNextPageResultPanelViewIconIsClickedForRow(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = FRM.FRMMainPage.GeneralSearchSearchResults;
                IWebElement paginationSystem = FRM.FRMMainPage.GeneralSearchPagination;

                //Look for a next page link.  We will set 'last page of records' here also.
                //thisTP.LoadNextPageLink(baseTable);
                thisTP.LoadDIVNextPageLink(paginationSystem, "pagination-next ng-scope");

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                //   thisTP.LoadPageTable(baseTable, "td", "td");
                thisTP.LoadDIVPageTable(baseTable, "ui-grid-row", "ui-grid-cell");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 2)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[2];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = FRM.FRMMainPage.GeneralSearchSearchResults;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }



   
        [Then(@"Verify FRM Nextpage Result Panel displays Previous Search results ""(.*)""")]
        public void ThenVerifyFRMNextpageResultPanelDisplaysPreviousSearchResults(string p0)
        {
            tmsWait.Hard(1);
           string mbi = GlobalRef.FRMMBI.ToString();
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@class='k-grid-content k-auto-scrollable']//span[contains(.,'" + mbi + "')]")).Displayed);
        }

        [Then(@"Verify FRM Search Result Panel displays Previous Search results ""(.*)""")]
        public void ThenVerifyFRMSearchResultPanelDisplaysPreviousSearchResults(string p0)
        {
            tmsWait.Hard(1);
            string mbi = GlobalRef.MBI.ToString();
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='hicNameSearchgrid-grid-hicnameGridPreviousSearch']//div[@class='ui-grid-cell-contents ng-binding ng-scope'][contains(.,'" + mbi + "')]")).Displayed);
        }



        [Then(@"Verify FRM Next page Result Panel displays Previous Search results")]
        public void ThenVerifyFRMNextPageResultPanelDisplaysPreviousSearchResults(Table table)
        {



            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = FRM.FRMMainPage.GeneralPrevSearchSearchResults;
                IWebElement paginationSystem = FRM.FRMMainPage.HICNameSearchPagination;

                //Look for a next page link.  We will set 'last page of records' here also.
                //thisTP.LoadNextPageLink(baseTable);
                thisTP.LoadDIVNextPageLink(paginationSystem, "pagination-next ng-scope");

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                //   thisTP.LoadPageTable(baseTable, "td", "td");
                thisTP.LoadDIVPageTable(baseTable, "ui-grid-row", "ui-grid-cell");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 2)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[2];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");


                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = FRM.FRMMainPage.GeneralPrevSearchSearchResults;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }


        }

        [Then(@"Verify FRM Next page General Result Panel displays Search results")]
        public void ThenVerifyFRMNextPageGeneralResultPanelDisplaysSearchResults(Table table)
        {

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = FRM.FRMMainPage.GeneralSearchSearchResults;
                IWebElement paginationSystem = FRM.FRMMainPage.GeneralSearchPagination;

                //Look for a next page link.  We will set 'last page of records' here also.
                //thisTP.LoadNextPageLink(baseTable);
                thisTP.LoadDIVNextPageLink(paginationSystem, "pagination-next ng-scope");

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                //   thisTP.LoadPageTable(baseTable, "td", "td");
                thisTP.LoadAngularDIVPageTable(baseTable, "ui-grid-row", "ui-grid-cell");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 2)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[2];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");


                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = FRM.FRMMainPage.GeneralSearchSearchResults;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }



        }


        [Then(@"Verify FRM Next page HIC Name Search Result Panel displays Search results")]
        public void ThenVerifyFRMNextPageHICNameSearchResultPanelDisplaysSearchResults(Table table)
        {
            tmsWait.Hard(4);

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = FRM.FRMMainPage.HICNameSearchResults;
               // IWebElement paginationSystem = FRM.FRMMainPage.HICNameSearchPagination;

                //Look for a next page link.  We will set 'last page of records' here also.
                //thisTP.LoadNextPageLink(baseTable);
               //thisTP.LoadDIVNextPageLink(paginationSystem, "pagination-next ng-scope");

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                //   thisTP.LoadPageTable(baseTable, "td", "td");
                thisTP.LoadAngularHICNameSearchTable(baseTable, "ui-grid-row", "ui-grid-cell");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 2)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[2];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");


                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = FRM.FRMMainPage.HICNameSearchResults;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

    




        [Then(@"Verify FRM Next page Result Panel displays Search results")]
       public void ThenVerifyFRMNextPageResultPanelDisplaysSearchResults(Table table)
       {
            tmsWait.Hard(2);

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
           TablePaging thisTP = new TablePaging();

           //Load the Gherkin table into the storage
           thisGT.LoadGherkinTable(table);

           //The big loop.  Keep working until all the Gherkin table rows are marked as matched
           //Or until we are on the last page of records, then we also quit looking.
           while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
           {
               //Start out with the assumption we are not on the last page of records.  We will check later.
               thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = FRM.FRMMainPage.GeneralSearchSearchResults;
                IWebElement paginationSystem = FRM.FRMMainPage.GeneralSearchPagination;

                //Look for a next page link.  We will set 'last page of records' here also.
                //thisTP.LoadNextPageLink(baseTable);
                thisTP.LoadDIVNextPageLink(paginationSystem, "pagination-next ng-scope");

               //Load the page data off the application.   
               //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
            //   thisTP.LoadPageTable(baseTable, "td", "td");
               thisTP.LoadAngularDIVPageTable(baseTable, "ui-grid-row", "ui-grid-cell");

               int iTableCounter = 0;
               string expectedTableCheckboxValue = "";
               //for each row in the Gherkin table, start flipping through all the rows in the page data.
               foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
               {
                   //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                   //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                   if (GherkinTableRow == null)
                   {
                       break;
                   }

                   //If this Gherkin table row is not yet matched, proceed.
                   if (GherkinTableRow.RowIsMatched == false)
                   {
                       //Convert the row to an array so we can do an element by element match.
                       string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                       //For each row in the page data
                       foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                       {
                           //Convert page data to array elements
                           //Only work with the loaded element rows.  The first unloaded one will be null.
                           if (ApplicationRow == null)
                           {
                               break;
                           }

                           //Convert the page row to array so we can pair up by elements.
                           string[] AppTableRow = ApplicationRow.Row.ToArray();
                           int iElementCounter = 0;
                           Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                           //In here as we pair up the data you will have custom matching.
                           //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                           foreach (string appTD in AppTableRow)
                           {
                               //if (iElementCounter > 0 && TDA.RowIsData)
                               if (ApplicationRow.RowIsData)
                               {
                                   //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                   if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                   {
                                       bThisRowMatches = false;
                                   }
                                   if (iElementCounter == 2)
                                   {
                                       expectedTableCheckboxValue = GherkinTableArray[2];
                                   }
                               }
                               else
                               {
                                   //Also fail row match if the element count of the page data row is 0
                                   if (iElementCounter > 0)
                                   {
                                       bThisRowMatches = false;
                                   }
                               }
                               iElementCounter++;
                           }
                           if (AppTableRow.Length == 0)
                           {
                               //Another check that if the page data row is 0 long, we didn't match, fail the match.
                               bThisRowMatches = false;
                           }
                           //Instance of TableRow Class for reporting functions
                           var TableRow = new TMSString();
                           //If we get here and we still match, then the array elements were the same

                           if (bThisRowMatches)
                           {
                               //report the success stuff.  Puts out the row data, etc.
                               thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                           }
                       }
                   }
                   iTableCounter++;
               }
               //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
               Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
               if (fullMatching)
               {
                    Console.WriteLine("All rows are matched, step completed as passed");
                                     
                  
                }
               else
               {
                   //Click next page link and start over.
                   if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                   {
                        tmsWait.Hard(5);
                        thisTP.bNotAtLastPageOfRecords = true;
                       thisTP.NPL.Click();
                       tmsWait.Hard(2);
                   }
               }
               baseTable = FRM.FRMMainPage.GeneralSearchSearchResults;

               //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
               //Time to boil it down and report which rows didn't get matched.
               //Also to fail because we were planning to match the rows.
               if (thisTP.bHaveGoodPageLink == false && !fullMatching)
               {
                   thisTP.ReportNotMatching(thisGT.GTable);
               }
           }
       }
    }
}


