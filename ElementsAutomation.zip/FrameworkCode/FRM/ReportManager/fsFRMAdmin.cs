﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using TechTalk.SpecFlow;
using TMSoR1.FrameworkCode;
using TMSoR1.FrameworkCode.FRM;
namespace TMSoR1
{
    [Binding]
    class fsFRMAdmin
    {
      

        [When(@"MouseMoveTo ""(.*)"" menu")]
        public void WhenMouseMoveToMenu(string menuToBeMouseMove)
        {
            switch (menuToBeMouseMove)
            {
                case "Extract": { MouseFunctions.MouseMoveToElement(FRMMainNavigation.FRMAdministartorExtractsmenu); tmsWait.Hard(2); break; }
                case "Administrator": { MouseFunctions.MouseMoveToElement(FRMMainNavigation.FRMAdministratormenu); break; }
            }
        }


        [Then(@"FRM Next Page Extract menu available with sub menus ""(.*)"" ""(.*)""")]
        public void ThenFRMNextPageExtractMenuAvailableWithSubMenus(string mmrExtractSubmenu, string premiumMemberExtractSubmenu)
        {
            tmsWait.Hard(2);

            Assert.IsTrue(tmsWait.IsElementPresent(By.XPath("//span[contains(.,'MMR Extract')]")));
            Assert.AreEqual(FRM.FRMAdministrator.MMRExtractsTitle.Text, mmrExtractSubmenu, mmrExtractSubmenu + " Page is displayed");

            Assert.IsTrue(tmsWait.IsElementPresent(By.XPath("//span[contains(.,'Member Premium Extract')]")));
            Assert.AreEqual(FRM.FRMAdministrator.MemberPremiumExtract.Text, premiumMemberExtractSubmenu, premiumMemberExtractSubmenu + " Page is displayed");
        }

         [Then(@"FRM Next page Administrator section available with sub menus ""(.*)"" ""(.*)"" ""(.*)"" ""(.*)"" ""(.*)"" ""(.*)"" ""(.*)"" ""(.*)"" ""(.*)"" ""(.*)"" ""(.*)"" ""(.*)""")]
        public void ThenFRMNextPageAdministratorSectionAvailableWithSubMenus(string batchupdate, string changeIndividualHIC, string changePlanID, string deleteOldDiscrepancies, string exportMonthlyExtract, string manageBidToolRates, string manageDiscrepancyStatusCode, string managePlanAdjustmentReasons, string planStarRatings, string runEnrollmentCheck, string workFlowAssignment, string extract)
        {
          

        // Assert.AreEqual(FRMMainNavigation.FRMAdministartormenubatchEnrollDisenroll.Text, batchenroll, "Batch Enroll/Disenroll sub menu is getting displayed.");
        Assert.AreEqual(FRMMainNavigation.FRMAdministartormenubatchUpdate.Text, batchupdate, "Batch Update sub menu is getting displayed.");
            Assert.AreEqual(FRMMainNavigation.FRMAdministartormenuchangeindividualHIC.Text, changeIndividualHIC, "Change Individual HIC sub menu is getting displayed.");
            Assert.AreEqual(FRMMainNavigation.FRMAdministartormenuchangePlanId.Text, changePlanID, "Change Plan ID sub menu is getting displayed.");
            Assert.AreEqual(FRMMainNavigation.FRMAdministartormenudeleteOldDiscrepancies.Text, deleteOldDiscrepancies, "Delete Old Discrepancies sub menu is getting displayed.");
            //Assert.AreEqual(FRMMainNavigation.FRMAdministartormenuerrorLog.Text, errorLog, "Error Log sub menu is getting displayed.");
            Assert.AreEqual(FRMMainNavigation.FRMAdministartormenuexportMonthlyExtract.Text, exportMonthlyExtract, "Explort Monthly Extract sub menu is getting displayed.");
            Assert.AreEqual(FRMMainNavigation.FRMAdministartormenumanageBidToolRates.Text, manageBidToolRates, "Manage Bid Tool Rates sub menu is getting displayed.");
            Assert.AreEqual(FRMMainNavigation.FRMAdministartormenuplanStarRatings.Text, planStarRatings, "Plan Start Ratings sub menu is getting displayed.");
            Assert.AreEqual(FRMMainNavigation.FRMAdministartormenumanageDiscrepancyStatusCode.Text, manageDiscrepancyStatusCode, "Manage Discrepancy Status Code sub menu is getting displayed.");
            Assert.AreEqual(FRMMainNavigation.FRMAdministartormenumanagePlanAdjustmentReasons.Text, managePlanAdjustmentReasons, "Manage Plan Adjustment Reasons sub menu is getting displayed.");
            Assert.AreEqual(FRMMainNavigation.FRMAdministartormenuworkFlowAssignment.Text, workFlowAssignment, "Workflow Assignment sub menu is getting displayed.");
            Assert.AreEqual(FRMMainNavigation.FRMAdministartormenurunEnrollmentCheck.Text, runEnrollmentCheck, "Run Enrollment sub menu is getting displayed.");
            Assert.AreEqual(FRMMainNavigation.FRMAdministartorExtractsmenu.Text, extract, "Extract sub menu is getting displayed.");
        }


        [When(@"FRM Administration Menu ""(.*)"" sub menu is Clicked")]
        public void WhenFRMAdministrationMenuSubMenuIsClicked(string p0)
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Administration']")));
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]")));
            tmsWait.Hard(2);

        }
        [When(@"Administration page Change Plan ID MBI is set to ""(.*)""")]
        public void WhenAdministrationPageChangePlanIDMBIIsSetTo(string p0)
        {
            string mbi = tmsCommon.GenerateData(p0);
            IWebElement change_mbi = Browser.Wd.FindElement(By.XPath("//input[@test-id='changePlanId-txt-planNumberHicID']"));
            change_mbi.SendKeys(mbi);
            tmsWait.Hard(1);
            change_mbi.SendKeys(Keys.Tab);
            tmsWait.Hard(3);
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[@test-id='changePlanId-lbl-partType']")));
        }

        [When(@"Administration page Change Plan ID section HIC Number is set to ""(.*)""")]
        public void WhenAdministrationPageChangePlanIDSectionHICNumberIsSetTo(string p1)
        {
            //TMSoR1.FRM.FRMChangePlanID.HICNumber.SendKeys(p0);
            string p0 = tmsCommon.GenerateData(p1);
            IWebElement mbiLookup = Browser.Wd.FindElement(By.XPath("//span[@test-id='changePlanId-span-existingSearchName']/a"));
            fw.ExecuteJavascript(mbiLookup);
            tmsWait.Hard(5);
            IWebElement reset = Browser.Wd.FindElement(By.CssSelector("[test-id='searchHIC-btn-resetHicNameSearch']"));
            fw.ExecuteJavascript(reset);
            tmsWait.Hard(2);
            IWebElement mbi = Browser.Wd.FindElement(By.CssSelector("[test-id='searchHIC-txt-ClaimNumberHicID']"));
            mbi.Clear();
            mbi.SendKeys("HIC");
            IWebElement searchBtn = Browser.Wd.FindElement(By.CssSelector("[test-id='searchHIC-btn-PopupexistingSearchNamenbtnS']"));
            fw.ExecuteJavascript(searchBtn);
            try
            {
                By toastMsg = By.XPath("//div[@class='toast-message'][contains(.,'No items found matching the search criteria.')]");
                bool msgDisplay = Browser.Wd.FindElement(toastMsg).Displayed;
                tmsWait.Hard(3);
                if (msgDisplay)
                {
                    mbi.Clear();
                    mbi.SendKeys("123");
                    fw.ExecuteJavascript(searchBtn);
                }
            }
            catch
            {

            }

            tmsWait.Hard(2);
            IWebElement select = Browser.Wd.FindElement(By.XPath("(//a[@title='Select'])[2]"));
            fw.ExecuteJavascript(select);
            tmsWait.Hard(2);

        }

        //[When(@"Administration page change Plan ID MBI is set to ""(.*)""")]
        //public void WhenAdministrationPageChangePlanIDMBIIsSetTo(string p0)
        //{
        //    string mbi = tmsCommon.GenerateData(p0);
        //    IWebElement change_mbi= Browser.Wd.FindElement(By.XPath("//input[@test-id='changePlanId-txt-planNumberHicID']"));
        //    change_mbi.SendKeys(mbi);
        //}


        [When(@"Administration page Change Plan ID section Part Type ""(.*)"" option is Clicked")]
        public void WhenAdministrationPageChangePlanIDSectionPartTypeOptionIsClicked(string p0)
        {

            string option = p0.ToString();
           switch(option)
            {

                case "Part C":
                    fw.ExecuteJavascript(TMSoR1.FRM.FRMChangePlanID.PartCOption);
                    tmsWait.Hard(3);
                    break;

                case "Part D":
                    fw.ExecuteJavascript(TMSoR1.FRM.FRMChangePlanID.PartDOption);
                    tmsWait.Hard(3);
                    break;

            }

        }

        [When(@"Administration page Change Plan ID section Current Plan Enrolled Payment Month is checked")]
        public void WhenAdministrationPageChangePlanIDSectionCurrentPlanEnrolledPaymentMonthIsChecked()
        {
            tmsWait.Hard(3);
            fw.ExecuteJavascript(TMSoR1.FRM.FRMChangePlanID.CurrentPlanEnrolledCheckbox);
        }

        [When(@"Administration page Change Plan ID section New Plan ID ""(.*)"" is selected")]
        public void WhenAdministrationPageChangePlanIDSectionNewPlanIDIsSelected(string p1)
        {
            string value = tmsCommon.GenerateData(p1);
            try
            {
                By loc = By.XPath("//kendo-dropdownlist[@test-id='changePlanId-select-selectedPlanId']//span[@class='k-select']");            
                AngularFunction.selectDropDownValue(loc, value);
               
            }
            catch
            {
                SelectElement select = new SelectElement(TMSoR1.FRM.FRMChangePlanID.NewPlanID);
                select.SelectByText("S0003");
            }
        }

        [When(@"Administration page Change Plan ID section Add button is Clicked")]
        public void WhenAdministrationPageChangePlanIDSectionAddButtonIsClicked()
        {
            fw.ExecuteJavascript(TMSoR1.FRM.FRMChangePlanID.AddButton);
        }

        [When(@"Administration page Change Plan ID section Save button is Clicked")]
        public void WhenAdministrationPageChangePlanIDSectionSaveButtonIsClicked()
        {
            fw.ExecuteJavascript(TMSoR1.FRM.FRMChangePlanID.SaveButton);
        }

        [Then(@"Verify Administration page Change Plan ID section ""(.*)"" message is displayed")]
        public void ThenVerifyAdministrationPageChangePlanIDSectionMessageIsDisplayed(string p0)
        {
            tmsWait.Hard(2);
            string expected = p0.ToString();
            string actual = TMSoR1.FRM.FRMChangePlanID.Successmsg.Text;

            Assert.AreEqual(expected, actual.Trim(), expected + " message is getting displayed");

        }


        [When(@"Administration page Change Plan ID section Reset button is Clicked")]
        public void WhenAdministrationPageChangePlanIDSectionResetButtonIsClicked()
        {
            fw.ExecuteJavascript(TMSoR1.FRM.FRMChangePlanID.ResetButton);
        }

        [Then(@"Verify Administration page Change Plan ID section HIC Number is set to ""(.*)""")]
        public void ThenVerifyAdministrationPageChangePlanIDSectionHICNumberIsSetTo(string p0)
        {
            string expected = p0.ToString();
            string actual = TMSoR1.FRM.FRMChangePlanID.HICNumber.Text;

            Assert.AreEqual(expected, actual, " Both values are matching");

        }

        [Then(@"Verify Administration page Change Plan ID section Part Type ""(.*)"" option is selected")]
        public void ThenVerifyAdministrationPageChangePlanIDSectionPartTypeOptionIsSelected(string p0)
        {
            tmsWait.Hard(10);

            string expected = p0.ToString();

            switch(expected)

            {
               
                case "Part C":
                    tmsWait.Hard(2);
                    Assert.IsTrue(TMSoR1.FRM.FRMChangePlanID.PartCOptionbutton.Selected, expected + " Option is selected");

                    break;

                case "Part D":
                    Assert.IsTrue(TMSoR1.FRM.FRMChangePlanID.PartDOptionbutton.Selected, expected + " Option is selected");

                    break;

            }
            

            
        }
        [Then(@"Verify Adjust Discrepancy Page displayed ""(.*)"" option as Default")]
        public void ThenVerifyAdjustDiscrepancyPageDisplayedOptionAsDefault(string p0)
        {
            string section = p0.ToString();
            bool elementSelected;
            By loc;
            switch (section)
            {
                case "Part C":
                    loc = By.XPath("//input[@test-id='frmMainAdjDisc-rdo-fmad_PartC']");
                    elementSelected = Browser.Wd.FindElement(loc).Selected;
                    Assert.IsTrue(elementSelected, "Elements is not slected");
                    break;
                case "Part D":
                    loc = By.XPath("//input[@test-id='frmMainAdjDisc-rdo-fmad_PartD']");
                    elementSelected = Browser.Wd.FindElement(loc).Selected;
                    Assert.IsTrue(elementSelected, "Elements is not slected");
                    break;
            }
        }

        [Then(@"Verify Enroll Disenroll Member Page displayed ""(.*)"" option as Default")]
        public void ThenVerifyEnrollDisenrollMemberPageDisplayedOptionAsDefault(string p0)
        {
            string section = p0.ToString();
            bool elementSelected;
            By loc;
            switch (section)
            {
                case "Part C":
                    loc = By.XPath("//input[@test-id='frmMainEnrollDisenroll-rdo-partChange1']");
                    elementSelected = Browser.Wd.FindElement(loc).Selected;
                    Assert.IsTrue(elementSelected, "Elements is not slected");
                    break;
                case "Part D":
                    loc = By.XPath("//input[@test-id='frmMainEnrollDisenroll-rdo-partChange2']");
                    elementSelected = Browser.Wd.FindElement(loc).Selected;
                    Assert.IsTrue(elementSelected, "Elements is not slected");
                    break;
            }
        }


        [Then(@"Verify MMR History Page displayed ""(.*)"" option as Default")]
        public void ThenVerifyMMRHistoryPageDisplayedOptionAsDefault(string p0)
        {
            string section = p0.ToString();
            bool elementSelected;
            By loc;
            switch (section)
            {
                case "Part C":
                    loc = By.XPath("//input[@test-id='frmMainMMRHistory-rdo-partValue1']");
                    elementSelected = Browser.Wd.FindElement(loc).Selected;
                    Assert.IsTrue(elementSelected, "Elements is not slected");
                    break;
                case "Part D":
                    loc = By.XPath("//input[@test-id='frmMainMMRHistory-rdo-partValue2']");
                    elementSelected = Browser.Wd.FindElement(loc).Selected;
                    Assert.IsTrue(elementSelected, "Elements is not slected");
                    break;
            }
        }

        [Then(@"Verify Compare Flags Plan Vs CMS Page displayed ""(.*)"" option as Default")]
        public void ThenVerifyCompareFlagsPlanVsCMSPageDisplayedOptionAsDefault(string p0)
        {
            string section = p0.ToString();
            bool elementSelected;
            By loc;
            switch (section)
            {
                case "Part C":
                    loc = By.XPath("//input[@test-id='frmMainCmprFlag-rdo-radioPartc']");
                    elementSelected = Browser.Wd.FindElement(loc).Selected;
                    Assert.IsTrue(elementSelected, "Elements is not slected");
                    break;
                case "Part D":
                    loc = By.XPath("//input[@test-id='frmMainCmprFlag-rdo-radioPartd']");
                    elementSelected = Browser.Wd.FindElement(loc).Selected;
                    Assert.IsTrue(elementSelected, "Elements is not slected");
                    break;
            }
        }


        [Then(@"Verify FRM ""(.*)"" option is selected as Default")]
        public void ThenVerifyFRMOptionIsSelectedAsDefault(string p0)
        {
            string section = p0.ToString();
            bool elementSelected;
            By loc;
            switch (section)
            {
                case "Part C":
                    loc = By.XPath("//input[@test-id='changePlanId-radio-changePlanCID']");
                    elementSelected = Browser.Wd.FindElement(loc).Selected;
                    Assert.IsTrue(elementSelected,"Elements is not slected");
                    break;
                case "Part D":
                    loc = By.XPath("//input[@test-id='changePlanId-radio-changePlanDID']");
                    elementSelected = Browser.Wd.FindElement(loc).Selected;
                    Assert.IsTrue(elementSelected, "Elements is not slected");
                    break;
            }
        }

        [Then(@"Verify Administration Change Plan ID page MBI Lookup link is displayed")]
        public void ThenVerifyAdministrationChangePlanIDPageMBILookupLinkIsDisplayed()
        {
            bool elementDisp;
            By mbiLookup = By.XPath("//span[@test-id='changePlanId-span-existingSearchName']/a");
            ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(mbiLookup));
            tmsWait.Hard(4);
            By mbiLookupPage = By.XPath("//span[@test-id='searchHIC-span-hICNameSearchPopupHeader'][contains(.,'MBI Name Search')]");
            elementDisp = Browser.Wd.FindElement(mbiLookupPage).Displayed;
            Assert.IsTrue(elementDisp, "Elements is not Displayed");

            By backtorecord = By.XPath("//span[@test-id='searchHIC-span-Back']");
            ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(mbiLookup));
            tmsWait.Hard(2);
        }
        [Then(@"Verify Part C Bid Rates displayed ""(.*)"" label")]
        public void ThenVerifyPartCBidRatesDisplayedLabel(string labelText)
        {
            bool elementDisp;
            By label = By.XPath("//label[contains(.,'"+ labelText + "')]");
            elementDisp = Browser.Wd.FindElement(label).Displayed;
            Assert.IsTrue(elementDisp, "Elements is not Displayed");
        }

        [Then(@"Verify Part C Member Premium  section is displayed")]
        public void ThenVerifyPartCMemberPremiumSectionIsDisplayed()
        {
            bool elementDisp;
            By loc = By.XPath("//a[contains(.,'Part C Member Premium')]");
            elementDisp = Browser.Wd.FindElement(loc).Displayed;
            Assert.IsTrue(elementDisp, "Section is not Displayed");
        }

        [Then(@"Verify Part D Bid Rates  section is displayed")]
        public void ThenVerifyPartDBidRatesSectionIsDisplayed()
        {
            bool elementDisp;
            By loc = By.XPath("//a[contains(.,'Part D Bid Rates')]");
            elementDisp = Browser.Wd.FindElement(loc).Displayed;
            Assert.IsTrue(elementDisp, "Section is not Displayed");
        }
        [Then(@"Verify Part D Bid Rates displayed ""(.*)"" label")]
        public void ThenVerifyPartDBidRatesDisplayedLabel(string labelText)
        {
            bool elementDisp;
            By label = By.XPath("//label[contains(.,'" + labelText + "')]");
            elementDisp = Browser.Wd.FindElement(label).Displayed;
            Assert.IsTrue(elementDisp, "Elements is not Displayed");
        }

        [Then(@"Verify Part C Bid Rates section is displayed")]
        public void ThenVerifyPartCBidRatesSectionIsDisplayed()
        {
            bool elementDisp;
            By loc = By.XPath("//a[contains(.,'Part C Bid Rates')]");
            elementDisp = Browser.Wd.FindElement(loc).Displayed;
            Assert.IsTrue(elementDisp, "Section is not Displayed");
        }


        [Then(@"Verify Administration Change Plan ID page ""(.*)"" section is displayed")]
        public void ThenVerifyAdministrationChangePlanIDPageSectionIsDisplayed(string p0)
        {
            string section = p0.ToString();
            bool elementDisp;
            By loc;
            switch (section)
            {


                
                case "Current Plan Enrolled":
                    loc = By.XPath("//label[@test-id='changePlanId-lbl-currentPlan'][contains(.,'"+ section + "')]");
                    elementDisp = Browser.Wd.FindElement(loc).Displayed;
                    Assert.IsTrue(elementDisp, "Elements is not Displayed");
                    break;
                case "New Plan Enrollment":
                    loc = By.XPath("//label[@test-id='changePlanId-lbl-NewPlanEnrol'][contains(.,'"+ section + "')]");
                    elementDisp = Browser.Wd.FindElement(loc).Displayed;
                    Assert.IsTrue(elementDisp, "Elements is not Displayed");
                    break;
            }
        }


        [Then(@"Verify FRM displayed ""(.*)"" section as Default")]
        public void ThenVerifyFRMDisplayedSectionAsDefault(string p0)
        {
            string section = p0.ToString();
            By loc;
            switch (section)
            {
                case "Part C Bid Rates":
                    loc = By.XPath("//a[contains(.,'"+ section + "')]");
                    Assert.IsTrue(ReUsableFunctions.elementVisible(loc), "Elements is not slected");                        
                    break;
                case "Part D Bid Rates":
                    loc = By.XPath("//a[contains(.,'" + section + "')]");
                    Assert.IsTrue(ReUsableFunctions.elementVisible(loc), "Elements is not slected");
                    break;
            }
        }

        [Then(@"Verify TMS FRM Administration ""(.*)"" page is displayed")]
        public void ThenVerifyTMSFRMAdministrationPageIsDisplayed(string p0)
        {
            string page = p0.ToString();

            switch(page)
            {
                case "Batch Update Processing":
                    tmsWait.Hard(2);
                    Assert.AreEqual(FRMMainNavigation.PageTitle.Text, page, page + "is displayed successfully ");
                    break;

                case "Change Individual HIC":
                    tmsWait.Hard(2);
                    Assert.AreEqual(FRMMainNavigation.PageTitle.Text, page, page + "is displayed successfully ");
                    break;

                case "Change Plan ID":
                    tmsWait.Hard(2);
                    Assert.AreEqual(FRMMainNavigation.PageTitle.Text, page, page + "is displayed successfully ");
                    break;
                case "Delete Old Discrepancies":
                    tmsWait.Hard(1);
                    Assert.AreEqual(FRMMainNavigation.PageTitle.Text, page, page + "is displayed successfully ");
                    break;
                case "Export Monthly Extract to file":
                    tmsWait.Hard(1);
                    Assert.AreEqual(FRMMainNavigation.PageTitle.Text, page, page + "is displayed successfully ");
                    break;
                case "Manage Bid Tool Rates":
                    tmsWait.Hard(1);
                    Assert.AreEqual(FRMMainNavigation.PageTitle.Text, page, page + "is displayed successfully ");
                    break;
                case "Manage Discrepancy Status Code":
                    tmsWait.Hard(1);
                    Assert.AreEqual(FRMMainNavigation.PageTitle.Text, page, page + "is displayed successfully ");
                    break;
                case "Manage Plan Adjustment Reasons":
                    tmsWait.Hard(1);
                    Assert.AreEqual(FRMMainNavigation.PageTitle.Text, page, page + "is displayed successfully ");
                    break;
                case "Plan Star Ratings":
                    tmsWait.Hard(1);
                    Assert.AreEqual(FRMMainNavigation.PageTitle.Text, page, page + "is displayed successfully ");
                    break;
                case "Workflow Assignment":
                    tmsWait.Hard(1);
                    Assert.AreEqual(FRMMainNavigation.PageTitle.Text, page, page + "is displayed successfully ");
                    break;

            }
           
        }

        [Then(@"Verify Manage Plan PBP Info ""(.*)"" is mandatory field")]
        public void ThenVerifyManagePlanPBPInfoIsMandatoryField(string p0)
        {
            tmsWait.Hard(2);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'"+p0+"')]/span[@class='text-danger'][contains(.,'*')]")).Displayed, "Field is not a mandatory field");
        }




        [When(@"FRM Admin Manage Plan PBP Info ""(.*)""  is clicked")]
        public void WhenFRMAdminManagePlanPBPInfoIsClicked(string p0)
        {
            string fieldname = tmsCommon.GenerateData(p0);
            switch(fieldname.ToLower())
            {
                case "plan level tab":
                   fw.ExecuteJavascript(ManagePlanPBPInfo.PlanLevelTab);
                    break;
                case "pbp level tab":
                    fw.ExecuteJavascript(ManagePlanPBPInfo.PBPLevelTab);
                    break;
                case "segment level":
                    fw.ExecuteJavascript(ManagePlanPBPInfo.SegmentLevelTab);
                    break;

                case "add button":
                    fw.ExecuteJavascript(ManagePlanPBPInfo.AddButton);
                    break;
                case "edit all button":
                    fw.ExecuteJavascript(ManagePlanPBPInfo.EditAll);
                    break;
                case "update button":
                    fw.ExecuteJavascript(ManagePlanPBPInfo.UpdateButton);
                    break;
                case "cancel button":
                    fw.ExecuteJavascript(ManagePlanPBPInfo.CancelButton);
                    break;
                case "first checkbox":
                    fw.ExecuteJavascript(ManagePlanPBPInfo.CancelButton);
                    break;
                case "second checkbox":
                    fw.ExecuteJavascript(ManagePlanPBPInfo.CancelButton);
                    break;

                case "back to record link":
                    fw.ExecuteJavascript(ManagePlanPBPInfo.BackToRecordLink);
                    break;
            }

            
        }

        [When(@"FRM Admin Manage Plan PBP Info Edit Icon is clicked for PlanId ""(.*)""")]
        public void WhenFRMAdminManagePlanPBPInfoEditIconIsClickedForPlanId(string p0)
        {
            string pid = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + pid + "')]//following-sibling::td/a")));
            tmsWait.Hard(2);
        }

        [Then(@"Verify Manage Plan PBP Info Edit Screen ""(.*)"" is displayed as ""(.*)""")]
        public void ThenVerifyManagePlanPBPInfoEditScreenIsDisplayedAs(string p0, string p1)
        {
            string fieldname = tmsCommon.GenerateData(p0);
            string expectedvalue = tmsCommon.GenerateData(p1);
            string actualvalue ="" ;
            switch (fieldname.ToLower())
            {
                case "planid": actualvalue = ManagePlanPBPInfo.AddPlanId.GetAttribute("value");
                    break;

            }

            Assert.AreEqual(expectedvalue, actualvalue, "Values does not Match");
        }




        [Then(@"Verify Manage Plan PBP Info ""(.*)"" is same as the ""(.*)""")]
        public void ThenVerifyManagePlanPBPInfoIsSameAsThe(string p0, string p1)
        {
            string valueonUI = tmsCommon.GenerateData(p0);
            string valueonDB = tmsCommon.GenerateData(p1);
            Assert.AreEqual(valueonUI, valueonDB, "Both Values on DB and UI does not match");
        }


        [When(@"FRM Admin Manage Plan PBP Info Edit ""(.*)""  is set to ""(.*)""")]
        public void WhenFRMAdminManagePlanPBPInfoIsSetTo(string p0, string p1)
        {
            string fieldname = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (fieldname.ToLower())
            {
                case "department name":
                    ManagePlanPBPInfo.DepatmentName.SendKeys(value);
                    break;
                case "tollfree number":
                    ManagePlanPBPInfo.TollFreeNumber.SendKeys(value);
                    break;
                case "city":
                    ManagePlanPBPInfo.City.SendKeys(value);
                    break;
                case "state":
                    ManagePlanPBPInfo.State.SendKeys(value);
                    break;
                case "zip":
                    ManagePlanPBPInfo.Zip.SendKeys(value);
                    break;
                
            }
        }


        [When(@"FRM Admin Manage Plan PBP Info Add ""(.*)""  is set to ""(.*)""")]
        public void WhenFRMAdminManagePlanPBPInfoAddIsSetTo(string p0, string p1)
        {
            string fieldname = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (fieldname.ToLower())
            {
                case "plan id":
                    ManagePlanPBPInfo.AddPlanId.SendKeys(value);
                    break;
                case "plan type":
                   fw.ExecuteJavascript(ManagePlanPBPInfo.AddPlanType);
                    By ptype = By.XPath("//li[text()='" + value + "']");
                    fw.ExecuteJavascript(Browser.Wd.FindElement(ptype));
                    break;
                case "plan name":
                    ManagePlanPBPInfo.AddPlanName.SendKeys(value);
                    break;
                case "delivery method":
                    fw.ExecuteJavascript(ManagePlanPBPInfo.AddDeliveryMethod);
                    By dmethod = By.XPath("//li[text()='" + value + "']");
                    fw.ExecuteJavascript(Browser.Wd.FindElement(dmethod));
                    break;

                case "business state":
                    fw.ExecuteJavascript(ManagePlanPBPInfo.AddBusinessState);
                    By bstate = By.XPath("//li[text()='" + value + "']");
                    fw.ExecuteJavascript(Browser.Wd.FindElement(bstate));
                    break;

                case "effective date":
                    AngularFunction.enterDate(ManagePlanPBPInfo.AddEffectiveDate, value);
                    break;

                case "term date":
                    AngularFunction.enterDate(ManagePlanPBPInfo.AddTermDate, value);
                    break;

                case "partd term date":
                    AngularFunction.enterDate(ManagePlanPBPInfo.AddPartDTermDate, value);
                    break;

                case "partd effective date":
                    AngularFunction.enterDate(ManagePlanPBPInfo.AddPartDEffectiveDate, value);
                    break;
               
                case "department name":
                    ManagePlanPBPInfo.AddDepartmentName.SendKeys(value);
                    break;

                
                case "address":
                    ManagePlanPBPInfo.AddAddress1.SendKeys(value);
                    break;
                case "city":
                    ManagePlanPBPInfo.AddCity.SendKeys(value);
                    break;
                case "state":
                    ManagePlanPBPInfo.AddState.SendKeys(value);
                    break;
                case "zip":
                    ManagePlanPBPInfo.AddZip.SendKeys(value);
                    break;

            }
        }



        [When(@"FRM Admin Manage Plan PBP Info Add ""(.*)"" button is clicked")]
        public void WhenFRMAdminManagePlanPBPInfoAddButtonIsClicked(string p0)
        {
            string fieldname = tmsCommon.GenerateData(p0);

            switch(fieldname.ToLower())
            {
                case "save":
                    fw.ExecuteJavascript(ManagePlanPBPInfo.AddSaveButton);
                    break;

            }
        }


        [When(@"FRM Admin Manage Plan PBP Info Add ""(.*)"" button is clicked and Verify Message ""(.*)""")]
        public void WhenFRMAdminManagePlanPBPInfoAddButtonIsClickedAndVerifyMessage(string p0, string p1)
        {
            fw.ExecuteJavascript(ManagePlanPBPInfo.AddSaveButton);

            By toastMsg = By.XPath("//div[@class='k-notification-content']");
            string actValue = Browser.Wd.FindElement(toastMsg).Text;

            Assert.IsTrue(actValue.Contains(p1), "Expected Message is displayed");
        }




        [Then(@"Verify Manage Plan PBP Info EditAll Screen is closed")]
        public void ThenVerifyManagePlanPBPInfoEditAllScreenIsClosed()
        {
            bool isclosed = true;
            try
            {
                isclosed = ManagePlanPBPInfo.EditAllWindow.Displayed;
            }
            catch
            {
                isclosed = false;

            }

            Assert.IsTrue(isclosed, "Window is not closed");
        }


        [Then(@"Verify Manage Plan PBP Info ""(.*)"" is displyed")]
        public void ThenVerifyManagePlanPBPInfoIsDisplyed(string p0)
        {
            string fieldname = tmsCommon.GenerateData(p0);
            bool ispresent = false;
            try
            {
                switch (fieldname.ToLower())
            {
                case "add button":
                        ispresent = ManagePlanPBPInfo.AddButton.Displayed;
                    break;
                 case "edit all button":
                        ispresent = ManagePlanPBPInfo.EditAll.Displayed;
                        break;
                }
            }
            catch
            {
                ispresent = false;

            }

            Assert.IsTrue(ispresent, "Expected field is not displayed");
        }




        [Then(@"Click on Administration sub-menu ""(.*)""")]
        public void ThenClickOnAdministrationSub_Menu(string p0)
        {
            IWebElement submenu = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]"));
            fw.ExecuteJavascript(submenu);
            
        }



        OpenQA.Selenium.Interactions.Actions Sourcebuilder = new OpenQA.Selenium.Interactions.Actions(Browser.Wd);

        [Then(@"Click on sub-menu ""(.*)"" opens page ""(.*)""")]
        public void ThenClickOnSub_MenuOpensPage(string submenu, string page)
        {

            switch (submenu)
            {

                case "Batch Enroll/Disenroll": { tmsWait.Hard(2); FRMMainNavigation.FRMAdministartormenubatchEnrollDisenroll.Click(); Assert.AreEqual(FRMMainNavigation.PageTitle.Text, page, page + "is displayed when clicks on sub-menu" + submenu); break; }
                case "Batch Update": { tmsWait.Hard(1); FRMMainNavigation.FRMAdministartormenubatchUpdate.Click(); tmsWait.Hard(2); Assert.AreEqual(FRMMainNavigation.PageTitle.Text, page, page + "is displayed when clicks on sub-menu" + submenu); break; }
                case "Change Individual HIC": { FRMMainNavigation.FRMAdministratormenu.Click(); tmsWait.Hard(1); FRMMainNavigation.FRMAdministartormenuchangeindividualHIC.Click(); tmsWait.Hard(2); Assert.AreEqual(FRMMainNavigation.PageTitle.Text, page, page + " is displayed when clicks on sub-menu" + submenu); break; }
                case "Change Plan ID": { Sourcebuilder.ClickAndHold(FRMMainNavigation.FRMAdministratormenu).Build().Perform(); tmsWait.Hard(2); FRMMainNavigation.FRMAdministartormenuchangePlanId.Click(); tmsWait.Hard(2); Assert.AreEqual(FRMMainNavigation.PageTitle.Text, page, page + "is displayed when clicks on sub-menu" + submenu); break; }
                case "Delete Old Discrepancies": { Sourcebuilder.ClickAndHold(FRMMainNavigation.FRMAdministratormenu).Build().Perform(); tmsWait.Hard(2); FRMMainNavigation.FRMAdministartormenudeleteOldDiscrepancies.Click(); Assert.AreEqual(FRMMainNavigation.PageTitle.Text, page, page + "is displayed when clicks on sub-menu" + submenu); break; }
                case "Error Log": { Sourcebuilder.ClickAndHold(FRMMainNavigation.FRMAdministratormenu).Build().Perform(); tmsWait.Hard(2); FRMMainNavigation.FRMAdministartormenuerrorLog.Click(); Assert.AreEqual(FRMMainNavigation.PageTitle.Text, page, page + "is displayed when clicks on sub-menu" + submenu); break; }
                case "Export Monthly Extract": { Sourcebuilder.ClickAndHold(FRMMainNavigation.FRMAdministratormenu).Build().Perform(); tmsWait.Hard(2); FRMMainNavigation.FRMAdministartormenuexportMonthlyExtract.Click(); Assert.AreEqual(FRMMainNavigation.PageTitle.Text, page, page + "is displayed when clicks on sub-menu" + submenu); break; }
                case "Manage Bid Tool Rates": { Sourcebuilder.ClickAndHold(FRMMainNavigation.FRMAdministratormenu).Build().Perform(); tmsWait.Hard(2); FRMMainNavigation.FRMAdministartormenumanageBidToolRates.Click(); Assert.AreEqual(FRMMainNavigation.PageTitle.Text, page, page + "is displayed when clicks on sub-menu" + submenu); break; }
                case "Manage Discrepancy Status Code": { Sourcebuilder.ClickAndHold(FRMMainNavigation.FRMAdministratormenu).Build().Perform(); tmsWait.Hard(2); FRMMainNavigation.FRMAdministartormenumanageDiscrepancyStatusCode.Click(); Assert.AreEqual(FRMMainNavigation.PageTitle.Text, page, page + "is displayed when clicks on sub-menu" + submenu); break; }
                case "Manage Plan Adjustment Reasons": { Sourcebuilder.ClickAndHold(FRMMainNavigation.FRMAdministratormenu).Build().Perform(); tmsWait.Hard(2); FRMMainNavigation.FRMAdministartormenumanagePlanAdjustmentReasons.Click(); Assert.AreEqual(FRMMainNavigation.PageTitle.Text, page, page + "is displayed when clicks on sub-menu" + submenu); break; }
                case "Plan Star Ratings": { Sourcebuilder.ClickAndHold(FRMMainNavigation.FRMAdministratormenu).Build().Perform(); tmsWait.Hard(2); FRMMainNavigation.FRMAdministartormenuplanStarRatings.Click(); Assert.AreEqual(FRMMainNavigation.PageTitle.Text, page, page + "is displayed when clicks on sub-menu" + submenu); break; }
                case "Run Enrollment Check": { Sourcebuilder.ClickAndHold(FRMMainNavigation.FRMAdministratormenu).Build().Perform(); tmsWait.Hard(2); FRMMainNavigation.FRMAdministartormenurunEnrollmentCheck.Click(); Assert.AreEqual(FRMMainNavigation.PageTitle.Text, page, page + "is displayed when clicks on sub-menu" + submenu); break; }
                //case "Workflow Assignment": { Sourcebuilder.ClickAndHold(FRMMainNavigation.FRMAdministratormenu).Build().Perform(); FRMMainNavigation.FRMAdministartormenuworkFlowAssignment.Click(); Assert.AreEqual(FRMMainNavigation.PageTitle.Text, page, page + "is displayed when clicks on sub-menu" + submenu); break; }
                case "Administration - Workflow Assignment": { ((IJavaScriptExecutor)Browser.Wd).ExecuteScript("arguments[0].click();", Browser.Wd.FindElement(By.XPath("//a[@title='Workflow Assignment']"))); tmsWait.Hard(3); Assert.AreEqual(FRMMainNavigation.PageTitle.Text, page, page + "is displayed when clicks on sub-menu" + submenu); break; }
                case "Extracts": { Sourcebuilder.ClickAndHold(FRMMainNavigation.FRMAdministratormenu).Build().Perform(); tmsWait.Hard(2); FRMMainNavigation.FRMAdministartorExtractsmenu.Click(); Assert.AreEqual(FRMMainNavigation.PageTitle.Text, page, page + "is displayed when clicks on sub-menu" + submenu); break; }
                case "MMR Extract": {((IJavaScriptExecutor)Browser.Wd).ExecuteScript("arguments[0].click();", Browser.Wd.FindElement(By.XPath("//a[@title='MMR Extract']"))); tmsWait.Hard(3);Assert.AreEqual(FRMMainNavigation.PageTitle.Text, page, page + "is displayed when clicks on sub-menu" + submenu); break; }
                case "Premium Member Extract": { ((IJavaScriptExecutor)Browser.Wd).ExecuteScript("arguments[0].click();", Browser.Wd.FindElement(By.XPath("//a[@title='Premium Member Extract']"))); tmsWait.Hard(3); Assert.AreEqual(FRMMainNavigation.PageTitle.Text, page, page + "is displayed when clicks on sub-menu" + submenu); break; }
                case "Member Premium Extract": { ((IJavaScriptExecutor)Browser.Wd).ExecuteScript("arguments[0].click();", Browser.Wd.FindElement(By.XPath("//span[contains(.,'Member Premium Extract')]"))); tmsWait.Hard(3); Assert.AreEqual(FRMMainNavigation.PageTitle.Text, page, page + "is displayed when clicks on sub-menu" + submenu); break; }
            }
        }

        [Then(@"Verify ""(.*)"" button is Disabled")]
        public void ThenVerifyButtonIsDisabled(string buttonName)
        {
            //tmsWait.WaitForElement(By.LinkText("Last"), 300);

            if (buttonName.ToLower() == "first")
            { 
                try
                {

                    //string dd = FRMMainGeneralSearch.GeneralSearchFirstButton.GetAttribute("class");
                    Assert.IsTrue(FRMMainGeneralSearch.GeneralSearchFirstButton.GetAttribute("class").Contains("disabled"), "First button is disabled");
                }
                catch (NoSuchElementException ex)
                {
                    fw.ConsoleReport("First button is enabled");
                }
            }
            else if (buttonName.ToLower() == "last")
            {
                    try
                    {
                        Assert.IsTrue(FRMMainGeneralSearch.GeneralSearchLastButton.GetAttribute("class").Contains("disabled"), "Last button is disabled");
                    }
                    catch (NoSuchElementException ex)
                    {
                        fw.ConsoleReport("Last button is enabled");
                    }
            }
        }


        [Then(@"Verify HIC Name Serach page Next and Previous button functionality")]
        public void ThenVerifyHICNameSerachPageNextAndPreviousButtonFunctionality()
        {

            IWebElement prevlink = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the previous page']"));
            bool prev= prevlink.GetAttribute("class").Contains("disabled");
            IWebElement nextlink = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
            bool next = nextlink.GetAttribute("class").Contains("disabled");
            if (!prev)
            {
                if(next)
                {
                    fw.ExecuteJavascript(FRMHICorNameSearch.HICNextLink);
                    next = nextlink.GetAttribute("class").Contains("disabled");
                    Assert.IsFalse(next, " Next link is Enabled");
                }


                
            }

            //Assert.IsFalse(prev, "Next link is not working");

            fw.ExecuteJavascript(FRMHICorNameSearch.HICLastButton);
            
            //bool next = nextlink.GetAttribute("class").Contains("disabled");
            if(!prev)
            {
                fw.ExecuteJavascript(prevlink);
                next = nextlink.GetAttribute("class").Contains("disabled");
            }
            //Assert.IsFalse(next, "Previous link is not working");




            //bool valuePrevBeforeNextClick = IsElementEnable(FRMHICorNameSearch.HICPreviousLink);
            //fw.ExecuteJavascript(FRMHICorNameSearch.HICNextLink);
            //bool valuePrevAfterNextClick = true, valueFirstAfterPrevClick = true;
            //try
            //{
            //    IsElementEnable(FRMHICorNameSearch.HICPreviousLink);
            //}
            //catch (NoSuchElementException)
            //{
            //    valuePrevAfterNextClick = false;
            //}
            //bool expectedNext = (valuePrevBeforeNextClick == valuePrevAfterNextClick) ? false : true;
            //Assert.IsTrue(expectedNext, "User is able to click Next button");
            //bool valueFirstBeforePrevClick = IsElementEnable(FRMHICorNameSearch.HICFirstButton);
            //fw.ExecuteJavascript(FRMHICorNameSearch.HICPreviousLink);
            //try
            //{
            //    IsElementEnable(FRMHICorNameSearch.HICFirstButton);
            //}
            //catch (NoSuchElementException)
            //{ valueFirstAfterPrevClick = false; }
            //bool expectedPrev = (valueFirstBeforePrevClick == valueFirstAfterPrevClick) ? false : true;

            //Assert.IsTrue(expectedPrev,"User is able to click Previous button");
        }

        private static bool IsElementEnable(IWebElement elementToVerify)
        {
            tmsWait.Hard(4);
            return elementToVerify.GetAttribute("class").Contains("disabled");
        }

        [When(@"View hyperlink label icon is clicked")]
        public void WhenViewHyperlinkLabelIconIsClicked()
        {
            FRMHICSearchResult.ViewHyperLink.Click();
        }

        [Then(@"Verify Member Details Page ""(.*)"" is displayed as hyperlink label icon under Payment History section")]
        public void ThenVerifyMemberDetailsPageIsDisplayedAsHyperlinkLabelIconUnderPaymentHistorySection(string lableName)
        {
            Assert.IsTrue(Browser.Wd.FindElement(By.CssSelector(".ui-grid-coluiGrid-08H div.ng-scope")).Text.Contains(lableName), lableName + " is displayed under Payment History Section.");
        }

        [Then(@"""(.*)"" hyperlink label is clicked")]
        public void ThenHyperlinkLabelIsClicked(string p0)
        {
            fw.ExecuteJavascript(FRMHICSearchResult.ReasonCodeLable);
            tmsWait.Hard(2);
        }


        [Then(@"Verify Discrepancy Reason code page is displayed")]
        public void ThenVerifyDiscrepancyReasonCodePageIsDisplayed()
        {
            tmsWait.Hard(16);
            Assert.IsTrue(FRMDiscrepancyReasonCodePage.ReasonCodeLable.Displayed, "Reason Code Lable is displayed.");
            
        }


        [When(@"Invalid search condition ""(.*)"" is entered in search text box")]
        public void WhenInvalidSearchConditionIsEnteredInSearchTextBox(string reasonCode)
        {
            FRMDiscrepancyReasonCodePage.ReasonCodeTextbox.SendKeys(reasonCode);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='reasonSearch-btn-btnSearch']")));
        }

        [Then(@"Verify Discrepancy Reason code page is displayed with Blank Table and Headers only")]
        public void ThenVerifyDiscrepancyReasonCodePageIsDisplayedWithBlankTableAndHeadersOnly()
        {
            bool count = (Browser.Wd.FindElements(By.XPath("//form[@name='newUserForm']//table//tbody//tr")).Count<2);
            // Assert.IsTrue(FRMDiscrepancyReasonCodePage.DefinitionLable.Displayed, "Definition Lable is displayed.");
            //Assert.IsTrue(FRMDiscrepancyReasonCodePage.ReasonCodeLable.Displayed, "Reason Code Lable is displayed.");
            
            Assert.IsTrue(count, "Reason Code Table is Blank");
        }

        [Then(@"Verify Discrepancy Reason code page is displayed text ""(.*)""")]
        public void ThenVerifyDiscrepancyReasonCodePageIsDisplayedText(string p0)
        {
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='reasonCodes-grid-reasonCodesGrid']//td[contains(.,'"+p0+"')]")).Displayed, "Expected text is not displayed");
        }



        [When(@"Click on More option under Payment History section on FRM Main")]
        public void WhenClickOnMoreOptionUnderPaymentHistorySectionOnFRMMain()
        {
            tmsWait.Hard(5);
            //string moreOptionClick = "$('i.fa.fa-ellipsis-h').click();";
            //fw.ExecuteJavascript(moreOptionClick);            
            try
            {
                fw.ExecuteJavascript(FRMDiscrepancyReasonCodePage.moreLink);
            }

            catch
            {
                fw.ExecuteJavascript(FRMDiscrepancyReasonCodePage.PaymentHistoryViewLink);
            }
        }


        [Then(@"Verify popup window with Full Screen size Modal popup of Payment History Details")]
        public void ThenVerifyPopupWindowWithFullScreenSizeModalPopupOfPaymentHistoryDetails()
        {
            Assert.IsTrue(tmsWait.IsElementPresent(By.CssSelector("button[name='btnAddNote']")));
        }


        [When(@"Click on ""(.*)"" menu option")]
        public void WhenClickOnMenuOption(string menuOption)
        {
            Browser.Wd.FindElement(By.XPath(String.Format("//span[contains(.,'{0}') and (@class='popupTextBlock')]", menuOption))).Click();
        }

        [When(@"Verify the work status page")]
        public void WhenVerifyTheWorkStatusPage()
        {
            Assert.IsTrue(FRMDiscrepancyReasonCodePage.AddNoteButton.Displayed, "Add note button is displayed.");
            Assert.IsTrue(FRMDiscrepancyReasonCodePage.EditCheckbox.Displayed, "Edit Checkbos is displayed.");
            Assert.IsTrue(FRMDiscrepancyReasonCodePage.SaveChangesButton.Displayed, "Save Changes button is displayed.");
        }


        [When(@"Selected Edit for ""(.*)"" Discrepancy Reason\(s\)")]
        public void WhenSelectedEditForDiscrepancyReasonS(string discrepancyCode)
        {
            Browser.Wd.FindElement(By.XPath(String.Format("//td[contains(.,'{0}') and (@class='ng-binding')]/preceding-sibling::td/input[@id='workstatus.Id']", discrepancyCode))).Click();
        }


        [When(@"Select ""(.*)"" status from ""(.*)"" drop down list")]
        public void WhenSelectStatusFromDropDownList(string value, string dropdownName)
        {
            if (dropdownName.ToLower() == "select status")
            {
                SelectElement selectStatusDD = new SelectElement(FRMDiscrepancyReasonCodePage.SelectStatusDropdown);
                selectStatusDD.SelectByText(value);
            }
            else if(dropdownName.ToLower()=="select user")
            {
                SelectElement selectStatusDD = new SelectElement(FRMDiscrepancyReasonCodePage.SelectUserDropdown);
                selectStatusDD.SelectByText(value);
            }
        }

        [When(@"Click on ""(.*)"" scope")]
        public void WhenClickOnScope(string p0)
        {
            if (!FRMDiscrepancyReasonCodePage.ApplytoSelectedmonthonlyRadio.Selected)
                FRMDiscrepancyReasonCodePage.ApplytoSelectedmonthonlyRadio.Click();
        }


        [When(@"Payment History page Back to Record button is Clicked")]
        public void WhenPaymentHistoryPageBackToRecordButtonIsClicked()
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@test-id='payMonPartDtls-span-backToRec']")));
        }


        [Then(@"Verify HIC NameSerach Result Page")]
        public void ThenVerifyHICNameSerachResultPage()
        {
            tmsWait.IsElementPresent(By.LinkText("Enroll/Disenroll Member"));
            Assert.IsTrue(Browser.Wd.FindElement(By.LinkText("Enroll/Disenroll Member")).Displayed, "Member Summary table is displayed.");
        }


        [When(@"Selected Level One task ""(.*)""")]
        public void WhenSelectedLevelOneTask(string levelOnetask)
        {
            tmsWait.Hard(2);
            if (levelOnetask.ToLower() == "batch of discrepancies")
            {
                if (!FRMWorkFlowPage.BatchOfDiscrepanciesRadioButton.Selected)
                    fw.ExecuteJavascript(FRMWorkFlowPage.BatchOfDiscrepanciesRadioButton);
            }
            else if(levelOnetask.ToLower() == "batch of members")
            {
                if (!FRMWorkFlowPage.BatchofMembersRadioButton.Selected)
                    fw.ExecuteJavascript(FRMWorkFlowPage.BatchofMembersRadioButton);
            }
        }


        [When(@"Selected Level two task ""(.*)""")]
        public void WhenSelectedLevelTwoTask(string levelTwoTask)
        {
            tmsWait.Hard(2);
            if (levelTwoTask.ToLower() == "assign to specific user")
            {
                if (!FRMWorkFlowPage.AssigntoSpecificUserRadioButton.Selected)
                    fw.ExecuteJavascript(FRMWorkFlowPage.AssigntoSpecificUserRadioButton);
            }
            else if (levelTwoTask.ToLower() == "update status")
            {
                if (!FRMWorkFlowPage.UpdateStatusRadioButton.Selected)
                    fw.ExecuteJavascript(FRMWorkFlowPage.UpdateStatusRadioButton);
            }
            else if(levelTwoTask.ToLower()== "assign to a specified user and update status")
            {
                if (!FRMWorkFlowPage.AssignSpecifiedUserUpdateStatusRadioButton.Selected)
                    fw.ExecuteJavascript(FRMWorkFlowPage.AssignSpecifiedUserUpdateStatusRadioButton);
            }
            else if (levelTwoTask == "Discrepancy to Specific User")
            {
                tmsWait.Hard(1);

                fw.ExecuteJavascript(FRMWorkFlowPage.DiscrepancytoSpecificUser);
            }
            else if (levelTwoTask == "Discrepancy Status")
            {
                tmsWait.Hard(1);

                fw.ExecuteJavascript(FRMWorkFlowPage.DiscrepancyStatusNew);
            }
            else if (levelTwoTask == "Update Discrepancy Status and assign to Specific User")
            {
                tmsWait.Hard(1);

                fw.ExecuteJavascript(FRMWorkFlowPage.UpdateDiscrepancyStatusandassigntoSpecificUser);
            }



        }

        [When(@"Selected Discrepancy Type as ""(.*)"" from dropdown list")]
        public void WhenSelectedDiscrepancyTypeAsFromDropdownList(string discrepancyTypeValue)
        {
            IWebElement discrepancyType = Browser.Wd.FindElement(By.XPath("//*[@id='workflowDiscrepancyTypeSelectID']//tr[8]/td"));
            fw.ExecuteJavascript(discrepancyType);
            tmsWait.Hard(2);

        }
        [When(@"Selected Plan ID as ""(.*)"" from dropdown list")]
    
        [When(@"Selected Plan ID from dropdown list")]
        public void WhenSelectedPlanIDAsFromDropdownList()
        {
            SelectElement planID = new SelectElement(FRMWorkFlowPage.PlanIDDropdown);
                planID.SelectByIndex(0);
            
        }

        [When(@"Selected PBP as ""(.*)"" from dropdown list")]
        public void WhenSelectedPBPAsFromDropdownList(string pbpbValue)
        {
            SelectElement pbp = new SelectElement(FRMWorkFlowPage.PBPDropdown);
            pbp.SelectByText(pbpbValue);
        }

        [When(@"Selected Payment Months as ""(.*)"" from dropdown list")]
        public void WhenSelectedPaymentMonthsAsFromDropdownList(string paymentMonthsValue)
        {
            SelectElement paymentMonths = new SelectElement(FRMWorkFlowPage.PaymentMonthsDropdown);
            paymentMonths.SelectByText(paymentMonthsValue);
        }

        [When(@"Selected Age of Discrepancy as ""(.*)"" from dropdown list")]
        public void WhenSelectedAgeOfDiscrepancyAsFromDropdownList(string ageValue)
        {
            SelectElement ageOfDiscrepancy = new SelectElement(FRMWorkFlowPage.AgeofDiscrepancyDropdown);
            ageOfDiscrepancy.SelectByText(ageValue);
        }

        [When(@"Selected Status as ""(.*)"" from dropdown list")]
        public void WhenSelectedStatusAsFromDropdownList(string statusValue)
        {
            SelectElement status = new SelectElement(FRMWorkFlowPage.StatusDropdown);
            status.SelectByText(statusValue);
        }

        [When(@"Selected Discrepancy Status as ""(.*)"" from dropdown list")]
        public void WhenSelectedDiscrepancyStatusAsFromDropdownList(string p0)
        {
            SelectElement DIS = new SelectElement(FRMWorkFlowPage.StatusDropdownNew);
            DIS.SelectByText(p0);
        }

        [When(@"Selected FRM User as ""(.*)"" from dropdown list")]
        public void WhenSelectedFRMUserAsFromDropdownList(string frmUserValue)
        {
            SelectElement frmUser = new SelectElement(FRMWorkFlowPage.FRMUserDropdown);
            frmUser.SelectByText(frmUserValue);
        }

        [When(@"Click on Save button")]
        public void WhenClickOnSaveButton()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(FRMWorkFlowPage.SaveButton);
        }

        [Then(@"Verify Administration save the values of dropdown before Potential Items plus successfully")]
        public void ThenVerifyAdministrationSaveTheValuesOfDropdownBeforePotentialItemsPlusSuccessfully()
        {
            tmsWait.Hard(10);
            string successMessage= FRMWorkFlowPage.SuccessMessageOnWorkflow.Text;
            Assert.IsTrue(successMessage.Contains("Success"), "Admin can save values before Potential item plus successfully");
        }

        [Then(@"Click on Reset button")]
        public void ThenClickOnResetButton()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(FRMWorkFlowPage.ResetButton);
         
        }

        [Then(@"Verify Administration reset the values of dropdown")]
        public void ThenVerifyAdministrationResetTheValuesOfDropdown()
        {
            tmsWait.Hard(2);

            IWebElement ddlUser = Browser.Wd.FindElement(By.XPath("//label[contains(.,'FRM User')]/parent::div//span[@class='k-select']"));
            string userValue = ddlUser.Text;
            Assert.IsTrue(userValue.Contains("Select..."), "Value does not match");

            IWebElement ddlStatus = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Status')]/parent::div//span[@class='k-select']"));
            string statusValue = ddlStatus.Text;
            Assert.IsTrue(statusValue.Contains("ALL"), "Value does not match");

            IWebElement ddlAgeOfDiscrepancy = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Age of Discrepancy')]/parent::div//span[@class='k-select']"));
            string statusAgeOfDiscrepancy = ddlAgeOfDiscrepancy.Text;
            Assert.IsTrue(statusAgeOfDiscrepancy.Contains("ALL"), "Value does not match");

            IWebElement ddlPaymentMonth = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Payment Month - From')]/parent::div//span[@class='k-select']"));
            string statusPaymentMonth = ddlPaymentMonth.Text;
            Assert.IsTrue(statusPaymentMonth.Contains("ALL"), "Value does not match");

            IWebElement ddlPBP = Browser.Wd.FindElement(By.XPath("//label[contains(.,'PBP')]/parent::div//span[@class='k-select']"));
            string statusddlPBP = ddlPBP.Text;
            Assert.IsTrue(statusddlPBP.Contains("ALL"), "Value does not match");


            //SelectElement frmUser = new SelectElement(FRMWorkFlowPage.FRMUserDropdown);
            // SelectElement status = new SelectElement(FRMWorkFlowPage.StatusDropdown);
            // SelectElement ageOfDiscrepancy = new SelectElement(FRMWorkFlowPage.AgeofDiscrepancyDropdown);
            // SelectElement paymentMonths = new SelectElement(FRMWorkFlowPage.PaymentMonthsDropdown);
            // SelectElement pbp = new SelectElement(FRMWorkFlowPage.PBPDropdown);
            // SelectElement planID = new SelectElement(FRMWorkFlowPage.PlanIDDropdown);
            // SelectElement discrepancyType = new SelectElement(FRMWorkFlowPage.DiscrepancyTypeDropdown);
            //Assert.IsTrue(discrepancyType.SelectedOption.Text.Contains("Date of Birth Mismatch - Part C"), "Discrepancy Type has default value.");
            // Assert.IsTrue(pbp.SelectedOption.Text.Equals("ALL"), "PBP has default value.");
            // Assert.IsTrue(paymentMonths.SelectedOption.Text.Equals("ALL"), "Payment months has default value.");
            // Assert.IsTrue(ageOfDiscrepancy.SelectedOption.Text.Equals("ALL"), "Age of Discrepancy has default value.");
            // Assert.IsTrue(status.SelectedOption.Text.Equals("ALL"), "Status of Discrepancy has default value.");
            // Assert.IsTrue(frmUser.SelectedOption.Text.Contains("Select..."), "FRM User has default value.");
        }

        [Then(@"Verify Administration reset the values of dropdown for Batch of Discrepancies page")]
        public void ThenVerifyAdministrationResetTheValuesOfDropdownForBatchOfDiscrepanciesPage()
        {
            tmsWait.Hard(2);
            SelectElement frmUser = new SelectElement(FRMWorkFlowPage.FRMUserDropdown);
            SelectElement status = new SelectElement(FRMWorkFlowPage.StatusDropdown);
            SelectElement ageOfDiscrepancy = new SelectElement(FRMWorkFlowPage.AgeofDiscrepancyDropdown);
            SelectElement paymentMonths = new SelectElement(FRMWorkFlowPage.PaymentMonthsDropdown);
            SelectElement pbp = new SelectElement(FRMWorkFlowPage.PBPDropdown);
            SelectElement planID = new SelectElement(FRMWorkFlowPage.PlanIDDropdown);
            SelectElement discrepancyType = new SelectElement(FRMWorkFlowPage.DiscrepancyTypeDropdown);
            Assert.IsTrue(discrepancyType.SelectedOption.Text.Contains("Basic Prem Mismatch - Part D"), "Discrepancy Type has default value.");
            Assert.IsTrue(pbp.SelectedOption.Text.Equals("ALL"), "PBP has default value.");
            Assert.IsTrue(paymentMonths.SelectedOption.Text.Equals("ALL"), "Payment months has default value.");
            Assert.IsTrue(ageOfDiscrepancy.SelectedOption.Text.Equals("ALL"), "Age of Discrepancy has default value.");
            Assert.IsTrue(status.SelectedOption.Text.Equals("ALL"), "Status of Discrepancy has default value.");
            Assert.IsTrue(frmUser.SelectedOption.Text.Contains("Select..."), "FRM User has default value.");
        }

        [Then(@"Verify Administration reset the values of dropdown for ""(.*)""")]
        public void ThenVerifyAdministrationResetTheValuesOfDropdownFor(string p0)
        {
           

        tmsWait.Hard(2);
            SelectElement frmUser = new SelectElement(FRMWorkFlowPage.FRMUserDropdown);
            SelectElement status = new SelectElement(FRMWorkFlowPage.StatusDropdown);
           // SelectElement ageOfDiscrepancy = new SelectElement(FRMWorkFlowPage.AgeofDiscrepancyDropdown);
            SelectElement paymentMonths = new SelectElement(FRMWorkFlowPage.PaymentMonthsDropdown);
            SelectElement pbp = new SelectElement(FRMWorkFlowPage.PBPDropdown);
            SelectElement planID = new SelectElement(FRMWorkFlowPage.PlanIDDropdown);
          //  SelectElement discrepancyType = new SelectElement(FRMWorkFlowPage.DiscrepancyTypeDropdown);
           // Assert.IsTrue(discrepancyType.SelectedOption.Text.Contains("Date of Birth Mismatch - Part C"), "Discrepancy Type has default value.");
            Assert.IsTrue(pbp.SelectedOption.Text.Equals("ALL"), "PBP has default value.");
            Assert.IsTrue(paymentMonths.SelectedOption.Text.Equals("ALL"), "Payment months has default value.");
          //  Assert.IsTrue(ageOfDiscrepancy.SelectedOption.Text.Equals("ALL"), "Age of Discrepancy has default value.");
            Assert.IsTrue(status.SelectedOption.Text.Equals("ALL"), "Status of Discrepancy has default value.");
            Assert.IsTrue(frmUser.SelectedOption.Text.Contains("Select..."), "FRM User has default value.");
        }
        [When(@"Admin Delete Discrepancies Over (.*) months oage Payment Months Range From Date as ""(.*)"" from drop down list")]
        public void WhenAdminDeleteDiscrepanciesOverMonthsOagePaymentMonthsRangeFromDateAsFromDropDownList(int p0, string p1)
        {
            IWebElement drp = Browser.Wd.FindElement(By.CssSelector("[test-id='delOldDiscr-select-discrepanciesFromId']"));
            new SelectElement(drp).SelectByText(p1);
        }

        [When(@"Selected Payment Months Range From Date as ""(.*)"" from drop down list")]
        public void WhenSelectedPaymentMonthsRangeFromDateAsFromDropDownList(string fromDate)
        {
            By Drp = By.XPath("//label[contains(.,'Payment Month Range')]/parent::div//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + fromDate + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
        }

        [When(@"Selected Payment Months Range To Date as ""(.*)"" from drop down list")]
        public void WhenSelectedPaymentMonthsRangeToDateAsFromDropDownList(string toDate)
        {
            By Drp = By.XPath("(//*[@test-id='delOldDiscr-select-discrepanciesToId']//span[@class='k-select'])[2]");
            By typeapp = By.XPath("//li[text()='" + toDate + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
        }

        [When(@"Selected Discrepancy Type as ""(.*)"" from drop down list")]
        public void WhenSelectedDiscrepancyTypeAsFromDropDownList(string discrepancyTypeValue)
        {
            By Drp = By.XPath("//label[contains(.,'Discrepancy Type')]/parent::div//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + discrepancyTypeValue + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
        }

        [When(@"Selected Plan ID as ""(.*)"" from drop down list")]
        public void WhenSelectedPlanIDAsFromDropDownList(string discrepancyPlanValue)
        {
            By Drp = By.XPath("//label[contains(.,'Plan ID')]/parent::div//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + discrepancyPlanValue + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
        }

        [When(@"Click on Delete Button")]
        public void WhenClickOnDeleteButton()
        {
            fw.ExecuteJavascript(FRMDeleteDiscrepancyPage.DiscrepancyPlanDeleteButton);
            tmsWait.Hard(5);
            //tmsWait.WaitForAlertPresent(20);
            IWebElement deletePop = Browser.Wd.FindElement(By.CssSelector("[test-id='confirmationDialog-btn-Yes']"));
            fw.ExecuteJavascript(deletePop);
            tmsWait.Hard(2);
        }



        [Then(@"Verify the admin Deleted Discrepancies successfully")]
        public void ThenVerifyTheAdminDeletedDiscrepanciesSuccessfully()
        {
            string deleteSuccessMessage= fw.GetElementText(By.CssSelector("[test-id='delOldDiscr-lbl-successfully']"));
            Assert.IsTrue(deleteSuccessMessage.Contains("Successfully deleted"), "Successfully deleted records message is not getting displayed.");
        }

        [When(@"Click on Reset Button")]
        public void WhenClickOnResetButton()
        {
            fw.ExecuteJavascript(FRMDeleteDiscrepancyPage.DiscrepancyPlanResetButton);
        }

        [Then(@"Verify the Reset option is reset selection criteria")]
        public void ThenVerifyTheResetOptionIsResetSelectionCriteria()
        {
            SelectElement planID = new SelectElement(FRMWorkFlowPage.PlanIDDropdown);
            SelectElement paymentFromDate = new SelectElement(FRMDeleteDiscrepancyPage.PaymentDateFromDropdown);
            SelectElement paymentToDate = new SelectElement(FRMDeleteDiscrepancyPage.PaymentDateToDropdown);
            SelectElement discrepancyTypeOnDescripency = new SelectElement(FRMDeleteDiscrepancyPage.DiscrepancyTypeDropdown);
            SelectElement discrepancyPlan = new SelectElement(FRMDeleteDiscrepancyPage.DiscrepancyPlanDropdown);
            Assert.IsTrue(paymentFromDate.SelectedOption.Text.Equals("From"), "Payment From Date has default value.");
            Assert.IsTrue(paymentToDate.SelectedOption.Text.Equals("To"), "Payment To Date has default value.");
            Assert.IsTrue(discrepancyTypeOnDescripency.SelectedOption.Text.Equals("All Types"), "Discrepancy Type has default value.");
            Assert.IsTrue(planID.SelectedOption.Text.Equals("H0018"), "Plan ID has default value.");
        }

        [When(@"Click on Reset button for Change Individual HIC")]
        public void WhenClickOnResetButtonForChangeIndividualHIC()
        {
            tmsWait.Hard(5);
            FRMChangeIndividualHIC.ResetButton.Click();
        }

        [Then(@"Verify Reset option is reset the values of New HIC Number and Existing HIC Number and Reason")]
        public void ThenVerifyResetOptionIsResetTheValuesOfNewHICNumberAndExistingHICNumberAndReason()
        {
            SelectElement reasonForHIC = new SelectElement(FRMAdministrator.ReasonDropdown);
            Assert.IsTrue(FRMAdministrator.ExistingNumberHicID.Text.Equals(""), "Existing HIC Number field has default value.");
            Assert.IsTrue(FRMAdministrator.NewNumberHicID.Text.Equals(""), "New HIC Number field has default value.");
            Assert.IsTrue(reasonForHIC.SelectedOption.Text.Contains("Select"), "Reason drop down has default value.");
        }

        [When(@"""(.*)"" hyperlink is clicked")]
        public void WhenHyperlinkIsClicked(string linkName)
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.LinkText(linkName)));
        }

        [Then(@"Verify Enroll/Disenroll Member page")]
        public void ThenVerifyEnrollDisenrollMemberPage()
        {
           //Assert.
        }

        [When(@"Verify ""(.*)"" Database under Triangle logo is ""(.*)""")]
        public void WhenVerifyDatabaseUnderTriangleLogoIs(string db, string status)
        {
            string myDatabase = string.Empty;
            IWebElement TZLogo = Browser.Wd.FindElement(By.Id("Navigation1_ProductMenu1_Menu1-menuItem000"));
            TZLogo.Click();
            if (db.ToLower().Equals("frm"))
                myDatabase = "FRM|" + ConfigFile.FRMdb;
            else if (db.ToLower().Equals("eam"))
                myDatabase = "EAM|" + ConfigFile.EAMdb;
            IList<IWebElement> classList = Browser.Wd.FindElements(By.ClassName("skmSubMenu"));
            Boolean bFoundDBInList = false;
            for (int k = 0; k < classList.Count; k++)
            {
                if (classList[k].Text == myDatabase)
                {
                    bFoundDBInList = true;
                    classList[k].Click();
                    break;
                }
            }
            if (!bFoundDBInList)
            {
                if (status.ToLower().Equals("not displayed"))
                    Assert.IsFalse(bFoundDBInList,  myDatabase + " able to find it in the DB list");
                else
                    Assert.IsTrue(bFoundDBInList, myDatabase + " unable to find it in the DB list");
            }
        }



        [Given(@"Verify FRM title on Home page")]
        [When(@"Verify FRM title on Home page")]
        public void GivenVerifyFRMTitleOnHomePage()
        {
            tmsWait.Hard(10);
            Assert.IsTrue(FRM.FRMMainPage.FRMHeader.Text.Contains("Financial Reconciliation Manager"), "FRM title is not matching");
        }


    }
}
