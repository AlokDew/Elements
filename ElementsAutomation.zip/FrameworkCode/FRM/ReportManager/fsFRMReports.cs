﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using TechTalk.SpecFlow;
using TMSoR1.FrameworkCode;

namespace TMSoR1
{
    [Binding]
    class fsFRMReports
    {


        [Then(@"Verify Manage Bid Tool Rates page ""(.*)"" tab ""(.*)"" is displayed")]
        public void ThenVerifyManageBidToolRatesPageTabIsDisplayed(string p0, string p1)
        {

            string section = tmsCommon.GenerateData(p0);
            string field = tmsCommon.GenerateData(p1);



            switch (field)
            {
                case "Year dropdown":
                    if (section.ToString().Equals("PartC Bid Rates"))
                    {
                        AngularFunction.elementPresenceUsingWebElement(cfAngularManageBidToolRates.ManageBidToolRates.PartCBidRatesYearDropdown);
                    }
                    else if (p0.ToString().Equals("Part C Member Premium"))
                    {
                        AngularFunction.elementPresenceUsingWebElement(cfAngularManageBidToolRates.ManageBidToolRates.PartCMemberPremiumYearDropdown);
                    }
                    else if (p0.ToString().Equals("Part D Bid Rates"))
                    {
                        AngularFunction.elementPresenceUsingWebElement(cfAngularManageBidToolRates.ManageBidToolRates.PartDBidRatesYearDropdown);
                    }
                    break;
                case "PlanID dropdown":
                    if (section.ToString().Equals("PartC Bid Rates"))
                    {
                        AngularFunction.elementPresenceUsingWebElement(cfAngularManageBidToolRates.ManageBidToolRates.PartCBidRatesPlanIDDropdown);
                    }
                    else if (p0.ToString().Equals("Part C Member Premium"))
                    {
                        AngularFunction.elementPresenceUsingWebElement(cfAngularManageBidToolRates.ManageBidToolRates.PartCMemberPremiumPlanIDDropdown);
                    }
                    else if (p0.ToString().Equals("Part D Bid Rates"))
                    {
                        AngularFunction.elementPresenceUsingWebElement(cfAngularManageBidToolRates.ManageBidToolRates.PartDBidRatesPlanIDDropdown);
                    }
                    break;
                case "PBP dropdown":
                    if (section.ToString().Equals("PartC Bid Rates"))
                    {
                        AngularFunction.elementPresenceUsingWebElement(cfAngularManageBidToolRates.ManageBidToolRates.PartCBidRatesPBPDropdown);
                    }
                    else if (p0.ToString().Equals("Part C Member Premium"))
                    {
                        AngularFunction.elementPresenceUsingWebElement(cfAngularManageBidToolRates.ManageBidToolRates.PartCMemberPremiumPBPDropdown);
                    }
                    else if (p0.ToString().Equals("Part D Bid Rates"))
                    {
                        AngularFunction.elementPresenceUsingWebElement(cfAngularManageBidToolRates.ManageBidToolRates.PartDBidRatesPBPDropdown);
                    }
                    break;
                case "Reset button":
                    if (section.ToString().Equals("PartC Bid Rates"))
                    {
                        AngularFunction.elementPresenceUsingWebElement(cfAngularManageBidToolRates.ManageBidToolRates.PartCBidRatesRESETBtn);
                    }
                    else if (p0.ToString().Equals("Part C Member Premium"))
                    {
                        AngularFunction.elementPresenceUsingWebElement(cfAngularManageBidToolRates.ManageBidToolRates.PartCMemberPremiumRESETBtn);
                    }
                    else if (p0.ToString().Equals("Part D Bid Rates"))
                    {
                        AngularFunction.elementPresenceUsingWebElement(cfAngularManageBidToolRates.ManageBidToolRates.PartDBidRatesRESETBtn);
                    }
                    break;
                case "Go button":
                    fw.ConsoleReport(" Go button is is removed from 5.8 R2 onwards");
                    break;
                case "ADD button":
                    if (section.ToString().Equals("PartC Bid Rates"))
                    {
                        AngularFunction.elementPresenceUsingWebElement(cfAngularManageBidToolRates.ManageBidToolRates.PartCBidRatesADDBtn);
                    }
                    else if (p0.ToString().Equals("Part C Member Premium"))
                    {
                        AngularFunction.elementPresenceUsingWebElement(cfAngularManageBidToolRates.ManageBidToolRates.PartCMemberPremiumADDBtn);
                    }
                    else if (p0.ToString().Equals("Part D Bid Rates"))
                    {
                        AngularFunction.elementPresenceUsingWebElement(cfAngularManageBidToolRates.ManageBidToolRates.PartDBidRatesADDBtn);
                    }

                    break;
                case "EDIT button":

                    if (section.ToString().Equals("PartC Bid Rates"))
                    {
                        AngularFunction.elementPresenceUsingWebElement(cfAngularManageBidToolRates.ManageBidToolRates.PartCBidRatesEDITBtn);
                    }
                    else if (p0.ToString().Equals("Part C Member Premium"))
                    {
                        AngularFunction.elementPresenceUsingWebElement(cfAngularManageBidToolRates.ManageBidToolRates.PartCMemberPremiumsEDITBtn);
                    }
                    else if (p0.ToString().Equals("Part D Bid Rates"))
                    {
                        AngularFunction.elementPresenceUsingWebElement(cfAngularManageBidToolRates.ManageBidToolRates.PartDBidRatesEDITBtn);
                    }
                    break;
                case "DELETE button":
                    if (section.ToString().Equals("PartC Bid Rates"))
                    {
                        AngularFunction.elementPresenceUsingWebElement(cfAngularManageBidToolRates.ManageBidToolRates.PartCBidRatesREMOVEBtn);
                    }
                    else if (p0.ToString().Equals("Part C Member Premium"))
                    {
                        AngularFunction.elementPresenceUsingWebElement(cfAngularManageBidToolRates.ManageBidToolRates.PartCMemberPremiumREMOVEBtn);
                    }
                    else if (p0.ToString().Equals("Part D Bid Rates"))
                    {
                        AngularFunction.elementPresenceUsingWebElement(cfAngularManageBidToolRates.ManageBidToolRates.PartDBidRatesREMOVEBtn);

                    }
                    break;

            }







        }

        public void verifyComponentDisplay(string t, string f,string p1)
        {
            string comp = "//" + t + "//" + f + "";
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath(comp)).Displayed,p1+"is not displayed");
        }


        public void verifyElementDisplay(string t,string f,string v)
        {
            tmsWait.Hard(5);
            string temp = "//" + t + "//span[@e-name='" + f + "']";
            Assert.AreEqual(v, Browser.Wd.FindElement(By.XPath(temp)).Text, v + " is not gettting displayed");
        }

        public void verifyPartDBidRatesEntry(string t, string name, string inputValue)
        {
            tmsWait.Hard(5);
            string value = tmsCommon.GenerateData(inputValue);


            if (name.Contains("planId"))
            {
                AngularFunction.getActualTextAndcompareExpectedValue(cfAngularManageBidToolRates.PartDBidRatesGrid.PlanID, value);
            }
            else if (name.Contains("pbp"))
            {
                AngularFunction.getActualTextAndcompareExpectedValue(cfAngularManageBidToolRates.PartDBidRatesGrid.PBP, value);
            }
            else if (name.Contains("drugBidType"))
            {
                AngularFunction.getActualTextAndcompareExpectedValue(cfAngularManageBidToolRates.PartDBidRatesGrid.DrugBidType, value);
            }
            else if (name.Contains("bidAmount"))
            {
                AngularFunction.getActualTextAndcompareExpectedValue(cfAngularManageBidToolRates.PartDBidRatesGrid.BidAmountat, value);
            }
            else if (name.Contains("fedReInsurance"))
            {
                AngularFunction.getActualTextAndcompareExpectedValue(cfAngularManageBidToolRates.PartDBidRatesGrid.ReinsuranceatPlanRisk, value);
            }
            else if (name.Contains("lisc"))
            {
                AngularFunction.getActualTextAndcompareExpectedValue(cfAngularManageBidToolRates.PartDBidRatesGrid.LICSatPlanRisk, value);
            }
            else if (name.Contains("basicPremium"))
            {
                AngularFunction.getActualTextAndcompareExpectedValue(cfAngularManageBidToolRates.PartDBidRatesGrid.Non_RoundedBasicPremium, value);
            }

            else if (name.Contains("supplPremium"))
            {
                AngularFunction.getActualTextAndcompareExpectedValue(cfAngularManageBidToolRates.PartDBidRatesGrid.Non_RoundedSupplPremium, value);
            }
            else if (name.Contains("coverageGapDiscount"))
            {
                AngularFunction.getActualTextAndcompareExpectedValue(cfAngularManageBidToolRates.PartDBidRatesGrid.CoverageGapDiscountAmount, value);
            }


            else if (name.Contains("effectiveDate"))
            {
                By loc = By.XPath("//label[contains(.,'Effective Date')]/parent::div/div[contains(.,'"+value+"')]");
                UIMODUtilFunctions.elementPresenceUsingLocators(loc);

                
            }
            else if (name.Contains("expiryDate"))
            {
                By loc = By.XPath("//label[contains(.,'Expiry Date')]/parent::div/div[contains(.,'"+value+"')]");
                UIMODUtilFunctions.elementPresenceUsingLocators(loc);
                
                
            }
        }

        public void verifyPartCMemberPremiumEntry(string t, string name, string inputValue)
        {
            tmsWait.Hard(5);
            string value = tmsCommon.GenerateData(inputValue);


            if (name.Contains("planId"))
            {
                AngularFunction.getActualTextAndcompareExpectedValue(cfAngularManageBidToolRates.PartCMemberPremiumGrid.PlanID, value);
            }
            else if (name.Contains("pbp"))
            {
                AngularFunction.getActualTextAndcompareExpectedValue(cfAngularManageBidToolRates.PartCMemberPremiumGrid.PBP, value);
            }
            else if (name.Contains("segmentId"))
            {
                AngularFunction.getActualTextAndcompareExpectedValue(cfAngularManageBidToolRates.PartCMemberPremiumGrid.SegmentID, value);
            }
            else if (name.Contains("rebatePartDSupplBuyDown"))
            {
                AngularFunction.getActualTextAndcompareExpectedValue(cfAngularManageBidToolRates.PartCMemberPremiumGrid.DBuyDownSupply, value);
            }
            else if (name.Contains("rebateABSuppl"))
            {
                AngularFunction.getActualTextAndcompareExpectedValue(cfAngularManageBidToolRates.PartCMemberPremiumGrid.ABMandSuppl, value);
            }
            else if (name.Contains("rebatePartBBuyDown"))
            {
                AngularFunction.getActualTextAndcompareExpectedValue(cfAngularManageBidToolRates.PartCMemberPremiumGrid.PartBBuyDown, value);
            }
            else if (name.Contains("rebatePartDBuyDown"))
            {
                AngularFunction.getActualTextAndcompareExpectedValue(cfAngularManageBidToolRates.PartCMemberPremiumGrid.PartDBuyDown, value);
            }
            else if (name.Contains("rebateABCostShare"))
            {
                AngularFunction.getActualTextAndcompareExpectedValue(cfAngularManageBidToolRates.PartCMemberPremiumGrid.ReduceABCostShare, value);
            }

            else if (name.Contains("effectiveDate"))
            {
                By loc = By.XPath("//label[contains(.,'Effective Date')]/parent::div/div[contains(.,'" + value + "')]");
                UIMODUtilFunctions.elementPresenceUsingLocators(loc);

               
            }
            else if (name.Contains("expiryDate"))
            {
                By loc = By.XPath("//label[contains(.,'Expiry Date')]/parent::div/div[contains(.,'" + value + "')]");
                UIMODUtilFunctions.elementPresenceUsingLocators(loc);
              
            }

        }
        public void verifyPartCBidRatesEntry(string t, string name, string inputValue)
        {
            tmsWait.Hard(5);
            string value = tmsCommon.GenerateData(inputValue);


            if (name.Contains("planId"))
            {
                AngularFunction.getActualTextAndcompareExpectedValue(cfAngularManageBidToolRates.PartCBidRatesGrid.PlanID, value);
            }
            else if (name.Contains("pbp"))
            {
                AngularFunction.getActualTextAndcompareExpectedValue(cfAngularManageBidToolRates.PartCBidRatesGrid.PBP, value);
            }
            else if (name.Contains("segmentId"))
            {
                AngularFunction.getActualTextAndcompareExpectedValue(cfAngularManageBidToolRates.PartCBidRatesGrid.SegmentID, value);
            }

            else if (name.Contains("scc"))
            {
                AngularFunction.getActualTextAndcompareExpectedValue(cfAngularManageBidToolRates.PartCBidRatesGrid.SCC, value);
            }
            else if (name.Contains("demoAgedPartA"))
            {
                AngularFunction.getActualTextAndcompareExpectedValue(cfAngularManageBidToolRates.PartCBidRatesGrid.AgedPartA, value);
            }
            else if (name.Contains("demoAgedPartB"))
            {
                AngularFunction.getActualTextAndcompareExpectedValue(cfAngularManageBidToolRates.PartCBidRatesGrid.AgedPartB, value);
            }

            else if (name.Contains("demoDisabledPartA"))
            {
                AngularFunction.getActualTextAndcompareExpectedValue(cfAngularManageBidToolRates.PartCBidRatesGrid.DisabledPartA, value);
            }
            else if (name.Contains("demoDisabledPartB"))
            {
                AngularFunction.getActualTextAndcompareExpectedValue(cfAngularManageBidToolRates.PartCBidRatesGrid.DisabledPartB, value);
            }
            else if (name.Contains("riskPartA"))
            {
                AngularFunction.getActualTextAndcompareExpectedValue(cfAngularManageBidToolRates.PartCBidRatesGrid.PartA, value);
            }
            else if (name.Contains("riskPartB"))
            {
                AngularFunction.getActualTextAndcompareExpectedValue(cfAngularManageBidToolRates.PartCBidRatesGrid.PartB, value);
            }

            else if (name.Contains("effectiveDate"))
            {
                By loc = By.XPath("//label[contains(.,'Effective Date')]/parent::div/div[contains(.,'"+ value + "')]");
                UIMODUtilFunctions.elementPresenceUsingLocators(loc);

            }
            else if (name.Contains("expiryDate"))
            {
                By loc = By.XPath("//label[contains(.,'Expiry Date')]/parent::div/div[contains(.,'" + value + "')]");
                UIMODUtilFunctions.elementPresenceUsingLocators(loc);
                
            }
        }

        [Then(@"Verify Manage Bid Tool Rates ""(.*)"" Tab ""(.*)"" field value is displayed as ""(.*)""")]
        public void ThenVerifyManageBidToolRatesTabFieldValueIsDisplayedAs(string p0, string field, string value)
        {
            string tab = null;
            value = tmsCommon.GenerateData(value);
            if (p0.ToString().Equals("PartC Bid Rates"))
            {

                verifyPartCBidRatesEntry(tab, field, value);
            }
            else if (p0.ToString().Equals("Part C Member Premium"))
            {

                verifyPartCMemberPremiumEntry(tab, field, value);
            }
            else if (p0.ToString().Equals("Part D Bid Rates"))
            {
                verifyPartDBidRatesEntry(tab, field, value);
            }

        }




        [When(@"Delete POP UP ""(.*)"" button is Clicked")]
        public void WhenDeletePOPUPButtonIsClicked(string p0)
        {
            try
            {
                if (p0.ToString().Equals("OK"))
                {

                    AngularFunction.clickOnYESonConfirmationDialog();
                    tmsWait.Hard(3);
                }
            }
            catch
            {
                fw.ConsoleReport(" there is no POP up");
            }
        }


        [Then(@"Verify Manage Bid Tool Rates ""(.*)"" Tab displayed message ""(.*)""")]
        public void ThenVerifyManageBidToolRatesTabDisplayedMessage(string p0, string p1)
        {
            // Commenting this statement as it is creating trouble due to slow display
            //bool result = Browser.Wd.FindElement(By.XPath("//span[contains(.,'"+p1+"')]")).Displayed;
            //Assert.IsTrue(result, "Expected message is not displayed");
            //tmsWait.Hard(4);
        }

        [When(@"FRM ""(.*)"" section Report List ""(.*)"" is Clicked")]
        public void WhenFRMSectionReportListIsClicked(string p0, string p1)
        {
            tmsWait.Hard(10);
            IWebElement section = Browser.Wd.FindElement(By.CssSelector("a[title='"+p0+"']"));            
            fw.ExecuteJavascript(section);
            tmsWait.Hard(10);
            IWebElement Report = Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + p1 + "')]"));
            fw.ExecuteJavascript(Report);
            tmsWait.Hard(10);

        }

        [Then(@"Verify Discrepancy Type - Flag Part D - By PlanID drop down list value is set to ""(.*)""")]
        public void ThenVerifyDiscrepancyType_FlagPartD_ByPlanIDDropDownListValueIsSetTo(string exp)
        {
            SelectElement drp = new SelectElement(Browser.Wd.FindElement(By.CssSelector("[test-id='ReasonCode']")));
            string act = drp.SelectedOption.Text;
            Assert.AreEqual(exp, act, "Both values are not matching");

        }


        [When(@"Report page Discrepancy Type Multi drop down list ""(.*)"" are selected")]
        public void WhenReportPageDiscrepancyTypeMultiDropDownListAreSelected(string p0)
        {
            IWebElement report = Browser.Wd.FindElement(By.XPath("//ul[@class='dropdown-menu']//a[contains(.,'All')]"));
            IWebElement selection = null;
            fw.ExecuteJavascript(report);

            //label[contains(.,'CMS 45 Day Compliance Report - Plan vs CMS - By Discrepancy Type')]
            string[] reportlist = p0.ToString().Split(',');

            foreach(string temp in reportlist)
            {
                selection = Browser.Wd.FindElement(By.XPath("//ul[@class='dropdown-menu']//a[contains(.,'"+temp+"')]"));
                fw.ExecuteJavascript(selection);
            }
            
        }

        [Then(@"Verify Discrepancy Type displays ""(.*)""")]
        public void ThenVerifyDiscrepancyTypeDisplays(string exp)
        {
            //IWebElement report = Browser.Wd.FindElement(By.XPath("//button[@title='"+ exp + "']"));
            //fw.ExecuteJavascript(report);
            tmsWait.Hard(3);
            string act = Browser.Wd.FindElement(By.XPath("//button[@value='Select.....']")).GetAttribute("title");

            Assert.AreEqual(exp, act, "Both values are not matching");

        }

        [When(@"Administration section page ""(.*)"" submenu is Clicked")]
        public void WhenAdministrationSectionPageSubmenuIsClicked(string p0)
        {
            IWebElement admin = Browser.Wd.FindElement(By.CssSelector("[title='Administration']"));
            fw.ExecuteJavascript(admin);
            IWebElement report = Browser.Wd.FindElement(By.XPath("//span[contains(.,'"+ p0 + "')]"));
            fw.ExecuteJavascript(report);
            tmsWait.Hard(5);
        }

        [Then(@"Verify Pagination is getting displayed")]
        public void ThenVerifyPaginationIsGettingDisplayed()
        {
            IWebElement page = Browser.Wd.FindElement(By.XPath("(//kendo-pager)[1]"));
            Assert.IsTrue(page.Displayed, "Pagination is not getting displayed");

        }

        [When(@"Manage Plan CMS Adjustment Reasons page Add Code button is clicked")]
        public void WhenManagePlanCMSAdjustmentReasonsPageAddCodeButtonIsClicked()
        {
            IWebElement report = Browser.Wd.FindElement(By.CssSelector("[test-id='managePlanAdjReas-th-AddCode'] i"));
            fw.ExecuteJavascript(report);
        }

        [Then(@"Verify Manage Plan CMS Adjustment Reasons page display Adjustment Reasons code as ""(.*)""")]
        public void ThenVerifyManagePlanCMSAdjustmentReasonsPageDisplayAdjustmentReasonsCodeAs(string p0)
        {
            bool nextPage = false;
            string text = tmsCommon.GenerateData(p0).ToUpper();
            do
            {
                nextPage = VerifyDiscrepancyStatusCode(text);
                if (nextPage)
                {
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@aria-label='Go to the next page']")));
                    tmsWait.Hard(1);
                }
            } while (nextPage);
            string[] codes = text.Split(',');
            foreach (string code in codes)
            {
                Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='managePlanAdjReason-grid-managePlanAdjReasonGrid']//tr[contains(.,'" + text + "')]")).Displayed, code + " Code is missing from Plan Adjustment Reasons table.");
            }

        }

        public bool VerifyDiscrepancyStatusCode(string code)
        {
            try
            {
                if (Browser.Wd.FindElement(By.XPath("//*[@test-id='managePlanAdjReason-grid-managePlanAdjReasonGrid']//div[@role='presentation']//td[contains(.,'" + code + "')]")).Displayed)
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                return true;
            }
            return true;
        }


        [When(@"Manage Plan CMS Adjustment Reasons page Adjustment Reasons code is set to ""(.*)""")]
        public void WhenManagePlanCMSAdjustmentReasonsPageAdjustmentReasonsCodeIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            string reason = tmsCommon.GenerateData(p0);
            IWebElement report = Browser.Wd.FindElement(By.CssSelector("input[required='required']"));
            report.SendKeys(reason);
            IWebElement save = Browser.Wd.FindElement(By.XPath("(//button[@title='Save'])[1]"));
            fw.ExecuteJavascript(save);
            tmsWait.Hard(5);


        }


        [Then(@"Manage Bid Tool Rates page is refreshed")]
        public void ThenManageBidToolRatesPageIsRefreshed()
        {
            Browser.Wd.FindElement(By.XPath("//part-c-bid-tool-rates//button[@title='Edit']")).Click();
        }

        [Then(@"Manage Bid Tool Rates page Click on ""(.*)"" button on Warning Dialog")]
        public void ThenManageBidToolRatesPageClickOnButtonOnWarningDialog(string p0)
        {

            tmsWait.Hard(2);
            try
            {


                if (p0.ToString().Equals("Cancel"))
                {
                    AngularFunction.clickOnNOonConfirmationDialog();
                    tmsWait.Hard(2);
                }
                else if (p0.ToString().Equals("OK"))
                {
                    AngularFunction.clickOnYESonConfirmationDialog();
                    tmsWait.Hard(2);
                }
            }

            catch (NoAlertPresentException e)
            {
                Console.WriteLine(" There is no Alert present");
            }
        }

        [Then(@"Manage Bid Tool Rates page ""(.*)"" ""(.*)"" button is Clicked")]
        public void ThenManageBidToolRatesPageButtonIsClicked(string p0, string delete)
        {

            string tab = null;

            if (p0.ToString().Equals("PartC Bid Rates"))
            {
                AngularFunction.clickOnElement(cfAngularManageBidToolRates.ManageBidToolRates.PartCBidRatesREMOVEBtn);
            }
            else if (p0.ToString().Equals("Part C Member Premium"))
            {
                AngularFunction.clickOnElement(cfAngularManageBidToolRates.ManageBidToolRates.PartCMemberPremiumREMOVEBtn);
            }
            else if (p0.ToString().Equals("Part D Bid Rates"))
            {
                AngularFunction.clickOnElement(cfAngularManageBidToolRates.ManageBidToolRates.PartDBidRatesREMOVEBtn);
            }
        }

        public void clickOnDelete(string t,string d)
        {
            tmsWait.Hard(2);
            IWebElement elem = Browser.Wd.FindElement(By.XPath("//" + t + "//button[@title='" + d + "']"));
            elem.Click();
            tmsWait.Hard(5);
        }

        public void clickOnEdit(string tab)
        {
            tmsWait.Hard(5);
            IWebElement elem = Browser.Wd.FindElement(By.XPath("//" + tab + "//button[@title='Edit']"));
            fw.ExecuteJavascript(elem);
            tmsWait.Hard(5);
        }
        [Then(@"Manage Bid Tool Rates page ""(.*)"" Edit button is Clicked")]
        public void ThenManageBidToolRatesPageEditButtonIsClicked(string p0)
        {

            if (p0.ToString().Equals("PartC Bid Rates"))
            {
                AngularFunction.clickOnElement(cfAngularManageBidToolRates.ManageBidToolRates.PartCBidRatesEDITBtn);
            }
            else if (p0.ToString().Equals("Part C Member Premium"))
            {
                AngularFunction.clickOnElement(cfAngularManageBidToolRates.ManageBidToolRates.PartCMemberPremiumsEDITBtn);
            }
            else if (p0.ToString().Equals("Part D Bid Rates"))
            {
                AngularFunction.clickOnElement(cfAngularManageBidToolRates.ManageBidToolRates.PartDBidRatesEDITBtn);
            }


        }


        [When(@"Administration page Manage Bid Tool Rates ""(.*)"" tab is clicked")]
        public void WhenAdministrationPageManageBidToolRatesTabIsClicked(string link)
        {
            IWebElement tab = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + link + "')]"));
            fw.ExecuteJavascript(tab);
            tmsWait.Hard(5);
        }

        void enterPartCMemberPremium(string tab, string name, string inputValue)
        {

            tmsWait.Hard(5);
            string value = tmsCommon.GenerateData(inputValue);


            if (name.Contains("planId"))
            {
                AngularFunction.sendKeysWithClear(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogPlanID, value);
            }
            else if (name.Contains("pbp"))
            {
                AngularFunction.sendKeysWithClear(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogPBP, value);
            }
            else if (name.Contains("segmentId"))
            {
                AngularFunction.sendKeysWithClear(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogSegmentID, value);
            }
            else if (name.Contains("rebatePartDSupplBuyDown"))
            {
                AngularFunction.sendKeysWithClear(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogDBuyDwnSupply, value);
            }
            else if (name.Contains("rebateABSuppl"))
            {
                AngularFunction.sendKeysWithClear(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogABMandSuppl, value);
            }
            else if (name.Contains("rebatePartBBuyDown"))
            {
                AngularFunction.sendKeysWithClear(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogPartBBuyDown, value);
            }
            else if (name.Contains("rebatePartDBuyDown"))
            {
                AngularFunction.sendKeysWithClear(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogPartDBuyDown, value);
            }
            else if (name.Contains("rebateABCostShare"))
            {
                AngularFunction.sendKeysWithClear(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogReduceABCostShare, value);
            }

            else if (name.Contains("effectiveDate"))
            {
                AngularFunction.enterDate(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogEffectiveDate, value);
            }
            else if (name.Contains("expiryDate"))
            {
                AngularFunction.enterDate(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogExpiryDate, value);
            }
        }

        void enterPartDBidRates(string tab, string name, string inputValue)
        {

            tmsWait.Hard(5);
            string value = tmsCommon.GenerateData(inputValue);


            if (name.Contains("planId"))
            {
                AngularFunction.sendKeysWithClear(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogPlanID, value);
            }
            else if (name.Contains("pbp"))
            {
                AngularFunction.sendKeysWithClear(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogPBP, value);
            }
            else if (name.Contains("drugBidType"))
            {
                AngularFunction.sendKeysWithClear(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogDrugBidType, value);
            }
            else if (name.Contains("bidAmount"))
            {
                AngularFunction.sendKeysWithClear(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogBidAmountat1_0, value);
            }
            else if (name.Contains("fedReInsurance"))
            {
                AngularFunction.sendKeysWithClear(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogFederalReinsuranceatPlanRisk, value);
            }
            else if (name.Contains("lisc"))
            {
                AngularFunction.sendKeysWithClear(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogLICSatPlanRisk, value);
            }
            else if (name.Contains("basicPremium"))
            {
                AngularFunction.sendKeysWithClear(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogNon_RoundedBasicPremium, value);
            }

            else if (name.Contains("supplPremium"))
            {
                AngularFunction.sendKeysWithClear(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogNon_RoundedSupplPremium, value);
            }
            else if (name.Contains("coverageGapDiscount"))
            {
                AngularFunction.sendKeysWithClear(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogCoverageGapDiscountAmount, value);
            }


            else if (name.Contains("effectiveDate"))
            {
                AngularFunction.enterDate(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogEffectiveDate, value);
            }
            else if (name.Contains("expiryDate"))
            {
                AngularFunction.enterDate(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogExpiryDate, value);
            }
        }

        void enterPartCBidRates(string tab, string name, string inputValue)
        {
            tmsWait.Hard(5);
            string value = tmsCommon.GenerateData(inputValue);


            if (name.Contains("planId"))
            {
                AngularFunction.sendKeysWithClear(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogPlanID, value);
            }
            else if (name.Contains("pbp"))
            {
                AngularFunction.sendKeysWithClear(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogPBP, value);
            }
            else if (name.Contains("segmentId"))
            {
                AngularFunction.sendKeysWithClear(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogSegmentID, value);
            }
            else if (name.Contains("segmentId"))
            {
                AngularFunction.sendKeysWithClear(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogSegmentID, value);
            }
            else if (name.Contains("scc"))
            {
                AngularFunction.sendKeysWithClear(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogSCC, value);
            }
            else if (name.Contains("demoAgedPartA"))
            {
                AngularFunction.sendKeysWithClear(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogAgedPartA, value);
            }
            else if (name.Contains("demoAgedPartB"))
            {
                AngularFunction.sendKeysWithClear(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogAgedPartB, value);
            }

            else if (name.Contains("demoDisabledPartA"))
            {
                AngularFunction.sendKeysWithClear(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogDisabledPartA, value);
            }
            else if (name.Contains("demoDisabledPartB"))
            {
                AngularFunction.sendKeysWithClear(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogDisabledPartB, value);
            }
            else if (name.Contains("riskPartA"))
            {
                AngularFunction.sendKeysWithClear(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogPartA, value);
            }
            else if (name.Contains("riskPartB"))
            {
                AngularFunction.sendKeysWithClear(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogPartB, value);
            }

            else if (name.Contains("effectiveDate"))
            {
                AngularFunction.enterDate(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogEffectiveDate, value);
            }
            else if (name.Contains("expiryDate"))
            {
                AngularFunction.enterDate(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogExpiryDate, value);
            }
        }

            void enterValueOnField(string tab, string name,string value)
        {
            tmsWait.Hard(5);
            string temp = "//" + tab + "//input[@name='"+name+"']";
            Browser.Wd.FindElement(By.XPath(temp)).Clear();
            Browser.Wd.FindElement(By.XPath(temp)).SendKeys(value);  
        }
        [When(@"Manage Bid Tool Rates ""(.*)"" Tab ""(.*)"" value is set to ""(.*)""")]
        public void WhenManageBidToolRatesTabValueIsSetTo(string p0, string field, string value)
        {
            string tab = null;
            value = tmsCommon.GenerateData(value);
            if (p0.ToString().Equals("PartC Bid Rates"))
            {

                enterPartCBidRates(tab, field, value);
            }
            else if (p0.ToString().Equals("Part C Member Premium"))
            {

                enterPartCMemberPremium(tab, field, value);
            }
            else if (p0.ToString().Equals("Part D Bid Rates"))
            {

                enterPartDBidRates(tab, field, value);
            }

        }

        public void PartDBidRatesSelectDroDown(string t, string f, string v)
        {
            switch (f)
            {
                case "Year":
                    AngularFunction.selectDropDownValue(cfAngularManageBidToolRates.ManageBidToolRates.PartDBidRatesYearDropdown, v);
                    break;
                case "Plan ID":
                    AngularFunction.selectDropDownValue(cfAngularManageBidToolRates.ManageBidToolRates.PartDBidRatesPlanIDDropdown, v);
                    break;
                case "PBP ID":
                    AngularFunction.selectDropDownValue(cfAngularManageBidToolRates.ManageBidToolRates.PartDBidRatesPBPDropdown, v);
                    break;
            }
        }

        public void PartCMemberPremiumSectionDropwDownSelection(string t, string f, string v)
        {
            switch (f)
            {
                case "Year":
                    AngularFunction.selectDropDownValue(cfAngularManageBidToolRates.ManageBidToolRates.PartCMemberPremiumYearDropdown, v);
                    break;
                case "Plan ID":
                    AngularFunction.selectDropDownValue(cfAngularManageBidToolRates.ManageBidToolRates.PartCMemberPremiumPlanIDDropdown, v);
                    break;
                case "PBP ID":
                    AngularFunction.selectDropDownValue(cfAngularManageBidToolRates.ManageBidToolRates.PartCMemberPremiumPBPDropdown, v);
                    break;
            }
        }

        public void PartCBidRateSectionDropwDownSelection(string t, string f, string v)
        {
            tmsWait.Hard(3);
            switch (f)
            {
                case "Year":
                    AngularFunction.selectDropDownValue(cfAngularManageBidToolRates.ManageBidToolRates.PartCBidRatesYearDropdown, v);
                    break;
                case "Plan ID":
                    AngularFunction.selectDropDownValue(cfAngularManageBidToolRates.ManageBidToolRates.PartCBidRatesPlanIDDropdown, v);
                    break;
                case "PBP ID":
                    AngularFunction.selectDropDownValue(cfAngularManageBidToolRates.ManageBidToolRates.PartCBidRatesPBPDropdown, v);
                    break;
            }
        }



        void clickOnComponent(string tab, string name)
        {
            tmsWait.Hard(1);
            string temp = "//" + tab + "//*[text()[contains(.,'" + name + "')]]";
            IWebElement element = Browser.Wd.FindElement(By.XPath(temp));
            fw.ExecuteJavascript(element);
            tmsWait.Hard(2);
            tmsWait.WaitForAlertPresent();
            if(tmsWait.IsAlertPresent())
            {
                Browser.ClosePopUps(true);
            }
        }

        public void selectDropdownlist(string t,string f,string v)
        {
            tmsWait.Hard(3);
            switch (f)
            {
                case "Year":
                    new SelectElement(Browser.Wd.FindElement(By.XPath("//" + t + "//*[@id='ddlYear']"))).SelectByText(v);
                    break;
                case "Plan ID":
                    new SelectElement(Browser.Wd.FindElement(By.XPath("//" + t + "//*[@id='ddlPlan']"))).SelectByText(v);                    
                    break;
                case "PBP ID":
                    new SelectElement(Browser.Wd.FindElement(By.XPath("//" + t + "//*[@id='ddlPBP']"))).SelectByText(v);
                     break;
            }
           
           
        }

        [When(@"Administration ""(.*)"" section ""(.*)"" Tab ""(.*)"" dropdown list is set to ""(.*)""")]
        public void WhenAdministrationSectionTabDropdownListIsSetTo(string p1, string p0, string field, string value)
        {

            string tab = null;
            value = tmsCommon.GenerateData(value);
            if (p0.ToString().Equals("PartC Bid Rates"))
            {
                PartCBidRateSectionDropwDownSelection(tab, field, value);

            }
            else if (p0.ToString().Equals("Part C Member Premium"))
            {

                PartCMemberPremiumSectionDropwDownSelection(tab, field, value);
            }
            else if (p0.ToString().Equals("Part D Bid Rates"))
            {

                PartDBidRatesSelectDroDown(tab, field, value);
            }

        }

        [When(@"Verify Administration ""(.*)"" section ""(.*)"" Tab Plan ID dropdown list is not displayed ""(.*)""")]
        public void WhenVerifyAdministrationSectionTabPlanIDDropdownListIsNotDisplayed(string p0, string section, string planId)
        {

            if (section.Equals("PartC Bid Rates"))
            {
                try
                {

                    AngularFunction.selectDropDownValue(cfAngularManageBidToolRates.ManageBidToolRates.PartCBidRatesPlanIDDropdown, planId);
                }
                catch
                {
                    Assert.IsTrue(true);
                }
            }
            else if (section.Equals("Part C Member Premium"))
            {
                try
                {

                    AngularFunction.selectDropDownValue(cfAngularManageBidToolRates.ManageBidToolRates.PartCMemberPremiumPlanIDDropdown, planId);
                }
                catch
                {
                    Assert.IsTrue(true);
                }
            }
            else if (section.Equals("Part D Bid Rates"))
            {
                try
                {

                    AngularFunction.selectDropDownValue(cfAngularManageBidToolRates.ManageBidToolRates.PartDBidRatesPlanIDDropdown, planId);
                }
                catch
                {
                    Assert.IsTrue(true);
                }
            }



        }




        [When(@"Manage Bid Tool Rates ""(.*)"" Tab ""(.*)"" button is Clicked")]
        public void WhenManageBidToolRatesTabButtonIsClicked(string p0, string name)
        {
            tmsWait.Hard(5);
            string tab = null;
            if (p0.ToString().Equals("PartC Bid Rates"))
            {
                if (name.Contains("ADD"))
                {
                    AngularFunction.clickOnElement(cfAngularManageBidToolRates.ManageBidToolRates.PartCBidRatesTAB);
                    AngularFunction.clickOnElement(cfAngularManageBidToolRates.ManageBidToolRates.PartCBidRatesADDBtn);
                }
                else if (name.Contains("SAVE"))
                {

                    AngularFunction.clickOnElement(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogSAVE);
                }
                else if (name.Contains("SEARCH"))
                {

                    AngularFunction.clickOnElement(cfAngularManageBidToolRates.ManageBidToolRates.PartCBidRatesSEARCHBtn);
                }
                else if (name.Contains("EDIT"))
                {

                    AngularFunction.clickOnElement(cfAngularManageBidToolRates.ManageBidToolRates.PartCBidRatesEDITBtn);
                }
                else if (name.Contains("CANCEL"))
                {

                    AngularFunction.clickOnElement(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogCANCEL);
                }
                else if (name.Contains("DELETE"))
                {

                    AngularFunction.clickOnElement(cfAngularManageBidToolRates.ManageBidToolRates.PartCBidRatesREMOVEBtn);
                }
                else if (name.Contains("UPDATE"))
                {

                    AngularFunction.clickOnElement(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogUPDATE);
                }

            }
            else if (p0.ToString().Equals("Part C Member Premium"))
            {
                if (name.Contains("ADD"))
                {
                    AngularFunction.clickOnElement(cfAngularManageBidToolRates.ManageBidToolRates.PartCMemberPremiumTAB);
                    AngularFunction.clickOnElement(cfAngularManageBidToolRates.ManageBidToolRates.PartCMemberPremiumADDBtn);
                }
                else if (name.Contains("SAVE"))
                {

                    AngularFunction.clickOnElement(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogSAVE);
                }
                else if (name.Contains("SEARCH"))
                {

                    AngularFunction.clickOnElement(cfAngularManageBidToolRates.ManageBidToolRates.PartCMemberPremiumSEARCHBtn);
                }
                else if (name.Contains("EDIT"))
                {

                    AngularFunction.clickOnElement(cfAngularManageBidToolRates.ManageBidToolRates.PartCMemberPremiumsEDITBtn);
                }
                else if (name.Contains("CANCEL"))
                {

                    AngularFunction.clickOnElement(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogCANCEL);
                }
                else if (name.Contains("DELETE"))
                {

                    AngularFunction.clickOnElement(cfAngularManageBidToolRates.ManageBidToolRates.PartCMemberPremiumREMOVEBtn);
                }
                else if (name.Contains("UPDATE"))
                {

                    AngularFunction.clickOnElement(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogUPDATE);
                }

            }
            else if (p0.ToString().Equals("Part D Bid Rates"))
            {
                if (name.Contains("ADD"))
                {
                    AngularFunction.clickOnElement(cfAngularManageBidToolRates.ManageBidToolRates.PartDBidRatesTAB);
                    AngularFunction.clickOnElement(cfAngularManageBidToolRates.ManageBidToolRates.PartDBidRatesADDBtn);
                }
                else if (name.Contains("SAVE"))
                {

                    AngularFunction.clickOnElement(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogSAVE);
                }
                else if (name.Contains("SEARCH"))
                {

                    AngularFunction.clickOnElement(cfAngularManageBidToolRates.ManageBidToolRates.PartDBidRatesSEARCHBtn);
                }
                else if (name.Contains("EDIT"))
                {

                    AngularFunction.clickOnElement(cfAngularManageBidToolRates.ManageBidToolRates.PartDBidRatesEDITBtn);
                }
                else if (name.Contains("CANCEL"))
                {

                    AngularFunction.clickOnElement(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogCANCEL);
                }
                else if (name.Contains("DELETE"))
                {

                    AngularFunction.clickOnElement(cfAngularManageBidToolRates.ManageBidToolRates.PartDBidRatesREMOVEBtn);
                }
                else if (name.Contains("UPDATE"))
                {

                    AngularFunction.clickOnElement(cfAngularManageBidToolRates.ManageBidToolRates.NewBidRatesDialogUPDATE);
                }
            }


        }

        [Then(@"FRM report page ""(.*)"" report link is clicked")]
        public void ThenFRMReportPageReportLinkIsClicked(string link)
        {
                    

            tmsWait.Hard(1);
            IWebElement reportlink = Browser.Wd.FindElement(By.CssSelector("[test-id='" + link + "']"));
            fw.ExecuteJavascript(reportlink);
            tmsWait.Hard(3);
           
        }

        [Then(@"FRM report page Range Start Date is selected as ""(.*)""")]
        public void ThenFRMReportPageRangeStartDateIsSelectedAs(string startDate)
        {
            tmsWait.Hard(5);
            SelectElement rangeStart = new SelectElement(FRM.FRMReport.RangeStartDropdown);
            rangeStart.SelectByText(startDate);
        }

        [Then(@"FRM report page Range End Date is selected as ""(.*)""")]
        public void ThenFRMReportPageRangeEndDateIsSelectedAs(string endDate)
        {
            tmsWait.Hard(5);
            SelectElement rangeEnd = new SelectElement(FRM.FRMReport.RangeEndDropdown);
            rangeEnd.SelectByText(endDate);
        }

    }
}
