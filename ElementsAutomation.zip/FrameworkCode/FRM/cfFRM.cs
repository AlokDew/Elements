﻿using OpenQA.Selenium;
using TechTalk.SpecFlow;

namespace TMSoR1
{
    public class FRM
    {
        public static NotesAndActionsSearch NotesAndActionsSearch { get { return new NotesAndActionsSearch(); } }
        public static NotesAndActionsCreateNewNote NotesAndActionsCreateNewNote { get { return new NotesAndActionsCreateNewNote(); } }
        public static ReportManagerSearch ReportManagerSearch { get { return new ReportManagerSearch(); } }
      public static FRMFileMenu FRMFileMenu { get { return new FRMFileMenu(); } }
        public static FRMMainPage FRMMainPage { get { return new FRMMainPage(); } } // UI Moderinzation
        public static FRMMainNavigation FRMMainNavigation { get { return new FRMMainNavigation(); } }
        public static FRMAdministrator FRMAdministrator { get { return new FRMAdministrator(); } }
        public static FRMMemberSummary FRMMemberSummary { get { return new FRMMemberSummary(); } }
        public static FRMMemberPaymentSummary FRMMemberPaymentSummary { get { return new FRMMemberPaymentSummary(); } }
        public static FRMAdjustDiscrepancy FRMAdjustDiscrepancy { get { return new FRMAdjustDiscrepancy(); } }
        public static FRMPaymentHistory FRMPaymentHistory { get { return new FRMPaymentHistory(); } }
        public static FRMHICChangeHistory FRMHICChangeHistory { get { return new FRMHICChangeHistory(); } }
        public static FRMMMRHistory FRMMMRHistory { get { return new FRMMMRHistory(); } }
        public static BatchEnrollDisEnroll BatchEnrollDisEnroll { get { return new BatchEnrollDisEnroll(); } }
        public static ExportMonthlyExtracttofile ExportMonthlyExtracttofile { get { return new ExportMonthlyExtracttofile(); } }
        public static ManageDiscrepancyStatusCode ManageDiscrepancyStatusCode { get { return new ManageDiscrepancyStatusCode(); } }
        public static AdjustDiscrepancy AdjustDiscrepancy { get { return new AdjustDiscrepancy(); } }
        public static FRMFilesProcessingStatus FRMFilesProcessingStatus { get { return new FRMFilesProcessingStatus(); } }
        public static GenerateReport GenerateReport { get { return new GenerateReport(); } }
        public static FRMMemberInfo FRMMemberInfo { get { return new FRMMemberInfo(); } }
        public static CompareFlags CompareFlags { get { return new CompareFlags(); } }
        public static FRMLogin FRMLogin { get { return new FRMLogin(); } }
        public static FRMMainmenu FRMMainmenu { get { return new FRMMainmenu(); } }
        public static FRMEnrollmentCheck FRMEnrollmentCheck { get { return new FRMEnrollmentCheck(); } }
        public static FRMChangePlanID FRMChangePlanID { get { return new FRMChangePlanID(); } }
        public static BatchUpdateProcessing BatchUpdateProcessing { get { return new BatchUpdateProcessing(); } }
        public static PlanStartRating PlanStartRating { get { return new PlanStartRating(); } }
        public static FRMReport FRMReport { get { return new FRMReport(); } }
        public static MMRExtract MMRExtract { get { return new MMRExtract(); } }
        public static MemberPremiumExtract MemberPremiumExtract { get { return new MemberPremiumExtract(); } }
        public static ManagePlanPBPInfo ManagePlanPBPInfo { get { return new ManagePlanPBPInfo(); } }
    }


    


    [Binding]
    public class FRMFileMenu
    {
        public IWebElement FRMMain { get { return Browser.Wd.FindElement(By.XPath("//div[contains(.,'Member Premium Extract')]//div[@class='main-content-header d-flex']")); } }
    }


    [Binding]
    public class MemberPremiumExtract
    {
        public IWebElement Title { get { return Browser.Wd.FindElement(By.XPath("//div[contains(.,'Member Premium Extract')]//div[@class='main-content-header d-flex']")); } }
        public IWebElement FromDate { get { return Browser.Wd.FindElement(By.CssSelector("select[test-id='premiumMemExt-select-premiumRangeFromId']")); } }
        public IWebElement ToDate { get { return Browser.Wd.FindElement(By.CssSelector("select[test-id='premiumMemExt-select-premiumRangeToId']")); } }
        public IWebElement RESET { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='premiumMemExt-btn-RESET']")); } }
        public IWebElement EXPORT { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='premiumMemExt-btn-EXPORT']")); } }
        public IWebElement FileProcessingStatusLink { get { return Browser.Wd.FindElement(By.LinkText("File Processing Status page")); } }


    }

    [Binding]
    public class MMRExtract
    {
        public IWebElement Title { get { return Browser.Wd.FindElement(By.CssSelector("span[test-id='mmrExtract-span-Administration']")); } }
        public IWebElement FromDate { get { return Browser.Wd.FindElement(By.CssSelector("select[test-id='mmrExtract-select-mmrRangeFromId']")); } }
        public IWebElement ToDate { get { return Browser.Wd.FindElement(By.CssSelector("select[test-id='mmrExtract-select-mmrRangeToId']")); } }
        public IWebElement RESET { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='mmrExtract-btn-RESET']")); } }
        public IWebElement EXPORT { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='mmrExtract-btn-EXPORT']")); } }
        public IWebElement FileProcessingStatusLink { get { return Browser.Wd.FindElement(By.LinkText("File Processing Status page")); } }


        

    }

    [Binding]

    public class PlanStartRating
    {
        public IWebElement PaginationNext { get { return Browser.Wd.FindElement(By.XPath("(//ul[@test-id='planStarRating-pagination']//a)[3]")); } }
        public IWebElement PaginationFirst { get { return Browser.Wd.FindElement(By.XPath("(//ul[@test-id='planStarRating-pagination']//a)[1]")); } }
        public IWebElement PaginationLast { get { return Browser.Wd.FindElement(By.XPath("(//ul[@test-id='planStarRating-pagination']//a)[4]")); } }
        public IWebElement PaginationPrevious { get { return Browser.Wd.FindElement(By.XPath("(//ul[@test-id='planStarRating-pagination']//a)[2]")); } }

        public IWebElement PlanStarRatingPaginationNext { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='PlanStarPaging']/li[3]//a")); } }
        public IWebElement PlanStarRatingPaginationPrevious { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='PlanStarPaging']//li[2]//a")); } }
        public IWebElement PlanStarRatingPaginationFirst { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='PlanStarPaging']//li[1]//a")); } }
        public IWebElement PlanStarRatingPaginationLast { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='PlanStarPaging']//li[4]//a")); } }

        public IWebElement PlanStarRatingPageSize { get { return Browser.Wd.FindElement(By.XPath("//input[@role='spinbutton']")); } }
    }

    [Binding]
    public class FRMReport
    {
        public IWebElement ReportPageTitle { get { return Browser.Wd.FindElement(By.CssSelector("span[test-id='report-title-searchCriteria']")); } }
        public IWebElement PaymentMonthStartDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PaymonStart']")); } }
        public IWebElement PaymentMonthEndDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PaymonEnd']")); } }
        public IWebElement CMDAdjustTypeDD { get { return Browser.Wd.FindElement(By.CssSelector("select[test-id='AdjReason']")); } }
        public IWebElement SortDetailsByeDD { get { return Browser.Wd.FindElement(By.CssSelector("select[test-id='SortBy']")); } }
        public IWebElement SaveFormat { get { return Browser.Wd.FindElement(By.CssSelector(".col-lg-1.col-md-1.col-sm-1.col-xs-1.padding0.ng-scope")); } }
        public IWebElement SortDirection { get { return Browser.Wd.FindElement(By.CssSelector("select[test-id='Sortorder']")); } }
        public IWebElement UserNotesTextbox { get { return Browser.Wd.FindElement(By.Id("reportNotes")); } }
        public IWebElement RunReportButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-runReport']")); } }
        public IWebElement SearchButton { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='mainContant']//button[contains(.,'SEARCH')]")); } }
        public IWebElement DeleteButton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='reportManager-btn-delete']")); } }
        public IWebElement DiscrepancyTypeMultiselect { get { return Browser.Wd.FindElement(By.CssSelector("multiselect[test-id='DiscrepTypeString']")); } }
        public IWebElement ReportResetButton { get { return Browser.Wd.FindElement(By.CssSelector("button[test-id='report-btn-reset']")); } }
        public IWebElement RangeStartDropdown { get { return Browser.Wd.FindElement(By.CssSelector("select[test-id='StartMonth']")); } }
        public IWebElement RangeEndDropdown { get { return Browser.Wd.FindElement(By.CssSelector("select[test-id='EndMonth']")); } }
    }

    [Binding]
    public class BatchUpdateProcessing
    {
        public IWebElement EnrollDisenroll { get { return Browser.Wd.FindElement(By.XPath(".//label[@for='batchUpdateEnrollChangeID']")); } }
        public IWebElement HICChange { get { return Browser.Wd.FindElement(By.XPath(".//label[@test-id='batchUpdate-lbl-batchUpdateHicID']")); } }
        public IWebElement FlagUpdate { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='batchUpdate-radio-batchUpdateFlagID']")); } }
        //public IWebElement Browse { get { return Browser.Wd.FindElement(By.XPath("//li[@class='k-file']//span[@class='k-filename']")); } }
        public IWebElement Browse { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='batchUpdate-fileUpload'] input")); } }
        public IWebElement Reset { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='BatchbtnReset']")); } }
        public IWebElement Upload { get { return Browser.Wd.FindElement(By.XPath("//button[contains(.,'Upload')]")); } }
        public IWebElement ErrorMessage { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,' Success !')]")); } }
        public IWebElement SucsessMessage { get { return Browser.Wd.FindElement(By.XPath("//div[@class='row ng-star-inserted']//label[contains(.,'Success')]")); } }
        //public IWebElement PageTitle { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='batchUpdate-span-Administration']")); } }
        public IWebElement PageTitle { get { return Browser.Wd.FindElement(By.XPath("//div[@class='main-content-header d-flex']/div/div[contains(.,'Batch Update')]")); } }
        public IWebElement Checkbox { get { return Browser.Wd.FindElement(By.Id("BatchUpadteCheckID")); } }
        public IWebElement FileProcessingStatusLink { get { return Browser.Wd.FindElement(By.Id("fileStatusEnrollmentID")); } }
        public IWebElement FileProcessingStatusPagination { get { return Browser.Wd.FindElement(By.Id("notesPaging")); } }
        public IWebElement FileProcessingStatusTable { get { return Browser.Wd.FindElement(By.XPath("//div[@data-ui-grid='fileProcessStatusGrid']//div[@class='ui-grid-viewport ng-isolate-scope']")); } }
        public IWebElement UploadedfileName { get { return Browser.Wd.FindElement(By.XPath("//li[@ng-repeat='file in files']")); } }
    }

    [Binding]
    public class FRMChangePlanID
    {
        public IWebElement HICNumber { get { return Browser.Wd.FindElement(By.Id("planNumberHicID")); } }
        public IWebElement SucessMessage { get { return Browser.Wd.FindElement(By.XPath("//span[@test-id='changePlanId-span-msg']")); } }
        public IWebElement ErrorMessage { get { return Browser.Wd.FindElement(By.XPath("//span[@test-id='changePlanId-span-msg']")); } }
        public IWebElement PartCOption { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='changePlanId-radio-changePlanCID']")); } }
        public IWebElement PartCOptionbutton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='changePlanId-radio-changePlanCID']")); } }
        public IWebElement PartDOptionbutton { get { return Browser.Wd.FindElement(By.Id("[test-id='changePlanId-radio-changePlanDID']")); } }
        public IWebElement PartDOption { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='changePlanId-radio-changePlanDID']")); } }
        public IWebElement SaveButton { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='changePlanbtnSave']")); } }
        public IWebElement ResetButton { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='changePlanbtnReset']")); } }
        public IWebElement AddButton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='changePlanId-btn-add']")); } }
        public IWebElement RemoveButton { get { return Browser.Wd.FindElement(By.XPath("//input[@value='Remove']")); } }
        public IWebElement SearchLink { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='existingSearchName']")); } }
        public IWebElement NewPlanID { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='drpPlan']")); } }
        public IWebElement EnrolledPlanIDCheckbox { get { return Browser.Wd.FindElement(By.XPath("//table[@class='listTable']//tr[1]/td[1]//input[@type='checkbox']")); } }
        public IWebElement CurrentPlanEnrolledCheckbox { get { return Browser.Wd.FindElement(By.XPath("//kendo-grid[@id='availPayMonthPlan']//kendo-grid-list//tr[1]//input")); } }
        public IWebElement Successmsg { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='changePlanId-lbl-success']")); } }


    }


    [Binding]
    public class FRMEnrollmentCheck
    {
        public IWebElement PageTitle { get { return Browser.Wd.FindElement(By.XPath(".//*[@class='main-content-header d-flex']/div[@class='flex-fill']/div")); } }
        public IWebElement Successmessage { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='runEnrollCheck-lbl-msg'][contains(.,'Enrollment Check Job has been submitted')]")); } }
        public IWebElement RunEnrollmentCheckButton { get { return Browser.Wd.FindElement(By.Id("runEnrollmentbtn")); } }
    }

    [Binding]
    public class FRMAdjustDiscrepancy
    {
        public IWebElement AdjustDiscrepancyBackToRecord { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainAdjDisc-span-backToRecord']")); } }
        public IWebElement partCRadioButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainAdjDisc-lbl-fmad_PartC']")); } }
        public IWebElement partDRadioButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainAdjDisc-lbl-fmad_PartD']")); } }
        public IWebElement genderMaleRadioButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainAdjDisc-lbl-fmadAllMale3']")); } }
        public IWebElement genderFemaleRadioButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainAdjDisc-rdo-fmadAllFemale']")); } }
        public IWebElement esrdStatusNoRadioButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainAdjDisc-rdo-fmaddAllNo']")); } }
        public IWebElement esrdStatusYesRadioButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainAdjDisc-rdo-fmadAllYes']")); } }
        public IWebElement hospiceStatusNoRadioButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainAdjDisc-rdo-fmaddAllNo']")); } }
        public IWebElement hospiceStatusYesRadioButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainAdjDisc-rdo-fmadAllYes']")); } }
        public IWebElement indicatorCDropdown { get { return Browser.Wd.FindElement(By.Id("ddlIndicatorPartC")); } }
        public IWebElement indicatorDDropdown { get { return Browser.Wd.FindElement(By.Id("ddlIndicatorPartD")); } }
        public IWebElement applyonevaluetoallradiobutton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainAdjDisc-lbl-applyOne']")); } }
        public IWebElement selectedmonthradiobutton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainAdjDisc-lbl-changeSelected']")); } }
        public IWebElement prospectiveMonthSelectionbox { get { return Browser.Wd.FindElement(By.Id("applyCurrentMonth")); } }
        public IWebElement prospectiveMonthSelectionLabelbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainAdjDisc-lbl-prospectiveMonths']")); } }
        public IWebElement reasonofagreementDropdown { get { return Browser.Wd.FindElement(By.Id("ddlReasonForAdjustment")); } }
        public IWebElement saveButton { get { return Browser.Wd.FindElement(By.XPath("(//button[@test-id='frmMainAdjDisc-btn-fmadbtnSave'])[2]")); } }
        public IWebElement saveButtonToSelectedMonth { get { return Browser.Wd.FindElement(By.Id("fmadbtnSave")); } }                                                                             //adjust-discrepancy/div[1]/div/div[2]/div/div/div[7]/div/button[2]
        public IWebElement backToAdjuDiscrpPageButton { get { return Browser.Wd.FindElement(By.Id("btnBackToRecord")); } }
        public IWebElement backToRecordsButton { get { return Browser.Wd.FindElement(By.Id("btnClose")); } }
        public IWebElement successMessage { get { return Browser.Wd.FindElement(By.XPath("//span[@test-id='frmMainAdjDisc-span-successMessage']")); } }
        public IWebElement employerGroupN { get { return Browser.Wd.FindElement(By.XPath("//label[@for='fmadAllNo']")); } }
        public IWebElement employerGroupY { get { return Browser.Wd.FindElement(By.XPath("//label[@for='fmadAllYes']")); } }
        public IWebElement esrdStatusN { get { return Browser.Wd.FindElement(By.XPath("//label[@for='fmadAllNo']")); } }
        public IWebElement genderMale { get { return Browser.Wd.FindElement(By.XPath("//label[@for='fmadAllMale']")); } }
        public IWebElement hospiceStatusY { get { return Browser.Wd.FindElement(By.XPath("//label[@for='fmadAllYes']")); } }
        public IWebElement institutionalStatusY { get { return Browser.Wd.FindElement(By.XPath("//label[@for='fmadAllYes']")); } }
        public IWebElement longTermInstStatusN { get { return Browser.Wd.FindElement(By.XPath("//label[@for='fmadAllNo']")); } }
        public IWebElement medicadeStatusAddonN { get { return Browser.Wd.FindElement(By.XPath("//label[@for='fmadAllNo']")); } }
        public IWebElement medicadeStatusN { get { return Browser.Wd.FindElement(By.XPath("//label[@for='fmadAllNo']")); } }
        public IWebElement mspStatusN { get { return Browser.Wd.FindElement(By.XPath("//label[@for='fmadAllNo']")); } }
        public IWebElement nursingHomeStatusN { get { return Browser.Wd.FindElement(By.XPath("//label[@for='fmadAllNo']")); } }
        public IWebElement orecN { get { return Browser.Wd.FindElement(By.XPath("//label[@for='fmadAllNo']")); } }
        public IWebElement outOfAreaY { get { return Browser.Wd.FindElement(By.XPath("//label[@for='fmadAllYes']")); } }
        public IWebElement partAStatusY { get { return Browser.Wd.FindElement(By.XPath("//label[@for='fmadAllYes']")); } }
        public IWebElement partBStatusY { get { return Browser.Wd.FindElement(By.XPath("//label[@for='fmadAllYes']")); } }
        public IWebElement partCRiskFactorY { get { return Browser.Wd.FindElement(By.Id("fmadAllTxt")); } }
        public IWebElement segmentIDTextbox { get { return Browser.Wd.FindElement(By.Id("fmadAllTxt")); } }
        public IWebElement stateCountyCodeTextbox { get { return Browser.Wd.FindElement(By.Id("fmadAllTxt")); } }
        public IWebElement dateofbirthTextbox { get { return Browser.Wd.FindElement(By.Id("fmadAllTxt")); } }
        public IWebElement longTermINSTTextbox { get { return Browser.Wd.FindElement(By.Id("fmadAllTxt")); } }
        public IWebElement partDRiskFactor { get { return Browser.Wd.FindElement(By.Id("fmadAllTxt")); } }
        public IWebElement PBPValue { get { return Browser.Wd.FindElement(By.Id("fmadAllTxt")); } }
        public IWebElement changeTypeTextbox { get { return Browser.Wd.FindElement(By.Id("fmadIndividualTxt")); } }
        public IWebElement segmentIDChangeTypeTextbox { get { return Browser.Wd.FindElement(By.Id("fmadIndividualTxt")); } }
        public IWebElement stateCountyCodeChangeTypeTextbox { get { return Browser.Wd.FindElement(By.Id("fmadIndividualTxt")); } }
        public IWebElement longTermINSTChangeTypeTextbox { get { return Browser.Wd.FindElement(By.Id("fmadIndividualTxt")); } }
        public IWebElement partDRiskFactorChangeType { get { return Browser.Wd.FindElement(By.Id("fmadIndividualTxt")); } }
        //public IWebElement riskFactorChangeType { get { return Browser.Wd.FindElement(By.XPath("//*[@id='forms_CompareFlag']/div[3]/div[2]/div[3]/select")); } }        
        public IWebElement riskFactorChangeType { get { return Browser.Wd.FindElement(By.XPath("//div[@ng-show='frmAdjustDiscrepancy.visible.individualCustomSelect']/select[@data-ng-model='frmAdjustDiscrepancy.newValue']")); } }
        //public IWebElement esrdMSPStatus { get { return Browser.Wd.FindElement(By.XPath("//*[@id='forms_CompareFlag']/div[4]/div/div[2]/select")); } }
        // public IWebElement esrdMSPStatus { get { return Browser.Wd.FindElement(By.XPath("//div[@ng-show='frmAdjustDiscrepancy.visible.individualCustomSelect']/select[@data-ng-model='frmAdjustDiscrepancy.newValue']")); } }
        public IWebElement esrdMSPStatus { get { return Browser.Wd.FindElement(By.XPath("//div[@ng-show='frmAdjustDiscrepancy.visible.allDdl']//select[@data-ng-model='frmAdjustDiscrepancy.newValue']")); } }

        // public IWebElement currentMonthCheckbox { get { return Browser.Wd.FindElement(By.XPath("//*[@id='forms_CompareFlag']/div[3]/div[1]/div/div/div/table/tbody/tr[1]/td[1]/input")); } }
        public IWebElement currentMonthCheckbox { get { return Browser.Wd.FindElement(By.XPath("(//input[@test-id='frmMainAdjDisc-chk-selectedAvailablePayMonths'])[1]")); } }
        public IWebElement addButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainAdjDisc-btn-btnAdd']")); } }
        public IWebElement removeButton { get { return Browser.Wd.FindElement(By.Id("btnRemove")); } }
        public IWebElement ESRDMSPStatusdrp { get { return Browser.Wd.FindElement(By.XPath("//select[@test-id='frmMainAdjDisc-select-allDdl']")); } }
        public IWebElement ApplyvalueselectedcurrentpaymentmontoprospectivemonCheckbox { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='frmMainAdjDisc-chk-chkBoxProspectiveMonths']")); } }
        public IWebElement BackToRecordButton { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='frmMainAdjDisc-span-backToRecord']")); } }
        public IWebElement CloseButton { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='frmMainAdjDisc-span-backToRecord']")); } }





    }


    [Binding]
    public class FRMPaymentHistory
    {
        public IWebElement paymentsRadioButton { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Payments')]")); } }
        public IWebElement flagsRadioButton { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='tabFlagsAnchor']/a/i")); } }
        public IWebElement paymentMonthDropdown { get { return Browser.Wd.FindElement(By.Id("drpPayMonths")); } }
        public IWebElement repMonthData { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='number-default'][2]")); } }
        public IWebElement moreLink { get { return Browser.Wd.FindElement(By.XPath("//a[@title='More']")); } }
        public IWebElement demographicPlanData { get { return Browser.Wd.FindElement(By.XPath("//*[@id='tabFlags']/div/demographic/div/table/tbody/tr[1]/*")); } }
        public IWebElement spanDemographicTable { get { return Browser.Wd.FindElement(By.XPath("//demographic//table[@class='table paymentTablehighlight']")); } }
        public IWebElement spanRiskAdjusterSpecialTable { get { return Browser.Wd.FindElement(By.XPath("//risk-adjuster-special//table[@class='table paymentTablehighlight']")); } }
        public IWebElement addNoteButton { get { return Browser.Wd.FindElement(By.Name("btnAddNote")); } }
    }

    [Binding]
    public class FRMMainmenu
    {
        public IWebElement TaskExport { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Export')]")); } }
        public IWebElement Dashboard { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='Button5']")); } }
        public IWebElement DashboardPage { get { return Browser.Wd.FindElement(By.XPath("//div[text()='Dashboard']")); } }
        public IWebElement Main { get { return Browser.Wd.FindElement(By.XPath("//div[contains(.,'Main')]")); } }
        public IWebElement FRMMainpage { get { return Browser.Wd.FindElement(By.XPath("//div[text()='Main']")); } }
        public IWebElement Reports { get { return Browser.Wd.FindElement(By.CssSelector("[title='Reports']")); } }
        public IWebElement ReportsPage { get { return Browser.Wd.FindElement(By.XPath("//div[text()='Reports']")); } }
        //public IWebElement ReportManager { get { return Browser.Wd.FindElement(By.XPath("//div[contains(.,'Report Manager')]")); } }
        public IWebElement ReportManager { get { return Browser.Wd.FindElement(By.CssSelector("[title='Report Manager']")); } }
        public IWebElement Administration { get { return Browser.Wd.FindElement(By.LinkText("Administration")); } }
        public IWebElement ReportManagerPage { get { return Browser.Wd.FindElement(By.XPath("//div[text()='Report Manager']")); } }
        
        public IWebElement FileProcessingStatus { get { return Browser.Wd.FindElement(By.CssSelector("[title='Job Processing Status']")); } }
        public IWebElement FileProcessingStatusPage { get { return Browser.Wd.FindElement(By.XPath("//div[text()='Job Processing Status']")); } }
        public IWebElement FRMTitleHeader { get { return Browser.Wd.FindElement(By.CssSelector("span[test-id='header-title-applicationName']")); } }
        //public IWebElement FRMPageTitle {  get { return Browser.Wd.FindElement(By.XPath("//div[@class='adminTitle ng-scope']/span")); } }
        // public IWebElement FRMPageTitle { get { return Browser.Wd.FindElement(By.XPath("//div[@class='main-content-header d-flex'][contains(.,'Plan Star Ratings')]")); } }

        public IWebElement FRMPageTitle { get { return Browser.Wd.FindElement(By.XPath("//div[contains(.,'Plan Star Ratings')]")); } }

        public IWebElement FileProcessingStatusPage1 { get { return Browser.Wd.FindElement(By.XPath("//div[text()='Job Processing Status']")); } }
    }


    [Binding]
    public class FRMLogin
    {
        public IWebElement Logout { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='header-btn-logOut']")); } }
        public IWebElement Help { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='header-btn-help']")); } }
        public IWebElement Information { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='Button4']")); } }
        public IWebElement MainMenu { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='expanButton']")); } }
        public IWebElement ProductDropDownmenu { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='dropdownProduct']")); } }
    }

    [Binding]
    public class CompareFlags
    {
        public IWebElement PageTitle { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainCmprFlag-span-compareFlags']")); } }
        public IWebElement BackToRecord { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainCmprFlag-span-backToRecord']")); } }
    }


    [Binding]
    public class FRMMemberInfo
    {
        public IWebElement PageTitle { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='membrInfo-span-membrInfo']")); } }
        public IWebElement BackToRecord { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='membrInfo-span-backToRecord']")); } }
    }

    [Binding]
    public class GenerateReport
    {
        public IWebElement PageTitle { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Generate Report')]")); } }
    }

    [Binding]
    public class FRMFilesProcessingStatus
    {
        public IWebElement PageTitle { get { return Browser.Wd.FindElement(By.XPath("//*[@id='mainContant']/div[1]/div/div[1]/span")); } }
        public IWebElement NextButton { get { return Browser.Wd.FindElement(By.LinkText("Next")); } }
        public IWebElement LastButton { get { return Browser.Wd.FindElement(By.LinkText("Last")); } }
        public IWebElement PreviousButton { get { return Browser.Wd.FindElement(By.LinkText("Previous")); } }
        public IWebElement FirstButton { get { return Browser.Wd.FindElement(By.LinkText("First")); } }

        public IWebElement FilePrcessingPaginationNext { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='notesPaging']/li[3]")); } }
        public IWebElement FilePrcessingPaginationPrevious { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='notesPaging']/li[2]")); } }
        public IWebElement FilePrcessingPaginationFirst { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='notesPaging']/li[1]")); } }
        public IWebElement FilePrcessingPaginationLast { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='notesPaging']/li[4]")); } }

    }

    [Binding]
    public class AdjustDiscrepancy
    {
        public IWebElement AdjustDiscrepancyTitle { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainAdjDisc-span-adjustDiscrepancy']")); } }
       
    }

    [Binding]
    public class ManageDiscrepancyStatusCode
    {
        public IWebElement AddCodeButton { get { return Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='manageDiscrStatusCode-grid-manageDiscrepancyStatusCodeGrid']//a[contains(.,'ADD NEW')]")); } }
        public IWebElement StatusCodeTextbox { get { return Browser.Wd.FindElement(By.XPath("//input[@value='dataItem.Value']")); } }
        //public IWebElement StatusCodeTextbox { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='DiscrepancyStatusCodeGrid']//input[@class='editable-input form-control ng-pristine ng-invalid ng-invalid-required ng-touched']")); } }
        public IWebElement SaveButton { get { return Browser.Wd.FindElement(By.XPath("//input[@value='dataItem.Value']/parent::td/following-sibling::td//span[@class='fas fa-save']")); } }
        public IWebElement Cancelbutton { get { return Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='manageDiscrStatusCode-grid-manageDiscrepancyStatusCodeGrid']//td/input/parent::td/following-sibling::td//span[@class='fas fa-ban']")); } }
        public IWebElement ManageDiscrepancyStatusCodeTable { get { return Browser.Wd.FindElement(By.Id("DiscrepancyStatusCodeGrid")); } }
        public IWebElement DiscrepancyReasonCode { get { return Browser.Wd.FindElement(By.XPath("//div[@id='ReasonCode']//table[@class='table table-bordered table-hover table-condensed table-striped col-lg-12 col-md-12 col-sm-12 col-xs-12']/tbody")); } }
        public IWebElement FirstRecordEditbutton { get { return Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='manageDiscrStatusCode-grid-manageDiscrepancyStatusCodeGrid']//td//span[@class='fas fa-pencil-alt'])[1]")); } }
        public IWebElement DuplicateErrorMsg { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='DiscrepancyStatusCodeGrid']//span[2]/div/div")); } }
        public IWebElement Deletebutton { get { return Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='manageDiscrStatusCode-grid-manageDiscrepancyStatusCodeGrid']//tr[1]/td[2]/a[2]")); } }
    }

    [Binding]
    public class FRMMemberPaymentSummary
    {
        public IWebElement BackToRecordbutton { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='membrPaySumry-span-backToRecord']")); } }
        public IWebElement PageTitle { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='membrPaySumry-span-membrPaySumry']")); } }
        public IWebElement HICNumber { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='forms_MemberPaySummary']//div[1][@class='col-lg-6 col-md-6 col-sm-6 col-xs-6 ng-binding']")); } }
        public IWebElement Name { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='forms_MemberPaySummary']//div[2][@class='col-lg-6 col-md-6 col-sm-6 col-xs-6 ng-binding']")); } }
        public IWebElement PartC { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='membrPaySumry-btn-btnPartC']")); } }
        public IWebElement PartD { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='membrPaySumry-btn-btnPartD']")); } }
        public IWebElement GenerateReport { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='membrPaySumry-btn-generateReport']")); } }
        public IWebElement PaymentMonthBar { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id= 'membrPaySumry-cnvs-myChart'][1]")); } }
    }


    [Binding]
    public class ExportMonthlyExtracttofile
    {
        public IWebElement ExportMonthlyExtractPlanID { get { return Browser.Wd.FindElement(By.Id("exportplanID")); } }
        public IWebElement ExportMonthlyExtractFromDate { get { return Browser.Wd.FindElement(By.Id("fromDate")); } }
        public IWebElement ExportMonthlyExtractToDate { get { return Browser.Wd.FindElement(By.Id("toDate")); } }
        public IWebElement ExportMonthlyExtractExportButton { get { return Browser.Wd.FindElement(By.Id("exportExtractbtnUpdate")); } }
        public IWebElement ExportMonthlyExtractEndDateLabel { get { return Browser.Wd.FindElement(By.Id("lblSetDateID")); } }
        public IWebElement ExportMonthlyExtractResetButton { get { return Browser.Wd.FindElement(By.Id("exportExtractbtnReset")); } }
        public IWebElement OperationTerminateToolTip { get { return Browser.Wd.FindElement(By.XPath("//*[@id='toast-container']/div/div/div")); } }

    }


    [Binding]
    public class BatchEnrollDisEnroll
    {
        public IWebElement BatchEnrollDisEnrollRequirement { get { return Browser.Wd.FindElement(By.XPath("//div[@class='col-lg-8 col-md-8 col-sm-12 col-xs-12']/div[@class='col-lg-12 col-md-12 col-sm-12 col-xs-12 FormTitle']")); } }
        public IWebElement BatchFlagChangeFileRequirements { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='batchUpdateFlagChange']/div")); } }
        public IWebElement BatchUpdateProcessingTitle { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='mainContant']//span[@class='col-lg-12 col-md-12 col-sm-12 col-xs-12 padding0']")); } }
        public IWebElement HICBatchEnrollDisEnrollRequirement { get { return Browser.Wd.FindElement(By.XPath("//div[@id='batchUpdateHicChange']/div")); } }
        public IWebElement FlagBatchEnrollDisEnrollRequirement { get { return Browser.Wd.FindElement(By.XPath("//*[@id='batchUpdateFlagChange']/div")); } }
        public IWebElement EnrollDisEnrollRequirement { get { return Browser.Wd.FindElement(By.XPath("//div[@id='batchUpdateFlagChange']/div")); } }



    }

    [Binding]
    public class FRMEnrollDisenrollMember
    {
        public static IWebElement EnrollDisenrollMemberLink { get { return Browser.Wd.FindElement(By.LinkText("Enroll/Disenroll Member")); } }
        public static IWebElement EnrollDisenrollMemberHeader { get { return Browser.Wd.FindElement(By.Id("myLargeModalLabel")); } }
        public static IWebElement BackToRecord { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='frmEnrollDisenroll-span-backToRecord']")); } }
    }

    [Binding]
    public class FRMMMRHistory
    {
        public IWebElement MMRHistoryBackToRecordbutton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainMMRHistory-span-backToRecord']")); } }
        public IWebElement MMRHistoryTitle { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'MMR History')]")); } }
        public IWebElement MMRHistoryTable { get { return Browser.Wd.FindElement(By.XPath("//*[@ng-show='frmMMRHistory.mmrHistoryList.MMRHistoryPartC.length>0']//table[@class='col-lg-12 col-md-12 col-sm-12 col-xs-12 table table-striped']")); } }
        public IWebElement partCRadioButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainMMRHistory-rdo-partValue1']")); } }
        public IWebElement partDRadioButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainMMRHistory-rdo-partValue2']")); } }
        public IWebElement mmrHistoryTable { get { return Browser.Wd.FindElement(By.XPath("//table[@class='col-lg-12 col-md-12 col-sm-12 col-xs-12 table table-striped']")); } }
        public IWebElement mmrHistoryPartDTable { get { return Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='membrPayDetail-grid-paymentHistory']//div[@role='grid']")); } }
        public IWebElement mmrHistoryPartCTable { get { return Browser.Wd.FindElement(By.CssSelector("col-lg-12.col-md-12.col-sm-12.col-xs-12.table.table-striped")); } }
        public IWebElement BackToRecord { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainMMRHistory-span-backToRecord']")); } }
    }

    [Binding]
    public class FRMHICChangeHistory
    {
        public IWebElement HICChangeHistoryTitle { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'MBI Change History')]")); } }
        public IWebElement HICChangeHistoryBackToRecord { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='lblHicChangeHistory'][@class='modal-title']")); } }
        public IWebElement HICChangeHistoryBackToRecordbutton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hicChangeHist-span-backToRec']")); } }
        public IWebElement HICChangeHistoryReportMon { get { return Browser.Wd.FindElement(By.Id("ddlReportMonth")); } }
        public IWebElement HICChangeHistoryPartD { get { return Browser.Wd.FindElement(By.XPath("//label[@for='rpd']")); } }
        public IWebElement HICChangeHistoryPartC { get { return Browser.Wd.FindElement(By.XPath("//label[@for='rpc']")); } }
    }

    [Binding]
    public class FRMMemberSummary
    {
        public IWebElement MemberSummaryHIC { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'HIC Number')]/following-sibling::span")); } }
        public IWebElement MemberSummarySurname { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Surname')]/following-sibling::span")); } }
        public IWebElement MemberSummaryRXID { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'RX ID')]/following-sibling::span")); } }
        public IWebElement MemberSummaryMemberID { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Member ID')]/following-sibling::span")); } }
        public IWebElement MemberSummaryFirstName { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'FI')]/following-sibling::span")); } }
        public IWebElement MemberSummaryTitle { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Member Summary')]")); } }
    }

    [Binding]
    public class FRMAdministrator
    {
        public IWebElement FRMAdministrationMenu { get { return Browser.Wd.FindElement(By.CssSelector("[title='Administration']")); } }
        public IWebElement FRMFileProcessingStatusMenu { get { return Browser.Wd.FindElement(By.CssSelector("[title='Job Processing Status']")); } }
        public IWebElement FRMAdjustDiscrepancyLink { get { return Browser.Wd.FindElement(By.LinkText("Adjust Discrepancy")); } }
        public IWebElement FRMEnrollDisenrollLink { get { return Browser.Wd.FindElement(By.LinkText("Enroll/Disenroll Member")); } }
        public IWebElement FRMViewSection { get { return Browser.Wd.FindElement(By.CssSelector("//*[@id='MemberSumary']/div[1]/div[1]/label")); } }
        public IWebElement FRMAdministratorChangeIndividualHICmenu { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Change Individual MBI')]")); } }
        public IWebElement FRMAdministratorManagePlanAdjustmentReasonsmenu { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Manage Plan Adjustment Reasons')]")); } }
        public IWebElement FRMAdministratorManageDiscrepancyStatusCodemenu { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Manage Discrepancy Status Code')]")); } }
        public IWebElement FRMAdministratorWorkfowAssignmentmenu { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Workflow Assignment')]")); } }
        public IWebElement FRMHomemenu { get { return Browser.Wd.FindElement(By.CssSelector("[title='Main']")); } }
        public IWebElement FRMFileProcessingmenu { get { return Browser.Wd.FindElement(By.CssSelector("[title='Job Processing Status']")); } }
        public IWebElement FRMFileProcessingmenu1 { get { return Browser.Wd.FindElement(By.XPath("//a[@title='Job Processing Status']")); } }
        public IWebElement FRMReportManagermenu { get { return Browser.Wd.FindElement(By.XPath("//a[@title='Report Manager']")); } }
        public static IWebElement ExistingNumberHicID { get { return Browser.Wd.FindElement(By.Id("existingNumberHicID")); } }
        public IWebElement workflowDiscrepanciesID { get { return Browser.Wd.FindElement(By.Id("workflowDiscrepanciesID")); } }
        public IWebElement workflowMembersID { get { return Browser.Wd.FindElement(By.Id("workflowMembersID")); } }
        public static IWebElement NewNumberHicID { get { return Browser.Wd.FindElement(By.Id("newNumberHicID")); } }
        public IWebElement ReasonHicID { get { return Browser.Wd.FindElement(By.Id("reasonCode")); } }
        public IWebElement Updatebutton { get { return Browser.Wd.FindElement(By.Id("individualbtnUpdate")); } }
        public IWebElement ChangeHICWarningYes { get { return Browser.Wd.FindElement(By.Id("confirmationDialogYes")); } }
        public static IWebElement ReasonDropdown { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='changeIndHIC-select-reasonHicID']//span[@class='k-select']")); } }

        public IWebElement Errormessage { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='changeIndHIC-lbl-errorMessage']")); } }

        public IWebElement Sucessmessage { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='changeIndHIC-lbl-oldHic']")); } }
        public IWebElement ChangeIndividualHICResetbutton { get { return Browser.Wd.FindElement(By.Id("individualbtnReset")); } }
        public IWebElement ManagePlanAdjustmentReasonsTable { get { return Browser.Wd.FindElement(By.CssSelector(".table.table-striped.tableIcons24")); } }
        public IWebElement ManageDiscrepancyStatusCodeTable { get { return Browser.Wd.FindElement(By.Id("DiscrepancyStatusCodeGrid")); } }
        public IWebElement PlanStarRatingsTable { get { return Browser.Wd.FindElement(By.CssSelector(".table.table-striped.tableIcons24")); } }
       // public IWebElement PlanStarRatingsmenu { get { return Browser.Wd.FindElement(By.CssSelector("a[title='Plan Star Ratings']")); } }
        public IWebElement PlanStarRatingsmenu { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Plan Star Ratings')]")); } }
        public IWebElement ChangePlanIDmenu { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Change Plan ID')]")); } }
        public IWebElement ManagePlanAdjustmentReasonsAddReasonButton { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='managePlanAdjReason-grid-managePlanAdjReasonGrid']/kendo-grid-toolbar/a")); } }
        //public IWebElement ManagePlanAdjustmentReasonsAddReasonButton { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='mainContant']//i[@class='fa fa-plus-circle verticalBottom']")); } }
        public IWebElement ManagePlanAdjustmentReasonsNewReasonTextbox { get { return Browser.Wd.FindElement(By.XPath("//input[@value='dataItem.Value']")); } }
        public IWebElement ManagePlanAdjustmentReasonsSaveButton { get { return Browser.Wd.FindElement(By.XPath("//span[@class='fas fa-save']")); } }
        public IWebElement ChangePlanHICNumber { get { return Browser.Wd.FindElement(By.Id("planNumberHicID")); } }
        public IWebElement ChangePlanPartC { get { return Browser.Wd.FindElement(By.Id("changePlanCID")); } }
        public IWebElement NewPlanIDDropdown { get { return Browser.Wd.FindElement(By.Id("drpPlan")); } }
        public IWebElement ChangePlanPartD { get { return Browser.Wd.FindElement(By.Id("changePlanDID")); } }
        public IWebElement ChangePlanAddNewbutton { get { return Browser.Wd.FindElement(By.Name("btnAddNote")); } }
        public IWebElement ChangePlanAddButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='changePlanId-btn-add']")); } }
        public IWebElement ChangePlanRemoveButton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='changePlanId-btn-remove']")); } }
        public IWebElement ChangePlanReset { get { return Browser.Wd.FindElement(By.Id("changePlanbtnReset")); } }
        public IWebElement ChangePlanSave { get { return Browser.Wd.FindElement(By.Id("changePlanbtnSave")); } }

        // Work Flow 

        public IWebElement WorkFlowAssignmentBatchofDes { get { return Browser.Wd.FindElement(By.XPath("//*[@id='workflowDiscrepanciesInputID']")); } }
        public IWebElement WorkFlowAssignmentBatchofMembers { get { return Browser.Wd.FindElement(By.XPath("//*[@id='workflowMembersInputID']")); } }
        public IWebElement WorkFlowAssignmentAssignSpecUser { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='workflowUserID']/label/span/span")); } }
        public IWebElement WorkFlowAssignmentUpdateStatus { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='workFlowAssignmnt-redio-SubTaskOption']")); } }
        public IWebElement WorkFlowAssignmentAssignSpecUserAndUpdatetatus { get { return Browser.Wd.FindElement(By.XPath("//*[@id='workflowUserStatusInputID']")); } }
        public IWebElement WorkFlowAssignmentDescrepancyType { get { return Browser.Wd.FindElement(By.Id("workflowDiscrepancyTypeSelectID")); } }
        public IWebElement WorkFlowAssignmentPaymentMonths { get { return Browser.Wd.FindElement(By.Id("workflowPaymentFromSelectID")); } }
        public IWebElement WorkFlowAssignmentStatus { get { return Browser.Wd.FindElement(By.Id("workflowStatus1SelectID")); } }
        public IWebElement WorkFlowAssignmentFromUser { get { return Browser.Wd.FindElement(By.Id("workflowUserFrmSelectID")); } }
        public IWebElement WorkFlowAssignmentPlanID { get { return Browser.Wd.FindElement(By.Id("workflowPlanSelectID")); } }
        public IWebElement WorkFlowAssignmentPBPID { get { return Browser.Wd.FindElement(By.Id("workflowPbpSelectID")); } }
        public IWebElement WorkFlowAssignmentAgeofDescrepancy { get { return Browser.Wd.FindElement(By.Id("workflowAgeSelectID")); } }
        public IWebElement WorkFlowAssignmentAssignedUser { get { return Browser.Wd.FindElement(By.XPath("//select[@data-ng-model='selectedWorkflow.User']")); } }
        public IWebElement WorkFlowAssignmentDiscrepancyStatus { get { return Browser.Wd.FindElement(By.XPath("//select[@data-ng-model='selectedWorkflow.SelectedStatus']")); } }
        public IWebElement WorkFlowAssignmentSavebutton { get { return Browser.Wd.FindElement(By.Id("workflowbtnSave")); } }
        public IWebElement WorkFlowAssignmentResetbutton { get { return Browser.Wd.FindElement(By.Id("workflowbtnReset")); } }
        public IWebElement WorkFlowAssignmentStaticMsg { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='mainContant']//div[@class='col-lg-12 col-md-12 col-sm-12 col-xs-12 successHeader']/label")); } }
        public IWebElement WorkFlowAssignmentCrossButton { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='mainContant']//i[@class='fa fa-times closeMessage']")); } }
        public IWebElement WorkFlowDiscrepancytoSpecificUser { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='workflowStatusID']/label/span/span")); } }
        public IWebElement WorkFlowDiscrepancyStatus { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='workflowStatusID1']/label/span/span")); } }
        public IWebElement WorkFlowUpdateDiscrepancyStatusandassigntoSpecificUser { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='workflowUserStatusID1']/label/span/span")); } }


        // Plan Star ratings
        public IWebElement PlanStarTable { get { return Browser.Wd.FindElement(By.XPath("//table[@class=' table table-striped tableIcons24']")); } }
        public IWebElement PlanStarPlanID { get { return Browser.Wd.FindElement(By.Id("planId")); } }
        public IWebElement PlanStarYear { get { return Browser.Wd.FindElement(By.Id("mmrRangeToId")); } }
        public IWebElement PlanStarGoButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planStarRating-btn-Go']")); } }
        public IWebElement PlanStarResetButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planStarRating-btn-Reset']")); } }
        public IWebElement PlanStarEditIconButton { get { return Browser.Wd.FindElement(By.CssSelector(".fa.fa-edit")); } }
        public IWebElement PlanStarDropdown { get { return Browser.Wd.FindElement(By.XPath("//*[@id='StarRating']")); } }
        public IWebElement PlanStarRatingCancelbutton { get { return Browser.Wd.FindElement(By.XPath("(//span[@class='fas fa-ban'])[1]")); } }
        public IWebElement PlanStarRatingSavebutton { get { return Browser.Wd.FindElement(By.XPath("(//span[@class='fas fa-save'])[1]")); } }
        public IWebElement PlanStarRatingPaginationTextRight { get { return Browser.Wd.FindElement(By.XPath("//input[@role='spinbutton']")); } }
        public IWebElement PlanStarRatingPaginationTextRightNew { get { return Browser.Wd.FindElement(By.XPath("//input[@class='ng-valid ng-dirty ng-valid-parse ng-touched']")); } }
        public IWebElement PlanStarRatingPaginationNext { get { return Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']")); } }
        public IWebElement PlanStarRatingPaginationPrevious { get { return Browser.Wd.FindElement(By.XPath("//a[@title='Go to the previous page']")); } }
        public IWebElement PlanStarRatingPaginationFirst { get { return Browser.Wd.FindElement(By.XPath("//a[@title='Go to the first page']")); } }
        public IWebElement PlanStarRatingPaginationLast { get { return Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")); } }

        // Extracts
        public IWebElement MMRExtractsTitle { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'MMR Extract')]")); } }
        public IWebElement MemberPremiumExtract { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Member Premium Extract')]")); } }

    }


    [Binding]
    public class FRMMainNavigation
    {
        
 public static IWebElement confirmationDialog { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")); } }
        public static IWebElement FRMAdministratormenu { get { return Browser.Wd.FindElement(By.CssSelector("[title='Administration']")); } }
        public static IWebElement FRMAdministratorExtracts { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Extracts')]")); } }
        public static IWebElement FRMAdministartorExtractsmenu { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Extracts')]")); } }
        //  public static IWebElement FRMAdministartorExtractsmenuMMRExtractSubmenu { get { return Browser.Wd.FindElement(By.CssSelector("a[href='#/tms/frm/mmrExtract']")); } }
        public static IWebElement FRMAdministartorExtractsmenuMMRExtractSubmenu { get { return Browser.Wd.FindElement(By.LinkText("MMR Extract")); } }
        public static IWebElement FRMAdministartorExtractsmenupremiumMemberExtractSubmenu { get { return Browser.Wd.FindElement(By.CssSelector("a[href='#/tms/frm/premiumMemberExtract']")); } }
        public static IWebElement FRMAdministartormenubatchEnrollDisenroll { get { return Browser.Wd.FindElement(By.CssSelector("a[href='#/batchEnrollDisenroll")); } }
        public static IWebElement FRMAdministartormenuchangeindividualHIC { get { return Browser.Wd.FindElement(By.CssSelector("a[href='#/tms/frm/changeIndividualHIC")); } }
        //public static IWebElement FRMAdministartormenubatchUpdate { get { return Browser.Wd.FindElement(By.XPath("//a[@title='Batch Update']")); } }
        public static IWebElement FRMAdministartormenubatchUpdate { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Batch Update')]")); } }
        public static IWebElement ChangePlanIDLink { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Change Plan ID ')]")); } }
        public static IWebElement FRMAdministartormenuchangePlanId { get { return Browser.Wd.FindElement(By.CssSelector("a[href='#/tms/frm/changePlanID")); } }
        public static IWebElement FRMAdministartormenudeleteOldDiscrepancies { get { return Browser.Wd.FindElement(By.CssSelector("a[href='#/tms/frm/deleteOldDiscrepancies")); } }
        public static IWebElement FRMAdministartormenuerrorLog { get { return Browser.Wd.FindElement(By.CssSelector("a[href='#/tms/frm/errorLog")); } }
        public static IWebElement FRMAdministartormenuexportMonthlyExtract { get { return Browser.Wd.FindElement(By.CssSelector("a[title='Export Monthly Extract to file']")); } }
        public static IWebElement FRMAdministartormenumanageBidToolRates { get { return Browser.Wd.FindElement(By.CssSelector("a[title='Manage Bid Tool Rates']")); } }
        public static IWebElement FRMAdministartormenumanageDiscrepancyStatusCode { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Manage Discrepancy Status Code ')]")); } }
        public static IWebElement FRMAdministartormenumanagePlanAdjustmentReasons { get { return Browser.Wd.FindElement(By.CssSelector("a[href='#/tms/frm/managePlanAdjustmentReasons")); } }
        public static IWebElement FRMAdministartormenuplanStarRatings { get { return Browser.Wd.FindElement(By.CssSelector("a[title='Plan Star Ratings']")); } }
        public static IWebElement FRMAdministartormenurunEnrollmentCheck { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Run Enrollment Check')]")); } }
        public static IWebElement FRMAdministartormenuworkFlowAssignment { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Workflow Assignment')]")); } }
        public static IWebElement PageTitle { get { return Browser.Wd.FindElement(By.CssSelector("[class='flex-fill'] div")); } }
    }


    [Binding]
    public class FRMMainGeneralSearch
    {
        //General Search Controls
        public static IWebElement GeneralSearchFirstButton { get { return Browser.Wd.FindElement(By.XPath("(//a[@title='Go to the first page'])[1]")); } }
        public static IWebElement GeneralSearchLastButton { get { return Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")); } }
        public static IWebElement GeneralSearchLastLink { get { return Browser.Wd.FindElement(By.LinkText("Last")); } }
        public static IWebElement GeneralSearchLastNameSortLink { get { return Browser.Wd.FindElement(By.XPath("//*[@id='generalGrid']//span[contains(.,'Last Name')]")); } }
    }

    [Binding]
    public class FRMHICorNameSearch
    {
        public static IWebElement HICNextLink { get { return Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']")); } }
        public static IWebElement HICPreviousLink { get { return Browser.Wd.FindElement(By.CssSelector("a[title='Go to the previous page']")); } }
        public static IWebElement HICPreviousButton { get { return Browser.Wd.FindElement(By.XPath("//li[@class='pagination-prev ng-scope']/a")); } }
        //public static IWebElement HICFirstButton { get { return Browser.Wd.FindElement(By.CssSelector("li.pagination-first.ng-scope a.ng-binding")); } }
        public static IWebElement HICFirstButton { get { return Browser.Wd.FindElement(By.CssSelector("a[title='Go to the first page']")); } }
        public static IWebElement HICLastButton { get { return Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")); } }

    }

    [Binding]
    public class FRMHICSearchResult
    {
        public static IWebElement ViewHyperLink { get { return Browser.Wd.FindElement(By.CssSelector(".icon-bullet_18px")); } }
        public static IWebElement ReasonCodeHyperLink { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='paymentHistory']//a[@data-target='#ReasonCode']/i")); } }
        public static IWebElement ReasonCodeLable { get { return Browser.Wd.FindElement(By.XPath("//a/i[@class='ml-2 fas fa-question-circle']")); } }
        public static IWebElement MemberSummaryTable { get { return Browser.Wd.FindElement(By.CssSelector(".ui-grid-header.ng-scope")); } }
        public static IWebElement PaymentDetailsTable { get { return Browser.Wd.FindElement(By.Id("payMonthPartDetails")); } }
        public static IWebElement AddNoteButton { get { return Browser.Wd.FindElement(By.CssSelector("button[name='btnAddNote")); } }
    }

    public class FRMWorkFlowPage
    {
        public static IWebElement DiscrepancytoSpecificUser { get { return Browser.Wd.FindElement(By.XPath("//label[@for='workflowUserInputID1']")); } }
        public static IWebElement DiscrepancyStatusNew { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='workflowUserStatusInputID1']")); } }
        public static IWebElement UpdateDiscrepancyStatusandassigntoSpecificUser { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='workflowUserStatusID1']/label")); } }
        public static IWebElement BatchOfDiscrepanciesRadioButton { get { return Browser.Wd.FindElement(By.XPath("//*[@id='workflowDiscrepanciesID']/label/span/span")); } }
        public static IWebElement BatchofMembersRadioButton { get { return Browser.Wd.FindElement(By.XPath("//*[@id='workflowMembersID']/label/span")); } }
        public static IWebElement AssigntoSpecificUserRadioButton { get { return Browser.Wd.FindElement(By.XPath("//*[@id='workflowUserID']/label/span")); } }
        public static IWebElement UpdateStatusRadioButton { get { return Browser.Wd.FindElement(By.XPath("//*[@id='workflowStatusID']/label/span/span")); } }
        public static IWebElement AssignSpecifiedUserUpdateStatusRadioButton { get { return Browser.Wd.FindElement(By.XPath("//*[@id='workflowUserStatusID']/label/span/span")); } }
        public static IWebElement DiscrepancyTypeDropdown { get { return Browser.Wd.FindElement(By.Id("workflowDiscrepancyTypeSelectID")); } }
        public static IWebElement PlanIDDropdown { get { return Browser.Wd.FindElement(By.Id("workflowPlanSelectID")); } }
        public static IWebElement PBPDropdown { get { return Browser.Wd.FindElement(By.Id("workflowPbpSelectID")); } }
        public static IWebElement PaymentMonthsDropdown { get { return Browser.Wd.FindElement(By.Id("workflowPaymentFromSelectID")); } }
        public static IWebElement AgeofDiscrepancyDropdown { get { return Browser.Wd.FindElement(By.Id("workflowAgeSelectID")); } }
        public static IWebElement StatusDropdown { get { return Browser.Wd.FindElement(By.Id("workflowStatus1SelectID")); } }
        public static IWebElement StatusDropdownNew { get { return Browser.Wd.FindElement(By.XPath(".//select[@data-ng-change='AssignDiscrepancyStatus()']")); } }
        public static IWebElement DiscrepancyStatus { get { return Browser.Wd.FindElement(By.Id("workflowUserFrmSelectID")); } }
        public static IWebElement FRMUserDropdown { get { return Browser.Wd.FindElement(By.Id("workflowUserFrmSelectID")); } }
        public static IWebElement SaveButton { get { return Browser.Wd.FindElement(By.Id("workflowbtnSave")); } }
        public static IWebElement ResetButton { get { return Browser.Wd.FindElement(By.Id("workflowbtnReset")); } }
        public static IWebElement SuccessMessage { get { return Browser.Wd.FindElement(By.XPath("//*[@id='mainContant']/div/div[1]/div[2]/div[1]")); } }
        public static IWebElement SuccessMessageOnWorkflow { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='workFlowAssignmnt-lbl-Success']")); } }

    }


    public class FRMDeleteDiscrepancyPage
    {
        public static IWebElement PaymentDateFromDropdown { get { return Browser.Wd.FindElement(By.Id("discrepanciesFromId")); } }
        public static IWebElement PaymentDateToDropdown { get { return Browser.Wd.FindElement(By.Id("discrepanciesToId")); } }
        public static IWebElement DiscrepancyTypeDropdown { get { return Browser.Wd.FindElement(By.Id("discrepancyTypeId")); } }
        public static IWebElement DiscrepancyPlanDropdown { get { return Browser.Wd.FindElement(By.Id("discrepancyPlanId")); } }
        public static IWebElement DiscrepancyPlanResetButton { get { return Browser.Wd.FindElement(By.Id("discrepancyPlanbtnReset")); } }
        public static IWebElement DiscrepancyPlanDeleteButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='delOldDiscr-btn-delete']")); } }
    }

    public class FRMDiscrepancyReasonCodePage
    {
        public static IWebElement BackToRecordLable { get { return Browser.Wd.FindElement(By.XPath("//div[@id='ReasonCode']//span[@class='col-sm-8 col-lg-8 col-md-8 col-xs-8']")); } }
        public static IWebElement ReasonCodeLable { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='reasonCode-lbl-reasonTitle']")); } }
        public static IWebElement DefinitionLable { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='forms_CompareFlag']/div/form/div/table/thead/tr/th[2]")); } }
        public static IWebElement ReasonCodeTextbox { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='reason-inp-txtReason']")); } }
        public static IWebElement ReasonCodeTable { get { return Browser.Wd.FindElement(By.CssSelector(".table-striped.col-lg-12.col-md-12.col-sm-12.col-xs-12")); } }
        public static IWebElement MoreOption { get { return Browser.Wd.FindElement(By.ClassName("fa.fa-ellipsis-h")); } }
        public static IWebElement EditCheckbox { get { return Browser.Wd.FindElement(By.Id("workstatus.Id")); } }
        public static IWebElement SaveChangesButton { get { return Browser.Wd.FindElement(By.CssSelector("button[class='btn.primaryButton")); } }
        public static IWebElement SelectStatusDropdown { get { return Browser.Wd.FindElement(By.CssSelector("editable-input.form-control.ng-pristine.ng-valid.ng-valid-required.ng-touched")); } }
        public static IWebElement SelectUserDropdown { get { return Browser.Wd.FindElement(By.CssSelector("editable-input.form-control.ng-pristine.ng-untouched.ng-valid.ng-valid-required")); } }
        public static IWebElement ApplytoSelectedmonthonlyRadio { get { return Browser.Wd.FindElement(By.CssSelector("label[for='radio01']")); } }
        public static IWebElement BackToRecordsButton { get { return Browser.Wd.FindElement(By.XPath("//pay-month//i[@class='fa fa-chevron-circle-left']")); } }
        public static IWebElement AddNoteButton { get { return Browser.Wd.FindElement(By.CssSelector("button[name='btnAddNote")); } }
        public static IWebElement moreLink { get { return Browser.Wd.FindElement(By.XPath("(//div[@id='paymentHistory']//i[@class='fa fa-eye'])[1]")); } }
        public static IWebElement PaymentHistoryViewLink { get { return Browser.Wd.FindElement(By.XPath("(//div[@id='paymentHistory']//a[@title='View'])[1]")); } }

    }

    public class FRMChangeIndividualHIC
    {
        public static IWebElement ResetButton { get { return Browser.Wd.FindElement(By.Id("individualbtnReset")); } }
    }

    [Binding]
    public class ManagePlanPBPInfo
    {

        public static IWebElement PlanLevelTab { get { return Browser.Wd.FindElement(By.XPath("//li[@id='k-tabstrip-tab-0']/span")); } }
        public static IWebElement PBPLevelTab { get { return Browser.Wd.FindElement(By.XPath("//li[@id='k-tabstrip-tab-1']/span")); } }
        public static IWebElement SegmentLevelTab { get { return Browser.Wd.FindElement(By.XPath("//li[@id='k-tabstrip-tab-2']/span")); } }
        public static IWebElement EditAll { get { return Browser.Wd.FindElement(By.XPath("//button[text()= ' EDIT ALL ' ]")); } }
        public static IWebElement AddButton { get { return Browser.Wd.FindElement(By.XPath("//button[text()=' ADD ']")); } }
        public static IWebElement DepatmentName { get { return Browser.Wd.FindElement(By.Id("planLevelDepartment")); } }
        public static IWebElement TollFreeNumber { get { return Browser.Wd.FindElement(By.XPath("//kendo-maskedtextbox[@test-id='planLevel-input-PhoneNumber']/input")); } }
        public static IWebElement Address1 { get { return Browser.Wd.FindElement(By.Id("planLevelAddress1")); } }
        public static IWebElement Address2 { get { return Browser.Wd.FindElement(By.Id("planLevelAddress2")); } }
        public static IWebElement City { get { return Browser.Wd.FindElement(By.Id("planLevelCity")); } }
        public static IWebElement State { get { return Browser.Wd.FindElement(By.Id("planLevelState")); } }
        public static IWebElement Zip { get { return Browser.Wd.FindElement(By.Id("zip")); } }
        public static IWebElement EditAllWindow { get { return Browser.Wd.FindElement(By.XPath("//i[contains(@title,'Only the values')]")); } }
        public static IWebElement UpdateButton { get { return Browser.Wd.FindElement(By.Id("btnAdd")); } }
        public static IWebElement CancelButton { get { return Browser.Wd.FindElement(By.Id("btnReset")); } }
        public static IWebElement BackToRecordLink { get { return Browser.Wd.FindElement(By.XPath("//span[@test-id='pbpLevel-span-back']")); } }
        public static IWebElement FirstCheckBox { get { return Browser.Wd.FindElement(By.XPath("//tr[@data-kendo-grid-item-index='0']/td[@aria-colindex='1']/input")); } }
        public static IWebElement SecondCheckBox { get { return Browser.Wd.FindElement(By.XPath("//tr[@data-kendo-grid-item-index='1']/td[@aria-colindex='1']/input")); } }

        public static IWebElement AddPlanId { get { return Browser.Wd.FindElement(By.XPath("//input[@formcontrolname='planId']")); } }
        public static IWebElement AddPlanType { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@formcontrolname='planType']//span[@class='k-select']")); } }
        public static IWebElement AddPlanName { get { return Browser.Wd.FindElement(By.XPath("//input[@formcontrolname='planName']")); } }
        public static IWebElement AddDeliveryMethod { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@formcontrolname='deliveryMethod']//span[@class='k-select']")); } }
        public static IWebElement AddBusinessState { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@formcontrolname='businessState']//span[@class='k-select']")); } }
        public static IWebElement AddAddress1 { get { return Browser.Wd.FindElement(By.XPath("//input[@formcontrolname='address1']")); } }
        public static IWebElement AddZip { get { return Browser.Wd.FindElement(By.XPath("//input[@formcontrolname='zip']")); } }
        public static IWebElement AddCity { get { return Browser.Wd.FindElement(By.XPath("//input[@formcontrolname='state']")); } }
        public static IWebElement AddState { get { return Browser.Wd.FindElement(By.XPath("//input[@formcontrolname='city']")); } }
        public static IWebElement AddEffectiveDate { get { return Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@formcontrolname='effectiveDate']//span[@role='button']")); } }
        public static IWebElement AddTermDate { get { return Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@formcontrolname='expDate']//span[@role='button']")); } }
        public static IWebElement AddPartDEffectiveDate { get { return Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@formcontrolname='partdEffectiveDate']//span[@role='button']")); } }
        public static IWebElement AddPartDTermDate { get { return Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@formcontrolname='partdTermDate']//span[@role='button']")); } }
        public static IWebElement AddSaveButton { get { return Browser.Wd.FindElement(By.Id("btnSave")); } }
        public static IWebElement AddDepartmentName { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='planLevel-input-departmentName']")); } }



    }

    [Binding]
    public class FRMMainPage
    {
        public IWebElement FRMMainWindow { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_UpdatePanel1")); } }
        public IWebElement ALLButton { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='ctl00_MainContent_rbPartALL']")); } }
        public IWebElement PartCButton { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_rbPartC")); } }
        public IWebElement PartDButton { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_rbPartD")); } }
        public IWebElement DiscrepancyTypeDD { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_ddDiscpType")); } }
        public IWebElement FilterbyPaymentMonthsFrom { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_ddFromDate")); } }
        public IWebElement FilterbyPaymentMonthsTo { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_ddTodate")); } }
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_ddPlanID")); } }
        public IWebElement PBP { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_ddPBP")); } }
        public IWebElement GRPIPA { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_ddIPA")); } }
        public IWebElement Status { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_ddStatus")); } }
        public IWebElement AgeOfDiscrepancy { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_ddDispAge")); } }
        public IWebElement User { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_ddUser")); } }
        public IWebElement Search { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_btnSearch")); } }
        public IWebElement ResetFilter { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_btnReset")); } }
        public IWebElement MIPlanID { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_lblPlanID")); } }
        public IWebElement MIHIC { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_lblHic")); } }
        public IWebElement MIMemberID { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_lblMember")); } }
        public IWebElement MIPlandefined2 { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='ctl00_MainContent_UpdatePanel1']/fieldset/table[1]/tbody/tr[4]/td[2]")); } }
        public IWebElement MIRxID { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_lblRxID")); } }
        public IWebElement MISurname { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_lblSurName")); } }
        public IWebElement MIFi { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_lblFI")); } }
        public IWebElement MIPlandefined1 { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='ctl00_MainContent_UpdatePanel1']/fieldset/table[1]/tbody/tr[4]/td[1]")); } }
        public IWebElement MIPartCOverUnder { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_lblPartcOU")); } }
        public IWebElement MIParDOverUnder { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_lblPartdOU")); } }
        public IWebElement MIFindByHicName { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_ibtSearch")); } }
        public IWebElement MISortbyClaim { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_RadioSort_0")); } }
        public IWebElement MISortbyName { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_RadioSort_1")); } }
        public IWebElement MIViewmembernotes { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_ImgViewNotes")); } }
        public IWebElement MICMS { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_btnCMS")); } }
        public IWebElement MIDisplypayments { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_btnTopFify")); } }
        public IWebElement MIDisplayAdjustmentWizard { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_ibtAdjustWizard")); } }
        public IWebElement MIDisplayEnrollDisenrollWizard { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_ImgDisEnrlment")); } }
        public IWebElement MIPaymentMonthsTable { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_GridMain")); } }
        public IWebElement MIDisplayMemberInfo { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_ibtMemberInfo")); } }
        public IWebElement MIDefineReasonCodes { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_ibtDisplayReasonCodes")); } }
        public IWebElement MIDisplayMemberReport { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_imgReportGroup")); } }
        //public IWebElement MICMS { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_btnCMS")); } }
        public IWebElement GeneralSearchPartAllOption { get { return Browser.Wd.FindElement(By.Id("rdbAll")); } }
        public IWebElement GeneralSearchPartPartCOption { get { return Browser.Wd.FindElement(By.Id("rdbC")); } }
        public IWebElement GeneralSearchPartPartDOption { get { return Browser.Wd.FindElement(By.Id("rdbD")); } }

        public IWebElement GeneralSearchPartPartDOptionBtn { get { return Browser.Wd.FindElement(By.XPath("//label[@for='rdbD']/span/span")); } }
        public IWebElement GeneralSearchPaymentMonthsFromDropdown { get { return Browser.Wd.FindElement(By.Id("drpPayFrom")); } }
        public IWebElement GeneralSearchPaymentMonthsToDropdown { get { return Browser.Wd.FindElement(By.Id("drpPayTo")); } }
        public IWebElement GeneralSearchPBPDropdown { get { return Browser.Wd.FindElement(By.Id("drpPbp")); } }
        public IWebElement GeneralSearchStatusDropdown { get { return Browser.Wd.FindElement(By.Id("drpStatus")); } }
        public IWebElement GeneralSearchUserDropdown { get { return Browser.Wd.FindElement(By.Id("drpUser")); } }
        public IWebElement GeneralSearchDiscrepancyTypeDropdown { get { return Browser.Wd.FindElement(By.Id("drpDescTypeCD")); } }
        public IWebElement GeneralSearchDiscrepancyTypeAllDropdown { get { return Browser.Wd.FindElement(By.Id("drpDescType")); } }
        public IWebElement GeneralSearchDiscrepancyTypeDropdown_ESI { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='genSearchCrt-select-drpDescTypeCD']")); } }        
        public IWebElement GeneralSearchPlanIDDropdown { get { return Browser.Wd.FindElement(By.Id("drpPlan")); } }
        public IWebElement GeneralSearchGRPIPADropdown { get { return Browser.Wd.FindElement(By.Id("drpIpa")); } }
        public IWebElement GeneralSearchAgeofDiscrepancyDropdown { get { return Browser.Wd.FindElement(By.Id("drpAge")); } }
        public IWebElement GeneralSearchSearchButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='genSearchCrt-btn-btnSearch']")); } }
        public IWebElement FRMHeader { get { return Browser.Wd.FindElement(By.CssSelector("span[test-id='header-title-applicationName']")); } }
       
        //    public IWebElement GeneralSearchSearchButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='generalSearchCriteria-btn-Search']")); } }

        public IWebElement GeneralSearchResetButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='genSearchCrt-btn-btnReset']")); } }
        public IWebElement GeneralSearchSearchCriteriaAccordion { get { return Browser.Wd.FindElement(By.LinkText("Search Criteria")); } }
        public IWebElement GeneralSearchSearchCResultAccordion { get { return Browser.Wd.FindElement(By.LinkText("Result")); } }
        public IWebElement GeneralSearchSearchResults { get { return Browser.Wd.FindElement(By.XPath("//div[@class='ui-grid-canvas']")); } }
        public IWebElement GeneralPrevSearchSearchResults { get { return Browser.Wd.FindElement(By.XPath("//div[@id='hicnameGrid']//div[@class='ui-grid-canvas']")); } }
        public IWebElement GeneralSearchRestorePrevSearch { get { return Browser.Wd.FindElement(By.Id("chkRestorePrev")); } }
        public IWebElement GeneralSearchPagination { get { return Browser.Wd.FindElement(By.Id("grneralSearchPaging")); } }
        public IWebElement Top50DiscrepancyTypeDropdown { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Discrepancy Type')]/parent::div//span[@class='k-select'])[2]")); } }
        public IWebElement Top50PaymentMonthsFromDropdown { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Payment Month From')]/parent::div//span[@class='k-select'])[2]")); } }
        public IWebElement Top50PaymentMonthsToDropdown { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Payment Month To')]/parent::div//span[@class='k-select'])[2]")); } }
        public IWebElement Top50PlanIDDropdown { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Plan ID')]/parent::div//span[@class='k-select'])[2]")); } }
        public IWebElement Top50SearchButton { get { return Browser.Wd.FindElement(By.Id("topfiftySearch")); } }
        public IWebElement Top50ResetButton { get { return Browser.Wd.FindElement(By.Id("topfifyReset")); } }
        public IWebElement Top50SearchCriteriaAccordion { get { return Browser.Wd.FindElement(By.LinkText("Search Criteria")); } }
        public IWebElement Top50SearchResultsAccordion { get { return Browser.Wd.FindElement(By.LinkText("Result")); } }
        public IWebElement Top50OverUnderPaymentTab { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Top 50 Over/Under Payment')]")); } }
        public IWebElement Top50SearchOverPaymentButton { get { return Browser.Wd.FindElement(By.Id("topfifyOverPayment")); } }
        public IWebElement Top50SearchUnderPaymentButton { get { return Browser.Wd.FindElement(By.Id("Button1")); } }
        public IWebElement Top50SearchUnderOverPaymentResults { get { return Browser.Wd.FindElement(By.XPath("//div[@data-ui-grid='topfiftyResultGrid']")); } }
        public IWebElement Top50SearchPagination { get { return Browser.Wd.FindElement(By.XPath("//ul[@ng-change='pageChangedTopGrd()']")); } }
        public IWebElement HICNameSearchTab { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'MBI/Name Search')]")); } }
        public IWebElement PaginationFirstButtonDisable { get { return Browser.Wd.FindElement(By.CssSelector("li.pagination-first ng-scope disabled")); } }
        public IWebElement PaginationPreviousButtonEnable { get { return Browser.Wd.FindElement(By.CssSelector("li.pagination-prev ng-scope")); } }
        public IWebElement PaginationNextButtonEnable { get { return Browser.Wd.FindElement(By.CssSelector("li.pagination-next ng-scope")); } }
        public IWebElement PaginationLastButtonEnable { get { return Browser.Wd.FindElement(By.CssSelector("li.pagination-last ng-scope")); } }
        public IWebElement PaginationLastButtonDisable { get { return Browser.Wd.FindElement(By.CssSelector("li.pagination-last ng-scope disabled")); } }
        public IWebElement ProductExpandButton { get { return Browser.Wd.FindElement(By.Id("expanButton")); } }
        public IWebElement ProductSelectBox { get { return Browser.Wd.FindElement(By.Id("dropdownProduct")); } }
        public IWebElement informationButton { get { return Browser.Wd.FindElement(By.Id("infoButton")); } }
        public IWebElement databaseText { get { return Browser.Wd.FindElement(By.XPath("//*[@id='TMSAdminHeading']//li[contains(., 'FRM_530R3')]")); } }



        //HIC Name Search Controls
        public IWebElement HICNameSearchClaimHIC { get { return Browser.Wd.FindElement(By.Id("txtHic")); } }
        public IWebElement HICNameSearchLastName { get { return Browser.Wd.FindElement(By.Id("txtLastName")); } }
        public IWebElement HICNameSearchRecordsFromCompleteDB { get { return Browser.Wd.FindElement(By.CssSelector("[id='Radio1']")); } }
        public IWebElement HICNameSearchRecordsFromPrevGenSrch { get { return Browser.Wd.FindElement(By.CssSelector("[id='Radio2']")); } }
        public IWebElement HICNameSearchResetbutton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hicNameSearchCriteria-btn-btnReset']")); } }
        public IWebElement HICNameSearchSearchbutton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='hicNameSearchCriteria-btn-btnSearch']")); } }
        public IWebElement HICNameSearchSearchCriteriaAccordion { get { return Browser.Wd.FindElement(By.LinkText("Search Criteria")); } }
        public IWebElement HICNameSearchSearchCriteriaNEWAccordion { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='frmMainAccordion']//div[3]//i[@class='fa fa-caret-right']")); } }
        public IWebElement HICNameSearchResultsAccordion { get { return Browser.Wd.FindElement(By.LinkText("Result")); } }
        //public IWebElement HICNameSearchResults { get { return Browser.Wd.FindElement(By.Id("hicnameGrid")); } }
        // public IWebElement HICNameSearchResults { get { return Browser.Wd.FindElement(By.XPath("//div[@id='hicnameGrid']//div[@class='ui-grid-row ng-scope']")); } }
        public IWebElement HICNameSearchResults { get { return Browser.Wd.FindElement(By.XPath("//div[@id='hicnameGrid']")); } }

        public IWebElement HICNameSearchPagination { get { return Browser.Wd.FindElement(By.Id("HicNameSearchPaging")); } }
        public IWebElement HICNameSearchResultsPaneViewLink { get { return Browser.Wd.FindElement(By.XPath("(//span[@title='View'])[1]")); } }
        public IWebElement MemberSummaryViewCompareFlags { get { return Browser.Wd.FindElement(By.LinkText("Compare Flags")); } }
        public IWebElement MemberSummaryViewMemberInfo { get { return Browser.Wd.FindElement(By.LinkText("Member Info.")); } }
        public IWebElement MemberSummaryViewMemberPaymentSummary { get { return Browser.Wd.FindElement(By.LinkText("Member Payment Summary")); } }
        public IWebElement MemberSummaryViewHICChangeHistory { get { return Browser.Wd.FindElement(By.LinkText("MBI Change History")); } }
        public IWebElement MemberSummaryViewMMRHistory { get { return Browser.Wd.FindElement(By.LinkText("MMR History")); } }
        public IWebElement MemberSummaryToolsAdjustDiscrepancy { get { return Browser.Wd.FindElement(By.LinkText("Adjust Discrepancy")); } }
        public IWebElement MemberSummaryToolsEnrollDisenroll { get { return Browser.Wd.FindElement(By.LinkText("Enroll/Disenroll Member")); } }
        public IWebElement MemberSummaryToolGenerateReport { get { return Browser.Wd.FindElement(By.LinkText("Generate Report")); } }
        public IWebElement MemberSummaryReasonCode { get { return Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='membrPayDetail-grid-paymentHistory']//span[@class='ng-star-inserted']//i[@class='ml-2 fas fa-question-circle']")); } }
        public IWebElement MemberSummaryReasonCodeTable { get { return Browser.Wd.FindElement(By.XPath("//form[@class='shell-form ng-pristine ng-valid']//table[@class='table table-bordered table-hover table-condensed table-striped col-lg-12 col-md-12 col-sm-12 col-xs-12']")); } }
        public IWebElement PaymentHistoryTable { get { return Browser.Wd.FindElement(By.Id("paymentHistory")); } }
        public IWebElement NotesPaging { get { return Browser.Wd.FindElement(By.Id("notesPaging")); } }
        public IWebElement AddNoteButton { get { return Browser.Wd.FindElement(By.XPath("//button[contains(.,'ADD NEW RECORD')]")); } }
        public IWebElement AddNoteTextArea { get { return Browser.Wd.FindElement(By.XPath("//input[@name='note']")); } }
        public IWebElement ActionDueDate { get { return Browser.Wd.FindElement(By.XPath("(//input[@data-role='datepicker'])[1]")); } }
        public IWebElement ActionCompleteDate { get { return Browser.Wd.FindElement(By.XPath("(//input[@data-role='datepicker'])[2]")); } }
        public IWebElement NotesSaveButton { get { return Browser.Wd.FindElement(By.XPath("//span[@class='fas fa-save']")); } }
        public IWebElement NotesCancelButton { get { return Browser.Wd.FindElement(By.XPath("//button[@title='cancel']")); } }
        public IWebElement NotesTable { get { return Browser.Wd.FindElement(By.XPath("//member-payment-details[@class='ng-scope']//div[@data-ng-controller='frmMainPaymentHistoryGridController']//table[@class='table table-bordered table-hover table-condensed table-striped col-lg-12 col-md-12 col-sm-12 col-xs-12 marginBottom0']")); } }

        //Member Information
        public IWebElement MemberSummaryHIC { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'MBI Number')]/following-sibling::span")); } }
        public IWebElement MemberSummaryFirstName { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'First Name')]/following-sibling::span")); } }
        public IWebElement MemberSummarySurName { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Surname')]/following-sibling::span")); } }
        public IWebElement MemberSummaryDOB { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'DOB:')]/following-sibling::span")); } }
        public IWebElement MemberSummaryRXID { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'RX ID')]/following-sibling::span")); } }
        public IWebElement MemberSummaryMemberID { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Member ID')]/following-sibling::span")); } }
        public IWebElement MemberSummarySex { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Sex')]/following-sibling::span")); } }
        public IWebElement MemberSummarySSN { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'SSN')]/following-sibling::span")); } }
        public IWebElement MemberInfoBackToRecordButton { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id= 'membrInfo-span-backToRecord']")); } }
        public IWebElement MemberSummaryPage { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='membrPayDetail-lbl-memberSummary']")); } }
    }



}
