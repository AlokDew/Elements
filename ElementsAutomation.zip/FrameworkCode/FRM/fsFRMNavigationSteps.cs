﻿using TechTalk.SpecFlow;
using OpenQA.Selenium;

namespace TMSoR1
{
    [Binding]
    public class FRMNavigationSteps
    {
        [When(@"I Navigate to FRM ""(.*)""")]
        [Given(@"I Navigate to FRM ""(.*)""")]
        public void WhenINavigateToFRM(string p0)
        {
            FRMNavigation.ClickLink(p0);
        }


        [Given(@"I Navigate to FRM ""(.*)"" menu")]
        [Then(@"I Navigate to FRM ""(.*)"" menu")]
        [When(@"I Navigate to FRM ""(.*)"" menu")]
        public void GivenINavigateToFRMMenu(string menu)
        {
            tmsWait.Hard(10);
            IWebElement link= Browser.Wd.FindElement(By.XPath("//div[@title='" + menu+"']"));
            fw.ExecuteJavascript(link);
        }

              

        [Given(@"I Navigate to ESI FRM ""(.*)"" menu")]
        [When(@"I Navigate to ESI FRM ""(.*)"" menu")]
        public void GivenINavigateToESIFRMMenu(string menu)
        {
            tmsWait.Hard(10);
            IWebElement link = Browser.Wd.FindElement(By.XPath("//div[@title='"+ menu + "']"));
            if(menu.Equals("Reports"))
            {
                link.Click();
            }
            else
            { fw.ExecuteJavascript(link); }
            
            tmsWait.Hard(10);
            Browser.SwitchToChildWindow();
            tmsWait.Hard(3);
            Browser.Wd.Navigate().Refresh();        
            tmsWait.Hard(10);
            string reportTitle = Browser.Wd.Title;
            fw.ConsoleReport(" Current Page Title --> " + reportTitle);
        }

        [Then(@"Close Child Browser Window")]
        public void ThenCloseChildBrowserWindow()
        {
            Browser.SwitchToChildWindow().Close();
            Browser.SwitchToParentWindow();
            tmsWait.Hard(3);
        }


    }
}