﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using TMSoR1;

namespace TMSoR1.FrameworkCode.FRM.ESIFRM
{
    [Binding]
    class cfESIFRMAdministration
    {
        public static WorkflowAssignment WorkflowAssignment { get { return new WorkflowAssignment(); } }
    }
}


[Binding]
public class WorkflowAssignment
{
    public IWebElement WorkflowAssignmentmenu { get { return Browser.Wd.FindElement(By.XPath("//*[@id='fisrtLevelMenu']/li[10]/a/span")); } }

}


  