﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;

using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.FRM.ESIFRM
{
    [Binding]
    class fsESIFRMUserManagementAccess
    {
        [When(@"ESI FRM Administration Menu ""(.*)"" submenu is Clicked")]
        public void WhenESIFRMAdministrationMenuSubmenuIsClicked(string submenu)
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@title='Administration']")));
            By menu = By.XPath("//span[contains(.,'"+ submenu + "')]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(menu);
            tmsWait.Hard(2);

            
        }

        [Then(@"Verify ESI FRM ""(.*)"" page is displayed successfully")]
        public void ThenVerifyESIFRMPageIsDisplayedSuccessfully(string section)
        {
            By labelPresence = By.XPath("//div[contains(.,'"+ section + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(labelPresence);
            tmsWait.Hard(2);
        }

        [Then(@"Verify ESI FRM Administration Menu ""(.*)"" submenu is not displayed")]
        public void ThenVerifyESIFRMAdministrationMenuSubmenuIsNotDisplayed(string submenu)
        {
        By menu = By.XPath("//a[@title='" + submenu + "']");
            UIMODUtilFunctions.elementNotPresenceUsingLocators(menu);
        }

        [Then(@"Verify ESI FRM ""(.*)"" Menu is not displayed")]
        public void ThenVerifyESIFRMMenuIsNotDisplayed(string submenu)
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@title='Menu']")));
            By menu = By.XPath("//div[@title='" + submenu + "']");
            UIMODUtilFunctions.elementNotPresenceUsingLocators(menu);
        }


    }
}
