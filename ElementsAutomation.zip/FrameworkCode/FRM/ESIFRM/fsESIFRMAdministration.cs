﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.FRM.ESIFRM
{
    [Binding]
    class fsESIFRMAdministration
    {


        [When(@"User navigates to Administration > Workflow Assignment")]
        public void WhenUserNavigatesToAdministrationWorkflowAssignment()
        {

            fw.ExecuteJavascript(cfESIFRMAdministration.WorkflowAssignment.WorkflowAssignmentmenu);
            tmsWait.Hard(2);
        }

        [Then(@"Verify that user is navigated to ""(.*)"" page")]
        public void ThenVerifyThatUserIsNavigatedToPage(string p0)
        {


            string AdminFRMPage = p0.ToString();
            string PageDisplayed;
            By loc;
            switch (AdminFRMPage.ToLower())
            {
                case "administration - workflow assignment":
                    tmsWait.Hard(10);
                    loc = By.XPath("//*[@id='mainContant']/div[1]/div/div[1]/span");

                    PageDisplayed = Browser.Wd.FindElement(loc).Text;
                    Assert.AreEqual(PageDisplayed.ToLower(), AdminFRMPage.ToLower(), "User is not navigated to Workflow Assignment Page");
                    break;

            } }



        [Then(@"Verify that radio button ""(.*)"" is selected by default")]

       
        public void ThenVerifyThatRadioButtonIsSelectedByDefault(string p0)
        {
            
            string defaultmenu;
           string radioclass;
            Boolean flag;

            defaultmenu = p0.ToString();
            

          IWebElement  locradiobutton = Browser.Wd.FindElement(By.XPath("//input[@test-id='workFlowAssignmnt-radio-workflowDiscrepanciesInputID']"));
            flag=locradiobutton.Selected;


            switch (defaultmenu.ToLower())
            {
                case "batch of discrepancies":
                    radioclass = locradiobutton.GetAttribute("class");

                    Assert.IsTrue(radioclass.Contains("ng-valid-parse"), "Batch discrepancies Radio button is not selected by default");
                    break;
            }



        }



        [Then(@"Verify that ""(.*)"" Button is not present")]
        public void ThenVerifyThatButtonIsNotPresent(string p0)
        {

          
                By element = By.XPath("//button[@test-id='workFlowAssignmnt-btn-assignmentbtnCurrent']");
                UIMODUtilFunctions.elementNotPresenceUsingLocators(element);
                               


        }




    }


}