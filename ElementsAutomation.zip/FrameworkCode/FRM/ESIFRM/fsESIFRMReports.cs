﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode
{
    [Binding]
    class fsESIFRMReports
    {
        [Then(@"Download PDF report")]
        public void ThenDownloadPDFReport()
        {

            By saveLoc = By.XPath("//span[@class='glyphui glyphui-save']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(saveLoc);
            tmsWait.Hard(2);
            By savePDF = By.XPath("//a[@title='PDF']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(savePDF);
            tmsWait.Hard(2);

        }

        [Then(@"Download CSV report")]
        public void ThenDownloadCSVReport()
        {
            By saveLoc = By.XPath("//span[@class='glyphui glyphui-save']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(saveLoc);
            tmsWait.Hard(2);
            By saveCSV = By.XPath("//a[@title='CSV (comma delimited)']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(saveCSV);
        }


        [Then(@"Download XLS report")]
        public void ThenDownloadXLSReport()
        {
            By saveLoc = By.XPath("//span[@class='glyphui glyphui-save']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(saveLoc);
            tmsWait.Hard(2);
            By saveXLS = By.XPath("//a[@title='Excel']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(saveXLS);
        }



        [When(@"Reporting Service Web Portal Page ""(.*)"" Folder is Clicked")]
        public void WhenReportingServiceWebPortalPageFolderIsClicked(string p0)
        {
            tmsWait.Hard(3);
            string folder = tmsCommon.GenerateData(p0);

            switch (folder)
            {
                case "Member":
                    fw.ExecuteJavascript(cfESIFRMReports.ESIReportWebPortal.MemberFolder);
                    break;
                case "Workflow":
                    fw.ExecuteJavascript(cfESIFRMReports.ESIReportWebPortal.WorkFlowFodler);
                    break;
                case "Financial":
                    fw.ExecuteJavascript(cfESIFRMReports.ESIReportWebPortal.FinancialFodler);
                    break;

                case "Discrepancy Type - Roster":
                    fw.ExecuteJavascript(cfESIFRMReports.ESIReportWebPortal.DiscrepancyTypeRosterFodler);
                    break;

                case "Discrepancy Type - Flag":
                    fw.ExecuteJavascript(cfESIFRMReports.ESIReportWebPortal.DiscrepancyTypeFlagFodler);
                    break;

                case "Compliance":
                    fw.ExecuteJavascript(cfESIFRMReports.ESIReportWebPortal.ComplianceFodler);
                    break;




            }
        }


        [When(@"Member Folder ""(.*)"" Report is Clicked")]
        public void WhenMemberFolderReportIsClicked(string p0)
        {
            tmsWait.Hard(3);
            string report = tmsCommon.GenerateData(p0);

            switch (report)
            {
                case "Monthly Discrepancy Summary - By Payment Month":
                    fw.ExecuteJavascript(cfESIFRMReports.MemberFolder.MemberMonthlyDiscrepancySummaryByPaymentMonthReport);
                    break;

                case "Transaction By MBI":
                    fw.ExecuteJavascript(cfESIFRMReports.MemberFolder.MemberMonthlyDiscrepancySummaryByPaymentMonthReport);
                    break;
                case "Part D - By MBI":
                    fw.ExecuteJavascript(cfESIFRMReports.DiscrepancyTypeFlagPartDESI.PartDByMBIReport);
                    break;
                case "Part D - By Name":
                    fw.ExecuteJavascript(cfESIFRMReports.DiscrepancyTypeFlagPartDESI.PartDByNameReport);
                    break;
                case "Part D - By Planid":
                    fw.ExecuteJavascript(cfESIFRMReports.DiscrepancyTypeFlagPartDESI.PartDByPlanIDReport);
                    break;
                case "Discrepancy Type Summary - Part C":
                    fw.ExecuteJavascript(cfESIFRMReports.FinancialFolder.DiscrepancyTypeSummarypartCReport);
                    break;
                case "Discrepancy Type Summary - Part D":
                    fw.ExecuteJavascript(cfESIFRMReports.FinancialFolder.DiscrepancyTypeSummarypartDReport);
                    break;

            }



        }

        [When(@"Workflow Folder ""(.*)"" Report is Clicked")]
        public void WhenWorkflowFolderReportIsClicked(string p0)
        {
            string report = tmsCommon.GenerateData(p0);

            switch (report)
            {
                case "Workflow Aging Detail":
                    fw.ExecuteJavascript(cfESIFRMReports.WorkflowFolder.WorkflowAgingDetailReport);
                    break;
                case "Workflow Aging Summary":
                    fw.ExecuteJavascript(cfESIFRMReports.WorkflowFolder.WorkflowAgingSummaryReport);
                    break;
            }
        }

        [When(@"Execute provided SQL Query ""(.*)"" and Get MBI Detail")]
        public void WhenExecuteProvidedSQLQueryAndGetMBIDetail(string query)
        {
            string MBI = singleColumnQueryExecutionSelectRecordBasedOnIndex(query, "EAMWarehouse", 1);
            fw.ConsoleReport(" MBI --> " + MBI);
            GlobalRef.FRMMBI = MBI;
        }

        [When(@"Reports Page View Report button is Clicked")]
        public void WhenReportsPageViewReportButtonIsClicked()
        {
            fw.ExecuteJavascript(cfESIFRMReports.WorkflowFolder.ViewReportBtn);
            tmsWait.Hard(10);
        }

        [When(@"Discrepancy Type Summary Part C Reports page View Report button is Clicked")]
        public void WhenDiscrepancyTypeSummaryPartCReportsPageViewReportButtonIsClicked()
        {
            fw.ExecuteJavascript(cfESIFRMReports.FinancialFolder.ViewReportButton);
            tmsWait.Hard(10);
        }

        [When(@"Reports Page ""(.*)"" drop down list is set to ""(.*)""")]
        public void WhenReportsPageDropDownListIsSetTo(string p0, string p1)
        {
            string drpValue = tmsCommon.GenerateData(p0);
            string Value = tmsCommon.GenerateData(p1);

            switch (drpValue)
            {
                case "From Payment Month":

                    ReUsableFunctions.selectValueFromDropDown(cfESIFRMReports.WorkflowFolder.FromPaymentMonthDrp, Value);
                    break;
                case "To Payment Month":
                    ReUsableFunctions.selectValueFromDropDown(cfESIFRMReports.WorkflowFolder.ToPaymentMonthDrp, Value);
                    break;
                case "Plan ID":
                    ReUsableFunctions.selectValueFromDropDown(cfESIFRMReports.WorkflowFolder.PlanIDDrp, Value);
                    break;
                case "Discrepancy Type":
                    ReUsableFunctions.legacyDropDownListSelection(cfESIFRMReports.WorkflowFolder.DiscrepancyTypeDrp, Value);
                    break;
                case "Discrepancy Status":
                    ReUsableFunctions.legacyDropDownListSelection(cfESIFRMReports.WorkflowFolder.DiscrepancyStatusDrp, Value);
                    break;
                case "Age Category":
                    ReUsableFunctions.legacyDropDownListSelection(cfESIFRMReports.WorkflowFolder.AgeCategoryDrp, Value);
                    break;

            }
            tmsWait.Hard(3);
        }
        [Then(@"we need to Switch to Reports IFrame")]
        public void ThenWeNeedToSwitchToReportsIFrame()
        {
            Browser.SwitchToIFrame();
        }

        [Then(@"Verify SQL Server Reporting Services displayed ""(.*)"" Report Folder")]
        public void ThenVerifySQLServerReportingServicesDisplayedReportFolder(string p0)
        {
            By report = By.XPath("//span[@class='multiline-ellipsis ng-binding'][contains(.,'" + p0 + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(report);
        }



        [Then(@"Verify WorkFlow Aging Detail Reports displayed Plan ID")]
        public void ThenVerifyWorkFlowAgingDetailReportsDisplayedPlanID()
        {
            string planID = GlobalRef.PlanID.ToString();
            bool planIDDisplay = Browser.Wd.FindElement(By.XPath("//div[@id='ReportViewerControl_ctl09']//table[contains(.,'" + planID + "')]")).Displayed;
            Assert.IsTrue(planIDDisplay, "Expeced Plan ID is not displayed ");
        }
        [Then(@"Verify WorkFlow Aging Detail Reports displayed Claim")]
        public void ThenVerifyWorkFlowAgingDetailReportsDisplayedClaim()
        {
            string planID = GlobalRef.HIC.ToString();
            bool planIDDisplay = Browser.Wd.FindElement(By.XPath("//div[@id='ReportViewerControl_ctl09']//table[contains(.,'" + planID + "')]")).Displayed;
            Assert.IsTrue(planIDDisplay, "Expeced HIC ID is not displayed ");
        }

        [Then(@"Verify WorkFlow Aging Detail Reports displayed Age")]
        public void ThenVerifyWorkFlowAgingDetailReportsDisplayedAge()
        {
            string planID = GlobalRef.AGE.ToString();
            bool planIDDisplay = Browser.Wd.FindElement(By.XPath("//div[@id='ReportViewerControl_ctl09']//table[contains(.,'" + planID + "')]")).Displayed;
            Assert.IsTrue(planIDDisplay, "Expeced AGE is not displayed ");
        }

        [When(@"Execute provided SQL Query ""(.*)"" and Store Plan ID data in SpecFlow Variable")]
        public void WhenExecuteProvidedSQLQueryAndStorePlanIDDataInSpecFlowVariable(string query)
        {
            string planID = singleColumnQueryExecutionSelectRecordBasedOnIndex(query, "EAMWarehouse", 0);
            fw.ConsoleReport(" Plan ID --> " + planID);
            GlobalRef.PlanID = planID;
        }
        [When(@"Execute provided SQL Query ""(.*)"" and Store claim data in SpecFlow Variable")]
        public void WhenExecuteProvidedSQLQueryAndStoreClaimDataInSpecFlowVariable(string query)
        {
            string claim = singleColumnQueryExecutionSelectRecordBasedOnIndex(query, "EAMWarehouse", 0);
            fw.ConsoleReport(" HIC --> " + claim);
            GlobalRef.HIC = claim;
        }
        [When(@"Execute provided SQL Query ""(.*)"" and Store ""(.*)"" data in SpecFlow Variable")]
        public void WhenExecuteProvidedSQLQueryAndStoreDataInSpecFlowVariable(string query, string p1)
        {
            string data = singleColumnQueryExecutionSelectRecordBasedOnIndex(query, "EAMWarehouse", 0);

            ScenarioContext.Current["" + p1 + ""] = data;
        }
        [When(@"Execute provided SQL Query ""(.*)"" on DB ""(.*)""")]
        public void WhenExecuteProvidedSQLQueryOnDB(string query, string db)
        {
            string queryres = query.Replace("DBNAME", db);
            ReUsableFunctions.ExecuteSimpleSQLQuery(queryres, db);
        }
        [Then(@"Verify executed SQL Query ""(.*)"" on DB ""(.*)"" return value as ""(.*)""")]
        public void ThenVerifyExecutedSQLQueryOnDBReturnValueAs(string query, string db, string expValue)
        {
            string actualValue;
            string queryres = query.Replace("DBNAME", db);
            actualValue = ReUsableFunctions.ExecuteSimpleSQLQueryReturnValue(queryres, db);
            fw.ConsoleReport(" Query Returned Value " + actualValue);
            Assert.AreEqual(expValue, actualValue, "Both values are not matching");
        }

        [When(@"Dashboard page Workflow Tracking section ""(.*)"" section is Clicked")]
        public void WhenDashboardPageWorkflowTrackingSectionSectionIsClicked(string p0)
        {
            By part = By.XPath("//div[@active='dashBoard.activeWorkflowTrackingTabIndex']//a[contains(.,'" + p0 + "')]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(part);
            tmsWait.Hard(2);
        }

        [When(@"Dashboard page (.*) Days Compliance Reporting section ""(.*)"" section is Clicked")]
        public void WhenDashboardPageDaysComplianceReportingSectionSectionIsClicked(int p0, string p1)
        {
            By part = By.XPath("//div[@active='dashBoard.activeComplianceTabIndex']//a[contains(.,'" + p1 + "')]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(part);
            tmsWait.Hard(2);
        }

        [Then(@"Verify Workflow Part C Section displayed Top Five User Assigned and Discrepancy Count record by executing SQL ""(.*)"" on DB ""(.*)""")]
        public void ThenVerifyWorkflowPartCSectionDisplayedTopFiveUserAssignedAndDiscrepancyCountRecordByExecutingSQLOnDB(string query, string DB)
        {
            ArrayList actList = new ArrayList();
            fsRSMLogin DBquery = new fsRSMLogin();
            actList = DBquery.ExecuteSQLQueryUsingSQL2017(query, DB);
            if (actList.Count != 0)
            {

                By firstRec = By.XPath("//div[@test-id='dashBoard-div-workflowTrackingPartCdata']//div[contains(.,'" + actList[0] + "')]/parent::div/following-sibling::div/div[contains(.,'" + actList[1] + "')]");
                Assert.IsTrue(ReUsableFunctions.elementDisplayed(firstRec), " Element is not displayed");
                fw.ConsoleReport(actList[0] + " --->" + actList[1]);

                By secondRec = By.XPath("//div[@test-id='dashBoard-div-workflowTrackingPartCdata']//div[contains(.,'" + actList[2] + "')]/parent::div/following-sibling::div/div[contains(.,'" + actList[3] + "')]");
                Assert.IsTrue(ReUsableFunctions.elementDisplayed(secondRec), " Element is not displayed");
                fw.ConsoleReport(actList[2] + " --->" + actList[3]);

                By thirdRec = By.XPath("//div[@test-id='dashBoard-div-workflowTrackingPartCdata']//div[contains(.,'" + actList[4] + "')]/parent::div/following-sibling::div/div[contains(.,'" + actList[5] + "')]");
                Assert.IsTrue(ReUsableFunctions.elementDisplayed(thirdRec), " Element is not displayed");
                fw.ConsoleReport(actList[4] + " --->" + actList[5]);
            }
            else
            {
                fw.ConsoleReport(" There is Part C records");
            }
        }

        [Then(@"Verify (.*) Days Compliance Reporting Part D section displayed Top Five User Assigned and Discrepancy Count record by executing SQL ""(.*)"" on DB ""(.*)""")]
        public void ThenVerifyDaysComplianceReportingPartDSectionDisplayedTopFiveUserAssignedAndDiscrepancyCountRecordByExecutingSQLOnDB(int p0, string query, string DB)
        {
            ArrayList actList = new ArrayList();
            fsRSMLogin DBquery = new fsRSMLogin();
            actList = DBquery.ExecuteSQLQueryUsingSQL2017(query, DB);

            if (actList.Count != 0)
            {

                By firstRec = By.XPath("//div[@test-id='dashBoard-div-complianceDataD']//div[contains(.,'" + actList[0] + "')]/parent::div/following-sibling::div/div[contains(.,'" + actList[1] + "')]");
                Assert.IsTrue(ReUsableFunctions.elementDisplayed(firstRec), " Element is not displayed");
                fw.ConsoleReport(actList[0] + " --->" + actList[1]);
                By secondRec = By.XPath("//div[@test-id='dashBoard-div-complianceDataD']//div[contains(.,'" + actList[2] + "')]/parent::div/following-sibling::div/div[contains(.,'" + actList[3] + "')]");
                Assert.IsTrue(ReUsableFunctions.elementDisplayed(secondRec), " Element is not displayed");
                fw.ConsoleReport(actList[2] + " --->" + actList[3]);
                By thirdRec = By.XPath("//div[@test-id='dashBoard-div-complianceDataD']//div[contains(.,'" + actList[4] + "')]/parent::div/following-sibling::div/div[contains(.,'" + actList[5] + "')]");
                Assert.IsTrue(ReUsableFunctions.elementDisplayed(thirdRec), " Element is not displayed");
                fw.ConsoleReport(actList[4] + " --->" + actList[5]);
                //By fourthRec = By.XPath("//div[@test-id='dashBoard-div-complianceDataD']//div[contains(.,'" + actList[6] + "')]/parent::div/following-sibling::div/div[contains(.,'" + actList[7] + "')]");
                //Assert.IsTrue(ReUsableFunctions.elementDisplayed(fourthRec), " Element is not displayed");
                //fw.ConsoleReport(actList[6] + " --->" + actList[7]);
                //By fifthRec = By.XPath("//div[@test-id='dashBoard-div-complianceDataD']//div[contains(.,'" + actList[8] + "')]/parent::div/following-sibling::div/div[contains(.,'" + actList[9] + "')]");
                //Assert.IsTrue(ReUsableFunctions.elementDisplayed(fifthRec), " Element is not displayed");
                //fw.ConsoleReport(actList[8] + " --->" + actList[9]);
            }
            else
            {
                fw.ConsoleReport(" There is no Part D record");
            }
        }

        [Then(@"Verify (.*) Days Compliance Reporting Part C section displayed Top Five User Assigned and Discrepancy Count record by executing SQL ""(.*)"" on DB ""(.*)""")]
        public void ThenVerifyDaysComplianceReportingPartCSectionDisplayedTopFiveUserAssignedAndDiscrepancyCountRecordByExecutingSQLOnDB(int p0, string query, string DB)
        {
            ArrayList actList = new ArrayList();
            fsRSMLogin DBquery = new fsRSMLogin();
            actList = DBquery.ExecuteSQLQueryUsingSQL2017(query, DB);

            if (actList.Count != 0)
            {

                By firstRec = By.XPath("//div[@test-id='dashBoard-div-complianceData']//div[contains(.,'" + actList[0] + "')]/parent::div/following-sibling::div/div[contains(.,'" + actList[1] + "')]");
                Assert.IsTrue(ReUsableFunctions.elementDisplayed(firstRec), " Element is not displayed");
                fw.ConsoleReport(actList[0] + " --->" + actList[1]);
                By secondRec = By.XPath("//div[@test-id='dashBoard-div-complianceData']//div[contains(.,'" + actList[2] + "')]/parent::div/following-sibling::div/div[contains(.,'" + actList[3] + "')]");
                Assert.IsTrue(ReUsableFunctions.elementDisplayed(secondRec), " Element is not displayed");
                fw.ConsoleReport(actList[2] + " --->" + actList[3]);
                By thirdRec = By.XPath("//div[@test-id='dashBoard-div-complianceData']//div[contains(.,'" + actList[4] + "')]/parent::div/following-sibling::div/div[contains(.,'" + actList[5] + "')]");
                Assert.IsTrue(ReUsableFunctions.elementDisplayed(thirdRec), " Element is not displayed");
                fw.ConsoleReport(actList[4] + " --->" + actList[5]);
                //By fourthRec = By.XPath("//div[@test-id='dashBoard-div-complianceData']//div[contains(.,'" + actList[6] + "')]/parent::div/following-sibling::div/div[contains(.,'" + actList[7] + "')]");
                //Assert.IsTrue(ReUsableFunctions.elementDisplayed(fourthRec), " Element is not displayed");
                //fw.ConsoleReport(actList[6] + " --->" + actList[7]);
                //By fifthRec = By.XPath("//div[@test-id='dashBoard-div-complianceData']//div[contains(.,'" + actList[8] + "')]/parent::div/following-sibling::div/div[contains(.,'" + actList[9] + "')]");
                //Assert.IsTrue(ReUsableFunctions.elementDisplayed(fifthRec), " Element is not displayed");
                //fw.ConsoleReport(actList[8] + " --->" + actList[9]);
            }
        }
    


    [Then(@"Verify Workflow Part D Section displayed Top Five User Assigned and Discrepancy Count record by executing SQL ""(.*)"" on DB ""(.*)""")]
    public void ThenVerifyWorkflowPartDSectionDisplayedTopFiveUserAssignedAndDiscrepancyCountRecordByExecutingSQLOnDB(string query, string DB)
    {

        ArrayList actList = new ArrayList();
        fsRSMLogin DBquery = new fsRSMLogin();
        actList = DBquery.ExecuteSQLQueryUsingSQL2017(query, DB);

        By firstRec = By.XPath("//div[@test-id='dashBoard-div-workflowTrackingPartDdata']//div[contains(.,'" + actList[0] + "')]/parent::div/following-sibling::div/div[contains(.,'" + actList[1] + "')]");
        Assert.IsTrue(ReUsableFunctions.elementDisplayed(firstRec), " Element is not displayed");
        fw.ConsoleReport(actList[0] + " --->" + actList[1]);
        By secondRec = By.XPath("//div[@test-id='dashBoard-div-workflowTrackingPartDdata']//div[contains(.,'" + actList[2] + "')]/parent::div/following-sibling::div/div[contains(.,'" + actList[3] + "')]");
        Assert.IsTrue(ReUsableFunctions.elementDisplayed(secondRec), " Element is not displayed");
        fw.ConsoleReport(actList[2] + " --->" + actList[3]);
        By thirdRec = By.XPath("//div[@test-id='dashBoard-div-workflowTrackingPartDdata']//div[contains(.,'" + actList[4] + "')]/parent::div/following-sibling::div/div[contains(.,'" + actList[5] + "')]");
        Assert.IsTrue(ReUsableFunctions.elementDisplayed(thirdRec), " Element is not displayed");
        fw.ConsoleReport(actList[4] + " --->" + actList[5]);
        //By fourthRec = By.XPath("//div[@test-id='dashBoard-div-workflowTrackingPartDdata']//div[contains(.,'" + actList[6] + "')]/parent::div/following-sibling::div/div[contains(.,'" + actList[7] + "')]");
        //Assert.IsTrue(ReUsableFunctions.elementDisplayed(fourthRec), " Element is not displayed");
        //fw.ConsoleReport(actList[6] + " --->" + actList[7]);
        //By fifthRec = By.XPath("//div[@test-id='dashBoard-div-workflowTrackingPartDdata']//div[contains(.,'" + actList[8] + "')]/parent::div/following-sibling::div/div[contains(.,'" + actList[9] + "')]");
        //Assert.IsTrue(ReUsableFunctions.elementDisplayed(fifthRec), " Element is not displayed");
        //fw.ConsoleReport(actList[8] + " --->" + actList[9]);
    }


    [Then(@"Verify Dashboard page Displayed ""(.*)"" section")]
    public void ThenVerifyDashboardPageDisplayedSection(string p0)
    {
        string value = tmsCommon.GenerateData(p0);
        By elementDisplay;

        switch (value)
        {
            case "Payments":

                elementDisplay = By.XPath("//label[@test-id='dashBoard-lbl-Payments'][contains(.,'" + value + "')]");
                Assert.IsTrue(ReUsableFunctions.elementPresence(elementDisplay), " Element is not displayed");
                break;
            case "45 Days Compliance Reporting Part C":
                elementDisplay = By.XPath("//li[@test-id='dashBoard-tab-partC']/a[contains(.,'Part C')]");
                Assert.IsTrue(ReUsableFunctions.elementPresence(elementDisplay), " Element is not displayed");
                break;
            case "45 Days Compliance Reporting Part D":
                elementDisplay = By.XPath("//li[@test-id='dashBoard-tab-partD']/a[contains(.,'Part D')]");
                Assert.IsTrue(ReUsableFunctions.elementPresence(elementDisplay), " Element is not displayed");
                break;
            case "Workflow Tracking Part C":
                elementDisplay = By.XPath("//li[@test-id='dashBoard-tab-partC1']/a[contains(.,'Part C')]");
                Assert.IsTrue(ReUsableFunctions.elementPresence(elementDisplay), " Element is not displayed");
                break;
            case "Workflow Tracking Part D":
                elementDisplay = By.XPath("//li[@test-id='dashBoard-tab-partD1']/a[contains(.,'Part D')]");
                Assert.IsTrue(ReUsableFunctions.elementPresence(elementDisplay), " Element is not displayed");
                break;
        }
    }


    [Then(@"Verify WorkFlow Aging Summary Reports displayed Noted ""(.*)""")]
    public void ThenVerifyWorkFlowAgingSummaryReportsDisplayedNoted(string p0)
    {
        string value = tmsCommon.GenerateData(p0);
        By elementDisplay;

        switch (value)
        {
            case "Record Count":
                string recordCount = GlobalRef.Count.ToString();
                elementDisplay = By.XPath("(//div[contains(text(),'Count')]/parent::div/parent::td/parent::tr/following-sibling::tr/td[5]/div[contains(.,'" + recordCount + "')])[1]");
                ReUsableFunctions.elementPresence(elementDisplay);
                break;
            case "Age":
                string age = GlobalRef.AGE.ToString();
                elementDisplay = By.XPath("//div[contains(text(),'Count')]/parent::div/parent::td/parent::tr/following-sibling::tr/td[4]/div[contains(.,'" + age + "')]");
                ReUsableFunctions.elementPresence(elementDisplay);
                break;
        }
    }

    [When(@"Execute provided SQL Query ""(.*)"" and Store Age ID data in SpecFlow Variable")]
    public void WhenExecuteProvidedSQLQueryAndStoreAgeIDDataInSpecFlowVariable(string query)
    {
        string age = singleColumnQueryExecutionSelectRecordBasedOnIndex(query, "EAMWarehouse", 0);
        fw.ConsoleReport(" AGE --> " + age);
        GlobalRef.AGE = age;
    }


    public string singleColumnQueryExecutionSelectRecordBasedOnIndex(string SqlString, string DB, int recordIndex)
    {
        ArrayList actList = new ArrayList();
        fsRSMLogin DBquery = new fsRSMLogin();
        actList = DBquery.ExecuteSQLQueryUsingSQL2017(SqlString, DB);
        string output = actList[recordIndex].ToString();
        return output;
    }

    [When(@"Monthly Discrepancy Summary By Payment Month Report MBI value is entered")]
    public void WhenMonthlyDiscrepancySummaryByPaymentMonthReportMBIValueIsEntered()
    {
        tmsWait.Hard(3);
        string mbi = GlobalRef.FRMMBI.ToString();
        ReUsableFunctions.enterValueOnWebElementWithoutClear(cfESIFRMReports.MemberMonthlyDiscrepancySummaryByPaymentMonth.MBI, mbi);

    }

    [When(@"Monthly Discrepancy Summary By Payment Month Report Tenant value is entered")]
    public void WhenMonthlyDiscrepancySummaryByPaymentMonthReportTenantValueIsEntered()
    {

        string tenant = ((ConfigFile.URL.Split('.'))[0].Split(':'))[1].Substring(2);
        ReUsableFunctions.enterValueOnWebElement(cfESIFRMReports.MemberMonthlyDiscrepancySummaryByPaymentMonth.TenantName, tenant);
    }


}

}
