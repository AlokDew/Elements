﻿
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode
{
    [Binding]
    class cfESIFRMExports
    {

        public static CMS45DayCompliance CMS45DayCompliance { get { return new CMS45DayCompliance(); } }
        public static DiscrepancyTypeFlagPartD DiscrepancyTypeFlagPartD { get { return new DiscrepancyTypeFlagPartD(); } }
        public static Transaction Transaction { get { return new Transaction(); } }

    }

    [Binding]
    public class Transaction
    {
        public IWebElement PlanIDDropdownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='planId_listbox']")); } }
        public IWebElement DateFrom { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='exportTransaction-txt-fromdate']")); } }
        public IWebElement DateTo { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='exportTransaction-txt-todate']")); } }
        public IWebElement PaymentMonthDropdownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='payMonth_listbox']")); } }
        public IWebElement exportButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='exportCmsDay-btn-initiateExport']")); } }
    }

    [Binding]
    public class CMS45DayCompliance
    {
        public IWebElement PlanIDDropdownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='planId_listbox']")); } }
        public IWebElement PaymentMonthDropdownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='payMonth_listbox']")); } }
        public IWebElement exportButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='exportCmsDay-btn-initiateExport']")); } }
        public IWebElement resetButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='exportCmsDay-btn-reset']")); } }
    }

    [Binding]
    public class DiscrepancyTypeFlagPartD
    {
        public IWebElement PlanIDDropdownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='planId_listbox']")); } }
        public IWebElement RangeStartDropdownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='rangeStart_listbox']")); } }
        public IWebElement RangeEndDropdownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='rangeEnd_listbox']")); } }
        public IWebElement exportButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='exportDiscTypeFlagPartD-btn-initiateExport']")); } }
        public IWebElement resetButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='exportDiscTypeFlagPartD-btn-reset']")); } }
    }
    
}
