﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode
{
    [Binding]
    class cfESIFRMReports
    {
      
            public static ESIReportWebPortal ESIReportWebPortal { get { return new ESIReportWebPortal(); } }
        public static MemberMonthlyDiscrepancySummaryByPaymentMonth MemberMonthlyDiscrepancySummaryByPaymentMonth { get { return new MemberMonthlyDiscrepancySummaryByPaymentMonth(); } }
        public static MemberFolder MemberFolder { get { return new MemberFolder(); } }
        public static WorkflowFolder WorkflowFolder { get { return new WorkflowFolder(); } }
        public static DiscrepancyTypeFlagPartDESI DiscrepancyTypeFlagPartDESI { get { return new DiscrepancyTypeFlagPartDESI(); } }
        public static FinancialFolder FinancialFolder { get { return new FinancialFolder(); } }
    }

    [Binding]
    public class FinancialFolder
    {
        public IWebElement DiscrepancyTypeSummarypartCReport { get { return Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Discrepancy%20Type%20Summary%20-%20Part%20C')]//span[@class='glyphui glyphui-report']")); } }
        public IWebElement DiscrepancyTypeSummarypartDReport { get { return Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Discrepancy%20Type%20Summary%20-%20Part%20D')]//span[@class='glyphui glyphui-report']")); } }
        public IWebElement FinancialSummaryPartReport { get { return Browser.Wd.FindElement(By.XPath("(//a[contains(@href,'Financial/Financial%20Summary%20-%20Part%20D')]//span[@class='glyphui glyphui-report'])[1]")); } }
        public IWebElement ViewReportButton { get { return Browser.Wd.FindElement(By.XPath("//input[@id='ReportViewerControl_ctl04_ctl00']")); } }
    }

    [Binding]
    public class DiscrepancyTypeFlagPartDESI
    {
        public IWebElement PartDByMBIReport { get { return Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Discrepancy%20Type%20-%20Flag/Part%20D%20-%20By%20MBI')]//span[@class='glyphui glyphui-report']")); } }
        public IWebElement PartDByNameReport { get { return Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Discrepancy%20Type%20-%20Flag/Part%20D%20-%20By%20Name')]//span[@class='glyphui glyphui-report']")); } }
        public IWebElement PartDByPlanIDReport { get { return Browser.Wd.FindElement(By.XPath("//a[contains(@href,'FRM/Discrepancy%20Type%20-%20Flag/Part%20D%20-%20By%20Planid')]//span[@class='glyphui glyphui-report']")); } }
    }


        [Binding]
    public class ESIReportWebPortal
    {
        public IWebElement MemberFolder { get { return Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Member')]//span[@class='glyphui glyphui-folder']")); } }
        public IWebElement WorkFlowFodler { get { return Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Workflow')]//span[@class='glyphui glyphui-folder']")); } }

        public IWebElement FinancialFodler { get { return Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Financial')]//span[@class='glyphui glyphui-folder']")); } }

        public IWebElement ComplianceFodler { get { return Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Compliance')]//span[@class='glyphui glyphui-folder']")); } }
        public IWebElement DiscrepancyTypeFlagFodler { get { return Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Discrepancy%20Type%20-%20Flag')]//span[@class='glyphui glyphui-folder']")); } }
        public IWebElement DiscrepancyTypeRosterFodler { get { return Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Discrepancy%20Type%20-%20Roster')]//span[@class='glyphui glyphui-folder']")); } }
    }
    [Binding]
    public class MemberFolder
    {
        public IWebElement MemberMonthlyDiscrepancySummaryByPaymentMonthReport { get { return Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Member/Monthly%20Discrepancy%20Summary%20-%20By%20Payment%20Month')]")); } }
        public IWebElement TransctionByMBIReport { get { return Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Member/Transaction%20By%20MBI')]//span[@class='glyphui glyphui-report']")); } }

        

    }

    [Binding]
    public class WorkflowFolder
    {
        public IWebElement WorkflowAgingDetailReport { get { return Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Workflow/Workflow%20Aging%20Detail')]//span[@class='glyphui glyphui-report']")); } }
        public IWebElement WorkflowAgingSummaryReport { get { return Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Workflow/Workflow%20Aging%20Summary')]//span[@class='glyphui glyphui-report']")); } }
        public IWebElement FromPaymentMonthDrp { get { return Browser.Wd.FindElement(By.XPath("//div[@id='ReportViewerControl_ctl04']//select[@id='ReportViewerControl_ctl04_ctl03_ddValue']")); } }
        public IWebElement ToPaymentMonthDrp { get { return Browser.Wd.FindElement(By.XPath("//div[@id='ReportViewerControl_ctl04']//select[@id='ReportViewerControl_ctl04_ctl05_ddValue']")); } }
        public IWebElement PlanIDDrp { get { return Browser.Wd.FindElement(By.XPath("//div[@id='ReportViewerControl_ctl04']//select[@id='ReportViewerControl_ctl04_ctl07_ddValue']")); } }
        public IWebElement DiscrepancyTypeDrp { get { return Browser.Wd.FindElement(By.XPath("//div[@id='ReportViewerControl_ctl04']//select[@id='ReportViewerControl_ctl04_ctl09_ddValue']")); } }
        public IWebElement DiscrepancyStatusDrp { get { return Browser.Wd.FindElement(By.XPath("//div[@id='ReportViewerControl_ctl04']//select[@id='ReportViewerControl_ctl04_ctl11_ddValue']")); } }
        public IWebElement AgeCategoryDrp { get { return Browser.Wd.FindElement(By.XPath("//div[@id='ReportViewerControl_ctl04']//select[@id='ReportViewerControl_ctl04_ctl15_ddValue']")); } }
        public IWebElement ViewReportBtn { get { return Browser.Wd.FindElement(By.XPath("//input[@id='ReportViewerControl_ctl04_ctl00']")); } }

        


    }
    [Binding]
    public class MemberMonthlyDiscrepancySummaryByPaymentMonth
    {
        public IWebElement MBI { get { return Browser.Wd.FindElement(By.XPath("//div[@data-parametername='HICNumber']/table//input")); } }
        public IWebElement TenantName { get { return Browser.Wd.FindElement(By.XPath("//div[@data-parametername='TenantTenantName']//input")); } }
        
    }

}
