﻿
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode
{
    [Binding]
    class fsESIFRMExports
    {
        [When(@"Exports Page Exports List section ""(.*)"" link is Clicked")]
        public void WhenExportsPageExportsListSectionLinkIsClicked(string p0)
        {
            By export = By.XPath("//label[contains(.,'"+p0+"')]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(export);
        }

        [Then(@"Verify ESI FRM Export page ""(.*)"" Export ""(.*)"" is displayed")]
        public void ThenVerifyESIFRMExportPageExportIsDisplayed(string ExportType, string fields)
        {
            bool elementDisp;
           if(ExportType.Equals("CMS 45 Day Compliance"))
            {
                switch(fields)
                {
                    case "Plan Id":
                        elementDisp = cfESIFRMExports.CMS45DayCompliance.PlanIDDropdownList.Displayed;
                        Assert.IsTrue(elementDisp, " Element is not displayed");
                        break;
                    case "Pay Month":
                        elementDisp = cfESIFRMExports.CMS45DayCompliance.PaymentMonthDropdownList.Displayed;
                        Assert.IsTrue(elementDisp, " Element is not displayed");
                        break;
                    case "Reset Button":
                        elementDisp = cfESIFRMExports.CMS45DayCompliance.resetButton.Displayed;
                        Assert.IsTrue(elementDisp, " Element is not displayed");
                        break;
                    case "Export Button":
                        elementDisp = cfESIFRMExports.CMS45DayCompliance.exportButton.Displayed;
                        Assert.IsTrue(elementDisp, " Element is not displayed");
                        break;

                }
            }
            else if (ExportType.Equals("Discrepancy Type Flag Part D"))
            {
                switch (fields)
                {
                    case "Plan Id":
                        elementDisp = cfESIFRMExports.DiscrepancyTypeFlagPartD.PlanIDDropdownList.Displayed;
                        Assert.IsTrue(elementDisp, " Element is not displayed");
                        break;
                    case "Range Start":
                        elementDisp = cfESIFRMExports.DiscrepancyTypeFlagPartD.RangeStartDropdownList.Displayed;
                        Assert.IsTrue(elementDisp, " Element is not displayed");
                        break;
                    case "Range End":
                        elementDisp = cfESIFRMExports.DiscrepancyTypeFlagPartD.RangeEndDropdownList.Displayed;
                        Assert.IsTrue(elementDisp, " Element is not displayed");
                        break;
                    case "Reset Button":
                        elementDisp = cfESIFRMExports.DiscrepancyTypeFlagPartD.resetButton.Displayed;
                        Assert.IsTrue(elementDisp, " Element is not displayed");
                        break;
                    case "Export Button":
                        elementDisp = cfESIFRMExports.DiscrepancyTypeFlagPartD.exportButton.Displayed;
                        Assert.IsTrue(elementDisp, " Element is not displayed");
                        break;
                }
            }

        }

        string readValue;
        [When(@"Exports Page CMS (.*) Day Compliance ""(.*)"" Drop down list is set to ""(.*)""")]
        public void WhenExportsPageCMSDayComplianceDropDownListIsSetTo(int p0, string drp, string Hardvalue)
        {
            By ele;
            
            switch(drp)
            {
                case "Plan ID":
                    ele = By.XPath("//span[@aria-owns='planId_listbox']//span[contains(@class,'k-input')]");
                    readValue = UIMODUtilFunctions.returnTextUsingLocators(ele);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfESIFRMExports.CMS45DayCompliance.PlanIDDropdownList, readValue);
                    GlobalRef.ReportPlanID = readValue;
                    break;
                case "Payment Month":
                    ele = By.XPath("//span[@aria-owns='payMonth_listbox']//span[contains(@class,'k-input')]");
                    readValue=UIMODUtilFunctions.returnTextUsingLocators(ele);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfESIFRMExports.CMS45DayCompliance.PaymentMonthDropdownList, readValue);
                    GlobalRef.ReportPaymentMon = readValue;
                    GlobalRef.ReportPaymentMonth = readValue;
                    break;
                    
            }
       
        }

        [When(@"Exports Page Discrepancy Type Flag Part D ""(.*)"" Drop down list is set to ""(.*)""")]
        public void WhenExportsPageDiscrepancyTypeFlagPartDDropDownListIsSetTo(string drp, string Hardvalue)
        {
          
            string value;

            switch (drp)
            {
                case "Plan ID":
                    value = ReUsableFunctions.ExecuteSimpleSQLQueryReturnValue("select distinct [Plan Id]  from  EAMWarehouse.FRM.[Plan] order by [Plan Id] desc", "EAMWarehouse");                    
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfESIFRMExports.DiscrepancyTypeFlagPartD.PlanIDDropdownList, value);

                    break;
                case "Range Start":
                    value = ReUsableFunctions.ExecuteSimpleSQLQueryReturnValue("select distinct [Payment Month] from EAMWarehouse.FRM.Bridge order by [Payment Month] asc", "EAMWarehouse");
                    CultureInfo culture = new CultureInfo("en-US");
                    DateTime tempDate = Convert.ToDateTime(value, culture);
                    value = tempDate.ToString("yyyy-MM-dd");
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfESIFRMExports.DiscrepancyTypeFlagPartD.RangeStartDropdownList, value);
                    break;
                case "Range End":
                    value = ReUsableFunctions.ExecuteSimpleSQLQueryReturnValue("select distinct [Payment Month] from EAMWarehouse.FRM.Bridge order by [Payment Month] desc", "EAMWarehouse");
                    CultureInfo culture1 = new CultureInfo("en-US");
                    DateTime tempDate1 = Convert.ToDateTime(value, culture1);
                    value = tempDate1.ToString("yyyy-MM-dd");
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfESIFRMExports.DiscrepancyTypeFlagPartD.RangeEndDropdownList, value);
                    break;

            }
        }

        [When(@"Exports Page Discrepancy Type Flag Part D Export Button is Clicked")]
        public void WhenExportsPageDiscrepancyTypeFlagPartDExportButtonIsClicked()
        {
            fw.ExecuteJavascript(cfESIFRMExports.DiscrepancyTypeFlagPartD.exportButton);
        }

        [Then(@"Wait for ""(.*)"" Export Processing gets complete")]
        public void ThenWaitForExportProcessingGetsComplete(string exportType)
        {
           switch(exportType)
            {
                case "Discrepancy Type Flag - Part D":
                    By btn = By.CssSelector("[test-id='exportDiscTypeFlagPartD-btn-initiateExport']");
                    By exportJob = By.CssSelector("[test-id='export-lbl-disctypeflagpartd']");
                    while (!Browser.Wd.FindElement(btn).Enabled)
                    {
                        Browser.Wd.Navigate().Refresh();
                        tmsWait.Hard(7);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(exportJob));
                    }
                    break;
            }
            
        }

        [Then(@"Wait for Data Transfer to Warehouse Processing gets complete")]
        public void ThenWaitForDataTransferToWarehouseProcessingGetsComplete()
        {
            By transferBtn = By.CssSelector("[test-id='dataMoveToWarehouse-btn-scheduleDataMoveJob']");
           
            while (!Browser.Wd.FindElement(transferBtn).Enabled)
            {
                Browser.Wd.Navigate().Refresh();
                tmsWait.Hard(7);
              
            }
        
        }

        [Then(@"Execute Provided SQL Query on DB ""(.*)"" and Compare readed ""(.*)"" CSV value with DB Value for CMS (.*) Day Compliance")]
        public void ThenExecuteProvidedSQLQueryOnDBAndCompareReadedCSVValueWithDBValueForCMSDayCompliance(string DBNAME, string typeOfValue, int p2)
        {
            string MBI = GlobalRef.ReportMBI.ToString();
        
            string PAYMON = GlobalRef.ReportPaymentMonth.ToString();            
          string PlanIDValue = GlobalRef.ReportPlanID.ToString();
            string sql;
            switch (typeOfValue)
            {
                case "MBI":
                    sql = "select top 1 w.[HIC Number],w.[Discrepancy Reason],w.[Discrepany Status] from frm.[DiscrepancyWorkflowPartCPartD] w full outer join frm.[Member] m on w.[HIC Number]=m.[HIC Number] where [Report Month]= '"+ PAYMON + "'  and  [Plan Id]='"+ PlanIDValue + "'  order by [HIC Number] asc";
                    string dbMBI = ReUsableFunctions.ExecuteSimpleSQLQueryReturnValue(sql, DBNAME);
                    string csvMBI = GlobalRef.ReportMBI.ToString();
                    Assert.AreEqual(dbMBI, csvMBI, " Both values are not matching");
                    break;
                case "Discrepancy Reason":
                    sql = "select top 1 w.[Discrepancy Reason],w.[Discrepany Status], w.[HIC Number] from frm.[DiscrepancyWorkflowPartCPartD] w full outer join frm.[Member] m on w.[HIC Number]=m.[HIC Number] where [Report Month]= '" + PAYMON + "'  and  [Plan Id]='" + PlanIDValue + "'  order by [HIC Number] asc";
                    string dbDisReason = ReUsableFunctions.ExecuteSimpleSQLQueryReturnValue(sql, DBNAME);
                    string csvDisReason = GlobalRef.ReportdiscrepancyReason.ToString();
                    Assert.AreEqual(dbDisReason, csvDisReason, " Both values are not matching");
                    break;
                case "Discrepancy Status":
                    sql = "select top 1 w.[Discrepany Status], w.[HIC Number], w.[Discrepancy Reason] from frm.[DiscrepancyWorkflowPartCPartD] w full outer join frm.[Member] m on w.[HIC Number]=m.[HIC Number] where [Report Month]= '" + PAYMON + "'  and  [Plan Id]='" + PlanIDValue + "'  order by [HIC Number] asc";
                    string dbDisStatus = ReUsableFunctions.ExecuteSimpleSQLQueryReturnValue(sql, DBNAME);
                    string csvDisStatus = GlobalRef.ReportdiscrepancyReason.ToString();
                    Assert.AreEqual(dbDisStatus, csvDisStatus, " Both values are not matching");
                    break;


            }

        }


        [Then(@"Execute Provided SQL Query on DB Warehouse and Compare readed ""(.*)"" CSV value with DB Value")]
        public void ThenExecuteProvidedSQLQueryOnDBWarehouseAndCompareReadedCSVValueWithDBValue(string typeOfValue)
        {
            string MBI = GlobalRef.ReportMBI.ToString();
            string PAYMON = GlobalRef.ReportPaymentMon.ToString();
            string sql;
            switch (typeOfValue)
            {
                case "Plan ID":
                    sql = "SELECT [Plan Id] ,[HIC Number],[Discrepancy Reason],[Discrepany Status] ,(select CONCAT([Member Last Name],' ',(LEFT([Member First Name],1))) from frm.member where [HIC Number] ='" + MBI + "') AS NAME ,(select [PBP] from [FRM].[PlanFlagsPartD] where [HIC Number]='" + MBI + "' and [Payment Month]='" + PAYMON + "') AS PBP ,(select SUM([Discrepancy Amount]) from [frm].[DiscrepancyPaymentsPartCPartD] where [HIC Number]='" + MBI + "' and [Payment Month]='" + PAYMON + "') FROM [frm].[DiscrepancyWorkflowPartCPartD] where [HIC Number]='" + MBI + "' and [Payment Month]='" + PAYMON + "'  and [Plan Type]='D' ";
                    string dbPlanID = ReUsableFunctions.ExecuteSimpleSQLQueryReturnValueusingWarehouse(sql);
                    string csvPlanID = GlobalRef.ReportPlanID.ToString();
                    Assert.AreEqual(dbPlanID, csvPlanID, " Both values are not matching");
                    break;
                case "Discrepancy Reason":
                    sql = "SELECT [Discrepancy Reason],[Discrepany Status] ,(select CONCAT([Member Last Name],' ',(LEFT([Member First Name],1))) from frm.member where [HIC Number] ='" + MBI + "') AS NAME ,(select [PBP] from [FRM].[PlanFlagsPartD] where [HIC Number]='" + MBI + "' and [Payment Month]='" + PAYMON + "') AS PBP ,(select SUM([Discrepancy Amount]) from [frm].[DiscrepancyPaymentsPartCPartD] where [HIC Number]='" + MBI + "' and [Payment Month]='" + PAYMON + "') FROM [frm].[DiscrepancyWorkflowPartCPartD] where [HIC Number]='" + MBI + "' and [Payment Month]='" + PAYMON + "'  and [Plan Type]='D' ";
                    string dbDisReason = ReUsableFunctions.ExecuteSimpleSQLQueryReturnValueusingWarehouse(sql);
                    string csvDisReason = GlobalRef.ReportdiscrepancyReason.ToString();
                    Assert.AreEqual(dbDisReason, csvDisReason, " Both values are not matching");
                    break;
                case "Discrepancy Status":
                    sql = "SELECT [Discrepany Status] ,(select CONCAT([Member Last Name],' ',(LEFT([Member First Name],1))) from frm.member where [HIC Number] ='" + MBI + "') AS NAME ,(select [PBP] from [FRM].[PlanFlagsPartD] where [HIC Number]='" + MBI + "' and [Payment Month]='" + PAYMON + "') AS PBP ,(select SUM([Discrepancy Amount]) from [frm].[DiscrepancyPaymentsPartCPartD] where [HIC Number]='" + MBI + "' and [Payment Month]='" + PAYMON + "') FROM [frm].[DiscrepancyWorkflowPartCPartD] where [HIC Number]='" + MBI + "' and [Payment Month]='" + PAYMON + "'  and [Plan Type]='D' ";
                    string dbDisStatus = ReUsableFunctions.ExecuteSimpleSQLQueryReturnValueusingWarehouse(sql);
                    string csvDisStatus = GlobalRef.ReportdiscrepancyStatus.ToString();
                    Assert.AreEqual(dbDisStatus, csvDisStatus, " Both values are not matching");
                    break;


            }
        }

        [Then(@"Execute Provided SQL Query on DB ""(.*)"" and Compare readed ""(.*)"" CSV value with DB Value")]
        public void ThenExecuteProvidedSQLQueryOnDBAndCompareReadedCSVValueWithDBValue(string DBNAME, string typeOfValue)
        {
          
        string MBI = GlobalRef.ReportMBI.ToString();
                string PAYMON = GlobalRef.ReportPaymentMon.ToString();
            string sql;
            switch (typeOfValue)
            {
                case "Plan ID":
                    sql = "SELECT [Plan Id] ,[HIC Number],[Discrepancy Reason],[Discrepany Status] ,(select CONCAT([Member Last Name],' ',(LEFT([Member First Name],1))) from frm.member where [HIC Number] ='" + MBI + "') AS NAME ,(select [PBP] from [FRM].[PlanFlagsPartD] where [HIC Number]='" + MBI + "' and [Payment Month]='" + PAYMON + "') AS PBP ,(select SUM([Discrepancy Amount]) from [frm].[DiscrepancyPaymentsPartCPartD] where [HIC Number]='" + MBI + "' and [Payment Month]='" + PAYMON + "') FROM [frm].[DiscrepancyWorkflowPartCPartD] where [HIC Number]='" + MBI + "' and [Payment Month]='" + PAYMON + "'  and [Plan Type]='D' ";
                    string dbPlanID= ReUsableFunctions.ExecuteSimpleSQLQueryReturnValue(sql, DBNAME);
                    string csvPlanID = GlobalRef.ReportPlanID.ToString();
                    Assert.AreEqual(dbPlanID, csvPlanID, " Both values are not matching");
                    break;
                case "Discrepancy Reason":
                    sql = "SELECT [Discrepancy Reason],[Discrepany Status] ,(select CONCAT([Member Last Name],' ',(LEFT([Member First Name],1))) from frm.member where [HIC Number] ='" + MBI + "') AS NAME ,(select [PBP] from [FRM].[PlanFlagsPartD] where [HIC Number]='" + MBI + "' and [Payment Month]='" + PAYMON + "') AS PBP ,(select SUM([Discrepancy Amount]) from [frm].[DiscrepancyPaymentsPartCPartD] where [HIC Number]='" + MBI + "' and [Payment Month]='" + PAYMON + "') FROM [frm].[DiscrepancyWorkflowPartCPartD] where [HIC Number]='" + MBI + "' and [Payment Month]='" + PAYMON + "'  and [Plan Type]='D' ";
                    string dbDisReason = ReUsableFunctions.ExecuteSimpleSQLQueryReturnValue(sql, DBNAME);
                    string csvDisReason = GlobalRef.ReportdiscrepancyReason.ToString();
                    Assert.AreEqual(dbDisReason, csvDisReason, " Both values are not matching");
                    break;
                case "Discrepancy Status":
                    sql = "SELECT [Discrepany Status] ,(select CONCAT([Member Last Name],' ',(LEFT([Member First Name],1))) from frm.member where [HIC Number] ='" + MBI + "') AS NAME ,(select [PBP] from [FRM].[PlanFlagsPartD] where [HIC Number]='" + MBI + "' and [Payment Month]='" + PAYMON + "') AS PBP ,(select SUM([Discrepancy Amount]) from [frm].[DiscrepancyPaymentsPartCPartD] where [HIC Number]='" + MBI + "' and [Payment Month]='" + PAYMON + "') FROM [frm].[DiscrepancyWorkflowPartCPartD] where [HIC Number]='" + MBI + "' and [Payment Month]='" + PAYMON + "'  and [Plan Type]='D' ";
                    string dbDisStatus = ReUsableFunctions.ExecuteSimpleSQLQueryReturnValue(sql, DBNAME);
                    string csvDisStatus = GlobalRef.ReportdiscrepancyStatus.ToString();
                    Assert.AreEqual(dbDisStatus, csvDisStatus, " Both values are not matching");
                    break;


            }
        }

        [Then(@"Verify ""(.*)"" DB Table Data count is matched with Exported CSV records count")]
        public void ThenVerifyDBTableDataCountIsMatchedWithExportedCSVRecordsCount(string DBNAME)
        {
           

        string PAYMON = GlobalRef.ReportPaymentMon.ToString();
            string PlanIDValue = GlobalRef.ReportPlanID.ToString();
            string path = GlobalRef.ReportPath.ToString();         
            fw.ConsoleReport(" Report Path -->" + path);
            var latestFileName = ReUsableFunctions.latestGeneratedFileName(path, "csv");
            var csvfileRecordCount = File.ReadLines(latestFileName).Count()-1;
            string sql;
            sql = "select count(*) from frm.[DiscrepancyWorkflowPartCPartD] w full outer join frm.[Member] m on w.[HIC Number]=m.[HIC Number] where [Report Month]= '"+ PAYMON + "'  and [Plan Id]='"+ PlanIDValue + "' ";
            int dbCount= Convert.ToInt32(ReUsableFunctions.ExecuteSimpleSQLQueryReturnValue(sql, DBNAME));
            Assert.AreEqual(csvfileRecordCount, dbCount, " Both records are not matching");
        }

        [When(@"TMS Shared Folder Latest FRM Report Export_Cms(.*)Days-Cms(.*)DaysExportTrigger CSV format is readed Payment Month and MBI are noted")]
        public void WhenTMSSharedFolderLatestFRMReportExport_CmsDays_CmsDaysExportTriggerCSVFormatIsReadedPaymentMonthAndMBIAreNoted(int p0, string p1)
        {
            string reportName = tmsCommon.GenerateData(p1);

            string tenant = GlobalRef.Tenant.ToString();
            By fileRootPath = By.CssSelector("[test-id='manageConfiguration-txt-fileRootPath']");
            string RootPath = UIMODUtilFunctions.returnValuefromWebComponentUsingGetAttribute(Browser.Wd.FindElement(fileRootPath));
            string LetterNameinServer = reportName;
            string path = RootPath + "\\" + tenant + "\\FRM\\";
            GlobalRef.ReportPath = path;
            string pathCSV = RootPath + "\\" + tenant + "\\FRM\\" + LetterNameinServer;
            fw.ConsoleReport(" Report Path -->" + path);

            var count = 0;            
            string mbi;
            
            string discrepancyStatus;
            string discrepancyReason;

            var latestFileName=ReUsableFunctions.latestGeneratedFileName(path, "csv");


            var reader = new StreamReader(File.OpenRead(@"" + latestFileName + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
                if (count > 1)
                {
                    mbi = (line.Split(','))[0];
                    GlobalRef.ReportMBI = mbi;
                 
                    discrepancyStatus = (line.Split(','))[7];
                    GlobalRef.ReportdiscrepancyStatus = discrepancyStatus;

                    discrepancyReason = (line.Split(','))[4];
                    GlobalRef.ReportdiscrepancyReason = discrepancyReason;
                   
                    break;
                }

            }
        }

        [When(@"TMS Shared Folder Latest FRM Report ""(.*)"" CSV format is readed Payment Month and MBI are noted")]
        public void WhenTMSSharedFolderLatestFRMReportCSVFormatIsReadedPaymentMonthAndMBIAreNoted(string p0)
        {
            string reportName = tmsCommon.GenerateData(p0);           

            string tenant = GlobalRef.Tenant.ToString();
            By fileRootPath = By.CssSelector("[test-id='manageConfiguration-txt-fileRootPath']");
            string RootPath = UIMODUtilFunctions.returnValuefromWebComponentUsingGetAttribute(Browser.Wd.FindElement(fileRootPath));
            string LetterNameinServer = reportName;
            string path = RootPath + "\\" + tenant + "\\FRM\\";
            string pathCSV = RootPath + "\\" + tenant + "\\FRM\\"+LetterNameinServer;
            fw.ConsoleReport(" Report Path -->" + path);
                     
            var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + path + "", "*_*.csv");
            string mbi;
            string paymentDate;
            string discrepancyStatus;
            string discrepancyReason;
            string PlanID;
            // Adding File Info details like Creation Time etc to sort by latest
            List<FileInfo> lst = new List<FileInfo>();
            foreach (var item in newFilePaths)
            {
                var srcFile = Path.Combine(path, item);
                lst.Add(new FileInfo(srcFile));
            }

            var latestFileName = lst.OrderByDescending(x => x.CreationTime).FirstOrDefault().FullName;


            var reader = new StreamReader(File.OpenRead(@"" + latestFileName + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
                if (count>1)
                {
                    mbi=(line.Split(','))[0];
                    GlobalRef.ReportMBI = mbi;
                    paymentDate = (line.Split(','))[3];
                    GlobalRef.ReportPaymentMon = paymentDate;
                    discrepancyStatus = (line.Split(','))[4];
                    GlobalRef.ReportdiscrepancyStatus = discrepancyStatus;
                    discrepancyReason = (line.Split(','))[7];
                    GlobalRef.ReportdiscrepancyReason = discrepancyReason;
                  //  PlanID = (line.Split(','))[1];
                   // GlobalRef.ReportPlanID = PlanID;
                    break;
                }

            }

            //var csvData = ReadFileFunctions.ReadCSVFile(path);
            //VerifyText(csvData, ReportValidationText, format);
        }



        [When(@"Exports Page CMS (.*) Day Compliance Export Button is Clicked")]
        public void WhenExportsPageCMSDayComplianceExportButtonIsClicked(int p0)
        {
            fw.ExecuteJavascript(cfESIFRMExports.CMS45DayCompliance.exportButton);
            tmsWait.Hard(9);
        }

        [Then(@"Verify ESI FRM displays page as ""(.*)""")]
        public void ThenVerifyESIFRMDisplaysPageAs(string p0)
        {
            By title = By.XPath("//span[contains(.,'"+ p0 + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(title);
        }

        [Then(@"Verify Administration Data Transfer to Warehouse page displays message ""(.*)""")]
        public void ThenVerifyAdministrationDataTransferToWarehousePageDisplaysMessage(string p0)
        {
            By title = By.XPath("//div[@role='alert'][contains(.,'"+p0+"')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(title);
            
        }

        [Then(@"Verify Administration Data Transfer to Warehouse page displays ""(.*)"" button")]
        public void ThenVerifyAdministrationDataTransferToWarehousePageDisplaysButton(string p0)
        {
            By title = By.XPath("//button[@test-id='dataMoveToWarehouse-btn-scheduleDataMoveJob'][contains(.,'"+p0+"')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(title);
        }


        [Then(@"Wait for Export Processing gets complete")]
        public void ThenWaitForExportProcessingGetsComplete()
        {
            By btn = By.CssSelector("[test-id='exportCmsDay-btn-initiateExport']");
            By exportJob = By.CssSelector("[test-id='export-lbl-cms45']");
            while(!Browser.Wd.FindElement(btn).Enabled)
            {
                Browser.Wd.Navigate().Refresh();
                tmsWait.Hard(7);
                Browser.Wd.FindElement(exportJob).Click();
            }
        }

    }
}