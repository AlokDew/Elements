﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1
{
    [Binding]
    public class fsExportMonthlyExtractToFile
    {
        [Then(@"Verify Export Monthly Extract to File page")]
        public void ThenVerifyExportMonthlyExtractToFilePage()
        {
            Assert.IsTrue(FRM.ExportMonthlyExtracttofile.ExportMonthlyExtractToDate.Displayed, "To Date text box is not displayed.");
            Assert.IsTrue(FRM.ExportMonthlyExtracttofile.ExportMonthlyExtractFromDate.Displayed, "From Date text box is not displayed.");
            Assert.IsTrue(FRM.ExportMonthlyExtracttofile.ExportMonthlyExtractExportButton.Displayed, "Export button is not displayed.");
            Assert.IsTrue(FRM.ExportMonthlyExtracttofile.ExportMonthlyExtractPlanID.Displayed, "Plan ID Dropdown is not displayed.");
            Assert.IsTrue(FRM.ExportMonthlyExtracttofile.ExportMonthlyExtractResetButton.Displayed, "Reset button is not displayed.");
        }


        [Then(@"Monthly Extract Text file is generated and saved")]
        public void ThenMonthlyExtractTextFileIsGeneratedAndSaved()
        {
            string downloadPath = Path.Combine(Environment.ExpandEnvironmentVariables("%userprofile%"), "Downloads");
            string[] filePaths = Directory.GetFiles(@"" + downloadPath + "", "*.txt");
            foreach (string filePath in filePaths)
            {
                File.Delete(filePath);
            }
            tmsWait.Hard(5);
            DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_MENU, 0, 0, 0);
            DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_S, 0, 0, 0);
            tmsWait.Hard(5);
            string[] filePathsAfterSave = Directory.GetFiles(@"" + downloadPath + "", "*.txt");
            foreach (string filePath in filePathsAfterSave)
            {
                Assert.IsTrue(filePath.Contains("MonthlyExtract"), "Monthly Extract file is not present in Download Folder.");
            }
        }


        [When(@"Export Monthly Extract to file page ""(.*)"" Plan ID is selected")]
        public void WhenExportMonthlyExtractToFilePagePlanIDIsSelected(string p0)
        {
            By Drp = By.XPath("//label[contains(.,'Select Plan ID or ALL')]/parent::div//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + p0 + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
        }

        [When(@"Export Monthly Extract to file page ""(.*)"" is set to ""(.*)""")]
        public void WhenExportMonthlyExtractToFilePageIsSetTo(string p0, string p1)
        {
            string field = p0.ToString();
            string date = p1.ToString();

            switch (field)
            {
                case "Start Date":
                    // FRM.ExportMonthlyExtracttofile.ExportMonthlyExtractFromDate.SendKeys(date);
                    // break;

                    //string value = date.Replace("/", "");
                    //By Drp = By.XPath("//label[text()='Start Date']/parent::div//input");
                    //Browser.Wd.FindElement(Drp).Clear();
                    //Browser.Wd.FindElement(Drp).SendKeys(value);
                    IWebElement stdate = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='expMonExtr-txt-fromDate']//span[@role='button']"));
                    tmsWait.Hard(3);
                    FrameworkCode.AngularFunction.enterDate(stdate, date);
                    break;
                case "End Date":
                    //FRM.ExportMonthlyExtracttofile.ExportMonthlyExtractToDate.SendKeys(date);
                    //break;

                    //string value2 = date.Replace("/", "");
                    //By Drp1 = By.XPath("//label[text()='End Date']/parent::div//input");
                    //Browser.Wd.FindElement(Drp1).Clear();
                    //Browser.Wd.FindElement(Drp1).SendKeys(value2);
                    //tmsWait.Hard(3);
                    IWebElement enddate = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='expMonExtr-txt-toDate']//span[@role='button']"));
                    tmsWait.Hard(3);
                    FrameworkCode.AngularFunction.enterDate(enddate, date);
                    break;

                default:
                    fw.ConsoleReport(" Please proide correct date");
                    break;

            }

        }

        [When(@"Export Monthly Extract to file page Export button is Clicked")]
        public void WhenExportMonthlyExtractToFilePageExportButtonIsClicked()
        {
            fw.ExecuteJavascript(FRM.ExportMonthlyExtracttofile.ExportMonthlyExtractExportButton);
        }



        [When(@"Export Monthly Extract to file page File Save dialog Cancel button is Clicked")]
        public void WhenExportMonthlyExtractToFilePageFileSaveDialogCancelButtonIsClicked()
        {
            tmsWait.Hard(10); //time to get focus on IE Notification Bar
                              //          FRM.ExportMonthlyExtracttofile.ExportMonthlyExtractExportButton.SendKeys(Keys.Tab + Keys.Enter);
            tmsWait.Hard(1);
            FRM.ExportMonthlyExtracttofile.ExportMonthlyExtractEndDateLabel.SendKeys(Keys.Tab);
            tmsWait.Hard(1);
            FRM.ExportMonthlyExtracttofile.ExportMonthlyExtractEndDateLabel.SendKeys(Keys.Tab);
            tmsWait.Hard(1);
            FRM.ExportMonthlyExtracttofile.ExportMonthlyExtractEndDateLabel.SendKeys(Keys.Escape);
        }


        [When(@"Export Monthly Extract Operation Terminate Message is displayed")]
        public void WhenExportMonthlyExtractOperationTerminateMessageIsDisplayed()
        {
            Assert.IsTrue(FRM.ExportMonthlyExtracttofile.OperationTerminateToolTip.Text.Equals("No data was returned from database. Operation terminating."), "ToolTip is not displayed.");
        }

    }
}
