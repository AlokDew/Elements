﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows;

namespace TMSoR1
{
    [Binding]
    public class fsFRMMain
    {
        
        [Then(@"FRM File FRM Main menu item is displayed")]
        public void ThenFRMFileMenuItemIsDisplayed()
        {
            Assert.IsTrue(FRM.FRMFileMenu.FRMMain.Displayed);
        }
        
        [When(@"I clicked on FRM Main menu item")]
        public void WhenIClickedOnMenuItem()
        {
            FRM.FRMFileMenu.FRMMain.Click();
        }

        [Then(@"FRM Main page is displayed")]
        public void ThenFRMMainPageIsDisplayed()
        {
             Assert.IsTrue(FRM.FRMMainPage.FRMMainWindow.Displayed);
             Console.WriteLine(" FRMMainWindow.Displayed");
             Assert.IsTrue(FRM.FRMMainPage.ALLButton.Displayed);
             Console.WriteLine(" FRMMainPage.ALLButton.Displayed");
             Assert.IsTrue(FRM.FRMMainPage.PartCButton.Displayed);
             Console.WriteLine(" FRMMainPage.PartCButton.Displayed");
             Assert.IsTrue(FRM.FRMMainPage.PartDButton.Displayed);
             Console.WriteLine(" FRMMainPage.PartDButton.Displayed");
             Assert.IsTrue(FRM.FRMMainPage.DiscrepancyTypeDD.Displayed);
             Console.WriteLine(" FRMMainPage.DiscrepancyTypeDD.Displayed");
             Assert.IsTrue(FRM.FRMMainPage.FilterbyPaymentMonthsFrom.Displayed);
             Console.WriteLine(" FRMMainPage.FilterbyPaymentMonthsFrom.Displayed");
             Assert.IsTrue(FRM.FRMMainPage.FilterbyPaymentMonthsTo.Displayed);
             Console.WriteLine(" FRMMainPage.FilterbyPaymentMonthsTo.Displayed");
             Assert.IsTrue(FRM.FRMMainPage.PlanID.Displayed);
             Console.WriteLine(" FRMMainPage.PlanID.Displayed");
             Assert.IsTrue(FRM.FRMMainPage.PBP.Displayed);
             Console.WriteLine(" FRMMainPage.PBP.Displayed");
             Assert.IsTrue(FRM.FRMMainPage.GRPIPA.Displayed);
             Console.WriteLine(" FRMMainPage.GRPIPA.Displayed");
             Assert.IsTrue(FRM.FRMMainPage.Status.Displayed);
             Console.WriteLine(" FRMMainPage.Status.Displayed");
             Assert.IsTrue(FRM.FRMMainPage.AgeOfDiscrepancy.Displayed);
             Console.WriteLine(" FRMMainPage.AgeOfDiscrepancy.Displayed");
             Assert.IsTrue(FRM.FRMMainPage.User.Displayed);
             Console.WriteLine(" FRMMainPage.User.Displayed");
             Assert.IsTrue(FRM.FRMMainPage.Search.Displayed);
             Console.WriteLine(" FRMMainPage.Search.Displayed");
             Assert.IsTrue(FRM.FRMMainPage.ResetFilter.Displayed);
             Console.WriteLine(" FRMMainPage.ResetFilter.Displayed");
             Assert.IsTrue(FRM.FRMMainPage.MICMS.Displayed);
             Console.WriteLine(" FRMMainPage.MICMS.Displayed");
             Assert.IsTrue(FRM.FRMMainPage.MIDefineReasonCodes.Displayed);
             Console.WriteLine(" FRMMainPage.MIDefineReasonCodes.Displayed");
             Assert.IsTrue(FRM.FRMMainPage.MIDisplayEnrollDisenrollWizard.Displayed);
             Console.WriteLine(" 18 success");
             Assert.IsTrue(FRM.FRMMainPage.MIDisplayMemberInfo.Displayed);
             Console.WriteLine(" 19 success");
             Assert.IsTrue(FRM.FRMMainPage.MIDisplayMemberReport.Displayed);
             Console.WriteLine(" 20 success");
             Assert.IsTrue(FRM.FRMMainPage.MIDisplypayments.Displayed);
             Console.WriteLine(" 21 success");
             Assert.IsTrue(FRM.FRMMainPage.MIFi.Displayed);
             Console.WriteLine(" 22 success");
             Assert.IsTrue(FRM.FRMMainPage.MIFindByHicName.Displayed);
             Console.WriteLine(" 23 success");
             Assert.IsTrue(FRM.FRMMainPage.MIHIC.Displayed);
             Console.WriteLine(" 24 success");
             Assert.IsTrue(FRM.FRMMainPage.MIMemberID.Displayed);
             Console.WriteLine(" 25 success");
             Assert.IsTrue(FRM.FRMMainPage.MIParDOverUnder.Displayed);
             Console.WriteLine(" 26 success");
             Assert.IsTrue(FRM.FRMMainPage.MIPartCOverUnder.Displayed);
             Console.WriteLine(" 27 success");
             Assert.IsTrue(FRM.FRMMainPage.MIPaymentMonthsTable.Displayed);
             Console.WriteLine(" 28 success");
             Assert.IsTrue(FRM.FRMMainPage.MIPlandefined1.Displayed);
             Console.WriteLine(" 29 success");
             Assert.IsTrue(FRM.FRMMainPage.MIPlandefined2.Displayed);
             Console.WriteLine(" 30 success");
             Assert.IsTrue(FRM.FRMMainPage.MIPlanID.Displayed);
             Console.WriteLine(" 31 success");
             Assert.IsTrue(FRM.FRMMainPage.MIRxID.Displayed);
             Console.WriteLine(" 32 success");
             Assert.IsTrue(FRM.FRMMainPage.MISortbyClaim.Displayed);
             Console.WriteLine(" 33 success");
             Assert.IsTrue(FRM.FRMMainPage.MISortbyName.Displayed);
             Console.WriteLine(" 34 success");
             Assert.IsTrue(FRM.FRMMainPage.MISurname.Displayed);
             Console.WriteLine(" 35 success");
             Assert.IsTrue(FRM.FRMMainPage.MIViewmembernotes.Displayed);
             Console.WriteLine(" 36 success");
            

        }


    }
}
