﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using OpenQA.Selenium;
//using OpenQA.Selenium.Firefox;
//using OpenQA.Selenium.Chrome;
//using OpenQA.Selenium.IE;
//using TechTalk.SpecFlow;
//using Microsoft.VisualStudio.TestTools.UnitTesting;
//using System.Collections;
//using System.Diagnostics;
//using System.Windows;

//namespace TMSoR1
//{
//    [Binding]
//    public class FRMFileMenu
//    {
//        public IWebElement FRMMain { get { return Browser.Wd.FindElement(By.Id("ctl00_RadMenu1_m0_m0")); } }
        
//    }

//    [Binding]
//    public class FRMMainPage
//    {

//        public IWebElement FRMMainWindow { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_UpdatePanel1")); } }
//        public IWebElement ALLButton { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='ctl00_MainContent_rbPartALL']")); } }
//        public IWebElement PartCButton { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_rbPartC")); } }
//        public IWebElement PartDButton { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_rbPartD")); } }
//        public IWebElement DiscrepancyTypeDD { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_ddDiscpType")); } }
//        public IWebElement FilterbyPaymentMonthsFrom { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_ddFromDate")); } }
//        public IWebElement FilterbyPaymentMonthsTo { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_ddTodate")); } }
//        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_ddPlanID")); } }
//        public IWebElement PBP { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_ddPBP")); } }
//        public IWebElement GRPIPA { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_ddIPA")); } }
//        public IWebElement Status { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_ddStatus")); } }
//        public IWebElement AgeOfDiscrepancy { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_ddDispAge")); } }
//        public IWebElement User { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_ddUser")); } }
//        public IWebElement Search { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_btnSearch")); } }
//        public IWebElement ResetFilter { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_btnReset")); } }
//        public IWebElement MIPlanID { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_lblPlanID")); } }
//        public IWebElement MIHIC { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_lblHic")); } }
//        public IWebElement MIMemberID { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_lblMember")); } }
//        public IWebElement MIPlandefined2 { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='ctl00_MainContent_UpdatePanel1']/fieldset/table[1]/tbody/tr[4]/td[2]")); } }
//        public IWebElement MIRxID { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_lblRxID")); } }
//        public IWebElement MISurname { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_lblSurName")); } }
//        public IWebElement MIFi { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_lblFI")); } }
//        public IWebElement MIPlandefined1 { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='ctl00_MainContent_UpdatePanel1']/fieldset/table[1]/tbody/tr[4]/td[1]")); } }
//        public IWebElement MIPartCOverUnder { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_lblPartcOU")); } }
//        public IWebElement MIParDOverUnder { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_lblPartdOU")); } }
//        public IWebElement MIFindByHicName { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_ibtSearch")); } }
//        public IWebElement MISortbyClaim { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_RadioSort_0")); } }
//        public IWebElement MISortbyName { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_RadioSort_1")); } }
//        public IWebElement MIViewmembernotes { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_ImgViewNotes")); } }
//        public IWebElement MICMS { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_btnCMS")); } }
//        public IWebElement MIDisplypayments { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_btnTopFify")); } }
//        public IWebElement MIDisplayAdjustmentWizard { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_ibtAdjustWizard")); } }
//        public IWebElement MIDisplayEnrollDisenrollWizard { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_ImgDisEnrlment")); } }
//        public IWebElement MIPaymentMonthsTable { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_GridMain")); } }
//        public IWebElement MIDisplayMemberInfo { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_ibtMemberInfo")); } }
//        public IWebElement MIDefineReasonCodes { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_ibtDisplayReasonCodes")); } }
//        public IWebElement MIDisplayMemberReport { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_imgReportGroup")); } }
//        //public IWebElement MICMS { get { return Browser.Wd.FindElement(By.Id("ctl00_MainContent_btnCMS")); } }
//    }
//}
