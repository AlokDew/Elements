﻿
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using TMSoR1.FrameworkCode;

namespace TMSoR1
{
    [Binding]
    public class FRMAdjustDiscrepancySteps
    {
        [Then(@"Adjust Discrepancy page Part ""(.*)"" is selected")]
        public void ThenAdjustDiscrepancyPagePartIsSelected(string part)
        {
            if (part.ToLower() == "c")
            {
                fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.partCRadioButton);
                tmsWait.Hard(2);
                fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.partCRadioButton);
            }
            else
            {
                fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.partDRadioButton);
                tmsWait.Hard(2);
                fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.partDRadioButton);
            }
        }

        [When(@"Read Plan ID from Adjustment Discrepancy Page and set to ""(.*)""")]
        public void WhenReadPlanIDFromAdjustmentDiscrepancyPageAndSetTo(string p0)
        {
            tmsWait.Hard(2);
            string planID = Browser.Wd.FindElement(By.XPath("//label[@test-id='frmMainAdjDisc-lbl-lblPlanId']")).Text;
            fw.ConsoleReport("Plan ID  -->" + planID);
            fw.setVariable(p0, planID);
        }


        [Then(@"Adjust Discrepancy page ""(.*)"" tab is clicked")]
        [When(@"Adjust Discrepancy page ""(.*)"" tab is clicked")]
        public void WhenAdjustDiscrepancyPageTabIsClicked(string p0)
        {
            switch(p0.ToLower())
            {
                case "cms":fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='frmMainAdjDisc-lbl-btnCms']"))); break;
                case "plan": fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='frmMainAdjDisc-lbl-btnPlan']"))); break;
            }

            tmsWait.Hard(2);
        }

        [Then(@"Adjust Discrepancy page ""(.*)"" button is Clicked")]
        public void ThenAdjustDiscrepancyPageButtonIsClicked(string p0)
        {
            IWebElement button = Browser.Wd.FindElement(By.XPath("//button[@id='btn"+p0+"']"));
            fw.ExecuteJavascript(button);
            tmsWait.Hard(5);
        }

        [Then(@"Adjust Discrepancy page ""(.*)"" checkbox is Clicked")]
        public void ThenAdjustDiscrepancyPageCheckboxIsClicked(string p0)
        {
            tmsWait.Hard(2);
            IWebElement button = Browser.Wd.FindElement(By.XPath("(//td//input[@test-id='frmMainAdjDisc-chk-selectedAvailablePayMonths'])[1]"));
            //IWebElement button = Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainAdjDisc-chk-frmMainAdjDisc-chk-selectedAvailablePayMonths']"));
            fw.ExecuteJavascript(button);
        }
        [Then(@"Adjust Discrepancy page ChangeType Textbox is set to ""(.*)""")]
        public void ThenAdjustDiscrepancyPageChangeTypeTextboxIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            IWebElement textbox = Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainAdjDisc-txt-fmadIndividualTxt']"));
            textbox.SendKeys(value);
        }

        [Then(@"Adjust Discrepancy page Apply the value selected for the current payment month to prospective months checkbox is checked")]
        public void ThenAdjustDiscrepancyPageApplyTheValueSelectedForTheCurrentPaymentMonthToProspectiveMonthsCheckboxIsChecked()
        {
            IWebElement button = Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainAdjDisc-chk-chkBoxProspectiveMonths']"));
            fw.ExecuteJavascript(button);
        }

        [Then(@"Verify Adjust Discrepancy page displays ""(.*)"" message")]
        public void ThenVerifyAdjustDiscrepancyPageDisplaysMessage(string p0)
        {
            tmsWait.Hard(5);
            IWebElement message = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0+"')]"));
            Assert.IsTrue(message.Displayed, p0 + "is not getting displayed");
        }

        [When(@"Adjust Discrepancy page ""(.*)"" is clicked")]
        public void WhenAdjustDiscrepancyPageIsClicked(string p0)
        {
            tmsWait.Hard(1);
            IWebElement button = Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainAdjDisc-btn-fmadbtn"+p0+"']"));
            fw.ExecuteJavascript(button);
            tmsWait.Hard(25);
        }



        [Then(@"Adjust Discrepancy page ""(.*)"" indicator is selected")]
        public void ThenAdjustDiscrepancyPageIndicatorIsSelected(string indicator)
        {
            //tmsWait.Hard(4);
            //SelectElement indicatorDD = new SelectElement(FRM.FRMAdjustDiscrepancy.indicatorCDropdown);
            //indicatorDD.SelectByText(indicator);
            By Drp = By.XPath("//label[contains(.,'Indicator')]/parent::div//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + indicator + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
        }

        [Then(@"Adjust Discrepancy page Part D ""(.*)"" indicator is selected")]
        public void ThenAdjustDiscrepancyPagePartDIndicatorIsSelected(string indicator)
        {
            By Drp = By.XPath("//label[contains(.,'Indicator')]/parent::div//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + indicator + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
        }

        [Then(@"Adjust Discrepancy page Part C ""(.*)"" indicator is selected")]
        public void ThenAdjustDiscrepancyPagePartCIndicatorIsSelected(string p0)
        {
            By Drp = By.XPath("//label[contains(.,'Indicator')]/parent::div//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + p0 + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
        }

        [Then(@"Adjust Discrepency page ""(.*)"" tab and ""(.*)"" is selected")]
        public void ThenAdjustDiscrepencyPageTabAndIsSelected(string p0, string p1)
        {
            string tabclick = tmsCommon.GenerateData(p0);
            string radioselect = tmsCommon.GenerateData(p1);

            if (ConfigFile.EnvType=="Main")
            {
              
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='frmMainAdjDisc-lbl-btnCms']")));
                tmsWait.Hard(3);
                fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.partDRadioButton);
                tmsWait.Hard(3);
            }
        }

        
        [Then(@"Adjust Discrepancy page Part C PBP Value ""(.*)"" is entered")]
        public void ThenAdjustDiscrepancyPagePartCPBPValueIsEntered(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            FRM.FRMAdjustDiscrepancy.PBPValue.SendKeys(value);
        }

        [Then(@"Adjust Discrepancy page Part D PBP Value ""(.*)"" is entered")]
        public void ThenAdjustDiscrepancyPagePartDPBPValueIsEntered(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            FRM.FRMAdjustDiscrepancy.PBPValue.SendKeys(value);
        }

        [Then(@"Adjust Discrepancy page Low Income Flag Value ""(.*)"" is entered")]
        public void ThenAdjustDiscrepancyPageLowIncomeFlagValueIsEntered(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            FRM.FRMAdjustDiscrepancy.PBPValue.SendKeys(value);
        }

        [Then(@"Adjust Discrepancy page ""(.*)"" Gender option is Clicked")]
        public void ThenAdjustDiscrepancyPageGenderOptionIsClicked(string p0)
        {
            if (p0 == "Male")
            {
                tmsWait.Hard(2);
                fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.genderMaleRadioButton);
            }
            else
            {
                tmsWait.Hard(2);
                fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.genderFemaleRadioButton);
            }
        }


        [Then(@"Adjust Discrepancy page ESRD MSP Status is set to ""(.*)""")]
        public void ThenAdjustDiscrepancyPageESRDMSPStatusIsSetTo(string value)
        {
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='frmMainAdjDisc-select-allDdl']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + value + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
        }

        [Then(@"Adjust Discrepancy page Apply the value selected for the current payment month to prospective months checkbox is Clicked")]
        public void ThenAdjustDiscrepancyPageApplyTheValueSelectedForTheCurrentPaymentMonthToProspectiveMonthsCheckboxIsClicked()
        {
            fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.ApplyvalueselectedcurrentpaymentmontoprospectivemonCheckbox);
        }


        [Then(@"Adjust Discrepancy page ""(.*)"" scope is selected")]
        public void ThenAdjustDiscrepancyPageScopeIsSelected(string scope)
        {
            if(scope.ToLower()== "apply one value to all payment months")
            {
                fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.applyonevaluetoallradiobutton);
            }
            else
            {
                fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.selectedmonthradiobutton);
            }
        }

        [Then(@"Adjust Discrepancy page prospective months selection box is selected")]
        public void ThenAdjustDiscrepancyPageProspectiveMonthsSelectionBoxIsSelected()
        {
            tmsWait.Hard(3);
            if(!FRM.FRMAdjustDiscrepancy.prospectiveMonthSelectionbox.Selected)
           // fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//input[@id='applyCurrentMonth']")));
            fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.prospectiveMonthSelectionbox);
        }

        [Then(@"Adjust Discrepancy page ESRD MSP Status ""(.*)"" is selected")]
        public void ThenAdjustDiscrepancyPageESRDMSPStatusIsSelected(string esrdStatus)
        {
            tmsWait.Hard(5);
            SelectElement esrd = new SelectElement(FRM.FRMAdjustDiscrepancy.esrdMSPStatus);
            esrd.SelectByText(esrdStatus);
        }


        [Then(@"Adjust Discrepancy page Date of Birth ""(.*)"" is entered")]
        public void ThenAdjustDiscrepancyPageDateOfBirthIsEntered(string date)
        {
            tmsWait.Hard(5);
            FRM.FRMAdjustDiscrepancy.dateofbirthTextbox.SendKeys(date);
        }

        [Then(@"Adjust Discrepancy page Long Term INST Part D ""(.*)"" is entered")]
        public void ThenAdjustDiscrepancyPageLongTermINSTPartDIsEntered(string value)
        {
            tmsWait.Hard(5);
            FRM.FRMAdjustDiscrepancy.longTermINSTTextbox.SendKeys(value);
        }

        [Then(@"Adjust Discrepancy page Long Term INST ""(.*)"" is entered")]
        public void ThenAdjustDiscrepancyPageLongTermINSTIsEntered(string value)
        {
            tmsWait.Hard(3);
            FRM.FRMAdjustDiscrepancy.longTermINSTChangeTypeTextbox.SendKeys(value);
        }

        [Then(@"Adjust Discrepancy page Part D Risk Factor ""(.*)"" is entered")]
        public void ThenAdjustDiscrepancyPagePartDRiskFactorIsEntered(string value)
        {
            tmsWait.Hard(2);
            FRM.FRMAdjustDiscrepancy.partDRiskFactor.SendKeys(value);
        }

        [Then(@"Adjust Discrepancy page Part D Risk Factor Change Type ""(.*)"" is entered")]
        public void ThenAdjustDiscrepancyPagePartDRiskFactorChangeTypeIsEntered(string value)
        {
            tmsWait.Hard(2);
            FRM.FRMAdjustDiscrepancy.partDRiskFactorChangeType.SendKeys(value);
        }


        [Then(@"Adjust Discrepancy page Reason of Agreement ""(.*)"" is selected")]
        public void ThenAdjustDiscrepancyPageReasonOfAgreementIsSelected(string reason1)
        {
            string reason = tmsCommon.GenerateData(reason1).ToUpper();
            By Drp = By.XPath("//label[contains(.,'Reason for Adjustment')]/parent::div//span[@class='k-select']");
            AngularFunction.selectDropDownValue(Drp, reason);
            tmsWait.Hard(3);
        }

        [When(@"Adjust Discrepancy page Back To Record button is Clicked")]
        public void WhenAdjustDiscrepancyPageBackToRecordButtonIsClicked()
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.BackToRecordButton);
        }

        [Then(@"Verify FRM Main ""(.*)"" page is displayed successfully")]
        public void ThenVerifyFRMMainPageIsDisplayedSuccessfully(string expected)
        {
            Assert.IsTrue(tmsWait.IsElementPresent(By.XPath("//span[contains(.,'Member Summary:')]")));
            Assert.AreEqual(FRM.FRMMemberSummary.MemberSummaryTitle.Text, expected, expected + " Page is displayed");
        }

        [Then(@"Adjust Discrepancy page Close button is Clicked")]
        public void ThenAdjustDiscrepancyPageCloseButtonIsClicked()
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.CloseButton);
        }



        [When(@"Adjust Discrepancy page Save button is clicked")]
        [Then(@"Adjust Discrepancy page Save button is clicked")]
        public void WhenAdjustDiscrepancyPageSaveButtonIsClicked()
        {
            tmsWait.Hard(1);
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainAdjDisc-btn-fmadbtnSave']"));
            fw.ExecuteJavascript(ele);
            
            tmsWait.Hard(25); // as ESI has huge data, increased wait.
        }
        [Then(@"Adjust Discrepancy page Save  button is clicked")]
        [When(@"Adjust Discrepancy page Save  button is clicked")]
        public void ThenAdjustDiscrepancyPageSaveButtonIsClicked()
        {
            tmsWait.Hard(1);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("(//button[@test-id='frmMainAdjDisc-btn-fmadbtnSave'])[1]"));
            fw.ExecuteJavascript(ele);
            //ele.Click();
            tmsWait.Hard(25);
        }
        [When(@"Adjust Discrepancy page Save button for selected month is clicked")]
        public void WhenAdjustDiscrepancyPageSaveButtonForSelectedMonthIsClicked()
        {
            tmsWait.Hard(5);
          
            IWebElement ele = Browser.Wd.FindElement(By.XPath("(//button[@test-id='frmMainAdjDisc-btn-fmadbtnSave'])[1]"));
            fw.ExecuteJavascript(ele);
            tmsWait.Hard(5);
        }

       
        [Then(@"Verify Adjustment Discrepancy page displayed ""(.*)""")]
        public void ThenVerifyAdjustmentDiscrepancyPageDisplayed(string expected)
        {
            tmsWait.Hard(15);
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainAdjDisc-span-successMessage']"));
            string actual = ele.Text;

            Assert.AreEqual(expected, actual, " Both results are not matching");

        }


        [Then(@"Adjust Discrepancy page Success Message will be displayed")]
        public void ThenAdjustDiscrepancyPageSuccessMessageWillBeDisplayed()
        {
            tmsWait.Hard(15);
           
                Assert.IsTrue(FRM.FRMAdjustDiscrepancy.successMessage.Displayed, "Success Message  is not displayed.");
                Assert.IsTrue(FRM.FRMAdjustDiscrepancy.backToAdjuDiscrpPageButton.Displayed, "Back to Adjust Discrepancy button is not displayed.");
                Assert.IsTrue(FRM.FRMAdjustDiscrepancy.backToRecordsButton.Displayed, "Back to Record button is not displayed.");
           
        }

        [Then(@"Adjust Discrepancy page Employer Group ""(.*)"" is selected")]
        public void ThenAdjustDiscrepancyPageEmployerGroupIsSelected(string p0)
        {
            if (p0 == "N")
            {
                fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.esrdStatusNoRadioButton);
                tmsWait.Hard(2);
            }
            else
            {
                fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.esrdStatusYesRadioButton);
                tmsWait.Hard(2);
            }
        }

        [Then(@"Adjust Discrepancy page ESRD Status ""(.*)"" is selected")]
        public void ThenAdjustDiscrepancyPageESRDStatusIsSelected(string p0)
        {
            if (p0 == "N")
            {
                fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.esrdStatusNoRadioButton);
                tmsWait.Hard(2);
            }
            else
            {
                fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.esrdStatusYesRadioButton);
                tmsWait.Hard(2);
            }

        }

        [Then(@"Adjust Discrepancy page Gender ""(.*)"" is selected")]
        public void ThenAdjustDiscrepancyPageGenderIsSelected(string p0)
        {
            tmsWait.Hard(5);
            FRM.FRMAdjustDiscrepancy.genderMale.Click();
        }

        [Then(@"Adjust Discrepancy page Hospice Status ""(.*)"" is selected")]
        public void ThenAdjustDiscrepancyPageHospiceStatusIsSelected(string p0)
        {
            if (p0 == "N")
            {
                fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.hospiceStatusNoRadioButton);
                tmsWait.Hard(2);
            }
            else
            {
                fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.hospiceStatusYesRadioButton);
                tmsWait.Hard(2);
            }
        }

        [Then(@"Adjust Discrepancy page Institutional Status ""(.*)"" is selected")]
        public void ThenAdjustDiscrepancyPageInstitutionalStatusIsSelected(string p0)
        {
            if (p0 == "N")
            {
                fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.esrdStatusNoRadioButton);
                tmsWait.Hard(2);
            }
            else
            {
                fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.esrdStatusYesRadioButton);
                tmsWait.Hard(2);
            }
        }

        [Then(@"Adjust Discrepancy page Long Term INST\(PartC\) ""(.*)"" is selected")]
        public void ThenAdjustDiscrepancyPageLongTermINSTPartCIsSelected(string p0)
        {
            tmsWait.Hard(4);
            fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.longTermInstStatusN);
            tmsWait.Hard(1);
        }

        [Then(@"Adjust Discrepancy page Medicaid Addon Status ""(.*)"" is selected")]
        public void ThenAdjustDiscrepancyPageMedicaidAddonStatusIsSelected(string p0)
        {
            if (p0 == "N")
            {
                fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.esrdStatusNoRadioButton);
                tmsWait.Hard(2);
            }
            else
            {
                fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.esrdStatusYesRadioButton);
                tmsWait.Hard(2);
            }
        }

        [Then(@"Adjust Discrepancy page Medicaid Status ""(.*)"" is selected")]
        public void ThenAdjustDiscrepancyPageMedicaidStatusIsSelected(string p0)
        {
            tmsWait.Hard(2);
            FRM.FRMAdjustDiscrepancy.medicadeStatusN.Click();
        }

        [Then(@"Adjust Discrepancy page MSP Status ""(.*)"" is selected")]
        public void ThenAdjustDiscrepancyPageMSPStatusIsSelected(string p0)
        {
            if (p0 == "N")
            {
                fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.esrdStatusNoRadioButton);
                tmsWait.Hard(2);
            }
            else
            {
                fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.esrdStatusYesRadioButton);
                tmsWait.Hard(2);
            }
        }

        [Then(@"Adjust Discrepancy page Nursing Home Status ""(.*)"" is selected")]
        public void ThenAdjustDiscrepancyPageNursingHomeStatusIsSelected(string p0)
        {
            if (p0 == "N")
            {
                fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.esrdStatusNoRadioButton);
                tmsWait.Hard(2);
            }
            else
            {
                fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.esrdStatusYesRadioButton);
                tmsWait.Hard(2);
            }
        }

        [Then(@"Adjust Discrepancy page OREC ""(.*)"" is selected")]
        public void ThenAdjustDiscrepancyPageORECIsSelected(string p0)
        {
            if (p0 == "N")
            {
                fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.esrdStatusNoRadioButton);
                tmsWait.Hard(2);
            }
            else
            {
                fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.esrdStatusYesRadioButton);
                tmsWait.Hard(2);
            }
        }

        [Then(@"Adjust Discrepancy page Out of Area ""(.*)"" is selected")]
        public void ThenAdjustDiscrepancyPageOutOfAreaIsSelected(string p0)
        {
            if (p0 == "N")
            {
                fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.esrdStatusNoRadioButton);
                tmsWait.Hard(2);
            }
            else
            {
                fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.esrdStatusYesRadioButton);
                tmsWait.Hard(2);
            }
        }

        [Then(@"Adjust Discrepancy page Part A Status ""(.*)"" is selected")]
        public void ThenAdjustDiscrepancyPagePartAStatusIsSelected(string p0)
        {
            if (p0 == "N")
            {
                fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.esrdStatusNoRadioButton);
                tmsWait.Hard(2);
            }
            else
            {
                fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.esrdStatusYesRadioButton);
                tmsWait.Hard(2);
            }
        }

        [Then(@"Adjust Discrepancy page Part B Status ""(.*)"" is selected")]
        public void ThenAdjustDiscrepancyPagePartBStatusIsSelected(string p0)
        {
            if (p0 == "N")
            {
                fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.esrdStatusNoRadioButton);
                tmsWait.Hard(2);
            }
            else
            {
                fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.esrdStatusYesRadioButton);
                tmsWait.Hard(2);
            }
        }

        [Then(@"Adjust Discrepancy page Part C Risk Factor ""(.*)"" is entered")]
        public void ThenAdjustDiscrepancyPagePartCRiskFactorIsEntered(string p0)
        {
            tmsWait.Hard(2);
            string riskFactor = tmsCommon.GenerateData(p0);
            FRM.FRMAdjustDiscrepancy.partCRiskFactorY.SendKeys(riskFactor);
        }

        [Then(@"Adjust Discrepancy page Change Type ""(.*)"" is entered")]
        public void ThenAdjustDiscrepancyPageChangeTypeIsEntered(string p0)
        {
            tmsWait.Hard(2);
            string riskFactor = tmsCommon.GenerateData(p0);
            FRM.FRMAdjustDiscrepancy.changeTypeTextbox.SendKeys(riskFactor);
        }

        [Then(@"Adjust Discrepancy page Segment ID ""(.*)"" is entered")]
        public void ThenAdjustDiscrepancyPageSegmentIDIsEntered(string p0)
        {
            tmsWait.Hard(2);
            string segmentID = tmsCommon.GenerateData(p0);
            FRM.FRMAdjustDiscrepancy.segmentIDTextbox.SendKeys(segmentID);
        }

        [Then(@"Adjust Discrepancy page State County Code Change Type ""(.*)"" is entered")]
        public void ThenAdjustDiscrepancyPageStateCountyCodeChangeTypeIsEntered(string code)
        {
            tmsWait.Hard(2);
            FRM.FRMAdjustDiscrepancy.stateCountyCodeChangeTypeTextbox.SendKeys(code);
        }

        [Then(@"Adjust Discrepancy page State County Code ""(.*)"" is entered")]
        public void ThenAdjustDiscrepancyPageStateCountyCodeIsEntered(string code)
        {
            tmsWait.Hard(2);
            FRM.FRMAdjustDiscrepancy.stateCountyCodeTextbox.SendKeys(code);
        }


        [Then(@"Adjust Discrepancy page Segment ID Change Type ""(.*)"" is entered")]
        public void ThenAdjustDiscrepancyPageSegmentIDChangeTypeIsEntered(string changeType)
        {
            tmsWait.Hard(2);
            FRM.FRMAdjustDiscrepancy.segmentIDChangeTypeTextbox.SendKeys(changeType);
        }


        [Then(@"Adjust Discrepancy page Risk Factor Change Type ""(.*)"" is selected")]
        public void ThenAdjustDiscrepancyPageRiskFactorChangeTypeIsSelected(string riskFactorChangeType)
        {
            tmsWait.Hard(2);
            SelectElement riskFactor = new SelectElement(FRM.FRMAdjustDiscrepancy.riskFactorChangeType);
            riskFactor.SelectByText(riskFactorChangeType);
        }


        [Then(@"Adjust Discrepancy page specific month is selected")]
        public void ThenAdjustDiscrepancyPageSpecificMonthIsSelected()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.currentMonthCheckbox);
        }

        [Then(@"Adjust Discrepancy page ADD button is clicked")]
        public void ThenAdjustDiscrepancyPageADDButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(FRM.FRMAdjustDiscrepancy.addButton);
        }

        [Then(@"Adjust Discrepancy page current months checkbox is checked")]
        public void ThenAdjustDiscrepancyPageCurrentMonthsCheckboxIsChecked()
        {
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[test-id='frmMainAdjDisc-chk-chkBoxProspectiveMonths']")));
            tmsWait.Hard(2);
        }

        [Then(@"Adjust Discrepancy page current month checkbox is checked")]
        public void ThenAdjustDiscrepancyPageCurrentMonthCheckboxIsChecked()
        {
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//input[@test-id='frmMainAdjDisc-chk-selectedAvailablePayMonths'])[1]")));
            tmsWait.Hard(2);
        }
        [Then(@"Adjust Discrepancy page current payment months checkbox is checked")]
        public void ThenAdjustDiscrepancyPageCurrentPaymentMonthsCheckboxIsChecked()
        {
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//input[@test-id='frmMainAdjDisc-chk-chkBoxProspectiveMonths']")));
            tmsWait.Hard(2);
        }



    }
}
