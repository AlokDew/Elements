﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.DLM
{

    class DLMElements
    {
            public static MMRDataLoad MMRDataLoad { get { return new MMRDataLoad(); } }
        public static Dashboard Dashboard { get { return new Dashboard(); } }
        public static UserManagement UserManagement { get { return new UserManagement(); } }

    }


    [Binding]
    public class UserManagement
    {
        public IWebElement ClickHereLink { get { return Browser.Wd.FindElement(By.LinkText("Click here")); } }
        public IWebElement userName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='edit-user-input-user-name']")); } }
        public IWebElement currentPassword { get { return Browser.Wd.FindElement(By.CssSelector("[name='currentpassword']")); } }
        public IWebElement newPassword { get { return Browser.Wd.FindElement(By.CssSelector("[name='newPassword']")); } }
        public IWebElement confirmPassword { get { return Browser.Wd.FindElement(By.CssSelector("[name='confirmPassword']")); } }
        public IWebElement submitButton { get { return Browser.Wd.FindElement(By.XPath("//button[contains(.,'Submit')]")); } }
    }
        [Binding]
    public class Dashboard
    {
        public IWebElement FileJobStatusPagination { get { return Browser.Wd.FindElement(By.XPath("//ul[@id='tableInputFilesPaging']")); } }
        public IWebElement FileJobStatusReferesh { get { return Browser.Wd.FindElement(By.XPath("//button[@id='btnRefresh']")); } }
        public IWebElement DataLoadStatusReferesh { get { return Browser.Wd.FindElement(By.XPath("//button[@id='btnRefreshTable']")); } }
        public IWebElement DataLoadStatusSelectDBDrpDownlist { get { return Browser.Wd.FindElement(By.XPath("//select[@id='ddlDbName']")); } }

    

    }

    [Binding]
        public class MMRDataLoad
        {
            public IWebElement MMRFileUploadParagraph { get { return Browser.Wd.FindElement(By.XPath("//div[@class='col-xs-12 padding0 marginBottom0']/p")); } }
            public IWebElement ManualMMRLoadParagraph { get { return Browser.Wd.FindElement(By.XPath("//div[@data-ng-controller='manualMMRLoadController']//p")); } }
           public IWebElement MMRFileUploadAccordian { get { return Browser.Wd.FindElement(By.XPath("(//div[@id='frmMainAccordion']//a)[1]")); } }
          public IWebElement ManualMMRLoadAccordian { get { return Browser.Wd.FindElement(By.XPath("(//div[@id='frmMainAccordion']//a)[2]")); } }
          public IWebElement MMRDataLoadSection { get { return Browser.Wd.FindElement(By.XPath("//div[contains(.,'MMR Load')]")); } }
          public IWebElement MMRFileUploadTitle { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'MMR File Upload')]")); } }
         public IWebElement SelectDBDrpDown { get { return Browser.Wd.FindElement(By.Id("ddlDbName")); } }
          public IWebElement ChooseFileLabel { get { return Browser.Wd.FindElement(By.Id("lblChooseFiles")); } }

   }

    [Binding]
    public class RAMXDataLoad
    {
        public IWebElement FileTypeDrpDown { get { return Browser.Wd.FindElement(By.Id("ddlFileType")); } }
        public IWebElement uploadBtn { get { return Browser.Wd.FindElement(By.Id("btnUploadFiles")); } }
    }

}
