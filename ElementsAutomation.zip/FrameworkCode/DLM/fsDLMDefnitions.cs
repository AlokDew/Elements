﻿//using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.DLM
{
    [Binding]
    class DLMDefnitions
    {

        [Then(@"Verify Data Load Dashboard page ""(.*)"" section is not displayed")]
        public void ThenVerifyDataLoadDashboardPageSectionIsNotDisplayed(string p0)
        {
            try {
                tmsWait.Hard(5);
                IWebElement element = Browser.Wd.FindElement(By.XPath("//a[@title='" + p0 + "']"));
                bool dis = element.Displayed;

                Assert.Fail("Expected Element should not be visible");
            }

            catch (Exception e)
            {
                Assert.IsTrue(true,"Excepted Element is not getting displayed:::Test Case passed");

            }

        }

        [When(@"User Login page Click Here to change link is Clicked")]
        public void WhenUserLoginPageClickHereToChangeLinkIsClicked()
        {
            tmsWait.Hard(2);
            try
            {
                ReUsableFunctions.clickOnWebElement(DLMElements.UserManagement.ClickHereLink);
                tmsWait.Implicit(30);
                tmsWait.Hard(10);
            }
            catch
            {

            }

        }

        [When(@"TMS Identity Manager Page Change Password page User Name is set to ""(.*)""")]
        public void WhenTMSIdentityManagerPageChangePasswordPageUserNameIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            string user = tmsCommon.GenerateData(p0);
            try
            {
                ReUsableFunctions.enterValueOnWebElement(DLMElements.UserManagement.userName, user);
            }
            catch
            {

            }
        }

        [When(@"TMS Identity Manager Page Change Password page User Name value is set as ""(.*)""")]
        public void WhenTMSIdentityManagerPageChangePasswordPageUserNameValueIsSetAs(string p0)
        {
            tmsWait.Hard(1);
            string user = tmsCommon.GenerateData(p0);
            try
            {
                ReUsableFunctions.enterValueOnWebElement(DLMElements.UserManagement.userName, user);
            }
            catch
            {

            }
        }

        [When(@"Clicked on Information Icon Clicked on Change Password menu")]
        public void WhenClickedOnInformationIconClickedOnChangePasswordMenu()
        {
            tmsWait.Hard(5);
            By info = By.XPath("//button[@id='Button2']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(info);

            By changepwd = By.XPath("//a[@test-id='header-btn-changePassword']");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(changepwd);



            tmsWait.Hard(11);
        }


        [When(@"TMS Identity Manager Page Change Password page User Name value is set to ""(.*)""")]
        public void WhenTMSIdentityManagerPageChangePasswordPageUserNameValueIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            string user = GlobalRef.UserName.ToString();
            try
            {
                ReUsableFunctions.enterValueOnWebElement(DLMElements.UserManagement.userName, user);
            }
            catch
            {

            }
        }

        [When(@"TMS Identity Manager Page Change Password page Current Password is set to ""(.*)""")]
        public void WhenTMSIdentityManagerPageChangePasswordPageCurrentPasswordIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            string current = tmsCommon.GenerateData(p0);
            try
            {
                ReUsableFunctions.enterValueOnWebElement(DLMElements.UserManagement.currentPassword, current);
            }
            catch
            { }
        }

        [When(@"TMS Identity Manager Page Change Password page New Password is set to ""(.*)""")]
        public void WhenTMSIdentityManagerPageChangePasswordPageNewPasswordIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            string newPwd = tmsCommon.GenerateData(p0);
            try
            {
                ReUsableFunctions.enterValueOnWebElement(DLMElements.UserManagement.newPassword, newPwd);
            }
            catch
            { }
        }

        [When(@"TMS Identity Manager Page Change Password page Confirm Password is set to ""(.*)""")]
        public void WhenTMSIdentityManagerPageChangePasswordPageConfirmPasswordIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            string confirPWD = tmsCommon.GenerateData(p0);
            try
            {
                ReUsableFunctions.enterValueOnWebElement(DLMElements.UserManagement.confirmPassword, confirPWD);
            }
            catch
            { }
            tmsWait.Hard(1);
        }

        [Then(@"Verify Member Information OEC Sales section Sales Rep Drop down is set to ""(.*)""")]
        public void ThenVerifyMemberInformationOECSalesSectionSalesRepDropDownIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(3);

                By Drp = By.XPath("//label[contains(.,'Sales Rep')]/parent::div//input");
                string actualValue = Browser.Wd.FindElement(Drp).GetAttribute("value");
                Assert.AreEqual(value, actualValue, " Both values are not matching");
            }
            else
            {

                IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@aria-owns='inputSalesRep_listbox']"));
                ele.SendKeys(value);
                tmsWait.Hard(1);
            }

        }

        [Then(@"Verify Member Information OEC Sales section Sales Rep Drop down does not have ""(.*)"" value")]
        public void ThenVerifyMemberInformationOECSalesSectionSalesRepDropDownDoesNotHaveValue(string p0)
        {
            bool flag=false;
            string salesrepValue = tmsCommon.GenerateData(p0);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Sales Rep')]/parent::div//span[@class='k-select']");

                By typeapp = By.XPath("//li[text()='" + salesrepValue + "']");

                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                try
                { 
                Browser.Wd.FindElement(Drp);
                }
                catch
                {
                    Assert.IsTrue(true,"Sales Rep Drop down has value " + salesrepValue + " which should not be in the list");

                }

            }
            else
            {

           
                IList<IWebElement> options = Browser.Wd.FindElements(By.XPath("//*[@id='inputSalesRep']/option"));
            for (int i=0; i<=options.Count-1;i++) {
                if (options[i].GetAttribute("value") == salesrepValue) {
                    flag = true;
                    break;
                }
            }
            Assert.AreEqual(false,flag, "Sales Rep Drop down has value "+salesrepValue+" which should not be in the list");
            }
        }



        [When(@"TMS Identity Manager Page Change Password page Submit Button is Clicked")]
        public void WhenTMSIdentityManagerPageChangePasswordPageSubmitButtonIsClicked()
        {
            tmsWait.Hard(1);
            try
            {
                ReUsableFunctions.clickOnWebElement(DLMElements.UserManagement.submitButton);
                tmsWait.Hard(5);
            }
            catch
            { }
            tmsWait.Hard(5);
        }

        [When(@"TMS Identity Manager Page Change Password page Submit Button is Clicked Verify Error Message as ""(.*)""")]
        public void WhenTMSIdentityManagerPageChangePasswordPageSubmitButtonIsClickedVerifyErrorMessageAs(string p0)
        {
            string expMessage = tmsCommon.GenerateData(p0);
            ReUsableFunctions.clickOnWebElement(DLMElements.UserManagement.submitButton);
            //string actualMsg = Browser.Wd.FindElement(By.XPath("//div[@class='toast-message']")).GetAttribute("aria-label");
            //fw.ConsoleReport(actualMsg);
            By toastMsg = By.XPath("//div[@class='k-notification-content']");
            string actValue = Browser.Wd.FindElement(toastMsg).Text;
            Assert.AreEqual(expMessage, actValue, " Both message are not matching");

        }

        [When(@"TMS Identity Manager Page Change Password page Submit Button is Clicked Verify the Error Message as ""(.*)""")]
        public void WhenTMSIdentityManagerPageChangePasswordPageSubmitButtonIsClickedVerifyTheErrorMessageAs(string p0)
        {
            string expMessage = tmsCommon.GenerateData(p0);
            ReUsableFunctions.clickOnWebElement(DLMElements.UserManagement.submitButton);
            //string actualMsg = Browser.Wd.FindElement(By.XPath("//span[@test-id='newChangePassword-span-newPasswordMissing']")).Text;
            string actualMsg = Browser.Wd.FindElement(By.XPath("//form[@id='newPasswordFrm']//span[@id='newPassword-error-msg']")).Text;
            fw.ConsoleReport("Displayed Error message "+actualMsg);
            Assert.AreEqual(expMessage, actualMsg, " Both message are not matching");
        }


        [When(@"Verify Error Message displayed as ""(.*)""")]
        public void WhenVerifyErrorMessageDisplayedAs(string p0)
        {
            //IWebElement ele = Browser.Wd.FindElement(By.XPath("//span[@test-id='newChangePassword-span-newPasswordMissing']"));
            //string actualMsg = Browser.Wd.FindElement(By.XPath("//form[@id='newPasswordFrm']//span[@id='newPassword-error-msg']")).Text;
            //bool actResults = ele.Displayed;
            //Assert.IsTrue(actResults, " Expected Error message is not displayed");
            string expMessage = tmsCommon.GenerateData(p0);
            //ReUsableFunctions.clickOnWebElement(DLMElements.UserManagement.submitButton);
            tmsWait.Hard(2);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//form[@Id='newPasswordFrm']//span[contains(text(),'"+ expMessage +"')]"));
            bool actResults = ele.Displayed;
            Assert.IsTrue(actResults, " Expected Error message :New password and confirm password should be same:is not displayed");

        }


        [When(@"TMS Identity Manager Page Change Password page Submit Button is Clicked and Verify Message ""(.*)""")]
        public void WhenTMSIdentityManagerPageChangePasswordPageSubmitButtonIsClickedAndVerifyMessage(string p0)
        {
            string expectedValue = tmsCommon.GenerateData(p0);
            ReUsableFunctions.clickOnWebElement(DLMElements.UserManagement.submitButton);
            //tmsWait.Hard(1);
            string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
            Assert.IsTrue(actualValue.Contains(expectedValue));
        }


        [When(@"DLM Application Crosswalk MBI Update ""(.*)"" tab is Clicked")]
        public void WhenDLMApplicationCrosswalkMBIUpdateTabIsClicked(string p0)
        {
            By tab = By.LinkText("Update MBI");
            ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(tab));
        }

        public void clickonCheckBox(IWebElement ele)
        {
            if (ele.Enabled)
            {
                if (!ele.Selected)
                {
                    fw.ExecuteJavascript(ele);
                }
            }

        }

        public void UnCheckCheckbox(IWebElement ele)
        {
            if (ele.Enabled)
            {
                if (ele.Selected)
                {
                    fw.ExecuteJavascript(ele);
                }
            }

        }
        [When(@"DLM Application When EAM ""(.*)"" row checkbox is checked FRM and RSM checkbox CDM checkbox PDEM and RxM checkbox RAM checkbox is UnChecked")]
        public void WhenDLMApplicationWhenEAMRowCheckboxIsCheckedFRMAndRSMCheckboxCDMCheckboxPDEMAndRxMCheckboxRAMCheckboxIsUnChecked(string p0)
        {
            string filename = tmsCommon.GenerateData(p0);

            IWebElement eam = Browser.Wd.FindElement(By.XPath("//input[@id='checkEamAll']"));
            clickonCheckBox(eam);
            UnCheckCheckbox(eam);
            IWebElement frm = Browser.Wd.FindElement(By.XPath("//input[@id='checkFrmRsmAll']"));
            clickonCheckBox(frm);
            UnCheckCheckbox(frm);
            IWebElement cdm = Browser.Wd.FindElement(By.XPath("//input[@id='checkFrmRsmAll']"));
            clickonCheckBox(cdm);
            UnCheckCheckbox(cdm);
            IWebElement pdemRxm = Browser.Wd.FindElement(By.XPath("//input[@id='checkPdemRxmAll']"));
            clickonCheckBox(pdemRxm);
            UnCheckCheckbox(pdemRxm);
            IWebElement ram = Browser.Wd.FindElement(By.XPath("//input[@id='checkRamAll']"));
            clickonCheckBox(ram);
            UnCheckCheckbox(ram);
            IWebElement eamrow = Browser.Wd.FindElement(By.XPath("//div[@test-id='crosswalkDataLoad-grid']/table//tr//td[contains(.,'"+filename+"')]/following-sibling::td/input[@id='checkBoxEam']"));
            clickonCheckBox(eamrow);

            //IWebElement markAsCompleteBtn = Browser.Wd.FindElement(By.XPath("//div[@test-id='crosswalkDataLoad-grid']/table//tr//td[contains(.,'" + filename + "')]/following-sibling::td/a[contains(.,'Mark Complete')]"));
            //fw.ExecuteJavascript(markAsCompleteBtn);
            tmsWait.Hard(2);
            //IWebElement confDia = Browser.Wd.FindElement(By.CssSelector("[test-id='confirmationDialog-btn-Yes']"));
            //fw.ExecuteJavascript(confDia);
            //tmsWait.Hard(4);
            IWebElement updateMBIbtn = Browser.Wd.FindElement(By.XPath("//button[@id='btnUpdateMbi']"));
            fw.ExecuteJavascript(updateMBIbtn);
            tmsWait.Hard(4);
            IWebElement confDiag = Browser.Wd.FindElement(By.CssSelector("[test-id='confirmationDialog-btn-Yes']"));
            fw.ExecuteJavascript(confDiag);

            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(20);
        }

        [When(@"DLM Application Crosswalk MBI Update Update MBI tab Mark As Complete button is Clicked")]
        public void WhenDLMApplicationCrosswalkMBIUpdateUpdateMBITabMarkAsCompleteButtonIsClicked()
        {
            By Btn = By.LinkText("Mark Complete");
            ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(Btn));
            tmsWait.Hard(3);
            By elem = By.CssSelector("[test-id='confirmationDialog-btn-Yes']");
            ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(elem));
            tmsWait.Hard(3);

        }


        [When(@"DLM Application Tasks section MBI Cross Walk Submenu ""(.*)"" menu is Clicked")]
        public void WhenDLMApplicationTasksSectionMBICrossWalkSubmenuMenuIsClicked(string menu)
        {

        By menuElem = By.XPath("//a[@title='"+ menu + "']");
            ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(menuElem));
            tmsWait.Hard(3);
        }

        [When(@"DLM Application Crosswalk MBI Update ""(.*)"" is Clicked")]
        public void WhenDLMApplicationCrosswalkMBIUpdateIsClicked(string menu)
        {
            By menuElem = By.XPath("//a[@title='" + menu + "']");
            ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(menuElem));
            tmsWait.Hard(3);
        }


        [Then(@"Verify Data Load page Manual Data Load Tab MMR File Upload section page ""(.*)"" field is displayed")]
        public void ThenVerifyDataLoadPageManualDataLoadTabMMRFileUploadSectionPageFieldIsDisplayed(string p0)
        {
            tmsWait.Hard(5);
            bool ele = Browser.Wd.FindElement(By.XPath("(//label[contains(.,'" + p0 + "')])[1]")).Displayed;
            Assert.IsTrue(ele, p0 + "is not getting displayed");
        }


        [Then(@"Verify Data Load page Manual Data Load Tab MMR File Upload section ""(.*)"" field is displayed")]
        public void ThenVerifyDataLoadPageManualDataLoadTabMMRFileUploadSectionFieldIsDisplayed(string p0)
        {
            tmsWait.Hard(5);
            bool ele = Browser.Wd.FindElement(By.XPath("(//label[contains(.,'" + p0 + "')])[2]")).Displayed;
            Assert.IsTrue(ele, p0 + "is not getting displayed");

        }
        [Then(@"Verify Data Load page Manual Data Load Tab MMR File Upload section ""(.*)"" field is displayed Successfully")]
        public void ThenVerifyDataLoadPageManualDataLoadTabMMRFileUploadSectionFieldIsDisplayedSuccessfully(string p0)
        {
            tmsWait.Hard(5);
            bool ele = Browser.Wd.FindElement(By.XPath("(//label[contains(.,'" + p0 + "')])[1]")).Displayed;
            Assert.IsTrue(ele, p0 + "is not getting displayed");
        }



        [Then(@"Verify Data Load page Manual Data Load Tab Manual MMR Load section ""(.*)"" field is displayed")]
        public void ThenVerifyDataLoadPageManualDataLoadTabManualMMRLoadSectionFieldIsDisplayed(string p0)
        {
            tmsWait.Hard(5);
            bool ele = Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + p0 + "')]")).Displayed;
            Assert.IsTrue(ele, p0 + "is not getting displayed");
        }



        [Then(@"Verify Data Load page Manual Data Load Tab ""(.*)"" paragraph is displayed")]
        public void ThenVerifyDataLoadPageManualDataLoadTabParagraphIsDisplayed(string p0)
        {
            tmsWait.Hard(5);
                       
            bool ele = Browser.Wd.FindElement(By.XPath("//div[@data-ng-controller='manualMMRLoadController']//p[contains(.,'" + p0 + "')]")).Displayed;
            Assert.IsTrue(ele, p0 + "is not getting displayed");
        }


        [Then(@"Verify Data Load page Manual Data Load Tab Execute button is displayed")]
        public void ThenVerifyDataLoadPageManualDataLoadTabExecuteButtonIsDisplayed()
        {
            bool execute = Browser.Wd.FindElement(By.Id("btnUploadFiles")).Displayed;
            Assert.IsTrue(execute, "Execute button is not getting displayed");
        }

        [Then(@"Verify Data Load page Manual Data Load Tab ""(.*)"" paragraph is displayed successfully")]
        public void ThenVerifyDataLoadPageManualDataLoadTabParagraphIsDisplayedSuccessfully(string p0)
        {
            bool paragraph = Browser.Wd.FindElement(By.XPath("//span[contains(.,'"+p0+"')]")).Displayed;
            Assert.IsTrue(paragraph, "Execute button is not getting displayed");
        }


        [Then(@"Verify Data Load page Schedule File and Data Load section ""(.*)"" field is displayed")]
        public void ThenVerifyDataLoadPageScheduleFileAndDataLoadSectionFieldIsDisplayed(string field)
        {
            bool elepresence = false;
            tmsWait.Hard(5);

            switch (field)
            {
                
                case "Client Database Name:":
                    elepresence = Browser.Wd.FindElement(By.XPath("(//div[@data-ng-controller='scheduleLoadController']//select)[1]")).Displayed;
                    Assert.IsTrue(elepresence, field + "is not getting displayed");
                    break;
                case "Job Name:":
                   elepresence = Browser.Wd.FindElement(By.XPath("(//input[@id='txtJobName'])[1]")).Displayed;
                    Assert.IsTrue(elepresence, field + "is not getting displayed");
                    break;
                case "Start Date:":
                    elepresence = Browser.Wd.FindElement(By.XPath("(//input[@is-open='openedStart'])[1]")).Displayed;
                    Assert.IsTrue(elepresence, field + "is not getting displayed");
                    break;
                case "End Date:":
                    elepresence = Browser.Wd.FindElement(By.XPath("(//input[@is-open='openedEnd'])[1]")).Displayed;
                    Assert.IsTrue(elepresence, field + "is not getting displayed");
                    break;
                case "Day of Month:":
                    elepresence = Browser.Wd.FindElement(By.XPath("(//div[@data-ng-controller='scheduleLoadController']//select)[2]")).Displayed;
                    Assert.IsTrue(elepresence, field + "is not getting displayed");
                    break;
                case "Time (HH:mm):":
                     elepresence = Browser.Wd.FindElement(By.XPath("(//div[@data-ng-controller='scheduleLoadController']//select)[3]")).Displayed;
                    Assert.IsTrue(elepresence, field + "is not getting displayed");
                    break;
                case "Occurrences:":
                     elepresence = Browser.Wd.FindElement(By.XPath("//input[@id='rdbMonthly']")).Displayed;
                    Assert.IsTrue(elepresence, field + "is not getting displayed");
                    break;

                case "Reset":
                    elepresence = Browser.Wd.FindElement(By.XPath("(//button[@id='btnCancel'])[1]")).Displayed;
                    Assert.IsTrue(elepresence, field + "is not getting displayed");
                    break;
                case "Schedule":
                    elepresence = Browser.Wd.FindElement(By.XPath("(//button[@id='btnSchedule'])[1]")).Displayed;
                    Assert.IsTrue(elepresence, field + "is not getting displayed");
                    break;

            }
        }

        [When(@"TMS Data Load Manager page ""(.*)"" Tab is Clicked Successfully")]
        public void WhenTMSDataLoadManagerPageTabIsClickedSuccessfully(string p0)
        {
            tmsWait.Hard(5);
            IWebElement ele = null;
            switch (p0)
            {
                case "MMR File Upload":

                    ele = Browser.Wd.FindElement(By.XPath("(//a[@role='button'])[1]"));
                    fw.ExecuteJavascript(ele);
                    break;

                case "Manual MMR Load":
                    ele = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Manual MMR Load')]"));
                    fw.ExecuteJavascript(ele);
                    break;
                case "Schedule File and Data Load":
                    ele = Browser.Wd.FindElement(By.XPath("(//a[@role='button'])[3]"));
                    fw.ExecuteJavascript(ele);
                    break;

            }

        }

        [When(@"TMS Data Load Manager page ""(.*)"" Tab is Clicked")]
        public void WhenTMSDataLoadManagerPageTabIsClicked(string p0)
        {
            IWebElement ele = null;
            switch (p0)
            {
                case "MMR File Upload":
                    try
                    {
                        ele = Browser.Wd.FindElement(By.XPath("(//a[@role='button'])[1]"));
                        if (ele.Displayed)
                        {
                            break;
                        }
                        else
                        {
                            tmsWait.Hard(5);
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//accordion[@close-others='accordionData.openMmrAtATime']//a)[1]")));
                        }
                    }
                    catch
                    {

                    }

                    break;

                case "Manual MMR Load":
                    try
                    {
                        ele = Browser.Wd.FindElement(By.XPath("(//a[@role='button'])[2]"));
                        if (ele.Displayed)
                        {
                            break;
                        }
                        else
                        {
                            tmsWait.Hard(5);
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//accordion[@close-others='accordionData.openMmrAtATime']//a)[2]")));
                        }
                    }
                    catch
                    {

                    }

                    break;

                case "Schedule File and Data Load":
                    try
                    {
                        ele = Browser.Wd.FindElement(By.Id("btnSchedule"));
                        if (ele.Displayed)
                        {
                            break;
                        }
                        else
                        {
                            tmsWait.Hard(5);
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//accordion[@close-others='accordionData.oneAtATime']//a)[3]")));
                        }
                    }
                    catch
                    {

                    }

                    break;

                case "Manual Data Load":
                    try
                    {
                        ele = Browser.Wd.FindElement(By.Id("btnExecute"));
                        if (ele.Displayed)
                        {
                            break;
                        }
                        else
                        {
                            tmsWait.Hard(5);
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//accordion[@close-others='accordionData.oneAtATime']//a)[1]")));
                        }
                    }
                    catch
                    {

                    }

                    break;

                case "File Upload":
                    try
                    {
                        ele = Browser.Wd.FindElement(By.Id("btnUploadFiles"));
                        if (ele.Displayed)
                        {
                            break;
                        }
                        else
                        {
                            tmsWait.Hard(5);
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//accordion[@close-others='accordionData.oneAtATime']//a)[2]")));
                        }
                    }
                    catch
                    {

                    }

                    break;
            }
        }

        [When(@"TMS Data Load Manager page ""(.*)"" section is Clicked")]
        public void WhenTMSDataLoadManagerPageSectionIsClicked(string p0)
        {
            IWebElement sec = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]"));
            fw.ExecuteJavascript(sec);

        }

        [Then(@"Verify MMR Data Load page displays section ""(.*)""")]
        public void ThenVerifyMMRDataLoadPageDisplaysSection(string p0)
        {
            bool section = Browser.Wd.FindElement(By.XPath("//accordion[@close-others='accordionData.openMmrAtATime']//span[contains(.,'"+p0+"')]")).Displayed;
            Assert.IsTrue(section, section + "is not getting displayed");
        }


        [Then(@"Verify DLM page MMR File Upload section displays message ""(.*)""")]
        public void ThenVerifyDLMPageMMRFileUploadSectionDisplaysMessage(string exp)
        {
            bool elementPresence = Browser.Wd.FindElement(By.XPath("//span[contains(.,'"+exp+"')]")).Displayed;
            Assert.IsTrue(elementPresence, " Element is not found");
        }

        [Then(@"Verify DLM page displays ""(.*)"" section successfully")]
        public void ThenVerifyDLMPageDisplaysSectionSuccessfully(string Field)
        {
            bool section = false;
            switch (Field)
            {
                case "MMR Data Load":
                    section = DLMElements.MMRDataLoad.MMRDataLoadSection.Displayed;
                    Assert.IsTrue(section, Field+" is not getting displayed");                 
                    break;
                case "MMR File Upload":
                    section = DLMElements.MMRDataLoad.MMRFileUploadTitle.Displayed;
                    Assert.IsTrue(section, Field + " is not getting displayed");
                    break;
            }
        }

        [When(@"Data Load - Dashboard page Data Load Status tab Referesh button is Cliced")]
        public void WhenDataLoad_DashboardPageDataLoadStatusTabRefereshButtonIsCliced()
        {
            DLMElements.Dashboard.DataLoadStatusReferesh.Click();
       
        }

        [When(@"Data Load - Dashboard page Data Load Status tab Select Database Dropdown is set to ""(.*)""")]
        public void WhenDataLoad_DashboardPageDataLoadStatusTabSelectDatabaseDropdownIsSetTo(string p0)
        {
            SelectElement drp = new SelectElement(DLMElements.Dashboard.DataLoadStatusSelectDBDrpDownlist);
            drp.SelectByText(p0);
        }


        [Then(@"Verify Data Load - Dashboard page ""(.*)"" tab Pagination is displayed")]
        public void ThenVerifyDataLoad_DashboardPageTabPaginationIsDisplayed(string Field)
        {

            bool section = false;
            switch (Field)
            {
                case "File Job Status":
                    section = DLMElements.Dashboard.FileJobStatusPagination.Displayed;
                    Assert.IsTrue(section, Field + " is not getting displayed");
                    break;
                case "Data Load Status":
                    section = DLMElements.Dashboard.FileJobStatusPagination.Displayed;
                    Assert.IsTrue(section, Field + " is not getting displayed");
                    break;
            }
        }


        [When(@"MMR File Upload section Select Database is set to ""(.*)""")]
        [When(@"DLM File Upload section under Main menu Select Application is set to ""(.*)""")]
        public void WhenMMRFileUploadSectionSelectDatabaseIsSetTo(string p0)
        {
            By Drp = By.XPath("//label[contains(.,'Select Application')]/parent::div//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + p0 + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
        }

        [Then(@"DLM Data Load section under Dashboard Select Application is set to ""(.*)""")]
        public void ThenDLMDataLoadSectionUnderDashboardSelectApplicationIsSetTo(string p0)
        {
            IWebElement ele = Browser.Wd.FindElement(By.Id("ddllblDataLoadApplication"));
            SelectElement s = new SelectElement(ele);
            s.SelectByText(p0);
            tmsWait.Hard(2);
        }

        [Then(@"i click on ""(.*)""")]
        public void ThenIClickOn(string p0)
        {
            tmsWait.Hard(4);
            string option = tmsCommon.GenerateData(p0);
            IWebElement link= Browser.Wd.FindElement(By.XPath("//*[@class='accordionHeader ng-scope'][contains(.,'" + option + "')]"));
            fw.ExecuteJavascript(link);
            tmsWait.Hard(2);
        }

       
        [Then(@"verify status of uploaded files is ""(.*)"" on ""(.*)"" application")]
        public void ThenVerifyStatusOfUploadedFilesIsOnApplication(string uploadStatus, string appName)
        {
            string DBName= "FileNameQuery";
            tmsWait.Hard(2);
            string dt;
            SelectElement s = new SelectElement(Browser.Wd.FindElement(By.Id("ddllblDataLoadApplication")));
            s.SelectByText(appName);
            tmsWait.Hard(2);

            string expStatus = tmsCommon.GenerateData(uploadStatus);

            string ClaimsFile = "Claims_Commercial_201809_Suspect_Valid000119.txt";
            string MembersFile = "Members_Commercial_201506_Valid00011.txt";
            string PharmacyFile = "Pharmacy_Commercial_20181217_Valid000119.txt";
            string ProvidersFile = "Providers_Commercial_20181217_Valid000119.txt";
            string SpansFile = "Spans_Commercial_201806_Various_Valid000119.txt";

            tmsWait.Hard(2);

            db.CreateConnRAMX(DBName);
            string dbQuery_pharmacy = tmsCommon.GenerateData("select top 1 FileEndTime from pdmupload.dbo.DataLoad_FileInfo where FileType = 'Pharmacy' and FileName = '"+ PharmacyFile+"' order by FileEndTime desc");
            string dbQuery_claims = tmsCommon.GenerateData("select top 1 FileEndTime from pdmupload.dbo.DataLoad_FileInfo where FileType = 'Claims' and FileName = '" + ClaimsFile + "' order by FileEndTime desc");
            string dbQuery_providers = tmsCommon.GenerateData("select top 1 FileEndTime from pdmupload.dbo.DataLoad_FileInfo where FileType = 'Providers' and FileName = '" + ProvidersFile + "' order by FileEndTime desc");
            string dbQuery_spans = tmsCommon.GenerateData("select top 1 FileEndTime from pdmupload.dbo.DataLoad_FileInfo where FileType = 'Spans' and FileName = '" + SpansFile + "' order by FileEndTime desc");
            string dbQuery_member = tmsCommon.GenerateData("select top 1 FileEndTime from pdmupload.dbo.DataLoad_FileInfo where FileType = 'Member' and FileName = '" + MembersFile + "' order by FileEndTime desc");

            tmsWait.Hard(5);

            IWebElement btnRefresh = Browser.Wd.FindElement(By.Id("btnRefresh"));
            fw.ExecuteJavascript(btnRefresh);
            tmsWait.Hard(5);
            IWebElement filejobstatus_link = Browser.Wd.FindElement(By.XPath("//*[@class='accordionHeader ng-scope'][contains(.,'File Job Status')]"));
            filejobstatus_link.Click();

            db.AddDBQuery(DBName, dbQuery_member);
            dt = db.StoreDBResultsInString(DBName);
            fw.ExecuteJavascript(btnRefresh);
            filejobstatus_link.Click();
            tmsWait.Hard(2);
            string ExpDate_member = Convert.ToDateTime(dt).ToString("MMM  d yyyy h:mmtt");
            string actualStatus_member = Browser.Wd.FindElement(By.XPath("//tr[contains(.,'" + MembersFile + "') and contains(.,'" + ExpDate_member + "')]//parent::tr//td[3]/span")).Text.ToString();
            Assert.AreEqual(expStatus, actualStatus_member, "File Load Status is not complete ");

            db.AddDBQuery(DBName, dbQuery_spans);
            dt = db.StoreDBResultsInString(DBName);
            fw.ExecuteJavascript(btnRefresh);
            filejobstatus_link.Click();
            tmsWait.Hard(2);
            string ExpDate_spans = Convert.ToDateTime(dt).ToString("MMM  d yyyy h:mmtt");
            string actualStatus_spans = Browser.Wd.FindElement(By.XPath("//tr[contains(.,'" + SpansFile + "') and contains(.,'" + ExpDate_spans + "')]//parent::tr//td[3]/span")).Text.ToString();
            Assert.AreEqual(expStatus, actualStatus_spans, "File Load Status is not complete");

            db.AddDBQuery(DBName, dbQuery_providers);
            dt = db.StoreDBResultsInString(DBName);
            fw.ExecuteJavascript(btnRefresh);
            filejobstatus_link.Click();
            tmsWait.Hard(2);
            string ExpDate_Providers = Convert.ToDateTime(dt).ToString("MMM  d yyyy h:mmtt");
            string actualStatus_Providers = Browser.Wd.FindElement(By.XPath("//tr[contains(.,'" + ProvidersFile + "') and contains(.,'" + ExpDate_Providers + "')]//parent::tr//td[3]/span")).Text.ToString();
            Assert.AreEqual(expStatus, actualStatus_Providers, "File Load Status is not complete");

            db.AddDBQuery(DBName, dbQuery_claims);
            dt = db.StoreDBResultsInString(DBName);
            string ExpDate_Claims = Convert.ToDateTime(dt).ToString("MMM  d yyyy h:mmtt");
            fw.ExecuteJavascript(btnRefresh);
            filejobstatus_link.Click();
            tmsWait.Hard(2);
            string actualStatus_Claims = Browser.Wd.FindElement(By.XPath("//tr[contains(.,'"+ ClaimsFile + "') and contains(.,'"+ ExpDate_Claims + "')]//parent::tr//td[3]/span")).Text.ToString();
            Assert.AreEqual(expStatus, actualStatus_Claims, "File Load Status is not complete");

            db.AddDBQuery(DBName, dbQuery_pharmacy);
            dt = db.StoreDBResultsInString(DBName);
            string ExpDate_Pharmacy = Convert.ToDateTime(dt).ToString("MMM  d yyyy h:mmtt");
            fw.ExecuteJavascript(btnRefresh);
            filejobstatus_link.Click();
            tmsWait.Hard(2);
            string actualStatus_Pharmacy = Browser.Wd.FindElement(By.XPath("//tr[contains(.,'" + PharmacyFile + "') and contains(.,'" + ExpDate_Pharmacy + "')]//parent::tr//td[3]/span")).Text.ToString();
            Assert.AreEqual(expStatus, actualStatus_Pharmacy, "File Load Status is not complete");

                       
            string[] arrFileName = { ClaimsFile, MembersFile, PharmacyFile, ProvidersFile, SpansFile };
            string[] arrStatus = { actualStatus_Claims, actualStatus_member, actualStatus_Pharmacy, actualStatus_Providers, actualStatus_spans };
            for (int i = 0; i <= arrStatus.Length - 1; i++)
            {
                int ReturnStatus = StatusValidation(arrStatus[i]);
                fw.ConsoleReport("Status of File Name :" + arrFileName[i]+ " is :"+ ReturnStatus);
                while (ReturnStatus != 0)
                {
                    fw.ExecuteJavascript(btnRefresh);
                    tmsWait.Hard(5);
                    ReturnStatus = StatusValidation(arrStatus[i]);
                }
            }
        }
        

         public int StatusValidation(string actualStatus)
        {
            if (actualStatus.Equals("Completed"))
            {

                return 0;
            }
            else if (actualStatus.Equals("Completed - Data Errors Exist"))
            {
                return 0;
            }

            else if (actualStatus.Equals("Medical claims file creation completed."))
            {
                return 0;
            }

            return 0;
        }


        [When(@"verify data load status message is displayed as ""(.*)""")]
        [Then(@"verify data load status message is displayed as ""(.*)""")]
        public void WhenVerifyDataLoadStatusMessageIsDisplayedAs(string p0)
        {
            string expText = tmsCommon.GenerateData(p0);
            string DBName = "FileNameQuery";
            IWebElement btnRefresh = Browser.Wd.FindElement(By.Id("btnRefresh"));
            IWebElement dataLoadstatus_link = Browser.Wd.FindElement(By.XPath("//*[@class='accordionHeader ng-scope'][contains(.,'Data Load Status')]"));
          
            db.CreateConnRAMX(DBName);
            string dbQuery = tmsCommon.GenerateData("select top 1  TranDate from [RAMX].[dbo].tbDataPumpTran order by TranDate desc");

            db.AddDBQuery(DBName, dbQuery);
            string dt = db.StoreDBResultsInString(DBName);
            string loadDatetime = Convert.ToDateTime(dt).ToString("MM/dd/yyyy HH:mm:ss tt");
            Console.Write("ExpLoadDatetime " + loadDatetime);
            tmsWait.Hard(5);
            string actualMessage = Browser.Wd.FindElement(By.XPath("//*[@id='grdDataloadStatusList']//tr[contains(.,'"+ expText + "') and contains(.,'"+ loadDatetime + "')]//td[2]/span")).Text;
            
            int ReturnStatus = StatusValidation(actualMessage);
           
            while (ReturnStatus != 0)
            {
                fw.ExecuteJavascript(btnRefresh);
                tmsWait.Hard(5);
                dataLoadstatus_link.Click();
                tmsWait.Hard(1);
                actualMessage = Browser.Wd.FindElement(By.XPath("//*[@id='grdDataloadStatusList']//tr[contains(.,'" + expText + "') and contains(.,'" + loadDatetime + "')]//td[2]/span")).Text;
                ReturnStatus = StatusValidation(actualMessage);
            }

          //  ScenarioContext.Current["CurrentDataLoadDateTime"] = Convert.ToDateTime(dt).AddHours(2).ToString("M/d/yyyy h:mm tt");
           // Console.Write("CurrentDataLoadDateTime = "+ScenarioContext.Current["CurrentDataLoadDateTime"]);

        }


        [When(@"i click on ""(.*)""")]
        public void WhenIClickOn(string p0)
        {
            string option = tmsCommon.GenerateData(p0);
            switch (p0) {
                case "Data Load Status":
                    IWebElement filejobstatus_link = Browser.Wd.FindElement(By.XPath("//*[@class='accordionHeader ng-scope'][contains(.,'"+option+"')]"));
                    filejobstatus_link.Click();
                    break;
            }
           
        }

        [Then(@"verify generated files ""(.*)"" exists in ""(.*)"" folder for RAMX application")]
        public void ThenVerifyGeneratedFilesExistsInFolderForRAMXApplication(string p0, string p1)
        {
            string folderName = tmsCommon.GenerateData(p1);
            if (folderName.Equals("Archive"))
            {
                folderName = "Output\\Archive";
            }
            
            //Getting Output folder
            string[] url = ConfigFile.URL.Split('/');
            string[] surl = url[2].Split('.');
            string outputpath = @"\\" + surl[1] + @"\" + "TMSShareFolder" + @"\" + surl[0] + @"\" + ConfigFile.RAMXdb + @"\" + folderName;

            //Check for the file
            string[] filenames = p0.Split(',');
            for (int i = 0; i < filenames.Length; i++)
            {
                DirectoryInfo fileinfo = new DirectoryInfo(outputpath);
              
                foreach (FileInfo f in fileinfo.GetFiles("*.txt"))
                {
                    ////Console.Write(f.Name + "   " + filenames[i] + "    " + f.LastWriteTime+"   "+ ScenarioContext.Current["CurrentDataLoadDateTime"]);
                    //if (f.Name.Contains(filenames[i]) && f.LastWriteTime.ToString("M/d/yyyy h:mm tt").Contains(ScenarioContext.Current["CurrentDataLoadDateTime"].ToString()))
                    //    {
                    //    Console.Write(f.Name + " file exists in Output Folder: ");
                    //    break;
                    //}
                }
            }
        }


        [Then(@"in DLM Manual Data Load section Execute button is clicked")]
        public void ThenInDLMManualDataLoadSectionExecuteButtonIsClicked()
        {
            tmsWait.Hard(2);
            IWebElement ele = Browser.Wd.FindElement(By.Id("btnExecute"));
            ele.Click();
            tmsWait.Hard(2);
        }


        [When(@"DLM File Upload section under Main menu, select files to upload for RAMX application")]
        public void WhenDLMFileUploadSectionUnderMainMenuSelectFilesToUploadForRAMXApplication()
        {
            tmsWait.Hard(2);
            string ALMTestID = "34050";
            string ClaimsFile = "Claims_Commercial_201809_Suspect_Valid000119.txt";
            string MembersFile = "Members_Commercial_201506_Valid00011.txt";
            string PharmacyFile = "Pharmacy_Commercial_20181217_Valid000119.txt";
            string ProvidersFile = "Providers_Commercial_20181217_Valid000119.txt";
            string SpansFile = "Spans_Commercial_201806_Various_Valid000119.txt";
            IWebElement ele = Browser.Wd.FindElement(By.Id("ddlFileType"));
            SelectElement s = new SelectElement(ele);
            tmsWait.Hard(1);
            if (ele.Enabled)
            {
              
                s.SelectByText("Claims*");
                pressTabKey();
                RAMX_fileUpload(ALMTestID, ClaimsFile);
               
                s.SelectByText("Members*");
                pressTabKey();
                RAMX_fileUpload(ALMTestID, MembersFile);
               
                s.SelectByText("Pharmacy");
                pressTabKey();
                RAMX_fileUpload(ALMTestID, PharmacyFile);
              
                s.SelectByText("Providers*");
                pressTabKey();
                RAMX_fileUpload(ALMTestID, ProvidersFile);
            
                s.SelectByText("Spans*");
                pressTabKey();
                RAMX_fileUpload(ALMTestID, SpansFile);

                tmsWait.Hard(2);
                IWebElement uploadBtn = Browser.Wd.FindElement(By.Id("btnUploadFiles"));
                fw.ExecuteJavascript(uploadBtn);
                tmsWait.Hard(2);
               }
            else {
            string messageText= Browser.Wd.FindElement(By.XPath("//*[@class='panel-collapse collapse in']/div/div/div/div[2]/div/div")).Text;
                Assert.Fail("RAMX Data Load did not happen: "+ messageText);
            }
        }

        public static void pressTabKey() {
            IWebElement currentElement = Browser.Wd.SwitchTo().ActiveElement();
            currentElement.SendKeys(Keys.Tab);
        }


        [Then(@"verify the message ""(.*)"" displayed on the page")]
        public void ThenVerifyTheMessageDisplayedOnThePage(string p0)
        {
            //DateTime dt = DateTime.Now;
            //ScenarioContext.Current["CurrentFileLoadTime"] = dt.ToString("MMM dd yyyy h:mmtt");
            tmsWait.Hard(4);
            string expMessageText = tmsCommon.GenerateData(p0);
            string actualMessageText = Browser.Wd.FindElement(By.XPath("//*[@class='panel-collapse collapse in']/div/div/div/div[2]/div/div")).Text;
            Assert.AreEqual(expMessageText, actualMessageText, "Correct Message is not displayed");
        }

        [Then(@"verify the message on Data Load screen ""(.*)"" displayed on the page")]
        public void ThenVerifyTheMessageOnDataLoadScreenDisplayedOnThePage(string p0)
        {
            string expMessageText = tmsCommon.GenerateData(p0);
            string actualMessageText = Browser.Wd.FindElement(By.XPath("//*[@class='panel-collapse in collapse']/div/div/div[1]/div[3]/div/div")).Text;
            Assert.AreEqual(expMessageText, actualMessageText, "Correct Message is not displayed");
        }



        public static void RAMX_fileUpload(string ALMTestID, string RAMXfile)
        {
            Boolean didUpload = ALMUtilities.GetALMTestPlanAttachedFile(RAMXfile, ALMTestID);
            if (didUpload)
            {
                try
                {
                    IList<IWebElement> fileNames = Browser.Wd.FindElements(By.XPath("//*[@class='k-upload-files k-reset']//li"));
                    foreach (IWebElement f in fileNames)
                    {
                        if (f.Text.ToString().Contains(RAMXfile))
                        {
                            Browser.Wd.FindElement(By.XPath("//*[@class='k-upload-files k-reset']//li[contains(.,'" + RAMXfile + "')]//button")).Click();
                            tmsWait.Hard(1);
                        }
                    }
                }
                catch (Exception e) {

                }

            }
            string FileName = "C:\\Temp\\" + RAMXfile;
            ////System.Windows.Forms.SendKeys.SendWait(FileName);
            ////System.Windows.Forms.SendKeys.SendWait("{ENTER}");
            IWebElement fileInput = Browser.Wd.FindElement(By.Id("fileUpload"));
            fileInput.SendKeys(FileName);
        }


        [Then(@"Verify MMR File Upload section display message as ""(.*)""")]
        public void ThenVerifyMMRFileUploadSectionDisplayMessageAs(string exp)
        {
            string act = DLMElements.MMRDataLoad.ChooseFileLabel.Text;
            Assert.AreEqual(exp, act, exp + "is not geting displayed");
        }


        [When(@"TMS Data Load Manager page ""(.*)"" Accordion is Clicked")]
        public void WhenTMSDataLoadManagerPageAccordionIsClicked(string Accord)
        {
            tmsWait.Hard(5);
            switch(Accord)
            {
                case "MMR File Upload":
                    fw.ExecuteJavascript(DLM.DLMElements.MMRDataLoad.MMRFileUploadAccordian);
                    break;
                case "Manual MMR Load":
                    fw.ExecuteJavascript(DLM.DLMElements.MMRDataLoad.ManualMMRLoadAccordian);
                    break;

            }
        }


        [When(@"DLM will be closed")]
        [Then(@"DLM will be closed")]
        public void WhenDLMWillBeClosed()
        {
           // Browser.CloseWebDriver();
        }

    }
}
