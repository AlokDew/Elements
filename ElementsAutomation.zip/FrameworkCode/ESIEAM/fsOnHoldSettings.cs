﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Data;
//using System.Data.SqlClient;
using Microsoft.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using TMSoR1.FrameworkCode;

namespace TMSoR1.FrameworkCode.ESIEAM
{
    [Binding]
    class fsOnHoldSettings
    {

        [When(@"I clicked on On Hold Settings History link")]
        public void WhenIClickedOnOnHoldSettingsHistoryLink()
        {
            IWebElement link = Browser.Wd.FindElement(By.CssSelector("[test-id='onHoldReasons-lbl-settingHistory']"));
            fw.ExecuteJavascript(link);
            tmsWait.Hard(3);
        }

        [When(@"Create File ""(.*)"" using Query ""(.*)"" and Import it")]
        public void WhenCreateFileUsingQueryAndImportIt(string p0, string p1)
        {
            string filename = tmsCommon.GenerateData(p0);
            string query = tmsCommon.GenerateData(p1);
            string datetime = DateTime.Now.ToString("yyyyMMdd_HHmmss");
            string LogFolder = @"C:\temp\";
       
            try
            {
                string FileNamePart =  filename;
                //Declare Variables and provide values
                // string FileNamePart = "Customer";//Datetime will be added to it
                string DestinationFolder = @"C:\temp\";
              //  string TableName = "Dbo.Customer";
                string FileDelimiter = ","; //You can provide comma or pipe or whatever you like
                string FileExtension = ".csv"; //Provide the extension you like such as .txt or .csv


                //Create Connection to SQL Server in which you like to load files
                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                //Create Connection to SQL Server in which you like to load files
                SqlConnection SQLConnection = new SqlConnection(sb.ToString());
                SQLConnection.InfoMessage += OnInfoMessageGenerated;

                SQLConnection.ConnectionString = "user id=" + ConfigFile.DBUser + ";" +
                                  "password=" + ConfigFile.DBPassword + ";" +
                                  "Data Source=" + ConfigFile.DataServer + "," + ConfigFile.Port + ";" +
                                  "Network Library=DBMSSOCN;" +
                                  "Initial Catalog=" + ConfigFile.RAMXdb + "; " +
                                  "connection timeout=30";

                
                SqlCommand cmd = new SqlCommand(query, SQLConnection);
                SQLConnection.Open();
                DataTable d_table = new DataTable();
                d_table.Load(cmd.ExecuteReader());
                SQLConnection.Close();

                //Prepare the file path 
                string FileFullPath = DestinationFolder + "\\" + FileNamePart  + FileExtension;

                StreamWriter sw = null;
                sw = new StreamWriter(FileFullPath, false);

                // Write the Header Row to File
                int ColumnCount = d_table.Columns.Count;
                for (int ic = 0; ic < ColumnCount; ic++)
                {
                    sw.Write(d_table.Columns[ic]);
                    if (ic < ColumnCount - 1)
                    {
                        sw.Write(FileDelimiter);
                    }
                }
                sw.Write(sw.NewLine);

                // Write All Rows to the File
                foreach (DataRow dr in d_table.Rows)
                {
                    for (int ir = 0; ir < ColumnCount; ir++)
                    {
                        if (!Convert.IsDBNull(dr[ir]))
                        {
                            sw.Write(dr[ir].ToString());
                        }
                        if (ir < ColumnCount - 1)
                        {
                            sw.Write(FileDelimiter);
                        }
                    }
                    sw.Write(sw.NewLine);

                }

                sw.Close();

            }
            catch (Exception exception)
            {
                // Create Log File for Errors
                using (StreamWriter sw = File.CreateText(LogFolder
                    + "\\" + "ErrorLog_" + datetime + ".log"))
                {
                    sw.WriteLine(exception.ToString());

                }

            }

        }
        [When(@"Execute storeprocedure ""(.*)"" and assign variable ""(.*)""")]
        public void WhenExecuteStoreprocedureAndAssignVariable(string p0, string p1)
        {
            string StoredProcedureName = tmsCommon.GenerateData(p0);


            SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
            //Create Connection to SQL Server in which you like to load files
            SqlConnection SQLConnection = new SqlConnection(sb.ToString());
            SQLConnection.InfoMessage += OnInfoMessageGenerated;
          //  SQLConnection.;
            SQLConnection.ConnectionString = "user id=" + ConfigFile.DBUser + ";" +
                              "password=" + ConfigFile.DBPassword + ";" +
                              "Data Source=" + ConfigFile.DataServer + "," + ConfigFile.Port + ";" +
                              "Network Library=DBMSSOCN;" +
                              "Initial Catalog=" + ConfigFile.EAMdb + "; " +
                              "connection timeout=30";

            //Execute Stored Procedure and save results in data table
            string query = StoredProcedureName;
            SqlCommand cmd = new SqlCommand(query, SQLConnection);
            SQLConnection.Open();
            string FileFullPath =  @"C:\temp\Result.txt" ; ;


            sw = new StreamWriter(FileFullPath, true);
            using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
            {
                using (DataSet set = new DataSet())
                {
                    adapter.Fill(set);

                }
            }
            sw.Close();
          //  fw.setVariable(p1, cmd.ToString().Trim());

        }
        [When(@"Create BEQ Response BQN File ""(.*)"" with missing item ""(.*)"" by using MBI ""(.*)"" and Import it")]
        public void WhenCreateBEQResponseBQNFileWithMissingItemByUsingMBIAndImportIt(string p0, string p1, string p2)
        {
            string filename = tmsCommon.GenerateData(p0);
            string mbi = tmsCommon.GenerateData(p2);
            string datetime = DateTime.Now.ToString("yyyyMMddHHmmss");
            string LogFolder = @"C:\temp\";
            string StoredProcedureName = "";
            try
            {
                string FileNamePart = @"C:\temp\" + filename;
                if (p1.ToLower().Equals("parta"))
                {
                    StoredProcedureName = "dbo.BEQResponse_Generator '" + mbi + "','ProcessedFlag=Y;BeneficiaryMatchFlag=Y;MedPartAEntStartDate=;MedPartBEntStartDate=20190101;PartDEnrEffDateEmpSubsStartDate1=20190101;PartDEligibilityStartDate=20190101'";
                    //Provide SP name,you Can provide with Parameter if you like
                }
                else if(p1.ToLower().Equals("partb"))
                {
                    StoredProcedureName = "dbo.BEQResponse_Generator '" + mbi + "','ProcessedFlag=Y;BeneficiaryMatchFlag=Y;MedPartAEntStartDate=20190101;MedPartBEntStartDate=;PartDEnrEffDateEmpSubsStartDate1=20190101;PartDEligibilityStartDate=20190101'";
                    //Pro
                }
                else
                {
                    StoredProcedureName = "dbo.BEQResponse_Generator '" + mbi + "','ProcessedFlag=Y;BeneficiaryMatchFlag=Y;MedPartAEntStartDate=20190101;MedPartBEntStartDate=20190101;PartDEnrEffDateEmpSubsStartDate1=20190101;PartDEligibilityStartDate=20190101'";
                    //Provide SP name,you Can provide with Parameter if you like

                }


                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                //Create Connection to SQL Server in which you like to load files
                SqlConnection SQLConnection = new SqlConnection(sb.ToString());
                SQLConnection.InfoMessage += OnInfoMessageGenerated;

                SQLConnection.ConnectionString = "user id=" + ConfigFile.DBUser + ";" +
                                  "password=" + ConfigFile.DBPassword + ";" +
                                  "Data Source=" + ConfigFile.DataServer + "," + ConfigFile.Port + ";" +
                                  "Network Library=DBMSSOCN;" +
                                  "Initial Catalog=" + ConfigFile.EAMdb + "; " +
                                  "connection timeout=30";

                //Execute Stored Procedure and save results in data table
                string query = "EXEC " + StoredProcedureName;
                SqlCommand cmd = new SqlCommand(query, SQLConnection);
                SQLConnection.Open();
                string FileFullPath = FileNamePart;


                sw = new StreamWriter(FileFullPath, true);
                using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                {
                    using (DataSet set = new DataSet())
                    {
                        adapter.Fill(set);

                    }
                }
                sw.Close();
            }
            catch (Exception exception)
            {
                // Create Log File for Errors
                using (StreamWriter sw1 = File.CreateText(LogFolder
                    + "\\" + "BEQErrorLog_" + datetime + ".log"))
                {
                    sw1.WriteLine(exception.ToString());

                }
            }
            string p1_gen = tmsCommon.GenerateData(p0);



            string SourceFileLocation = @"C:\temp\";
            Boolean didUpload = false;
            string source = SourceFileLocation + p1_gen;
            string source1 = source + ".txt";
            string FileName = "";
            if (Directory.Exists(SourceFileLocation))

            {
                if (File.Exists(source))
                {
                    didUpload = true;
                    FileName = source;
                }

                else if (File.Exists(source1))
                {
                    didUpload = true;
                    FileName = source1;
                }
            }


            if (didUpload)
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//input[@test-id='import-input-fileUpload']")));
                By upload = By.CssSelector("[test-id='import-input-fileUpload']");
                IWebElement uploadElement = Browser.Wd.FindElement(upload);
                uploadElement.SendKeys(FileName);
                tmsWait.Hard(2);

                By uploadBtn = By.XPath("//button[contains(.,'Upload')]");
                IWebElement uploadButton = Browser.Wd.FindElement(uploadBtn);
                fw.ExecuteJavascript(uploadButton);
                tmsWait.Hard(2);
                // By import = By.CssSelector("[test-id='import-btn-import']");
                // IWebElement importBtn = Browser.Wd.FindElement(import);
                // fw.ExecuteJavascript(importBtn);
                tmsWait.Hard(8);
                By fileProcess = By.LinkText("Job Processing Status page");
                fw.ExecuteJavascript(Browser.Wd.FindElement(fileProcess));
                tmsWait.Hard(30);


            }
        }

        // Please customize as per your need - Venkatesh P
        StreamWriter sw = null;
        [When(@"Create BEQ Response BQN File ""(.*)"" using MBI ""(.*)"" and Import it")]
        public void WhenCreateBEQResponseBQNFileUsingMBIAndImportIt(string p0, string p1)
        {
            string filename = tmsCommon.GenerateData(p0);
            string mbi = tmsCommon.GenerateData(p1);
            string datetime = DateTime.Now.ToString("yyyyMMddHHmmss");
            string LogFolder = @"C:\temp\";
            try
            {
                string FileNamePart = @"C:\temp\" + filename;

                string StoredProcedureName = "dbo.BEQResponse_Generator '" + mbi + "','ProcessedFlag=Y;BeneficiaryMatchFlag=Y;MedPartAEntStartDate=20190101;MedPartBEntStartDate=20190101;PartDEnrEffDateEmpSubsStartDate1=20190101;PartDEligibilityStartDate=20190101'";
                //Provide SP name,you Can provide with Parameter if you like


                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                //Create Connection to SQL Server in which you like to load files
                SqlConnection SQLConnection = new SqlConnection(sb.ToString());
                SQLConnection.InfoMessage += OnInfoMessageGenerated;

                SQLConnection.ConnectionString = "user id=" + ConfigFile.DBUser + ";" +
                                  "password=" + ConfigFile.DBPassword + ";" +
                                  "Data Source=" + ConfigFile.DataServer + "," + ConfigFile.Port + ";" +
                                  "Network Library=DBMSSOCN;" +
                                  "Initial Catalog=" + ConfigFile.EAMdb + "; " +
                                  "connection timeout=30";

                //Execute Stored Procedure and save results in data table
                string query = "EXEC " + StoredProcedureName;
                SqlCommand cmd = new SqlCommand(query, SQLConnection);
                SQLConnection.Open();
                string FileFullPath = FileNamePart;


                sw = new StreamWriter(FileFullPath, true);
                using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                {
                    using (DataSet set = new DataSet())
                    {
                        adapter.Fill(set);
                 
                    }
                }
                sw.Close();
            }
            catch (Exception exception)
            {
                // Create Log File for Errors
                using (StreamWriter sw1 = File.CreateText(LogFolder
                    + "\\" + "BEQErrorLog_" + datetime + ".log"))
                {
                    sw1.WriteLine(exception.ToString());

                }
            }
            string p1_gen = tmsCommon.GenerateData(p0);



            string SourceFileLocation = @"C:\temp\";
            Boolean didUpload = false;
            string source = SourceFileLocation + p1_gen;
            string source1 = source + ".txt";
            string FileName = "";
            if (Directory.Exists(SourceFileLocation))

            {
                if (File.Exists(source))
                {
                    didUpload = true;
                    FileName = source;
                }

                else if (File.Exists(source1))
                {
                    didUpload = true;
                    FileName = source1;
                }
            }


            if (didUpload)
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//input[@test-id='import-input-fileUpload']")));
                By upload = By.CssSelector("[test-id='import-input-fileUpload']");
                IWebElement uploadElement = Browser.Wd.FindElement(upload);
                uploadElement.SendKeys(FileName);
                tmsWait.Hard(2);

                By uploadBtn = By.XPath("//button[contains(.,'Upload')]");
                IWebElement uploadButton = Browser.Wd.FindElement(uploadBtn);
                fw.ExecuteJavascript(uploadButton);
                tmsWait.Hard(2);
                // By import = By.CssSelector("[test-id='import-btn-import']");
                // IWebElement importBtn = Browser.Wd.FindElement(import);
                // fw.ExecuteJavascript(importBtn);
                tmsWait.Hard(8);
                By fileProcess = By.LinkText("Job Processing Status page");
                fw.ExecuteJavascript(Browser.Wd.FindElement(fileProcess));
                tmsWait.Hard(30);


            }

        }

            private void OnInfoMessageGenerated(object sender, SqlInfoMessageEventArgs args)
            {
                Console.WriteLine("{0}", args.Message);
                sw.WriteLine(args.Message.ToString());
            }

        string StoredProcedureName;
        [When(@"i Create BEQ Response BQN File ""(.*)"" for ""(.*)"" status using MBI ""(.*)"" update value at postion ""(.*)"" as ""(.*)"" and Import ""(.*)""")]
        public void WhenICreateBEQResponseBQNFileForStatusUsingMBIUpdateValueAtPostionAsAndImport(string p0, string p1, string p2, string position, string value, string jobType)
        {
           
            string filename = tmsCommon.GenerateData(p0);
                string beqStatus= tmsCommon.GenerateData(p1);
                string mbi = tmsCommon.GenerateData(p2);
                string datetime = DateTime.Now.ToString("yyyyMMddHHmmss");
                string countyCode = tmsCommon.GenerateData(value);
                string filePosition = tmsCommon.GenerateData(position);
                string[] arrFilePosition = filePosition.Split('-');
                int textStartIndex = Convert.ToInt32(arrFilePosition[0]);
                int textLength = (Convert.ToInt32(arrFilePosition[1]) - textStartIndex) + 1;
                StringBuilder st;

                string LogFolder = @"C:\temp\";
                GlobalRef.JobName = jobType;
               
                try
                {
                    string FileNamePart = @"C:\temp\" + filename;
               
                
                if (beqStatus == "Passed BEQ")
                  
                {
                    StoredProcedureName = "dbo.BEQResponse_Generator '" + mbi + "','ProcessedFlag=Y;BeneficiaryMatchFlag=Y;MedPartAEntStartDate=20190101;MedPartBEntStartDate=20190101;PartDEnrEffDateEmpSubsStartDate1=20190101;PartDEligibilityStartDate=20190101'";
                        //Provide SP name,you Can provide with Parameter if you like
                    }
                    else if (beqStatus == "Failed BEQ") {
                         StoredProcedureName = "dbo.BEQResponse_Generator '" + mbi + "','ProcessedFlag=Y;BeneficiaryMatchFlag=Y;MedPartAEntStartDate=04011997;MedPartBEntStartDate=04011997;PartDEligibilityStartDate=01012006'";
                        //Provide SP name,you Can provide with Parameter if you like
                    }

                    SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                    //Create Connection to SQL Server in which you like to load files
                    SqlConnection SQLConnection = new SqlConnection(sb.ToString());
                    SQLConnection.InfoMessage += OnInfoMessageGenerated;

                    SQLConnection.ConnectionString = "user id=" + ConfigFile.DBUser + ";" +
                                      "password=" + ConfigFile.DBPassword + ";" +
                                      "Data Source=" + ConfigFile.DataServer + "," + ConfigFile.Port + ";" +
                                      "Network Library=DBMSSOCN;" +
                                      "Initial Catalog=" + ConfigFile.EAMdb + "; " +
                                      "connection timeout=30";

                    //Execute Stored Procedure and save results in data table
                    string query = "EXEC " + StoredProcedureName;
                    SqlCommand cmd = new SqlCommand(query, SQLConnection);
                    SQLConnection.Open();
                    string FileFullPath = FileNamePart;



                    sw = new StreamWriter(FileFullPath, true);

                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        using (DataSet set = new DataSet())
                        {
                            adapter.Fill(set);
                        }
                    }

                    sw.Close();
                    // var reader = new StreamReader(File.OpenRead(@"" + FileFullPath + ""));
                    string[] lines = System.IO.File.ReadAllLines(FileFullPath);
                    st = new StringBuilder(lines[1]);
                    st.Remove(textStartIndex - 1, textLength);
                    st.Insert(textStartIndex - 1, value);
                    Console.Write(st.ToString());
                    string[] st1 = new string[lines.Length];
                    st1[0] = lines[0].ToString();
                    st1[1] = st.ToString();
                    st1[2] = lines[2].ToString();
                    System.IO.File.WriteAllLines(FileFullPath, st1);
                    sw.Close();
                  
                }

                catch (Exception exception)
                {
                    // Create Log File for Errors
                    using (StreamWriter sw1 = File.CreateText(LogFolder
                        + "\\" + "BEQErrorLog_" + datetime + ".log"))
                    {
                        sw1.WriteLine(exception.ToString());

                    }
                }
                string p1_gen = tmsCommon.GenerateData(p0);

                string SourceFileLocation = @"C:\temp\";
                Boolean didUpload = false;
                string source = SourceFileLocation + p1_gen;
                string source1 = source + ".txt";
                string FileName = "";
                if (Directory.Exists(SourceFileLocation))

                {
                    if (File.Exists(source))
                    {
                        didUpload = true;
                        FileName = source;
                    }

                    else if (File.Exists(source1))
                    {
                        didUpload = true;
                        FileName = source1;
                    }
                }


                if (didUpload)
                {
                    tmsWait.Hard(2);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@title='Import']")));
                    tmsWait.Hard(2);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[contains(.,'BQN File')]")));
                    tmsWait.Hard(2);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//input[@test-id='import-input-fileUpload']")));
                    By upload = By.CssSelector("[test-id='import-input-fileUpload']");
                    IWebElement uploadElement = Browser.Wd.FindElement(upload);
                    uploadElement.SendKeys(FileName);
                    tmsWait.Hard(2);

                    By uploadBtn = By.XPath("//button[contains(.,'Upload')]");
                    IWebElement uploadButton = Browser.Wd.FindElement(uploadBtn);
                    fw.ExecuteJavascript(uploadButton);
                    tmsWait.Hard(2);
                    // By import = By.CssSelector("[test-id='import-btn-import']");
                    // IWebElement importBtn = Browser.Wd.FindElement(import);
                    // fw.ExecuteJavascript(importBtn);
                    tmsWait.Hard(8);
                    By fileProcess = By.LinkText("Job Processing Status page");
                    fw.ExecuteJavascript(Browser.Wd.FindElement(fileProcess));
                    tmsWait.Hard(30);

                }
            }





        [When(@"i Create BEQ Response BQN File ""(.*)"" using MBI ""(.*)"" update value at postion ""(.*)"" as ""(.*)"" and Import ""(.*)""")]
        public void WhenICreateBEQResponseBQNFileUsingMBIUpdateValueAtPostionAsAndImport(string p0, string p1, string position, string value, string jobType)
        {
            string filename = tmsCommon.GenerateData(p0);
            string mbi = tmsCommon.GenerateData(p1);
            string datetime = DateTime.Now.ToString("yyyyMMddHHmmss");
            string countyCode = tmsCommon.GenerateData(value);
            string filePosition = tmsCommon.GenerateData(position);
            string[] arrFilePosition = filePosition.Split('-');
            int textStartIndex = Convert.ToInt32(arrFilePosition[0]);
            int textLength = (Convert.ToInt32(arrFilePosition[1]) - textStartIndex) + 1 ;
            StringBuilder st;

            string LogFolder = @"C:\temp\";
            GlobalRef.JobName = jobType;
            try
            {
                string FileNamePart = @"C:\temp\" + filename;

                string StoredProcedureName = "dbo.BEQResponse_Generator '" + mbi + "','ProcessedFlag=Y;BeneficiaryMatchFlag=Y;MedPartAEntStartDate=20190101;MedPartBEntStartDate=20190101;PartDEnrEffDateEmpSubsStartDate1=20190101;PartDEligibilityStartDate=20190101'";
                //Provide SP name,you Can provide with Parameter if you like


                SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
                //Create Connection to SQL Server in which you like to load files
                SqlConnection SQLConnection = new SqlConnection(sb.ToString());
                SQLConnection.InfoMessage += OnInfoMessageGenerated;

                SQLConnection.ConnectionString = "user id=" + ConfigFile.DBUser + ";" +
                                  "password=" + ConfigFile.DBPassword + ";" +
                                  "Data Source=" + ConfigFile.DataServer + "," + ConfigFile.Port + ";" +
                                  "Network Library=DBMSSOCN;" +
                                  "Initial Catalog=" + ConfigFile.EAMdb + "; " +
                                  "connection timeout=30";

                //Execute Stored Procedure and save results in data table
                string query = "EXEC " + StoredProcedureName;
                SqlCommand cmd = new SqlCommand(query, SQLConnection);
                SQLConnection.Open();
                string FileFullPath = FileNamePart;



                sw = new StreamWriter(FileFullPath, true);

                using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                {
                    using (DataSet set = new DataSet())
                    {
                        adapter.Fill(set);
                    }
                }

                sw.Close();
               // var reader = new StreamReader(File.OpenRead(@"" + FileFullPath + ""));
                string[] lines = System.IO.File.ReadAllLines(FileFullPath);
                st = new StringBuilder(lines[1]);
                st.Remove(textStartIndex-1, textLength);
                st.Insert(textStartIndex-1, value);
                Console.Write(st.ToString());
                string[] st1 = new string[lines.Length];
                st1[0] = lines[0].ToString();
                st1[1] = st.ToString();
                st1[2] = lines[2].ToString();
                System.IO.File.WriteAllLines(FileFullPath,st1 );
                sw.Close();
                //string[] st1 = new string[lines.Length];
                //var lineBEQRes = 0;
                //for (int i = 0; i < lines.Length; i++)
                //{

                //    if (lineBEQRes == 1)
                //    {
                //       
                //beqResponseOldMBI = lines[1].Substring(8, 11);
                //        st = new StringBuilder(lines[lineBEQRes]);
                //        // st.Remove(8, 11);
                //        // st.Insert(8, beqResponseMBI);
                //        st.Replace(beqResponseOldMBI, newMBI);


            }

            catch (Exception exception)
            {
                // Create Log File for Errors
                using (StreamWriter sw1 = File.CreateText(LogFolder
                    + "\\" + "BEQErrorLog_" + datetime + ".log"))
                {
                    sw1.WriteLine(exception.ToString());

                }
            }
            string p1_gen = tmsCommon.GenerateData(p0);



            string SourceFileLocation = @"C:\temp\";
            Boolean didUpload = false;
            string source = SourceFileLocation + p1_gen;
            string source1 = source + ".txt";
            string FileName = "";
            if (Directory.Exists(SourceFileLocation))

            {
                if (File.Exists(source))
                {
                    didUpload = true;
                    FileName = source;
                }

                else if (File.Exists(source1))
                {
                    didUpload = true;
                    FileName = source1;
                }
            }


            if (didUpload)
            {
                tmsWait.Hard(2);
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@title='Import']")));
                tmsWait.Hard(2);
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[contains(.,'BQN File')]")));
                tmsWait.Hard(2);
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//input[@test-id='import-input-fileUpload']")));
                By upload = By.CssSelector("[test-id='import-input-fileUpload']");
                IWebElement uploadElement = Browser.Wd.FindElement(upload);
                uploadElement.SendKeys(FileName);
                tmsWait.Hard(2);

                By uploadBtn = By.XPath("//button[contains(.,'Upload')]");
                IWebElement uploadButton = Browser.Wd.FindElement(uploadBtn);
                fw.ExecuteJavascript(uploadButton);
                tmsWait.Hard(2);
                // By import = By.CssSelector("[test-id='import-btn-import']");
                // IWebElement importBtn = Browser.Wd.FindElement(import);
                // fw.ExecuteJavascript(importBtn);
                tmsWait.Hard(8);
                By fileProcess = By.LinkText("Job Processing Status page");
                fw.ExecuteJavascript(Browser.Wd.FindElement(fileProcess));
                tmsWait.Hard(30);

            }
        }


        [When(@"Click on On Hold Reason Info Icon and Verify Tool tip message as ""(.*)""")]
        public void WhenClickOnOnHoldReasonInfoIconAndVerifyToolTipMessageAs(string p0)
        {
            IWebElement tool = Browser.Wd.FindElement(By.CssSelector("[test-id='onHoldReasons-tooltip-onHoldReasonTooltip']"));
            fw.ExecuteJavascript(tool);
            tmsWait.Hard(1);
            IWebElement column = Browser.Wd.FindElement(By.XPath("//div[@class='k-tooltip-content'][contains(.,'"+p0+"')]"));
            UIMODUtilFunctions.elementPresenceUsingWebElement(column);
        }

        [Then(@"Verify On Hold Settings History dialog displayed ""(.*)"" column")]
        public void ThenVerifyOnHoldSettingsHistoryDialogDisplayedColumn(string p0)
        {
            IWebElement column = Browser.Wd.FindElement(By.XPath("//div[@test-id='searchProvider-grid-providerLookup']//span[contains(.,'Changed From')]"));
            UIMODUtilFunctions.elementPresenceUsingWebElement(column);
        }

        [Then(@"I Clicked on Cross Button")]
        public void ThenIClickedOnCrossButton()
        {
            IWebElement link = Browser.Wd.FindElement(By.CssSelector("[test-id='auditInfo-btn-cancel']"));
            fw.ExecuteJavascript(link);
            tmsWait.Hard(10);
        }
        [When(@"EAM Configuration page Prevent Further Processing for On-Hold Transactions checkbox is ""(.*)""")]
        public void WhenEAMConfigurationPagePreventFurtherProcessingForOn_HoldTransactionsCheckboxIs(string Operation)
        {
            By checkbox = By.CssSelector("[test-id='onHoldReasons-chk-preventOnHoldTrans']");
            ReUsableFunctions.CheckBoxOperations(checkbox, Operation);



        }

        [When(@"I Clicked on Reason ID header and Verify it is sorted in Ascending Order")]
        public void WhenIClickedOnReasonIDHeaderAndVerifyItIsSortedInAscendingOrder()
        {
            IWebElement reasonID = Browser.Wd.FindElement(By.XPath("(//div[@test-id='OnHoldReasons-grid-onHoldReasons']//a)[1]"));
            fw.ExecuteJavascript(reasonID);
            tmsWait.Hard(2);
            IWebElement sort = Browser.Wd.FindElement(By.XPath("(//div[@test-id='OnHoldReasons-grid-onHoldReasons']//a)[1]/parent::th[contains(@aria-sort,'ascending')]"));
            UIMODUtilFunctions.elementPresenceUsingWebElement(sort);
        }

        [When(@"I Clicked on Reason Description header and Verify it is sorted in Ascending Order")]
        public void WhenIClickedOnReasonDescriptionHeaderAndVerifyItIsSortedInAscendingOrder()
        {
            IWebElement reasonID = Browser.Wd.FindElement(By.XPath("(//div[@test-id='OnHoldReasons-grid-onHoldReasons']//a)[2]"));
            fw.ExecuteJavascript(reasonID);
            tmsWait.Hard(2);
            IWebElement sort = Browser.Wd.FindElement(By.XPath("(//div[@test-id='OnHoldReasons-grid-onHoldReasons']//a)[2]/parent::th[contains(@aria-sort,'ascending')]"));
            UIMODUtilFunctions.elementPresenceUsingWebElement(sort);
        }

        [Then(@"Verify Add On-Hold Reason page displayed Pagination")]
        public void ThenVerifyAddOn_HoldReasonPageDisplayedPagination()
        {
            IWebElement sort = Browser.Wd.FindElement(By.XPath("//div[@test-id='OnHoldReasons-grid-onHoldReasons']//div[@data-role='pager']"));
            UIMODUtilFunctions.elementPresenceUsingWebElement(sort);
        }

        [Then(@"Verify Add On-Hold Reason page any System defined Reason Description should be Disabled")]
        public void ThenVerifyAddOn_HoldReasonPageAnySystemDefinedReasonDescriptionShouldBeDisabled()
        {
            IWebElement checkbox = Browser.Wd.FindElement(By.XPath("//div[@test-id='OnHoldReasons-grid-onHoldReasons']//td[contains(.,'Pending Additional Information')]/following-sibling::td/input"));
            bool visibleStatus = checkbox.Enabled;

            Assert.IsFalse(visibleStatus, " Expected Element is Visible");
            
        }


        [When(@"On Hold Reason Save button is Clicked without entering any Value and Verify message ""(.*)""")]
        public void WhenOnHoldReasonSaveButtonIsClickedWithoutEnteringAnyValueAndVerifyMessage(string p0)
        {
            tmsWait.Hard(4);
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='OnHoldReasons-btn-save']"));
            fw.ExecuteJavascript(ele);
            By msg = By.XPath("//span[contains(.,'"+ p0 + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(msg);

        }

        [When(@"On Hold Reason page  On Hold Reason is entered as ""(.*)"" And Reset button is Clicked Verify message ""(.*)""")]
        public void WhenOnHoldReasonPageOnHoldReasonIsEnteredAsAndResetButtonIsClickedVerifyMessage(string expEnteredMsg, string Empty)
        {
            IWebElement actualele=Browser.Wd.FindElement(By.CssSelector("[test-id='onHoldReasons-txt-addReason']"));
            actualele.SendKeys(expEnteredMsg);
            string actualEnteredMsg = actualele.GetAttribute("value");

            Assert.AreEqual(expEnteredMsg, actualEnteredMsg, " Both are not matching");

            IWebElement reset = Browser.Wd.FindElement(By.CssSelector("[test-id='OnHoldReasons-btn-cancel']"));
            fw.ExecuteJavascript(reset);

            tmsWait.Hard(1);
            IWebElement actualele1 = Browser.Wd.FindElement(By.CssSelector("[test-id='onHoldReasons-txt-addReason']"));
            string actualEnteredMsg1 = actualele.Text;

            Assert.AreEqual(Empty, actualEnteredMsg1, " Both are not matching");



        }

        [When(@"EAM Configuration Prevent Further Processing for On-Hold Transactions checkbox is ""(.*)"" and Verify message ""(.*)""")]
        public void WhenEAMConfigurationPreventFurtherProcessingForOn_HoldTransactionsCheckboxIsAndVerifyMessage(string Operation, string expMsg)
        {
            tmsWait.Hard(4);
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='onHoldReasons-chk-preventOnHoldTrans']"));
            fw.ExecuteJavascript(ele);            

            string actualMsg = Browser.Wd.FindElement(By.XPath("//div[@class='toast-message']")).GetAttribute("aria-label");

            fw.ConsoleReport(actualMsg);
            Assert.AreEqual(expMsg, actualMsg, " Both message are not matching");
        }

        [Then(@"Verify EAM Configuration page displayed success toaster message ""(.*)""")]
        public void ThenVerifyEAMConfigurationPageDisplayedSuccessToasterMessage(string p0)
        {
            ReUsableFunctions.toasterMessageDisplay(p0);
        }

        [Then(@"Save Transaction Button is Clicked")]
        public void ThenSaveTransactionButtonIsClicked()
        {

            IWebElement link = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-btn-saveTransactionFields']"));
            fw.ExecuteJavascript(link);
            tmsWait.Hard(3);
        }

        [When(@"EAM Configuration Member Fields Plan One is set to ""(.*)""")]
        public void WhenEAMConfigurationMemberFieldsPlanOneIsSetTo(string value)
        {
            string p0 = tmsCommon.GenerateData(value);
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-memberFieldPlanOne']"));
            ReUsableFunctions.enterValueOnWebElement(ele, p0);
        }

        [When(@"EAM Configuration Member Fields Plan Two is set to ""(.*)""")]
        public void WhenEAMConfigurationMemberFieldsPlanTwoIsSetTo(string value)
        {
            string p0 = tmsCommon.GenerateData(value);
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-memberFieldPlanTwo']"));
            ReUsableFunctions.enterValueOnWebElement(ele, p0);
        }

        [When(@"EAM Configuration Member Fields Plan Three is set to ""(.*)""")]
        public void WhenEAMConfigurationMemberFieldsPlanThreeIsSetTo(string value)
        {
            string p0 = tmsCommon.GenerateData(value);
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-memberFieldPlanThree']"));
            ReUsableFunctions.enterValueOnWebElement(ele, p0);
        }

        [When(@"EAM Configuration Member Fields Plan Four is set to ""(.*)""")]
        public void WhenEAMConfigurationMemberFieldsPlanFourIsSetTo(string value)
        {
            string p0 = tmsCommon.GenerateData(value);
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-memberFieldPlanFour']"));
            ReUsableFunctions.enterValueOnWebElement(ele, p0);
        }

        [When(@"EAM Configuration Member Fields Plan Five is set to ""(.*)""")]
        public void WhenEAMConfigurationMemberFieldsPlanFiveIsSetTo(string value)
        {
            string p0 = tmsCommon.GenerateData(value);
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-memberFieldPlanFive']"));
            ReUsableFunctions.enterValueOnWebElement(ele, p0);
        }

        [When(@"EAM Configuration Member Fields Plan Six is set to ""(.*)""")]
        public void WhenEAMConfigurationMemberFieldsPlanSixIsSetTo(string value)
        {
            string p0 = tmsCommon.GenerateData(value);
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-memberFieldPlanSix']"));
            ReUsableFunctions.enterValueOnWebElement(ele, p0);
        }

        [When(@"EAM Configuration Member Fields Plan Seven is set to ""(.*)""")]
        public void WhenEAMConfigurationMemberFieldsPlanSevenIsSetTo(string value)
        {
            string p0 = tmsCommon.GenerateData(value);
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-memberFieldPlanSeven']"));
            ReUsableFunctions.enterValueOnWebElement(ele, p0);
        }

        [When(@"EAM Configuration Member Fields Plan Eight is set to ""(.*)""")]
        public void WhenEAMConfigurationMemberFieldsPlanEightIsSetTo(string value)
        {
            string p0 = tmsCommon.GenerateData(value);
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-memberFieldPlanEight']"));
            ReUsableFunctions.enterValueOnWebElement(ele, p0);
        }

        [When(@"EAM Configuration Member Fields Plan Nine is set to ""(.*)""")]
        public void WhenEAMConfigurationMemberFieldsPlanNineIsSetTo(string value)
        {
            string p0 = tmsCommon.GenerateData(value);
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-memberFieldPlanNine']"));
            ReUsableFunctions.enterValueOnWebElement(ele, p0);
        }

        [When(@"EAM Configuration Member Fields Plan Ten is set to ""(.*)""")]
        public void WhenEAMConfigurationMemberFieldsPlanTenIsSetTo(string value)
        {
            string p0 = tmsCommon.GenerateData(value);
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-memberFieldPlanTen']"));
            ReUsableFunctions.enterValueOnWebElement(ele, p0);
        }

        [Then(@"Save Member Button is Clicked")]
        public void ThenSaveMemberButtonIsClicked()
        {
            IWebElement savebtn = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-btn-saveMemberFields']"));
            fw.ExecuteJavascript(savebtn);
           
        }


        [When(@"EAM Configuration Transaction Fields Plan One is set to ""(.*)""")]
        public void WhenEAMConfigurationTransactionFieldsPlanOneIsSetTo(string value)
        {
            string p0 = tmsCommon.GenerateData(value);
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-transactionFieldPlanOne']"));
            ReUsableFunctions.enterValueOnWebElement(ele, p0);

        }
        [When(@"View Edit Member page Note ""(.*)"" from Transactions section")]
        public void WhenViewEditMemberPageNoteFromTransactionsSection(string variable)
        {
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='transactions-grid-memberTransactionsGrid']"));
           
            ReUsableFunctions.ScrollingInToSpecicElementView(ele);

            string value = Browser.Wd.FindElement(By.XPath("//td/span[@ng-bind='dataItem.transStatus'][contains(.,'New')]/parent::td/preceding-sibling::td/span[@ng-bind='dataItem.transId']")).Text;
            fw.setVariable(variable, value);
        }



        [When(@"EAM Configuration Transaction Fields Plan Two is set to ""(.*)""")]
        public void WhenEAMConfigurationTransactionFieldsPlanTwoIsSetTo(string value)
        {
            string p0 = tmsCommon.GenerateData(value);
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-transactionFieldPlanTwo']"));
            ReUsableFunctions.enterValueOnWebElement(ele, p0);

        }

        [When(@"EAM Configuration Transaction Fields Plan Three is set to ""(.*)""")]
        public void WhenEAMConfigurationTransactionFieldsPlanThreeIsSetTo(string value)
        {
            string p0 = tmsCommon.GenerateData(value);
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-transactionFieldPlanThree']"));
            ReUsableFunctions.enterValueOnWebElement(ele, p0);

        }

        [When(@"EAM Configuration Transaction Fields Plan Four is set to ""(.*)""")]
        public void WhenEAMConfigurationTransactionFieldsPlanFourIsSetTo(string value)
        {
            string p0 = tmsCommon.GenerateData(value);
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-transactionFieldPlanFour']"));
            ReUsableFunctions.enterValueOnWebElement(ele, p0);

        }

        [When(@"EAM Configuration Transaction Fields Plan Five is set to ""(.*)""")]
        public void WhenEAMConfigurationTransactionFieldsPlanFiveIsSetTo(string value)
        {
            string p0 = tmsCommon.GenerateData(value);
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-transactionFieldPlanFive']"));
            ReUsableFunctions.enterValueOnWebElement(ele, p0);

        }

        [When(@"EAM Configuration Transaction Fields Plan Six is set to ""(.*)""")]
        public void WhenEAMConfigurationTransactionFieldsPlanSixIsSetTo(string value)
        {
            string p0 = tmsCommon.GenerateData(value);
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-transactionFieldPlanSix']"));
            ReUsableFunctions.enterValueOnWebElement(ele, p0);
        }

        [When(@"EAM Configuration Transaction Fields Plan Seven is set to ""(.*)""")]
        public void WhenEAMConfigurationTransactionFieldsPlanSevenIsSetTo(string value)
        {
            string p0 = tmsCommon.GenerateData(value);
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-transactionFieldPlanSeven']"));
            ReUsableFunctions.enterValueOnWebElement(ele, p0);
        }

        [When(@"EAM Configuration Transaction Fields Plan Eight is set to ""(.*)""")]
        public void WhenEAMConfigurationTransactionFieldsPlanEightIsSetTo(string value)
        {
            string p0 = tmsCommon.GenerateData(value);
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-transactionFieldPlanEight']"));
            ReUsableFunctions.enterValueOnWebElement(ele, p0);

        }

        [When(@"EAM Configuration Transaction Fields Plan Nine is set to ""(.*)""")]
        public void WhenEAMConfigurationTransactionFieldsPlanNineIsSetTo(string value)
        {
            string p0 = tmsCommon.GenerateData(value);
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-transactionFieldPlanNine']"));
            ReUsableFunctions.enterValueOnWebElement(ele, p0);
        }

        [When(@"EAM Configuration Transaction Fields Plan Ten is set to ""(.*)""")]
        public void WhenEAMConfigurationTransactionFieldsPlanTenIsSetTo(string value)
        {
            string p0 = tmsCommon.GenerateData(value);
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefiendFields-txt-transactionFieldPlanTen']"));
            ReUsableFunctions.enterValueOnWebElement(ele, p0);
        }

        [When(@"View Edit Transaction page Search results First Row is Clicked")]
        public void WhenViewEditTransactionPageSearchResultsFirstRowIsClicked()
        {
            tmsWait.Hard(3);
            IWebElement link = Browser.Wd.FindElement(By.XPath("(//a[@role='button'])[1]"));
            fw.ExecuteJavascript(link);
            tmsWait.Hard(5);
        }

        [When(@"View Edit Transaction page Search results First ""(.*)"" Row is Clicked")]
        public void WhenViewEditTransactionPageSearchResultsFirstRowIsClicked(string variable)
        {
            string value = Browser.Wd.FindElement(By.XPath("(//span[@ng-bind='dataItem.mbi'])[1]")).Text;
            fw.setVariable(variable, value);
            tmsWait.Hard(3);
            IWebElement link = Browser.Wd.FindElement(By.XPath("(//a[@role='button'])[1]"));
            fw.ExecuteJavascript(link);
            tmsWait.Hard(5);
        }
        [When(@"View Edit Members page Search results First ""(.*)"" Row is Clicked")]
        public void WhenViewEditMembersPageSearchResultsFirstRowIsClicked(string variable)
        {
            string value = Browser.Wd.FindElement(By.XPath("(//span[@ng-bind='dataItem.mbi'])[1]")).Text;
            fw.setVariable(variable, value);
            tmsWait.Hard(3);
            IWebElement link = Browser.Wd.FindElement(By.XPath("(//a[@role='button'])[1]"));
            fw.ExecuteJavascript(link);
            tmsWait.Hard(5);
        }

        [When(@"Letters page First Letter Name is made it as InActive and ""(.*)"" is noted")]
        public void WhenLettersPageFirstLetterNameIsMadeItAsInActiveAndIsNoted(string p0)
        {
            string lettername = Browser.Wd.FindElement(By.XPath("(//div[@test-id='onDemandLetter-grid']//td[3]/input[@checked='checked']/parent::td/following-sibling::td[2]/input[@checked='checked']/parent::td/following-sibling::td/a/parent::td/preceding-sibling::td/span[@ng-bind='dataItem.letterName'])[1]")).Text;

            fw.setVariable(p0, lettername);
            By edit = By.XPath("(//div[@test-id='onDemandLetter-grid']//td[3]/input[@checked='checked']/parent::td/following-sibling::td[2]/input[@checked='checked']/parent::td/following-sibling::td/a)[1]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(edit);

           

            By active = By.XPath("//input[@name='letterIsActive']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(active);

            By saveBtn = By.XPath("(//a[@role='button']/span[@class='k-i-check fa fa-floppy-o'])[1]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(saveBtn);
            
        }

        [When(@"Letters page Letters drop down ""(.*)"" Letters is selected")]
        public void WhenLettersPageLettersDropDownLettersIsSelected(string value)
        {
            IWebElement ele=Browser.Wd.FindElement(By.CssSelector("[aria-owns='drpLetter_listbox']"));
            UIMODUtilFunctions.selectDropDownValueFromGendoUI(ele, value);
        }

        [Then(@"Verify Letters page Letters ""(.*)"" is not displayed")]
        public void ThenVerifyLettersPageLettersIsNotDisplayed(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[aria-owns='drpLetter_listbox']"));

            try
            {
                string idAttribute = ele.GetAttribute("aria-owns");
                IWebElement drpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='" + idAttribute + "']/li[contains(.,'" + value + "')]"));

                Assert.Fail(" Inactive Letters is displayed");
            }
            catch
            {
                Assert.IsTrue(true);
            }
        }



    }
}
