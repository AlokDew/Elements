﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using System.Globalization;
using FileHelpers;

namespace TMSoR1.FrameworkCode.HCC_RAM
{
    [Binding]
    class fsFlagForAuditReview
    {

        [When(@"Auditor Review page Search By ""(.*)"" option button is Clicked")]
        public void WhenAuditorReviewPageSearchByOptionButtonIsClicked(string p0)
        {
            By ele = By.CssSelector("[test-id='auditorReview-radio-" + p0 + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(ele));
            tmsWait.Hard(5);
        }

        [When(@"Auditor Review page Search By File Name Drop down list is set to ""(.*)""")]
        public void WhenAuditorReviewPageSearchByFileNameDropDownListIsSetTo(string p0)
        {
            string filename = tmsCommon.GenerateData(p0);
            By drp = By.XPath("//kendo-dropdownlist[@test-id='auditorReview-file-txt-FileNames']//span[@class='k-select']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(drp));
            tmsWait.Hard(2);
            By value = By.XPath("//li[contains(.,'" + filename + "')]");
            fw.ExecuteJavascript(Browser.Wd.FindElement(value));
        }

        [When(@"Auditor Review page Search By File Date Loaded From is set to ""(.*)""")]
        public void WhenAuditorReviewPageSearchByFileDateLoadedFromIsSetTo(string p0)
        {
            string date = tmsCommon.GenerateData(p0);
            By dateField = By.XPath("//kendo-datepicker[@id='txtFromDate']//span[@role='button']");

            if (date.Equals("Today"))
            {
                AngularFunction.enterTodayAsDate(dateField);
            }
            else
            {
                AngularFunction.enterDate(dateField, date);
            }
        }

        [When(@"Auditor Review page Search By Parameter Encounter From Date is set to ""(.*)""")]
        public void WhenAuditorReviewPageSearchByParameterEncounterFromDateIsSetTo(string p0)
        {
            string date = tmsCommon.GenerateData(p0);
            By dateField = By.XPath("//kendo-datepicker[@id='encounterFromDdate']//span[@role='button']");

            if (date.Equals("Today"))
            {
                AngularFunction.enterTodayAsDate(dateField);
            }
            else
            {
                AngularFunction.enterDate(dateField, date);
            }
        }

        [When(@"Auditor Review page Search By Parameter Encounter To Date is set to ""(.*)""")]
        public void WhenAuditorReviewPageSearchByParameterEncounterToDateIsSetTo(string p0)
        {
            string date = tmsCommon.GenerateData(p0);
            By dateField = By.XPath("//kendo-datepicker[@id='encounterToDdate']//span[@role='button']");

            if (date.Equals("Today"))
            {
                AngularFunction.enterTodayAsDate(dateField);
            }
            else
            {
                AngularFunction.enterDate(dateField, date);
            }
        }

        [When(@"Auditor Review page Search button is Clicked")]
        public void WhenAuditorReviewPageSearchButtonIsClicked()
        {
            By ele = By.CssSelector("[test-id='auditorReview-btn-filesearch']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(ele));
            tmsWait.Hard(3);
        }


        [When(@"Auditor Review page Search button for Parameter section is clicked")]
        public void WhenAuditorReviewPageSearchButtonForParameterSectionIsClicked()
        {
            //By ele = By.XPath("//button[@id='auditorReview-btnsearch-parameter']");
            tmsWait.Hard(3);
            By id = By.Id("auditorReview-btnsearch-parameter");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(id);
            //fw.ExecuteJavascript(Browser.Wd.FindElement(ele));
            //AngularFunction.clickOnElement(ele);
            tmsWait.Hard(3);
        }

        [When(@"Auditor Review page Reset button for Parameter section is clicked")]
        public void WhenAuditorReviewPageResetButtonForParameterSectionIsClicked()
        {
            By ele = By.Id("auditorReview-btnReset");
            fw.ExecuteJavascript(Browser.Wd.FindElement(ele));
            tmsWait.Hard(3);
        }

        [When(@"Auditor Review page ChartID is set to ""(.*)""")]
        public void WhenAuditorReviewPageChartIDIsSetTo(string p0)
        {
            string chart_id_value = tmsCommon.GenerateData(p0.ToString());
            IWebElement chart_id_field = Browser.Wd.FindElement(By.XPath("//input[@test-id='auditorReview-txt-chartId']"));
            chart_id_field.SendKeys(chart_id_value);
            //chart_id_field.SendKeys(Keys.Tab);
            tmsWait.Hard(3);
        }

        [When(@"Auditor Review page Search By Parameter Status is set to ""(.*)""")]
        public void WhenAuditorReviewPageSearchByParameterStatusIsSetTo(string p0)
        {
            By Drp = By.XPath("//label[contains(.,'Status')]/parent::div//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + p0 + "']");


            UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
        }

        [When(@"Auditor Review page Member ID ""(.*)"" Chart ID as ""(.*)"" Provider ID as ""(.*)"" is Clicked")]
        public void WhenAuditorReviewPageMemberIDChartIDAsProviderIDAsIsClicked(string p0, string p1, string p2)
        {
            string memID = tmsCommon.GenerateData(p0);
            string chartID = tmsCommon.GenerateData(p1);
            string providerID = tmsCommon.GenerateData(p2);
            By res = By.XPath("//kendo-grid[@test-id='audit-grid']//td[contains(.,'" + memID + "')]/following-sibling::td[contains(.,'" + chartID + "')]/following-sibling::td[contains(.,'" + providerID + "')]/following-sibling::td/button/span[@class='fas fa-pencil-alt']");
           // UIMODUtilFunctions.clickOnWebElementUsingLocators(res);
            fw.ExecuteJavascript(Browser.Wd.FindElement(res));
            tmsWait.Hard(3);
        }

        [When(@"Auditor Review page results grid First Row Expand Contract Button is Clicked")]
        public void WhenAuditorReviewPageResultsGridFirstRowExpandContractButtonIsClicked()
        {
            By res = By.XPath("(//kendo-grid[@test-id='audit-grid']//td/a)[1]");
            fw.ExecuteJavascript(Browser.Wd.FindElement(res));
            tmsWait.Hard(3);
        }

        [When(@"Auditor Review page results grid First Row Information Button is Clicked")]
        public void WhenAuditorReviewPageResultsGridFirstRowInformationButtonIsClicked()
        {
            By res = By.XPath("(//kendo-grid[@test-id='audit-grid']//td/div/i/following-sibling::a)[1]");
            fw.ExecuteJavascript(Browser.Wd.FindElement(res));
            tmsWait.Hard(3);
        }

        [When(@"Auditor Review page results grid First Row Information Close Button is Clicked")]
        public void WhenAuditorReviewPageResultsGridFirstRowInformationCloseButtonIsClicked()
        {
            By res = By.XPath("(//kendo-popup//div//a[@title='Close'])[1]");
            fw.ExecuteJavascript(Browser.Wd.FindElement(res));
            tmsWait.Hard(3);
        }

        [Then(@"Verify Auditor Review page displays Results Grid with expected headers")]
        public void ThenVerifyAuditorReviewPageDisplaysResultsGridWithExpectedHeaders()
        {
            By res = By.XPath("//kendo-grid[@test-id='audit-grid']//tr/th[contains(.,'Member ID')]/following-sibling::th[contains(.,'Chart ID')]/following-sibling::th[contains(.,'Diagnosis Code')]/following-sibling::th[contains(.,'Encounter From Date')]/following-sibling::th[contains(.,'Encounter To Date')]/following-sibling::th[contains(.,'Type Of Service')]/following-sibling::th[contains(.,'Provider ID')]/following-sibling::th[contains(.,'Provider Name')]/following-sibling::th[contains(.,'Claim Number')]/following-sibling::th[contains(.,'Risk Assessment Code')]/following-sibling::th[contains(.,'Status')]/following-sibling::th[contains(.,'Auditor Note')]/following-sibling::th[contains(.,'Edit')]");
            bool results = Browser.Wd.FindElement(res).Displayed;
            Assert.IsTrue(results, "Expected headers of result grid is not found");
        }

        [Then(@"Verify Auditor Review page displays Chart ID as ""(.*)"" Status as ""(.*)"" for the selected File")]
        public void ThenVerifyAuditorReviewPageDisplaysChartIDAsStatusAsForTheSelectedFile(string p0, string p1)
        {
            string chartID = tmsCommon.GenerateData(p0);
            string status = tmsCommon.GenerateData(p1);
            By res = By.XPath("//kendo-grid[@test-id='audit-grid']//td[contains(.,'" + chartID + "')]/following-sibling::td[contains(.,'" + status + "')]");
            bool results = Browser.Wd.FindElement(res).Displayed;
            Assert.IsTrue(results, " Expected search result is not found");
        }

        [Then(@"Verify Auditor Review page displays Auditor Note ""(.*)""")]
        public void ThenVerifyAuditorReviewPageDisplaysAuditorNote(string p0)
        {
            string note = tmsCommon.GenerateData(p0);
            By res = By.XPath("//kendo-popup//kendo-tooltip//div[contains(.,'" + note + "')]");
            bool results = Browser.Wd.FindElement(res).Displayed;
            Assert.IsTrue(results, " Expected search result is not found");
        }

        [Then(@"Verify Auditor Review page displays Expanded Member Information")]
        public void ThenVerifyAuditorReviewPageDisplaysExpandedMemberInformation()
        {
            By res = By.XPath("//kendo-grid[@test-id='audit-grid']//td[contains(.,'Member Name:')]");
            bool results = Browser.Wd.FindElement(res).Displayed;
            Assert.IsTrue(results, " Expected search result is not found");
        }

        [Then(@"Verify Auditor Review page does not display Expanded Member Information")]
        public void ThenVerifyAuditorReviewPageDoesNotDisplayExpandedMemberInformation()
        {
            By res = By.XPath("//kendo-grid[@test-id='audit-grid']//td[contains(.,'Member Name:')]");
            bool results = Browser.Wd.FindElement(res).Displayed;
            Assert.IsFalse(results, " Expected search result is not found");
        }

        [When(@"Auditor Review page Search results Chart ID as ""(.*)"" Status as ""(.*)"" record is selected")]
        public void WhenAuditorReviewPageSearchResultsChartIDAsStatusAsRecordIsSelected(string p0, string p1)
        {
            string chartID = tmsCommon.GenerateData(p0);
            string status = tmsCommon.GenerateData(p1);
            By res = By.XPath("//kendo-grid[@test-id='audit-grid']//td[contains(.,'" + chartID + "')]//following-sibling::td[contains(.,'" + status + "')]//preceding-sibling::td/input[@type='checkbox']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(res));
            tmsWait.Hard(1);
        }

        [When(@"Auditor Review page Search results Select All checkbox is selected")]
        public void WhenAuditorReviewPageSearchResultsSelectAllCheckboxIsSelected()
        {
            By res = By.XPath("//kendo-grid[@test-id='audit-grid']//input[@kendogridselectallcheckbox]");
            fw.ExecuteJavascript(Browser.Wd.FindElement(res));
            tmsWait.Hard(1);
        }

        [Then(@"Verify Auditor Review page Action button is Clicked")]
        public void ThenVerifyAuditorReviewPageActionButtonIsClicked()
        {
            By ele = By.CssSelector("[test-id='auditorReview-btn-action']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(ele));
            tmsWait.Hard(3);
        }

        [When(@"Action dialog Status is set to ""(.*)""")]
        public void WhenActionDialogStatusIsSetTo(string p0)
        {
            string filename = tmsCommon.GenerateData(p0);
            By drp = By.XPath("//kendo-dropdownlist[@test-id='auditorReview-select-action-status']//span[@class='k-select']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(drp));
            tmsWait.Hard(1);
            By value = By.XPath("//li[contains(.,'" + p0 + "')]");
            fw.ExecuteJavascript(Browser.Wd.FindElement(value));
        }

        [When(@"Action dialog Auditor Note is set to ""(.*)""")]
        public void WhenActionDialogAuditorNoteIsSetTo(string p0)
        {
            tmsWait.Hard(4);
            string note = tmsCommon.GenerateData(p0);
            By ele = By.CssSelector("[test-id='auditorReview-txt-auditorNote']");
            Browser.Wd.FindElement(ele).SendKeys(note);
        }

        [When(@"Action dialog Submit button is Clicked")]
        public void WhenActionDialogSubmitButtonIsClicked()
        {
            By ele = By.CssSelector("[test-id='searchMember-btn-search']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(ele));
            tmsWait.Hard(1);
        }

        [When(@"Action dialog Submit button is Clicked and Verify Message ""(.*)""")]
        public void WhenActionDialogSubmitButtonIsClickedAndVerifyMessage(string p0)
        {

            string expected_Message = tmsCommon.GenerateData(p0);
            By ele = By.CssSelector("[test-id='searchMember-btn-search']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(ele));
            tmsWait.Hard(1);
            string actual_Message = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
            try
            {
                Assert.IsTrue(actual_Message.Contains(expected_Message));
            }

            catch
            {
                Assert.IsTrue(actual_Message.Contains("There is no"), "No such message is displayed");
            }


        }

        [When(@"Action dialog Cancel button is Clicked")]
        public void WhenActionDialogCancelButtonIsClicked()
        {
            By ele = By.CssSelector("[test-id='searchMember-btn-reset']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(ele));
            tmsWait.Hard(1);
        }

        [Then(@"Verify Auditor Review page displayed success Toaster message ""(.*)""")]
        public void ThenVerifyAuditorReviewPageDisplayedSuccessToasterMessage(string p0)
        {
            ReUsableFunctions.toasterMessageDisplay(p0);
            tmsWait.Hard(10);

        }

        [Then(@"Verify Auditor Review page ""(.*)"" is displayed")]
        public void ThenVerifyAuditorReviewPageIsDisplayed(string p0)
        {
            string field = tmsCommon.GenerateData(p0);
            switch (field.ToLower())
            {
                case "auditor review title": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//div[contains(.,'Auditor Review')])[1]")).Displayed); break;
                case "search by": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[@test-id='auditorReview-lbl-selectType']")).Displayed); break;
                case "file radio button": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//input[@test-id='auditorReview-radio-File']")).Displayed); break;
                case "parameter radio button": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//input[@test-id='auditorReview-radio-Parameter']")).Displayed); break;
                case "date loaded from": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Date Loaded From')]/following-sibling::kendo-datepicker")).Displayed); break;
                case "to": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'To')]/following-sibling::kendo-datepicker")).Displayed); break;
                case "source": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Source')]/following-sibling::kendo-dropdownlist")).Displayed); break;
                case "search button": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//button[@test-id='auditorReview-btn-filesearch']")).Displayed); break;
                case "results grid": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='audit-grid']")).Displayed); break;
                case "action status": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='auditorReview-select-action-status']")).Displayed); break;
            }
        }

        [Then(@"Verify Auditor Review page ""(.*)"" is not displayed")]
        public void ThenVerifyAuditorReviewPageIsNotDisplayed(string p0)
        {
            string field = tmsCommon.GenerateData(p0);
            switch (field.ToLower())
            {
                case "auditor review title": Assert.IsFalse(Browser.Wd.FindElement(By.XPath("(//div[contains(.,'Auditor Review')])[1]")).Displayed); break;
                case "search by": Assert.IsFalse(Browser.Wd.FindElement(By.XPath("//label[@test-id='auditorReview-lbl-selectType']")).Displayed); break;
                case "file radio button": Assert.IsFalse(Browser.Wd.FindElement(By.XPath("//input[@test-id='auditorReview-radio-File']")).Displayed); break;
                case "parameter radio button": Assert.IsFalse(Browser.Wd.FindElement(By.XPath("//input[@test-id='auditorReview-radio-Parameter']")).Displayed); break;
                case "date loaded from": Assert.IsFalse(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Date Loaded From')]/following-sibling::kendo-datepicker")).Displayed); break;
                case "to": Assert.IsFalse(Browser.Wd.FindElement(By.XPath("//label[contains(.,'To')]/following-sibling::kendo-datepicker")).Displayed); break;
                case "source": Assert.IsFalse(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Source')]/following-sibling::kendo-dropdownlist")).Displayed); break;
                case "search button": Assert.IsFalse(Browser.Wd.FindElement(By.XPath("//button[@test-id='auditorReview-btn-filesearch']")).Displayed); break;
                case "results grid":
                    By resultGrid = By.XPath("//kendo-grid[@test-id='audit-grid']");
                    AngularFunction.elementNotPresenceUsingLocators(resultGrid);
                    break;
                    //Assert.IsFalse(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='audit-grid']")).Displayed); break;
                case "action status":
                    By ActionStatus = By.XPath("//kendo-dropdownlist[@test-id='auditorReview-select-action-status']");
                    AngularFunction.elementNotPresenceUsingLocators(ActionStatus);
                     break;
            }
        }

        [Then(@"Verify Auditor Review page ""(.*)"" Radio Button is selected")]
        public void ThenVerifyAuditorReviewPageRadioButtonIsSelected(string p0)
        {
            string field = tmsCommon.GenerateData(p0);
            switch (field.ToLower())
            {
                case "file": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='auditorReview-file-txt-FileNames']")).Displayed); break;
                case "parameter": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='auditorReview-select-status']")).Displayed); break;
            }
        }

        [Then(@"Verify Auditor Review page ""(.*)"" Drop Down is set to ""(.*)""")]
        public void ThenVerifyAuditorReviewPageDropDownIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            string actualValue = "";
            By Drp = null;

            switch (field.ToLower())
            {
                case "source": 
                    tmsWait.Hard(3);

                    Drp = By.XPath("//label[contains(.,'Source')]/parent::div//span[@class='k-input']");
                    actualValue = Browser.Wd.FindElement(Drp).Text;
                    Assert.AreEqual(value, actualValue, " Both values are not matching");
                    break;
                case "status":
                    tmsWait.Hard(3);

                    Drp = By.XPath("//label[contains(.,'Status')]/parent::div//span[@class='k-input']");
                    actualValue = Browser.Wd.FindElement(Drp).Text;
                    Assert.AreEqual(value, actualValue, " Both values are not matching");
                    break;
            }
        }

        [Then(@"Verify Auditor Review page ""(.*)"" Field is set to ""(.*)""")]
        public void ThenVerifyAuditorReviewPageFieldIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string expectedValue = tmsCommon.GenerateData(p1);
            string actualValue = "";
            By Drp = null;

            switch (field.ToLower())
            {
                case "chart id":
                    Drp = By.XPath("//input[@test-id='auditorReview-txt-chartId']");
                    actualValue = Browser.Wd.FindElement(Drp).GetAttribute("value");
                    Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");

                    break;
            }
        }

        [When(@"Auditor Review page Member ID ""(.*)"" is entered")]
        public void WhenAuditorReviewPageMemberIDIsEntered(string p0)
        {
            string value = tmsCommon.GenerateData(p0);

            By memberLookup = By.CssSelector("[test-id='auditorReview-a-memberLookup']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(memberLookup));
            tmsWait.Hard(5);

            By memberLookupFirstName = By.CssSelector("[test-id='searchMember-txt-MemberID']");
            Browser.Wd.FindElement(memberLookupFirstName).SendKeys(value);

            By memberLookupSearchBtn = By.CssSelector("[test-id='searchMember-btn-search']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(memberLookupSearchBtn));
            tmsWait.Hard(5);

            By selectRecord = By.XPath("(//button[@title='Add'])[1]");
            fw.ExecuteJavascript(Browser.Wd.FindElement(selectRecord));
        }

        [When(@"Auditor Review page Provider ID ""(.*)"" is entered")]
        public void WhenAuditorReviewPageProviderIDIsEntered(string p0)
        {
            /*string value = tmsCommon.GenerateData(p0);

            By providerLookup = By.CssSelector("[test-id='auditorReview-a-providerLookup']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(providerLookup));
            tmsWait.Hard(5);

            By providerLookupFirstName = By.CssSelector("[test-id='searchProvider-txt-ProviderID']");
            Browser.Wd.FindElement(providerLookupFirstName).SendKeys(value);

            By providerLookupSearchBtn = By.CssSelector("[test-id='searchProvider-btn-search']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(providerLookupSearchBtn));
            tmsWait.Hard(5);

            By selectRecord = By.XPath("(//button[@title='Add'])[1]");
            fw.ExecuteJavascript(Browser.Wd.FindElement(selectRecord));*/

            By AuditReviewProvider = By.Id("inputProviderId");
            Browser.Wd.FindElement(AuditReviewProvider).SendKeys(GlobalRef.AuditREviewProviderId);
            tmsWait.Hard(3);
        }

        [When(@"Enter New Diagnosis Data page Member ID look up is clicked and Member is populated")]
        public void WhenEnterNewDiagnosisDataPageMemberIDLookUpIsClickedAndMemberIsPopulated()
        {
            By memberLookup = By.CssSelector("[test-id='searchDiag-link-member']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(memberLookup));
            tmsWait.Hard(5);


            By memberLookupFirstName = By.CssSelector("[test-id='searchMember-txt-MemberID']");
            Browser.Wd.FindElement(memberLookupFirstName).SendKeys("MEM");

            By memberLookupSearchBtn = By.CssSelector("[test-id='searchMember-btn-search']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(memberLookupSearchBtn));
            tmsWait.Hard(5);

            By selectRecord = By.XPath("(//button[@title='Add'])[1]");
            fw.ExecuteJavascript(Browser.Wd.FindElement(selectRecord));

        }

        [When(@"Enter New Diagnosis Data page Chart ID value is set to ""(.*)""")]
        public void WhenEnterNewDiagnosisDataPageChartIDValueIsSetTo(string p0)
        {
            tmsWait.Hard(10);
            string chart = tmsCommon.GenerateData(p0);
            By chartID = By.CssSelector("[test-id='searchDiag-txt-txtChartId']");
            Browser.Wd.FindElement(chartID).Clear();
            Browser.Wd.FindElement(chartID).SendKeys(chart);
            Browser.Wd.FindElement(chartID).SendKeys(Keys.Tab);
            tmsWait.Hard(2);
        }

        [When(@"Enter New Diagnosis Data page Diagnosis Code value is set to ""(.*)""")]
        public void WhenEnterNewDiagnosisDataPageDiagnosisCodeValueIsSetTo(string p0)
        {
            string diag = tmsCommon.GenerateData(p0);
            By diagID = By.CssSelector("[test-id='searchDiag-txt-txtDiagCode']");
            Browser.Wd.FindElement(diagID).SendKeys(diag);
            tmsWait.Hard(2);
        }

        [When(@"Enter New Diagnosis Data page Existing Diagnosis Code value is entered")]
        public void WhenEnterNewDiagnosisDataPageExistingDiagnosisCodeValueIsEntered()
        {
            tmsWait.Hard(2);
            string existingDig = singleColumnQueryExecutionSelectRecordBasedOnIndex("SELECT Codevalue FROM [RAM].[dbo].[ICD9Codes] where ICDVersion=1", ConfigFile.RAMdb, 1);
            tmsWait.Hard(2);
            GlobalRef.DIAGCODE = existingDig;
            By diagID = By.CssSelector("[test-id='searchDiag-txt-txtDiagCode']");
            UIMODUtilFunctions.enterValueOnWebElementUsingLocators(diagID, existingDig);
        }

        [When(@"RAMX Enter New Diagnosis Data page Existing Diagnosis Code value is entered")]
        public void WhenRAMXEnterNewDiagnosisDataPageExistingDiagnosisCodeValueIsEntered()
        {
            tmsWait.Hard(2);
            string existingDig = singleColumnQueryExecutionSelectRecordBasedOnIndex("SELECT Codevalue FROM [RAMX].[dbo].[ICD9Codes] where ICDVersion=1", "RAMX", 1);
            tmsWait.Hard(2);
            GlobalRef.DIAGCODE = existingDig;
            By diagID = By.CssSelector("[test-id='searchDiag-txt-txtDiagCode']");
            UIMODUtilFunctions.enterValueOnWebElementUsingLocators(diagID, existingDig);
        }
        [When(@"RAMX Enter New Diagnosis Data page Existing Diagnosis Code ""(.*)"" is entered")]
        public void WhenRAMXEnterNewDiagnosisDataPageExistingDiagnosisCodeIsEntered(string p0)
        {
            string existingDig = tmsCommon.GenerateData(p0);
            GlobalRef.DIAGCODE = existingDig;
            By diagID = By.CssSelector("[test-id='searchDiag-txt-txtDiagCode']");
            UIMODUtilFunctions.enterValueOnWebElementUsingLocators(diagID, existingDig);
        }


        [When(@"Enter New Diagnosis Data page Encounter From Date is set to ""(.*)""")]
        public void WhenEnterNewDiagnosisDataPageEncounterFromDateIsSetTo(string date)
        {
            tmsWait.Hard(3);
            if (date.Equals("Today"))
            {

                //    DateTime currentTime = DateTime.Now;
                //    string currentDate = currentTime.ToString("D");
                //    CultureInfo invC = CultureInfo.InvariantCulture;
                // currentTime.ToString("f", invC);
                // string xpath= (currentTime.ToString("f", invC)).Substring(0,(currentTime.ToString("f", invC)).Length-6);
                IWebElement calButton = Browser.Wd.FindElement(By.CssSelector("[aria-controls='txtEncounterFromDate_dateview']"));
                fw.ExecuteJavascript(calButton);
                tmsWait.Hard(3);
                string xpath = Browser.Wd.FindElement(By.XPath("(//td[contains(@class,'k-today')]/a)[1]")).GetAttribute("title");
                IWebElement calDate = Browser.Wd.FindElement(By.CssSelector("[title='" + xpath + "']"));
                tmsWait.Hard(3);
                fw.ExecuteJavascript(calDate);
            }
            if (date.Equals("Current Year Jan"))
            {
                DateTime currentTime = DateTime.Now;
                string startDate = "01/01/" + currentTime.Year;
                IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='searchMember-txt-encounterFromDate']//span/input"));
                string value1 = startDate.Replace("/", "");
                ele.Clear();
                ele.SendKeys(value1);
                tmsWait.Hard(3);
                //By from = By.CssSelector("[test-id='searchMember-txt-encounterFromDate']");
                //Browser.Wd.FindElement(from).Clear();
                //Browser.Wd.FindElement(from).SendKeys(startDate);
            }
            if (date.Equals("Generate|variable|EncounterDate"))
            {
                
                string dateinput = tmsCommon.GenerateData(date);
              
             //   By datePicker = By.XPath("//kendo-datepicker[@test-id='searchMember-txt-encounterFromDate']//span[@class='k-select']");
               // AngularFunction.enterRAM_EncounterDate(datePicker, dateinput);

               
                goto SkipToEnd;
            }
            if (date.Equals("Previous Year Jan"))
            {
                DateTime currentTime = DateTime.Now;
                string startDate = "01/01/" + (currentTime.Year - 1);
                By from = By.CssSelector("[test-id='searchMember-txt-encounterFromDate']");
                Browser.Wd.FindElement(from).Clear();
                Browser.Wd.FindElement(from).SendKeys(startDate);
            }
            else
            {
                /*
                                DateTime currentTime = DateTime.Now;
                                string startDate = "01/01/" + currentTime.Year;
                                By from = By.CssSelector("[test-id='searchMember-txt-encounterFromDate']");
                                Browser.Wd.FindElement(from).Clear();
                                Browser.Wd.FindElement(from).SendKeys(startDate); */
            }

        SkipToEnd: { }
        }

        [When(@"Enter New Diagnosis Data page Encounter To Date is set to ""(.*)""")]
        public void WhenEnterNewDiagnosisDataPageEncounterToDateIsSetTo(string to)
        {
            if (to.Equals("Current Year Dec"))
            {
                DateTime currentTime = DateTime.Now;
                string startDate = "12/31/" + currentTime.Year;
                By toDate = By.CssSelector("[test-id='searchMember-txt-encounterToDate']");
                Browser.Wd.FindElement(toDate).Clear();
                Browser.Wd.FindElement(toDate).SendKeys(startDate);
            }
            if (to.Equals("Previous Year Dec"))
            {
                DateTime currentTime = DateTime.Now;
                string startDate = "12/31/" + (currentTime.Year - 1);
                By toDate = By.CssSelector("[test-id='searchMember-txt-encounterToDate']");
                Browser.Wd.FindElement(toDate).Clear();
                Browser.Wd.FindElement(toDate).SendKeys(startDate);
            }

            if (to.Equals("Today"))
            {
                string startDate = DateTime.Now.ToString("M/d/yyyy");
                //By toDate = By.CssSelector("[test-id='searchMember-txt-encounterToDate']");
                IWebElement toDate = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='searchMember-txt-encounterToDate']//span/input"));
                string startDate1 = startDate.Replace("/", "");
               toDate.Clear();
                toDate.SendKeys(startDate1);

            }
            //if (to.Equals("Today"))
            //{
            //    DateTime currentTime = DateTime.Now;
            //    string currentDate = currentTime.ToString("D");

            //    IWebElement calButton = Browser.Wd.FindElement(By.CssSelector("[aria-controls='txtEncounterToDate_dateview']"));
            //    fw.ExecuteJavascript(calButton);
            //    tmsWait.Hard(3);
            //    IWebElement calDate = Browser.Wd.FindElement(By.CssSelector("[title='" + currentDate + "']"));

            //    fw.ExecuteJavascript(calDate);
            //}
            //else
            //{
            //    By toDate = By.CssSelector("[test-id='searchMember-txt-encounterToDate']");
            //    Browser.Wd.FindElement(toDate).Clear();
            //    Browser.Wd.FindElement(toDate).SendKeys(to);
            //    tmsWait.Hard(2);
            //}
        }

        [When(@"Enter New Diagnosis Data page Select Any Type of Service")]
        public void WhenEnterNewDiagnosisDataPageSelectAnyTypeOfService()
        {
            //By drp = By.CssSelector("[aria-owns='ddlTypeofservice_listbox']");
            //fw.ExecuteJavascript(Browser.Wd.FindElement(drp));
            //tmsWait.Hard(1);
            //By value = By.XPath("(//ul[@id='ddlTypeofservice_listbox']//li)[2]");
            //fw.ExecuteJavascript(Browser.Wd.FindElement(value));
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='searchDiag-txt-ddlTypeofservice']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='20 - Physician Diagnosis']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }

        [When(@"Enter New Diagnosis Data page Select Provider ID ""(.*)"" from Provider ID look up")]
        public void WhenEnterNewDiagnosisDataPageSelectProviderIDFromProviderIDLookUp(string p0)
        {
            string temp = tmsCommon.GenerateData(p0);
            By providerLookup = By.CssSelector("[test-id='searchDiag-link-provider']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(providerLookup));
            tmsWait.Hard(5);


            By providerLookupFirstName = By.CssSelector("[test-id='searchProvider-txt-ProviderID']");
            Browser.Wd.FindElement(providerLookupFirstName).SendKeys(temp);

            By memberLookupSearchBtn = By.CssSelector("[test-id='searchProvider-btn-search']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(memberLookupSearchBtn));
            tmsWait.Hard(5);

            By selectRecord = By.XPath("(//button[@title='Add'])[1]");
            fw.ExecuteJavascript(Browser.Wd.FindElement(selectRecord));
        }

        [When(@"Enter New Diagnosis Data page Select Provider ID from Provider ID look up")]
        public void WhenEnterNewDiagnosisDataPageSelectProviderIDFromProviderIDLookUp()
        {
            By providerLookup = By.CssSelector("[test-id='searchDiag-link-provider']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(providerLookup));
            tmsWait.Hard(8);


            By providerLookupFirstName = By.CssSelector("[test-id='searchProvider-txt-FirstName']");
            Browser.Wd.FindElement(providerLookupFirstName).SendKeys("A");

            By memberLookupSearchBtn = By.CssSelector("[test-id='searchProvider-btn-search']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(memberLookupSearchBtn));
            tmsWait.Hard(5);

            By selectRecord = By.XPath("(//button[@title='Add'])[1]");
            fw.ExecuteJavascript(Browser.Wd.FindElement(selectRecord));
        }

        [When(@"Enter New Diagnosis Data page Select any Risk Assessment Code")]
        public void WhenEnterNewDiagnosisDataPageSelectAnyRiskAssessmentCode()
        {

            By Drp = By.XPath("//kendo-dropdownlist[@id='ddlRiskAssessment']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='A – Clinical Setting']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }

        [When(@"Enter New Diagnosis Data page Select any Coder ID")]
        public void WhenEnterNewDiagnosisDataPageSelectAnyCoderID()
        {
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='searchDiag-txt-ddlCoderId']//span[@class='k-select']");
            By typeapp = By.XPath("//li[contains(.,'None')]");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }

        [When(@"Enter New Diagnosis Data page Select Coder ID as ""(.*)""")]
        public void WhenEnterNewDiagnosisDataPageSelectCoderIDAs(string p0)
        {
            tmsWait.Hard(2);
            string value = tmsCommon.GenerateData(p0);

            By Drp = By.XPath("//label[contains(.,'Coder ID')]/parent::div//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + value + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);

        }

        [When(@"Enter New Diagnosis Data page Select any Chart Review Source")]
        public void WhenEnterNewDiagnosisDataPageSelectAnyChartReviewSource()
        {
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='searchDiag-txt-ddlDiagnosisSource']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='Other']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }

        [When(@"Enter New Diagnosis Data page Enter reference Information")]
        public void WhenEnterNewDiagnosisDataPageEnterReferenceInformation()
        {
            By reference = By.CssSelector("[test-id='searchDiag-txt-txtReferenceInformation']");
            Browser.Wd.FindElement(reference).Clear();
            Browser.Wd.FindElement(reference).SendKeys("AutoTesting");
        }

        [When(@"Enter New Diagnosis Data page Reference Information is set to ""(.*)""")]
        public void WhenEnterNewDiagnosisDataPageReferenceInformationIsSetTo(string p0)
        {
            string temp = tmsCommon.GenerateData(p0);
            By reference = By.CssSelector("[test-id='searchDiag-txt-txtReferenceInformation']");
            AngularFunction.sendKeysWithClear(reference, temp);
        }

        [Then(@"Verify Edit Diagnosis Code Detail page Provider Name is Disabled")]
        public void ThenVerifyEditDiagnosisCodeDetailPageProviderNameIsDisabled()
        {
            By temp = By.CssSelector("[test-id='editOnHoldDiagnosis-txt-txtProviderName']");
            AngularFunction.elementDisableUsingLocators(temp);


        }

        [Then(@"Verify Edit Diagnosis Code Detail page Member ID is Disabled")]
        public void ThenVerifyEditDiagnosisCodeDetailPageMemberIDIsDisabled()
        {
            By temp = By.CssSelector("[test-id='editOnHoldDiagnosis-txt-txtMemberId']");
            AngularFunction.elementDisableUsingLocators(temp);
        }

        [Then(@"Verify Edit Diagnosis Code Detail page Chart ID is Disabled")]
        public void ThenVerifyEditDiagnosisCodeDetailPageChartIDIsDisabled()
        {
            By temp = By.CssSelector("[test-id='editOnHoldDiagnosis-txt-txtClartId']");
            AngularFunction.elementDisableUsingLocators(temp);
        }

        [Then(@"Verify Edit Diagnosis Code Detail page Control Number is Disabled")]
        public void ThenVerifyEditDiagnosisCodeDetailPageControlNumberIsDisabled()
        {
            By temp = By.CssSelector("[test-id='editOnHoldDiagnosis-txt-txtControlNumber']");
            AngularFunction.elementDisableUsingLocators(temp);
        }

        [Then(@"Verify Edit Diagnosis Code Detail page PIR Status is Disabled")]
        public void ThenVerifyEditDiagnosisCodeDetailPagePIRStatusIsDisabled()
        {
            By temp = By.CssSelector("[test-id='editOnHoldDiagnosis-txt-txtPIRStatus']");
            AngularFunction.elementDisableUsingLocators(temp);
        }

        [Then(@"Verify Edit Diagnosis Code Detail page Auditor Note is Disabled")]
        public void ThenVerifyEditDiagnosisCodeDetailPageAuditorNoteIsDisabled()
        {

            By temp = By.CssSelector("[test-id='editOnHoldDiagnosis-txt-txtAuditorNote']");
            AngularFunction.elementDisableUsingLocators(temp);
        }


        [When(@"Edit Diagnosis Code Detail page Dignosis Code is removed then Verify the error message display ""(.*)""")]
        public void WhenEditDiagnosisCodeDetailPageDignosisCodeIsRemovedThenVerifyTheErrorMessageDisplay(string p0)
        {
            IWebElement component = Browser.Wd.FindElement(By.CssSelector("[test-id='editOnHoldDiagnosis-txt-txtDiagCode']"));
            string temp = component.GetAttribute("value");

            component.Clear();
            component.SendKeys(Keys.Tab);
            By msg = By.XPath("//span[contains(.,'"+ p0 + "')]");
            AngularFunction.elementPresenceUsingLocators(msg);

            component.SendKeys(temp);

        }

        [When(@"Edit Diagnosis Code Detail page Provider ID is removed then Verify the error message display ""(.*)""")]
        public void WhenEditDiagnosisCodeDetailPageProviderIDIsRemovedThenVerifyTheErrorMessageDisplay(string p0)
        {
            IWebElement component = Browser.Wd.FindElement(By.CssSelector("[test-id='editOnHoldDiagnosis-txt-txtDiagCode']"));
            string temp = component.GetAttribute("value");

            component.Clear();

            By msg = By.XPath("//span[contains(.,'" + p0 + "')]");
            AngularFunction.elementPresenceUsingLocators(msg);

            component.SendKeys(temp);
            
        }


        [When(@"RAMX Enter New Diagnosis Data page Enter reference Information as ""(.*)""")]
        public void WhenRAMXEnterNewDiagnosisDataPageEnterReferenceInformationAs(string p0)
        {
            string referenceInfo = tmsCommon.GenerateData(p0);
            GlobalRef.Reference = referenceInfo;
            By reference = By.CssSelector("[test-id='searchDiag-txt-txtReferenceInformation']");
            Browser.Wd.FindElement(reference).Clear();
            Browser.Wd.FindElement(reference).SendKeys(referenceInfo);
        }


        [When(@"RAM Application Flag for Audit Page ""(.*)"" is uploaded")]
        [When(@"RAMX Application Flag for Audit Page ""(.*)"" is uploaded")]
        public void WhenRAMApplicationFlagForAuditPageIsUploaded(string p0)
        {
            tmsWait.Hard(7);
            //string fileName = tmsCommon.GenerateData(p0);
            //string path = @"C:\Temp\" + fileName;
            ////string path1 = @"C:\Temp";

            ////By upload = By.CssSelector("[test-id='flagForAuditReview-upload-fileUpload'] input");
            //// By upload = By.XPath("//button[@class='k-button k-primary k-upload-selected']");
            //By upload = By.XPath("//div[@class='k-button k-upload-button']");
            //IWebElement uploadElement = Browser.Wd.FindElement(upload);
            //uploadElement.SendKeys(path);
            tmsWait.Hard(3);
            tmsWait.Hard(7);
            string fileName = tmsCommon.GenerateData(p0);
            string path = @"C:\temp\" + fileName;
            By upload = By.CssSelector("[test-id='flagForAuditReview-upload-fileUpload'] input");
            IWebElement uploadElement = Browser.Wd.FindElement(upload);
            uploadElement.SendKeys(path);



        }

        [When(@"RAMX Application Flag for Audit Page Import Button is clicked without selecting a file and Verify Message ""(.*)""")]
        public void WhenRAMXApplicationFlagForAuditPageImportButtonIsClickedWithoutSelectingAFileAndVerifyMessage(string p0)
        {
            string message = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='flagForAuditReview-btnUploadFiles']")));
            string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
            tmsWait.Hard(1);
            Assert.IsTrue(actualValue.Contains(message));
        }



        public string singleColumnQueryExecution(string SqlString, string DB)
        {
            ArrayList actList = new ArrayList();
            fsRSMLogin DBquery = new fsRSMLogin();
            actList = DBquery.ExecuteSQLQuery(SqlString, DB);
            string output = actList[0].ToString();
            return output;
        }

        public string singleColumnQueryExecutionSelectRecordBasedOnIndex(string SqlString, string DB, int recordIndex)
        {
            ArrayList actList = new ArrayList();
            fsRSMLogin DBquery = new fsRSMLogin();
            actList = DBquery.ExecuteSQLQuery(SqlString, DB);
            //int aa= actList[recordIndex];
            string output = actList[recordIndex].ToString();
            return output;
        }

        [When(@"Manage Suspects page Type drop down list is set to ""(.*)""")]
        public void WhenManageSuspectsPageTypeDropDownListIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            string value = tmsCommon.GenerateData(p0);
            //new SelectElement(Browser.Wd.FindElement(By.CssSelector("[test-id='manageSuspects-select-searchType']"))).SelectByText(value);

            By Drp = By.XPath("//kendo-dropdownlist[@test-id='manageSuspects-select-searchType']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + value + "']");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
        }

        [When(@"PIR page Variable ""(.*)"" is set to value ""(.*)""")]
        [Then(@"PIR page Variable ""(.*)"" is set to value ""(.*)""")]
        [Given(@"PIR page Variable ""(.*)"" is set to value ""(.*)""")]
        public void WhenPIRPageVariableIsSetToValue(string p0, string p1)
        {
            tmsWait.Hard(20);
            string readedValue = "";

            if (p1.Equals("PageReadedPIR"))
            {
                By element = By.CssSelector("[test-id='pirResponse-span-heading']");
                readedValue = (Browser.Wd.FindElement(element).Text.Split())[1];

            }
            if (p1.Equals("PageReadedMember"))
            {
                By element = By.CssSelector("[test-id='pirResponse-span-memberIdTxt']");
                readedValue = Browser.Wd.FindElement(element).Text;

            }
            if (p1.Equals("PageReadedProvider"))
            {
                By element = By.CssSelector("[test-id='pirResponse-span-providerIdTxt']");
                readedValue = Browser.Wd.FindElement(element).Text;

            }
            if (p1.Equals("PageReadedDateOfService"))
            {
                By element = By.CssSelector("[test-id='pirResponse-span-dosTxt']");
                readedValue = Browser.Wd.FindElement(element).Text;

            }
            if (p1.Equals("ExistingDiagCode1"))
            {
                tmsWait.Hard(2);
                readedValue = singleColumnQueryExecutionSelectRecordBasedOnIndex("SELECT Codevalue FROM [RAM].[dbo].[ICD9Codes] where ICDVersion=1", ConfigFile.RAMdb, 2);


            }
            if (p1.Equals("ExistingDiagCode2"))
            {
                tmsWait.Hard(2);
                readedValue = singleColumnQueryExecutionSelectRecordBasedOnIndex("SELECT Codevalue FROM [RAM].[dbo].[ICD9Codes] where ICDVersion=1", ConfigFile.RAMdb, 3);


            }

            fw.setVariable(p0, readedValue);
            tmsWait.Hard(5);
        }

        [When(@"Manage Suspects page Search button is Clicked")]
        public void WhenManageSuspectsPageSearchButtonIsClicked()
        {
            By search = By.CssSelector("[test-id='manageSuspects-button-search']");
            IWebElement searchBtn = Browser.Wd.FindElement(search);
            fw.ExecuteJavascript(searchBtn);
            tmsWait.Hard(14);

        }
        [Then(@"Manage Suspects page Back button is Clicked")]
        public void ThenManageSuspectsPageBackButtonIsClicked()
        {
            IWebElement Btn = Browser.Wd.FindElement(By.XPath("//span[@test-id='pirResponse-span-back']"));
            fw.ExecuteJavascript(Btn);
            tmsWait.Hard(12);
        }

        [Then(@"Verify PIR page displayed message as ""(.*)""")]
        public void ThenVerifyPIRPageDisplayedMessageAs(string p0)
        {
            tmsWait.Hard(4);
            By msglocator = By.XPath("//label[@test-id='pirResponse-label-responseSubmittedError'][contains(.,'" + p0 + "')]");

            bool msgDisplay = Browser.Wd.FindElement(msglocator).Displayed;
            Assert.IsTrue(msgDisplay, " Expected Message is not displayed");

        }

        [Then(@"Verify Toaster message ""(.*)"" is displayed")]
        [Then(@"Verify On-Hold and Diagnosis Review page displayed message as ""(.*)""")]
        public void ThenVerifyOn_HoldAndDiagnosisReviewPageDisplayedMessageAs(string p0)
        {
            // ReUsableFunctions.toasterMessageDisplay(p0);
        }






        [Then(@"Verify PIR page Submit button is Disabled")]
        public void ThenVerifyPIRPageSubmitButtonIsDisabled()
        {
            By msglocator = By.CssSelector("[test-id='pirResponse-btn-add']");

            //bool msgDisplay = Browser.Wd.FindElement(msglocator).Enabled;
            AngularFunction.elementNotPresenceUsingLocators(msglocator);
            //Assert.IsFalse(msgDisplay, " Expected Button is Enabled");

        }

        [Then(@"Verify PIR page Submit button is Enabled")]
        public void ThenVerifyPIRPageSubmitButtonIsEnabled()
        {
            By msglocator = By.CssSelector("[test-id='pirResponse-btn-add']");

            bool msgDisplay = Browser.Wd.FindElement(msglocator).Enabled;
            Assert.IsTrue(msgDisplay, " Expected Button is not Disabled");
        }
        [Then(@"Back To Record button is Clicked")]
        public void ThenBackToRecordButtonIsClicked()
        {
            By backtoRecord = By.XPath("(//span[@class='k-icon k-i-x'])[2]");
            fw.ExecuteJavascript(Browser.Wd.FindElement(backtoRecord));
            tmsWait.Hard(4);
        }

        [Then(@"Verify that user is navigated to ""(.*)"" Page")]
        public void ThenVerifyThatUserIsNavigatedToPage(string pagename)
        {

            tmsWait.Hard(5);
            By loc = By.XPath("//div[contains(text(),'"+pagename+"')]");
            AngularFunction.elementPresenceUsingLocators(loc); 
        }

        [When(@"PIR page Back To Record button is Clicked")]
        [Then(@"PIR page Back To Record button is Clicked")]
        public void ThenPIRPageBackToRecordButtonIsClicked()
        {
            tmsWait.Hard(5);
            By loc = By.CssSelector("[test-id='pirResponse-span-back']");
            AngularFunction.clickOnElement(loc);
            //fw.ExecuteJavascript(Browser.Wd.FindElement(backtoRecord));
            tmsWait.Hard(5);
        }

        [Then(@"Verify PIR page displayed Provider ID successfully")]
        public void ThenVerifyPIRPageDisplayedProviderIDSuccessfully()
        {
            tmsWait.Hard(4);
            string expectedMemberID = GlobalRef.ProviderID.ToString();
            By mem = By.CssSelector("[test-id='pirResponse-span-providerIdTxt']");
            //string actualMemberID = Browser.Wd.FindElement(mem).Text;
            //Assert.AreEqual(expectedMemberID, actualMemberID, " Both actual and expected are not matching");
            bool memberIDDisplay = Browser.Wd.FindElement(mem).Displayed;
            Assert.IsTrue(memberIDDisplay, " Suspect Page is not displayed");
        }

        [Then(@"Verify Manage Suspects page displayed ""(.*)"" successfully")]
        public void ThenVerifyManageSuspectsPageDisplayedSuccessfully(string p0)
        {

            string value = tmsCommon.GenerateData(p0);
            tmsWait.Hard(8);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//div[@test-id='manageSuspects-grid-memberResult']//td[contains(.,'" + value + "')])[1]")).Displayed);

        }

        [Then(@"Verify PIR page displayed Member ID successfully")]
        public void ThenVerifyPIRPageDisplayedMemberIDSuccessfully()
        {
            tmsWait.Hard(4);

            string expectedProviderID = GlobalRef.MemberID.ToString();
            By pro = By.CssSelector("[test-id='pirResponse-span-memberIdTxt']");
            //string actualProviderID = Browser.Wd.FindElement(pro).Text;
            //Assert.AreEqual(expectedProviderID, actualProviderID, " Both actual and expected are not matching");
            bool providerIDDisplay = Browser.Wd.FindElement(pro).Displayed;
            Assert.IsTrue(providerIDDisplay, " Suspect Page is not displayed");
        }


        [Then(@"Verify Suspect HCC Information is displayed successfully")]
        public void ThenVerifySuspectHCCInformationIsDisplayedSuccessfully()
        {
            By page = By.XPath("//label[@test-id='pirResponse-lbl-suspectsHccInfo'][contains(.,'Suspect HCC Information:')]");
            bool pageDisplay = Browser.Wd.FindElement(page).Displayed;
            Assert.IsTrue(pageDisplay, " Suspect Page is not displayed");
        }

        [When(@"Enter New Diagnosis Data page Execute Query and Active Member is populated for Report ""(.*)"" Type as ""(.*)""")]
        public void WhenEnterNewDiagnosisDataPageExecuteQueryAndActiveMemberIsPopulatedForReportTypeAs(string reportName, string interactionType)
        {
            int recordIndex = 0;
            if (reportName.Equals("CMS File Extract Summary"))
            {
                if (interactionType.Equals("Interactive"))
                    recordIndex = 3;
                if (interactionType.Equals("CSV"))
                    recordIndex = 4;
                if (interactionType.Equals("XLSX"))
                    recordIndex = 5;
            }

            if (reportName.Equals("CMS Queue Report"))
            {
                if (interactionType.Equals("Interactive"))
                    recordIndex = 3;
                if (interactionType.Equals("CSV"))
                    recordIndex = 4;
                if (interactionType.Equals("XLSX"))
                    recordIndex = 5;
            }

            string MEMID = singleColumnQueryExecutionSelectRecordBasedOnIndex("SELECT txtMemberID  FROM RAM.dbo.tbMemberPlan where dteEnd='9999-12-31 00:00:00.000'", ConfigFile.RAMdb, recordIndex);

            GlobalRef.MEMID = MEMID;
            By memberLookup = By.CssSelector("[test-id='searchDiag-link-member']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(memberLookup));
            tmsWait.Hard(5);


            By memberLookupMemID = By.CssSelector("[test-id='searchMember-txt-MemberID']");
            Browser.Wd.FindElement(memberLookupMemID).SendKeys(MEMID);

            By memberLookupSearchBtn = By.CssSelector("[test-id='searchMember-btn-search']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(memberLookupSearchBtn));
            tmsWait.Hard(5);

            By selectRecord = By.XPath("(//button[@title='Add'])[1]");
            fw.ExecuteJavascript(Browser.Wd.FindElement(selectRecord));
        }

        [Then(@"RAM App Enter New Diagnosis Data page Member is set to ""(.*)"" and required field validator is verified")]
        public void ThenRAMAppEnterNewDiagnosisDataPageMemberIsSetToAndRequiredFieldValidatorIsVerified(string p0)
        {
            string MEMID = tmsCommon.GenerateData(p0);
            GlobalRef.MEMID = MEMID;

            //By memberLookup = By.CssSelector("[test-id='searchDiag-link-member']");
            //fw.ExecuteJavascript(Browser.Wd.FindElement(memberLookup));
            //tmsWait.Hard(50);

            By memberLookupMemID = By.CssSelector("[test-id='searchDiag-txt-txtMemberId']");
            tmsWait.WaitForElement(memberLookupMemID, 10);
            tmsWait.Hard(50);
            Browser.Wd.FindElement(memberLookupMemID).SendKeys(MEMID);

            By memberLookupSearchBtn = By.Id("btnsearch");
            fw.ExecuteJavascript(Browser.Wd.FindElement(memberLookupSearchBtn));
            tmsWait.Hard(5);

            By loc = By.XPath("//span[contains(.,'No special characters allowed including space')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }


        [When(@"RAM App Enter New Diagnosis Data page Member is set to ""(.*)"" and required field validator is verified")]
        public void WhenRAMAppEnterNewDiagnosisDataPageMemberIsSetToAndRequiredFieldValidatorIsVerified(string p0)
        {
            string MEMID = tmsCommon.GenerateData(p0);
            GlobalRef.MEMID = MEMID;

            //By memberLookup = By.CssSelector("[test-id='searchDiag-link-member']");
            //fw.ExecuteJavascript(Browser.Wd.FindElement(memberLookup));
            //tmsWait.Hard(50);

            By memberLookupMemID = By.CssSelector("[test-id='searchDiag-txt-txtMemberId']");
            tmsWait.WaitForElement(memberLookupMemID, 10);
            tmsWait.Hard(50);
            Browser.Wd.FindElement(memberLookupMemID).SendKeys(MEMID);

            By memberLookupSearchBtn = By.Id("btnsearch");
            fw.ExecuteJavascript(Browser.Wd.FindElement(memberLookupSearchBtn));
            tmsWait.Hard(5);

            By loc = By.XPath("//span[contains(.,'No special characters allowed including space')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);

        }

        [When(@"Enter New Diagnosis Data page claim Number set to ""(.*)""")]
        public void WhenEnterNewDiagnosisDataPageClaimNumberSetTo(string p0)
        {
            By claim = By.CssSelector("[test-id='searchDiag-txt-txtPlanClaimId']");
            string temp = tmsCommon.GenerateData(p0);
            AngularFunction.sendKeysWithClear(claim, temp); 
        }


        [When(@"RAMX App Enter New Diagnosis Data page Member is set to ""(.*)""")]
        [When(@"RAM App Enter New Diagnosis Data page Member is set to ""(.*)""")]
        public void WhenRAMXAppEnterNewDiagnosisDataPageMemberIsSetTo(string p0)
        {
            string MEMID = tmsCommon.GenerateData(p0);
            GlobalRef.MEMID = MEMID;
            By memberLookup = By.CssSelector("[test-id='searchDiag-link-member']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(memberLookup));
            tmsWait.Hard(5);
            By memberLookupMemID = By.CssSelector("[test-id='searchMember-txt-MemberID']");
            tmsWait.WaitForElement(memberLookupMemID, 5);
            tmsWait.Hard(5);
            Browser.Wd.FindElement(memberLookupMemID).SendKeys(MEMID);

            By memberLookupSearchBtn = By.CssSelector("[test-id='searchMember-btn-search']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(memberLookupSearchBtn));
            tmsWait.Hard(5);

            By selectRecord = By.XPath("(//button[@title='Add'])[1]");
            fw.ExecuteJavascript(Browser.Wd.FindElement(selectRecord));
        }

        [When(@"RAM App Enter New Diagnosis Data page Search button is clicked")]
        public void WhenRAMAppEnterNewDiagnosisDataPageSearchButtonIsClicked()
        {
            ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("//button[@test-id='encounter-btn-search']")));
            tmsWait.Hard(10);
        }

        [When(@"RAMX App Enter New Diagnosis Data page Search button is clicked")]
        public void WhenRAMXAppEnterNewDiagnosisDataPageSearchButtonIsClicked()
        {
            ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("//button[@test-id='member-diagnosis-btn-search']")));
            tmsWait.Hard(10);
        }

        [Then(@"Verify Enter New Diagnosis data page Chart Review source drop down contains source ""(.*)""")]
        public void ThenVerifyEnterNewDiagnosisDataPageChartReviewSourceDropDownContainsSource(string p0)
        {

            string expectedValue = tmsCommon.GenerateData(p0);
            bool found = false;
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='searchDiag-txt-ddlDiagnosisSource']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + expectedValue + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            //IWebElement drp = Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlDiagnosisSource_listbox']"));
            //fw.ExecuteJavascript(drp);
            //tmsWait.Hard(4);
            //IReadOnlyCollection<IWebElement> drpValues = Browser.Wd.FindElements(By.XPath("//ul[@id='ddlDiagnosisSource_listbox']/li"));

            //foreach (IWebElement temp in drpValues)
            //{
            //    if (temp.Text.Equals(expectedValue))
            //    {
            //        found = true;
            //    }
            //}
            IWebElement ddele = Browser.Wd.FindElement(By.XPath("(//label[text()='Chart Review Source']/parent::div//span[@class='k-input'])"));
            string actual_value = ddele.Text;
            Assert.IsTrue(actual_value.Contains(expectedValue), "Value does not match");

            //Assert.IsTrue(found, "Chart Review source does not contains expected source");
        }



        [Then(@"Verify Executed Query displayed Audit Status ""(.*)"" as  ""(.*)""")]
        public void ThenVerifyExecutedQueryDisplayedAuditStatusAs(string p0, string p1)
        {
            string expected = tmsCommon.GenerateData(p1);
            string actual = tmsCommon.GenerateData(p1);

            Assert.AreEqual(expected, actual, " Both were not matching");
        }


        [When(@"RAMX App Enter New Diagnosis Data page Execute SQL Query and Active Member is populated for RAPS Format")]
        public void WhenRAMXAppEnterNewDiagnosisDataPageExecuteSQLQueryAndActiveMemberIsPopulatedForRAPSFormat()
        {
            string MEMID = singleColumnQueryExecutionSelectRecordBasedOnIndex("SELECT txtMemberID  FROM RAMX.dbo.tbMemberPlan where dteEnd='9999-12-31 00:00:00.000'", "RAMX", 5).Trim();

            GlobalRef.MEMID = MEMID;
            By memberLookup = By.CssSelector("[test-id='searchDiag-link-member']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(memberLookup));
            tmsWait.Hard(5);


            By memberLookupMemID = By.CssSelector("[test-id='searchMember-txt-MemberID']");
            Browser.Wd.FindElement(memberLookupMemID).SendKeys(MEMID);

            By memberLookupSearchBtn = By.CssSelector("[test-id='searchMember-btn-search']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(memberLookupSearchBtn));
            tmsWait.Hard(5);

            By selectRecord = By.XPath("//button[@title='Add']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(selectRecord));
        }

        [When(@"Enter New Diagnosis Data page Execute Query and Active Member is populated for RAPS Format")]
        public void WhenEnterNewDiagnosisDataPageExecuteQueryAndActiveMemberIsPopulatedForRAPSFormat()
        {
            string MEMID = singleColumnQueryExecutionSelectRecordBasedOnIndex("SELECT txtMemberID  FROM RAM.dbo.tbMemberPlan where dteEnd='9999-12-31 00:00:00.000'", ConfigFile.RAMdb, 5);

            GlobalRef.MEMID = MEMID;
            By memberLookup = By.CssSelector("[test-id='searchDiag-link-member']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(memberLookup));
            tmsWait.Hard(5);


            By memberLookupMemID = By.CssSelector("[test-id='searchMember-txt-MemberID']");
            Browser.Wd.FindElement(memberLookupMemID).SendKeys(MEMID);

            By memberLookupSearchBtn = By.CssSelector("[test-id='searchMember-btn-search']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(memberLookupSearchBtn));
            tmsWait.Hard(5);

            By selectRecord = By.XPath("(//a[@title='Add'])[1]");
            fw.ExecuteJavascript(Browser.Wd.FindElement(selectRecord));
        }


        [When(@"Enter New Diagnosis Data page Execute Query and Active Member is populated for Dual Extract")]
        public void WhenEnterNewDiagnosisDataPageExecuteQueryAndActiveMemberIsPopulatedForDualExtract()
        {
            string MEMID = singleColumnQueryExecutionSelectRecordBasedOnIndex("SELECT txtMemberID  FROM RAM.dbo.tbMemberPlan where dteEnd='9999-12-31 00:00:00.000'", ConfigFile.RAMdb, 4);

            GlobalRef.MEMID = MEMID;
            By memberLookup = By.CssSelector("[test-id='searchDiag-link-member']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(memberLookup));
            tmsWait.Hard(5);


            By memberLookupMemID = By.CssSelector("[test-id='searchMember-txt-MemberID']");
            Browser.Wd.FindElement(memberLookupMemID).SendKeys(MEMID);

            By memberLookupSearchBtn = By.CssSelector("[test-id='searchMember-btn-search']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(memberLookupSearchBtn));
            tmsWait.Hard(5);

            By selectRecord = By.XPath("(//a[@title='Add'])[1]");
            fw.ExecuteJavascript(Browser.Wd.FindElement(selectRecord));
        }

        [When(@"Enter New Diagnosis Data page Active Member is populated using ""(.*)""")]
        public void WhenEnterNewDiagnosisDataPageActiveMemberIsPopulatedUsing(string p0)
        {
            string MEMID = tmsCommon.GenerateData(p0);

            GlobalRef.MEMID = MEMID;
            By memberLookup = By.CssSelector("[test-id='searchDiag-link-member']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(memberLookup));
            tmsWait.Hard(5);


            By memberLookupMemID = By.CssSelector("[test-id='searchMember-txt-MemberID']");
            Browser.Wd.FindElement(memberLookupMemID).SendKeys(MEMID);

            By memberLookupSearchBtn = By.CssSelector("[test-id='searchMember-btn-search']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(memberLookupSearchBtn));
            tmsWait.Hard(5);

            By selectRecord = By.XPath("(//button[@title='Add'])[1]");
            fw.ExecuteJavascript(Browser.Wd.FindElement(selectRecord));
        }


        [When(@"Enter New Diagnosis Data page Execute Query and Active Member is populated")]
        public void WhenEnterNewDiagnosisDataPageExecuteQueryAndActiveMemberIsPopulated()
        {
            string MEMID = singleColumnQueryExecutionSelectRecordBasedOnIndex("SELECT txtMemberID  FROM RAM.dbo.tbMemberPlan where dteEnd='9999-12-31 00:00:00.000'", ConfigFile.RAMdb, 2);

            GlobalRef.MEMID = MEMID;
            By memberLookup = By.CssSelector("[test-id='searchDiag-link-member']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(memberLookup));
            tmsWait.Hard(5);


            By memberLookupMemID = By.CssSelector("[test-id='searchMember-txt-MemberID']");
            Browser.Wd.FindElement(memberLookupMemID).SendKeys(MEMID);

            By memberLookupSearchBtn = By.CssSelector("[test-id='searchMember-btn-search']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(memberLookupSearchBtn));
            tmsWait.Hard(5);

            By selectRecord = By.XPath("(//button[@title='Add'])[1]");
            fw.ExecuteJavascript(Browser.Wd.FindElement(selectRecord));
        }

        [Then(@"Verify CMS File Extract Summary report Number of Records are matching with CMS Extract file")]
        public void ThenVerifyCMSFileExtractSummaryReportNumberOfRecordsAreMatchingWithCMSExtractFile()
        {
            DateTime date = DateTime.Now;
            string todayDate = string.Format("{0:MM/dd/yyyy}", date);   // format 02/03/2019
            //Always take latest record
            string TotalRecordsFromDB = singleColumnQueryExecutionSelectRecordBasedOnIndex("SELECT NumOfRecs FROM RAM.dbo.tbCMSFileInfo where CONVERT( varchar,FileSentDate,101 )='" + todayDate + "' ORDER BY CAST( TranDate AS datetime ) DESC;  ", ConfigFile.RAMdb, 0);
            string TotalRecordsFromExtractFile = GlobalRef.NUMRECORD.ToString();

            fw.ConsoleReport(" Total Extracted Records from File -->" + TotalRecordsFromExtractFile);
            fw.ConsoleReport(" Total Extracted Records from DB -->" + TotalRecordsFromDB);
            Assert.AreEqual(TotalRecordsFromDB, TotalRecordsFromExtractFile, " Both records are not matching");

        }
        [Then(@"Verify CMS File Extract Summary report Number of Records are matching with CMS Extract file for File Sent Date as  ""(.*)""")]
        public void ThenVerifyCMSFileExtractSummaryReportNumberOfRecordsAreMatchingWithCMSExtractFileForFileSentDateAs(string p0)
        {
            DateTime date = DateTime.Now;
            string todayDate = string.Format("{0:MM/dd/yyyy}", date);   // format 02/03/2019
            //Always take latest record
            string TotalRecordsFromDB = singleColumnQueryExecutionSelectRecordBasedOnIndex("SELECT NumOfRecs FROM RAM.dbo.tbCMSFileInfo where CONVERT( varchar,FileSentDate,101 )='" + todayDate + "' ORDER BY CAST( TranDate AS datetime ) DESC;  ", ConfigFile.RAMdb, 0);
            string TotalRecordsFromExtractFile = GlobalRef.NUMRECORD.ToString();

            fw.ConsoleReport(" Total Extracted Records from File -->" + TotalRecordsFromExtractFile);
            fw.ConsoleReport(" Total Extracted Records from DB -->" + TotalRecordsFromDB);
            Assert.AreEqual(TotalRecordsFromDB, TotalRecordsFromExtractFile, " Both records are not matching");
        }

        [Then(@"Verify CMS File Extract Summary report Displays Noted CMS File ID")]
        public void ThenVerifyCMSFileExtractSummaryReportDisplaysNotedCMSFileID()
        {
            string FileProcessingCMSFILEID = GlobalRef.CMSFILEID.ToString();


            fw.ConsoleReport(" CMS File ID " + FileProcessingCMSFILEID);
        }


        [When(@"Execute Query ""(.*)"" and Fetch PIR from DB and Row ""(.*)"" and Enter PIR Control Number under Manage Suspects page")]
        public void WhenExecuteQueryAndFetchPIRFromDBAndRowAndEnterPIRControlNumberUnderManageSuspectsPage(string query, int p1)
        {
            string controlNumber = singleColumnQueryExecutionSelectRecordBasedOnIndex(query, ConfigFile.RAMdb, p1);
            fw.ConsoleReport(" PIR Control Number --> " + controlNumber);
            By PIR = By.CssSelector("[test-id='manageSuspects-input-pitControlNumber']");
            IWebElement uploadElement = Browser.Wd.FindElement(PIR);
            uploadElement.SendKeys(controlNumber);
        }

        [When(@"Enter PIR Control Number under Manage Suspects page ""(.*)""")]
        public void WhenEnterPIRControlNumberUnderManageSuspectsPage(string p0)
        {
            string controlNumber = tmsCommon.GenerateData(p0);
            fw.ConsoleReport(" PIR Control Number --> " + controlNumber);
            By PIR = By.CssSelector("[test-id='manageSuspects-input-pitControlNumber']");
            IWebElement uploadElement = Browser.Wd.FindElement(PIR);
            uploadElement.SendKeys(controlNumber);
        }


        [When(@"Executed Query display Value ""(.*)"" as ""(.*)""")]
        public void WhenExecutedQueryDisplayValueAs(string p0, string p1)
        {
            string expectedResult = tmsCommon.GenerateData(p0);
            string actualResult = tmsCommon.GenerateData(p1);
            Assert.AreEqual(expectedResult, actualResult, " Both results are not matching");

            fw.ConsoleReport(" Query displayed Value " + actualResult);
        }


        [When(@"Execute Query ""(.*)"" for PIR ""(.*)"" Verify IsBlocked as ""(.*)"" PIRSTATUS as ""(.*)"" IsDeleted as ""(.*)""")]
        public void WhenExecuteQueryForPIRVerifyIsBlockedAsPIRSTATUSAsIsDeletedAs(string p0, string p1, string block, string status, string delete)
        {
            string query = p0 + tmsCommon.GenerateData(p1);
            string expectedValueforBlocked = block;
            string expectedValueforStatus = status;
            string expectedValueforDelete = delete;
            bool actualValueforBlocked = Convert.ToBoolean(singleColumnQueryExecutionSelectRecordBasedOnIndex(query, ConfigFile.RAMdb, 0));

            string actualValueforPIRStatus = singleColumnQueryExecutionSelectRecordBasedOnIndex(query, ConfigFile.RAMdb, 1);
            bool actualValueforDeleted = Convert.ToBoolean(singleColumnQueryExecutionSelectRecordBasedOnIndex(query, ConfigFile.RAMdb, 2));
            Assert.IsFalse(actualValueforBlocked, " Both values are not matching");
            Assert.AreEqual(expectedValueforStatus, actualValueforPIRStatus, " Both values are not matching");
            Assert.IsFalse(actualValueforDeleted, " Both values are not matching");
        }


        [When(@"Execute Query ""(.*)"" and Fetch PIR from DB and Enter PIR Control Number under Manage Suspects page")]
        public void WhenExecuteQueryAndFetchPIRFromDBAndEnterPIRControlNumberUnderManageSuspectsPage(string query)
        {
            string controlNumber = singleColumnQueryExecutionSelectRecordBasedOnIndex(query, ConfigFile.RAMdb, 4);
            fw.ConsoleReport(" PIR Control Number --> " + controlNumber);
            By PIR = By.CssSelector("[test-id='manageSuspects-input-pitControlNumber']");
            IWebElement uploadElement = Browser.Wd.FindElement(PIR);
            uploadElement.SendKeys(controlNumber);
        }


        [When(@"Execute Query and Fetch PIR from DB and Enter PIR Control Number as ""(.*)"" under Manage Suspects page")]
        public void WhenExecuteQueryAndFetchPIRFromDBAndEnterPIRControlNumberAsUnderManageSuspectsPage(string p0)
        {

            tmsWait.Hard(3);
            string controlNumber = tmsCommon.GenerateData(p0);
            By PIR = By.CssSelector("[test-id='manageSuspects-input-pitControlNumber']");
            IWebElement uploadElement = Browser.Wd.FindElement(PIR);
            uploadElement.SendKeys(controlNumber);
        }


        [When(@"Execute Query and Fetch PIR from DB and Enter PIR Control Number under Manage Suspects page")]
        public void WhenExecuteQueryAndFetchPIRFromDBAndEnterPIRControlNumberUnderManageSuspectsPage()
        {
            string controlNumber = singleColumnQueryExecutionSelectRecordBasedOnIndex("SELECT TOP 1 intControlnum FROM RAM.dbo.tbExceptionLetters WHERE tbDiagsID is not null and suspid =999", ConfigFile.RAMdb, 0);
            fw.ConsoleReport(" PIR Control Number --> " + controlNumber);
            tmsWait.Hard(3);
            By PIR = By.CssSelector("[test-id='manageSuspects-input-pitControlNumber']");
            IWebElement uploadElement = Browser.Wd.FindElement(PIR);
            uploadElement.SendKeys(controlNumber);
        }
        [When(@"Manage Suspects page ""(.*)"" is entered under Manage Suspects page")]
        public void WhenManageSuspectsPageIsEnteredUnderManageSuspectsPage(string p0)
        {
            string controlNumber = tmsCommon.GenerateData(p0);
            By PIR = By.CssSelector("[test-id='manageSuspects-input-pitControlNumber']");
            IWebElement uploadElement = Browser.Wd.FindElement(PIR);
            uploadElement.SendKeys(controlNumber);
        }

        [When(@"RAMX On-Hold and Diagnosis Review page ""(.*)"" is set to ""(.*)""")]
        public void WhenRAMXOn_HoldAndDiagnosisReviewPageIsSetTo(string p0, string p1)
        {
            string fieldName = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            IWebElement ele;
            SelectElement drpDown;
            tmsWait.Hard(2);
            switch (p0)
            {
                case "Member ID":
                    ele = Browser.Wd.FindElement(By.XPath("//*[@test-id='viewOnHolDiagnosis-txt-txtMemberId']"));
                    ele.SendKeys(value);
                    break;
                case "Provider ID":
                    ele = Browser.Wd.FindElement(By.XPath("//*[@test-id='viewOnHolDiagnosis-txt-providerId']"));
                    ele.SendKeys(value);
                    break;
                case "Status":
                    By Drp = By.XPath("//label[contains(.,'Status')]/parent::div//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + value + "']");
                    fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                    fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                    tmsWait.Hard(3);

                    break;
                case "On-Hold Reason":
                    By DrpOH = By.XPath("//label[contains(.,'On-Hold Reason')]/parent::div//span[@class='k-select']");
                    By typeappOH = By.XPath("//li[text()='" + value + "']");
                    fw.ExecuteJavascript(Browser.Wd.FindElement(DrpOH));
                    fw.ExecuteJavascript(Browser.Wd.FindElement(typeappOH));
                    tmsWait.Hard(3); 

                    break;
            }
        }


        [When(@"On-Hold and Diagnosis Review page Member ID is set to ""(.*)""")]
        public void WhenOn_HoldAndDiagnosisReviewPageMemberIDIsSetTo(string p0)
        {
           //First click on look up icon
            string mem = tmsCommon.GenerateData(p0);
            //By lookup = By.CssSelector("[test-id='viewOnHolDiagnosis-a-memberLookup']");
            By lookup = By.CssSelector("[test-id='viewOnHolDiagnosis-a-memberLookup']");
            IWebElement lookupElement = Browser.Wd.FindElement(lookup);
            fw.ExecuteJavascript(lookupElement);
            tmsWait.Hard(3);
            //enter memberid value in lookup window
            //By locatorMemID = By.CssSelector("[test-id='pcpLookup-txt-searchBy']");
            By locatorMemID = By.CssSelector("[test-id = 'searchMember-txt-MemberID']");
            IWebElement elementMEM = Browser.Wd.FindElement(locatorMemID);
            elementMEM.SendKeys(mem);
            tmsWait.Hard(3);
            //Click on search button 
            //By searchBtn = By.CssSelector("[test-id='lookup-btn-Search']");
            By searchBtn = By.CssSelector("[test-id='searchMember-btn-search']");
            IWebElement searchBtnEle = Browser.Wd.FindElement(searchBtn);
            fw.ExecuteJavascript(searchBtnEle);
            tmsWait.Hard(3);
            //Select the memberid from grid 
            //By rowLoc = By.XPath("//div[@test-id='lookup-grid-searchresult']//table[@data-role='selectable']//td[contains(.,'" + mem + "')]");
            By rowLoc = By.XPath("//kendo-grid[@test-id='searchMember-grid-memberLookup']//td[contains(.,'" + mem + "')]//following-sibling::td//button[@title='Add']");
            IWebElement rowEle = Browser.Wd.FindElement(rowLoc);
            fw.ExecuteJavascript(rowEle);
            tmsWait.Hard(3);
            //Now no need to clicking back to record ,once clicked on add button pop up will auto close hence commenting below code 
            //By backToRecordLoc = By.CssSelector("[test-id='pcpLookup-txt-backToRecord']");
            //IWebElement backtorecordBtn = Browser.Wd.FindElement(backToRecordLoc);
            //fw.ExecuteJavascript(backtorecordBtn);
            //tmsWait.Hard(3);
        }


        [When(@"On-Hold and Diagnosis Review page Search Button is Clicked")]
        public void WhenOn_HoldAndDiagnosisReviewPageSearchButtonIsClicked()
        {
            By locator = By.CssSelector("[test-id='viewOnHolDiagnosis-button-search']");
            IWebElement element = Browser.Wd.FindElement(locator);
            fw.ExecuteJavascript(element);
            tmsWait.Hard(10);
        }

        [When(@"On-Hold and Diagnosis Review page Pending for Coder Correction link is Clicked")]
        public void WhenOn_HoldAndDiagnosisReviewPagePendingForCoderCorrectionLinkIsClicked()
        {
            By locator = By.XPath("//span[contains(.,' Pending for Coder Correction: ')]");
            IWebElement element = Browser.Wd.FindElement(locator);
            fw.ExecuteJavascript(element);
            tmsWait.Hard(10);
        }

        [When(@"verify On-hold member with ""(.*)"", ""(.*)"" gets displayed in the grid")]
        public void WhenVerifyOn_HoldMemberWithGetsDisplayedInTheGrid(string p0, string p1)
        {
            string memID = tmsCommon.GenerateData(p0);
            string onholdReason = tmsCommon.GenerateData(p1);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='viewOnHoldDiagnosis-grid-resultsGrid']//td[contains(.,'" + memID + "')]/following-sibling::td[contains(.,'" + onholdReason + "')]"));
            Assert.IsTrue(ele.Displayed, "Member Id with selected On Hold Reason was not found");
        }


        [When(@"On Hold and Diagnosis Review page Diagnosis Code ""(.*)"" Provider ID ""(.*)"" Member ID ""(.*)"" Control Number ""(.*)"" PIR Status ""(.*)"" is Checkbox is Clicked")]
        public void WhenOnHoldAndDiagnosisReviewPageDiagnosisCodeProviderIDMemberIDControlNumberPIRStatusIsCheckboxIsClicked(string p0, string p1, string p2, string p3, string p4)
        {
            string code = tmsCommon.GenerateData(p0);
            string pro = tmsCommon.GenerateData(p1);
            string mem = tmsCommon.GenerateData(p2);
            string control = tmsCommon.GenerateData(p3);
            string status = tmsCommon.GenerateData(p4);

            By locator = By.XPath("//kendo-grid[@test-id='viewOnHoldDiagnosis-grid-resultsGrid']//td[contains(.,'" + code + "')]/following-sibling::td[contains(.,'" + pro + "')]/following-sibling::td[contains(.,'" + control + "')]/following-sibling::td[contains(.,'" + mem + "')]//following-sibling::td[contains(.,'')]/preceding-sibling::td/input");
            IWebElement element = Browser.Wd.FindElement(locator);
            fw.ExecuteJavascript(element);

        }
        [When(@"On Hold and Diagnosis Review page Diagnosis Code ""(.*)"" Provider ID ""(.*)"" Member ID ""(.*)"" Control Number ""(.*)"" PIR Status ""(.*)"" is Checkbox is Clicked(.*)")]
        public void WhenOnHoldAndDiagnosisReviewPageDiagnosisCodeProviderIDMemberIDControlNumberPIRStatusIsCheckboxIsClicked(string p0, string p1, string p2, string p3, string p4, int p5)
        {
            string code = tmsCommon.GenerateData(p0);
            string pro = tmsCommon.GenerateData(p1);
            string mem = tmsCommon.GenerateData(p2);
            string control = tmsCommon.GenerateData(p3);
            string status = tmsCommon.GenerateData(p4);

           
            By locator = By.XPath("//kendo-grid[@test-id='viewOnHoldDiagnosis-grid-resultsGrid']//td[contains(.,'" + control + "')]/preceding-sibling::td[contains(.,'" + pro + "')]/following-sibling::td[contains(.,'" + mem + "')]/preceding-sibling::td[contains(.,'" + code + "')]/preceding-sibling::td/input");

            AngularFunction.clickOnElement(locator);

        }


        [Then(@"On-Hold and Diagnosis Review page Release From OnHold button is Clicked")]
        public void ThenOn_HoldAndDiagnosisReviewPageReleaseFromOnHoldButtonIsClicked()
        {
            By btn = By.CssSelector("[test-id='viewOnHoldDiagnosis-btn-releaseFromOnHold']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(btn);
            tmsWait.Hard(2);
            By conf = By.CssSelector("[test-id='confirmationDialog-btn-Yes']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(conf);

        }


        [Then(@"On-Hold and Diagnosis Review page Auditor Review button is Clicked")]
        public void ThenOn_HoldAndDiagnosisReviewPageAuditorReviewButtonIsClicked()
        {
            By btn = By.CssSelector("[test-id='viewOnHoldDiagnosis-btn-auditorReview']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(btn);
            tmsWait.Hard(2);
            By conf = By.CssSelector("[test-id='confirmationDialog-btn-Yes']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(conf);
        }


        [When(@"On Hold and Diagnosis Review page Diagnosis Code ""(.*)"" Provider ID ""(.*)"" Member ID ""(.*)"" Control Number ""(.*)"" PIR Status ""(.*)"" is not present")]
        public void WhenOnHoldAndDiagnosisReviewPageDiagnosisCodeProviderIDMemberIDControlNumberPIRStatusIsNotPresent(string p0, string p1, string p2, string p3, string p4)
        {
            tmsWait.Hard(5);
            string code = tmsCommon.GenerateData(p0);
            string pro = tmsCommon.GenerateData(p1);
            string mem = tmsCommon.GenerateData(p2);
            string control = tmsCommon.GenerateData(p3);
            string status = tmsCommon.GenerateData(p4);


            //By locator = By.XPath("//div[@test-id='viewOnHoldDiagnosis-grid-resultsGrid']//td[contains(.,'"+ code + "')]/following-sibling::td[contains(.,'"+ pro + "')]/following-sibling::td[contains(.,'"+ mem + "')]/following-sibling::td[contains(.,'"+ control + "')]//following-sibling::td[contains(.,'"+status+"')]/following-sibling::td/a");
          //  By locator = By.XPath("//div[@test-id='viewOnHoldDiagnosis-grid-resultsGrid']//td[contains(.,'" + control + "')]/preceding-sibling::td[contains(.,'" + pro + "')]/following-sibling::td[contains(.,'" + mem + "')]/following-sibling::td[contains(.,'" + control + "')]//following-sibling::td[contains(.,'" + status + "')]/following-sibling::td/a");

            By locator = By.XPath("//kendo-grid[@test-id='viewOnHoldDiagnosis-grid-resultsGrid']//td[contains(.,'" + control + "')]/preceding-sibling::td[contains(.,'" + pro + "')]/following-sibling::td[contains(.,'" + mem + "')]/preceding-sibling::td[contains(.,'" + code + "')]/preceding-sibling::td/input");
            UIMODUtilFunctions.elementNotPresenceUsingLocators(locator);
        }


        [When(@"On Hold and Diagnosis Review page Diagnosis Code ""(.*)"" Provider ID ""(.*)"" Member ID ""(.*)"" Control Number ""(.*)"" PIR Status ""(.*)"" is Clicked")]
        public void WhenOnHoldAndDiagnosisReviewPageDiagnosisCodeProviderIDMemberIDControlNumberPIRStatusIsClicked(string p0, string p1, string p2, string p3, string p4)
        {
            string code = tmsCommon.GenerateData(p0);
            string pro = tmsCommon.GenerateData(p1);
            string mem = tmsCommon.GenerateData(p2);
            string control = tmsCommon.GenerateData(p3);
            string status = tmsCommon.GenerateData(p4);           

            //click on edit button   
            By locator = By.XPath("//kendo-grid[@test-id='viewOnHoldDiagnosis-grid-resultsGrid']//td[contains(.,'" + control + "')]/preceding-sibling::td[contains(.,'" + pro + "')]/following-sibling::td[contains(.,'" + mem + "')]/following-sibling::td[contains(.,'" + control + "')]//following-sibling::td[contains(.,'" + status + "')]/following-sibling::td/a/span");

            AngularFunction.clickOnElement(locator);
        }

        [Then(@"Verify Page displays as ""(.*)"" with PIR Number ""(.*)""")]
        public void ThenVerifyPageDisplaysAsWithPIRNumber(string msg, string p1)
        {
            tmsWait.Hard(5);
            string expectedPageTitle = msg + " " + tmsCommon.GenerateData(p1);
            //string actualPageTitle = Browser.Wd.FindElement(By.CssSelector("[test-id='pirResponse-span-heading']")).Text;
            string actualPageTitle = Browser.Wd.FindElement(By.CssSelector("[test-id ='manageConfiguration-span-heading']")).Text;
      
            Assert.AreEqual(expectedPageTitle, actualPageTitle, " Both Titles are not matching");
        }

        [Then(@"Verify Page displays as ""(.*)"" with Code Number ""(.*)""")]
        public void ThenVerifyPageDisplaysAsWithCodeNumber(string msg, string p1)
        {
            tmsWait.Hard(5);
            string expectedPageTitle = "" + msg + " " + tmsCommon.GenerateData(p1) + "";
            string actualPageTitle = Browser.Wd.FindElement(By.CssSelector("[test-id='manageConfiguration-span-heading']")).Text;
            Assert.AreEqual(expectedPageTitle, actualPageTitle, " Both Titles are not matching");
        }

        [When(@"Edit Diagnosis Code Details page ""(.*)"" field is set to ""(.*)""")]
        public void WhenEditDiagnosisCodeDetailsPageFieldIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            By loc;
            By Drp;
            By typeapp;
            IWebElement element;
            bool expectedElementDisplay;

            switch (field)
            {
                case "Diagnosis Code":
                    loc = By.CssSelector("[test-id='editOnHoldDiagnosis-txt-txtDiagCode']");
                    element = Browser.Wd.FindElement(loc);
                    element.Clear();
                    //element.SendKeys(Keys.Delete);
                    element.SendKeys(value);
                    element.SendKeys(Keys.Backspace);
                    break;

                case "Provider ID":
                    loc = By.CssSelector("[test-id='editOnHoldDiagnosis-txt-txtProviderId']");
                    element = Browser.Wd.FindElement(loc);
                    element.Clear();
                    element.SendKeys(value);
                    break;

                case "Type of Service":
                    Drp = By.XPath("//kendo-dropdownlist[@test-id='editOnHoldDiagnosis-txt-ddlTypeofservice']//span[@class='k-select']");
                    typeapp = By.XPath("//li[text()='" + value + "']");

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                    break;

                case "On-Hold Reason":
                    Drp = By.XPath("//kendo-dropdownlist[@test-id='editOnHoldDiagnosis-txt-ddlonHoldReason']//span[@class='k-select']");
                    typeapp = By.XPath("//li[text()='" + value + "']");

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                    tmsWait.Hard(2);
                    break;

                case "Status":
                    tmsWait.Hard(3);
                    //Drp = By.XPath("//kendo-dropdownlist[@test-id='editOnHoldDiagnosis-txt-ddlStatus']//span[@class='k-select']");
                    //typeapp = By.XPath("//li[text()='" + value + "']");
                    //tmsWait.Hard(3);
                    //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    //tmsWait.Hard(3);
                    //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                    By statusDrp = By.XPath("//kendo-dropdownlist[@test-id='editOnHoldDiagnosis-txt-ddlStatus']//span[@class='k-select']");
                    //By statustypeapp = By.XPath("//li[contains(.,'" + value + "')]");
                    By statustypeapp = By.XPath("//li[text()='" + value + "']");
                    fw.ExecuteJavascript(Browser.Wd.FindElement(statusDrp));
                  
                    fw.ExecuteJavascript(Browser.Wd.FindElement(statustypeapp));
                    tmsWait.Hard(3);
                    break;

                case "Claim Number":
                    loc = By.CssSelector("[test-id='editOnHoldDiagnosis-txt-txtPlanClaimId']");
                    element = Browser.Wd.FindElement(loc);
                    element.Clear();
                    element.SendKeys(value);
                    break;

                case "Coder ID":
                    Drp = By.XPath("//kendo-dropdownlist[@test-id='editOnHoldDiagnosis-txt-ddlCoderId']//span[@class='k-select']");
                    typeapp = By.XPath("//li[text()='" + value + "']");

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                    tmsWait.Hard(3);
                    break;

                case "Auditor Note":
                    loc = By.CssSelector("[test-id='editOnHoldDiagnosis-txt-txtAuditorNote']");
                    element = Browser.Wd.FindElement(loc);
                    element.Clear();
                    element.SendKeys(value);
                    break;
            }
        }

        [Then(@"Verify Edit Diagnosis Code Details page ""(.*)"" field is set to ""(.*)""")]
        public void ThenVerifyEditDiagnosisCodeDetailsPageFieldIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            By loc;
            IWebElement element;
            bool expectedElementDisplay;
            switch (field)
            {
                case "Diagnosis Code":
                    //loc = By.CssSelector("[test-id='editOnHoldDiagnosis-txt-txtDiagCode']");
                    loc = By.CssSelector("[id='txtDiagCode']");
                    element = Browser.Wd.FindElement(loc);
                    expectedElementDisplay = element.Displayed;
                    Assert.IsTrue(expectedElementDisplay, value + " is not displayed");
                    break;

                case "Provider ID":
                    //loc = By.CssSelector("[test-id='editOnHoldDiagnosis-txt-txtProviderId']");
                    loc = By.CssSelector("[id='txtProviderId']");
                    element = Browser.Wd.FindElement(loc);
                    expectedElementDisplay = element.Displayed;
                    Assert.IsTrue(expectedElementDisplay, value + " is not displayed");
                    break;

                case "Member ID":
                    //loc = By.CssSelector("[test-id='editOnHoldDiagnosis-txt-txtMemberId']");
                    loc = By.CssSelector("[id='txtMemberId']");
                    element = Browser.Wd.FindElement(loc);
                    expectedElementDisplay = element.Displayed;
                    Assert.IsTrue(expectedElementDisplay, value + " is not displayed");
                    break;

                case "Control Number":
                    //loc = By.CssSelector("[test-id='editOnHoldDiagnosis-txt-txtControlNumber']");
                    loc = By.CssSelector("[id='txtControlNumber']");
                    element = Browser.Wd.FindElement(loc);
                    expectedElementDisplay = element.Displayed;
                    Assert.IsTrue(expectedElementDisplay, value + " is not displayed");
                    break;
            }

        }

        [Then(@"Verify Edit Diagnosis Code Details page ""(.*)"" error message is ""(.*)""")]
        public void ThenVerifyEditDiagnosisCodeDetailsPageErrorMessageIs(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            By loc;
            IWebElement element;
            bool expectedElementDisplay;
            switch (field)
            {
                case "Diagnosis Code":
                    loc = By.CssSelector("[id='txtDiagCode-error-msg']");
                    element = Browser.Wd.FindElement(loc);
                    expectedElementDisplay = element.Displayed;
                    Assert.IsTrue(expectedElementDisplay, value + " is not displayed");
                    break;

                case "Provider ID":
                    loc = By.CssSelector("[id='txtProviderId-error-msg']");
                    element = Browser.Wd.FindElement(loc);
                    expectedElementDisplay = element.Displayed;
                    Assert.IsTrue(expectedElementDisplay, value + " is not displayed");
                    break;

                case "Type of Service":
                    loc = By.CssSelector("[id='ddlTypeofservice-error-msg']");
                    element = Browser.Wd.FindElement(loc);
                    expectedElementDisplay = element.Displayed;
                    Assert.IsTrue(expectedElementDisplay, value + " is not displayed");
                    break;

                case "On-Hold Reason":
                    loc = By.CssSelector("[id='ddlonHoldReason-error-msg']");
                    element = Browser.Wd.FindElement(loc);
                    expectedElementDisplay = element.Displayed;
                    Assert.IsTrue(expectedElementDisplay, value + " is not displayed");
                    break;
            }

        }

        [Then(@"Edit Diagnosis Code page Back To Record button is Clicked")]
        public void ThenEditDiagnosisCodePageBackToRecordButtonIsClicked()
        {
            By backtoRecord = By.CssSelector("[test-id='manageConfiguration-span-back']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(backtoRecord));
            tmsWait.Hard(4);
        }

        [Then(@"Edit Diagnosis Code page ""(.*)"" button is Clicked")]
        [When(@"Edit Diagnosis Code page ""(.*)"" button is Clicked")]
        public void WhenEditDiagnosisCodePageButtonCodeIsClicked(string p0)
        {
            string button = p0.ToUpper();
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//button[contains(.,'" + button + "')])[1]")));
            tmsWait.Hard(3);
        }

        [Then(@"Verify Edit Diagnosis Code Details page ""(.*)"" field is disabled")]
        public void ThenVerifyEditDiagnosisCodeDetailsPageFieldIsDisabled(string p0)
        {
            string field = tmsCommon.GenerateData(p0);
            By loc;
            IWebElement element;
            bool expectedElementDisabled;

            switch (field)
            {
                case "Diagnosis Code":
                    loc = By.CssSelector("[test-id='editOnHoldDiagnosis-txt-txtDiagCode']");
                    element = Browser.Wd.FindElement(loc);
                    expectedElementDisabled = element.Enabled;
                    Assert.IsFalse(expectedElementDisabled, field + " is editable");
                    break;

                case "Provider ID":
                    loc = By.CssSelector("[test-id='editOnHoldDiagnosis-txt-txtProviderId']");
                    element = Browser.Wd.FindElement(loc);
                    expectedElementDisabled = element.Enabled;
                    Assert.IsFalse(expectedElementDisabled, field + " is editable");
                    break;

                case "Member ID":
                    loc = By.CssSelector("[test-id='editOnHoldDiagnosis-txt-txtMemberId']");
                    element = Browser.Wd.FindElement(loc);
                    expectedElementDisabled = element.Enabled;
                    Assert.IsFalse(expectedElementDisabled, field + " is editable");
                    break;

                case "Control Number":
                    loc = By.CssSelector("[test-id='editOnHoldDiagnosis-txt-txtControlNumber']");
                    element = Browser.Wd.FindElement(loc);
                    expectedElementDisabled = element.Enabled;
                    Assert.IsFalse(expectedElementDisabled, field + " is editable");
                    break;

                case "Chart ID":
                    loc = By.CssSelector("[test-id='editOnHoldDiagnosis-txt-txtClartId']");
                    element = Browser.Wd.FindElement(loc);
                    expectedElementDisabled = element.Enabled;
                    Assert.IsFalse(expectedElementDisabled, field + " is editable");
                    break;

                case "PIR Status":
                    loc = By.CssSelector("[test-id='editOnHoldDiagnosis-txt-txtPIRStatus']");
                    element = Browser.Wd.FindElement(loc);
                    expectedElementDisabled = element.Enabled;
                    Assert.IsFalse(expectedElementDisabled, field + " is editable");
                    break;
            }
        }


        [Then(@"Verify On-Hold and Diagnosis Review page displayed toaster message ""(.*)""")]
        public void ThenVerifyOn_HoldAndDiagnosisReviewPageDisplayedToasterMessage(string p0)
        {
            ReUsableFunctions.toasterMessageDisplay(p0);
        }

        [Then(@"Verify View and Undo PIR Responses page displayed toaster message ""(.*)""")]
        public void ThenVerifyViewAndUndoPIRResponsesPageDisplayedToasterMessage(string p0)
        {
            ReUsableFunctions.toasterMessageDisplay(p0);
        }


        [When(@"Imports page Client Identified Suspects section File Type ""(.*)"" is Clicked")]
        public void WhenImportsPageClientIdentifiedSuspectsSectionFileTypeIsClicked(string p0)
        {
            By type = By.CssSelector("[test-id='import-input-" + p0 + "']");
            IWebElement typeOpt = Browser.Wd.FindElement(type);
            fw.ExecuteJavascript(typeOpt);
        }

        [When(@"Imports page Client Identified Suspects section Suspect File ""(.*)"" is uploaded")]
        public void WhenImportsPageClientIdentifiedSuspectsSectionSuspectFileIsUploaded(string p0)
        {
            tmsWait.Hard(4);
            string fileName = tmsCommon.GenerateData(p0);
            string path = "C:\\temp\\" + fileName;

            By upload = By.CssSelector("[test-id='import-input-fileUpload'] input");
            IWebElement uploadElement = Browser.Wd.FindElement(upload);
            uploadElement.SendKeys(path);

            By uploadBtn = By.XPath(".//button[contains(text(), 'Upload')]");
            IWebElement uploadButton = Browser.Wd.FindElement(uploadBtn);
            fw.ExecuteJavascript(uploadButton);
            tmsWait.Hard(3);
        }

        [When(@"Imports page PIR Response file ""(.*)"" is Imported")]
        public void WhenImportsPagePIRResponseFileIsImported(string p0)
        {
            tmsWait.Hard(4);
            string fileName = tmsCommon.GenerateData(p0);
            string path = @"C:\temp\" + fileName;

            By upload = By.CssSelector("[test-id='import-input-fileUpload'] input");
            IWebElement uploadElement = Browser.Wd.FindElement(upload);
            uploadElement.SendKeys(path);

            By uploadBtn = By.XPath("//button[contains(.,'Upload')]");
            IWebElement uploadButton = Browser.Wd.FindElement(uploadBtn);
            fw.ExecuteJavascript(uploadButton);
            tmsWait.Hard(3);
        }

        [When(@"View and Undo PIR Responses Select Type is set to ""(.*)""")]
        public void WhenViewAndUndoPIRResponsesSelectTypeIsSetTo(string p0)
        {
            //By loc = By.CssSelector("[test-id='viewUndoPir-select-searchType']");
            //new SelectElement(Browser.Wd.FindElement(loc)).SelectByText(p0);
            tmsWait.Hard(1);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='viewUndoPir-select-searchType']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + p0 + "']");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

        }

        [When(@"View and Undo PIR Responses Control Number TextBox is set to ""(.*)""")]
        public void WhenViewAndUndoPIRResponsesControlNumberTextBoxIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            By loc = By.CssSelector("[test-id='viewUndoPir-input-controlNumber']");
            Browser.Wd.FindElement(loc).SendKeys(value);

        }
        [When(@"View and Undo PIR Responses Search Button is Clicked")]
        public void WhenViewAndUndoPIRResponsesSearchButtonIsClicked()
        {
            By loc = By.CssSelector("[test-id='viewUndoPir-button-search']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(loc));

        }
        [Then(@"Verify View and Undo PIR Responses page displayed ""(.*)"" as ""(.*)""")]
        public void ThenVerifyViewAndUndoPIRResponsesPageDisplayedAs(string p0, string p1)
        {
            tmsWait.Hard(2);
            string value = tmsCommon.GenerateData(p1);
            By loc = By.XPath("//kendo-grid[@test-id='viewUndoPirResponse-grid-suspectsGridSearchResult']//td[contains(.,'" + value + "')]");
            bool resultsDisplay = Browser.Wd.FindElement(loc).Displayed;

            Assert.IsTrue(resultsDisplay, " Expected results are not displayed");
        }

        [Then(@"Refresh RAM File Processing Page")]
        public void ThenRefreshRAMFileProcessingPage()
        {
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(20);
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(20);
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(20);
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(20);
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(20);

        }

        [When(@"RAM Imports page Client Identified Suspects section Import button is Clicked")]
        public void WhenRAMImportsPageClientIdentifiedSuspectsSectionImportButtonIsClicked()
        {
            try
            {
                By import = By.CssSelector("[test-id='import-btn-import']");
                IWebElement importBtn = Browser.Wd.FindElement(import);
                fw.ExecuteJavascript(importBtn);
            }
            catch
            {

            }
            tmsWait.Hard(30);
            By fileProcess = By.LinkText("Job Processing Status page");
            fw.ExecuteJavascript(Browser.Wd.FindElement(fileProcess));
            tmsWait.Hard(30); // Fileprocessing is taking much time so we put more wait. Dont reduce it.
        }



        [When(@"Imports page PIR Response section Import button is Clicked")]
        [When(@"Imports page Client Identified Suspects section Import button is Clicked")]
        public void WhenImportsPageClientIdentifiedSuspectsSectionImportButtonIsClicked()
        {
            //By import = By.CssSelector("[test-id='import-btn-import']");
            //IWebElement importBtn = Browser.Wd.FindElement(import);
            //fw.ExecuteJavascript(importBtn);
            By fileProcess = By.CssSelector("[title='Job Processing Status']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(fileProcess));
            tmsWait.Hard(30); // Fileprocessing is taking much time so we put more wait. Dont reduce it.

        }
        bool recordFound = false;
        [Then(@"Verify Suspect Fallout file on TMS Shared Folder displayed Error Message as ""(.*)"" and record count displayed as ""(.*)""")]
        public void ThenVerifySuspectFalloutFileOnTMSSharedFolderDisplayedErrorMessageAsAndRecordCountDisplayedAs(string p0, string p1)
        {

            string errormsg = p0;
            string exprecordcount = p1;


            string RAMFolder = ReUsableFunctions.returnTMSSharedInputFolder(ConfigFile.RAMdb);
            string resultsFolder = RAMFolder + "\\Suspects\\Fallout\\";

            var newFilePaths = Directory.GetFiles(@"" + resultsFolder + "", "*.txt");

            // Adding File Info details like Creation Time etc to sort by latest
            List<FileInfo> lst = new List<FileInfo>();
            foreach (var item in newFilePaths)
            {
                var srcFile = Path.Combine(resultsFolder, item);
                lst.Add(new FileInfo(srcFile));
            }

            var latestFileName = lst.OrderByDescending(x => x.CreationTime).FirstOrDefault().FullName;

            string actualrecordCount = (File.ReadLines(latestFileName).Count() - 1).ToString();
            Assert.AreEqual(exprecordcount, actualrecordCount, "Both counts are not matching");

            fw.ConsoleReport(" Total record found " + actualrecordCount);

            int count = 0;
            var reader = new StreamReader(File.OpenRead(@"" + latestFileName + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
                var values = line.Split('|');

                if (count > 1)
                {
                    if (values.Contains(errormsg))
                    {
                        recordFound = true;
                        fw.ConsoleReport(" Expected record found in File " + errormsg);

                        break;
                    }


                }
            }


            Assert.IsTrue(recordFound);
        }


        [Then(@"Verify Suspect Results file on TMS Shared Folder displayed Total Records Read as ""(.*)"" Ignored Rows Length Too Long or Short as ""(.*)"" Insert Errors as ""(.*)"" Empty Rows as ""(.*)"" Successfully Imported Rows as  ""(.*)""")]
        public void ThenVerifySuspectResultsFileOnTMSSharedFolderDisplayedTotalRecordsReadAsIgnoredRowsLengthTooLongOrShortAsInsertErrorsAsEmptyRowsAsSuccessfullyImportedRowsAs(string p0, string p1, string p2, string p3, string p4)
        {

            string RAMFolder = ReUsableFunctions.returnTMSSharedInputFolder(ConfigFile.RAMdb);
            string resultsFolder = RAMFolder + "\\Suspects\\Results\\";

            var newFilePaths = Directory.GetFiles(@"" + resultsFolder + "", "*.txt");

            // Adding File Info details like Creation Time etc to sort by latest
            List<FileInfo> lst = new List<FileInfo>();
            foreach (var item in newFilePaths)
            {
                var srcFile = Path.Combine(resultsFolder, item);
                lst.Add(new FileInfo(srcFile));
            }

            var latestFileName = lst.OrderByDescending(x => x.CreationTime).FirstOrDefault().FullName;

            int count = 0;
            var reader = new StreamReader(File.OpenRead(@"" + latestFileName + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
                var values = line.Split(',');
                if (count > 1)
                {
                    if (count == 2)
                    {
                        Assert.IsTrue(values[1].Contains(p0), "Expected Element is not getting Displayed.");
                        fw.ConsoleReport(" Total Records Read " + values[1]);
                    }
                    if (count == 3)
                    {
                        Assert.IsTrue(values[1].Contains(p1), "Expected Element is not getting Displayed.");
                        fw.ConsoleReport(" Ignored Rows - Length Too Long or Short " + values[1]);
                    }
                    if (count == 4)
                    {
                        Assert.IsTrue(values[1].Contains(p2), "Expected Element is not getting Displayed.");
                        fw.ConsoleReport("Insert Errors " + values[1]);
                    }

                    if (count == 5)
                    {
                        Assert.IsTrue(values[1].Contains(p3), "Expected Element is not getting Displayed.");
                        fw.ConsoleReport(" Empty Rows " + values[1]);
                    }

                    if (count == 6)
                    {
                        Assert.IsTrue(values[1].Contains(p4), "Expected Element is not getting Displayed.");
                        fw.ConsoleReport(" Successfully Imported Rows " + values[1]);
                    }


                }
            }


        }


        [Then(@"Verify PIR Response Fallout file on TMS Shared Folder displayed Error Message as ""(.*)"" and record count displayed as ""(.*)""")]
        public void ThenVerifyPIRResponseFalloutFileOnTMSSharedFolderDisplayedErrorMessageAsAndRecordCountDisplayedAs(string p0, string p1)
        {

            string errormsg = p0;
            string exprecordcount = p1;


            string RAMFolder = ReUsableFunctions.returnTMSSharedInputFolder(ConfigFile.RAMdb);
            string resultsFolder = RAMFolder + "\\PIRResponse\\Fallout\\";

            var newFilePaths = Directory.GetFiles(@"" + resultsFolder + "", "*.txt");

            // Adding File Info details like Creation Time etc to sort by latest
            List<FileInfo> lst = new List<FileInfo>();
            foreach (var item in newFilePaths)
            {
                var srcFile = Path.Combine(resultsFolder, item);
                lst.Add(new FileInfo(srcFile));
            }

            var latestFileName = lst.OrderByDescending(x => x.CreationTime).FirstOrDefault().FullName;

            string actualrecordCount = (File.ReadLines(latestFileName).Count() - 1).ToString();
            Assert.AreEqual(exprecordcount, actualrecordCount, "Both counts are not matching");

            fw.ConsoleReport(" Total record found " + actualrecordCount);

            int count = 0;
            var reader = new StreamReader(File.OpenRead(@"" + latestFileName + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
                var values = line.Split('|');

                if (count > 1)
                {
                    if (values.Contains(errormsg))
                    {
                        recordFound = true;
                        fw.ConsoleReport(" Expected record found in File " + errormsg);

                        break;
                    }
                }
            }

            Assert.IsTrue(recordFound);
        }


        [Then(@"Verify PIR Response Results file on TMS Shared Folder displayed Total Records Read as ""(.*)"" Ignored Rows Length Too Long or Short as ""(.*)"" Insert Errors as ""(.*)"" Invalid Field Data Errors as ""(.*)"" Successfully Imported Rows as ""(.*)""")]
        public void ThenVerifyPIRResponseResultsFileOnTMSSharedFolderDisplayedTotalRecordsReadAsIgnoredRowsLengthTooLongOrShortAsInsertErrorsAsInvalidFieldDataErrorsAsSuccessfullyImportedRowsAs(string p0, string p1, string p2, string p3, string p4)
        {

            string RAMFolder = ReUsableFunctions.returnTMSSharedInputFolder(ConfigFile.RAMdb);
            string resultsFolder = RAMFolder + "\\PIRResponse\\Results\\";

            var newFilePaths = Directory.GetFiles(@"" + resultsFolder + "", "*.txt");

            // Adding File Info details like Creation Time etc to sort by latest
            List<FileInfo> lst = new List<FileInfo>();
            foreach (var item in newFilePaths)
            {
                var srcFile = Path.Combine(resultsFolder, item);
                lst.Add(new FileInfo(srcFile));
            }

            var latestFileName = lst.OrderByDescending(x => x.CreationTime).FirstOrDefault().FullName;

            int count = 0;
            var reader = new StreamReader(File.OpenRead(@"" + latestFileName + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
                var values = line.Split(',');
                if (count > 1)
                {
                    if (count == 2)
                    {
                        Assert.IsTrue(values[1].Contains(p0), "Expected Element is not getting Displayed.");
                        fw.ConsoleReport(" Total Records Read " + values[1]);
                    }
                    if (count == 3)
                    {
                        Assert.IsTrue(values[1].Contains(p1), "Expected Element is not getting Displayed.");
                        fw.ConsoleReport(" Ignored Rows - Length Too Long or Short " + values[1]);
                    }
                    if (count == 4)
                    {
                        Assert.IsTrue(values[1].Contains(p2), "Expected Element is not getting Displayed.");
                        fw.ConsoleReport(" Insert Errors " + values[1]);
                    }

                    if (count == 5)
                    {
                        Assert.IsTrue(values[1].Contains(p3), "Expected Element is not getting Displayed.");
                        fw.ConsoleReport(" Invalid Field Data Errors " + values[1]);
                    }

                    if (count == 6)
                    {
                        Assert.IsTrue(values[1].Contains(p4), "Expected Element is not getting Displayed.");
                        fw.ConsoleReport(" Successfully Imported Rows " + values[1]);
                    }
                }
            }
        }


        [Then(@"verify the message on Flag for Auditor page ""(.*)"" displayed on the page")]
        public void ThenVerifyTheMessageOnFlagForAuditorPageDisplayedOnThePage(string p0)
        {
            tmsWait.Hard(4);
            string expMessageText = tmsCommon.GenerateData(p0);
            string actualMessageText = Browser.Wd.FindElement(By.XPath("//div[@class='ng-isolate-scope alert alert-info']/div")).Text;
            Assert.AreEqual(expMessageText, actualMessageText, "Correct Message is not displayed");
        }


        [When(@"Administration- Flag for Edit page Import button is Clicked")]
        public void WhenAdministration_FlagForEditPageImportButtonIsClicked()
        {
            By import = By.CssSelector("[test-id='flagForAuditReview-btnUploadFiles']");
            IWebElement importBtn = Browser.Wd.FindElement(import);
            fw.ExecuteJavascript(importBtn);
            By fileProcess = By.LinkText("File Processing Status page");
            fw.ExecuteJavascript(Browser.Wd.FindElement(fileProcess));
            tmsWait.Hard(30);
        }

        [Then(@"verify for ""(.*)"" File Processing status is set to ""(.*)""")]
        public void ThenVerifyForFileProcessingStatusIsSetTo(string p0, string p1)
        {
            
        }

        [When(@"RAMX Imports page Import List section ""(.*)"" is Clicked")]
        public void WhenRAMXImportsPageImportListSectionIsClicked(string p0)
        {
            if (p0.Equals("Client Identified Suspects"))
            {
                By clientSus = By.XPath("(//label[contains(.,'Client Identified Suspects')])[1]");
                IWebElement uploadElement = Browser.Wd.FindElement(clientSus);
                tmsWait.Hard(5);
                fw.ExecuteJavascript(uploadElement);
                tmsWait.Hard(3);
                try
                {
                    IWebElement filetype = Browser.Wd.FindElement(By.XPath("//label[contains(text(),'Specify the File')]"));
                    if (!filetype.Displayed)
                    {
                        uploadElement.Click();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            if (p0.Equals("PIR Response"))
            {

                By PIRRes = By.XPath("(//label[contains(.,'PIR Response')])[1]");
                IWebElement uploadElement = Browser.Wd.FindElement(PIRRes);
                fw.ExecuteJavascript(uploadElement);
            }
            tmsWait.Hard(12);
        }

        [When(@"Imports page Import List section ""(.*)"" is Clicked")]
        public void WhenImportsPageImportListSectionIsClicked(string p0)
        {
            if (p0.Equals("Client Identified Suspects"))
            {
                By clientSus = By.XPath("(//label[contains(.,'Client Identified Suspects')])[1]");
                IWebElement uploadElement = Browser.Wd.FindElement(clientSus);
                fw.ExecuteJavascript(uploadElement);
            }
            if (p0.Equals("PIR Response"))
            {

                By PIRRes = By.XPath("(//label[contains(.,'PIR Response')])[1]");
                IWebElement uploadElement = Browser.Wd.FindElement(PIRRes);
                fw.ExecuteJavascript(uploadElement);
            }
            tmsWait.Hard(3);
        }

        [When(@"Create PIR response file for Both Confirmed_OnHold_using PIR ""(.*)"" Member ID ""(.*)"" Provider ID ""(.*)"" DOS ""(.*)"" DiagCodeOne ""(.*)"" DiagCodeTwo ""(.*)"" using ALM File ""(.*)"" from Test ID ""(.*)"" and set new FileName ""(.*)""")]
        public void WhenCreatePIRResponseFileForBothConfirmed_OnHold_UsingPIRMemberIDProviderIDDOSDiagCodeOneDiagCodeTwoUsingALMFileFromTestIDAndSetNewFileName(string p0, string p1, string p2, string p3, string p4, string p5, string p6, string p7, string p8)
        {

            string pir = tmsCommon.GenerateData(p0);
            string memberid = tmsCommon.GenerateData(p1);
            string providerid = tmsCommon.GenerateData(p2);
            string dos = tmsCommon.GenerateData(p3);
            string diagcode1 = tmsCommon.GenerateData(p4);
            string diagcode2 = tmsCommon.GenerateData(p5);
            string fileName = tmsCommon.GenerateData(p6);
            string testID = tmsCommon.GenerateData(p7);


            //string controllerFileLocation = "c:\\temp\\tmsAlm\\";

            string controllerFileLocation = "c:\\temp\\";
            string SourceFileLocation = "C:\\SourceFile\\";
            Boolean didUpload = false;
            string source = SourceFileLocation + fileName;


            //if (Directory.Exists(SourceFileLocation))
            //{
            //    //    if (!File.Exists(controllerFileLocation))
            //    //    {
            //    //        File.Copy(controllerFileLocation + Path.GetFileName(source), SourceFileLocation + fileName);
            //    //    }
            //    //}
            //    // Boolean didUpload = false;




            //    Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + fileName + "] is [" + File.Exists(controllerFileLocation + fileName) + "]");
            //    if (File.Exists(controllerFileLocation + fileName))
            //    {
            //        File.Copy(controllerFileLocation + fileName, "C:\\Temp\\" + fileName);
            //        tmsWait.Hard(1);
            //        didUpload = true;
            //        Console.WriteLine("**Performed local copy because file did exist locally.");

            //    }
            //    else
            //    {
            //        Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

            //        didUpload = ALMUtilities.GetALMTestPlanAttachedFile(fileName, testID);
            //    }
            //}
            //if (didUpload)
            //{

            //    string FileName = "C:\\Temp\\" + fileName;
            //    //For debugging
            //    string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p8);

            //    // Renaming File Name to New Name
            //    File.Move(@FileName, @newFileName);
            //    FileName = newFileName;
            //    tmsWait.Hard(1);


            //}


            if (Directory.Exists(SourceFileLocation))
            {
                if (!File.Exists(controllerFileLocation))
                {
                    File.Copy(SourceFileLocation + fileName, controllerFileLocation + Path.GetFileName(source));
                }
            }

            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + fileName + "] is [" + File.Exists(controllerFileLocation + fileName) + "]");
            if (File.Exists(controllerFileLocation + fileName))
            {
                //  File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen, true);
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");

            }
            else
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");
                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(fileName, testID);
            }

            if (didUpload)
            {

                string FileName = "C:\\Temp\\" + fileName;
                //For debugging
                string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p8);

                // Renaming File Name to New Name
                File.Move(@FileName, @newFileName);
                FileName = newFileName;
                tmsWait.Hard(1);


            }


            string modifiedFile = "c:\\temp\\" + tmsCommon.GenerateData(p8);
            string modifiedFile1 = "c:\\SourceFileLocation\\" + tmsCommon.GenerateData(p8);
            List<string> sqllist = new List<string>();


            string[] sqlarray = sqllist.ToArray();

            string[] lines = System.IO.File.ReadAllLines(modifiedFile);
            string[] st1 = new string[lines.Length];

            for (int i = 0; i < lines.Length; i++)
            {

                StringBuilder st = new StringBuilder(lines[i]);
                st.Replace((lines[0].Split('|'))[0], pir);
                st.Replace((lines[0].Split('|'))[1], memberid);
                st.Replace((lines[0].Split('|'))[2], providerid);
                st.Replace((lines[0].Split('|'))[3], dos);
                if (i == 0)
                {
                    st.Replace((lines[0].Split('|'))[4], diagcode1);
                }
                else
                {
                    st.Replace((lines[1].Split('|'))[4], diagcode2);
                }

                st1[i] = st.ToString();

                Console.WriteLine(st1[i]);

            }

            System.IO.File.WriteAllLines(modifiedFile, st1);

        }
        [DelimitedRecord("|")]
        [IgnoreEmptyLines()]
        [IgnoreFirst()]
        public class PipePIRResponse
        {

            public string PIR { get; set; } //1
            public string HIC { get; set; } // 2           
            public string PrviderID { get; set; } // 3
            public string Encounter { get; set; } // 4
            public string DiagCode { get; set; } // 5
            public string CoderID { get; set; } // 6
            public string Blank { get; set; }  // Blank // 7
            public string ClaimNumber { get; set; } // 8 
            public string DiagCodeStatus { get; set; } // 9 
            public string OnHoldReason { get; set; } // 10
            public string ChartReview { get; set; } // 11

        }
        [When(@"Create RAMX PIR response file using PIR ""(.*)"" Member ID ""(.*)"" Provider ID ""(.*)"" DOS ""(.*)"" DiadCode ""(.*)"" Coder ID as ""(.*)"" ClaimNumber as ""(.*)"" using ALM File ""(.*)"" from Test ID ""(.*)"" and set new FileName ""(.*)""")]
        public void WhenCreateRAMXPIRResponseFileUsingPIRMemberIDProviderIDDOSDiadCodeCoderIDAsClaimNumberAsUsingALMFileFromTestIDAndSetNewFileName(string p0, string p1, string p2, string p3, string p4, string p5, string p6, string p7, int p8, string p9)
        {

            string pirip = tmsCommon.GenerateData(p0);
            string memberidip = tmsCommon.GenerateData(p1);
            string provideridip = tmsCommon.GenerateData(p2);
            string encounterdateip = tmsCommon.GenerateData(p3);
            string diagcodeip = tmsCommon.GenerateData(p4);
            string coderidip = tmsCommon.GenerateData(p5);
            string Blankip = " ";
            string claimnumberip = tmsCommon.GenerateData(p6);
            string filename = tmsCommon.GenerateData(p9);

            try
            {
                IList<PipePIRResponse> studentList = new List<PipePIRResponse>() {
                    new PipePIRResponse()
                    {
                    PIR =pirip,HIC=memberidip,PrviderID=provideridip,Encounter=encounterdateip,DiagCode=diagcodeip,CoderID=coderidip,Blank=Blankip,ClaimNumber="CLMAUTO001",DiagCodeStatus="N",OnHoldReason="Incomplete information",ChartReview="Other"
                    },
                    new PipePIRResponse()
                    {
                    PIR =pirip,HIC=memberidip,PrviderID=provideridip,Encounter=encounterdateip,DiagCode="A0101",CoderID=coderidip,Blank=Blankip,ClaimNumber="CLMAUTO001",DiagCodeStatus="Y",OnHoldReason="Incomplete information",ChartReview="Other"
                    }
            };
                //filehelper object
                FileHelperEngine engine = new FileHelperEngine(typeof(PipePIRResponse));
                //csv object
                List<PipePIRResponse> csv = new List<PipePIRResponse>();
                //convert any datasource to csv based object

                foreach (var item in studentList)
                {
                    PipePIRResponse temp = new PipePIRResponse();

                    temp.PIR = item.PIR;
                    temp.HIC = item.HIC;
                    temp.PrviderID = item.PrviderID;
                    temp.Encounter = item.Encounter;
                    temp.DiagCode = item.DiagCode;
                    temp.CoderID = item.CoderID;
                    temp.Blank = item.Blank;
                    temp.ClaimNumber = item.ClaimNumber;
                    temp.DiagCodeStatus = item.DiagCodeStatus;
                    temp.OnHoldReason = item.OnHoldReason;
                    temp.ChartReview = item.ChartReview;
                    csv.Add(temp);

                }
                //give file a name and header text
                string finalfilename = "C:\\temp\\" + filename;
                // engine.HeaderText = "HIC Num|Member ID|HCC|Payment Year|Provider ID|Provider Name";
                //save file locally
                engine.WriteFile(finalfilename, csv);

            }
            catch (Exception ex)
            {

            }
            //string pir = tmsCommon.GenerateData(p0);
            //string memberid = tmsCommon.GenerateData(p1);
            //string providerid = tmsCommon.GenerateData(p2);
            //string dos = tmsCommon.GenerateData(p3);
            //string diagcode = tmsCommon.GenerateData(p4);
            //string fileName = tmsCommon.GenerateData(p5);
            //string testID = tmsCommon.GenerateData(p6);


            //string controllerFileLocation = "c:\\temp\\tmsAlm\\";

            //Boolean didUpload = false;

            //Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + fileName + "] is [" + File.Exists(controllerFileLocation + fileName) + "]");
            //if (File.Exists(controllerFileLocation + fileName))
            //{
            //    File.Copy(controllerFileLocation + fileName, "C:\\Temp\\" + fileName);
            //    tmsWait.Hard(1);
            //    didUpload = true;
            //    Console.WriteLine("**Performed local copy because file did exist locally.");

            //}
            //else
            //{
            //    Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

            //    didUpload = ALMUtilities.GetALMTestPlanAttachedFile(fileName, testID);
            //}
            //if (didUpload)
            //{

            //    string FileName = "C:\\Temp\\" + fileName;
            //    //For debugging
            //    string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p7);

            //    // Renaming File Name to New Name
            //    File.Move(@FileName, @newFileName);
            //    FileName = newFileName;
            //    tmsWait.Hard(1);


            //}

            //string modifiedFile = "c:\\temp\\" + tmsCommon.GenerateData(p7);

            //List<string> sqllist = new List<string>();
            //// sqllist = db.OutputDBResultsToList(p0);

            //string[] sqlarray = sqllist.ToArray();

            //string[] lines = System.IO.File.ReadAllLines(modifiedFile);
            //string[] st1 = new string[lines.Length];

            //for (int i = 0; i < lines.Length; i++)
            //{

            //    StringBuilder st = new StringBuilder(lines[i]);
            //    st.Replace((lines[0].Split('|'))[0], pir);
            //    st.Replace((lines[0].Split('|'))[1], memberid);
            //    st.Replace((lines[0].Split('|'))[2], providerid);
            //    st.Replace((lines[0].Split('|'))[3], dos);
            //    st.Replace((lines[0].Split('|'))[4], diagcode);
            //    // st.Remove(485, 5);
            //    // Console.WriteLine($"{sqlarray[i]} - {sqlarray[i].Length}");
            //    //st.Insert(485, sqlarray[i]);
            //    st1[i] = st.ToString();

            //    Console.WriteLine(st1[i]);


            //}

            //System.IO.File.WriteAllLines(modifiedFile, st1);

        }


        [When(@"Create RAMX PIR response file using PIR ""(.*)"" Member ID ""(.*)"" Provider ID ""(.*)"" DOS ""(.*)"" DiadCode ""(.*)"" Coder ID as ""(.*)"" ClaimNumber as ""(.*)"" DiagCodeStatus ""(.*)"" OnHoldReason ""(.*)"" ChartReviewSource ""(.*)""  using ALM File ""(.*)"" from Test ID ""(.*)"" and set new FileName ""(.*)""")]
        public void WhenCreateRAMXPIRResponseFileUsingPIRMemberIDProviderIDDOSDiadCodeCoderIDAsClaimNumberAsDiagCodeStatusOnHoldReasonChartReviewSourceUsingALMFileFromTestIDAndSetNewFileName(string p0, string p1, string p2, string p3, string p4, string p5, string p6, string p7, string p8, string p9, string p10, int p11, string p12)
        {
            string pirip = tmsCommon.GenerateData(p0);
            string memberidip = tmsCommon.GenerateData(p1);
            string provideridip = tmsCommon.GenerateData(p2);
            string encounterdateip = tmsCommon.GenerateData(p3);
            string diagcodeip = tmsCommon.GenerateData(p4);
            string coderidip = tmsCommon.GenerateData(p5);
            string Blankip = " ";
            string claimnumberip = tmsCommon.GenerateData(p6);
            string diagcodestatus = tmsCommon.GenerateData(p7);
            string onHoldReason = tmsCommon.GenerateData(p8);
            string chartreviewsource = tmsCommon.GenerateData(p9);

            string filename = tmsCommon.GenerateData(p12);

            try
            {
                IList<PipePIRResponse> studentList = new List<PipePIRResponse>() {
                    new PipePIRResponse()
                    {
                    PIR =pirip,HIC=memberidip,PrviderID=provideridip,Encounter=encounterdateip,DiagCode=diagcodeip,CoderID=coderidip,Blank=Blankip,ClaimNumber="CLMAUTO001",DiagCodeStatus=diagcodestatus,OnHoldReason=onHoldReason,ChartReview=chartreviewsource
                    },
                    //new PipePIRResponse()
                    //{
                    //PIR =pirip,HIC=memberidip,PrviderID=provideridip,Encounter=encounterdateip,DiagCode="A0101",CoderID=coderidip,Blank=Blankip,ClaimNumber="CLMAUTO001",DiagCodeStatus=diagcodestatus,OnHoldReason=onHoldReason,ChartReview=chartreviewsource
                    //}
            };
                //filehelper object
                FileHelperEngine engine = new FileHelperEngine(typeof(PipePIRResponse));
                //csv object
                List<PipePIRResponse> csv = new List<PipePIRResponse>();
                //convert any datasource to csv based object

                foreach (var item in studentList)
                {
                    PipePIRResponse temp = new PipePIRResponse();

                    temp.PIR = item.PIR;
                    temp.HIC = item.HIC;
                    temp.PrviderID = item.PrviderID;
                    temp.Encounter = item.Encounter;
                    temp.DiagCode = item.DiagCode;
                    temp.CoderID = item.CoderID;
                    temp.Blank = item.Blank;
                    temp.ClaimNumber = item.ClaimNumber;
                    temp.DiagCodeStatus = item.DiagCodeStatus;
                    temp.OnHoldReason = item.OnHoldReason;
                    temp.ChartReview = item.ChartReview;
                    csv.Add(temp);

                }
                //give file a name and header text
                string finalfilename = "C:\\temp\\" + filename;
                // engine.HeaderText = "HIC Num|Member ID|HCC|Payment Year|Provider ID|Provider Name";
                //save file locally
                engine.WriteFile(finalfilename, csv);

            }
            catch (Exception ex)
            {

            }
        }








        [When(@"Create PIR response file using PIR ""(.*)"" Member ID ""(.*)"" Provider ID ""(.*)"" DOS ""(.*)"" DiadCode ""(.*)"" using ALM File ""(.*)"" from Test ID ""(.*)"" and set new FileName ""(.*)""")]
        public void WhenCreatePIRResponseFileUsingPIRMemberIDProviderIDDOSDiadCodeUsingALMFileFromTestIDAndSetNewFileName(string p0, string p1, string p2, string p3, string p4, string p5, string p6, string p7)
        {

            string pir = tmsCommon.GenerateData(p0);
            string memberid = tmsCommon.GenerateData(p1);
            string providerid = tmsCommon.GenerateData(p2);
            string dos = tmsCommon.GenerateData(p3);
            string diagcode = tmsCommon.GenerateData(p4);
            string fileName = tmsCommon.GenerateData(p5);
            string testID = tmsCommon.GenerateData(p6);


            //string controllerFileLocation = "c:\\temp\\tmsAlm\\";

            string controllerFileLocation = "c:\\temp\\";
            string SourceFileLocation = "C:\\SourceFile\\";
            Boolean didUpload = false;
            string source = SourceFileLocation + fileName;



            if (Directory.Exists(SourceFileLocation))
            {
                if (!File.Exists(controllerFileLocation))
                {
                    File.Copy(SourceFileLocation + fileName, controllerFileLocation + Path.GetFileName(source));
                }
            }

            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + fileName + "] is [" + File.Exists(controllerFileLocation + fileName) + "]");
            if (File.Exists(controllerFileLocation + fileName))
            {
                //  File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen, true);
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");

            }
            else
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");
                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(fileName, testID);
            }

            if (didUpload)
            {

                string FileName = "C:\\Temp\\" + fileName;
                //For debugging
                string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p7);

                // Renaming File Name to New Name
                File.Move(@FileName, @newFileName);
                FileName = newFileName;
                tmsWait.Hard(1);


            }

            //Boolean didUpload = false;

            //Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + fileName + "] is [" + File.Exists(controllerFileLocation + fileName) + "]");
            //if (File.Exists(controllerFileLocation + fileName))
            //{
            //    File.Copy(controllerFileLocation + fileName, "C:\\Temp\\" + fileName);
            //    tmsWait.Hard(1);
            //    didUpload = true;
            //    Console.WriteLine("**Performed local copy because file did exist locally.");

            //}
            //else
            //{
            //    Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

            //    didUpload = ALMUtilities.GetALMTestPlanAttachedFile(fileName, testID);
            //}
            //if (didUpload)
            //{

            //    string FileName = "C:\\Temp\\" + fileName;
            //    //For debugging
            //    string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p7);

            //    // Renaming File Name to New Name
            //    File.Move(@FileName, @newFileName);
            //    FileName = newFileName;
            //    tmsWait.Hard(1);


            //}

            string modifiedFile = "c:\\temp\\" + tmsCommon.GenerateData(p7);

            List<string> sqllist = new List<string>();
            // sqllist = db.OutputDBResultsToList(p0);

            string[] sqlarray = sqllist.ToArray();

            string[] lines = System.IO.File.ReadAllLines(modifiedFile);
            string[] st1 = new string[lines.Length];

            for (int i = 0; i < lines.Length; i++)
            {

                StringBuilder st = new StringBuilder(lines[i]);
                st.Replace((lines[0].Split('|'))[0], pir);
                st.Replace((lines[0].Split('|'))[1], memberid);
                st.Replace((lines[0].Split('|'))[2], providerid);
                st.Replace((lines[0].Split('|'))[3], dos);
                st.Replace((lines[0].Split('|'))[4], diagcode);
                // st.Remove(485, 5);
                // Console.WriteLine($"{sqlarray[i]} - {sqlarray[i].Length}");
                //st.Insert(485, sqlarray[i]);
                st1[i] = st.ToString();

                Console.WriteLine(st1[i]);


            }

            System.IO.File.WriteAllLines(modifiedFile, st1);

        }

        [When(@"Create Client Identified ""(.*)"" Delimited Suspects File using existing ALM File ""(.*)"" from Test ID ""(.*)"" and set new FileName ""(.*)""")]
        public void WhenCreateClientIdentifiedDelimitedSuspectsFileUsingExistingALMFileFromTestIDAndSetNewFileName(string p0, string p1, string p2, string p3)
        {
            string fileType = tmsCommon.GenerateData(p0);
            //string memberid = tmsCommon.GenerateData(p1);
            //string providerid = tmsCommon.GenerateData(p2);
            //string dos = tmsCommon.GenerateData(p3);
            //string diagcode1 = tmsCommon.GenerateData(p4);
            //string diagcode2 = tmsCommon.GenerateData(p5);
            string fileName = tmsCommon.GenerateData(p1);
            string testID = tmsCommon.GenerateData(p2);


            string controllerFileLocation = "c:\\temp\\tmsAlm\\";

            Boolean didUpload = false;

            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + fileName + "] is [" + File.Exists(controllerFileLocation + fileName) + "]");
            if (File.Exists(controllerFileLocation + fileName))
            {
                File.Copy(controllerFileLocation + fileName, "C:\\Temp\\" + fileName);
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");

            }
            else
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(fileName, testID);
            }
            if (didUpload)
            {

                string FileName = "C:\\Temp\\" + fileName;
                //For debugging
                string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p3);

                // Renaming File Name to New Name
                File.Move(@FileName, @newFileName);
                FileName = newFileName;
                tmsWait.Hard(1);


            }

            string modifiedFile = "c:\\temp\\" + tmsCommon.GenerateData(p3);

            List<string> sqllist = new List<string>();


            string[] sqlarray = sqllist.ToArray();

            string[] lines = System.IO.File.ReadAllLines(modifiedFile);
            string[] st1 = new string[lines.Length];

            //string Header;
            string delimiter = "";
            int recordIndex = 0;
            string[][] output = new string[1][];
            // string fileName = tmsCommon.GenerateData(p1);
            string HICNumber = "";
            string MemberID = "";
            string HCC = "";
            string paymentYear = "";
            string providerID = "";
            string lastName = "";
            string firstName = "";
            string providerName = "";

            tmsWait.Hard(3);
            if (fileType.Equals("|"))
            {
                // Header = "HIC Num|Member ID|HCC|Payment Year|Provider ID|Provider Name" + Environment.NewLine;
                delimiter = fileType;
                recordIndex = 1;
                HICNumber = singleColumnQueryExecutionSelectRecordBasedOnIndex("select HicNumber from RAM.[dbo].[tbmemberplan] where dteend = '9999-12-31 00:00:00.000'", ConfigFile.RAMdb, 3);
                MemberID = singleColumnQueryExecutionSelectRecordBasedOnIndex("select txtMemberID from RAM.dbo.tbmemberplan  where dteend='9999-12-31 00:00:00.000'", ConfigFile.RAMdb, 3);
                HCC = singleColumnQueryExecutionSelectRecordBasedOnIndex("select HCCnumber from RAM.dbo.tbRAM_PTC_HCC_DESC where PaymentYear > 2018 AND HCCNumber=17", ConfigFile.RAMdb, 3);
                paymentYear = singleColumnQueryExecutionSelectRecordBasedOnIndex("select PaymentYear from RAM.dbo.tbRAM_PTC_HCC_DESC where PaymentYear > 2018 AND HCCNumber=17", ConfigFile.RAMdb, 3);
                providerID = singleColumnQueryExecutionSelectRecordBasedOnIndex("select txtProviderID from RAM.dbo.tbProvider where txtFirst !=' ' AND txtlast !=' '", ConfigFile.RAMdb, 234);
                firstName = singleColumnQueryExecutionSelectRecordBasedOnIndex("select txtFirst from ram.dbo.tbProvider where txtFirst !=' ' AND txtlast !=' '", ConfigFile.RAMdb, 234);
                lastName = singleColumnQueryExecutionSelectRecordBasedOnIndex("select txtlast from ram.dbo.tbProvider where txtFirst !=' ' AND txtlast !=' '", ConfigFile.RAMdb, 234);
                providerName = firstName.Trim() + " " + lastName.Trim();
                output = new string[][]{new string[]{ "HIC Num", "Member ID", "HCC", "Payment Year", "Provider ID", "Provider Name" },
                new string[]{ HICNumber, MemberID, HCC,paymentYear,providerID,providerName}};
            }


            for (int i = 0; i < lines.Length; i++)
            {

                StringBuilder st = new StringBuilder(lines[i]);
                if (i == 0)
                {
                    st1[i] = lines[i];
                }
                if (i > 0)
                {
                    st.Replace((lines[i].Split('|'))[0], HICNumber);
                    st.Replace((lines[i].Split('|'))[1], MemberID);
                    st.Replace((lines[i].Split('|'))[2], HCC);
                    st.Replace((lines[i].Split('|'))[3], paymentYear);
                    st.Replace((lines[i].Split('|'))[4], providerID);
                    st.Replace((lines[i].Split('|'))[5], providerName);
                }
                st1[i] = st.ToString();

                Console.WriteLine(st1[i]);

            }

            System.IO.File.WriteAllLines(modifiedFile, st1);
        }


        [When(@"Create RAMX Client Identified ""(.*)"" Delimited Suspects File as ""(.*)""")]
        public void WhenCreateRAMXClientIdentifiedDelimitedSuspectsFileAs(string delimiterchar, string p1)
        {
            //string Header;
            string delimiter = "";
            int recordIndex = 0;
            string[][] output = new string[1][];
            string fileName = tmsCommon.GenerateData(p1);
            string HICNumber = "";
            string MemberID = "";
            string HCC = "";
            string paymentYear = "";
            string providerID = "";
            string lastName = "";
            string firstName = "";
            string providerName = "";
            //HICNumber = singleColumnQueryExecution("select Top 1 HicNumber from RAM.[dbo].[tbmemberplan] where dteend = '9999-12-31 00:00:00.000'", ConfigFile.RAMdb);
            //MemberID = singleColumnQueryExecution("select  Top 1 txtMemberID from RAM.dbo.tbmemberplan  where dteend='9999-12-31 00:00:00.000'", ConfigFile.RAMdb);
            //HCC = singleColumnQueryExecution("select Top 1 HCCnumber from RAM.dbo.tbRAM_PTC_HCC_DESC where PaymentYear > 2018 AND HCCNumber=17", ConfigFile.RAMdb);
            //paymentYear = singleColumnQueryExecution("select Top 1 PaymentYear from RAM.dbo.tbRAM_PTC_HCC_DESC where PaymentYear > 2018 AND HCCNumber=17", ConfigFile.RAMdb);
            //providerID = singleColumnQueryExecution("select Top 1 txtProviderID from RAM.dbo.tbProvider where txtFirst !=' ' AND txtlast !=' '", ConfigFile.RAMdb);
            //firstName = singleColumnQueryExecution("select Top 1 txtFirst from ram.dbo.tbProvider where txtFirst !=' ' AND txtlast !=' '", ConfigFile.RAMdb);
            //lastName = singleColumnQueryExecution("select Top 1 txtlast from ram.dbo.tbProvider where txtFirst !=' ' AND txtlast !=' '", ConfigFile.RAMdb);
            //providerName = firstName.Trim() + " " + lastName.Trim();
            tmsWait.Hard(3);
            if (delimiterchar.Equals("|"))
            {
                // Header = "HIC Num|Member ID|HCC|Payment Year|Provider ID|Provider Name" + Environment.NewLine;
                delimiter = delimiterchar;
                recordIndex = 1;
                HICNumber = singleColumnQueryExecutionSelectRecordBasedOnIndex("select HicNumber from RAM.[dbo].[tbmemberplan] where dteend = '9999-12-31 00:00:00.000'", ConfigFile.RAMdb, recordIndex);
                MemberID = singleColumnQueryExecutionSelectRecordBasedOnIndex("select txtMemberID from RAM.dbo.tbmemberplan  where dteend='9999-12-31 00:00:00.000'", ConfigFile.RAMdb, recordIndex);
                HCC = singleColumnQueryExecutionSelectRecordBasedOnIndex("select HCCnumber from RAM.dbo.tbRAM_PTC_HCC_DESC where PaymentYear > 2018 AND HCCNumber=17", ConfigFile.RAMdb, recordIndex);
                paymentYear = singleColumnQueryExecutionSelectRecordBasedOnIndex("select PaymentYear from RAM.dbo.tbRAM_PTC_HCC_DESC where PaymentYear > 2018 AND HCCNumber=17", ConfigFile.RAMdb, recordIndex);
                providerID = singleColumnQueryExecutionSelectRecordBasedOnIndex("select txtProviderID from RAM.dbo.tbProvider where txtFirst !=' ' AND txtlast !=' '", ConfigFile.RAMdb, recordIndex);
                firstName = singleColumnQueryExecutionSelectRecordBasedOnIndex("select txtFirst from ram.dbo.tbProvider where txtFirst !=' ' AND txtlast !=' '", ConfigFile.RAMdb, recordIndex);
                lastName = singleColumnQueryExecutionSelectRecordBasedOnIndex("select txtlast from ram.dbo.tbProvider where txtFirst !=' ' AND txtlast !=' '", ConfigFile.RAMdb, recordIndex);
                providerName = firstName.Trim() + " " + lastName.Trim();
                output = new string[][]{new string[]{ "HIC Num", "Member ID", "HCC", "Payment Year", "Provider ID", "Provider Name" },
                new string[]{ HICNumber, MemberID, HCC,paymentYear,providerID,providerName}};
            }

            if (delimiterchar.Equals(","))
            {
                // Header = "HIC Num,Member ID,HCC,Payment Year,Provider ID,Provider Name" + Environment.NewLine;
                delimiter = delimiterchar;
                recordIndex = 0;
                HICNumber = singleColumnQueryExecutionSelectRecordBasedOnIndex("select Top 1 HicNumber from RAM.[dbo].[tbmemberplan] where dteend = '9999-12-31 00:00:00.000'", ConfigFile.RAMdb, recordIndex);
                MemberID = singleColumnQueryExecutionSelectRecordBasedOnIndex("select  Top 1 txtMemberID from RAM.dbo.tbmemberplan  where dteend='9999-12-31 00:00:00.000'", ConfigFile.RAMdb, recordIndex);
                HCC = singleColumnQueryExecutionSelectRecordBasedOnIndex("select Top 1 HCCnumber from RAM.dbo.tbRAM_PTC_HCC_DESC where PaymentYear > 2018 AND HCCNumber=17", ConfigFile.RAMdb, recordIndex);
                paymentYear = singleColumnQueryExecutionSelectRecordBasedOnIndex("select Top 1 PaymentYear from RAM.dbo.tbRAM_PTC_HCC_DESC where PaymentYear > 2018 AND HCCNumber=17", ConfigFile.RAMdb, recordIndex);
                providerID = singleColumnQueryExecutionSelectRecordBasedOnIndex("select Top 1 txtProviderID from RAM.dbo.tbProvider where txtFirst !=' ' AND txtlast !=' '", ConfigFile.RAMdb, recordIndex);
                firstName = singleColumnQueryExecutionSelectRecordBasedOnIndex("select Top 1 txtFirst from ram.dbo.tbProvider where txtFirst !=' ' AND txtlast !=' '", ConfigFile.RAMdb, recordIndex);
                lastName = singleColumnQueryExecutionSelectRecordBasedOnIndex("select Top 1 txtlast from ram.dbo.tbProvider where txtFirst !=' ' AND txtlast !=' '", ConfigFile.RAMdb, recordIndex);
                providerName = firstName.Trim() + " " + lastName.Trim();
                output = new string[][]{new string[]{ "HIC Num", "Member ID", "HCC", "Payment Year", "Provider ID", "Provider Name" },
                new string[]{ HICNumber, MemberID, HCC,paymentYear,providerID,providerName}};
            }
            if (delimiterchar.Equals("TabSeparate"))
            {
                // Header = "HIC Num   Member ID   HCC Payment Year    Provider ID Provider Name" + Environment.NewLine;
                delimiter = "   ";
                recordIndex = 2;
                HICNumber = singleColumnQueryExecutionSelectRecordBasedOnIndex("select HicNumber from RAM.[dbo].[tbmemberplan] where dteend = '9999-12-31 00:00:00.000'", ConfigFile.RAMdb, recordIndex);
                MemberID = singleColumnQueryExecutionSelectRecordBasedOnIndex("select txtMemberID from RAM.dbo.tbmemberplan  where dteend='9999-12-31 00:00:00.000'", ConfigFile.RAMdb, recordIndex);
                HCC = singleColumnQueryExecutionSelectRecordBasedOnIndex("select HCCnumber from RAM.dbo.tbRAM_PTC_HCC_DESC where PaymentYear > 2018 AND HCCNumber=17", ConfigFile.RAMdb, recordIndex);
                paymentYear = singleColumnQueryExecutionSelectRecordBasedOnIndex("select PaymentYear from RAM.dbo.tbRAM_PTC_HCC_DESC where PaymentYear > 2018 AND HCCNumber=17", ConfigFile.RAMdb, recordIndex);
                providerID = singleColumnQueryExecutionSelectRecordBasedOnIndex("select txtProviderID from RAM.dbo.tbProvider where txtFirst !=' ' AND txtlast !=' '", ConfigFile.RAMdb, recordIndex);
                firstName = singleColumnQueryExecutionSelectRecordBasedOnIndex("select txtFirst from ram.dbo.tbProvider where txtFirst !=' ' AND txtlast !=' '", ConfigFile.RAMdb, recordIndex);
                lastName = singleColumnQueryExecutionSelectRecordBasedOnIndex("select txtlast from ram.dbo.tbProvider where txtFirst !=' ' AND txtlast !=' '", ConfigFile.RAMdb, recordIndex);
                providerName = firstName.Trim() + " " + lastName.Trim();
                output = new string[][]{new string[]{ "HIC Num", "Member ID", "HCC", "Payment Year", "Provider ID", "Provider Name" },
                new string[]{ HICNumber, MemberID, HCC,paymentYear,providerID,providerName}};
            }

            fw.ConsoleReport(" Member ID -->" + MemberID);
            fw.ConsoleReport(" HICNumber -->" + HICNumber);
            fw.ConsoleReport(" HCC -->" + HCC);
            fw.ConsoleReport(" PaymentYear -->" + paymentYear);
            fw.ConsoleReport(" ProviderID -->" + providerID);
            fw.ConsoleReport(" First Name -->" + firstName);
            fw.ConsoleReport(" Last Name -->" + lastName);
            fw.ConsoleReport(" Provider Name -->" + providerName);

            GlobalRef.MemberID = MemberID;
            GlobalRef.ProviderID = providerID;


            string path = @"C:\temp\" + fileName;

            // string Header = "HIC Num,Member ID,HCC,Payment Year,Provider ID,Provider Name"+ Environment.NewLine;

            //string[][] output = new string[][]{new string[]{ "HIC Num", "Member ID", "HCC", "Payment Year", "Provider ID", "Provider Name" },
            // new string[]{ HICNumber, MemberID, HCC,paymentYear,providerID,providerName}};
            //string delimiter = delimiterchar;


            if (!File.Exists(path))
            {

                int length = output.GetLength(0);
                StringBuilder sb = new StringBuilder();
                for (int index = 0; index < length; index++)
                    sb.AppendLine(string.Join(delimiter, output[index]));
                File.WriteAllText(path, sb.ToString());
            }


        }

        [When(@"Assign Variable ""(.*)"" value to ""(.*)""")]
        public void WhenAssignVariableValueTo(string p0, string p1)
        {
            string variable = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (variable)
            {
                case "Provider":
                    GlobalRef.ProviderID = value;
                    break;
                case "Member":
                    GlobalRef.MemberID = value;

                    break;

            }
        }

        [When(@"Create Provider Full Name ""(.*)"" using Provider First Name ""(.*)"" and Provider Last Name ""(.*)""")]
        public void WhenCreateProviderFullNameUsingProviderFirstNameAndProviderLastName(string p0, string p1, string p2)
        {
            string first = tmsCommon.GenerateData(p1);
            string last = tmsCommon.GenerateData(p2);
            string providerName = tmsCommon.GenerateData(p0);
            string temp = first.Trim() + " " + last.Trim();
            fw.setVariable(providerName, temp);

        }
        [DelimitedRecord(",")]
        [IgnoreEmptyLines()]
        [IgnoreFirst()]
        public class CSVFileContent1
        {


            public string Member { get; set; }
            public string HCC { get; set; }

            public string PaymentYear { get; set; }
            public string ProviderID { get; set; }
            public string ProviderName { get; set; }
        }

        [When(@"Created Client Identified Comma Separate Delmited Suspect File as ""(.*)"" With Member ID as ""(.*)"" HCC as ""(.*)"" Payment Year as ""(.*)""")]
        public void WhenCreatedClientIdentifiedCommaSeparateDelmitedSuspectFileAsWithMemberIDAsHCCAsPaymentYearAs(string p0, string p1, string p2, string p3)
        {

            string filename = tmsCommon.GenerateData(p0);
            string Mem = tmsCommon.GenerateData(p1);
            string HCC = tmsCommon.GenerateData(p2);
            string paymentyear = tmsCommon.GenerateData(p3);


            try
            {
                IList<CSVFileContent1> studentList = new List<CSVFileContent1>() {
                    new CSVFileContent1(){ Member=Mem,HCC=HCC,PaymentYear=paymentyear,ProviderID=" ",ProviderName=" "}
            };
                //filehelper object
                FileHelperEngine engine = new FileHelperEngine(typeof(CSVFileContent1));
                //csv object
                List<CSVFileContent1> csv = new List<CSVFileContent1>();
                //convert any datasource to csv based object

                foreach (var item in studentList)
                {
                    CSVFileContent1 temp = new CSVFileContent1();


                    temp.Member = item.Member;
                    temp.HCC = item.HCC;
                    temp.PaymentYear = item.PaymentYear;
                    temp.ProviderID = item.ProviderID;
                    temp.ProviderName = item.ProviderName;
                    csv.Add(temp);

                }
                //give file a name and header text
                string finalfilename = "C:\\SourceFile\\" + filename;
                string finalfilename1 = "C:\\temp\\" + filename;
                engine.HeaderText = "Member ID,HCC,Payment Year,Provider ID,Provider Name";
                //save file locally
                engine.WriteFile(finalfilename, csv);
                engine.WriteFile(finalfilename1, csv);
            }
            catch (Exception ex)
            {

            }
        }
        [DelimitedRecord(",")]
        [IgnoreEmptyLines()]
        [IgnoreFirst()]
        public class CSVFileContent11
        {


            public string Member { get; set; }
            public string HCC { get; set; }

            public string PaymentYear { get; set; }
            public string ProviderID { get; set; }
            public string ProviderName { get; set; }
            public string HCCProbability { get; set; }

            public string ExpectedRevenue { get; set; }
        }

        [When(@"Created Client Identified Comma Separate Delmited Suspect File as ""(.*)"" With Member ID as ""(.*)"" and ""(.*)"" and ""(.*)"" Provider as ""(.*)"" HCC as ""(.*)"" PaymentYear as ""(.*)"" CIS1")]
        public void WhenCreatedClientIdentifiedCommaSeparateDelmitedSuspectFileAsWithMemberIDAsAndAndProviderAsHCCAsPaymentYearAsCIS1(string p0, string p1, string p2, string p3, string p4, string p5, string p6)
        {
            string filename = tmsCommon.GenerateData(p0);
            string Mem1 = tmsCommon.GenerateData(p1);
            string Mem2 = tmsCommon.GenerateData(p2);
            string Mem3 = tmsCommon.GenerateData(p3);

            string provider = tmsCommon.GenerateData(p4);
            string HCC = tmsCommon.GenerateData(p5);
            string paymentyear = tmsCommon.GenerateData(p6);


            try
            {
                IList<CSVFileContent11> studentList = new List<CSVFileContent11>() {
                    new CSVFileContent11(){ Member=Mem1,HCC=HCC,PaymentYear=paymentyear,ProviderID=provider,ProviderName=" ",HCCProbability=".9",ExpectedRevenue="2100"},
                new CSVFileContent11() { Member = Mem2, HCC = HCC, PaymentYear = paymentyear, ProviderID =" ", ProviderName=" ",HCCProbability=".9",ExpectedRevenue="2100" },
                      new CSVFileContent11(){ Member=Mem3,HCC=HCC,PaymentYear=paymentyear,ProviderID=" ",ProviderName=" ",HCCProbability=".9",ExpectedRevenue="2100"}

                };
                //filehelper object
                FileHelperEngine engine = new FileHelperEngine(typeof(CSVFileContent11));
                //csv object
                List<CSVFileContent11> csv = new List<CSVFileContent11>();
                //convert any datasource to csv based object

                foreach (var item in studentList)
                {
                    CSVFileContent11 temp = new CSVFileContent11();


                    temp.Member = item.Member;
                    temp.HCC = item.HCC;
                    temp.PaymentYear = item.PaymentYear;
                    temp.ProviderID = item.ProviderID;
                    temp.ProviderName = item.ProviderName;
                    temp.HCCProbability = item.HCCProbability;
                    temp.ExpectedRevenue = item.ExpectedRevenue;
                    csv.Add(temp);

                }
                //give file a name and header text
                string finalfilename = "C:\\SourceFile\\" + filename;
                string finalfilename1 = "C:\\temp\\" + filename;
                engine.HeaderText = "Member ID,HCC,Payment Year,Provider ID,Provider Name,HCC Probability,Expected Revenue";
                //save file locally
                engine.WriteFile(finalfilename, csv);
                engine.WriteFile(finalfilename1, csv);
            }
            catch (Exception ex)
            {

            }
        }


        [When(@"I Created Client Identified Comma Separate Delmited Suspect File as ""(.*)"" With Member ID as ""(.*)"" and ""(.*)"" and ""(.*)"" Provider as ""(.*)"" HCC as ""(.*)"" PaymentYear as ""(.*)"" CIS(.*)")]
        public void WhenICreatedClientIdentifiedCommaSeparateDelmitedSuspectFileAsWithMemberIDAsAndAndProviderAsHCCAsPaymentYearAsCIS(string p0, string p1, string p2, string p3, string p4, string p5, string p6, string p7)
        {
            string filename = tmsCommon.GenerateData(p0);
            string Mem1 = tmsCommon.GenerateData(p1);
            string Mem2 = tmsCommon.GenerateData(p2);
            string Mem3 = tmsCommon.GenerateData(p3);

            string provider = tmsCommon.GenerateData(p4);
            string HCC = tmsCommon.GenerateData(p5);
            string paymentyear = tmsCommon.GenerateData(p6);


            try
            {
                IList<CSVFileContent11> studentList = new List<CSVFileContent11>() {
                    new CSVFileContent11(){ Member=Mem1,HCC=HCC,PaymentYear=paymentyear,ProviderID=provider,ProviderName=" ",HCCProbability=".9",ExpectedRevenue="2100"},
                new CSVFileContent11() { Member = Mem2, HCC = HCC, PaymentYear = paymentyear, ProviderID =" ", ProviderName=" ",HCCProbability=".9",ExpectedRevenue="2100" },
                      new CSVFileContent11(){ Member=Mem3,HCC=HCC,PaymentYear=paymentyear,ProviderID=" ",ProviderName=" ",HCCProbability=".9",ExpectedRevenue="2100"}

                };
                //filehelper object
                FileHelperEngine engine = new FileHelperEngine(typeof(CSVFileContent11));
                //csv object
                List<CSVFileContent11> csv = new List<CSVFileContent11>();
                //convert any datasource to csv based object

                foreach (var item in studentList)
                {
                    CSVFileContent11 temp = new CSVFileContent11();


                    temp.Member = item.Member;
                    temp.HCC = item.HCC;
                    temp.PaymentYear = item.PaymentYear;
                    temp.ProviderID = item.ProviderID;
                    temp.ProviderName = item.ProviderName;
                    temp.HCCProbability = item.HCCProbability;
                    temp.ExpectedRevenue = item.ExpectedRevenue;
                    csv.Add(temp);

                }

                string SourceFileLocation = "C:\\SourceFile\\";
                if (!(Directory.Exists(SourceFileLocation)))
                {
                    Directory.CreateDirectory(SourceFileLocation);
                }

                //give file a name and header text
                string finalfilename = "C:\\SourceFile\\" + filename;
                string finalfilename1 = "C:\\temp\\" + filename;
                engine.HeaderText = "Member ID,HCC,Payment Year,Provider ID,Provider Name,HCC Probability,Expected Revenue";
                //save file locally
                engine.WriteFile(finalfilename, csv);
                engine.WriteFile(finalfilename1, csv);
            }
            catch (Exception ex)
            {

            }
        }



        [When(@"Created Client Identified Comma Separate Delmited Suspect File as ""(.*)"" With Member ID as ""(.*)"" and ""(.*)"" and ""(.*)"" Provider as ""(.*)"" HCC as ""(.*)"" PaymentYear as ""(.*)"" CIS")]
        public void WhenCreatedClientIdentifiedCommaSeparateDelmitedSuspectFileAsWithMemberIDAsAndAndProviderAsHCCAsPaymentYearAsCIS(string p0, string p1, string p2, string p3, string p4, string p5, string p6)
        {
            string filename = tmsCommon.GenerateData(p0);
            string Mem1 = tmsCommon.GenerateData(p1);
            string Mem2 = tmsCommon.GenerateData(p2);
            string Mem3 = tmsCommon.GenerateData(p3);

            string provider = tmsCommon.GenerateData(p4);
            string HCC = tmsCommon.GenerateData(p5);
            string paymentyear = tmsCommon.GenerateData(p6);


            try
            {
                IList<CSVFileContent1> studentList = new List<CSVFileContent1>() {
                    new CSVFileContent1(){ Member=Mem1,HCC=HCC,PaymentYear=paymentyear,ProviderID=provider,ProviderName=" "},
                new CSVFileContent1() { Member = Mem2, HCC = HCC, PaymentYear = paymentyear, ProviderID = " ", ProviderName = " " },
                      new CSVFileContent1(){ Member=Mem3,HCC=HCC,PaymentYear=paymentyear,ProviderID=" ",ProviderName=" "}

                };
                //filehelper object
                FileHelperEngine engine = new FileHelperEngine(typeof(CSVFileContent1));
                //csv object
                List<CSVFileContent1> csv = new List<CSVFileContent1>();
                //convert any datasource to csv based object

                foreach (var item in studentList)
                {
                    CSVFileContent1 temp = new CSVFileContent1();


                    temp.Member = item.Member;
                    temp.HCC = item.HCC;
                    temp.PaymentYear = item.PaymentYear;
                    temp.ProviderID = item.ProviderID;
                    temp.ProviderName = item.ProviderName;
                    csv.Add(temp);

                }
                //give file a name and header text
                string finalfilename = "C:\\SourceFile\\" + filename;
                string finalfilename1 = "C:\\temp\\" + filename;
                engine.HeaderText = "Member ID,HCC,Payment Year,Provider ID,Provider Name";
                //save file locally
                engine.WriteFile(finalfilename, csv);
                engine.WriteFile(finalfilename1, csv);
            }
            catch (Exception ex)
            {

            }
        }

        [DelimitedRecord(",")]
        [IgnoreEmptyLines()]

        public class CSVFileContent3
        {


            public string chartid { get; set; }


        }
        [When(@"Created Chart File as ""(.*)"" With ChartID as ""(.*)""")]
        public void WhenCreatedChartFileAsWithChartIDAs(string p0, string p1)
        {
            string filename = tmsCommon.GenerateData(p0);
            string ChartID = tmsCommon.GenerateData(p1);


            try
            {
                IList<CSVFileContent3> studentList = new List<CSVFileContent3>() {
                    new CSVFileContent3(){ chartid=ChartID}
            };
                //filehelper object
                FileHelperEngine engine = new FileHelperEngine(typeof(CSVFileContent3));
                //csv object
                List<CSVFileContent3> csv = new List<CSVFileContent3>();
                //convert any datasource to csv based object

                foreach (var item in studentList)
                {
                    CSVFileContent3 temp = new CSVFileContent3();


                    temp.chartid = item.chartid;

                    csv.Add(temp);

                }
                //give file a name and header text
                string finalfilename = "C:\\SourceFile\\" + filename;
                //engine.HeaderText = "Member ID,HCC,Payment Year,Provider ID,Provider Name,HCC Probability,Expected Revenue";
                //save file locally
                engine.WriteFile(finalfilename, csv);

            }
            catch (Exception ex)
            {

            }
        }

        [When(@"Created Client Identified Comma Separate Delmited Suspect File as ""(.*)"" With ChartID as ""(.*)""")]
        public void WhenCreatedClientIdentifiedCommaSeparateDelmitedSuspectFileAsWithChartIDAs(string p0, string p1)
        {
            string filename = tmsCommon.GenerateData(p0);
            string ChartID = tmsCommon.GenerateData(p1);


            try
            {
                IList<CSVFileContent3> studentList = new List<CSVFileContent3>() {
                    new CSVFileContent3(){ chartid=ChartID}
            };
                //filehelper object
                FileHelperEngine engine = new FileHelperEngine(typeof(CSVFileContent3));
                //csv object
                List<CSVFileContent3> csv = new List<CSVFileContent3>();
                //convert any datasource to csv based object

                foreach (var item in studentList)
                {
                    CSVFileContent3 temp = new CSVFileContent3();


                    temp.chartid = item.chartid;

                    csv.Add(temp);

                }
                //give file a name and header text
                string finalfilename = "C:\\SourceFile\\" + filename;
                //engine.HeaderText = "Member ID,HCC,Payment Year,Provider ID,Provider Name,HCC Probability,Expected Revenue";
                //save file locally
                engine.WriteFile(finalfilename, csv);

            }
            catch (Exception ex)
            {

            }
        }

        [When(@"I Created Invalid Client Identified Comma Separate Delmited Suspect File as ""(.*)"" With Member ID as ""(.*)"" HCC as ""(.*)"" Payment Year as ""(.*)""")]
        public void WhenICreatedInvalidClientIdentifiedCommaSeparateDelmitedSuspectFileAsWithMemberIDAsHCCAsPaymentYearAs(string p0, string p1, string p2, string p3)
        {
            string filename = tmsCommon.GenerateData(p0);
            string Mem = tmsCommon.GenerateData(p1);
            string HCC = tmsCommon.GenerateData(p2);
            string paymentyear = tmsCommon.GenerateData(p3);


            try
            {
                IList<CSVFileContent1> studentList = new List<CSVFileContent1>() {
                    new CSVFileContent1(){ Member=Mem,HCC=HCC,PaymentYear=" ",ProviderID="vjhgj",ProviderName=" "}
            };
                //filehelper object
                FileHelperEngine engine = new FileHelperEngine(typeof(CSVFileContent1));
                //csv object
                List<CSVFileContent1> csv = new List<CSVFileContent1>();
                //convert any datasource to csv based object

                foreach (var item in studentList)
                {
                    CSVFileContent1 temp = new CSVFileContent1();


                    temp.Member = item.Member;
                    temp.HCC = item.HCC;
                    temp.PaymentYear = item.PaymentYear;
                    temp.ProviderID = item.ProviderID;
                    temp.ProviderName = item.ProviderName;
                    csv.Add(temp);

                }
                //give file a name and header text
                string finalfilename = "C:\\SourceFile\\" + filename;
                engine.HeaderText = "Member ID,HCC,Payment Year,Provider ID,Provider Name,HCC Probability,Expected Revenue";
                //save file locally
                engine.WriteFile(finalfilename, csv);

            }
            catch (Exception ex)
            {

            }
        }
        [DelimitedRecord(",")]
        [IgnoreEmptyLines()]
        [IgnoreFirst()]
        public class CSVFileContent2
        {


            public string Member { get; set; }
            public string HCC { get; set; }

            public string PaymentYear { get; set; }
            public string ProviderID { get; set; }
            public string ProviderName { get; set; }
            public string Probability { get; set; }
            public string Revenue { get; set; }


        }

        [When(@"I Created  Client IMPROVE Identified Comma Separate Delmited Suspect File as ""(.*)"" With Member ID as ""(.*)"" HCC as ""(.*)"" Payment Year as ""(.*)"" Revenue as ""(.*)"" Probability as ""(.*)""")]
        public void WhenICreatedClientIMPROVEIdentifiedCommaSeparateDelmitedSuspectFileAsWithMemberIDAsHCCAsPaymentYearAsRevenueAsProbabilityAs(string p0, string p1, string p2, string p3, string p4, string p5)
        {

            string filename = tmsCommon.GenerateData(p0);
            string Mem = tmsCommon.GenerateData(p1);
            string HCC = tmsCommon.GenerateData(p2);

            string paymentyear = tmsCommon.GenerateData(p3);
            string Probability = tmsCommon.GenerateData(p4);

            string Revenue = tmsCommon.GenerateData(p3);
            try
            {
                IList<CSVFileContent2> studentList = new List<CSVFileContent2>() {
                    new CSVFileContent2(){ Member=Mem,HCC=HCC,PaymentYear=paymentyear,ProviderID=" ",ProviderName=" ",Probability=Probability,Revenue=Revenue}
            };
                //filehelper object
                FileHelperEngine engine = new FileHelperEngine(typeof(CSVFileContent2));
                //csv object
                List<CSVFileContent2> csv = new List<CSVFileContent2>();
                //convert any datasource to csv based object

                foreach (var item in studentList)
                {
                    CSVFileContent2 temp = new CSVFileContent2();


                    temp.Member = item.Member;
                    temp.HCC = item.HCC;
                    temp.PaymentYear = item.PaymentYear;
                    temp.ProviderID = item.ProviderID;
                    temp.ProviderName = item.ProviderName;
                    temp.Probability = item.Probability;
                    temp.Revenue = item.Revenue;
                    csv.Add(temp);

                }
                //give file a name and header text
                string finalfilename = "C:\\SourceFile\\" + filename;
                string finalfilename1 = "C:\\temp\\" + filename;
                engine.HeaderText = "Member ID,HCC,Payment Year,Provider ID,Provider Name,HCC Probability,Expected Revenue";
                //save file locally
                engine.WriteFile(finalfilename, csv);
                engine.WriteFile(finalfilename1, csv);
            }
            catch (Exception ex)
            {

            }
        }

        [When(@"I Created Invalid Client IMPROVE Identified Comma Separate Delmited Suspect File as ""(.*)"" With Member ID as ""(.*)"" HCC as ""(.*)"" Payment Year as ""(.*)"" Revenue as ""(.*)"" Probability as ""(.*)""")]
        public void WhenICreatedInvalidClientIMPROVEIdentifiedCommaSeparateDelmitedSuspectFileAsWithMemberIDAsHCCAsPaymentYearAsRevenueAsProbabilityAs(string p0, string p1, string p2, string p3, string p4, string p5)
        {
            string filename = tmsCommon.GenerateData(p0);
            string Mem = tmsCommon.GenerateData(p1);
            string HCC = tmsCommon.GenerateData(p2);

            string paymentyear = tmsCommon.GenerateData(p3);
            string Probability = tmsCommon.GenerateData(p4);

            string Revenue = tmsCommon.GenerateData(p3);
            try
            {
                IList<CSVFileContent2> studentList = new List<CSVFileContent2>() {
                    new CSVFileContent2(){ Member=" ",HCC=" ",PaymentYear=" ",ProviderID=" ",ProviderName=" ",Probability=" ",Revenue=" "}
            };
                //filehelper object
                FileHelperEngine engine = new FileHelperEngine(typeof(CSVFileContent2));
                //csv object
                List<CSVFileContent2> csv = new List<CSVFileContent2>();
                //convert any datasource to csv based object

                foreach (var item in studentList)
                {
                    CSVFileContent2 temp = new CSVFileContent2();


                    temp.Member = item.Member;
                    temp.HCC = item.HCC;
                    temp.PaymentYear = item.PaymentYear;
                    temp.ProviderID = item.ProviderID;
                    temp.ProviderName = item.ProviderName;
                    temp.Probability = item.Probability;
                    temp.Revenue = item.Revenue;
                    csv.Add(temp);

                }
                //give file a name and header text
                string finalfilename = "C:\\SourceFile\\" + filename;
                string finalfilename1 = "C:\\temp\\" + filename;
                engine.HeaderText = "Member ID,HCC,Payment Year,Provider ID,Provider Name,HCC Probability,Expected Revenue";
                //save file locally
                engine.WriteFile(finalfilename, csv);
                engine.WriteFile(finalfilename1, csv);
            }
            catch (Exception ex)
            {

            }
        }

        [DelimitedRecord("|")]
        [IgnoreEmptyLines()]
        [IgnoreFirst()]
        public class CSVPIPEFileContent
        {

            public string HIC { get; set; }
            //Description, this attribute will handle the double quotes issue
            //[FieldQuoted('"', QuoteMode.OptionalForBoth)]
            public string Member { get; set; }
            public string HCC { get; set; }

            public string PaymentYear { get; set; }
            public string ProviderID { get; set; }
            public string ProviderName { get; set; }

        }

        [DelimitedRecord(",")]
        [IgnoreEmptyLines()]
        [IgnoreFirst()]
        public class CSVFileContent
        {

            public string HIC { get; set; }
            //Description, this attribute will handle the double quotes issue
            //[FieldQuoted('"', QuoteMode.OptionalForBoth)]
            public string Member { get; set; }
            public string HCC { get; set; }

            public string PaymentYear { get; set; }
            public string ProviderID { get; set; }
            public string ProviderName { get; set; }

        }



        [DelimitedRecord("\t")]
        [IgnoreEmptyLines()]
        [IgnoreFirst()]
        public class TabFileContent
        {

            public string HIC { get; set; }
            //Description, this attribute will handle the double quotes issue
            //[FieldQuoted('"', QuoteMode.OptionalForBoth)]
            public string Member { get; set; }
            public string HCC { get; set; }

            public string PaymentYear { get; set; }
            public string ProviderID { get; set; }
            public string ProviderName { get; set; }
        }

        [When(@"Created Client Identified Comma Separate Delmited Suspect File as ""(.*)"" With HIC Number ""(.*)"" Member ID as ""(.*)"" HCC as ""(.*)"" Payment Year as ""(.*)"" Provider ID as ""(.*)"" Provider Name as ""(.*)""")]
        public void WhenCreatedClientIdentifiedCommaSeparateDelmitedSuspectFileAsWithHICNumberMemberIDAsHCCAsPaymentYearAsProviderIDAsProviderNameAs(string p0, string p1, string p2, string p3, string p4, string p5, string p6)
        {
            string filename = tmsCommon.GenerateData(p0);
            string HICNum = tmsCommon.GenerateData(p1);
            string Mem = tmsCommon.GenerateData(p2);
            string HCC = tmsCommon.GenerateData(p3);
            string paymentyear = tmsCommon.GenerateData(p4);
            string providerid = tmsCommon.GenerateData(p5);
            string providername = tmsCommon.GenerateData(p6);

            try
            {
                IList<CSVFileContent> studentList = new List<CSVFileContent>() {
                    new CSVFileContent(){ HIC=HICNum,Member=Mem,HCC=HCC,PaymentYear=paymentyear,ProviderID=providerid,ProviderName=providername}
            };
                //filehelper object
                FileHelperEngine engine = new FileHelperEngine(typeof(CSVFileContent));
                //csv object
                List<CSVFileContent> csv = new List<CSVFileContent>();
                //convert any datasource to csv based object

                foreach (var item in studentList)
                {
                    CSVFileContent temp = new CSVFileContent();

                    temp.HIC = item.HIC;
                    temp.Member = item.Member;
                    temp.HCC = item.HCC;
                    temp.PaymentYear = item.PaymentYear;
                    temp.ProviderID = item.ProviderID;
                    temp.ProviderName = item.ProviderName;
                    csv.Add(temp);

                }
                //give file a name and header text
                string finalfilename = "C:\\temp\\" + filename;
                engine.HeaderText = "HIC Num,Member ID,HCC,Payment Year,Provider ID,Provider Name";
                //save file locally
                engine.WriteFile(finalfilename, csv);

            }
            catch (Exception ex)
            {

            }

        }

        [When(@"Created Client Identified Pipe Separate Delmited Suspect File as ""(.*)"" With HIC Number ""(.*)"" Member ID as ""(.*)"" HCC as ""(.*)"" Payment Year as ""(.*)"" Provider ID as ""(.*)"" Provider Name as ""(.*)""")]
        public void WhenCreatedClientIdentifiedPipeSeparateDelmitedSuspectFileAsWithHICNumberMemberIDAsHCCAsPaymentYearAsProviderIDAsProviderNameAs(string p0, string p1, string p2, string p3, string p4, string p5, string p6)
        {
            string filename = tmsCommon.GenerateData(p0);
            string HICNum = tmsCommon.GenerateData(p1);
            string Mem = tmsCommon.GenerateData(p2);
            string HCC = tmsCommon.GenerateData(p3);
            string paymentyear = tmsCommon.GenerateData(p4);
            string providerid = tmsCommon.GenerateData(p5);
            string providername = tmsCommon.GenerateData(p6);

            try
            {
                IList<CSVPIPEFileContent> studentList = new List<CSVPIPEFileContent>() {
                    new CSVPIPEFileContent(){ HIC=HICNum,Member=Mem,HCC=HCC,PaymentYear=paymentyear,ProviderID=providerid,ProviderName=providername}
            };
                //filehelper object
                FileHelperEngine engine = new FileHelperEngine(typeof(CSVPIPEFileContent));
                //csv object
                List<CSVPIPEFileContent> csv = new List<CSVPIPEFileContent>();
                //convert any datasource to csv based object

                foreach (var item in studentList)
                {
                    CSVPIPEFileContent temp = new CSVPIPEFileContent();

                    temp.HIC = item.HIC;
                    temp.Member = item.Member;
                    temp.HCC = item.HCC;
                    temp.PaymentYear = item.PaymentYear;
                    temp.ProviderID = item.ProviderID;
                    temp.ProviderName = item.ProviderName;
                    csv.Add(temp);

                }
                //give file a name and header text
                string finalfilename = "C:\\temp\\" + filename;
                engine.HeaderText = "HIC Num|Member ID|HCC|Payment Year|Provider ID|Provider Name";
                //save file locally
                engine.WriteFile(finalfilename, csv);

            }
            catch (Exception ex)
            {

            }
        }


        [When(@"Created Client Identified Tab Separate Delmited Suspect File as ""(.*)"" With HIC Number ""(.*)"" Member ID as ""(.*)"" HCC as ""(.*)"" Payment Year as ""(.*)"" Provider ID as ""(.*)"" Provider Name as ""(.*)""")]
        public void WhenCreatedClientIdentifiedTabSeparateDelmitedSuspectFileAsWithHICNumberMemberIDAsHCCAsPaymentYearAsProviderIDAsProviderNameAs(string p0, string p1, string p2, string p3, string p4, string p5, string p6)
        {
            string filename = tmsCommon.GenerateData(p0);
            string HICNum = tmsCommon.GenerateData(p1);
            string Mem = tmsCommon.GenerateData(p2);
            string HCC = tmsCommon.GenerateData(p3);
            string paymentyear = tmsCommon.GenerateData(p4);
            string providerid = tmsCommon.GenerateData(p5);
            string providername = tmsCommon.GenerateData(p6);

            try
            {
                IList<TabFileContent> studentList = new List<TabFileContent>() {
                    new TabFileContent(){ HIC=HICNum,Member=Mem,HCC=HCC,PaymentYear=paymentyear,ProviderID=providerid,ProviderName=providername}
            };
                //filehelper object
                FileHelperEngine engine = new FileHelperEngine(typeof(TabFileContent));
                //csv object
                List<TabFileContent> csv = new List<TabFileContent>();
                //convert any datasource to csv based object

                foreach (var item in studentList)
                {
                    TabFileContent temp = new TabFileContent();

                    temp.HIC = item.HIC;
                    temp.Member = item.Member;
                    temp.HCC = item.HCC;
                    temp.PaymentYear = item.PaymentYear;
                    temp.ProviderID = item.ProviderID;
                    temp.ProviderName = item.ProviderName;
                    csv.Add(temp);

                }
                //give file a name and header text
                string finalfilename = "C:\\temp\\" + filename;
                engine.HeaderText = "HIC Num" + "\t" + "Member ID" + "\t" + "HCC Payment Year" + "\t" + "Provider ID" + "\t" + "Provider Name";
                //save file locally
                engine.WriteFile(finalfilename, csv);

            }
            catch (Exception ex)
            {

            }

        }


        [DelimitedRecord("\t")]
        [IgnoreEmptyLines()]
        [IgnoreFirst()]
        public class TabFileContent1
        {

            //Description, this attribute will handle the double quotes issue
            //[FieldQuoted('"', QuoteMode.OptionalForBoth)]
            public string Member { get; set; }
            public string HCC { get; set; }

            public string PaymentYear { get; set; }
            public string ProviderID { get; set; }
            public string ProviderName { get; set; }
        }
        [When(@"Created Client Identified Tab Separate Delmited Suspect File as ""(.*)"" With Member ID as ""(.*)"" HCC as ""(.*)"" Payment Year as ""(.*)"" Provider ID as ""(.*)""")]
        public void WhenCreatedClientIdentifiedTabSeparateDelmitedSuspectFileAsWithMemberIDAsHCCAsPaymentYearAsProviderIDAs(string p0, string p1, string p2, string p3, string p4)
        {
            string filename = tmsCommon.GenerateData(p0);
            string Mem = tmsCommon.GenerateData(p1);
            string HCC = tmsCommon.GenerateData(p2);
            string paymentyear = tmsCommon.GenerateData(p3);
            string providerid = tmsCommon.GenerateData(p4);


            try
            {
                IList<TabFileContent1> studentList = new List<TabFileContent1>() {
                    new TabFileContent1(){ Member=Mem,HCC=HCC,PaymentYear=paymentyear,ProviderID=providerid,ProviderName=" "}
            };
                //filehelper object
                FileHelperEngine engine = new FileHelperEngine(typeof(TabFileContent1));
                //csv object
                List<TabFileContent1> csv = new List<TabFileContent1>();
                //convert any datasource to csv based object

                foreach (var item in studentList)
                {
                    TabFileContent1 temp = new TabFileContent1();


                    temp.Member = item.Member;
                    temp.HCC = item.HCC;
                    temp.PaymentYear = item.PaymentYear;
                    temp.ProviderID = item.ProviderID;
                    temp.ProviderName = item.ProviderName;
                    csv.Add(temp);

                }

                //give file a name and header text
                string finalfilename = "C:\\SourceFile\\" + filename;
                string finalfilename1 = "C:\\temp\\" + filename;
                //save file locally
                engine.HeaderText = "Member ID	HCC	Payment Year	Provider ID	Provider Name";
                engine.WriteFile(finalfilename, csv);
                engine.WriteFile(finalfilename1, csv);
            }
            catch (Exception ex)
            {

            }
        }


        [When(@"Create RAM Client Identified ""(.*)"" Delimited Suspects File as ""(.*)""")]
        public void WhenCreateRAMClientIdentifiedDelimitedSuspectsFileAs(string delimiterchar, string p1)
        {
            //string Header;
            string delimiter = "";
            int recordIndex = 0;
            string[][] output = new string[1][];
            string fileName = tmsCommon.GenerateData(p1);
            string HICNumber = "";
            string MemberID = "";
            string HCC = "";
            string paymentYear = "";
            string providerID = "";
            string lastName = "";
            string firstName = "";
            string providerName = "";
            //HICNumber = singleColumnQueryExecution("select Top 1 HicNumber from RAM.[dbo].[tbmemberplan] where dteend = '9999-12-31 00:00:00.000'", ConfigFile.RAMdb);
            //MemberID = singleColumnQueryExecution("select  Top 1 txtMemberID from RAM.dbo.tbmemberplan  where dteend='9999-12-31 00:00:00.000'", ConfigFile.RAMdb);
            //HCC = singleColumnQueryExecution("select Top 1 HCCnumber from RAM.dbo.tbRAM_PTC_HCC_DESC where PaymentYear > 2018 AND HCCNumber=17", ConfigFile.RAMdb);
            //paymentYear = singleColumnQueryExecution("select Top 1 PaymentYear from RAM.dbo.tbRAM_PTC_HCC_DESC where PaymentYear > 2018 AND HCCNumber=17", ConfigFile.RAMdb);
            //providerID = singleColumnQueryExecution("select Top 1 txtProviderID from RAM.dbo.tbProvider where txtFirst !=' ' AND txtlast !=' '", ConfigFile.RAMdb);
            //firstName = singleColumnQueryExecution("select Top 1 txtFirst from ram.dbo.tbProvider where txtFirst !=' ' AND txtlast !=' '", ConfigFile.RAMdb);
            //lastName = singleColumnQueryExecution("select Top 1 txtlast from ram.dbo.tbProvider where txtFirst !=' ' AND txtlast !=' '", ConfigFile.RAMdb);
            //providerName = firstName.Trim() + " " + lastName.Trim();
            tmsWait.Hard(3);
            if (delimiterchar.Equals("|"))
            {
                // Header = "HIC Num|Member ID|HCC|Payment Year|Provider ID|Provider Name" + Environment.NewLine;
                delimiter = delimiterchar;
                recordIndex = 1;
                HICNumber = singleColumnQueryExecutionSelectRecordBasedOnIndex("select HicNumber from RAMX.[dbo].[tbmemberplan] where dteend = '9999-12-31 00:00:00.000'", ConfigFile.RAMXdb, recordIndex);
                MemberID = singleColumnQueryExecutionSelectRecordBasedOnIndex("select txtMemberID from RAMX.dbo.tbmemberplan  where dteend='9999-12-31 00:00:00.000'", ConfigFile.RAMXdb, recordIndex);
                HCC = singleColumnQueryExecutionSelectRecordBasedOnIndex("select HCCnumber from RAMX.dbo.tbRAM_PTC_HCC_DESC where PaymentYear > 2017 AND HCCNumber=19", ConfigFile.RAMXdb, recordIndex);
                paymentYear = singleColumnQueryExecutionSelectRecordBasedOnIndex("select PaymentYear from RAMX.dbo.tbRAM_PTC_HCC_DESC where PaymentYear > 2017 AND HCCNumber=19", ConfigFile.RAMXdb, recordIndex);
                providerID = singleColumnQueryExecutionSelectRecordBasedOnIndex("select txtProviderID from RAMX.dbo.tbProvider where txtFirst !=' ' AND txtlast !=' '", ConfigFile.RAMXdb, recordIndex);
                firstName = singleColumnQueryExecutionSelectRecordBasedOnIndex("select txtFirst from ramx.dbo.tbProvider where txtFirst !=' ' AND txtlast !=' '", ConfigFile.RAMXdb, recordIndex);
                lastName = singleColumnQueryExecutionSelectRecordBasedOnIndex("select txtlast from ramx.dbo.tbProvider where txtFirst !=' ' AND txtlast !=' '", ConfigFile.RAMXdb, recordIndex);
                providerName = firstName.Trim() + " " + lastName.Trim();
                output = new string[][]{new string[]{ "HIC Num", "Member ID", "HCC", "Payment Year", "Provider ID", "Provider Name" },
                new string[]{ HICNumber, MemberID, HCC,paymentYear,providerID,providerName}};
            }

            if (delimiterchar.Equals(","))
            {
                // Header = "HIC Num,Member ID,HCC,Payment Year,Provider ID,Provider Name" + Environment.NewLine;
                delimiter = delimiterchar;
                recordIndex = 0;
                HICNumber = singleColumnQueryExecutionSelectRecordBasedOnIndex("select Top 1 HicNumber from RAMX.[dbo].[tbmemberplan] where dteend = '9999-12-31 00:00:00.000'", ConfigFile.RAMXdb, recordIndex);
                MemberID = singleColumnQueryExecutionSelectRecordBasedOnIndex("select  Top 1 txtMemberID from RAMX.dbo.tbmemberplan  where dteend='9999-12-31 00:00:00.000'", ConfigFile.RAMXdb, recordIndex);
                HCC = singleColumnQueryExecutionSelectRecordBasedOnIndex("select Top 1 HCCnumber from RAMX.dbo.tbRAM_PTC_HCC_DESC where PaymentYear > 2017 AND HCCNumber=19", ConfigFile.RAMXdb, recordIndex);
                paymentYear = singleColumnQueryExecutionSelectRecordBasedOnIndex("select Top 1 PaymentYear from RAMX.dbo.tbRAM_PTC_HCC_DESC where PaymentYear > 2017 AND HCCNumber=19", ConfigFile.RAMXdb, recordIndex);
                providerID = singleColumnQueryExecutionSelectRecordBasedOnIndex("select Top 1 txtProviderID from RAMX.dbo.tbProvider where txtFirst !=' ' AND txtlast !=' '", ConfigFile.RAMXdb, recordIndex);
                firstName = singleColumnQueryExecutionSelectRecordBasedOnIndex("select Top 1 txtFirst from ramx.dbo.tbProvider where txtFirst !=' ' AND txtlast !=' '", ConfigFile.RAMXdb, recordIndex);
                lastName = singleColumnQueryExecutionSelectRecordBasedOnIndex("select Top 1 txtlast from ramx.dbo.tbProvider where txtFirst !=' ' AND txtlast !=' '", ConfigFile.RAMXdb, recordIndex);
                providerName = firstName.Trim() + " " + lastName.Trim();
                output = new string[][]{new string[]{ "HIC Num", "Member ID", "HCC", "Payment Year", "Provider ID", "Provider Name" },
                new string[]{ HICNumber, MemberID, HCC,paymentYear,providerID,providerName}};
            }

            if (delimiterchar.Equals("TabSeparate"))
            {
                // Header = "HIC Num   Member ID   HCC Payment Year    Provider ID Provider Name" + Environment.NewLine;
                delimiter = "   ";
                recordIndex = 2;
                HICNumber = singleColumnQueryExecutionSelectRecordBasedOnIndex("select HicNumber from RAMX.[dbo].[tbmemberplan] where dteend = '9999-12-31 00:00:00.000'", ConfigFile.RAMXdb, recordIndex);
                MemberID = singleColumnQueryExecutionSelectRecordBasedOnIndex("select txtMemberID from RAMX.dbo.tbmemberplan  where dteend='9999-12-31 00:00:00.000'", ConfigFile.RAMXdb, recordIndex);
                HCC = singleColumnQueryExecutionSelectRecordBasedOnIndex("select HCCnumber from RAMX.dbo.tbRAM_PTC_HCC_DESC where PaymentYear > 2017 AND HCCNumber=19", ConfigFile.RAMXdb, recordIndex);
                paymentYear = singleColumnQueryExecutionSelectRecordBasedOnIndex("select PaymentYear from RAMX.dbo.tbRAM_PTC_HCC_DESC where PaymentYear > 2017 AND HCCNumber=19", ConfigFile.RAMXdb, recordIndex);
                providerID = singleColumnQueryExecutionSelectRecordBasedOnIndex("select txtProviderID from RAMX.dbo.tbProvider where txtFirst !=' ' AND txtlast !=' '", ConfigFile.RAMXdb, recordIndex);
                firstName = singleColumnQueryExecutionSelectRecordBasedOnIndex("select txtFirst from ramx.dbo.tbProvider where txtFirst !=' ' AND txtlast !=' '", ConfigFile.RAMXdb, recordIndex);
                lastName = singleColumnQueryExecutionSelectRecordBasedOnIndex("select txtlast from ramx.dbo.tbProvider where txtFirst !=' ' AND txtlast !=' '", ConfigFile.RAMXdb, recordIndex);
                providerName = firstName.Trim() + " " + lastName.Trim();
                output = new string[][]{new string[]{ "HIC Num", "Member ID", "HCC", "Payment Year", "Provider ID", "Provider Name" },
                new string[]{ HICNumber, MemberID, HCC,paymentYear,providerID,providerName}};
            }

            fw.ConsoleReport(" Member ID -->" + MemberID);
            fw.ConsoleReport(" HICNumber -->" + HICNumber);
            fw.ConsoleReport(" HCC -->" + HCC);
            fw.ConsoleReport(" PaymentYear -->" + paymentYear);
            fw.ConsoleReport(" ProviderID -->" + providerID);
            fw.ConsoleReport(" First Name -->" + firstName);
            fw.ConsoleReport(" Last Name -->" + lastName);
            fw.ConsoleReport(" Provider Name -->" + providerName);

            GlobalRef.MemberID = MemberID;
            GlobalRef.ProviderID = providerID;


            string path = @"C:\temp\" + fileName;

            // string Header = "HIC Num,Member ID,HCC,Payment Year,Provider ID,Provider Name"+ Environment.NewLine;

            //string[][] output = new string[][]{new string[]{ "HIC Num", "Member ID", "HCC", "Payment Year", "Provider ID", "Provider Name" },
            // new string[]{ HICNumber, MemberID, HCC,paymentYear,providerID,providerName}};
            //string delimiter = delimiterchar;


            if (!File.Exists(path))
            {

                int length = output.GetLength(0);
                StringBuilder sb = new StringBuilder();
                for (int index = 0; index < length; index++)
                    sb.AppendLine(string.Join(delimiter, output[index]));
                File.WriteAllText(path, sb.ToString());
            }


        }



        [When(@"Create Simple Valid CSV file as ""(.*)"" with valid chart ID(.*) as ""(.*)"" and Valid chartID(.*) as ""(.*)""")]
        public void WhenCreateSimpleValidCSVFileAsWithValidChartIDAsAndValidChartIDAs(string p0, int p1, string p2, int p3, string p4)
        {
            string fileName = tmsCommon.GenerateData(p0);
            string chart1 = tmsCommon.GenerateData(p2);
            string chart2 = tmsCommon.GenerateData(p4);


            string path = @"C:\temp\" + fileName;


            if (!File.Exists(path))
            {

                string createChartIDs = chart1 + Environment.NewLine + chart2;
                File.WriteAllText(path, createChartIDs);
            }
        }


        [When(@"Create Simple Valid CSV file as ""(.*)"" with multiple chartID as ""(.*)"" and ""(.*)"" and ""(.*)""")]
        public void WhenCreateSimpleValidCSVFileAsWithMultipleChartIDAsAndAnd(string p0, string p1, string p2, string p3)
        {
            string fileName = tmsCommon.GenerateData(p0);
            string chart1 = tmsCommon.GenerateData(p1);
            string chart2 = tmsCommon.GenerateData(p2);
            string chart3 = tmsCommon.GenerateData(p3);

            string path = @"C:\temp\" + fileName;

            if (!File.Exists(path))
            {
                string createChartIDs = chart1 + Environment.NewLine + chart2 + Environment.NewLine + chart3;
                File.WriteAllText(path, createChartIDs);
            }
        }

        [When(@"Create Valid CSV file as ""(.*)"" with valid chart ID(.*) as ""(.*)"" and Valid chartID(.*) as ""(.*)""")]
        public void WhenCreateValidCSVFileAsWithValidChartIDAsAndValidChartIDAs(string p0, int p1, string p2, int p3, string p4)
        {

            string fileName = tmsCommon.GenerateData(p0);
            string chart1 = tmsCommon.GenerateData(p2);
            string chart2 = tmsCommon.GenerateData(p4);


            string path = @"C:\temp\" + fileName;


            if (!File.Exists(path))
            {

                string createChartIDs = chart1 + Environment.NewLine + chart2;
                File.WriteAllText(path, createChartIDs);
            }
        }



        [When(@"Create Simple Valid CSV file as ""(.*)"" with valid chart ID(.*) as ""(.*)"" and Valid chartID(.*) as ""(.*)"" On chartID(.*) as ""(.*)""")]
        public void WhenCreateSimpleValidCSVFileAsWithValidChartIDAsAndValidChartIDAsOnChartIDAs(string p0, int p1, string p2, int p3, string p4, int p5, string p6)
        {

            string fileName = tmsCommon.GenerateData(p0);
            string chart1 = tmsCommon.GenerateData(p2);
            string chart2 = tmsCommon.GenerateData(p4);
            string chart3 = tmsCommon.GenerateData(p6);

            string path = @"C:\temp\" + fileName;


            if (!File.Exists(path))
            {

                string createChartIDs = chart1 + Environment.NewLine + chart2 + Environment.NewLine + chart3;
                File.WriteAllText(path, createChartIDs);
            }
        }

        [When(@"Create Simple Valid CSV file as ""(.*)"" with valid chartID as ""(.*)""")]
        [Then(@"Create Simple Valid CSV file as ""(.*)"" with valid chartID as ""(.*)""")]
        [Given(@"Create Simple Valid CSV file as ""(.*)"" with valid chartID as ""(.*)""")]
        public void WhenCreateSimpleValidCSVFileAsWithValidChartIDAs(string p0, string p1)
        {
            string fileName = tmsCommon.GenerateData(p0);
            string chartValue = tmsCommon.GenerateData(p1);
            string path = @"C:\temp\" + fileName;

            if (!File.Exists(path))
            {
                File.WriteAllText(path, chartValue);
            }
        }

        [When(@"Create Simple Flag for Audit Review CSV File As ""(.*)"" With Valid ChartID As ""(.*)""")]
        public void WhenCreateSimpleFlagForAuditReviewCSVFileAsWithValidChartIDAs(string p0, string p1)
        {
            string fileName = tmsCommon.GenerateData(p0);
            string chartValue = tmsCommon.GenerateData(p1);
            string path = @"C:\Temp\" + fileName;

            if (!File.Exists(path))
            {
                File.WriteAllText(path, chartValue);
            }
        }

        [When(@"on Auditor Review page i select file name ""(.*)"" in File Name dropdown")]
        public void WhenOnAuditorReviewPageISelectFileNameInFileNameDropdown(string p0)
        {
            tmsWait.Hard(15);
            Browser.Wd.FindElement(By.XPath("//*[@aria-owns='auditorReviewFileNames_listbox']")).Click();
            tmsWait.Hard(1);
            string fileName = tmsCommon.GenerateData(p0);
            IWebElement Reprtname_option = Browser.Wd.FindElement(By.XPath("//*[@id='auditorReviewFileNames_listbox']/li[contains(.,'" + fileName + "')]"));
            Reprtname_option.Click();
            tmsWait.Hard(1);
        }



        [When(@"on Auditor Review page i select Date Loaded ""(.*)"" is set to ""(.*)""")]
        public void WhenOnAuditorReviewPageISelectDateLoadedIsSetTo(string p0, string p1)
        {
            string datetype = tmsCommon.GenerateData(p0);
            switch (datetype.ToLower())
            {
                case "from":
                    string dd = DateTime.Now.AddDays(-1).ToString("MM/dd/yyyy");
                    IWebElement fromdate = Browser.Wd.FindElement(By.XPath("//input[@test-id='auditorReview-file-txt-fromdate']"));
                    fromdate.Clear();
                    fromdate.SendKeys(dd); break;
                case "to":
                    string dt = DateTime.Now.ToString("MM/dd/yyyy");
                    IWebElement todate = Browser.Wd.FindElement(By.XPath("//input[@test-id='auditorReview-txt-ToDate']"));
                    todate.Clear();
                    todate.SendKeys(dt); break;
            }
        }


        [When(@"Auditor Review page ""(.*)"" Date is set to ""(.*)""")]
        public void WhenAuditorReviewPageDateIsSetTo(string p0, string p1)
        {

            string datetype = tmsCommon.GenerateData(p0);
            string adate = tmsCommon.GenerateData(p1);
            switch (datetype.ToLower())
            {
                case "from": string dt = DateTime.Now.ToString("MM/dd/yyyy");
                    IWebElement fdate = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='auditorReview-date-fromdate']//span[@role='button']"));
                    AngularFunction.enterDate(fdate, dt);
                    break;
                case "to": break;
            }
        }


        [When(@"Auditor Review page From Date is set to ""(.*)""")]
        public void WhenAuditorReviewPageFromDateIsSetTo(string p0)
        {
            string datetype = tmsCommon.GenerateData(p0);
            string dt = DateTime.Now.ToString("MM/dd/yyyy");
            IWebElement fdate = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='auditorReview-date-fromdate']//span[@role='button']"));

            if(datetype.ToLower()=="todays")
            {
                AngularFunction.enterDate(fdate, dt);
            }

            else
            {
                AngularFunction.enterDate(fdate, datetype);
            }
               
        }

        [When(@"Auditor Review page enter To date less than from date ""(.*)"" and Verify Message ""(.*)""")]
        public void WhenAuditorReviewPageEnterToDateLessThanFromDateAndVerifyMessage(string p0, string p1)
        {
            string datetype = tmsCommon.GenerateData(p0);
            string expectedMessage = tmsCommon.GenerateData(p1);
            string dt = DateTime.Now.AddDays(-1).ToString("MM/dd/yyyy");
            IWebElement fdate = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='auditorReview-date-dtTerminationDate']//span[@role='button']"));
            AngularFunction.enterDate(fdate, dt);
            tmsWait.Hard(1);
            By toastMsg = By.XPath("//div[@class='k-notification-content']");
            string actualValue = Browser.Wd.FindElement(toastMsg).Text;
            Assert.IsTrue(actualValue.Contains(expectedMessage), "Expected message is not displayed");
        }


        [When(@"Auditor Review page enter Invalid ""(.*)"" date")]
        public void WhenAuditorReviewPageEnterInvalidDate(string p0)
        {
            string datetype = tmsCommon.GenerateData(p0);
            switch(datetype.ToLower())
            {
                case "from":
                    RAM.RAMAuditorReview.FileRadioButton.SendKeys(Keys.Tab);
                   IWebElement fdate = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='auditorReview-date-fromdate']//input"));
                    tmsWait.Hard(1);
                    fdate.SendKeys("01/01/0999");
                    break;
                case "to":
                    IWebElement todate = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='auditorReview-date-dtTerminationDate']//input"));
                    tmsWait.Hard(1);
                    todate.SendKeys("01/01/0999");
                    break;

            }
    }

        [Then(@"Verify Invalid ""(.*)"" date message ""(.*)""")]
        public void ThenVerifyInvalidDateMessage(string p0, string p1)
        {
            string datetype = tmsCommon.GenerateData(p0);
            string expectedMessage = tmsCommon.GenerateData(p1);

            string actualMsg = Browser.Wd.FindElement(By.XPath("//span[@id='txt" + datetype + "Date-error-msg']")).Text;
            Assert.IsTrue(actualMsg.Contains(expectedMessage), "Error Message is not displayed");

        }

        [When(@"Auditor Review page Search button is click")]
        public void WhenAuditorReviewPageSearchButtonIsClick()
        {
            fw.ExecuteJavascript(RAM.RAMAuditorReview.AuditorReviewSearchButton);
        }



        [When(@"Auditor Review page Search button is click and Verify Message ""(.*)""")]
        public void WhenAuditorReviewPageSearchButtonIsClickAndVerifyMessage(string p0)
        {
            string expectedMessage = tmsCommon.GenerateData(p0);
            tmsWait.Hard(6);
            fw.ExecuteJavascript(RAM.RAMAuditorReview.AuditorReviewSearchButton);
            By toastMsg = By.XPath("//div[@class='k-notification-content']");
            string actualValue = Browser.Wd.FindElement(toastMsg).Text;
            Assert.IsTrue(actualValue.Contains(expectedMessage), "Expected message is not displayed");
            tmsWait.Hard(3);
        }



        [When(@"on Auditor Review page i click on search button")]
        public void WhenOnAuditorReviewPageIClickOnSearchButton()
        {
            tmsWait.Hard(1);
            Browser.Wd.FindElement(By.XPath("//*[@test-id='auditorReview-btn-filesearch']")).Click();
            tmsWait.Hard(1);
        }



        [Then(@"verify on Administration-FlagforAudit page Fallout Records value should be ""(.*)"" for File Name ""(.*)""")]
        public void ThenVerifyOnAdministration_FlagforAuditPageFalloutRecordsValueShouldBeForFileName(string p0, string p1)
        {
            string fileName = tmsCommon.GenerateData(p1);
            string expFalloutRecords = tmsCommon.GenerateData(p0);
            string actualValue = Browser.Wd.FindElement(By.XPath("//*[@id='grdRuleUploadFileList']/table/tbody/tr[contains(.,'" + fileName + "')]/td[5]")).Text;
            Assert.AreEqual(expFalloutRecords, actualValue, "Fallout record count is not as expected");
        }



        [Then(@"Create Simple Valid CSV file as ""(.*)"" with valid chart ID(.*) as ""(.*)"" and Valid chartID(.*) as ""(.*)""")]
        public void ThenCreateSimpleValidCSVFileAsWithValidChartIDAsAndValidChartIDAs(string p0, int p1, string p2, int p3, string p4)
        {
            string fileName = tmsCommon.GenerateData(p0);
            string chart1 = tmsCommon.GenerateData(p2);
            string chart2 = tmsCommon.GenerateData(p4);

            string path = @"C:\temp\" + fileName;

            string delimiter = ", ";

            if (!File.Exists(path))
            {

                string createChartIDs = chart1 + Environment.NewLine + chart2;
                File.WriteAllText(path, createChartIDs);
            }
        }

        [When(@"Enter New Diagnosis Data page Click on Save button")]
        public void WhenEnterNewDiagnosisDataPageClickOnSaveButton()
        {
            By save = By.XPath("(//button[contains(.,'SAVE')])[1]");
            fw.ExecuteJavascript(Browser.Wd.FindElement(save));
            tmsWait.Hard(1);
        }

        [When(@"Enter New Diagnosis Data page Click on Save and Replicate button")]
        public void WhenEnterNewDiagnosisDataPageClickOnSaveAndReplicateButton()
        {
            By save = By.XPath("(//button[contains(.,'SAVE')])[2]");
            fw.ExecuteJavascript(Browser.Wd.FindElement(save));
        }


        [When(@"Enter New Diagnosis Data page Click on Save and Replicate button and verify message ""(.*)""")]
        public void WhenEnterNewDiagnosisDataPageClickOnSaveAndReplicateButtonAndVerifyMessage(string p0)
        {
            string expectedValue = tmsCommon.GenerateData(p0);
            By save = By.XPath("(//button[contains(.,'SAVE')])[2]");
            fw.ExecuteJavascript(Browser.Wd.FindElement(save));
            tmsWait.Hard(1);
            // string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
            By toastMsg = By.XPath("//div[@class='k-notification-content']");
            string actualValue = Browser.Wd.FindElement(toastMsg).Text;
            Assert.IsTrue(actualValue.Contains(expectedValue));
        }


        [Then(@"Verify RAMX Application Enter New Diagnosis Data page displayed Diagnosis code as ""(.*)"" Provider ID as ""(.*)"" Claim Number as ""(.*)"" Chart ID as ""(.*)"" Reference Information as ""(.*)"" On Hold Reason as ""(.*)""")]
        public void ThenVerifyRAMXApplicationEnterNewDiagnosisDataPageDisplayedDiagnosisCodeAsProviderIDAsClaimNumberAsChartIDAsReferenceInformationAsOnHoldReasonAs(string p0, string p1, string p2, string p3, string p4, string p5)
        {
            string expDiagcode = tmsCommon.GenerateData(p0);
            string expprovider = tmsCommon.GenerateData(p1);
            string expclaim = tmsCommon.GenerateData(p2);
            string expchart = tmsCommon.GenerateData(p3);
            string expreferenceinfo = tmsCommon.GenerateData(p4);
            string expOnholdreason = tmsCommon.GenerateData(p5);
            tmsWait.Hard(2);
            //By res = By.XPath("//div[@test-id='searchDiag-grid-member']//td[contains(.,'" + expDiagcode + "')]/following-sibling::td[contains(.,'" + expprovider + "')]/following-sibling::td[contains(.,'" + expclaim + "')]/following-sibling::td[contains(.,'" + expchart + "')]/following-sibling::td[contains(.,'" + expreferenceinfo + "')]/following-sibling::td[contains(.,'" + expOnholdreason + "')]");
            By res=  By.XPath("//kendo-grid[@test-id='searchDiag-grid-member']//td[contains(.,'" + expDiagcode + "')]/following-sibling::td[contains(.,'" + expprovider + "')]/following-sibling::td[contains(.,'" + expclaim + "')]/following-sibling::td[contains(.,'" + expchart + "')]/following-sibling::td[contains(.,'" + expOnholdreason + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(res);
        }


        [Then(@"Verify RAMX Enter New Diagnosis Data page displayed Diagnosis code as ""(.*)"" Provider ID as ""(.*)"" Claim Number as ""(.*)"" Chart ID as ""(.*)"" Reference Information as ""(.*)""")]
        public void ThenVerifyRAMXEnterNewDiagnosisDataPageDisplayedDiagnosisCodeAsProviderIDAsClaimNumberAsChartIDAsReferenceInformationAs(string p0, string p1, string p2, string p3, string p4)
        {
            string expDiagcode = tmsCommon.GenerateData(p0);
            string expprovider = tmsCommon.GenerateData(p1);
            string expclaim = tmsCommon.GenerateData(p2);
            string expchart = tmsCommon.GenerateData(p3);
            string expreferenceinfo = tmsCommon.GenerateData(p4);

            tmsWait.Hard(2);
            By res = By.XPath("//div[@test-id='searchDiag-grid-member']//td[contains(.,'" + expDiagcode + "')]/following-sibling::td[contains(.,'" + expprovider + "')]/following-sibling::td[contains(.,'" + expclaim + "')]/following-sibling::td[contains(.,'" + expchart + "')]/following-sibling::td[contains(.,'" + expreferenceinfo + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(res);
        }

        [When(@"Enter New Diagnosis Data page Enable On-Hold checkbox is Checked")]
        public void WhenEnterNewDiagnosisDataPageEnableOn_HoldCheckboxIsChecked()
        {
            By OnHold = By.CssSelector("[test-id='searchDiag-lbl-lblIsEnableOnHold']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(OnHold));
        }

        [Then(@"Verify Enter New Diagnosis Data page displayed Chart ID as ""(.*)"" Diagnosis Code as ""(.*)""")]
        public void ThenVerifyEnterNewDiagnosisDataPageDisplayedChartIDAsDiagnosisCodeAs(string p0, string p1)
        {
            tmsWait.Hard(4);
            string chartID = tmsCommon.GenerateData(p0);
            string diagCode = tmsCommon.GenerateData(p1);
            By data = By.XPath("//kendo-grid[@test-id='searchDiag-grid-member']//td[contains(.,'" + diagCode + "')]/following-sibling::td[contains(.,'" + chartID + "')]");
            bool results = Browser.Wd.FindElement(data).Displayed;
            Assert.IsTrue(results, " Expected data is not getting displayed");

        }


        [When(@"Enter New Diagnosis Data page Select any Reason")]
        public void WhenEnterNewDiagnosisDataPageSelectAnyReason()
        {
            //By drp = By.CssSelector("[aria-owns='ddlonHoldReason_listbox']");
            //fw.ExecuteJavascript(Browser.Wd.FindElement(drp));
            //tmsWait.Hard(1);
            //By value = By.XPath("(//ul[@id='ddlonHoldReason_listbox']//li)[2]");
            //fw.ExecuteJavascript(Browser.Wd.FindElement(value));

            By Drp = By.XPath("//kendo-dropdownlist[@id='ddlonHoldReason']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='Questions for supervisor']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }



    }
}
