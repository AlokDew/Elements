﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.HCC_RAM
{
    [Binding]
    class fsProviderLookup
    {
        [When(@"RAM Main menu Manage Suspects submenu is Clicked")]
        public void WhenRAMMainMenuManageSuspectsSubmenuIsClicked()
        {

            IWebElement main = Browser.Wd.FindElement(By.XPath("//a[@title='Main']"));
            fw.ExecuteJavascript(main);
            tmsWait.Hard(1);
            IWebElement suspectMenu = Browser.Wd.FindElement(By.XPath("//a[@title='Manage Suspects']"));
            fw.ExecuteJavascript(suspectMenu);
        }

        [Given(@"""(.*)"" is set to the value returned from RAM Application Dashboard")]
        public void GivenIsSetToTheValueReturnedFromRAMApplicationDashboard(string p0)
        {
            tmsWait.Implicit(10);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@test-id='ramDashboard-lbl-lastDataLoad']"));
            string[] onlydate = ele.Text.Split(' ');
            string lastdataload = onlydate[0];
            fw.setVariable(p0, lastdataload);
            GlobalRef.ActualLoadDate= lastdataload;
        }

        [Given(@"""(.*)"" is set to the value returned from RAMX Application Dashboard")]
        [When(@"""(.*)"" is set to the value returned from RAMX Application Dashboard")]
        public void GivenIsSetToTheValueReturnedFromRAMXApplicationDashboard(string p0)
        {
            tmsWait.Implicit(10);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//label[@test-id='ramxDashboard-lbl-lastDataLoad']"));
            tmsWait.Implicit(2);
            string lastdataload = ele.Text.ToString();
            fw.setVariable(p0, lastdataload);
            GlobalRef.ActualLoadDate= lastdataload;
        }

        [When(@"I verify database ""(.*)"" results")]
        public void WhenIVerifyDatabaseResults(string p0)
        {
            string dt = db.StoreDBResultsInString(p0);
            string[] onlydate = dt.Split(' ');
           string lastdataload = onlydate[0];
            string actualdate = GlobalRef.ActualLoadDate.ToString();
            string[] acdate = actualdate.Split(' ');
            string[] exd = actualdate.Split('/');
            if(exd[0].StartsWith("0"))
            {
                 lastdataload = "0" + onlydate[0];
            }
             
            string ExpDate = Convert.ToDateTime(dt).ToString("MM/dd/yyyy");
            Assert.AreEqual(ExpDate, acdate[0], "LoadDate is not matching with the date in database ");
        }


        [When(@"verify database ""(.*)"" results should match with UI values for Plan Id ""(.*)""")]
        public void WhenVerifyDatabaseResultsShouldMatchWithUIValuesForPlanId(string p0, string p1)
        {
            string result = db.StoreDBResultsInString(p0);
            string planId = tmsCommon.GenerateData(p1);
            string[] dbResults = result.Split('|');

            Console.Write("Suspect count in DB table : "+ dbResults[0]);
            Console.Write("Revenue Amount/Financial Impact value in DB table : " + dbResults[1]);

            string expSuspectCount = dbResults[0].ToString();
            double expFinImpact = Math.Round(Convert.ToDouble(dbResults[1]));
            string actualSuspectCount = Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='ramxDashboard-grid-suspectSummary']//td[contains(.,'" + planId + "')]//parent::td//following-sibling::td)[1]")).Text;
            
            string finImpact = Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='ramxDashboard-grid-suspectSummary']//td[contains(.,'" + planId + "')]//parent::td//following-sibling::td)[2]")).Text;

            //Verifyting the value on UI and comparing it with value returned from database
            double actualFinImpact = double.Parse(finImpact, NumberStyles.Currency);
            Assert.AreEqual(expSuspectCount, actualSuspectCount, "Suspect count do not match");
            Assert.AreEqual(expFinImpact, actualFinImpact, "Financial Impact values do not match");

            //Checking the format of Financial Impact values on RAMX application
            //string expFinImpact_formatted = string.Format(CultureInfo.GetCultureInfo("en-US"), "{0:C0}", expFinImpact);
            //Assert.IsTrue(expFinImpact_formatted.Contains(finImpact), "Formatting of Financial Impact value is not correct");

        }


        [Then(@"verify database value for output ""(.*)""")]
        public void ThenVerifyDatabaseValueForOutput(string p0)
        {
            string expdt = Convert.ToDateTime(p0).ToString("yyyy-MM-dd HH:mm:ss");
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@test-id='ramDashboard-lbl-lastDataLoad']"));
            DateTime lastdataload = Convert.ToDateTime(ele.Text);
            string actdt = lastdataload.ToString("yyyy-MM-dd HH:mm");
            Console.Write(actdt, expdt);
        }
        [Then(@"on RAMX dashboard page I select Payment Year as ""(.*)""")]
        [When(@"on RAM dashboard page I select Payment Year as ""(.*)""")]
        [Given(@"on RAM dashboard page I select Payment Year as ""(.*)""")]
        public void GivenOnRAMDashboardPageISelectPaymentYearAs(string p0)
        {
            string GeneratedPayYear = tmsCommon.GenerateData(p0);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='ramDashboard-select-paymentYear']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + GeneratedPayYear + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }
        [Then(@"on RAMX dashboard page I select Payment Year as ""(.*)""")]
        [Given(@"on RAMX dashboard page I select Payment Year as ""(.*)""")]
        [When(@"on RAMX dashboard page I select Payment Year as ""(.*)""")]
        public void GivenOnRAMXDashboardPageISelectPaymentYearAs(string p0)
        {
            string GeneratedPayYear = tmsCommon.GenerateData(p0);
            //IWebElement drpdown = Browser.Wd.FindElement(By.XPath("//*[@test-id='ramxDashboard-select-paymentYear']"));
            //SelectElement PaymentYear = new SelectElement(drpdown);
            //PaymentYear.SelectByText(GeneratedPayYear);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='ramxDashboard-select-paymentYear']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='2018']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }
        [Given(@"on RAM dashboard page verify Risk Score chart is displayed")]
        [Then(@"on RAM dashboard page verify Risk Score chart is displayed")]
        [When(@"on RAM dashboard page verify Risk Score chart is displayed")]
        public void GivenOnRAMDashboardPageVerifyRiskScoreChartIsDisplayed()
        {
            IWebElement riskScoreChart= Browser.Wd.FindElement(By.XPath("//*[@test-id='ramDashboard-dv-riskScoreChart']"));
            Assert.IsTrue(riskScoreChart.Displayed, "Risk Score Chart is not displayed");
        }
        [When(@"on RAM dashboard page verify Revenue chart is displayed")]
        [Then(@"on RAM dashboard page verify Revenue chart is displayed")]
        [Given(@"on RAM dashboard page verify Revenue chart is displayed")]
        public void GivenOnRAMDashboardPageVerifyRevenueChartIsDisplayed()
        {
            IWebElement riskScoreChart = Browser.Wd.FindElement(By.XPath("//*[@test-id='ramDashboard-dv-revenueChart']"));
            Assert.IsTrue(riskScoreChart.Displayed, "Revenue Chart is not displayed");
        }

       
        [Then(@"i click on Risk Score chart")]
        public void ThenWhenIClickOnRiskScoreChart()
        {
            //IWebElement RiskScoreBar = Browser.Wd.FindElement(By.CssSelector("#riskScoreChart > svg > g > g:nth-child(3) > g:nth-child(4) > g > g:nth-child(1) > g:nth-child(2) > path:nth-child(1)"));
            IWebElement RiskScoreBar = Browser.Wd.FindElement(By.XPath("(//kendo-chart[@test-id='ramDashboard-dv-riskScoreChart']//*[@fill[contains(.,'url')]])[1]"));

            tmsWait.Hard(3);
            Actions actions = new Actions(Browser.Wd);
            actions.Click(RiskScoreBar).ContextClick().Perform();
            tmsWait.Implicit(20);
        }

        [Then(@"Search Criteria page File Type option ""(.*)"" option is clicked")]
        public void ThenSearchCriteriaPageFileTypeOptionOptionIsClicked(string p0)
        {
            IWebElement ele = null;

            switch (p0)
            {
                case "Comma Delimited":
                    ele = Browser.Wd.FindElement(By.Id("commaDelimied"));
                    break;
                case "Pipe Delimited":
                    ele = Browser.Wd.FindElement(By.Id("pipeDelimied"));
                    break;
                case "Tab Delimited":
                    ele = Browser.Wd.FindElement(By.Id("tabDelimied"));
                    break;
            }
            fw.ExecuteJavascript(ele);

        }

        [Then(@"i click on Import button")]
        public void ThenIClickOnImportButton()
        {
            tmsWait.Hard(2);
            IWebElement ele = Browser.Wd.FindElement(By.Id("btnImport"));
            fw.ExecuteJavascript(ele);

        }

        
        [Then(@"i click on Revenue chart")]
        public void ThenIClickOnRevenueChart()
        {
            //IWebElement RevenueBar = Browser.Wd.FindElement(By.CssSelector("#revenueScoreChart > svg > g > g:nth-child(3) > g:nth-child(4) > g > g:nth-child(1) > g:nth-child(2)> path:nth-child(1)"));
            IWebElement RevenueBar = Browser.Wd.FindElement(By.XPath("(//kendo-chart[@test-id='ramDashboard-dv-revenueChart']//*[@fill[contains(.,'url')]])[1]"));

            tmsWait.Hard(3);
            Actions actions = new Actions(Browser.Wd);
            actions.Click(RevenueBar).ContextClick().Perform();
            tmsWait.Implicit(20);
        }
        [Then(@"on RAM dashboard page verify row count in Provider Summary table")]
        [When(@"on RAM dashboard page verify row count in Provider Summary table")]
        [When(@"on RAMX dashboard page verify row count in Provider Summary table")]
        [Given(@"on RAM dashboard page verify row count in Provider Summary table")]
        [Given(@"on RAMX dashboard page verify row count in Provider Summary table")]
        public void GivenOnRAMDashboardPageVerifyRowCountInProviderSummaryTable()
        {
            tmsWait.Hard(2);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='ramDashboard-grid-providerSummary']//kendo-grid-list//table/tbody"));
            IList<IWebElement> rows = ele.FindElements(By.TagName("tr"));
            Assert.AreEqual(5, rows.Count, "Provider Summary row count is not 5");
       }
        [When(@"on RAM dashboard page verify provider names based on suspect count")]
        public void WhenOnRAMDashboardPageVerifyProviderNamesBasedOnSuspectCount()
        {
            tmsWait.Hard(2);
            IList<int> suspectCountList = new List<int>();

            IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='ramDashboard-grid-providerSummary']//kendo-grid-list//table/tbody"));
            IList<IWebElement> rows = ele.FindElements(By.TagName("tr"));
            for (int i = 0; i < rows.Count; i++)
            {
                IList<IWebElement> cols = rows[i].FindElements(By.TagName("td"));
                int suspectcnt = Convert.ToInt32(cols[1].Text);
                suspectCountList.Add(suspectcnt);
            }
            for (int j = 1; j < suspectCountList.Count; j++)
            {
                if (suspectCountList[j - 1] < suspectCountList[j])
                {
                    Assert.Fail("Provider names are NOT ordered based on Suspect count");
                }
            }
            Console.Write("Provider names are ordered based on Suspect count");
        }


        [When(@"verify Provider names are displayed based on Suspect count")]
        [Then(@"verify Provider names are displayed based on Suspect count")]
        [Given(@"verify Provider names are displayed based on Suspect count")]
        public void GivenVerifyProviderNamesAreDisplayedBasedOnSuspectCount()
        {
            tmsWait.Hard(2);
            IList<int> suspectCountList = new List<int>();

            //IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@id='ProviderSummaryData']/div[2]/table/tbody"));

            IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='ramxDashboard-grid-providerSummary']//kendo-grid-list//table/tbody"));
            IList<IWebElement> rows = ele.FindElements(By.TagName("tr"));
            for (int i = 0; i < rows.Count; i++)
            {
                IList<IWebElement> cols = rows[i].FindElements(By.TagName("td"));
                int suspectcnt = Convert.ToInt32(cols[1].Text);
                suspectCountList.Add(suspectcnt);
            }
            for (int j = 1; j < suspectCountList.Count; j++) {
                    if (suspectCountList[j-1] < suspectCountList[j]) {
                    Assert.Fail("Provider names are NOT ordered based on Suspect count");
                    }
            }
            Console.Write("Provider names are ordered based on Suspect count");
        }

        [When(@"on RAM dashboard page verify Plan Ids based on suspect count")]
        public void WhenOnRAMDashboardPageVerifyPlanIdsBasedOnSuspectCount()
        {
            tmsWait.Hard(2);
            IList<int> suspectCountList = new List<int>();

            IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='ramDashboard-lbl-suspectSummary']//kendo-grid-list//table/tbody"));
            IList<IWebElement> rows = ele.FindElements(By.TagName("tr"));
            for (int i = 0; i < rows.Count; i++)
            {
                IList<IWebElement> cols = rows[i].FindElements(By.TagName("td"));
                int suspectcnt = Convert.ToInt32(cols[1].Text);
                suspectCountList.Add(suspectcnt);
            }
            for (int j = 1; j < suspectCountList.Count; j++)
            {
                if (suspectCountList[j - 1] < suspectCountList[j])
                {
                    Assert.Fail("Plan Ids are NOT displayed based on Suspect count");
                }
            }
            Console.Write("Plan Ids are NOT displayed based on Suspect count");
        }


        [When(@"verify Plan Ids are displayed based on Suspect count")]
        [Given(@"verify Plan Ids are displayed based on Suspect count")]
        public void GivenVerifyPlanIdsAreDisplayedBasedOnSuspectCount()
        {
            tmsWait.Hard(2);
            IList<int> suspectCountList = new List<int>();

            IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='ramxDashboard-grid-suspectSummary']//kendo-grid-list//table/tbody"));
            IList<IWebElement> rows = ele.FindElements(By.TagName("tr"));
            for (int i = 0; i < rows.Count; i++)
            {
                IList<IWebElement> cols = rows[i].FindElements(By.TagName("td"));
                int suspectcnt = Convert.ToInt32(cols[1].Text);
                suspectCountList.Add(suspectcnt);
            }
            for (int j = 1; j < suspectCountList.Count; j++)
            {
                if (suspectCountList[j - 1] < suspectCountList[j])
                {
                    Assert.Fail("Provider names are NOT ordered based on Suspect count");
                }
            }
            Console.Write("Provider names are ordered based on Suspect count");
        }

        [When(@"I select PlanID dropdown value as ""(.*)""")]

        [Given(@"I select PlanID dropdown value as ""(.*)""")]
        public void GivenISelectPlanIDDropdownValueAs(string p0)
        {
            string GeneratedValue = tmsCommon.GenerateData(p0);
            //IWebElement drpdown = Browser.Wd.FindElement(By.XPath("//*[@test-id='ramxDashboard-select-plan']"));
            //SelectElement PlanID = new SelectElement(drpdown);
            //PlanID.SelectByText(GeneratedValue);
            By Drp = By.XPath("//label[text()='Plan ID: ']/parent::div//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + GeneratedValue + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }
        [Given(@"I select RAMX Dashboard PlanID dropdown value as ""(.*)""")]
        [When(@"I select RAMX Dashboard PlanID dropdown value as ""(.*)""")]
        public void GivenISelectRAMXPlanIDDropdownValueAs(string p0)
        {
            string GeneratedValue = tmsCommon.GenerateData(p0);
            //IWebElement drpdown = Browser.Wd.FindElement(By.XPath("//*[@test-id='ramxDashboard-select-plan']"));
            //SelectElement PlanID = new SelectElement(drpdown);
            //PlanID.SelectByText(GeneratedValue);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='ramxDashboard-select-plan']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + GeneratedValue + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }
        [When(@"I click on Suspect Count link in Provider Summary table")]
        [Then(@"I click on Suspect Count link in Provider Summary table")]
        [Given(@"I click on Suspect Count link in Provider Summary table")]
        public void GivenIClickOnSuspectCountLinkInProviderSummaryTable()
        {
            //These are commented because they only work for RAMX.  Following two lines work for both RAM and RAMX - William Kennedy 2/14/2021
            //IWebElement suspectcnt = Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='ramxDashboard-grid-providerSummary']//td/a)[1]"));
            //IWebElement providerName = Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='ramxDashboard-grid-providerSummary']//td)[1]"));
            IWebElement suspectcnt = Browser.Wd.FindElement(By.XPath("(//kendo-grid[contains(.,'Provider Name')]//td//a)[1]"));
            IWebElement providerName = Browser.Wd.FindElement(By.XPath("(//kendo-grid[contains(.,'Provider Name')]//td)[1]"));

            GlobalRef.ProviderName = providerName.Text;
            GlobalRef.SuspectCount = suspectcnt.Text;
            fw.ExecuteJavascript(suspectcnt);
            tmsWait.Implicit(10);
        }
        [Then(@"I click on Suspect Count link in Suspect Summary table")]
        [When(@"I click on Suspect Count link in Suspect Summary table")]
        [Given(@"I click on Suspect Count link in Suspect Summary table")]
        public void GivenIClickOnSuspectCountLinkInSuspectSummaryTable()
        {
            IWebElement suspectcount = Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='ramDashboard-lbl-suspectSummary']//td/a)[1]"));
            IWebElement PlanIDvalue = Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='ramDashboard-lbl-suspectSummary']//td)[1]"));
            GlobalRef.SuspectSummary_PlanID = PlanIDvalue.Text;
            GlobalRef.SuspectSummary_SuspectCount = suspectcount.Text;
            fw.ExecuteJavascript(suspectcount);
            tmsWait.Implicit(10);
        }
        [When(@"verify Plan dropdown value is set to ""(.*)""")]
        [Then(@"verify Plan dropdown value is set to ""(.*)""")]
        [Given(@"verify Plan dropdown value is set to ""(.*)""")]
        public void GivenVerifyPlanDropdownValueIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            bool elementpresence = false;
            elementpresence = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='PlanId']//span[contains(.,'" + value + "')]")).Displayed;
            Assert.IsTrue(elementpresence, "Element is not present");
        }


        [Then(@"verify Plan dropdown value on Suspects Summary page is set to ""(.*)""")]
        [When(@"verify Plan dropdown value on Suspects Summary page is set to ""(.*)""")]
        [Given(@"verify Plan dropdown value on Suspects Summary page is set to ""(.*)""")]
        public void GivenVerifyPlanDropdownValueOnSuspectsSummaryPageIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            bool elementpresence = Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='PlanID']//span[contains(.,'" + value + "')]")).Displayed;
            Assert.IsTrue(elementpresence, "PlanID Value is incorrect");
        }

        [Given(@"verify PaymentYear dropdown value on Suspects Summary page is set to ""(.*)""")]
        public void GivenVerifyPaymentYearDropdownValueOnSuspectsSummaryPageIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            bool elementpresence = Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='PlanID']//span[contains(.,'" + value + "')]")).Displayed;
            Assert.IsTrue(elementpresence, "PlanID Value is incorrect");
        }


        [Then(@"verify PaymentYear dropdown value is set to ""(.*)""")]
        [When(@"verify PaymentYear dropdown value is set to ""(.*)""")]
        [Given(@"verify PaymentYear dropdown value is set to ""(.*)""")]
        public void GivenVerifyPaymentYearDropdownValueIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            bool elementpresence = false;
            elementpresence = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='PayYear']//span[contains(.,'" + value + "')]")).Displayed;
            Assert.IsTrue(elementpresence, "Element is not present");
        }
        [When(@"verify SuspectType dropdown value is set to ""(.*)""")]
        public void WhenVerifySuspectTypeDropdownValueIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            IWebElement drpdown = Browser.Wd.FindElement(By.XPath("//*[@test-id='Type']"));
            SelectElement SuspectType = new SelectElement(drpdown);
            string SuspectTypeVal = SuspectType.SelectedOption.Text;
            Assert.AreEqual(value, SuspectTypeVal, " Value is incorrect");
        }

        [When(@"verify PaymentYear dropdown value on Suspects Summary report page is set to ""(.*)""")]
        [Given(@"verify PaymentYear dropdown value on Suspects Summary report page is set to ""(.*)""")]
        public void GivenVerifyPaymentYearDropdownValueOnSuspectsSummaryReportPageIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            //IWebElement drpdown = Browser.Wd.FindElement(By.XPath("//*[@test-id='PaymentYear']"));
            //SelectElement PayYear = new SelectElement(drpdown);
            By Drp = By.XPath("//*[@test-id='PaymentYear']//span[@class='k-input']");
            string payyearValue = Browser.Wd.FindElement(Drp).Text;
            Assert.AreEqual(value, payyearValue, "Payment Year Value is incorrect");
        }




        [Given(@"verify ""(.*)"" page is loaded")]
        public void GivenVerifyPageIsLoaded(string p0)
        {
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@test-id='report-title-searchCriteria']"));
            bool result = ele.Text.Contains(p0);
            Assert.IsTrue(result, "Report Page is not loaded");

        }

        [Then(@"verify suspect count is found on the report")]
        public void ThenVerifySuspectCountIsFoundOnTheReport()
        {
            string suspectCountinSummaryTable= GlobalRef.SuspectSummary_SuspectCount.ToString();
            Browser.SwitchToChildWindow();
                       
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//div[@dir= 'LTR']/table/tbody/tr//table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[4]/td[5]/div"));
            string suspectCountText = ele.Text.ToString();
            Assert.AreEqual(suspectCountinSummaryTable, suspectCountText, "Suspect Count on report did not match with suspect count in Summary table");
        }


        [Then(@"verify suspect count for provider name is correct in the report")]
        public void ThenVerifySuspectCountForProviderNameIsCorrectInTheReport()
        {
            bool alertPresent;
            bool flag = false;
            string suspectcount = GlobalRef.SuspectCount.ToString();
            string providerName = GlobalRef.ProviderName.ToString();
            Browser.SwitchToChildWindow();

            IWebElement searchField = Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl05_ctl03_ctl00"));
            IWebElement findLink = Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl05_ctl03_ctl01"));
            providerName = providerName.Replace(" ,", ",");
            providerName = providerName.Substring(0, 3);
            searchField.Clear();
            searchField.SendKeys(providerName.Trim());
            tmsWait.Hard(3);
            fw.ExecuteJavascript(findLink);
            tmsWait.Hard(2);
            tmsWait.Implicit(10);

            alertPresent = IsAlertPresent();
            IWebElement ele;
            IList<IWebElement> rows;

            do
            {

                ele = Browser.Wd.FindElement(By.XPath("//div[@dir= 'LTR']/table/tbody/tr//table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody"));
                rows = ele.FindElements(By.TagName("tr"));
                for (int i = 3; i < rows.Count; i++)
                {
                    /*William Kennedy 2/18/2020 commented the original rows logic, test is no longer stored in the td nodes, using "contains" to find the cells with the text to verify*/
                    //IList<IWebElement> cols = rows[i].FindElements(By.TagName("td"));
                    IWebElement testRow = Browser.Wd.FindElement(By.XPath("//tr/td[contains(.,'" + providerName + "')]/following-sibling::td[contains(.,'" + suspectcount + "')]"));

                    //if (cols[0].Text.Contains(providerName) && cols[1].Text.Contains(suspectcount))
                    if (testRow.Displayed)
                    {
                        flag = true;
                        Assert.IsTrue(true, providerName + "is found on Report");
                        fw.ConsoleReport(providerName + " is found on Report");
                        Assert.IsTrue(true, suspectcount + "is found on Report");
                        fw.ConsoleReport(suspectcount + " is found on Report");
                        break;
                    }
                }
                tmsWait.Hard(2);
                IWebElement nextLink = Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl05_ctl03_ctl03"));
                fw.ExecuteJavascript(nextLink);
                tmsWait.Hard(5);
                alertPresent = IsAlertPresent();
            } while (alertPresent == false);

            if (flag == false)
            {
                Assert.Fail("Provider Name/Suspect Count was not found on the report");
            }
            Browser.Wd.SwitchTo().Alert().Dismiss();
        }







        public static bool IsAlertPresent()
        {
            try
            {
                Browser.Wd.SwitchTo().Alert();
                return true;
            }
            catch (NoAlertPresentException)
            {
                return false;
            }
        }



        public void reportContentVerification(string content)
        {
            tmsWait.Hard(5);
            Browser.SwitchToChildWindow();
            string pagesounce = Browser.Wd.FindElement(By.TagName("body")).Text;
            tmsWait.Hard(3);
            if (pagesounce.Contains(content) || pagesounce.Contains(content.ToUpper()))
            {
                Assert.IsTrue(true, content + "is found on Report");
                fw.ConsoleReport(content + " is found on Report");

            }
            else
            {
                Assert.Fail("Report Content is incorrect...");
            }
        }



        [Then(@"Verify RAM Application ""(.*)"" page is getting displayed")]
        public void ThenVerifyRAMApplicationPageIsGettingDisplayed(string p0)
        {
            IWebElement manageSuspectPage = Browser.Wd.FindElement(By.XPath("(//span[contains(.,'"+p0+"')])[2]"));
            bool pagePresence = manageSuspectPage.Displayed;
            Assert.IsTrue(pagePresence, p0 + " is not getting displayed");

        }

    }
}
