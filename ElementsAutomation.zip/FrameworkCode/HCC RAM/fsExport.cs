﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
//using System.Windows.Forms;
using System.Globalization;
using System.Text.RegularExpressions;
using System.IO;
using Microsoft.Data.SqlClient;
using System.Threading;

namespace TMSoR1.FrameworkCode.HCC_RAM
{
    [Binding]
    class fsExport
    {

        string expected, InputValue, GeneratedData;
        SelectElement select;
        //public string downloadPath = System.IO.Path.Combine(Environment.ExpandEnvironmentVariables("%userprofile%"), "Downloads");

        [When(@"I Navigate to Application ""(.*)""")]
        public void WhenINavigateToApplication(string p0)
        {
            IWebElement xpath = Browser.Wd.FindElement(By.CssSelector("[test-id='menu-ddl-applicationNavigation" + p0 + "Text']"));
            fw.ExecuteJavascript(xpath);
        }


        [When(@"""(.*)"" Application Database modify link is clicked")]
        public void WhenApplicationDatabaseModifyLinkIsClicked(string p0)
        {
            string xpath = "//table[@id='DetailsView1']//td[contains(.,'" + p0.ToString() + "')]//preceding-sibling::td//div/input[contains(@id,'DetailsView1_setUIClientAppLinkID')]";
            Browser.Wd.FindElement(By.XPath(xpath)).Click();
        }

        [When(@"Tenant Setup Manage Configuration Output path is readed")]
        public void WhenTenantSetupManageConfigurationOutputPathIsReaded()
        {
            string URL = ConfigFile.URL;
            string[] lines = URL.Split('.');
            string tenanatf = lines[0].Substring(8);
        }


        [When(@"WebAdministration page OutputLocation path iis saved")]
        public void WhenWebAdministrationPageOutputLocationPathIisSaved()
        {
            IWebElement save = null;
            string AppURL = ConfigFile.URL;
            string[] lines = AppURL.Split('.');
            CultureInfo cultureInfo = Thread.CurrentThread.CurrentCulture;
            TextInfo textInfo = cultureInfo.TextInfo;
            //string txt = textInfo.ToTitleCase(txt);
            // string tenanat = textInfo.ToTitleCase(lines[0].Substring(8));
            IWebElement tenantsetup = Browser.Wd.FindElement(By.XPath("//a[@title='Tenant Set-up']"));
            fw.ExecuteJavascript(tenantsetup);
            tmsWait.Hard(5);
            String path = null;
            try {
                string manageconnectionsXpath = "//div[@test-id='tenantSetup-grid-grdTenantSetUp']//table//tr[contains(.,'TMS-QA')]//a[@class='rptlink cursorLink']";
                IWebElement manage = Browser.Wd.FindElement(By.XPath(manageconnectionsXpath));
                fw.ExecuteJavascript(manage);
                path = "\\TMS - QA\\RAM\\Input\\";
            }
            catch
            {
                string manageconnectionsXpath = "//div[@test-id='tenantSetup-grid-grdTenantSetUp']//table//tr[contains(.,'TMS')]//a[@class='rptlink cursorLink']";
                IWebElement manage = Browser.Wd.FindElement(By.XPath(manageconnectionsXpath));
                fw.ExecuteJavascript(manage);
                path = "\\TMS\\RAMX\\Input\\";

            }
            string outputpathurl = "\\\\" + ConfigFile.DataServer + "\\TMSShare";
            tmsWait.Hard(10);
            string Tenantoutputpath = Browser.Wd.FindElement(By.CssSelector("[test-id='manageConfiguration-txt-fileRootPath']")).GetAttribute("value").ToString();
            if (Tenantoutputpath.Equals(""))
            {
                Browser.Wd.FindElement(By.CssSelector("[test-id='manageConfiguration-txt-fileRootPath']")).SendKeys(outputpathurl);
                save = Browser.Wd.FindElement(By.CssSelector("[test-id='manageConfiguration-btn-save']"));
                fw.ExecuteJavascript(save);
                tmsWait.Hard(5);

            }

            // string finaloutputpath = Tenantoutputpath+"\\"+tenanat+"\\RAM\\Output";
            string finaloutputpath = Tenantoutputpath + path;
            GlobalRef.outputpath = finaloutputpath;
            // string finaloutputpath = Tenantoutputpath+"\\"+tenanat+"\\RAM\\Output";



            //GlobalRef.outputpath = Browser.Wd.FindElement(By.Id("OutputFolder")).GetAttribute("value");
        }
    
        [When(@"RAMX WebAdministration page OutputLocation path is saved")]
        public void WhenRAMXWebAdministrationPageOutputLocationPathIsSaved()
        {
            IWebElement save = null;
            string AppURL = ConfigFile.URL;
            string[] lines = AppURL.Split('.');
            CultureInfo cultureInfo = Thread.CurrentThread.CurrentCulture;
            TextInfo textInfo = cultureInfo.TextInfo;
            IWebElement rootadmin = Browser.Wd.FindElement(By.CssSelector("[title='Root Administration']"));
            fw.ExecuteJavascript(rootadmin);

            IWebElement tenantsetup = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Tenant Set-up')]"));
            fw.ExecuteJavascript(tenantsetup);
            tmsWait.Hard(14);

            string tenantName = AngularFunction.getTenantName().ToUpper();
            String path = null;
            
                string manageconnectionsXpath = "//kendo-grid[@test-id='tenantSetup-grid-grdTenantSetUp']//td[contains(.,'"+ tenantName + "')]/following-sibling::td/a[@class='manageLink']";
                IWebElement manage = Browser.Wd.FindElement(By.XPath(manageconnectionsXpath));
                fw.ExecuteJavascript(manage);

                string fileRootPath = AngularFunction.FileRootPath();
                string completeSharedFolderPath = fileRootPath + tenantName;
                path = "\\RAMX\\Input\\Processed";

            string outputpathurl = completeSharedFolderPath + path;
            tmsWait.Hard(10);
            string Tenantoutputpath = Browser.Wd.FindElement(By.CssSelector("[test-id='manageConfiguration-txt-fileRootPath']")).GetAttribute("value").ToString();
            if (Tenantoutputpath.Equals(""))
            {
                Browser.Wd.FindElement(By.CssSelector("[test-id='manageConfiguration-txt-fileRootPath']")).SendKeys(completeSharedFolderPath);
                save = Browser.Wd.FindElement(By.CssSelector("[test-id='manageConfiguration-btn-save']"));
                fw.ExecuteJavascript(save);
                tmsWait.Hard(5);

            }

         
            GlobalRef.outputpath = outputpathurl;
            string back = "//span[@test-id='manageConfiguration-span-back']";
            IWebElement backbutton = Browser.Wd.FindElement(By.XPath(back));
            fw.ExecuteJavascript(backbutton);
        }


        [Then(@"Verify RAMX ""(.*)"" File Is Present in ""(.*)"" Folder")]
        public void ThenVerifyRAMXFileIsPresentInFolder(string p0, string p1)
        {
            expected = p1.ToString();
            GeneratedData = tmsCommon.GenerateData(p0.ToString());
            string path = GlobalRef.outputpath.ToString();
           
     
             Assert.IsTrue(File.Exists(path + "\\" + GeneratedData));
                 
            
        }

        [Then(@"Verify RAMX ""(.*)"" File Is Present in ""(.*)"" Folder(.*)")]
        public void ThenVerifyRAMXFileIsPresentInFolder(string p0, string p1, int p2)
        {
            expected = tmsCommon.GenerateData(p0.ToString());
            expected = expected + ".csv";
            GeneratedData = tmsCommon.GenerateData(p1.ToString());
            string path = GlobalRef.outputpath.ToString();


            Assert.IsTrue(File.Exists(path + "\\" + expected));
        }

        [When(@"WebAdministration page OutputLocation path is saved")]
        public void WhenWebAdministrationPageOutputLocationPathIsSaved()
        {
            IWebElement save = null;
            string AppURL = ConfigFile.URL;
            string[] lines = AppURL.Split('.');
            CultureInfo cultureInfo = Thread.CurrentThread.CurrentCulture;
            TextInfo textInfo = cultureInfo.TextInfo;
            //string txt = textInfo.ToTitleCase(txt);
             string tenanat = textInfo.ToTitleCase(lines[0].Substring(8));
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@title='Root Administration']")));
            IWebElement tenantsetup = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Tenant Set-up')]"));
            tmsWait.Hard(2);
            fw.ExecuteJavascript(tenantsetup);
            tmsWait.Hard(5);

            //string manageconnectionsXpath = "//kendo-grid[@test-id='tenantSetup-grid-grdTenantSetUp']//table//tr[contains(.,'TMS')]//a[@name='manage']";
            string manageconnectionsXpath = "//kendo-grid[@test-id='tenantSetup-grid-grdTenantSetUp']//table//tr[contains(.,'TMS')]//a[contains(.,'Manage Configuration')]";
            IWebElement manage = Browser.Wd.FindElement(By.XPath(manageconnectionsXpath));
            fw.ExecuteJavascript(manage);

            string outputpathurl = "\\\\" + ConfigFile.DataServer + "\\TMSShare";
            tmsWait.Hard(10);
            string Tenantoutputpath = Browser.Wd.FindElement(By.CssSelector("[test-id='manageConfiguration-txt-fileRootPath']")).GetAttribute("value").ToString();
            if (Tenantoutputpath.Equals(""))
            {
                Browser.Wd.FindElement(By.CssSelector("[test-id='manageConfiguration-txt-fileRootPath']")).SendKeys(outputpathurl);
                save = Browser.Wd.FindElement(By.CssSelector("[test-id='manageConfiguration-btn-save']"));
                fw.ExecuteJavascript(save);
                tmsWait.Hard(5);

            }

             string finaloutputpath = Tenantoutputpath+"\\"+tenanat.ToUpper()+"\\RAM\\Output";
           // string finaloutputpath = Tenantoutputpath + "\\TMS\\RAM\\Output";
            GlobalRef.outputpath = finaloutputpath;

            //GlobalRef.outputpath = Browser.Wd.FindElement(By.Id("OutputFolder")).GetAttribute("value");
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@test-id='manageConfiguration-span-back']/i")));
        }

        [When(@"WebAdministration page Authentication type is set to ""(.*)""")]
        public void WhenWebAdministrationPageAuthenticationTypeIsSetTo(string p0)
        {
            SelectElement select = new SelectElement(RAM.ExportPage.Authentication);
            select.SelectByText(p0.ToString());
        }

        [When(@"WebAdministration page user name and password is set")]
        public void WhenWebAdministrationPageUserNameAndPasswordIsSet()
        {
            RAM.ExportPage.EditDatabaseUserTextBox.Clear();
            RAM.ExportPage.EditDatabasePasswordTextBox.Clear();
            RAM.ExportPage.EditDatabaseUserTextBox.SendKeys(ConfigFile.DBUser);
            RAM.ExportPage.EditDatabasePasswordTextBox.SendKeys(ConfigFile.DBPassword);
        }


        [When(@"WebAdministration page OutputLocation path cleared")]
        public void WhenWebAdministrationPageOutputLocationPathCleared()
        {
            tmsWait.Hard(2);
            Browser.Wd.FindElement(By.Id("OutputFolder")).Clear();
        }


        [Given(@"I have copied RAM ""(.*)"" folder path from application setting")]
        public void GivenIHaveCopiedRAMFolderPathFromApplicationSetting(string p0)
        {
            Browser.Wd.FindElement(By.LinkText("Application")).Click();
            Browser.Wd.FindElement(By.XPath("//div[contains(@id,'DetailsView1_AssignedAppsDetails')]/parent::td/following-sibling::td[contains(.,'TMSRAM')]//preceding-sibling::td/div/input[1]"));
            string outputpath = Browser.Wd.FindElement(By.Id("OutputFolder")).GetAttribute("value");
            Browser.Wd.FindElement(By.XPath("//a[contains(.,'Home')]")).Click();
            GlobalRef.outputpath = outputpath;
        }

        [When(@"OutputLocation path for Export is restored")]
        public void WhenOutputLocationPathForExportIsRestored()
        {
			tmsWait.Hard(4);
            Browser.Wd.FindElement(By.Id("OutputFolder")).SendKeys(GlobalRef.outputpath.ToString());

        }

        [Then(@"Verify PIR Extract link is displayed on export page")]
        public void ThenVerifyPIRExtractLinkIsDisplayedOnExportPage()
        {
           Assert.AreEqual("PIR Extract", RAM.ExportPage.PIRExtract.Text, "PIR Extract" + " Link is not getting displayed");
        }



        [Then(@"Verify ""(.*)"" link is displayed on export page")]
        public void ThenVerifyLinkIsDisplayedOnExportPage(string p0)
        {
            tmsWait.Hard(5);
            expected = p0.ToString();
            switch (expected)
            {
                case "CMS Extract":
                    Assert.AreEqual(expected, RAM.ExportPage.CMSExtractLink.Text, expected + " Link is not getting displayed");
                    break;
                case "PIR Mail Extract":
                    Assert.AreEqual(expected, RAM.ExportPage.PIRMailExtractLink.Text, expected + " Link is not getting displayed");
                    break;
                case "Member HCC Extract":
                    Assert.AreEqual(expected, RAM.ExportPage.MemberHCCExtractLink.Text, expected + " Link is not getting displayed");
                    break;
                case "Suspect by Coder Extract":
                    Assert.AreEqual(expected, RAM.ExportPage.SuspectbyCoderExtractLink.Text, expected + " Link is not getting displayed");
                    break;
                case "PIR Extract":
                    Assert.AreEqual(expected, RAM.ExportPage.PIRExtractLink.Text, expected + " Link is not getting displayed");
                    break;
                case "PIR Extract By Control Number":
                    Assert.AreEqual(expected, RAM.ExportPage.PIRExtractByControlNumberLink.Text, expected + " Link is not getting displayed");
                    break;

            }
        }

        [When(@"Export page ""(.*)"" link is clicked")]
        public void WhenExportPageLinkIsClicked(string p0)
        {
            GlobalRef.ExportName = p0.ToString();
            tmsWait.Hard(5);
            expected = p0.ToString();
			IWebElement xpath = Browser.Wd.FindElement(By.XPath("(//label[contains(.,'" + expected + "')])[1]"));
            fw.ExecuteJavascript(xpath);
            
        }



        [When(@"""(.*)"" page Suspect Type set to ""(.*)""")]
        public void WhenPageSuspectTypeSetTo(string p0, string p1)
        {
            if (p0.ToString().Contains("PIR Extract"))
            {
                if (p1.ToString().Contains(','))
                {
                    string[] GeneratedData1 = p1.Split(',');
                    for (int i = 0; i < GeneratedData1.Count(); i++)
                    {
                        tmsWait.Hard(2);
                        //string xpath = "//li[contains(.,'" + GeneratedData1[i] + "')]";
                        //IWebElement test = Browser.Wd.FindElement(By.XPath(xpath));
                        //fw.ExecuteJavascript(test);

                        string xpath = "//kendo-multiselect[@test-id='SuspectType']//input";
                        IWebElement test = Browser.Wd.FindElement(By.XPath(xpath));
                        test.SendKeys(GeneratedData1[i]);
                        tmsWait.Hard(1);
                        test.SendKeys(OpenQA.Selenium.Keys.Enter);
                    }
                    GlobalRef.mSuspectType = p1.ToString();
                }
                else
                {
                    GeneratedData = tmsCommon.GenerateData(p1.ToString());
                    tmsWait.Hard(2);
                    //string xpath = "//li[contains(.,'" + GeneratedData + "')]";
                    //IWebElement test = Browser.Wd.FindElement(By.XPath(xpath));
                    //fw.ExecuteJavascript(test);

                    string xpath = "//kendo-multiselect[@test-id='SuspectType']//input";
                    IWebElement test = Browser.Wd.FindElement(By.XPath(xpath));
                    test.SendKeys(GeneratedData);
                    tmsWait.Hard(1);
                    test.SendKeys(OpenQA.Selenium.Keys.Enter);
                    GlobalRef.mSuspectType = GeneratedData;
                }
            }
            else
            {
                GeneratedData = tmsCommon.GenerateData(p1.ToString());
                //select = new SelectElement(RAM.ExportPage.SuspectType);
                //select.SelectByText(GeneratedData);
                GlobalRef.mSuspectType = GeneratedData;

                By Drp = By.XPath("//kendo-dropdownlist[@test-id='SuspectType']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + GeneratedData + "']");

                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
            }


        }

        [When(@"I select ""(.*)"" checkbox")]
        public void WhenISelectCheckbox(string p0)
        {
            switch (p0)
            {
                case "Update PIR Status To Open":
                IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@test-id='UpdatePir']"));
                if (ele.Selected != true)
                {
                   fw.ExecuteJavascript(ele);
                   tmsWait.Hard(3);
                }
                break;
            }
        }


        [When(@"PIR Extract By Control Number page Control Number is set to ""(.*)""")]
        public void WhenPIRExtractByControlNumberPageControlNumberIsSetTo(string p0)
        {
            GeneratedData = tmsCommon.GenerateData(p0.ToString());
            RAM.ExportPage.ControlNumber.SendKeys(GeneratedData);
            GlobalRef.mControlNumber = GeneratedData;
        }

        [When(@"PIR Extract By Control Number page Update PIR is set to ""(.*)""")]
        public void WhenPIRExtractByControlNumberPageUpdatePIRIsSetTo(string p0)
        {
            GeneratedData = tmsCommon.GenerateData(p0.ToString());
            if (GeneratedData.Contains("1"))
            {
                RAM.ExportPage.UpdatePirCheckbox.Click();
            }
            
        }


        [When(@"""(.*)"" page Suspect Status set to ""(.*)""")]
        public void WhenPageSuspectStatusSetTo(string p0, string p1)
        {
            GeneratedData = tmsCommon.GenerateData(p1.ToString());
            GlobalRef.mSuspectStatus = GeneratedData;
            //select = new SelectElement(RAM.ExportPage.SuspectStatus);
            //select.SelectByText(GeneratedData);

            By Drp = By.XPath("//kendo-dropdownlist[@test-id='SuspectStatus']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + GeneratedData + "']");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
        }

        [When(@"Administration Page pop up Ok Button is clicked")]
        public void WhenAdministrationPagePopUpOkButtonIsClicked()
        {
            IAlert alert = Browser.Wd.SwitchTo().Alert();
            alert.Accept();
        }


        [When(@"""(.*)"" page Plan ID is set to ""(.*)""")]
        public void WhenPagePlanIDIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(2);
            InputValue = tmsCommon.GenerateData(p1.ToString());
            GlobalRef.mPlanID = InputValue;

            if (InputValue.Contains(','))
            {
                string[] ArrayInputValue = InputValue.Split(',');

                foreach (string singleInputValue in ArrayInputValue)
                {
                    tmsWait.Hard(2);
                    //string xpath = "//li[contains(.,'" + singleInputValue + "')]";
                    //IWebElement test = Browser.Wd.FindElement(By.XPath(xpath));
                    //fw.ExecuteJavascript(test);

                    string xpath = "//kendo-multiselect[@test-id='PlanId']//input";
                    IWebElement test = Browser.Wd.FindElement(By.XPath(xpath));
                    test.SendKeys(singleInputValue);
                    tmsWait.Hard(1);
                    test.SendKeys(OpenQA.Selenium.Keys.Enter);
                }
            }
            
            else
            {
                tmsWait.Hard(2);
                //string OriginalText = null;
                //try
                //{
                //    OriginalText = Browser.Wd.FindElement(By.XPath("//div[contains(.,'Plan ID:')]//div[@unselectable='on']/div/ul/li/span[contains(.,'H')]")).Text;
                //} catch { }


                //string xpath = "//li[contains(.,'" + InputValue + "')]";
                //IReadOnlyCollection<IWebElement> test = Browser.Wd.FindElements(By.XPath(xpath));
                //test.Last();
                //fw.ExecuteJavascript(test.Last());

                //if (OriginalText != null)
                //{
                //    xpath = "//li[contains(.,'" + OriginalText + "')]/span/span";
                //    Browser.Wd.FindElement(By.XPath(xpath)).Click();
                //}

                string xpath = "//kendo-multiselect[@test-id='PlanId']//input";
                IWebElement test = Browser.Wd.FindElement(By.XPath(xpath));
                test.SendKeys(InputValue);
                tmsWait.Hard(1);
                test.SendKeys(OpenQA.Selenium.Keys.Enter);
            }


        }

        [When(@"""(.*)"" page PIR Status set to ""(.*)""")]

        public void WhenPagePIRStatusSetTo(string p0, string p1)
        {
            tmsWait.Hard(2);
            GeneratedData = tmsCommon.GenerateData(p1.ToString());
            GlobalRef.mPIRStatus = GeneratedData;
            //SelectElement select = new SelectElement(RAM.ExportPage.SuspectStatus);
            //select.SelectByText(GeneratedData);

            By Drp = By.XPath("//kendo-dropdownlist[@test-id='SuspectStatus']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + GeneratedData + "']");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
        }

        [Given(@"variable ""(.*)"" is set to the year for which there is PIR data")]
        public void GivenVariableIsSetToTheYearForWhichThereIsPIRData(string p0)
        {
            string DBName = "FileNameQuery";
            bool flag = false;
            string dbQuery1;
            
            db.CreateConnRAMX(DBName);
            DateTime Date = DateTime.Now;
            System.DateTime DateAdd = Date.AddYears(-2);
            int year = Convert.ToInt32(DateAdd.Year);
          
            for (int i = year; i <= year + 10; i++)
            {

                dbQuery1 = tmsCommon.GenerateData("exec [RAMX].[dbo].[PIR_ExtractFile] @paymentyear=" + i);
                db.AddDBQuery(DBName, dbQuery1);
                string result = db.StoreDBResults(DBName);
             
                if (result != "")
                {
                    fw.setVariable(p0, i.ToString());
                    flag = true;
                    break;
                }
            }
            if (flag == false) {
                Assert.Fail("No PIR Data");
            }

        }


        [Given(@"variable ""(.*)"" is set to the year for which there is no PIR data")]
        public void GivenVariableIsSetToTheYearForWhichThereIsNoPIRData(string p0)
        {
            string DBName = "FileNameQuery";
            bool flag = false;
            string dbQuery1;
            //string dbQuery2;
            db.CreateConnRAMX(DBName);
            int year = 2017;
            for (int i = year; i <= year + 10; i++)
            {
                dbQuery1 = tmsCommon.GenerateData("exec [RAMX].[dbo].[PIR_ExtractFile] @paymentyear="+i);
               //dbQuery2 = tmsCommon.GenerateData("Select @@rowcount");
                db.AddDBQuery(DBName, dbQuery1);
               // db.AddDBQuery(DBName, dbQuery2);
                string result = db.StoreDBResultsInString(DBName);
                if (result == "") {
                    fw.setVariable(p0, i.ToString());
                    flag = true;
                    break;
                }
            }
            if (flag == false)
            {
                Assert.Fail("No such payment year for which PIR data does not exist");
            }
        }

        [When(@"""(.*)"" page ""(.*)"" button is clicked")]
        public void WhenPageButtonIsClicked(string p0, string p1)
        {
            IWebElement xpath = Browser.Wd.FindElement(By.XPath("//button[@test-id='export-btn-runReport']"));
            fw.ExecuteJavascript(xpath);
            tmsWait.Hard(6);
        }

        [When(@"""(.*)"" page Payment Year set to ""(.*)""")]
        public void WhenPagePaymentYearSetTo(string p0, string p1)
        {
            GeneratedData = tmsCommon.GenerateData(p1.ToString());
            GlobalRef.mPaymentYear = GeneratedData;
            //select = new SelectElement(RAM.ExportPage.PaymentYear);
            //select.SelectByText(GeneratedData);

            By Drp = By.XPath("//kendo-dropdownlist[@test-id='PaymentYear']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + GeneratedData + "']");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
        }


        [When(@"Export page ""(.*)"" button is clicked")]
        [Then(@"Export page ""(.*)"" button is clicked")]
        [Given(@"Export page ""(.*)"" button is clicked")]
        public void WhenExportPageButtonIsClicked(string p0)
        {
            tmsWait.Hard(2);
            string downloadPath = null;
            try
            {
                downloadPath = GlobalRef.outputpath.ToString();
            }
            catch (Exception e)
            {

            }
            if (!String.IsNullOrEmpty(downloadPath))
            {
                string[] fileExtensions = { ".txt", ".csv" };
                DirectoryInfo di = new DirectoryInfo(downloadPath);
                FileInfo[] oldDownloadedFiles = di.EnumerateFiles().Where(p => fileExtensions.Contains(p.Extension, StringComparer.InvariantCultureIgnoreCase)).ToArray();

                foreach (var oldFile in oldDownloadedFiles)
                {
                   oldFile.Attributes = FileAttributes.Normal;
                    File.Delete(oldFile.FullName);
                }
            }

            //IWebElement xpath = Browser.Wd.FindElement(By.XPath("//button[contains(.,'EXPORT')]"));

            IWebElement xpath = Browser.Wd.FindElement(By.XPath("//button[@test-id='export-btn-runReport']"));
            fw.ExecuteJavascript(xpath);
            tmsWait.Hard(6);
            //if (p0.ToString().Contains("EXPORT"))
            //{
            //    tmsWait.Hard(1);
            //    fw.ExecuteJavascript(RAM.ExportPage.ExportButton);
            //}
            //else
            //{
            //    tmsWait.Hard(1);
            //    fw.ExecuteJavascript(RAM.ExportPage.ResetButton);
            //}
        }

        [When(@"Export page ""(.*)"" text hyperlink is clicked")]
        [Then(@"Export page ""(.*)"" text hyperlink is clicked")]
        public void WhenExportPageTextHyperlinkIsClicked(string p0)
        {
            tmsWait.Hard(4);
			//IWebElement xpath = Browser.Wd.FindElement(By.LinkText("File Processing Status page"));
            IWebElement xpath = Browser.Wd.FindElement(By.PartialLinkText("Processing Status page"));
            fw.ExecuteJavascript(xpath);
            tmsWait.Hard(6);
        }


        

        [Then(@"verfiy that extracted files should get saved in output location configured for RAM in TMS Admin")]
        public void WhenVerfiyThatExtractedFilesShouldGetSavedInOutputLocationConfiguredForRAMInTMSAdmin()
        {
            string downloadPath = "\\" + ConfigFile.DataServer + "\\TMSShareFolder";//GlobalRef.outputpath.ToString();\\abn-pdm-sql-d32\TMSShareFolder

            string[] fileExtensions = { ".txt", ".csv" };
            DirectoryInfo di = new DirectoryInfo(downloadPath);
            FileInfo[] oldDownloadedFiles = di.EnumerateFiles().Where(p => fileExtensions.Contains(p.Extension, StringComparer.InvariantCultureIgnoreCase)).ToArray();
            int cnt = oldDownloadedFiles.Count();
            if (cnt == 0)
            {
                Assert.Fail("Export file is not downloaded at " + downloadPath + " output location");
            }
            GlobalRef.FullFilePath = di.FullName + "\\" + oldDownloadedFiles[0].ToString();
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[contains(.,'PIR_MAIL_EXTRACT')]")).Displayed);
        }

        [Then(@"verfiy that extracted files should get saved in output location configured for ""(.*)"" in TMS Admin")]
        public void ThenVerfiyThatExtractedFilesShouldGetSavedInOutputLocationConfiguredForInTMSAdmin(string p0)
        {
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//tr[contains(.,'"+p0+"')]")).Displayed);
        }



        [Then(@"Verfiy that ""(.*)"" file naming convention should ""(.*)""")]
        public void WhenVerfiyThatFileNamingConventionShould(string p0, string p1)
        {
            string ExtractName = p0.ToString();
            //string filename = @"\\\\ABN-PDM-APP-D16\\TMSShareFolder\\RAM\\Export\\Member_HCC_Extract_All_2016_82320164324.csv";
            string filename = p1; //GlobalRef.FullFilePath.ToString();   // scenario.contex we have to use


            if (p1.ToString().ToUpper().Contains("PAYMENTYEAR")) { p1 = p1.Replace("_mmddyyhhss", ""); }
            
            string[] InputfileName = filename.Split('\\');
            int count = InputfileName.Count();
            GlobalRef.DownloadFileName = InputfileName[0];

            switch (p0.ToString())
            {
                case "Member HCC Extract":
                    if (p1.ToString().ToUpper().Contains("PLANID")) { p1 = p1.Replace("PlanID", GlobalRef.mPlanID.ToString()); }
                    if (p1.ToString().ToUpper().Contains("PAYMENTYEAR")) { p1 = p1.Replace("PaymentYear", GlobalRef.mPaymentYear.ToString()); }
                    //string MemberExtractfilename = p1;
                    //string ActualFileNameWithDigit = InputfileName[count - 1];
                    //int idx = ActualFileNameWithDigit.LastIndexOf('_');
                    //string actual = ActualFileNameWithDigit.Substring(0, idx);
                    string actualextractname = Browser.Wd.FindElement(By.XPath("//div[@id='fileProcessStatusGrid']//tr[1]//td[3]//span")).Text;
                    //Assert.AreEqual(MemberExtractfilename, actual, "File naming convention miss matched");
                    Assert.IsTrue(actualextractname.Contains(p1));
                    break;

                case "PE Project Extract Job":
                    string projectname = GlobalRef.ProjectName.ToString();
                    if (p1.ToString().ToUpper().Contains("MMDDYYHHSS")) { p1 = p1.Replace("_mmddyyhhss", ""); }
                    if (p1.ToString().ToUpper().Contains("PROJECTNAME")) { p1 = p1.Replace("projectName", projectname); }
                   string  MemberExtractfilename = p1;
                    string ActualFileNameWithDigit = InputfileName[count - 1];
                   int  idx = ActualFileNameWithDigit.LastIndexOf('_');
                    string actual = ActualFileNameWithDigit.Substring(0, idx);
                    Assert.AreEqual(MemberExtractfilename, actual, "File naming convention miss matched");
                    break;

                case "Suspect By Coder Extract":
                    if (p1.ToString().ToUpper().Contains("PAYMENTYEAR")) { p1 = p1.Replace("PaymentYear", GlobalRef.mPaymentYear.ToString()); }
                    p1 = p1.Replace("_mmddyyhhss", "");
                    string SuspectExtractfilename = p1;
                    ActualFileNameWithDigit = InputfileName[count - 1];
                    idx = ActualFileNameWithDigit.LastIndexOf('_');
                    actual = ActualFileNameWithDigit.Substring(0, idx);
                    Assert.AreEqual(SuspectExtractfilename, actual, "File naming convention miss matched");
                    break;

                case "PIR Extract By Control Number":

                    p1 = p1.Replace("_mmddyyhhss", "");
                    string PIExtractCNfilename = p1;
                    ActualFileNameWithDigit = InputfileName[count - 1];
                    idx = ActualFileNameWithDigit.LastIndexOf('_');
                    actual = ActualFileNameWithDigit.Substring(0, idx);
                    Assert.AreEqual(PIExtractCNfilename, actual, "File naming convention miss matched");
                    break;

                case "PIR Extract":
                    p1 = p1.Replace("_mmddyyhhss", "");
                    string PIExtractfilename = p1;
                    ActualFileNameWithDigit = InputfileName[count - 1];
                    idx = ActualFileNameWithDigit.LastIndexOf('_');
                    actual = ActualFileNameWithDigit.Substring(0, idx);
                    Assert.AreEqual(PIExtractfilename, actual, "File naming convention miss matched");
                    break;

                case "PIR Mail Extract":
                    p1 = p1.Replace("_mmddyyhhss", "");
                    string PIRMailExtractfilename = p1;
                    ActualFileNameWithDigit = InputfileName[count - 1];
                    idx = ActualFileNameWithDigit.LastIndexOf('_');
                    actual = ActualFileNameWithDigit.Substring(0, idx);
                    Assert.AreEqual(PIRMailExtractfilename, actual, "File naming convention miss matched");
                    break;
            }
        }
        [When(@"""(.*)"" page Priority set to ""(.*)""")]
        public void WhenPagePrioritySetTo(string p0, string p1)
        {
            GeneratedData = tmsCommon.GenerateData(p1.ToString());
            GlobalRef.mPriority = GeneratedData;
            //SelectElement select = new SelectElement(RAM.ExportPage.Priority);
            //select.SelectByText(GeneratedData);

            string xpath = "//kendo-multiselect[@test-id='Priority']//input";
            IWebElement test = Browser.Wd.FindElement(By.XPath(xpath));
            test.SendKeys(GeneratedData);
            tmsWait.Hard(1);
            test.SendKeys(OpenQA.Selenium.Keys.Enter);
        }

        [When(@"""(.*)"" page Enrolled Months set to ""(.*)""")]
        public void WhenPageEnrolledMonthsSetTo(string p0, string p1)
        {
            GeneratedData = tmsCommon.GenerateData(p1.ToString());
            GlobalRef.mEnrolledMonths = GeneratedData;
            //SelectElement select = new SelectElement(RAM.ExportPage.EnrolledMonths);
            //select.SelectByText(GeneratedData);

            By Drp = By.XPath("//kendo-dropdownlist[@test-id='EnrolledMonths']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + GeneratedData + "']");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
        }

        [When(@"""(.*)"" page ""(.*)"" look up is click")]
        public void WhenPageLookUpIsClick(string p0, string p1)
        {
            Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + p1+ "')]/parent::div/parent::div//following-sibling::div//a/i")).Click();
        }

        [When(@"""(.*)"" page Member ID is set to ""(.*)""")]
        public void WhenPageMemberIDIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(5);
            GeneratedData = tmsCommon.GenerateData(p1.ToString());
            GlobalRef.mMemberID = GeneratedData;
            if (p0.Contains("MemberLookUp"))
            {
                //RAM.ExportPage.txtLookUpId.SendKeys(GeneratedData);
                RAM.ExportPage.txtLookemmberUpId.SendKeys(GeneratedData);
                
            }
            else if (p0.Contains("ProviderLookUp"))
            {
                RAM.ExportPage.txtLookUpProviderId2.SendKeys(GeneratedData);
            }
            tmsWait.Hard(2);
        }

        [When(@"""(.*)"" page Search button is click")]
        public void WhenPageSearchButtonIsClick(string p0)
        {
            //fw.ExecuteJavascript(RAMMainLookup.Lookup.LookupSearchBtn);
            fw.ExecuteJavascript(RAMMainLookup.Lookup.MemberLookupSearchBtn);
            tmsWait.Hard(2);
        }

        [When(@"""(.*)"" page ""(.*)"" record select from search result grid")]
        public void WhenPageRecordSelectFromSearchResultGrid(string p0, string p1)
        {
            tmsWait.Hard(3);
            //RAM.ExportPage.txtLookUpId.Clear();
            By searchBtn = By.XPath("//button[contains(.,'SEARCH')]");
            By searchMemRow = By.XPath("(//kendo-grid//tr)[2]");
            By back = By.CssSelector("[test-id='member-span-back']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(searchBtn));
            tmsWait.Hard(5);
            fw.ExecuteJavascript(Browser.Wd.FindElement(searchMemRow));
            Browser.Wd.FindElement(searchMemRow).Click();
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(back));
            tmsWait.Hard(2);
            //GeneratedData = tmsCommon.GenerateData(p1.ToString());
            //Browser.Wd.FindElement(By.XPath("//tr[contains(.,'"+ GeneratedData + "')]")).Click();
        }

        [When(@"""(.*)"" page ""(.*)"" record is selected from search result grid")]
        public void WhenPageRecordIsSelectedFromSearchResultGrid(string p0, string p1)
        {
            tmsWait.Hard(3);
            By searchBtn = By.CssSelector("[test-id='lookup-btn-Search']");
            By searchMemRow = By.XPath("(//div[@test-id='lookup-grid-searchresult']//tr)[2]");
            By back = By.CssSelector("[test-id='pcpLookup-txt-backToRecord']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(searchBtn));
            tmsWait.Hard(5);
            fw.ExecuteJavascript(Browser.Wd.FindElement(searchMemRow));
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(back));
        }



        [When(@"""(.*)"" page ""(.*)"" button is click")]
        public void WhenPageButtonIsClick(string p0, string p1)
        {
            RAMMainLookup.Lookup.backToRecord.Click();
        }

        [Then(@"Verify PIR Extract page ""(.*)"" is display as ""(.*)""")]
        public void ThenVerifyPIRExtractPageIsDisplayAs(string p0, string p1)
        {
            string lookupname = p0.ToString();
            GeneratedData = tmsCommon.GenerateData(p1.ToString());
            string MemeberID = Browser.Wd.FindElement(By.XPath("//input[@test-id='MemberId']")).GetAttribute("value");
            Assert.AreEqual(GeneratedData, MemeberID.Trim(), "Selected Look up value not get reflected on PIR page ");
        }

      
        [Then(@"Export List page ""(.*)"" link is clicked")]
        public void ThenExportListPageLinkIsClicked(string extractLink)
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + extractLink + "')]")));
        }

        [Then(@"PIR Extract page EXPORT button is clicked")]
        public void ThenPIRExtractPageEXPORTButtonIsClicked()
        {
            tmsWait.Hard(2);
            RAM.ExportPage.ExportButton.Click();
        }

        [Then(@"PIR Extract page File Processing Status page link is clicked")]
        public void ThenPIRExtractPageFileProcessingStatusPageLinkIsClicked()
        {
            tmsWait.Hard(2);
            RAM.ExportPage.FileProcessingPageLink.Click();
        }


        [When(@"""(.*)"" page MemberID set to ""(.*)""")]
        public void WhenPageMemberIDSetTo(string p0, string p1)
        {
            GeneratedData = tmsCommon.GenerateData(p1.ToString());
            GlobalRef.mMemberID = GeneratedData;

            if (!GeneratedData.Equals("null"))
            {
                RAM.ExportPage.MemberId.SendKeys(GeneratedData);
            }
        }

        [When(@"""(.*)"" page ProviderID set to ""(.*)""")]
        public void WhenPageProviderIDSetTo(string p0, string p1)
        {
            GeneratedData = tmsCommon.GenerateData(p1.ToString());
            GlobalRef.mProviderID = GeneratedData;

            if (!GeneratedData.Equals("null"))
            {
                RAM.ExportPage.ProviderId.SendKeys(GeneratedData);
            }
        }

        [When(@"""(.*)"" page MarkAsOpen set to ""(.*)""")]
        public void WhenPageMarkAsOpenSetTo(string p0, string p1)
        {
            tmsWait.Hard(2);
            GeneratedData = tmsCommon.GenerateData(p1.ToString());
            GlobalRef.mMarkAsOpen = GeneratedData;
            if (GeneratedData.Equals("1"))
            {
                //RAM.ExportPage.UpdatePirCheckbox.Click();
                fw.ExecuteJavascript(RAM.ExportPage.UpdatePirCheckbox);
            }
        }


        [Then(@"Compare the ""(.*)"" file should be generated data as per stored procedure ""(.*)""")]
        public void ThenCompareTheFileShouldBeGeneratedDataAsPerStoredProcedure(string p0, string p1)
        {
            string pirFileName = Browser.Wd.FindElement(By.XPath("//tr[contains(.,'Member HCC Extract')]//td//a[contains(@ng-click,'DwnFile')]//span")).Text;
            //string pirFileName = p0.ToString();
            if (p1.Contains("PaymentYear")) p1 = p1.Replace("PaymentYear", GlobalRef.mPaymentYear.ToString());

            if (p1.Contains("PlanId"))
            {
                if (GlobalRef.mPlanID.ToString().Contains("All"))
                {
                    p1 = p1.Replace("PlanId", "-1");
                }
                else
                {
                    p1 = p1.Replace("PlanId", GlobalRef.mPlanID.ToString());
                }
            }

            if (p0.ToString().Equals("PIR Mail Extract"))
            {
                // this code has been written to replace GUI PIRStatus value in SP with backend value 
                string PIRStatus = GlobalRef.mPIRStatus.ToString();
                int returnPIRStatus = StatusPIR(PIRStatus);
                string PIRStatus_sp = Convert.ToString(returnPIRStatus);
                p1 = p1.Replace("PIRStatus", PIRStatus_sp);
            }
            else if (p0.ToString().Equals("Suspect By Coder Extract"))
            {
                // this code has been written to replace GUI  Suspect Status value in SP with backend value 
                string suspectStatus = GlobalRef.mSuspectStatus.ToString();
                int returnsuspectStatus = StatusPIR(suspectStatus);
                string suspectStatus_sp = Convert.ToString(returnsuspectStatus);
                p1 = p1.Replace("SuspectStatus", suspectStatus_sp);

                // this code has been written to replace GUI Suspect type value in SP with backend value 
                string suspectType = GlobalRef.mSuspectType.ToString();
                int retrunSuspectType = StatusSuspect(suspectType);
                string SuspectType_sp = Convert.ToString(retrunSuspectType);
                p1 = p1.Replace("SuspectType", SuspectType_sp);
            }
            else if (p0.ToString().Equals("PIR Extract"))
            {
                // this code has been written to replace GUI  Suspect Status value in SP with backend value 
                string PIRStatus = GlobalRef.mPIRStatus.ToString();
                int returnPIRStatus = StatusPIR(PIRStatus);
                string PIRStatus_sp = Convert.ToString(returnPIRStatus);
                p1 = p1.Replace("PIRStatus", PIRStatus_sp);

                // this code has been written to replace GUI Suspect type value in SP with backend value 
                string SuspectType_sp = null;
                string suspectType = GlobalRef.mSuspectType.ToString();
                string[] suspectArray = suspectType.Split(',');
                for (int s = 0; s < suspectArray.Count(); s++)
                {
                    int retrunSuspectType = StatusSuspect(suspectArray[s]);
                    SuspectType_sp = SuspectType_sp + "," + Convert.ToString(retrunSuspectType);
                }
                SuspectType_sp = SuspectType_sp.TrimStart(',');

                p1 = p1.Replace("SuspectType", "'" + SuspectType_sp + "'");

                p1 = p1.Replace("MemberID", GlobalRef.mMemberID.ToString());
                p1 = p1.Replace("ProviderID", GlobalRef.mProviderID.ToString());
                p1 = p1.Replace("MarkAsOpen", GlobalRef.mMarkAsOpen.ToString());
                p1 = p1.Replace("Priority", GlobalRef.mPriority.ToString());
                p1 = p1.Replace("EnrolledMonths", GlobalRef.mEnrolledMonths.ToString());


            }
            else if (p0.ToString().Equals("PIR Extract By Control Number"))
            {
                string ControlNumber = GlobalRef.mControlNumber.ToString();
                p1 = p1.Replace("ControlNumber", ControlNumber);
                GeneratedData = tmsCommon.GenerateData("Generate|variable|UpdatePIR");
                p1 = p1.Replace("UpdatePIR", GeneratedData);
            }
            else if (p0.ToString().Equals("PE Project Extract Job"))
            {
                string Dbcontent = null;
                int index = 0;
                Dictionary<int, string[]> table = new Dictionary<int, string[]>();
                string ProjectName = GlobalRef.ProjectName.ToString();

                string query = "select ProjectId from tbWorkFlow_Projects where ProjectName='" + ProjectName + "'";
                fsWorkflow obj = new fsWorkflow();
                table = obj.ExecuteSingleQuery(query, ConfigFile.RAMdb, 1, 0, "0");
                if (table.Count() == 0)
                {
                    Assert.Fail("Selected Tree queue dont have data");

                }

                Dbcontent = string.Join(",", table[index]);


                p1 = p1.Replace("ProjectName", Dbcontent);

            }


            string Querystring = p1;
            string url = ConfigFile.URL;
            char[] character = { '.' };
            string[] urls = url.Split(character);
            string tenant = urls[0].Remove(0, 8);
            string[] temp = ConfigFile.URL.Split('.');
            string downloadPath = "\\\\" + temp[1] + "\\TMSShareFolder\\" + tenant + "\\RAM\\output"; 
                //GlobalRef.outputpath.ToString();   
            string ExportName = pirFileName; //GlobalRef.DownloadFileName.ToString();

            switch (p0.ToString())
            {
                case "Member HCC Extract":
                    var csvData = ReadFileFunctions.ReadCSVFile(downloadPath + "\\" + "" + ExportName);
                    CompareFile(csvData, "csv", Querystring);
                    break;
                case "Suspect By Coder Extract":
                    csvData = ReadFileFunctions.ReadCSVFile(downloadPath + "\\" + "" + ExportName);
                    CompareFile(csvData, "txt", Querystring);
                    break;
                case "PIR Mail Extract":
                    var txtData = ReadFileFunctions.ReadTEXTFile(downloadPath + "\\" + "" + ExportName);
                    CompareFile(txtData, "txt", Querystring);
                    break;
                case "PIR Extract":
                    txtData = ReadFileFunctions.ReadTEXTFile(downloadPath + "\\" + "" + ExportName);
                    CompareFile(txtData, "txt", Querystring);
                    break;
                case "PIR Extract By Control Number":
                    txtData = ReadFileFunctions.ReadTEXTFile(downloadPath + "\\" + "" + ExportName);
                    CompareFile(txtData, "txt", Querystring);
                    break;
                case "CMS Extract":
                    txtData = ReadFileFunctions.ReadTEXTFile(downloadPath + "\\" + "" + ExportName);
                    CompareFile(txtData, "txt", Querystring);
                    break;
                case "PE Project Extract Job":
                    txtData = ReadFileFunctions.ReadTEXTFile(downloadPath + "\\" + "" + ExportName);
                    CompareFile(txtData, "txt", Querystring);
                    break;
            }
        }

        int StatusSuspect(string suspectType)
        {
                if (suspectType.Contains("Medical"))
                {
                    return 1;
                }
                else if (suspectType.Contains("Pharmacy"))
                {
                    return 2;
                }
                else if (suspectType.Contains("Historical HCC"))
                {
                     return 8;
                }
                else if (suspectType.Contains("Probabilty"))
                {
                    return 5;
                }
                else if (suspectType.Contains("RxMG"))
                {
                    return 11;
                }
                else if (suspectType.Contains("Other"))
                {
                    return 3;
                }
                else if (suspectType.Contains("All"))
                {
                    return -1;
                }
            return -1;
         }

        int StatusPIR(string PIRStatus)
        {
            if (PIRStatus.Contains("ALL"))
            {
                return -2;
            }
            else if (PIRStatus.Contains("New"))
            {
                return -1;
            }
            else if (PIRStatus.Contains("Open"))
            {
                return 0;
            }
            else if (PIRStatus.Contains("Closed"))
            {
                return 1;
            }

            return -2;
        }


        [Then(@"verify that exported file RAPS should be in ""(.*)"" status")]
        public void ThenVerifyThatExportedFileRAPSShouldBeInStatus(string expectedStatus)
        {
            tmsWait.Hard(10);
            string actualStatus = string.Empty;
            int count = 0;
            do
            {
                Thread.Sleep(60000);
                count++;
                actualStatus = Browser.Wd.FindElement(By.XPath("//tr[contains(.,'RAPS -  Create RAPS Prod File')]//parent::tr//td[2]/span")).Text;
            } while (actualStatus == "Executing" || actualStatus == "Pending");
            if (!actualStatus.Equals(expectedStatus))
            {
                Assert.Fail();
            }
        }



        [Then(@"verify that requested Job should be in ""(.*)"" status")]
        public void ThenVerifyThatRequestedJobShouldBeInStatus(string expectedStatus)
        {
            tmsWait.Hard(10);
            string exportname = GlobalRef.ExportName.ToString();
            string actualStatus = string.Empty;
            int count = 0;
            do
            {
                Browser.Wd.Navigate().Refresh();
                Thread.Sleep(30);
                count++;
                //actualStatus = Browser.Wd.FindElement(By.XPath("//div[contains(.,'" + exportname + "')]/parent::div/preceding-sibling::div/div/span")).Text;
                try
                {
                    actualStatus = Browser.Wd.FindElement(By.XPath("//tr[contains(.,'" + exportname + "')]//parent::tr//td[4]")).Text;
                }
                catch
                {
                    Thread.Sleep(3);
                    actualStatus = Browser.Wd.FindElement(By.XPath("//tr[contains(.,'" + exportname + "')]//parent::tr//td[4]")).Text;
                   // Browser.Wd.Navigate().Refresh();
                    //Thread.Sleep(30);
                }
               
                //if (count > 10)
                //{
                //    Assert.Fail();
                //}
            } while (actualStatus == "Executing"|| actualStatus == "Pending");

            if (expectedStatus.Equals("Complete"))
            {
                expectedStatus = "Success"; /*RAN and RAMX use Success for completion, taken in to account here*/
            }
            if (!actualStatus.Equals(expectedStatus))
            {
                Assert.Fail();
            }
        
        }

        
        public int StatusValidation(string actualStatus,string expectedStatus)
        {
            if (actualStatus.Equals("Pending"))
            {
                tmsWait.Hard(2);
                return 1;
            }
            else if (actualStatus.Equals("Executing"))
            {
                return 1;
            }
           else if (actualStatus.Equals("Complete/No Updates"))
            {
                if (expectedStatus.Equals(actualStatus))
                {
                    return 0;
                }
                else
                {
                    Assert.Fail("Report Generation Job is failed");
                    return 0;
                }
            }

            else if (actualStatus.Equals("Failed"))
            {
                if (expectedStatus.Equals(actualStatus)){
                    return 0;
                }else {
                    Assert.Fail("Report Generation Job is failed");
                    return 0;
                }
                
            }
            else if (actualStatus.Equals("Disabled"))
            {
                Assert.Fail("Report Generation Job is Disabled");
                return 0;
            }
            else if ((bool)Convert.ToBoolean(actualStatus.Equals("Complete")))
            {
                return 0;
            }

            return 0;
        }

        [Then(@"Verfiy that on File Processing Status Notes section should display the error messsage ""(.*)""")]
        public void ThenVerfiyThatOnFileProcessingStatusNotesSectionShouldDisplayTheErrorMesssage(string errorMsg)
        {
            //string JobId = GlobalRef.RequestID.ToString();
            //string errorMesg=Browser.Wd.FindElement(By.XPath("//div[ contains(@class,'ui-grid-cell ng-scope ui-grid-coluiGrid') and contains(.,'" + JobId + "')]//following-sibling::div[3]/div")).Text;
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[contains(.,'" + errorMsg + "')]")).Displayed);
        }

        [When(@"I click on expand button ""(.*)""")]
        public void WhenIClickOnExpandButton(string p0)
        {
            RAM.ExportPage.expandButton.Click();
        }

        [When(@"I select production database ""(.*)""")]
        public void WhenISelectProductionDatabase(string p0)
        {
            RAM.ExportPage.dropdownProduct.Click();
            Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + p0.ToString() + "')]")).Click();
            
        }

        public void CompareFile(List<string> dataFromFile, string format,string Querystring)
        {

            string errorMessage = null, splitpattern = null, colSkip = null;
            bool flag = false;
            int dbcolcnt = 0, rowstartcnt=0, FileRecordCnt=0, rowcnt=0;
            string Filecontent=null, Dbcontent=null;
            // Database col count and first col to skip
            if (Querystring.Contains("PIR_GetProvidersForMailExtract"))
            {
                dbcolcnt = 13; //count should be the number of Columns return by store procedure
                rowstartcnt = 2; //this variable is defined as some of store procedure columns need to be skip before starting comparison as export file also don’t have those columns
                splitpattern = "|"; //As some export file has been split either by “,” or “|”
                colSkip = "0";
                rowcnt = 0;
            }
            else if (Querystring.Contains("spPDM_RAM_MemberHCC_Extract"))
            {
                dbcolcnt = 6;
                rowstartcnt = 1;
                splitpattern = ",";
                colSkip = "0";
                rowcnt = 0;
                
            }
            else if (Querystring.Contains("spPDM_Report_SuspectCoder_SELECT"))
            {
                dbcolcnt = 23;
                rowstartcnt = 0;
                splitpattern = ",";
                colSkip = "13,21,22";
                rowcnt = 1;
            }
            else if (Querystring.Contains("PIR_ExtractFile"))
            {
                dbcolcnt = 66;
                rowstartcnt = 0;
                splitpattern = "|";
                colSkip = "44,45";
                rowcnt = 0;
            }
            else if (Querystring.Contains("spProspectiveEval_ProjectExtract"))
            {
                dbcolcnt = 37;
                rowstartcnt = 0;
                splitpattern = "|";
                colSkip = "0";
                rowcnt = 0;
            }


            Dictionary<int, string[]> table = new Dictionary<int, string[]>();
            fsExport Executequery = new fsExport();
           // table.Add(0, ' Number');
            table = Executequery.ExecuteSingleQuery(Querystring, ConfigFile.RAMdb, dbcolcnt, rowstartcnt, colSkip);


            
            int DbRecordsCnt = table.Count();
            FileRecordCnt = dataFromFile.Count();

            Boolean ispresent = false;
            // Compare the Number of record in downloaded file against the Database table record object.
            if (FileRecordCnt == DbRecordsCnt)
            {
                ispresent = true;
            }
            else {
                errorMessage = "Downloaded Export file row count is not matched with stored procedure return row count";
            }

            Assert.IsTrue(ispresent, format + "  " + errorMessage);


        }

            public Dictionary<int, string[]> ExecuteSingleQuery(string SqlString, string DB_NAME, int numberOfColumn,int rowstartcnt,string colSkip)
            {
                Dictionary<int, string[]> table = new Dictionary<int, string[]>();
                SqlCommand thisCommand = null;
                int flag = 0;   
                List<string> list = new List<string>();
                try
                {
                    SqlConnection DBConn = new SqlConnection();
                //string thisConnectionString = "user id=tmsservice;" +
                //           "password=TriZetto456;" +
                //           "Server=" + ConfigFile.DataServer + ";" +
                //           "Trusted_Connection = yes; " +
                //           "database=" + DB_NAME + "; " +
                //           "connection timeout=30";
                string thisConnectionString = "server=" + ConfigFile.DataServer + ";" + "database=" + DB_NAME + ";" + "user id=" + ConfigFile.DBUser + ";" + "password=" + ConfigFile.DBPassword + ";" + "Max Pool Size=9000;" + "Connection Timeout=150;" + "Min Pool Size=2";
                DBConn.ConnectionString = thisConnectionString;
                    DBConn.Open();
                    thisCommand = new SqlCommand(SqlString, DBConn);
                    SqlDataReader reader = thisCommand.ExecuteReader();
                    int numberOfRows = (reader.FieldCount + 1) / numberOfColumn;
                    int j = 0;

                    if (numberOfColumn == 23)
                    {
                       j = 1;
                       List<string> copyHeader = new List<String>() { "Control Number", "Provider ID", "Provider Last Name", "Member Name", "Member ID", "HIC Number", "HCC Weight", "Response Date", "Status", "PIR Result", "Write In Code", "Unconfirm Reason", "Coder ID", "Payment Year", "Suspect Type", "HCC Name", "RXHCCID", "Diagnosis Code", "Date Of Service", "Notes" };
                       table.Add(0, copyHeader.ToArray());
                    }

                    if (reader.HasRows)
                    {
                        
                        while (reader.Read())
                        {

                         list.Clear();
                         string[] rowSkipArray = colSkip.Split(',');
                         for (int i = rowstartcnt; i < numberOfColumn; i++)
                            {
                                
                                if(rowSkipArray!=null)
                                {
                                    for (int k = 0; k <= rowSkipArray.Length-1; k++)
                                    {
                                        if (i == Convert.ToInt32(rowSkipArray[k]))
                                        {
                                            flag = 0;
                                            break;
                                        }
                                        else {
                                            flag = 1;
                                        }
                                       
                                    }
                                    if (flag == 1)
                                    {
                                       list.Add(reader.GetValue(i).ToString().TrimEnd());
                                    }
                                }
                                else
                                {
                                    list.Add(reader.GetValue(i).ToString().TrimEnd());
                                }
                            }

                             List<string> copyList = list;

                                //if (numberOfColumn==66)
                                //{
                                //    if (copyList.ToArray().GetValue(61).ToString().Equals("Medical Doctor"))
                                //    {
                                //        copyList.Insert(61, "Medical Doctor (MD)");
                                //        copyList.RemoveAt(62);
                                //    }
                                //}
        
                            table.Add(j, copyList.ToArray());
                            
                            j++;
                        }
                    }
                }
                catch (Exception e)
                {
                    fw.ConsoleReport("Failed read record: [" + e + "] Query [" + SqlString + "]");
                }

             return table;

            }
    
    }


   
}
