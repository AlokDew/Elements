﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.HCC_RAM
{

    [Binding]
    class fsSetPlanStarRating
    {
        [When(@"Plan Start Rating Page PlanID ""(.*)"" is selected")]
        public void WhenPlanStartRatingPagePlanIDIsSelected(string planId)
        {
            tmsWait.Hard(2);
            //var selectPlanID = new SelectElement(RAM.SetPlanStarRating.PlanID);
            //selectPlanID.SelectByIndex(1);
            By Drp = By.XPath("//label[text()='Plan ID']/parent::div//span[@class='k-select']");

            By typeapp = By.XPath("//li[text()='" + planId + "']");


            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));

            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }

        [Then(@"Verify error mesaage""(.*)""")]
        public void ThenVerifyErrorMesaage(string expectedtext)
        {
            Assert.AreEqual(expectedtext, RAM.SetPlanStarRating.Errormessageplan.Text, "Message is displyed successfully ");
        }

        [When(@"Plan Start Rating Page Payment Year ""(.*)"" is selected")]
        public void WhenPlanStartRatingPagePaymentYearIsSelected(string paymentyear)
        {
            //var selectPaymentyear = new SelectElement(RAM.SetPlanStarRating.PaymentYear);
            //selectPaymentyear.SelectByIndex(4);
            By Drp = By.XPath("//label[text()='Payment Year:']/parent::div//span[@class='k-select']");

            By typeapp = By.XPath("//li[text()='" + paymentyear + "']");

            //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            //tmsWait.Hard(3);
            //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }

        [When(@"Plan Start Rating Page  Star Rating ""(.*)""  is selected")]
        public void WhenPlanStartRatingPageStarRatingIsSelected(string rating)
        {
            tmsWait.Hard(5);
            //var selectrating = new SelectElement(RAM.SetPlanStarRating.StarRating);
            //selectrating.SelectByText(rating);
            By Drp = By.XPath("//label[text()='Star Rating:']/parent::div//span[@class='k-select']");

            By typeapp = By.XPath("//li[text()='" + rating + "']");

            //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            //tmsWait.Hard(3);
            //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }

        [When(@"RAM Configuration Page I clicked on ""(.*)""")]
        public void WhenRAMConfigurationPageIClickedOn(string link)
        {
            tmsWait.Hard(3);
           fw.ExecuteJavascript(RAM.SetPlanStarRating.PlanStarRatinglink);
        }

        [When(@"Plan Start Rating PageClicked on Save button")]
        public void WhenPlanStartRatingPageClickedOnSaveButton()
        {
            tmsWait.Hard(5);
            RAM.SetPlanStarRating.Savebutton.Click();
        }
        [When(@"Plan Start Rating PageClicked on Save button and success message varified ""(.*)""")]
        [Then(@"Plan Start Rating PageClicked on Save button and success message varified ""(.*)""")]
        public void ThenPlanStartRatingPageClickedOnSaveButtonAndSuccessMessageVarified(string p0)
        {
            tmsWait.Hard(5);
            RAM.SetPlanStarRating.Savebutton.Click();
            fw.ExecuteJavascript(RAM.SetPlanStarRating.Savebutton);
            fw.ExecuteJavascript(RAM.SetPlanStarRating.Savebutton);
            By toastMsg = By.XPath("//div[@class='k-notification-content']");
            string actualValue = Browser.Wd.FindElement(toastMsg).Text;
            //string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
            string expectedValue = p0.ToString();
            Assert.IsTrue(expectedValue.Contains(actualValue), "Message is not displyed successfully ");
        }

        [When(@"Set Client Options page Send to option set as ""(.*)""")]
        public void WhenSetClientOptionsPageSendToOptionSetAs(string option)
        {
            tmsWait.Hard(2);
            //SelectElement sendToDD = new SelectElement(RAM.SetPlanStarRating.SendToDropdown);
            //sendToDD.SelectByText(option);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='configuration-select-ddlOptionChoice']//span[@class='k-select']");

            By typeapp = By.XPath("//li[text()='" + option + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
        }

        [When(@"Set Client Options page Claim Threshold Prior Year Suspects is set as ""(.*)""")]
        public void WhenSetClientOptionsPageClaimThresholdPriorYearSuspectsIsSetAs(string value)
        {
            tmsWait.Hard(2);
            RAM.SetPlanStarRating.ClaimThersholdYearTextbox.Clear();
            RAM.SetPlanStarRating.ClaimThersholdYearTextbox.SendKeys(value);
        }

        [When(@"Set Client Options page Save button is clicked")]
        public void WhenSetClientOptionsPageSaveButtonIsClicked()
        {
            tmsWait.Hard(2);
            RAM.SetPlanStarRating.SaveSetClientOptionButton.Click();
        }

        [When(@"Set Client Options page verify error message for below thersholod value")]
        public void WhenSetClientOptionsPageVerifyErrorMessageForBelowThersholodValue()
        {
            tmsWait.Hard(2);
            Assert.IsTrue(RAM.SetPlanStarRating.ErrorMsgClaimThersholdValue.Text.Contains("Threshold value must be a numeric value between 50 to 90"));
        }

    }
}

