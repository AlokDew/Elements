﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.HCC_RAM
{
    [Binding]
    class fsAddDiagnosisCode
    {
        private bool nextPage;

        [Then(@"Verify Add Diagnosis Codes page is not displayed Diagnosis code as ""(.*)"" and Discription as ""(.*)""")]
        public void ThenVerifyAddDiagnosisCodesPageIsNotDisplayedDiagnosisCodeAsAndDiscriptionAs(string p0, string p1)
        {
            string actualCode = tmsCommon.GenerateData(p0);
            string actualDescription = tmsCommon.GenerateData(p1);
            By loc = By.XPath("//*[@test-id='diagnosisCodes-table-codes']//td[contains(.,'" + actualCode + "')]/following-sibling::td[contains(.,'" + actualDescription + "')]");

            bool flag = false;

            while (!flag)
            {
                try
                {
                    AngularFunction.elementPresenceUsingLocators(loc);
                    flag = true;
                }
                catch
                {
                    AngularFunction.clickonNextLink();
                }
            }
        }


        [Then(@"Verify Add Diagnosis Codes page displayed Diagnosis code as ""(.*)"" and Discription as ""(.*)""")]
        public void ThenVerifyAddDiagnosisCodesPageDisplayedDiagnosisCodeAsAndDiscriptionAs(string code, string description)
        {
            string actualCode = tmsCommon.GenerateData(code);
            string actualDescription = tmsCommon.GenerateData(description);
            By loc = By.XPath("//kendo-grid[@test-id='diagnosisCodes-table-codes']//td[contains(.,'" + actualCode + "')]/following-sibling::td[contains(.,'" + actualDescription + "')]");

            bool flag = false;

            while (!flag)
            {
                try
                {
                    AngularFunction.elementPresenceUsingLocators(loc);
                    flag = true;
                }
                catch
                {
                    AngularFunction.clickonNextLink();
                }
            }

            //KendoUIFunctions.ResultGridTextValidation(actualCode);
            //KendoUIFunctions.ResultGridTextValidation(actualDescription);
            ////do
            //{
            //    nextPage = VerifyDiagnosisCode(actualCode, actualDescription);
            //    if (nextPage)
            //    {
            //        Browser.Wd.FindElement(By.LinkText("Next")).Click();
            //    }
            //} while (nextPage);

            //delete dignosis code
        }

        [Then(@"Verify that Manage suspect page get the additional diagnosis code ""(.*)"" is saved")]
        public void ThenVerifyThatManageSuspectPageGetTheAdditionalDiagnosisCodeIsSaved(string code)
        {
            string actualCode = tmsCommon.GenerateData(code);
            By loc = By.XPath("//kendo-grid[@test-id='pirResponse-grid-additionalDiagnosesGrid']//td[contains(.,'" + actualCode + "')]");

            bool flag = false;

            while (!flag)
            {
                try
                {
                    AngularFunction.elementPresenceUsingLocators(loc);
                    flag = true;
                }
                catch
                {
                    AngularFunction.clickonNextLink();
                }
            }

            //KendoUIFunctions.ResultGridTextValidation(actualCode);
            //KendoUIFunctions.ResultGridTextValidation(actualDescription);
            ////do
            //{
            //    nextPage = VerifyDiagnosisCode(actualCode, actualDescription);
            //    if (nextPage)
            //    {
            //        Browser.Wd.FindElement(By.LinkText("Next")).Click();
            //    }
            //} while (nextPage);

            //delete dignosis code
        }

        /// <summary>
        /// Verify Code and Description on Diagnosis Page
        /// </summary>
        /// <param name="code">Code</param>
        /// <param name="description">Description</param>
        /// <returns>Boolean value based on search result</returns>
        public bool VerifyDiagnosisCode(string code, string description)
        {
            try
            {
                if (Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + code + "')]/parent::td/following-sibling::td/span[contains(.,'" + description + "')]")).Displayed)
                {

                    return false;

                }
            }
            catch (Exception ex)
            {
                return true;
            }
            return true;
        }

        [When(@"Imports page Imports List section ""(.*)""  link is clicked")]
        public void WhenImportsPageImportsListSectionLinkIsClicked(string link)
        {
            switch (link)
            {
                case "PIR Response":
                    RAM.ImportsPage.PIRResponse.Click();
                    break;
                case "Client Identified Suspects":
                    RAM.ImportsPage.ClientIdentifiedSuspects.Click();
                    break;
            }
        }

        [When(@"I have navigated to RAM ""(.*)"" menu ""(.*)"" sub menu ""(.*)"" sub menu is Clicked")]
        public void WhenIHaveNavigatedToRAMMenuSubMenuSubMenuIsClicked(string menu, string sub1, string sub2)
        {

            tmsWait.Hard(5);

            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Menu']")));
            tmsWait.Hard(1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='" + menu + "']")));
            tmsWait.Hard(1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + sub1 + "')]")));
            tmsWait.Hard(1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//span[contains(.,'" + sub2 + "')])[2]")));

        }

        [When(@"I have navigated to Menu ""(.*)""")]
        public void WhenIHaveNavigatedToMenu(string p0)
        {
            String Submenu = tmsCommon.GenerateData(p0);
            try
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(text(),'" + Submenu + "')]")));
                tmsWait.Hard(5);
            }
            catch
            {
                //if exception catched Assert script to fail 
                Assert.Fail();
            }
        }

        [Then(@"Clicked on ""(.*)"" from PIR Page")]
        public void ThenClickedOnFromPIRPage(string p0)
        {
            tmsWait.Hard(3);
            Browser.Wd.FindElement(By.XPath("//span[@test-id='pirDiagnosisCodes-span-back']")).Click();
            tmsWait.Hard(4);

        }

        [When(@"I have navigated to RAM page ""(.*)""")]
        [When(@"I have navigated to RAMX page ""(.*)""")]
        public void WhenIHaveNavigatedToRAMPage(string menu)
        {

            tmsWait.Hard(4);
            GlobalRef.ReportName= menu;
            tmsWait.Hard(10);

            if (menu.Equals("Add Reasons") || menu.Equals("Add Diagnosis Codes") || menu.Equals("Add On Hold Reasons") || menu.Equals("Add Coder IDs") || menu.Equals("Add Payment Year") || menu.Equals("Exclude/Include Provider") || menu.Equals("RAM Configuration") || menu.Equals("Suspect Assignment Options") || menu.Equals("Customize PIR Cover Letter") || menu.Equals("Add Chart Review Source") || menu.Equals("Audit Configuration")
 || menu.Equals("Auditor Review") || menu.Equals("Flag for Auditor Review") || menu.Equals("RAMX Configuration"))
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Administration']")));
            }
            else if (menu.Equals("Import") || menu.Equals("Export") || menu.Equals("On-Hold and Diagnosis Review") || menu.Equals("Audit-View/Export") || menu.Equals("Risk Adjustment Updates") || menu.Equals("Delete Submitted Diag Codes"))
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Tasks']")));
            }
            else if (menu.Equals("Cancel Suspects") || menu.Equals("View and Undo PIR Responses") || menu.Equals("Update PIR Provider") || menu.Equals("Update Provider Info"))
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Suspects']")));
            }
            else if (menu.Equals("Manage Suspects") || menu.Equals("Enter New Diagnosis Data") || menu.Equals("Manage Suspect Assignments") || menu.Equals("Prospective Evaluation"))
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Main']")));
            }
            else if (menu.Equals("Reports"))
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Reports']")));
            }
            else if (menu.Equals("Report Manager"))
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Report Manager']")));
            }
            else if (menu.Equals("Job Processing Status"))
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Job Processing Status']")));
            }
            else if (menu.Equals("Main"))
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Main']")));
            }
            tmsWait.Hard(2);
            try
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + menu + "')]/parent::div/parent::div[contains(@test-id,'submenu')]")));
                tmsWait.Hard(5);
            }
            catch
            {

            }
        }


        [When(@"RAM page ""(.*)"" sub menu is clicked")]
        public void WhenRAMPageSubMenuIsClicked(string p0)
        {
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[contains(@test-id,'subMenuEx')]//span[contains(.,'" + p0 + "')]")));
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@class='item-desc-wrap']/span[text()='Scheduling']//ancestor::div[starts-with(@test-id,'subMenuEx')]")));
            tmsWait.Hard(3);
        }


        [Then(@"Activity is set to ""(.*)""")]
        public void ThenActivityIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string activity = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@test-id='audit-drp-activity']")));
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//multiselect[@test-id='audit-drp-activity']//ul/li/a[contains(.,'" + activity + "')] ")));
        }

        [Then(@"Action is set to ""(.*)""")]
        public void ThenActionIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string action = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@test-id='audit-drp-actions']")));
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//multiselect[@test-id='audit-drp-actions']//ul/li/a[contains(.,'" + action + "')] ")));

        }

        [Then(@"User is set to ""(.*)""")]
        public void ThenUserIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string user = tmsCommon.GenerateData(p0);
            SelectElement drpdown = new SelectElement(Browser.Wd.FindElement(By.XPath("//*[@test-id='audit-ddl-users']")));
            drpdown.SelectByText(user);
        }


        [Then(@"From Date is set to ""(.*)""")]
        [Given(@"From Date is set to ""(.*)""")]
        [When(@"From Date is set to ""(.*)""")]
        public void ThenFromDateIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string GeneratedData = tmsCommon.GenerateData(p0);
            IWebElement fromDate = Browser.Wd.FindElement(By.Id("txtFromDate"));
            fw.ExecuteJavascriptSetText(fromDate, GeneratedData);
        }


        [Then(@"I click on Reset button")]
        public void ThenIClickOnResetButton()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@test-id='audit-btn-reset']")));
            tmsWait.Hard(1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@test-id='audit-btn-reset']")));
        }


        [When(@"default values are noted for all the fields on Audit-View/Export page")]
        public void WhenDefaultValuesAreNotedForAllTheFieldsOnAudit_ViewExportPage()
        {
            tmsWait.Hard(2);
            string activityText_default = Browser.Wd.FindElement(By.XPath("//*[@test-id='audit-drp-activity']")).Text;
            GlobalRef.activityValue_default= activityText_default;
            string actionText_default = Browser.Wd.FindElement(By.XPath("//*[@test-id='audit-drp-actions']")).Text;
            GlobalRef.actionValue_default= actionText_default;
            string userText_default = new SelectElement(Browser.Wd.FindElement(By.XPath("//*[@test-id='audit-ddl-users']"))).SelectedOption.Text;
            GlobalRef.userValue_default= userText_default;
        }



        [Then(@"verify all values are reset to original values")]
        public void ThenVerifyAllValuesAreResetToOriginalValues()
        {
            string activityText = Browser.Wd.FindElement(By.XPath("//*[@test-id='audit-drp-activity']")).Text;
            Assert.AreEqual(GlobalRef.activityValue_default.ToString(), activityText.ToString(), "Value is incorrect");
            string actionText = Browser.Wd.FindElement(By.XPath("//*[@test-id='audit-drp-actions']")).Text;
            Assert.AreEqual(GlobalRef.actionValue_default.ToString(), actionText.ToString(), "Value is incorrect");
            string userText = new SelectElement(Browser.Wd.FindElement(By.XPath("//*[@test-id='audit-ddl-users']"))).SelectedOption.Text;
            Assert.AreEqual(GlobalRef.userValue_default.ToString(), userText.ToString(), "Value is incorrect");
        }


        [When(@"Administration Audit Configuration set to ON")]
        public void WhenAdministrationAuditConfigurationSetToON()
        {
            tmsWait.Implicit(5);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@class='k-switch-label-off km-switch-label-off']")));
        }

        [When(@"Verify Flag for Audit page displayed Warning message as ""(.*)""")]
        public void ThenVerifyFlagForAuditPageDisplayedWarningMessageAs(string expMsg)
        {
            Assert.AreEqual(expMsg, Browser.Wd.FindElement(By.ClassName("toast-message")).GetAttribute("aria-label"), "Expected Toaster message is not displayed");
        }


        [Then(@"Verify Flag for Audit page displayed the error message for uploading duplicate file ""(.*)""")]
        public void ThenVerifyFlagForAuditPageDisplayedTheErrorMessageForUploadingDuplicateFile(string p0)
        {
            string fileName = tmsCommon.GenerateData(p0);
            string expMsg = "is already uploaded. Please select a different file to upload";
            By toaster = By.XPath("//div[contains(.,'The file " + fileName + " " + expMsg + "')]");
            bool toasterDisplay = Browser.Wd.FindElement(toaster).Displayed;
            Assert.IsTrue(toasterDisplay, " Expected Toaster message is not displayed");
            tmsWait.Hard(1);
            //IWebElement removeBtn = Browser.Wd.FindElement(By.XPath("//span[@title='Remove']")); //this button exists and is valid but button identified in next line is more reliable
            IWebElement removeBtn = Browser.Wd.FindElement(By.XPath("//button[contains(.,'Delete')]"));
            fw.ExecuteJavascript(removeBtn);
            tmsWait.Hard(2);
        }


        [Then(@"Verify Flag for Audit page Processed File Name ""(.*)"" Fallout report contains Data as ""(.*)"" Error Message as ""(.*)""")]
        [Then(@"Verify Flag for Audit page Processed File Name ""(.*)"" Fallout report contains Imported Data as ""(.*)"" Error Message as ""(.*)""")]
        public void ThenVerifyFlagForAuditPageProcessedFileNameFalloutReportContainsImportedDataAsErrorMessageAs(string p0, string p1, string p2)
        {
            tmsWait.Hard(2);
            string fileName = tmsCommon.GenerateData(p0);
            string chartID = tmsCommon.GenerateData(p1);
            string expErrorMsg = tmsCommon.GenerateData(p2);

            string downloadPath = Path.Combine(Environment.ExpandEnvironmentVariables("%userprofile%"), "Downloads");

            var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");

            var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            tmsWait.Hard(2);
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
                var values = line.Split('|');
                if (line.Contains(chartID))
                {
                    string actualErrorMsg = values[3];
                    Assert.AreEqual(expErrorMsg, actualErrorMsg, " Both values are not matching");
                    fw.ConsoleReport(" Chart ID --> " + chartID);
                    fw.ConsoleReport(" Chart ID Error Message--> " + actualErrorMsg);
                }
            }
            reader.Close();
        }

        [Then(@"verify ""(.*)""")]
        public void ThenVerify(string p0)
        {
            bool isDisplayed;
            switch (p0)
            {
                case "File Processing Summary Grid":
                    string[] columnNames = new string[] { "File Name", "Processing Status", "Total Records", "Fallout Records", "User", "Date" };
                    foreach (string column in columnNames)
                    {
                        IWebElement gridElement = Browser.Wd.FindElement(By.XPath("//*[@test-id='ruleUploadFile-grid']//tr/th[contains(.,'" + column + "')]"));
                        Assert.IsTrue(gridElement.Displayed, "Column Name : " + column + " is not displayed in file processing grid ");
                    }
                    break;
                case "Refresh Button":
                    isDisplayed = Browser.Wd.FindElement(By.XPath("//*[@test-id='flagForAuditReview-btn-btnRefresh']")).Displayed;
                    Assert.IsTrue(isDisplayed, "Refresh button is not displayed");
                    break;

                case "Pagination":
                    isDisplayed = Browser.Wd.FindElement(By.XPath("//*[@role='spinbutton']")).Displayed;
                    Assert.IsTrue(isDisplayed, "Pagination is not displayed");
                    break;
            }

        }


        [Then(@"verify file processing summary grid")]
        public void ThenVerifyFileProcessingSummaryGrid()
        {

        }



        [When(@"Flag for Audit page File Processing Summary File Name ""(.*)"" Status ""(.*)"" Fallout Report is downloaded")]
        public void WhenFlagForAuditPageFileProcessingSummaryFileNameStatusFalloutReportIsDownloaded(string p0, string p1)
        {
            ReUsableFunctions.deleteFilesFromDownloadFolder();
            tmsWait.Hard(2);
            string fileupload = tmsCommon.GenerateData(p0);
            string status = tmsCommon.GenerateData(p1);

            By xpath = By.XPath("//kendo-grid[@test-id='ruleUploadFile-grid']//td[contains(.,'" + fileupload + "')]/following-sibling::td[contains(.,'" + status + "')]/following-sibling::td//a");
            IWebElement download = Browser.Wd.FindElement(xpath);
            fw.ExecuteJavascript(download);
            tmsWait.Hard(2);

        }
        [Then(@"Verify Flag for Audit page displayed error toaster message as ""(.*)""")]
        public void ThenVerifyFlagForAuditPageDisplayedErrorToasterMessageAs(string p0)
        {
            ReUsableFunctions.toasterMessageDisplay(p0);
        }

        [When(@"Flag for Audit page Upload button is Clicked")]
        public void WhenFlagForAuditPageUploadButtonIsClicked()
        {
            tmsWait.Hard(5);
            IWebElement upload = Browser.Wd.FindElement(By.CssSelector("[class='k-button k-primary k-upload-selected']"));
            fw.ExecuteJavascript(upload);
        }

        [When(@"Flag for Audit page Upload button is Clicked and warning message ""(.*)"" gets displayed")]
        public void WhenFlagForAuditPageUploadButtonIsClickedAndWarningMessageGetsDisplayed(string p0)
        {
            tmsWait.Hard(5);
            IWebElement upload = Browser.Wd.FindElement(By.CssSelector("[test-id='flagForAuditReview-fileUpload']"));
            fw.ExecuteJavascript(upload);
            string actualMessage = Browser.Wd.FindElement(By.ClassName("toast-message")).GetAttribute("aria-label");
            Assert.AreEqual(p0, actualMessage, "Expected Toaster message is not displayed");
            //By toaster = By.XPath("//div[contains(.,'"+ p0 + "')]");
            //bool toasterDisplay = Browser.Wd.FindElement(toaster).Displayed;
            //Assert.IsTrue(toasterDisplay, " Expected Toaster message is not displayed");
        }


        [Then(@"Verify Flag for Audit page File Processing Summary page File Name as ""(.*)""  Total Records as ""(.*)"" Fallout Records as ""(.*)""")]
        public void ThenVerifyFlagForAuditPageFileProcessingSummaryPageFileNameAsTotalRecordsAsFalloutRecordsAs(string p0, string p1, string p2)
        {
            tmsWait.Hard(5);
            string fileupload = tmsCommon.GenerateData(p0);
            string totalrecords = tmsCommon.GenerateData(p1);
            string falloutrecords = "";//tmsCommon.GenerateData(p2);

            By xpath = By.XPath("(//kendo-grid[@test-id='ruleUploadFile-grid']//td[contains(.,'" + fileupload + "')]//following-sibling::td[contains(.,'" + totalrecords + "')])[1]");
            bool results = Browser.Wd.FindElement(xpath).Displayed;

            Assert.IsTrue(results, " Chart ID Records are displayed on Fallout report");

        }

        [Then(@"Wait for Both ConfirmedAndOnHold ""(.*)"" File Processing status is set to ""(.*)""")]
        public void ThenWaitForBothConfirmedAndOnHoldFileProcessingStatusIsSetTo(string p0, string p1)
        {
            string description = tmsCommon.GenerateData(p0);


            By xpath = By.XPath("(//div[@test-id='file-grid-fileProcessStatusGrid']//tr[contains(.,'" + description + "')]/td[2]/span)[1]");


            string actualStatus;

            Browser.Wd.Navigate().Refresh(); // as File processing is taking time, we kept it intentionally
            tmsWait.Hard(30);
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(30);
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(30);
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(30);
            actualStatus = Browser.Wd.FindElement(xpath).Text.ToString();
            int ReturnStatus = StatusValidation(actualStatus);

            while (ReturnStatus != 0)
            {
                Browser.Wd.Navigate().Refresh();
                tmsWait.Hard(5);
                actualStatus = Browser.Wd.FindElement(xpath).Text.ToString();
                ReturnStatus = StatusValidation(actualStatus);
            }
        }

        [Then(@"EAM """"(.*)"" section  All action has changed is By one")]
        public void ThenEAMSectionAllActionHasChangedIsByOne(string p0)
        {
            string dbcount = GlobalRef.ActionItem.ToString();
            int c = Int32.Parse(dbcount);
            tmsWait.Hard(5);
            String actualstatus = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Total Actions')]")).Text;


            string[] Actual = actualstatus.Split(' ');
            int vc = Int32.Parse(Actual[2]);

            Assert.IsTrue(vc.Equals(c - 1));
            // GlobalRef.ActionItem = Actual[2];
        }

        [Then(@"Verify variable ""(.*)"" is Equal to ""(.*)"" Grid Items")]
        public void ThenVerifyVariableIsEqualToGridItems(string p0, string p1)

        {
            string dbcount = tmsCommon.GenerateData(p0);
            tmsWait.Hard(5);
            String actualstatus = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Total Actions')]")).Text;


            string[] Actual = actualstatus.Split(' ');


            // Assert.IsTrue(Actual[2].Equals(dbcount));
            GlobalRef.ActionItem = Actual[2];

        }

        [Then(@"EAM """"(.*)"" section  All action has not changed")]
        public void ThenEAMSectionAllActionHasNotChanged(string p0)
        {


            string dbcount = GlobalRef.ActionItem.ToString();
            tmsWait.Hard(5);
            String actualstatus = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Total Actions')]")).Text;


            string[] Actual = actualstatus.Split(' ');


            Assert.IsTrue(Actual[2].Equals(dbcount));
        }

        [Then(@"Verify variable ""(.*)"" is Equal to  Noted MBI")]
        public void ThenVerifyVariableIsEqualToNotedMBI(string p0)
        {

            string JobStatus = GlobalRef.MBI.ToString();
            string filename = tmsCommon.GenerateData(p0);

            Assert.IsTrue(JobStatus.Equals(filename));

        }

        [Then(@"Verify Gherkin variable ""(.*)"" is Equal to ""(.*)""")]
        public void ThenVerifyGherkinVariableIsEqualTo(string p0, string p1)
        {
            string exp = tmsCommon.GenerateData(p1);
            string act= tmsCommon.GenerateData(p0);
            fw.ConsoleReport("actual value " + act);
            fw.ConsoleReport("expected value " + exp);
            Assert.AreEqual(exp, act," both are not matching");
        }

       

        [When(@"Verify variable ""(.*)"" is Equal to ""(.*)""")]
        [Then(@"Verify variable ""(.*)"" is Equal to ""(.*)""")]
        public void ThenVerifyVariableIsEqualTo(string p0, string p1)
        {

            string JobStatus = tmsCommon.GenerateData(p0);

            string filename = tmsCommon.GenerateData(p1);
            if (filename.Equals("NULL"))
            {
                Assert.IsTrue(JobStatus.Equals(""));
            }
            else if (filename.Equals("1"))
            {

                if (JobStatus.Equals("True"))
                {
                }
                else
                {
                    Assert.IsTrue(JobStatus.Equals("1"));
                }
                 ;
            }
            else
            {
                Assert.IsTrue(JobStatus.Trim().Equals(filename.Trim()));
            }





        }

        [When(@"Verify variable ""(.*)"" is Equall to ""(.*)""")]
        [Then(@"Verify variable ""(.*)"" is Equall to ""(.*)""")]
        public void ThenVerifyVariableIsEquallTo(string p0, string p1)
        {

            string JobStatus = tmsCommon.GenerateData(p0);
            string filename = tmsCommon.GenerateData(p1);

            filename = filename + ".csv";
            Assert.IsTrue(JobStatus.Trim().Equals(filename.Trim()));




        }
        //[When(@"I clicks on ""(.*)"" verify sorting of ""(.*)""")]
        //public void WhenIClicksOnVerifySortingOf(string p0, string p1)
        //{
        //    List<string> stringdrpValues = new List<string>();
        //    List<string> stringValues;
        //    List<string> stringDBValues = dbValues;
        //    IList<IWebElement> code;
        //    tmsWait.Hard(2);
        //    int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
        //    for (int i = 1; i <= totalPagesIntheGrid; i++)
        //    {
        //        tmsWait.Hard(2);
        //        code = Browser.Wd.FindElements(By.XPath("//div[@test-id='pirResponse-grid-potentialRelatedDiagnosesGrid']//span[@ng-bind='dataItem.code']"));
        //        tmsWait.Hard(7);
        //        stringValues = ConvertWebElementInToString(code);
        //        foreach (string t in stringValues)
        //        {
        //            stringdrpValues.Add(t);

        //        }
        //        IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
        //        ReUsableFunctions.clickOnWebElement(nextpage);

        //    }

        //    Assert.IsTrue((resultantString.Count == 0), "Values are not matching");
        //}

        [Then(@"Verify variable ""(.*)"" is Equal to RequestID on File Processing page")]
        public void ThenVerifyVariableIsEqualToRequestIDOnFileProcessingPage(string p0)
        {
            string reqid = tmsCommon.GenerateData(p0);
            string RequestID = GlobalRef.RequestID.ToString();
            Assert.IsTrue(reqid.Equals(RequestID));
        }
        [Then(@"Verify variable ""(.*)"" is Equal to CodeValue Present on PIR Page")]
        public void ThenVerifyVariableIsEqualToCodeValuePresentOnPIRPage(string p0)
        {
            string DBCodeValue = tmsCommon.GenerateData(p0);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + DBCodeValue + "')]")).Displayed);

        }

        [Then(@"Wait for ""(.*)"" File Processing status is set to ""(.*)""")]
        public void ThenWaitForFileProcessingStatusIsSetTo(string p0, string p1)
        {

            tmsWait.Hard(5);
            IWebElement refresh = Browser.Wd.FindElement(By.CssSelector("[test-id='jobProcessingStatus-button-refresh']"));
            tmsWait.Hard(5);
            string actualStatus;
            tmsWait.Hard(20);
            string description = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(refresh);
            tmsWait.Hard(5);
            By xpath = By.XPath("//tr[1]/td[contains(text(),'PIR Response File')]/following-sibling::td[1]");
            actualStatus = Browser.Wd.FindElement(xpath).Text.ToString();
            int ReturnStatus = StatusValidation(actualStatus);

            fw.ExecuteJavascript(refresh);
            tmsWait.Hard(5);
            while (ReturnStatus != 0)
            {
                fw.ExecuteJavascript(refresh);
                tmsWait.Hard(15);
                actualStatus = Browser.Wd.FindElement(xpath).Text.ToString();
                ReturnStatus = StatusValidation(actualStatus);
            }



            //By xpath = By.XPath("//td[contains(.,'CIS File')]/following-sibling::td[@aria-colindex='4']");

            //By xpathRequestID = By.XPath("(//div[@test-id='file-grid-fileProcessStatusGrid']//tr[contains(.,'" + description + "')]/td/p)[1]");

            //string actualStatus;
            //string RequestID;
            //Browser.Wd.Navigate().Refresh();
            //tmsWait.Hard(30);
            //Browser.Wd.Navigate().Refresh();
            //tmsWait.Hard(30);
            //Browser.Wd.Navigate().Refresh();
            //tmsWait.Hard(30);
            //actualStatus = Browser.Wd.FindElement(xpath).Text.ToString();
            //int ReturnStatus = StatusValidation(actualStatus);
            //while (ReturnStatus != 0)
            //{
            //    Browser.Wd.Navigate().Refresh();
            //    tmsWait.Hard(28);
            //    actualStatus = Browser.Wd.FindElement(xpath).Text.ToString();
            //    ReturnStatus = StatusValidation(actualStatus);
            //}
            ////  RequestID = Browser.Wd.FindElement(xpathRequestID).Text.ToString();
            //// GlobalRef.RequestID = RequestID;
        }


        [Then(@"Verify Flag for Audit page File Processing Summary File Name ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyFlagForAuditPageFileProcessingSummaryFileNameIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(20);
            string fileupload = tmsCommon.GenerateData(p0);

            IWebElement upload = Browser.Wd.FindElement(By.CssSelector("[class='k-button k-primary k-upload-selected']"));

            fw.ExecuteJavascript(upload);
            tmsWait.Hard(15);
            By xpath = By.XPath("//kendo-grid[@test-id='ruleUploadFile-grid']//td[contains(.,'" + fileupload + "')]/following-sibling::td[1]");

            //  IWebElement confirmYes = Browser.Wd.FindElement(By.CssSelector("[test-id='confirmationDialog-btn-Yes']"));
            //  fw.ExecuteJavascript(confirmYes);
            tmsWait.Hard(5);
            IWebElement refresh = Browser.Wd.FindElement(By.CssSelector("[test-id='flagForAuditReview-btn-btnRefresh']"));

            tmsWait.Hard(5);
            string actualStatus;


            fw.ExecuteJavascript(refresh);
            tmsWait.Hard(5);

            By Datefilter = By.XPath("//kendo-grid//tr[1]/th[6]//span[text()='Date']");
            Browser.Wd.FindElement(Datefilter).Click();
            tmsWait.Hard(3);
            Browser.Wd.FindElement(Datefilter).Click();
            tmsWait.Hard(3);

            actualStatus = Browser.Wd.FindElement(xpath).Text.ToString();
            int ReturnStatus = StatusValidation(actualStatus);

            


            fw.ExecuteJavascript(refresh);
            tmsWait.Hard(5);
            while (ReturnStatus != 0)
            {
                fw.ExecuteJavascript(refresh);
                tmsWait.Hard(15);
                actualStatus = Browser.Wd.FindElement(xpath).Text.ToString();
                ReturnStatus = StatusValidation(actualStatus);
            }

            




        }

        public int StatusValidation(string actualStatus)
        {
            if (actualStatus.Equals("Pending"))
            {
                tmsWait.Hard(2);
                return 1;
            }
            else if (actualStatus.Equals("Executing"))
            {
                return 1;
            }
            else if (actualStatus.Equals("In-progress"))
            {
                return 1;
            }

            else if (actualStatus.Equals("Failed"))
            {
                Assert.Fail(" Job Processing is failed");
                return 0;
            }
            else if (actualStatus.Equals("Completed"))
            {

                return 0;
            }

            return 0;
        }


        [When(@"Verify the title of page displayed as ""(.*)""")]
        public void WhenVerifyTheTitleOfPageDisplayedAs(string p0)
        {
            tmsWait.Hard(6);
            string PageTitle = Browser.Wd.FindElement(By.XPath("//div[contains(@class,'adminTitle')]//span")).Text;
            //string PageTitle = Browser.Wd.FindElement(By.XPath(".//*[@id='mainContant']//label[contains(text(),'"+p0+"')]")).Text;
            Assert.AreEqual(PageTitle, p0.ToString(), "Title is not displayed as per actual");

        }

        [When(@"Verify the Main Page displayed ""(.*)"" menu")]
        public void WhenVerifyTheMainPageDisplayedMenu(string p0)
        {
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(".//*[@test-id='header-btn-expanMenu']")));
            tmsWait.Hard(1);
            //string PageTitle = Browser.Wd.FindElement(By.XPath("//li[@data-ng-repeat='field in navigationMenu.menuItems']//span[contains(.,'"+ p0+"')]")).Text;
            //string PageTitle = Browser.Wd.FindElement(By.XPath("//ul[@test-id='menu-titleList']//span[contains(.,'"+p0+"')]")).Text;
            bool ispresent = false;
            try
            {
                ispresent = Browser.Wd.FindElement(By.XPath("//div[@title='" + p0 + "']")).Displayed;
            }
            catch { }

            Assert.IsTrue(ispresent, "Expected page is not displayed");

            // Assert.AreEqual(PageTitle, p0.ToString(), "Title is not displayed as per actual");
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(".//*[@test-id='header-btn-expanMenu']")));
        }

        [Then(@"Verify the Submenu ""(.*)"" is displayed under menu ""(.*)""")]
        public void ThenVerifyTheSubmenuIsDisplayedUnderMenu(string p0, string p1)
        {
            string submenu = tmsCommon.GenerateData(p0);
            string menu = tmsCommon.GenerateData(p1);
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(".//*[@test-id='header-btn-expanMenu']")));
            tmsWait.Hard(1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@title='" + menu + "']")));
            bool ispresent = false;
            //div[contains(@test-id,'submenu')]//span[contains(.,'Manage Suspects')]
            try
            {
                ispresent = Browser.Wd.FindElement(By.XPath("//div[contains(@test-id,'submenu')]//span[contains(.,'" + submenu + "')]")).Displayed;
            }

            catch { }

            Assert.IsTrue(ispresent);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@title='" + menu + "']")));
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(".//*[@test-id='header-btn-expanMenu']")));
            tmsWait.Hard(1);
        }

        [Then(@"Verify the menu ""(.*)"" is displayed under submenu ""(.*)"" for main menu ""(.*)""")]
        public void ThenVerifyTheMenuIsDisplayedUnderSubmenuForMainMenu(string p0, string p1, string p2)
        {
            string menu = tmsCommon.GenerateData(p0);
            string submenu = tmsCommon.GenerateData(p1);
            string mainmenu = tmsCommon.GenerateData(p2);
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(".//*[@test-id='header-btn-expanMenu']")));
            tmsWait.Hard(1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@title='" + mainmenu + "']")));
            tmsWait.Hard(1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[contains(@test-id,'submenu')]//span[contains(.,'" + submenu + "')]")));
            bool ispresent = false;
            //div[contains(@test-id,'submenu')]//span[contains(.,'Manage Suspects')]
            try
            {
                ispresent = Browser.Wd.FindElement(By.XPath("//div[contains(@test-id,'subMenuEx')]//span[contains(.,'" + menu + "')]")).Displayed;
            }

            catch { }

            Assert.IsTrue(ispresent);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[contains(@test-id,'submenu')]//span[contains(.,'" + submenu + "')]")));
            tmsWait.Hard(1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@title='" + mainmenu + "']")));
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(".//*[@test-id='header-btn-expanMenu']")));
            tmsWait.Hard(1);

        }





        [When(@"Manage Suspects page ""(.*)"" is set to ""(.*)""")]
        public void WhenManageSuspectsPageIsSetTo(string p0, string p1)
        {
            string field = p0.ToString();
            string value = tmsCommon.GenerateData(p1);
            switch (field)
            {
                case "Provider ID":
                    RAM.ManageSuspectPage.ProviderID.SendKeys(value);

                    break;
                case "Last Name":
                    RAM.ManageSuspectPage.ProviderLastName.SendKeys(value);
                    break;


            }

        }

        [When(@"Manage Suspects page Select Type is selected as ""(.*)""")]
        public void WhenManageSuspectsPageSelectTypeIsSelectedAs(string p0)
        {
            string option = p0.ToString();
            switch (option)
            {
                case "Provider":
                    fw.ExecuteJavascript(RAM.ManageSuspectPage.ProviderRadio);
                    break;
                case "Group":
                    fw.ExecuteJavascript(RAM.ManageSuspectPage.GroupRadio);
                    break;
                case "Provider Group Affiliation":
                    fw.ExecuteJavascript(RAM.ManageSuspectPage.AffiliationRadio);
                    break;
            }
        }

        [When(@"View and Undo PIR Responses page ""(.*)"" button is Clicked")]
        public void WhenViewAndUndoPIRResponsesPageButtonIsClicked(string p0)
        {
            // tmsWait.Hard(2);
            clickonWebComponent(RAM.ViewandUndoPIRResponses.SearchButton);

            // more wait time is added after comparing the servers with response time of the page 
            tmsWait.Hard(70);
        }

        [When(@"View and Undo PIR Responses page Control Number ""(.*)"" Undo link is Clicked")]
        [Then(@"View and Undo PIR Responses page Control Number ""(.*)"" Undo link is Clicked")]
        public void WhenViewAndUndoPIRResponsesPageControlNumberUndoLinkIsClicked(string p0)
        {
            tmsWait.Hard(4);
            string controlnumber = tmsCommon.GenerateData(p0);
            try
            {
                if (Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + controlnumber + "')]/following-sibling::td/a[contains(@class,'grid-Delete')]")).Displayed)
                {
                    clickonWebComponent(Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + controlnumber + "')]/following-sibling::td/a[contains(@class,'grid-Delete')]")));
                    tmsWait.Hard(1);
                    warningDialogClickonButton(RAM.ManageSuspectPage.WarningdialogOK);

                }

            }
            catch (Exception)
            {
                //skip
            }
        }



        [When(@"View and Undo PIR Responses page Control Number ""(.*)"" Undo link is Clicked Verify Message ""(.*)""")]
        public void WhenViewAndUndoPIRResponsesPageControlNumberUndoLinkIsClickedVerifyMessage(string p0, string p1)
        {
            tmsWait.Hard(4);
            string controlnumber = tmsCommon.GenerateData(p0);
            IWebElement unDo = Browser.Wd.FindElement(By.XPath("//*[@test-id='viewUndoPirResponse-grid-suspectsGridSearchResult']//td[contains(.,'" + controlnumber + "')]//parent::td//following-sibling::td/a/span[@class='fas fa-undo']"));
            fw.ExecuteJavascript(unDo);
            tmsWait.Hard(1);
            warningDialogClickonButton(RAM.ManageSuspectPage.WarningdialogOK);
            tmsWait.Hard(1);
            string expectedValue = p1.ToString();
            By toastMsg = By.XPath("//div[@class='k-notification-content']");
            string actValue = Browser.Wd.FindElement(toastMsg).Text;
            Assert.IsTrue(actValue.Contains(expectedValue));

        }


        [Then(@"View ""(.*)"" link Clicked and message varified ""(.*)""")]
        [When(@"View ""(.*)"" link Clicked and message varified ""(.*)""")]
        public void ThenViewLinkClickedAndMessageVarified(string p0, string p1)
        {
            tmsWait.Hard(30);
            string controlnumber = tmsCommon.GenerateData(p0);

            if (Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='viewUndoPirResponse-grid-suspectsGridSearchResult']//td[contains(.,'" + controlnumber + "')]")).Displayed)
            {
                tmsWait.Hard(3);
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@test-id='viewUndoPirResponse-grid-suspectsGridSearchResult']//td[contains(.,'" + controlnumber + "')]//parent::td//following-sibling::td/a/span[@class='fas fa-undo']")));

                tmsWait.Hard(1);
                fw.ExecuteJavascript(RAM.ManageSuspectPage.WarningdialogOK);
              
            }

        }

        [When(@"View and Undo PIR Responses page Control Number ""(.*)"" Information link is Clicked")]
        public void WhenViewAndUndoPIRResponsesPageControlNumberInformationLinkIsClicked(string p0)
        {
            string controlnumber = tmsCommon.GenerateData(p0.ToString());
            tmsWait.Hard(3);
            IWebElement infor = Browser.Wd.FindElement(By.XPath("//*[@test-id='viewUndoPirResponse-grid-suspectsGridSearchResult']//td[contains(.,'" + controlnumber + "')]//parent::td//following-sibling::td/a/span[@class='fas fa-info-circle']"));
            fw.ExecuteJavascript(infor);
            //clickonWebComponent(infor);
        }

        [Then(@"Verify All entered diagnosis codes for Control Number page displays Control Number ""(.*)"" successfully")]
        public void ThenVerifyAllEnteredDiagnosisCodesForControlNumberPageDisplaysControlNumberSuccessfully(string p0)
        {
            string controlnumber = tmsCommon.GenerateData(p0.ToString());
            tmsWait.Hard(3);
            IWebElement control = Browser.Wd.FindElement(By.XPath("//*[@id='diagnosisCodesSearchResultId']//td[contains(.,'" + controlnumber + "')]"));
            Assert.IsTrue(control.Displayed, control + " is not displayed");
        }

        [Then(@"Control Number page Back buton is clicked")]
        public void ThenControlNumberPageBackButonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(RAM.ControlNumberPage.BackButton);
        }


        [When(@"View and Undo PIR Responses page ""(.*)"" is selected as ""(.*)""")]
        [Then(@"View and Undo PIR Responses page ""(.*)"" is selected as ""(.*)""")]
        public void WhenViewAndUndoPIRResponsesPageIsSelectedAs(string p0, string p1)
        {
            string drp = p0.ToString();
            //string value = p1.ToString();
            // string endDate = DateTime.Now.ToString("MM/dd/yyyy");
            // string startDate = DateTime.Now.AddDays(-1).ToString("MM/dd/yyyy");
            string value = tmsCommon.GenerateData(p1.ToString());

            switch (drp)
            {
                case "Search By":
                    By Drp = By.XPath("//label[contains(.,'Select Type')]/parent::div//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + value + "']");
                    fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                    fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                    tmsWait.Hard(3);
                    break;
                case "Control Number":
                    RAM.ViewandUndoPIRResponses.ControlNumber.SendKeys(value);
                    tmsWait.Hard(2);
                    break;
                case "MemberID":
                    RAM.ViewandUndoPIRResponses.MemberID.SendKeys(value);
                    tmsWait.Hard(2);
                    break;
                case "Start Date":
                    By startDateField = By.XPath("//kendo-datepicker[@test-id='viewUndoPir-txt-startDate']//span[@role='button']");
                    AngularFunction.enterDate(startDateField, value);
                    break;
                case "End Date":
                    By endDateField = By.XPath("//kendo-datepicker[@test-id='viewUndoPir-txt-endDatepicker']//span[@role='button']");
                    AngularFunction.enterDate(endDateField, value);
                    break;
                case "Member ID":
                    RAM.ViewandUndoPIRResponses.MemberID.SendKeys(value);
                    tmsWait.Hard(2);
                    break;
            }
            tmsWait.Hard(2);
        }

        [Then(@"Manage Suspects page ""(.*)"" is selected as ""(.*)""")]
        [When(@"Manage Suspects page ""(.*)"" is selected as ""(.*)""")]
        public void WhenManageSuspectsPageIsSelectedAs(string p0, string p1)
        {
            tmsWait.Hard(3);
            string drp = p0.ToString();
            string value = tmsCommon.GenerateData(p1.ToString());
            int flag = 0;

            switch (drp)
            {
                case "Search Type":

                    By Drp = By.XPath("//label[contains(.,'Type')]/parent::div//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + value + "']");
                    fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                    fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                    tmsWait.Hard(3);

                    break;
                case "PIR Control Number":

                    //String input = Browser.Wd.FindElement(By.XPath("//input[contains(@test-id,'ControlNumber')]")).GetAttribute("test-id");

                    //if (input.Contains("manageSuspects"))
                    //{
                    RAM.ManageSuspectPage.PIRNumber.Clear();
                    RAM.ManageSuspectPage.PIRNumber.SendKeys(value);
                    //}
                    //else
                    //{
                    //    RAM.ManageSuspectPage.PIRNumber_undoPIR.Clear();
                    //    RAM.ManageSuspectPage.PIRNumber_undoPIR.SendKeys(value);
                    //}
                    break;

                case "ProviderID":
                    Browser.Wd.FindElement(By.CssSelector("[test-id='manageSuspects-txt-providerId']")).Clear();
                    Browser.Wd.FindElement(By.CssSelector("[test-id='manageSuspects-txt-providerId']")).SendKeys(value);
                    break;

                case "MemberID":

                    Browser.Wd.FindElement(By.CssSelector("[test-id='manageSuspects-input-planMemberId']")).Clear();
                    Browser.Wd.FindElement(By.CssSelector("[test-id='manageSuspects-input-planMemberId']")).SendKeys(value);
                    break;

                case "ProviderLastName":
                    Browser.Wd.FindElement(By.CssSelector("[test-id='manageSuspects-input-lastName']")).Clear();
                    Browser.Wd.FindElement(By.CssSelector("[test-id='manageSuspects-input-lastName']")).SendKeys(value);
                    break;

                case "MemberLastName":

                    Browser.Wd.FindElement(By.CssSelector("[test-id='manageSuspects-input-memberLastName']")).SendKeys(value);
                    break;

                case "PlanMemberID":
                    Browser.Wd.FindElement(By.CssSelector("[test-id='manageSuspects-input-planMemberId']")).Clear();
                    Browser.Wd.FindElement(By.CssSelector("[test-id='manageSuspects-input-planMemberId']")).SendKeys(value);
                    break;

                case "Control Number":
                    Browser.Wd.FindElement(By.CssSelector("[test-id='manageSuspects-input-pitControlNumber']")).Clear();
                    Browser.Wd.FindElement(By.CssSelector("[test-id='manageSuspects-input-pitControlNumber']")).SendKeys(value);
                    break;


            }
        }


        [When(@"Manage Suspects page Last Name is set to ""(.*)""")]
        public void WhenManageSuspectsPageLastNameIsSetTo(string p0)
        {
            string name = p0.ToString();

        }

        [Then(@"Manage Suspect page Coder ID value is set to the first value in dropdown")]
        public void ThenManageSuspectPageCoderIDValueIsSetToTheFirstValueInDropdown()
        {
            tmsWait.Hard(3);
            //SelectElement MMPPBPDropdown = new SelectElement(Browser.Wd.FindElement(By.XPath(".//*[@test-id='pirResponse-select-coders']")));
            //MMPPBPDropdown.SelectByIndex(1);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='pirResponse-select-coders']//span[@class='k-select']");
            By typeapp = By.XPath("(//li[contains(.,'A')])[1]");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(2);
        }


        [Then(@"Manage Suspect page Reason is set to ""(.*)""")]
        [When(@"Manage Suspect page Reason is set to ""(.*)""")]
        [Given(@"Manage Suspect page Reason is set to ""(.*)""")]
        public void ThenManageSuspectPageReasonIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string reasonText = tmsCommon.GenerateData(p0);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='pirResponse-select-unconfirmedSuspects']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + reasonText + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(1);

            //SelectElement ReasonDropdown = new SelectElement(Browser.Wd.FindElement(By.XPath(".//*[@test-id='pirResponse-select-unconfirmedSuspects']")));
            //ReasonDropdown.SelectByText(reasonText);
        }



        [When(@"Manage Suspects Search results page ""(.*)"" Provider ""(.*)"" PIR Number View Edit link is Clicked")]
        public void WhenManageSuspectsSearchResultsPageProviderPIRNumberViewEditLinkIsClicked(string p0, string p1)
        {

            string prov = p0.ToString();
            string pirnumber = p1.ToString();
            IWebElement provider = Browser.Wd.FindElement(By.XPath(".//*[@test-id='manageSuspects-grid-providerResult']//td[contains(.,'" + prov + "')]/following-sibling::td//a[@ng-click='gotoPirResponse(" + pirnumber + ")']"));
            fw.ExecuteJavascript(provider);
        }


        [When(@"Manage Suspects Search results page Provider PIR Number View Edit link is Clicked")]
        public void WhenManageSuspectsSearchResultsPageProviderPIRNumberViewEditLinkIsClicked()
        {
            tmsWait.WaitForElement(By.XPath("//div[@role='presentation']//tr//td//a[@title='Edit']"), 40);
            IWebElement provider = Browser.Wd.FindElement(By.XPath("//div[@role='presentation']//tr//td//a[@title='Edit']"));
            fw.ExecuteJavascript(provider);
        }

        public bool isWebElementPresence(IWebElement element)
        {
            bool presence = element.Displayed;
            return presence;

        }
        [Then(@"Verify All PIR Notes page ""(.*)"" is Displayed")]
        public void ThenVerifyAllPIRNotesPageIsDisplayed(string p0)
        {
            string component = p0.ToString();

            switch (component)
            {
                case "Back To Record":
                    bool back = isWebElementPresence(RAM.ManageSuspectPage.BackToRecord);
                    Assert.IsTrue(back, component + "is not displayed");
                    break;

                case "New Note":
                    tmsWait.WaitForElement(By.CssSelector("[test-id='pirViewEditNotes-txt-addNoteValue']"), 30);
                    bool note = isWebElementPresence(RAM.ManageSuspectPage.NewNotes);
                    Assert.IsTrue(note, component + "is not displayed");
                    break;


                case "ADD NOTE":
                    bool addnote = isWebElementPresence(RAM.ManageSuspectPage.ADDNotebutton);
                    Assert.IsTrue(addnote, component + "is not displayed");
                    break;
            }
        }

        [When(@"All entered diagnosis codes page View Notes link is Clicked")]
        public void WhenAllEnteredDiagnosisCodesPageViewNotesLinkIsClicked()
        {
            RAM.Allentereddiagnosiscodes.ViewNotes.Click();
        }



        [When(@"Manage Suspect page View Notes link is Clicked")]
        public void WhenManageSuspectPageViewNotesLinkIsClicked()
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(RAM.ManageSuspectPage.ViewNotes);
        }

        [When(@"All PIR Notes page New Note is set to ""(.*)""")]
        public void WhenAllPIRNotesPageNewNoteIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            string note = tmsCommon.GenerateData(p0);
            RAM.ManageSuspectPage.NewNotes.SendKeys(note);

        }
        void warningDialogClickonButton(IWebElement button)
        {
            fw.ExecuteJavascript(button);
        }




        [When(@"All PIR Notes page ADD NOTE button is clicked")]
        public void WhenAllPIRNotesPageADDNOTEButtonIsClicked()
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(RAM.ManageSuspectPage.ADDNotebutton);
            tmsWait.Hard(5);
            warningDialogClickonButton(RAM.ManageSuspectPage.WarningdialogYes);


        }
        [When(@"All PIR Notes page ADD NOTE button is clicked and ""(.*)"" displayed successfully")]
        [Then(@"All PIR Notes page ADD NOTE button is clicked and ""(.*)"" displayed successfully")]
        public void ThenAllPIRNotesPageADDNOTEButtonIsClickedAndDisplayedSuccessfully(string p0)
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(RAM.ManageSuspectPage.ADDNotebutton);
            tmsWait.Hard(5);
            warningDialogClickonButton(RAM.ManageSuspectPage.WarningdialogYes);

            string actualvalue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
            string expectedvalue = p0.ToString();
            Assert.IsTrue(actualvalue.Contains(expectedvalue), "Message is displayed successfully");

        }

        [Then(@"All PIR Notes page ADD NOTE button is clicked and Verify All PIR Notes page ""(.*)"" displayed successfully")]
        public void ThenAllPIRNotesPageADDNOTEButtonIsClickedAndVerifyAllPIRNotesPageDisplayedSuccessfully(string p0)
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(RAM.ManageSuspectPage.ADDNotebutton);
            tmsWait.Hard(5);
            warningDialogClickonButton(RAM.ManageSuspectPage.WarningdialogYes);

        }

        [When(@"All PIR Notes page Notes Table ""(.*)"" data is edited")]
        public void WhenAllPIRNotesPageNotesTableDataIsEdited(string p0)
        {
            string data = tmsCommon.GenerateData(p0);
            IWebElement edit = Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + data + "')]//following-sibling::td//span[@class='fas fa-edit']"));
            fw.ExecuteJavascript(edit);
        }

        [When(@"All PIR Notes page Notes Table ""(.*)"" data is set to ""(.*)""")]
        public void WhenAllPIRNotesPageNotesTableDataIsSetTo(string p0, string p1)
        {
            string modnote = tmsCommon.GenerateData(p1);
            IWebElement edited = Browser.Wd.FindElement(By.XPath("//div[@role='presentation']//td/input"));
            edited.Clear();
            edited.SendKeys(modnote);
            Browser.Wd.FindElement(By.XPath("//span[@class='fas fa-save']")).Click();
        }
        [When(@"All PIR Notes page Notes ""(.*)"" data is set to ""(.*)""")]
        [Then(@"All PIR Notes page Notes ""(.*)"" data is set to ""(.*)""")]
        public void WhenAllPIRNotesPageNotesDataIsSetTo(string p0, string p1)
        {


            string modnote = tmsCommon.GenerateData(p1);
            IWebElement edited = Browser.Wd.FindElement(By.XPath("//div[@role='presentation']//td/input"));
            edited.Clear();
            edited.SendKeys(modnote);
            // Browser.Wd.FindElement(By.XPath("//span[@class='k-i-check fa fa-floppy-o']")).Click();
        }

        [When(@"Verify All PIR Notes page Notes Table has data ""(.*)""")]
        [Then(@"Verify All PIR Notes page Notes Table has data ""(.*)""")]
        public void ThenVerifyAllPIRNotesPageNotesTableHasData(string p0)
        {
            string addednote = tmsCommon.GenerateData(p0);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@role='presentation']//td[contains(.,'" + addednote + "')]")).Displayed, addednote + "is not displayed");
            tmsWait.Hard(10);
        }


        public static string toasterMessagedisplay()
        {
            string name = string.Empty;
            tmsWait.WaitForElement(By.ClassName("toast-message"), 340);
            if (Browser.Wd.FindElement(By.ClassName("toast-message")).Displayed)
            {
                return Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
            }
            return name;
        }

        [Then(@"Verify All PIR Notes page ""(.*)"" displayed Informational message")]
        [When(@"Verify All PIR Notes page ""(.*)"" displayed Informational message")]
        public void ThenVerifyAllPIRNotesPageDisplayedInformationalMessage(string p0)
        {
            try
            {
                tmsWait.Hard(9);
                string exp = p0.ToString();
                string act = RAM.ManageSuspectPage.PIRInformationalmsg.Text;
                Assert.AreEqual(exp, act, exp + "is not getting displayed");

            }
            catch (NoSuchElementException ex)
            {
                tmsWait.Hard(15);
                string exp = p0.ToString();
                string act = RAM.ManageSuspectPage.PIRInformationalmsg.Text;
                Assert.AreEqual(exp, act, exp + "is not getting displayed");
            }
        }


        [Then(@"Verify All PIR Notes page ""(.*)"" displayed successfully")]
        public void ThenVerifyAllPIRNotesPageDisplayedSuccessfully(string p0)
        {
            ////tmsWait.Hard(5);
            //string expected = p0.ToString();
            //string actual = fsAddDiagnosisCode.toasterMessagedisplay();
            //Assert.AreEqual(expected, actual, "Both values are not getting matched");
            //ReUsableFunctions.toasterMessageDisplayVerification(p0);
        }
        [Then(@"All PIR Notes page edit button is clicked and Verify All PIR Notes page ""(.*)"" displayed successfully")]
        [When(@"All PIR Notes page edit button is clicked and Verify All PIR Notes page ""(.*)"" displayed successfully")]
        public void ThenAllPIRNotesPageEditButtonIsClickedAndVerifyAllPIRNotesPageDisplayedSuccessfully(string p0)
        {
            tmsWait.Hard(4);
            Browser.Wd.FindElement(By.XPath("//span[@class='fas fa-save']")).Click();
            // string actualvalue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
            // string expectedvalue = p0.ToString();
            // bool msg = expectedvalue.Contains(actualvalue);
            //  Assert.IsTrue(msg, "Message is not displayed successfully");
        }

        [Then(@"ADD NOTE button clicked and ""(.*)"" displayed and varified\tdata ""(.*)""")]
        [When(@"ADD NOTE button clicked and ""(.*)"" displayed and varified\tdata ""(.*)""")]
        public void WhenADDNOTEButtonClickedAndDisplayedAndVarifiedData(string p0, string p1)
        {
            try
            {
                tmsWait.Hard(5);
                fw.ExecuteJavascript(RAM.ManageSuspectPage.ADDNotebutton);
                tmsWait.Hard(5);
                warningDialogClickonButton(RAM.ManageSuspectPage.WarningdialogYes);

                string expectedValue = p0.ToString();
                By toastMsg = By.XPath("//div[@class='k-notification-content']");
                string actValue = Browser.Wd.FindElement(toastMsg).Text;
                Assert.IsTrue(actValue.Contains(expectedValue));

            }
            catch (Exception e)
            {
                tmsWait.Hard(3);
                string addednote = tmsCommon.GenerateData(p1);
                Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//*[@test-id='pirViewEditNotes-grd-noteGrd']//td[contains(.,'" + addednote + "')]")).Displayed, addednote + "is not displayed");
                tmsWait.Hard(10);
            }
        }

        [Then(@"Verify View and Undo PIR Responses page ""(.*)"" displayed Successfully")]
        public void ThenVerifyViewAndUndoPIRResponsesPageDisplayedSuccessfully(string p0)
        {
            string expected = p0.ToString();
            string actual = fsAddDiagnosisCode.toasterMessagedisplay();

            Assert.AreEqual(expected, actual, "Both values are not getting matched");

        }

        [Then(@"Verify ""(.*)"" message displayed successfully")]
        public void ThenVerifyMessageDisplayedSuccessfully(string p0)
        {
            string expected = p0.ToString();
            string actual = fsAddDiagnosisCode.toasterMessagedisplay();
            Assert.IsTrue(expected.Contains(actual), expected + " is not displayed");
        }


        [Then(@"Verify PIR page ""(.*)"" button is enabled")]
        public void ThenVerifyPIRPageButtonIsEnabled(string p0)
        {
            Assert.IsTrue(RAM.ManageSuspectPage.AddDiagnosesButton.Enabled, p0 + "Is not enabled");
        }

        [When(@"Manage Suspects page ""(.*)"" button is Clicked PIR")]
        public void WhenManageSuspectsPageButtonIsClickedPIR(string p0)
        {
            fw.ExecuteJavascript(RAM.ManageSuspectPage.SearchButton);
            tmsWait.Hard(5);
        }

        [When(@"Manage Suspects page ""(.*)"" button is Clicked for No Search")]
        public void WhenManageSuspectsPageButtonIsClickedForNoSearch(string p0)
        {
            fw.ExecuteJavascript(RAM.ManageSuspectPage.SearchButton);
        }
        [When(@"Manage Suspects page ""(.*)"" button is Clicked and Then Verify message ""(.*)""")]
        [Then(@"Manage Suspects page ""(.*)"" button is Clicked and Then Verify message ""(.*)""")]
        public void ThenManageSuspectsPageButtonIsClickedAndThenVerifyMessage(string p0, string p1)
        {
            fw.ExecuteJavascript(RAM.ManageSuspectPage.SearchButton);
            // Comment Toaster message as Toaster message slowness
            //string expectedvalue = p1.ToString();
            //string actualvalue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;

            //Assert.IsTrue(expectedvalue.Contains(actualvalue), "Message is displayed successfully");
        }

        [When(@"Manage Suspects page ""(.*)"" record from memberid lookup is selected")]
        public void WhenManageSuspectsPageMemberIdFromMemberidLookupIsSelected(int p0)
        {
            string member_record = tmsCommon.GenerateData(p0.ToString());
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@test-id='manageSuspects-a-memberLookup']")));
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='member-btn-search']")));
            tmsWait.Hard(3);
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='lookup-grid-memberLookup']//tbody//tr[" + member_record + "]")));
            Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='lookup-grid-memberLookup']//tbody//tr[" + member_record + "]")).Click();
            tmsWait.Hard(1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@test-id='member-span-back']")));
            tmsWait.Hard(3);

        }


        [When(@"Manage Suspects page Search button is Clicked Successfully")]
        public void WhenManageSuspectsPageSearchButtonIsClickedSuccessfully()
        {
            fw.ExecuteJavascript(RAM.ManageSuspectPage.SearchButton);
        }

        [When(@"Manage Suspects page ""(.*)"" button is Clicked")]
        public void WhenManageSuspectsPageButtonIsClicked(string p0)
        {
            fw.ExecuteJavascript(RAM.ManageSuspectPage.SearchButton);
            tmsWait.Hard(20);
            bool flag = false;
            try
            {
                if (RAM.ManageSuspectPage.ConfirmationYesButton.Displayed)
                {
                    RAM.ManageSuspectPage.ConfirmationYesButton.Click();
                }
            }
            catch (Exception)
            {
                flag = true;
                //No any confirmation message
            }
            tmsWait.Hard(20);
        }


        [When(@"Manage Suspects page PIR Edit icon is clicked")]
        public void WhenManageSuspectsPagePIREditIconIsClicked()
        {
            ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='manageSuspects-grid-memberResult']//a[@title='Edit']")));
            tmsWait.Hard(15);
        }



        [When(@"Manage Suspects page Get the ""(.*)"" value and assign to ""(.*)""")]
        public void WhenManageSuspectsPageGetTheValueAndAssignTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = null;
            switch (field.ToLower())
            {
                case "dos": value = Browser.Wd.FindElement(By.XPath("//span[@test-id='pirResponse-span-dosTxt']")).Text; break;
                case "pir":
                    string heading = Browser.Wd.FindElement(By.XPath("//span[@test-id='pirResponse-span-heading']")).Text;
                    string[] heading_collection = heading.Split(' ');
                    value = heading_collection[1].Trim();
                    break;
            }

            fw.setVariable(p1, value);
        }

        [Then(@"Verify Report data ""(.*)"" is match with manage suspect screen data ""(.*)""")]
        public void ThenVerifyReportDataIsMatchWithManageSuspecScreenData(string p0, string p1)
        {
            string expectedvalue = tmsCommon.GenerateData(p0);
            string acutalvalue = tmsCommon.GenerateData(p1);
            Assert.IsTrue(acutalvalue.Contains(expectedvalue.Trim()), "Values does not match");
        }

        [Then(@"Verify Report data ""(.*)"" is match with database values ""(.*)""")]
        public void ThenVerifyReportDataIsMatchWithDatabaseValues(string p0, string p1)
        {
            string expectedvalue = tmsCommon.GenerateData(p0);
            string acutalvalue = tmsCommon.GenerateData(p1);
            Assert.IsTrue(acutalvalue.Contains(expectedvalue.Trim()), "Values does not match");
        }


        [Then(@"Verify Report data ""(.*)"" is same as manage suspect top hcc")]
        public void ThenVerifyReportDataIsSameAsManageSuspectTopHcc(string p0)
        {
            string expectedvalue = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(RAM.ManageSuspectPage.PageMemberTopKnownHCC);
            tmsWait.Hard(3);
            string tophcc = Browser.Wd.FindElement(By.XPath("//div[@id='topKnownHccGrid']//td[1]/span")).Text;
            if (tophcc != "N/A")
            {
                Assert.IsTrue(expectedvalue.Contains(tophcc), "Top known hcc does not match");
            }

            else
            {
                Console.WriteLine("Top Knwon HCC is not available");
            }

            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//span[contains(.,'Member Top')])[2]/following-sibling::button")));
            tmsWait.Hard(3);
        }





        [Then(@"Verify Manage Suspects page Chart Review source drop down contains source ""(.*)""")]
        public void ThenVerifyManageSuspectsPageChartReviewSourceDropDownContainsSource(string p0)
        {

            string expectedValue = tmsCommon.GenerateData(p0);
            bool found = false;
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='pirResponse-select-source']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + expectedValue + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

            tmsWait.Hard(2);

            IWebElement ddele = Browser.Wd.FindElement(By.XPath("(//label[text()='Chart Review Source']/parent::div//span[@class='k-input'])"));
            string actual_value = ddele.Text;
            Assert.IsTrue(actual_value.Contains(expectedValue), "Value does not match");


            //Assert.IsTrue(found);
        }




        [When(@"Verify Manage Suspect displayed with Provider Result")]
        public void WhenVerifyManageSuspectDisplayedWithProviderResult()
        {
            tmsWait.WaitForElement(By.Id("providerPirDetails1"), 370);
            Assert.IsTrue(RAM.ManageSuspectPage.ProviderResultGrid.Displayed);
        }


        [When(@"Manage Suspects page ""(.*)"" button is Clicked without criteria")]
        public void WhenManageSuspectsPageButtonIsClickedWithoutCriteria(string p0)
        {
            fw.ExecuteJavascript(RAM.ManageSuspectPage.SearchButton);
            tmsWait.Hard(2);
            bool flag = false;
            try
            {
                if (RAM.ManageSuspectPage.ConfirmationYesButton.Displayed)
                {
                    RAM.ManageSuspectPage.ConfirmationYesButton.Click();
                }
            }
            catch (Exception)
            {
                flag = true;
                //No any confirmation message
            }
        }

        [When(@"Manage Suspects Search Page Reset button is clicked")]
        public void WhenManageSuspectsSearchPageResetButtonIsClicked()
        {
            tmsWait.Hard(2);
            RAM.ManageSuspectPage.ResetButton.Click();
            tmsWait.Hard(2);
            Assert.IsTrue(RAM.ManageSuspectPage.LastName.GetAttribute("placeholder").Equals("ALL"));
            Assert.IsTrue(RAM.ManageSuspectsSearchResultpage.PlanMemberIDTextbox.GetAttribute("placeholder").Equals("ALL"));
        }


        [When(@"Manage Suspects result Next button is clicked")]
        public void WhenManageSuspectsResultNextButtonIsClicked()
        {
            //tmsWait.Hard(10);
            fw.ExecuteJavascript(RAM.ManageSuspectPage.NextButton);
            Assert.IsTrue(RAM.ManageSuspectPage.NextButton.GetAttribute("data-page").Equals(3));
        }

        [When(@"Verify Manage Suspects result count is ""(.*)""")]
        [Then(@"Verify Manage Suspects result count is ""(.*)""")]
        public void ThenVerifyManageSuspectsResultCountIs(string p0)
        {
            tmsWait.Hard(10);
            IWebElement field = Browser.Wd.FindElement(By.XPath("//div[@test-id='manageSuspects-grid-memberResult']//span[contains(.,'" + p0 + "')]"));
            Assert.IsTrue(field.Displayed, p0 + "is not displayed");
        }

        [When(@"PIR page Potential Related Diagnosis section is opened")]
        public void WhenPIRPagePotentialRelatedDiagnosisSectionIsOpened()
        {
            tmsWait.Hard(9);
            if (RAM.ManageSuspectPage.PotentialRelatedSection.Displayed)
            {
                fw.ExecuteJavascript(RAM.ManageSuspectPage.PotentialRelatedSection);
            }
        }

        [When(@"PIR page First Record Edit Action button is clicked")]
        public void WhenPIRPageFirstRecordEditActionButtonIsClicked()
        {
            try
            {
                tmsWait.Hard(8);
                fw.ExecuteJavascript(RAM.ManageSuspectPage.EditActionButton);
            }
            catch
            {
                fw.ExecuteJavascript(RAM.ManageSuspectPage.PotentialRelatedSection);
                tmsWait.Hard(5);
                RAM.ManageSuspectPage.EditActionButton.Click();
            }
        }

        [When(@"PIR page Add checkbox is checked")]
        public void WhenPIRPageAddCheckboxIsChecked()
        {
            tmsWait.Hard(2);
            RAM.ManageSuspectPage.AddCheckbox.Click();
        }

        [When(@"PIR page Encounter Date is entered ""(.*)""")]
        public void WhenPIRPageEncounterDateIsEntered(string date)
        {
            //date = DateTime.Today.AddDays(2).ToString("MM/dd/yyyy");
            //RAM.ManageSuspectPage.EncounterDateTextbox.SendKeys(date);
            RAM.ManageSuspectPage.EncounterDateTextbox.SendKeys(Browser.Wd.FindElement(By.XPath("(//span[@test-id='pirResponse-span-dosTxt'])[1]")).Text);
        }

        [When(@"PIR page Encounter Date is entered as ""(.*)""")]
        public void WhenPIRPageEncounterDateIsEnteredAs(string date)
        {
            string edate = Browser.Wd.FindElement(By.XPath("//span[@test-id='pirResponse-span-dosTxt']")).Text;
            // RAM.ManageSuspectPage.EncounterDateTextbox.SendKeys(DateTime.Today.ToString("MM/dd/yyyy"));
            // Code update to enter date as encounter date or year should be alway date of claim year or date, so here claim date of PIR will fetch runtime and insert
            AngularFunction.enterRAM_EncounterDate(RAM.ManageSuspectPage.EncounterDateTextbox, edate);


        }

        [When(@"PIR page ProviderId is entered as ""(.*)""")]
        public void WhenPIRPageProviderIdIsEnteredAs(string p0)
        {
            string provdid = tmsCommon.GenerateData(p0.ToString());
            IWebElement Provider = Browser.Wd.FindElement(By.XPath("//input[@name='providerId']"));
            Provider.Clear();
            Provider.SendKeys(provdid);
        }


        [When(@"PIR page Invalid Encounter Date is entered ""(.*)""")]
        public void WhenPIRPageInvalidEncounterDateIsEntered(string Sdate)
        {
            //RAM.ManageSuspectPage.EncounterDateTextbox.SendKeys(p0);

            AngularFunction.enterDate(RAM.ManageSuspectPage.EncounterDateTextbox, Sdate);
        }


        [When(@"PIR page Save button is clicked")]
        public void WhenPIRPageSaveButtonIsClicked()
        {
            tmsWait.Hard(10);
            //fw.ExecuteJavascript(RAM.ManageSuspectPage.SaveButton);
            fw.ExecuteJavascript(RAM.ManageSuspectPage.SaveButton);
            tmsWait.Hard(5);
        }
        [Then(@"PIR page Save button is clicked and PIR Page Verify Error message ""(.*)""")]
        public void ThenPIRPageSaveButtonIsClickedAndPIRPageVerifyErrorMessage(string p0)
        {
            try
            {


                tmsWait.Hard(5);
                //fw.ExecuteJavascript(RAM.ManageSuspectPage.SaveButton);
                RAM.ManageSuspectPage.SaveButton.Click();
                RAM.ManageSuspectPage.SaveButton.Click();
                //ReUsableFunctions.toasterMessageDisplayVerification(p0);

                string actualvalue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                string expectedvalue = p0.ToString();
                Assert.IsTrue(actualvalue.Contains(expectedvalue), "Message is not displayed successfully");
            }
            catch
            {
                tmsWait.Hard(1);
                bool tru = RAM.ManageSuspectPage.SaveButton.Enabled;
                Assert.IsTrue(tru);
            }
        }
        [Then(@"PIR Page Verify Error message ""(.*)""")]
        public void ThenPIRPageVerifyErrorMessage(string message)
        {
            if (Browser.Wd.FindElement(By.XPath(".//*[@id='toast-container']/div/div/div")).Displayed)
            {
                Assert.IsTrue(Browser.Wd.FindElement(By.XPath(".//*[@id='toast-container']/div/div/div")).Text.Contains(message));
            }
        }

        [When(@"PIR page Encounter Risk Access Code is entered as ""(.*)""")]
        public void WhenPIRPageEncounterRiskAccessCodeIsEnteredAs(string code)
        {
            RAM.ManageSuspectPage.RiskAccessCodeTextbox.Clear();
            RAM.ManageSuspectPage.RiskAccessCodeTextbox.SendKeys(code);

        }

        [When(@"PIR page claim number is entered as ""(.*)""")]
        public void WhenPIRPageClaimNumberIsEnteredAs(int p0)
        {
            RAM.ManageSuspectPage.ClaimNumber.Clear();
            RAM.ManageSuspectPage.ClaimNumber.SendKeys(p0.ToString());
            tmsWait.Hard(1);
        }



        void enterValueOnFiels(string name, string value)
        {
            IWebElement temp = Browser.Wd.FindElement(By.CssSelector("[name='providerId']"));
            temp.SendKeys(value);
        }

        [When(@"Manage Suspects page Addional Diagnoses table ""(.*)"" is set to ""(.*)""")]
        public void WhenManageSuspectsPageAddionalDiagnosesTableIsSetTo(string p0, string value)
        {
            tmsWait.Hard(2);
            string name = null;
            string tablecomp = p0.ToString();
            switch (tablecomp)
            {
                case "Code":
                    name = "code";
                    //enterValueOnFiels(name, value);
                    Browser.Wd.FindElement(By.XPath("//input[@test-id='searchDiag-txt-txtDiagCode']")).SendKeys(value);
                    tmsWait.Hard(1);
                    break;
                case "Encounter Date":
                    string yesterday = DateTime.Now.AddDays(-1).ToString("M/d/yyyy");
                    Browser.Wd.FindElement(By.XPath("//input[@data-role='datepicker']")).SendKeys(yesterday);
                    tmsWait.Hard(1);
                    break;
                case "Provider ID":
                    name = "providerId";
                    //enterValueOnFiels(name, value);
                    value = Browser.Wd.FindElement(By.XPath("//span[@test-id='pirResponse-span-providerIdTxt']")).Text;
                    Browser.Wd.FindElement(By.XPath("//input[@test-id='searchDiag-txt-txtProviderId']")).SendKeys(value);
                    tmsWait.Hard(1);
                    break;
                case "Risk Assess Code":
                    name = "riskAssessCode";
                    //enterValueOnFiels(name, value);
                    By Drp = By.XPath("//kendo-dropdownlist[@test-id='searchDiag-txt-riskAssessment']//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + value + "']");
                    fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                    fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                    tmsWait.Hard(1);
                    break;
                case "Claim Number":
                    name = "claimNumber";
                    Browser.Wd.FindElement(By.XPath("//input[@test-id='searchDiag-txt-txtPlanClaimId']")).SendKeys(value);
                    //enterValueOnFiels(name, value);
                    tmsWait.Hard(1);
                    break;

            }
        }

        [When(@"PIR page Potential Related Diagnosis Provider Id is set to ""(.*)""")]
        public void WhenPIRPagePotentialRelatedDiagnosisProviderIdIsSetTo(string p0)
        {
            string value = Browser.Wd.FindElement(By.XPath("//span[@test-id='pirResponse-span-providerIdTxt']")).Text;
            Browser.Wd.FindElement(By.XPath("//input[@id='providerId']")).SendKeys("100104000000");
            tmsWait.Hard(1);
        }



        [When(@"Manage Suspects page Addional Diagnoses table Save button is Clicked")]
        public void WhenManageSuspectsPageAddionalDiagnosesTableSaveButtonIsClicked()
        {

            IWebElement Savebutton = Browser.Wd.FindElement(By.XPath("//button[@test-id='searchDiag-btn-add']"));
            AngularFunction.clickOnElement(Savebutton);
            tmsWait.Hard(2);

        }


        [When(@"Manage Suspects page I certify that the above information is accurate to the best of my knowledge, information and belief checkbox is ""(.*)""")]
        public void WhenManageSuspectsPageICertifyThatTheAboveInformationIsAccurateToTheBestOfMyKnowledgeInformationAndBeliefCheckboxIs(string p0)
        {
            tmsWait.Hard(2);
            string state = RAM.ManageSuspectPage.AgreeCheckbox.GetAttribute("checked");
            if ((state.Equals("true")) && (p0.Equals("Checked")))
            {
                fw.ConsoleReport(" Certify check box is already checked");
            }
            else if (p0.Equals("UnChecked"))
            {
                tmsWait.Hard(2);
                //RAM.ManageSuspectPage.AgreeCheckbox.Click();
                fw.ExecuteJavascript(RAM.ManageSuspectPage.AgreeCheckbox);
            }
        }


        [When(@"Manage Suspect page ""(.*)"" is Clicked")]
        public void WhenManageSuspectPageIsClicked(string p0)
        {
            IWebElement element = null;
            string comp = p0.ToString();
            switch (comp)
            {
                case "Additional Diagnoses Accordion":
                    //element = Browser.Wd.FindElement(By.XPath("//*[@test-id='pirResponse-title-additionalDiagnoses']"));
                    element = Browser.Wd.FindElement(By.XPath("//label[contains(.,' Additional Diagnosis')]//parent::div/i"));
                    fw.ExecuteJavascript(element);
                    break;
                case "Add New Record":
                    element = Browser.Wd.FindElement(By.XPath("//a[@class='k-button k-button-icontext k-grid-add']"));
                    fw.ExecuteJavascript(element);

                    break;
            }
        }

        void clickonWebComponent(IWebElement com)
        {
            fw.ExecuteJavascript(com);
        }

        [When(@"PIR page ""(.*)"" button is Clicked")]
        [Given(@"PIR page ""(.*)"" button is Clicked")]
        [Then(@"PIR page ""(.*)"" button is Clicked")]
        public void WhenPIRPageButtonIsClicked(string component)
        {
            tmsWait.Hard(5);
            switch (component)
            {
                case "ADD Diagnosis":
                    fw.ExecuteJavascript(RAM.ManageSuspectPage.AddDiagnosesButton);
                    //tmsWait.WaitForElement(By.CssSelector("[test-id='confirmationDialog-div-dialog']"),30);
                    tmsWait.Hard(2);
                    warningDialogClickonButton(RAM.ManageSuspectPage.WarningdialogOK);
                    break;
                case "Back To Record":
                    tmsWait.Hard(2);
                    fw.ExecuteJavascript(RAM.ManageSuspectPage.BackToRecord);
                    break;
                case "ADD DIAGNOSES":
                    clickonWebComponent(RAM.ManageSuspectPage.AddDiagnosesButton);
                    break;

                case "Submit":
                    clickonWebComponent(RAM.ManageSuspectPage.AddDiagnosesButton);
                    tmsWait.Hard(2);
                    warningDialogClickonButton(RAM.ManageSuspectPage.WarningdialogOK);
                    break;
            }

        }


        [Then(@"Verify PIR page Submit button is disabled")]
        public void ThenVerifyPIRPageSubmitButtonIsDisabled()
        {
            bool ispresent = false;
            try
            {
                string svalue = Browser.Wd.FindElement(By.XPath("//button[@test-id='pirResponse-btn-add']")).GetAttribute("aira-disabled");
                if (svalue == "true")
                {
                    ispresent = true;
                }
            }
            catch { }

            Assert.IsTrue(ispresent, "submitted button is not disabled");
        }


        [When(@"PIR page ""(.*)"" button Clicked")]
        public void WhenPIRPageButtonClicked(string p0)
        {
            clickonWebComponent(RAM.ManageSuspectPage.AddDiagnosesButton);
            tmsWait.Hard(3);
        }

        [When(@"PIR page Confirmation dialog ""(.*)"" button is Clicked")]
        public void WhenPIRPageConfirmationDialogButtonIsClicked(string p0)
        {
            fw.ExecuteJavascript(RAM.ManageSuspectPage.WarningdialogCancel);
            tmsWait.Hard(3);
        }





        [Then(@"PIR page ""(.*)"" button is Clicked and Verify ""(.*)"" displayed successfully")]
        [When(@"PIR page ""(.*)"" button is Clicked and Verify ""(.*)"" displayed successfully")]
        public void WhenPIRPageButtonIsClickedAndVerifyDisplayedSuccessfully(string p0, string p1)
        {
            fw.ExecuteJavascript(RAM.ManageSuspectPage.AddDiagnosesButton);
            //tmsWait.WaitForElement(By.CssSelector("[test-id='confirmationDialog-div-dialog']"),30);
            tmsWait.Hard(2);
            warningDialogClickonButton(RAM.ManageSuspectPage.WarningdialogOK);


            //string actualvalue = Browser.Wd.FindElement(By.ClassName("toast-message")).GetAttribute("aria-label");
            string expectedvalue = p1.ToString();
            // Assert.IsTrue(expectedvalue.Contains(actualvalue), "Message is displayed successfully");

        }
        [When(@"PIR page ""(.*)"" button is Clicked and Verify msg ""(.*)"" displayed successfully")]
        public void WhenPIRPageButtonIsClickedAndVerifyMsgDisplayedSuccessfully(string p0, string p1)
        {
            fw.ExecuteJavascript(RAM.ManageSuspectPage.AddDiagnosesButton);
            // Comment due to Toaster slowness
            //tmsWait.WaitForElement(By.CssSelector("[test-id='confirmationDialog-div-dialog']"),30);
            //tmsWait.Hard(2);
            //warningDialogClickonButton(RAM.ManageSuspectPage.WarningdialogOK);
          
        }

        [When(@"PIR page ""(.*)"" button is Clicked and success message ""(.*)"" varified")]
        public void WhenPIRPageButtonIsClickedAndSuccessMessageVarified(string p0, string p1)
        {
            fw.ExecuteJavascript(RAM.ManageSuspectPage.AddDiagnosesButton);
            //tmsWait.WaitForElement(By.CssSelector("[test-id='confirmationDialog-div-dialog']"),30);
            tmsWait.Hard(2);
            warningDialogClickonButton(RAM.ManageSuspectPage.WarningdialogOK);
            ReUsableFunctions.toasterMessageDisplayVerification(p1);

        }

        [When(@"PIR page ""(.*)"" button is Clicked and Success message ""(.*)"" verified")]
        public void WhenPIRPageButtonIsClickedAndSuccessMessageVerified(string p0, string p1)
        {

            fw.ExecuteJavascript(RAM.ManageSuspectPage.AddDiagnosesButton);
            //tmsWait.WaitForElement(By.CssSelector("[test-id='confirmationDialog-div-dialog']"),30);
            tmsWait.Hard(2);
            warningDialogClickonButton(RAM.ManageSuspectPage.WarningdialogOK);
            // ReUsableFunctions.toasterMessageDisplayVerification(p1);

            string actualvalue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
            string expectedvalue = p1.ToString();
            Assert.IsTrue(actualvalue.Contains(expectedvalue), "Message is displayed successfully");
        }



        [Then(@"Verify ""(.*)"" page is opened Successfully")]
        public void ThenVerifyPageIsOpenedSuccessfully(string page)
        {
            tmsWait.Hard(12);
            string expected = page.ToString();
            switch (page.ToLower())
            {
                case "add diagnosis codes":
                    Assert.AreEqual(expected, RAM.AddDiagnosisCodesPage.RAMAaddDiagnosisCodeslable.Text, expected + " Title is not getting displayed");
                    break;
                case "add reasons":
                    Assert.AreEqual(expected, RAM.AddReasonsPage.RAMAaddReasonslable.Text, expected + " Title is not getting displayed");
                    break;
                case "customize pir cover letter":
                    tmsWait.Hard(3);
                    Assert.AreEqual(expected, RAM.PIRCoverLetter.PIRCoverLetterTitle.Text, expected + " Title is not getting displayed");
                    break;
                case "Suspect Assignment Options":
                    Assert.AreEqual(expected, RAM.WorkflowOptions.ProspectiveMgmntTitle.Text, expected + " Title is not getting displayed");
                    break;
                case "manage suspect search":
                    Assert.IsTrue(RAM.ManageSuspectsSearchResultpage.ManageSuspectSearchPageProviderLabel.Displayed);
                    break;
                case "manage suspect":
                    Assert.IsTrue(RAM.ManageSuspectPage.ManageSuspectBlock.Displayed);
                    break;
                case "Cancel Suspect Search":
                    Assert.IsTrue(RAM.CancelSuspectPage.CancelSuspectsButton.Displayed);
                    break;
                case "Update Provider Info":
                    Assert.IsTrue(Suspects.UpdateProviderInfo.ProviderIDLabel.Displayed);
                    break;

                case "view notes":

                    Assert.IsTrue(RAM.ManageSuspectPage.AddNoteBtn.Displayed);
                    break;
                case "Add On-Hold Reasons":

                    Assert.IsTrue(RAM.AddOnHoldReasons.AddOnHoldReasonLabel.Displayed);
                    break;
                case "Export List:":

                    Assert.IsTrue(RAM.ExportPage.ExportsTitle.Displayed);
                    break;

            }
        }

        [Then(@"Verify all UI objects on Administration - Add Diagnosis Codes screen")]
        public void ThenVerifyAllUIObjectsOnAdministration_AddDiagnosisCodesScreen()
        {
            tmsWait.Implicit(30);
            tmsWait.Hard(2);
            fw.ExecuteJavascript(RAM.AddDiagnosisCodesPage.RAMAaddICD9Code);
            // Assert.IsTrue(RAM.AddDiagnosisCodesPage.RAMAaddICD9Code.Displayed, "ICD-9 radio button is not displayed");
            Assert.IsTrue(RAM.AddDiagnosisCodesPage.RAMAaddICD10Code.Displayed, "ICD-10 radio button is not displayed");
            Assert.IsTrue(RAM.AddDiagnosisCodesPage.RAMAICDCode.Displayed, "Diagnosis Code text box is not displayed");
            Assert.IsTrue(RAM.AddDiagnosisCodesPage.RAMAICDDescription.Displayed, "Description text box is not displayed");
            Assert.IsTrue(RAM.AddDiagnosisCodesPage.RAMAICDCodeAddButton.Displayed, "Add button is not displayed");
            Assert.IsTrue(RAM.AddDiagnosisCodesPage.RAMAICDCodeResetButton.Displayed, "Description text box is not displayed");
            Assert.IsTrue(RAM.AddDiagnosisCodesPage.RAMAICDCodeResetButton.Displayed, "Description text box is not displayed");
            //Assert.IsTrue(RAM.AddDiagnosisCodesPage.RAMAaddDiagnosisCodesGrid.Displayed, "Diagnosis Codes added by User Grid is not displayed");

        }



        [When(@"Add Diagnosis Codes page ""(.*)"" diagnosis code is selected")]
        public void WhenAddDiagnosisCodesPageDiagnosisCodeIsSelected(string p0)
        {
            string code = p0.ToString();
            tmsWait.Hard(2);
            switch (code)
            {
                case "ICD-9":
                    fw.ExecuteJavascript(RAM.AddDiagnosisCodesPage.RAMAaddICD9Code);

                    break;
                case "ICD-10":
                    fw.ExecuteJavascript(RAM.AddDiagnosisCodesPage.RAMAaddICD10CodeRadio);
                    break;
            }

        }


        [Then(@"verify ""(.*)"" diagnosis code is selected")]
        public void ThenVerifyDiagnosisCodeIsSelected(string p0)
        {
            string code = p0.ToString();
            tmsWait.Hard(2);
            switch (code)
            {
                case "ICD-9":
                    bool isSelected = RAM.AddDiagnosisCodesPage.RAMAaddICD9Code.Selected;
                    Assert.IsTrue(RAM.AddDiagnosisCodesPage.RAMAaddICD9Code.Selected, "ICD-9 Radio button is not selected");

                    break;
                case "ICD-10":
                    Assert.IsTrue(RAM.AddDiagnosisCodesPage.RAMAaddICD10CodeRadio.Selected, "ICD-10 Radio button is not selected");
                    break;
            }
        }


        [When(@"Add Diagnosis Code page Diagnosis code is set to ""(.*)""")]
        [Then(@"Add Diagnosis Code page Diagnosis code is set to ""(.*)""")]
        public void WhenAddDiagnosisCodePageDiagnosisCodeIsSetTo(string p0)
        {
            string temp = tmsCommon.GenerateData(p0);
            RAM.AddDiagnosisCodesPage.RAMAICDCode.Clear();
            RAM.AddDiagnosisCodesPage.RAMAICDCode.SendKeys(temp);
        }

        [When(@"Add Diagnosis Code page Diagnosis Description is set to ""(.*)""")]
        public void WhenAddDiagnosisCodePageDiagnosisDescriptionIsSetTo(string p0)
        {
            string temp = tmsCommon.GenerateData(p0);
            tmsWait.Hard(2);
            RAM.AddDiagnosisCodesPage.RAMAICDDescription.Clear();
            RAM.AddDiagnosisCodesPage.RAMAICDDescription.SendKeys(temp);
        }
        [Then(@"Add Diagnosis Code page New Diagnosis Description is set to ""(.*)""")]
        public void ThenAddDiagnosisCodePageNewDiagnosisDescriptionIsSetTo(string p0)
        {
            string temp = tmsCommon.GenerateData(p0);
            tmsWait.Hard(2);
            RAM.AddDiagnosisCodesPage.RAMAICDNewDescription.Clear();
            RAM.AddDiagnosisCodesPage.RAMAICDNewDescription.SendKeys(temp);
        }

        [Then(@"Add Diagnosis Code page Clicked on Save button under Diagnosis code as ""(.*)""")]
        public void ThenAddDiagnosisCodePageClickedOnSaveButtonUnderDiagnosisCodeAs(string p0)
        {
            string code = tmsCommon.GenerateData(p0);

            By save = By.XPath("//tr[contains(.,'" + code + "')]//button/span[@class='fas fa-save']");
            AngularFunction.clickOnElement(save);
            tmsWait.Hard(2);
        }


        [When(@"Add Diagnosis Code page Add Button is Clicked")]
        [Then(@"Add Diagnosis Code page Add Button is Clicked")]
        public void WhenAddDiagnosisCodePageAddButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.AddDiagnosisCodesPage.RAMAICDCodeAddButton);
            tmsWait.Hard(2);
        }

        [Then(@"verify there is no value in ""(.*)"" edit box")]
        public void ThenVerifyThereIsNoValueInEditBox(string p0)
        {
            IWebElement ele = null;
            string option = tmsCommon.GenerateData(p0);
            switch (option)
            {
                case "Diagnosis Code":
                    ele = RAM.AddDiagnosisCodesPage.RAMAICDCode;
                    break;
                case "Description":
                    ele = RAM.AddDiagnosisCodesPage.RAMAICDDescription;
                    break;
            }
            Assert.AreEqual("", ele.Text, "Value is not removed in the Edit Box");
        }


        [When(@"Add Diagnosis Code page Reset Button is Clicked")]
        public void WhenAddDiagnosisCodePageResetButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.AddDiagnosisCodesPage.RAMAICDCodeResetButton);
            tmsWait.Hard(2);
        }


        [When(@"Exports page ""(.*)"" link is Clicked")]
        public void WhenExportsPageLinkIsClicked(string p0)
        {
            tmsWait.Hard(2);
            IWebElement exportJob = Browser.Wd.FindElement(By.XPath("//div[@id='exportJobslist']//label[contains(.,'" + p0 + "')]"));
            fw.ExecuteJavascript(exportJob);
            tmsWait.Hard(5);
        }

        [When(@"CMS Extract page Plan ID field is set to ""(.*)""")]
        public void WhenCMSExtractPagePlanIDFieldIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            GlobalRef.PlanID = value;
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='PlanId']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + value + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }

        [When(@"CMS Extract page File Type field is set to ""(.*)""")]
        public void WhenCMSExtractPageFileTypeFieldIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string value = tmsCommon.GenerateData(p0);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='FileType']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + value + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }
        [Given(@"RAM report page Plan ID is set to ""(.*)""")]
        [When(@"RAM report page Plan ID is set to ""(.*)""")]
        [Then(@"RAM report page Plan ID is set to ""(.*)""")]
        public void WhenRAMReportPagePlanIDIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='PlanId']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + value + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
        }

        [When(@"CMS Extract page ""(.*)"" is set to ""(.*)""")]
        public void WhenCMSExtractPageIsSetTo(string field, string value)
        {
            string plan = tmsCommon.GenerateData(value);

            switch (field)
            {
                case "Plan ID":
                    By Drp = By.XPath("//kendo-dropdownlist[@test-id='PlanId']//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + plan + "']");
                    fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                    fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                    tmsWait.Hard(3);
                    break;
                case "File Type":
                    By fileType = By.XPath("//kendo-dropdownlist[@test-id='FileType']//span[@class='k-select']");
                    By fileTypeValue = By.XPath("//li[text()='" + plan + "']");
                    fw.ExecuteJavascript(Browser.Wd.FindElement(fileType));
                    fw.ExecuteJavascript(Browser.Wd.FindElement(fileTypeValue));
                    tmsWait.Hard(3);
                    break;
            }
        }


        [When(@"CMS Extract page Export button is Clicked")]
        public void WhenCMSExtractPageExportButtonIsClicked()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[test-id='export-btn-runReport']")));
            tmsWait.Hard(5);
        }

        [Then(@"Verify mesaage ""(.*)""")]
        public void ThenVerifyMesaage(string toastmessage)
        {
            By toastMsg = By.XPath("//div[@class='k-notification-content']");
            string actValue = Browser.Wd.FindElement(toastMsg).Text;
            Assert.IsTrue(actValue.Contains(toastmessage));
        }
        [When(@"Verify mesaage ""(.*)"" and ""(.*)"" is added")]
        public void WhenVerifyMesaageAndIsAdded(string p0, string p1)
        {



            try
            {
                By toastMsg = By.XPath("//div[@class='k-notification-content']");
                string actualValue = Browser.Wd.FindElement(toastMsg).Text;
                Assert.AreEqual(p0, actualValue, "Message is not displyed successfully ");
                //string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                //string expectedValue = p0.ToString();
                //Assert.AreEqual(expectedValue, actualValue, "Message is not displyed successfully ");
            }
            catch
            {
                tmsWait.Hard(2);
                //KendoUIFunctions.ResultGridTextValidation(p1);
                bool isDisplayed = Browser.Wd.FindElement(By.XPath("//table[@role='grid']//td[contains(.,'" + p1 + "')]")).Displayed;
                Assert.IsTrue(isDisplayed, "Diag code Added successfully");
            }
        }

        [Then(@"Verify RAM Provider IncludeExclude message is displayed")]
        public void ThenVerifyRAMProviderIncludeExcludeMesaageIsDisplayed()
        {
            tmsWait.Hard(2);
            bool isDisplayed = Browser.Wd.FindElement(By.XPath("//label[@test-id='excludeProviders-lbl-message']")).Displayed;
            Assert.IsTrue(isDisplayed, "Provider page Include/Exclude message is displayed");
        }

        [When(@"I clicked on ""(.*)"" on Warnig popup window and success message ""(.*)"" varified for ""(.*)""")]
        public void WhenIClickedOnOnWarnigPopupWindowAndSuccessMessageVarifiedFor(string p0, string p1, string p2)
        {


            try
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")));

                By toastMsg = By.XPath("//div[@class='k-notification-content']");
                string actualValue = Browser.Wd.FindElement(toastMsg).Text;
                string expectedValue = p1.ToString();
                Assert.AreEqual(expectedValue, actualValue, "Message is not displyed successfully ");
            }
            catch
            {

                IList<IWebElement> idc = Browser.Wd.FindElements(By.XPath("//table[@role='grid']//td[contains(.,'" + p2 + "')]"));
                int x = 0;
                int y = Convert.ToInt32(idc.Count);
                x = Convert.ToInt32(x);
                bool notpresent = y.Equals(x);
                Assert.IsTrue(notpresent, "Diag code deleted successfully");
            }
        }

        [Then(@"Verify Successfull Toaster message ""(.*)""")]
        public void ThenVerifySuccessfullToasterMessage(string p0)
        {

            ReUsableFunctions.toasterMessageDisplay(p0);
        }

        [Then(@"Verify warning message is displayed ""(.*)""")]
        public void ThenVerifyWarningMessageIsDisplayed(string p0)
        {
            string expText = tmsCommon.GenerateData(p0);
            bool isDisplayed = Browser.Wd.FindElement(By.XPath(".//span[contains(text(), '" + expText + "')]")).Displayed;
            Assert.IsTrue(isDisplayed, "Error : Warning message not displayed or is incorrect");

        }


        [Then(@"Verify ""(.*)"" displayed in result grid")]
        public void ThenVerifyDisplayedInResultGrid(string p0)
        {
            string actualCode = tmsCommon.GenerateData(p0.ToString());
            KendoUIFunctions.ResultGridTextValidation(actualCode);
        }


        [Then(@"Verify Add Diagnosis Codes page user is able to edit Diagnosis code as ""(.*)"" and Discription as ""(.*)"" And Update description And Click on Save Button")]
        public void ThenVerifyAddDiagnosisCodesPageUserIsAbleToEditDiagnosisCodeAsAndDiscriptionAsAndUpdateDescriptionAndClickOnSaveButton(string codeforedit, string descriptioncodeedit)
        {

            tmsWait.Hard(3);
            fw.ExecuteJavascript(RAM.AddDiagnosisCodesPage.RAMAICDCodeResetButton);
            tmsWait.Hard(2);
            string actualCode = tmsCommon.GenerateData(codeforedit);
            string actualDescription = tmsCommon.GenerateData(descriptioncodeedit);

            By loc = By.XPath("//*[@test-id='diagnosisCodes-table-codes']//td[contains(.,'" + actualCode + "')]/following-sibling::td[contains(.,'" + actualDescription + "')]");
            By loctoEdit = By.XPath("//*[@test-id='diagnosisCodes-table-codes']//td[contains(.,'" + actualCode + "')]/following-sibling::td[contains(.,'" + actualDescription + "')]/following-sibling::td/button/span[@class='fas fa-pencil-alt']");

            bool flag = false;

            while (!flag)
            {
                try
                {
                    tmsWait.Hard(1);
                    AngularFunction.elementPresenceUsingLocators(loctoEdit);
                    AngularFunction.clickOnElement(loctoEdit);
                    tmsWait.Hard(2);
                    flag = true;
                }
                catch
                {
                    AngularFunction.clickonNextLink();
                    tmsWait.Hard(1);
                }
            }

            //do
            //{
            //    nextPage = VerifyDiagnosisCodeForEdit(actualCode, actualDescription);
            //    if (nextPage)
            //    {
            //        Browser.Wd.FindElement(By.LinkText("Next")).Click();
            //    }
            //} while (nextPage);

            //KendoUIFunctions.ResultGridTextValidation(actualCode);
            //KendoUIFunctions.EditAndUpdateResultGridRecord(actualCode, actualDescription);

        }

        /// <summary>
        /// Verify Code and Description on Diagnosis Page
        /// </summary>
        /// <param name="code">Code</param>
        /// <param name="description">Description</param>
        /// <returns>Boolean value based on search result</returns>
        public bool VerifyDiagnosisCodeForEdit(string code, string description)
        {
            try
            {
                if (Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + code + "')]/parent::td/following-sibling::td/span[contains(.,'" + description + "')]")).Displayed)
                {

                    return false;

                }
            }
            catch (Exception ex)
            {
                return true;
            }
            return true;


        }



        [When(@"RAM Apllication will be closed")]
        [Then(@"RAM Apllication will be closed")]
        [Then(@"RAMX Apllication will be closed")]
        [Given(@"RAMX Apllication will be closed")]
        [Then(@"RAM Application will be closed")]
        [Then(@"RAM will be closed")]
        public void ThenRAMApllicationWillBeClosed()
        {
            // Browser.CloseWebDriver();
        }




        [Then(@"Verify Add Diagnosis Codes page user is able to delete Diagnosis code as ""(.*)"" and Discription as ""(.*)""")]
        public void ThenVerifyAddDiagnosisCodesPageUserIsAbleToDeleteDiagnosisCodeAsAndDiscriptionAs(string code, string description)
        {
            tmsWait.Hard(5);

            string actualCode = tmsCommon.GenerateData(code);
            string actualDescription = tmsCommon.GenerateData(description);

            By loc = By.XPath("//kendo-grid[@test-id='diagnosisCodes-table-codes']//td[contains(.,'" + actualCode + "')]/following-sibling::td[contains(.,'" + actualDescription + "')]");
            By loctoDelete = By.XPath("//kendo-grid[@test-id='diagnosisCodes-table-codes']//td[contains(.,'" + actualCode + "')]/following-sibling::td[contains(.,'" + actualDescription + "')]//following-sibling::td/button[contains(@class,'remove')]");

            bool flag = false;

            while (!flag)
            {
                try
                {
                    tmsWait.Hard(2);
                    AngularFunction.elementPresenceUsingLocators(loc);
                    AngularFunction.clickOnElement(loctoDelete);
                    tmsWait.Hard(2);

                    flag = true;
                }
                catch
                {
                    AngularFunction.clickonNextLink();
                }
            }
        }

        /// <summary>
        /// Verify Code and Description on Diagnosis Page
        /// </summary>
        /// <param name="code">Code</param>
        /// <param name="description">Description</param>
        /// <returns>Boolean value based on search result</returns>
        public bool VerifyDiagnosisCodeForDelete(string code, string description)
        {
            try
            {
                if (Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + code + "')]/parent::td/following-sibling::td/span[contains(.,'" + description + "')]")).Displayed)
                {

                    return false;

                }
            }
            catch (Exception ex)
            {
                return true;
            }
            return true;


        }

        [When(@"I clicked on ""(.*)"" on Warnig popup window")]
        public void WhenIClickedOnOnWarnigPopupWindow(string inputaction)
        {
            tmsWait.Hard(5);


            switch (inputaction.ToLower())
            {
                case "ok":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")));

                    break;
                case "cancel":
                    //Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-No']")).Click();
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-No']")));
                    break;
            }

        }


        [Then(@"verify Forward and Back button functioanlity on Add Diagnosis Codes page")]
        public void ThenVerifyForwardAndBackButtonFunctioanlityOnAddDiagnosisCodesPage()
        {
            for (int i = 0; i < 10; i++)
            {
                string temp = tmsCommon.GenerateData("Generate|alpha[2]|num|4|");
                RAM.AddDiagnosisCodesPage.RAMAICDCode.Clear();
                RAM.AddDiagnosisCodesPage.RAMAICDCode.SendKeys(temp);

                RAM.AddDiagnosisCodesPage.RAMAICDDescription.Clear();
                RAM.AddDiagnosisCodesPage.RAMAICDDescription.SendKeys("QADesc_" + temp);
                fw.ExecuteJavascript(RAM.AddDiagnosisCodesPage.RAMAICDCodeAddButton);
                tmsWait.Hard(2);
            }

            IWebElement nextPage = Browser.Wd.FindElement(By.XPath("//span[@class='k-icon k-i-arrow-e']"));
            IWebElement prevPage = Browser.Wd.FindElement(By.XPath("//span[@class='k-icon k-i-arrow-w']"));

            int oldPageNum = Convert.ToInt32(Browser.Wd.FindElement(By.XPath("//input[@class='k-input k-formatted-value']")).GetAttribute("aria-valuenow"));
            fw.ExecuteJavascript(nextPage);
            tmsWait.Implicit(10);
            tmsWait.Hard(2);
            int actualPageNum = Convert.ToInt32(Browser.Wd.FindElement(By.XPath("//input[@class='k-input k-formatted-value']")).GetAttribute("aria-valuenow"));
            Assert.AreEqual(oldPageNum + 1, actualPageNum, "User not navigated to the next page");
            tmsWait.Hard(2);
            fw.ExecuteJavascript(prevPage);
            tmsWait.Hard(2);
            int pagenumberAfter = Convert.ToInt32(Browser.Wd.FindElement(By.XPath("//input[@class='k-input k-formatted-value']")).GetAttribute("aria-valuenow"));
            Assert.AreEqual(actualPageNum - 1, pagenumberAfter, "User not navigated to the next page");

        }

        [When(@"PIRPage Clicked on ""(.*)""")]
        public void WhenPIRPageClickedOn(string p0)
        {
            tmsWait.Hard(2);
            AngularFunction.clickOnElement(RAM.ManageSuspectPage.MemberTopKnownHCC);
            tmsWait.Hard(2);

        }

        [When(@"I Entered the project name ""(.*)"" and clicked on ""(.*)"" button")]
        public void WhenIEnteredTheProjectNameAndClickedOnButton(string p0, string p1)

        {

            string projectname = tmsCommon.GenerateData(p0);
            string Useraction = tmsCommon.GenerateData(p1);
            //Enter Project Name 
            RAM.ManageSuspectPage.MaintainProjectEnterProjectName.SendKeys(projectname);
            tmsWait.Hard(1);
            //Use action based code 
            switch (Useraction) {
                case "Close":
                    IWebElement close = Browser.Wd.FindElement(By.XPath("//a[@class='k-button k-bare k-button-icon k-window-action k-dialog-action k-dialog-close']"));
                    AngularFunction.clickOnElement(close);
                    tmsWait.Hard(2);
                    //Assert that popup window is closed now 
                    By loc = By.XPath("//span[contains(text(),'Add Project')]");
                    AngularFunction.elementNotPresenceUsingLocators(loc);
                    break;
                case "ADD":
                    AngularFunction.clickOnElement(RAM.ManageSuspectPage.MaintainProjectAddProjectButton);
                    break;
            }

        }


        [Then(@"Verify that the ""(.*)"" popup is opened successfully")]
        public void ThenVerifyThatThePopupIsOpenedSuccessfully(string title)
        {
            //Assert the popup Title
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[contains(text(),'" + title + "')]")).Displayed);

        }

        [When(@"Maintain Project page I clicked on ""(.*)"" button")]
        public void WhenMaintainProjectPageIClickedOnButton(string p0)
        {
            tmsWait.Hard(1);
            AngularFunction.clickOnElement(RAM.ManageSuspectPage.MaintainProjectSearchButton);
            tmsWait.Hard(30);
        }

        [Then(@"Maintain Project page Verify that Project dropdown has ""(.*)"" and ""(.*)""")]
        public void ThenMaintainProjectPageVerifyThatProjectDropdownHasAnd(string p0, string p1)
        {
            string Project1 = tmsCommon.GenerateData(p0);
            string Project2 = tmsCommon.GenerateData(p1);
            // Verify that the first Project Name is selectable 
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='maintainProjects-select-AssignedProject']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + Project1 + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(2);
            // Verify that the second Project Name is selectable 
            By Drp1 = By.XPath("//kendo-dropdownlist[@test-id='maintainProjects-select-AssignedProject']//span[@class='k-select']");
            By typeapp1 = By.XPath("//li[text()='" + Project2 + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp1));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp1));
            tmsWait.Hard(2);
        }

        [Then(@"Maintain Project page Verify that Sorting funcionality is working")]
       public void ThenMaintainProjectPageVerifyThatSortingFuncionalityIsWorking()
        {
            //Storing all the ProviderNames Values before sorting 
            IList<IWebElement> List = Browser.Wd.FindElements(By.XPath("//table[@class='k-grid-table']/tbody/tr/td[1]"));
            List<String> BeforesortList = new List<String>();
            foreach (var item in List)
            {
              BeforesortList.Add(item.Text);
            }

            foreach (string a in BeforesortList)
            { Console.WriteLine(a); }

            //Sort by Provider 
            AngularFunction.clickOnElement(RAM.ManageSuspectPage.MaintainProjectSortButton);
            tmsWait.Hard(2);
            //Compare elements after sort 
            IList<IWebElement> List1 = Browser.Wd.FindElements(By.XPath("//table[@class='k-grid-table']/tbody/tr/td[1]"));
            List<String> AftersortList1 = new List<String>();
            foreach (var item in List1)
            {
                AftersortList1.Add(item.Text);

            }
            List<string> resultantString = compareTwoList(BeforesortList, AftersortList1);
            Assert.IsFalse((resultantString.Count == 0), "Values are matching which means grid is not getting sorted ");

            ////Again Sort by Provider 
            //AngularFunction.clickOnElement(RAM.ManageSuspectPage.MaintainProjectSortButton);
            //tmsWait.Hard(2);
            ////Compare elements again after sorting by provider  
            //IList<IWebElement> List2 = Browser.Wd.FindElements(By.XPath("//table[@class='k-grid-table']/tbody/tr/td[1]"));
            //List<String> AftersortList2 = new List<String>();
            //foreach (var item in List2)
            //{
            //    AftersortList2.Add(item.Text);
            //}
            //foreach (string a in AftersortList2)
            //{ Console.WriteLine(a); }
            //foreach (string a in BeforesortList)
            //{ Console.WriteLine(a); }

            //List<string> resultantString1 = compareTwoList(BeforesortList, AftersortList2);
            //Assert.IsTrue((resultantString1.Count == 0), "Values are not matching");

        

            //Common function to compare two string List 
            List<string> compareTwoList(List<string> drpValues, List<string> dbValues)
            {
                List<string> resultantList = new List<string>();

                //Console.WriteLine("Difference in the Drop Down List and DB value lists...");
                IEnumerable<string> list3;
                list3 = drpValues.Except(dbValues);

                foreach (string value in list3)
                {
                    resultantList.Add(value);
                }
                return resultantList;
            }

        }

        [When(@"I Clicked on Create new Project Maintain Projects page")]
        public void WhenIClickedOnCreateNewProjectMaintainProjectsPage()
        {
            tmsWait.Hard(2);
            AngularFunction.clickOnElement(RAM.ManageSuspectPage.MaintainProjectCreateProjectButton);
            tmsWait.Hard(2);

        }

        [Then(@"Verify that the ""(.*)"" page is opened successfully")]
        public void ThenVerifyThatThePageIsOpenedSuccessfully(string pagetitle)
        {
            tmsWait.Hard(2);
            //Assert the Page Title
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[contains(text(),'"+pagetitle+"')]")).Displayed);
            //Assert the Presense of the Create Project button 
            Assert.IsTrue(RAM.ManageSuspectPage.MaintainProjectCreateProjectButton.Displayed);
            
        }

        [Then(@"Verify that ""(.*)"" page has ""(.*)"" and  ""(.*)""")]
        public void ThenVerifyThatPageHasAnd(string p0, string HCCName, string HCCDescription)
        {
            string HCCNamevalue = tmsCommon.GenerateData(HCCName);
            string HCCDescriptionvalue = tmsCommon.GenerateData(HCCDescription);
            Console.WriteLine(HCCName);
            Console.WriteLine(HCCDescription);
            KendoUIFunctions.ResultGridTextValidation(HCCDescription);

        }


        [When(@"Undo Submitted PIR ""(.*)"" if already submitted")]
        public void WhenUndoSubmittedPIRIfAlreadySubmitted(string p0)
        {
            string value = tmsCommon.GenerateData(p0.ToString());
            try
            {
                if (RAM.ManageSuspectPage.PIRInformationalmsg.Displayed)
                {
                    fw.ExecuteJavascript(RAM.ManageSuspectPage.BackToRecord);
                    tmsWait.Hard(3);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Suspects']")));
                    tmsWait.Hard(4);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'View and Undo PIR Responses')]")));
                    tmsWait.Hard(5);
                    AngularFunction.selectDropDownValue(RAM.ViewandUndoPIRResponses.SearchBydrpdown, "Control Number");

                    tmsWait.Hard(3);
                    RAM.ViewandUndoPIRResponses.ControlNumber.SendKeys(value);
                    tmsWait.Hard(1);
                    clickonWebComponent(RAM.ViewandUndoPIRResponses.SearchButton);
                    tmsWait.Hard(4);
                    try
                    {
                        //if (Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='viewUndoPirResponse-grid-suspectsGridSearchResult']//td[contains(.,'" + value + "')]/following-sibling::td//a[@name='Delete']/span")).Displayed)

                         if (Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='viewUndoPirResponse-grid-suspectsGridSearchResult']//td[contains(.,'" + value + "')]/following-sibling::td//a/span[@class='fas fa-undo']")).Displayed)
                            {
                            clickonWebComponent(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='viewUndoPirResponse-grid-suspectsGridSearchResult']//td[contains(.,'" + value + "')]/following-sibling::td//a/span[@class='fas fa-undo']")));
                            warningDialogClickonButton(RAM.ManageSuspectPage.WarningdialogOK);
                        }
                    }
                    catch (Exception)
                    {
                        //skip
                    }
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Main']")));
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'Manage Suspects')]")));
                    tmsWait.Hard(2);
                    AngularFunction.selectDropDownValue(RAM.ManageSuspectPage.SearchTypeDrpdownlist, "PIR");

                    tmsWait.Hard(1);
                    RAM.ManageSuspectPage.PIRNumber.SendKeys(value);
                    fw.ExecuteJavascript(RAM.ManageSuspectPage.SearchButton);
                    tmsWait.Hard(5);
                    bool flag = false;
                    try
                    {
                        if (RAM.ManageSuspectPage.ConfirmationYesButton.Displayed)
                        {
                            RAM.ManageSuspectPage.ConfirmationYesButton.Click();
                        }
                    }
                    catch (Exception)
                    {
                        flag = true;
                        //No any confirmation message
                    }
                }

            }
            catch (Exception)
            {
                // skip
            }
          
        }

    }
}
