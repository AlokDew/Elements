﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.HCC_RAM
{
    [Binding]
    class fsAddOnHoldReason
    {
        [When(@"AddOnHoldReasons page Add button is clicked")]
        public void WhenAddOnHoldReasonsPageAddButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.AddOnHoldReasonPage.AddButton);
        }

        [Then(@"Verify AddOnHoldReasons page validation message '(.*)' is displayed")]
        public void ThenVerifyAddOnHoldReasonsPageValidationMessageIsDisplayed(string p0)
        {
           
        }

        [When(@"AddOnHoldReasons page reasonText is set to ""(.*)""")]
        public void WhenAddOnHoldReasonsPageReasonTextIsSetTo(string p0)
        {
            
        }

        [Then(@"Verify AddOnHoldReason Message ""(.*)""")]
        public void ThenVerifyAddOnHoldReasonMessage(string p0)
        {
            
        }

        [Then(@"Verify AddOnHoldReason ""(.*)"" is displayed in the grid")]
        public void ThenVerifyAddOnHoldReasonIsDisplayedInTheGrid(string p0)
        {
           
        }

        [Given(@"User navigate to Administration Section")]
        public void GivenUserNavigateToAdministrationSection()
        {
            AngularFunction.clickOnElement(cfRAMAdministration.AddOnHoldReasons.Administration);

        }

        [Then(@"User click Sub Menu Add On Hold Reasons")]
        public void ThenUserClickSubMenuAddOnHoldReasons()
        {
            AngularFunction.clickOnElement(cfRAMAdministration.AddOnHoldReasons.AddOnHoldReasonsMenu);
        }

        [Then(@"User Enter ""(.*)"" in  On-Hold Reason test box - Add On Hold Reasons page")]
        public void ThenUserEnterInOn_HoldReasonTestBox_AddOnHoldReasonsPage(string p0)
        {
            String reason = tmsCommon.GenerateData(p0);
            AngularFunction.sendKeysWithClear(cfRAMAdministration.AddOnHoldReasons.AddOnHoldReasonsTextbox,reason);
        }

        [Then(@"User click ""(.*)"" button")]
        public void ThenUserClickButton(string p0)
        {
            AngularFunction.clickOnElement(cfRAMAdministration.AddOnHoldReasons.ADDButton);

        }

        [Then(@"verify Warning Pop up ""(.*)"" is displayed with YES and NO")]
        public void ThenVerifyWarningPopUpIsDisplayedWithYESAndNO(string p0)
        {
            UIMODUtilFunctions.elementPresenceUsingWebElement(cfRAMAdministration.AddOnHoldReasons.ConfirmationDialogue);
            UIMODUtilFunctions.elementPresenceUsingWebElement(cfRAMAdministration.AddOnHoldReasons.ConfirmationDialogueYES);
            UIMODUtilFunctions.elementPresenceUsingWebElement(cfRAMAdministration.AddOnHoldReasons.ConfirmationDialogueNO);
        }

        [Then(@"on clicking YES in Warning page")]
        public void ThenOnClickingYESInWarningPage()
        {
            UIMODUtilFunctions.clickOnConfirmationYesDialog();
        }

        [Then(@"verify newly added on hold reason ""(.*)"" is showing on List Of On-HoldReasons grid")]
        public void ThenVerifyNewlyAddedOnHoldReasonIsShowingOnListOfOn_HoldReasonsGrid(string p0)
        {
            string onholdreason = tmsCommon.GenerateData(p0);
            bool valuefound = false;
            By onholdvaluepresence = By.XPath("//Kendo-grid[@test-id='addOnHoldReasons-grid-onHoldReasonsGrid']//tr/td[@aria-colindex='2'][contains(.,'" + onholdreason + "')]");
            while(!valuefound)
            {
                try
                {
                    valuefound = Browser.Wd.FindElement(onholdvaluepresence).Displayed;
                    break;
                }
                catch
                {
                    AngularFunction.clickonNextLink();
                }
            }
            

            Assert.IsTrue(valuefound);

        }
        [Then(@"check added on hold reason ""(.*)"" is Active")]
        public void ThenCheckAddedOnHoldReasonIsActive(string p0)
        {
            string onholdreason = tmsCommon.GenerateData(p0);
            bool valuefound = false;
            By onholdvaluepresence = By.XPath("//Kendo-grid[@test-id='addOnHoldReasons-grid-onHoldReasonsGrid']//tr/td[@aria-colindex='2'][contains(.,'"+ onholdreason+"')]/preceding-sibling::td/input");
            while (!valuefound)
            {
                try
                {
                    valuefound = Browser.Wd.FindElement(onholdvaluepresence).Selected;
                    break;
                }
                catch
                {
                    AngularFunction.clickonNextLink();
                }
            }


            Assert.IsTrue(valuefound, "On-hold reason not found");

        }


        [Then(@"check addded on hold reason  ""(.*)"" Active column checkbox as ""(.*)""")]
        public void ThenCheckAdddedOnHoldReasonActiveColumnCheckboxAs(string p0, string p1)
        {
            string onholdreason = tmsCommon.GenerateData(p0);
            By onholdvaluepresence = By.XPath("//Kendo-grid[@test-id='addOnHoldReasons-grid-onHoldReasonsGrid']//tr/td[@aria-colindex='2'][contains(.,'"+onholdreason+"')]/preceding-sibling::td[@aria-colindex='1']/Input[@id='isActive']");
            
        }



    }
}
