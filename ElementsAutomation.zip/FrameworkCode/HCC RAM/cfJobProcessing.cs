﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1
{
    class cfJobProcessing
    {
        public static RAMJobProcessing RAMJobProcessing { get { return new RAMJobProcessing(); } }
    }

    [Binding]
    public class RAMJobProcessing
    {
        public IWebElement jobDropdown { get { return Browser.Wd.FindElement(By.XPath("//label[text()='Job']/parent::div//span[@class='k-select']")); } }
        public IWebElement SearchButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='jobProcessingStatus-button-search']")); } }
        public IWebElement importPlusButton { get { return Browser.Wd.FindElement(By.XPath("(//a[@title='Expand Details'])[1]")); } }
    }


    }
