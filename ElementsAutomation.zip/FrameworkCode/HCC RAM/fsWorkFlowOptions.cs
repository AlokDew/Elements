﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using OpenQA.Selenium.Support.UI;
using System.IO;

namespace TMSoR1.FrameworkCode.HCC_RAM
{
    [Binding]
    class fsWorkFlowOptions
    {
        [When(@"Members New Queue Code is set to ""(.*)""")]
        public void WhenMembersNewQueueCodeIsSetTo(string p0)
        {
            tmsWait.WaitForElement(By.XPath("//*[@test-id='workflowOptions-input-queueCode']"), 300);
            string GeneratedData = tmsCommon.GenerateData(p0);
            RAM.WorkflowOptions.AddQCodeTextbox.SendKeys(GeneratedData);
        }


        [When(@"WorkflowOptions Queue Code Add button is clicked")]
        public void WhenWorkflowOptionsQueueCodeAddButtonIsClicked()
        {

            tmsWait.Hard(3);
            fw.ExecuteJavascript(RAM.WorkflowOptions.AddQCodeBtn);
        }
        [When(@"WorkflowOptions Queue Code Add button is clicked and Verify Message ""(.*)""")]
        [Then(@"WorkflowOptions Queue Code Add button is clicked and Verify Message ""(.*)""")]
        public void ThenWorkflowOptionsQueueCodeAddButtonIsClickedAndVerifyMessage(string p0)
        {
            tmsWait.Hard(3);
            fw.ExecuteJavascript(RAM.WorkflowOptions.AddQCodeBtn);
            //string expectedValue = p0.ToString();

            //By toastMsg = By.XPath("//div[@class='k-notification-content']");
            //string actValue = Browser.Wd.FindElement(toastMsg).Text;
            //Assert.IsTrue(actValue.Contains(expectedValue));
        }


        [Then(@"WorkflowOptions Queue Code Add button is clicked And success message varified ""(.*)""")]
        [When(@"WorkflowOptions Queue Code Add button is clicked And success message varified ""(.*)""")]
        public void ThenWorkflowOptionsQueueCodeAddButtonIsClickedAndSuccessMessageVarified(string p0)
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(RAM.WorkflowOptions.AddQCodeBtn);

            string expectedValue = p0.ToString();
            By toastMsg = By.XPath("//div[@class='k-notification-content']");
            string actValue = Browser.Wd.FindElement(toastMsg).Text;
            Assert.IsTrue(actValue.Contains(expectedValue));
        }

        [When(@"WorkflowOptions queue status code is set to ""(.*)""")]
        public void WhenWorkflowOptionsQueueStatusCodeIsSetTo(string p0)
        {
            tmsWait.WaitForElement(By.XPath("//*[@test-id='workflowOptions-input-queueStatusCode']"), 300);
            string GeneratedData = tmsCommon.GenerateData(p0);
            RAM.WorkflowOptions.AddQStatusCodeTextBox.SendKeys(GeneratedData);
        }


        [When(@"WorkflowOptions queue status code Add button is clicked")]
        public void WhenWorkflowOptionsQueueStatusCodeAddButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.WorkflowOptions.AddQStatusCodeBtn);
            tmsWait.Hard(2);
        }

        [When(@"WorkflowOptions New Action Code is set to ""(.*)""")]
        public void WhenWorkflowOptionsNewActionCodeIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            RAM.WorkflowOptions.AddActionCodeTextbox.SendKeys(GeneratedData);
        }

        [When(@"WorkflowOptions Action Code Add button is clicked")]
        public void WhenWorkflowOptionsActionCodeAddButtonIsClicked()
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(RAM.WorkflowOptions.AddActionCodeBtn);
        }

        [Then(@"WorkflowOptions Action Code Add button is clicked And success message varified ""(.*)""")]
        [When(@"WorkflowOptions Action Code Add button is clicked And success message varified ""(.*)""")]
        public void ThenWorkflowOptionsActionCodeAddButtonIsClickedAndSuccessMessageVarified(string p0)
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(RAM.WorkflowOptions.AddActionCodeBtn);
        }


        [Then(@"Verify WorkflowOptions Acknowledge Message ""(.*)""")]
        [Then(@"Verify WorkflowOptions appropriate error message ""(.*)""")]
        public void ThenVerifyWorkflowOptionsAcknowledgeMessage(string p0)
        {
            tmsWait.Hard(5);
            string expectedValue = p0.ToString();
            By toastMsg = By.XPath("//div[@class='k-notification-content']");
            string actValue = Browser.Wd.FindElement(toastMsg).Text;
            Assert.IsTrue(actValue.Contains(expectedValue));

        }
        [When(@"Verify WorlflowOptions Queue Code ""(.*)"" is Available in QueueCode Table")]
        [Then(@"Verify WorlflowOptions Queue Code ""(.*)"" is Available in QueueCode Table")]
        public void ThenVerifyWorlflowOptionsQueueCodeIsAvailableInQueueCodeTable(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string qCode = Convert.ToString(GeneratedData);

            IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@test-id='workflowOptions-table-queueCodesList']//td[contains(.,'" + qCode + "')]"));
            UIMODUtilFunctions.elementPresenceUsingWebElement(ele);
        }

        [When(@"WorkflowOptions delete standard existing QCode ""(.*)""")]
        public void WhenWorkflowOptionsDeleteStandardExistingQCodeEvaluation(string p0)
        {
            switch(p0)
            {
                case "Evaluation":
                    IWebElement DeleteEvaluation = Browser.Wd.FindElement(By.Id("queue12"));
                    //DeleteEvaluation.Click();
                    fw.ExecuteJavascript(DeleteEvaluation);
                    break;
                case "Provider Outreach":
                    IWebElement DeleteProviderOutreach = Browser.Wd.FindElement(By.XPath("//table[@test-id='workflowOptions-table-queueCodesList']//i[@id='queue10']"));
                    //DeleteProviderOutreach.Click();
                    fw.ExecuteJavascript(DeleteProviderOutreach);
                    break;
                case "Member Outreach":
                    IWebElement DeleteMemberOutreach = Browser.Wd.FindElement(By.Id("queue11"));
                    fw.ExecuteJavascript(DeleteMemberOutreach);
                    //DeleteMemberOutreach.Click();
                    break;
            }
            tmsWait.Hard(2);
            RAM.WorkflowOptions.QCodeDeleteYesButton.Click();
            

        }

        //[Then(@"Verify WorkflowOptions appropriate error message ""(.*)""")]
        //public void ThenVerifyWorkflowOptionsAppropriateErrorMessage(string p0)
        //{
        //    Assert.AreEqual(p0, RAM.WorkflowOptions.ProspectiveMgmtAcknwldgMsg.Text, "Appropriate Error Message is not displayed");
        //    tmsWait.Hard(2);
        //}

        [When(@"WorkflowOptions delete queue code ""(.*)""")]
        public void WhenWorkflowOptionsDeleteQueueCode(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            IWebElement DeleteNewQcode = Browser.Wd.FindElement(By.XPath("//span[contains(.,'"+ GeneratedData +"')]/parent::td/i"));
            fw.ExecuteJavascript(DeleteNewQcode);
            tmsWait.Hard(2);
            RAM.WorkflowOptions.QCodeDeleteYesButton.Click();
        }

        [When(@"I selected WorkflowOptions Queue code ""(.*)""")]
        public void WhenISelectedWorkflowOptionsQueueCode(string p0)
        {
            tmsWait.Hard(5);
            string value = tmsCommon.GenerateData(p0);
            IWebElement drp = Browser.Wd.FindElement(By.CssSelector("[test-id='workflowOptions-select-queueCodes']"));
            new SelectElement(drp).SelectByText(value);
        }

        [When(@"I select WorkflowOptions Queue code ""(.*)""")]
        public void WhenISelectWorkflowOptionsQueueCode(string p0)
        {
           
            string GeneratedData = tmsCommon.GenerateData(p0);
            IWebElement QCodeTable = RAM.WorkflowOptions.QCodeTable;
            ReadOnlyCollection<IWebElement> allQCodes = QCodeTable.FindElements(By.TagName("tr"));
            bool isPresent = false;
            string qcode = Convert.ToString(GeneratedData);

            foreach (IWebElement row in allQCodes)
            {
                tmsWait.Hard(1);
                if (row.Text.ToString().Contains((qcode)))
                {
                    isPresent = true;
                    row.Click();
                    break;
                }
            }
            Assert.IsTrue(isPresent);
        }


        [When(@"I select WorkflowOptions standard Queue code ""(.*)""")]
        public void WhenISelectWorkflowOptionsStandardQueueCode(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@test-id='workflowOptions-span-codeDescription'][contains(.,'" + GeneratedData + "')]")));
            //IWebElement QCodeTable = RAM.WorkflowOptions.QCodeTable;
            //ReadOnlyCollection<IWebElement> allQCodes = QCodeTable.FindElements(By.TagName("tr"));
            //bool isPresent = false;
            ////string qcode = Convert.ToString(p0);

            //foreach (IWebElement row in allQCodes)
            //{
            //    tmsWait.Hard(2);
            //    if (row.Text.ToString().Contains((GeneratedData)))
            //    {
            //        isPresent = true;
            //        row.Click();
            //        break
            //            ;
            //    }
            //}
            //Assert.IsTrue(isPresent);
        }

        [When(@"WorkflowOptions delete standard queue status code ""(.*)""")]
        public void WhenWorkflowOptionsDeleteStandardQueueStatusCode(string p0)
        {
            tmsWait.Hard(5);
            switch (p0)
            {
                case "Conducted And coded":
                    IWebElement DeleteCC = Browser.Wd.FindElement(By.Id("status25"));
                    DeleteCC.Click();
                    break;
                case "Conducted, Not coded":
                    IWebElement DeleteCNotCoded = Browser.Wd.FindElement(By.Id("status26"));
                    DeleteCNotCoded.Click();
                    break;
                case "Not Conducted":
                    IWebElement DeleteMNotConducted = Browser.Wd.FindElement(By.Id("status27"));
                    DeleteMNotConducted.Click();
                    break;
            }
            tmsWait.Hard(2);
            RAM.WorkflowOptions.QStatusCodeYesBtn.Click();
        }



        [When(@"WorkflowOptions delete queue status code ""(.*)""")]
        public void WhenWorkflowOptionsDeleteQueueStatusCode(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            IWebElement DeleteNewQStatuscode = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + GeneratedData + "')]/parent::td/i"));
            fw.ExecuteJavascript(DeleteNewQStatuscode);
            tmsWait.Hard(2);
            RAM.WorkflowOptions.QStatusCodeYesBtn.Click();
        }

        [Then(@"Verify WorlflowOptions Queue Code ""(.*)"" is Available in ActionCode Table")]
        [When(@"Verify WorlflowOptions Queue Code ""(.*)"" is Available in ActionCode Table")]
        public void ThenVerifyWorlflowOptionsQueueCodeIsAvailableInActionCodeTable(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string Actioncode = Convert.ToString(GeneratedData);

            IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@test-id='workflowOptions-table-actionCodes']//td[contains(.,'" + Actioncode + "')]"));
            UIMODUtilFunctions.elementPresenceUsingWebElement(ele);
        }


        [When(@"WorkflowOptions delete standard existing ActionCode ""(.*)""")]
        public void WhenWorkflowOptionsDeleteStandardExistingActionCode(string p0)
        {
            switch (p0)
            {
                case "Close or Open":
                    IWebElement DeleteCloseorOpen = Browser.Wd.FindElement(By.Id("action3"));
                    fw.ExecuteJavascript(DeleteCloseorOpen);
                    tmsWait.Hard(2);
                    break;
                case "Update Queue":
                    IWebElement DeleteUpdateQueue = Browser.Wd.FindElement(By.Id("action1"));
                    fw.ExecuteJavascript(DeleteUpdateQueue);
                    tmsWait.Hard(2);
                    break;
                case "Update Queue Status":
                    IWebElement DeleteUpdateQueueStatus = Browser.Wd.FindElement(By.Id("action2"));
                    fw.ExecuteJavascript(DeleteUpdateQueueStatus);
                    tmsWait.Hard(2);
                    break;
            }
            tmsWait.Hard(2);
            RAM.WorkflowOptions.ActionYesBtn.Click();

        }

        [When(@"WorkfflowOptions delete action code ""(.*)""")]
        public void WhenWorkfflowOptionsDeleteActionCode(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            IWebElement DeleteNewActioncode = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + GeneratedData + "')]/parent::td/i"));
            fw.ExecuteJavascript(DeleteNewActioncode);
            tmsWait.Hard(2);
            RAM.WorkflowOptions.ActionYesBtn.Click();
        }

        [When(@"WorkflowOptions applyrules qcode ""(.*)"" is selected")]
        public void WhenWorkfflowOptionsApplyrulesQcodeIsSelected(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            //SelectElement ApplyQcode = new SelectElement(RAM.WorkflowOptions.Applyrulesqcode);
            //ApplyQcode.SelectByText(GeneratedData);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='workflowOptions-select-queueCodes']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + GeneratedData + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(2);
           
           
        }

        [When(@"WorkflowOptions applyrules qstatus code ""(.*)""")]
        public void WhenWorkflowOptionsApplyrulesQstatusCode(string p0)
        {
            tmsWait.Hard(5);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='workflowOptions-select-queueStatusCodes']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + p0 + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(2);
            //var allStatusCode = Browser.Wd.FindElements(By.XPath("//span[@test-id='workflowOptions-span-statusCodeDescription']"));
            //foreach(IWebElement statuscode in allStatusCode)
            //{
            //    if(statuscode.Text.Contains(p0))
            //    {
            //        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]/parent::td/i")));
            //        tmsWait.Hard(3);
            //        fw.ExecuteJavascript(Browser.Wd.FindElement(By.Id("deleteYesQueueStatusCode")));
            //        break;
            //    }
            //}
            //IWebElement QstatusCodeTable = RAM.WorkflowOptions.QStatusCodeTable;
            //ReadOnlyCollection<IWebElement> allstatusCodes = QstatusCodeTable.FindElements(By.TagName("tr"));
            //bool isPresent = false;
            string Statuscode = Convert.ToString(p0);

            //foreach (IWebElement row in allstatusCodes)
            //{
            //    tmsWait.Hard(2);
            //    if (row.Text.ToString().Contains((Statuscode)))
            //    {
            //        isPresent = true;
            //        break;
            //    }
            //}
            
            //if(!isPresent)
            //{ 
            //SelectElement ApplyQStatuscode = new SelectElement(RAM.WorkflowOptions.Applyrulesqstatuscode);
            //ApplyQStatuscode.SelectByText("Evaluation Scheduled");
            //}

            //else
            //{
            //    Console.WriteLine("Queue Status code is already mapped");
            //}
        }

        [When(@"WorkflowOptions applyrules save button is clicked")]
        public void WhenWorkflowOptionsApplyrulesSaveButtonIsClicked()
        {
            RAM.WorkflowOptions.ApplyrulesqSaveBtn.Click();
            tmsWait.Hard(2);
        }
        [Then(@"WorkflowOptions applyrules save button is clicked and verify Message ""(.*)""")]
        [When(@"WorkflowOptions applyrules save button is clicked and verify Message ""(.*)""")]
        public void ThenWorkflowOptionsApplyrulesSaveButtonIsClickedAndVerifyMessage(string p0)
        {
            tmsWait.Hard(2);
            RAM.WorkflowOptions.ApplyrulesqSaveBtn.Click();
            string expectedValue = p0.ToString();
        }


        [Then(@"Verify WorlflowOptions Queue Status Code ""(.*)"" is Available in QueueStatusCode Table")]
        public void ThenVerifyWorlflowOptionsQueueStatusCodeIsAvailableInQueueCodeTable(string p0)
        {
            tmsWait.Hard(5);
            string GeneratedData = tmsCommon.GenerateData(p0);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[@test-id='workflowOptions-span-statusCodeDescription'][contains(.,'" + GeneratedData + "')]")).Displayed, "expected value is not displayed");
            //    IWebElement QstatusCodeTable = RAM.WorkflowOptions.QStatusCodeTable;
            //    ReadOnlyCollection<IWebElement> allStatusCodes = QstatusCodeTable.FindElements(By.TagName("tr"));
            //    bool isPresent = false;
            //    string Statuscode = Convert.ToString(p0);

            //    foreach (IWebElement row in allStatusCodes)
            //    {
            //        tmsWait.Hard(4);
            //        if (row.Text.ToString().Contains((Statuscode)))
            //        {
            //            isPresent = true;
            //            break;
            //        }
            //    }
            //    Assert.IsTrue(isPresent);
        }

        [Given(@"Verify Number ""(.*)"" is prime or not")]
        public void GivenVerifyNumberIsPrimeOrNot(int p0)
        {
            Console.WriteLine("Enter a number");
            int num; Boolean primes = false;
            num = p0;//Convert.ToInt32(Console.ReadLine(p0));
            int k = 0;
            for (int i=1;i<=num;i++)
            {
                if(num % i ==0)
                {
                    k++;
                }
            }

            if(k==2)
            {
                primes = true;
            }
            else
            {
                Console.WriteLine("Number is not a Prime number");
            }
            Assert.IsTrue(primes);
         
        }

    }
}
