﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.HCC_RAM
{
    [Binding]
    class fsAddSource
    {
        private bool nextPage;

        [When(@"Add Source page source is Set to ""(.*)""")]
        public void WhenAddSourcePageSourceIsSetTo(string p0)
        {
            string sourcetext = tmsCommon.GenerateData(p0.ToString());
            RAM.AddSourcePage.RAMAddSourcetxt.SendKeys(sourcetext);
        }

        [When(@"Add Source page Add button is Clicked")]
        public void WhenAddSourcePageAddButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.AddSourcePage.RAMSourceAddButton);
            tmsWait.Hard(5);
        }

        [When(@"Warning pop up Yes Button is clicked")]
        public void WhenWarningPopUpYesButtonIsClicked()
        {
            tmsWait.Hard(5);
            bool flag = false;
            try
            {
                if (RAM.AddSourcePage.WarningYesButton.Displayed)
                {
                    RAM.AddSourcePage.WarningYesButton.Click();
                }
            }
            catch (Exception)
            {
                flag = true;
                //No any confirmation message
            }
        }

        [Then(@"Verify that Source grid display as per Source added in database")]
        public void ThenVerifyThatSourceGridDisplayAsPerSourceAddedInDatabase()
        {
            Dictionary<int, string[]> table = new Dictionary<int, string[]>();
            fsExport Executequery = new fsExport();
            string Querystring = "SELECT * FROM [RAM].[dbo].[PirSource]";
            table = Executequery.ExecuteSingleQuery(Querystring, ConfigFile.RAMdb, 8, 1, "0");
            IWebElement tableId = Browser.Wd.FindElement(By.XPath(".//*[@test-id='addSource-grid-sourceGrid']/table"));
            IList<IWebElement> rows = tableId.FindElements(By.TagName("tr"));
            int DbRecordsCnt = table.Count();
            int tableRecordCnt = rows.Count()-1;
            Assert.AreEqual(DbRecordsCnt, tableRecordCnt, "Record Count are miss-match");

        }


        [Then(@"Verify Add Source page is displaying Source added by User grid with added coderid ""(.*)""")]
        public void ThenVerifyAddSourcePageIsDisplayingSourceAddedByUserGridWithAddedCoderid(string p0)
        {

            string actualcoderid = tmsCommon.GenerateData(p0.ToString());
            tmsWait.Hard(3);

            do
            {
                nextPage = VerifySourceID(actualcoderid);
                if (nextPage)
                {
                    Browser.Wd.FindElement(By.LinkText("Next")).Click();
                }
            } while (nextPage);
        }


        public static bool VerifySourceID(string Sourceid)
        {
            try
            {
                IWebElement coderID = Browser.Wd.FindElement(By.XPath("//div[@test-id='addSource-grid-sourceGrid']//tr[contains(.,'" + Sourceid + "')]"));
                if (coderID.Displayed)
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                return true;
            }
            return true;
        }

    }

}
