﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
//using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using OpenQA.Selenium.Support.UI;
using System.IO;

namespace TMSoR1.FrameworkCode.HCC_RAM
{
    [Binding]
	class fsWorkflow
	{
		string GeneratedData, InputValue=null;

        public Dictionary<int, string[]> ExecuteSingleQuery(string SqlString, string DB_NAME, int numberOfColumn, int rowstartcnt, string colSkip)
        {
            Dictionary<int, string[]> table = new Dictionary<int, string[]>();
            SqlCommand thisCommand = null;
            List<string> list = new List<string>();
            try
            {

                //string thisConnectionString = "user id=" + ConfigFile.DBUser + "; " +
                //                   "password=" + ConfigFile.DBPassword + ";" +
                //                   "Server=" + ConfigFile.DataServer + ";" +
                //                   "Trusted_Connection=no; " +
                //                   "database=" + DB_NAME + "; " +
                //                   "connection timeout=30";

                string thisConnectionString = "server=" + ConfigFile.DataServer + ";" + "database=" + DB_NAME + ";" + "user id=" + ConfigFile.DBUser + ";" + "password=" + ConfigFile.DBPassword + ";" + "Max Pool Size=9000;" + "Connection Timeout=150;" + "Min Pool Size=2";
                SqlConnection DBConn = new SqlConnection();
                DBConn.ConnectionString = thisConnectionString;
                DBConn.Open();
                thisCommand = new SqlCommand(SqlString, DBConn);
                SqlDataReader reader = thisCommand.ExecuteReader();
                //int numberOfRows = (reader.FieldCount + 1) / numberOfColumn;
                int j = 0;


                if (reader.HasRows)
                {

                    while (reader.Read())
                    {

                        list.Clear();

                        for (int i = 0; i < numberOfColumn; i++)
                        {
                            list.Add(reader.GetValue(i).ToString().TrimEnd());
                        }

                        List<string> copyList = list;

                        table.Add(j, copyList.ToArray());

                        j++;
                    }


                }


            }
            catch (Exception e)
            {
                Console.WriteLine("Failed read record: [" + e + "] Query [" + SqlString + "]");
            }

            return table;

        }







        [Given(@"variable ""(.*)"" is set to value from database ""(.*)""")]
		[Then(@"variable ""(.*)"" is set to value from database ""(.*)""")]
		public void GivenVariableIsSetToValueFromDatabase(string p0, string p1)
		{
			int index = 0;
            string MemberID=null, ClaimNumber = null, Dbcontent = null;

            Dictionary<int, string[]> table = new Dictionary<int, string[]>();
			GeneratedData = tmsCommon.GenerateData("Generate|variable|ProjectName");
			string QueueName = tmsCommon.GenerateData("Generate|variable|TreeViewQueueName");
			
			if (p1.Contains("ProjectNameQuery")) p1 = p1.Replace("ProjectNameQuery", GeneratedData);

			if (p1.Contains("QueueNameValue")) p1 = p1.Replace("QueueNameValue", QueueName);

			string query = p1.ToString();
           
            fsWorkflow obj = new fsWorkflow();
			table = obj.ExecuteSingleQuery(query, ConfigFile.RAMdb, 2, 0, "0");

			if (table.Count()==0)
			{
				Assert.Fail("Selected Tree queue dont have data");
				
			}

			Dbcontent = string.Join(",", table[index]);



			// As most of DB having PCP 99999999 value and which is bad data, so while loop written to skip the 99999999 and take value PCP ID
			while (Dbcontent.Contains("99999999"))
			{
				index++;
				Dbcontent = string.Join(",", table[index]);
			}

			string[] DbRowStringt= Dbcontent.Split(',');

            switch (p0.ToLower())
            {
                case "providerid":
                    string ProviderID = DbRowStringt[0];
                    fw.setVariable(p0, ProviderID);
                    break;

                case "controlnumber":
                    string ControlNumber = DbRowStringt[0];
                    fw.setVariable(p0, ControlNumber);
                    break;

                case "memberid":
                    MemberID = DbRowStringt[0];
                    fw.setVariable(p0, MemberID);
                    break;

                case "claimnumber":
                    ClaimNumber = DbRowStringt[0];
                    fw.setVariable(p0, ClaimNumber);
                    break;

            }

           
			GlobalRef.mPCPID = DbRowStringt[1];
		}


        [Then(@"variable ""(.*)"" is set to available valid value from database ""(.*)""")]
        public void ThenVariableIsSetToAvailableValidValueFromDatabase(string p0, string p1)
        {
            string strReturnString = null, PaymentYear=null;
            int count = 0;
            DateTime Date = DateTime.Now;
            strReturnString = Date.Year.ToString();

            Dictionary<int, string[]> table = new Dictionary<int, string[]>();
            string query = p1.ToString();
            fsWorkflow obj = new fsWorkflow();
            query = query.Replace("available_year", strReturnString);

            for (int i = 0; i<= 6; i++)
            {
                table = obj.ExecuteSingleQuery(query, ConfigFile.RAMdb, 2, 0, "0");
                if (table.Count() == 0)
                {
                    count++;
                    System.DateTime DateAdd = Date.AddYears(-1);
                    strReturnString = DateAdd.Year.ToString();
                    PaymentYear = query.Substring(query.IndexOf("'")+1,4);
                    query = query.Replace(PaymentYear, strReturnString);
                    //query = "select * from tbexceptionletters where PaymentYear='2006'"
                }
                else {
                    fw.setVariable(p0, strReturnString);
                    break;
                }
            }
            
           
            

            
            
        }


        [When(@"I have created Assignment project")]
		public void WhenIHaveCreatedAssignmentProject()
		{
			string iniString = "Project";
			string strReturnString=string.Empty;
            Dictionary<int, string[]> table = new Dictionary<int, string[]>();
			string query = "select distinct (t3.ProjectName) from tbProspectiveEval_ProjectDetail t1 inner join tbProspectiveEval_WorkflowDetail t2 on t1.ProsEvalID = t2.ProsEvalID inner join tbWorkFlow_Projects t3 on t1.projectid = t3.projectid";
			table = ExecuteSingleQuery(query, ConfigFile.RAMdb, 1, 0, "0");
			Random rnd = new Random();
			string dt = DateTime.Now.Date.ToString("MM/dd/yyyy");
			string td = DateTime.Now.AddDays(120).ToString("MM/dd/yyyy");
			for (int lo = 1; lo < 6; lo++)
			{
				strReturnString += rnd.Next(0,9).ToString();
			}
            iniString += strReturnString;

            if (table.Count < 1)
            {
                tmsWait.Hard(10);
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@title='Manage Projects']")));
                fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.createProjectLink);
                tmsWait.Hard(5);
                RAM.RAMProspectiveEvaulation.ProjectNameTextBox.SendKeys(iniString);
                RAM.RAMProspectiveEvaulation.FromDate.SendKeys(dt);
                RAM.RAMProspectiveEvaulation.ThruDate.SendKeys(td);
                tmsWait.Hard(2);
                fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.CreateProjectADDbtn);
                tmsWait.Hard(5);

				IList<IWebElement> elements = Browser.Wd.FindElements(By.CssSelector("[test-id = 'addProspectiveEvaluation-btn-yes']"));

                if (elements.Count > 0)
                {
                    fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.MemberExistYESBtn);
                }
                else
                {
                    fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.BackToCreateProject);
                }

				tmsWait.Hard(5);
                fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.PESAVE);
                tmsWait.WaitForAlertPresent();
                fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.ConfirmYes);
                tmsWait.WaitForElement(By.CssSelector("button[test-id='prospectiveEvaluation-btn-queue']"), 300);
                ThenVerifyThatVerifyThatSuccessfulMessageAsGetDisplayed("Project Successfully Added!");
                fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.QueueToAssignBtn);
                tmsWait.WaitForElement(By.ClassName("toast-message"), 340);
            }
		}


        [Then(@"I create Assignment Project ""(.*)"" for PCP ""(.*)"" evaluation from date ""(.*)"" and to date ""(.*)""")]
        public void ThenICreateAssignmentProjectForPCPEvaluationFromDateAndToDate(string p0, string p1, string p2, string p3)
        {
            tmsWait.Hard(7);
            string projname = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Main']")));
            tmsWait.Hard(1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'Prospective Evaluation')]")));
            tmsWait.Hard(1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'Manage Projects')]")));
           
            tmsWait.Hard(5);
            fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.createProjectLink);
            tmsWait.Hard(14);
            RAM.RAMProspectiveEvaulation.ProjectNameTextBox.SendKeys(projname);
            AngularFunction.enterDate(RAM.RAMProspectiveEvaulation.FromDate, p2);
            AngularFunction.enterDate(RAM.RAMProspectiveEvaulation.ThruDate, p3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@test-id='addProspectiveEvaluation-a-pcp']/i")));     //Working on PCP lookup 
            tmsWait.Hard(8);
            //tmsWait.WaitForElement(By.XPath("//input[@id='txtLookUpId']"), 60);
            Browser.Wd.FindElement(By.XPath("//input[@test-id='pcpLookup-txt-searchBy']")).SendKeys(p1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='pcplookup-btn-Search']")));
            tmsWait.Hard(4);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='lookup-grid-searchresult']//input[@type='checkbox']")));
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@test-id='grouplookup-img-BackToRecord']")));        //End on working PCP lookup
               //selecting payment year
            
            tmsWait.Hard(3);//End on working PCP lookup
                            //selecting payment year
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='addProspectiveEvaluation-slct-dataSourceYear']//div[@class='k-multiselect-wrap k-floatwrap']//input")));
            Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='addProspectiveEvaluation-slct-dataSourceYear']//div[@class='k-multiselect-wrap k-floatwrap']//input")).SendKeys("2013");
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//li[contains(.,'2013')]")));
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='addProspectiveEvaluation-btn-save']")));
            tmsWait.Hard(5);

            try
            {


                if (Browser.Wd.FindElement(By.XPath("//span[contains(.,'Members already exists')]")).Displayed)
                {
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='addProspectiveEvaluation-btn-yes']")));
                    tmsWait.Hard(5);
                }

            }

            catch (Exception e)
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//i[@test-id='addProspectiveEvaluation-img-BackToRecord']")));
            }

            //tmsWait.Hard(6);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='prospectiveEvaluation-btn-save']")));
            //tmsWait.Hard(4);
           // fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='addProspectiveEvaluation-btn-yes']")));
            tmsWait.Hard(6);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")));
            tmsWait.Hard(7);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='prospectiveEvaluation-btn-queue']")));
            //string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
        }

        [When(@"I create Assignment Project ""(.*)"" for PCP ""(.*)"" evaluation from date ""(.*)"" and to date ""(.*)""")]
        public void WhenICreateAssignmentProjectForPCPEvaluationFromDateAndToDate(string p0, string pcpid, string fromdate, string todate)
        {
            tmsWait.Hard(7);
            string projname = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Menu']")));
            tmsWait.Hard(1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Main']")));
            tmsWait.Hard(1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'Prospective Evaluation')]")));
            tmsWait.Hard(1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'Manage Projects')]")));
            tmsWait.Hard(5);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Menu']")));
            tmsWait.Hard(1);

            if(pcpid=="firstpcp")
            {
                pcpid = Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='addProspectiveEvaluation-grid-dgMemberInfo']//td[@aria-colindex='5'])[1]")).Text;
            }
            if (pcpid == "secondpcp")
            {
                pcpid = Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='addProspectiveEvaluation-grid-dgMemberInfo']//td[@aria-colindex='5'])[2]")).Text;
            }

            fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.createProjectLink);
            tmsWait.Hard(7);
            RAM.RAMProspectiveEvaulation.ProjectNameTextBox.SendKeys(projname);
            AngularFunction.enterDate(RAM.RAMProspectiveEvaulation.FromDate, fromdate);
            AngularFunction.enterDate(RAM.RAMProspectiveEvaulation.ThruDate, todate);
           
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@test-id='addProspectiveEvaluation-a-pcp']/i")));     //Working on PCP lookup 
            tmsWait.Hard(8);
           
            Browser.Wd.FindElement(By.XPath("//input[@test-id='pcpLookup-txt-searchBy']")).SendKeys(pcpid);                 
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='pcplookup-btn-Search']"))); 
            tmsWait.Hard(4);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='lookup-grid-searchresult']//input[@type='checkbox']")));
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@test-id='grouplookup-img-BackToRecord']"))); 
             tmsWait.Hard(3);//End on working PCP lookup
                             //selecting payment year
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='addProspectiveEvaluation-slct-dataSourceYear']//div[@class='k-multiselect-wrap k-floatwrap']//input")));
            Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='addProspectiveEvaluation-slct-dataSourceYear']//div[@class='k-multiselect-wrap k-floatwrap']//input")).SendKeys("2013");
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//li[contains(.,'2013')]")));
                    
            
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='addProspectiveEvaluation-btn-save']")));
            tmsWait.Hard(5);

            try
            {

           
            if (Browser.Wd.FindElement(By.XPath("//span[contains(.,'Members already exists')]")).Displayed)
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='addProspectiveEvaluation-btn-yes']")));
                tmsWait.Hard(5);
            }

            }

            catch (Exception e)
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[test-id='confirmationDialog-btn-No']")));
            }
           
            tmsWait.Hard(6);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='prospectiveEvaluation-btn-save']")));
            tmsWait.Hard(4);
           //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='addProspectiveEvaluation-btn-yes']")));
            tmsWait.Hard(6);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")));
            tmsWait.Hard(7);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='prospectiveEvaluation-btn-queue']")));
            //string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
            //Assert.IsTrue(actualValue.Contains("The Project has been queued to Assignments successfully"));
        }





        [Then(@"Verify that Assignments page displayed with  title ""(.*)""")]
		public void ThenVerifyThatAssignmentsPageDisplayedWithTitle(string expected)
		{
			tmsWait.Hard(2);
            By loc = By.XPath("//div[@class='flex-fill'][contains(.,'Assignments')]");
            AngularFunction.elementPresenceUsingLocators(loc);
			
		}


		[Then(@"PE Assignments page Individual Update radio option selected")]
		public void ThenPEAssignmentsPageIndividualUpdateRadioOptionSelected()
		{
			fw.ExecuteJavascript(RAM.ProspectiveEvaluationAssignments.IndividualUpdate);
		}


		[Then(@"PE Assignments page Project Name is set ""(.*)""")]
		public void ThenPEAssignmentsPageProjectNameIsSet(string p0)
		{
			
			//InputValue = tmsCommon.GenerateData(p0.ToString());
			string xpath = "//select[@test-id='assignment-list-project']/option";
			IWebElement test = Browser.Wd.FindElement(By.XPath(xpath));
			string ProjectNameSelected = fw.ExecuteJavascriptReturnText(test).ToString();

			fw.KendoSelectByValue(Browser.Wd, RAM.ProspectiveEvaluationAssignments.assignmentListProject, ProjectNameSelected);
			//fw.ExecuteJavascript(test);
			
			string GeneratedUserID = tmsCommon.GenerateData(ProjectNameSelected);
			fw.setVariable("ProjectName", GeneratedUserID);
		}

        [Then(@"ProspectivetEvaluation Assignment project is set to ""(.*)""")]
        public void ThenProspectivetEvaluationAssignmentProjectIsSetTo(string p0)
        {
            string projectname = tmsCommon.GenerateData(p0);

           
                By Drp = By.XPath("//label[contains(.,'Project Name')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + projectname + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                tmsWait.Hard(3);
                //By value = By.XPath("//label[contains(.,'Project Name')]/parent::div//span[@class='k-select']");

                //AngularFunction.selectDropDownValue(value, projectname)
         

           
        }


        [When(@"PE Assignments page view project Name is set ""(.*)""")]
        public void WhenPEAssignmentsPageViewProjectNameIsSet(string p0)
        {
            tmsWait.Hard(5);
            string xpath = "//select[@test-id='prospectiveEvaluation-slct-projectName']/option";
            IWebElement test = Browser.Wd.FindElement(By.XPath(xpath));
            string ProjectNameSelected = fw.ExecuteJavascriptReturnText(test).ToString();

            //fw.KendoSelectByValue(Browser.Wd, RAM.ProspectiveEvaluationAssignments.assignmentListProject, ProjectNameSelected);
            //fw.ExecuteJavascript(test);

            string GeneratedUserID = tmsCommon.GenerateData(ProjectNameSelected);
            fw.setVariable("ProjectName", GeneratedUserID);
            GlobalRef.ProjectName= GeneratedUserID;
            GlobalRef.ExportName= "PE Project Extract Job";
        }




        [Then(@"PE Assignments page Evaluation date is set ""(.*)""")]
		public void ThenPEAssignmentsPageEvaluationDateIsSet(string p0)
		{
			if (p0.ToString().Contains("Available_Year"))
			{
				// no need to select , default value consider here
			}
			else
			{
				InputValue = tmsCommon.GenerateData(p0.ToString());
				string xpath = "//li[contains(.,'" + InputValue + "')]";
				IWebElement test = Browser.Wd.FindElement(By.XPath(xpath));
				fw.ExecuteJavascript(test);
			}
		}

        [Then(@"ProspectivetEvaluation Assignment project is selected")]
        public void ThenProspectivetEvaluationAssignmentProjectIsSelected()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Evaluation DOS - From and To Date')]/parent::div//span[@class='k-select']")));
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//li[contains(.,'2013')]")));

       
        }


        [Then(@"ProspectivetEvaluation Assignment Batch Update radio button is clicked")]
        public void ThenProspectivetEvaluationAssignmentBatchUpdateRadioButtonIsClicked()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//input[@test-id='peAssignments-rd-batchUpdate']")));
                
                }


        [Then(@"PE Assignments page Searhc Button is click")]
		public void ThenPEAssignmentsPageSearhcButtonIsClick()
		{
			tmsWait.Hard(3);
			fw.ExecuteJavascript(RAM.ProspectiveEvaluationAssignments.SearchButton);
        
        }

        [When(@"PE Assignments page Notify total records and assigned to variable ""(.*)""")]
        public void WhenPEAssignmentsPageNotifyTotalRecordsAndAssignedToVariable(string p0)
        {
            string trecords = Browser.Wd.FindElement(By.XPath("//kendo-pager-info[@class='k-pager-info k-label']")).Text;
            string[] totalrecords = trecords.Split(' ');
            fw.setVariable(p0, totalrecords[4]);
        }


        [Then(@"verify that under result Information section project name ""(.*)"" is displayed")]
		public void ThenVerifyThatUnderResultInformationSectionProjectNameIsDisplayed(string p0)
		{
			tmsWait.Hard(10);
			string ProjectName  = tmsCommon.GenerateData(p0.ToString());
			Assert.AreEqual(ProjectName, RAM.ProspectiveEvaluationAssignments.projectName.Text, ProjectName + " correct Project name is not getting displayed");
		}


        [Then(@"Get the pcpid and assigned to ""(.*)""")]
        public void ThenGetThePcpidAndAssignedTo(string p0)
        {
            string pcpid = Browser.Wd.FindElement(By.XPath("//span[@test-id='assignments-span-pcp']")).Text;
            fw.setVariable(p0, pcpid);
        }

        [Then(@"Verify PCP in database ""(.*)"" is same as PCP on UI ""(.*)""")]
        public void ThenVerifyPCPInDatabaseIsSameAsPCPOnUI(string p0, string p1)
        {
            string pcp_db = tmsCommon.GenerateData(p0);
            string pcp_ui = tmsCommon.GenerateData(p1);
            Assert.AreEqual(pcp_db, pcp_ui);
        }

        [Then(@"Verify ProjectName in database ""(.*)"" is same as Projectname on UI ""(.*)""")]
        public void ThenVerifyProjectNameInDatabaseIsSameAsProjectnameOnUI(string p0, string p1)
        {
            string project_db = tmsCommon.GenerateData(p0);
            string project_ui = tmsCommon.GenerateData(p1);
            Assert.AreEqual(project_db, project_ui);
        }

        [Then(@"Verify TotalRecords in database ""(.*)"" is same as TotalRecords on UI ""(.*)""")]
        public void ThenVerifyTotalRecordsInDatabaseIsSameAsTotalRecordsOnUI(string p0, string p1)
        {
            string totalrecords_db = tmsCommon.GenerateData(p0);
            string totalrecords_ui = tmsCommon.GenerateData(p1);
            Assert.AreEqual(totalrecords_db, totalrecords_ui);
        }



        [When(@"PE Assignments page ""(.*)"" queue select from Tree view section")]
		public void WhenPEAssignmentsPageQueueSelectFromTreeViewSection(string TreeQueue)
		{
			fsWorkflow fsWorkflow = new fsWorkflow();
            TreeQueue = tmsCommon.GenerateData(TreeQueue.ToString());
			fsWorkflow.TreeExpand(TreeQueue);

		}

		public void TreeExpand(string TreeQueue )
		{
			if (TreeQueue.Contains("Evaluation"))
			{
                fw.ExecuteJavascript(RAM.ProspectiveEvaluationAssignments.EvaulationTreeQueue);
			}
			else if (TreeQueue.Contains("Member Outreach"))
			{
                fw.ExecuteJavascript(RAM.ProspectiveEvaluationAssignments.MemberOutreachTreeQueue);
			}
			else if (TreeQueue.Contains("Provider Outreach"))
			{
                fw.ExecuteJavascript(RAM.ProspectiveEvaluationAssignments.ProviderOutreachTreeQueue);
			}
		}

		[When(@"PE Assignments page ""(.*)"" queue select Memeber as'(.*)'")]
		public void WhenPEAssignmentsPageQueueSelectMemeberAs(string p0, string p1)
		{
            
            string PCPID=GlobalRef.mPCPID.ToString();

            string xpath_pcpid = "//span[contains(.,'"+ PCPID + "')]//preceding-sibling::span";
			IWebElement test1=Browser.Wd.FindElement(By.XPath(xpath_pcpid));
			fw.ExecuteJavascript(test1);

			string MemberID = tmsCommon.GenerateData(p1.ToString());
			string xpath = "//span[contains(.,'"+ MemberID + "')]";
			IWebElement test = Browser.Wd.FindElement(By.XPath(xpath));
			fw.ExecuteJavascript(test);
			tmsWait.Hard(2);
		}

        [When(@"ProspectivetEvaluation Assignment select member ""(.*)""")]
        public void WhenProspectivetEvaluationAssignmentSelectMember(string p0)
        {
            string memid = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(@class,'k-i-expand')]")));
           tmsWait.Hard(1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(@class,'k-i-expand')]")));
            tmsWait.Hard(1);
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@class='k-icon k-i-expand']")));
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//span[contains(.,'"+memid+"')])[2]")));
            tmsWait.Hard(5);

        }


        [Then(@"verify that PE Assignments page Memeber Outreach section displayed the Member ID as ""(.*)""")]
		public void ThenVerifyThatPEAssignmentsPageMemeberOutreachSectionDisplayedTheMemberIDAs(string MemberID)
		{
			tmsWait.Hard(5);
			MemberID = tmsCommon.GenerateData(MemberID.ToString());
			Assert.AreEqual(MemberID, RAM.ProspectiveEvaluationAssignments.MemberidText.Text, MemberID + " correct Member ID is not getting displayed");
		}

		[Then(@"PE Assignments page ""(.*)"" tree view queue displayed ""(.*)"" status ""(.*)""")]
		public void ThenPEAssignmentsPageTreeViewQueueDisplayedStatus(string queue, string p1, string status)
		{
			tmsWait.Hard(3);
			fsWorkflow fsWorkflow = new fsWorkflow();
			queue = tmsCommon.GenerateData(queue.ToString());
			fsWorkflow.TreeExpand(queue);
			
			string PCPID = GlobalRef.mPCPID.ToString(); 

			string xpath_pcpid = "//span[contains(.,'" + PCPID + "')]//preceding-sibling::span";
			IWebElement test1 = Browser.Wd.FindElement(By.XPath(xpath_pcpid));
			fw.ExecuteJavascript(test1);

			string MemberID = tmsCommon.GenerateData(p1.ToString());
			string xpath = "//span[contains(.,'" + MemberID + "')]";
			IWebElement test = Browser.Wd.FindElement(By.XPath(xpath));
			string TreeMemeberStatus=fw.ExecuteJavascriptReturnText(test).ToString();
			string[] actualStatus = TreeMemeberStatus.Split('-');
			Assert.AreEqual(status, actualStatus[1].TrimStart(), "invalid Status is displayed on Tree Queue");

		}

        [Then(@"Verify ProspectivetEvaluation Assignment project displayed status as ""(.*)"" for member ""(.*)""")]
        public void ThenVerifyProspectivetEvaluationAssignmentProjectDisplayedStatusAsForMember(string p0, string p1)
        {
            string memid = tmsCommon.GenerateData(p1);
    // fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@class='k-icon k-i-expand']")));
            tmsWait.Hard(1);
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@class='k-icon k-i-expand']")));
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'"+memid+"')]")));
            string statuschk = Browser.Wd.FindElement(By.XPath("//label[@test-id='workflow-txt-memberId']")).Text;
            Assert.IsTrue(statuschk.Contains(memid));

        }

        [When(@"PE Assignments page ""(.*)"" button click")]
		public void WhenPEAssignmentsPageButtonClick(string p0)
		{
			tmsWait.Hard(3);
            fw.ScrollWindowToViewElement(RAM.ProspectiveEvaluationAssignments.HistoryButton);

            fw.ExecuteJavascript(RAM.ProspectiveEvaluationAssignments.HistoryButton);
         
            //ReUsableFunctions.reportAuthenticationHandler();
            tmsWait.Hard(10);
        }

        [When(@"PE Assignments page ""(.*)"" popup back button is clicked")]
        public void WhenPEAssignmentsPagePopupCloseButtonIsClicked(string p0)
        {
            fw.ExecuteJavascript(RAM.ProspectiveEvaluationAssignments.HistoryPopUpBack);
        }


        [Then(@"verify that Histroy page displayed with page title as ""(.*)""")]
		public void ThenVerifyThatHistroyPageDisplayedWithPageTitleAs(string ExpectedResult)
		{
			IWebElement test = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Member Assignment History')]"));
			Assert.AreEqual(ExpectedResult, fw.ExecuteJavascriptReturnText(test).ToString(), "invalid title or pop is not displayed on History button");
		}

		[When(@"PE Assignments page Memeber information section Action Due Date is set to ""(.*)""")]
		public void WhenPEAssignmentsPageMemeberInformationSectionActionDueDateIsSetTo(string p0)
		{
            if(p0=="Blank")
            {
                Console.WriteLine("By Default Action due Date having no value so not entering any date as we need to keep action due date as Blank");
            }
            else
            {
                string dt = DateTime.Now.AddDays(2).Date.ToShortDateString();
                By date = By.XPath("//kendo-datepicker[@id='dueDatePicker']//span[@role='button']");
                AngularFunction.enterDate(date, dt);
            }
            
			
		}


		[Then(@"verify that Histroy page displayed ""(.*)"" as ""(.*)""")]
		public void ThenVerifyThatHistroyPageDisplayedAs(string p0, string action)
		{
			String dt = DateTime.Now.Date.ToString("MM/dd/yyyy");
			IWebElement xpath;
            By loc;

			string test = null;
			switch (p0.ToString())
			{
				case "Action":
					loc =By.XPath("//kendo-grid[@test-id='grd-member-Workflow-History']//td[contains(.,'"+action+"')]");
                    AngularFunction.elementPresenceUsingLocators(loc);
					//xpath = Browser.Wd.FindElement(By.XPath(test));
					//string actual = fw.ExecuteJavascriptReturnText(xpath).ToString();
                    //Assert.AreEqual(action.ToString(), fw.ExecuteJavascriptReturnText(xpath).ToString(), "Invalid action is displayed");
					break;

				case "Queue":
					action=tmsCommon.GenerateData(action.ToString());
					test = "//td[contains(.,'" + dt + "')]/following-sibling::td//span[contains(.,'" + action + "')]";
					//xpath = Browser.Wd.FindElement(By.XPath(test));
					//Assert.AreEqual(action.ToString(), fw.ExecuteJavascriptReturnText(xpath).ToString(), "Invalid Queue is displayed");
					break;
				case "Queue Status":
					action = tmsCommon.GenerateData(action.ToString());
                    loc = By.XPath("//kendo-grid[@test-id='grd-member-Workflow-History']//td[contains(.,'" + action + "')]");
                    AngularFunction.elementPresenceUsingLocators(loc);

     //               test = "//td[contains(.,'" + dt + "')]/following-sibling::td//span[contains(.,'" + action + "')]";
					//xpath = Browser.Wd.FindElement(By.XPath(test));
					//Assert.AreEqual(action.ToString(), fw.ExecuteJavascriptReturnText(xpath).ToString(), "Invalid Queue Status is displayed");
					break;
				case "Updated By":
					//action = tmsCommon.GenerateData(action.ToString());
                    loc = By.XPath("(//kendo-grid[@test-id='grd-member-Workflow-History']//td[contains(.,'tmsadmin')])[1]");
                    AngularFunction.elementPresenceUsingLocators(loc);
					//xpath = Browser.Wd.FindElement(By.XPath(test));
					//Assert.AreEqual(action.ToString(), fw.ExecuteJavascriptReturnText(xpath).ToString(), "Invalid Queue Status is displayed");
					break;

                case "Action Due Date":string bdate = Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='grd-member-Workflow-History']//td[@aria-colindex=5][@colspan='1'])[1]")).Text;
                    if(action=="Blank")
                    {
                        action = "";
                    }
                    Assert.AreEqual(action, bdate);
                    break;
			}
		}



		[When(@"PE Assignments page ""(.*)"" button is clicked")]
		public void WhenPEAssignmentsPageButtonIsClicked(string p0)
		{
			tmsWait.Hard(5);
			fw.ExecuteJavascript(RAM.ProspectiveEvaluationAssignments.updateButton);
		}

		[Then(@"verify that verify that successful message as ""(.*)"" get displayed")]
		public void ThenVerifyThatVerifyThatSuccessfulMessageAsGetDisplayed(string p0)
		{
			string expected = p0.ToString();
			string actual = fsAddDiagnosisCode.toasterMessagedisplay();
			Assert.AreEqual(expected, actual, "Both values are not getting matched");
		}

		[Then(@"verify that PE Assignments page Memeber section displayed the Queue as ""(.*)""")]
		public void ThenVerifyThatPEAssignmentsPageMemeberSectionDisplayedTheQueueAs(string Queue)
		{
			tmsWait.Hard(5);
			Queue = tmsCommon.GenerateData(Queue.ToString());
			string actual_Queue = RAM.ProspectiveEvaluationAssignments.Queue.Text;
            Assert.AreEqual(Queue, RAM.ProspectiveEvaluationAssignments.Queue.Text, "Invalid queue name displayed");
		}


		[Then(@"verify that PE Assignments page Memeber section displayed the Queue Status as ""(.*)""")]
		public void ThenVerifyThatPEAssignmentsPageMemeberSectionDisplayedTheQueueStatusAs(string QueueStatus)
		{
			tmsWait.Hard(2);
			QueueStatus = tmsCommon.GenerateData(QueueStatus.ToString());
			string[] actual_status = QueueStatus.Split('-');
			Assert.AreEqual(actual_status[1], RAM.ProspectiveEvaluationAssignments.QueueStatus.Text, "Invalid queue status displayed");
        }


		/// <summary>
		/// 
		/// </summary>
		/// <param name="TreeQueue"></param>
		/// <param name="Action"></param>
		/// <param name="ActionStatus"></param>
		[When(@"PE Assignments page ""(.*)"" section Action is set to ""(.*)"" with Action Status set to ""(.*)""")]
		public void WhenPEAssignmentsPageSectionActionIsSetToWithActionStatusSetTo(string TreeQueue, string Action, string ActionStatus)
		{
			TreeQueue = tmsCommon.GenerateData(TreeQueue.ToString());
			tmsWait.Hard(5);

			Action=tmsCommon.GenerateData(Action.ToString());
			ActionStatus= tmsCommon.GenerateData(ActionStatus.ToString());
			string[] action_status = ActionStatus.Split('-');
            fsWorkflow obj = new fsWorkflow();

            By actionDrp = By.XPath("(//label[contains(.,'Action')]/parent::div//span[@class='k-select'])[1]");
            AngularFunction.selectDropDownValue(actionDrp, Action);


			if (!Action.Contains("Close or Open"))
            {
                By actionDrp1 = By.XPath("(//label[contains(.,'Action Status')]/parent::div//span[@class='k-select'])[1]");
                AngularFunction.selectDropDownValue(actionDrp1, ActionStatus);
                
			}
			

			
		}


		private void SelectAction(string Action)
		{
			tmsWait.Hard(2);
			string xpath = "//ul[@id='drpIndividualUpdateAction_listbox']//li[contains(.,'" + Action + "')]";
			IWebElement test = Browser.Wd.FindElement(By.XPath(xpath));
			fw.ExecuteJavascript(test);
			tmsWait.Hard(2);
		}
		private void SelectActionStatus(string ActionStatus)
		{
			string xpath = "//li[contains(.,'" + ActionStatus + "')]";
			IWebElement test = Browser.Wd.FindElement(By.XPath(xpath));
			fw.ExecuteJavascript(test);
		}

		
	}
}
