﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using OpenQA.Selenium.Interactions;
using System.Collections;

namespace TMSoR1.FrameworkCode.HCC_RAM
{
    [Binding]
    class OnHoldFunctionality
    {
        [When(@"Manage Suspect page get the member id from ""(.*)""")]
        public void WhenManageSuspectPageGetTheMemberId(string rampage)
        {

            switch (rampage.ToLower())
            {
                case "manage suspect":
                    GlobalRef.MemberId = RAM.ManageSuspectPage.MemberId.Text;
                    break;
                case "enter new diagnosis data":
                    GlobalRef.MemberId = Suspects.EnterNewDiagnosisCode.GetMemberID.Text;
                    break;
            }


        }
        [When(@"Payment Year ""(.*)"" is prepared from Encounter Date ""(.*)""")]
        public void WhenPaymentYearIsPreparedFromEncounterDate(string p0, string p1)
        {
            string paymentyear = tmsCommon.GenerateData(p0);
            string encounterDate = tmsCommon.GenerateData(p1);
            string temp = (Convert.ToInt32(((encounterDate.Split(' '))[0].Split('/'))[2]) + 1).ToString();
            fw.ConsoleReport(" Payment Year " + temp);
            fw.setVariable(paymentyear, temp);
        }
        [When(@"Payment Year NEW ""(.*)"" is prepared from Encounter Date ""(.*)""")]
        public void WhenPaymentYearNEWIsPreparedFromEncounterDate(string p0, string p1)
        {
            string paymentyear = tmsCommon.GenerateData(p0);
            string encounterDate = tmsCommon.GenerateData(p1);
            string temp = (Convert.ToInt32(encounterDate )+ 1).ToString();
            fw.ConsoleReport(" Payment Year " + temp);
            fw.setVariable(paymentyear, temp);
        }


        [When(@"Execute Query based on Index ""(.*)"" assign variable ""(.*)"" to value ""(.*)""")]
        public void WhenExecuteQueryBasedOnIndexAssignVariableToValue(int index, string p1, string query)
        {
           tmsWait.Hard(10); // Reason for more Wait is Table field updation is taking time. please do not remove this wait
            string result = db.returnSQLQueryresultsBasedOnIndex(query, index);

            // Commenting below statement as SQL Message box wont return anything
            if (p1.ToLower().Contains("date"))
            {
                string temp = (result.Trim().Split(" "))[0];
                fw.setVariable(p1, temp);

            }
            else
            {
                fw.setVariable(p1, result.Trim());
            }

        }

        [When(@"Execute Query ""(.*)"" and Store it in Datatable")]
        public void WhenExecuteQueryAndStoreItInDatatable(string query)
        {
            //System.Data.DataTable results = db.executeQueryStoreIntoDatatable(query);
            List<string> li = new List<string>();

           db.StoreDBResults(query,li);
            
        }


        [When(@"Execute Query using SQL Connection ""(.*)""")]
        public void WhenExecuteQueryUsingSQLConnection(string query)
        {
            tmsWait.Hard(15); // Reason for more Wait is Table field updation is taking time. please do not remove this wait
            string result = db.returnSQLQueryresultsBasedOnIndex(query, 0);
           
        }

        [Then(@"Verify variable ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyVariableIsSetTo(string p0, string p1)
        {
            p0 = tmsCommon.GenerateData(p0);

            Assert.AreEqual(p0, p1, " Both are not matching");
        }


        [When(@"Actual ""(.*)"" is set to ""(.*)""")]
        public void WhenActualIsSetTo(string p0, string p1)
        {
            string edate = tmsCommon.GenerateData(p0);
            string[] ed = edate.Split(' ');
            string actual_edate = ed[0];
            fw.setVariable(p1, actual_edate);
        }


        [Then(@"Verify TRR returns PartDSubsLevel as ""(.*)"" LowIncCoPayCat as ""(.*)""")]
        public void ThenVerifyTRRReturnsPartDSubsLevelAsLowIncCoPayCatAs(string expPartD, string expLowInc)
        {
            string actualPartD = GlobalRef.Value0.ToString();
            string actualLowInc = GlobalRef.Value1.ToString();

            Assert.AreEqual(expPartD, actualPartD, " Both are not matching");
            
            Assert.AreEqual(expLowInc, actualLowInc, " Both are not matching");
        }

        [When(@"Execute Query store it to Array format ""(.*)""")]
        public void WhenExecuteQueryStoreItToArrayFormat(string dbname)
        {


            tmsWait.Hard(15); // Reason for more Wait is Table field updation is taking time. please do not remove this wait
            string[] results = db.returnSQLQueryresultsWithArrayFormat(dbname);

            for (int i = 0; i < results.Length; i++)
            {
                ScenarioContext.Current["Value" + i + ""] = results[i];

            }
        }
        List<string> StringValue;
        public System.Collections.Generic.List<string> SearchTextInResultGridWithStatusList(string textValidate)
        {
            try
            {
                
                IList<IWebElement> list = Browser.Wd.FindElements(By.XPath("//table[@role='grid']//td[contains(.,'" + textValidate + "')]/preceding-sibling::td/input"));
                foreach(IWebElement a in list)
                { 
                if (a.GetAttribute("checked").ToLower().Equals("true"))
                    {
                        string checkedonhold = Browser.Wd.FindElement(By.XPath("//table[@role='grid']//td[contains(.,'" + textValidate + "')]")).Text;

                        StringValue.Add(checkedonhold);


                    }
                }

            }
            catch (Exception ex)
            {
                return StringValue;
            }
           
            return StringValue;


        }
       public List<string> dbValues;
        string[,] array2Db;
        List<int> dbIntValues;
        List<int> dbIntValues1;
        List<int> dbIntValues2;
     
        List<DateTime> dbDateValues;
        [When(@"Execute Query on DB ""(.*)"" get all the values from Tablee")]
        [When(@"Execute Query on DB ""(.*)"" get all the values from Table")]
        public void WhenExecuteQueryOnDBGetAllTheValuesFromTable(string dbname)
        {
            tmsWait.Hard(15); // Reason for more Wait is Table field updation is taking time. please do not remove this wait

            dbIntValues = db.returnSQLQueryresultsWithCompleteIntegerRowsInArrayFormat(dbname);

        }
        [Then(@"Execute Query on DB ""(.*)"" get all the string values from Table")]
       
        [When(@"Execute Query on DB ""(.*)"" get all the string values from Table")]
        public void WhenExecuteQueryOnDBGetAllTheStringValuesFromTable(string p0)
        {
            tmsWait.Hard(15);
            dbValues = db.returnSQLQueryresultsWithCompleteRowsInArrayFormat(p0);
        }
        [When(@"Execute Query on DB ""(.*)"" get all the string values from Table new")]
        public void WhenExecuteQueryOnDBGetAllTheStringValuesFromTableNew(string p0)
        {
            tmsWait.Hard(15);
            array2Db = db.returnSQLQueryresultsWithCompleteIntegerRowsInArrayFormatnew(p0);
        }

        [When(@"Execute Query on DB ""(.*)"" get all the Integer values from Table")]
        public void WhenExecuteQueryOnDBGetAllTheIntegerValuesFromTable(string dbname)
        {
            tmsWait.Hard(15); // Reason for more Wait is Table field updation is taking time. please do not remove this wait

            dbIntValues = db.returnSQLQueryresultsWithCompleteIntegerRowsInArrayFormat(dbname);
        }
        [When(@"Execute Query on DB ""(.*)"" get all the SmallInteger values from Table")]
        public void WhenExecuteQueryOnDBGetAllTheSmallIntegerValuesFromTable(string dbname)
        {
            tmsWait.Hard(15); // Reason for more Wait is Table field updation is taking time. please do not remove this wait

            dbIntValues = db.returnSQLQueryresultsWithCompleteIntegerRowsInArrayFormat16(dbname);
        }
        [When(@"Execute Query on DB ""(.*)"" get all the Integer values from Table tbMemberHCC")]
        public void WhenExecuteQueryOnDBGetAllTheIntegerValuesFromTableTbMemberHCC(string dbname)
        {
         
            tmsWait.Hard(15); // Reason for more Wait is Table field updation is taking time. please do not remove this wait

            dbIntValues = db.returnSQLQueryresultsWithCompleteIntegerRowsInArrayFormat(dbname);
        }
        [When(@"Execute Query on DB ""(.*)"" get all the Integer values from tbRAM_PTC_HCC_DESC Table")]
        public void WhenExecuteQueryOnDBGetAllTheIntegerValuesFromTbRAM_PTC_HCC_DESCTable(string p0)
        {
            tmsWait.Hard(15); // Reason for more Wait is Table field updation is taking time. please do not remove this wait

            dbIntValues1 = db.returnSQLQueryresultsWithCompleteIntegerRowsInArrayFormat(p0);
        }

        [When(@"Execute Query on DB ""(.*)"" get all intHCC Integer values from tbMemberHCC and Verify Value")]
        public void WhenExecuteQueryOnDBGetAllIntHCCIntegerValuesFromTbMemberHCCAndVerifyValue(string p0)
        {

        
        tmsWait.Hard(15); // Reason for more Wait is Table field updation is taking time. please do not remove this wait

            dbIntValues2 = db.returnSQLQueryresultsWithCompleteIntegerRowsInArrayFormat16(p0);
            List<int> resultantString = compareTwoListint(dbIntValues1, dbIntValues2);
           
                Assert.IsTrue((resultantString.Count == 0),"Values are not matching"); 
            
        }
        [When(@"Execute Query on DB ""(.*)"" get all intHCC Integer values from Table")]
        public void WhenExecuteQueryOnDBGetAllintHCCIntegerValuesFromTable(string dbname)
        {
            tmsWait.Hard(15); // Reason for more Wait is Table field updation is taking time. please do not remove this wait

            dbIntValues = db.returnSQLQueryresultsWithCompleteIntegerRowsInArrayFormat16(dbname);
            string str = "";
            for (int i = 0; i < dbIntValues.Count; i++)
            {
                if(!(i== dbIntValues.Count - 1))
                {

                
                str = str +"'"+ dbIntValues[i] + "',";
                }else
                {
                    str = str + "'" + dbIntValues[i] + "'";
                }
            }
            ScenarioContext.Current["HCCValue"] = str;
        }


        [When(@"Execute Query on DB ""(.*)"" get all the Date values from Table")]
        public void WhenExecuteQueryOnDBGetAllTheDateValuesFromTable(string dbname)
        {
            tmsWait.Hard(15); // Reason for more Wait is Table field updation is taking time. please do not remove this wait

            dbDateValues = db.returnSQLQueryresultsWithCompleteDateRowsInArrayFormat(dbname);
        }


        List<string> compareTwoList(List<string> drpValues, List<string> dbValues)
        {
            List<string> resultantList = new List<string>();

            //Console.WriteLine("Difference in the Drop Down List and DB value lists...");
            IEnumerable<string> list3;
            list3 = drpValues.Except(dbValues);
            
            foreach (string value in list3)
            {
                resultantList.Add(value);
            }
            return resultantList;
        }
        bool compareTwoListAA(string[,] array2, string[,] array1)
        {

          bool r=  array2.Cast<string>().SequenceEqual(array1.Cast<string>());
            return r;

        }


        List<int> compareTwoListint(List<int> drpValues, List<int> dbValues)
        {
            List<int> resultantList = new List<int>();
            List<int> stringdrpValues = new List<int>();
            foreach (int temp in dbValues)
            {
                stringdrpValues.Add(temp);
            }

            Console.WriteLine("Difference in the Drop Down List and DB value lists...");
            IEnumerable<int> list3;
            list3 = drpValues.Except(stringdrpValues);
            foreach (int value in list3)
            {
                resultantList.Add(value);
            }
            return resultantList;
        }
        // Compare String and Integer
        List<string> compareTwoList(List<string> drpValues, List<int> dbValues)
        {
            List<string> resultantList = new List<string>();
            List<string> stringdrpValues = new List<string>();
            foreach (int temp in dbValues)
            {
                stringdrpValues.Add(temp.ToString());
            }

            Console.WriteLine("Difference in the Drop Down List and DB value lists...");
            IEnumerable<string> list3;
            list3 = drpValues.Except(stringdrpValues);
            foreach (string value in list3)
            {
                resultantList.Add(value);
            }
            return resultantList;
        }

        // Compare String and Date
        List<string> compareTwoList(List<string> drpValues, List<DateTime> dbValues)
        {
            List<string> resultantList = new List<string>();
            List<string> stringdrpValues = new List<string>();
            foreach (DateTime temp in dbValues)
            {
                stringdrpValues.Add(temp.ToString("MM/dd/yyyy"));
            }

            Console.WriteLine("Difference in the Drop Down List and DB value lists...");
            IEnumerable<string> list3;
            list3 = drpValues.Except(stringdrpValues);
            foreach (string value in list3)
            {
                resultantList.Add(value);
            }
            return resultantList;
        }
       public List<string> ConvertWebElementInToString(IList<IWebElement> webdrpValues)
        {
            List<string> temp=new List<string>();
            Console.WriteLine(" List of Values in Drop Down list");
            foreach(IWebElement t in webdrpValues)
            {
                temp.Add(t.Text);
                Console.WriteLine(t.Text);
            }
            return temp;

        }
        public static List<string> ConvertWebElementInToStringg(IList<IWebElement> webdrpValues)
        {
            List<string> temp = new List<string>();
            Console.WriteLine(" List of Values in Drop Down list");
            foreach (IWebElement t in webdrpValues)
            {
                tmsWait.Hard(4);
                temp.Add(t.Text);
                Console.WriteLine(t.Text);
            }
            return temp;

        }
        List<string> ConvertWebElementInToStringUptoSpecific(IList<IWebElement> webdrpValues)
        {
            List<string> temp = new List<string>();
            Console.WriteLine(" List of Values in Drop Down list");
            int count = 1;
            foreach (IWebElement t in webdrpValues)
            {
                
                temp.Add(t.Text);
                Console.WriteLine(t.Text);
                count++;
                if (count==8)
                {
                    break;
                }
            }
            return temp;

        }

        
      public  List<string> ConvertWebElementInToString1(IList<IWebElement> webdrpValues)
        {
            List<string> temp = new List<string>();
            Console.WriteLine(" Plan ID is checked for 5 star rating");
            foreach (IWebElement t in webdrpValues)
            {
                temp.Add(t.Text);
                Console.WriteLine(t.Text);
            }
            return temp;

        }
        [Then(@"Verify Reports page Age drop down values")]
        public void ThenVerifyReportsPageAgeDropDownValues()
        {
            IList<IWebElement> webdrpValues;
            List<string> stringdrpValues;
            List<string> resultantString;
            List<string> constantValue =new List<string> {"New","1 - 3 Months","4 - 6 Months","7 - 9 Months","10 - 12 Months","13 - 24 Months","25 Months +"};

            webdrpValues = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@id='ReportViewerControl_ctl04_ctl19_ddValue']"))).Options;
            stringdrpValues = ConvertWebElementInToString(webdrpValues);
            
            resultantString = compareTwoList(stringdrpValues, constantValue);
            foreach (string temp in resultantString)
            {
                if (temp.Equals("<Select a Value>"))
                {
                    Assert.IsTrue(true, " All values are matched");
                    break;
                }
                else
                {
                    Assert.Fail(" DB values are not displayed on Drop down");
                }
            }
            
        }
        [When(@"I clicks on ""(.*)"" verify sorting of ""(.*)"" with Database Code values")]
        public void WhenIClicksOnVerifySortingOfWithDatabaseCodeValues(string p0, string p1)
        {
            string value = tmsCommon.GenerateData(p0);


            List<string> stringdrpValues = new List<string>();
            List<string> stringValues;
            List<string> stringDBValues = dbValues;

            tmsWait.Hard(2);
                switch (value.ToLower())
                {
                    case "disenrol code header":
                    List<int> intdrpValues = new List<int>();
                    List<int> intValues;
                    List<int> intDBValues = dbIntValues;
                    IList<IWebElement> code = null;
                    Browser.Wd.FindElement(By.XPath("//span[@title='Code']")).Click();
                    tmsWait.Hard(2);
                    code = Browser.Wd.FindElements(By.XPath("//div[@test-id='disenrollmentReasons-grid-disenrollmentReasons']/table//tr/td[1]"));
                        tmsWait.Hard(7);

                    intValues = ConvertWebElementInTo(code);
                        foreach (int t in intValues)
                        {
                        intdrpValues.Add(t);

                        }



                        List<int> resultantint = compareTwoListint(intDBValues, intdrpValues);

                        Assert.IsTrue((resultantint.Count == 0), "Values are not matching");
                        break;
                    case "description header":
                   
                    Browser.Wd.FindElement(By.XPath("//span[@title='Description']")).Click();
                    tmsWait.Hard(2);
                    code = Browser.Wd.FindElements(By.XPath("//div[@test-id='disenrollmentReasons-grid-disenrollmentReasons']/table//tr/td[3]"));

                    tmsWait.Hard(7);
                    stringValues = ConvertWebElementInToString(code);
                    foreach (string t in stringValues)
                    {
                        stringdrpValues.Add(t);

                    }



                    List<string> resultantString = compareTwoList(stringDBValues, stringdrpValues);

                    Assert.IsTrue((resultantString.Count == 0), "Values are not matching");
                    break;

                case "hccname":
                    // RAM Manage Suspect Page TOP Known HCC name comparison with the db values 
                    tmsWait.Hard(2);
                    code = Browser.Wd.FindElements(By.XPath("//kendo-grid[@test-id='providerPirDetails-grid-topKnown']//tbody/tr/td[1]"));
                    tmsWait.Hard(5);
                    stringValues = ConvertWebElementInToString(code);
                    foreach (string t in stringValues)
                    {
                        stringdrpValues.Add(t);

                    }
                    List<string> resultantString10 = compareTwoList(stringDBValues, stringdrpValues);
                    Assert.IsTrue((resultantString10.Count == 0), "Values are not matching");
                    break;

                case "hccdescription":
                    // RAM Manage Suspect Page TOP Known HCC Description comparison with the db values 
                    tmsWait.Hard(2);
                    code = Browser.Wd.FindElements(By.XPath("//kendo-grid[@test-id='providerPirDetails-grid-topKnown']//tbody/tr/td[2]"));
                    tmsWait.Hard(5);
                    stringValues = ConvertWebElementInToString(code);
                    foreach (string t in stringValues)
                    {
                        stringdrpValues.Add(t);

                    }
                    List<string> resultantString11 = compareTwoList(stringDBValues, stringdrpValues);
                    Assert.IsTrue((resultantString11.Count == 0), "Values are not matching");
                    break;



                case "langcode":
                   
                    Browser.Wd.FindElement(By.XPath("//a[contains(.,'Code')]")).Click();
                    Browser.Wd.FindElement(By.XPath("//a[contains(.,'Code')]")).Click();
                    tmsWait.Hard(2);
                    code = Browser.Wd.FindElements(By.XPath("//div[@test-id='language-grid-languages']//td[1]"));

                    tmsWait.Hard(7);
                    stringValues = ConvertWebElementInToString(code);
                    foreach (string t in stringValues)
                    {
                        stringdrpValues.Add(t);

                    }



                    List<string> resultantString1 = compareTwoList(stringDBValues, stringdrpValues);

                    Assert.IsTrue((resultantString1.Count == 0), "Values are not matching");
                    break;
                case "langname":

                    Browser.Wd.FindElement(By.XPath("//a[contains(.,'Name')]")).Click();
                    tmsWait.Hard(2);
                    code = Browser.Wd.FindElements(By.XPath("//div[@test-id='language-grid-languages']//td[2]"));

                    tmsWait.Hard(7);
                    stringValues = ConvertWebElementInToString(code);
                    foreach (string t in stringValues)
                    {
                        stringdrpValues.Add(t);

                    }

                    List<string> resultantString2 = compareTwoList(stringDBValues, stringdrpValues);

                    Assert.IsTrue((resultantString2.Count == 0), "Values are not matching");
                    break;
                case "relcode":
Browser.Wd.FindElement(By.XPath("//a[contains(.,'Code')]")).Click();
                    tmsWait.Hard(2);
                    Browser.Wd.FindElement(By.XPath("//a[contains(.,'Code')]")).Click();
                    tmsWait.Hard(2);
            code = Browser.Wd.FindElements(By.XPath("//div[@test-id='relationship-grid-relationships']//td[1]"));

            tmsWait.Hard(7);
            stringValues = ConvertWebElementInToString(code);
            foreach (string t in stringValues)
            {
                stringdrpValues.Add(t);

            }

            List<string> resultantString3 = compareTwoList(stringDBValues, stringdrpValues);

            Assert.IsTrue((resultantString3.Count == 0), "Values are not matching");
            break;
                case "relname":

                    Browser.Wd.FindElement(By.XPath("//a[contains(.,'Relationship')]")).Click();
                    tmsWait.Hard(2);
                    code = Browser.Wd.FindElements(By.XPath("//div[@test-id='relationship-grid-relationships']//td[2]"));

                    tmsWait.Hard(7);
                    stringValues = ConvertWebElementInToString(code);
                    foreach (string t in stringValues)
                    {
                        stringdrpValues.Add(t);

                    }

                    List<string> resultantString4 = compareTwoList(stringDBValues, stringdrpValues);

                    Assert.IsTrue((resultantString4.Count == 0), "Values are not matching");
                    break;
            }


    }

        private List<int> ConvertWebElementInTo(IList<IWebElement> code)
        {
            List<int> temp = new List<int>();
            Console.WriteLine(" List of Values in Drop Down list");
            foreach (IWebElement t in code)
            {
                temp.Add(Int32.Parse(t.Text));
                Console.WriteLine(t.Text);
            }
            return temp;
        }

        [When(@"I Keep ""(.*)"" as blank And ""(.*)"" field as blank And ""(.*)"" as blank and clicked on save and verify red error msg")]
        public void WhenIKeepAsBlankAndFieldAsBlankAndAsBlankAndClickedOnSaveAndVerifyRedErrorMsg(string p0, string p1, string p2)
        {
        ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.Disenrollment.SaveBtn);

            tmsWait.Hard(2);

            string actualValue = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Disenroll Code is a required field')]")).Text;
            Assert.IsTrue(actualValue.Contains("Disenroll Code is a required field"));

            string actualValue2 = Browser.Wd.FindElement(By.XPath("//span[contains(.,'MapTo is a required field')]")).Text;
            Assert.IsTrue(actualValue2.Contains("MapTo is a required field"));

            string actualValue3 = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Description is a required field')]")).Text;
            Assert.IsTrue(actualValue3.Contains("Description is a required field"));


           
        }
        [When(@"I Keep ""(.*)"" fields as blank and clicked on save and verify red error msg")]
        public void WhenIKeepFieldsAsBlankAndClickedOnSaveAndVerifyRedErrorMsg(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            string xpath = null;
            // tmsWait.Hard(2);

            switch (value.ToLower())
            {
                case "language":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.Language.SaveButton);
                    break;

                    tmsWait.Hard(2);

                    string actualValue = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Code is a require field.')]")).Text;
                    Assert.IsTrue(actualValue.Contains("Code is a require field."));

                    string actualValue2 = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Language is a require field.')]")).Text;
                    Assert.IsTrue(actualValue2.Contains("Language is a require field."));

                case "relationship":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.RelationShip.SaveButton);
                    string actualValue3 = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Relation code is required.')]")).Text;
                    Assert.IsTrue(actualValue3.Contains("Relation code is required."));

                    string actualValue4 = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Relationship is required.')]")).Text;
                    Assert.IsTrue(actualValue4.Contains("Relationship is required."));
                    break;
            }
        }


        [When(@"I Keep ""(.*)"" as blank And ""(.*)"" field as blank and clicked on save and verify red error msg")]
        public void WhenIKeepAsBlankAndFieldAsBlankAndClickedOnSaveAndVerifyRedErrorMsg(string p0, string p1)
        {
            string value = tmsCommon.GenerateData(p0);
            string xpath = null;
            // tmsWait.Hard(2);

            switch (value.ToLower())
            {
                case "language":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.Language.SaveButton);
                    break;

                    tmsWait.Hard(2);

                    string actualValue = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Code is a require field.')]")).Text;
                    Assert.IsTrue(actualValue.Contains("Code is a require field."));

                    string actualValue2 = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Language is a require field.')]")).Text;
                    Assert.IsTrue(actualValue2.Contains("Language is a require field."));

                case "relationship":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.RelationShip.SaveButton);
                    string actualValue3 = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Relation code is required.')]")).Text;
                    Assert.IsTrue(actualValue3.Contains("Relation code is required."));

                    string actualValue4 = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Relationship is required.')]")).Text;
                    Assert.IsTrue(actualValue4.Contains("Relationship is required."));
                    break;
            }
        }


        [When(@"I clicks on Next previous first  last button arrows of pagination if there are more than ""(.*)"" records in grid")]
        public void WhenIClicksOnNextPreviousFirstLastButtonArrowsOfPaginationIfThereAreMoreThanRecordsInGrid(string p0)
        {
            
       
            IList<IWebElement> code;
            string value = tmsCommon.GenerateData(p0);
            string xpath = null;
           // tmsWait.Hard(2);

            switch (value.ToLower())
            {
                case "disenrollment":
                     xpath = "disenrollmentReasons-grid-disenrollmentReasons";
                    break;
                case "languages":
                    xpath = "language-grid-languages";
                    break;
                case "relationship":
                    xpath = "relationship-grid-relationships";
                    break;
            }
            tmsWait.Hard(2);

            code = Browser.Wd.FindElements(By.XPath("//div[@test-id='"+ xpath +"']//td[1]"));

            if (code.Count == 10)
            {
                IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                ReUsableFunctions.clickOnWebElement(nextpage);

                tmsWait.Hard(2);

                IWebElement prevpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the previous page']"));
                ReUsableFunctions.clickOnWebElement(prevpage);
                tmsWait.Hard(2);

                IWebElement lastpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']"));
                ReUsableFunctions.clickOnWebElement(lastpage);
                tmsWait.Hard(2);

                IWebElement firstpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the first page']"));
                ReUsableFunctions.clickOnWebElement(firstpage);
            }
        }
        [Then(@"Verify EAM Administration page View Edit Plan Info section ""(.*)"" values matched with Database PlanID values")]
        public void ThenVerifyEAMAdministrationPageViewEditPlanInfoSectionValuesMatchedWithDatabasePlanIDValues(string p0)
        {

            List<string> stringdrpValues = new List<string>();
            List<string> stringValues;
            List<string> stringDBValues = dbValues;
            IList<IWebElement> code;
            tmsWait.Hard(2);
            int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                tmsWait.Hard(2);
                code = Browser.Wd.FindElements(By.XPath("//div[@test-id='planInfo-grid-plans']//span[@ng-bind='dataItem.planId']"));
                tmsWait.Hard(7);
                stringValues = ConvertWebElementInToString(code);
                foreach (string t in stringValues)
                {
                    stringdrpValues.Add(t);

                }
                IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                ReUsableFunctions.clickOnWebElement(nextpage);

            }
            List<string> resultantString = compareTwoList(stringDBValues, stringdrpValues);

            Assert.IsTrue((resultantString.Count == 0), "Values are not matching");
        }
        List<string> StringValue2= new List<string>();
        [Then(@"AddOnHoldReason All active Onholdreason is stored in list")]
        public void ThenAddOnHoldReasonAllActiveOnholdreasonIsStoredInList()
        {
            int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {

                    IList<IWebElement> list = Browser.Wd.FindElements(By.XPath("//table[@role='grid']//td[2]/input[@checked='checked']"));
                    foreach (IWebElement a in list)
                    {
                        if (a.GetAttribute("checked").ToLower().Equals("true"))
                        {
                            string checkedonhold = Browser.Wd.FindElement(By.XPath("//table[@role='grid']//td[2]/input[@checked='checked']/parent::td/following-sibling::td[1]")).Text;

                            StringValue2.Add(checkedonhold);


                        }
                    }

                }

                catch (Exception ex)
                {

                }

                IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                ReUsableFunctions.clickOnWebElement(nextpage);
            }


        }
        
        [Then(@"verify Manage Suspect page additional diag all active onhold reason are present")]
        public void ThenVerifyManageSuspectPageAdditionalDiagAllActiveOnholdReasonArePresent()
        {
            tmsWait.Hard(3);
            List<string> StringValue1 = new List<string>();
            fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.OnHoldReasonlistbox);
            tmsWait.Hard(2);
            IList<IWebElement> op = Browser.Wd.FindElements(By.XPath("//div[@id='ddlonHoldReason-list']//ul//li"));
            foreach (IWebElement p in op)
            {
                Console.WriteLine(p.Text);

                StringValue1.Add(p.Text);
            }

            List<string> resultantString1 = compareTwoList(StringValue2, StringValue1);

            Assert.IsTrue((resultantString1.Count == 0), "Values are not matching");

        }

        [Then(@"Verify EAM Administration page View Edit Plan Info section ""(.*)"" values matched with Database PlanID values1")]
        public void ThenVerifyEAMAdministrationPageViewEditPlanInfoSectionValuesMatchedWithDatabasePlanIDValues1(string p0)
        {
         
            IList<IWebElement> stringValues1;
           string[,] array1 = array2Db;
            IList<IWebElement> code;
            tmsWait.Hard(2);
            int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
           string scount= Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']/following-sibling::span[1]")).Text;
            string[] scount1 = scount.Split(' ');
            int c1 = Int32.Parse(scount1[4]);
            string[,] array2 = new string[c1, 3];
            int j = 0;
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                
                stringValues1 = Browser.Wd.FindElements(By.XPath("//div[@test-id='planInfo-grid-plans']//span[@ng-bind='dataItem.planId']"));





                    for (int k = 1; k <= stringValues1.Count(); k++)
                    {
                        array2[j , 0] = Browser.Wd.FindElement(By.XPath("(//div[@test-id='planInfo-grid-plans']//span[@ng-bind='dataItem.planId'])[" + k + "]")).Text;
                        array2[j , 1] = Browser.Wd.FindElement(By.XPath("(//div[@test-id='planInfo-grid-plans']//span[@ng-bind='dataItem.planId'])[" + k+ "]/parent::td/following-sibling::td[1]/span")).Text;
                        array2[j , 2] = Browser.Wd.FindElement(By.XPath("(//div[@test-id='planInfo-grid-plans']//span[@ng-bind='dataItem.planId'])[" + k+ "]/parent::td/following-sibling::td[3]/span")).Text;
                    j = j + 1;

                }
                    
                
                IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                ReUsableFunctions.clickOnWebElement(nextpage);
                tmsWait.Hard(4);
               // j = j + 1;
            }
            bool t= compareTwoListAA(array2, array1);

            Assert.IsTrue(t, "Values are not matching");
        }
        [Then(@"Verify P(.*)P AR Management page ""(.*)"" values matched with Database PlanID values")]
        public void ThenVerifyPPARManagementPageValuesMatchedWithDatabasePlanIDValues(int p0, string p1)
        {
            List<string> stringdrpValues = new List<string>();
            List<string> stringValues;
            List<string> stringDBValues = dbValues;
            IList<IWebElement> code;
            tmsWait.Hard(2);
            int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                tmsWait.Hard(2);
                code = Browser.Wd.FindElements(By.XPath("//div[@test-id='ArManagement-grid']//tr/td[2]/span"));
                tmsWait.Hard(7);
                stringValues = ConvertWebElementInToString(code);
                foreach (string t in stringValues)
                {
                    stringdrpValues.Add(t);

                }
                IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                ReUsableFunctions.clickOnWebElement(nextpage);

            }
            List<string> resultantString = compareTwoList(stringDBValues, stringdrpValues);

            Assert.IsTrue((resultantString.Count == 0), "Values are not matching");
        }

        [Then(@"Verify EAM Fallout Report Page dropdown ""(.*)"" values matched with Database values")]
        public void ThenVerifyEAMFalloutReportPageDropdownValuesMatchedWithDatabaseValues(string p0)
        {
            
        }

        [Then(@"Verify PIR Page Potential Related Diagnosis ""(.*)"" values matched with Database Code values")]


   public void ThenVerifyPIRPagePotentialRelatedDiagnosisValuesMatchedWithDatabaseCodeValues(string p0)
        {

            List<string> stringdrpValues= new List<string>();
            List<string> stringValues;
            List<string> stringDBValues = dbValues;
            IList<IWebElement> code;
            tmsWait.Hard(2);
            int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                tmsWait.Hard(2);
                code = Browser.Wd.FindElements(By.XPath("//div[@test-id='pirResponse-grid-potentialRelatedDiagnosesGrid']//span[@ng-bind='dataItem.code']"));
                tmsWait.Hard(7);
                stringValues= ConvertWebElementInToString(code);
                foreach (string t in stringValues)
                {
                    stringdrpValues.Add(t);
                   
                }
                IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                ReUsableFunctions.clickOnWebElement(nextpage);

            }
            List<string> resultantString = compareTwoList(stringDBValues, stringdrpValues);

            Assert.IsTrue((resultantString.Count == 0), "Values are not matching");
        }

        [Then(@"Verify EAM Configuration page Plan(.*)StarStatus section checked ""(.*)"" matched with Database Planid")]
        public void ThenVerifyEAMConfigurationPagePlanStarStatusSectionCheckedMatchedWithDatabasePlanid(int p0, string p1)
        {
           
            List<string> stringdrpValues = new List<string>();
            List<string> stringValues;
            List<string> stringDBValues = dbValues;
            IList<IWebElement> code = new List<IWebElement>();
            tmsWait.Hard(2);
            int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                tmsWait.Hard(2);
                try
                {
                    code = Browser.Wd.FindElements(By.XPath("//input[@checked='checked']/parent::td/preceding-sibling::td/span"));
                    tmsWait.Hard(7);
                    stringValues = ConvertWebElementInToString1(code);

                    foreach (string t in stringValues)
                    {
                        stringdrpValues.Add(t);

                    }
                }
                catch
                {

                }
                IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                ReUsableFunctions.clickOnWebElement(nextpage);

            }
            List<string> resultantString = compareTwoList(stringDBValues, stringdrpValues);

            Assert.IsTrue((resultantString.Count == 0), "Values are not matching");
        }

        [Then(@"Verify PIR Page Potential Related Diagnosis ""(.*)"" values matched with Database values")]
        public void ThenVerifyPIRPagePotentialRelatedDiagnosisValuesMatchedWithDatabaseValues(string p0)
        {
        
            List<string> stringdrpValues = null;
            List<string> stringDBValues = dbValues;
            IList<IWebElement> code;
            tmsWait.Hard(2);
            int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                tmsWait.Hard(2);
                code = Browser.Wd.FindElements(By.XPath("//div[@test-id='pirResponse-grid-potentialRelatedDiagnosesGrid']//span[@ng-bind='dataItem.code']"));
                tmsWait.Hard(7);
                stringdrpValues = ConvertWebElementInToString(code);
                tmsWait.Hard(2);
                foreach (string temp in stringdrpValues)
                {
                    if (!(stringDBValues.Contains(temp)))
                    {


                        Assert.Fail(" DB values and code values are not matching");
                    }
                }
                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);
               
            }

         
            
          
       
        }


        [Then(@"Verify HCCSquence present in tbRAM_PTC_HCC_DESC ""(.*)"" value matched with table tbMemberHCC")]
        public void ThenVerifyHCCSquencePresentInTbRAM_PTC_HCC_DESCValueMatchedWithTableTbMemberHCC(string p0)
        {
          
        string HCC = tmsCommon.GenerateData(p0);
            List<int> stringDBValues = dbIntValues;
            int hcc1 = Int32.Parse(HCC);
            foreach (int temp in stringDBValues)
            {
                if (!(stringDBValues.Contains(temp)))
                {


                    Assert.Fail(" DB values and code values are not matching");
                }
            }
        }

        [Then(@"Verify Add On-Hold Reason page ""(.*)"" values matched with Database values")]
        public void ThenVerifyAddOn_HoldReasonPageValuesMatchedWithDatabaseValues(string p0)
        {
            IList<IWebElement> webdrpValues;
            List<string> stringdrpValues;
            List<string> stringDBValues;
         
            List<string> resultantString;
         
                    webdrpValues = Browser.Wd.FindElements(By.CssSelector("[ng-bind='dataItem.reasonDescription']"));
                    
            stringdrpValues = ConvertWebElementInToStringUptoSpecific(webdrpValues);
            stringDBValues = dbValues;
                    resultantString = compareTwoList(stringdrpValues, stringDBValues);
            if (resultantString.Count == 0)
            {
                Assert.IsTrue(true, " Both are matched");
            }
            else
            {
                Assert.Fail(" DB values and Drop down values are not matching");
            }
        }
        [Then(@"Verify on Search Criteria page new ""(.*)"" dropdown has All values ""(.*)"" and ""(.*)"" and ""(.*)""")]
        public void ThenVerifyOnSearchCriteriaPageNewDropdownHasAllValuesAndAnd(string p0, string p1, string p2, string p3)
        {
           
        List<string> webdrpValues;
            List<string> stringValues = new List<string> { p1,p2,p3 };


            List<string> resultantString;
            IList<IWebElement> webValues = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@test-id='Status']"))).Options;
            webdrpValues = ConvertWebElementInToString(webValues);

            resultantString = compareTwoList(webdrpValues, stringValues);
            foreach (string temp in resultantString)
            {
                if (resultantString.Count == 1)
                {
                    if (temp.Equals("All"))
                    {
                        Assert.IsTrue(true, " All values are matched");
                        break;
                    }
                    else
                    {
                        Assert.Fail(" DB values are not displayed on Drop down");
                    }
                }
                else
                {
                    Assert.Fail(" DB values and Drop down values are not matching");
                }

            }
        }

        [Then(@"Verify on Search Criteria page ""(.*)"" dropdown has All Transaction code")]
        public void ThenVerifyOnSearchCriteriaPageDropdownHasAllTransactionCode(string p0)
        {
            List<string> webdrpValues;
            List<string> stringValues = new List<string> { "61", "51", "72", "73", "74", "75", "76", "77", "78","79", "80", "81","00" };

          
            List<string> resultantString;
            IList<IWebElement> webValues = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@test-id='TransactionCode']"))).Options;
            webdrpValues = ConvertWebElementInToString(webValues);
       
            resultantString = compareTwoList(webdrpValues, stringValues);
            foreach (string temp in resultantString)
            {
                if (resultantString.Count == 1)
                {
                    if (temp.Equals("All"))
                    {
                        Assert.IsTrue(true, " All values are matched");
                        break;
                    }
                    else
                    {
                        Assert.Fail(" DB values are not displayed on Drop down");
                    }
                }
                else
                {
                    Assert.Fail(" DB values and Drop down values are not matching");
                }

            }
        }
        [Then(@"Verify on Search Criteria page ""(.*)"" dropdown has All values ""(.*)"" and ""(.*)""")]
        public void ThenVerifyOnSearchCriteriaPageDropdownHasAllValuesAnd(string p0, string p1, string p2)
        {
            List<string> webdrpValues;
            List<string> stringValues = new List<string> { p1, p2 };

      
            List<string> resultantString;
            IList<IWebElement> webValues = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@test-id='FileType']"))).Options;
            webdrpValues = ConvertWebElementInToString(webValues);

            resultantString = compareTwoList(webdrpValues, stringValues);
            foreach (string temp in resultantString)
            {
                if (resultantString.Count == 1)
                {
                    if (temp.Equals("All"))
                    {
                        Assert.IsTrue(true, " All values are matched");
                        break;
                    }
                    else
                    {
                        Assert.Fail(" DB values are not displayed on Drop down");
                    }
                }
                else
                {
                    Assert.Fail(" DB values and Drop down values are not matching");
                }

            }
        }

        
        [Then(@"Verify Reports page ""(.*)"" drop down values matched with Database values")]
        public void ThenVerifyReportsPageDropDownValuesMatchedWithDatabaseValues(string type)
        {
            IList<IWebElement> webdrpValues;
            List<string> stringdrpValues;
            List<string> stringDBValues;
            List<int> integerDBValues;
            List<DateTime> dateDBValues;
            List<string> resultantString;
            switch (type)
            {
                case "Discrepancy Type":
                    webdrpValues = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@id='ReportViewerControl_ctl04_ctl03_ddValue']"))).Options;
                    stringdrpValues=ConvertWebElementInToString(webdrpValues);
                    stringDBValues = dbValues;
                     resultantString =compareTwoList(stringdrpValues, stringDBValues);
                    foreach (string temp in resultantString)
                    {
                        if (resultantString.Count == 1)
                        {
                            if (temp.Equals("<Select a Value>"))
                            {
                                Assert.IsTrue(true, " All values are matched");
                                break;
                            }
                            else
                            {
                                Assert.Fail(" DB values are not displayed on Drop down");
                            }
                        }
                        else
                        {
                            Assert.Fail(" DB values and Drop down values are not matching");
                        }

                    }
                    break;


                case "Status":
                    webdrpValues = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@id='ReportViewerControl_ctl04_ctl17_ddValue']"))).Options;
                    stringdrpValues = ConvertWebElementInToString(webdrpValues);
                    stringDBValues = dbValues;
                    resultantString = compareTwoList(stringdrpValues, stringDBValues);
                    foreach (string temp in resultantString)
                    {
                        if (resultantString.Count == 1)
                        {
                            if (temp.Equals("<Select a Value>"))
                            {
                                Assert.IsTrue(true, " All values are matched");
                                break;
                            }
                            else
                            {
                                Assert.Fail(" DB values are not displayed on Drop down");
                            }
                        }
                        else
                        {
                            Assert.Fail(" DB values and Drop down values are not matching");
                        }
                    }
                    break;

                    
                case "User Name":
                    webdrpValues = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@id='ReportViewerControl_ctl04_ctl15_ddValue']"))).Options;
                    stringdrpValues = ConvertWebElementInToString(webdrpValues);
                    stringDBValues = dbValues;
                    resultantString = compareTwoList(stringdrpValues, stringDBValues);
                    foreach (string temp in resultantString)
                    {
                        if (resultantString.Count == 1)
                        {
                            if (temp.Equals("<Select a Value>"))
                            {
                                Assert.IsTrue(true, " All values are matched");
                                break;
                            }
                            else
                            {
                                Assert.Fail(" DB values are not displayed on Drop down");
                            }
                        }
                        else
                        {
                            Assert.Fail(" DB values and Drop down values are not matching");
                        }
                    }
                    break;

                    

                case "Plan ID":
                    webdrpValues = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@id='ReportViewerControl_ctl04_ctl09_ddValue']"))).Options;
                    stringdrpValues = ConvertWebElementInToString(webdrpValues);
                    stringDBValues = dbValues;
                     resultantString = compareTwoList(stringdrpValues, stringDBValues);
                    foreach (string temp in resultantString)
                    {
                        if (resultantString.Count == 1)
                        {
                            if (temp.Equals("<Select a Value>"))
                            {
                                Assert.IsTrue(true, " All values are matched");
                                break;
                            }
                            else
                            {
                                Assert.Fail(" DB values are not displayed on Drop down");
                            }
                        }
                        else
                        {
                            Assert.Fail(" DB values and Drop down values are not matching");
                        }

                    }
                    break;
                case "Plan ID1":
                    webdrpValues = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@test-id='PlanId']"))).Options;
                    stringdrpValues = ConvertWebElementInToString(webdrpValues);
                    stringDBValues = dbValues;
                    resultantString = compareTwoList(stringdrpValues, stringDBValues);
                    foreach (string temp in resultantString)
                    {
                        if (resultantString.Count == 1)
                        {
                            if (temp.Equals("All"))
                            {
                                Assert.IsTrue(true, " All values are matched");
                                break;
                            }
                            else
                            {
                                Assert.Fail(" DB values are not displayed on Drop down");
                            }
                        }
                        else
                        {
                            Assert.Fail(" DB values and Drop down values are not matching");
                        }

                    }
                    break;
                case "PBP ID":
                    webdrpValues = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@id='ReportViewerControl_ctl04_ctl11_ddValue']"))).Options;
                    stringdrpValues = ConvertWebElementInToString(webdrpValues);
                    integerDBValues = dbIntValues;
                    resultantString = compareTwoList(stringdrpValues, integerDBValues);
                    foreach (string temp in resultantString)
                    {
                        if (temp.Equals("All") || temp.Equals("Blank"))
                        {
                            Assert.IsTrue(true, " All values are matched");
                            break;
                        }
                    }
                    break;

                case "PBP ID1":
                    webdrpValues = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@test-id='Pbp']"))).Options;
                    stringdrpValues = ConvertWebElementInToString(webdrpValues);
                    stringDBValues = dbValues;
                    resultantString = compareTwoList(stringdrpValues, stringDBValues);
                    foreach (string temp in resultantString)
                    {
                        if (temp.Equals("All") || temp.Equals("Blank"))
                        {
                            Assert.IsTrue(true, " All values are matched");
                            break;
                        }
                    }
                    break;
                case "File Name":
                    webdrpValues = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@test-id='FileName']"))).Options;
                    stringdrpValues = ConvertWebElementInToString(webdrpValues);
                    stringDBValues = dbValues;
                    resultantString = compareTwoList(stringdrpValues, stringDBValues);
                    foreach (string temp in resultantString)
                    {
                        if (temp.Equals("All") || temp.Equals("Blank"))
                        {
                            Assert.IsTrue(true, " All values are matched");
                            break;
                        }
                    }
                    break;
                case "Pay Mon":
                    webdrpValues = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@id='ReportViewerControl_ctl04_ctl05_ddValue']"))).Options;
                    stringdrpValues = ConvertWebElementInToString(webdrpValues);
                    dateDBValues = dbDateValues;
                    resultantString = compareTwoList(stringdrpValues, dateDBValues);
                   if(resultantString.Count==0)
                    {
                        Assert.IsTrue(true, " Both are matched");
                    }
                    else
                    {
                        Assert.Fail(" DB values and Drop down values are not matching");
                    }
                    break;
                    
            }
        }


        [When(@"Execute Query on DB ""(.*)"" assign value to SpecFlow Variable")]
        public void WhenExecuteQueryOnDBAssignValueToSpecFlowVariable(string dbname)
        {
            tmsWait.Hard(15); // Reason for more Wait is Table field updation is taking time. please do not remove this wait
            string[] results = db.returnSQLQueryresultsWithArrayFormat(dbname);
            
            for(int i=0;i< results.Length;i++)
            {
                ScenarioContext.Current["Value"+i+""] = results[i];
            }

            
        }
        [When(@"Execute Query on DB ""(.*)"" assign Total value to SpecFlow Variable")]
        public void WhenExecuteQueryOnDBAssignTotalValueToSpecFlowVariable(string dbname)
        {
            tmsWait.Hard(15); // Reason for more Wait is Table field updation is taking time. please do not remove this wait
            string[] results = db.returnSQLQueryresultsWithArrayFormat(dbname);

            for (int i = 0; i < results.Length; i++)
            {
                ScenarioContext.Current["TValue" + i + ""] = results[i];

            }
        }

        [Then(@"Create ""(.*)"" Gherkin variable and assign Value for Discrepancy Type Summary Part C")]
        public void ThenCreateGherkinVariableAndAssignValueForDiscrepancyTypeSummaryPartC(string p0)
        {
            string temp;
            switch (p0)
            {
                case "Total PlanID":
                    temp = GlobalRef.Value0.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;

                case "Total ReasonCode":
                    temp = GlobalRef.Value1.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Total Count Under":
                    temp = GlobalRef.Value2.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Total Count Over":
                    temp = GlobalRef.Value3.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Total Total Count":
                    temp = GlobalRef.Value4.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Total Payment Under":
                    temp = GlobalRef.Value5.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Total Payment Over":
                    temp = GlobalRef.Value6.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Total Total Payment":
                    temp = GlobalRef.Value7.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
            }
        }

        [When(@"Create ""(.*)"" Gherkin variable and assign Total Value for Discrepancy Type Summary Part C")]
        public void WhenCreateGherkinVariableAndAssignTotalValueForDiscrepancyTypeSummaryPartC(string p0)
        {
            string temp;
            switch (p0)
            {
                case "Total PlanID":
                    temp = GlobalRef.TValue0.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                
                case "Total Count Under":
                    temp = GlobalRef.TValue1.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Total Count Over":
                    temp = GlobalRef.TValue2.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Total Total Count":
                    temp = GlobalRef.TValue3.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Total Payment Under":
                    temp = GlobalRef.TValue4.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Total Payment Over":
                    temp = GlobalRef.TValue5.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Total Total Payment":
                    temp = GlobalRef.TValue6.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
            }
        }


        [When(@"Create ""(.*)"" Gherkin variable and assign Value for Discrepancy Type Summary Part C")]
        public void WhenCreateGherkinVariableAndAssignValueForDiscrepancyTypeSummaryPartC(string p0)
        {
            string temp;
            switch (p0)
            {
                case "PlanID":
                    temp = GlobalRef.Value0.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;

                case "ReasonCode":
                    temp = GlobalRef.Value1.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Count Under":
                    temp = GlobalRef.Value2.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Count Over":
                    temp = GlobalRef.Value3.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Total Count":
                    temp = GlobalRef.Value4.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Payment Under":
                    temp = GlobalRef.Value5.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Payment Over":
                    temp = GlobalRef.Value6.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Total Payment":
                    temp = GlobalRef.Value7.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
            }
        }

        [When(@"Create ""(.*)"" Gherkin variable and assign Value in Data Load Detail report")]
        public void WhenCreateGherkinVariableAndAssignValueInDataLoadDetailReport(string p0)
        {
            string temp;
            switch (p0)
            {
                case "Table":
                    temp = GlobalRef.Value1.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Field":
                    temp = GlobalRef.Value2.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Exp Reason":
                    temp = GlobalRef.Value3.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Member ID":
                    temp = GlobalRef.Value4.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Claim":
                    temp = GlobalRef.Value5.ToString();
                    if (temp.Equals("-1"))
                    {
                        temp = "NA";
                    }
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Plan":
                    temp = GlobalRef.Value6.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;

            }
        }
        [When(@"Create ""(.*)"" Gherkin variable and assign Value from tbExceptionLetters table")]
        public void WhenCreateGherkinVariableAndAssignValueFromTbExceptionLettersTable(string p0)
        {
            string temp;
            switch (p0)
            {
                case "intHCCSequence":
                    temp = GlobalRef.Value0.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "PaymentYear":
                    temp = GlobalRef.Value1.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "bntMemberID":
                    temp = GlobalRef.Value2.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;

                
            }
        }

        [When(@"Create ""(.*)"" Gherkin variable and assign Value from tbExceptionLetter table")]
        public void WhenCreateGherkinVariableAndAssignValueFromTbExceptionLetterTable(string p0)
        {
            string temp;
            switch (p0)
            {
                case "bntMemberId":
                    temp = GlobalRef.Value0.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "paymentYear":
                    temp = GlobalRef.Value1.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "HCCProbability":
                    temp = GlobalRef.Value2.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Revenue":
                    temp = GlobalRef.Value3.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
               

            }
        }

        [When(@"Create ""(.*)"" Gherkin variable and assign Value from ExceptionLetter table")]
        public void WhenCreateGherkinVariableAndAssignValueFromExceptionLetterTable(string p0)
        {
            string temp;
            switch (p0)
            {
                case "SuspId":
                    temp = GlobalRef.Value0.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "txtProviderID":
                    temp = GlobalRef.Value1.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Active":
                    temp = GlobalRef.Value2.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "HCCProbability":
                    temp = GlobalRef.Value3.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Revenue":
                    temp = GlobalRef.Value4.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Priority":
                    temp = GlobalRef.Value3.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;

            }
        }

        [When(@"Create ""(.*)"" Gherkin variable and assign Value from ExceptionLetters table")]
        public void WhenCreateGherkinVariableAndAssignValueFromExceptionLettersTable(string p0)
        {
           

        string temp;
            switch (p0)
            {
                case "SuspId":
                    temp = GlobalRef.Value0.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "txtProviderID":
                    temp = GlobalRef.Value1.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Active":
                    temp = GlobalRef.Value2.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "HCCProbability":
                    temp = GlobalRef.Value3.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Revenue":
                    temp = GlobalRef.Value4.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Priority":
                    temp = GlobalRef.Value5.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;

            }
        }

        [When(@"Create ""(.*)"" Gherkin variable and assign Value from HistoryInputManagerRequests table")]
        public void WhenCreateGherkinVariableAndAssignValueFromHistoryInputManagerRequestsTable(string p0)
        {
            string temp;
            switch (p0)
            {
                case "EntityCount":
                    temp = GlobalRef.Value0.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "SuccessCount":
                    temp = GlobalRef.Value1.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "FalloutCount":
                    temp = GlobalRef.Value2.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
            }
            }

        [When(@"Create ""(.*)"" Gherkin variable and assign Value from table")]
        public void WhenCreateGherkinVariableAndAssignValueFromTable(string p0)
        {

            string temp;
            switch (p0)
            {
                case "IsValid":
                    temp = GlobalRef.Value0.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Count":
                    temp = GlobalRef.Value1.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Totalcount":
                    temp = GlobalRef.Value0.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                  
            }
        }

        [When(@"Create ""(.*)"" Gherkin variable and assign Value from tbplan_pbp table")]
        public void WhenCreateGherkinVariableAndAssignValueFromTbplan_PbpTable(string p0)
        {
            
        string temp;
            switch (p0.ToLower())
            {
                case "planid":
                    temp = GlobalRef.Value0.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "pbpid":
                    temp = GlobalRef.Value1.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "pbp":
                    temp = GlobalRef.Value1.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;

            }
        }

        [When(@"Create ""(.*)"" Gherkin variable and assign Value from tbClaimOnHold table")]
        public void WhenCreateGherkinVariableAndAssignValueFromTbClaimOnHoldTable(string p0)
        {
            string temp;
            switch (p0)
            {
                case "isblocked":
                    temp = GlobalRef.Value0.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "pirstatus":
                    temp = GlobalRef.Value1.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "isdeleted":
                    temp = GlobalRef.Value2.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
            }
            }

        [When(@"Create ""(.*)"" Gherkin variable and assign Value from tbPlan table")]
        public void WhenCreateGherkinVariableAndAssignValueFromTbPlanTable(string p0)
        {
            string temp;
            switch (p0)
            {
                case "PlanID":
                    temp = GlobalRef.Value0.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "PBP":
                    temp = GlobalRef.Value1.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
            }
        }
        [When(@"Create ""(.*)"" Gherkin variable and assign Value from EafFalloutLevel_Audit table")]
        public void WhenCreateGherkinVariableAndAssignValueFromEafFalloutLevel_AuditTable(string p0)
        {
            string temp;
            switch (p0)
            {
                case "transactioncode":
                    temp = GlobalRef.Value0.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "OriginalValue":
                    temp = GlobalRef.Value1.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "NewValue":
                    temp = GlobalRef.Value2.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
            }
        }

        [When(@"Create ""(.*)"" Gherkin variable and assign Value from tbTransactions table")]
        public void WhenCreateGherkinVariableAndAssignValueFromTbTransactionsTable(string p0)
        {
            string temp;
            switch (p0)
            {
                case "Incomplete":
                    temp = GlobalRef.Value0.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "missingitem":
                    temp = GlobalRef.Value1.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "ErrMessage":
                    temp = GlobalRef.Value2.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
            }
        }
        [When(@"Create ""(.*)"" Gherkin variable and assign Value from  tablee")]
        public void WhenCreateGherkinVariableAndAssignValueFromTablee(string p0)
        {
            string temp;
            switch (p0)
            {
                case "DBRXID":
                    temp = ScenarioContext.Current["Value0"].ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "DBSubmitterID":
                    temp = ScenarioContext.Current["Value1"].ToString(); 
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "DBFileName":
                    temp = ScenarioContext.Current["Value2"].ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "DBFileloadDate":
                    temp = ScenarioContext.Current["Value3"].ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "DBStatusDescription":
                    temp = ScenarioContext.Current["Value4"].ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
            }

            }

        [When(@"Create ""(.*)"" Gherkin variable and assign Value from tbDiags table")]
        public void WhenCreateGherkinVariableAndAssignValueFromTbDiagsTable(string p0)
        {
            string temp;
            switch (p0)
            {
                case "SourceId":
                    temp = GlobalRef.Value0.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "DiagSource":
                    temp = GlobalRef.Value1.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "SVCType":
                    temp = GlobalRef.Value2.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "tbDiagsId":
                    temp = GlobalRef.Value3.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "txtICd9Code":
                    temp = GlobalRef.Value4.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "intKnownStatus":
                    temp = GlobalRef.Value5.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "intSuspectStatus":
                    temp = GlobalRef.Value6.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "SuspId":
                    temp = GlobalRef.Value7.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;

            }

        }


        // Needs to be modified as per your need
        [When(@"Create ""(.*)"" Gherkin variable and assign Value")]
        public void WhenCreateGherkinVariableAndAssignValue(string p0)
        {
            string temp;
            switch (p0)
            {
                case "ReasonCodeValue":
                     temp = GlobalRef.Value1.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "MBI":
                    temp = GlobalRef.Value2.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "PlanIDValue":
                    temp = GlobalRef.Value3.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "StatusValue":
                    temp = GlobalRef.Value4.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "Age":
                    temp = GlobalRef.Value5.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "PayMonValue":
                    temp = GlobalRef.Value6.ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;
                case "State":
                    temp = ScenarioContext.Current["Value"].ToString();
                    fw.setVariable(p0, temp.Trim());
                    break;

            }
            
        }

        [When(@"Discrepancy Type Summary Part C Reports page ""(.*)"" is set to ""(.*)""")]
        public void WhenDiscrepancyTypeSummaryPartCReportsPageIsSetTo(string p0, string p1)
        {
            string reasoncode = tmsCommon.GenerateData(p0);
            string reasoncodeValue = tmsCommon.GenerateData(p1);
            tmsWait.Hard(3);
             if (reasoncode.Equals("From Payment Month"))
            {
                new SelectElement(Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl03_ddValue"))).SelectByValue(reasoncodeValue);
            }
            if (reasoncode.Equals("To Payment Month"))
            {
                new SelectElement(Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl05_ddValue"))).SelectByValue(reasoncodeValue);
            }
        }


        [When(@"Reports page ""(.*)"" is set to ""(.*)""")]
        public void WhenReportsPageIsSetTo(string p0, string p1)
        {
            string reasoncode = tmsCommon.GenerateData(p0);
            string reasoncodeValue = tmsCommon.GenerateData(p1);

            if (reasoncode.Equals("Discrepancy Type"))
            {
                if (reasoncodeValue.Equals("DSUB_D"))
                {
                    reasoncodeValue = "Part D Direct Subsidy Mismatch";
                }
                else if (reasoncodeValue.Equals("DOB_D"))
                {
                    reasoncodeValue = "Part D Date of Birth Mismatch";
                }
                else if (reasoncodeValue.Equals("CGDA_D"))
                {
                    reasoncodeValue = "Part D Coverage Gap Discount Amount Mismatch";
                }
                
                else
                {
                    Assert.Fail(" Please provide correct Discrepancy Type");
                }

                new SelectElement(Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl03_ddValue"))).SelectByValue(reasoncodeValue);
            }
            else if(reasoncode.Equals("From Payment Month"))
            {
                new SelectElement(Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl05_ddValue"))).SelectByValue(reasoncodeValue);
            }

            else if (reasoncode.Equals("To Payment Month"))
            {
                //
            }

            else if (reasoncode.Equals("Plan ID"))
            {
                tmsWait.Hard(3);
                new SelectElement(Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl09_ddValue"))).SelectByValue(reasoncodeValue);
            }
            else if (reasoncode.Equals("Discrepancy Status"))
            {
                tmsWait.Hard(3);
                new SelectElement(Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl17_ddValue"))).SelectByValue(reasoncodeValue);
                
            }
            else if (reasoncode.Equals("Age"))
            {
                tmsWait.Hard(3);
                if ((Convert.ToInt32(reasoncodeValue)<=12) && (Convert.ToInt32(reasoncodeValue) >= 10))
                {
                    reasoncodeValue = "10 - 12 Months";
                }
                else if ((Convert.ToInt32(reasoncodeValue) <= 6) && (Convert.ToInt32(reasoncodeValue) >= 4))
                {
                    reasoncodeValue = "4 - 6 Months";
                }
                else if ((Convert.ToInt32(reasoncodeValue) <= 3) && (Convert.ToInt32(reasoncodeValue) >= 1))
                {
                    reasoncodeValue = "1 - 3 Months";
                }
                else if ((Convert.ToInt32(reasoncodeValue) <= 9) && (Convert.ToInt32(reasoncodeValue) >= 7))
                {
                    reasoncodeValue = "7 - 9 Months";
                }
                else if ((Convert.ToInt32(reasoncodeValue) <= 24) && (Convert.ToInt32(reasoncodeValue) >= 13))
                {
                    reasoncodeValue = "13 - 24 Months";
                }
                else if ((Convert.ToInt32(reasoncodeValue) >= 25))
                {
                    reasoncodeValue = "25 Months +";
                }
                else
                {
                    Assert.Fail(" Please provide correct Discrepancy Type");
                }
                new SelectElement(Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl19_ddValue"))).SelectByValue(reasoncodeValue);
            }

        }


        public string singleColumnQueryExecutionSelectRecordBasedOnIndex(string SqlString, string DB, int recordIndex)
        {
            ArrayList actList = new ArrayList();
            fsRSMLogin DBquery = new fsRSMLogin();
            actList = DBquery.ExecuteSQLQueryUsingSQL2017(SqlString, DB);
            string output = actList[recordIndex].ToString();
            return output;
        }

        [When(@"Manage Suspect page Mark onHold first paotential diagnosis code with on hold reason ""(.*)""")]
        public void WhenManageSuspectPageMarkOnHoldFirstPaotentialDiagnosisCodeWithOnHoldReason(string OnHoldreason)
        {
            IWebElement Potentialdiagcode = Browser.Wd.FindElement(By.XPath(".//*[@id='potentialDiagnosesGrid']//table/tbody"));
            IReadOnlyCollection<IWebElement> allrows = Potentialdiagcode.FindElements(By.TagName("tr"));
            foreach (var row in allrows)
            {

                int FirstPdiagcode = Int32.Parse(row.FindElement(By.XPath("td[1]/span")).Text);
                GlobalRef.PotentialDiagCode = FirstPdiagcode.ToString();

                IWebElement clickEditFirstdiagcode = row.FindElement(By.XPath("td[11]/a"));
                fw.ExecuteJavascript(clickEditFirstdiagcode);
                IWebElement AddcheckboxForFirstdaig = row.FindElement(By.XPath("td[5]/input"));
                fw.ExecuteJavascript(AddcheckboxForFirstdaig);
                IWebElement EncounterDateForFirstdaig = row.FindElement(By.XPath("td[6]//input"));
                EncounterDateForFirstdaig.SendKeys(RAM.ManageSuspectPage.DateofService.Text);
                IWebElement riskAssCode = row.FindElement(By.XPath("td[7]/input"));
                riskAssCode.SendKeys("A");
                IWebElement OnHoldcheckboxForFirstdaig = row.FindElement(By.XPath("td[9]/input"));
                fw.ExecuteJavascript(OnHoldcheckboxForFirstdaig);
                IWebElement OnHoldDropdownForFirstdaig = row.FindElement(By.XPath("td[10]/span"));
                fw.ExecuteJavascript(OnHoldDropdownForFirstdaig);
                tmsWait.Hard(1);
                IWebElement OnHoldDropdownListForFirstdaig = Browser.Wd.FindElement(By.XPath(".//li[contains(text(), '" + OnHoldreason + "')]"));
                fw.ExecuteJavascript(OnHoldDropdownListForFirstdaig);
                IWebElement SaveactionForFirstdiagcode = row.FindElement(By.XPath("td[11]//span[@class='k-update fa fa-floppy-o']"));
                fw.ExecuteJavascript(SaveactionForFirstdiagcode);
                break;

            }
        }

        [When(@"Manage suspect page get the additional diagnosis code")]
        public void WhenManageSuspectPageGetTheAdditionalDiagnosisCode()
        {
            tmsWait.Hard(2);
            GlobalRef.adddiagcode = Browser.Wd.FindElement(By.XPath(".//*[@id='additionalDiagnosesGrid']//span[@ng-bind='dataItem.code']")).Text;
            tmsWait.Hard(1);
        }


        [When(@"Manage Suspect page AddDiagnosis button is clicked")]
        public void WhenManageSuspectPageAddDiagnosisButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.ManageSuspectPage.AddDiagnosesButton);
            tmsWait.Hard(1);
        }


        [Then(@"Verify warning message ""(.*)""")]
        public void ThenVerifyWarningMessage(string actualwarning)
        {
            tmsWait.Hard(3);
            string expectedwarning = RAM.ManageSuspectPage.WarningdialogForOnHold.Text;
            Assert.AreEqual(actualwarning, expectedwarning, "Warning message is not correct");
            tmsWait.Hard(2);
        }




        [When(@"Manage Suspect page warningdialog button is clicked")]
        public void WhenManageSuspectPageWarningdialogButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.ManageSuspectPage.WarningdialogOK);
            tmsWait.Hard(3);

        }

        [When(@"Verify message ""(.*)"" on manage suspect page")]
        [Then(@"Verify message ""(.*)"" on manage suspect page")]
        public void ThenVerifyMessageOnManageSuspectPage(string OnHoldPIRMsg)
        {
            string actualMsg = RAM.ManageSuspectPage.OnHoldPIRConfirmMsg.Text;
            Assert.AreEqual(OnHoldPIRMsg, actualMsg, "PIR confirmation message is not displayed properly");
            tmsWait.Hard(2);
        }

        [When(@"Verify PIRConfirmation message ""(.*)"" on manage suspect page")]
        [Then(@"Verify PIRConfirmation message ""(.*)"" on manage suspect page")]
        public void ThenVerifyPIRConfirmationMessageOnManageSuspectPage(string pirmsg)
        {
            tmsWait.Hard(13);
            string actualMsg = RAM.ManageSuspectPage.PIRmsg.Text;
            Assert.IsTrue(actualMsg.Contains(pirmsg), "PIR confirmation message is not displayed properly");
            tmsWait.Hard(1);
        }


        [When(@"Manage Suspect page Back to record link is clicked")]
        public void WhenManageSuspectPageBackToRecordLinkIsClicked()
        {
            fw.ExecuteJavascript(RAM.ManageSuspectPage.BackToRecord);
            tmsWait.Hard(8);
        }

        [When(@"ViewOnHold diagnosis code page MembnerId is set to same as memberid of submitted PIR")]
        public void WhenViewOnHoldDiagnosisCodePageMembnerIdIsSetToSameAsMemberidOfSubmittedPIR()
        {
            string MemId = Convert.ToString(GlobalRef.MemberId);
            RAM.ViewOnHoldDiagnosisCode.MemberIdTxt.SendKeys(MemId);
        }

        [When(@"ViewOnHold diagnosis code page MembnerId is set to ""(.*)""")]
        public void WhenViewOnHoldDiagnosisCodePageMembnerIdIsSetTo(string p0)
        {
            RAM.ViewOnHoldDiagnosisCode.MemberIdTxt.SendKeys(p0);
        }

        [When(@"ViewOnHold diagnosis code page ChartId is set to ""(.*)""")]
        public void WhenViewOnHoldDiagnosisCodePageChartIdIsSetTo(string p0)
        {
            string chart = tmsCommon.GenerateData(p0);

            RAM.ViewOnHoldDiagnosisCode.ChartIdTxt.SendKeys(chart);
        }

        [When(@"ViewOnHold diagnosis code page search button is clicked")]
        public void WhenViewOnHoldDiagnosisCodePageSearchButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.ViewOnHoldDiagnosisCode.SearchButton);
            tmsWait.Hard(2);
        }

        [When(@"ViewOnHold diagnosis code page first row edit button is clicked")]
        public void WhenViewOnHoldDiagnosisCodePageFirstRowEditButtonIsClicked()
        {
            IWebElement editicon = Browser.Wd.FindElement(By.XPath("(//*[@test-id='viewOnHoldDiagnosis-grid-resultsGrid']//parent::td//following-sibling::td/a/span[@class='cursorLink fas fa-edit'])[1]"));

            fw.ExecuteJavascript(editicon);
            tmsWait.Hard(2);
        }

        [Then(@"Verify ViewOnHold diagnosis code page record for DiagCode ""(.*)"" is not present")]
        public void ThenVerifyViewOnHoldDiagnosisCodePageRecordForDiagCodeIsNotPresent(int p0)
        {
            Boolean ispresent = false;
            IReadOnlyCollection<IWebElement> allrow = RAM.ViewOnHoldDiagnosisCode.ViewonHolddiagGrid.FindElements(By.TagName("tr"));
            foreach(var row in allrow)
            {
                string diagcode = row.FindElement(By.XPath("//td[2]")).Text;
                if (diagcode == p0.ToString())
                {
                    ispresent = true;
                    break;
                }
            }
            Assert.IsFalse(ispresent);
        }

        //[Then(@"Verify diagnosis codes are onhold getting displayed with ""(.*)"" status on viewOnHold diagnosis code")]
        //public void ThenVerifyDiagnosisCodesAreOnholdGettingDisplayedWithStatusOnViewOnHoldDiagnosisCode(string pirstatus)
        //{
        //    int pdiagcode = Convert.ToInt32(GlobalRef.PotentialDiagCode);
        //    //int adddiagcode = (Convert.ToInt32(GlobalRef.adddiagcode))
        //    // IWebElement ViewonHolddiagGrid = Browser.Wd.FindElement(By.XPath(".//*[@id='onHoldDiagnosisGrid']/table/tbody"));
        //    IReadOnlyCollection<IWebElement> allrows = RAM.ViewOnHoldDiagnosisCode.ViewonHolddiagGrid.FindElements(By.TagName("tr"));
        //    Boolean IsPresent = false;
        //    foreach (var row in allrows)
        //    {

        //        int OnHolddiagcode1 = Int32.Parse(row.FindElement(By.XPath("td[2]/span")).Text);
        //        string actualpirstatus = row.FindElement(By.XPath("td[10]")).Text;
        //        if ((OnHolddiagcode1 == pdiagcode || OnHolddiagcode1 == adddiagcode) && actualpirstatus == pirstatus)
        //        {
        //            IsPresent = true;
        //        }
        //        Assert.IsTrue(IsPresent);

        //    }
        //}

        [Then(@"Verify additional diagnosis codes are onhold getting displayed with ""(.*)"" status on viewOnHold diagnosis code")]
        public void ThenVerifyAdditionalDiagnosisCodesAreOnholdGettingDisplayedWithStatusOnViewOnHoldDiagnosisCode(string pirstatus)
        {
            int adddiagcode = (Convert.ToInt32(GlobalRef.adddiagcode));
            IReadOnlyCollection<IWebElement> allrows = RAM.ViewOnHoldDiagnosisCode.ViewonHolddiagGrid.FindElements(By.TagName("tr"));
            Boolean IsPresent = false;
            foreach (var row in allrows)
            {

                int OnHolddiagcode1 = Int32.Parse(row.FindElement(By.XPath("td[2]/span")).Text);
                string actualpirstatus = row.FindElement(By.XPath("td[10]")).Text;
                if ((OnHolddiagcode1 == adddiagcode) && (actualpirstatus == pirstatus))
                {
                    IsPresent = true;
                }
                Assert.IsTrue(IsPresent);

            }

        }


        [Then(@"Verify On Hold and Diagnosis Review page displayed On Hold Reason as ""(.*)"" Status as ""(.*)"" PIR as ""(.*)""")]
        public void ThenVerifyOnHoldAndDiagnosisReviewPageDisplayedOnHoldReasonAsStatusAsPIRAs(string p0, string p1, string p2)
        {
            tmsWait.Hard(2);
            string onholdreason = tmsCommon.GenerateData(p0);
            string status = tmsCommon.GenerateData(p1);
            string PIR = tmsCommon.GenerateData(p2);

            By loc = By.XPath("//kendo-grid[@test-id='viewOnHoldDiagnosis-grid-resultsGrid']//tr//td[contains(.,'" + PIR + "')]//following-sibling::td//following-sibling::td//following-sibling::td[contains(.,'" + onholdreason + "')]//following-sibling::td[contains(.,'" + status + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);


        }

        [Then(@"Verify On Hold and Diagnosis Review page displayed PIR as ""(.*)"" PIR Status as ""(.*)""")]
        public void ThenVerifyOnHoldAndDiagnosisReviewPageDisplayedPIRAsPIRStatusAs(string p0, string p1)
        {
            tmsWait.Hard(2);
            string PIR = tmsCommon.GenerateData(p0);
            string PIRstatus = tmsCommon.GenerateData(p1);

            By loc = By.XPath("//kendo-grid[@test-id='viewOnHoldDiagnosis-grid-resultsGrid']//tr//td[contains(.,'" + PIR + "')]//following-sibling::td[contains(.,'"+ PIRstatus + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        } 


        [Then(@"Verify potential diag code is onhold getting displayed with ""(.*)"" status on viewOnHold diagnosis code")]
        public void ThenVerifyPotentialDiagCodeIsOnholdGettingDisplayedWithStatusOnViewOnHoldDiagnosisCode(string pirstatus)
        {
            int pdiagcode = Convert.ToInt32(GlobalRef.PotentialDiagCode);
            IReadOnlyCollection<IWebElement> allrows = RAM.ViewOnHoldDiagnosisCode.ViewonHolddiagGrid.FindElements(By.TagName("tr"));
            Boolean IsPresent = false;
            foreach (var row in allrows)
            {

                int OnHolddiagcode1 = Int32.Parse(row.FindElement(By.XPath("td[2]/span")).Text);
                string actualpirstatus = row.FindElement(By.XPath("td[10]")).Text;
                if ((OnHolddiagcode1 == pdiagcode) && (actualpirstatus == pirstatus))
                {
                    IsPresent = true;
                }
                Assert.IsTrue(IsPresent);

            }

        }


        [When(@"Manage Suspect page Mark confirmed first paotential diagnosis code")]
        public void WhenManageSuspectPageMarkConfirmedFirstPaotentialDiagnosisCode()
        {
            //IWebElement Potentialdiagcode = Browser.Wd.FindElement(By.XPath(".//*[@id='potentialDiagnosesGrid']//table/tbody"));
            IReadOnlyCollection<IWebElement> allrows = RAM.ManageSuspectPage.PotentialdiagcodeGrid.FindElements(By.TagName("tr"));
            foreach (var row in allrows)
            {

                int FirstPdiagcode = Int32.Parse(row.FindElement(By.XPath("td[1]/span")).Text);
                GlobalRef.PotentialDiagCode = FirstPdiagcode.ToString();

                IWebElement clickEditFirstdiagcode = row.FindElement(By.XPath("td[11]/a"));
                fw.ExecuteJavascript(clickEditFirstdiagcode);
                IWebElement AddcheckboxForFirstdaig = row.FindElement(By.XPath("td[5]/input"));
                fw.ExecuteJavascript(AddcheckboxForFirstdaig);
                IWebElement EncounterDateForFirstdaig = row.FindElement(By.XPath("td[6]//input"));
                EncounterDateForFirstdaig.SendKeys(RAM.ManageSuspectPage.DateofService.Text);
                tmsWait.Hard(2);
                IWebElement riskAssCode = row.FindElement(By.XPath("td[7]//input"));
                riskAssCode.SendKeys("A");
                tmsWait.Hard(3);
                IWebElement claimnumber = row.FindElement(By.XPath("td[8]//input"));
                claimnumber.SendKeys("56966");
            }
        }

        [When(@"ViewOnHold diagnosis code page update ""(.*)"" to ""(.*)""")]
        public void WhenViewOnHoldDiagnosisCodePageUpdateTo(string updatefield, string setvalue)
        {
            int adddiagcode = Convert.ToInt32(GlobalRef.adddiagcode);
            //IWebElement ViewonHolddiagGrid = Browser.Wd.FindElement(By.XPath(".//*[@id='onHoldDiagnosisGrid']/table/tbody"));
            IReadOnlyCollection<IWebElement> allrows = RAM.ViewOnHoldDiagnosisCode.ViewonHolddiagGrid.FindElements(By.TagName("tr"));
            //Boolean IsPresent = false;
            foreach (var row in allrows)
            {
                IWebElement adiagcode = row.FindElement(By.XPath("td[2]//span"));
                IWebElement editicon = row.FindElement(By.XPath("td[13]//a"));
                int adcode = Convert.ToInt32(adiagcode.Text);
                if (adcode == adddiagcode)
                {
                    switch (updatefield.ToLower())
                    {
                        case "code":
                            fw.ExecuteJavascript(editicon);
                            IWebElement diagcode = row.FindElement(By.XPath("td[2]//input"));
                            diagcode.SendKeys(setvalue);
                            break;
                        case "providerid":
                            fw.ExecuteJavascript(editicon);
                            IWebElement prid = row.FindElement(By.XPath("td[3]//input"));
                            prid.SendKeys(setvalue);
                            break;
                        case "encounterdate":
                            fw.ExecuteJavascript(editicon);
                            IWebElement edate = row.FindElement(By.XPath("td[4]//input"));
                            edate.SendKeys(setvalue);
                            break;
                        case "riskcode":
                            fw.ExecuteJavascript(editicon);
                            IWebElement rcodedropdown = row.FindElement(By.XPath("td[5]//span"));
                            fw.ExecuteJavascript(rcodedropdown);
                            IWebElement rcodedroplist = Browser.Wd.FindElement(By.XPath(".//li[contains(text(),'B')]"));
                            fw.ExecuteJavascript(rcodedroplist);
                            break;
                        case "claimnumber":
                            fw.ExecuteJavascript(editicon);
                            IWebElement cnumber = row.FindElement(By.XPath("td[6]//input"));
                            cnumber.SendKeys(setvalue);
                            break;
                        case "coderid":
                            fw.ExecuteJavascript(editicon);
                            IWebElement coderdropdown = row.FindElement(By.XPath("td[8]//span"));
                            fw.ExecuteJavascript(coderdropdown);
                            IWebElement coderdroplist = Browser.Wd.FindElement(By.XPath(".//li[contains(text(),'None')]"));
                            fw.ExecuteJavascript(coderdroplist);
                            break;
                        case "onholdreason":
                            fw.ExecuteJavascript(editicon);
                            IWebElement onholdreasondropdown = row.FindElement(By.XPath("td[12]//span"));
                            fw.ExecuteJavascript(onholdreasondropdown);
                            IWebElement onholdreasondroplist = Browser.Wd.FindElement(By.XPath(".//li[contains(text(),'Other')]"));
                            fw.ExecuteJavascript(onholdreasondroplist);
                            break;
                    }
                    IWebElement saveaction = row.FindElement(By.XPath("td//a[@class='k-button k-button-icontext k-primary k-grid-update']"));
                    fw.ExecuteJavascript(saveaction);
                    break;
                }
            }

        }

        [When(@"ViewOnHold diagnosis code page checkbox is checked for diagnosis code ""(.*)""")]
        public void WhenViewOnHoldDiagnosisCodePageCheckboxIsCheckedForDiagnosisCode(int onholdcode)
        {
            IReadOnlyCollection<IWebElement> allrows = RAM.ViewOnHoldDiagnosisCode.ViewonHolddiagGrid.FindElements(By.TagName("tr"));
            foreach (var row in allrows)
            {
                int diagcode = Convert.ToInt32(row.FindElement(By.XPath("td[2]//span")).Text);

                if (diagcode.Equals(onholdcode))
                {
                    tmsWait.Hard(2);
                    fw.ExecuteJavascript(row.FindElement(By.XPath("//input[@type='checkbox']")));
                    break;
                }
            }
        }

        [When(@"ViewOnHold diagnosis code page Approve button is clicked")]
        public void WhenViewOnHoldDiagnosisCodePageApproveButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.ViewOnHoldDiagnosisCode.ApproveButton);
            tmsWait.Hard(2);
            fw.ExecuteJavascript(RAM.ViewOnHoldDiagnosisCode.ApproveConfdialogYes);
        }

        [Then(@"verify Enter New Diagnosis Data Member ID is set same as MemberId of worked PIR")]
        [When(@"verify Enter New Diagnosis Data Member ID is set same as MemberId of worked PIR")]
        public void WhenVerifyEnterNewDiagnosisDataMemberIDIsSetSameAsMemberIdForWorkedPIR()
        {
            string MemId = Convert.ToString(GlobalRef.MemberId);
            Suspects.EnterNewDiagnosisCode.MemberIDLookuptxtbox.SendKeys(MemId);

        }

        [Then(@"Verify Enter New Diagnosis data ""(.*)"" is with onhold ""(.*)""")]
        public void ThenVerifyEnterNewDiagnosisDataIsWithOnhold(string p0, string p1)
        {
            string diagcode = tmsCommon.GenerateData(p0);
            string typeofAction = tmsCommon.GenerateData(p1);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='searchDiag-grid-member']//div//tr//td[contains(.,'"+ diagcode + "')]//following-sibling::td//input[@class='form-check-input k-checkbox']"));
            ReUsableFunctions.CheckBoxStatus(ele, typeofAction);
        }


        [Then(@"Verify Enter New Diagnosis data ""(.*)"" is available with onhold status ""(.*)""")]
        public void ThenVerifyEnterNewDiagnosisDataIsAvailableWithOnholdStatus(int diagcode, string status)
        {

            IReadOnlyCollection<IWebElement> allrows = Suspects.EnterNewDiagnosisCode.DiagnosisCodeGrid.FindElements(By.TagName("tr"));
            Boolean Ispresent = false;
            foreach (var row in allrows)
            {
                int mycode = Convert.ToInt32(row.FindElement(By.XPath("td[1]//span")).Text);
                string mystatus = row.FindElement(By.XPath("td[8]")).Text;
                if (diagcode == mycode && mystatus.Equals(status))
                {
                    Ispresent = true;
                    break;
                }

            }
            Assert.IsTrue(Ispresent);
        }

        [When(@"Manage Suspect page mark uncheck onhold check box for diagnosis code")]
        public void WhenManageSuspecPageMarkUncheckOnholdCheckBoxForDiagnosisCode()
        {
            IReadOnlyCollection<IWebElement> allrows = RAM.ManageSuspectPage.PotentialdiagcodeGrid.FindElements(By.TagName("tr"));
            foreach (var row in allrows)
            {

                int FirstPdiagcode = Int32.Parse(row.FindElement(By.XPath("td[1]/span")).Text);
                GlobalRef.PotentialDiagCode = FirstPdiagcode.ToString();
                IWebElement clickEditFirstdiagcode = row.FindElement(By.XPath("td[11]/a"));
                fw.ExecuteJavascript(clickEditFirstdiagcode);
                IWebElement OnHoldcheckboxForFirstdaig = row.FindElement(By.XPath("td[9]/input"));
                fw.ExecuteJavascript(OnHoldcheckboxForFirstdaig);
                tmsWait.Hard(2);
                IWebElement Saveaction = row.FindElement(By.XPath("//a[@class='k-button k-button-icontext k-primary k-grid-update']"));
                fw.ExecuteJavascript(Saveaction);
                break;
            }

        }

        [Then(@"Verify onhold diagnosis code is not getting displayed on viewOnHold diagnosis code grid")]
        public void ThenVerifyOnholdDiagnosisCodeIsNotGettingDisplayedOnViewOnHoldDiagnosisCodeGrid()
        {
            IWebElement noitemdisplay = Browser.Wd.FindElement(By.XPath(".//span[contains(text(),'No items to display')]"));
            Boolean isexist = false;
            if (noitemdisplay.Displayed)
            {
                isexist = true;
            }
            Assert.IsTrue(isexist);
        }

        [When(@"Enter New Diagnosis Data search for MemberId from lookup")]
        public void WhenEnterNewDiagnosisDataSearchForMemberIdFromLookup()
        {
            fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.MemberIDLookup);
            tmsWait.Hard(1);
            IWebElement memberId = Browser.Wd.FindElement(By.CssSelector("[test-id='searchMember-txt-MemberID']"));
            memberId.SendKeys("MEM");
            fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.LookupSearchBtn);
            tmsWait.Hard(3);
            IReadOnlyCollection<IWebElement> allrows = Suspects.EnterNewDiagnosisCode.MemberLookupGrid.FindElements(By.TagName("tr"));
            string memId = string.Empty;
            int i = 0;
            foreach (var row in allrows)
            {

                if (i > 2)
                {
                    fw.ExecuteJavascript(row.FindElement(By.XPath("td[2]")));
                    tmsWait.Hard(1);
                    memId = row.FindElement(By.XPath("td[2]")).Text;
                    break;
                }
                i++;
            }

            GlobalRef.MemberId = memId;
            fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.addButton);
            tmsWait.Hard(1);
            

        }

        [When(@"Enter New Diagnosis Data page OnHold check box is checked")]
        public void WhenEnterNewDiagnosisDataPageOnHoldCheckBoxIsChecked()
        {
            fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.OnHoldCheckBox);
        }

        [When(@"Enter New Diagnosis page OnholdReason ""(.*)"" is selected")]
        public void WhenEnterNewDiagnosisPageOnholdReasonIsSelected(string onholdreason)
        {

            //SelectElement onHoldreason = new SelectElement(Suspects.EnterNewDiagnosisCode.OnHoldReason);
            //onHoldreason.SelectByText(onholdreason);
            // fw.KendoSelectByValue(Browser.Wd, Suspects.EnterNewDiagnosisCode.OnHoldReason, onholdreason);
            IWebElement xpath = Browser.Wd.FindElement(By.XPath("//li[contains(.,'"+ onholdreason + "')]"));
            fw.ExecuteJavascript(xpath);
            tmsWait.Hard(2);
        
        }

        [When(@"ViewOnHold diagnosis code page MembnerId is set to same as memberid of enter new diagnosis data")]
        public void WhenViewOnHoldDiagnosisCodePageMembnerIdIsSetToSameAsMemberidOfEnterNewDiagnosisData()
        {
            string onholdmemid = (GlobalRef.MemberId).ToString();
            RAM.ViewOnHoldDiagnosisCode.MemberIdTxt.SendKeys(onholdmemid);
        }

        [Then(@"Verify enter new diagnosis data onhold code ""(.*)"" is getting displayed with ""(.*)"" status on viewOnHold diagnosis codee")]
        public void ThenVerifyEnterNewDiagnosisDataOnholdCodeIsGettingDisplayedWithStatusOnViewOnHoldDiagnosisCodee(int p0, string status)
        {
            string onholdcode = tmsCommon.GenerateData(p0.ToString());
            IReadOnlyCollection<IWebElement> allrows = RAM.ViewOnHoldDiagnosisCode.ViewonHolddiagGrid.FindElements(By.TagName("tr"));
            Boolean IsPresent = false;
            foreach (var row in allrows)
            {

                string OnHolddiagcode1 = (row.FindElement(By.XPath("(//td[2])[1]")).Text);
                string actualpirstatus = row.FindElement(By.XPath("(//td[14])[1]")).Text;
                if (actualpirstatus == "N/A")
                    actualpirstatus = "NA";

                if ((OnHolddiagcode1 == onholdcode.ToString()) || (actualpirstatus == status))
                {
                    IsPresent = true;
                }
                Assert.IsTrue(IsPresent);

            }
        }

        [Then(@"Verify enter new diagnosis data onhold code ""(.*)"" is getting displayed with ""(.*)"" status on viewOnHold diagnosis code")]
        public void ThenVerifyEnterNewDiagnosisDataOnholdCodeIsGettingDisplayedWithStatusOnViewOnHoldDiagnosisCode(int p0, string status)
        {
            tmsWait.Hard(2);
            string onholdcode = tmsCommon.GenerateData(p0.ToString());
            IReadOnlyCollection<IWebElement> allrows = RAM.ViewOnHoldDiagnosisCode.ViewonHolddiagGrid.FindElements(By.TagName("tr"));
            Boolean IsPresent = false;
            foreach (var row in allrows)
            {

                string OnHolddiagcode1 = (row.FindElement(By.XPath("//td[2]/span")).Text);
                tmsWait.Hard(2);
                string actualpirstatus = row.FindElement(By.XPath("//td[12]")).Text;
                tmsWait.Hard(2);
                if (actualpirstatus == "N/A")
                    actualpirstatus = "NA";

                if ((OnHolddiagcode1 == onholdcode.ToString()) || (actualpirstatus == status))
                {
                    IsPresent = true;
                }
                Assert.IsTrue(IsPresent);

            }
        }


        [Then(@"Verify OnHold Code ""(.*)"" with status ""(.*)""")]
        public void ThenVerifyOnHoldCodeWithStatus(string p0, string status)
        {
            string onholdcode = tmsCommon.GenerateData(p0.ToString());
            IReadOnlyCollection<IWebElement> allrows = RAM.ViewOnHoldDiagnosisCode.ViewonHolddiagGrid.FindElements(By.TagName("tr"));
            Boolean IsPresent = false;
            foreach (var row in allrows)
            {

                string OnHolddiagcode1 = (row.FindElement(By.XPath("//td[2]")).Text);
                string actualpirstatus = row.FindElement(By.XPath("//td[14]")).Text;
                if (actualpirstatus == "N/A")
                    actualpirstatus = "NA";

                if ((OnHolddiagcode1 == onholdcode.ToString()) || (actualpirstatus == status))
                {
                    IsPresent = true;
                }
                Assert.IsTrue(IsPresent);

            }
        }
    


        [Then(@"Verify Manage suspect page Add diagnosis button is enabled")]
        public void ThenVerifyManageSuspectPageAddDiagnosisButtonIsEnabled()
        {
            Assert.IsTrue(RAM.ManageSuspectPage.AddDiagnosesButton.Enabled,"PIR is not on hold or submitted as add diagnosis button on manage suspect page is disabled");
            
        }

        [Then(@"Verify Manage suspect page Add diagnosis button is disabled")]
        public void ThenVerifyManageSuspectPageAddDiagnosisButtonIsDisabled()
        {
            Assert.IsFalse(RAM.ManageSuspectPage.AddDiagnosesButton.Enabled);
       
        }

      
        [When(@"Delete submitted diag code page ""(.*)"" is selected")]
        public void WhenDeleteSubmittedDiagCodePageIsSelected(string p0)
        {
                    fw.ExecuteJavascript(RAM.DeleteSubmittedDiagCodes.MemberIdLookupBtn);
                    tmsWait.Hard(1);
                    IWebElement lookupoption = Browser.Wd.FindElement(By.XPath("//div[@class='input-group-append pl-2']//i"));
                    fw.ExecuteJavascript(lookupoption);
                    tmsWait.Hard(1);
                    string memid = (GlobalRef.MemberId).ToString();
           
                    RAM.DeleteSubmittedDiagCodes.MemberIDLookupText.SendKeys(memid);
                    tmsWait.Hard(2);
                    RAM.DeleteSubmittedDiagCodes.MemberIDLookupText.SendKeys(OpenQA.Selenium.Keys.Enter);
                    //IWebElement clickoutside = Browser.Wd.FindElement(By.Id("lblAdvanceSearch"));
                   // fw.ExecuteJavascript(clickoutside);
                    tmsWait.Hard(2);
         
        }

        [When(@"Delete submitted diag code page ""(.*)"" is entered")]
        public void WhenDeleteSubmittedDiagCodePageIsEntered(string p0)
        {
            IWebElement mbiInput = Browser.Wd.FindElement(By.Id("tagOrSearch"));
            mbiInput.SendKeys(p0);
        }


       [When(@"Manage Suspect page AdditionalDiagCode is set to ""(.*)""")]
        public void WhenManageSuspectPageAdditionalDiagCodeIsSetTo(string p0)
        {
            RAM.ManageSuspectPage.AdditionalDiagCode.SendKeys(p0);
        }

        [When(@"Manage Suspect page AdditionalEncounterFromDate is set to ""(.*)""")]
        public void WhenManageSuspectPageAdditionalEncounterFromDateIsSetTo(string p0)
        {
            
        }

        [When(@"Manage Suspect page AdditionalEncounter ""(.*)"" Date is set to ""(.*)""")]
        public void WhenManageSuspectPageAdditionalEncounterDateIsSetTo(string p0, string p1)
        {
            string encounterfromdate = Browser.Wd.FindElement(By.XPath("(//span[@test-id='pirResponse-span-dosTxt'])[1]")).Text;
            switch (p0.ToLower())
            {
                case "from":
                    if (p1 == "DOS")
                    AngularFunction.enterDate(RAM.ManageSuspectPage.AdditionalEncounterFromDate, encounterfromdate);
                    break;

                case "to":
                    if (p1 == "DOS")
                    AngularFunction.enterDate(RAM.ManageSuspectPage.AdditionalEncounterToDate, encounterfromdate);
                    break;
            }

        }

        

        [When(@"Manage Suspect page AdditionalProviderId is set to ""(.*)""")]
        public void WhenManageSuspectPageAdditionalProviderIdIsSetTo(string p0)
        {
            RAM.ManageSuspectPage.AdditionalProviderId.SendKeys(p0);
        }

        [When(@"Manage Suspect page Additonal Save button is clicked")]
        public void WhenManageSuspectPageAdditonalSaveButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.ManageSuspectPage.AdditionalSavebutton);
        }

    }
}
