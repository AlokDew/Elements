﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
//using System.Windows.Forms;
using TechTalk.SpecFlow;
using System.Text.RegularExpressions;
using System.IO;
using OpenQA.Selenium.Support.UI;

namespace TMSoR1.FrameworkCode.HCC_RAM
{
    [Binding]
    public class fsManageProject
    {
        [When(@"Assignments Page Individual Update is selected")]
        public void WhenAssignmentsPageIndividualUpdateIsSelected()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(RAM.ProspectiveEvaluationAssignments.IndividualUpdate);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//ul[@id='drpProject_listbox']//li[@data-offset-index='1']")));
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//ul[@id='drpProjectDuration_listbox']//li[@data-offset-index='1']")));
        }

        [When(@"Assignments Page Search button is clicked")]
        public void WhenAssignmentsPageSearchButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(RAM.ProspectiveEvaluationAssignments.SearchButton);
        }
        
        [When(@"Assignments Page Filter Section is opened")]
        public void WhenAssignmentsPageFilterSectionIsOpened()
        {
            tmsWait.Hard(2);
            // Commented below as Filter is Opened by default
            //fw.ExecuteJavascript(RAM.ProspectiveEvaluationAssignments.FilterSection);
           // fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//i[contains(@ng-hide,'!filterToggleHideFlag')]")));
        }

        [When(@"Verify that Filter section displayed for selected project")]
        public void WhenVerifyThatFilterSectionDisplayedForSelectedProject()
        {
            Assert.IsTrue(RAM.ProspectiveEvaluationAssignments.MemeberWithoutHCCLabel.Displayed);
            Assert.IsTrue(RAM.ProspectiveEvaluationAssignments.PayementYearLabel.Displayed);
            Assert.IsTrue(RAM.ProspectiveEvaluationAssignments.RaftTypeLabel.Displayed);
            Assert.IsTrue(RAM.ProspectiveEvaluationAssignments.RiskScoreLabel.Displayed);
            Assert.IsTrue(RAM.ProspectiveEvaluationAssignments.AgeGroupLabel.Displayed);
        }

        [When(@"Verify that Provider and Member section displayed for selected project")]
        public void WhenVerifyThatProviderAndMemberSectionDisplayedForSelectedProject()
        {
            Assert.IsTrue(RAM.ProspectiveEvaluationAssignments.ProviderInfoTitle.Displayed);
            Assert.IsTrue(RAM.ProspectiveEvaluationAssignments.MemberInfoTitle.Displayed);
            Assert.IsTrue(RAM.ProspectiveEvaluationAssignments.ProviderIDLabel.Displayed);
            Assert.IsTrue(RAM.ProspectiveEvaluationAssignments.MemberIDLabel.Displayed);
            Assert.IsTrue(RAM.ProspectiveEvaluationAssignments.MemberNameLabel.Displayed);
            Assert.IsTrue(RAM.ProspectiveEvaluationAssignments.MemberAddressLabel.Displayed);
            Assert.IsTrue(RAM.ProspectiveEvaluationAssignments.QueueStatusLabel.Displayed);
            Assert.IsTrue(RAM.ProspectiveEvaluationAssignments.DueDatePicker.Displayed);
        }


        [When(@"Assignments Page Member Profile Report button is clicked")]
        public void WhenAssignmentsPageMemberProfileReportButtonIsClicked()
        {
            tmsWait.Hard(2);

            fw.ExecuteJavascriptScroll(RAM.ProspectiveEvaluationAssignments.MemberProfileReportButton);
            tmsWait.Hard(60);
            ReUsableFunctions.reportAuthenticationHandler();

            DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_RETURN, 0, 0, 0);
            tmsWait.WaitForWindowToOpen();
           // tmsWait.Hard(20);
            tmsWait.Hard(60);
            Browser.SwitchToChildWindow();
            Assert.IsTrue(Browser.Wd.Title.Contains("MemberProfileMainReport"));
            Browser.Wd.Close();
            Browser.SwitchToParentWindow();
        }
        
        [When(@"Assignments Page Member Outreach section is clicked")]
        public void WhenAssignmentsPageMemberOutreachSectionIsClicked()
        {
            tmsWait.WaitForElement(By.XPath("//span[@class='k-icon k-i-expand']"), 300);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@class='k-icon k-i-expand']")));
            
        }

        [When(@"Assignments Page PCP is clicked from Member Outreach section")]
        public void WhenAssignmentsPagePCPIsClickedFromMemberOutreachSection()
        {
            tmsWait.Hard(2);
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@class='k-icon k-i-expand']")));
             fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(".//*[@id='assignmentsForm']//span[contains(.,'PCP 0')]/preceding-sibling::span[@class='k-icon k-i-expand']")));
        }

        [When(@"Assignments Page Member is clicked from PCP")]
        public void WhenAssignmentsPageMemberIsClickedFromPCP()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'Open')]")));
        }

        [When(@"Assignments Page Edit Information for selected PCP")]
        public void WhenAssignmentsPageEditInformationForSelectedPCP()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(RAM.ProspectiveEvaluationAssignments.EditLink);
        }

        [When(@"PCP Lookup Page Search button is clicked")]
        public void WhenPCPLookupPageSearchButtonIsClicked()
        {
            tmsWait.WaitForElement(By.XPath("//button[contains(.,'SEARCH') and @test-id='pcplookup-btn-Search']"), 200);
            fw.ExecuteJavascript(RAM.ProspectiveEvaluationAssignments.SearchPCPButton);
        }

        [When(@"PCP Lookup Page Provider ID is selected")]
        public void WhenPCPLookupPageProviderIDIsSelected()
        {
            tmsWait.Hard(60);
            fw.ExecuteJavascript(RAM.ProspectiveEvaluationAssignments.ProviderGridCell);
            GlobalRef.ProviderID = Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='lookup-grid-searchresult']//tr/td)[2]")).Text;
        }

        [When(@"PCP Lookup Page Back button is clicked")]
        public void WhenPCPLookupPageBackButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(RAM.ProspectiveEvaluationAssignments.BackButton);
        }

        [When(@"Assignment Page Verify Provider ID for selected PCP")]
        public void WhenAssignmentPageVerifyProviderIDForSelectedPCP()
        {
            tmsWait.Hard(2);
            string expectedProvider = Convert.ToString(GlobalRef.ProviderID);
            //string expectedProvider = Convert.ToString(providerID);
            Assert.IsTrue(RAM.ProspectiveEvaluationAssignments.ProviderIDText.Text.Equals(expectedProvider));
        }


        [When(@"Assignments Page History button is clicked")]
        public void WhenAssignmentsPageHistoryButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(RAM.ProspectiveEvaluationAssignments.HistoryButton);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//th[contains(.,'Action Date')]")).Displayed);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//th[contains(.,'Q-Status')]")).Displayed);
        }


        [When(@"I have created Assignment project for workflow")]
        public void WhenIHaveCreatedAssignmentProjectForWorkflow()
        {
            string iniString = "Project";
            string strReturnString = string.Empty;
            Dictionary<int, string[]> table = new Dictionary<int, string[]>();
            string query = "select distinct (t3.ProjectName) from tbProspectiveEval_ProjectDetail t1 inner join tbProspectiveEval_WorkflowDetail t2 on t1.ProsEvalID = t2.ProsEvalID inner join tbWorkFlow_Projects t3 on t1.projectid = t3.projectid";
            table = ExecuteSingleQuery(query, ConfigFile.RAMdb, 1, 0, "0");
            Random rnd = new Random();
            string dt = DateTime.Now.Date.ToString("MM/dd/yyyy");
            string td = DateTime.Now.AddDays(120).ToString("MM/dd/yyyy");
            for (int lo = 1; lo < 6; lo++)
            {
                strReturnString += rnd.Next(0, 9).ToString();
            }
            iniString += strReturnString;

            if (table.Count < 1)
            {
                fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.createProjectLink);
                tmsWait.Hard(5);
                RAM.RAMProspectiveEvaulation.ProjectNameTextBox.SendKeys(iniString);
                RAM.RAMProspectiveEvaulation.FromDate.SendKeys(dt);
                RAM.RAMProspectiveEvaulation.ThruDate.SendKeys(td);
                tmsWait.Hard(2);
                fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.CreateProjectADDbtn);
                tmsWait.Hard(5);

                IList<IWebElement> elements = Browser.Wd.FindElements(By.CssSelector("[test-id = 'addProspectiveEvaluation-btn-yes']"));

                if (elements.Count > 0)
                {
                    fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.MemberExistYESBtn);
                }
                else
                {
                    fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.BackToCreateProject);
                }

                tmsWait.Hard(5);
                fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.PESAVE);
                tmsWait.WaitForAlertPresent();
                tmsWait.WaitForElement(By.CssSelector("[test-id = 'confirmationDialog-btn-Yes']"), 300);
                fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.ConfirmYes);
                tmsWait.WaitForElement(By.CssSelector("button[test-id='prospectiveEvaluation-btn-queue']"), 300);
                ThenVerifyThatVerifyThatSuccessfulMessageAsGetDisplayed("Project Successfully Added!");
                fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.QueueToAssignBtn);
                tmsWait.WaitForElement(By.ClassName("toast-message"), 340);
            }
        }

     

        [When(@"Manage project page create new project ""(.*)"" for evaluation date ""(.*)"" and ""(.*)"" finally queue to assignment")]
        public void WhenManageProjectPageCreateNewProjectForEvaluationDateAndFinallyQueueToAssignment(string project, string evdatefrom, string evdateto)
        {
            fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.createProjectLink);
            tmsWait.WaitForElement(By.XPath("//span[@test-id='addProspectiveEvaluation-title-addNewProject']"), 60);
            tmsWait.Hard(5);
            RAM.RAMProspectiveEvaulation.ProjectNameTextBox.SendKeys(project);
            RAM.RAMProspectiveEvaulation.FromDate.SendKeys(evdatefrom);
            RAM.RAMProspectiveEvaulation.ThruDate.SendKeys(evdateto);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@class='k-widget k-multiselect k-header form-control multiselectKendo k-valid']")));
           fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//ul[@role='listbox'])[1]//li[contains(.,'2013')]")));
           //SelectElement year = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[test-id='addProspectiveEvaluation-slct-dataSourceYear']")));
           //year.SelectByValue("2013");
            fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.CreateProjectADDbtn);
            tmsWait.Hard(3);
            fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.ConfirmYes);
            fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.PESAVE);
            tmsWait.WaitForAlertPresent();
            tmsWait.WaitForElement(By.XPath("//button[@test-id='addProspectiveEvaluation-btn-yes']"), 300);
            fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.ConfirmYes);



        }


        [Then(@"verify that verify that successful message as ""(.*)"" get displayed")]
        public void ThenVerifyThatVerifyThatSuccessfulMessageAsGetDisplayed(string p0)
        {
            string expected = p0.ToString();
            string actual = fsAddDiagnosisCode.toasterMessagedisplay();
            Assert.AreEqual(expected, actual, "Both values are not getting matched");
        }
        private Dictionary<int, string[]> ExecuteSingleQuery(string SqlString, string DB_NAME, int numberOfColumn, int rowstartcnt, string colSkip)
        {
            Dictionary<int, string[]> table = new Dictionary<int, string[]>();
            SqlCommand thisCommand = null;
            int flag = 0;
            List<string> list = new List<string>();
            try
            {

                //string thisConnectionString = "user id=tmsservice;" +
                //                   "password=TriZetto456;" +
                //                   "Server=" + ConfigFile.DataServer + ";" +
                //                   "Trusted_Connection=no; " +
                //                   "database=" + DB_NAME + "; " +
                //                   "connection timeout=30";
                string thisConnectionString = "server=" + ConfigFile.DataServer + ";" + "database=" + DB_NAME + ";" + "user id=" + ConfigFile.DBUser + ";" + "password=" + ConfigFile.DBPassword + ";" + "Max Pool Size=9000;" + "Connection Timeout=150;" + "Min Pool Size=2";
                SqlConnection DBConn = new SqlConnection();
                DBConn.ConnectionString = thisConnectionString;
                DBConn.Open();
                thisCommand = new SqlCommand(SqlString, DBConn);
                SqlDataReader reader = thisCommand.ExecuteReader();
                //int numberOfRows = (reader.FieldCount + 1) / numberOfColumn;
                int j = 0;


                if (reader.HasRows)
                {

                    while (reader.Read())
                    {

                        list.Clear();

                        for (int i = 0; i < numberOfColumn; i++)
                        {
                            list.Add(reader.GetValue(i).ToString().TrimEnd());
                        }

                        List<string> copyList = list;

                        table.Add(j, copyList.ToArray());

                        j++;
                    }
                }
            }
            catch (Exception e)
            {
                fw.ConsoleReport("Failed read record: [" + e + "] Query [" + SqlString + "]");
            }

            return table;

        }
    }
}
