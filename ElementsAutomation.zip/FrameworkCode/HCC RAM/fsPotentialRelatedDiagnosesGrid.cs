﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.HCC_RAM
{[Binding]
    class fsPotentialRelatedDiagnosesGrid
    {
        [Then(@"Verify Manage Suspect Page link ""(.*)"" is present")]
        public void ThenVerifyManageSuspectPageLinkIsPresent(string linkname)
        {
            string expectedlinkname = linkname.ToString();
            switch (expectedlinkname.ToLower())
            {
                case "additional diagnoses":
                    Assert.IsTrue(RAM.ManageSuspectPage.AdditionalDiagnosesLink.Displayed);
                    break;
                case "potential related diagnoses for pir":
                    Assert.IsTrue(RAM.ManageSuspectPage.PotentialRelatedDiagnosesLink.Displayed);
                    break;

            }
        }
        [When(@"Manage Suspect Page Clicked On Link ""(.*)""")]
        public void WhenManageSuspectPageClickedOnLink(string linkname)
        {
            string expectedlinkname = linkname.ToString();
            switch (expectedlinkname.ToLower()) { 
                case "additional diagnoses":
                    tmsWait.Hard(2);
                fw.ExecuteJavascript(RAM.ManageSuspectPage.AdditionalDiagnoses);
                break;
            case "potential related diagnoses for pir":
                    tmsWait.Hard(2);
                   // fw.ExecuteJavascript(RAM.ManageSuspectPage.PotentialRelatedDiagnosesLink);
                    fw.ExecuteJavascript(RAM.ManageSuspectPage.PotentialRelatedSection);
                    break;
                case "additional diagnoses1":
                    tmsWait.Hard(2);
                    fw.ExecuteJavascript(RAM.ManageSuspectPage.AdditionalDiagnosisSection);
                    break;
            }
        }

        [Then(@"Verify Manage Suspect page Potential Related Diagnoses for PIR table has data ""(.*)""")]
        public void ThenVerifyManageSuspectPagePotentialRelatedDiagnosesForPIRTableHasData(string p0)
        {
            string temp = p0.ToString();
            string[] expected = temp.Split(',');

            IList<IWebElement> table = Browser.Wd.FindElements(By.XPath("//label"));
            //IList<IWebElement> headers = table.FindElements(By.TagName("th"));
            foreach (string exp in expected)
            {
                foreach (IWebElement act in table)
                {
                    if (act.Text.Equals(exp))
                        {
                        Assert.IsTrue((act.Text.Equals(exp)), exp + " is not found");
                        fw.ConsoleReport(exp + " is found on Table");
                        break;
                         }

                }
            }

           }
        [When(@"Manage suspect Page Confirm First potential diagnosis code")]
        public void WhenManageSuspectPageConfirmFirstPotentialDiagnosisCode()
        {
            IWebElement Potentialdiagcode = Browser.Wd.FindElement(By.XPath(".//*[@id='potentialDiagnosesGrid']//table/tbody"));
            IReadOnlyCollection<IWebElement> allrows = Potentialdiagcode.FindElements(By.TagName("tr"));
            foreach (var row in allrows)
            {

                //int FirstPdiagcode = Int32.Parse(row.FindElement(By.XPath("td[1]/span")).Text);
                string FirstPdiagcode = row.FindElement(By.XPath("td[1]/span")).Text;
                ScenarioContext.Current["PotentialDiagCode"] = FirstPdiagcode;

                IWebElement clickEditFirstdiagcode = row.FindElement(By.XPath("td[11]/a"));
                fw.ExecuteJavascript(clickEditFirstdiagcode);
                IWebElement AddcheckboxForFirstdaig = row.FindElement(By.XPath("td[5]/input"));
                fw.ExecuteJavascript(AddcheckboxForFirstdaig);
                IWebElement EncounterDateForFirstdaig = row.FindElement(By.XPath("td[6]//input"));
                EncounterDateForFirstdaig.SendKeys(RAM.ManageSuspectPage.DateofService.Text);
                //IWebElement riskAssCode = row.FindElement(By.XPath("td[7]/input"));
                IWebElement riskAssCode = row.FindElement(By.Name("riskAssessCode"));
                riskAssCode.Clear();
                riskAssCode.SendKeys("C");
                string mmrisk = riskAssCode.GetAttribute("value");
                tmsWait.Hard(3);
                IWebElement claimnu = row.FindElement(By.XPath("td[8]/input"));
                claimnu.SendKeys("123");
                        //IWebElement SaveactionForFirstdiagcode = row.FindElement(By.XPath("td[11]//a[@class='k-button k-button-icontext k-primary k-grid-update']"));
                IWebElement SaveactionForFirstdiagcode = Browser.Wd.FindElement(By.XPath("(//*[@id='potentialDiagnosesGrid']//a[@role='button'])[1]"));

                fw.ExecuteJavascript(SaveactionForFirstdiagcode);
                
                tmsWait.Hard(5);
                break;
            }
        }

        [Then(@"Verify Delete submitted diag code result grid having potential diag code with diag source ""(.*)""")]
        public void ThenVerifyDeleteSubmittedDiagCodeResultGridHavingPotentialDiagCodeWithDiagSource(string dsource)
        {
            Boolean isexist = false;
            IReadOnlyCollection<IWebElement> allrows = RAM.DeleteSubmittedDiagCodes.ResultGrid.FindElements(By.TagName("tr"));
            foreach (var row in allrows)
            {
                IWebElement actualdcode = row.FindElement(By.XPath("td[8]/span"));
                IWebElement actualdsource = row.FindElement(By.XPath("td[9]/span"));
                if (actualdcode.Text == ScenarioContext.Current["PotentialDiagCode"].ToString() && actualdsource.Text == dsource)
                {
                    isexist = true;
                    break;
                }
                //Assert.IsTrue(isexist);

            }
            Assert.IsTrue(isexist);
        }

        [When(@"Delete submitted diag code page potential diag code is selected")]
        public void WhenDeleteSubmittedDiagCodePagePotentialDiagCodeIsSelected()
        {
            IReadOnlyCollection<IWebElement> allrows = RAM.DeleteSubmittedDiagCodes.ResultGrid.FindElements(By.TagName("tr"));
            foreach (var row in allrows)
            {
                IWebElement checkdiagcode = row.FindElement(By.XPath("td[1]/input"));
                IWebElement actualdcode = row.FindElement(By.XPath("td[8]/span"));
                if (ScenarioContext.Current["PotentialDiagCode"].ToString()== actualdcode.Text)
                {
                    fw.ExecuteJavascript(checkdiagcode);
                    break;
                }
            }
        }

        [Then(@"verify CMS extract file has deleted confirmed diag code")]
        public void ThenVerifyCMSExtractFileHasDeletedConfirmedDiagCode()
        {
            string filename = "";
            Boolean isexist = false;
            IReadOnlyCollection<IWebElement> allrows = Browser.Wd.FindElements(By.XPath(".//*[@id='fileProcessStatusGrid']//table//tbody/tr"));
            foreach (var row in allrows)
            {
                string extractname = Browser.Wd.FindElement(By.XPath("//td[4]/span")).Text;
                if (extractname == "CMS Extract")
                {
                    filename = Browser.Wd.FindElement(By.XPath("//td[3]//span")).Text;
                    break;
                }
            }
            string[] appserver = ConfigFile.URL.Split('.');
            string downloadPath = "\\\\" + appserver[1] + "\\TMSSharedFolder\\TMS-QA\\RAM\\output\\" + filename + "";
            //string downloadPath = "\\\\" + appserver[1] + "\\TMSSharedFolder\\TMS-QA\\RAM\\output\\94_cms.txt";
            var readData = ReadFileFunctions.ReadTEXTFile(downloadPath);
            foreach (var rrow in readData)
            {
                // string [] my = rrow.Split(' ');
                string hicin = rrow.Substring(85, 10);
                string actualhicin = ScenarioContext.Current["HICN"].ToString();

                if (hicin == actualhicin)
                //if (hicin == "HICN055676")
                {
                    string deleteindicator = rrow.Substring(68, 1);
                    string deleteddiagcode = rrow.Substring(118, 5);
                    if (deleteindicator == "D" && deleteddiagcode.Trim() == ScenarioContext.Current["PotentialDiagCode"].ToString())
                    {
                        isexist = true;
                        break;
                    }
                }

            }
            Assert.IsTrue(isexist);
        }

        [Then(@"Verify ""(.*)"" CoderId drop down has value ""(.*)""")]
        public void ThenVerifyCoderIdDropDownHasValue(string p0, string p1)
        {
            string coderid = tmsCommon.GenerateData(p1);
            Boolean ispresent = false;
            switch(p0.ToLower())
            {
                case "managesuspectpage":
                    IReadOnlyCollection<IWebElement> coder = Browser.Wd.FindElements(By.XPath("//select[@test-id='pirResponse-select-coders']"));
                    foreach(var row in coder)
                    {
                        if(row.Text==coderid)
                        {
                            ispresent = true;
                        }
                    }
                    break;
                case "manageassignment":
                    IReadOnlyCollection<IWebElement> coderagain = Browser.Wd.FindElements(By.XPath("//select[@test-id='scheduling-select-Coder']"));
                    foreach (var row in coderagain)
                    {
                        if (row.Text == coderid)
                        {
                            ispresent = true;
                        }
                    }
                    break;

            }
            Assert.IsTrue(ispresent);
        }

        [Then(@"Verify RAMX ""(.*)"" CoderId drop down has value ""(.*)""")]
        [Then(@"Verify RAM ""(.*)"" CoderId drop down has value ""(.*)""")]
        public void ThenVerifyRAMXCoderIdDropDownHasValue(string p0, string p1)
        {
            string coderid = tmsCommon.GenerateData(p1);
            Boolean ispresent = false;
            switch (p0.ToLower())
            {
                case "managesuspectpage":
                    IReadOnlyCollection<IWebElement> coder = Browser.Wd.FindElements(By.XPath("//select[@test-id='manageSuspects-select-coderId']"));
                    foreach (var row in coder)
                    {
                        if (row.Text == coderid)
                        {
                            ispresent = true;
                        }
                    }
                    break;

                case "EnterNewDiagDataPage":
                    By drp = By.CssSelector("[aria-owns='ddlCoderId_listbox']");
                    fw.ExecuteJavascript(Browser.Wd.FindElement(drp));
                    tmsWait.Hard(1);
                    IWebElement valuedrp = Browser.Wd.FindElement(By.XPath("//ul[@id='ddlCoderId_listbox']//li[contains(.,'" + coderid + "')]"));
                    Assert.IsTrue(valuedrp.Displayed, "Coder ID is not present in the dropdown");
                    break;


            }
        }


    }
}
