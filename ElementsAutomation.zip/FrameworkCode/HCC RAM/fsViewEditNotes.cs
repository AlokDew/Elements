﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using OpenQA.Selenium.Support.UI;

namespace TMSoR1.FrameworkCode.HCC_RAM
{
    [Binding]
    class fsViewEditNotes
    {
        [When(@"Manage suspect Screen ""(.*)"" link is clicked")]
        public void WhenManageSuspectScreenLinkIsClicked(string p0)
        {
            RAM.ManageSuspectPage.ViewNotes.Click();
            tmsWait.Hard(2);
        }


        [When(@"View Notes Page Add Note Text is set to ""(.*)""")]
        public void WhenViewNotesPageAddNoteTextIsSetTo(string p0)
        {
            RAM.ManageSuspectPage.AddNote.SendKeys(p0);
        }

        [When(@"View Notes Page Add Button is clicked")]
        public void WhenViewNotesPageAddButtonIsClicked()
        {
            RAM.ManageSuspectPage.AddNoteBtn.Click();
            tmsWait.Hard(2);
        }

        [When(@"View Notes Page Alert Popup Yes button is clicked")]
        public void WhenViewNotesPageAlertPopupYesButtonIsClicked()
        {
            RAM.ManageSuspectPage.AddNotePopupYesBtn.Click();
           
        }

        [Then(@"Verify View Notes Page Message ""(.*)""")]
        public void ThenVerifyViewNotesPageMessage(string p0)
        {
            Assert.AreEqual(p0, RAM.ManageSuspectPage.ManageSuspectAcknowledgmentMsg.Text, "Add Note Failed");
            tmsWait.Hard(2);
           
        }

        [When(@"View Notes page EditIcon is clicked for Note ""(.*)""")]
        public void WhenViewNotesPageEditIconIsClickedForNote(string p0)
        {
            IWebElement EditNoteIcon = Browser.Wd.FindElement(By.XPath("//span[text()='"+ p0 +"']/parent::td/parent::tr//a"));
            EditNoteIcon.Click();
        }

        [When(@"View Notes page Notefield name is set to ""(.*)""")]
        public void WhenViewNotesPageNotefieldNameIsSetTo(string p0)
        {
            RAM.ManageSuspectPage.EditNoteText.Clear();
            RAM.ManageSuspectPage.EditNoteText.SendKeys(p0);
            tmsWait.Hard(3);
        }

        [When(@"View Notes page save icon is clicked")]
        public void WhenViewNotesPageSaveIconIsClicked()
        {
            RAM.ManageSuspectPage.SaveNoteIcon.Click();
            
        }



    }
}
