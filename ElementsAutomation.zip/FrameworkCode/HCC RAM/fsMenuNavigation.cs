﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.HCC_RAM
{
    [Binding]
    class fsMenuNavigation
    {
        Actions builder = new Actions(Browser.Wd);

        [When(@"I Moved ""(.*)"" sub menu")]
        public void WhenIMovedSubMenu(string p0)
        {
            string menu = p0.ToString();

            switch (menu)
            {

                case "Manage Suspects Assignment":
                    builder.MoveToElement(Browser.Wd.FindElement(By.CssSelector("[test-id='subMenu-21']"))).Build().Perform();
                     break;
                case "Prospective Evaluation":
                    builder.MoveToElement(Browser.Wd.FindElement(By.CssSelector("a[title='Prospective Evaluation']"))).Build().Perform();
                    break;
                case "Import":
                    builder.MoveToElement(Browser.Wd.FindElement(By.CssSelector("[test-id='subMenu-23']"))).Build().Perform();
                    break;
                case "Export":
                    builder.MoveToElement(Browser.Wd.FindElement(By.CssSelector("[test-id='subMenu-24']"))).Build().Perform();
                    break;

            }
        }


        [Then(@"Verify Application displayed ""(.*)"" page")]
        public void ThenVerifyApplicationDisplayedPage(string p0)
        {
            string exp = p0.ToString();
            tmsWait.Hard(3);
            
            switch (exp)
            {

                case "Import List":
                    
                    Assert.AreEqual(exp, RAM.ImportsPage.Title.Text, exp + "is not displayed ");
                    break;
                case "Export List":
                    try
                    {
                        string ss = RAM.ImportsPage.ExportList.Text;
                    }
                    catch { }
                    Assert.AreEqual(exp, RAM.ImportsPage.ExportList.Text, exp + "is not displayed ");
                    break;
               
      
            }
        
        }


        [When(@"I Clicked ""(.*)"" menu")]
        public void WhenIClickedMenu(string p0)
        {
            tmsWait.Hard(4);
            string menu = p0.ToString();

            switch(menu)
            {
                case "Administration":
                    fw.ExecuteJavascript(RAM.RAMMainmenu.Administration);
                   // RAM.RAMMainmenu.Administration.Click();
                    break;

                case "Reports":
                    fw.ExecuteJavascript(RAM.RAMMainmenu.Reports);
                   // RAM.RAMMainmenu.Reports.Click();
                    break;
                case "Suspects":
                    fw.ExecuteJavascript(RAM.RAMMainmenu.Suspects);
                    //RAM.RAMMainmenu.Suspects.Click();
                    break;
                case "Main":
                    fw.ExecuteJavascript(RAM.RAMMainmenu.Main);
                    //RAM.RAMMainmenu.Main.Click();
                    break;
                case "Tasks":
                    fw.ExecuteJavascript(RAM.RAMMainmenu.Tasks);
                 // RAM.RAMMainmenu.Tasks.Click();
                    break;
                case "Import":
                    fw.ExecuteJavascript(RAM.TasksSubmenu.Import);
                    //builder.MoveToElement(RAM.TasksSubmenu.Import).Click().Build().Perform();
                   break;
                case "Export":
                    fw.ExecuteJavascript(RAM.TasksSubmenu.Export);
                    //builder.MoveToElement(RAM.TasksSubmenu.Export).Click().Build().Perform();
                    break;



            }
        }


        [Then(@"Verify Reports page displayed ""(.*)"" Heading")]
        public void ThenVerifyReportsPageDisplayedHeading(string p0)
        {
           
            IList<string> expected = p0.Split(',').ToList();
            foreach (string verfiy in expected)
            {
                
                if (Browser.Wd.FindElement(By.XPath("//div[@id='reportsBlock']//label[contains(.,'" + verfiy + "')]")).Displayed)
                {
                    Assert.IsTrue(true, verfiy + " is found on RAM Menu");

                }
                else
                {
                    Assert.IsFalse(false, verfiy + " is not found on RAM Menu");
                }
            }



        }
        [Then(@"Verify Import menu displayed ""(.*)"" submenu")]
        public void ThenVerifyImportMenuDisplayedSubmenu(string p0)
        {
            IList<string> expected = p0.Split(',').ToList();
            foreach (string verfiy in expected)
            {

                if (Browser.Wd.FindElement(By.XPath("//li[@test-id='subMenu-23']//ul//a[@title='" + verfiy + "']/span")).Displayed)
                {
                    Assert.IsTrue(true, verfiy + " is found on RAM Menu");

                }
                else
                {
                    Assert.IsFalse(false, verfiy + " is not found on RAM Menu");
                }
            }
        }


        [When(@"RAM Dashboard page Payment Year drop down list is set to ""(.*)""")]
        public void WhenRAMDashboardPagePaymentYearDropDownListIsSetTo(string p0)
        {
            string year = p0.ToString();
            //SelectElement paymentyear = new SelectElement(RAM.RAMDashboardPage.PaymentYeardrpdown);
            //paymentyear.SelectByText(year);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='ramDashboard-select-paymentYear']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + year + "']");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

        }

        [Then(@"Verify RAM Dashboard page ""(.*)"" section is displayed")]
        public void ThenVerifyRAMDashboardPageSectionIsDisplayed(string p0)
        {
            string grid = p0.ToString();
            switch(grid)
            {
                case "Suspect Summary":
                    Assert.IsTrue(RAM.RAMDashboardPage.SuspectSummaryGrid.Displayed, grid+ "section is not getting displayed");
                    break;

                case "Provider Summary":
                    Assert.IsTrue(RAM.RAMDashboardPage.ProviderSummaryGrid.Displayed, grid + "section is not getting displayed");
                    break;
                case "RiskScore":
                    Assert.IsTrue(RAM.RAMDashboardPage.RiskScore.Displayed, grid + "section is not getting displayed");
                    break;
                case "Revenue":
                    Assert.IsTrue(RAM.RAMDashboardPage.Revenue.Displayed, grid + "section is not getting displayed");
                    break;
                    
            }
   

        }

        [Then(@"Verify Tasks menu displayed ""(.*)"" submenu")]
        public void ThenVerifyTasksMenuDisplayedSubmenu(string p0)
        {

            IList<string> expected = p0.Split(',').ToList();
            foreach (string verfiy in expected)
            {
               
                if (Browser.Wd.FindElement(By.XPath("//li[@test-id='menu-18']//ul//a[@title='" + verfiy + "']")).Displayed)
                {
                    Assert.IsTrue(true, verfiy + " is found on RAM Menu");

                }
                else
                {
                    Assert.IsFalse(false, verfiy + " is not found on RAM Menu");
                }
            }
        }

        [Then(@"Verify Export menu displayed ""(.*)"" submenu")]
        public void ThenVerifyExportMenuDisplayedSubmenu(string p0)
        {
            IList<string> expected = p0.Split(',').ToList();
            foreach (string verfiy in expected)
            {

                if (Browser.Wd.FindElement(By.XPath("//li[@test-id='subMenu-24']//ul//a[@title='" + verfiy + "']/span")).Displayed)
                {
                    Assert.IsTrue(true, verfiy + " is found on RAM Menu");

                }
                else
                {
                    Assert.IsFalse(false, verfiy + " is not found on RAM Menu");
                }
            }
        }


        [Then(@"Verify Prospective Evaluation menu displayed ""(.*)"" submenu")]
        public void ThenVerifyProspectiveEvaluationMenuDisplayedSubmenu(string p0)
        {
            IList<string> expected = p0.Split(',').ToList();
            foreach (string verfiy in expected)
            {

                if (Browser.Wd.FindElement(By.XPath("//li[@test-id='subMenu-22']//ul//a[@title='" + verfiy + "']/span")).Displayed)
                {
                    Assert.IsTrue(true, verfiy + " is found on RAM Menu");

                }
                else
                {
                    Assert.IsFalse(false, verfiy + " is not found on RAM Menu");
                }
            }
        }


        [Then(@"Verify Manage Suspects Assignment menu displayed ""(.*)"" submenu")]
        public void ThenVerifyManageSuspectsAssignmentMenuDisplayedSubmenu(string p0)
        {

            IList<string> expected = p0.Split(',').ToList();
            foreach (string verfiy in expected)
            {
                if (Browser.Wd.FindElement(By.XPath("//a[@title='" + verfiy + "']")).Displayed)
                {
                    Assert.IsTrue(true, verfiy + " is found on RAM Menu");

                }
                else
                {
                    Assert.IsFalse(false, verfiy + " is not found on RAM Menu");
                }
            }

        }

        [Then(@"Verify Main menu displayed ""(.*)"" submenu")]
        public void ThenVerifyMainMenuDisplayedSubmenu(string p0)
        {

            IList<string> expected = p0.Split(',').ToList();
            foreach (string verfiy in expected)
            {

                if (Browser.Wd.FindElement(By.XPath("//a[@title='" + verfiy + "']")).Displayed)
                {
                    Assert.IsTrue(true, verfiy + " is found on RAM Menu");

                }
                else
                {
                    Assert.IsFalse(false, verfiy + " is not found on RAM Menu");
                }
            }

        }


        [Then(@"Verify Suspects menu displayed ""(.*)"" submenu")]
        public void ThenVerifySuspectsMenuDisplayedSubmenu(string p0)
        {
            IList<string> expected = p0.Split(',').ToList();
            foreach (string verfiy in expected)
            {

                if (Browser.Wd.FindElement(By.XPath("//li[@test-id='menu-19']//ul//a[@title='" + verfiy + "']//span")).Displayed)
                {
                    Assert.IsTrue(true, verfiy + " is found on RAM Menu");

                }
                else
                {
                    Assert.IsFalse(false, verfiy + " is not found on RAM Menu");
                }
            }
        }



        [Then(@"Verify Administration menu displayed ""(.*)"" submenu")]
        public void ThenVerifyAdministrationMenuDisplayedSubmenu(string p0)
        {


            IList<string> expected = p0.Split(',').ToList();
            foreach (string verfiy in expected)
            {

                if (Browser.Wd.FindElement(By.XPath("//li[@test-id='menu-23']//ul//a[@title='" + verfiy + "']/span")).Displayed)
                {
                    Assert.IsTrue(true, verfiy + " is found on RAM Menu");

                }
                else
                {
                    Assert.IsFalse(false, verfiy + " is not found on RAM Menu");
                }
            }

        }

    }
}
