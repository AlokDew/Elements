﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.HCC_RAM
{

    [Binding]
    class fsSetClientOptions
    {

        [When(@"Set Client Options Page I Selected Option Choice as ""(.*)"" and Entered threshold percentage as ""(.*)""% and Clicked on Save button")]
        public void WhenSetClientOptionsPageISelectedOptionChoiceAsAndEnteredThresholdPercentageAsAndClickedOnSaveButton(string optionchoice, string thresholdpercentage)

        {

            tmsWait.Hard(8);
            //create select element object 
            //var selectElement = new SelectElement(RAM.SetClientOptions.Optionchoice);

            ////select by value
            //selectElement.SelectByText(optionchoice);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='configuration-select-ddlOptionChoice']//span[@class='k-select']");

            By typeapp = By.XPath("//li[text()='" + optionchoice + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            
            tmsWait.Hard(8);
            RAM.SetClientOptions.ThresholdValue.Clear();
            RAM.SetClientOptions.ThresholdValue.SendKeys(thresholdpercentage);
            RAM.SetClientOptions.Savebutton.Click();

          
        }

        [When(@"Set Client Options Page Default Payment Year for Report Dropdown Controls drop down value select as ""(.*)""")]
        public void WhenSetClientOptionsPageDefaultPaymentYearForReportDropdownControlsDropDownValueSelectAs(int p0)
        {
            //SelectElement select = new SelectElement(RAM.SetClientOptions.configurationSelectPaymentYear);
            //select.SelectByText(p0.ToString());
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='configuration-select-paymentYear']//span[@class='k-select']");

            By typeapp = By.XPath("//li[text()='" + p0.ToString() + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

            tmsWait.Hard(8);
            RAM.SetClientOptions.Savebutton.Click();

        }

        [Then(@"Custom Cover Letter PIR page Payment Year displayed the  value as ""(.*)""")]
        public void ThenCustomCoverLetterPIRPagePaymentYearDisplayedTheValueAs(int p0)
        {
            // string actualPaymentYear =
            //SelectElement select = new SelectElement(RAM.SetClientOptions.PaymentYear);
            //string actualpaymentYear=select.SelectedOption.Text;
            IWebElement ddele = Browser.Wd.FindElement(By.XPath("(//label[text()='Payment Year']/parent::div//span[@class='k-input'])"));
            string actualpaymentYear = ddele.Text;
            Assert.AreEqual(actualpaymentYear,p0.ToString(),"As per RAM configuartion setting payment year is not set to Report page");
                
        }


        [Then(@"Verify validationmesaage ""(.*)""")]
        public void ThenVerifyValidationmesaage(string expectederrormessage)
        {
            Assert.AreEqual(expectederrormessage, RAM.SetClientOptions.ErrorMessageThresholdValue.Text, expectederrormessage + " Error message is not getting displayed");
            tmsWait.Hard(5);
        }


        [Then(@"Verify Set Author configuration Yes is ""(.*)""")]
        public void ThenVerifySetAuthorConfigurationYesIs(string p0)
        {
            IWebElement Setauthorcheck = Browser.Wd.FindElement(By.XPath("//input[@test-id='configuration-checkbox-auditorConfiguration']"));
            string setAuthorChkBox = Setauthorcheck.GetAttribute("class");
            
            if(!setAuthorChkBox.Contains("not-empty"))
            {
                fw.ExecuteJavascript(Setauthorcheck);
                tmsWait.Hard(1);
            }

            else
            {
                Console.WriteLine("Check box is already checked");
            }

        }





        [Then(@"on RAMX Configuration page ""(.*)"" is set to ""(.*)""")]
        public void ThenOnRAMXConfigurationPageIsSetTo(string p0, string p1)
        {
            string option = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            IWebElement ele;
            switch (option)
            {
                case "Model Year":
                    ele = Browser.Wd.FindElement(By.XPath("//*[@test-id='configuration-txt-modelYear']"));
                    ele.Clear();
                    tmsWait.Hard(1);
                    ele.SendKeys(value);
                    break;
                case "Execution Zone Code":
                    ele = Browser.Wd.FindElement(By.XPath("//*[@test-id='configuration-txt-executionZoneCode']"));
                    ele.Clear();
                    tmsWait.Hard(1);
                    ele.SendKeys(value);
                    break;
                case "Submission Type Code":
                    ele = Browser.Wd.FindElement(By.XPath("//*[@test-id='configuration-txt-submissionTypeCode']"));
                    ele.Clear();
                    tmsWait.Hard(1);
                    ele.SendKeys(value);
                    break;
                case "Interface Control Release Number":
                    ele = Browser.Wd.FindElement(By.XPath("//*[@test-id='configuration-txt-releaseNumber']"));
                    ele.Clear();
                    tmsWait.Hard(1);
                    ele.SendKeys(value);
                    break;
                case "Add Delete Void Code":
                    ele = Browser.Wd.FindElement(By.XPath("//*[@test-id='configuration-txt-addDeleteVoidCode']")); ;
                    ele.Clear();
                    tmsWait.Hard(1);
                    ele.SendKeys(value);
                    break;
                case "Source Code":
                    ele = Browser.Wd.FindElement(By.XPath("//*[@test-id='configuration-txt-sourceCode']"));
                    ele.Clear();
                    tmsWait.Hard(1);
                    ele.SendKeys(value);
                    break;
            }
        }

        [Then(@"on RAMX Configuration page I click on Save button")]
        public void ThenOnRAMXConfigurationPageIClickOnSaveButton()
        {
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@test-id='configuration-btn-save']"));
            ele.Click();
            tmsWait.Hard(1);
           // string actualMessage = Browser.Wd.FindElement(By.XPath("//*[@class='toast-message']")).Text; // commented due to deay in display of toaster message
            //string expMessage = "Configuration updated successfully.";
           // Assert.AreEqual(expMessage, actualMessage, "Message is not correct/displayed");
        }



    }




}

