﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1
{
    class cfRAMAdministration
    {
        public static AddOnHoldReasons AddOnHoldReasons { get { return new AddOnHoldReasons(); } }
    }


    public class AddOnHoldReasons
    {
        public IWebElement Administration { get { return Browser.Wd.FindElement(By.CssSelector("[title='Administration']")); } }
        public IWebElement AddOnHoldReasonsMenu { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Add On Hold Reasons')]")); } }
        public IWebElement AddOnHoldReasonsTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='onHoldReasons-txt-addReason']")); } }
        public IWebElement ADDButton { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'ADD')]")); } }

        public IWebElement ConfirmationDialogue { get { return Browser.Wd.FindElement(By.XPath("(//div[@role='dialog'])[2]")); } }

        public IWebElement ConfirmationDialogueYES { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='confirmationDialog-btn-Yes']")); } }
        public IWebElement ConfirmationDialogueNO { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='confirmationDialog-btn-No']")); } }

    }



}

