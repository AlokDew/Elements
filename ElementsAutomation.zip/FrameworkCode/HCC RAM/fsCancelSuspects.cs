﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.HCC_RAM
{
    [Binding]
    class fsCancelSuspects
    {
        [When(@"Cancel Suspect Search Page Cancel Suspects By is selected as ""(.*)""")]
        public void WhenCancelSuspectSearchPageCancelSuspectsByIsSelectedAs(string suspect)
        {
            //SelectElement cancelSuspects = new SelectElement(RAM.CancelSuspectPage.CancelSuspectsByDropdown);
            //cancelSuspects.SelectByText(suspect);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='cancelSuspects-select-searchType']//span[@class='k-select']");

            By typeapp = By.XPath("//li[text()='" + suspect + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

            tmsWait.Hard(3);
        }

        [When(@"Cancel Suspect Search Page Provider Suspect is selected as ""(.*)""")]
        public void WhenCancelSuspectSearchPageProviderSuspectIsSelectedAs(string suspect)
        {
            //SelectElement providerSuspectDD = new SelectElement(RAM.CancelSuspectPage.ProviderSuspectDropdown);
            //providerSuspectDD.SelectByText(suspect);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='cancelSuspects-select-providerSuspectsType']//span[@class='k-select']");

            By typeapp = By.XPath("//li[text()='" + suspect + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }

        [When(@"Cancel Suspect page Last Name is set to ""(.*)""")]
        public void WhenCancelSuspectPageLastNameIsSetTo(string lastName)
        {
            RAM.CancelSuspectPage.LastNameTextbox.SendKeys(lastName);
        }

        [When(@"Cancel Suspect page Search button is clicked")]
        public void WhenCancelSuspectPageSearchButtonIsClicked()
        {
            RAM.CancelSuspectPage.SearchButton.Click();
            
            try
            {
                if (RAM.CancelSuspectPage.ProviderSearchPanel.Displayed)
                {
                    Assert.IsTrue(RAM.CancelSuspectPage.ProviderSearchPanel.Displayed);
                }
            }
            catch (Exception)
            {
                try
                {
                    if (RAM.CancelSuspectPage.NoResultMessage.Displayed)
                    {
                        Assert.IsTrue(RAM.CancelSuspectPage.NoResultMessage.Displayed);
                    }
                }
                catch (Exception)
                {
                    if (RAM.CancelSuspectPage.CancelSuspectActionButton.Displayed)
                    {
                        RAM.CancelSuspectPage.CancelSuspectActionButton.Click();
                    }
                    tmsWait.Hard(3);
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@id='dialog']")).Displayed);
                }
            }
        }


        [When(@"Cancel Suspect Search button is clicked")]
        public void WhenCancelSuspectSearchButtonIsClicked()
        {
            RAM.CancelSuspectPage.SearchButton.Click();
            tmsWait.Hard(5);
        }

        [When(@"Cancel Suspect page ICD Code is entered as ""(.*)""")]
        public void WhenCancelSuspectPageICDCodeIsEnteredAs(string icd)
        {
            RAM.CancelSuspectPage.ICDCodeTextbox.SendKeys(icd);
        }


        [When(@"Cancel Suspect page Action Cancel Suspect button is clicked")]
        public void WhenCancelSuspectPageActionCancelSuspectButtonIsClicked()
        {
            if(RAM.CancelSuspectPage.CancelSuspectActionButton.Displayed)
            {
                RAM.CancelSuspectPage.CancelSuspectActionButton.Click();
            }
        }

        [Then(@"Verify Manage Suspects displays message ""(.*)""")]
        public void ThenVerifyManageSuspectsDisplaysMessage(string exp)
        {
            if (Browser.Wd.FindElement(By.ClassName("toast-message")).Displayed)
            {
                string act = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                Assert.AreEqual(exp, act, exp + " is not displayed");
            }
            //if (RAM.CancelSuspectPage.NoResultMessage.Displayed)
            //{
            //    string act = RAM.CancelSuspectPage.NoResultMessage.Text;
            //    Assert.AreEqual(exp, act, exp + " is not displayed");
            //}
        }


        [When(@"Cancel Suspects page Select Type is selected as ""(.*)""")]
        public void WhenCancelSuspectsPageSelectTypeIsSelectedAs(string type)
        {
            tmsWait.Hard(2);
            switch(type.ToLower())
            {
                case "group":
                    fw.ExecuteJavascript(RAM.CancelSuspectPage.GroupRadiobutton);
                    break;
                case "provider":
                    fw.ExecuteJavascript(RAM.CancelSuspectPage.ProviderRadiobutton);
                    break;
            }
        }


        [When(@"Cancel Suspect Search Page Payment Year is selected as ""(.*)""")]
        public void WhenCancelSuspectSearchPagePaymentYearIsSelectedAs(string year)
        {
            year = tmsCommon.GenerateData(year);
            //SelectElement payementYear = new SelectElement(RAM.CancelSuspectPage.PaymentYearsDropdown);
            //payementYear.SelectByText(year);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='cancelSuspects-select-paymentYear']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + year + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }

        [When(@"Cancel Suspect Search Page PIR Control Number is entered as ""(.*)""")]
        public void WhenCancelSuspectSearchPagePIRControlNumberIsEnteredAs(string pir)
        {
            RAM.CancelSuspectPage.PIRControlNumberTextbox.SendKeys(pir);
        }


        [When(@"Cancel Suspect Search Page Suspect Type is selected as ""(.*)""")]
        public void WhenCancelSuspectSearchPageSuspectTypeIsSelectedAs(string type)
        {
            //SelectElement suspectType = new SelectElement(RAM.CancelSuspectPage.SuspectTypeDropdown);
            //suspectType.SelectByText(type);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='cancelSuspects-select-suspectTypes']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + type + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }

        [When(@"Cancel Suspect Search Page Reset button is clicked")]
        public void WhenCancelSuspectSearchPageResetButtonIsClicked()
        {
            RAM.CancelSuspectPage.ResetButton.Click();
        }

        [When(@"Cancel Suspect Search Page Cancel Suspect Blank message displayed as ""(.*)""")]
        public void WhenCancelSuspectSearchPageCancelSuspectBlankMessageDisplayedAs(string message)
        {
            if (RAM.CancelSuspectPage.BlankProviderErrorMessage.Displayed)
            {
                Assert.IsTrue(RAM.CancelSuspectPage.BlankProviderErrorMessage.Text.Contains(message));
            }
        }


        [When(@"Cancel Suspect Search Confirmation Yes button is clicked")]
        public void WhenCancelSuspectSearchConfirmationYesButtonIsClicked()
        {
            RAM.CancelSuspectPage.ConfirmationYesButton.Click();
            tmsWait.Hard(5);
        }



        [When(@"Cancel Suspect Search Page Confirmation Yes button is clicked")]
        public void WhenCancelSuspectSearchPageConfirmationYesButtonIsClicked()
        {
            tmsWait.Hard(2);
            RAM.CancelSuspectPage.ConfirmationYesButton.Click();
            try
            {
                if (RAM.CancelSuspectPage.ProviderSearchPanel.Displayed)
                {
                    Assert.IsTrue(RAM.CancelSuspectPage.ProviderSearchPanel.Displayed);
                }
            }
            catch (Exception)
            {
                try
                {
                    if (RAM.CancelSuspectPage.NoResultMessage.Displayed)
                    {
                        Assert.IsTrue(RAM.CancelSuspectPage.NoResultMessage.Displayed);
                    }
                }
                catch (Exception)
                {
                    if (RAM.CancelSuspectPage.CancelSuspectActionButton.Displayed)
                    {
                        RAM.CancelSuspectPage.CancelSuspectActionButton.Click();
                    }
                    tmsWait.Hard(3);
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@id='dialog']")).Displayed);
                }
            }
        }

        [When(@"Verify Cancel Suspect Search is displayed")]
        public void WhenVerifyCancelSuspectSearchIsDisplayed()
        {
            if (RAM.CancelSuspectPage.ProviderSearchPanel.Displayed)
            {
                Assert.IsTrue(RAM.CancelSuspectPage.ProviderSearchPanel.Displayed);
            }
        }


        [When(@"Cancel Suspect Search Page Cancel Suspects button is clicked")]
        public void WhenCancelSuspectSearchPageCancelSuspectsButtonIsClicked()
        {
            tmsWait.Hard(2);
            RAM.CancelSuspectPage.CancelSuspectsButton.Click();
            tmsWait.Hard(2);
        }

        [When(@"Cancel Suspect Page Error message for blank PIR Control Number is displayed as ""(.*)""")]
        public void WhenCancelSuspectPageErrorMessageForBlankPIRControlNumberIsDisplayedAs(string message)
        {
            tmsWait.Hard(2);
            Assert.IsTrue(RAM.CancelSuspectPage.ErrorMessageControlNumber.Text.Equals(message));
        }

        [When(@"Cancel Suspect Search Page HCC Name is entered as ""(.*)""")]
        public void WhenCancelSuspectSearchPageHCCNameIsEnteredAs(string hcc)
        {
            tmsWait.Hard(2);
            RAM.CancelSuspectPage.HCCNameTextbox.SendKeys(hcc);
        }

        [When(@"Cancel Suspect Page Error message for blank HCC Name is displayed as ""(.*)""")]
        public void WhenCancelSuspectPageErrorMessageForBlankHCCNameIsDisplayedAs(string message)
        {
            Assert.IsTrue(RAM.CancelSuspectPage.ErrorMessageHCCName.Text.Equals(message));
        }


        [When(@"Cancel Suspect Search Page Yes button is clicked")]
        public void WhenCancelSuspectSearchPageYesButtonIsClicked()
        {
            tmsWait.Hard(5);
            RAM.CancelSuspectPage.ConfirmationYesButton.Click();
        }

        [When(@"Cancel Suspect Page Successful Confirmation dialog box is displayed")]
        public void WhenCancelSuspectPageSuccessfulConfirmationDialogBoxIsDisplayed()
        {
            tmsWait.Hard(1);

            try
            {
                if (Browser.Wd.FindElement(By.ClassName("k-notification-content")).Displayed)
                {
                    //No any result
                }
            }
            catch (Exception)
            {
                tmsWait.Hard(3);
                Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//kendo-dialog-titlebar[contains(@id,'dialog')]")).Displayed);
            }
        }

        [When(@"Verify Cancel Suspect Search Page Error message is displayed")]
        public void WhenVerifyCancelSuspectSearchPageErrorMessageIsDisplayed()
        {
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[contains(.,'Sorry, there are no available Suspects/PIRs to cancel. Please try your search again')]")).Displayed);
        }

        [When(@"Cancel Suspect Page Error message for invalid PIR Control Number is displayed as ""(.*)""")]
        public void WhenCancelSuspectPageErrorMessageForInvalidPIRControlNumberIsDisplayedAs(string message)
        {
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[contains(.,'" + message + "')]")).Displayed);
        }


    }
}
