﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.HCC_RAM
{
    [Binding]
    class fsAddReasons
    {
        private bool nextPage;
        [When(@"Administration Main Menu Add Reasons sub menu is clicked")]
        public void WhenAdministrationMainMenuAddReasonsSubMenuIsClicked()
        {
            RAM.RAMHomePage.RAMAdministration.Click();
            RAM.AdminSubmenu.RAMAaddReasons.Click();
        }
        [Then(@"Verify ""(.*)""page is opened Successfully")]
        public void ThenVerifyPageIsOpenedSuccessfully(string p0)
        {
            string expected = p0.ToString();
            string actual = RAM.AddReasonsPage.RAMAaddReasonslable.Text;
            Assert.AreEqual(expected, actual, expected + "Title is not getting displayed");
        }

        [When(@"Add Reasons Page Reason is Set to ""(.*)""")]
        public void WhenAddReasonsPageReasonIsSetTo(string reason)
        {
            string reasonstring = tmsCommon.GenerateData(reason);
            tmsWait.Hard(2);
            RAM.AddReasonsPage.RAMAaddReason.SendKeys(reasonstring);
        }

        [When(@"Add Reasons Page Add button is Clicked")]
        public void WhenAddReasonsPageAddButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.AddReasonsPage.RAMAaddReasonAddbutton);
            
        }

        [Then(@"Verify RAM Main page displays ""(.*)"" menus")]
        public void ThenVerifyRAMMainPageDisplaysMenus(string p0)
        {
            tmsWait.Hard(5);
            bool verify = true;
            IList<string> expected = p0.Split(',').ToList();
            foreach (string verfiy in expected)
            {
               
                if (Browser.Wd.FindElement(By.XPath("//ul[@test-id='menu-titleList']/li[contains(.,'" + verfiy + "')]")).Displayed)
                {
                    Assert.IsTrue(true, verfiy + " is found on RAM Menu");

                }
                else
                {
                    Assert.IsFalse(false, verfiy + " is not found on RAM Menu");
                }
            }
        }


        [When(@"Add Reasons page from grid for added reason ""(.*)"" edit button is clicked And Updated reason And Clicked on Save button")]
        public void WhenAddReasonsPageFromGridForAddedReasonEditButtonIsClickedAndUpdatedReasonAndClickedOnSaveButton(string reasontoedit)
        {
            string actualaddedreson = tmsCommon.GenerateData(reasontoedit);
            //do
            //{
            //    nextPage = VerifyAddReason(actualaddedreson);
            //    if (nextPage)
            //    {
            //        Browser.Wd.FindElement(By.LinkText("Next")).Click();
            //    }
            //} while (nextPage);

            KendoUIFunctions.ResultGridTextValidation(actualaddedreson);
            //Edit Reason code
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//tr[contains(.,'" + actualaddedreson + "')]//span[@class='fas fa-pencil-alt']")));
            string updateddescription = "Update" + actualaddedreson;
            tmsWait.Hard(8);
            // Update Diagnosis Code Description
            Browser.Wd.FindElement(By.XPath("//input[@name='Description']")).Clear();
            tmsWait.Hard(4);
            Browser.Wd.FindElement(By.XPath("//input[@name='Description']")).SendKeys(updateddescription);
            tmsWait.Hard(4);
            //Click on Save Button 
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//input[@modelname='Reason']/parent::td//following-sibling::td//button[@class='k-button k-grid-save-command ng-star-inserted']")));
        }

        public bool VerifyAddReason(string addedreason)
        {
            try
            {
                if (Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + addedreason + "')]")).Displayed)
                {

                    return false;

                }
            }
            catch (Exception ex)
            {
                return true;
            }
            return true;


        }


    




    [When(@"Warning dialog ""(.*)"" button is Clicked")]
        public void WhenWarningDialogButtonIsClicked(string inputaction)
        {
            string button = inputaction.ToString();
            try
            {


                if (button.Equals("Yes"))
                {
                    tmsWait.Hard(5);
                    
                    fw.ExecuteJavascript(RAM.AddReasonsPage.WarningYesButton);
                }
                else if (button.Equals("No"))
                {
                    tmsWait.Hard(5);
                    RAM.AddReasonsPage.WarningNoButton.Click();
                }
            }
            catch
            {
                fw.ConsoleReport(" There is no Alert");
           
            }
           // tmsWait.Hard(2);
        }

        [Then(@"Verify Add Reasons page is displaying Reasons added by User grid with added reason ""(.*)""")]
        public void ThenVerifyAddReasonsPageIsDisplayingReasonsAddedByUserGridWithAddedReason(string addedreason)
        {
            string actualaddedreson = tmsCommon.GenerateData(addedreason);
            //PaginationNextbuttonClick(actualaddedreson);
            KendoUIFunctions.ResultGridTextValidation(actualaddedreson);
         }


        // this method written to click on "Next" button unless given element not found in result grid
        public void PaginationNextbuttonClick(string actualaddedreson)
        {
            do
            {
                nextPage = VerifyResultGrid(actualaddedreson);
                if (nextPage)
                {
                    IWebElement NextButton = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    fw.ExecuteJavascript(NextButton);
                }
            } while (nextPage);
           
        }
        public bool VerifyDiagnosisCode(string addedreason)
        {
            try
            {
                if (Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + addedreason + "')]")).Displayed)
                {

                    return false;

                }
            }
            catch (Exception ex)
            {
                return true;
            }
            return true;


        }

        public bool VerifyResultGrid(string addedreason)
        {
            try
            {
                if (Browser.Wd.FindElement(By.XPath(" //table[@role='grid']//td[contains(.,'" + addedreason + "')]")).Displayed)
                {

                    return false;

                }
            }
            catch (Exception ex)
            {
                return true;
            }
            return true;


        }



    }
}