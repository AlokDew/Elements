﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using TechTalk.SpecFlow;
using TMSoR1.FrameworkCode.RxM;

namespace TMSoR1.FrameworkCode.HCC_RAM
{
    [Binding]
    public class fsRAMReport
    {
        SelectElement searchByDD;
        [Then(@"RAMX report page ""(.*)"" report link is clicked")]
        [Then(@"RAM report page ""(.*)"" report link is clicked")]
        public void ThenRAMReportPageReportLinkIsClicked(string link)
        {
            //tmsWait.Hard(5);
            //IWebElement expandAll = Browser.Wd.FindElement(By.CssSelector("[test-id='report-button-expandcolaps']"));
            //fw.ExecuteJavascript(expandAll);

            tmsWait.Hard(5);
            IWebElement reportlink = Browser.Wd.FindElement(By.CssSelector("[test-id='" + link + "']"));
            fw.ExecuteJavascript(reportlink);
            tmsWait.Hard(5);
        }



        [Then(@"RAM report page ""(.*)"" reports link is clicked")]
        [Then(@"RAMX report page ""(.*)"" reports link is clicked")]
        public void ThenRAMReportPageReportsLinkIsClicked(string p0)
        {
            IWebElement link = null;
            tmsWait.Hard(10);
            switch (p0)
            {
                case "Cover Letter PIR":
                    link = Browser.Wd.FindElement(By.CssSelector("[test-id='311']"));
                    fw.ExecuteJavascript(link);
                    break;
                case "Custom Cover Letter PIR":
                    link = Browser.Wd.FindElement(By.CssSelector("[test-id='310']"));
                    fw.ExecuteJavascript(link);
                    break;
                case "Risk Revenue by PCP – Details":
                    link = Browser.Wd.FindElement(By.CssSelector("[test-id='Risk Revenue by&nbsp;PCP&nbsp;– Details']"));
                    fw.ExecuteJavascript(link);
                    break;


            }

            tmsWait.Hard(10);

        }

        [Then(@"Report page Provider Icon is Clicked")]
        public void ThenReportPageProviderIconIsClicked()
        {
            tmsWait.Hard(10);
            IWebElement link = Browser.Wd.FindElement(By.XPath("(//span[@test-id='report-link-group']/a/i)[1]"));
            fw.ExecuteJavascript(link);
            tmsWait.Hard(10);
        }

        [Then(@"Provider Lookup page Back button is Clicked")]
        public void ThenProviderLookupPageBackButtonIsClicked()
        {
            IWebElement link = Browser.Wd.FindElement(By.CssSelector("[test-id='pcpLookup-txt-backToRecord']"));
            fw.ExecuteJavascript(link);
        }

        [Then(@"Provider Lookup Search results Provider ID ""(.*)"" is Clicked")]
        public void ThenProviderLookupSearchResultsProviderIDIsClicked(string p0)
        {
            IWebElement result = Browser.Wd.FindElement(By.XPath("//div[@test-id='searchProvider-grid-providerLookup']//tr/td[contains(.,'" + p0 + "')]/following-sibling::td//a"));
            fw.ExecuteJavascript(result);
            tmsWait.Hard(2);

        }


        [Then(@"Provider Lookup Provider ID is set to ""(.*)"" and Serch button is Clicked")]
        public void ThenProviderLookupProviderIDIsSetToAndSerchButtonIsClicked(string p0)
        {
            IWebElement txt = Browser.Wd.FindElement(By.CssSelector("[test-id='searchProvider-txt-ProviderID']"));
            txt.SendKeys(p0);
            IWebElement search = Browser.Wd.FindElement(By.CssSelector("[test-id='searchProvider-btn-search']"));
            fw.ExecuteJavascript(search);
            tmsWait.Hard(3);

            GlobalRef.providerID = p0;
        }

        [Then(@"Search Criteria page Client is selected as ""(.*)""")]
        public void ThenSearchCriteriaPageClientIsSelectedAs(string client)
        {
            SelectElement clientDD = new SelectElement(RAM.CustomCoverLetterPIR.ClientDropdown);
            clientDD.SelectByText(client);
        }

        [Then(@"Search Criteria page Payement Year is selected as ""(.*)""")]
        public void ThenSearchCriteriaPagePayementYearIsSelectedAs(string year)
        {
            SelectElement payementYearDD = new SelectElement(RAM.CustomCoverLetterPIR.PaymentYearDropdown);
            payementYearDD.SelectByText(year);

        }
        [When(@"Search Criteria page Payement Year is selected ""(.*)""")]
        [Then(@"Search Criteria page Payement Year is selected ""(.*)""")]
        public void ThenSearchCriteriaPagePayementYearIsSelected(int p0)
        {
            SelectElement payementYearDD = new SelectElement(RAM.CustomCoverLetterPIR.PaymentYearDropdown);
            //payementYearDD.SelectByText(year);
            IList<IWebElement> x = payementYearDD.Options;
            payementYearDD.SelectByIndex(x.Count - 5);
        }

        [Then(@"on Reports Search Criteria page Payement Year is selected ""(.*)""")]
        public void ThenOnReportsSearchCriteriaPagePayementYearIsSelected(string year)
        {
            By Drp = By.XPath("//label[contains(.,'Payment Year')]/parent::div//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + year + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
        }


        [Then(@"Search Criteria page Status is selected as ""(.*)""")]
        public void ThenSearchCriteriaPageStatusIsSelectedAs(string status)
        {
            By Drp = By.XPath("//label[contains(.,'Status')]/parent::div//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + status + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
        }

        [Then(@"Search Criteria page Letter Type is selected as ""(.*)""")]
        public void ThenSearchCriteriaPageLetterTypeIsSelectedAs(string letterType)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(1);

                By Drp = By.XPath("//kendo-dropdownlist[@test-id='LetterType']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + letterType + "']");

                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
            }
            else
            {
                SelectElement letterTypeDD = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@test-id='LetterType']")));
                letterTypeDD.SelectByText(letterType);
            }
        }

        [Then(@"RAM report page PIR By Control No report Control Number is set to ""(.*)""")]
        [Then(@"RAMX report page PIR By Control No report Control Number is set to ""(.*)""")]
        public void ThenRAMReportPagePIRByControlNoReportControlNumberIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            IWebElement controlnum = Browser.Wd.FindElement(By.CssSelector("[test-id='ControlNum']"));
            controlnum.SendKeys(p0);
        }

        [Then(@"FRM report MBI is set to ""(.*)""")]
        public void ThenFRMReportMBIIsSetTo(string p0)
        {
            tmsWait.Hard(4);
            IWebElement mbi = Browser.Wd.FindElement(By.XPath("//input[@test-id='Claim']"));
            mbi.SendKeys(p0);
        }

        [Then(@"on Search Criteria page ""(.*)"" is set to ""(.*)""")]
        public void ThenOnSearchCriteriaPageIsSetTo(string p0, string p1)
        {

            IWebElement PlanID = Browser.Wd.FindElement(By.XPath("//select[@test-id='PlanId']"));
            SelectElement PlanID_DD = new SelectElement(PlanID);
            PlanID_DD.SelectByText(p1);
        }

        [Then(@"on Search Criteria page PlanID is set to ""(.*)""")]
        public void ThenOnSearchCriteriaPagePlanIDIsSetTo(string p0)
        {
            tmsWait.Hard(4);
            string value = tmsCommon.GenerateData(p0);

            if (ConfigFile.EnvType.Equals("ESI"))
            {
                new SelectElement(Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl03_ddValue"))).SelectByText(value);
            }
            else
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    tmsWait.Hard(1);
                    
                    By Drp = By.XPath("//kendo-dropdownlist[@test-id='PlanID']//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + value + "']");

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                }
                else
                {
                    IWebElement PlanID = Browser.Wd.FindElement(By.XPath("//select[@test-id='PlanID']"));
                    SelectElement PlanID_DD = new SelectElement(PlanID);
                    PlanID_DD.SelectByText(value);
                }
            }

        }


        [Then(@"on Transaction Summary Search Criteria page Planid is set to ""(.*)""")]
        public void ThenOnTransactionSummarySearchCriteriaPagePlanidIsSetTo(string p0)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(1);
                
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='Planid']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + p0 + "']");

                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
            }
            else
            {
                IWebElement TransactionPlanid = Browser.Wd.FindElement(By.XPath("//select[@test-id='Planid']"));
                SelectElement TransactionPlanid_DD = new SelectElement(TransactionPlanid);
                TransactionPlanid_DD.SelectByText(p0);
            }
        }


        [Then(@"on Search Criteria page Plan is set to ""(.*)""")]
        public void ThenOnSearchCriteriaPagePlanIsSetTo(string p0)
        {
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                new SelectElement(Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl03_ddValue"))).SelectByText(p0);
            }
            else
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    tmsWait.Hard(1);

                    By Drp = By.XPath("//kendo-dropdownlist[@test-id='Plan']//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + p0 + "']");

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                }
                else
                {
                    IWebElement Plan = Browser.Wd.FindElement(By.XPath("//select[@test-id='Plan']"));
                    SelectElement Plan_DD = new SelectElement(Plan);
                    Plan_DD.SelectByText(p0);
                }
            }
        }

        [Then(@"on Search Criteria page Plan_Id is set to ""(.*)""")]
        public void ThenOnSearchCriteriaPagePlan_IdIsSetTo(string p0)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(1);
                
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='PLAN_ID']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + p0 + "']");

                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
            }
            else
            {
                IWebElement Plan_Id = Browser.Wd.FindElement(By.XPath("//select[@test-id='PLAN_ID']"));
                SelectElement Plan_Id_DD = new SelectElement(Plan_Id);
                Plan_Id_DD.SelectByText(p0);
            }
        }

        [Then(@"on Search Criteria page PLAN_ID is set to ""(.*)""")]
        [When(@"on Search Criteria page PLAN_ID is set to ""(.*)""")]
        [Given(@"on Search Criteria page PLAN_ID is set to ""(.*)""")]
        public void ThenOnSearchCriteriaPagePLAN_IDIsSetTo(string p0)
        {
            IWebElement multiSelect = Browser.Wd.FindElement(By.CssSelector("[test-id='PLAN_ID']"));
            fw.ExecuteJavascript(multiSelect);
            tmsWait.Hard(3);
            IWebElement option = Browser.Wd.FindElement(By.XPath("//a[contains(.,'" + p0 + "')]"));
            fw.ExecuteJavascript(option);
            tmsWait.Hard(3);
            fw.ExecuteJavascript(multiSelect);
        }

        [Then(@"on Search Criteria page PlanId is selected as ""(.*)""")]
        public void ThenOnSearchCriteriaPagePlanIdIsSelectedAs(string p0)
        {
            IWebElement multiSelect = Browser.Wd.FindElement(By.CssSelector("[test-id='PlanId']"));
            fw.ExecuteJavascript(multiSelect);
            tmsWait.Hard(3);
            IWebElement option = Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + p0 + "')]"));
            fw.ExecuteJavascript(option);
            tmsWait.Hard(3);
            fw.ExecuteJavascript(multiSelect);
        }


        [Then(@"on Search Criteria page PBPID is set to ""(.*)""")]
        public void ThenOnSearchCriteriaPagePBPIDIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);

            if (ConfigFile.EnvType.Equals("ESI"))
            {
                new SelectElement(Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl05_ddValue"))).SelectByText(value);
            }
            else
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    tmsWait.Hard(1);
                    
                    By Drp = By.XPath("//kendo-dropdownlist[@test-id='PBPID']//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + value + "']");

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                }
                else
                {
                    IWebElement PBPID_ele = Browser.Wd.FindElement(By.XPath("//select[@test-id='PBPID']"));
                    SelectElement PBPID_DD = new SelectElement(PBPID_ele);
                    PBPID_DD.SelectByText(value);
                }
            }
        }


        [Then(@"on Search Criteria page Status is set to ""(.*)""")]
        public void ThenOnSearchCriteriaPageStatusIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            IWebElement statusElement = Browser.Wd.FindElement(By.XPath("//select[@test-id='Status']"));
            SelectElement Status_DD = new SelectElement(statusElement);
            Status_DD.SelectByText(value);
        }


        [Then(@"on Search Criteria page Cancelation Type is set to ""(.*)""")]
        public void ThenOnSearchCriteriaPageCancelationTypeIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            IWebElement element = Browser.Wd.FindElement(By.XPath("//select[@test-id='CancelationType']"));
            SelectElement CancelationTypeDD = new SelectElement(element);
            CancelationTypeDD.SelectByText(value);
        }


        [Then(@"on Search Criteria page PBP is set to ""(.*)""")]
        [Given(@"on Search Criteria page PBP is set to ""(.*)""")]
        public void ThenOnSearchCriteriaPagPBPIsSetTo(string value)
        {
            tmsWait.Hard(3);
            string pbpValue = tmsCommon.GenerateData(value);
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                new SelectElement(Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl05_ddValue"))).SelectByText(pbpValue);
            }
            else
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    tmsWait.Hard(1);
                    
                    By Drp = By.XPath("//kendo-dropdownlist[@test-id='PBP']//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + pbpValue + "']");

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                }
                else
                {
                    IWebElement PBP_ele = Browser.Wd.FindElement(By.XPath("//select[@test-id='PBP']"));
                    SelectElement PBP_DD = new SelectElement(PBP_ele);
                    PBP_DD.SelectByText(pbpValue);
                }
            }
        }

        [Then(@"on Transaction Summary Search Criteria page TransCode is set to ""(.*)""")]
        public void ThenOnTransactionSummarySearchCriteriaPageTransCodeIsSetTo(string p0)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(1);
                
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='TransCode']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + p0 + "']");

                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
            }
            else
            {
                IWebElement TransCode = Browser.Wd.FindElement(By.XPath("//select[@test-id='TransCode']"));
                SelectElement TransCode_DD = new SelectElement(TransCode);
                TransCode_DD.SelectByText(p0);
            }
        }

        [Then(@"on Transaction Summary Search Criteria page StatusCode is set to ""(.*)""")]
        public void ThenOnTransactionSummarySearchCriteriaPageStatusCodeIsSetTo(string p0)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(1);
                
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='transStatusCode']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + p0 + "']");

                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
            }
            else
            {
                IWebElement StatusCode = Browser.Wd.FindElement(By.XPath("//select[@test-id='transStatusCode']"));
                SelectElement StatusCode_DD = new SelectElement(StatusCode);
                StatusCode_DD.SelectByText(p0);
            }
        }

        [Then(@"on Transaction Summary Search Criteria page SalesRepName is set to ""(.*)""")]
        public void ThenOnTransactionSummarySearchCriteriaPageSalesRepNameIsSetTo(string p0)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(1);
                
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='RepId']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + p0 + "']");

                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
            }
            else
            {
                IWebElement SalesRepName = Browser.Wd.FindElement(By.XPath("//select[@test-id='RepId']"));
                SelectElement SalesRepName_DD = new SelectElement(SalesRepName);
                SalesRepName_DD.SelectByText(p0);
            }
        }

        [Then(@"on Transaction Summary Search Criteria page SalesLocation is set to ""(.*)""")]
        public void ThenOnTransactionSummarySearchCriteriaPageSalesLocationIsSetTo(string p0)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(1);
                
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='SalesLocation']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + p0 + "']");

                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
            }
            else
            {
                IWebElement SalesLocation = Browser.Wd.FindElement(By.XPath("//select[@test-id='SalesLocation']"));
                SelectElement SalesLocation_DD = new SelectElement(SalesLocation);
                SalesLocation_DD.SelectByText(p0);
            }
        }

        [Then(@"on Transaction Summary Search Criteria page SubmissionMethod is set to ""(.*)""")]
        public void ThenOnTransactionSummarySearchCriteriaPageSubmissionMethodIsSetTo(string p0)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(1);
                
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='SubmissionMethod']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + p0 + "']");

                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
            }
            else
            {
                IWebElement SubmissionMethod = Browser.Wd.FindElement(By.XPath("//select[@test-id='SubmissionMethod']//input"));
                SelectElement SubmissionMethod_DD = new SelectElement(SubmissionMethod);
                SubmissionMethod_DD.SelectByText(p0);
            }
        }

        [Then(@"on Transaction Summary Search Criteria page Effective Date From ""(.*)"" is selected")]
        public void ThenOnTransactionSummarySearchCriteriaPageEffectiveDateFromIsSelected(string p0)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(1);
                
                string value = p0.Replace("/", "");
                By Drp = By.XPath("//kendo-datepicker[@test-id='EffectiveDate']//input");
                Browser.Wd.FindElement(Drp).Clear();
                Browser.Wd.FindElement(Drp).SendKeys(value);

                tmsWait.Hard(3);
            }
            else
            {
                IWebElement EffDateFrom = Browser.Wd.FindElement(By.XPath("//input[@test-id='EffectiveDate']"));
                string GeneratedData = tmsCommon.GenerateData(p0.ToString());
                fw.ExecuteJavascriptSetText(EffDateFrom, GeneratedData);
            }
        }

        [Then(@"on Search Criteria page Effective Date To ""(.*)"" is selected")]
        public void ThenOnSearchCriteriaPageEffectiveDateToIsSelected(string p0)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(1);
                
                string value = p0.Replace("/", "");
                By Drp = By.XPath("//kendo-datepicker[@test-id='EndDate']//input");
                Browser.Wd.FindElement(Drp).Clear();
                Browser.Wd.FindElement(Drp).SendKeys(value);

                tmsWait.Hard(3);
            }
            else
            {
                IWebElement EffDateTo = Browser.Wd.FindElement(By.XPath("//input[@test-id='EndDate']"));
                string GeneratedData = tmsCommon.GenerateData(p0.ToString());
                fw.ExecuteJavascriptSetText(EffDateTo, GeneratedData);
            }
        }

        [Then(@"on Search Criteria page Source is set to ""(.*)""")]
        public void ThenOnSearchCriteriaPageSourceIsSetTo(string p0)
        {
            IWebElement sourceElement = Browser.Wd.FindElement(By.XPath("//select[@test-id='ProgramSource']"));
            SelectElement Source_DD = new SelectElement(sourceElement);
            Source_DD.SelectByText(p0);
        }


        [Then(@"on Search Criteria page Transaction Start Date is set to ""(.*)""")]
        public void ThenOnSearchCriteriaPageTransactionStartDateIsSetTo(string p0)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(1);
                
                string value = tmsCommon.GenerateData(p0);
                By Drp = By.XPath("//kendo-datepicker[@test-id='EffStartDate']//span[@role='button']");
                //Browser.Wd.FindElement(Drp).Clear();
                //Browser.Wd.FindElement(Drp).SendKeys(value);
                AngularFunction.enterDate(Drp, value);

                tmsWait.Hard(3);
            }
            else
            {
                IWebElement EffStartDate = Browser.Wd.FindElement(By.XPath("//input[@test-id='EffStartDate']"));
                string GeneratedData = tmsCommon.GenerateData(p0.ToString());
                tmsWait.Hard(1);
                fw.ExecuteJavascript(EffStartDate);
                fw.ExecuteJavascriptSetText(EffStartDate, GeneratedData);
            }
        }

        [Then(@"on Search Criteria page Transaction End Date is set to ""(.*)""")]
        public void ThenOnSearchCriteriaPageTransactionEndDateIsSetTo(string p0)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(1);
                
                string value = tmsCommon.GenerateData(p0);
                By Drp = By.XPath("//kendo-datepicker[@test-id='EffEndDate']//span[@role='button']");
                //Browser.Wd.FindElement(Drp).Clear();
                //Browser.Wd.FindElement(Drp).SendKeys(value);
                AngularFunction.enterDate(Drp, value);

                tmsWait.Hard(3);
            }
            else
            {
                IWebElement EffEndDate = Browser.Wd.FindElement(By.XPath("//input[@test-id='EffEndDate']"));
                string GeneratedData = tmsCommon.GenerateData(p0.ToString());
                tmsWait.Hard(1);
                fw.ExecuteJavascript(EffEndDate);
                fw.ExecuteJavascriptSetText(EffEndDate, GeneratedData);
            }
        }


        [Then(@"on Transaction Summary Search Criteria page Effective Date To is selected")]
        public void ThenOnTransactionSummarySearchCriteriaPageEffectiveDateToIsSelected()
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(1);

                DateTime date = DateTime.Now;
                string currentDate = date.ToString("MM/dd/yyyy");
                string value = tmsCommon.GenerateData(currentDate);
                By Drp = By.XPath("//kendo-datepicker[@test-id='EndDate']//span[@role='button']");
                //Browser.Wd.FindElement(Drp).Clear();
                //Browser.Wd.FindElement(Drp).SendKeys(value);
                AngularFunction.enterDate(Drp, value);

                tmsWait.Hard(3);
            }
            else
            {
                IWebElement EffDateTo = Browser.Wd.FindElement(By.XPath("//input[@test-id='EndDate']"));
                DateTime date = DateTime.Now;
                string currentDate = date.ToString("MM/dd/yyyy");
                tmsWait.Hard(2);
                fw.ExecuteJavascriptSetText(EffDateTo, currentDate);
            }
        }

        [Then(@"on Transaction Summary Search Criteria page SalesStartDate is set to ""(.*)""")]
        public void ThenOnTransactionSummarySearchCriteriaPageSalesStartDateIsSetTo(string p0)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(1);
                
                string value = tmsCommon.GenerateData(p0);
                By Drp = By.XPath("//kendo-datepicker[@test-id='salesStartDate']//span[@role='button']");
                //Browser.Wd.FindElement(Drp).Clear();
                //Browser.Wd.FindElement(Drp).SendKeys(value);
                AngularFunction.enterDate(Drp, value);

                tmsWait.Hard(3);
            }
            else
            {
                IWebElement SalesStartDate = Browser.Wd.FindElement(By.XPath("//input[@test-id='salesStartDate']"));
                string GeneratedData = tmsCommon.GenerateData(p0.ToString());
                fw.ExecuteJavascriptSetText(SalesStartDate, GeneratedData);
            }
        }


        [Then(@"on Transaction Summary Search Criteria page SalesEndDate is selected")]
        public void ThenOnTransactionSummarySearchCriteriaPageSalesEndDateIsSelected()
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(1);
                
                DateTime date = DateTime.Now;
                string currentDate = date.ToString("MM/dd/yyyy");
                string value = tmsCommon.GenerateData(currentDate);
                By Drp = By.XPath("//kendo-datepicker[@test-id='salesEndDate']//span[@role='button']");
                //Browser.Wd.FindElement(Drp).Clear();
                //Browser.Wd.FindElement(Drp).SendKeys(value);
                AngularFunction.enterDate(Drp, value);

                tmsWait.Hard(3);
            }
            else
            {
                IWebElement SalesEndDate = Browser.Wd.FindElement(By.XPath("//input[@test-id='salesEndDate']"));
                DateTime date = DateTime.Now;
                string currentDate = date.ToString("MM/dd/yyyy");
                tmsWait.Hard(2);
                fw.ExecuteJavascriptSetText(SalesEndDate, currentDate);
            }
        }



        [Then(@"on Transaction Summary Search Criteria page PBPId is set to ""(.*)""")]
        public void ThenOnTransactionSummarySearchCriteriaPagePBPIdIsSetTo(string p0)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(1);
                
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='PBP_ID']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + p0 + "']");

                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
            }
            else
            {
                IWebElement PBPId = Browser.Wd.FindElement(By.XPath("//select[@test-id='PBP_ID']"));
                SelectElement PBPId_DD = new SelectElement(PBPId);
                PBPId_DD.SelectByText(p0);
            }
        }

        [Then(@"on Search Criteria page File Name is set to ""(.*)""")]
        public void ThenOnSearchCriteriaPageFileNameIsSetTo(string p0)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(1);
                
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='Fileid']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + p0 + "']");

                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
            }
            else
            {
                SelectElement NoRxFileName_DD = new SelectElement(RAM.RAMReportPage.NoRxFileName);
                NoRxFileName_DD.SelectByText(p0);
            }
        }

        [Then(@"on Search Criteria page Error Reason is set to ""(.*)""")]
        public void ThenOnSearchCriteriaPageErrorReasonIsSetTo(string p0)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(1);
                
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='Reasonid']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + p0 + "']");

                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
            }
            else
            {
                SelectElement NoRxErrReason_DD = new SelectElement(RAM.RAMReportPage.NoRxErrorReason);
                NoRxErrReason_DD.SelectByText(p0);
            }
        }


        [Then(@"on Search Criteria page MemberStatus is set to ""(.*)""")]
        public void ThenOnSearchCriteriaPageMemberStatusIsSetTo(string p0)
        {
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                tmsWait.Hard(2);
                new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@id='ReportViewerControl_ctl04_ctl09_ddValue']"))).SelectByText(p0);
            }
            else
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    tmsWait.Hard(1);
                    
                    By Drp = By.XPath("//kendo-dropdownlist[@test-id='MemberStatus']//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + p0 + "']");

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                }
                else
                {
                    IWebElement MemberStatus = Browser.Wd.FindElement(By.XPath("//select[@test-id='MemberStatus']"));
                    SelectElement MemberStatus_DD = new SelectElement(MemberStatus);
                    MemberStatus_DD.SelectByText(p0);
                }
            }
        }

        [Then(@"on Search Criteria page Effective_From is set to ""(.*)""")]
        public void ThenOnSearchCriteriaPageEffective_FromIsSetTo(string p0)
        {
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                tmsWait.Hard(2);



                try {

                    IWebElement Effective_From = Browser.Wd.FindElement(By.CssSelector("[id='ReportViewerControl_ctl04_ctl09_txtValue']"));
                    Effective_From.SendKeys(p0);
                    Effective_From.SendKeys(Keys.Tab);

                }
                catch
                {
                    IWebElement Effective_From = Browser.Wd.FindElement(By.CssSelector("[id='ReportViewerControl_ctl04_ctl11_txtValue']"));
                    Effective_From.SendKeys(p0);
                    Effective_From.SendKeys(Keys.Tab);

                }
            }
            if (ConfigFile.EnvType.Equals("Main"))
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    tmsWait.Hard(1);
                    
                    string value = tmsCommon.GenerateData(p0);
                    By Drp = By.XPath("//kendo-datepicker[@test-id='Effective_From']//span[@role='button']");
                    //Browser.Wd.FindElement(Drp).Clear();
                    //Browser.Wd.FindElement(Drp).SendKeys(value);
                    AngularFunction.enterDate(Drp, value);
                    tmsWait.Hard(3);
                }
                else
                {
                    //IWebElement Effective_From = Browser.Wd.FindElement(By.XPath("//input[@test-id='EffectiveStartDate']"));
                    //string GeneratedData = tmsCommon.GenerateData(p0.ToString());
                    //fw.ExecuteJavascriptSetText(Effective_From, GeneratedData);
                    string GeneratedData = tmsCommon.GenerateData(p0.ToString());
                    ReUsableFunctions.selectDateFromDateField(GeneratedData);
                }


            }

        }


        [Then(@"on Search Criteria page Effective_To is set to ""(.*)""")]
        public void ThenOnSearchCriteriaPageEffective_ToIsSetTo(string p0)
        {
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                tmsWait.Hard(2);
                try
                {
                    IWebElement Effective_To = Browser.Wd.FindElement(By.XPath("//input[@name='ReportViewerControl$ctl04$ctl13$txtValue']"));
                    Effective_To.SendKeys(p0);
                    Effective_To.SendKeys(Keys.Tab);
                }
                catch
                {
                    IWebElement Effective_To = Browser.Wd.FindElement(By.CssSelector("[id='ReportViewerControl_ctl04_ctl13_txtValue']"));
                    Effective_To.SendKeys(p0);
                    Effective_To.SendKeys(Keys.Tab);
                }
            }
            else
            {

                if (ConfigFile.EnvType.Equals("Main"))
                {
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        tmsWait.Hard(1);
                        
                        string value = tmsCommon.GenerateData(p0);
                        By Drp = By.XPath("//kendo-datepicker[@test-id='Effective_To']//span[@role='button']");
                        //Browser.Wd.FindElement(Drp).Clear();
                        //Browser.Wd.FindElement(Drp).SendKeys(value);
                        AngularFunction.enterDate(Drp, value);

                        tmsWait.Hard(3);
                    }
                    else
                    {
                        //IWebElement Effective_From = Browser.Wd.FindElement(By.XPath("//input[@test-id='EffectiveStartDate']"));
                        //string GeneratedData = tmsCommon.GenerateData(p0.ToString());
                        //fw.ExecuteJavascriptSetText(Effective_From, GeneratedData);
                        string GeneratedData = tmsCommon.GenerateData(p0.ToString());
                        ReUsableFunctions.selectDateEndDateField(GeneratedData);
                    }


                }
            }
        }





        [Then(@"on Search Criteria page PWOption is set to ""(.*)""")]
        public void ThenOnSearchCriteriaPagePWOptionIsSetTo(string p0)
        {
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                tmsWait.Hard(2);
                new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@id='ReportViewerControl_ctl04_ctl09_ddValue']"))).SelectByValue("1");
            }
            else
            {
                tmsWait.Hard(2);
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    tmsWait.Hard(1);
                    
                    By Drp = By.XPath("//kendo-dropdownlist[@test-id='PWOption']//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + p0 + "']");

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                }
                else
                {
                    IWebElement PWOoption = Browser.Wd.FindElement(By.XPath("//select[@test-id='PWOption']"));
                    SelectElement PWOoption_DD = new SelectElement(PWOoption);
                    PWOoption_DD.SelectByText(p0);
                }
            }
        }

        [Then(@"Verify on Search Criteria page Action/Notes dropdown has All values ""(.*)"" and ""(.*)"" and ""(.*)""")]
        public void ThenVerifyOnSearchCriteriaPageActionNotesDropdownHasAllValuesAndAnd(string p0, string p1, string p2)
        {
            tmsWait.Hard(2);
            IWebElement Action_Note = Browser.Wd.FindElement(By.XPath("//select[@test-id='Action_Note']"));
            SelectElement Action_Note_ele = new SelectElement(Action_Note);
            Action_Note_ele.SelectByText(p0);
            tmsWait.Hard(1);
            Action_Note_ele.SelectByText(p1);
            tmsWait.Hard(1);
            Action_Note_ele.SelectByText(p2);
            tmsWait.Hard(1);
            Action_Note_ele.SelectByText(p0);
        }
        [Then(@"Verify on Search Criteria page File dropdown has All values ""(.*)"" and ""(.*)""")]
        public void ThenVerifyOnSearchCriteriaPageFileDropdownHasAllValuesAnd(string p0, string p1)
        {
            tmsWait.Hard(2);
            IWebElement Action_Note = Browser.Wd.FindElement(By.XPath("//select[@test-id='Action_Note']"));
            SelectElement Action_Note_ele = new SelectElement(Action_Note);
            Action_Note_ele.SelectByText(p0);

            Action_Note_ele.SelectByText(p0);
        }
        [Then(@"Verify on Search Criteria page transaction code dropdown has All Transaction code")]
        public void ThenVerifyOnSearchCriteriaPageTransactionCodeDropdownHasAllTransactionCode()
        {

            tmsWait.Hard(2);
            IWebElement Action_Note = Browser.Wd.FindElement(By.XPath("//select[@test-id='Action_Note']"));
            SelectElement Action_Note_ele = new SelectElement(Action_Note);

        }
        [Then(@"Verify on Search Criteria page status dropdown has All values ""(.*)"" and ""(.*)"" and ""(.*)""")]
        public void ThenVerifyOnSearchCriteriaPageStatusDropdownHasAllValuesAndAnd(string p0, string p1, string p2)
        {
            tmsWait.Hard(2);
            IWebElement Action_Note = Browser.Wd.FindElement(By.XPath("//select[@test-id='Action_Note']"));
            SelectElement Action_Note_ele = new SelectElement(Action_Note);
            Action_Note_ele.SelectByText(p0);

            Action_Note_ele.SelectByText(p0);
        }

        [When(@"on Search Criteria page UserCreated is set to ""(.*)""")]
        [Then(@"on Search Criteria page UserCreated is set to ""(.*)""")]
        public void ThenOnSearchCriteriaPageUserCreatedIsSetTo(string p0)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(1);
                
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='UserCreated']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + p0 + "']");

                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
            }
            else
            {
                IWebElement UserCreatedOption = Browser.Wd.FindElement(By.XPath("//select[@test-id='UserCreated']"));
                SelectElement UserCreated_DD = new SelectElement(UserCreatedOption);
                UserCreated_DD.SelectByText(p0);
            }
        }

        [Then(@"on Search Criteria page SegmentID is set to ""(.*)""")]
        public void ThenOnSearchCriteriaPageSegmentIDIsSetTo(string p0)
        {
            IWebElement SegmentIDOption = Browser.Wd.FindElement(By.XPath("//select[@test-id='SegmentID']"));
            SelectElement SegmentID_DD = new SelectElement(SegmentIDOption);
            SegmentID_DD.SelectByText(p0);
        }

        [Then(@"on Search Criteria page LEP Letter Sent is set to ""(.*)""")]
        public void ThenOnSearchCriteriaPageLEPLetterSentIsSetTo(string p0)
        {
            IWebElement LEPLetter = Browser.Wd.FindElement(By.XPath("//select[@test-id='LetterCode']"));
            SelectElement LEPLetter_DD = new SelectElement(LEPLetter);
            LEPLetter_DD.SelectByText(p0);
        }

        [Then(@"on Search Criteria page Due Days is set to ""(.*)""")]
        public void ThenOnSearchCriteriaPageDueDaysIsSetTo(string p0)
        {
            IWebElement DueDays = Browser.Wd.FindElement(By.XPath("//select[@test-id='LetterCode']"));
            SelectElement DueDays_DD = new SelectElement(DueDays);
            DueDays_DD.SelectByText(p0);
        }
        [When(@"Report Page ""(.*)"" link is Clicked")]
        public void WhenReportPageLinkIsClicked(string link)
        {
            tmsWait.Hard(10);

            GlobalRef.JobName = "Reports";

            // fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//li[@test-id='import-li-joblist']/label[contains(.,'" + link + "')]")));
        }
        [When(@"Search Criteria page Run Interactively ""(.*)"" option is clicked")]
        [Then(@"Search Criteria page Run Interactively ""(.*)"" option is clicked")]
        [Given(@"Search Criteria page Run Interactively ""(.*)"" option is clicked")]
        public void ThenSearchCriteriaPageRunInteractivelyOptionIsClicked(string interactiveOption)
        {
            tmsWait.Hard(2);
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                fw.ConsoleReport(" There is no Option button");
            }
            else
            {
                if (interactiveOption.ToLower().Equals("yes"))
                {
                    IWebElement elem = Browser.Wd.FindElement(By.Id("rdInteractiveYes"));
                    fw.ExecuteJavascript(elem);
                    tmsWait.Hard(5);

                    GlobalRef.winium = "Interactive";
                }
                else
                {
                    IWebElement elem = Browser.Wd.FindElement(By.Id("rdInteractiveNo"));
                    fw.ExecuteJavascript(elem);
                    tmsWait.Hard(5);

                    GlobalRef.winium = "NonInteractive";
                }
              
            }


        }

        [Then(@"RAM report page Project DropDown is set to ""(.*)""")]
        public void ThenRAMReportPageProjectDropDownIsSetTo(string p0)
        {
            string ProjName = tmsCommon.GenerateData(p0);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='EvalDateProjID']//span[@class='k-select']");
            By typeapp = By.XPath("//li[contains(.,'" + ProjName + "')]");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }


        
        [When(@"PIR Extract By Control Number page ""(.*)"" option is selected")]
        public void WhenPIRExtractByControlNumberPageOptionIsSelected(string p0)
        {
            if (p0.ToLower().Equals("Update PIR"))
            {
                IWebElement elem = Browser.Wd.FindElement(By.Id("1"));
                fw.ExecuteJavascript(elem);
                tmsWait.Hard(5);
            }
            else
            {
                IWebElement elem = Browser.Wd.FindElement(By.Id("2"));
                fw.ExecuteJavascript(elem);
                tmsWait.Hard(5);
            }
        }


        [Then(@"RAM report page View Report button is Clicked")]
        public void ThenRAMReportPageViewReportButtonIsClicked()
        {
            RAM.CMSFileDetailsReport.ViewReport.Click();
        }

        [Then(@"on Search Criteria page HIC Member is set to ""(.*)""")]
        public void ThenOnSearchCriteriaPageHICMemberIsSetTo(string p0)
        {
            IWebElement mbi = Browser.Wd.FindElement(By.XPath("//input[@test-id='Hic']")); //field identifiers are the same in both tms and tmsx tenants
            string content = tmsCommon.GenerateData(p0);
            mbi.SendKeys(content);
        }



        [Then(@"Search Criteria page Start date is selected as ""(.*)""")]
        public void ThenSearchCriteriaPageStartDateIsSelectedAs(string p0)
        {
            bool valid = false;
            string expDate = tmsCommon.GenerateData(p0);

            if (expDate.Equals("First Day of Month"))
            {
                expDate = "01/01/2020";
            }
            else if (expDate.Equals("Today"))
            {
                expDate = UIMODUtilFunctions.returnDateFormatDDMMYYYY();
            }
            while (!valid)
            {
                IWebElement date = Browser.Wd.FindElement(By.XPath("(//span[@class='k-dateinput-wrap']/input[@placeholder])[1]"));
               string newValue= expDate.Replace("/", "");
                date.Clear();
                date.SendKeys(newValue);             
              
                
                string fieldDate = Browser.Wd.FindElement(By.XPath("(//span[@class='k-dateinput-wrap']/input)[1]")).GetAttribute("value");


                if (!(fieldDate.Contains("MM/dd")) && !(fieldDate.Contains("/dd")) && !(fieldDate.Contains("/yyyy")) && !(fieldDate.Contains("/yyyy")) && !(fieldDate.Contains("/day")))
                {
                    try
                    {
                        IWebElement runReport = Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-runReport']"));
                        fw.ExecuteJavascript(runReport);
                        tmsWait.Hard(2);
                        bool errorMessage = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Invalid date Range')]")).Displayed;
                        date.Clear();
                        date.SendKeys("2019");
                        valid = false;
                    }
                    catch
                    {
                        valid = true;

                    }

                }

            }

           

            //DateTime date = DateTime.Now;
            //DateTime firstDayOfMonth = new DateTime(date.Year, date.Month, 1);
            //string startDate = firstDayOfMonth.ToString("MM/dd/yyyy");
            //tmsWait.Hard(2);
            //fw.ExecuteJavascriptSetText(RAM.DataLoadDetailReport.StartDatePicker, startDate);
        }

        [Then(@"Search Criteria page End date is selected as ""(.*)""")]
        public void ThenSearchCriteriaPageEndDateIsSelectedAs(string p0)
        {

            bool valid = false;
            string expDate = tmsCommon.GenerateData(p0);

            if (expDate.Equals("First Day of Month"))
            {
                expDate = "01/01/2020";
            }
            else if (p0.Equals("TodayDate"))
            {
                expDate=UIMODUtilFunctions.returnCurrentDateAndTime();

            }
            while (!valid)
            {
                IWebElement date = Browser.Wd.FindElement(By.XPath("(//span[@class='k-dateinput-wrap']/input)[2]"));
                string newValue = expDate.Replace("/", "");
                date.Clear();
                date.SendKeys(newValue);

                string fieldDate = Browser.Wd.FindElement(By.XPath("(//span[@class='k-dateinput-wrap']/input)[1]")).GetAttribute("value");



                if (!(fieldDate.Contains("MM/dd")) && !(fieldDate.Contains("/dd")) && !(fieldDate.Contains("/yyyy")) && !(fieldDate.Contains("/yyyy")) && !(fieldDate.Contains("/day")))
                {
                    try
                    {
                        IWebElement runReport = Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-runReport']"));
                        fw.ExecuteJavascript(runReport);
                        tmsWait.Hard(2);
                        bool errorMessage = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Invalid date Range')]")).Displayed;
                        date.Clear();
                        date.SendKeys("2021");
                        valid = false;
                    }
                    catch
                    {
                        valid = true;

                    }

                }
            }
               

            
        }

        [Then(@"Search Criteria PIR Result page Start date is selected as ""(.*)""")]
        public void ThenSearchCriteriaPIRResultPageStartDateIsSelectedAs(string p0)
        {

            IWebElement start = Browser.Wd.FindElement(By.XPath("//div/input[@test-id='fromDate']/parent::div//button"));
            fw.ExecuteJavascript(start);
            tmsWait.Hard(3);
            IWebElement pick = Browser.Wd.FindElement(By.XPath("(//table[@role='grid']//td//button)[1]"));
            fw.ExecuteJavascript(pick);


            //DateTime date = DateTime.Now;
            //DateTime firstDayOfMonth = new DateTime(date.Year, date.Month, 1);
            //string startDate = firstDayOfMonth.ToString("MM/dd/yyyy");
            //tmsWait.Hard(2);

            //fw.ExecuteJavascriptSetText(RAM.PIRResultSummary.StartDatePicker, startDate);
        }

        [Then(@"Search Criteria PIR Result page End date is selected as ""(.*)""")]
        public void ThenSearchCriteriaPIRResultPageEndDateIsSelectedAs(string p0)
        {
            IWebElement start = Browser.Wd.FindElement(By.XPath("//div/input[@test-id='ToDate']/parent::div//button"));
            fw.ExecuteJavascript(start);
            tmsWait.Hard(3);
            IWebElement pick = Browser.Wd.FindElement(By.XPath("(//table[@role='grid']//td//button)[30]"));
            fw.ExecuteJavascript(pick);

            //DateTime date = DateTime.Now;
            //string currentDate = date.ToString("MM/dd/yyyy");
            //tmsWait.Hard(2);
            //fw.ExecuteJavascriptSetText(RAM.DataLoadDetailReport.EndDatePicker, currentDate);
        }

        [Then(@"Search Criteria report page Start date is selected as ""(.*)""")]
        public void ThenSearchCriteriaReportPageStartDateIsSelectedAs(string p0)
        {
            string currentyr = DateTime.Now.Year.ToString();

            IWebElement start = Browser.Wd.FindElement(By.XPath("//div/input[@test-id='fromDate']/parent::div//button"));
            fw.ExecuteJavascript(start);
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[contains(@id,'datepicker')]")));
            tmsWait.Hard(1);
            string yr = Browser.Wd.FindElement(By.XPath("//button[contains(@id,'datepicker')]/strong")).Text;
            if (currentyr == yr)
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'January')]")));
                tmsWait.Hard(1);
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//span[contains(.,'01')]/parent::button)[1]")));
                tmsWait.Hard(2);
            }


        }


        [Then(@"Search Criteria PIR Result page Payment Year is set to ""(.*)""")]
        public void ThenSearchCriteriaPIRResultPagePaymentYearIsSetTo(int p0)
        {
            //SelectElement planid = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@test-id='PaymentYear']")));
            //planid.SelectByText(p0.ToString());
            string yearselected = p0.ToString();
            new SelectElement(Browser.Wd.FindElement(By.CssSelector("[test-id='PaymentYear']"))).SelectByText(yearselected);
        }

        [Then(@"on Search Criteria page MemCodNum ""(.*)"" is entered")]
        public void ThenOnSearchCriteriaPageMemCodNumIsEntered(string p0)
        {
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                string memcod = tmsCommon.GenerateData(p0);

                By loc = By.CssSelector("[id='ReportViewerControl_ctl04_ctl03_txtValue']");

                UIMODUtilFunctions.enterValueOnWebElementUsingLocators(loc, memcod);


            }
        }

        [Then(@"on Search Criteria page PlanId ""(.*)"" is entered")]
        public void ThenOnSearchCriteriaPagePlanIdIsEntered(string p0)
        {
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                string PLAN = tmsCommon.GenerateData(p0);

                new SelectElement(Browser.Wd.FindElement(By.CssSelector("[id='ReportViewerControl_ctl04_ctl05_ddValue']"))).SelectByText(PLAN);

            }
        }

        [Then(@"on Search Criteria page EffectiDateFrom ""(.*)"" is entered")]
        public void ThenOnSearchCriteriaPageEffectiDateFromIsEntered(string p0)
        {
            tmsWait.Hard(3);
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                string memcod = tmsCommon.GenerateData(p0);

                By loc = By.CssSelector("[id='ReportViewerControl_ctl04_ctl21_txtValue']");

                UIMODUtilFunctions.enterValueOnWebElementUsingLocators(loc, memcod);


            }

        }

        [Then(@"on Search Criteria page EffectiDateTo ""(.*)"" is entered")]
        public void ThenOnSearchCriteriaPageEffectiDateToIsEntered(string p0)
        {
            tmsWait.Hard(3);
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                string memcod = tmsCommon.GenerateData(p0);

                By loc = By.CssSelector("[id='ReportViewerControl_ctl04_ctl23_txtValue']");

                UIMODUtilFunctions.enterValueOnWebElementUsingLocators(loc, memcod);


            }
        }

        [Then(@"on Search Criteria page Sales Start Date ""(.*)"" is entered")]
        public void ThenOnSearchCriteriaPageSalesStartDateIsEntered(string p0)
        {
            tmsWait.Hard(3);
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                string memcod = tmsCommon.GenerateData(p0);

                By loc = By.CssSelector("[id='ReportViewerControl_ctl04_ctl25_txtValue']");

                UIMODUtilFunctions.enterValueOnWebElementUsingLocators(loc, memcod);


            }
        }

        [Then(@"on Search Criteria page Sales End Date ""(.*)"" is entered")]
        public void ThenOnSearchCriteriaPageSalesEndDateIsEntered(string p0)
        {
            tmsWait.Hard(3);
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                string memcod = tmsCommon.GenerateData(p0);

                By loc = By.CssSelector("[id='ReportViewerControl_ctl04_ctl27_txtValue']");

                UIMODUtilFunctions.enterValueOnWebElementUsingLocators(loc, memcod);


            }
        }

        [When(@"Member Name is selected from Search Member Lookup")]
        public void WhenMemberNameIsSelectedFromSearchMemberLookup()
        {
            tmsWait.Hard(2);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                UIMODUtilFunctions.clickOnWebElementUsingLocators(By.XPath("//span[@test-id='report-link-group']//a"));
            }
            else
            {
                fw.ExecuteJavascript(RAM.RAMReportPage.MemberIDSearchButton);
            }
            tmsWait.Hard(2);
            //tmsWait.Implicit(240);
            fw.ExecuteJavascript(RAM.DeleteSubmittedDiagCodes.MemberLookUpSearchButton);
            // .Click();
            tmsWait.Hard(2);
            //select the first member checkbox
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                UIMODUtilFunctions.clickOnWebElementUsingLocators(By.XPath("//*[@id='auditMembersListGrid']//div/table/tbody/tr[1]/td[1]/input"));
            }
            else
            {
                fw.ExecuteJavascript(RAM.RAMReportPage.FirstMemberRecord_CheckBox);
            }
            tmsWait.Hard(1);
            fw.ExecuteJavascript(RAM.DeleteSubmittedDiagCodes.AddButton);
            tmsWait.Hard(2);
        }


        [Then(@"on Search Criteria page member id is entered")]
        public void ThenOnSearchCriteriaPageMemberIdIsEntered()
        {
            if (ConfigFile.EnvType.Equals("ESI"))
            {

            }
            else
            {
                tmsWait.Hard(2);
                fw.ExecuteJavascript(RAM.RAMReportPage.MemberIDSearchButton);
                tmsWait.Hard(2);
                //tmsWait.Implicit(240);
                fw.ExecuteJavascript(RAM.DeleteSubmittedDiagCodes.MemberLookUpSearchButton);
                // .Click();
                tmsWait.Hard(2);
                fw.ExecuteJavascript(RAM.RAMReportPage.FirstMemberRecord_CheckBox);
                tmsWait.Hard(1);
                RAM.DeleteSubmittedDiagCodes.AddButton.Click();

            }

        }





        [Then(@"Search Criteria page First Member ID is selected")]
        public void ThenSearchCriteriaPageFirstMemberIDIsSelected()
        {
            tmsWait.Hard(2);
            RAM.AssignmentHistoryReport.MemberIDLookup.Click();
            tmsWait.Hard(10);
            //tmsWait.WaitForElement(By.CssSelector("[test-id='lookup-btn-Search']"), 200);
            RAM.AssignmentHistoryReport.SearchMemberButton.Click();
            IWebElement res = Browser.Wd.FindElement(By.XPath("//div[@test-id='lookup-grid-searchresult']//tbody/tr[1]"));
            fw.ExecuteJavascript(res);
            tmsWait.Hard(2);
            //tmsWait.WaitForElement(By.XPath("//td[@role='gridcell']/span"), 200);
            RAM.AssignmentHistoryReport.BackButton.Click();
            //tmsWait.WaitForElement(By.CssSelector("[test-id='report-btn-runReport']"), 200);
        }

        [Then(@"RAM report page ""(.*)"" is set to ""(.*)""")]
        public void ThenRAMReportPageIsSetTo(string p0, string p1)
        {
            string field = p0.ToString();
            switch (field)
            {
                case "Start Date":
                    RAM.CMSFileDetailsReport.startdate.SendKeys(p1);
                    break;
                case "End Date":
                    RAM.CMSFileDetailsReport.enddate.SendKeys(p1);
                    break;
                case "Min Date":
                    Browser.SwitchToChildWindow();
                    RAM.CMSFileDetailsReport.MinDate.SendKeys(p1);
                    break;
                case "Max Date":
                    Browser.SwitchToChildWindow();
                    RAM.CMSFileDetailsReport.MaxDate.SendKeys(p1);
                    break;
            }
        }

        public void reportContentNotPresent(string content)
        {
            tmsWait.Hard(5);
            string pagesounce = Browser.Wd.FindElement(By.TagName("body")).Text;
            if ((pagesounce.Contains(content)) || (pagesounce.Contains(content.ToUpper())))
            {
                Assert.Fail("Content is Present on Report");

            }

        }

        public void reportContentNotPresentVerification(string content)
        {

            tmsWait.Hard(5);

            string pagesounce = Browser.Wd.FindElement(By.TagName("body")).Text;
            if (!(pagesounce.Contains(content)) && !(pagesounce.Contains(content.ToUpper())))
            {
                Assert.IsTrue(true, content + "is not found on Report");
                fw.ConsoleReport(content + " is not found on Report");

            }
            else
            {
                Assert.Fail("Report Content is incorrect...");
            }

        }
        public void reportContentVerification(string content)
        {
            tmsWait.Hard(5);
            Browser.SwitchToChildWindow();
            string pagesounce = Browser.Wd.FindElement(By.TagName("body")).Text;
            tmsWait.Hard(6);
            if (pagesounce.Contains(content) || pagesounce.Contains(content.ToUpper()))
            {
                Assert.IsTrue(true, content + "is found on Report");
                fw.ConsoleReport(content + " is found on Report");

            }
            else
            {
                Assert.Fail("Report Content is incorrect...");
            }
        }

        [When(@"Quarterly Enrollment Compliance Report Total Enrollments Received A Column is noted")]
        [Then(@"Quarterly Enrollment Compliance Report Total Enrollments Received A Column is noted")]
        public void WhenQuarterlyEnrollmentComplianceReportTotalEnrollmentsReceivedAColumnIsNoted()
        {
            //IWebElement ColAInit = Browser.Wd.FindElement(By.XPath("((//table[@role='presentation'])[2]//table[1]//tr[11]/td[5]/div/div)[1]"));
            IWebElement ColAInit = Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']/table/tbody/tr/td//table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td[3]/table/tbody/tr[11]/td[5]/div"));
            tmsWait.Hard(1);
            GlobalRef.TotalEnrlReceivedAInit = Int32.Parse(ColAInit.Text);
            Console.WriteLine(" TotalEnrlReceivedAInit -->" + ColAInit.Text);
        }

        [When(@"Quarterly Enrollment Compliance Report Total Enrollments Denied D Column is noted")]
        public void WhenQuarterlyEnrollmentComplianceReportTotalEnrollmentsDeniedDColumnIsNoted()
        {
            IWebElement ColDInit = Browser.Wd.FindElement(By.XPath("((//table[@role='presentation'])[2]//table[1]//tr[11]/td[6]/div/div)[2]"));
            tmsWait.Hard(2);
            GlobalRef.TotalEnrollmentsDeniedColD_Init = ColDInit.Text;
            Console.WriteLine(" TotalEnrollmentsDeniedColD_Init -->" + ColDInit.Text);
        }

        [When(@"Quarterly Enrollment Compliance Report Total Enrollments Denied F Column is noted")]
        public void WhenQuarterlyEnrollmentComplianceReportTotalEnrollmentsDeniedFColumnIsNoted()
        {
            IWebElement ColFInit = Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']/table/tbody/tr/td//table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td/table/tbody/tr[6]/td[2]/table/tbody/tr[11]/td[6]/div"));
            tmsWait.Hard(2);
            GlobalRef.TotalEnrollmentsDeniedColF_Init = ColFInit.Text;
            Console.WriteLine(" TotalEnrollmentsDeniedColF_Init -->" + ColFInit.Text);
        }



        [When(@"Quarterly Enrollment Compliance Report Enrollments that Required Requests or Additional Information C Column is noted")]
        [Given(@"Quarterly Enrollment Compliance Report Enrollments that Required Requests or Additional Information C Column is noted")]
        [Then(@"Quarterly Enrollment Compliance Report Enrollments that Required Requests or Additional Information C Column is noted")]

        public void WhenQuarterlyEnrollmentComplianceReportEnrollmentsThatRequiredRequestsOrAdditionalInformationCColumnIsNoted()
        {
            IWebElement ColCInit = Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']/table/tbody/tr/td//table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td/table/tbody/tr[4]/td[3]/table/tbody/tr[11]/td[5]/div"));
            tmsWait.Hard(1);
            GlobalRef.EnrollmentsthatRequiredRequestsorAdditionalInformationCColumnInit = ColCInit.Text;
            Console.WriteLine(" Enrollments that Required Requests or Additional Information C Column Initial -->" + ColCInit.Text);
        }

        [When(@"Quarterly Enrollment Compliance Report Enrollments that Required Requests or Additional Information C Column is Increased")]
        public void WhenQuarterlyEnrollmentComplianceReportEnrollmentsThatRequiredRequestsOrAdditionalInformationCColumnIsIncreased()
        {
            IWebElement ColCFinal = Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']/table/tbody/tr/td//table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td/table/tbody/tr[4]/td[3]/table/tbody/tr[11]/td[5]/div"));
            tmsWait.Hard(2);
            GlobalRef.EnrollmentsthatRequiredRequestsorAdditionalInformationCColumnFinal = ColCFinal.Text;
            Console.WriteLine(" Enrollments that Required Requests or Additional Information C Column Final -->" + ColCFinal.Text);
            int Initial = Convert.ToInt32(GlobalRef.EnrollmentsthatRequiredRequestsorAdditionalInformationCColumnInit);
            int Final = Convert.ToInt32(GlobalRef.EnrollmentsthatRequiredRequestsorAdditionalInformationCColumnFinal);

            bool results = (Initial < Final);

            Assert.IsTrue(results, " C Column is not getting increased");
        }

        [Then(@"Quarterly DisEnrollment Compliance Report Total Voluntary Disenrollments Received A Column is noted")]

        [When(@"Quarterly DisEnrollment Compliance Report Total Voluntary Disenrollments Received A Column is noted")]
        [Then(@"Quarterly DisEnrollment Compliance Report Total Voluntary Disenrollments Received A Column is noted")]
        public void WhenQuarterlyDisEnrollmentComplianceReportTotalVoluntaryDisenrollmentsReceivedAColumnIsNoted()
        {

            // IWebElement ColAInit = Browser.Wd.FindElement(By.XPath("//tr[8]/td[5]/div/div")); // as it is a Static table, we used Absolute Xpath
            IWebElement ColAInit = Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']/table/tbody/tr/td//table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td/table/tbody/tr[8]/td[5]/div/div"));
            tmsWait.Hard(2);
            GlobalRef.TotalVoluntaryDisenrollmentsReceivedInit = ColAInit.Text;
            Console.WriteLine(" TotalVoluntaryDisenrollmentsReceived -->" + ColAInit.Text);
        }


        [When(@"Quarterly Enrollment Compliance Report Total Enrollments Received A Column is not Increased")]
        [Given(@"Quarterly Enrollment Compliance Report Total Enrollments Received A Column is not Increased")]
        [Then(@"Quarterly Enrollment Compliance Report Total Enrollments Received A Column is not Increased")]
        public void WhenQuarterlyEnrollmentComplianceReportTotalEnrollmentsReceivedAColumnIsNotIncreased()
        {
            IWebElement ColAFinal = Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']/table/tbody/tr/td//table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td[3]/table/tbody/tr[11]/td[5]/div"));
            tmsWait.Hard(2);
            GlobalRef.TotalEnrlReceivedAFinal = ColAFinal.Text;
            Console.WriteLine(" TotalEnrlReceivedAFinal -->" + ColAFinal.Text);
            int TotalEnrlRecivedAInitial = Convert.ToInt32(GlobalRef.TotalEnrlReceivedAInit);
            int TotalEnrlRecivedAFinal = Convert.ToInt32(GlobalRef.TotalEnrlReceivedAFinal);
            bool results = (TotalEnrlRecivedAInitial == TotalEnrlRecivedAFinal);
            Assert.IsTrue(results, " A Column is not getting increased");
        }

        [When(@"Quarterly Enrollment Compliance Report Total Enrollments Received A Column is Increased")]
        public void WhenQuarterlyEnrollmentComplianceReportTotalEnrollmentsReceivedAColumnIsIncreased()
        {
            tmsWait.Hard(8);
            IWebElement ColAFinal = Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']/table/tbody/tr/td//table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td[3]/table/tbody/tr[11]/td[5]/div"));
            tmsWait.Hard(2);
            GlobalRef.TotalEnrlReceivedAFinal = ColAFinal.Text;
            Console.WriteLine(" TotalEnrlReceivedAFinal -->" + ColAFinal.Text);
            int TotalEnrlRecivedAInitial = Convert.ToInt32(GlobalRef.TotalEnrlReceivedAInit);
            int TotalEnrlRecivedAFinal = Convert.ToInt32(GlobalRef.TotalEnrlReceivedAFinal);
            bool results = (TotalEnrlRecivedAInitial < TotalEnrlRecivedAFinal);
            Assert.IsTrue(results, " A Column is not getting increased");
        }

        [When(@"Quarterly Enrollment Compliance Report Total Enrollments A Column is Increased")]
        public void WhenQuarterlyEnrollmentComplianceReportTotalEnrollmentsAColumnIsIncreased()
        {
            tmsWait.Hard(8);
            IWebElement ColAFinal = Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']/table/tbody/tr/td//table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td[3]/table/tbody/tr[11]/td[5]/div"));
            tmsWait.Hard(2);
            GlobalRef.TotalEnrlReceivedAFinal = ColAFinal.Text;
            Console.WriteLine(" TotalEnrlReceivedAFinal -->" + ColAFinal.Text);
            int TotalEnrlRecivedAInitial = Convert.ToInt32(GlobalRef.TotalEnrlReceivedAInit);
            int TotalEnrlRecivedAFinal = Convert.ToInt32(GlobalRef.TotalEnrlReceivedAFinal);
            bool results = (TotalEnrlRecivedAInitial < TotalEnrlRecivedAFinal);
            Assert.IsTrue(results, " A Column is not getting increased");
        }

        [Then(@"verify count for total number of transactions is increased")]
        public void ThenVerifyCountForTotalNumberOfTransactionsIsIncreased()
        {
            tmsWait.Hard(2);
            Browser.SwitchToChildWindow();
            tmsWait.Hard(2);
            IWebElement ReportPage = Browser.Wd.FindElement(By.XPath("//td[contains(@id,'ReportCell')]"));
            tmsWait.Hard(2);
            IWebElement TotalTrans_Element = Browser.Wd.FindElement(By.XPath("//div[contains(text(),'Batch Number')]/ancestor::tr/following-sibling::tr/td/div/div[contains(text(),'61')]/ancestor::td/following-sibling::td/div/div"));
            tmsWait.Hard(2);
            // String[] r = TotalTrans_Element.Text.Split(' ');
            GlobalRef.TotalTransactions_Finalcount = TotalTrans_Element.Text.Trim();

            Console.WriteLine(" TotalTransactions_Finalcount -->" + TotalTrans_Element.Text);
            int TotalTrans_InitialCount = Convert.ToInt32(GlobalRef.TotalTransactions_Initialcount);
            int TotalTrans_FinalCount = Convert.ToInt32(GlobalRef.TotalTransactions_Finalcount);
            bool results = (TotalTrans_InitialCount < TotalTrans_FinalCount);
            Assert.IsTrue(results, " Total Transactions Count is not increased");
        }

        [Then(@"count for total number of transactions is noted")]
        public void ThenCountForTotalNumberOfTransactionsIsNoted()
        {
            IWebElement ele = null;
            tmsWait.Hard(2);
            Browser.SwitchToChildWindow();
            tmsWait.Hard(2);
            IWebElement ReportPage = Browser.Wd.FindElement(By.XPath("//td[contains(@id,'ReportCell')]"));
            try
            {
                ele = ReportPage.FindElement(By.XPath("//div[contains(text(),'Batch Number')]/ancestor::tr/following-sibling::tr/td/div/div[contains(text(),'61')]/ancestor::td/following-sibling::td/div/div"));
                GlobalRef.TotalTransactions_Initialcount = ele.Text;
                Console.WriteLine(" TotalTransactions_Initialcount -->" + ele.Text);
            }
            catch
            {

                //  String[] r = ele.Text.Split(' ');
                //  Console.WriteLine(" TotalTransactions_Initialcount -->" + r[2]);
                GlobalRef.TotalTransactions_Initialcount = "0";

                Console.WriteLine(" TotalTransactions_Initialcount -->" + 0);
            }
            //Console.WriteLine(" TotalTransactions_Initialcount -->" + ele.Text);
            //tmsWait.Hard(2);
            Browser.SwitchToChildWindow().Close();
            Browser.SwitchToParentWindow();
            tmsWait.Hard(2);
        }


        [When(@"Quarterly DisEnrollment Compliance Report Total Voluntary Disenrollments Received A Column is Increased")]
        public void WhenQuarterlyDisEnrollmentComplianceReportTotalVoluntaryDisenrollmentsReceivedAColumnIsIncreased()
        {
            IWebElement ColAFinal = Browser.Wd.FindElement(By.XPath("//tr[8]/td[5]/div/div"));
            tmsWait.Hard(2);
            GlobalRef.TotalVoluntaryDisenrollmentsReceivedFinal = ColAFinal.Text;
            Console.WriteLine(" TotalEnrlReceivedAFinal -->" + ColAFinal.Text);
            int TotalVoluntaryDisenrollmentsReceivedInitValue = Convert.ToInt32(GlobalRef.TotalVoluntaryDisenrollmentsReceivedInit);
            int TotalVoluntaryDisenrollmentsReceivedFinalValue = Convert.ToInt32(GlobalRef.TotalVoluntaryDisenrollmentsReceivedFinal);

            bool results = (TotalVoluntaryDisenrollmentsReceivedInitValue < TotalVoluntaryDisenrollmentsReceivedFinalValue);

            Assert.IsTrue(results, " A Column is not getting increased");
        }



        [When(@"Quarterly Enrollment Compliance Report Enrollments Complete at the Time of Initial Receipt B Column is noted")]
        [Then(@"Quarterly Enrollment Compliance Report Enrollments Complete at the Time of Initial Receipt B Column is noted")]
        public void WhenQuarterlyEnrollmentComplianceReportEnrollmentsCompleteAtTheTimeOfInitialReceiptBColumnIsNoted()
        {
            IWebElement ColB = Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']/table/tbody/tr/td//table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td[3]/table/tbody/tr[11]/td[6]/div"));
            tmsWait.Hard(2);
            GlobalRef.EnrollmentsCompleteattheTimeofInitialReceiptInit = ColB.Text;
            Console.WriteLine(" EnrollmentsCompleteattheTimeofInitialReceiptInit --> " + ColB.Text);
        }

        [When(@"Quarterly DisEnrollment Compliance Report Disenrollments Complete at the Time of Initial Receipt B Column is noted")]
        public void WhenQuarterlyDisEnrollmentComplianceReportDisenrollmentsCompleteAtTheTimeOfInitialReceiptBColumnIsNoted()
        {

            IWebElement ColB = Browser.Wd.FindElement(By.XPath("//tr[8]/td[6]/div/div"));
            tmsWait.Hard(2);
            GlobalRef.DisEnrollmentCompleteattheTimeofInitialReceiptInit = ColB.Text;
            Console.WriteLine(" DisEnrollment Complete at the Time of Initial Receipt B Column Initial --> " + ColB.Text);
        }



        [When(@"Quarterly DisEnrollment Compliance Report Disenrollments Complete at the Time of Initial Receipt B Column is Increased")]
        public void WhenQuarterlyDisEnrollmentComplianceReportDisenrollmentsCompleteAtTheTimeOfInitialReceiptBColumnIsIncreased()
        {

            IWebElement ColB = Browser.Wd.FindElement(By.XPath("//tr[8]/td[6]/div/div"));
            tmsWait.Hard(2);
            GlobalRef.DisEnrollmentCompleteattheTimeofInitialReceiptFinal = ColB.Text;
            Console.WriteLine(" EnrollmentsCompleteattheTimeofInitialReceiptFinal --> " + ColB.Text);
            int DisEnrollmentCompleteattheTimeofInitialReceiptInitValue = Convert.ToInt32(GlobalRef.DisEnrollmentCompleteattheTimeofInitialReceiptInit.ToString());
            int DisEnrollmentCompleteattheTimeofInitialReceiptFinalValue = Convert.ToInt32(GlobalRef.DisEnrollmentCompleteattheTimeofInitialReceiptFinal.ToString());

            bool results = (DisEnrollmentCompleteattheTimeofInitialReceiptInitValue < DisEnrollmentCompleteattheTimeofInitialReceiptFinalValue);

            Assert.IsTrue(results, " B Column is not getting increased");
        }



        [When(@"Quarterly Enrollment Compliance Report Enrollments Complete at the Time of Initial Receipt B Column is increased")]
        public void WhenQuarterlyEnrollmentComplianceReportEnrollmentsCompleteAtTheTimeOfInitialReceiptBColumnIsIncreased()
        {
            IWebElement ColB = Browser.Wd.FindElement(By.XPath("((//table[@role='presentation'])[2]//table[1]//tr[11]/td[6]/div/div)[1]"));
            tmsWait.Hard(2);
            GlobalRef.EnrollmentsCompleteattheTimeofInitialReceiptFinal = ColB.Text;
            Console.WriteLine(" EnrollmentsCompleteattheTimeofInitialReceiptFinal --> " + ColB.Text);
            int EnrollmentsCompleteattheTimeofInitialReceiptInitValue = Convert.ToInt32(GlobalRef.EnrollmentsCompleteattheTimeofInitialReceiptInit);
            int EnrollmentsCompleteattheTimeofInitialReceiptFinalValue = Convert.ToInt32(GlobalRef.EnrollmentsCompleteattheTimeofInitialReceiptFinal);

            bool results = (EnrollmentsCompleteattheTimeofInitialReceiptInitValue < EnrollmentsCompleteattheTimeofInitialReceiptFinalValue);

            Assert.IsTrue(results, " B Column is not getting increased");
        }



        [When(@"Quarterly Enrollment Compliance Report Enrollments Complete B Column is increased")]
        public void WhenQuarterlyEnrollmentComplianceReportEnrollmentsCompleteBColumnIsIncreased()
        {
            IWebElement ColB = Browser.Wd.FindElement(By.XPath("((//table[@role='presentation'])[2]//table[1]//tr[11]/td[6]/div/div)[1]"));
            tmsWait.Hard(2);
            GlobalRef.EnrollmentsCompleteattheTimeofInitialReceiptFinal = ColB.Text;
            Console.WriteLine(" EnrollmentsCompleteattheTimeofInitialReceiptFinal --> " + ColB.Text);
            int EnrollmentsCompleteattheTimeofInitialReceiptInitValue = Convert.ToInt32(GlobalRef.EnrollmentsCompleteattheTimeofInitialReceiptInitB);
            int EnrollmentsCompleteattheTimeofInitialReceiptFinalValue = Convert.ToInt32(GlobalRef.EnrollmentsCompleteattheTimeofInitialReceiptFinal);

            bool results = (EnrollmentsCompleteattheTimeofInitialReceiptInitValue < EnrollmentsCompleteattheTimeofInitialReceiptFinalValue);

            Assert.IsTrue(results, " B Column is not getting increased");
        }
        [When(@"Quarterly Enrollment Compliance Report Total Enrollments Denied D Column is Increased")]
        public void WhenQuarterlyEnrollmentComplianceReportTotalEnrollmentsDeniedDColumnIsIncreased()
        {
            IWebElement ColD = Browser.Wd.FindElement(By.XPath("((//table[@role='presentation'])[2]//table[1]//tr[11]/td[6]/div/div)[2]"));
            tmsWait.Hard(2);
            GlobalRef.TotalEnrollmentsDeniedColD_Final = ColD.Text;
            Console.WriteLine("TotalEnrollmentsDeniedColD_Final --> " + ColD.Text);
            int EnrollmentsDeniedInitValue = Convert.ToInt32(GlobalRef.TotalEnrollmentsDeniedColD_Init);
            int TotalEnrollmentsDeniedColD_Final = Convert.ToInt32(GlobalRef.TotalEnrollmentsDeniedColD_Final);
            bool results = (EnrollmentsDeniedInitValue < TotalEnrollmentsDeniedColD_Final);
            Assert.IsTrue(results, " D Column is not getting increased");
        }

        [When(@"Quarterly Enrollment Compliance Report Total Enrollments Denied F Column is Increased")]
        public void WhenQuarterlyEnrollmentComplianceReportTotalEnrollmentsDeniedFColumnIsIncreased()
        {
            IWebElement ColF = Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']/table/tbody/tr/td//table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td/table/tbody/tr[6]/td[2]/table/tbody/tr[11]/td[6]/div"));
            tmsWait.Hard(2);
            GlobalRef.TotalEnrollmentsDeniedColF_Final = ColF.Text;
            Console.WriteLine("TotalEnrollmentsDeniedColF_Final --> " + ColF.Text);
            int ColFInitValue = Convert.ToInt32(GlobalRef.TotalEnrollmentsDeniedColF_Init);
            int ColF_Final = Convert.ToInt32(GlobalRef.TotalEnrollmentsDeniedColF_Final);
            bool results = (ColFInitValue < ColF_Final);
            Assert.IsTrue(results, " F Column is not getting increased");
        }

        [When(@"Set BEQ and CMS page Connnectivity method is set to ""(.*)""")]
        public void WhenSetBEQAndCMSPageConnnectivityMethodIsSetTo(string method)
        {
            IWebElement element = Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + method + "')]/parent::td/input"));
            fw.ExecuteJavascript(element);
        }

        [When(@"Plan To ID Mapping value is set as ""(.*)"" for all GUID and RACFID")]
        public void WhenPlanToIDMappingValueIsSetAsForAllGUIDAndRACFID(string p0)
        {
            IReadOnlyCollection<IWebElement> elements = Browser.Wd.FindElements(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_grdvMapping']//input[@type='text']"));
            List<IWebElement> listelements = new List<IWebElement>(elements);

            foreach (IWebElement temp in listelements)
            {
                temp.Clear();
                temp.SendKeys(p0);
            }

            tmsWait.Hard(3);

            IWebElement save = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSave"));
            fw.ExecuteJavascript(save);

        }

        [Then(@"Verify Set BEQ and CMS page displayed message as ""(.*)""")]
        public void ThenVerifySetBEQAndCMSPageDisplayedMessageAs(string p0)
        {
            IWebElement msg = Browser.Wd.FindElement(By.XPath("//span[@id='ctl00_ctl00_MainMasterContent_MainContent_lblMessage'][contains(.,'" + p0 + "')]"));
            Assert.IsTrue(msg.Displayed, p0 + " message is not displayed");
        }

        [When(@"Reports page Member Name is selected from Member Lookup")]
        public void WhenReportsPageMemberNameIsSelectedFromMemberLookup()
        {

            tmsWait.Hard(2);
            // click on Member lookup
            IWebElement lookup = Browser.Wd.FindElement(By.XPath("//span[@test-id='report-link-group']/a"));
            fw.ExecuteJavascript(lookup);
            tmsWait.Hard(2);
            // Click on Search button on Member lookup
            IWebElement trrCode = Browser.Wd.FindElement(By.CssSelector("[test-id='member-btn-search']"));
            fw.ExecuteJavascript(trrCode);
            tmsWait.Hard(2);
            // Click on first record
            IWebElement trrSearchButton = Browser.Wd.FindElement(By.XPath("(//div[@test-id='member-grid-auditslist']//input)[1]"));
            fw.ExecuteJavascript(trrSearchButton);
            tmsWait.Hard(2);
            // Click on Add
            IWebElement trrRowClick = Browser.Wd.FindElement(By.CssSelector("[test-id='member-btn-add']"));
            fw.ExecuteJavascript(trrRowClick);
            tmsWait.Hard(2);

        }

        [Then(@"Verify Title of ""(.*)"" report is displayed successfully")]
        public void ThenVerifyTitleOfReportIsDisplayedSuccessfully(string expectedTitle)
        {
            tmsWait.Hard(3);
            Browser.SwitchToChildWindow();
            tmsWait.Hard(1);
            string actualTitle = Browser.Wd.Title;
            bool results = actualTitle.Contains(expectedTitle);
            Assert.IsTrue(results, " Expected Report is not displayed");

        }

        [Then(@"Verify correct report is displayed")]
        public void ThenVerifyCorrectReportIsDisplayed()
        {
            string expTitleText = "CustomCoverLetterPIR - Report Viewer";
            Browser.SwitchToChildWindow();
            tmsWait.Hard(10);
            string actualpageTitle = Browser.Wd.Title;
            Assert.AreEqual(expTitleText, actualpageTitle, "CustomCoverLetterPIR Report Not Opened");
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[contains(@id,'ReportViewerControl')]//table[@role='presentation']")).Displayed);
        }
        [Then(@"Verify ESI FRM ""(.*)"" report is displayed successfully")]
        public void ThenVerifyESIFRMReportIsDisplayedSuccessfully(string p0)
        {
            tmsWait.Hard(10);
            string content = tmsCommon.GenerateData(p0);


            try
            {

                // tmsWait.Hard(5);
                // Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[contains(@id,'ReportViewerControl')]//table[@role='presentation']//div/div[contains(.,'" + content + "')]")).Displayed);
            }

            catch
            {
                tmsWait.Hard(5);
                Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[contains(@id,'ReportViewerControl')]//table[@id='ReportViewerControl_fixedTable']//div/div[contains(.,'" + content + "')]")).Displayed);
            }
        }
        [Then(@"verify UI of the opened in new browser PastDueActions Report page")]
        public void ThenVerifyUIOfTheOpenedInNewBrowserPastDueActionsReportPage()
        {
            string pageTitle = "Past Due Actions";

            IWebElement UserCreated = Browser.Wd.FindElement(By.XPath("//div[contains(text(),'User Created:')]"));
            Assert.IsTrue(UserCreated.Displayed, "User Created: is not displayed");
            IWebElement user = Browser.Wd.FindElement(By.XPath("//div[contains(text(),'Created Dates:')]"));
            Assert.IsTrue(user.Displayed, "User field is not displayed");
            IWebElement typeAll = Browser.Wd.FindElement(By.XPath("//div[contains(text(),'Due Dates:')]"));
            Assert.IsTrue(typeAll.Displayed, "All option is displayed");
            IWebElement typeNotes = Browser.Wd.FindElement(By.XPath("//div[contains(text(),'Completed:')]"));
            Assert.IsTrue(typeNotes.Displayed, "Notes option is not displayed");
            IList<IWebElement> header = Browser.Wd.FindElements(By.XPath("//span[@aria-label='Report table']/parent::td/table/tbody/tr[3]/td/div"));
            IList<string> text = TMSoR1.FrameworkCode.HCC_RAM.OnHoldFunctionality.ConvertWebElementInToStringg(header);
            IList<string> stringlis = new List<string>() { "Last Name", "First Name", "Middle Name", "MBI", "Created", "Created By", "Date Due", "Action" };
            bool flag = true;
            foreach (string t in text)
            {
                if (!stringlis.Contains(t))
                {
                    flag = false;
                    break;
                }
            }
            Assert.IsTrue(flag);
        }


        [Then(@"verify UI of the opened in new browser NotesActions Report page")]
        public void ThenVerifyUIOfTheNotesActionsReportPageOpenedInNewBrowser()
        {
            string pageTitle = "Notes/Actions Report";
            IWebElement action = Browser.Wd.FindElement(By.XPath("//div[contains(text(),'Action/Note:')]"));
            Assert.IsTrue(action.Displayed, "Heading Notes and Actions is not displayed");
            IWebElement mbiTextbox = Browser.Wd.FindElement(By.XPath("//div[contains(text(),'User Created:')]"));
            Assert.IsTrue(mbiTextbox.Displayed, "User Created: is not displayed");
            IWebElement user = Browser.Wd.FindElement(By.XPath("//div[contains(text(),'Created Dates:')]"));
            Assert.IsTrue(user.Displayed, "User field is not displayed");
            IWebElement typeAll = Browser.Wd.FindElement(By.XPath("//div[contains(text(),'Due Dates:')]"));
            Assert.IsTrue(typeAll.Displayed, "All option is displayed");
            IWebElement typeNotes = Browser.Wd.FindElement(By.XPath("//div[contains(text(),'Completed:')]"));
            Assert.IsTrue(typeNotes.Displayed, "Notes option is not displayed");
            IList<IWebElement> header = Browser.Wd.FindElements(By.XPath("//span[@aria-label='Report table']/parent::td/table/tbody/tr[3]/td/div"));
            IList<string> text = TMSoR1.FrameworkCode.HCC_RAM.OnHoldFunctionality.ConvertWebElementInToStringg(header);
            IList<string> stringlis = new List<string>() { "Created", "Last Name", "First Name", "Middle Initial", "Created By", "Module", "Note", "Due On", "Completed", "Completed By" };
            bool flag = true;
            foreach (string t in text)
            {
                if (!stringlis.Contains(t))
                {
                    flag = false;
                    break;
                }
            }
            Assert.IsTrue(flag);
            //IWebElement status = Browser.Wd.FindElement(By.XPath("//*[@test-id='notesSearch-lbl-user' and contains(.,'Status')]"));
            //Assert.IsTrue(status.Displayed, "Status field is not displayed");
            //IWebElement resetBtn = Browser.Wd.FindElement(By.Id("btnReset"));
            //Assert.IsTrue(resetBtn.Displayed, "Reset button is not displayed");
            //IWebElement searchBtn = Browser.Wd.FindElement(By.Id("btnSearch"));
            //Assert.IsTrue(searchBtn.Displayed, "Search button is not displayed");
            //IWebElement userDefaultvalue = Browser.Wd.FindElement(By.XPath("//*[@aria-owns='inputBoxUsername_listbox']/span/span[1]"));
            //Assert.IsTrue(userDefaultvalue.Displayed, "User dropdown default value is not correct");
        }

        [Then(@"Verify ""(.*)"" report is displayed successfully")]
        public void ThenVerifyReportIsDisplayedSuccessfully(string p0)
        {
            Browser.Wd.Navigate().Refresh();

            tmsWait.Hard(10);
            string content = tmsCommon.GenerateData(p0);

            if (ConfigFile.EnvType.Equals("ESI"))
            {
                if (content.Equals("BEQ Mismatches Report"))
                {
                    content = "BEQ Mismatch Report";
                }
                if (content.Equals("T/RR Detail Report"))
                {
                    content = "TRR Detail Report";
                }

                if (content.Equals("Members with LEP Report"))
                {
                    content = "Members with LEP";
                }

                try
                {
                    AngularFunction.resolveCertificateErrors();
                }
                catch
                {

                }
                try
                {
                    string pagesource = Browser.Wd.FindElement(By.TagName("body")).Text;
                    tmsWait.Hard(6);
                    if (pagesource.Contains(content) || pagesource.Contains(content.ToUpper()))
                    {
                        Assert.IsTrue(true, content + "is found on Report");
                        fw.ConsoleReport(content + " is found on Report");

                    }
                    else
                    {
                        Assert.Fail("Report Content is not found...");
                    }
                }
                catch (OpenQA.Selenium.UnhandledAlertException e)
                {
                    string alertMsg = Browser.Wd.SwitchTo().Alert().Text;
                    string currentdate = DateTime.Now.ToString("M/d/yyyy");
                    if (alertMsg.Contains("Start Date"))
                    {
                        Browser.Wd.SwitchTo().Alert().Accept();

                        IWebElement start = Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl09_txtValue"));
                        start.SendKeys(currentdate);
                        start.SendKeys(Keys.Tab);

                        IWebElement end = Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl11_txtValue"));
                        end.SendKeys(currentdate);
                        end.SendKeys(Keys.Tab);
                        IWebElement btn = Browser.Wd.FindElement(By.CssSelector("[id='ReportViewerControl_ctl04_ctl00']"));
                        fw.ExecuteJavascript(btn);
                        tmsWait.Hard(6);
                        string pagesource = Browser.Wd.FindElement(By.TagName("body")).Text;

                        if (pagesource.Contains(content) || pagesource.Contains(content.ToUpper()))
                        {
                            Assert.IsTrue(true, content + "is found on Report");
                            fw.ConsoleReport(content + " is found on Report");

                        }
                        else
                        {
                            Assert.Fail("Report Content is not found...");
                        }


                    }

                }
            }
            else
            {

               
                Browser.SwitchToChildWindow();
                try
                {
                    AngularFunction.resolveCertificateErrors();
                }
                catch
                {

                }
                try
                {

                    tmsWait.Hard(15);
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[contains(@id,'ReportViewerControl')]//table[@role='presentation']//div/div[contains(.,'" + content + "')]")).Displayed);
                }

                catch
                {
                    tmsWait.Hard(12);
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[contains(@id,'ReportViewerControl')]//table[@id='ReportViewerControl_fixedTable']//div/div[contains(.,'" + content + "')]")).Displayed);
                }
            }
            //{

            //    Browser.SwitchToChildWindow();
            //    tmsWait.Hard(3);
            //    string actualContent = Browser.Wd.FindElement(By.TagName("body")).Text; ;
            //    Boolean result = actualContent.Contains(content);
            //    Assert.IsTrue(result, p0 + "Is not getting displayed");
            //}
        }

        [Then(@"Verify Report data match with Database value ""(.*)""")]
        public void ThenVerifyReportDataMatchWithDatabaseValue(string p0)
        {
            string expected_data = tmsCommon.GenerateData(p0);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@id='ReportViewerControl_ReportViewer']//td[contains(.,'" + expected_data + "')]")).Displayed, "Report Data mismatch");
        }




        [When(@"RAMX Report Data ""(.*)"" is set to ""(.*)""")]
        public void WhenRAMXReportDataIsSetTo(string p0, string p1)
        {

            string reportField = tmsCommon.GenerateData(p0);
            string getvalues = null;
            switch (reportField.ToLower())
            {
                case "control number": tmsWait.Hard(5); getvalues = Browser.Wd.FindElement(By.XPath("//div[@id='ReportViewerControl_ctl09']//td//div[contains(.,'Control Number:')]/parent::td/following-sibling::td/div/child::div")).Text; break;
                case "member id": getvalues = Browser.Wd.FindElement(By.XPath("//div[@id='ReportViewerControl_ctl09']//td//div[contains(.,'Member Id:')]/parent::td/following-sibling::td/div/child::div")).Text; break;
                case "member name": getvalues = Browser.Wd.FindElement(By.XPath("(//div[@id='ReportViewerControl_ctl09']//td//div[contains(.,'Member Name:')]/parent::td/following-sibling::td/div/child::div)[1]")).Text; break;
                //case "provider id": getvalues = Browser.Wd.FindElement(By.XPath("//div[@id='ReportViewerControl_ctl09']//td//div[contains(.,'Control Number:')]/parent::td/following-sibling::td/div/child::div")).Text; break;
                case "plan id": getvalues = Browser.Wd.FindElement(By.XPath("(//div[@id='ReportViewerControl_ctl09']//td//div[contains(.,'Plan Id:')]/parent::td/following-sibling::td/div/child::div)[1]")).Text; break;
                case "dos": getvalues = Browser.Wd.FindElement(By.XPath("(//div[@id='ReportViewerControl_ctl09']//td//div[contains(.,'Date of Service:')]/parent::td/following-sibling::td/div/child::div)[1]")).Text; break;
                case "top known hcc": getvalues = Browser.Wd.FindElement(By.XPath("(//div[@id='ReportViewerControl_ctl09']//td//div[contains(.,'HCC')]/div)[1]")).Text; break;
                case "submitted code": string getval = Browser.Wd.FindElement(By.XPath("//div[@id='ReportViewerControl_ctl09']//td//div[contains(.,'Submitted code')]/parent::td/following-sibling::td/div")).Text;
                    if (getval.Contains("ICD"))
                    {
                        string[] getv = getval.Split('-');
                        getvalues = getv[1];
                    }
                    break;
                case "msc speciality": getvalues = Browser.Wd.FindElement(By.XPath("//div[@id='ReportViewerControl_ctl09']//td//div[contains(.,'MSC Specialty:')]/parent::td/following-sibling::td/div/child::div")).Text; break;
                    //case "hcc name": break;



            }

            fw.setVariable(p1, getvalues);
        }

        [When(@"Report page ""(.*)"" is set to ""(.*)""")]
        public void WhenReportPageIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);

            switch (field.ToLower())
            {
                case "pcp id": fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@test-id='report-link-group']/a")));
                    tmsWait.Hard(8);
                    Browser.Wd.FindElement(By.XPath("//input[@test-id='pcpLookup-txt-searchBy']")).SendKeys(value);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='lookup-btn-Search']")));
                    tmsWait.Hard(3);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@test-id='lookup-grid-searchresult']//table/tbody//span[text()='" + value + "']")));
                    tmsWait.Hard(2);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'Back')]")));
                    tmsWait.Hard(3);
                    break;

                case "payment year": SelectElement pyear = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@test-id='PaymentYear']")));
                    pyear.SelectByText(value);
                    tmsWait.Hard(1);
                    break;

                case "pay year":
                    SelectElement payear = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@test-id='PayYear']")));
                    payear.SelectByText(value);
                    tmsWait.Hard(1);
                    break;

                case "suspect type": Browser.Wd.FindElement(By.XPath("//multiselect[@test-id='Type']/div")).Click();
                    Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + value + "')]")).Click();
                    tmsWait.Hard(1);
                    Browser.Wd.FindElement(By.XPath("//multiselect[@test-id='Type']/div")).Click();
                    break;
                case "status":
                    SelectElement status = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@test-id='Status']")));
                    status.SelectByText(value);
                    tmsWait.Hard(1); break;

                case "hcc sequence": fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//span[@test-id='report-link-group']/a)[2]")));
                    tmsWait.Hard(5);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='lookup-btn-Search']")));
                    tmsWait.Hard(2);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@test-id='lookup-grid-searchresult']//tbody/tr")));
                    tmsWait.Hard(2);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@test-id='pcpLookup-txt-backToRecord']")));
                    tmsWait.Hard(2);
                    break;
            }
        }



        [Then(@"Verify Total Suspect value is assigned into variable ""(.*)""")]
        public void ThenVerifyTotalSuspectValueIsAssignedIntoVariable(string p0)
        {
            Browser.SwitchToChildWindow();
            string expvalue = Browser.Wd.FindElement(By.XPath("//table[@role='presentation']//tbody//td/span[@aria-label='Report table']/parent::td/child::table//tr[4]/td[2]/div")).Text;
            fw.setVariable(p0, expvalue);

            //try
            //{

            //    tmsWait.Hard(10);

            //    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[contains(@id,'ReportViewerControl')]//table[@role='presentation']//div/div[contains(.,'" + content + "')]")).Displayed);
            //}

            //catch
            //{
            //    tmsWait.Hard(12);
            //    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[contains(@id,'ReportViewerControl')]//table[@id='ReportViewerControl_fixedTable']//div/div[contains(.,'" + content + "')]")).Displayed);
            //}
        }




        [Then(@"Verify Query result ""(.*)"" is matching with UI value ""(.*)""")]
        public void ThenVerifyQueryResultIsMatchingWithUIValue(string p0, string p1)
        {
            string suspect_in_DB = tmsCommon.GenerateData(p0);
            string suspect_in_UI = tmsCommon.GenerateData(p1.ToString());
            Assert.IsTrue(suspect_in_DB.Contains(suspect_in_UI));
        }


        //[Then(@"Verify ""(.*)"" value is assigned into variable ""(.*)""")]
        //public void ThenVerifyValueIsAssignedIntoVariable(string p0, string p1)
        //{
        //    string fieldTocapture = tmsCommon.GenerateData(p0);
        //    string valueassignInto = tmsCommon.GenerateData(p1);
        //    string valueTobeAssinged = null;
        //    Browser.SwitchToChildWindow(); 
        //    tmsWait.Hard(3);
        //    switch(fieldTocapture.ToLower())
        //    {
        //        case "member id":valueTobeAssinged = Browser.Wd.FindElement(By.XPath("//table[@role='presentation']//tbody//td/span[@aria-label='Report table']/parent::td/child::table//tr[4]/td[2]/div")).Text;
        //            break;
        //        case "member name": break;
        //        case "plan id": break;
        //        case "provider id": break;
        //        case "dos": break;
        //        case "top hcc": break;
        //        case "hcc probability": break;
        //        case "hcc name": break;
        //        case "hcc description": break;
        //        case "related code": break;
        //        case "related description": break;



        //    }
        //    fw.setVariable(valueassignInto, valueTobeAssinged);
        //}


        [Then(@"Verify ""(.*)"" on Report is same as ""(.*)"" on Manage Suspect Screen")]
        public void ThenVerifyOnReportIsSameAsOnManageSuspectScreen(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string expected_value = tmsCommon.GenerateData(p1);
            //Browser.SwitchToChildWindow();
            tmsWait.Hard(3);
            switch (field.ToLower())
            {
                case "member id":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//div[@id='VisibleReportContentReportViewerControl_ctl09']//div[contains(.,'" + expected_value + "')])[3]")).Displayed, "Value does not match on UI and Report");
                    break;
                case "member name":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//div[@id='VisibleReportContentReportViewerControl_ctl09']//div[contains(.,'" + expected_value + "')])[3]")).Displayed, "Value does not match on UI and Report");
                    break;
                case "plan id": break;
                case "provider id":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//div[@id='VisibleReportContentReportViewerControl_ctl09']//div[contains(.,'" + expected_value + "')])[3]")).Displayed, "Value does not match on UI and Report");
                    break;
                case "dos":
                    string[] split_expected_value = expected_value.Split('/');
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//div[@id='VisibleReportContentReportViewerControl_ctl09']//div[contains(.,'" + split_expected_value[2] + "')])[3]")).Displayed, "Value does not match on UI and Report");
                    break;
                case "top hcc":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//div[@id='VisibleReportContentReportViewerControl_ctl09']//div[contains(.,'" + expected_value + "')])[3]")).Displayed, "Value does not match on UI and Report");
                    break;
                case "hcc probability":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//div[@id='VisibleReportContentReportViewerControl_ctl09']//div[contains(.,'" + expected_value + "')]")).Displayed, "Value does not match on UI and Report");
                    break;
                case "hcc name":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//div[@id='VisibleReportContentReportViewerControl_ctl09']//div[contains(.,'" + expected_value + "')])")).Displayed, "Value does not match on UI and Report");
                    break;
                case "hcc description":

                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@id='VisibleReportContentReportViewerControl_ctl09']//div[contains(.,'" + expected_value.ToLower() + "')]")).Displayed, "Value does not match on UI and Report");
                    break;
                    //case "related code": break;
                    //case "related description": break;
            }

        }


        [Then(@"Verify Value for ""(.*)"" is matched with ""(.*)""")]
        public void ThenVerifyValueForIsMatchedWith(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (field.ToLower())
            {
                case "providerid": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//div[@id='VisibleReportContentReportViewerControl_ctl09']//div[contains(.,'" + value + "')])[3]")).Displayed, "Value does not match on UI and Report"); break;
                case "status": break;
            }
        }


        [When(@"Switch to Parent Window")]
        public void WhenSwitchToParentWindow()
        {
            Browser.SwitchToParentWindow();
            tmsWait.Hard(3);
        }



        [Then(@"Verify Report displays Table Name as ""(.*)"" Field name as ""(.*)"" Exp Reason as ""(.*)"" Member ID as ""(.*)"" Claim as ""(.*)"" Plan as ""(.*)""")]
        public void ThenVerifyReportDisplaysTableNameAsFieldNameAsExpReasonAsMemberIDAsClaimAsPlanAs(string p0, string p1, string p2, string p3, string p4, string p5)
        {

            tmsWait.Hard(5);
            string table = tmsCommon.GenerateData(p0);
            string field = tmsCommon.GenerateData(p1);
            string expreason = tmsCommon.GenerateData(p2);
            string memberid = tmsCommon.GenerateData(p3);
            string claim = tmsCommon.GenerateData(p4);
            string plan = tmsCommon.GenerateData(p5);

            By loc = By.XPath("//div[@id='ReportViewerControl_ctl09']//tr/td[contains(.,'" + table + "')]/following-sibling::td[contains(.,'" + field + "')]/following-sibling::td[contains(.,'" + expreason + "')]/following-sibling::td[contains(.,'" + memberid + "')]/following-sibling::td[contains(.,'" + claim + "')]/following-sibling::td[contains(.,'" + plan + "')]");
            By pageno = By.XPath("(//span[@id='ReportViewerControl_ctl05_ctl00_TotalPages'])[1]");
            By NextButton = By.XPath("//input[@id='ReportViewerControl_ctl05_ctl00_Next_ctl00_ctl00']");
            if (Browser.Wd.FindElement(pageno).Displayed)
            { string pages = Browser.Wd.FindElement(pageno).Text;

                for (int i = 1; i <= Int32.Parse(pages); i++)
                {
                    try
                    {
                        UIMODUtilFunctions.elementPresenceUsingLocators(loc);
                        break;
                    }
                    catch
                    {
                        if (i != Int32.Parse(pages) && i != 1) {
                            Browser.Wd.FindElement(NextButton).Click();
                        }
                    }
                }
            }

            ;
        }


        [Then(@"Verify EAM ""(.*)"" report is displayed successfully")]
        public void ThenVerifyEAMReportIsDisplayedSuccessfully(string p0)
        {
            string content = tmsCommon.GenerateData(p0);
            Browser.SwitchToChildWindow();
            tmsWait.Hard(2);
            Browser.SwitchToIFrame();
            tmsWait.Hard(5);
            Assert.IsTrue(Browser.Wd.PageSource.Contains(content));
        }

        [Then(@"Verify text presence ""(.*)"" on report page")]
        public void ThenVerifyTextPresenceOnReportPage(string p0)
        {
            string content = tmsCommon.GenerateData(p0);
            tmsWait.Hard(5);
            Browser.SwitchToChildWindow();
            tmsWait.Hard(2);
            Browser.SwitchToIFrame();
            tmsWait.Hard(2);
            bool presence = Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table//tr[contains(.,'" + content + "')]")).Displayed;

            Assert.IsTrue(presence, content + " is not displayed");
        }

        [Then(@"Switch back to Parent window")]
        public void ThenSwitchBackToParentWindow()
        {
            Browser.SwitchToChildWindow().Close();
            tmsWait.Hard(2);
            Browser.SwitchToParentWindow();
        }


        [Then(@"Verify ""(.*)"" report is displayed")]
        public void ThenVerifyReportIsDisplayed(string content)
        {
            tmsWait.Hard(3);
            bool ispresent = false;

            if (ConfigFile.EnvType.Equals("ESI"))
            {
                try
                {
                    ispresent = Browser.Wd.FindElement(By.XPath("(//div[contains(.,'Send to CMS Queue Report')])[8]")).Displayed;
                }

                catch
                {

                }

                Assert.IsTrue(ispresent, "Expected Report Name is not displayed on ESI EAM Report Page");
            }
            else
            {
                reportContentVerification(content);
            }

        }


        [Then(@"Verify text ""(.*)"" on report page is displayed")]
        [When(@"Verify text ""(.*)"" on report page is displayed")]
        [Given(@"Verify text ""(.*)"" on report page is displayed")]
        public void ThenVerifyTextOnReportPageIsDisplayed(string p0)
        {
            string content = tmsCommon.GenerateData(p0);
            if (ConfigFile.EnvType.Equals("ESI"))
            {

                string pagesource = Browser.Wd.FindElement(By.TagName("body")).Text;
                tmsWait.Hard(6);
                if (content.Equals("Extra characters in: EmpGroupNumber"))
                {
                    content = "Extra characters in:EmpGroupNumber";
                }
                if (content.Equals("Extra characters in: SecondaryRxPCN"))
                {
                    content = "Extra characters in:SecondaryRxPCN";
                }
                if (content.Equals("Extra characters in: SalesDate"))
                {
                    content = "Extra characters in:SalesDate";
                }
                if (content.Equals("Extra characters in: RxPCN"))
                {
                    content = "Extra characters in:RxPCN";
                }
                if (content.Equals("Extra characters in: RxGroup"))
                {
                    content = "Extra characters in:RxGroup";
                }
                if (content.Equals("Extra characters in: RxBIN"))
                {
                    content = "Extra characters in:RxBIN";
                }

                if (content.Equals("Extra characters in: PWOption"))
                {
                    content = "Extra characters in:PWOption";
                }
                if (content.Equals("Extra characters in: PCPProviderID"))
                {
                    content = "Extra characters in:PCPProviderID";
                }

                if (content.Equals("Extra characters in: PCPLastName"))
                {
                    content = "Extra characters in:PCPLastName";
                }
                if (content.Equals("Extra characters in: MedicarePartD"))
                {
                    content = "Extra characters in:MedicarePartD";
                }
                if (content.Equals("Extra characters in: RxPCN"))
                {
                    content = "Extra characters in:RxPCN";
                }
                if (content.Equals("Extra characters in: AgentID"))
                {
                    content = "Extra characters in:AgentID";
                }




                if (content.Equals("Extra characters in: SecondPhone"))
                {
                    content = "Extra characters in:SecondPhone";
                }
                if (content.Equals("Extra characters in: MailingCity"))
                {
                    content = "Extra characters in:MailingCity";
                }
                if (content.Equals("Extra characters in: PCPEffDate"))
                {
                    content = "Extra characters in:PCPEffDate";
                }

                if (content.Equals("Extra characters in: PCPEndDate"))
                {
                    content = "Extra characters in:PCPEndDate";
                }
                if (content.Equals("Extra characters in: PCPFirstName"))
                {
                    content = "Extra characters in:PCPFirstName";
                }
                if (content.Equals("Extra characters in: PCPLastName"))
                {
                    content = "Extra characters in:PCPLastName";
                }
                if (content.Equals("Extra characters in: PWOption"))
                {
                    content = "Extra characters in:PWOption";
                }
                if (content.Equals("Extra characters in:  RxPCN,"))
                {
                    content = "Extra characters in:RxPCN,";
                }

                if (pagesource.Contains(content) || pagesource.Contains(content.ToUpper()))
                {
                    Assert.IsTrue(true, content + "is found on Report");
                    fw.ConsoleReport(content + " is found on Report");

                }


                else
                {
                    if (content.Contains(":"))
                    {
                        string[] tokens = content.Split(':');
                        content = tokens[0] + ":" + tokens[1].TrimStart();
                        if (pagesource.Contains(content) || pagesource.Contains(content.ToUpper()))
                        {
                            Assert.IsTrue(true, content + "is found on Report");
                            fw.ConsoleReport(content + " is found on Report");
                        }
                        else { Assert.Fail("Report Content is not found...");
                        }
                    }
                }
            }
            else
            {
                reportContentVerification(content);
            }
        }


        [Then(@"RAM report page navigate to last page of report")]
        public void ThenRAMReportPageNavigateToLastPageOfReport()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//input[@title='Last Page'])[1]")));
            tmsWait.Hard(3);
        }


        [Then(@"Verify CMS File ID ""(.*)"" Plan ID ""(.*)"" Number of Records ""(.*)"" is displayed on report")]
        public void ThenVerifyCMSFileIDPlanIDNumberOfRecordsIsDisplayedOnReport(string p0, string p1, string p2)
        {
            tmsWait.Hard(3);
            string cmsfileid = tmsCommon.GenerateData(p0);
            string planid = tmsCommon.GenerateData(p1);
            string numrecords = tmsCommon.GenerateData(p2);

            IWebElement ele = Browser.Wd.FindElement(By.XPath("//div[@id='ReportViewerControl_ctl09']//table//tr//td[contains(.,'" + cmsfileid + "')]/following-sibling::td[contains(.,'" + planid + "')]/following-sibling::td[contains(.,'" + numrecords + "')]"));
            bool recordPresence = ele.Displayed;

            Assert.IsTrue(recordPresence, " Expected record is not present");
        }


        [Then(@"Verify ESI FRM content ""(.*)"" on report page is displayed")]
        public void ThenVerifyESIFRMContentOnReportPageIsDisplayed(string p0)
        {
            string c = tmsCommon.GenerateData(p0);
            string content = String.Format("{0:0.00}", c); //display only 2 digit
            string pagesource = Browser.Wd.FindElement(By.TagName("body")).Text;
            tmsWait.Hard(6);
            if (pagesource.Contains(content) || pagesource.Contains(content.ToUpper()))
            {
                Assert.IsTrue(true, content + "is found on Report");
                fw.ConsoleReport(content + " is found on Report");

            }
            else
            {
                Assert.Fail("Report Content is not found...");
            }
        }

        [Then(@"Verify ESI FRM Discrepancy Type Summary Part C Reports page displayed Plan ID as ""(.*)"" Reason Code as ""(.*)"" Count Under as ""(.*)"" Count Over as ""(.*)"" Total Count as ""(.*)"" Payment Under as ""(.*)"" Payment Over as ""(.*)"" Total Payment as ""(.*)""")]
        public void ThenVerifyESIFRMDiscrepancyTypeSummaryPartCReportsPageDisplayedPlanIDAsReasonCodeAsCountUnderAsCountOverAsTotalCountAsPaymentUnderAsPaymentOverAsTotalPaymentAs(string p0, string p1, string p2, string p3, string p4, string p5, string p6, string p7)
        {

            string planid = tmsCommon.GenerateData(p0);
            string reasoncode = tmsCommon.GenerateData(p1);
            string countunder = tmsCommon.GenerateData(p2);
            string countover = tmsCommon.GenerateData(p3);
            string totalcount = tmsCommon.GenerateData(p4);
            string paymentunder = tmsCommon.GenerateData(p5);
            string finalPaymentUnder = Convert.ToDouble(paymentunder).ToString("C", System.Globalization.CultureInfo.GetCultureInfo("en-us"));
            string paymentover = tmsCommon.GenerateData(p6);
            string finalpaymentover = Convert.ToDouble(paymentover).ToString("C", System.Globalization.CultureInfo.GetCultureInfo("en-us"));
            string totalpayment = tmsCommon.GenerateData(p7);
            string finaltotalpayment = Convert.ToDouble(totalpayment).ToString("C", System.Globalization.CultureInfo.GetCultureInfo("en-us"));

            By loc = By.XPath("//div[@id='ReportViewerControl_ctl09']//tr//div[contains(.,'PlanId:  " + planid + "')]/parent::td/parent::tr/following-sibling::tr//div[contains(.,'" + reasoncode + "')]/parent::td/parent::tr/td[4][contains(.,'" + countunder + "')]/following-sibling::td[2][contains(.,'" + countover + "')]/following-sibling::td[2][contains(.,'" + totalcount + "')]/following-sibling::td[2][contains(.,'0.00')]/following-sibling::td[2][contains(.,'6,550.57')]/following-sibling::td[2][contains(.,'6,550.57')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);

        }

        [Then(@"Verify ESI FRM Discrepancy Type Summary Part C Reports page displayed Total Plan ID as ""(.*)"" Count Under as ""(.*)"" Count Over as ""(.*)"" Total Count as ""(.*)"" Payment Under as ""(.*)"" Payment Over as ""(.*)"" Total Payment as ""(.*)""")]
        public void ThenVerifyESIFRMDiscrepancyTypeSummaryPartCReportsPageDisplayedTotalPlanIDAsCountUnderAsCountOverAsTotalCountAsPaymentUnderAsPaymentOverAsTotalPaymentAs(string p0, string p1, string p2, string p3, string p4, string p5, string p6)
        {

            string planid = tmsCommon.GenerateData(p0);
            string countunder = tmsCommon.GenerateData(p1);
            string countover = tmsCommon.GenerateData(p2);
            string totalcount = tmsCommon.GenerateData(p3);
            string paymentunder = tmsCommon.GenerateData(p4);
            string finalPaymentUnder = Convert.ToDouble(paymentunder).ToString("C", System.Globalization.CultureInfo.GetCultureInfo("en-us"));
            string paymentover = tmsCommon.GenerateData(p5);
            string finalpaymentover = Convert.ToDouble(paymentover).ToString("C", System.Globalization.CultureInfo.GetCultureInfo("en-us"));
            string totalpayment = tmsCommon.GenerateData(p6);
            string finaltotalpayment = Convert.ToDouble(totalpayment).ToString("C", System.Globalization.CultureInfo.GetCultureInfo("en-us"));

            By loc = By.XPath("//div[@id='ReportViewerControl_ctl09']//tr//div[contains(.,'Totals For " + planid + "')]/parent::td/parent::tr//td[4][contains(.,'" + countunder + "')]/following-sibling::td[2][contains(.,'" + countover + "')]/following-sibling::td[2][contains(.,'" + totalcount + "')]/following-sibling::td[2][contains(.,'" + finalPaymentUnder + "')]/following-sibling::td[2][contains(.,'" + finalpaymentover + "')]/following-sibling::td[2][contains(.,'" + finaltotalpayment + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }


        [Then(@"verify text HIC ""(.*)"" and Reason description ""(.*)"" is displayed on the report")]
        public void ThenVerifyTextHICAndReasonDescriptionIsDisplayedOnTheReport(string p0, string p1)
        {
            bool alertPresent;
            bool flag = false;
            string hic = tmsCommon.GenerateData(p0);
            string reasonDesc = tmsCommon.GenerateData(p1);
            Browser.SwitchToChildWindow();

            IWebElement searchField = Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl05_ctl03_ctl00"));
            IWebElement findLink = Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl05_ctl03_ctl01"));
            searchField.Clear();
            searchField.SendKeys(hic.Trim());
            tmsWait.Hard(3);
            fw.ExecuteJavascript(findLink);
            tmsWait.Hard(2);
            tmsWait.Implicit(10);

            alertPresent = IsAlertPresent();
            IWebElement ele;
            IList<IWebElement> rows;

            do
            {
                ele = Browser.Wd.FindElement(By.XPath("//div[@dir= 'LTR']/table/tbody/tr//table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody"));
                rows = ele.FindElements(By.TagName("tr"));
                for (int i = 3; i < rows.Count; i++)
                {
                    IList<IWebElement> cols = rows[i].FindElements(By.TagName("td"));
                    if (cols[1].Text.Contains(hic) && cols[7].Text.Contains(reasonDesc))
                    {
                        flag = true;
                        Assert.IsTrue(true, hic + "is found on Report");
                        fw.ConsoleReport(hic + " is found on Report");
                        Assert.IsTrue(true, reasonDesc + "is found on Report");
                        fw.ConsoleReport(reasonDesc + " is found on Report");
                        break;
                    }
                }
                tmsWait.Hard(2);
                IWebElement nextLink = Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl05_ctl03_ctl03"));
                fw.ExecuteJavascript(nextLink);
                tmsWait.Hard(5);
                alertPresent = IsAlertPresent();
            } while (alertPresent == false);

            if (flag == false)
            {
                Assert.Fail("HIC/Reason description was not found on the report");
            }
            Browser.Wd.SwitchTo().Alert().Dismiss();
        }



        public static bool IsAlertPresent()
        {
            try
            {
                Browser.Wd.SwitchTo().Alert();
                return true;
            }
            catch (NoAlertPresentException)
            {
                return false;
            }
        }


        [Then(@"Verify Diagnosis Code displayed on report page")]
        public void ThenVerifyDiagnosisCodeDisplayedOnReportPage()
        {
            string expectedDiagCode = GlobalRef.DIAGCODE.ToString();
            reportContentVerification(expectedDiagCode);

        }

        [Then(@"Verify entered Member ID on report page is displayed")]
        public void ThenVerifyEnteredMemberIDOnReportPageIsDisplayed()
        {
            string content = GlobalRef.MEMID.ToString();
            reportContentVerification(content);
        }

        [Then(@"Verify entered Member ID ""(.*)"" on report page is displayed")]
        [When(@"Verify entered Member ID ""(.*)"" on report page is displayed")]
        [Given(@"Verify entered Member ID ""(.*)"" on report page is displayed")]
        public void ThenVerifyEnteredMemberIDOnReportPageIsDisplayed(string p0)
        {
            string content = tmsCommon.GenerateData(p0);
            reportContentVerification(content);
        }



        [Then(@"Verify Report should not display ""(.*)"" value")]
        public void ThenVerifyReportShouldNotDisplayValue(string p0)
        {
            string content = tmsCommon.GenerateData(p0);
            reportContentNotPresentVerification(content);
        }


        [Then(@"Verify text ""(.*)"" on report page is not displayed")]
        [Given(@"Verify text ""(.*)"" on report page is not displayed")]
        public void ThenVerifyTextOnReportPageIsNotDisplayed(string p0)
        {
            string content = tmsCommon.GenerateData(p0);
            reportContentNotPresent(content);
        }

        [Then(@"RAM report page Member ID search button is clicked to search Member")]
        public void ThenRAMReportPageMemberIDSearchButtonIsClickedToSearchMember()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(RAM.RAMReportPage.MemberIDSearchButton);
        }

        [Then(@"Member Lookup page Search button is clicked")]
        public void ThenMemberLookupPageSearchButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(RAM.RAMReportPage.MemberLookupSearchButton);
        }

        [Then(@"Member Lookup page first row of member ID is selected")]
        public void ThenMemberLookupPageFirstRowOfMemberIDIsSelected()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(RAM.RAMReportPage.FirstMemberRecord);
        }

        [Then(@"Member Lookup page Back button is clicked")]
        public void ThenMemberLookupPageBackButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(RAM.RAMReportPage.MemberLookupBackButton);
        }


        [Then(@"Search Criteria page Save Format ""(.*)"" is selected")]
        public void ThenSearchCriteriaPageSaveFormatIsSelected(string saveFormat)
        {
            Browser.Wd.FindElement(By.XPath("//input[@value='" + saveFormat + "']")).Click();
        }

        [When(@"RAM report page Run Report button is clicked")]
        public void WhenRAMReportPageRunReportButtonIsClicked()
        {
            tmsWait.Hard(1);
            fw.ExecuteJavascript(RAM.RAMReportPage.RunReportButton);
            tmsWait.Hard(20);

            string reporttype = GlobalRef.winium.ToString();
            if (reporttype.Equals("Interactive"))
            {
                ReUsableFunctions.reportAuthenticationHandler();
            }
        }


        [Then(@"Search Criteria page Run Report button is clicked")]
        [Given(@"Search Criteria page Run Report button is clicked")]
        [When(@"Search Criteria page Run Report button is clicked")]
        public void ThenSearchCriteriaPageRunReportButtonIsClicked()
        {
            tmsWait.Hard(7);

            if (ConfigFile.EnvType.Equals("ESI"))
            {
                IWebElement btn = Browser.Wd.FindElement(By.CssSelector("[id='ReportViewerControl_ctl04_ctl00']"));
                fw.ExecuteJavascript(btn);
            }

            else
            {
                tmsWait.Hard(2);
                fw.ExecuteJavascript(RAM.RAMReportPage.RunReportButton);
                tmsWait.Hard(10);
                // ReUsableFunctions.reportAuthenticationHandler();

                if (ConfigFile.BrowserType.Equals("edge") || ConfigFile.BrowserType.Equals("edgelegacy") || ConfigFile.BrowserType.Equals("edgechrome"))
                {
                    fw.ConsoleReport("***************** Accepting Certificate Error in Reporting Window ***************");
                    try
                    {
                        IWebElement advancedButton = Browser.Wd.FindElement(By.CssSelector("[id='details-button']"));
                        fw.ExecuteJavascript(advancedButton);
                        tmsWait.Hard(5);

                        IWebElement acceptRiskBtn = Browser.Wd.FindElement(By.CssSelector("[id='proceed-link']"));
                        fw.ExecuteJavascript(acceptRiskBtn);
                        tmsWait.Hard(10);

                        IWebElement advancedButton1 = Browser.Wd.FindElement(By.CssSelector("[id='details-button']"));
                        fw.ExecuteJavascript(advancedButton1);
                        tmsWait.Hard(5);

                        IWebElement acceptRiskBtn1 = Browser.Wd.FindElement(By.CssSelector("[id='proceed-link']"));
                        fw.ExecuteJavascript(acceptRiskBtn1);

                    }
                    catch
                    {
                        try
                        {
                            IWebElement continueBtn = Browser.Wd.FindElement(By.PartialLinkText("Continue to this webpage"));
                            fw.ExecuteJavascript(continueBtn);
                            tmsWait.Hard(5);
                        }
                        catch
                        {

                            fw.ConsoleReport("There is no Certiicate Warning");
                        }
                    }
                }

                string reporttype = GlobalRef.winium.ToString();
                if (reporttype.Equals("Interactive"))
                {
                    ReUsableFunctions.reportAuthenticationHandler();
                }
            }

        }


        [When(@"""(.*)"" page Generate Report button is Clicked")]
        public void WhenPageGenerateReportButtonIsClicked(string p0)
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("button[test-id='membrPaySumry-btn-generateReport']")));
            tmsWait.Hard(5);
            ReUsableFunctions.reportAuthenticationHandler();
            tmsWait.Hard(5);

        }





        [Then(@"Member CMS-HCC Disease History Member ID searched and selected")]
        [When(@"Member CMS-HCC Disease History Member ID searched and selected")]
        public void ThenMemberCMS_HCCDiseaseHistoryMemberIDSearchedAndSelected()
        {
            fw.ExecuteJavascript(RAM.RAMReportPage.MemberIDSearchButton);
            tmsWait.Hard(12);
            fw.ExecuteJavascript(RAM.RAMReportPage.MemberLookupSearchButton);
            tmsWait.Hard(14);
            fw.ExecuteJavascript(RAM.RAMReportPage.FirstMemberRecord);
            tmsWait.Hard(2);
            fw.ExecuteJavascript(RAM.RAMReportPage.MemberLookupBackButton);
        }


        [Then(@"Report page Start Date is selected for Confirmed Suspect By HCC report")]
        public void ThenReportPageStartDateIsSelectedForConfirmedSuspectByHCCReport()
        {
            DateTime date = DateTime.Now;
            DateTime firstDayOfMonth = new DateTime(date.Year, date.Month, 1);
            string startDate = firstDayOfMonth.ToString("MM/dd/yyyy");
            tmsWait.Hard(2);
            fw.ExecuteJavascriptSetText(RAM.RAMReportPage.StartKendoDate, startDate);
        }

        [Then(@"Report page End Date is selected for Confirmed Suspect By HCC report")]
        public void ThenReportPageEndDateIsSelectedForConfirmedSuspectByHCCReport()
        {
            DateTime date = DateTime.Now;
            string currentDate = date.ToString("MM/dd/yyyy");
            tmsWait.Hard(2);
            fw.ExecuteJavascriptSetText(Browser.Wd.FindElement(By.CssSelector("input[test-id='EndDate']")), currentDate);
        }

        [Then(@"on Search Criteria page Effective Date From ""(.*)"" is selected")]
        public void ThenOnSearchCriteriaPagePageStartDateIsSelected(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0.ToString());
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl07_txtValue")).SendKeys(GeneratedData);
                Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl07_txtValue")).SendKeys(Keys.Tab);
            }
            else
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    tmsWait.Hard(1);
                    
                    string value = GeneratedData.Replace("/", "");
                    By Drp = By.XPath("//kendo-datepicker[@test-id='EffDate_From']//input");
                    Browser.Wd.FindElement(Drp).Clear();
                    Browser.Wd.FindElement(Drp).SendKeys(value);

                    tmsWait.Hard(3);
                }
                else
                {
                    fw.ExecuteJavascriptSetText(RAM.RAMReportPage.EffDateFrom, GeneratedData);
                }
            }
        }


        [When(@"EAM Report page Effective date is set to ""(.*)""")]
        [Given(@"EAM Report page Effective date is set to ""(.*)""")]
        [Then(@"EAM Report page Effective date is set to ""(.*)""")]
        public void WhenEAMReportPageEffectiveDateIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0.ToString());
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(1);
                
                string value = GeneratedData.Replace("/", "");
                By Drp = By.XPath("//kendo-datepicker[@test-id='EffDate']//input");
                Browser.Wd.FindElement(Drp).Clear();
                Browser.Wd.FindElement(Drp).SendKeys(value);

                tmsWait.Hard(3);
            }
            else
            {
                fw.ExecuteJavascriptSetText(RAM.RAMReportPage.EffDate, GeneratedData);
            }
        }


        [Then(@"on Search Criteria page From Date From ""(.*)"" is selected")]
        public void ThenOnSearchCriteriaPageFromDateFromIsSelected(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0.ToString());
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(1);
                
                string value = GeneratedData.Replace("/", "");
                By Drp = By.XPath("//kendo-datepicker[@test-id='FromDate']//input");
                Browser.Wd.FindElement(Drp).Clear();
                Browser.Wd.FindElement(Drp).SendKeys(value);

                tmsWait.Hard(3);
            }
            else
            {
                fw.ExecuteJavascriptSetText(RAM.RAMReportPage.FromDate, GeneratedData);
            }
        }


        [Then(@"on Search Criteria page Effective Date To is selected")]
        public void ThenOnSearchCriteriaPageEffectiveDateToIsSelected()
        {
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl09_txtValue")).SendKeys("02/01/2020");
                Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl09_txtValue")).SendKeys(Keys.Tab);

            }
            else
            {
                DateTime date = DateTime.Now;
                string currentDate = date.ToString("MM/dd/yyyy");
                tmsWait.Hard(2);
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    tmsWait.Hard(1);
                    
                    string value = currentDate.Replace("/", "");
                    By Drp = By.XPath("//kendo-datepicker[@test-id='EffDate_To']//input");
                    Browser.Wd.FindElement(Drp).Clear();
                    Browser.Wd.FindElement(Drp).SendKeys(value);

                    tmsWait.Hard(3);
                }
                else
                {
                    fw.ExecuteJavascriptSetText(RAM.RAMReportPage.EffDateTo, currentDate);
                }
            }
        }


        [Then(@"Report page Start Date is selected for CMS Queue Report")]
        [When(@"Report page Start Date is selected for CMS Queue Report")]
        public void ThenReportPageStartDateIsSelectedForCMSQueueReport()
        {
            DateTime date = DateTime.Now;
            DateTime firstDayOfMonth = new DateTime(date.Year, date.Month, 1);
            string startDate = firstDayOfMonth.ToString("MM/dd/yyyy");
            tmsWait.Hard(2);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(1);
                
                string value = startDate.Replace("/", "");
                By Drp = By.XPath("//kendo-datepicker[@test-id='Mindate']//input");
                Browser.Wd.FindElement(Drp).Clear();
                Browser.Wd.FindElement(Drp).SendKeys(value);

                tmsWait.Hard(3);
            }
            else
            {
                fw.ExecuteJavascriptSetText(RAM.RAMReportPage.StartKendoDate, startDate);
            }
        }


        [Then(@"Report page End Date is selected for CMS Queue Report")]
        [When(@"Report page End Date is selected for CMS Queue Report")]
        public void ThenReportPageEndDateIsSelectedForCMSQueueReport()
        {
            DateTime date = DateTime.Now;
            string currentDate = date.ToString("MM/dd/yyyy");
            tmsWait.Hard(2);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(1);
                
                string value = currentDate.Replace("/", "");
                By Drp = By.XPath("//kendo-datepicker[@test-id='ThroughDate']//input");
                Browser.Wd.FindElement(Drp).Clear();
                Browser.Wd.FindElement(Drp).SendKeys(value);

                tmsWait.Hard(3);
            }
            else
            {
                fw.ExecuteJavascriptSetText(Browser.Wd.FindElement(By.CssSelector("input[test-id='ThroughDate']")), currentDate);
            }
        }

        [Then(@"on Search Criteria page Fallout Start Date ""(.*)"" is selected")]
        public void ThenOnSearchCriteriaPageFalloutSrartDateIsSelected(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0.ToString());
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(1);
                
                string value = GeneratedData.Replace("/", "");
                By Drp = By.XPath("//kendo-datepicker[@test-id='StartDate']//input");
                Browser.Wd.FindElement(Drp).Clear();
                Browser.Wd.FindElement(Drp).SendKeys(value);

                tmsWait.Hard(3);
            }
            else
            {
                fw.ExecuteJavascriptSetText(RAM.RAMReportPage.NoRxStartDate, GeneratedData);
            }
        }


        [Then(@"on Search Criteria page Fallout End Date is selected")]
        public void ThenOnSearchCriteriaPageFalloutEndDateIsSelected()
        {
            DateTime date = DateTime.Now;
            string currentDate = date.ToString("MM/dd/yyyy");
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(1);
                
                string value = currentDate.Replace("/", "");
                By Drp = By.XPath("//kendo-datepicker[@test-id='EndDate']//input");
                Browser.Wd.FindElement(Drp).Clear();
                Browser.Wd.FindElement(Drp).SendKeys(value);

                tmsWait.Hard(3);
            }
            else
            {
                fw.ExecuteJavascriptSetText(RAM.RAMReportPage.NoRxEndDate, currentDate);
            }
        }

        [Then(@"on Search Criteria page Fallout File Name is set to ""(.*)""")]
        public void ThenOnSearchCriteriaPageFalloutFileNameIsSetTo(string p0)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(1);
                
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='Files']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + p0 + "']");

                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
            }
            else
            {
                SelectElement FalloutFile_DD = new SelectElement(RAM.RAMReportPage.FalloutFileName);
                FalloutFile_DD.SelectByText(p0);
            }
        }


        [Then(@"on Search Criteria page ElectionType is set to ""(.*)""")]
        public void ThenOnSearchCriteriaPageElectionTypeIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0.ToString());
            if (ConfigFile.EnvType.Equals("ESI"))
            {

            }
            else
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    tmsWait.Hard(1);

                    IWebElement elecType = Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='ElectionType']//input"));

                    elecType.SendKeys(GeneratedData);
                    tmsWait.Hard(3);
                    elecType.SendKeys(OpenQA.Selenium.Keys.Enter);
                }
                else
                {
                    string xpathstring = "//multiselect[@test-id='ElectionType']//a[contains(.,'" + GeneratedData + "')]";
                    SelectDropDownValues(xpathstring);
                }
            }

        }


        [Then(@"Report page Start Date is selected for Data Load Detail Report")]
        public void ThenReportPageStartDateIsSelectedForDataLoadDetailReport()
        {
            DateTime date = DateTime.Now;
            DateTime firstDayOfMonth = new DateTime(date.Year, date.Month, 1);
            string startDate = firstDayOfMonth.ToString("MM/dd/yyyy");
            tmsWait.Hard(2);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(1);
                
                string value = startDate.Replace("/", "");
                By Drp = By.XPath("//kendo-datepicker[@test-id='Mindate']//input");
                Browser.Wd.FindElement(Drp).Clear();
                Browser.Wd.FindElement(Drp).SendKeys(value);

                tmsWait.Hard(3);
            }
            else
            {
                fw.ExecuteJavascriptSetText(RAM.RAMReportPage.StartKendoDate, startDate);
            }
        }


        [Then(@"Report page End Date is selected for Data Load Detail Report")]
        public void ThenReportPageEndDateIsSelectedForDataLoadDetailReport()
        {
            DateTime date = DateTime.Now;
            string currentDate = date.ToString("MM/dd/yyyy");
            tmsWait.Hard(2);
            fw.ExecuteJavascriptSetText(Browser.Wd.FindElement(By.CssSelector("input[test-id='EndDate']")), currentDate);
        }
        [When(@"on Search Criteria page Created Date ""(.*)"" is set to ""(.*)""")]
        public void WhenOnSearchCriteriaPageCreatedDateIsSetTo(string p0, string p1)
        {
            string GeneratedData = tmsCommon.GenerateData(p1.ToString());
            string[] date = GeneratedData.Split('/');

            date[0] = "01";
            string[] date1 = GeneratedData.Split('/'); ;
            date1[0] = "30";
            if (p0.ToLower().Equals("to"))
            {
                IWebElement calButton = Browser.Wd.FindElement(By.XPath("(//button[@class='btn btn-default reportsCalendar '])[1]"));
                fw.ExecuteJavascript(calButton);
                tmsWait.Hard(3);
                try {
                    IWebElement calDate = Browser.Wd.FindElement(By.XPath("(//div[@datepicker-options='datepickerOptions']//table/tbody//button/span[contains(.,'" + date1[0] + "')])[2]"));
                    fw.ExecuteJavascript(calDate);
                }
                catch {
                    IWebElement calDate = Browser.Wd.FindElement(By.XPath("(//div[@datepicker-options='datepickerOptions']//table/tbody//button/span[contains(.,'" + date1[0] + "')])[1]"));
                    fw.ExecuteJavascript(calDate);
                }


            }
            else
            {
                IWebElement calButton = Browser.Wd.FindElement(By.XPath("(//button[@class='btn btn-default reportsCalendar'])[1]"));
                fw.ExecuteJavascript(calButton);
                tmsWait.Hard(3);
                IWebElement calDate = Browser.Wd.FindElement(By.XPath("(//div[@datepicker-options='datepickerOptions']//table/tbody//button/span[contains(.,'" + date[0] + "')])[1]"));
                fw.ExecuteJavascript(calDate);
            }
        }

        [When(@"on Search Criteria page DueDate Date ""(.*)"" is set to ""(.*)""")]
        public void WhenOnSearchCriteriaPageDueDateDateIsSetTo(string p0, string p1)
        {
            string GeneratedData = tmsCommon.GenerateData(p1.ToString());
            string[] date = GeneratedData.Split('/');
            date[0] = "01";

            string[] date1 = GeneratedData.Split('/');
            date1[0] = "30";
            if (p0.ToLower().Equals("to"))
            {
                IWebElement calButton = Browser.Wd.FindElement(By.XPath("(//button[@class='btn btn-default reportsCalendar '])[2]"));
                fw.ExecuteJavascript(calButton);
                tmsWait.Hard(3);
                try {
                    IWebElement calDate = Browser.Wd.FindElement(By.XPath("(//div[@datepicker-options='datepickerOptions']//table/tbody//button/span[contains(.,'" + date1[0] + "')])[2]"));
                    fw.ExecuteJavascript(calDate);

                }
                catch
                {
                    IWebElement calDate = Browser.Wd.FindElement(By.XPath("(//div[@datepicker-options='datepickerOptions']//table/tbody//button/span[contains(.,'" + date1[0] + "')])[1]"));
                    fw.ExecuteJavascript(calDate);
                }
            }
            else
            {
                IWebElement calButton = Browser.Wd.FindElement(By.XPath("(//button[@class='btn btn-default reportsCalendar'])[2]"));
                fw.ExecuteJavascript(calButton);
                tmsWait.Hard(3);
                IWebElement calDate = Browser.Wd.FindElement(By.XPath("(//div[@datepicker-options='datepickerOptions']//table/tbody//button/span[contains(.,'" + date[0] + "')])[1]"));
                fw.ExecuteJavascript(calDate);
            }
        }

        [Then(@"RSM Report page Start Date is selected")]
        [Then(@"RxM Report page Start Date is selected")]
        public void ThenRSMReportPageStartDateIsSelected()
        {
            By start=By.XPath("//kendo-datepicker[@test-id='StartDate']//span[@role='button']");
            AngularFunction.enterRAMX_RXM_Date(start, "01/01/2020");
            
        }

        [Then(@"Verify RxM Report page ""(.*)"" field is displayed")]
        public void ThenVerifyRxMReportPageFieldIsDisplayed(string p0)
        {
            if(p0.Contains("PlanID"))
            {
                AngularFunction.selectDropDownValue(cfRXMReports.RXMReports.PlanID, "All");
            }
            else if(p0.Contains("PBP"))
            {
                AngularFunction.selectDropDownValue(cfRXMReports.RXMReports.PBP, "All");
            }
            else if (p0.Contains("Year Of Service"))
            {
                AngularFunction.selectDropDownValue(cfRXMReports.RXMReports.YearOfService, "All");
            }
            else if(p0.Contains("StatusID"))
            {
                AngularFunction.selectDropDownValue(cfRXMReports.RXMReports.StatusID, "All");
            }
            
        }




        [Then(@"Rxm Report page End Date is selected")]
        [Then(@"RMS Report page End Date is selected")]
        public void ThenRMSReportPageEndDateIsSelected()
        {
            By start = By.XPath("//kendo-datepicker[@test-id='EndDate']//span[@role='button']");
            AngularFunction.enterRAMX_RXM_Date(start, "01/11/2020");
        }
        [When(@"RAM Report page Payment Year Selected as Current Year Plus One")]
        public void WhenRAMReportPagePaymentYearSelectedAsCurrentYearPlusOne()
        {
            string todaydate = DateTime.Now.ToString("MM/dd/yyyy");
            string currentYearPlusOne = (Convert.ToInt32(todaydate.Split('/')[2]) + 1).ToString();

            new SelectElement(Browser.Wd.FindElement(By.CssSelector("[test-id='PaymentYear']"))).SelectByText(currentYearPlusOne);

        }

        [When(@"RAM Application Report page Payment Year Selected as ""(.*)""")]
        public void WhenRAMApplicationReportPagePaymentYearSelectedAs(string p0)
        {
            string todaydate = tmsCommon.GenerateData(p0);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='PaymentYear']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + todaydate + "']");
            AngularFunction.clickOnElement(Drp);
            AngularFunction.clickOnElement(typeapp);
        }

        [When(@"RAM Report page Payment Year Selected as ""(.*)"" Plus One Year")]
        public void WhenRAMReportPagePaymentYearSelectedAsPlusOneYear(string p0)
        {
            string todaydate = tmsCommon.GenerateData(p0);
            string currentYearPlusOne = (Convert.ToInt32(todaydate.Split('/')[2]) + 1).ToString();
          
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='PaymentYear']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + currentYearPlusOne + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }

        [When(@"RAM Report page Payment Year is Selected as ""(.*)""")]
        public void WhenRAMReportPagePaymentYearIsSelectedAs(string p0)
        {
            string paymentYear = tmsCommon.GenerateData(p0);

            By Drp = By.XPath("//kendo-dropdownlist[@test-id='PaymentYear']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + paymentYear + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }


        [When(@"RAM Report page Payment Year drop down selected as ""(.*)""")]
        public void WhenRAMReportPagePaymentYearDropDownSelectedAs(string p0)
        {
            tmsWait.Hard(3);
            string dateValue = tmsCommon.GenerateData(p0);
            string paymentYear = (Convert.ToInt32(((dateValue.Split(' '))[0].Split('/'))[2]) + 1).ToString();

            new SelectElement(Browser.Wd.FindElement(By.CssSelector("[test-id='PaymentYear']"))).SelectByText(paymentYear);
        }

        [When(@"RAM Report page Payment Year Selected as ""(.*)""")]
        public void WhenRAMReportPagePaymentYearSelectedAs(string p0)
        {
            tmsWait.Hard(2);
            string Pyear = tmsCommon.GenerateData(p0);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='PaymentYear']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + p0 + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }
        [When(@"RAMX Report page Payment Year is set to ""(.*)""")]
        public void WhenRAMXReportPagePaymentYearIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string dateValue = tmsCommon.GenerateData(p0);

            string paymentYear = (Convert.ToInt32(dateValue.Split('/')[2]) + 1).ToString();
            new SelectElement(Browser.Wd.FindElement(By.CssSelector("[test-id='PaymentYear']"))).SelectByText(paymentYear);
        }

        [When(@"RAMX Report page Payment Year Selected as ""(.*)""")]
        public void WhenRAMXReportPagePaymentYearSelectedAs(string p0)
        {
            tmsWait.Hard(2);
            string dateValue = tmsCommon.GenerateData(p0);
            string lastYear = Convert.ToInt32(dateValue).ToString();
            string paymentYear = (Convert.ToInt32(dateValue)).ToString();
            string currentYear = DateTime.Now.Year.ToString();
            if (paymentYear == currentYear)
            {
                //new SelectElement(Browser.Wd.FindElement(By.CssSelector("[test-id='PaymentYear']"))).SelectByText(lastYear);
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='PaymentYear']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + lastYear + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            }
            else
            {
                //new SelectElement(Browser.Wd.FindElement(By.CssSelector("[test-id='PaymentYear']"))).SelectByText(paymentYear);
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='PaymentYear']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + paymentYear + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            }

        }

        [When(@"RAMX Report page Payment Year Selected ""(.*)""")]
        public void WhenRAMXReportPagePaymentYearSelected(string p0)
        {
            tmsWait.Hard(2);
            string paymentYear = tmsCommon.GenerateData(p0);
            // new SelectElement(Browser.Wd.FindElement(By.CssSelector("[test-id='PaymentYear']"))).SelectByText(paymentYear);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='PaymentYear']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + paymentYear + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }

        [When(@"RAMX Report page Include Staging Data Check box is Clicked")]
        [When(@"RAM Report page Include Staging Data Check box is Clicked")]
        public void WhenRAMReportPageIncludeStagingDataCheckBoxIsClicked()
        {
            IWebElement stageCheck = Browser.Wd.FindElement(By.CssSelector("[test-id='IsStagingDataIncluded']"));
            fw.ExecuteJavascript(stageCheck);
            tmsWait.Hard(2);
        }


        [When(@"RAM report page End Date is entered as Today Date")]
        [Then(@"RAM report page End Date is entered as Today Date")]
        [Given(@"RAM report page End Date is entered as Today Date")]
        public void WhenRAMReportPageEndDateIsEnteredAsTodayDate()
        {
            string dateValue =DateTime.Now.ToString("M/d/yyyy");

            By date = By.XPath("(//kendo-datepicker//span[@class='k-select'])[2]");
            AngularFunction.enterDate_In_Report(date, dateValue);


        }

        [When(@"RAM Ineligible Records for CMS Extract report page End Date is entered as Today Date")]
        public void WhenRAMIneligibleRecordsForCMSExtractReportPageEndDateIsEnteredAsTodayDate()
        {
            string startDate = DateTime.Now.ToString("M/d/yyyy");
            IWebElement toDate = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='ThroughDate']//span/input"));
            string startDate1 = startDate.Replace("/", "");
            toDate.Clear();
            toDate.SendKeys(startDate1);
        }


        [When(@"RAM CMS Queue report page End Date is entered as Today Date")]
        public void WhenRAMCMSQueueReportPageEndDateIsEnteredAsTodayDate()
        {
            string startDate = DateTime.Now.ToString("M/d/yyyy");
            IWebElement toDate = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='ThroughDate']//span/input"));
            string startDate1 = startDate.Replace("/", "");
            toDate.Clear();
            toDate.SendKeys(startDate1);
        }


        [When(@"RAM report page Start Date is entered as Current Year Jan")]
        public void WhenRAMReportPageStartDateIsEnteredAsCurrentYearJan()
        {

            DateTime currentTime = DateTime.Now;
            string startDate = "01/01/" + currentTime.Year;
            //IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='Mindate']//span/input"));
            //string value1 = startDate.Replace("/", "");
            //ele.Clear();
            //ele.SendKeys(value1);

            string[] svalue = startDate.Split(' ');
            
            IWebElement el = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='PlanId']//span"));
            el.SendKeys(Keys.Tab);
 
            tmsWait.Hard(3);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='Mindate']//input"));
            string[] value1 = svalue[0].Split('/');
            ele.SendKeys(value1[0]);
            ele.SendKeys(value1[1]);
            ele.SendKeys(value1[2]);
            ele.SendKeys(Keys.Tab);
            tmsWait.Hard(3);
        }

        [When(@"RAM CMS Queue report page Start Date is entered as Current Year Jan")]
        public void WhenRAMCMSQueueReportPageStartDateIsEnteredAsCurrentYearJan()
        {
            DateTime currentTime = DateTime.Now;
            string startDate = "01/01/" + currentTime.Year;
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='FromDate']//span/input"));
            string value1 = startDate.Replace("/", "");
            ele.Clear();
            ele.SendKeys(value1);
            tmsWait.Hard(3);
        }


        [When(@"RAMX report page End Date is entered as ""(.*)""")]
        public void WhenRAMXReportPageEndDateIsEnteredAs(string p0)
        {
            string dateValue = "";
            tmsWait.Hard(2);
            if (p0.Equals("TodayDate"))
            {
                dateValue = DateTime.Now.ToString("M/d/yyyy");
            }
            //IWebElement el = Browser.Wd.FindElement(By.XPath("(//kendo-dateinput/span)[1]"));
            //el.SendKeys(Keys.Tab);
            IWebElement Sdate = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='EndDate']//input"));
            string[] value1 = dateValue.Split('/');
            Sdate.SendKeys(value1[0]);
            Sdate.SendKeys(value1[1]);
            Sdate.SendKeys(value1[2]);

            //string date = dateValue.Split(' ')[0];
            //string mon = date.Split('/')[0];
            //string dayValue = date.Split('/')[1];
            //string yearValue = date.Split('/')[2];
            //string monthvalue = "";

            ///*Code of angular updates*/
            //date = dateValue.Replace("/", "");
            //By Drp = By.XPath("//label[text()='End Date:']/parent::div//input");
            //Browser.Wd.FindElement(Drp).Clear();
            //Browser.Wd.FindElement(Drp).SendKeys(date);

            tmsWait.Hard(3);

            /* //Code for pre Angular changes
            switch (mon)
            {
                case "01":
                case "1":
                    monthvalue = "January";
                    break;
                case "02":
                case "2":
                    monthvalue = "March";
                    break;
                case "3":
                case "03":
                    monthvalue = "April";
                    break;
                case "4":
                case "04":
                    monthvalue = "May";
                    break;
                case "5":
                case "05":
                    monthvalue = "June";
                    break;
                case "06":
                case "6":
                    monthvalue = "July";
                    break;
                case "7":
                case "07":
                    monthvalue = "August";
                    break;
                case "08":
                case "8":
                    monthvalue = "September";
                    break;
                case "9":
                case "09":
                    monthvalue = "September";
                    break;
                case "10":
                    monthvalue = "November";
                    break;
                case "11":
                    monthvalue = "December";
                    break;
                case "12":
                    monthvalue = "December";
                    break;
            }



            // click on calendar icon
            IWebElement selectedDate = Browser.Wd.FindElement(By.XPath("//button[@class='btn btn-default reportsCalendar ']"));
            fw.ExecuteJavascript(selectedDate);
            // click on calendar Head Title
            IWebElement title = Browser.Wd.FindElement(By.XPath("//button[@class='btn btn-default btn-sm uib-title']"));
            fw.ExecuteJavascript(title);

            // Click on Left 
            By leftArrow = By.XPath("//button[@class='btn btn-default btn-sm pull-left uib-left']");
            By rightArrow = By.XPath("//button[@class='//button[@class='btn btn-default btn-sm pull-right uib-right']']");

            By expectedYearLoc;
            By expectedMonthLoc;
            By expectedDayLoc;

            expectedMonthLoc = By.XPath("(//table[@role='grid']/tbody/tr[contains(.,'" + monthvalue + "')]//button)[3]");
            expectedYearLoc = By.XPath("//button[@role='heading']/strong[.='" + yearValue + "']");
            expectedDayLoc = By.XPath("(//div[@datepicker-options='datepickerOptions']//table/tbody//button/span[contains(.,'" + dayValue + "')])[1]");


            bool elementFound = foundDate(expectedYearLoc, leftArrow);
            if (elementFound)
            {
                fw.ConsoleReport(" Year found");
            }
            bool MonthFound = foundDate(expectedMonthLoc, leftArrow);
            if (MonthFound)
            {

                fw.ExecuteJavascript(Browser.Wd.FindElement(expectedMonthLoc));
                fw.ConsoleReport(" Month found");
            }
            bool DayFound = foundDate(expectedDayLoc, leftArrow);

            if (DayFound)
            {

                fw.ExecuteJavascript(Browser.Wd.FindElement(expectedDayLoc));
                fw.ConsoleReport(" Day found");
            } */
        }

        [When(@"RAMX report page EncounterDate Start Date is entered as ""(.*)""")]


        [When(@"RAMX report page EncounterDate End Date is entered as ""(.*)""")]

        public void WhenRAMXReportPageEncounterDateDateIsEnteredAs(string value)
        {
            tmsWait.Hard(2);
            string date = tmsCommon.GenerateData(value);
            //  string date = tmsCommon.GenerateData(dateValue).Split(' ')[0];
            string mon = date.Split('/')[0];
            string dayValue = date.Split('/')[1];
            string yearValue = date.Split('/')[2].ToString();

            string monthvalue = "";
            switch (mon)
            {
                case "01":
                case "1":
                    monthvalue = "January";
                    break;
                case "02":
                case "2":
                    monthvalue = "January";
                    break;
                case "03":
                case "3":
                    monthvalue = "March";
                    break;
                case "04":
                case "4":
                    monthvalue = "April";
                    break;
                case "05":
                case "5":
                    monthvalue = "May";
                    break;
                case "06":
                case "6":
                    monthvalue = "June";
                    break;
                case "07":
                case "7":
                    monthvalue = "July";
                    break;
                case "08":
                case "8":
                    monthvalue = "August";
                    break;
                case "09":
                case "9":
                    monthvalue = "September";
                    break;
                case "10":
                    monthvalue = "October";
                    break;
                case "11":
                    monthvalue = "November";
                    break;
                case "12":
                    monthvalue = "December";
                    break;
            }



            // click on calendar icon
            IWebElement selectedDate = Browser.Wd.FindElement(By.XPath("//button[@class='btn btn-default reportsCalendar']"));
            fw.ExecuteJavascript(selectedDate);
            // click on calendar Head Title
            IWebElement title = Browser.Wd.FindElement(By.XPath("//button[@class='btn btn-default btn-sm uib-title']"));
            fw.ExecuteJavascript(title);

            // Click on Left 
            By leftArrow = By.XPath("//button[@class='btn btn-default btn-sm pull-left uib-left']");
            By rightArrow = By.XPath("//button[@class='//button[@class='btn btn-default btn-sm pull-right uib-right']']");

            By expectedYearLoc;
            By expectedMonthLoc;
            By expectedDayLoc;

            expectedMonthLoc = By.XPath("//table[@role='grid']/tbody/tr[contains(.,'" + monthvalue + "')]//button");
            expectedYearLoc = By.XPath("//button[@role='heading']/strong[.='" + yearValue + "']");
            expectedDayLoc = By.XPath("(//div[@datepicker-options='datepickerOptions']//table/tbody//button/span[contains(.,'" + dayValue + "')])[1]");


            bool elementFound = foundDate(expectedYearLoc, leftArrow);
            if (elementFound)
            {
                fw.ConsoleReport(" Year found");
            }
            bool MonthFound = foundDate(expectedMonthLoc, leftArrow);
            if (MonthFound)
            {

                fw.ExecuteJavascript(Browser.Wd.FindElement(expectedMonthLoc));
                fw.ConsoleReport(" Month found");
            }
            bool DayFound = foundDate(expectedDayLoc, leftArrow);

            if (DayFound)
            {

                fw.ExecuteJavascript(Browser.Wd.FindElement(expectedDayLoc));
                fw.ConsoleReport(" Day found");
            }
        }

        [When(@"RAMX report page ""(.*)"" is entered as ""(.*)""")]
        public void WhenRAMXReportPageIsEnteredAs(string p0, string p1)
        {
            switch (p0) {
                case "Payment Year":
                    SelectElement payyear = new SelectElement(Browser.Wd.FindElement(By.XPath("//*[@test-id='PayYear']")));
                    payyear.SelectByValue(p1);
                    break;

                case "Plan":
                    SelectElement plan = new SelectElement(Browser.Wd.FindElement(By.XPath("//*[@test-id='PlanId']")));
                    plan.SelectByValue(p1);
                    break;

            }
        }



        [When(@"RAMX report page Start Date is entered as ""(.*)""")]
        [When(@"RAM report page Start Date is entered as ""(.*)""")]
        public void WhenRAMReportPageStartDateIsEnteredAs(string value)
        {
            tmsWait.Hard(2);

            string dateValue = tmsCommon.GenerateData(value);
            By date = By.XPath("(//kendo-datepicker//span[@class='k-select'])[1]");
            AngularFunction.enterDate_In_Report(date, dateValue);

           

        }

        public bool foundDate(By loc, By leftArrow)
        {
            bool elementFound = false;
            while (!elementFound)
            {
                try
                {

                    bool elementDisp = Browser.Wd.FindElement(loc).Displayed;
                    if (!elementDisp)
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(leftArrow));
                        elementFound = true;
                    }
                    else if (elementDisp)
                    {

                        elementFound = true;
                    }
                }
                catch
                {
                    fw.ExecuteJavascript(Browser.Wd.FindElement(leftArrow));

                }


            }
            return elementFound;
        }
        [When(@"RAM report page End Date is entered as ""(.*)""")]
        public void WhenRAMReportPageEndDateIsEnteredAs(string p0)
        {
            tmsWait.Hard(2);
            
            string dateValue = tmsCommon.GenerateData(p0);
            string[] evalue = dateValue.Split(' ');
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='ThroughDate']//input"));
            string[] evalue1 = evalue[0].Split('/');
            ele.SendKeys(evalue1[0]);
            ele.SendKeys(evalue1[1]);
            ele.SendKeys(evalue1[2]);
           // ele.SendKeys(Keys.Tab);
            //IWebElement selectedDate = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='ThroughDate']//span[@role='button']"));
            //fw.ExecuteJavascript(selectedDate);
            //tmsWait.Hard(3);
            //By todayDate = By.XPath("//button[@class='btn btn-default btn-sm active']");
            //tmsWait.Hard(3);
            //fw.ExecuteJavascript(Browser.Wd.FindElement(todayDate));
            //AngularFunction.enterDate(selectedDate, evalue[0]);
            tmsWait.Hard(3);

        }




        [When(@"RAM report page Start Date is entered as Today Date")]
        [Then(@"RAM report page Start Date is entered as Today Date")]
        [Given(@"RAM report page Start Date is entered as Today Date")]
        public void WhenRAMReportPageStartDateIsEnteredAsTodayDate()
        {

            string todaydate = DateTime.Now.ToString("MM/dd/yyyy");

            string currentdate = todaydate.Split('/')[1].ToString();
            string currentMon = todaydate.Split('/')[0].ToString();
            IWebElement calButton = Browser.Wd.FindElement(By.XPath("(//button[@class='btn btn-default reportsCalendar'])[1]"));
            fw.ExecuteJavascript(calButton);
            tmsWait.Hard(3);
            IWebElement calDate = Browser.Wd.FindElement(By.XPath("(//div[@datepicker-options='datepickerOptions']//table/tbody//button/span[contains(.,'" + currentdate + "')])[1]"));

            fw.ExecuteJavascript(calDate);
            IWebElement selectedDate;
            try
            {
                selectedDate = Browser.Wd.FindElement(By.CssSelector("[test-id='Mindate']"));
            }
            catch
            {
                selectedDate = Browser.Wd.FindElement(By.CssSelector("[test-id='FromDate']"));
            }
            string selectedMon = selectedDate.GetAttribute("value").Split('/')[0].ToString();
            if (selectedMon.Equals(currentMon))
            {
                fw.ConsoleReport(" Selected Date is Proper");
            }
            else
            {

                fw.ExecuteJavascript(calButton);
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//div[@datepicker-options='datepickerOptions']//table/tbody//button/span[contains(.,'" + currentdate + "')])[2]")));
            }


        }


        [When(@"Report page Start Date is selected")]
        [Then(@"Report page Start Date is selected")]
        public void WhenReportPageStartDateIsSelected()
        {

            IWebElement calButton = Browser.Wd.FindElement(By.XPath("(//button[@class='btn btn-default reportsCalendar'])[1]"));
            fw.ExecuteJavascript(calButton);
            tmsWait.Hard(3);
            IWebElement calDate = Browser.Wd.FindElement(By.XPath("(//div[@datepicker-options='datepickerOptions']//table/tbody//button/span[contains(.,'01')])[1]"));
            fw.ExecuteJavascript(calDate);







            //DateTime date = DateTime.Now;
            //DateTime firstDayOfMonth = new DateTime(date.Year, date.Month, 1);
            //string startDate = firstDayOfMonth.ToString("MM/dd/yyyy");
            //tmsWait.Hard(2);

        }

        [When(@"Report page End Date is selected")]
        [Then(@"Report page End Date is selected")]
        public void WhenReportPageEndDateIsSelected()
        {

            IWebElement calButton = Browser.Wd.FindElement(By.XPath("//button[@class='btn btn-default reportsCalendar ']"));
            fw.ExecuteJavascript(calButton);
            tmsWait.Hard(3);
            IWebElement calDate = Browser.Wd.FindElement(By.XPath("(//div[@datepicker-options='datepickerOptions']//table/tbody//button/span[contains(.,'21')])[1]"));
            fw.ExecuteJavascript(calDate);

            //DateTime date = DateTime.Now;
            //string currentDate = date.ToString("MM/dd/yyyy");
            //tmsWait.Hard(2);
            //fw.ExecuteJavascriptSetText(RAM.RAMReportPage.EndKendoDate, currentDate);
        }


        [Then(@"Verify File Processing Page ""(.*)"" report name is displayed")]
        public void ThenVerifyFileProcessingPageReportNameIsDisplayed(string reportName)
        {
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[text()='" + reportName + "']")).Displayed);
        }

        [Then(@"Verify the RAM File Processing Status page report ""(.*)"" status is ""(.*)""")]
        public void ThenVerifyTheRAMFileProcessingStatusPageReportStatusIs(string reportName, string reportStatus)
        {
            tmsWait.Hard(2);
            string actualStatus;
            string xpath = "//div[text()='" + reportName + "']//parent::div/preceding-sibling::div//span[1]";
            actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
            int ReturnStatus = StatusValidation(actualStatus);

            while (ReturnStatus != 0)
            {
                actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                ReturnStatus = StatusValidation(actualStatus);
            }
        }

        public int StatusValidation(string actualStatus)
        {
            if (actualStatus.Equals("Pending"))
            {
                tmsWait.Hard(2);
                return 1;
            }
            else if (actualStatus.Equals("Executing"))
            {
                return 1;
            }
            else if (actualStatus.Equals("Failed"))
            {
                Assert.Fail("Report Generation Job is failed");
                return 0;
            }
            else if (actualStatus.Equals("Complete"))
            {
                return 0;
            }
            return 0;
        }


        [When(@"RAM Report Manager page Report Name ""(.*)"" is selected")]
        public void WhenRAMReportManagerPageReportNameIsSelected(string reportName)
        {
            tmsWait.Hard(5);
            string xpathstring = "//multiselect[@test-id='multiSelectReports']//a[contains(.,'" + reportName + "')]/span";
            SelectDropDownValues(xpathstring);
        }

        [When(@"RAM Report Manager page Plan ID ""(.*)"" is selected")]
        public void WhenRAMReportManagerPagePlanIDIsSelected(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0.ToString());
            string xpathstring = "//multiselect[@test-id='multiSelectPlans']//a[contains(.,'" + GeneratedData + "')]/span";
            SelectDropDownValues(xpathstring);
        }

        public void SelectDropDownValues(string xpathstring)
        {
            IWebElement test = Browser.Wd.FindElement(By.XPath(xpathstring));
            fw.ExecuteJavascript(test);
        }

        [When(@"RAM Report Manager Search button is clicked")]
        public void WhenRAMReportManagerSearchButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.RAMReportPage.SearchButton);

            tmsWait.Hard(3);
            GlobalRef.InitialReportCount = GetReportManagerRecordsCount();
        }

        [When(@"RAM Report Manager Delete button is clicked for report ""(.*)""")]
        public void WhenRAMReportManagerDeleteButtonIsClickedForReport(string reportName)
        {
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[contains(.,'"+reportName+"')]//div//a//span[contains(@class,'fa fa-trash fa fa-trash')]")));
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//input[@type='checkbox'])[2]")));
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='reportManager-btn-delete']")));
        }

        [When(@"RAM Report Manager Delete Warning ""(.*)"" button is clicked")]
        public void WhenRAMReportManagerDeleteWarningButtonIsClicked(string deleteAction)
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(".//*[@id='confirmationDialogYes']")));
            // tmsWait.Hard(2);
            //Browser.ClosePopUps(true);
        }

        [When(@"Verify RAM Report Manager total record count decreased by one")]
        public void WhenVerifyRAMReportManagerTotalRecordCountDecreasedByOne()
        {
            tmsWait.Hard(5);
            var countAfterDelete = GetReportManagerRecordsCount();
            var initialCount = GlobalRef.InitialReportCount;
            int initialReportCount = Convert.ToInt32(initialCount);
            Assert.AreEqual(countAfterDelete + 1, initialReportCount);
        }

        public int GetReportManagerRecordsCount()
        {
            var initialText = Browser.Wd.FindElement(By.XPath("//*[@id='ResultGridDiv']/div[2]/div/div[1]/span")).Text;
            var partialText = initialText.Remove(0, initialText.IndexOf('(') + 1);
            return Convert.ToInt32(Regex.Match(partialText, @"\d+").Value);
        }

        [Then(@"Search Criteria page Provider search button is clicked")]
        public void ThenSearchCriteriaPageProviderSearchButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(RAM.RAMReportPage.ProviderLookupButton);
            tmsWait.Hard(2);
            //IWebElement form = Browser.Wd.FindElement(By.Id("frmViewSearchProvider"));


        }
        [Then(@"Search Criteria page Provider Lookup icon is Clicked")]
        public void ThenSearchCriteriaPageProviderLookupIconIsClicked()
        {
            tmsWait.Hard(2);
            IWebElement icon = Browser.Wd.FindElement(By.XPath("(//span[@test-id='report-link-group']/a)[1]"));
            fw.ExecuteJavascript(icon);
        }

        [Then(@"Search Criteria page Group Lookup search button is clicked")]
        public void ThenSearchCriteriaPageGroupLookupSearchButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(RAM.RAMReportPage.GroupLookupButton);
        }


        [Then(@"Search Criteria page Member ID Lookup button is clicked")]
        public void ThenSearchCriteriaPageMemberIDLookupButtonIsClicked()
        {
            tmsWait.Hard(5);
           
            fw.ExecuteJavascript(RAM.RAMReportPage.MemberIDLookupButton1);
            tmsWait.Hard(5);
        }

        [Then(@"Search Criteria page Member ID Lookup button is clicked Successfully")]
        public void ThenSearchCriteriaPageMemberIDLookupButtonIsClickedSuccessfully()
        {
            tmsWait.Hard(5);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("(//span[@test-id='report-link-group']/a)[2]"));
            fw.ExecuteJavascript(ele);
            tmsWait.Hard(5);
        }


        [Then(@"Search Criteria page Search result is displayed")]
        public void ThenSearchCriteriaPageSearchResultIsDisplayed()
        {
            tmsWait.Hard(6);

            IReadOnlyCollection<IWebElement> lookup = Browser.Wd.FindElements(By.XPath("//kendo-grid[@test-id='lookup-grid-memberLookup']//tbody/tr"));
            int dataSize = lookup.Count;
            bool resultsGridPresence = (dataSize > 0);
            Assert.IsTrue(resultsGridPresence, "Search results is empty");
        }


        [Then(@"Search Criteria page Search result is getting displayed")]
        public void ThenSearchCriteriaPageSearchResultIsGettingDisplayed()
        {
            tmsWait.Hard(5);

            IReadOnlyCollection<IWebElement> lookup = Browser.Wd.FindElements(By.XPath("//div[@test-id='searchProvider-grid-providerLookup']//table//tr/td"));
            int dataSize = lookup.Count;
            bool resultsGridPresence = (dataSize > 0);
            Assert.IsTrue(resultsGridPresence, "Search results is empty");
        }


        [Then(@"Search Criteria page Error message is displayed for NonExisting value")]
        public void ThenSearchCriteriaPageErrorMessageIsDisplayedForNonExistingValue()
        {
            Assert.IsTrue(RAM.RAMReportPage.ToastMessage.Displayed);
        }


        [Then(@"Search Criteria page PCP Lookup search button is clicked")]
        public void ThenSearchCriteriaPagePCPLookupSearchButtonIsClicked()
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(RAM.RAMReportPage.PCPLookupSearchButton);
        }

        [Then(@"Search Criteria page HCC Lookup search button is clicked")]
        public void ThenSearchCriteriaPageHCCLookupSearchButtonIsClicked()
        {

            fw.ExecuteJavascript(RAM.RAMReportPage.HCCLookupSearchButton);
            tmsWait.Hard(5);
        }




        [Then(@"HCC Lookup Search page HCC Search By is selected as ""(.*)""")]
        public void ThenHCCLookupSearchPageHCCSearchByIsSelectedAs(string p0)
        {
            tmsWait.Hard(5);
            //IWebElement DropdownClick = Browser.Wd.FindElement(By.XPath("//label[@test-id='pcpLookup-lbl-searchBy']/following-sibling::span"));
            //IWebElement value = Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + p0.ToString() + "')]"));
            //KendoUIFunctions.KendoSelectByValue(value, DropdownClick);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='hcc-select-searchBy']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + p0 + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

            //fw.KendoSelectByValue(Browser.Wd, RAM.RAMReportPage.HCCSearchByDropdown, "HCC ID");
        }



        [Then(@"HCC Lookup Search page HCC id is entered ""(.*)""")]
        public void ThenHCCLookupSearchPageHCCIdIsEntered(string id)
        {
            tmsWait.Hard(2);
            RAM.RAMReportPage.HCCIDTextbox.SendKeys(id);
        }


        [Then(@"Search Criteria page Search by selected as ""(.*)""")]
        public void ThenSearchCriteriaPageSearchBySelectedAs(string option)
        {
            tmsWait.Hard(2);
            searchByDD = new SelectElement(RAM.RAMReportPage.SearchByDropdown);
            searchByDD.SelectByText(option);
        }

        [Then(@"PCP Lookup Search page SEARCH button is clicked")]
        public void ThenPCPLookupSearchPageSEARCHButtonIsClicked()
        {
            tmsWait.Hard(2);
            tmsWait.WaitForElement(By.Id("btnSearch"), 30);
            fw.ExecuteJavascript(RAM.RAMReportPage.PCPSEARCHButton);
            tmsWait.Hard(3);
            try
            {
                if (RAM.RAMReportPage.ProviderSearchGrid.Displayed)
                {
                    Assert.IsTrue(RAM.RAMReportPage.ProviderSearchGrid.Displayed);
                }
            }
           catch
            {
                // ignore
            }
           
           
            //IReadOnlyCollection<IWebElement> lookup = Browser.Wd.FindElements(By.CssSelector("[test-id='lookup-grid-searchresult']"));
            //int dataSize = lookup.Count;
            //bool resultsGridPresence = (dataSize > 0);
            //Assert.IsTrue(resultsGridPresence, "Search results are empty");
        }


        [Then(@"PCP Lookup Search page error message is displayed for invalid character")]
        public void ThenPCPLookupSearchPageErrorMessageIsDisplayedForInvalidCharacter()
        {
            tmsWait.Hard(2);
            Assert.IsTrue(RAM.RAMReportPage.InvalidMessage.Text.Contains("No special characters allowed including space"));
        }

        [Then(@"Member Lookup Search page error message is displayed for invalid character")]
        public void ThenMemberLookupSearchPageErrorMessageIsDisplayedForInvalidCharacter()
        {
            tmsWait.Hard(3);
       
            Assert.IsTrue(RAM.RAMReportPage.InvalidMessage.Text.Contains("No special characters allowed including space"));
        }


        [Then(@"Provider Lookup Search page error message is displayed for invalid character")]
        public void ThenProviderLookupSearchPageErrorMessageIsDisplayedForInvalidCharacter()
        {
            tmsWait.Hard(2);
            // Comment toaster message
            Assert.IsTrue(RAM.RAMReportPage.InvalidMessage.Text.Contains("No records available."));
        }


        [Then(@"HCC Lookup Search page SEARCH button is clicked")]
        public void ThenHCCLookupSearchPageSEARCHButtonIsClicked()
        {
            tmsWait.Hard(2);
            RAM.RAMReportPage.HCCSEARCHButton.Click();
            tmsWait.WaitForElement(By.CssSelector("[test-id='lookup-grid-hccLookup']"), 360);
            Assert.IsTrue(RAM.RAMReportPage.ProviderSearchGrid.Displayed);
        }

        [Then(@"HCC Lookup Search page Pagination Grid is present")]
        public void ThenHCCLookupSearchPagePaginationGridIsPresent()
        {
            tmsWait.Hard(5);
            Assert.IsTrue(RAM.RAMReportPage.PaginationGrid.Displayed);
        }

        [Then(@"PCP Lookup Search page Pagination Grid is present")]
        public void ThenPCPLookupSearchPagePaginationGridIsPresent()
        {
            tmsWait.Hard(10);
            Assert.IsTrue(RAM.RAMReportPage.PaginationGrid.Displayed);
        }


        [Then(@"Member Lookup Search page Pagination Grid is present")]
        public void ThenMemberLookupSearchPagePaginationGridIsPresent()
        {
            tmsWait.Hard(10);
            Assert.IsTrue(RAM.RAMReportPage.PaginationGrid.Displayed);
        }

        [Then(@"Provider Lookup Search page Pagination Grid is present")]
        public void ThenProviderLookupSearchPagePaginationGridIsPresent()
        {
            tmsWait.Hard(10);
            Assert.IsTrue(RAM.RAMReportPage.PaginationGrid.Displayed);
        }

        [Then(@"Group Lookup Search page Pagination Grid is present")]
        public void ThenGroupLookupSearchPagePaginationGridIsPresent()
        {
            tmsWait.Hard(10);
            Assert.IsTrue(RAM.RAMReportPage.PaginationGrid.Displayed);
        }

        [Then(@"HCC Lookup Search page SEARCH button is clicked for invalid character")]
        public void ThenHCCLookupSearchPageSEARCHButtonIsClickedForInvalidCharacter()
        {
            tmsWait.Hard(2);
            RAM.RAMReportPage.HCCSEARCHButton.Click();
            Assert.IsTrue(RAM.RAMReportPage.ProviderInvalidCharacter.Text.Contains("No special characters allowed including space"));
        }

        [Then(@"PCP Lookup Search page PCP ID is entered as ""(.*)""")]
        public void ThenPCPLookupSearchPagePCPIDIsEnteredAs(string id)
        {
            tmsWait.Hard(5);
            RAM.RAMReportPage.PCPIDTextbox.SendKeys(id);
        }

        [Then(@"PCP Lookup Search page RESET button is clicked")]
        public void ThenPCPLookupSearchPageRESETButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(RAM.RAMReportPage.RESETPCPButton);
           // Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[@class='k-input ng-scope']")).Text.Equals("PCP ID"));
        }

        [Then(@"HCC Lookup Search page RESET button is clicked")]
        public void ThenHCCLookupSearchPageRESETButtonIsClicked()
        {
            tmsWait.Hard(2);
            //RAM.RAMReportPage.RESETHCCButton.Click();
            fw.ExecuteJavascript(RAM.RAMReportPage.RESETHCCButton);
            //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[@class='k-input ng-scope']")).Text.Equals("HCC ID"));
        }



        [Then(@"Verify selected value displayed as ""(.*)""")]
        public void ThenVerifySelectedValueDisplayedAs(string expectedValue)
        {
            tmsWait.Hard(3);
            //bool elementpresence = false;
            IWebElement ddele = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='pcp-select-searchBy']//span[@class='k-input']"));
            string actual_value = ddele.Text;
            Assert.IsTrue(actual_value.Contains(expectedValue), "Value does not match");
            // elementpresence = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='pcpLookup-list-searchBy']//span[contains(.,'" + expectedValue + "')]")).Displayed;
            //Assert.IsTrue(elementpresence, "Reset fucnctionality is not working");
        }


        [Then(@"PCP Lookup Search page PCP Search By is selected ""(.*)""")]
        public void ThenPCPLookupSearchPagePCPSearchByIsSelected(string option)
        {
            tmsWait.Hard(2);
            By Drp = By.XPath("//label[contains(.,'Search By')]/parent::div//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + option + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
            // fw.KendoSelectByValue(Browser.Wd, RAM.RAMReportPage.PCPSearchBySelectionbox, "First Name");
        }


        [Then(@"PCP Lookup Search page Multiple records are clicked")]
        public void ThenPCPLookupSearchPageMultipleRecordsAreClicked()
        {
            tmsWait.Hard(2);
            
            //Clicking on first record
            Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='lookup-grid-pcpLookup']//tr[1]")).Click();
           // fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='lookup-grid-pcpLookup']//tr[2]")));
            //Clicking on second record
            Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='lookup-grid-pcpLookup']//tr[2]")).Click();
           // fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='lookup-grid-pcpLookup']//tr[3]")));
            
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='lookup-grid-searchresult']//td/input[@class='k-checkbox ng-star-inserted'])[1]")));
            GlobalRef.PCPValue = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='lookup-grid-pcpLookup']//tr[2]/td[@aria-colindex='1']")).Text;
        }

        [Then(@"PCP Lookup Search page Back record is clicked")]
        public void ThenPCPLookupSearchPageBackRecordIsClicked()
        {
            tmsWait.Hard(2);
            RAM.RAMReportPage.BackPCPLookupButton.Click();
        }

        [Then(@"Verify page displayed as ""(.*)""")]
        public void ThenVerifyPageDisplayedAs(string title)
        {
            tmsWait.Hard(2);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@class='main-content-header d-flex'][contains(.,'"+ title + "')]")).Displayed);
        }


        [Then(@"PCP Lookup Search verify last PCP is selected")]
        public void ThenPCPLookupSearchVerifyLastPCPIsSelected()
        {
            bool elementpresence = false;
            var value = GlobalRef.PCPValue;
            elementpresence = Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='PCP']//ul/li[contains(.,'" + value + "')]")).Displayed;
            Assert.IsTrue(elementpresence, "Element is found");
        }

        [Then(@"HCC Lookup Search verify last HCC is selected")]
        public void ThenHCCLookupSearchVerifyLastHCCIsSelected()
        {
            var value = GlobalRef.HCCID;
            bool elementpresence = false;
            elementpresence = Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='HCC']//ul/li[contains(.,'" + value + "')]")).Displayed;
            Assert.IsTrue(elementpresence, "Element is found");
        }


        [Then(@"Provider Lookup page Search By is selected as ""(.*)""")]
        public void ThenProviderLookupPageSearchByIsSelectedAs(string option)
        {
            tmsWait.Hard(2);
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + option + "')]")));
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(".//*[@test-id='searchProvider-txt-"+option+"'")));

        }

        [Then(@"Provider Lookup page Search By dropdown selected as ""(.*)""")]
        public void ThenProviderLookupPageSearchByDropdownSelectedAs(string p0)
        {
            tmsWait.Hard(3);
            //IWebElement drp = Browser.Wd.FindElement(By.CssSelector("[test-id='pcpLookup-list-searchBy']"));
            //SelectElement drplist = new SelectElement(drp);
            //drplist.SelectByText(p0);
            IWebElement DropdownClick = Browser.Wd.FindElement(By.XPath("//label[@test-id='pcpLookup-lbl-searchBy']/following-sibling::span"));
            IWebElement value = Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + p0.ToString() + "')]"));
            KendoUIFunctions.KendoSelectByValue(value, DropdownClick);

        }


        [Then(@"Member Lookup page Search By is selected as ""(.*)""")]
        public void ThenMemberLookupPageSearchByIsSelectedAs(string option)
        {
            tmsWait.Hard(3);

            //By Drp = By.XPath("//label[contains(.,'Search By')]/parent::div//span[@class='k-select']");
            //By typeapp = By.XPath("//li[text()='" + option + "']");
            //fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            //fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='member-select-searchBy']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + option + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
            Console.WriteLine(" Testing");
        }

        [Then(@"Member Lookup page Member First Name is set to ""(.*)""")]
        public void ThenMemberLookupPageMemberFirstNameIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            IWebElement text = Browser.Wd.FindElement(By.CssSelector("[test-id='member-input-SearchBytxt']"));
            text.Clear();
            text.SendKeys(p0);

        }


        [Then(@"Group Lookup page Search By is selected as ""(.*)""")]
        public void ThenGroupLookupPageSearchByIsSelectedAs(string option)
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + option + "')]")));
        }


        [Then(@"Provider Lookup page Provider ID is entered as ""(.*)""")]
        public void ThenProviderLookupPageProviderIDIsEnteredAs(string id)
        {
            tmsWait.Hard(2);
            RAM.RAMReportPage.ProviderIDTextbox.SendKeys(id);
        }

        [Then(@"Member Lookup page Member ID is entered as ""(.*)""")]
        public void ThenMemberLookupPageMemberIDIsEnteredAs(string id)
        {
            tmsWait.Hard(2);
            RAM.RAMReportPage.MemberIDTextbox.SendKeys(id);
        }

        [Then(@"Update PIR Provider page Provider ID is entered as ""(.*)""")]
        public void ThenUpdatePIRProviderPageProviderIDIsEnteredAs(string id)
        {
            tmsWait.Hard(2);
            RAM.RAMReportPage.PIRProviderIDTextbox.SendKeys(id);
        }

        [Then(@"Member Lookup page RESET button is clicked Successfully")]
        public void ThenMemberLookupPageRESETButtonIsClickedSuccessfully()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(RAM.RAMReportPage.RESETPIRProviderButton);
            tmsWait.Hard(2);
        }


        [Then(@"Member Lookup page RESET button is clicked")]
        public void ThenMemberLookupPageRESETButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(RAM.RAMReportPage.RESETPIRProviderButton);
            tmsWait.Hard(2);
            IWebElement place = Browser.Wd.FindElement(By.XPath("//input[@id='txtUpdatePirProviderId']"));
            string exp = place.GetAttribute("placeholder").ToString();
            Assert.IsTrue(exp.Equals("All"));
        }

        [Then(@"Verify RAM Application Member Lookup page Member ID field is set to ""(.*)""")]
        public void ThenVerifyRAMApplicationMemberLookupPageMemberIDFieldIsSetTo(string expectedValue)
        {
            tmsWait.Hard(4);
            IWebElement place = Browser.Wd.FindElement(By.CssSelector("[test-id='member-input-SearchBytxt']"));
            string actualValue = place.Text;

            Assert.AreEqual(expectedValue, actualValue, "Both values are not matching");
        }


        [Then(@"Update Provider page Search By is selected as ""(.*)""")]
        public void ThenUpdateProviderPageSearchByIsSelectedAs(string option)
        {
            tmsWait.Hard(2);
            SelectElement selectSearchBy = new SelectElement(RAM.RAMReportPage.UpdatePIRSearchBy);
            selectSearchBy.SelectByText(option);
        }

        [Then(@"Update Provider page Provider Lookup button is clicked")]
        public void ThenUpdateProviderPageProviderLookupButtonIsClicked()
        {
            tmsWait.Hard(2);
            RAM.RAMReportPage.ProviderIDLookupButton.Click();
        }


        [Then(@"Member Lookup page message is displayed as ""(.*)"" for nonexisting MemberID")]
        public void ThenMemberLookupPageMessageIsDisplayedAsForNonexistingMemberID(string message)
        {
            Assert.IsTrue(Browser.Wd.FindElement(By.ClassName("toast-message")).Text.Contains(message));
        }


        [Then(@"Provider Lookup page SEARCH button is clicked")]
        public void ThenProviderLookupPageSEARCHButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(RAM.RAMReportPage.SearchProviderIDButton);
        }

        [Then(@"Provider Lookup page SEARCH button is clicked Successfully")]
        public void ThenProviderLookupPageSEARCHButtonIsClickedSuccessfully()
        {
            tmsWait.Hard(2);
            IWebElement button = Browser.Wd.FindElement(By.XPath("//button[@test-id='searchProvider-btn-search']"));
            fw.ExecuteJavascript(button);
        }

        [When(@"I Clicked on Plan (.*)Star Status tab")]
        public void WhenIClickedOnPlanStarStatusTab(int p0)
        {
            tmsWait.Hard(2);
            IWebElement tab = Browser.Wd.FindElement(By.XPath("//a[@title='Update plans 5Star status']"));
            fw.ExecuteJavascript(tab);
            tmsWait.Hard(2);
        }

        [When(@"I Clicked on Business Rules tab")]
        public void WhenIClickedOnBusinessRulesTab()
        {
            tmsWait.Hard(4);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(1);
                IWebElement tab = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Business Rules')]"));
                fw.ExecuteJavascript(tab);
            }
            else
            {

                IWebElement tab = Browser.Wd.FindElement(By.XPath("//li[@test-id='eamConfigurations-li-eamConfigurationsList']/label[contains(.,'Business Rules')]"));
                fw.ExecuteJavascript(tab);
            }

        }

        [When(@"EAM Configuration page I Clicked on ""(.*)"" link")]
        public void WhenEAMConfigurationPageIClickedOnLink(string p0)
        {
            tmsWait.Hard(4);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(1);
                IWebElement tab = Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + p0 + "')]"));
                fw.ExecuteJavascript(tab);
            }
            else
            {
                IWebElement tab = Browser.Wd.FindElement(By.XPath("//li[@test-id='eamConfigurations-li-eamConfigurationsList']/label[contains(.,'" + p0 + "')]"));
                fw.ExecuteJavascript(tab);
            }
        }

        [When(@"I Clicked on Election Type Validation link")]
        public void WhenIClickedOnElectionTypeValidationLink()
        {
            tmsWait.Hard(4);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(1);
                IWebElement tab = Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Election Type Validation')])[1]"));
                fw.ExecuteJavascript(tab);
            }
            else
            {
                IWebElement tab = Browser.Wd.FindElement(By.XPath("//li[@test-id='eamConfigurations-li-eamConfigurationsList']/label[contains(.,'Election Type Validation')]"));
                fw.ExecuteJavascript(tab);
            }
        }

        [When(@"EAM Configuration page ""(.*)"" on ""(.*)"" validation")]
        public void WhenEAMConfigurationPageOnValidation(string checkboxStatus, string businessRules)
        {
            tmsWait.Hard(2);
            IWebElement check = Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + businessRules + "')]/preceding-sibling::input"));
            bool status = false;
            if (checkboxStatus.Equals("checked"))
            {
                status = true;
            }

            if (status)
            {
                if (check.Selected)
                {
                    Console.WriteLine(" It is already checked");

                }
                else
                {
                    fw.ExecuteJavascript(check);
                    IWebElement update = Browser.Wd.FindElement(By.XPath("//button[@test-id='businessRules-btn-saveBusinessRules']"));
                    fw.ExecuteJavascript(update);
                }
            }
            else
            {
                if (!check.Selected)
                {
                    Console.WriteLine(" It is already Unchecked");

                }
                else
                {
                    fw.ExecuteJavascript(check);
                    IWebElement update = Browser.Wd.FindElement(By.XPath("//button[@test-id='businessRules-btn-saveBusinessRules']"));
                    fw.ExecuteJavascript(update);
                }
            }
        }



        [When(@"EAM Configuration page I ""(.*)"" on ""(.*)"" validation")]
        public void WhenEAMConfigurationPageIOnValidation(string checkboxStatus, string businessRules)
        {

            tmsWait.Hard(5);
            if (ConfigFile.tenantType.Equals("tmsx") && businessRules.Equals("Election Type validation:"))
            {
                IWebElement tab = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Election Type Validation')]"));
                fw.ExecuteJavascript(tab);
                tmsWait.Hard(5);
                if (checkboxStatus.ToLower().Equals("unchecked"))
                {
                    checkboxStatus = "off";
                }
                if (checkboxStatus.Equals("checked"))
                {
                    checkboxStatus = "on";
                }
                string switchChk = Browser.Wd.FindElement(By.XPath("//div[@test-id='electionTypeValidation-i-allowManualElectionTypeOverride']//span[@role='switch']")).GetAttribute("aria-checked");

                switch (checkboxStatus.ToLower())
                {
                    case "on":

                        if (switchChk.Contains("false"))
                        {
                            Browser.Wd.FindElement(By.XPath("//div[@test-id='electionTypeValidation-i-allowManualElectionTypeOverride']//span[@class='k-switch-handle']")).Click();
                        }
                        break;
                    case "off":
                        if (switchChk.Contains("true"))
                        {
                            Browser.Wd.FindElement(By.XPath("//div[@test-id='electionTypeValidation-i-allowManualElectionTypeOverride']//span[@class='k-switch-handle']")).Click();
                        }
                        break;
                }
                tmsWait.Hard(2);

            }



            else
            {
                /*Commented next three lines because they move to the Election Type Validation page and cause tests on the Business Rules page to fail, remove them in the future once this is verified working as intended - William Kennedy*/
                //IWebElement tab = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Election Type Validation')]"));
                //fw.ExecuteJavascript(tab);
                //tmsWait.Hard(5);
                IWebElement check = Browser.Wd.FindElement(By.XPath("//input[@test-id='businessRules-chk-" + businessRules + "']"));
                string classvalue = Browser.Wd.FindElement(By.XPath("//input[@test-id='businessRules-chk-" + businessRules + "']")).GetAttribute("class");
                if (checkboxStatus == "checked")
                {

                    if (classvalue.Contains("not-empty"))
                    {
                        Console.WriteLine("Check box is already checked");
                    }

                    else
                    {
                        fw.ExecuteJavascript(check);
                        tmsWait.Hard(1);
                    }

                }

                else
                {
                    if (classvalue.Contains("not-empty"))
                    {

                        fw.ExecuteJavascript(check);
                        tmsWait.Hard(1);
                    }

                    else
                    {
                        Console.WriteLine("Check box is already Unchecked");
                    }
                }

            }
        }







        [Then(@"Verify Business Rule value ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyBusinessRuleValueIsSetTo(string p0, string p1)
        {
            string actualvalue = tmsCommon.GenerateData(p0);
            string expectedvalue = tmsCommon.GenerateData(p1);
            Assert.AreEqual(expectedvalue.ToLower(), actualvalue.ToLower(), "Value for business rule is not as expected");
        }




        [When(@"I ""(.*)"" on ""(.*)"" checkbox")]
        public void WhenIOnCheckbox(string checkboxStatus, string businessRules)
        {
            By loc;
            switch (businessRules)
            {
                case "Receipt Date Validation":
                    loc = By.CssSelector("[test-id='businessRules-chk-ReceiptDateValidation']");
                    ReUsableFunctions.CheckBoxOperations(loc, checkboxStatus);
                    break;
                case "Signature Date Validation":
                    loc = By.CssSelector("[test-id='businessRules-chk-SignatureDateValidation']");
                    ReUsableFunctions.CheckBoxOperations(loc, checkboxStatus);
                    break;
            }

            IWebElement SaveRules = Browser.Wd.FindElement(By.CssSelector("[test-id='businessRules-btn-saveBusinessRules']"));
            fw.ExecuteJavascript(SaveRules);
        }

        [When(@"I Clicked on Business Rules page ""(.*)"" is set to ""(.*)""")]
        public void WhenIClickedOnBusinessRulesPageIsSetTo(string businessRules, string checkboxStatus)
        {
            tmsWait.Hard(2);
            IWebElement check = Browser.Wd.FindElement(By.XPath("//table[@class='Others']//tr/td[contains(.,'" + businessRules + "')]/following-sibling::td/input"));
            bool status = false;
            if (checkboxStatus.Equals("checked"))
            {
                status = true;
            }

            if (status)
            {
                if (check.Selected)
                {
                    Console.WriteLine(" It is already checked");

                }
                else
                {
                    fw.ExecuteJavascript(check);
                    IWebElement update = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnUpdateplan"));
                    fw.ExecuteJavascript(update);
                }
            }
            else if (checkboxStatus.Equals("unchecked"))
            {
                if (!check.Selected)
                {
                    Console.WriteLine(" It is already Unchecked");

                }
                else
                {
                    fw.ExecuteJavascript(check);
                    IWebElement update = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnUpdateplan"));
                    fw.ExecuteJavascript(update);
                }
            }
        }


        [Then(@"Verify Query returns ""(.*)"" no of records is equal to ""(.*)""")]
        public void ThenVerifyQueryReturnsNoOfRecordsIsEqualTo(string p0, int p1)
        {
            string dbrows = tmsCommon.GenerateData(p0);
            string uirows = tmsCommon.GenerateData(p1.ToString());
           
            Assert.IsTrue(dbrows.Contains(uirows), "no of rows are not same");
        }


        [When(@"I ""(.*)"" on ""(.*)"" validation")]
        public void WhenIOnValidation(string checkboxStatus, string businessRules)
        {
            tmsWait.Hard(2);
            IWebElement check;
            if (ConfigFile.tenantType.Equals("tmsx") && businessRules.Equals("EGHP Validation:"))
            {
                tmsWait.Hard(2);
                check = Browser.Wd.FindElement(By.XPath("//label[contains(.,'EGHP Validation')]/parent::div/input"));

                ReUsableFunctions.CheckBoxOperations(check, checkboxStatus);
            }
            else if(ConfigFile.tenantType.Equals("tmsx") && !(businessRules.Equals("EGHP Validation:")))
            { 
            
                    check = Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + businessRules + "')]/parent::div/input"));

                    ReUsableFunctions.CheckBoxOperations(check, checkboxStatus);
              }
            else if (!(ConfigFile.tenantType.Equals("tmsx")) && (businessRules.Equals("EGHP Validation:")))
            {

                check = Browser.Wd.FindElement(By.XPath("//label[contains(.,'EGHP Validation')]/parent::div/input"));

                ReUsableFunctions.CheckBoxOperations(check, checkboxStatus);
            }
            else
            {
                check = Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + businessRules + "')]/parent::div/input"));
                ReUsableFunctions.CheckBoxOperations(check, checkboxStatus);
            }
            IWebElement update = Browser.Wd.FindElement(By.CssSelector("[test-id='businessRules-btn-saveBusinessRules']"));
                        fw.ExecuteJavascript(update);
        }


        //    bool status = false;
        //    if (checkboxStatus.Equals("checked"))
        //    {
        //        status = true;
        //    }

        //    if (status)
        //    {
        //        if (check.Selected)
        //        {
        //            Console.WriteLine(" It is already checked");

        //        }
        //        else
        //        {
        //            fw.ExecuteJavascript(check);
        //            if (ConfigFile.tenantType.Equals("tmsx"))
        //            {
        //                tmsWait.Hard(1);
        //                IWebElement update = Browser.Wd.FindElement(By.CssSelector("[test-id='businessRules-btn-saveBusinessRules']"));
        //                fw.ExecuteJavascript(update);

        //            }
        //            else
        //            {

        //                IWebElement update = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnUpdateplan"));
        //                fw.ExecuteJavascript(update);
        //            }
        //        }
        //    }
        //    else if (checkboxStatus.Equals("unchecked"))
        //    {
        //        if (!check.Selected)
        //        {
        //            Console.WriteLine(" It is already Unchecked");

        //        }
        //        else
        //        {
        //            fw.ExecuteJavascript(check);
        //            if (ConfigFile.tenantType.Equals("tmsx"))
        //            {
        //                tmsWait.Hard(1);
        //                IWebElement update = Browser.Wd.FindElement(By.CssSelector("[test-id='businessRules-btn-saveBusinessRules']"));
        //                fw.ExecuteJavascript(update);

        //            }
        //            else
        //            {
        //                IWebElement update = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnUpdateplan"));
        //                fw.ExecuteJavascript(update);
        //            }
        //        }
        //    }
        //}
    //}

        //label[contains(.,'Date of Death Validation')]/preceding-sibling::input

        [When(@"I ""(.*)"" on ""(.*)"" Plan")]
        public void WhenIOnPlan(string checkboxStatus, string plan)
        {
            IWebElement check = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_GridPlan']//tr//td[contains(.,'"+ plan + "')]/following-sibling::td/input"));
            bool status=false;
            if(checkboxStatus.Equals("checked"))
            {
                status = true;
            }
           
            if (status)
            {
                if (check.Selected)
                {
                    Console.WriteLine(" It is already checked");

                }
                else
                {
                    fw.ExecuteJavascript(check);
                    IWebElement update = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnUpdateplan"));
                    fw.ExecuteJavascript(update);
                    tmsWait.Hard(2);
                    Browser.ClosePopUps(true);
                }
            }
            else
            {
                if (!check.Selected)
                {
                    Console.WriteLine(" It is already Unchecked");

                }
                else
                {
                    fw.ExecuteJavascript(check);
                    IWebElement update = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnUpdateplan"));
                    fw.ExecuteJavascript(update);
                    tmsWait.Hard(2);
                    Browser.ClosePopUps(true);
                }
            }
            

        }


        [Then(@"Group Lookup page SEARCH button is clicked")]
        public void ThenGroupLookupPageSEARCHButtonIsClicked()
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(RAM.RAMReportPage.SearchProviderIDButton);
            //tmsWait.Hard(5);
        }

        [Then(@"Member Lookup page SEARCH button is clicked")]
        public void ThenMemberLookupPageSEARCHButtonIsClicked()
        {
            tmsWait.Hard(1);
            fw.ExecuteJavascript(RAM.RAMReportPage.SearchProviderIDButton);
            tmsWait.Hard(10);
            //RAM.RAMReportPage.SearchProviderIDButton.SendKeys(Keys.F11);
        }
        [When(@"Member Lookup page SEARCH button is clicked and msg varified ""(.*)""")]
        [Then(@"Member Lookup page SEARCH button is clicked and msg varified ""(.*)""")]
        public void ThenMemberLookupPageSEARCHButtonIsClickedAndMsgVarified(string expectedValue)
        {
            
        tmsWait.Hard(1);
            fw.ExecuteJavascript(RAM.RAMReportPage.SearchProviderIDButton);
                  string actualValue = Browser.Wd.FindElement(By.XPath("//div[@class='toast-message']")).GetAttribute("aria-label");
         
            Assert.IsTrue(actualValue.Contains(expectedValue));
        }
        [Then(@"Verify RAMX Member lookup displayed no record")]
        public void ThenVerifyRAMXMemberLookupDisplayedNoRecord()
        {
            //tmsWait.Hard(1);
            //By toastMsg = By.XPath("//div[@class='k-notification-content']");
            //string actValue = Browser.Wd.FindElement(toastMsg).Text;
            //Assert.IsTrue(actValue.Contains("There is no member found for member search criteria"));

        }


        [Then(@"Provider Lookup page message is displayed as ""(.*)""")]
        public void ThenProviderLookupPageMessageIsDisplayedAs(string message)
        {
            tmsWait.Hard(10);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + message + "')]")).Displayed);
        }

        [Then(@"HCC Lookup page message is displayed as ""(.*)""")]
        public void ThenHCCLookupPageMessageIsDisplayedAs(string message)
        {
            tmsWait.Hard(10);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + message + "')]")).Displayed);
        }


        [Then(@"PCP Lookup page message is displayed as ""(.*)""")]
        public void ThenPCPLookupPageMessageIsDisplayedAs(string message)
        {
            tmsWait.Hard(10);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + message + "')]")).Displayed);
        }



        [Then(@"Provider Lookup page first Provider ID is clicked")]
        public void ThenProviderLookupPageFirstProviderIDIsClicked()
        {
           // tmsWait.Hard(5);


            //IWebElement DropdownClick = Browser.Wd.FindElement(By.XPath("//label[@test-id='pcpLookup-lbl-searchBy']/following-sibling::span"));
            //IWebElement value = Browser.Wd.FindElement(By.XPath("//li[contains(.,'Provider ID')]"));
            //KendoUIFunctions.KendoSelectByValue(value, DropdownClick);

            tmsWait.WaitForElement(By.CssSelector("[test-id='lookup-grid-searchresult']"), 30);

                           fw.ExecuteJavascript(RAM.RAMReportPage.FirstRecordProvider);
                //RAM.RAMReportPage.FirstRecordProvider.Click();
               // Browser.Wd.FindElement(By.XPath("//tbody[@role='rowgroup']//tr[1]/td")).Click();

            GlobalRef.providerID = fw.GetElementText(By.XPath("//tbody[@role='rowgroup']//tr[1]/td[2]/span"));
                //Browser.Wd.FindElement(By.XPath("//tbody[@role='rowgroup']//tr[1]/td[1]/span")).Text;
        }

        [Then(@"HCC Lookup Search page First Record is clicked")]
        public void ThenHCCLookupSearchPageFirstRecordIsClicked()
        {
            tmsWait.Hard(5);
            GlobalRef.HCCID = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='lookup-grid-hccLookup']//td[2]")).Text;
            //fw.ExecuteJavascript(RAM.RAMReportPage.FirstRecordHCC);
            RAM.RAMReportPage.FirstRecordHCC.Click();
        }


        [Then(@"Search Criteria page RESET button is clicked")]
        public void ThenSearchCriteriaPageRESETButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(RAM.RAMReportPage.RESETButton);
            //Assert.IsTrue(RAM.RAMReportPage.ProviderInput.GetAttribute("placeholder").Equals(""));
        }


        [Then(@"Verify HCC Lookup displayed search result")]
        public void ThenVerifyHCCLookupDisplayedSearchResult()
        {
            tmsWait.Hard(3);
           // IWebElement noitemdisplay = Browser.Wd.FindElement(By.XPath(".//span[contains(text(),'No items to display')]"));
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath(".//td[contains(text(), 'HCC1')]")).Displayed, "Search result is not displayed");
        }

        [Then(@"Member Lookup page pagination next button is clicked")]
        public void ThenMemberLookupPagePaginationNextButtonIsClicked()
        {
            bool ele;
            try {
                tmsWait.Hard(30);                      
                AngularFunction.clickOnElement(RAM.RAMReportPage.MemberLookupnextbutton);
                //fw.ExecuteJavascript(RAM.RAMReportPage.MemberLookupnextbutton);
                tmsWait.Hard(2);

            }
            catch
            {
                RAM.RAMReportPage.MemberLookupnextbutton.Click();
                tmsWait.Hard(2);
            }
        }

        [Then(@"Verify page number is displayed as ""(.*)""")]
        public void ThenVerifyPageNumberIsDisplayedAs(string expNum)
        {
            tmsWait.Hard(12);
            //string actualNum = Browser.Wd.FindElement(By.XPath("//input[@role='spinbutton']")).GetAttribute("aria-valuenow");
            string actualNum = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='lookup-grid-memberLookup']//input[@role='spinbutton']")).GetAttribute("aria-valuenow");
            fw.ConsoleReport(" We are in Page number" + actualNum);
            Assert.AreEqual(expNum, actualNum, "Pagination is not working");


          
        }

        [When(@"Member Lookup page pagination previous button is clicked")]
        public void WhenMemberLookupPagePaginationPreviousButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.RAMReportPage.MemberLookuppreviousbutton);
            tmsWait.Hard(1);
        }

    }
}
