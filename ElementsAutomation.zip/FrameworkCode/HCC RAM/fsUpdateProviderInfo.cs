﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using System.IO;

namespace TMSoR1.FrameworkCode.HCC_RAM
{
    [Binding]
    class fsUpdateProviderInfo
    {
        [Then(@"Update Provider Info page Search Image button is clicked")]
        public void ThenUpdateProviderInfoPageSearchImageButtonIsClicked()
        {
            tmsWait.Hard(1);
            fw.ExecuteJavascript(Suspects.UpdateProviderInfo.SearchImageButton);
            tmsWait.Hard(6);
        }

        [Then(@"Update Provider Info page Search button is clicked")]
        public void ThenUpdateProviderInfoPageSearchButtonIsClicked()
        {
            tmsWait.Hard(6);
           fw.ExecuteJavascript(Suspects.UpdateProviderInfo.SearchButton);
        }


        [Then(@"Provider Lookup page Search button is clicked")]
        public void ThenProviderLookupPageSearchButtonIsClicked()
        {
            tmsWait.Hard(2);
            //Suspects.UpdateProviderInfo.SearchButton.Click();
            //Actions ob = new Actions(Browser.Wd);
           // ob.Click(Suspects.UpdateProviderInfo.LookupSearchButton);
            fw.ExecuteJavascript(Suspects.UpdateProviderInfo.LookupSearchButton);
            tmsWait.Hard(5);
        }

        [Then(@"Provider Lookup page Cancel button is clicked")]
        public void ThenProviderLookupPageCancelButtonIsClicked()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='searchProvider-btn-cancel']")));
            tmsWait.Hard(1);
        }


        [Then(@"Update Provider Info page Provider ID is entered as ""(.*)""")]
        public void ThenUpdateProviderInfoPageProviderIDIsEnteredAs(string id)
        {
            tmsWait.Hard(2);
            Suspects.UpdateProviderInfo.ProviderLookuptxtbox.SendKeys(id);
        }


        [Then(@"Provider Lookup page First Provider is selected")]
        public void ThenProviderLookupPageFirstProviderIsSelected()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Suspects.UpdateProviderInfo.FirstProviderRow);
        }

        [Then(@"Provider Lookup page Back button is clicked")]
        public void ThenProviderLookupPageBackButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Suspects.UpdateProviderInfo.BackButton);
        }

        [Then(@"HCC Lookup Search page Back button is clicked")]
        public void ThenHCCLookupSearchPageBackButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Suspects.UpdateProviderInfo.BackButton);
        }


        [Then(@"Search Criteria page verify provider id is displayed in provider textbox")]
        public void ThenSearchCriteriaPageVerifyProviderIdIsDisplayedInProviderTextbox()
        {
            var providerID = ScenarioContext.Current["providerID"];
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[@ng-bind='$getDisplayText()']")).Text.Equals(providerID.ToString()));
        }


        [Then(@"Update Provider Info page Contact Name Textbox is entered as ""(.*)""")]
        public void ThenUpdateProviderInfoPageContactNameTextboxIsEnteredAs(string contact)
        {
            tmsWait.Hard(5);
            Suspects.UpdateProviderInfo.ContactNameTextbox.Clear();
            Suspects.UpdateProviderInfo.ContactNameTextbox.SendKeys(contact);
        }

        [Then(@"Update Provider Info page Address one Textbox is entered as ""(.*)""")]
        public void ThenUpdateProviderInfoPageAddressOneTextboxIsEnteredAs(string address)
        {
            tmsWait.Hard(5);
            Suspects.UpdateProviderInfo.Address1Textbox.Clear();
            Suspects.UpdateProviderInfo.Address1Textbox.SendKeys(address);
        }

        [Then(@"Update Provider Info page Address two Textbox is entered as ""(.*)""")]
        public void ThenUpdateProviderInfoPageAddressTwoTextboxIsEnteredAs(string address)
        {
            tmsWait.Hard(5);
            Suspects.UpdateProviderInfo.Address2Textbox.Clear();
            Suspects.UpdateProviderInfo.Address2Textbox.SendKeys(address);
        }

        [Then(@"Update Provider Info page City Textbox is entered as ""(.*)""")]
        public void ThenUpdateProviderInfoPageCityTextboxIsEnteredAs(string city)
        {
            tmsWait.Hard(5);
            Suspects.UpdateProviderInfo.CityTextbox.Clear();
            Suspects.UpdateProviderInfo.CityTextbox.SendKeys(city);
        }


        [Then(@"Update Provider Info page State is selected as ""(.*)""")]
        public void ThenUpdateProviderInfoPageStateIsSelectedAs(string state)
        {
            tmsWait.Hard(2);
            By stateDrp=By.XPath("//label[contains(.,'State')]/parent::div//span[@class='k-select']");
            AngularFunction.selectDropDownValue(stateDrp, state);
            tmsWait.Hard(2);
            
        }

        [Then(@"Verify For Address one error message is displayed as ""(.*)""")]
        public void ThenVerifyForAddressOneErrorMessageIsDisplayedAs(string message)
        {
            Assert.IsTrue(Suspects.UpdateProviderInfo.ErrorAddressOneMessage.Text.Equals(message));
        }


        [Then(@"Update Provider Info page Update button is clicked")]
        public void ThenUpdateProviderInfoPageUpdateButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Suspects.UpdateProviderInfo.UpdateBtn);
        }

        [Then(@"Verify For Contact Name error message is displayed as ""(.*)""")]
        public void ThenVerifyForContactNameErrorMessageIsDisplayedAs(string message)
        {
            Assert.IsTrue(Suspects.UpdateProviderInfo.ErrorContactMessage.Text.Equals(message));
        }

        [Then(@"Verify For State error message is displayed as ""(.*)""")]
        public void ThenVerifyForStateErrorMessageIsDisplayedAs(string message)
        {
            try
            {
                if (Suspects.UpdateProviderInfo.ErrorStateMessage.Displayed)
                {
                    Assert.IsTrue(Suspects.UpdateProviderInfo.ErrorStateMessage.Text.Equals(message));
                }
            }catch(Exception)
            {
                Browser.Wd.FindElement(By.XPath("//*[@id='frmUpdateProvider']/div[3]/div[2]/label")).Click();
                tmsWait.Hard(2);
                Suspects.UpdateProviderInfo.UpdateBtn.Click();
            }
            Assert.IsTrue(Suspects.UpdateProviderInfo.ErrorStateMessage.Text.Equals(message));
        }


        [Then(@"Update Provider Info page Telephone Textbox is entered as ""(.*)""")]
        public void ThenUpdateProviderInfoPageTelephoneTextboxIsEnteredAs(string phone)
        {
            tmsWait.Hard(5);
            Suspects.UpdateProviderInfo.TelephoneTextbox.Clear();
            Suspects.UpdateProviderInfo.TelephoneTextbox.SendKeys(phone);
        }

        [Then(@"Verify For Telephone error message is displayed as ""(.*)""")]
        public void ThenVerifyForTelephoneErrorMessageIsDisplayedAs(string message)
        {
            Assert.IsTrue(Suspects.UpdateProviderInfo.ErrorTelephoneMessage.Text.Equals(message));
        }

        [Then(@"Verify For City error message is displayed as ""(.*)""")]
        public void ThenVerifyForCityErrorMessageIsDisplayedAs(string message)
        {
            Assert.IsTrue(Suspects.UpdateProviderInfo.ErrorCityMessage.Text.Equals(message));
        }


        [Then(@"Verify For Fax error message is displayed as ""(.*)""")]
        public void ThenVerifyForFaxErrorMessageIsDisplayedAs(string message)
        {
            Assert.IsTrue(Suspects.UpdateProviderInfo.ErrorFaxMessage.Text.Equals(message));
        }

        [Then(@"Update Provider Info page Fax Textbox is entered as ""(.*)""")]
        public void ThenUpdateProviderInfoPageFaxTextboxIsEnteredAs(string fax)
        {
            tmsWait.Hard(5);
            Suspects.UpdateProviderInfo.FaxTextbox.Clear();
            Suspects.UpdateProviderInfo.FaxTextbox.SendKeys(fax);
        }

        [Then(@"Update Provider Info page Zip Textbox is entered as ""(.*)""")]
        public void ThenUpdateProviderInfoPageZipTextboxIsEnteredAs(string zip)
        {
            tmsWait.Hard(5);
            Suspects.UpdateProviderInfo.ZipTextbox.Clear();
            Suspects.UpdateProviderInfo.ZipTextbox.SendKeys(zip);
        }

        [Then(@"Verify For Zip error message is displayed as ""(.*)""")]
        public void ThenVerifyForZipErrorMessageIsDisplayedAs(string message)
        {
            Assert.IsTrue(Suspects.UpdateProviderInfo.ErrorZipMessage.Text.Equals(message));
        }

        [Then(@"Verify For State lable is attached with dropdown")]
        public void ThenVerifyForStateLableIsAttachedWithDropdown()
        {
            Assert.IsTrue(Suspects.UpdateProviderInfo.StateDropdown.Displayed);
        }

        [Then(@"Provider Lookup link is Clicked")]
        public void ThenProviderLookupLinkIsClicked()
        {
            tmsWait.Hard(3);
            IWebElement ProviderFirstName = Browser.Wd.FindElement(By.XPath("(//span[@test-id='report-link-group']/a)[1]"));
            fw.ExecuteJavascript(ProviderFirstName);
            tmsWait.Hard(3);
        }

        [Then(@"Verify Provider Results Grid is getting displayed successfully")]
        public void ThenVerifyProviderResultsGridIsGettingDisplayedSuccessfully()
        {
            tmsWait.Hard(3);
            IWebElement results = Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='searchMember-grid-providerLookup']//tr)[2]"));
            bool gridPresence = results.Displayed;
            tmsWait.Hard(2);
            Assert.IsTrue(gridPresence, "Result Grid not displayed");
        }


        [Then(@"Provider Lookup page FirstName is set to ""(.*)""")]
        public void ThenProviderLookupPageFirstNameIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            IWebElement ProviderFirstName = Browser.Wd.FindElement(By.XPath("//input[@test-id='searchProvider-txt-FirstName']"));
            ProviderFirstName.SendKeys(p0);
        }

        [Then(@"Provider Lookup page Search result is displayed")]
        public void ThenProviderLookupPageSearchResultIsDisplayed()
        {
            IWebElement GridExist = Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='searchMember-grid-providerLookup']//tr[@role='row'])[2]"));
            Assert.IsTrue(GridExist.Displayed, "Result not displayed");
            
        }

        [Then(@"NewProvider Lookup page pagination next button is clicked")]
        public void ThenNewProviderLookupPagePaginationNextButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(RAM.RAMReportPage.NewProviderLookupNextBtn);
            tmsWait.Hard(2);
        }

        [Then(@"Verify NewProvider Lookup page number is displayed as ""(.*)""")]
        public void ThenVerifyNewProviderLookupPageNumberIsDisplayedAs(int p0)
        {
            int actualpageno = Convert.ToInt32(RAM.RAMReportPage.NewProviderLookuppagenumber.GetAttribute("aria-label"));
            Assert.AreEqual(p0, actualpageno, "Pagination is not working");
        }

        [When(@"NewProvider Lookup page pagination previous button is clicked")]
        public void WhenNewProviderLookupPagePaginationPreviousButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.RAMReportPage.NewProviderLookupPreviousBtn);
            tmsWait.Hard(1);
        }


        [Then(@"Verify Provider lookup middileinitial is enabled")]
        public void ThenVerifyProviderLookupMiddileinitialIsEnabled()
        {
           // Boolean isenabled = false;
            //IWebElement MiddileInitial = Browser.Wd.FindElement(By.XPath("//*[@test-id='searchProvider-txt-MiddleInitial']"));
            Assert.IsTrue(Suspects.EnterNewDiagnosisCode.NewProviderlookuoMI.Enabled, "MI is disabled");
        }

        [Then(@"Verify Providerlookup middileinitial is disabled")]
        public void ThenVerifyProviderlookupMiddileinitialIsDisabled()
        {
            tmsWait.Hard(2);
            Assert.IsFalse(Suspects.EnterNewDiagnosisCode.NewProviderlookuoMI.Enabled, "MI is enabled");
        }

        [Then(@"NewProvider Lookup page RESET button is clicked")]
        public void ThenNewProviderLookupPageRESETButtonIsClicked()
        {
            fw.ExecuteJavascript(Suspects.UpdatePIRProviderInfo.NewproviderlookupResetBtn);
            tmsWait.Hard(2);
        }

        [When(@"ProviderGroup lookup icon is clicked")]
        public void WhenProviderGroupLookupIconIsClicked()
        {
            tmsWait.Hard(1);
            fw.ExecuteJavascript(Suspects.UpdatePIRProviderInfo.ProviderGroupLookupIcon);
            tmsWait.Hard(1);
        }

        [Then(@"Providergroup lookup page groupID is entered as ""(.*)""")]
        public void ThenProvidergroupLookupPageGroupIDIsEnteredAs(string p0)
        {
            tmsWait.Hard(3);
            try
            {
                ScenarioContext.Current["providerID"] = p0;
                RAM.RAMReportPage.ProviderGroupLookupID.SendKeys(p0);
                tmsWait.Hard(1);
            }
            catch
            {
                
            }
        }

    }
}
