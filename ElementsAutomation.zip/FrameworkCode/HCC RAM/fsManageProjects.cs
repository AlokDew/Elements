﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
//using System.Windows.Forms;

namespace TMSoR1.FrameworkCode.HCC_RAM
{
    [Binding]
    class fsManageProjects
    {

        [When(@"Verify that ""(.*)"" submenu is present in Main menu")]
        public void WhenVerifyThatSubmenuIsPresentInMainMenu(string MenuItem)
        {
            tmsWait.Hard(2);
            IWebElement menuObj = null;
            menuObj = Browser.Wd.FindElement(By.XPath(".//span[contains(.,'" + MenuItem.Trim() + "')]"));
            Assert.IsTrue(menuObj.Displayed, MenuItem + " is not displayed");
        }
        public IWebElement checkMenuOnHover(IWebElement menuObj, string Submenu)
        {
            

            Actions builder = new Actions(Browser.Wd);
            builder.MoveToElement(menuObj).Build().Perform();

            // wait for max of 5 seconds before proceeding. This allows sub menu appears properly before trying to click on it
            WebDriverWait wait = new WebDriverWait(Browser.Wd, TimeSpan.FromSeconds(5));
           // wait.Until(ExpectedConditions.PresenceOfAllElementsLocatedBy(By.XPath(".//span[text() = '" + Submenu.Trim() + "']")));  // until this submenu is found

            //identify menu option from the resulting menu display and click
            IWebElement SubmenuObj = Browser.Wd.FindElement(By.XPath(".//span[text() = '" + Submenu.Trim() + "']"));
            Assert.IsTrue(SubmenuObj.Displayed, SubmenuObj + " is not displayed");
            return SubmenuObj;
        }

        [When(@"Verify that ""(.*)"" submenu is present in ""(.*)"" menu")]
        public void WhenVerifyThatSubmenuIsPresentInMenu(string Submenu, string hoverMenu)
        {
            //tmsWait.Hard(2);
            //IWebElement menuObj = null;
            //IWebElement menuOption = null;
            //menuObj = Browser.Wd.FindElement(By.XPath(".//span[text() = '" + hoverMenu.Trim() + "']"));
            //Assert.IsTrue(menuObj.Displayed, hoverMenu + " is not displayed");

            //menuOption =  checkMenuOnHover(menuObj, Submenu);
            //Assert.IsTrue(menuOption.Displayed, Submenu + " is not displayed");
        }

        [When(@"Prospective Evalution ""(.*)"" is selected")]
        public void WhenProspectiveEvalutionIsSelected(string Submenu)
        {
           // string xpath = ".//span[text(.,'"+ Submenu + "')]";
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(".//span[contains(.,'Prospective Evaluation')]")));
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(".//span[text()='" + Submenu + "']")));
            tmsWait.Hard(2);
        }

        [When(@"Manage Project Page Project ""(.*)"" is selected")]
        public void WhenManageProjectPageProjectIsSelected(string p0)
        {
            tmsWait.Hard(2);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='prospectiveEvaluation-slct-projectName']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + p0 + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(2);
        }

        [Then(@"Verify Manage Project page title ""(.*)"" is displayed")]
        [When(@"Verify Manage Project page title ""(.*)"" is displayed")]
        public void WhenVerifyManageProjectPageTitleIsDisplayed(string title)
        {
            string titleAtUi = RAM.RAMProspectiveEvaulation.manageProjectTitle.Text;
            Assert.IsTrue(titleAtUi.Equals(title.ToString().Trim()), "Expected Title " + title + " is matched at UI" + titleAtUi);
            tmsWait.Hard(1);
        }

        [When(@"Verify Assignments page title ""(.*)"" is displayed")]
        public void WhenVerifyAssignmentsPageTitleIsDisplayed(string title)
        {
            tmsWait.Hard(2);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("(//div[contains(.,'" + title + "')])[4]"));
            UIMODUtilFunctions.elementPresenceUsingWebElement(ele);
        }

        [Then(@"Verify Manage Project ""(.*)"" bar is displayed")]
        [When(@"Verify Manage Project ""(.*)"" bar is displayed")]
        public void WhenVerifyManageProjectBarIsDisplayed(string bar)
        {
                tmsWait.Hard(2);
                IWebElement ele = Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + bar + "')]"));
                UIMODUtilFunctions.elementPresenceUsingWebElement(ele);
        }
        public IWebElement checkForLabelName(string labelName)
        {
            IWebElement labelObj = null;
            try
            {
                 labelObj = Browser.Wd.FindElement(By.XPath(".//label[text() = '" + labelName.Trim() + "']"));
            }
            catch
            {
                labelObj = Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + labelName.Trim() + "')]"));
                //labelObj = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + labelName.Trim() + "')]"));
            }
            return labelObj;
        }
        [Then(@"Verify Manage Project ""(.*)"" is displayed with dropdown")]
        [When(@"Verify Manage Project ""(.*)"" is displayed with dropdown")]
        public void WhenVerifyManageProjectIsDisplayedWithDropdown(string labelName)
        {
            IWebElement labelObj = checkForLabelName(labelName);
            IWebElement dropdownObj = Browser.Wd.FindElement(By.XPath(".//label[text() = '" + labelName.Trim() + "']/following-sibling::kendo-dropdownlist"));
            Assert.IsTrue(labelObj.Displayed, labelName + " is displayed");
            Assert.IsTrue(dropdownObj.Displayed, labelName+ " Dropdown is displayed");
        }
        [When(@"Verify Add New Project ""(.*)"" is displayed")]
        [Then(@"Verify Add New Project ""(.*)"" is displayed")]
        public void ThenVerifyAddNewProjectIsDisplayed(string labelName)
        {
            if (labelName.Equals("Back To Manage Projects"))
            {
                IWebElement backToManage = Browser.Wd.FindElement(By.XPath(".//span[contains(.,'" + labelName.Trim() + "')]"));
                try { Assert.IsTrue(backToManage.Displayed, labelName + " is displayed"); }
                catch { Assert.IsTrue(backToManage.Enabled, labelName + " is displayed"); }
            }
            else
            {
                IWebElement labelObj = checkForLabelName(labelName);
                try { Assert.IsTrue(labelObj.Displayed, labelName + " is displayed"); }
                catch { Assert.IsTrue(labelObj.Enabled, labelName + " is displayed"); }
            }
        }
        public void compareHeaderColumn(IWebElement gridObj, String HeaderText)
        {

            char[] delim = { ',' };
            string[] columns = HeaderText.Split(delim);
            Assert.IsTrue(gridObj.Displayed,  " grid is not displayed");

            IList<IWebElement> headerObj = gridObj.FindElements(By.TagName("th"));
            List<string> headertxt = new List<string>();
            foreach (IWebElement field in headerObj)
            {
                headertxt.Add(field.Text.ToString());

            }
            foreach (string column in columns)
            {
                Assert.IsTrue(headertxt.Contains(column.Trim()), column + " is not displayed");
            }
        }
        [Then(@"Verify Manage Project ""(.*)"" is displayed with column header as ""(.*)""")]
        [When(@"Verify Manage Project ""(.*)"" is displayed with column header as ""(.*)""")]
        public void WhenVerifyManageProjectIsDisplayedWithColumnHeaderAs(string gridName, string Columnhearder)
        {
            tmsWait.Hard(20);
            IWebElement table = null;
            table = RAM.RAMProspectiveEvaulation.manageProjectResultGridHeader;
            Assert.IsTrue(table.Displayed, gridName + " grid is not displayed");
            compareHeaderColumn(table, Columnhearder);
        }
        [Then(@"Verify PE Assignments ""(.*)"" is displayed with column header as ""(.*)""")]
        public void ThenVerifyPEAssignmentsIsDisplayedWithColumnHeaderAs(string gridName, string Columnhearder)
        {
            IWebElement table = null;
            table = RAM.RAMProspectiveEvaulation.BatchUpdateGridheader;
            Assert.IsTrue(table.Displayed, gridName + " Assignments batch update grid is not displayed");
            compareHeaderColumn(table, Columnhearder);
        }
        [Then(@"Verify PE ""(.*)"" lookup result grid column header displayed as ""(.*)""")]
        public void ThenVerifyPELookupResultGridColumnHeaderDisplayedAs(string gridName, string Columnhearder)
        {
            tmsWait.WaitForElement(By.XPath(".//*[@test-id = 'hcc-grid-dgHccLookup']//thead"), 100000);
           // tmsWait.Hard(50);
            IWebElement table = null;
            if (gridName.ToUpper().Contains("HCC")) table = RAM.RAMProspectiveEvaulation.HCClookupResultGridHeader;
        }

        [When(@"Verify PE ""(.*)"" lookup result grid column header are displayed as ""(.*)""")]
        [Then(@"Verify PE ""(.*)"" lookup result grid column header are displayed as ""(.*)""")]
        public void ThenVerifyPELookupResultGridColumnHeaderAreDisplayedAs(string gridName, string Columnhearder)
        {
            tmsWait.WaitForElement(By.XPath(".//*[contains(@test-id , 'Lookup')]//thead"), 100);
            tmsWait.Hard(50);
            IWebElement table = null;
            //if(gridName.ToUpper().Contains("HCC")) table = RAM.RAMProspectiveEvaulation.HCClookupResultGridHeader; 
            //if (gridName.ToUpper().Contains("RISK SCORE")) table = RAM.RAMProspectiveEvaulation.RiskScorelookupResultGridHeader;
            if (gridName.ToUpper().Contains("RAFT TYPE")) table = RAM.RAMProspectiveEvaulation.RaftTypelookupResultGridHeader;
            if (gridName.ToUpper().Contains("HCC")) table = RAM.RAMProspectiveEvaulation.HCClookupResultGridHeader;

            Assert.IsTrue(table.Displayed, gridName + " grid is not displayed");
            compareHeaderColumn(table, Columnhearder);
        }

        //public IWebElement checkForButton(string buttonName)
        //{
        //    IWebElement btnObj = null;
        //    try {
        //         btnObj = Browser.Wd.FindElement(By.XPath("//button[text()='" + buttonName.Trim() + "')]")); }
        //    catch { }
        //    Assert.IsTrue(btnObj.Displayed,buttonName+ " is not displayed");
        //    return btnObj;
        //}
        [When(@"Verify Manage Project EXPORT button is displayed")]
        public void WhenVerifyManageProjectEXPORTButtonIsDisplayed()
        {
            bool displayed = RAM.RAMProspectiveEvaulation.ExportBtn.Displayed;
            Assert.IsTrue(displayed, "EXPORT button is not displayed");
        }


        [When(@"Verify Manage Project EXPORT button is clicked")]
        public void WhenVerifyManageProjectEXPORTButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.ExportBtn);
            tmsWait.Hard(2);
        }

        [Then(@"Verify link ""(.*)"" is displayed")]
        public void ThenVerifyLinkIsDisplayed(string p0)
        {
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//a[@id='fileStatusEnrollmentID']")).Displayed, "Link is not displayed");
        }



        [When(@"Verify Manage Project QUEUE TO ASSIGNMENTS button is displayed")]
        public void WhenVerifyManageProjectQUEUETOASSIGNMENTSButtonIsDisplayed()
        {
            bool displayed = RAM.RAMProspectiveEvaulation.QueueToAssignBtn.Displayed;
            Assert.IsTrue(displayed, "Queue To Assignments button is not displayed");
        }
        [Then(@"Verify Add New Project RESET button is displayed")]
        public void ThenVerifyAddNewProjectRESETButtonIsDisplayed()
        {
            bool displayed = RAM.RAMProspectiveEvaulation.CreateProjectRESETbtn.Displayed;
            Assert.IsTrue(displayed, "RESET button is not displayed");
        }
        [Then(@"Verify Add New Project ADD button is displayed")]
        public void ThenVerifyAddNewProjectADDButtonIsDisplayed()
        {
            bool displayed = RAM.RAMProspectiveEvaulation.CreateProjectADDbtn.Displayed;
            Assert.IsTrue(displayed, "ADD button is not displayed");
        }


        [Then(@"Verify Add New Project ""(.*)"" lookup by default '(.*)' should be displayed")]
        public void ThenVerifyAddNewProjectLookupByDefaultShouldBeDisplayed(string lookupName, string defaultValue)
        {
            tmsWait.Hard(4);
            IWebElement defaultObjtext = Browser.Wd.FindElement(By.XPath(".//label[text()='" + lookupName.Trim() + "']/parent::div/following-sibling::div//li/span[text()='"+ defaultValue.Trim() + "']"));
            tmsWait.Hard(2);
           // IWebElement defaultObjdeleteIcon = Browser.Wd.FindElement(By.XPath(".//label[text()='" + lookupName.Trim() + "']/parent::div/following-sibling::div//li//span[text() = 'delete']"));
           // tmsWait.Hard(2);
            Assert.IsTrue(defaultObjtext.Displayed, defaultValue + " is displayed as dafult value for " + lookupName);
            //Assert.IsTrue(defaultObjdeleteIcon.Displayed, "Delete icon is displayed at dafult value  " );
           // tmsWait.Hard(3);
        }
        [Then(@"Verify Add New Project ""(.*)"" by default '(.*)' should be displayed")]
        public void ThenVerifyAddNewProjectByDefaultShouldBeDisplayed(string p0, string p1)
        {
            string actualdefault = Browser.Wd.FindElement(By.XPath("//ul[@id='memberLookUpDrp_taglist']//li/span")).Text;
            Assert.AreEqual(p1, actualdefault, "Default value is not displayed as ALL");
        }



        [When(@"Manage Project ""(.*)"" link is clicked")]
        public void WhenManageProjectLinkIsClicked(string p0)
        {
            fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.createProjectLink);
            tmsWait.Hard(5);
        }

        [When(@"Manage Project page PCP id is copied from '(.*)' row and assigned to variable ""(.*)""")]
        public void WhenManageProjectPagePCPIdIsCopiedFromRowAndAssignedToVariable(int p0, string p1)
        {
            string no_of_row = tmsCommon.GenerateData(p0.ToString());
            string pcp = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='addProspectiveEvaluation-grid-dgMemberInfo']//tr[" + p0 + "]/td[5]")).Text;
            fw.setVariable(p1, pcp);
        }


        [Then(@"Verify Add New Project title is displayed ""(.*)""")]
        public void ThenVerifyAddNewProjectTitleIsDisplayed(string title)
        {
            tmsWait.Hard(15);
            string titleAtUi = RAM.RAMProspectiveEvaulation.createProjectpageTitle.Text;
            Assert.IsTrue(titleAtUi.Equals(title.ToString().Trim()), "Expected Title " + title + " is matched at UI" + titleAtUi);
        }
        [Then(@"Verify Add New Project ""(.*)"" dropdown displayes ""(.*)""")]
        public void ThenVerifyAddNewProjectDropdownDisplayes(string fieldName, string dropdownValues)
        {
            By Drp = By.XPath("//label[contains(.,'"+ fieldName + "')]/parent::div//span[@class='k-select']");
           // By typeapp = By.XPath("//li[text()='" + value + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            //fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);

        }
		[When(@"Create Project ""(.*)"" is set to ""(.*)""")]
		[Then(@"Create Project ""(.*)"" is set to ""(.*)""")]
		public void ThenCreateProjectIsSetTo(string field, string valueToSet)
		{
			IWebElement fieldObj = null;
            valueToSet = tmsCommon.GenerateData(valueToSet);
            string fromDateValue = tmsCommon.GenerateData(valueToSet);
            string toDateValue = tmsCommon.GenerateData(valueToSet);
            switch (field)
			{
				case "Project Name": fieldObj = RAM.RAMProspectiveEvaulation.ProjectNameTextBox;
                    fieldObj.Clear();
                    fieldObj.SendKeys(valueToSet);
                    break;

				case "From Date":
                   // string dosFromDate = fromDateValue.Replace("/", "");
                    // IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='addProspectiveEvaluation-txt-fromDatePicker']//span/input"));
                    //ele.Clear();
                    //ele.SendKeys(dosFromDate);
                    IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='addProspectiveEvaluation-txt-fromDatePicker']//span[@role='button']"));
                    tmsWait.Hard(1);
                    AngularFunction.enterDate(ele, fromDateValue);
                    break;


                case "Thru Date":
                    //string dostoDate = toDateValue.Replace("/", "");
                    //IWebElement eleToDate = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='addProspectiveEvaluation-txt-thruDatePicker']//span/input"));
                    //eleToDate.Clear();
                    //eleToDate.SendKeys(dostoDate);
                    IWebElement thrD = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='addProspectiveEvaluation-txt-thruDatePicker']//span[@role='button']"));
                    //By thrD = By.XPath("//kendo-datepicker[@test-id='addProspectiveEvaluation-txt-thruDatePicker']//span[@role='button]");
                    tmsWait.Hard(1);
                    AngularFunction.enterDate(thrD, fromDateValue);
                    tmsWait.Hard(2);
                    break;
			}
			
		}

        [When(@"Manage Project ADD button is clicked")]
        public void WhenManageProjectADDButtonIsClicked()
        {
            IWebElement BtnObj = null;
            BtnObj = RAM.RAMProspectiveEvaulation.CreateProjectADDbtn1;
            fw.ExecuteJavascript(BtnObj);
            tmsWait.Hard(4);
        }

        [When(@"Manage Project ""(.*)"" button is clicked")]
        [Then(@"Manage Project ""(.*)"" button is clicked")]
        public void ThenManageProjectButtonIsClicked(string buttonName)
        {
            tmsWait.Hard(3);
            IWebElement BtnObj = null;
            switch (buttonName)
            {
                case "ADD": BtnObj = RAM.RAMProspectiveEvaulation.CreateProjectADDbtn; break;
                case "EXPORT": BtnObj = RAM.RAMProspectiveEvaulation.ExportBtn; break;
                case "QUEUE TO ASSIGNMENTS": BtnObj = RAM.RAMProspectiveEvaulation.QueueToAssignBtn; break;
                case "RESET": BtnObj = RAM.RAMProspectiveEvaulation.CreateProjectRESETbtn; break;
                case "SAVE": BtnObj = RAM.RAMProspectiveEvaulation.PESAVE; break;
                case "OK": BtnObj = RAM.RAMProspectiveEvaulation.ConfirmYes; break;
                case "VIEW PROJECT": BtnObj = RAM.RAMProspectiveEvaulation.ViewProjectBtn; break;
                case "CLOSE": BtnObj = RAM.RAMProspectiveEvaulation.InfolookCLOSEBtn; break;
            }
            fw.ExecuteJavascript(BtnObj);
            tmsWait.Hard(4);
        }
        [When(@"Manage Project ""(.*)"" button is clicked and verify Message ""(.*)""")]
        [Then(@"Manage Project ""(.*)"" button is clicked and verify Message ""(.*)""")]
        public void ThenManageProjectButtonIsClickedAndVerifyMessage(string p0, string p1)
        {

            try
            {
                string expectedValue = p1.ToString();
                IWebElement BtnObj = RAM.RAMProspectiveEvaulation.CreateProjectADDbtn;
                fw.ExecuteJavascript(BtnObj);
                By toastMsg = By.XPath("//div[@class='k-notification-content']");
                string actValue = Browser.Wd.FindElement(toastMsg).Text;
                Assert.IsTrue(actValue.Contains(expectedValue));

            }
            catch (NoSuchElementException e)
            {
                if (Browser.Wd.FindElement(By.XPath("//span[contains(.,'Members already exists in other project')]")).Displayed)
                {

                    fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.MemberExistYESBtn);
                    tmsWait.Hard(5);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='prospectiveEvaluation-btn-save']")));
                   // string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                    string expectedValue = p1.ToString();
                    //Assert.IsTrue(expectedValue.Contains(actualValue), "Message is not displyed successfully ");

                    By toastMsg = By.XPath("//div[@class='k-notification-content']");
                    string actValue = Browser.Wd.FindElement(toastMsg).Text;
                    Assert.IsTrue(actValue.Contains(expectedValue));
                }
            }
        }

        [When(@"Manage Project ""(.*)"" button is clicked And Success message is verified")]
        [Then(@"Manage Project ""(.*)"" button is clicked And Success message is verified")]
        public void ThenManageProjectButtonIsClickedAndSuccessMessageIsVerified(string p0)
        {
            IWebElement BtnObj = RAM.RAMProspectiveEvaulation.ConfirmYes;
            fw.ExecuteJavascript(BtnObj);
            string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
            string expectedValue = p0.ToString();
            Assert.IsTrue(expectedValue.Contains(actualValue), "Message is not displyed successfully ");
        }
        [When(@"Manage Project OK button is clicked And Success message ""(.*)"" is verified")]
        [Then(@"Manage Project OK button is clicked And Success message ""(.*)"" is verified")]
        public void ThenManageProjectOKButtonIsClickedAndSuccessMessageIsVerified(string p0)
        {
            IWebElement BtnObj = RAM.RAMProspectiveEvaulation.ConfirmYes;
            fw.ExecuteJavascript(BtnObj);
            tmsWait.Hard(1);
            //string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
            //string expectedValue = p0.ToString();
            //Assert.IsTrue(expectedValue.Contains(actualValue), actualValue, "Message is not displyed successfully ");
        }

        [Then(@"Verify Members already exists in other project page should be displayed")]
        public void ThenVerifyMembersAlreadyExistsInOtherProjectPageShouldBeDisplayed()
        {
            tmsWait.Hard(50);
           
            try
            {
                if (Browser.Wd.FindElement(By.XPath("//span[contains(.,'Members already exists in other project')]")).Displayed)
                {
                    Assert.IsTrue(RAM.RAMProspectiveEvaulation.MemberAlreadyExist.Displayed, "'Members already exists in other project' page is displayed");
                    Assert.IsTrue(RAM.RAMProspectiveEvaulation.MemberExistNOBtn.Displayed, "NO button is not displayed");
                    Assert.IsTrue(RAM.RAMProspectiveEvaulation.MemberExistYESBtn.Displayed, "YES Button is not displayed");
                    Assert.IsTrue(RAM.RAMProspectiveEvaulation.MemberExistResultGrid.Displayed, "Member grid is not displayed");
                    IWebElement messageObj = Browser.Wd.FindElement(By.XPath(".//div[contains(text(),'Members listed below already exist in a different project for Prospective Evaluation, do you still want to include them in this project ?')]"));
                    Assert.IsTrue(messageObj.Displayed, "'Members already exists in other project' message is displayed");

                    //taking out the number of members from message
                    string completetext = messageObj.Text;
                    string[] textarray = completetext.Split(' ');
                    int memberalreadyIncluded = int.Parse(textarray[0].ToString());
                    int TotalMember = int.Parse(textarray[3].ToString());
                    int memberremaing = TotalMember - memberalreadyIncluded;
                    ScenarioContext.Current["memberremaing"] = memberremaing;
                    fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.ExistYESBtn);
                    tmsWait.Hard(5);

                   // fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'Back To Manage Projects')]")));
                    tmsWait.Hard(15);
                    //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='prospectiveEvaluation-btn-save']")));
                   Browser.Wd.FindElement(By.XPath("//button[@test-id='prospectiveEvaluation-btn-save']")).Click();
                    tmsWait.Hard(6);
                  //  fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")));
                    Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")).Click();
           
                    tmsWait.Hard(7);


                }
            }

            catch
            {
                //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'Back To Manage Projects')]")));
                //tmsWait.Hard(3);
                //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='prospectiveEvaluation-btn-save']")));
                //tmsWait.Hard(2);
                //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")));
                //tmsWait.Hard(5);

            }

        }

        [Then(@"Members already exists in other project page should be displayed")]
        public void ThenMembersAlreadyExistsInOtherProjectPageShouldBeDisplayed()
        {
            tmsWait.Hard(10);
            //tmsWait.WaitForElement(By.CssSelector("button[test-id='addProspectiveEvaluation-btn-no']"), 300);
            //tmsWait.WaitForElement(By.CssSelector("button[test-id='addProspectiveEvaluation-btn-yes']"), 300);
            //tmsWait.WaitForElement(By.CssSelector("button[test-id='addProspectiveEvaluation-grid-dgMemberInfo']"), 300);
            try {
                if (Browser.Wd.FindElement(By.XPath("//span[contains(.,'Members already exists in other project')]")).Displayed)
                {
                    Assert.IsTrue(RAM.RAMProspectiveEvaulation.MemberAlreadyExist.Displayed, "'Members already exists in other project' page is displayed");
                    Assert.IsTrue(RAM.RAMProspectiveEvaulation.MemberExistNOBtn.Displayed, "NO button is not displayed");
                    Assert.IsTrue(RAM.RAMProspectiveEvaulation.MemberExistYESBtn.Displayed, "YES Button is not displayed");
                    Assert.IsTrue(RAM.RAMProspectiveEvaulation.MemberExistResultGrid.Displayed, "Member grid is not displayed");
                    IWebElement messageObj = Browser.Wd.FindElement(By.XPath(".//div[contains(text(),'Members listed below already exist in a different project for Prospective Evaluation, do you still want to include them in this project ?')]"));
                    Assert.IsTrue(messageObj.Displayed, "'Members already exists in other project' message is displayed");

                    //taking out the number of members from message
                    string completetext = messageObj.Text;
                    string[] textarray = completetext.Split(' ');
                    int memberalreadyIncluded = int.Parse(textarray[0].ToString());
                    int TotalMember = int.Parse(textarray[3].ToString());
                    int memberremaing = TotalMember - memberalreadyIncluded;
                    
                    GlobalRef.memberremaing = memberremaing.ToString();
                    fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.MemberExistYESBtn);
                    tmsWait.Hard(5);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='prospectiveEvaluation-btn-save']")));
                    tmsWait.Hard(2);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")));
                    tmsWait.Hard(5);


                }
            }

            catch 
            {
                //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'Back To Manage Projects')]")));
                tmsWait.Hard(3);
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='prospectiveEvaluation-btn-save']")));
                tmsWait.Hard(2);
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")));
                tmsWait.Hard(5);

            }
           
        }


        [Then(@"Member Already Exist NO button is clicked and toster message is verified")]
        public void ThenMemberAlreadyExistNOButtonIsClickedAndTosterMessageIsVerified()
        {
            IWebElement messageObj = null;         
            int RemainingMember = int.Parse(ScenarioContext.Current["memberremaing"].ToString());
            fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.MemberExistNOBtn);
            tmsWait.Hard(2);
            if (RemainingMember == 0) messageObj = Browser.Wd.FindElement(By.XPath(".//div[contains(text(),'Sorry, No Data Exists for selected filters.Please re-select your filters.')]"));
            Assert.IsTrue(messageObj.Displayed, " Sorry, No Data Exists for selected filters.Please re-select your filters. message is displayed");
        }
        [Then(@"Success message is verified")]
        public void ThenSuccessMessageIsVerified()
        {
            IWebElement messageObj = Browser.Wd.FindElement(By.XPath(".//div[contains(text(),'Project Successfully Added!')]"));
            Assert.IsTrue(messageObj.Displayed, "Project Successfully Added! is not displayed");
        }

        [When(@"Manage Projects ""(.*)"" checkbox is ""(.*)""")]
        [Then(@"Manage Projects ""(.*)"" checkbox is ""(.*)""")]
        public void ThenManageProjectsCheckboxIs(string checkBoxName, string state)
        {
            IWebElement checkboxObj = null;
            if (checkBoxName.Equals("Member without visits")) checkboxObj = RAM.RAMProspectiveEvaulation.MemberWithoutVisit;
            if (checkBoxName.Equals("Member without a HCC")) checkboxObj = RAM.RAMProspectiveEvaulation.MemberWithoutHCC;

            if (state.Trim().ToLower().Equals("checked"))
            {
                if (!checkboxObj.Selected)
                    fw.ExecuteJavascript(checkboxObj);
            }
            else
                if (checkboxObj.Selected)
                fw.ExecuteJavascript(checkboxObj);

        }
        [Then(@"Manage Projects verify ""(.*)"" checkbox is ""(.*)""")]
        public void ThenManageProjectsVerifyCheckboxIs(string checkBoxName, string state)
        {
            IWebElement checkboxObj = null;
            if (checkBoxName.Equals("Member without visits")) checkboxObj = RAM.RAMProspectiveEvaulation.MemberWithoutVisit;
            if (checkBoxName.Equals("Member without a HCC")) checkboxObj = RAM.RAMProspectiveEvaulation.MemberWithoutHCC;

            if (state.Trim().ToLower().Equals("checked"))
            {
                Assert.IsTrue(!checkboxObj.Selected, checkBoxName+ " is not checked");
            }
            else
                Assert.IsFalse(checkboxObj.Selected, checkBoxName + " is not unchecked");
          
        }
        [When(@"Verify PE ""(.*)"" lookup is ""(.*)""")]
        [Then(@"Verify PE ""(.*)"" lookup is ""(.*)""")]
        public void ThenVerifyPELookupIs(string LookupName, string state)
        {
            IWebElement lookupbj = null;
            tmsWait.Hard(3);
            switch (LookupName)
            {
                case "HCC(PE):": lookupbj = RAM.RAMProspectiveEvaulation.HCCLookupListBox; break;
                case "Count of known HCC Per Member:": lookupbj = RAM.RAMProspectiveEvaulation.CountKnownHCCLookupListBox; break;
                case "Member(PE):": lookupbj = RAM.RAMProspectiveEvaulation.MemberLookupListBox; break;
                case "AGE GROUP": lookupbj = RAM.RAMProspectiveEvaulation.AgeGroupDropdown; break;
                case "GENDER": lookupbj = RAM.RAMProspectiveEvaulation.GenderDropdown; break;
            }
           
            if (state.Trim().ToLower().Equals("enabled"))
            {                
                Assert.IsTrue(lookupbj.Enabled, LookupName + " is not enabled ");
            }
            else Assert.IsFalse(lookupbj.Enabled, LookupName + " is not disabled ");
        }
        [When(@"Verify PE ""(.*)"" lookup icon is ""(.*)""")]
        public void WhenVerifyPELookupIconIs(string LookupName, string state)
        {
            IWebElement lookupbj = null;
            tmsWait.Hard(3);
            switch (LookupName)
            {
                case "HCC(PE):": lookupbj = RAM.RAMProspectiveEvaulation.HCCLookupListBox; break;
                case "Count of known HCC Per Member:": lookupbj = RAM.RAMProspectiveEvaulation.CountKnownHCCLookupListBox; break;
                case "Member(PE):": lookupbj = RAM.RAMProspectiveEvaulation.MemberLookupListBox; break;
                case "RISK SCORE": lookupbj = RAM.RAMProspectiveEvaulation.RiskScorelookupIcon; break;
                case "RAFT TYPE": lookupbj = RAM.RAMProspectiveEvaulation.RaftTypelookupIcon; break;
                case "PCP": lookupbj = RAM.RAMProspectiveEvaulation.PCPlookupIcon; break;
                case "PCP GROUP": lookupbj = RAM.RAMProspectiveEvaulation.PCPGrouplookupIcon; break;
            }

            if (state.Trim().ToLower().Equals("displayed"))
            {
                Assert.IsTrue(!lookupbj.Displayed, LookupName + " is not enabled ");
            }
            else Assert.IsFalse(lookupbj.Displayed, LookupName + " is not disabled ");
        }

        [Then(@"HCC Lookup select ""(.*)"" for ""(.*)"" year from result grid")]
        public void ThenHCCLookupSelectForYearFromResultGrid(string valueToSelect, string paymentYear)
        {
            tmsWait.Hard(14);
            IWebElement lookupObj = null;
            valueToSelect = tmsCommon.GenerateData(valueToSelect);
            string[] values = splitString(valueToSelect, new char[] { ',' }); 

            
            paymentYear = tmsCommon.GenerateData(paymentYear);
            foreach(string value in values)
            {
                string xpath = "//kendo-grid[@test-id='hcc-grid-dgHccLookup']//td/input[@type='checkbox']/parent::td/following-sibling::td[text()='" + value.Trim() + "']/following-sibling::td[contains(.," + paymentYear + ")]";                
                lookupObj = Browser.Wd.FindElement(By.XPath(xpath));               
                fw.ExecuteJavascript(lookupObj);
            }
            
        }
        [When(@"""(.*)"" Lookup Back link is clicked")]
        [Then(@"""(.*)"" Lookup Back link is clicked")]
        public void ThenLookupBackLinkIsClicked(string LookupName)
        {
            IWebElement lookupbj = null;
            switch (LookupName.ToUpper().Trim())
            {
                case "HCC": lookupbj = RAM.RAMProspectiveEvaulation.HCClookupBACK; break;
                case "RISK SCORE": lookupbj = RAM.RAMProspectiveEvaulation.RiskScorelookupBACK; break; 
                case "RAFT TYPE": lookupbj = RAM.RAMProspectiveEvaulation.RaftTypelookupBACK; break;
                case "PCP": lookupbj = RAM.RAMProspectiveEvaulation.PCPGrouplookupBACK; break;
                case "PCP GROUP": lookupbj = RAM.RAMProspectiveEvaulation.PCPGrouplookupBACK; break;
                case "MEMBER": lookupbj = RAM.RAMProspectiveEvaulation.MemberlookupBACK; break;
            }
            fw.ExecuteJavascript(lookupbj);
        }
        [Then(@"Manage projects verify that ""(.*)"" has selected value ""(.*)"" is displayed")]
        [When(@"Manage projects verify that ""(.*)"" has selected value ""(.*)"" is displayed")]
        public void WhenManageProjectsVerifyThatHasSelectedValueIsDisplayed(string LookupName, string valueToCheck)
        {
            tmsWait.Hard(13);
            string lookupObj = "";
            valueToCheck = tmsCommon.GenerateData(valueToCheck);
            string[] values = splitString(valueToCheck, new char[] { ',' });
            char[] Charset = { 'd', 'e', 'l', 't' };
            List<string> valueAtUI = new List<string>();
            List<string> valueAtUI1 = new List<string>();
            if (LookupName.Contains("HCC")) lookupObj = "hccLookUpDrp";
            if (LookupName.Contains("RiskScore")) lookupObj = "riskScoreLookUpDrp";
            if (LookupName.Contains("RAFTTYPE")) lookupObj = "raftTypeLookUpDrp";

            //IList<IWebElement> listObj = lookupObj.FindElements(By.TagName("li"));
            //foreach (IWebElement value in listObj)
            //{
            //    string[] val =  value.Text.Split(new string[] { "\r\ndelete"}, StringSplitOptions.None);
            //    string val1 = value.Text.TrimEnd(new char[] { 'd', 'e', 'l', 't' });
            //   valueAtUI.Add(val[0]);
            //    valueAtUI1.Add(val1);
            //}
            foreach (string valuetocheck in values)
            {
                try { Assert.IsTrue(Browser.Wd.FindElement(By.XPath(".//*[@id='" + lookupObj + "']//span[contains(.,'" + valuetocheck + "')]")).Displayed, valuetocheck + " is not present in lookup listbox"); }
                catch { /*Assert.IsTrue(valueAtUI1.Contains(valuetocheck), valuetocheck + " is not present in lookup listbox");*/ }
            }
        }

        //[When(@"Verify that ""(.*)"" has selected value ""(.*)"" is displayed")]
        //[Then(@"Verify that ""(.*)"" has selected value ""(.*)"" is displayed")]
        //public void ThenVerifyThatHasSelectedValueIsDisplayed(string LookupName, string valueToCheck)
        //{
        //    IWebElement lookupObj = null;
        //    valueToCheck = tmsCommon.GenerateData(valueToCheck);
        //    string[] values = splitString(valueToCheck, new char[] { ',' });

        //    IList<string> valueAtUI = null;
        //    if (LookupName.Contains("HCC")) lookupObj = RAM.RAMProspectiveEvaulation.HCClookupDropdown;
        //    if (LookupName.Contains("RiskScore")) lookupObj = RAM.RAMProspectiveEvaulation.HCClookupDropdown;

        //    IList<IWebElement> listObj = lookupObj.FindElements(By.TagName("li"));
        //    foreach (IWebElement value in listObj)
        //    {
        //        valueAtUI.Add(value.FindElement(By.TagName("span")).Text.ToString());
        //    }
        //    foreach (string valuetocheck in values)
        //    {
        //        Assert.IsTrue(valueAtUI.Contains(valuetocheck), valuetocheck + " is not present in lookup listbox");
        //    }
        //}

        [When(@"Manage Project ""(.*)"" lookup icon is clicked")]
        public void WhenManageProjectLookupIconIsClicked(string lookupName)
        {
            IWebElement lookupbj = null;
            switch (lookupName.ToUpper().Trim())
            {
                case "HCC": lookupbj = RAM.RAMProspectiveEvaulation.HCClookupIcon; break;
                case "RISK SCORE:": lookupbj = RAM.RAMProspectiveEvaulation.RiskScorelookupIcon; break;
                case "RAFT TYPE": lookupbj = RAM.RAMProspectiveEvaulation.RaftTypelookupIcon; break;
                case "PCP": lookupbj = RAM.RAMProspectiveEvaulation.PCPlookupIcon; break;
                case "PCP GROUP": lookupbj = RAM.RAMProspectiveEvaulation.PCPGrouplookupIcon; break;
                case "MEMBER": lookupbj = RAM.RAMProspectiveEvaulation.MemberlookupIcon; break;
            }
            fw.ExecuteJavascript(lookupbj);
           tmsWait.Hard(15);
           // By g = By.XPath(".//label[@test-id = 'pcpLookup-lbl-searchBy']/following-sibling::span/span/span[1]");
           // tmsWait.WaitForElement(g,600000);
        }
        public string[] splitString(string appendedText,char[] delim)
        {
            return appendedText.Split(delim);
        }
        [When(@"Risk Score Lookup select ""(.*)"" value from the result grid")]
        public void WhenRiskScoreLookupSelectValueFromTheResultGrid(string valueToSet)
        {
            valueToSet = tmsCommon.GenerateData(valueToSet);            
            IWebElement lookupObj = null;
            string[] values = splitString(valueToSet, new char[] { ',' }); 
            foreach (string value in values)
            {
                string[] rangelimite = splitString(value,new char[] { '-' });
                string xpath = "//div[@test-id = 'riskScore-grid-dgRiskScoreLookup']/div[2]//td/span[text() = '" + rangelimite[1].Trim() + "']/parent::td//preceding-sibling::td/span[text()='" + rangelimite[0].Trim() + "']/parent::td//preceding-sibling::td[2]/input";
                lookupObj = Browser.Wd.FindElement(By.XPath(xpath));
                fw.ExecuteJavascript(lookupObj);
            }
        }
        [When(@"RAFT TYPE Lookup select ""(.*)"" value from the result grid")]
        public void WhenRAFTTYPELookupSelectValueFromTheResultGrid(string valueToSet)
        {
            valueToSet = tmsCommon.GenerateData(valueToSet);
            IWebElement lookupObj = null;
            string[] values = splitString(valueToSet, new char[] { ',' });
            foreach (string value in values)
            {              
                string xpath = ".//*[@test-id='raftType-grid-dgRaftTypeLookup']//td[text()='" + value .Trim()+ "']//preceding-sibling::td/input";
                lookupObj = Browser.Wd.FindElement(By.XPath(xpath));
                fw.ExecuteJavascript(lookupObj);
            }
        }
        [When(@"PE ""(.*)"" lookup Search by ""(.*)"" dropdropdown is selected")]
        public void WhenPELookupSearchByDropdropdownIsSelected(string lookupName, string valueTobeSelected)
        {
            tmsWait.Hard(1);

            By Drp = By.XPath("//kendo-dropdownlist[@id='searchbydrpdown']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + valueTobeSelected + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }

        [When(@"PE PCP lookup ProviderId is set to ""(.*)""")]
        public void WhenPEPCPLookupProviderIdIsSetTo(string p0)
        {
            string pcpid= tmsCommon.GenerateData(p0);
            RAM.RAMProspectiveEvaulation.PCPLookupTextBox.SendKeys(pcpid);
        }



        [When(@"PE Verify ""(.*)"" lookup label name is displayed as ""(.*)"" if Search By ""(.*)""")]
        public void WhenPEVerifyLookupLabelNameIsDisplayedAsIfSearchBy(string lookupName, string ReflectedLabelName, string SearchBy)
        {
                tmsWait.Hard(2);
                IWebElement ele = Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + ReflectedLabelName + "')]"));
                UIMODUtilFunctions.elementPresenceUsingWebElement(ele);
        }


        [When(@"PE PCP Id is entered as ""(.*)"" and error message ""(.*)"" is verified")]
        public void WhenPEPCPIdIsEnteredAsAndErrorMessageIsVerified(string p0, string p1)
        {
            RAM.RAMProspectiveEvaulation.PCPLookupTextBox.SendKeys(p0);
            tmsWait.Hard(2);
            Assert.IsTrue(RAM.RAMReportPage.ErrorMessage.Text.Contains("No special characters allowed including space"));
        }

        [When(@"PE PCP Group Id is entered as ""(.*)"" and error message ""(.*)"" is verified")]
        public void WhenPEPCPGroupIdIsEnteredAsAndErrorMessageIsVerified(string p0, string p1)
        {
            RAM.RAMProspectiveEvaulation.PCPLookupTextBox.SendKeys(p0);
            tmsWait.Hard(2);
            Assert.IsTrue(RAM.RAMReportPage.ErrorMessage.Text.Contains("No special characters allowed including space"));
        }



        [When(@"PE ""(.*)"" lookup ""(.*)"" button is clicked")]
        public void WhenPELookupButtonIsClicked(string LookupName, string Buttonname)
        {
            if (LookupName.ToLower().Equals("member"))
            {
                fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.LookupSearchBtnMember);
            }
            else { 
            if (Buttonname.Equals("SEARCH"))
                if (RAM.RAMProspectiveEvaulation.LookupSearchBtn.Displayed)

                    fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.LookupSearchBtn); }
            tmsWait.Hard(240);
        }
        [When(@"PE Verify ""(.*)"" lookup grid displayed with column hearder as ""(.*)""")]
        public void WhenPEVerifyLookupGridDisplayedWithColumnHearderAs(string gridName, string Columnhearder)
        {
            IWebElement table = null;
            table = RAM.RAMProspectiveEvaulation.PCPlookupResultGridHeader;
            Assert.IsTrue(table.Displayed, gridName + " grid is not displayed");
            compareHeaderColumn(table, Columnhearder);
        }
        [When(@"PE ""(.*)"" lookup ""(.*)"" is set as ""(.*)""")]
        public void WhenPELookupIsSetAs(string lookupName, string TextboxToSet, string ValueToset)
        {
            ValueToset = tmsCommon.GenerateData(ValueToset);

            RAM.RAMProspectiveEvaulation.searchbyValue.Clear();
            RAM.RAMProspectiveEvaulation.searchbyValue.SendKeys(ValueToset);
        }
        [When(@"PE ""(.*)"" lookup top ""(.*)"" is selected")]
        public void WhenPELookupTopIsSelected(string LookupName, int rows)
        {
            IWebElement rowObj = null;
            string databaseName = ConfigFile.RAMdb.ToString();
            fsRSMLogin executeDbQuery = new fsRSMLogin();
            for (int i = 1; i <= rows; i++)
            {
                string xpath = ".//*[@test-id='lookup-grid-searchresult']/div[2]//tr["+i+"]/td/input";
                try { rowObj = Browser.Wd.FindElement(By.XPath(xpath)); }
                catch
                {
                    if (LookupName.Equals("PCP GROUP")) { string QueryString = "insert into tbProviderGroup (txtClientID,txtGroupID,txtGroup,txtAddress1,txtAddress2,txtCity,txtState,txtZip,txtPhone,txtFax,txtEmail,txtURL,stampdate,stampuser) values(1, 1001,'', '','', '', '', '','','','','','01/01/2017 00:00:00','B')";
                        Dictionary<int, string[]> table = executeDbQuery.ExecuteSingleQuery(QueryString, databaseName, 14);
                        fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.LookupSearchBtn);tmsWait.Hard(4);
                        rowObj = Browser.Wd.FindElement(By.XPath(xpath)); } else Assert.IsTrue(true, LookupName + " does not have data");
                }
                fw.ExecuteJavascript(rowObj);
            }
        }

        [When(@"PE PCP lookup top ""(.*)"" is selected")]
        public void WhenPEPCPLookupTopIsSelected(int p0)
        {
            string indexpcp = (p0 - 1).ToString();
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//input[contains(@id,'checkbox" + indexpcp + "')]")));
        }



        [When(@"Create Project ""(.*)"" multiselect dropdown is set to ""(.*)""")]
        [Then(@"Create Project ""(.*)"" multiselect dropdown is set to ""(.*)""")]
        public void ThenCreateProjectMultiselectDropdownIsSetTo(string mulitiSelectField, string multipleValues)
        {
            multipleValues = tmsCommon.GenerateData(multipleValues);
            string[] multiPayYear = splitString(multipleValues, new char[] { ',' });
            //SelectElement paymentYearDropdown = new SelectElement(RAM.RAMProspectiveEvaulation.AddprojectpaymentYear);
            IWebElement paymentYearDropdown = RAM.RAMProspectiveEvaulation.AddprojectpaymentYear;

            string xpath = "//kendo-multiselect[@test-id = 'addProspectiveEvaluation-slct-dataSourceYear']//input";
            string deletexpath = "//label[contains(.,'Prospective Evaluation Data Source Payment Year:')]/parent::div/following-sibling::div//span[contains(text(),'delete')]";
            try {
                //while (Browser.Wd.FindElement(By.XPath(deletexpath)).Displayed)
                //    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(deletexpath)));
                paymentYearDropdown.SendKeys(OpenQA.Selenium.Keys.Backspace);
            }
            catch { }
            foreach (string payYear in multiPayYear)
            {
                try {
                    //string xpath1 = "//li[contains(.,'" + payYear.Trim() + "')]";
                    //tmsWait.Hard(4);
                    //fw.ExecuteJavascript( Browser.Wd.FindElement(By.XPath(xpath)));
                    //tmsWait.Hard(7);
                    //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(xpath1))); tmsWait.Hard(1);
                    paymentYearDropdown.SendKeys(payYear.Trim());
                    tmsWait.Hard(1);
                    paymentYearDropdown.SendKeys(OpenQA.Selenium.Keys.Enter);
                }
                catch { }
            }           
        }
        [When(@"Member Already Exist YES button is clicked")]
        public void WhenMemberAlreadyExistYESButtonIsClicked()
        {
            tmsWait.Hard(20);
            try
            {
                if (Browser.Wd.FindElement(By.XPath("//span[contains(.,'Members already exists in other project')]")).Displayed)
                {
                    fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.MemberExistYESBtn);
            
                }
            }
            catch (Exception ex)
            {

            }
        }
        [Then(@"Filter accordian is expanded")]
        [When(@"Filter accordian is expanded")]
        public void WhenFilterAccordianIsExpanded()
        {
            tmsWait.Hard(5);
            //fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.FilterAnchor.FindElement(By.TagName("i")));
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@test-id='prospectiveEvaluation-title-filter']")));
            tmsWait.Hard(2);
        }
        [Then(@"Filter accordian is Clicked")]
        public void ThenFilterAccordianIsClicked()
        {
            tmsWait.Hard(5);
            //fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.FilterAnchor.FindElement(By.TagName("i")));
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[@class='cursorLink']")));
            tmsWait.Hard(2);
        }

       




            [Then(@"verify PE Output ""(.*)"" value is displaye as ""(.*)""")]
        [Then(@"Verify ""(.*)"" is displayed as ""(.*)""")]
        public void ThenVerifyIsDisplayedAs(string fieldname, string Fieldvalue)
        {
            tmsWait.Hard(5);
            string xpath1 = "";
            string xpath2 = "";
            Fieldvalue = tmsCommon.GenerateData(Fieldvalue);
            
            string[] multiplevalues = splitString(Fieldvalue, new char[] { ','});
            if (multiplevalues.Length == 1 || fieldname.Equals("Payment Year:"))
            {
                Fieldvalue = tmsCommon.GenerateData(Fieldvalue);
                xpath1 = "//label[contains(.,'" + fieldname + "')]/following-sibling::span[contains(.,'" + Fieldvalue + "')]";
                //string xpath = ".//label[text() = '"+fieldname+"']/following-sibling::span[text() = '"+ Fieldvalue + "']";
               // xpath1 = "//span[@test-id='prospectiveEvaluation-span-" + fieldname + "']";
                try { Assert.IsTrue(Browser.Wd.FindElement(By.XPath(xpath1)).Displayed, fieldname + " is not displayed with values as " + Fieldvalue); }
                catch {
                    if (!Browser.Wd.FindElement(By.XPath("label[contains(.,'" + fieldname + "')]")).Displayed) fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.FilterAnchor.FindElement(By.TagName("i")));
                    tmsWait.Hard(2);
                }
                Assert.IsTrue(Browser.Wd.FindElement(By.XPath(xpath1)).Displayed, fieldname + " is not displayed with values as " + Fieldvalue);
            }
            else
            {
                 
                xpath1 = "label[contains(.,'" + fieldname + "')]/following-sibling::span[contains(.,'Multi')]";
                try
                { Assert.IsTrue(Browser.Wd.FindElement(By.XPath(xpath1)).Displayed, fieldname + " is not displayed with values as Multi"); }
                catch { if (!Browser.Wd.FindElement(By.XPath("//label[text()='" + fieldname + "']")).Displayed) fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.FilterAnchor.FindElement(By.TagName("i"))); }
                Assert.IsTrue(Browser.Wd.FindElement(By.XPath(xpath1)).Displayed, fieldname + " is not displayed with values as Multi");
                xpath2 = "//label[text()='" + fieldname + "']/following-sibling::span[contains(.,'Multi')]//i";
                Assert.IsTrue(Browser.Wd.FindElement(By.XPath(xpath2)).Displayed, "information icon should be displayed");
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(xpath2)));
            }
        }

        [Then(@"verify PE Output ""(.*)"" value is displayed as ""(.*)""")]
        public void ThenVerifyPEOutputValueIsDisplayedAs(string fieldname, string p1)
        {
            string fieldvalue = tmsCommon.GenerateData(p1);

            switch (fieldname.ToLower())
            {
                case "payment year":
                   // string ss = Browser.Wd.FindElement(By.XPath("//span[@test-id='prospectiveEvaluation-span-paymentYear']")).Text;
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[@test-id='prospectiveEvaluation-span-paymentYear']")).Text.Contains(fieldvalue), fieldname + "is not displayed as" +fieldvalue);
                    break;
                case "member without a hcc":
                    Assert.IsTrue( Browser.Wd.FindElement(By.XPath("//span[@test-id='prospectiveEvaluation-span-memWithoutHCC']")).Text.Contains(fieldvalue), fieldname + "is not displayed as" + fieldvalue);
                    break;
                case "member without visits":
                    Assert.IsTrue( Browser.Wd.FindElement(By.XPath("//span[@test-id='prospectiveEvaluation-span-memWithoutVisits']")).Text.Contains(fieldvalue), fieldname + "is not displayed as" + fieldvalue);
                    break;
                case "data must exist in all payment year selected:":
                    Assert.IsTrue( Browser.Wd.FindElement(By.XPath("//span[@test-id='prospectiveEvaluation-span-dataExists']")).Text.Contains(fieldvalue), fieldname + "is not displayed as" + fieldvalue);
                    break;
                case "risk score":
                    Assert.IsTrue( Browser.Wd.FindElement(By.XPath("//span[@test-id='prospectiveEvaluation-span-riskscore']")).Text.Contains(fieldvalue), fieldname + "is not displayed as" + fieldvalue);
                    break;
                case "raft type":
                    Assert.IsTrue( Browser.Wd.FindElement(By.XPath("//span[@test-id='prospectiveEvaluation-span-raftType']")).Text.Contains(fieldvalue), fieldname + "is not displayed as" + fieldvalue);
                    break;
                case "count of known hcc per member":
                    Assert.IsTrue( Browser.Wd.FindElement(By.XPath("//span[@test-id='prospectiveEvaluation-span-countOf']")).Text.Contains(fieldvalue), fieldname + "is not displayed as" + fieldvalue);
                    break;
                case "pcp":
                    Assert.IsTrue( Browser.Wd.FindElement(By.XPath("//span[@test-id='prospectiveEvaluation-span-pcp']")).Text.Contains(fieldvalue), fieldname + "is not displayed as" + fieldvalue);
                    break;
                case "pcp group":
                    Assert.IsTrue( Browser.Wd.FindElement(By.XPath("//span[@test-id='prospectiveEvaluation-span-pcpGroup']")).Text.Contains(fieldvalue), fieldname + "is not displayed as" + fieldvalue);
                    break;
                case "age group":
                    Assert.IsTrue( Browser.Wd.FindElement(By.XPath("//span[@test-id='prospectiveEvaluation-span-ageGroup']")).Text.Contains(fieldvalue), fieldname + "is not displayed as" + fieldvalue);
                    break;
            }
        }


        

        [Then(@"verify Info popup at PE Output for ""(.*)"" has values ""(.*)""")]
        public void ThenVerifyInfoPopupAtPEOutputForHasValues(string LookupName, string LookupValues)
        {
            string titlesubstring = "";
            LookupValues = tmsCommon.GenerateData(LookupValues);
            if (LookupName.Contains("HCC")) titlesubstring = "HCC";
            InfoPopupVerification(LookupName, titlesubstring);
            string[] values = splitString(LookupValues, new char[] { ',' });
            foreach(string value in values)
            {
                string xpath = ".//*[@id='dialog']//td[contains(.,'"+ value + "')]";
                Assert.IsTrue(Browser.Wd.FindElement(By.XPath(xpath)).Displayed, value + " is not displayed");
            }
            

        }

        public void InfoPopupVerification(string LookupName, string titlesubstring)
        {
            tmsWait.Hard(10);
             Assert.IsTrue(RAM.RAMProspectiveEvaulation.InfoLookup.Displayed, "info lookup is not displayed");
            string title = "Filter Lookup - " + titlesubstring;
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath(".//*[@id='dialog']//span[text() = '"+title+"']")).Text.Equals(title), title +" title is not displayed");
            IWebElement table = RAM.RAMProspectiveEvaulation.InfolookUpResultGridHeader;
            compareHeaderColumn(table, "Filter Type,Data Text");
            Assert.IsTrue(RAM.RAMProspectiveEvaulation.InfolookCLOSEBtn.Displayed, "Close button is not displayed");
        }

        [Then(@"Verify Evaluation Dates of Service From and Thru Date ""(.*)"" is displayed as ""(.*)""")]
        public void ThenVerifyEvaluationDatesOfServiceFromAndThruDateIsDisplayedAs(string fieldname, string Fieldvalue)
        {
            Fieldvalue = tmsCommon.GenerateData(Fieldvalue);
            string xpath = ".//label[text() = 'Evaluation Dates of Service - From and Thru Date:']/following-sibling::span[text() = '"+ fieldname + " "+ Fieldvalue + "']";
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath(xpath)).Displayed, fieldname + " is not displayed with values as " + Fieldvalue);
        }

        [Then(@"Verify that member result grid is displayed")]
        public void ThenVerifyThatMemberResultGridIsDisplayed()
        {
            Assert.IsTrue(RAM.RAMProspectiveEvaulation.MemberExistResultGrid.Displayed, "Member Result Grid is not displayed");
        }
        [Then(@"Manage Project ""(.*)"" button is displayed")]
        public void ThenManageProjectButtonIsDisplayed(string BtnName)
        {
            tmsWait.Hard(15);
            IWebElement BtnObj = Browser.Wd.FindElement(By.XPath("//button[contains(.,'" + BtnName + "')]"));
            Assert.IsTrue(BtnObj.Displayed, BtnName + " button is not displayed");
        }
        [Then(@"verify confirmation popup displayed")]
        public void ThenVerifyConfirmationPopupDisplayed()
        {
            Assert.IsTrue(RAM.RAMProspectiveEvaulation.SaveConfirmDialog.Displayed, "Confirmation pop up is not displayed after saving");
            Assert.IsTrue(RAM.RAMProspectiveEvaulation.ConfirmNO.Displayed, "NO button is not displayed");
            Assert.IsTrue(RAM.RAMProspectiveEvaulation.ConfirmYes.Displayed, "YES Button is not displayed");

            IWebElement messageObj = Browser.Wd.FindElement(By.XPath(".//span[contains(., 'Are you sure want to add the project? Once added, you can not delete  the project. Are you sure you want to continue?')]"));
            Assert.IsTrue(messageObj.Displayed, "Confirmation pop up message is not displayed");
        }
        [When(@"View Projects Project Name is selcted as ""(.*)""")]
        public void WhenViewProjectsProjectNameIsSelctedAs(string ValueToSet)
        {
                ValueToSet = tmsCommon.GenerateData(ValueToSet);
                //SelectElement projectName = new SelectElement(RAM.RAMProspectiveEvaulation.ProjectNameDropdownPE);
                //projectName.SelectByText(ValueToSet);
                //tmsWait.Hard(1);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='prospectiveEvaluation-slct-projectName']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + ValueToSet + "']");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
        }

        [When(@"View Projects Date of Service Range is selcted as ""(.*)"" to ""(.*)""")]
        public void WhenViewProjectsDateOfServiceRangeIsSelctedAsTo(string fromdate, string ThruDate)
        {
            string range = tmsCommon.GenerateData(fromdate) + " - " + tmsCommon.GenerateData(ThruDate);
            //SelectElement DateRange = new SelectElement(RAM.RAMProspectiveEvaulation.DateRangeDropdownPE);
            //DateRange.SelectByText(range);
            //tmsWait.Hard(1);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='prospectiveEvaluation-slct-evaluationDates']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + range + "']");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
        }
        [Then(@"Verify that toster error message is diaplyed on adding project with same service range and project name")]
        public void ThenVerifyThatTosterErrorMessageIsDiaplyedOnAddingProjectWithSameServiceRangeAndProjectName()
        {
            IWebElement messageObj = Browser.Wd.FindElement(By.XPath(".//div[contains(text(),'Project name with the selected evaluation dates of service already exists.')]"));
            Assert.IsTrue(messageObj.Displayed, "'Project name with the selected evaluation dates of service already exists.' is not displayed");
        }
        [Then(@"tab key is pressed")]
        [When(@"tab key is pressed")]
        public void WhenTabKeyIsPressed()
        {
            fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.createProjectpageTitle);
            fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.createProjectpageTitle);
            tmsWait.Hard(2);
        }
        [Then(@"""(.*)"" message should be displayed")]
        public void ThenThruDateShouldBeGreaterThanFromDateMessageShouldBeDisplayed(string p0)
        {
           // Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[text() = 'Thru Date should be greater than From Date']")).Displayed, "'Thru Date should be greater than From Date' message is not displayed");

            By toastMsg = By.XPath("//div[@class='k-notification-content']");
            string actValue = Browser.Wd.FindElement(toastMsg).Text;
            Assert.IsTrue(actValue.Contains(p0));

        }

        [Then(@"Verify message ""(.*)"" is displayed")]
        public void ThenVerifyMessageThruDateShouldBeGreaterThanFromDateIsDisplayed(string p0)
        {
            By toastMsg = By.XPath("//div[@class='k-notification-content']");
            string actValue = Browser.Wd.FindElement(toastMsg).Text;
            Assert.IsTrue(actValue.Contains(p0));
        }


        [When(@"Verify PE Assignments ""(.*)"" accordian is displayed")]
        public void WhenVerifyPEAssignmentsAccordianIsDisplayed(string p0)
        {
                    checkForLabelName(p0);
        }
        [Then(@"Verify PE Assignments ""(.*)"" label is displayed")]
        [When(@"Verify PE Assignments ""(.*)"" label is displayed")]
        public void WhenVerifyPEAssignmentsLabelIsDisplayed(string LabelName)
        {
            checkForLabelName(LabelName);
        }
        [When(@"Verify PE Assignments ""(.*)"" button is displayed")]
        public void WhenVerifyPEAssignmentsButtonIsDisplayed(string BtnName)
        {
            IWebElement BtnObj = null;
            switch(BtnName.ToUpper().Trim())
            {
                case "SEARCH": BtnObj = RAM.RAMProspectiveEvaulation.AssignSEARCHBtn; break;
                case "SELECT": BtnObj = RAM.RAMProspectiveEvaulation.AssignSELECTBtn; break;
                case "UPDATE": BtnObj = RAM.RAMProspectiveEvaulation.AssignUPDATEBtn; break;
            }
            Assert.IsTrue(BtnObj.Displayed, BtnName + " is not displayed");
        }
        [When(@"Verify PE Assignments ""(.*)"" dropdown is displayed")]
        public void WhenVerifyPEAssignmentsDropdownIsDisplayed(string DropdownName)
        {
            IWebElement dropDownObj = null;
            switch (DropdownName.ToLower().Trim())
            {
                case "project name": dropDownObj = RAM.RAMProspectiveEvaulation.ProjectNameDropDnAssign; break;
                case "evaluation dates of service from and thru date": dropDownObj = RAM.RAMProspectiveEvaulation.EvalDateDropDnAssign; break;
                case "queue status": dropDownObj = RAM.RAMProspectiveEvaulation.QueueStatusDropdnAssign; break;
                case "queue": dropDownObj = RAM.RAMProspectiveEvaulation.QueueDropdnAssign; break;
                case "batch update action": dropDownObj = RAM.RAMProspectiveEvaulation.ActionDropdnAssign; break;
            }
            Assert.IsTrue(dropDownObj.Enabled, DropdownName + " is not displayed");
        }
        [Then(@"verify Assignments Batch Update popup displayed")]
        public void ThenVerifyAssignmentsBatchUpdatePopupDisplayed()
        {
            tmsWait.Hard(4);
            try
            {
                Assert.IsTrue(RAM.RAMProspectiveEvaulation.AssignBatchUpdatePopUp.Displayed, "Batch Assignments pop is not displayed");
            }

            catch
            {
                Assert.IsTrue(RAM.RAMProspectiveEvaulation.AssignBatchUpdatePopUp1.Displayed, "Batch Assignments pop is not displayed");
            }
        }


        [When(@"PE Assignments Batch Update Popup Window Next link is clicked")]
        public void WhenPEAssignmentsBatchUpdatePopupWindowNextLinkIsClicked()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//a[@title='Go to the next page'])[2]")));
            tmsWait.Hard(1);
        }


        [When(@"PE Assignments Batch Update Popup Window ""(.*)"" link is clicked")]
        public void WhenPEAssignmentsBatchUpdatePopupWindowLinkIsClicked(string p0)
        {
            string linkname = tmsCommon.GenerateData(p0);
            string xpath="";
            switch (linkname.ToLower())
            {
                case "next page":  xpath = "//a[@title='Go to the next page']";  break;
                case "last page":  xpath = "//a[@title='Go to the last page']"; break;
                case "previous page":  xpath = "//a[@title='Go to the previous page']"; break;
                case "first page":  xpath = "//a[@title='Go to the first page']"; break;

            }
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(xpath)));
            tmsWait.Hard(3);
        }


        [Then(@"Verify PE Assignments pagination displayed ""(.*)"" page number one")]
        public void ThenVerifyPEAssignmentsPaginationDisplayedPageNumberOne(string p0)
        {
            string pagenumberstatus = tmsCommon.GenerateData(p0);
            string currentpage = Browser.Wd.FindElement(By.XPath("//span[@class='k-pager-input k-label']//input")).GetAttribute("value");
            int cpage = Int32.Parse(currentpage);        
            switch(pagenumberstatus.ToLower())

            {
                case "greater than": Assert.IsTrue(1< cpage, "Pagination Link is not working"); break;
               
                case "equal to": Assert.IsTrue(1 ==cpage, "Pagination Link is not working"); break;
            }

        }


        [When(@"PE Assignments Batch Update Status Popup ""(.*)"" is clicked")]
        public void WhenPEAssignmentsBatchUpdateStatusPopupIsClicked(string p0)
        {
            string status = tmsCommon.GenerateData(p0);
            switch(status)
            {
                case "close":
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='close-btn-select']")));
            tmsWait.Hard(2);
                break;
        }
    }


        public void selectFromDropdown(IWebElement obj, string ValueToSelect)
        {
            fw.ExecuteJavascript(obj);
            string xpath = "//li[contains(.,'"+ ValueToSelect + "')]";
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(xpath)));
            tmsWait.Hard(1);
        }
        [When(@"PE Assignments ""(.*)"" is selected as  ""(.*)""")]
        [When(@"PE Assignments ""(.*)"" is selected as ""(.*)""")]
        public void WhenPEAssignmentsIsSelectedAs(string dropdown, string ValueToSelect)
        {
            IWebElement dropDownObj = null;
            ValueToSelect = tmsCommon.GenerateData(ValueToSelect);
            if(dropdown.Equals("Project Name")) dropDownObj = RAM.RAMProspectiveEvaulation.ProjectNameDropDnAssign;
            if (dropdown.Equals("Queue")) { dropDownObj = RAM.RAMProspectiveEvaulation.QueueDropdnAssign; }
            if (dropdown.Equals("Evaluation Date")) { dropDownObj = RAM.RAMProspectiveEvaulation.EvalDateDropDnAssign; }
            if (dropdown.Equals("Queue Status")) dropDownObj = RAM.RAMProspectiveEvaulation.QueueStatusDropdnAssign;
            if (dropdown.Equals("Action")) dropDownObj = RAM.RAMProspectiveEvaulation.ActionDropdnAssign;
            //SelectElement dropDownSelect = new SelectElement(dropDownObj);
            //selectFromDropdown(dropDownObj,ValueToSelect);
            By typeapp = By.XPath("//li[text()='" + ValueToSelect + "']");
            fw.ExecuteJavascript(dropDownObj);
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }
        [When(@"PE Assignments ""(.*)"" radio button is selected")]
        public void WhenPEAssignmentsRadioButtonIsSelected(string radioBtn)
        {
            if(radioBtn.ToLower().Contains("individual")) fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//input[@test-id = 'peAssignments-rd-individualUpdate']")));
            if (radioBtn.ToLower().Contains("batch")) fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//input[@test-id = 'peAssignments-rd-batchUpdate']")));
        }
        [When(@"Verify that  PE Assignments Result grid is displayed")]
        public void WhenVerifyThatPEAssignmentsResultGridIsDisplayed()
        {
            Assert.IsTrue(RAM.RAMProspectiveEvaulation.ResultgridAssign.Displayed, "Result grid id not displayed");
        }
        [Then(@"PE Assignments ""(.*)"" button is clicked")]
        [When(@"PE Assignments ""(.*)"" button is clicked")]
        public void WhenPEAssignmentsButtonIsClicked(string BtnName)
        {
            IWebElement BtnObj = null;
            switch (BtnName.ToUpper().Trim())
            {
                case "SEARCH": BtnObj = RAM.RAMProspectiveEvaulation.AssignSEARCHBtn; break;
                case "SELECT": BtnObj = RAM.RAMProspectiveEvaulation.AssignSELECTBtn; break;
                case "UPDATE": BtnObj = RAM.RAMProspectiveEvaulation.AssignUPDATEBtn; break;
            }
            fw.ExecuteJavascript(BtnObj);
            tmsWait.Hard(3);
        }


        [Then(@"Verify OpenStatus ""(.*)"" and ""(.*)"" are not equal")]
        public void ThenVerifyOpenStatusAndAreNotEqual(string p0, string p1)
        {
            string openStatusBefore = tmsCommon.GenerateData(p0);
            string openStatusAfter = tmsCommon.GenerateData(p1);
            Assert.AreNotEqual(openStatusBefore, openStatusAfter, "Status has not changed");
        }

        [Then(@"verify total number of records of ""(.*)"" and ""(.*)"" are equal")]
        public void ThenVerifyTotalNumberOfRecordsOfAndAreEqual(string p0, string p1)
        {
            string MemberOutreach = tmsCommon.GenerateData(p0);
            string ProviderOutreach = tmsCommon.GenerateData(p1);
            Assert.AreEqual(MemberOutreach, ProviderOutreach, "Total number of records are not same");
        }



        [Then(@"verify PE Assignments ""(.*)"" has values as ""(.*)""")]
        [Then(@"Verify PE Assignments  ""(.*)"" has values as ""(.*)""")]
        [When(@"Verify PE Assignments  ""(.*)"" has values as ""(.*)""")]
        public void WhenVerifyPEAssignmentsHasValuesAs(string dropdownName, string values)
        {
            tmsWait.Hard(4);
            string xpath = "";
            IWebElement DropdownObj = null;
            List<IWebElement> listvalues = new List<IWebElement>();
          
            if (dropdownName.Equals("Queue"))DropdownObj = RAM.RAMProspectiveEvaulation.QueueDropdnAssign;
            if (dropdownName.Equals("Queue Status")) DropdownObj = RAM.RAMProspectiveEvaulation.QueueStatusDropdnAssign;
            if (dropdownName.Equals("Batch Update Action")) DropdownObj = RAM.RAMProspectiveEvaulation.ActionDropdnAssign;

            string[] valuelist = splitString(values, new char[] { '/' });
            fw.ExecuteJavascript(DropdownObj);
            tmsWait.Hard(2);
            foreach (string value in valuelist)
            {
                xpath = "//select[@test-id = '" + DropdownObj.GetAttribute("test-id").ToString() + "']/option[contains(., '" + value.Trim() + "')]";
                
                try { Assert.IsTrue(Browser.Wd.FindElement(By.XPath(xpath)).Enabled, value + " is not found in dropdown list"); }
                catch { fw.ExecuteJavascript(DropdownObj); }
                Assert.IsTrue(Browser.Wd.FindElement(By.XPath(xpath)).Enabled, value + " is not found in dropdown list");
            }

            

        }

        [When(@"PE Assignments ""(.*)"" is selected as  ""(.*)"" at Results page")]
        public void WhenPEAssignmentsIsSelectedAsAtResultsPage(string QueueName, string ValueToSelect)
        {
            IWebElement DropdownObj = null;
            string xpath = "";
            string testid = "";
            ValueToSelect = tmsCommon.GenerateData(ValueToSelect);
            string[] valuelist = splitString(ValueToSelect, new char[] { '/' });
            if (QueueName.Equals("Queue")) testid = "assignment-list-queue";
            if (QueueName.Equals("Queue Status")) testid = "assignment-list-queuestatus";
            if (QueueName.Equals("Batch Update Action")) testid = "member-list-batchUpdateAction";

            By Drp = By.XPath("//kendo-dropdownlist[@test-id='"+ testid + "']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + ValueToSelect + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            //if (QueueName.Equals("Queue Status")) DropdownObj = RAM.RAMProspectiveEvaulation.QueueStatusDropdnAssign;
            //if (QueueName.Equals("Batch Update Action")) DropdownObj = RAM.RAMProspectiveEvaulation.ActionDropdnAssign;
            //foreach(string value in valuelist)
            //{
            //   foreach(IWebElement valueObj in listvalues)
            //    {
            //        if (valueObj.Text.Contains(value.Trim())) fw.ExecuteJavascript(valueObj);
            //    }
            //}
            //foreach (string value in valuelist)
            //{ 
            //    xpath = ".//*[@id='"+ id+ "']/li[contains(.,'" + value.Trim() + "')]";
            //    try { fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(xpath))); }
            //    catch { fw.ExecuteJavascript(DropdownObj); }
            //    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(xpath))); 
            //}
        }



        [When(@"PE Assignments batch update is selected for QueueName ""(.*)"" and QueueStatus ""(.*)""")]
        public void WhenPEAssignmentsBatchUpdateIsSelectedForQueueNameAndQueueStatus(string p0, string p1)
        {
            string queue = tmsCommon.GenerateData(p0);
            string queuestatus = tmsCommon.GenerateData(p1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='grd-workflow-batch-update']//td[text()='"+ queue + "']/following-sibling::td[text()='"+ queuestatus + "']")));
            tmsWait.Hard(1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='workflow-batch-update-btn-select']")));
            tmsWait.Hard(2);
        }



        [When(@"PE Assignments Go button is clicked")]
        public void WhenPEAssignmentsGoButtonIsClicked()
        {

            string xpath = "//button[@test-id='assignment-search-queue']";
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(xpath)));
        }



        [Then(@"verify PE Assignments Result Grid has data rows in it for project name ""(.*)"" queue ""(.*)"" and Queue Status ""(.*)""")]
        public void ThenVerifyPEAssignmentsResultGridHasDataRowsInItForProjectNameQueueAndQueueStatus(string ProjectName, string Queue, string QueueStatus)
        {
            string QueueInString = "";
            bool matched = false;
            string UiTotalItem = RAM.RAMProspectiveEvaulation.ResultgridDataCount.Text;
            string[] substrings = splitString(UiTotalItem, new char[]  { ' ' });
            ProjectName = tmsCommon.GenerateData(ProjectName);
            if (Queue.Trim().Equals("Evaluation")) QueueInString = "Eval_Subgroup";
            if (Queue.Trim().Equals("Member Outreach")) QueueInString = "MO_Subgroup";
            if (Queue.Trim().Equals("Provider Outreach")) QueueInString = "PO_Subgroup";
            string QueryString = "SELECT [t1].[txtFirst] AS [FirstName], [t1].[txtLast] AS [LastName], [t1].[txtMemberId] AS [MemberId], [t1].[dteDOB] AS [DateOfBirth], [t0].[PCPID] AS [PcpId], [t0].[GroupID] AS [GroupId],[t2].[PIRStatusID],[t3].[Description] AS [QUEUE STATUS],[t3].[QueueSubGroupID],[t4].[QueueSubGroupName] AS [QUEUE NAME] FROM[tbProspectiveEval_ProjectDetail] AS[t0] INNER JOIN[tbMember] AS[t1] ON[t0].[MemberID] = [t1].[txtMemberId] INNER JOIN[tbProspectiveEval_WorkflowDetail] AS[t2] ON[t0].[ProsEvalID] = [t2].[ProsEvalID] INNER JOIN[tbWorkFlow_SubGroupStatus] AS[t3] ON[t2].[PIRStatusID] = [t3].[PIRStatusID] INNER JOIN[tbWorkFlow_QueueSubGroup] AS[t4] ON[t3].[QueueSubGroupID] = [t4].[QueueSubGroupID] INNER JOIN[tbWorkFlow_Projects] AS[t5] ON[t5].[ProjectID] = [t0].[ProjectID] WHERE([t5].[ProjectName] = '"+ ProjectName + "') AND([t4].[QueueSubGroupName] = '" + QueueInString + "') AND([t3].[Description] = '"+ QueueStatus .Trim()+ "')";

            WhenPEAssignmentsIsSelectedAsAtResultsPage("Queue", Queue);
            tmsWait.Hard(2);
            WhenPEAssignmentsIsSelectedAsAtResultsPage("Queue Status", QueueStatus);
            fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.AssignSELECTBtn);
            tmsWait.Hard(5);
            //try { RAM.RAMProspectiveEvaulation.ResultgridDataRowsAssign.FindElements(By.TagName("tr")); }
            //catch { Assert.IsTrue(false, "Result Grid is empty"); }
            fsRSMLogin executeDbQuery = new fsRSMLogin();
            string databaseName = ConfigFile.RAMdb.ToString();
            Dictionary<int,string[]> table =  executeDbQuery.ExecuteSingleQuery(QueryString, databaseName, 10);
            int expectedNumberOfRows = table.Count;
            int UIRowCount = Int32.Parse(substrings[substrings.Length - 2]);
            if (expectedNumberOfRows - UIRowCount == 0)  matched = true;
            Assert.IsTrue(matched, "Number of data elements returned from DB"+ expectedNumberOfRows + " does not match with UI"+ UIRowCount);
        }
        public Dictionary<int, string[]> readUItable(IWebElement tableObj)
        {
            Dictionary<int, string[]> tableatUI = new Dictionary<int, string[]> ();
            List<string> rowValues = new List<string>();
            int columncount;
            int rowCount;
            int i = 0;
           List<IWebElement> rowObj =  tableObj.FindElements(By.TagName("tr")).ToList<IWebElement>();
            rowCount = rowObj.Count;
            foreach (IWebElement row in rowObj)
            {
                List<IWebElement> DatawObj  = row.FindElements(By.TagName("td")).ToList<IWebElement>();
                columncount = DatawObj.Count;
                foreach (IWebElement data in DatawObj)
                {
                    try
                    {
                        rowValues.Add(data.FindElement(By.TagName("span")).Text);
                    }
                    catch
                    {
                        rowValues.Add(data.Text);
                    }
                }               
                    tableatUI.Add(i, rowValues.ToArray());
                rowValues.Clear();
                i++;
            }
            return tableatUI;
        }
        public Dictionary<int, string[]> ReadGherkinTable(Table table)
        {
            int rowCount = table.RowCount;
            int i = 0;
            List<string> rowdata = new List<string>();
            Dictionary<int, string[]> gherkinTable = new Dictionary<int, string[]>();
            foreach (var row in table.Rows)
            {
                rowdata = row.Values.ToList<string>();
                gherkinTable.Add(i, rowdata.ToArray());
                rowdata.Clear();
                i++;
            }
            return gherkinTable;
        }
        public void nextpageclick(Dictionary<int, string[]> UITable, Dictionary<int, string[]> GherkinTable)
        {
            int RemainingRows = GherkinTable.Count - UITable.Count;
            if (RemainingRows > 0)
            {
                fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.BatchUpdatePopupNextPageLink);
                tmsWait.Hard(2);
            }
        }
        public bool CompareRow(Dictionary<int, string[]> UITable, Dictionary<int, string[]> GherkinTable,IWebElement UITableObj)
        {
            bool found = false;
            int j = 0;
            string[] gherkinrows = new string[] { };
            string[] Uirow = new string[] { };
            for (int i = 0; i < GherkinTable.Count; i++)
            {
                gherkinrows = GherkinTable[i];

                for (int l = 0; l < UITable.Count; l++)
                {
                    UITable = readUItable(RAM.RAMProspectiveEvaulation.BatchUpdateGridDataRows);
                    Uirow = UITable[l];

                    for (j = 0; j < gherkinrows.Length; j++)
                    {
                        for (int k = 0; k < Uirow.Length; k++)
                        {
                            if (gherkinrows[j].Equals(Uirow[k]))
                            {
                                found = true; break;
                            }
                            else found = false;
                        }

                    }
                    if (found == true) break;
                }
               if(found == false)
                { 
                    fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.BatchUpdatePopupNextPageLink);
                    tmsWait.Hard(2);
                    for (int l = 0; l < UITable.Count; l++)
                    {
                        UITable = readUItable(RAM.RAMProspectiveEvaulation.BatchUpdateGridDataRows);
                        Uirow = UITable[l];

                        for (j = 0; j < gherkinrows.Length; j++)
                        {
                            for (int k = 0; k < Uirow.Length; k++)
                            {
                                if (gherkinrows[j].Equals(Uirow[k]))
                                {
                                    found = true; break;
                                }
                                else found = false;
                            }

                        }
                        if (found == true)
                        {
                            fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.BatchUpdatePopupFirstPageLink);
                            tmsWait.Hard(2); break;
                        }

                    }
                }
                
                //int RemainingRows = GherkinTable.Count - UITable.Count;
                //if (i == UITable.Count - 1 && RemainingRows > 0)
                //{
                //    fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.BatchUpdatePopupNextPageLink);
                //    tmsWait.Hard(2);
                //}
            }

            return found;
        }

        public bool SelectRowAtUI(Dictionary<int, string[]> UITable, Dictionary<int, string[]> GherkinTable, IWebElement UITableObj)
        {
            bool found = false;
            int j = 0;
            string[] gherkinrows = new string[] { };
            string[] Uirow = new string[] { };
            Dictionary<int, string[]> tableatUI = new Dictionary<int, string[]>();
            List<string> rowValues = new List<string>();
            int columncount;
            int rowCount;
            List<IWebElement> rowObj = UITableObj.FindElements(By.TagName("tr")).ToList<IWebElement>();
            rowCount = rowObj.Count;
            for (int i = 0; i < GherkinTable.Count; i++)
            {
                gherkinrows = GherkinTable[i];

                foreach (IWebElement row in rowObj)
                {
                    List<IWebElement> DatawObj = row.FindElements(By.TagName("td")).ToList<IWebElement>();
                    columncount = DatawObj.Count;
                    foreach (IWebElement data in DatawObj)
                    {
                        try
                        {
                            rowValues.Add(data.FindElement(By.TagName("span")).Text);
                        }
                        catch
                        {
                            rowValues.Add(data.Text);
                        }
                    }
                    for (j = 0; j < gherkinrows.Length; j++)
                    {
                        for (int k = 0; k < rowValues.ToArray().Length; k++)
                        {
                            if (gherkinrows[j].Equals(rowValues.ToArray()[k]))
                            {
                                found = true; break;
                            }
                            else found = false;
                        }

                    }
                    rowValues.Clear();
                    if (found == true) { fw.ExecuteJavascript(row); break; }
                }
                
            }

            return found;
        }
        [Then(@"Verify PE Assignments ""(.*)"" is displayed with rows")]
        public void ThenVerifyPEAssignmentsIsDisplayedWithRows(string GridName, Table table)
        {
            IWebElement UItableObj = RAM.RAMProspectiveEvaulation.BatchUpdateGridDataRows;
            Dictionary<int, string[]> GherkinTable = ReadGherkinTable(table);
            Dictionary<int, string[]> UITable = readUItable(UItableObj);
            bool found = CompareRow(UITable, GherkinTable, UItableObj);
            Assert.IsTrue(found, "expted row is not found at UI");
        }
        [When(@"PE Assignments ""(.*)"" is selected as")]
        public void WhenPEAssignmentsIsSelectedAs(string GridName, Table table)
        {
            IWebElement UItableObj = RAM.RAMProspectiveEvaulation.BatchUpdateGridDataRows;
            Dictionary<int, string[]> GherkinTable = ReadGherkinTable(table);
            Dictionary<int, string[]> UITable = readUItable(UItableObj);
            bool found = SelectRowAtUI(UITable, GherkinTable, UItableObj);
            Assert.IsTrue(found, "expted row is not found at UI");
            fw.ExecuteJavascript(RAM.RAMProspectiveEvaulation.BatchUpdateSELECTBtn);
            tmsWait.Hard(3);
        }
        [Then(@"RAM toster message ""(.*)"" should be displayed")]
        public void ThenRAMTosterMessageShouldBeDisplayed(string message)
        {
            string xpath = ".//div[contains(text(),'"+message+"')]";
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath(xpath)).Displayed, "toster message" + message + " is not displayed");
        }

    }

}
