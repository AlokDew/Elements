﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.HCC_RAM
{

    [Binding]
    class fsExcludeIncludeProvider
    {


        [When(@"IncludeExclude provider page lastname is set to ""(.*)""")]
        public void WhenIncludeExcludeProviderPageLastnameIsSetTo(string p0)
        {
            string generatedData = tmsCommon.GenerateData(p0);
            RAM.ExcludeIncludeProviderPage.ProviderLastName.SendKeys(generatedData);
        }

        [When(@"IncludeExclude provider page ProviderID is set to ""(.*)""")]
        public void WhenIncludeExcludeProviderPageProviderIDIsSetTo(string p0)
        {
            string generatedData = tmsCommon.GenerateData(p0);
            RAM.ExcludeIncludeProviderPage.ProviderId.SendKeys(generatedData);
            tmsWait.Hard(1);
        }

        [Then(@"all providers are listed and record count on ExcludeInclude Provider page matches with record count in db ""(.*)""")]
        public void ThenAllProvidersAreListedAndRecordCountOnExcludeIncludeProviderPageMatchesWithRecordCountInDb(string p0)
        {
            string dbRecordcount = tmsCommon.GenerateData(p0).ToString().Trim();
            Console.WriteLine("Total providers in DB table 'tbproviders' >> " + dbRecordcount);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//span[@class='k-pager-info k-label']"));
            string val = ele.Text;
            string[] arr = val.Split(new string[] { " of " }, StringSplitOptions.None);
            string[] items = arr[1].Split(' ');
            string actualRecordcount= items[0].ToString().Trim();
            Console.WriteLine("Total providers on ExcludeInclude Provider page >> "+actualRecordcount);
            Assert.AreEqual(dbRecordcount, actualRecordcount, "Error : Total providers on ExcludeInclude Provider page do not match with those in table 'tbproviders'");
        }



        [Then(@"verify message ""(.*)"" is displayed on IncludeExclude provider page")]
        public void ThenVerifyMessageIsDisplayedOnIncludeExcludeProviderPage(string p0)
        {
            string expectedMessage = tmsCommon.GenerateData(p0);
            string actualMessage = RAM.ExcludeIncludeProviderPage.ExcludeProviderMessage.Text;
            Assert.AreEqual(expectedMessage, actualMessage, "Message text is not correct");
        }


        [Then(@"verify on IncludeExclude provider page ""(.*)"" is displayed")]
        public void ThenVerifyOnIncludeExcludeProviderPageIsDisplayed(string p0)
        {
            string generatedData = tmsCommon.GenerateData(p0);
            bool isDisplayed;
            string expText="ALL";
            string actualText;
            switch (generatedData)
            {
                case "Provider ID":
                    isDisplayed = RAM.ExcludeIncludeProviderPage.ProviderId.Displayed;
                    Assert.IsTrue(isDisplayed, "Provider ID text box is not displayed on Exclude/Include Provider screen");
                    actualText = RAM.ExcludeIncludeProviderPage.ProviderId.GetAttribute("placeholder");
                    Assert.AreEqual(expText, actualText, "Default Text is Provider ID is incorrect");
                 break;
                case "Provider Last Name":
                    isDisplayed = RAM.ExcludeIncludeProviderPage.ProviderLastName.Displayed;
                    Assert.IsTrue(isDisplayed, "Provider Last Name text box is not displayed on Exclude/Include Provider screen");
                    actualText = RAM.ExcludeIncludeProviderPage.ProviderLastName.GetAttribute("placeholder");
                    Assert.AreEqual(expText, actualText, "Default Text is Provider Name is incorrect");
                    break;
                case "Search":
                    isDisplayed = RAM.ExcludeIncludeProviderPage.Findbutton.Displayed;
                    Assert.IsTrue(isDisplayed, "Search button is not displayed on Exclude/Include Provider screen");
                break;

            }
        }

       [When(@"Clicked on Find button")]
        public void WhenClickedOnFindButton()
        {
            tmsWait.WaitForElement(By.XPath("//button[@test-id='excludeProviders-btn-search']"), 100);
            fw.ExecuteJavascript(RAM.ExcludeIncludeProviderPage.Findbutton);
            tmsWait.Hard(20);
        }

        [When(@"on Provider Lookup page, Reset button is clicked")]
        public void WhenOnProviderLookupPageResetButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.ExcludeIncludeProviderPage.ResetButton);
            tmsWait.Hard(2);
        }


        [Then(@"verify default value in Search By field dropdown on Provider Lookup page")]
        public void ThenVerifyDefaultValueInSearchByFieldDropdownOnProviderLookupPage()
        {
            tmsWait.Hard(2);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//span[@class='k-input ng-scope']"));
            string actualValue = ele.Text;
            string expectedValue = "Provider ID";
            Assert.AreEqual(expectedValue, actualValue, "Default value in Search By Field is incorrect ");
         }


        [When(@"When Clicked on Find button")]
        public void WhenWhenClickedOnFindButton()
        {
            fw.ExecuteJavascript(RAM.ExcludeIncludeProviderPage.Findbutton);

        }

        [When(@"Find Provider Page I entered any existing provider ID")]
        public void WhenFindProviderPageIEnteredAnyExistingProviderID()
        {
            //get first provider id from the grid
            string firstproviderid=RAM.ExcludeIncludeProviderPage.ProviderID_First.Text;
            RAM.ExcludeIncludeProviderPage.ProviderId.SendKeys(firstproviderid);
            
        }

        [When(@"Find Provider Page I entered any existing Provider ID Last Name")]
        public void WhenFindProviderPageIEnteredAnyExistingProviderIDLastName()
        {

        }

        [When(@"ExcludeInclude Provider Provider Lookup icon is clicked")]
        public void WhenExcludeIncludeProviderProviderLookupIconIsClicked()
        {
            fw.ExecuteJavascript(RAM.ExcludeIncludeProviderPage.ProviderLookupIcon);
            tmsWait.Hard(3);
        }

        [When(@"on Provider Lookup page, Search By field ""(.*)"" is selected")]
        public void WhenOnProviderLookupPageSearchByFieldIsSelected(string p0)
        {
            tmsWait.Hard(2);
            string generatedData = tmsCommon.GenerateData(p0);
            //IWebElement ele = Browser.Wd.FindElement(By.XPath("//div[@class='k-list-scroller']/ul/li[contains(.,'"+generatedData+"')]"));
            //fw.ExecuteJavascript(ele);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='provider-select-searchBy']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + generatedData + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(1);
        }

        [When(@"on Provider Lookup page, Provider value is entered as ""(.*)""")]
        public void WhenOnProviderLookupPageProviderValueIsEnteredAs(string p0)
        {
            string generatedData = tmsCommon.GenerateData(p0);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@test-id='provider-input-SearchBytxt']"));
            ele.Clear();
            ele.SendKeys(generatedData);
        }

        [When(@"on Provider Lookup page, Provider First Name value is entered as ""(.*)""")]
        public void WhenOnProviderLookupPageProviderFirstNameValueIsEnteredAs(string p0)
        {
            string generatedData = tmsCommon.GenerateData(p0);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@test-id='searchProvider-txt-FirstName']"));
            ele.Clear();
            ele.SendKeys(generatedData);
        }

        [When(@"on Provider Lookup page, Provider Last Name value is entered as ""(.*)""")]
        public void WhenOnProviderLookupPageProviderLastNameValueIsEnteredAs(string p0)
        {
            string generatedData = tmsCommon.GenerateData(p0);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@test-id='searchProvider-txt-LastName']"));
            ele.Clear();
            ele.SendKeys(generatedData);
        }

        [When(@"on Provider Lookup page, Search button is clicked")]
        public void WhenOnProviderLookupPageSearchButtonIsClicked()
        {
            tmsWait.Hard(1);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@test-id='provider-btn-search']"));
            fw.ExecuteJavascript(ele);
        }

        [When(@"verify ""(.*)"" is displayed in the grid")]
        [Then(@"verify ""(.*)"" is displayed in the grid")]
        public void WhenVerifyIsDisplayedInTheGrid(string p0)
        {
            tmsWait.Hard(2);
            bool isDisplayed= false;
            string generatedData = tmsCommon.GenerateData(p0);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//tbody/tr[contains(.,'"+generatedData+"')]"));
            isDisplayed = ele.Displayed;                
            Assert.IsTrue(isDisplayed, "Provider details are not displayed in the grid");
        }

        [When(@"verify Provider ID ""(.*)"" is displayed in the grid")]
        public void WhenVerifyProviderIDIsDisplayedInTheGrid(string p0)
        {
            tmsWait.Hard(2);
            bool isDisplayed= false;
            string generatedData = tmsCommon.GenerateData(p0);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//tbody/tr/td[contains(.,'" + generatedData+"')]"));
            isDisplayed = ele.Displayed;                
            Assert.IsTrue(isDisplayed, "Provider ID is not displayed in the grid");
        }



        [When(@"Provider ID result grid first record is selected")]
        public void WhenProviderIDResultGridFirstRecordIsSelected()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//tr[@data-kendo-grid-item-index='0']")));
        }

        [When(@"Provider ID result grid multiple records is selected")]
        public void WhenProviderIDResultGridMultipleRecordsIsSelected()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//tr[1]/td[1]")));
        }

        [When(@"Provider lookup pagination next button is clicked")]
        public void WhenProviderLookupPaginationNextButtonIsClicked()
        {
            try
            {
                fw.ExecuteJavascript(RAM.ExcludeIncludeProviderPage.ProviderLookupNextIcon);
            }
            catch
            {
                /*If the try fails, then there is probably only one page, continue execution*/
            }
            tmsWait.Hard(2);
        }




        [Then(@"Verify Provider ID is displayed based on Provider ID search criteria")]
        public void ThenVerifyProviderIDIsDisplayedBasedOnProviderIDSearchCriteria()
        {

            tmsWait.IsElementPresent(By.XPath("//div[@id='providersGrid']/div/div[1]/div[2]/div/div[1]/div/div[2]"));

        }


        [Then(@"Find Provider Page Verify Note ""(.*)""")]
        public void ThenFindProviderPageVerifyNote(string expectednote)
        {
            // tmsWait.Hard(10);
            tmsWait.WaitForElement(By.XPath("//label[@test-id='excludeProviders-lbl-viewDiagnosisCodes']"), 60);
            string actualnote =RAM.ExcludeIncludeProviderPage.ProviderListNote.Text;
            Assert.AreEqual(expectednote, actualnote, expectednote + " Note is not getting displayed on Provider List");

        }

        [When(@"Find Provider Page I Clicked on Include checkbox")]
        public void WhenFindProviderPageIClickedOnIncludeCheckbox()
        {
            //adding more wait as its been observed that this page is taking 5 minutes to load 
            //tmsWait.Hard(400);
            tmsWait.WaitForElement(By.XPath("//kendo-grid[@test-id='excludeProviders-grid-providers']//tr[1]//input"), 400);
            fw.ExecuteJavascript(RAM.ExcludeIncludeProviderPage.CheckboxforfirstProvider);
            tmsWait.Hard(7);
        }

        [When(@"Find Provider Page I Clicked on Include checkbox for one more Provider")]
        public void WhenFindProviderPageIClickedOnIncludeCheckboxForOneMoreProvider()
        {
            //tmsWait.Hard(5);
            //RAM.ExcludeIncludeProviderPage.CheckboxforSecondProvider.Click();
            //tmsWait.Hard(5);
            fw.ExecuteJavascript(RAM.ExcludeIncludeProviderPage.CheckboxforSecondProvider);
        }


        [When(@"Clicked on Update button")]
        public void WhenClickedOnUpdateButton()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(RAM.ExcludeIncludeProviderPage.UpdateButton);
            tmsWait.Hard(8);
        }

        [When(@"Clicked on Cancel button")]
        public void WhenClickedOnCancelButton()
        {
            fw.ExecuteJavascript(RAM.ExcludeIncludeProviderPage.CancleButton);
            tmsWait.Hard(15);
        }

        
        [Then(@"Verify include checkbox is checked")]
        public void ThenVerifyIncludeCheckboxIsChecked()
        {
            tmsWait.Hard(15);
            Assert.IsTrue(RAM.ExcludeIncludeProviderPage.CheckboxforfirstProvider.Selected, "Failed Test Case as Checkbox is unchecked");
            tmsWait.Hard(5);
        }

        [Then(@"Verify include checkbox is checked for one more provider")]
        public void ThenVerifyIncludeCheckboxIsCheckedForOneMoreProvider()
        {
            tmsWait.Hard(5);
            Assert.IsTrue(RAM.ExcludeIncludeProviderPage.CheckboxforSecondProvider.Selected, "Failed Test Case as Checkbox is unchecked");
        }

        


        [Then(@"Verify include checkbox is unchecked")]
        public void ThenVerifyIncludeCheckboxIsUnchecked()
        {
            Assert.IsFalse(RAM.ExcludeIncludeProviderPage.CheckboxforfirstProvider.Selected, "Failed Test Case as Checkbox is checked");
        }



        [Then(@"Find Provider Page update include checkbox based on condition as ""(.*)""")]
        public void ThenFindProviderPageUpdateIncludeCheckboxBasedOnConditionAs(string condition)
        {
            tmsWait.Hard(6);
            if (condition.ToLower() == "check")
            {
                if (RAM.ExcludeIncludeProviderPage.CheckboxforfirstProvider.Selected)
                {
                    fw.ExecuteJavascript(RAM.ExcludeIncludeProviderPage.CheckboxforfirstProvider);
                    fw.ExecuteJavascript(RAM.ExcludeIncludeProviderPage.UpdateButton);
                    tmsWait.Hard(4);
                }
            }

        }


        [When(@"Find Provider Page I Clicked on Include checkbox for selected Provider")]
        public void WhenFindProviderPageIClickedOnIncludeCheckboxForSelectedProvider()
        {
            if (RAM.ExcludeIncludeProviderPage.CheckboxforfirstProvider.Selected)
            {
                fw.ExecuteJavascript(RAM.ExcludeIncludeProviderPage.CheckboxforfirstProvider);
                fw.ExecuteJavascript(RAM.ExcludeIncludeProviderPage.UpdateButton);
                tmsWait.Hard(3);
            }
            tmsWait.Hard(3);
            fw.ExecuteJavascript(RAM.ExcludeIncludeProviderPage.CheckboxforfirstProvider);
            fw.ExecuteJavascript(RAM.ExcludeIncludeProviderPage.UpdateButton);
            tmsWait.Hard(3);
        }


        [Then(@"uncheck ""(.*)"" Provider Ids to exclude and verify message ""(.*)"" is displayed")]
        public void ThenUncheckProviderIdsToExcludeAndVerifyMessageIsDisplayed(int p0, string toastmessage)
        {
            int cnt = 1;
            int i = 1;
            bool flag = false;
            bool isUpdated = false;
            IWebElement ele = null;
            string expectedValue = toastmessage.ToString();
            string actualValue;
            tmsWait.Hard(1);
            IList<IWebElement> tableRowCount = Browser.Wd.FindElements(By.XPath(".//*[@test-id='excludeProviders-grid-providers']//table/tbody/tr"));
            if (tableRowCount.Count < p0)
            {
                p0 = tableRowCount.Count;
                Console.Write("There is/are only " + tableRowCount.Count + " row(s) to update on Exclude/Include Provider page....");
                expectedValue = tableRowCount.Count + " row(s) updated successfully";
            }

            for (int j = 1; j <= p0; j++)
            {
                ele = Browser.Wd.FindElement(By.XPath(".//*[@test-id='excludeProviders-grid-providers']//tr[" + j + "]//input"));
                if (ele.Selected == false)
                {
                    fw.ExecuteJavascript(ele);
                    tmsWait.Hard(1);
                    isUpdated = true;
                    
                }
            }
            if (isUpdated == true)
            {
                fw.ExecuteJavascript(RAM.ExcludeIncludeProviderPage.UpdateButton);
                tmsWait.Hard(5);
            }

            do
            {
                ele = Browser.Wd.FindElement(By.XPath(".//*[@test-id='excludeProviders-grid-providers']//tr[" + i + "]//input"));
                if (ele.Selected == true)
                {
                    fw.ExecuteJavascript(ele);
                    cnt++;
                    i++;
                }
            } while (cnt <= p0);

            fw.ExecuteJavascript(RAM.ExcludeIncludeProviderPage.UpdateButton);
            tmsWait.Hard(3);
            actualValue = Browser.Wd.FindElement(By.XPath("//div[@class='k-notification-content']")).Text;
            Assert.AreEqual(expectedValue, actualValue, "Message is displyed successfully ");
            tmsWait.Hard(5);

            for (int j = 1; j <= tableRowCount.Count; j++)
            {
                ele = Browser.Wd.FindElement(By.XPath(".//*[@test-id='excludeProviders-grid-providers']//tr[" + j + "]//input"));
                if (ele.Selected == false)
                {
                    fw.ExecuteJavascript(ele);
                    tmsWait.Hard(1);
                    flag = true;
                }
            }
            if (flag == true)
            {
                fw.ExecuteJavascript(RAM.ExcludeIncludeProviderPage.UpdateButton);
                tmsWait.Hard(5);
            }
        }


        [Then(@"check ""(.*)"" Provider Ids to include and verify message ""(.*)"" is displayed")]
        public void ThenCheckProviderIdsToIncludeAndVerifyMessageIsDisplayed(int p0, string toastmessage)
        {
            int cnt = 1;
            int i = 1;
            bool flag = false;
            IWebElement ele = null;
            string expectedValue = toastmessage.ToString(); 
            string actualValue;
            tmsWait.Hard(1);
            IList<IWebElement> tableRowCount = Browser.Wd.FindElements(By.XPath(".//*[@test-id='excludeProviders-grid-providers']//table/tbody/tr"));
            if (tableRowCount.Count < p0) {
                p0 = tableRowCount.Count;
                Console.Write("There is/are only " + tableRowCount.Count + " row(s) to update on Exclude/Include Provider page....");
                expectedValue = tableRowCount.Count + " row(s) updated successfully";
            }

            for (int j = 1; j <= p0; j++)
            {
                ele = Browser.Wd.FindElement(By.XPath(".//*[@test-id='excludeProviders-grid-providers']//tr[" + j + "]//input"));
                if (ele.Selected == true)
                {
                    fw.ExecuteJavascript(ele);
                    tmsWait.Hard(1);
                }
            }
            fw.ExecuteJavascript(RAM.ExcludeIncludeProviderPage.UpdateButton);
            tmsWait.Hard(5);

            do
            {
                ele = Browser.Wd.FindElement(By.XPath(".//*[@test-id='excludeProviders-grid-providers']//tr[" + i + "]//input"));
                if (ele.Selected == false)
                {
                    fw.ExecuteJavascript(ele);
                    cnt++;
                    i++;
                }
            } while (cnt <= p0);

            fw.ExecuteJavascript(RAM.ExcludeIncludeProviderPage.UpdateButton);
            tmsWait.Hard(3);
            actualValue = Browser.Wd.FindElement(By.XPath("//div[@class='k-notification-content']")).Text;
            Assert.AreEqual(expectedValue, actualValue, "Message is displyed successfully ");
            tmsWait.Hard(5);

            for (int j = 1; j <= tableRowCount.Count; j++)
            {
                ele = Browser.Wd.FindElement(By.XPath(".//*[@test-id='excludeProviders-grid-providers']//tr[" + j + "]//input"));
                if (ele.Selected == false)
                {
                    fw.ExecuteJavascript(ele);
                    tmsWait.Hard(1);
                    flag = true;
                }
            }
            if (flag == true)
            {
                fw.ExecuteJavascript(RAM.ExcludeIncludeProviderPage.UpdateButton);
                tmsWait.Hard(5);
            }
            
     
        }

        

        [Then(@"Find Provider Page update include checkbox based on condition as ""(.*)"" for one more provider")]
        public void ThenFindProviderPageUpdateIncludeCheckboxBasedOnConditionAsForOneMoreProvider(string condition)
        {
            tmsWait.Hard(3);
            if (condition.ToLower() == "check")
            {
                IWebElement dd = RAM.ExcludeIncludeProviderPage.CheckboxforSecondProvider;
                if (!RAM.ExcludeIncludeProviderPage.CheckboxforSecondProvider.Selected)
                {
                    fw.ExecuteJavascript(RAM.ExcludeIncludeProviderPage.CheckboxforSecondProvider);
             
                    fw.ExecuteJavascript(RAM.ExcludeIncludeProviderPage.UpdateButton);
                    tmsWait.Hard(4);
                }
            }
            else
            {
                if (RAM.ExcludeIncludeProviderPage.CheckboxforSecondProvider.Selected)
                {
                    fw.ExecuteJavascript(RAM.ExcludeIncludeProviderPage.CheckboxforSecondProvider);

                    fw.ExecuteJavascript(RAM.ExcludeIncludeProviderPage.UpdateButton);
                    tmsWait.Hard(4);
                }
            }
        }


        [When(@"Find Provider Page I clicked on ""(.*)"" provider")]
        public void WhenFindProviderPageIClickedOnProvider(string checkboxinput)
        {
            string checkboxstatus =RAM.ExcludeIncludeProviderPage.CheckboxforfirstProvider.GetAttribute("value");
            tmsWait.Hard(5);
            switch (checkboxinput.ToLower())
            {
                case "uncheck":
                    //checking status of checkbox and if it is Off(unchecked) then check it first
                    if (checkboxstatus =="off")
                    { RAM.ExcludeIncludeProviderPage.CheckboxforfirstProvider.Click();
                        tmsWait.Hard(5);
                        RAM.ExcludeIncludeProviderPage.UpdateButton.Click();
                    }
                    //code to uncheck include checkbox
                    RAM.ExcludeIncludeProviderPage.CheckboxforfirstProvider.Click();
                    tmsWait.Hard(5);
                    RAM.ExcludeIncludeProviderPage.UpdateButton.Click();
                    break;
                case "check":
                    //checking status of checkbox and if is On(checked) then uncheck it first
                    if (checkboxstatus == "on")
                    { RAM.ExcludeIncludeProviderPage.CheckboxforfirstProvider.Click();
                        tmsWait.Hard(5);
                        RAM.ExcludeIncludeProviderPage.UpdateButton.Click();

                    }
                    //code to check include checkbox
                    RAM.ExcludeIncludeProviderPage.CheckboxforfirstProvider.Click();
                    tmsWait.Hard(5);
                    RAM.ExcludeIncludeProviderPage.UpdateButton.Click();
                    break;

            }

            }



        }


}
