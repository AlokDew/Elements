﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.HCC_RAM
{
    [Binding]
    class fsManageSuspectSearch
    {

        [When(@"Manage Suspect Search Page Search Type is Selected as ""(.*)""")]
        public void WhenManageSuspectSearchPageSearchTypeIsSelectedAs(string SearchBy)
        {
            string SearchBySuspect = SearchBy.ToString();
            


            By Drp = By.XPath("//kendo-dropdownlist[@test-id='manageSuspects-select-searchType']//span[@class='k-select']");
            AngularFunction.selectDropDownValue(Drp, SearchBy);

           

            switch (SearchBySuspect.ToUpper())
            {

                case "PIR":
                    Assert.IsTrue(RAM.ManageSuspectsSearchResultpage.ManageSuspectInputPIRNumber.Displayed);
                    break;

                case "MEMBER":
                    Assert.IsTrue(RAM.ManageSuspectsSearchResultpage.MemberLastName.Displayed);
                    break;


            }
        }

        [When(@"Manage Suspect Search Page PIR Number is Set to ""(.*)"" And Clicked On Search Button")]
        public void WhenManageSuspectSearchPagePIRNumberIsSetToAndClickedOnSearchButton(string PIRNumberInput)

        {
            //string PIRNumber = PIRNumberInput.ToString();
            string PIRNumber = tmsCommon.GenerateData(PIRNumberInput);
            RAM.ManageSuspectsSearchResultpage.ManageSuspectInputPIRNumber.SendKeys(PIRNumber);
            tmsWait.Hard(5);
           fw.ExecuteJavascript(RAM.ManageSuspectsSearchResultpage.ManageSuspectSearchButton);
           tmsWait.Hard(5);


        }

        [When(@"Manage Suspect Search Page Coder ID is Set to ""(.*)"" And Clicked On Search Button")]
        public void WhenManageSuspectSearchPageCoderIDIsSetToAndClickedOnSearchButton(string p0)
        {
            //string PIRNumber = PIRNumberInput.ToString();
            string coder = tmsCommon.GenerateData(p0);
            AngularFunction.selectKendoDropDownValue(RAM.ManageSuspectsSearchResultpage.CoderIDDrp, coder);
           
            tmsWait.Hard(3);
            fw.ExecuteJavascript(RAM.ManageSuspectsSearchResultpage.ManageSuspectSearchButton);
            tmsWait.Hard(5);
        }

        [Then(@"Verify Manage Suspect Search Page displayed No Records")]
        public void ThenVerifyManageSuspectSearchPageDisplayedNoRecords()
        {           

        By loc = By.XPath("//kendo-grid[@test-id='manageSuspects-grid-memberResult']//tr");
            AngularFunction.elementNotPresenceUsingLocators(loc);
        }

        [Then(@"Manage Suspect Search Page PIR is Set to ""(.*)"" And Clicked On Search Button and message varified")]
        [When(@"Manage Suspect Search Page PIR is Set to ""(.*)"" And Clicked On Search Button and message varified")]
        public void WhenManageSuspectSearchPagePIRIsSetToAndClickedOnSearchButtonAndMessageVarified(string p0)
        {


            string PIRNumber = tmsCommon.GenerateData(p0);
            RAM.ManageSuspectsSearchResultpage.ManageSuspectInputPIRNumber.SendKeys(PIRNumber);
            tmsWait.Hard(5);
            fw.ExecuteJavascript(RAM.ManageSuspectsSearchResultpage.ManageSuspectSearchButton);
            // Comment Toaster message as scripts will fail due to slowness of toaster
            //string expectedValue = "No PIR records found for this control number".ToString();
            //string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
            //Assert.AreEqual(expectedValue, actualValue, "Message is not displyed successfully ");


        }

        [When(@"Manage Suspect Search Page Member ID is Set to ""(.*)"" And Clicked On Search Button")]
        public void WhenManageSuspectSearchPageMemberIDIsSetToAndClickedOnSearchButton(string p0)
        {
            //string PIRNumber = PIRNumberInput.ToString();
            string memberid = tmsCommon.GenerateData(p0);
            RAM.ManageSuspectsSearchResultpage.PlanMemberIDTextbox.SendKeys(memberid);
            tmsWait.Hard(5);
            fw.ExecuteJavascript(RAM.ManageSuspectsSearchResultpage.ManageSuspectSearchButton);
            tmsWait.Hard(3);
        }

        [When(@"Manage Suspects page Member Search results Member ID ""(.*)"" is Clicked")]
        public void WhenManageSuspectsPageMemberSearchResultsMemberIDIsClicked(string p0)
        {
            string member = tmsCommon.GenerateData(p0);
            //By searchresult = By.XPath("(//kendo-grid[@test-id='manageSuspects-grid-memberResult']//td[contains(.,'" + member + "')]/following-sibling::td//a[@title='Edit'])[1]");
            By searchresult = By.XPath("//kendo-grid[@test-id='manageSuspects-grid-memberResult']//td[contains(.,'" + member + "')]//div//a[@title='Edit']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(searchresult));
            tmsWait.Hard(3);
        }

        [When(@"RAMX Application PIR Page Member Top Known HCC link is Clicked")]
        public void WhenRAMXApplicationPIRPageMemberTopKnownHCCLinkIsClicked()
        {
            fw.ExecuteJavascript(RAM.PIRPage.MemberTopUnknownHCCLink);
            tmsWait.Hard(12);
        }

        [When(@"RAMX PIR Page ADD Note button is Clicked")]
        public void WhenRAMXPIRPageADDNoteButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.PIRPage.AddNoteButton);
        }

        [When(@"RAMX All PIR Notes Page Note text box is set to ""(.*)""")]
        public void WhenRAMXAllPIRNotesPageNoteTextBoxIsSetTo(string p0)
        {
            string note = tmsCommon.GenerateData(p0);
            RAM.PIRPage.AllPIRNoteTextbox.SendKeys(note);
        }

        [When(@"RAMX All PIR Notes Page ADD Button is Clicked")]
        public void WhenRAMXAllPIRNotesPageADDButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.PIRPage.AllPIRADDButton);
            tmsWait.Hard(3);
            By loc = By.CssSelector("[test-id='confirmationDialog-btn-Yes']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            tmsWait.Hard(3);

        }

        [Then(@"Verify All PIR Notes page displayed ""(.*)""")]
        public void ThenVerifyAllPIRNotesPageDisplayed(string p0)
        {
            string results = tmsCommon.GenerateData(p0);
            By loc = By.XPath("//kendo-grid[@test-id='pirViewEditNotes-grd-noteGrd']//td[contains(.,'" + results + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }

        [When(@"RAMX Application Member Top Known HCC dialog HCC ""(.*)"" HCC Description as ""(.*)""")]
        public void WhenRAMXApplicationMemberTopKnownHCCDialogHCCHCCDescriptionAs(string hcc, string hccdes)
        {
            //By loc = By.XPath("//div[@id='topKnownHccGrid']//td[contains(.,'" + hcc + "')]/following-sibling::td[contains(.,'" + hccdes + "')]");
            By loc = By.XPath("//kendo-grid[@test-id='providerPirDetails-grid-topKnown']//td[contains(.,'" + hcc + "')]/following-sibling::td[contains(.,'" + hccdes + "')]");

            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }


        [Then(@"Verify Manage Suspect Search Page mesaage ""(.*)""")]
        public void ThenVerifyManageSuspectSearchPageMesaage(string errormessage)
        {
            string expectedValue = errormessage.ToString();
            string actualValue = RAM.ManageSuspectsSearchResultpage.ManageSuspectPIRNumberErrorMessage.Text;
            Assert.AreEqual(expectedValue, actualValue, "Error Message is getting displyed successfully ");

        }

        [When(@"Manage Suspect Search Page Last Name is Set to ""(.*)"" And Clicked On Search Button")]
        public void WhenManageSuspectSearchPageLastNameIsSetToAndClickedOnSearchButton(string lastname)
        {
            string LastName = lastname.ToString();
            RAM.ManageSuspectsSearchResultpage.MemberLastName.SendKeys(LastName);
            RAM.ManageSuspectsSearchResultpage.ManageSuspectSearchButton.Click();
        }


        [When(@"Manage Suspect Search Page Last Name is entered as ""(.*)""")]
        public void WhenManageSuspectSearchPageLastNameIsEnteredAs(string lastName)
        {
            RAM.ManageSuspectsSearchResultpage.MemberLastName.SendKeys(lastName);
        }

        [When(@"Manage Suspect Search Page Member ID is entered as ""(.*)""")]
        public void WhenManageSuspectSearchPageMemberIDIsEnteredAs(string p0)
        {
            string memberID = tmsCommon.GenerateData(p0);
            RAM.ManageSuspectsSearchResultpage.PlanMemberIDTextbox.SendKeys(memberID);
        }

        [When(@"Manage Suspect Search Page Search button is clicked")]
        public void WhenManageSuspectSearchPageSearchButtonIsClicked()
        {
            RAM.ManageSuspectsSearchResultpage.ManageSuspectSearchButton.Click();
        }


        [Then(@"Verify Manage suspect Result grid is opened successfully")]
        public void ThenVerifyManageSuspectResultGridIsOpenedSuccessfully()
        {
            if (RAM.ManageSuspectsSearchResultpage.ActionEditLink.Displayed)
            {
                Assert.IsTrue(RAM.ManageSuspectsSearchResultpage.ActionEditLink.Displayed);
            }

        }
    }
}

