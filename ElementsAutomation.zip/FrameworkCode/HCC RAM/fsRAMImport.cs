﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using OpenQA.Selenium.Interactions;
using System.IO;

namespace TMSoR1.FrameworkCode.HCC_RAM
{
    [Binding]
    class fsRAMImport
    {
        [When(@"RAM Import page PIR Response link is clicked")]
        [When(@"RAMX Import page PIR Response link is clicked")]
        public void WhenRAMImportPagePIRResponseLinkIsClicked()
        {
            fw.ExecuteJavascript(RAM.ImportsPage.PIRResponse);
        }


        [When(@"Import page ""(.*)"" link is clicked")]
        public void WhenExportPageLinkIsClicked(string p0)
        {
            tmsWait.Hard(5);
            string expected = p0.ToString();
            IWebElement xpath = Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + expected + "')]"));
            fw.ExecuteJavascript(xpath);

        }


        [When(@"Execute SQL Query ""(.*)"" Verify Query results returns No Values")]
        public void WhenExecuteSQLQueryVerifyQueryResultsReturnsNoValues(string query)
        {
            tmsWait.Hard(15); // Reason for more Wait is Table field updation is taking time. please do not remove this wait

            int recordcount = db.returnSQLQueryresultsWithBlankValues(query);
            

            Assert.AreEqual(0, recordcount, " Both are not matching");
        }

        [When(@"Execute SQL Query ""(.*)"" Verify Query results returns value as ""(.*)""")]
        public void WhenExecuteSQLQueryVerifyQueryResultsReturnsValueAs(string query, string p1)
        {

            tmsWait.Hard(15); // Reason for more Wait is Table field updation is taking time. please do not remove this wait
            var queryResult = db.returnSQLQueryresultsWithCompleteIntegerRowsInArrayFormat(query);

            fw.ConsoleReport("intHCCSequence values ");
            

            List<int> HCCNumber = new List<int>();
            foreach(string temp in p1.Split(','))
            {
                HCCNumber.Add(Convert.ToInt32(temp));
                fw.ConsoleReport(temp);
            }
           

            
            List<int> results= ReUsableFunctions.compareTwoIntList(queryResult, HCCNumber);

            int resultscount = results.Count;

            Assert.AreEqual(0, resultscount, " Both counts are not matching");

        }


        [When(@"Execute SQL Query ""(.*)"" compare Query results HCC Number value with ALM attached Excel File content ""(.*)"" from Test ID ""(.*)""")]
        public void WhenExecuteSQLQueryCompareQueryResultsHCCNumberValueWithALMAttachedExcelFileContentFromTestID(string query, string file, string test)
        {
           
            ReUsableFunctions.deleteFilesFromTempFolder();

            tmsWait.Hard(15); // Reason for more Wait is Table field updation is taking time. please do not remove this wait
            var queryResult = db.returnSQLQueryresultsWithCompleteIntegerRowsInArrayFormat(query);



            string fileName = tmsCommon.GenerateData(file);
            string testid = tmsCommon.GenerateData(test);


            Boolean keepTrying = true;

            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            // We added this code for Jenkins run
            // Do not comment below code as it will be used for Smoke test suite
            string SourceFileLocation = "C:\\SourceFile\\";
            string tempFolder = "c:\\temp\\";
            Boolean didUpload = false;
            string source = SourceFileLocation + fileName;
            bool fileDownloadOnALM = false;
            if (Directory.Exists(SourceFileLocation))
            {
                if (!File.Exists(controllerFileLocation))
                {
                    File.Copy(SourceFileLocation + fileName, tempFolder + fileName);
                    fileDownloadOnALM = true;
                    didUpload = true;

                    fw.ConsoleReport(fileName + " File is found on Source File Folder");
                }
            }



            if (!fileDownloadOnALM)
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(fileName, testid);
            }

            string Filepath = "c:\\Temp\\" + fileName.Split('.')[0];
            tmsWait.Hard(7);
            var excelData = ReUsableFunctions.ReadSpecificSheet_SpecificIndex_Data_XLSFile(Filepath + ".XLSX", Filepath + ".CSV", 4, 14);

            List<int> HCCNumber = new List<int>();
            foreach (string temp in excelData)
            {
                if (temp.Equals(""))
                {
                    fw.ConsoleReport(" There is an empty String");
                }
                else
                {
                    HCCNumber.Add(Convert.ToInt32(temp));
                }
            }

            // Verified some values
            bool result = queryResult.Except(HCCNumber).Any();
            bool match = false;
            if (result)
            {
                Console.WriteLine("matched");
                match = true;
            }
            else
            {
                Console.WriteLine("not matched");

            }

           
            //if (HCCNumber.Intersect(queryResult).Any())
            //{
            //    Console.WriteLine("matched");
            //    match = true;
            //}
            //else
            //{
            //    Console.WriteLine("not matched");
            //    match = true;
            //}

            Assert.IsTrue(match, " SQL Query records are matched with Excel Sheet record");

            // VerifyText(excelData, ReportValidationText, format);
            try
            {
                System.IO.DirectoryInfo di = new DirectoryInfo("c:\\Temp\\");

                foreach (FileInfo tfile in di.GetFiles())
                {
                    tfile.Delete();
                }

            }
            catch
            {

            }

            tmsWait.Hard(40);  // we kep this wait for int
        }


        [When(@"Execute SQL Query ""(.*)"" compare Query results with ALM attached Excel File content ""(.*)"" from Test ID ""(.*)""")]
        public void WhenExecuteSQLQueryCompareQueryResultsWithALMAttachedExcelFileContentFromTestID(string query, string file, string test)
        {
            ReUsableFunctions.deleteFilesFromTempFolder();

            tmsWait.Hard(15); // Reason for more Wait is Table field updation is taking time. please do not remove this wait
            var queryResult = db.returnSQLQueryresultsWithCompleteRowsInArrayFormat(query);



            string fileName = tmsCommon.GenerateData(file);
            string testid = tmsCommon.GenerateData(test);


            Boolean keepTrying = true;

            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            // We added this code for Jenkins run
            // Do not comment below code as it will be used for Smoke test suite
            string SourceFileLocation = "C:\\SourceFile\\";
            string tempFolder = "c:\\temp\\";
            Boolean didUpload = false;
            string source = SourceFileLocation + fileName;
            bool fileDownloadOnALM = false;
            if (Directory.Exists(SourceFileLocation))
            {
                if (!File.Exists(controllerFileLocation))
                {
                    File.Copy(SourceFileLocation + fileName, tempFolder + fileName);
                    fileDownloadOnALM = true;
                    didUpload = true;

                    fw.ConsoleReport(fileName + " File is found on Source File Folder");
                }
            }



            if (!fileDownloadOnALM)
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(fileName, testid);
            }

            string Filepath = "c:\\Temp\\" + fileName.Split('.')[0];
            tmsWait.Hard(7);
            var excelData = ReUsableFunctions.ReadSpecificSheet_SpecificIndex_Data_XLSFile(Filepath + ".XLSX", Filepath + ".CSV", 4, 2);

            fw.ConsoleReport(" Reading File Path " + Filepath);

            bool match = false;

            //It  subtracts all the elements from first collection(queryResult) from second collection (excelData), returns the remaining elements

            var result = queryResult.Except(excelData).ToList().Count;

            if (result==0)
            {
                Console.WriteLine("matched");
                match = true;
            }
            else
            {
                Console.WriteLine("not matched");
               
            }

            Assert.IsTrue(match, " SQL Query records are matched with Excel Sheet record");
            fw.ConsoleReport(" SQL Query results are matching with Excel sheet record");
            fw.ConsoleReport(" List of Code Value ");
            foreach (var temp in queryResult)
            {
                fw.ConsoleReport(temp);
            }

            // VerifyText(excelData, ReportValidationText, format);
            try
            {
                System.IO.DirectoryInfo di = new DirectoryInfo("c:\\Temp\\");

                foreach (FileInfo tfile in di.GetFiles())
                {
                    tfile.Delete();
                }

            }
            catch
            {

            }

            tmsWait.Hard(40);  // we kep this wait for intentionally as EAF file processing is taking time, will remove later

        }


        [When(@"Download Attached Excel File ""(.*)"" from Test ID ""(.*)""")]
        public void WhenDownloadAttachedExcelFileFromTestID(string p0, string p1)
        {

            string fileName = tmsCommon.GenerateData(p0);
            string testid = tmsCommon.GenerateData(p1);
        

            Boolean keepTrying = true;

            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            // We added this code for Jenkins run
            // Do not comment below code as it will be used for Smoke test suite
            string SourceFileLocation = "C:\\SourceFile\\";
            string tempFolder = "c:\\temp\\";
            Boolean didUpload = false;
            string source = SourceFileLocation + fileName;
            bool fileDownloadOnALM = false;
            if (Directory.Exists(SourceFileLocation))
            {
                if (!File.Exists(controllerFileLocation))
                {
                    File.Copy(SourceFileLocation + fileName, tempFolder + fileName);
                    fileDownloadOnALM = true;
                    didUpload = true;

                    fw.ConsoleReport(fileName+" File is found on Source File Folder");
                }
            }

            

            if (!fileDownloadOnALM)
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(fileName, testid);
            }

            string Filepath= "c:\\Temp\\"+ fileName.Split('.')[0];
            tmsWait.Hard(7);
            var excelData = ReUsableFunctions.ReadSpecificSheet_SpecificIndex_Data_XLSFile(Filepath + ".XLSX", Filepath + ".CSV", 3, 2);
               
           // VerifyText(excelData, ReportValidationText, format);
            try
            {
                System.IO.DirectoryInfo di = new DirectoryInfo("c:\\Temp\\");

                foreach (FileInfo file in di.GetFiles())
                {
                    file.Delete();
                }

            }
            catch
            {

            }

            tmsWait.Hard(40);  // we kep this wait for intentionally as EAF file processing is taking time, will remove later
        

    }
        public void VerifyText(List<string> dataFromFile, string reportName, string format)
        {
            bool flag = false;
            tmsWait.Hard(5);

            foreach (string data in dataFromFile)
            {

                if (data.ToUpper().Contains(reportName.ToUpper()))
                {
                    flag = true;
                }
            }
            if (format.ToUpper().Equals("CSV"))
            {

                Assert.IsTrue(flag, format + " File has missed some data. Failed..."); //For CSV there is Report Name is not getting displayed. File is getting dreated successfully...
            }
            if (format.ToUpper().Equals("XLS"))
            {
                Assert.IsTrue(flag, format + " File has missed some data. Failed...");
            }
            if (format.ToUpper().Equals("XLSX"))
            {
                Assert.IsTrue(flag, format + " File has missed some data. Failed...");
            }
        }


        [When(@"RAM Import page Client Identified suspect link is clicked")]
        public void WhenRAMImportPageClientIdentifiedSuspectLinkIsClicked()
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(RAM.ImportsPage.ClientIdentifiedSuspects);
        }

        [When(@"RAM Import page Client Identified suspect pipelimited radio button is clicked")]
        [When(@"RAMX Import page Client Identified suspect pipelimited radio button is clicked")]
        public void WhenRAMImportPageClientIdentifiedSuspectPipelimitedRadioButtonIsClicked()
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(RAM.ImportsPage.PipeDelimitedRadioBtn);
        }


        [When(@"Load RAMX PIR Response File page, Config File ALM Project, Test ID ""(.*)"" attached file ""(.*)"" is selected with New File Name ""(.*)""")]
        [When(@"Load RAM PIR Response File page, Config File ALM Project, Test ID ""(.*)"" attached file ""(.*)"" is selected with New File Name ""(.*)""")]
        public void WhenLoadRAMPIRResponseFilePageConfigFileALMProjectTestIDAttachedFileIsSelectedWithNewFileName(string p0, string p1, string p2)
        {
            tmsWait.Hard(5);
            string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);

            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            Boolean didUpload = false;

            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");

  
         
            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");
            if (File.Exists(controllerFileLocation + p1_gen))
            {
                File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen, true);
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");

            }
           
            
            //if (File.Exists(controllerFileLocation + p1_gen))
            //{
            //    File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen, true);
            //    tmsWait.Hard(1);
            //    didUpload = true;
            //    Console.WriteLine("**Performed local copy because file did exist locally.");

            //}
            else
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
       
            if (didUpload)
            {
                string FileName = "C:\\Temp\\" + p1_gen;
                //For debugging
                string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen);
                File.Move(@FileName, @newFileName);
                FileName = newFileName;
             
                RAM.ImportsPage.PIRSelectFileBtn.SendKeys(FileName);
                RAM.ImportsPage.UploadFilesBtn.Click();
                tmsWait.Hard(1);
            }
        }

        [When(@"RAMX Import page Import button is clicked")]
        [When(@"RAM Import page Import button is clicked")]
        public void WhenRAMImportPageImportButtonIsClicked()
        {
           
                fw.ExecuteJavascript(RAM.ImportsPage.ImportBtn);
                tmsWait.Hard(5);
          

            
          
        }



    }
}
