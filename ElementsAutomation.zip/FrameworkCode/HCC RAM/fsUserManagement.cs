﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using TechTalk.SpecFlow;

namespace TMSoR1
{
    [Binding]
    public class fsUserManagement
    {
        [Given(@"Verify submenu ""(.*)"" is displayed under ""(.*)"" menu")]
        public void GivenVerifySubmenuIsDisplayedUnderMenu(string submenu, string menu)
        {
            tmsWait.Hard(5);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//a[@title='"+ menu+"']/following-sibling::ul//li//a[@title='"+ submenu+"']")).Enabled);
           
        }

    }
}
