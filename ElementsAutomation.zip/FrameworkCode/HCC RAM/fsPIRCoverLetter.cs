﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using TechTalk.SpecFlow;
using OpenQA.Selenium.Interactions;

namespace TMSoR1.FrameworkCode.HCC_RAM
{
    [Binding]
    class fsPIRCoverLetter
    {

        [When(@"RAMAdministration PIRCoverLetter Text is cleared")]
        [When(@"RAMXAdministration PIRCoverLetter Text is cleared")]
        public void WhenRAMAdministrationPIRCoverLetterTextIsCleared()
        {
            RAM.PIRCoverLetter.PIRCoverLetterTxtArea.Clear();
            tmsWait.Hard(2);
        }

        [When(@"RAMAdministration PIRCoverLetter Updated as ""(.*)""")]
        [When(@"RAMXAdministration PIRCoverLetter Updated as ""(.*)""")]
        public void WhenRAMAdministrationPIRCoverLetterUpdatedAs(string p0)
        {
            string text = tmsCommon.GenerateData(p0);
            RAM.PIRCoverLetter.PIRCoverLetterTxtArea.Clear();
            RAM.PIRCoverLetter.PIRCoverLetterTxtArea.SendKeys(text);
            ScenarioContext.Current["UpdatedText"] = text.Trim();
        }

        [When(@"RamAdministration PIRCoverLetter Update button is clicked")]
        [When(@"RamxAdministration PIRCoverLetter Update button is clicked")]
        public void WhenRamAdministrationPIRCoverLetterUpdateButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.PIRCoverLetter.PIRCoverLetterUpdateBtn);
            tmsWait.Hard(5);
            if (RAM.PIRCoverLetter.PIRCoverLetterUpdateYes.Displayed)
            {
                fw.ExecuteJavascript(RAM.PIRCoverLetter.PIRCoverLetterUpdateYes);
                //tmsWait.Hard(5);
            }
        }

        [When(@"RamAdministration PIRCoverLetter Reset button is clicked")]
        [When(@"RamxAdministration PIRCoverLetter Reset button is clicked")]
        public void WhenRamAdministrationPIRCoverLetterResetButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.PIRCoverLetter.PIRCoverLetterResetBtn);
            tmsWait.Hard(3);
        }

        [Then(@"Verify PIR Cover Letter Message ""(.*)""")]
        public void ThenVerifyPIRCoverLetterMessage(string p0)
        {
            //tmsWait.Hard(5);
            

            By toastMsg = By.XPath("//div[@class='k-notification-content']");
            string actValue = Browser.Wd.FindElement(toastMsg).Text;
            string expectedValue = p0.ToString();
            Assert.IsTrue(actValue.Contains(expectedValue));
        }

        [When(@"I execute SQL Query on Database ""(.*)"" with SQL")]
        public void WhenIExecuteSQLQueryOnDatabaseWithSQL(string p0)
        {
            //string clientid = Convert.ToString(ScenarioContext.Current["ClientId"]);
            string clientID = GlobalRef.ClientId;
            //Console.WriteLine(clientid);
            string dbQuery = "select CoverLetterText from tbReportCoverLetter where txtClientID=" + clientID;
            db.AddDBQuery(p0, dbQuery);
        }

        [Then(@"Verify CustomizePIR Cover Letter is Updated correctly")]
        public void ThenVerifyCustomizePIRCoverLetterIsUpdatedSuccessfully()
        {
            string expectedLetterText = Convert.ToString(ScenarioContext.Current["ClientId"]);
            Assert.AreEqual(ScenarioContext.Current["UpdatedText"], ScenarioContext.Current["ClientId"], "Cover Letter Text Not Updated correctly");
        }
        [Then(@"Verify CustomizePIR Cover Letter is Cleared correctly")]
        public void ThenVerifyCustomizePIRCoverLetterIsClearedcorrectly()
        {
            string expectedLetterText = RAM.PIRCoverLetter.PIRCoverLetterTxtArea.Text;
            Assert.IsTrue(expectedLetterText.Length.Equals(0), "Cover Letter Text Not cleared correctly");
        }

        [Then(@"Verify Customize PIR CoverLetter updated text is cleared successfully")]
        public void ThenVerifyCustomizePIRCoverLetterUpdatedTextIsClearedSuccessfully()
        {
            string expectedLetterText = Convert.ToString(ScenarioContext.Current["ClientId"]);
            Assert.AreNotEqual(ScenarioContext.Current["UpdatedText"], ScenarioContext.Current["ClientId"], "Reset Functionality Failed");
        }

        [When(@"RAMAdministration PIRCoverLetter InstructionIcon is clicked")]
        [When(@"RAMXAdministration PIRCoverLetter InstructionIcon is clicked")]
        public void WhenRAMAdministrationPIRCoverLetterInstructionIconIsClicked()
        {
            Actions action = new Actions(Browser.Wd);
            action.MoveToElement(RAM.PIRCoverLetter.PIRCoverLetterQuestionMark).Perform();
            tmsWait.Hard(3);
        }

      
       [Then(@"RAMXAdministration PIRCoverLetter InstructionIcon is clicked and verify RAMAdministration PIRCoverLetter Instructions is displayed")]
        public void ThenRAMXAdministrationPIRCoverLetterInstructionIconIsClickedAndVerifyRAMAdministrationPIRCoverLetterInstructionsIsDisplayed()
        {
            Actions action = new Actions(Browser.Wd);
            action.MoveToElement(RAM.PIRCoverLetter.PIRCoverLetterQuestionMark).Perform();
            bool isDisplayed = Browser.Wd.FindElement(By.XPath("//div[@class='tooltip ng-scope ng-isolate-scope right tooltipCustom fade in']")).Displayed;
            Assert.IsTrue(isDisplayed, "Instructions box is not Displayed");
        }


        [Then(@"RAMXAdministration PIRCoverLetter InstructionIcon is clicked and verify Instructions text")]
        public void ThenRAMXAdministrationPIRCoverLetterInstructionIconIsClickedAndVerifyInstructionsText()
        {
            Actions action = new Actions(Browser.Wd);
            action.MoveToElement(RAM.PIRCoverLetter.PIRCoverLetterQuestionMark).Perform();
            tmsWait.Hard(3);
        }


        [When(@"verify warning message is displayed ""(.*)""")]
        public void WhenVerifyWarningMessageIsDisplayed(string p0)
        {
            string expMessage = tmsCommon.GenerateData(p0);
            string actualMessage= Browser.Wd.FindElement(By.XPath("//span[@test-id='updateCoverLetter-span-addWarning']")).Text;
            Assert.AreEqual(expMessage, actualMessage, "Message content is not as expected");
        }

        [When(@"i click on warning message")]
        public void WhenIClickOnWarningMessage()
        {
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//button[@test-id='updateCoverLetter-btn-yes']"));
            fw.ExecuteJavascript(ele);
        }


        [Then(@"Verify RAMAdministration PIRCoverLetter Instructions is displayed")]
        [Then(@"Verify RAMXAdministration PIRCoverLetter Instructions is displayed")]
        public void ThenVerifyRAMAdministrationPIRCoverLetterInstructionsIsDisplayed()
        {
            try
            {
                tmsWait.Hard(3);
                Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@class='tooltip ng-isolate-scope left fade']")).Displayed);

            }
            catch (Exception)
            { }
        }
    }
}
