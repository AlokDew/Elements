﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.HCC_RAM
{[Binding]
    class fsAdditionalDiagnoses
    {

        [Then(@"Verify Manage Suspect page Additional Diagnoses Grid Add new record button  is present")]
        public void ThenVerifyManageSuspectPageAdditionalDiagnosesGridAddNewRecordButtonIsPresent()
        {
            RAM.ManageSuspectPage.AdditionalDiagnosesAddNewRecordlink.Click();
        }

        [Then(@"Verify Manage Suspect page Label ""(.*)"" is present")]
        public void ThenVerifyManageSuspectPageLabelIsPresent(string p0)
        {
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(text(), '"+ p0 +"')]")).Displayed);
        }


        [Then(@"Verify Manage Suspect page Additional Diagnoses Grid Add new record button  is clicked")]
        public void ThenVerifyManageSuspectPageAdditionalDiagnosesGridAddNewRecordButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.ManageSuspectPage.AdditionalDiagnosesAddNewRecordlink);
        }
        [When(@"Manage Suspect page addditional diag code is set to ""(.*)""")]
        public void WhenManageSuspectPageAddditionalDiagCodeIsSetTo(int adddiagcode)
        {
            string additionaldiagcode = adddiagcode.ToString();
            RAM.ManageSuspectPage.AdditionaldiagCode.SendKeys(additionaldiagcode);
        }

        
      [When(@"Manage Suspect page additional diag encounter date is set as date of service")]
       public void WhenManageSuspectPageAdditionalDiagEncounterDateIsSetAsDateOfService()
       {
            RAM.ManageSuspectPage.AdditionaldiagECounterDate.Clear();
            RAM.ManageSuspectPage.AdditionaldiagECounterDate.SendKeys(RAM.ManageSuspectPage.DateofService.Text);
            tmsWait.Hard(1);
        }

        [When(@"Manage Suspect page additional diag provider id is set to ""(.*)""")]
        public void WhenManageSuspectPageAdditionalDiagProviderIdIsSetTo(string adddiagproviderId)
        {
            RAM.ManageSuspectPage.AdddiagProviderId.SendKeys(adddiagproviderId);
            tmsWait.Hard(1);

        }

        [When(@"Manage suspect page additional diag riskassess code is set to ""(.*)""")]
        public void WhenManageSuspectPageAdditionalDiagRiskassessCodeIsSetTo(string adddiagriskcode)
        {
            By Drp = By.XPath("//kendo-dropdownlist[@id='ddlRiskAssessment']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='B – Non Clinical w/ Wellness Proc']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

        }

        [When(@"Manage suspect page additional daig claim number is set to ""(.*)""")]
        public void WhenManageSuspectPageAdditionalDaigNumberIsSetTo(string adddiagclaimno)
        {

            ReUsableFunctions.enterValueOnWebElement(RAM.PIRPage.ClaimNumber, adddiagclaimno);
        }

        [When(@"Manage Suspect page additional diag onhold check box is checked")]
        public void WhenManageSuspectPageAdditionalDiagOnholdCheckBoxIsChecked()
        {
            fw.ExecuteJavascript(RAM.ManageSuspectPage.AdddiagOnHoldcheckbox);
        }
       

        [When(@"Manage Suspect page additional diag onhold reason ""(.*)"" is selected")]
        public void WhenManageSuspectPageAdditionalDiagOnholdReasonIsSelected(string onholdreason)
        {
            SelectElement selectOnHoldReason = new SelectElement(RAM.ManageSuspectPage.DropdownOnHoldReason);
            selectOnHoldReason.SelectByText(onholdreason);
            //string  Inactivereason= tmsCommon.GenerateData(onholdreason);
            //IWebElement onholdreasondd = Browser.Wd.FindElement(By.XPath(".//span[@class='k-dropdown-wrap k-state-default']"));
            //fw.ExecuteJavascript(onholdreasondd);
            //tmsWait.Hard(1);
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(".//li[contains(text(), '" + Inactivereason + "')]")));
        }

        [When(@"Manage Suspect page save button is clicked for code ""(.*)""")]
        public void WhenManageSuspectPageSaveButtonIsClickedForCode(int code)
        {
            fw.ExecuteJavascript(RAM.ManageSuspectPage.Adddiagsaveaction);
            tmsWait.Hard(2);
        }




    }
}
