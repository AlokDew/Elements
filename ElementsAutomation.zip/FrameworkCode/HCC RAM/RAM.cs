﻿namespace TMSoR1
{
    internal class RAM
    {
    }
}