﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System.Collections.Generic;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.HCC_RAM
{
    [Binding]
    public class fsRAMScheduling
    {
        SelectElement paymentYear, priorityDD, suspectType;

      [When(@"Scheduling page Search Provider button is clicked")]
        public void WhenSchedulingPageSearchProviderButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(RAM.RAMScheduling.SearchProviderButton);
            tmsWait.Hard(1);
        }

        [When(@"Scheduling page First Provider ID is selected")]
        public void WhenSchedulingPageFirstProviderIDIsSelected()
        {
            Browser.Wd.FindElement(By.XPath("//*[@id='providers']/option[2]")).Click();
            RAM.RAMScheduling.ProviderDropdown.Click();
            SelectElement providerID = new SelectElement(RAM.RAMScheduling.ProviderDropdown);
            ScenarioContext.Current["SelectedProviderID"] = providerID.SelectedOption.Text;
        }

        [When(@"Scheduling Summary page note updated as ""(.*)""")]
        public void WhenSchedulingSummaryPageNoteUpdatedAs(string note)
        {
            string note1 = tmsCommon.GenerateData(note);
            RAM.RAMScheduling.NoteTextArea.Clear();
            RAM.RAMScheduling.NoteTextArea.SendKeys(note1);
        }

        [When(@"Scheduling Summary page Update Queue Status button is clicked")]
        public void WhenSchedulingSummaryPageUpdateQueueStatusButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.RAMScheduling.UpdateQueueStatusButton);

            Assert.IsTrue(RAM.RAMScheduling.SuccessMessage.Displayed);
        }
        [Then(@"Scheduling Status button clicked for ""(.*)"" and message varified ""(.*)""")]
        [When(@"Scheduling Status button clicked for ""(.*)"" and message varified ""(.*)""")]
        public void WhenSchedulingStatusButtonClickedForAndMessageVarified(string p0, string p1)
        {
            string Note1 = tmsCommon.GenerateData(p0);
            try
            {
                RAM.RAMScheduling.UpdateQueueStatusButton.Click();
            }
            catch
            {

             
                string note = RAM.RAMScheduling.NoteTextArea.GetAttribute("value");
                
                Assert.IsTrue(note.Contains(Note1));
            }
        }




        [When(@"Scheduling Summary page Update Queue Status button is clicked and success message varified ""(.*)""")]
        public void WhenSchedulingSummaryPageUpdateQueueStatusButtonIsClickedAndSuccessMessageVarified(string p0)
        {

        

            // fw.ExecuteJavascript(RAM.RAMScheduling.UpdateQueueStatusButton);
       
            //Assert.IsTrue(RAM.RAMScheduling.SuccessMessage.Displayed);
            RAM.RAMScheduling.UpdateQueueStatusButton.Click();
            RAM.RAMScheduling.UpdateQueueStatusButton.Click();
            string actualvalue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
            string expectedvalue = p0.ToString();
            Assert.IsTrue(actualvalue.Contains(expectedvalue), "Message is displayed successfully");
           
        }

        [When(@"on Scheduling Summary page Update Queue Status button is clicked and success message varified ""(.*)""")]
        public void WhenOnSchedulingSummaryPageUpdateQueueStatusButtonIsClickedAndSuccessMessageVarified(string p0)
        {
            IWebElement currentElement = Browser.Wd.SwitchTo().ActiveElement();
            currentElement.SendKeys(Keys.Tab);
            tmsWait.Hard(1);
            currentElement = Browser.Wd.SwitchTo().ActiveElement();
            currentElement.SendKeys(Keys.Tab);
            tmsWait.Hard(1);
            currentElement = Browser.Wd.SwitchTo().ActiveElement();
            currentElement.SendKeys(Keys.Tab);
            tmsWait.Hard(1);
            RAM.RAMScheduling.UpdateQueueStatusButton.Click();
            //string actualvalue = Browser.Wd.FindElement(By.ClassName("toast-message")).GetAttribute("aria-label");
            By toastMsg = By.XPath("//div[@class='k-notification-content']");
            string actualvalue = Browser.Wd.FindElement(toastMsg).Text;
            string expectedvalue = p0.ToString();
            Assert.IsTrue(actualvalue.Contains(expectedvalue), "Message is displayed successfully");

        }


        [When(@"Scheduling page Provider ID is selected as ""(.*)""")]
        public void WhenSchedulingPageProviderIDIsSelectedAs(string provider)
        {
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//select[@test-id='scheduling-select-provider']//option[2]")));
            tmsWait.Hard(5);
            //SelectElement providerDD = new SelectElement(RAM.RAMScheduling.ProviderDropdown);
            //providerDD.SelectByIndex(0);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='scheduling-select-provider']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + provider + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));


        }


        [When(@"Verify Data get display in Result section as per the serch Criteria")]
        public void WhenVerifyDataGetDisplayInResultSectionAsPerTheSerchCriteria()
        {
            tmsWait.Hard(5);
            if (RAM.RAMScheduling.ProviderSearchResult.Displayed)
            {
                Assert.IsTrue(RAM.RAMScheduling.ProviderSearchResult.Text.Contains("Provider Information"));
            }
            else
            {
                //Need to select another options in Provider search
            }
        }

        [When(@"Scheduling page first provider is selected")]
        public void WhenSchedulingPageFirstProviderIsSelected()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//ul[@class='k-group k-treeview-lines']/li[1]")));
            tmsWait.Hard(1);
        }

        [When(@"Scheduling page first provider first queue and first member is selected")]
        public void WhenSchedulingPageFirstProviderFirstQueueAndFirstMemberIsSelected()
        {
            try
            {

          
            tmsWait.Hard(1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//ul[@class='k-group k-treeview-lines']//li[1]//span[@class='k-icon k-i-expand'])[1]")));
            tmsWait.Hard(4);
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//ul[@class='k-group k-treeview-lines']//li[1]//span[@class='k-icon k-i-expand'])[1]")));
            //tmsWait.Hard(4);
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//ul[@class='k-group']//li[1]//span[contains(., 'Member')])[1]")));

            //tmsWait.WaitForElement(By.XPath("//span[@test-id='scheduling-spn-editProvider']"), 60);
            }
            catch(NoSuchElementException ex)
            {
                tmsWait.Hard(2);
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//ul[contains(@class,'k-treeview-lines')]//li[1]//span[contains(@class,'k-i-expand')])[1]")));
                tmsWait.Hard(2);
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//ul[contains(@class,'k-treeview-lines')]//li[1]//span[contains(@class,'k-i-expand')])[1]")));
                tmsWait.Hard(2);
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//li[@aria-level='3'])[1]//span")));

                
            }

            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//ul[@class='k-group k-treeview-lines']//li[1]//span[@class='k-icon k-i-expand'])[1]")));
            //tmsWait.Hard(4);
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//ul[@class='k-group']//li[1]//span[contains(., 'Member')])[1]")));
            //tmsWait.WaitForElement(By.XPath("//span[@test-id='scheduling-spn-editProvider']"), 60);
        }



        [When(@"Scheduling Summary page Edit link is clicked")]
        [Then(@"Scheduling Summary page Edit link is clicked")]
        public void WhenSchedulingSummaryPageEditLinkIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(RAM.RAMScheduling.EditProviderLink);
           
            tmsWait.WaitForElement(By.CssSelector("[test-id='addProject-txt-providerPhone']"));
            ScenarioContext.Current["city"] = RAM.RAMScheduling.CityTextbox.Text;
            
        }
        [When(@"Verify Scheduling Summary page ""(.*)"" is updated as ""(.*)""")]
        [Then(@"Verify Scheduling Summary page ""(.*)"" is updated as ""(.*)""")]
        public void ThenVerifySchedulingSummaryPageIsUpdatedAs(string field, string expectedvalue)
        {
            string xvalue = tmsCommon.GenerateData(expectedvalue);
            switch (field.ToUpper())
            {

                case "FAX":
                    IWebElement actualvaluefax = Browser.Wd.FindElement(By.XPath("//span[@test-id='scheduling-txt-providerFax']"));
                    Assert.AreEqual(actualvaluefax.Text, xvalue, "Value is not updated");
                    break;

                case "PHONE":
                    IWebElement actualvaluephone = Browser.Wd.FindElement(By.XPath("//span[@test-id='scheduling-txt-providerPhone']"));
                    Assert.AreEqual(actualvaluephone.Text, xvalue, "Value is not updated");
                    break;
               

            }
            
        }

        //Gurdeep Arora
        [When(@"on Scheduling page Queue Status is selected as ""(.*)""")]
        public void WhenOnSchedulingPageQueueStatusIsSelectedAs(string option)
        {
            tmsWait.Hard(5);
            //SelectElement queueStatusDD = new SelectElement(RAM.RAMScheduling.QueueStatusDropdown);
            //queueStatusDD.SelectByText(option);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='scheduling-select-QueueStatus']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + option + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }

        //[Then(@"Verify Provider Information page ""(.*)"" is displayed as ""(.*)""")]
        //public void ThenVerifyProviderInformationPageIsDisplayedAs(string p0, string expectedvalue)
        //{
        //    IWebElement actualvaluephone = Browser.Wd.FindElement(By.XPath("//span[@test-id='scheduling-txt-providerPhone']"));
        //    Assert.AreEqual(actualvaluephone.Text, expectedvalue, "Value is not updated");
        //}


        [When(@"Provider Information page City is entered as ""(.*)""")]
        [Then(@"Provider Information page City is entered as ""(.*)""")]
        public void WhenProviderInformationPageCityIsEnteredAs(string city)
        {
            tmsWait.Hard(2);
            string excity = tmsCommon.GenerateData(city);
            RAM.RAMScheduling.CityTextbox.Clear();
            RAM.RAMScheduling.CityTextbox.SendKeys(excity);
        }

        [When(@"Provider Information page State is selected as ""(.*)""")]
        [Then(@"Provider Information page State is selected as ""(.*)""")]
        public void WhenProviderInformationPageStateIsSelectedAs(string state)
        {
            tmsWait.Hard(2);
            //SelectElement stateDD = new SelectElement(RAM.RAMScheduling.ProviderStateDropdown);
            //ScenarioContext.Current["StateValue"] = stateDD.SelectedOption.Text;
            IWebElement stateDD = Browser.Wd.FindElement(By.XPath("(//label[text()='State']/parent::div//span[@class='k-input'])"));
            ScenarioContext.Current["StateValue"] = stateDD.Text;
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='scheduling-select-providerState']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + state + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

            tmsWait.Hard(3);
            tmsWait.Hard(2);
            
        }

        [When(@"Provider Information page Fax is entered as ""(.*)""")]
        [Then(@"Provider Information page Fax is entered as ""(.*)""")]
        public void WhenProviderInformationPageFaxIsEnteredAs(string fax)
        {
            string fax1 = tmsCommon.GenerateData(fax);
            tmsWait.Hard(3);
            try
            {
            RAM.RAMScheduling.FaxText.Clear();
            RAM.RAMScheduling.FaxText.SendKeys(fax1);
            }

            catch
            {
                fw.ConsoleReport("FAX field is disabled so user is unable to enter value");
            }
        }

        [When(@"Provider Information page Zip is entered as ""(.*)""")]
        [Then(@"Provider Information page Zip is entered as ""(.*)""")]
        public void WhenProviderInformationPageZipIsEnteredAs(string zip)
        {
            tmsWait.Hard(2);
            RAM.RAMScheduling.ZipTextbox.Clear();
            RAM.RAMScheduling.ZipTextbox.SendKeys(zip);
        }

        [When(@"Provider Information page Save button is clicked")]
        [Then(@"Provider Information page Save button is clicked")]
        public void WhenProviderInformationPageSaveButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.RAMScheduling.ProviderSaveButton);
            //tmsWait.WaitForElement(By.XPath("//span[@test-id='scheduling-spn-editProvider']"), 60);
            tmsWait.Hard(5);
        }
        [When(@"Provider Information page Save button is clicked And Verify Message ""(.*)""")]
        [Then(@"Provider Information page Save button is clicked And Verify Message ""(.*)""")]
        public void ThenProviderInformationPageSaveButtonIsClickedAndVerifyMessage(string p0)
        {try
            {

           
            tmsWait.Hard(3);
        
        fw.ExecuteJavascript(RAM.RAMScheduling.ProviderSaveButton);
           
            }catch(NoSuchElementException ex)
            {
                IList <IWebElement> r= Browser.Wd.FindElements((By.CssSelector("[test-id='scheduling-spn-editProvider']")));
                if (r.Count == 1)
                {
                    bool b = r.Count == 1;
                    Assert.IsTrue(b, "Message is not displayed successfully");
                }
                

            }
        }

        [When(@"Provider Information page Reset button is clicked")]
        public void WhenProviderInformationPageResetButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.RAMScheduling.ProviderResetButton);
            tmsWait.Hard(2);
        }

        [When(@"Verify reset functionality for Provider")]
        public void WhenVerifyResetFunctionalityForProvider()
        {
            tmsWait.Hard(2);
            //SelectElement stateDD = new SelectElement(RAM.RAMScheduling.ProviderStateDropdown);
            IWebElement ddele = Browser.Wd.FindElement(By.XPath("(//label[text()='State']/parent::div//span[@class='k-input'])"));
            string actual_value = ddele.Text;
            Assert.IsTrue(actual_value.Equals(ScenarioContext.Current["StateValue"].ToString()));
        }


        [When(@"Scheduling Summary page verify the Member information is displayed correctly")]
        public void WhenSchedulingSummaryPageVerifyTheMemberInformationIsDisplayedCorrectly()
        {
           
                //IWebElement test1 = Browser.Wd.FindElement(By.XPath("//span[@class='k-icon k-i-expand']"));
                //fw.ExecuteJavascript(test1);

                //Browser.Wd.FindElement(By.XPath("//span[@class='k-icon k-i-expand']")).Click();
                //fw.ExecuteJavascript(RAM.RAMScheduling.ProviderIDPlusIcon);
                //tmsWait.Hard(2);
                //fw.ExecuteJavascript(RAM.RAMScheduling.ProviderIDPlusIcon);
                //tmsWait.Hard(2);
                //fw.ExecuteJavascript(RAM.RAMScheduling.MemberIDInfo);
                //tmsWait.Hard(2);
                Assert.IsTrue(RAM.RAMScheduling.MemberIDInfo.Text.Contains(RAM.RAMScheduling.MemberIDText.Text));
                Assert.IsTrue(RAM.RAMScheduling.MemberIDInfo.Text.Contains(RAM.RAMScheduling.QueueText.Text));
                Assert.IsTrue(RAM.RAMScheduling.NameText.Displayed);
                Assert.IsTrue(RAM.RAMScheduling.PhoneText.Displayed);
                Assert.IsTrue(RAM.RAMScheduling.schedulingFaxText.Displayed);
                Assert.IsTrue(RAM.RAMScheduling.MemberNameText.Displayed);
                Assert.IsTrue(RAM.RAMScheduling.QueueStatusDropdown.Displayed);
                Assert.IsTrue(RAM.RAMScheduling.NoteTextArea.Displayed);
                
            
        }



        [When(@"Scheduling page Queue is selcted as ""(.*)""")]
        public void WhenSchedulingPageQueueIsSelctedAs(string option)
        {
            //SelectElement queueDD = new SelectElement(RAM.RAMScheduling.QueueDropdown);
            //queueDD.SelectByText(option);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='scheduling-select-queue']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + option + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }


        [When(@"Scheduling page Reset button is clicked")]
        public void WhenSchedulingPageResetButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.RAMScheduling.ResetButton);
            //SelectElement queueDD = new SelectElement(RAM.RAMScheduling.QueueDropdown);
            //Assert.IsTrue(queueDD.SelectedOption.Text.Equals("All"));
        }

        [Then(@"Scheduling page Queue drop down having value ""(.*)""")]
        public void ThenSchedulingPageQueueDropDownHavingValue(string p0)
        {
            IWebElement ddele = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='scheduling-select-queue']//span[@class='k-input']"));
            string actual_value = ddele.Text;
            Assert.IsTrue(actual_value.Contains(p0), "Value does not match");
        }


        [When(@"Maintain Project page Create New Project link is clicked")]
        public void WhenMaintainProjectPageCreateNewProjectLinkIsClicked()
        {
            tmsWait.Hard(9);
            RAM.RAMScheduling.CreateNewProjectLink.Click();
        }

        [When(@"Maintain Project page Poject Name is entered as ""(.*)""")]
        public void WhenMaintainProjectPagePojectNameIsEnteredAs(string prjName)
        {
            string prjName1 = tmsCommon.GenerateData(prjName);
            tmsWait.Hard(3);
           
            RAM.RAMScheduling.ProjectNameTextbox.SendKeys(prjName1);
        }

        [When(@"Maintain Project page ADD button is clicked")]
        public void WhenMaintainProjectPageADDButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.RAMScheduling.AddNewProjectButton);
            Assert.IsTrue(RAM.RAMScheduling.ProjectAddMessage.Displayed);
        }


        [When(@"Maintain Project page ADD button is clicked and Success message verified")]
        public void WhenMaintainProjectPageADDButtonIsClickedAndSuccessMessageVerified()
        {
            fw.ExecuteJavascript(RAM.RAMScheduling.AddNewProjectButton);
            tmsWait.Hard(1);
            By toastMsg = By.XPath("//div[@class='k-notification-content']");
            string actValue = Browser.Wd.FindElement(toastMsg).Text;
            Assert.IsTrue(actValue.Equals("Project added successfully"));
        }
        [When(@"Maintain Project page SEARCH button is clicked")]
        public void WhenMaintainProjectPageSEARCHButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.RAMScheduling.SearchProjectButton);
            tmsWait.Hard(30);
            //tmsWait.WaitForElementExist(By.XPath("//kendo-grid[@test-id='maintainProjects-label-grdSuspectAssignment']"),30);
            Assert.IsTrue(RAM.RAMScheduling.ProjectSearchResult.Displayed);
        }

        [When(@"Maintain Project page Payment Year selected as ""(.*)""")]
        public void WhenMaintainProjectPagePaymentYearSelectedAs(string year)
        {
            tmsWait.Hard(2);
            //paymentYear = new SelectElement(RAM.RAMScheduling.PaymentYearDropdown);
            //paymentYear.SelectByText(year);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='maintainProjects-select-paymentYear']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + year + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }

        [When(@"Maintain Project page Suspect Type selected as ""(.*)""")]
        public void WhenMaintainProjectPageSuspectTypeSelectedAs(string type)
        {
            tmsWait.Hard(2);
            //suspectType = new SelectElement(RAM.RAMScheduling.SuspectTypeDropdown);
            //suspectType.SelectByText(type);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='maintainProjects-select-suspectType']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + type + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }

        [When(@"Maintain Project page Priority selected as ""(.*)""")]
        public void WhenMaintainProjectPagePrioritySelectedAs(string priority)
        {
            tmsWait.Hard(2);
            //priorityDD = new SelectElement(RAM.RAMScheduling.PriorityDropdown);
            //priorityDD.SelectByText(priority);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='maintainProjects-select-priority']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + priority + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }

        [When(@"Maintain Project page Reset button is clicked")]
        public void WhenMaintainProjectPageResetButtonIsClicked()
        {
            tmsWait.Hard(2);
            RAM.RAMScheduling.ResetProjectButton.Click();
            //**To check default value of suspect status
            IWebElement ddele = Browser.Wd.FindElement(By.XPath("(//label[text()='Suspect Type']/parent::div//span[@class='k-input'])"));
            string suspectType = ddele.Text;
            Assert.IsTrue(suspectType.Equals("All"));

            //**To check default value of Payment year
            IWebElement ddele1 = Browser.Wd.FindElement(By.XPath("(//label[text()='Payment Year']/parent::div//span[@class='k-input'])"));
            string paymentYear = ddele.Text;
            Assert.IsTrue(paymentYear.Equals("All"));

            //**To check default value of Payment year
            IWebElement ddele2 = Browser.Wd.FindElement(By.XPath("(//label[text()='Priority']/parent::div//span[@class='k-input'])"));
            string priority = ddele.Text;
            Assert.IsTrue(priority.Equals("All"));
            //Assert.IsTrue(paymentYear.SelectedOption.Text.Equals("All"));
            //Assert.IsTrue(priorityDD.SelectedOption.Text.Equals("All"));
        }

    }
}
