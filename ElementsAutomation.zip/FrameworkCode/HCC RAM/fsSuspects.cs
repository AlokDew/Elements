﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
//using System.Windows.Forms;
using OpenQA.Selenium;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Support.UI;


namespace TMSoR1.FrameworkCode.HCC_RAM
{
    [Binding]
    class fsSuspects
    {
        [When(@"Verify that ""(.*)"" submenu is present in Suspects menu")]
        public void WhenVerifyThatSubmenuIsPresentInSuspectsMenu(string SubmenuItem)
        {
            tmsWait.Hard(5);
            if (SubmenuItem.Equals("Update PIR Provider"))
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Suspects']")));
                tmsWait.Hard(5);
            }
            else if (SubmenuItem.Equals("Update Provider Info"))
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Suspects']")));
                tmsWait.Hard(5);
            }


            else
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Main']")));
                tmsWait.Hard(5);
            }
            IWebElement menulink = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + SubmenuItem + "')]"));
            Assert.IsTrue(menulink.Displayed, SubmenuItem + " Link is not present");
        }

        [When(@"""(.*)"" submenu is selected from Suspects menu")]
        public void WhenSubmenuIsSelectedFromSuspectsMenu(string SubmenuItem)
        {
            tmsWait.Hard(2);
            IWebElement menulink = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + SubmenuItem + "')]"));
            fw.ExecuteJavascript(menulink);
        }
        [When(@"""(.*)"" lookup Search by ""(.*)"" dropdropdown is selected")]
        public void WhenLookupSearchByDropdropdownIsSelected(string lookupName, string valueTobeSelected)
        {
            try
            {
                tmsWait.Hard(3);
                By Drp = By.XPath("//label[contains(.,'Search By')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + lookupName + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                tmsWait.Hard(3);

            }
            catch
            {

            }
            //this is to collapse the dropdown again
            //lookup.searchByValue.Click();
        }
        //public dynamic SetLookupName(string lookupname)
        //{
        //    var lookup = RAMMainLookup.Lookup;
        //    switch (lookupname.ToUpper().Trim())
        //    {
        //        case "MEMBER ID": lookup = RAMMainLookup.Lookup; break;
        //        case "PROVIDER ID": break;

        //        default: Console.WriteLine(lookupname + " lookup is not handled"); break;
        //    }
        //    return lookup;
        //}

        [When(@"""(.*)"" lookup icon is clicked")]
        public void WhenLookupIconIsClicked(string lookupName)
        {
            switch (lookupName.ToUpper().Trim())
            {
                case "MEMBER ID":
                    fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.MemberIDLookup);
                    tmsWait.WaitForElement(By.XPath("//label[@test-id='searchMember-lbl-MemberID']"), 60);
                    break;
                case "PROVIDER ID": fw.ExecuteJavascript(Suspects.UpdateProviderInfo.ProviderIDLookup); break;

                default: Console.WriteLine(lookupName + " lookup is not handled"); break;
            }


        }

        [When(@"""(.*)"" lookup title should be ""(.*)""")]
        public void WhenLookupTitleShouldBe(string lookupName, string lookupTitle)
        {
            tmsWait.Hard(3);
            string lookupTitleWebpage = "";

            lookupTitleWebpage = RAMMainLookup.Lookup.lookupTitle.Text;
            Assert.IsTrue(lookupTitleWebpage.Trim().Equals(lookupTitle.Trim()), lookupTitle + " title should be displayed");
        }

        [When(@"Verify ""(.*)"" lookup label name is displayed as ""(.*)"" if Search By ""(.*)""")]
        public void WhenVerifyLookupLabelNameIsDisplayedAsIfSearchBy(string lookupName, string ReflectedLabelName, string SearchBy)
        {

            string ActualValueSearchBy = "";
            string SearchBydropdownUI = "";
            string membersearchlabelUI = "";




            IWebElement ele = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Provider')]"));
            UIMODUtilFunctions.elementPresenceUsingWebElement(ele);




            //checking wether the textbox label is displayed correctly(SEARCH By) common for all lookups 
            //ActualValueSearchBy = RAMMainLookup.Lookup.searchBylabel.Text;
            // Assert.IsTrue(ActualValueSearchBy.Contains("Search By"), " search by textbox label is displayed as  " + ActualValueSearchBy);

            ////Second textbox label changes with the value selected in SearchBy dropdown, reading the value selected in SearchBy dropdown
            //SearchBydropdownUI = RAMMainLookup.Lookup.searchByValue.Text;
            //Assert.IsTrue(SearchBydropdownUI.Trim().Equals(SearchBy.Trim()), "Search By filter criteria is wrongly selected as " + SearchBydropdownUI);

            ////checking the label displayed for another textbox according to selection in Search By textbox
            //membersearchlabelUI = RAMMainLookup.Lookup.searchbylabel.Text;
            //Assert.IsTrue(membersearchlabelUI.Trim().Equals(ReflectedLabelName.Trim()), "Member search textbox label is wrongly displayed as "+ membersearchlabelUI+"whereas should be displayed as"+ ReflectedLabelName);

        }

        [When(@"Verify ""(.*)"" lookup grid displayed with column header as ""(.*)""")]
        public void WhenVerifyLookupGridDisplayedWithColumnHeaderAs(string p0, string columnHeader)
        {
            char[] delim = { ',' };
            string[] columns = columnHeader.Split(delim);


            foreach (string column in columns)
            {
                IWebElement headerName = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='provider-grid-searchbytxt']//th[contains(.,'" + column + "')]"));
                Assert.IsTrue(headerName.Displayed, headerName + " is not displayed");
            }
        }


        [When(@"Verify ""(.*)"" lookup grid displayed with column hearder as ""(.*)""")]
        public void WhenVerifyLookupGridDisplayedWithColumnHearderAs(string lookName, string columnHeader)
        {
            char[] delim = { ',' };
            string[] columns = columnHeader.Split(delim);


            foreach (string column in columns)
            {
                IWebElement headerName = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='lookup-grid-providerLookup']//th[contains(.,'" + column + "')]"));
                Assert.IsTrue(headerName.Displayed, headerName + " is not displayed");
            }
        }

        [When(@"Update Provider Info Result page displayed with Fields as ""(.*)""")]
        public void WhenUpdateProviderInfoResultPageDisplayedWithFieldsAs(string FieldNames)
        {
            tmsWait.Hard(2);
            char[] delim = { ',' };
            string[] fieldNames = FieldNames.Split(delim);


            foreach (string Field in fieldNames)
            {
                IWebElement field = Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + Field + "')]"));

                Assert.IsTrue(field.Displayed, field.Text + " is not displayed");

            }
        }

        public string getFieldValue(string fieldName)
        {
            fsRSMLogin queryObj = new fsRSMLogin();
            string value = "";
            string queryString = "";


            queryString = "select m.txtFirst, m.txtLast, m.txtMemberid, m.dteDOB,m.txtgroupid,(p.txtFirst + p.txtLast) as txtFacilityName  ,m.bntMemberID from tbmember m join tbprovider p on m.txtPCPId = p.txtProviderID  where txtmemberid = '" + tmsCommon.GenerateData("Generate|variable|MemberID") + "'";
            Dictionary<int, String[]> rowvalue = new Dictionary<int, String[]>();
            rowvalue = queryObj.ExecuteSingleQuery(queryString, "TMSRAM", 7);
            string[] values = rowvalue[0];
            switch (fieldName.Trim())
            {
                case "First Name:":
                    value = values[0];
                    break;
                case "Last Name:":
                    value = values[1];
                    break;
                case "Member ID:":
                    value = values[2];
                    break;
                case "Date of Birth:":
                    DateTime DOB;
                    bool cov = DateTime.TryParse(values[3], out DOB);
                    value = DOB.ToString("M/d/yyyy");
                    break;
                case "Group ID:":
                    value = values[4];
                    break;
                case "PCP Name:":
                    value = values[5].Replace(" ", string.Empty);
                    break;
                case "Internal Member ID:":
                    value = values[6];
                    break;
            }

            return value.Trim();

        }

        public void validateError(IWebElement webObject, string errorMessage)
        {

            // for special char
            webObject.SendKeys("@#$!");
            webObject.SendKeys(OpenQA.Selenium.Keys.Tab);
            string xpath = ".//span[contains(.,'" + errorMessage + "')]";
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath(xpath)).Displayed, "Special Character are entered and " + errorMessage + "is not displayed on Tab out");
            webObject.Clear();
        }

        public void DatefieldValidation(IWebElement webObject, string errorMessage)
        {
            string[] invalidinput = { "!@#$" };

            foreach (string input in invalidinput)
            {
                webObject.SendKeys(input);
                webObject.SendKeys(OpenQA.Selenium.Keys.Tab);
                tmsWait.Hard(1);
                string xpath = ".//span[contains(.,'" + errorMessage + "')]";
                Assert.IsTrue(Browser.Wd.FindElement(By.XPath(xpath)).Displayed, "Special Character are entered and " + errorMessage + "is not displayed on Tab out");
                webObject.Clear();
            }
            // for special char

        }

        [Then(@"Validate for Date Field ""(.*)"" display error message ""(.*)""")]
        [When(@"Validate for Date Field ""(.*)"" display error message ""(.*)""")]
        public void WhenValidateForDateFieldDisplayErrorMessage(string fieldname, string errorMsg)
        {
            if (fieldname.Equals("Start Date")) DatefieldValidation(Suspects.EnterNewDiagnosisCode.StartDateTxtbox, errorMsg);
            if (fieldname.Equals("End Date")) DatefieldValidation(Suspects.EnterNewDiagnosisCode.EnddateTxtbox, errorMsg);
        }


        [When(@"Validate for special character input Add new Diagnosis data ""(.*)"" field display error message ""(.*)""")]
        public void WhenValidateForSpecialCharacterInputAddNewDiagnosisDataFieldDisplayErrorMessage(string Fieldname, string errorMessage)
        {
            IWebElement webObject = null;
            switch (Fieldname)
            {
                case "Diagnosis Code":
                    webObject = Suspects.EnterNewDiagnosisCode.DiagCodegrTextbox;
                    break;
                case "Provider ID":
                    webObject = Suspects.EnterNewDiagnosisCode.ProviderIDTextbox;
                    break;
                case "Claim Number":
                    webObject = Suspects.EnterNewDiagnosisCode.ClaimIDgrid;
                    break;
                case "Coder ID":
                    webObject = Suspects.EnterNewDiagnosisCode.ClaimIDgrid;
                    break;
                case "Encounter Date":
                    webObject = Suspects.EnterNewDiagnosisCode.ClaimIDgrid;
                    break;
            }
            validateError(webObject, errorMessage);
        }


        [When(@"Enter New Diagnosis Data Result page ""(.*)"" value")]
        public void WhenEnterNewDiagnosisDataResultPageValue(string fieldName)
        {


            tmsWait.Hard(4);
            var field = Suspects.EnterNewDiagnosisCode;
            string fieldvalue = "";

            switch (fieldName.Trim())
            {
                case "First Name:":
                    Assert.IsTrue(fieldName.Equals(field.ResultFirstname.Text), fieldName + " is wrongly displayed as " + field.ResultFirstname.Text);
                    fieldvalue = field.ResultFirstnameVal.Text;
                    break;
                case "Last Name:":
                    Assert.IsTrue(fieldName.Equals(field.ResultLastname.Text), fieldName + " is wrongly displayed as " + field.ResultLastname.Text);
                    fieldvalue = field.ResultLastnameVal.Text;
                    break;
                case "Member ID:":
                    Assert.IsTrue(fieldName.Equals(field.ResultMemberID.Text), fieldName + " is wrongly displayed as " + field.ResultMemberID.Text);
                    fieldvalue = field.ResultMemberIDVal.Text;
                    break;
                case "Date of Birth:":
                    Assert.IsTrue(fieldName.Equals(field.ResultDOB.Text), fieldName + " is wrongly displayed as " + field.ResultDOB.Text);
                    fieldvalue = field.ResultDOBVal.Text;
                    break;
                case "PCP Name:":
                    Assert.IsTrue(fieldName.Equals(field.ResultPCPname.Text), fieldName + " is wrongly displayed as " + field.ResultPCPname.Text);
                    fieldvalue = field.ResultPCPnameVal.Text.Replace(" ", string.Empty);
                    break;
                case "Internal Member ID:":
                    Assert.IsTrue(fieldName.Equals(field.ResultIntmemberID.Text), fieldName + " is wrongly displayed as " + field.ResultIntmemberID.Text);
                    fieldvalue = field.ResultIntmemberIDVal.Text;
                    break;
                case "Group ID:":
                    Assert.IsTrue(fieldName.Equals(field.ResultGroupID.Text), fieldName + " is wrongly displayed as " + field.ResultGroupID.Text);
                    fieldvalue = field.ResultGroupIDVal.Text;
                    break;


            }
            Assert.IsTrue(fieldvalue.Equals(getFieldValue(fieldName)), "value are not matching");
        }

        [When(@"Enter New Diagnosis Data Result page Add new Diagnosis code button is clicked")]
        public void WhenEnterNewDiagnosisDataResultPageAddNewDiagnosisCodeButtonIsClicked()
        {
            tmsWait.Hard(2);
            Assert.IsTrue(Suspects.EnterNewDiagnosisCode.addDiagnosisCodeBtn.Displayed, "Add New diagnosis code button is not displayed");
            Suspects.EnterNewDiagnosisCode.addDiagnosisCodeBtn.Click();
            tmsWait.Hard(1);
        }


        [When(@"Update PIR Provider result page Next button is clicked on pagination")]
        public void WhenUpdatePIRProviderResultPageNextButtonIsClickedOnPagination()
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(Suspects.UpdatePIRProviderInfo.NextButton);
            tmsWait.Hard(2);
            string ss = Suspects.UpdatePIRProviderInfo.CurrentPageNo.GetAttribute("aria-valuenow");
            Assert.IsTrue(ss.Equals("2"), "Page is not updated...Next button failed");
        }

        [When(@"Update PIR Provider result page Previous button is clicked on pagination")]
        public void WhenUpdatePIRProviderResultPagePreviousButtonIsClickedOnPagination()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Suspects.UpdatePIRProviderInfo.PreviousButton);
            tmsWait.Hard(2);
            Assert.IsTrue(Suspects.UpdatePIRProviderInfo.CurrentPageNo.GetAttribute("aria-valuenow").Equals("1"), "Page is not updated...Previous button failed");
        }

        [When(@"Update PIR Provider result page Last button is clicked on pagination")]
        public void WhenUpdatePIRProviderResultPageLastButtonIsClickedOnPagination()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Suspects.UpdatePIRProviderInfo.LastButton);
            tmsWait.Hard(2);
            Assert.IsTrue(Suspects.UpdatePIRProviderInfo.CurrentPageNo.GetAttribute("aria-valuenow").Equals((Suspects.UpdatePIRProviderInfo.LastPageNo.Text.Split(' '))[1]), "Page is not updated...Last button failed");
        }

        [When(@"Update PIR Provider result page First button is clicked on pagination")]
        public void WhenUpdatePIRProviderResultPageFirstButtonIsClickedOnPagination()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Suspects.UpdatePIRProviderInfo.FirstButton);
            tmsWait.Hard(2);
            Assert.IsTrue(Suspects.UpdatePIRProviderInfo.CurrentPageNo.GetAttribute("aria-valuenow").Equals("1"), "Page is not updated...First button failed");
        }


        [Then(@"Verify ""(.*)"" grid is displayed with column header as ""(.*)""")]
        [When(@"Verify ""(.*)"" grid is displayed with column header as ""(.*)""")]
        public void WhenVerifyGridIsDisplayedWithColumnHeaderAs(string gridName, string Columnhearder)
        {
            char[] delim = { ',' };
            string[] columns = Columnhearder.Split(delim);
            IWebElement table = null;
            if (gridName.Equals("Add new Diagnosis code")) table = Suspects.EnterNewDiagnosisCode.AddnewCodeGrid;
            if (gridName.Equals("View All Entries Result")) table = Suspects.EnterNewDiagnosisCode.ViewAllEntryMembergridheader;
            if (gridName.Equals("View All Entries Result codelist")) table = Suspects.EnterNewDiagnosisCode.ViewAllEntryCodegridheader;
            if (gridName.Equals("Update PIR Provider")) table = Suspects.UpdatePIRProviderInfo.resultGridHeader;
            Assert.IsTrue(table.Displayed, gridName + " grid is not displayed");

            IList<IWebElement> headerObj = table.FindElements(By.TagName("th"));
            List<string> headertxt = new List<string>();
            foreach (IWebElement field in headerObj)
            {
                headertxt.Add(field.Text.ToString());

            }
            foreach (string column in columns)
            {
                Assert.IsTrue(headertxt.Contains(column.Trim()), column + " is not displayed");
            }
        }


        [Then(@"""(.*)"" lookup ""(.*)"" is set as ""(.*)""")]
        [When(@"""(.*)"" lookup ""(.*)"" is set as ""(.*)""")]
        public void WhenLookupIsSetAs(string lookupName, string TextboxToSet, string ValueToset)
        {
            tmsWait.Hard(1);
            ValueToset = tmsCommon.GenerateData(ValueToset);

            RAMMainLookup.Lookup.searchbyValue.Clear();
            RAMMainLookup.Lookup.searchbyValue.SendKeys(ValueToset);
        }

        [Then(@"""(.*)"" lookup ""(.*)"" button is clicked")]
        [When(@"""(.*)"" lookup ""(.*)"" button is clicked")]
        public void WhenLookupButtonIsClicked(string lookupName, string Buttonname)
        {
            //tmsWait.Hard(1);
            //if (Buttonname.Equals("SEARCH"))
            //    if (RAMMainLookup.Lookup.LookupSearchBtn.Displayed)
            tmsWait.Hard(3);
            fw.ExecuteJavascript(RAMMainLookup.Lookup.LookupSearchBtn);
            //fw.ExecuteJavascript(RAMMainLookup.Lookup.LookupSearchBtn);
            tmsWait.Hard(16);
            //RAMMainLookup.Lookup.LookupSearchBtn.Click();
        }

        [When(@"Provider ID search result grid first record is selected")]
        public void WhenProviderIDSearchResultGridFirstRecordIsSelected()
        {
            tmsWait.Hard(20);

            tmsWait.WaitForElement(By.XPath("//kendo-grid[@test-id='provider-grid-searchbytxt']"), 80);

            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']//span")));
            tmsWait.Hard(5);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='provider-grid-searchbytxt']//tr/td)[2]")));

        }

        [When(@"Provider ID look up page back to record button is clicked")]
        public void WhenProviderIDLookUpPageBackToRecordButtonIsClicked()
        {
            fw.ExecuteJavascript(Suspects.UpdateProviderInfo.BackButton);
        }

        [When(@"""(.*)"" Provider lookup ""(.*)"" is selected")]
        public void WhenProviderLookupIsSelected(string p0, string pro)
        {
            string provider = tmsCommon.GenerateData(pro);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='provider-grid-searchbytxt']//tr[@role='row']/td[contains(.,'" + provider + "')]"));
            fw.ExecuteJavascript(ele);
            tmsWait.Hard(3);
            IWebElement back = Browser.Wd.FindElement(By.XPath("//span[@test-id='provider-span-back']/i"));
            fw.ExecuteJavascript(back);
            tmsWait.Hard(3);
        }

        [Then(@"Verify Update Provider Info  ""(.*)"" is set as ""(.*)""")]
        public void ThenVerifyUpdateProviderInfoIsSetAs(string p0, string p1)
        {
            tmsWait.Hard(3);
            string exp = tmsCommon.GenerateData(p1);
            string actual = Browser.Wd.FindElement(By.CssSelector("[test-id='provider-txt-add1']")).GetAttribute("value");

            Assert.AreEqual(exp, actual);

        }


        [Then(@"""(.*)"" lookup ""(.*)"" is selected")]
        [When(@"""(.*)"" lookup ""(.*)"" is selected")]
        public void WhenLookupIsSelected(string lookupName, string valueToSelect)
        {
            tmsWait.Hard(10);
            valueToSelect = tmsCommon.GenerateData(valueToSelect);
            IWebElement row = null;
            int i = 1;
            while (i < 5)
            {
                try
                {
                    row = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='lookup-grid-providerLookup']//tr[@role='row']/td[contains(.,'" + valueToSelect + "')]"));

                    Assert.IsTrue(row.Displayed, row.Text + " is not present at result grid");

                    break;

                }
                catch { }
                i++;
            }


            fw.ExecuteJavascript(row);
            fw.ExecuteJavascript(RAMMainLookup.Lookup.backToRecord);
        }

        [When(@"Verify Enter New Diagnosis Data selected ""(.*)"" is displayed")]
        public void WhenVerifyEnterNewDiagnosisDataSelectedIsDisplayed(string memberID)
        {
            tmsWait.Hard(2);
            memberID = tmsCommon.GenerateData(memberID);
            //IWebElement sau = Browser.Wd.FindElement(By.XPath(".//*[@id='txtMemberLookUpId']"));
            //string memberIDUI = sau.Text;
            string memberIDUI = Browser.Wd.FindElement(By.CssSelector("[test-id='searchDiag-txt-txtMemberId']")).GetAttribute("value");     //Suspects.EnterNewDiagnosisCode.MemberIDLookuptxtbox.GetAttribute("value");
            Assert.IsTrue(memberIDUI.Trim().Equals(memberID.Trim()), memberID + " is wrongly displayed as " + memberIDUI);
        }

        [When(@"Verify Update Provider Info success message after updating")]
        public void WhenVerifyUpdateProviderInfoSuccessMessageAfterUpdating()
        {
            IWebElement success = Browser.Wd.FindElement(By.XPath(".//div[@class='toast-message' and text() = 'Provider update successfully']"));
            Assert.IsTrue(success.Displayed, "Success message is not displayed for provider update");
        }


        [When(@"Enter New Diagnosis Data success message is displayed")]
        public void WhenEnterNewDiagnosisDataSuccessMessageIsDisplayed()
        {
            IWebElement success = Browser.Wd.FindElement(By.XPath(".//div[@class='toast-message' and text() = 'New diagnosis record(s) added successfully.']"));
            Assert.IsTrue(success.Displayed, "Success message is not displayed for provider update");
        }

        [Then(@"verify Enter New Diagnosis Data Member ID is set as ""(.*)""")]
        [When(@"verify Enter New Diagnosis Data Member ID is set as ""(.*)""")]
        public void WhenVerifyEnterNewDiagnosisDataMemberIDIsSetAs(string valueTocheck)
        {
            if (valueTocheck.Trim().Equals("blank")) if (Suspects.EnterNewDiagnosisCode.MemberIDLookuptxtbox.GetAttribute("value") == "")
                    Console.WriteLine("Textbox has been reset");
        }

        [When(@"Update Provider Info Provider ID is set as ""(.*)""")]
        public void WhenUpdateProviderInfoProviderIDIsSetAs(string valueToSet)
        {

            if (valueToSet.Trim().Equals("blank")) Suspects.UpdateProviderInfo.ProviderLookuptxtbox.Clear();
            else
            {
                Suspects.UpdateProviderInfo.ProviderLookuptxtbox.Clear();
                valueToSet = tmsCommon.GenerateData(valueToSet);
                Suspects.UpdateProviderInfo.ProviderLookuptxtbox.SendKeys(valueToSet);
            }
        }
        [When(@"Enter New Diagnosis Data Member ID is set as ""(.*)""")]
        public void WhenEnterNewDiagnosisDataMemberIDIsSetAs(string valueToSet)
        {
            string v = tmsCommon.GenerateData(valueToSet);
            if (v.Trim().Equals("blank")) Suspects.EnterNewDiagnosisCode.MemberIDLookuptxtbox.Clear();
            else
            {
                Suspects.EnterNewDiagnosisCode.MemberIDLookuptxtbox.Clear();
                valueToSet = tmsCommon.GenerateData(v);
                Suspects.EnterNewDiagnosisCode.MemberIDLookuptxtbox.SendKeys(v);
            }
        }


        [When(@"Update Provider Info error message should be displayed as ""(.*)""")]
        public void WhenUpdateProviderInfoErrorMessageShouldBeDisplayedAs(string message)
        {
            IWebElement error;
            if (message.Contains("providerid"))
            {

                message = message.Replace("providerid", tmsCommon.GenerateData("Generate|variable|ProviderIDNonexisting"));
                error = Browser.Wd.FindElement(By.XPath(".//div[@class='toast-message' and contains(., '" + message + "')]"));
            }
            else
            {
                error = Browser.Wd.FindElement(By.XPath(".//span[contains(.,'" + message + "')]"));
            }
            Assert.IsTrue(error.Displayed, "Error message is not displayed for provider update");
        }

        [When(@"Enter New Diagnosis Data error message should be displayed as ""(.*)""")]
        public void WhenEnterNewDiagnosisDataErrorMessageShouldBeDisplayedAs(string message)
        {
            tmsWait.Hard(5);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@class='toast-message' and contains(., '" + message + "')]")).Displayed);
        }
        [Then(@"Enter New Diagnosis Data exception message should be displayed as ""(.*)""")]
        [When(@"Enter New Diagnosis Data exception message should be displayed as ""(.*)""")]
        public void WhenEnterNewDiagnosisDataExceptionMessageShouldBeDisplayedAs(string error)
        {
            tmsWait.Hard(10);
            // Comment due to Toaster slowness
            // Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[@id='txtMemberId-error-msg']")).Text.Contains(error));

        }


        [When(@"Enter New Diagnosis Data error message toster should be displayed as ""(.*)""")]
        public void WhenEnterNewDiagnosisDataErrorMessageTosterShouldBeDisplayedAs(string message)
        {
            IWebElement error = null;
            error = Browser.Wd.FindElement(By.XPath(".//div[@class='toast-message' and contains(., '" + message + "')]"));

            Console.WriteLine(message + " is displayed");

        }

        [Then(@"Enter New Diagnosis Data records displayed successfully")]
        public void ThenEnterNewDiagnosisDataRecordsDisplayedSuccessfully()
        {
            tmsWait.Hard(5);
            Assert.IsTrue(Suspects.EnterNewDiagnosisCode.MemberListGrid.Displayed);
        }


        [When(@"Enter New Diagnosis Data records displayed successfully")]
        public void WhenEnterNewDiagnosisDataRecordsDisplayedSuccessfully()
        {
            tmsWait.Hard(5);
            Assert.IsTrue(Suspects.EnterNewDiagnosisCode.MemberListGrid.Displayed);
        }
        [Then(@"Diagnosis Data ""(.*)"" button is clicked and message displayed ""(.*)""")]
        [When(@"Diagnosis Data ""(.*)"" button is clicked and message displayed ""(.*)""")]
        public void WhenDiagnosisDataButtonIsClickedAndMessageDisplayed(string p0, string p1)
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.SearchButton);
            //tmsWait.Hard(1);
            // Comment toaster as scripts will fail due to slowness of message display
            //string actualvalue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
            //string expectedvalue = p1.ToString();
            //bool msg = expectedvalue.Contains(actualvalue);
            //Assert.IsTrue(msg, "Message is not displayed successfully");
        }

        [When(@"Enter New Diagnosis Data ""(.*)"" button is clicked")]
        [Then(@"Enter New Diagnosis Data ""(.*)"" button is clicked")]
        public void WhenEnterNewDiagnosisDataButtonIsClicked(string btn)
        {
            //if (btn.ToUpper().Trim().Equals("SEARCH")) fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.SearchButton);
            //if (btn.ToUpper().Trim().Equals("RESET")) fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.ResetButton);
            switch (btn.ToUpper().Trim())
            {
                case "SEARCH":
                    tmsWait.Hard(2);
                    fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.SearchButton);
                    tmsWait.Hard(4);
                    break;
                case "RESET":
                    fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.ResetButton);

                    break;
            }
            // tmsWait.Hard(1);
        }


        [When(@"Enter New Diagnosis Data MemberId text box is set as ""(.*)""")]
        public void WhenEnterNewDiagnosisDataMemberIdTextBoxIsSetAs(string memberID)
        {
            memberID = tmsCommon.GenerateData(memberID);
            Suspects.EnterNewDiagnosisCode.MemberIDLookuptxtbox.SendKeys(memberID);
            tmsWait.Hard(2);
        }




        [When(@"verify Update Provider Info Provider ID is set as ""(.*)""")]
        public void WhenVerifyUpdateProviderInfoProviderIDIsSetAs(string valueTocheck)
        {
            if (valueTocheck.Trim().Equals("blank"))
                if (Suspects.UpdateProviderInfo.ProviderLookuptxtbox.Text.ToString() == "")
                    Console.WriteLine("Textbox has been reset");
        }


        [When(@"Verify Update Provider Info selected ""(.*)"" is displayed")]
        public void WhenVerifyUpdateProviderInfoSelectedIsDisplayed(string ProviderID)
        {
            ProviderID = tmsCommon.GenerateData(ProviderID);
            string providerIDUI = fw.ExecuteJavascriptReturnText(Suspects.UpdateProviderInfo.ProviderLookuptxtbox).ToString();
            //string providerIDUI = Suspects.UpdateProviderInfo.ProviderLookuptxtbox.Text;
            //Assert.IsTrue(providerIDUI.Trim().ToUpper().Equals(ProviderID.Trim().ToUpper()), ProviderID + " is wrongly displayed as " + providerIDUI);
        }
        [When(@"Update Provider Info ""(.*)"" button is clicked")]
        public void WhenUpdateProviderInfoButtonIsClicked(string btn)
        {

            if (btn.ToUpper().Trim().Equals("SEARCH")) fw.ExecuteJavascript(Suspects.UpdateProviderInfo.SearchButton);
            if (btn.ToUpper().Trim().Equals("RESET")) fw.ExecuteJavascript(Suspects.UpdateProviderInfo.ResetButton);
            if (btn.ToUpper().Trim().Equals("UPDATE")) fw.ExecuteJavascript(Suspects.UpdateProviderInfo.UpdateBtn);// to be updated
            tmsWait.Hard(5);
        }


        [When(@"Update Provider Info ""(.*)"" is enterd as ""(.*)""")]
        public void WhenUpdateProviderInfoIsEnterdAs(string Field, string fieldValue)
        {
            var fielD = (dynamic)null;
            fielD = Suspects.EnterNewDiagnosisCode;
            switch (Field)
            {
                case "Address1":
                    fielD.Address1.Clear();
                    fielD.Address1.SendKeys(fieldValue);
                    break;
                case "Address2":
                    fielD.Address2.Clear();
                    fielD.Address2.SendKeys(fieldValue);
                    break;
                case "City/Town":
                    fielD.City_Town.Clear();
                    fielD.City_Town.SendKeys(fieldValue);
                    break;
                case "Zip":
                    fielD.ZIP.Clear();
                    fielD.ZIP.SendKeys("0" + fieldValue);
                    break;
                case "Contact Name":
                    fielD.Contactname.Clear();
                    fielD.Contactname.SendKeys(fieldValue);
                    break;
                case "Telephone":
                    fielD.Telephone.Clear();
                    fielD.Telephone.SendKeys(fieldValue);
                    break;
                case "Fax":
                    fielD.Fax.Clear();
                    fielD.Fax.SendKeys(fieldValue);
                    break;
                case "State":
                    By xpath = By.XPath("//label[contains(.,'State')]/parent::div//span[@class='k-select']");
                    AngularFunction.selectDropDownValue(xpath, fieldValue);
                    break;
                default:
                    Console.WriteLine(Field + " is not handled");
                    break;
            }

        }

        [When(@"Enter New Diagnosis Data Result accordian ""(.*)"" is set as ""(.*)""")]
        public void WhenEnterNewDiagnosisDataResultAccordianIsSetAs(string FieldName, string ValueToSet)
        {
            ValueToSet = tmsCommon.GenerateData(ValueToSet);
            switch (FieldName)
            {
                case "Diagnosis Code":
                    Suspects.EnterNewDiagnosisCode.DiagCodegrTextbox.SendKeys(ValueToSet);
                    break;
                case "Encounter Date":
                    Suspects.EnterNewDiagnosisCode.EncounterDategrid.SendKeys(ValueToSet);
                    break;
                case "Claim number":
                    Suspects.EnterNewDiagnosisCode.ClaimIDgrid.SendKeys(ValueToSet);
                    break;
                case "Type of Service":

                    string xpath = "//li[text() = '" + ValueToSet + "']";
                    fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.TypeOfServicegrid);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(xpath)));
                    break;
                case "Coder ID":
                    Suspects.EnterNewDiagnosisCode.CoderIDgrid.SendKeys(ValueToSet);
                    break;
                case "Risk Assess Code":
                    xpath = "//li[text() = '" + ValueToSet + "']";
                    fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.RiskAssessmentgrid);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(xpath)));
                    break;
                case "Provider ID":
                    Suspects.EnterNewDiagnosisCode.ProviderIDTextbox.SendKeys(ValueToSet);
                    break;
            }
        }

        public bool CompareRowAtUIGrid(string expectedRow, IWebElement ObjTableToCompare)
        {
            char[] delim = { ',' };
            string[] ExpectedFieldnames = expectedRow.Split(delim);
            int numberOfFields = ExpectedFieldnames.Length;
            string[] ExpectedRowValues = null;
            List<int> skipPositions = new List<int>();
            int flag = 0;
            int pos = 0;

            List<string> valuelist = new List<string>();

            string dataappender = "Generate|variable|";
            foreach (string field in ExpectedFieldnames)
            {
                switch (field)
                {
                    case "Type of Service":
                        valuelist.Add(tmsCommon.GenerateData(dataappender + field).Substring(0, 2));
                        break;
                    case "Risk Assess Code":
                        valuelist.Add(tmsCommon.GenerateData(dataappender + field).Substring(0, 1));
                        break;
                    case "Skip":
                        skipPositions.Add(pos);
                        break;
                    case "CurrentDate":
                        valuelist.Add(DateTime.Now.ToString("MM/dd/yyyy"));
                        break;
                    default:
                        valuelist.Add(tmsCommon.GenerateData(dataappender + field));
                        break;
                }
                pos++;
            }

            ExpectedRowValues = valuelist.ToArray();
            string expectedrow = string.Join(" ", ExpectedRowValues);
            List<string> rowvalues = new List<string>();

            while (flag == 0)
            {
                IWebElement objWebTable = ObjTableToCompare;
                IList<IWebElement> ROWs = objWebTable.FindElements(By.TagName("tr"));

                foreach (IWebElement ROW in ROWs)
                {
                    string rowAtUI = "";
                    rowvalues.Clear();
                    IList<IWebElement> rowvaluesObj = ROW.FindElements(By.TagName("td"));
                    foreach (IWebElement rowobjj in rowvaluesObj)
                    {

                        rowvalues.Add(rowobjj.Text);
                    }
                    rowAtUI = string.Join(" ", rowvalues.ToArray());
                    if (expectedRow.Contains("Skip"))
                        rowAtUI = SkiValuefromrow(rowvalues, skipPositions);
                    if (rowAtUI.Equals(expectedrow))
                    {
                        flag = 1;
                        break;
                    }
                }
                //fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.NextPageBtn);
                //again object needs to be read and take the text repeat all steps

                if (flag == 1) { Console.WriteLine(expectedrow + " is found at UI grid"); return true; }
                if (flag == 0) { Console.WriteLine(expectedrow + " is not found at UI grid"); return false; }
            }

            return false;
        }
        public string SkiValuefromrow(List<string> result, List<int> skipPosition)
        {
            int i = 0;
            foreach (int position in skipPosition)
            {
                int skipPos = position;
                if (i > 0) skipPos = skipPos - i;
                result.RemoveAt(skipPos);
                i++;
            }
            string formatedrow = string.Join(" ", result.ToArray());

            return formatedrow;
        }
        [Then(@"Enter New Diagnosis Data Result accordian has row ""(.*)""")]
        public void ThenEnterNewDiagnosisDataResultAccordianHasRow(string expectedRow)
        {
            tmsWait.Hard(5);
            IWebElement objWebTable = Suspects.EnterNewDiagnosisCode.SavedCodetable;
            CompareRowAtUIGrid(expectedRow, objWebTable);
        }

        [Then(@"Update PIR Provider Result accordian does not has row ""(.*)""")]
        public void ThenUpdatePIRProviderResultAccordianDoesNotHasRow(string expectedRow)
        {
            tmsWait.Hard(15);
            IWebElement objWebTable = Suspects.UpdatePIRProviderInfo.updatePIRprovidermemberList;
            bool found = CompareRowAtUIGrid(expectedRow, objWebTable);
            Assert.IsFalse(found, expectedRow + " should not be present");
        }

        [Then(@"Update PIR Provider Result accordian has row ""(.*)""")]
        public void ThenUpdatePIRProviderResultAccordianHasRow(string expectedRow)
        {
            tmsWait.Hard(5);
            string value = tmsCommon.GenerateData(expectedRow);
            By loc = By.XPath("(//kendo-grid[@test-id='updatePirProvider-label-grdPrv']//td[contains(.,'" + value + "')])[1]");
            AngularFunction.elementPresenceUsingLocators(loc);
        }

        //[Then(@"Enter New Diagnosis Data Result accordian has row")]
        //public void ThenEnterNewDiagnosisDataResultAccordianHasRow(Table table)
        //{

        //    try
        //    {
        //        IWebElement objWebTable = Suspects.EnterNewDiagnosisCode.SavedCodetable;
        //        string text = objWebTable.Text;
        //        string[] stringSeparators = new string[] { "\r\n" };
        //        string[] rows = text.Split(stringSeparators, StringSplitOptions.None);

        //        String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
        //        for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
        //        {
        //            int index = 0;
        //            if (int.TryParse(arrRes[i, 0], out index))
        //            {
        //                if (index < 0)
        //                {
        //                    Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        Assert.Fail("Added new Diagnosis code Table has row: {0}", e.Message);
        //    }
        //}

        [When(@"Enter New Diagnosis Data Result accordian ""(.*)"" button is clicked")]
        public void WhenEnterNewDiagnosisDataResultAccordianButtonIsClicked(string button)
        {
            if (button.Equals("Save")) Suspects.EnterNewDiagnosisCode.SaveBtngrid.Click();
        }

        [When(@"Verify Enter New Diagnosis data ""(.*)"" link is present")]
        [Then(@"Verify Enter New Diagnosis data ""(.*)"" link is present")]
        public void ThenVerifyEnterNewDiagnosisDataLinkIsPresent(string linkname)
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.ViewAllEntriesLink);
        }

        [When(@"Verify Enter New Diagnosis data View All Entries link is present")]
        [When(@"Verify Enter New Diagnosis data View Existing Diag Entries link is present")]
        public void WhenVerifyEnterNewDiagnosisDataViewAllEntriesLinkIsPresent(string linkname)
        {
            tmsWait.Hard(2);
            ReUsableFunctions.clickOnWebElement(Suspects.EnterNewDiagnosisCode.ViewAllEntriesLink);
        }

        [When(@"RAM Enter New Diagnosis Data page View Existing Diagn Entries link is clicked")]
        [Then(@"Verify Enter New Diagnosis data View Existing Diag Entries link is clicked")]
        public void ThenVerifyEnterNewDiagnosisDataViewExistingDiagEntriesLinkIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.ViewAllEntriesLink);
        }


        [When(@"Enter New Diagnosis Data page Member ID search button is clicked")]
        public void WhenEnterNewDiagnosisDataPageMemberIDSearchButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.MemberIDLookup);
            tmsWait.Hard(1);
        }

        [When(@"Enter New Diagnosis Data lookup window memberid is set to ""(.*)""")]
        public void WhenEnterNewDiagnosisDataLookupWindowMemberidIsSetTo(string p0)
        {
            string mem = tmsCommon.GenerateData(p0);
            Suspects.EnterNewDiagnosisCode.MemberIDlookupWindowTextBox.SendKeys(mem);
        }


        [When(@"Member Lookup Search page SEARCH button is clicked")]
        public void WhenMemberLookupSearchPageSEARCHButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.LookupSearchBtn);
        }

        [When(@"Member Lookup Search page First Member ID is selected")]
        public void WhenMemberLookupSearchPageFirstMemberIDIsSelected()
        {
            //   tmsWait.WaitForElement(By.XPath("//td[@role='gridcell']/span"), 100);
            // fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//td[@role='gridcell']/span")));
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//button[contains(.,'ADD')])[1]")));
        }

        [When(@"Member Lookup Search page Second Member ID is selected")]
        public void WhenMemberLookupSearchPageSecondMemberIDIsSelected()
        {
            tmsWait.WaitForElement(By.XPath("//td[@role='gridcell']/span"), 100);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(".//*[@id='memberLookupGridOptions']//table//tr[2]//td//a")));
        }


        [When(@"Member Lookup Search page Back button is clicked")]
        public void WhenMemberLookupSearchPageBackButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.BackButton);
        }

        [When(@"Enter New Diagnosis Data page SEARCH button is clicked")]
        public void WhenEnterNewDiagnosisDataPageSEARCHButtonIsClicked()
        {
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.SearchMemberIDButton);
            tmsWait.Hard(2);
            tmsWait.WaitForElement(By.CssSelector("[test-id='searchMember-btn-addDiagnosisCode'"));
        }

        [When(@"Enter New Diagnosis Data page Add Diagnosis Data button is clicked")]
        public void WhenEnterNewDiagnosisDataPageAddDiagnosisDataButtonIsClicked()
        {
            tmsWait.WaitForElement(By.CssSelector("[test-id='searchMember-btn-addDiagnosisCode']"), 300);
            fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.addDiagnosisCodeBtn);
        }

        [When(@"Enter New Diagnosis Data page Diagnosis Code is entered as ""(.*)""")]
        public void WhenEnterNewDiagnosisDataPageDiagnosisCodeIsEnteredAs(string p0)
        {
            tmsWait.Hard(2);
            string code = tmsCommon.GenerateData(p0.ToString());
            Suspects.EnterNewDiagnosisCode.DiagCodegrTextbox.Clear();
            Suspects.EnterNewDiagnosisCode.DiagCodegrTextbox.SendKeys(code);
        }

        [When(@"Enter New Diagnosis Data page Encounter Date is entered as ""(.*)""")]
        public void WhenEnterNewDiagnosisDataPageEncounterDateIsEnteredAs(string p0)
        {
            string date = DateTime.Today.ToString("MM/dd/yyyy");
            //fw.ExecuteJavascriptSetText(Suspects.EnterNewDiagnosisCode.EncounterDategrid, date);
            // Suspects.EnterNewDiagnosisCode.EncounterFromDate.SendKeys(date);
            AngularFunction.enterDate(Suspects.EnterNewDiagnosisCode.EncounterFromDate, date);
        }

        [When(@"Enter New Diagnosis Data page Encounter From Date is entered as ""(.*)""")]
        public void WhenEnterNewDiagnosisDataPageEncounterFromDateIsEnteredAs(string p0)
        {
            //string date = DateTime.Today.ToString("MM/dd/yyyy");
            string fromDate = tmsCommon.GenerateData(p0);
            AngularFunction.enterDate(Suspects.EnterNewDiagnosisCode.EncounterFromDate, fromDate);
            tmsWait.Hard(3);
            //Suspects.EnterNewDiagnosisCode.EncounterFromDate.Clear();
            //Suspects.EnterNewDiagnosisCode.EncounterFromDate.SendKeys(fromDate);
        }

        [When(@"Create ""(.*)"" in correct Format from variable ""(.*)""")]
        public void WhenCreateInCorrectFormatFromVariable(string p0, string p1)
        {
            string fromDate = tmsCommon.GenerateData(p1);
            string[] fdate = fromDate.Split(' ');
            //string finalDate = fdate[0].Replace('-', '/');
            fw.setVariable(p0, fdate[0]);
        }


        [When(@"Calculate ""(.*)"" from ""(.*)""")]
        public void WhenCalculateFrom(string p0, string p1)
        {
            string fromDate = tmsCommon.GenerateData(p1);
            string[] fdate = fromDate.Split('/');
            int py = int.Parse(fdate[2]);
            int pyear = py + 1;
            fw.setVariable(p0, pyear.ToString());
        }


        [When(@"Enter New Diagnosis Data page Chart ID is entered as ""(.*)""")]
        public void WhenEnterNewDiagnosisDataPageChartIDIsEnteredAs(string p0)
        {
            tmsWait.Hard(4);
            string value = tmsCommon.GenerateData(p0);
            Suspects.EnterNewDiagnosisCode.chartID.Clear();
            Suspects.EnterNewDiagnosisCode.chartID.SendKeys(value);
            Suspects.EnterNewDiagnosisCode.chartID.SendKeys(OpenQA.Selenium.Keys.Tab);
        }


        [When(@"Enter New Diagnosis Data page Encounter To Date is entered as ""(.*)""")]
        public void WhenEnterNewDiagnosisDataPageEncounterToDateIsEnteredAs(string p0)
        {
            // string date = DateTime.Today.ToString("MM/dd/yyyy");
            tmsWait.Hard(2);
            string toDate = tmsCommon.GenerateData(p0);
            //Setting date to todays date 
            AngularFunction.enterTodayAsDate(Suspects.EnterNewDiagnosisCode.EncounterToDate);
            tmsWait.Hard(2);
            // Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@name='txtEncounterToDate']//span/input")).SendKeys("");
            AngularFunction.enterDate(Suspects.EnterNewDiagnosisCode.EncounterToDate, toDate);
            tmsWait.Hard(3);
            //Suspects.EnterNewDiagnosisCode.EncounterToDate.Clear();
            //Suspects.EnterNewDiagnosisCode.EncounterToDate.SendKeys(toDate);
        }

        [When(@"Enter New Diagnosis Data page Provider ID is set to ""(.*)""")]
        public void WhenEnterNewDiagnosisDataPageProviderIDIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@test-id='searchDiag-txt-txtProviderId']"));
            ele.SendKeys(value);
        }

        [When(@"Enter New Diagnosis Data page Claim Number is set to ""(.*)""")]
        public void WhenEnterNewDiagnosisDataPageClaimNumberIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@test-id='searchDiag-txt-txtPlanClaimId']"));
            ele.SendKeys(value);
        }



        [When(@"Enter New Diagnosis Data page Provider ID is entered as ""(.*)""")]
        public void WhenEnterNewDiagnosisDataPageProviderIDIsEnteredAs(string id)
        {
            fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.providerIDLookup);
            tmsWait.Hard(4);
            IWebElement memberId = Browser.Wd.FindElement(By.CssSelector("[test-id='searchProvider-txt-ProviderID']"));
            memberId.SendKeys("0");
            fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.LookupProviderSearchBtn);
            tmsWait.Hard(10);
            IReadOnlyCollection<IWebElement> allrows = Suspects.EnterNewDiagnosisCode.providerLookupGrid.FindElements(By.TagName("tr"));
            string memId = string.Empty;
            //int i = 0;
            foreach (var row in allrows)
            {

                memId = row.FindElement(By.XPath("td[1]")).Text;
                break;
            }


            tmsWait.Hard(3);
            ScenarioContext.Current["ProviderId"] = memId;

            fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.addButton);
            tmsWait.Hard(1);
            //Suspects.EnterNewDiagnosisCode.ProviderIDTextbox.Clear();
            //Suspects.EnterNewDiagnosisCode.ProviderIDTextbox.SendKeys(id);
        }


        [When(@"Get ""(.*)"" is set to ""(.*)""")]
        public void WhenGetIsSetTo(string p0, string p1)
        {
            string setproviderid = (ScenarioContext.Current["ProviderId"]).ToString();
            fw.setVariable(p0, setproviderid);
        }

        [When(@"""(.*)"" is set to ""(.*)""")]
        public void WhenIsSetTo(string p0, string p1)
        {
            string edate = tmsCommon.GenerateData(p1);
            string[] encounterd = edate.Split(' ');
            string final_edate = encounterd[0];
            fw.setVariable(p0, final_edate);
        }

        [When(@"""(.*)"" is set to Plus one of Encounterdate ""(.*)""")]
        public void WhenIsSetToPlusOneOfEncounterdate(string p0, string p1)
        {
            string paymentyear = tmsCommon.GenerateData(p0);
            string encounterDate = tmsCommon.GenerateData(p1);
            int year = Convert.ToInt32((encounterDate.Split('/'))[2]) + 1;
            string temp = year.ToString();
            fw.ConsoleReport(" Payment Year " + temp);
            fw.setVariable(paymentyear, temp);
        }




        [When(@"Enter New Diagnosis Data page Claim Number is entered as ""(.*)""")]
        public void WhenEnterNewDiagnosisDataPageClaimNumberIsEnteredAs(string id)
        {
            string claimnumber = tmsCommon.GenerateData(id);
            Suspects.EnterNewDiagnosisCode.ClaimIDgrid.Clear();
            Suspects.EnterNewDiagnosisCode.ClaimIDgrid.SendKeys(claimnumber);
        }

        [When(@"Enter New Diagnosis Data page Type of Service is selected as ""(.*)""")]
        public void WhenEnterNewDiagnosisDataPageTypeOfServiceIsSelectedAs(string type)
        {
            By typeofservice = By.XPath("//label[text()='Type of Service']/parent::div//span[@class='k-select']");
            AngularFunction.selectDropDownValue(typeofservice, type);
            ////fw.KendoSelectByValue(Browser.Wd, Suspects.EnterNewDiagnosisCode.TypeOfServicegrid, type);
            //// fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//ul[@id='ddlTypeofservice_listbox']//li[contains(.,'"+ type+"')]")));
            ////fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//select[@id='ddlTypeofservice']/option[@value='02']")));
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[text()='Type of Service']/parent::div//span[@class='k-select']")));
            ////SelectElement typeofservice = new SelectElement(Browser.Wd.FindElement(By.XPath(".//*[@test-id='searchDiag-txt-ddlTypeofservice']")));
            ////typeofservice.SelectByValue(type);
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//ul[@id='ddlTypeofservice_listbox']//li[contains(text(), '"+ type +"')]")));

        }

        [When(@"Enter New Diagnosis Data page Coder ID is entered as ""(.*)""")]
        public void WhenEnterNewDiagnosisDataPageCoderIDIsEnteredAs(string id)
        {
            string coder = tmsCommon.GenerateData(id);
            By loc = By.XPath("//label[contains(.,'Coder ID')]/parent::div//span[@class='k-select']");
            AngularFunction.selectDropDownValue(loc, coder);
            //Suspects.EnterNewDiagnosisCode.CoderIDgrid.Clear();
            //Suspects.EnterNewDiagnosisCode.CoderIDgrid.SendKeys(id);
            //SelectElement coderid = new SelectElement(Suspects.EnterNewDiagnosisCode.CoderIDgrid);
            //coderid.SelectByText(id);
            //// fw.KendoSelectByValue(Browser.Wd, Suspects.EnterNewDiagnosisCode.CoderIDgrid, id);
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//ul[@id='ddlCoderId_listbox']//li[1]")));

        }

        [When(@"Enter New Diagnosis Data page Risk Assess Code is selected as ""(.*)""")]
        public void WhenEnterNewDiagnosisDataPageRiskAssessCodeIsSelectedAs(string type)
        {
            string riskass = tmsCommon.GenerateData(type);
            By risk = By.XPath("//label[contains(.,'Risk Assessment Code')]/parent::div//span[@class='k-select']");
            AngularFunction.selectDropDownValue(risk, riskass);
            ////fw.KendoSelectByValue(Browser.Wd, Suspects.EnterNewDiagnosisCode.RiskAssessmentgrid, type);
            ////fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//ul[@id='ddlRiskAssessment_listbox']//li[contains(.,'" + type + "')]")));
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@aria-owns ='ddlRiskAssessment_listbox']")));
            ////SelectElement typeofservice = new SelectElement(Browser.Wd.FindElement(By.XPath(".//*[@test-id='searchDiag-txt-riskAssessment']")));
            ////typeofservice.SelectByValue(type);
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//ul[@id='ddlRiskAssessment_listbox']//li[contains(text(), '" + type + "')]")));
        }

        [When(@"Enter New Diagnosis Data page OnHold checkbox is checked")]
        public void WhenEnterNewDiagnosisDataPageOnHoldCheckboxIsChecked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.OnHoldCheckBox);
            tmsWait.Hard(1);
        }

        [When(@"Enter New Diagnosis Data Page OnHoldReason ""(.*)"" is selected")]
        public void WhenEnterNewDiagnosisDataPageOnHoldReasonIsSelected(string p0)
        {
            tmsWait.Hard(3);
            string reason = tmsCommon.GenerateData(p0);
            //fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.OnHoldReasonlistbox);
            //tmsWait.Hard(2);
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@id='ddlonHoldReason-list']//ul//li[contains(.,'" + reason + "')]")));
            //tmsWait.Hard(2);

            By Drp = By.XPath("//kendo-dropdownlist[@test-id='searchDiag-txt-ddlonHoldReason']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + reason + "']");

            UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

        }
        [Then(@"verify Manage Suspect page additional diag newly added inactive onhold reason ""(.*)"" is not present")]
        public void ThenVerifyManageSuspectPageAdditionalDiagNewlyAddedInactiveOnholdReasonIsNotPresent(string p0)
        {
            tmsWait.Hard(3);
            string reason = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.OnHoldReasonlistbox);
            tmsWait.Hard(2);
            IList<IWebElement> op = Browser.Wd.FindElements(By.XPath("//div[@id='ddlonHoldReason-list']//ul//li"));
            foreach (IWebElement p in op)
            {
                Console.WriteLine(p.Text);

                if (p.Text.Equals(p0))
                {
                    Assert.Fail();
                }
            }
        }


        [When(@"RAMX Enter New Diagnosis Data Page OnHoldReason ""(.*)"" is selected")]
        public void WhenRAMXEnterNewDiagnosisDataPageOnHoldReasonIsSelected(string p0)
        {
            ScenarioContext.Current.Pending();
        }

        [Then(@"Verify Enter New Diagnosis data page displayed Dignosis Code as ""(.*)""")]
        public void ThenVerifyEnterNewDiagnosisDataPageDisplayedDignosisCodeAs(string p0)
        {
            string code = tmsCommon.GenerateData(p0);
            By loc = By.XPath("//kendo-grid[@test-id='searchDiag-grid-member']//td[contains(.,'" + code + "')]");
            AngularFunction.elementPresenceUsingLocators(loc);
        }


        [Then(@"Enter New Diagnosis Data page newly added Diagnosis Code is saved")]
        [When(@"Enter New Diagnosis Data page newly added Diagnosis Code is saved")]
        public void WhenEnterNewDiagnosisDataPageNewlyAddedDiagnosisCodeIsSaved()
        {
            fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.SaveBtngrid);

        }
        [When(@"Enter New Diagnosis Data page newly added Diagnosis Code is saved and Success message ""(.*)"" varified")]
        [Then(@"Enter New Diagnosis Data page newly added Diagnosis Code is saved and Success message ""(.*)"" varified")]
        public void ThenEnterNewDiagnosisDataPageNewlyAddedDiagnosisCodeIsSavedAndSuccessMessageVarified(string p0)
        {
            bool flag = false;
            fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.SaveBtngrid);
            tmsWait.Hard(2);
            // commenting this statement as Toaster message is taking much time to display. will verify using workaround. will uncomment later
            //By toastMsg = By.XPath("//div[@class='toast-message']");
            //string actValue = Browser.Wd.FindElement(toastMsg).Text;
            //if (actValue.Contains(p0) || actValue.Contains("Record has been added."))
            //{
            //    flag = true;
            //}
            //Assert.IsTrue(flag, "Record not added");
        }


        [When(@"Verify Enter New Diagnosis Data page Code is saved successfully")]
        public void WhenVerifyEnterNewDiagnosisDataPageCodeIsSavedSuccessfully()
        {
            tmsWait.Hard(2);
            string code = tmsCommon.GenerateData("Generated|variable|Code");

            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[contains(@ng-bind,'diagCode') and contains(.,'" + code + "')]")).Displayed, "Newly added code is displayed");

            //  Assert.IsTrue(Browser.Wd.FindElement(By.ClassName("toast-message")).Text.Contains("New diagnosis record(s) added successfully"));
        }


        [When(@"EnterNewDiagnosisData MemberIdlookup icon is clicked")]
        public void WhenEnterNewDiagnosisDataMemberIdLookupIconIsClicked()
        {
            fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.MemberIDLookup);
        }


        [When(@"EnterNewDiagnosisData Memberlookup ""(.*)"" is set to ""(.*)""")]
        public void WhenEnterNewDiagnosisDataMemberlookupIsSetTo(string field, string p1)
        {
            string value = tmsCommon.GenerateData(p1);
            string dateValue = value.Replace("/", "");
            switch (field.ToLower())
            {
                case "memberid":
                    Browser.Wd.FindElement(By.XPath("//input[@test-id='searchMember-txt-MemberID']")).SendKeys(value);
                    break;
                case "firstname":
                    Browser.Wd.FindElement(By.XPath("//input[@test-id='searchMember-txt-FirstName']")).SendKeys(value);
                    break;
                case "lastname":
                    Browser.Wd.FindElement(By.XPath("//input[@test-id='searchMember-txt-LastName']")).SendKeys(value);
                    break;
                case "dob":
                    By startdate = By.XPath("//kendo-datepicker[@id='txtDateOfBirth']//span[@role='button']");
                    //AngularFunction.enterDate(startdate, dateValue);
                    AngularFunction.enterDate(startdate, value);
                    tmsWait.Hard(5);
                    break;
            }
        }



        [When(@"EnterNewDiagnosisData Memberlookup Search button is clicked")]
        public void WhenEnterNewDiagnosisDataMemberlookupSearchButtonIsClicked()
        {
            fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.LookupSearchBtn);
            tmsWait.Hard(3);
        }

        [Then(@"Verify EnterNewDiagnosisData Memberlookup result grid display data")]
        public void ThenVerifyEnterNewDiagnosisDataMemberlookupResultGridDisplayData()
        {
            tmsWait.Hard(10);

            IWebElement lookuptable = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='searchMember-grid-memberLookup']//tbody"));
            IReadOnlyCollection<IWebElement> allrows = lookuptable.FindElements(By.TagName("tr"));
            Boolean isdisplayedresult = false;
            int count = allrows.Count;
            if (allrows.Count > 0)
            {
                isdisplayedresult = true;
            }
            Assert.IsTrue(isdisplayedresult);
        }

        [Then(@"Verify EnterNewDiagnosisData Members ""(.*)"" is displayed as ""(.*)""")]
        public void ThenVerifyEnterNewDiagnosisDataMembersDOBIsDisplayedAs(string p0, string p1)
        {
            tmsWait.Hard(3);
            string value = tmsCommon.GenerateData(p1);
            switch (p0.ToLower())
            {

                case "memberid":
                    Assert.AreEqual(value, (Browser.Wd.FindElement(By.XPath("//input[@test-id='searchDiag-txt-txtMemberId']"))).GetAttribute("value"), "Member searched by filtering DOB is incorrect because actual DOB does not match with expected");
                    tmsWait.Hard(1);
                    break;

                case "firstname":
                    bool fname = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Member Name')]/parent::div/label[contains(.,'" + value + "')]")).Displayed;

                    Assert.IsTrue(fname, "FristName does not match with the expected one");
                    break;

                case "lastname":
                    bool lname = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Member Name')]/parent::div/label[contains(.,'" + value + "')]")).Displayed;

                    Assert.IsTrue(lname, "FristName does not match with the expected one");
                    break;

                case "dob":
                    //   string actDOB = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Date Of Birth')]/parent::div/label)[1]")).Text;
                    string actDOB = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Date Of Birth')]/parent::div/label[2]")).Text;
                    Assert.IsTrue(value.Contains(actDOB), "Member searched by filtering DOB is incorrect because actual DOB does not match with expected");
                    tmsWait.Hard(1);
                    break;

            }

        }

        [When(@"EnterNewDiagnosisData Memberlookup first result is selected")]
        public void WhenEnterNewDiagnosisDataMemberlookupFirstResultIsSelected()
        {
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[contains(.,'ADD')]")));
            tmsWait.Hard(1);
        }



        [Then(@"Verify View All Entries ""(.*)""  are displayed")]
        public void ThenVerifyViewAllEntriesAreDisplayed(string fields)
        {
            char[] delim = { ',' };
            IWebElement thisfield = null;
            string[] Fields = fields.Split(delim);
            foreach (string field in Fields)
            {
                switch (field.Trim().ToUpper())
                {
                    case "SEARCH":
                        thisfield = Suspects.EnterNewDiagnosisCode.ViewAllEntriesSearch;
                        tmsWait.Hard(5);
                        break;
                    case "RESET":
                        thisfield = Suspects.EnterNewDiagnosisCode.ViewAllEntriesRESET;
                        tmsWait.Hard(5);
                        break;
                    case "START DATE":
                        thisfield = Suspects.EnterNewDiagnosisCode.StartDateTxtbox;
                        tmsWait.Hard(5);
                        break;
                    case "END DATE":
                        thisfield = Suspects.EnterNewDiagnosisCode.EnddateTxtbox;
                        tmsWait.Hard(5);
                        break;
                    case "BACK":
                        thisfield = Suspects.EnterNewDiagnosisCode.ViewAllEntriesBack;
                        tmsWait.Hard(5);
                        break;

                    case "UNDO NEW DIAGNOSIS ENTRIES":
                        thisfield = Suspects.EnterNewDiagnosisCode.ViewAllEntriesTitle;
                        tmsWait.Hard(5);
                        break;

                        // Assert.IsTrue(Suspects.EnterNewDiagnosisCode.ViewAllEntriesTitle.Text.ToUpper().Equals(field.ToUpper()),"View All Entries page Title should be displayed as"+ field);
                        //break;
                }
                Assert.IsTrue(thisfield.Displayed, thisfield.Text + " is not displayed");
            }
        }

        [When(@"View All Entries ""(.*)"" is set as ""(.*)""")]
        [Then(@"View All Entries ""(.*)"" is set as ""(.*)""")]
        public void ThenViewAllEntriesIsSetAs(string fieldName, string ValueToSet)
        {
            tmsWait.Hard(10);
            ValueToSet = tmsCommon.GenerateData(ValueToSet);

            if (fieldName.ToUpper().Equals("START DATE"))

            {
                AngularFunction.enterDate(Suspects.EnterNewDiagnosisCode.StartDateTxtbox, ValueToSet);
            }

            //UIMODUtilFunctions.enterValueOnWebElementUsingLocators(eleStartdate, ValueToSet);

            //    fw.ExecuteJavascriptSetText(Suspects.EnterNewDiagnosisCode.StartDateTxtbox, ValueToSet);
            //Suspects.EnterNewDiagnosisCode.StartDateTxtbox.SendKeys(ValueToSet);

            if (fieldName.ToUpper().Equals("END DATE"))
            {

                AngularFunction.enterDate(Suspects.EnterNewDiagnosisCode.EnddateTxtbox, ValueToSet);
                // Suspects.EnterNewDiagnosisCode.EnddateTxtbox.SendKeys(ValueToSet);
                //  fw.ExecuteJavascriptSetText(Suspects.EnterNewDiagnosisCode.EnddateTxtbox, ValueToSet);
            }
        }
        [Then(@"Verify Enter New Diagnosis Data records displayed successfully")]
        public void ThenVerifyEnterNewDiagnosisDataRecordsDisplayedSuccessfully()
        {
            tmsWait.Hard(10);

            IWebElement lookuptable = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='searchMember-grid-member']//tbody"));
            IReadOnlyCollection<IWebElement> allrows = lookuptable.FindElements(By.TagName("tr"));
            Boolean isdisplayedresult = false;
            int count = allrows.Count;
            if (allrows.Count > 0)
            {
                isdisplayedresult = true;
            }
            Assert.IsTrue(isdisplayedresult);
        }

        [When(@"View All Entries SEARCH button is clicked")]
        [Then(@"View All Entries SEARCH button is clicked")]
        public void ThenViewAllEntriesSEARCHButtonIsClicked()
        {
            fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.ViewAllEntriesSearch);
            tmsWait.Hard(120);
        }
        [When(@"View All  SEARCH button is clicked and toster displayed as ""(.*)"" and recored varified")]
        public void WhenViewAllSEARCHButtonIsClickedAndTosterDisplayedAsAndRecoredVarified(string p0)
        {
            try
            {
                fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.ViewAllEntriesSearch);

                string expectedvalue = p0.ToString();
                string actualvalue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;

                Assert.IsTrue(actualvalue.Contains(expectedvalue), "Message is displayed successfully");
            }
            catch (NoSuchElementException ex)
            {
                tmsWait.Hard(6);
                Assert.IsTrue(Suspects.EnterNewDiagnosisCode.MemberListGrid.Displayed);
            }
        }

        [Then(@"Verify ""(.*)"" labes should be displayed with text as ""(.*)""")]
        public void ThenVerifyLabesShouldBeDisplayedWithTextAs(string GriDNAme, string message)
        {
            if (message.Contains("StartDate")) message = message.Replace("StartDate", tmsCommon.GenerateData("Generate|variable|Start Date"));
            if (message.Contains("EndDate")) message = message.Replace("EndDate", tmsCommon.GenerateData("Generate|variable|End Date"));
            if (message.Contains("MemberID")) message = message.Replace("MemberID", tmsCommon.GenerateData("Generate|variable|MemberID"));

            string xpath = "//label[contains(.,'" + message.Trim() + "')]";
            IWebElement labelObj = Browser.Wd.FindElement(By.XPath(xpath));
            Assert.IsTrue(labelObj.Displayed, message + " is not displayed");
        }
        [Then(@"View All entries has row ""(.*)""")]
        public void ThenViewAllEntriesHasRow(string expectedRow)
        {
            IWebElement objWebTable = Suspects.EnterNewDiagnosisCode.ViewAllEntryMemberList;
            CompareRowAtUIGrid(expectedRow, objWebTable);
        }


        [Then(@"Verify View All entries does not has row ""(.*)""")]
        public void ThenVerifyViewAllEntriesDoesNotHasRow(string expectedRow)
        {
            tmsWait.Hard(5);
            IWebElement objWebTable = Suspects.EnterNewDiagnosisCode.ViewAllEntriesCodeList;
            bool result = CompareRowAtUIGrid(expectedRow, objWebTable);
            Assert.IsFalse(result, "Row is not deleted and still exist");
        }

        [Then(@"View All entries select ""(.*)"" corresponding to first row is selected")]
        public void ThenViewAllEntriesSelectCorrespondingToFirstRowIsSelected(string p0)
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='searchMember-grid-member']//td/a)[1]")));
        }

        [Then(@"View All entries select ""(.*)"" corresponding to first row is deleted")]
        public void ThenViewAllEntriesSelectCorrespondingToFirstRowIsDeleted(string p0)
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='searchMember-grid-diag']//td/a)[1]")));
        }



        [Then(@"View All entries select ""(.*)"" corresponding to  ""(.*)"" is selected")]
        public void ThenViewAllEntriesSelectCorrespondingToIsSelected(string columnToSelect, string expectedRow)
        {
            IWebElement objWebTable = null;
            if (columnToSelect.ToUpper().Trim().Equals("DETAILS")) objWebTable = Suspects.EnterNewDiagnosisCode.ViewAllEntryMemberList;
            if (columnToSelect.ToUpper().Trim().Equals("DELETE")) objWebTable = Suspects.EnterNewDiagnosisCode.ViewAllEntriesCodeList;
            bool result = selectFieldFromGrid(columnToSelect, expectedRow, objWebTable);
            Assert.IsTrue(result, "row not found");

        }
        public bool selectFieldFromGrid(string FieldtoSelct, string rowToSelctFrom, IWebElement objWebTable)
        {
            char[] delim = { ',' };
            string[] ExpectedFieldnames = rowToSelctFrom.Split(delim);
            int numberOfFields = ExpectedFieldnames.Length;
            string[] ExpectedRowValues = null;
            List<int> skipPositions = new List<int>();
            int flag = 0;
            int pos = 0;

            List<string> valuelist = new List<string>();

            string dataappender = "Generate|variable|";
            foreach (string field in ExpectedFieldnames)
            {
                switch (field)
                {
                    case "Type of Service":
                        valuelist.Add(tmsCommon.GenerateData(dataappender + field).Substring(0, 2));
                        break;
                    case "Risk Assess Code":
                        valuelist.Add(tmsCommon.GenerateData(dataappender + field).Substring(0, 1));
                        break;
                    case "Skip":
                        skipPositions.Add(pos);
                        break;
                    case "CurrentDate":
                        valuelist.Add(DateTime.Now.ToString("MM/dd/yyyy"));
                        break;
                    default:
                        valuelist.Add(tmsCommon.GenerateData(dataappender + field));
                        break;
                }
                pos++;
            }

            ExpectedRowValues = valuelist.ToArray();
            string expectedrow = string.Join(" ", ExpectedRowValues);
            List<string> rowvalues = new List<string>();


            while (flag == 0)
            {
                IList<IWebElement> ROWs = objWebTable.FindElements(By.TagName("tr"));

                foreach (IWebElement ROW in ROWs)
                {
                    string rowAtUI = "";
                    rowvalues.Clear();
                    IList<IWebElement> rowvaluesObj = ROW.FindElements(By.TagName("td"));
                    foreach (IWebElement rowobjj in rowvaluesObj)
                    {

                        rowvalues.Add(rowobjj.Text);
                    }

                    rowAtUI = string.Join(" ", rowvalues.ToArray());
                    if (rowToSelctFrom.Contains("Skip"))
                        rowAtUI = SkiValuefromrow(rowvalues, skipPositions);
                    if (rowAtUI.Equals(expectedrow))
                    {
                        flag = 1;

                        if (FieldtoSelct.Equals("Details")) try { fw.ExecuteJavascript(rowvaluesObj[6].FindElement(By.TagName("a"))); } catch { }
                        if (FieldtoSelct.Equals("Delete")) try { fw.ExecuteJavascript(rowvaluesObj[6].FindElement(By.XPath(".//i[contains(@class,'icon-delete')]"))); } catch { }
                        if (FieldtoSelct.Equals("Select")) try { fw.ExecuteJavascript(rowvaluesObj[0].FindElement(By.TagName("input"))); } catch { }

                        break;
                    }
                }
                //fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.NextPageBtn);
            }
            Console.WriteLine(expectedrow + " is found at UI grid");
            if (flag == 1) return true;
            return false;
        }


        [Then(@"Verify that View All entries Delete Confirmation pop up is displayed")]
        public void ThenVerifyThatViewAllEntriesDeleteConfirmationPopUpIsDisplayed()
        {
            tmsWait.Hard(5);
            Assert.IsTrue(Suspects.EnterNewDiagnosisCode.DeleteConfirmationPopup.Displayed, "Delete Confirmation Pop-up is not displayed");
            Assert.IsTrue(Suspects.EnterNewDiagnosisCode.DleConfirmTitle.Displayed, "Delete Confirmation Title is not displayed as 'Confirmation'");
            Assert.IsTrue(Suspects.EnterNewDiagnosisCode.DeleteConfirmMsg.Displayed, "Delete Confirmation message is not displayed as 'Are you sure you want to delete this record ?'");
            Assert.IsTrue(Suspects.EnterNewDiagnosisCode.DeleteOKBtn.Displayed, "Delete Confirmation OK button is not displayed");
            Assert.IsTrue(Suspects.EnterNewDiagnosisCode.DeleteCancelBtn.Displayed, "Delete Confirmation CANCEL button is not displayed");
        }

        [Then(@"View All entries Delete Confirmation ""(.*)"" button is clicked")]
        public void ThenViewAllEntriesDeleteConfirmationButtonIsClicked(string Btn)
        {
            fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.DeleteOKBtn);
        }

        [When(@"Verify CMS Extract Page ""(.*)"" is displayed")]
        public void WhenVerifyCMSExtractPageIsDisplayed(string p0)
        {
            string field = tmsCommon.GenerateData(p0);
            switch (field.ToLower())
            {
                case "plan id":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='PlanId']//span[@class='k-select']")).Displayed);
                    tmsWait.Hard(5);
                    break;

                case "file type":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='FileType']//span[@class='k-select']")).Displayed);
                    By Drp = By.XPath("//kendo-dropdownlist[@test-id='FileType']//span[@class='k-select']");
                    fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                    tmsWait.Hard(5);
                    break;

                case "reset":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//button[contains(.,'RESET')]")).Displayed);
                    tmsWait.Hard(5);
                    break;

                case "export":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//button[contains(.,'EXPORT')]")).Displayed);
                    tmsWait.Hard(5);
                    break;
            }

        }


        [When(@"Verify RAM Scheduling ""(.*)"" is displayed")]
        public void WhenVerifyRAMSchedulingIsDisplayed(string p0)
        {
            string field = tmsCommon.GenerateData(p0);
            switch (field.ToLower())
            {
                case "scheduling title page":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//div[contains(.,'Scheduling')])[4]")).Displayed);
                    tmsWait.Hard(5);
                    break;
                case "project":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@id='projects']//span[@class='k-select']")).Displayed);
                    tmsWait.Hard(5);
                    break;
                case "provider":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@id='providers']//span[@class='k-select']")).Displayed);
                    tmsWait.Hard(5);
                    break;
                case "queue":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@id='queue']//span[@class='k-select']")).Displayed);
                    tmsWait.Hard(5);
                    break;
                case "member id":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Member ID')]")).Displayed);
                    tmsWait.Hard(5);
                    break;
                case "member name":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Member Name')]")).Displayed);
                    tmsWait.Hard(5);
                    break;
                case "queueg":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Queue')])[2]")).Displayed);
                    tmsWait.Hard(5);
                    break;
                case "queue Status":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Queue Status')]")).Displayed);
                    tmsWait.Hard(5);
                    break;
                case "date":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Date')]")).Displayed);
                    tmsWait.Hard(5);
                    break;
                case "coder":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Coder')]")).Displayed);
                    tmsWait.Hard(5);
                    break;
                case "note":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Note')]")).Displayed);
                    tmsWait.Hard(5);
                    break;

                case "Name":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Name')])[1]")).Displayed);
                    tmsWait.Hard(5);
                    break;
                case "Phone":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Phone')]")).Displayed);
                    tmsWait.Hard(5);
                    break;
                case "Fax":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Fax')]")).Displayed);
                    tmsWait.Hard(5);
                    break;
            }

        }



        [Then(@"Verify Enter New Diagnosis Data page ""(.*)"" is displayed")]
        public void ThenVerifyEnterNewDiagnosisDataPageIsDisplayed(string p0)
        {
            string field = tmsCommon.GenerateData(p0);
            switch (field.ToLower())
            {
                case "enter new diagnosis data title": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//div[contains(.,'Enter New Diagnosis Data')])[1]")).Displayed); break;
                case "member id lookup icon": Assert.IsTrue(Suspects.EnterNewDiagnosisCode.MemberIDLookup.Displayed); break;
                case "search button": Assert.IsTrue(Suspects.EnterNewDiagnosisCode.SearchButton.Displayed); break;
                case "reset button": Assert.IsTrue(Suspects.EnterNewDiagnosisCode.ResetButton.Displayed); break;
                case "view existing diag enteries": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//button[contains(.,'VIEW EXISTING DIAG ENTRIES')]")).Displayed); break;
                case "diagnosis Code text box": Assert.IsTrue(Suspects.EnterNewDiagnosisCode.DiagCodegrTextbox.Displayed); break;
                case "encounter from date text box": Assert.IsTrue(Suspects.EnterNewDiagnosisCode.EncounterFromDate.Displayed); break;
                case "encounter to date text box": Assert.IsTrue(Suspects.EnterNewDiagnosisCode.EncounterToDate.Displayed); break;
                case "type of service": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='searchDiag-txt-ddlTypeofservice']//span[@class='k-select']")).Displayed); break;
                case "provider text box": Assert.IsTrue(Suspects.EnterNewDiagnosisCode.ProviderIDTextbox.Displayed); break;
                case "provider name": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//input[@test-id='searchDiag-txt-txtProviderName']")).Displayed); break;
                case "claim number text box": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//input[@test-id='searchDiag-txt-txtPlanClaimId']")).Displayed); break;
                case "risk assessment code text box": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@id='ddlRiskAssessment']//span[@class='k-select']")).Displayed); break;
                case "coder id drop down": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@id='ddlCoderId']//span[@class='k-select']")).Displayed); break;
                case "chart review source": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@id='ddlDiagnosisSource']//span[@class='k-select']")).Displayed); break;
                case "reference information": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//input[@test-id='searchDiag-txt-txtReferenceInformation']")).Displayed); break;
                case "chart Id text box": Assert.IsTrue(Suspects.EnterNewDiagnosisCode.chartID.Displayed); break;
                case "on top enable on hold check box": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[@test-id='searchDiag-lbl-lblHoldReasonDefault']")).Displayed); break;
                case "on top on hold reason drop down": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@id='ddlonHoldReasonDefault']//span[@class='k-select']")).Displayed); break;
                case "on bottam enable on hold check box": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[@test-id='searchDiag-lbl-lblIsEnableOnHold']")).Displayed); break;
                case "on bottam on hold reason drop down": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@id='ddlonHoldReason']//span[@class='k-select']")).Displayed); break;
                case "save button": Assert.IsTrue(Suspects.EnterNewDiagnosisCode.SaveBtngrid.Displayed); break;
                case "save and replicate button": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//button[contains(.,'SAVE AND REPLICATE')]")).Displayed); break;

            }
        }

        [Then(@"Verify Enter New Diagnosis Data page Result Grid Coulmn ""(.*)"" is displayed")]
        public void ThenVerifyEnterNewDiagnosisDataPageResultGridCoulmnIsDisplayed(string p0)
        {
            string field = tmsCommon.GenerateData(p0);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='searchDiag-grid-member']//table//th[contains(.,'" + field + "')]")).Displayed);

        }

        [Then(@"Verify Enter New Diagnosis Data page Result Grid Columns ""(.*)"" and ""(.*)"" and ""(.*)"" and ""(.*)"" and ""(.*)"" and ""(.*)"" and ""(.*)"" and ""(.*)"" and ""(.*)"" and ""(.*)"" and ""(.*)"" and ""(.*)"" and ""(.*)"" and ""(.*)"" are displayed")]
        public void ThenVerifyEnterNewDiagnosisDataPageResultGridColumnsAndAndAndAndAndAndAndAndAndAndAndAndAndAreDisplayed(string p0, string p1, string p2, string p3, string p4, string p5, string p6, string p7, string p8, string p9, string p10, string p11, string p12, string p13)
        {
            string field1 = tmsCommon.GenerateData(p0);
            string field2 = tmsCommon.GenerateData(p1);
            string field3 = tmsCommon.GenerateData(p2);
            string field4 = tmsCommon.GenerateData(p3);
            string field5 = tmsCommon.GenerateData(p4);
            string field6 = tmsCommon.GenerateData(p5);
            string field7 = tmsCommon.GenerateData(p6);
            string field8 = tmsCommon.GenerateData(p7);
            string field9 = tmsCommon.GenerateData(p8);
            string field10 = tmsCommon.GenerateData(p9);
            string field11 = tmsCommon.GenerateData(p10);
            string field12 = tmsCommon.GenerateData(p11);
            string field13 = tmsCommon.GenerateData(p12);
            string field14 = tmsCommon.GenerateData(p13);

            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='searchDiag-grid-member']//table//th[contains(.,'" + field1 + "')]/following-sibling::th[contains(.,'" + field2 + "')]/following-sibling::th[contains(.,'" + field3 + "')]/following-sibling::th[contains(.,'" + field4 + "')]/following-sibling::th[contains(.,'" + field5 + "')]/following-sibling::th[contains(.,'" + field6 + "')]/following-sibling::th[contains(.,'" + field7 + "')]/following-sibling::th[contains(.,'" + field8 + "')]/following-sibling::th[contains(.,'" + field9 + "')]/following-sibling::th[contains(.,'" + field10 + "')]/following-sibling::th[contains(.,'" + field11 + "')]/following-sibling::th[contains(.,'" + field12 + "')]/following-sibling::th[contains(.,'" + field13 + "')]/following-sibling::th[contains(.,'" + field14 + "')]")).Displayed);

        }

        [Then(@"Verify the Enter New Diagnosis Data page Result Grid has row Diagnosis Data ""(.*)"" and Provider Id ""(.*)"" and Claim Number ""(.*)"" and Chart Id ""(.*)"" is displayed")]
        public void ThenVerifyTheEnterNewDiagnosisDataPageResultGridHasRowDiagnosisDataAndProviderIdAndClaimNumberAndChartIdIsDisplayed(string p0, string p1, string p2, string p3)
        {
            string diagnosis_code = tmsCommon.GenerateData(p0.ToString());
            string provider_id = tmsCommon.GenerateData(p1);
            string claim_number = tmsCommon.GenerateData(p2);
            string chart_id = tmsCommon.GenerateData(p3);
            bool hasrow = false;
            int totalPagesIntheGrid = ReUsableFunctions.getTotalPages();
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {
                    hasrow = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='searchDiag-grid-member']//td[contains(.,'" + diagnosis_code + "')]/following-sibling::td[contains(.,'" + provider_id + "')]/following-sibling::td[contains(.,'" + claim_number + "')]/following-sibling::td[contains(.,'" + chart_id + "')]")).Displayed;
                    break;
                }
                catch
                {

                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);
                }

            }
            Assert.IsTrue(hasrow, "There is no such row Present");
        }


        [Then(@"Verify Enter New Diagnosis Data page Result Grid has row Diagnosis Data ""(.*)"" and Provider Id ""(.*)"" and Claim Number ""(.*)"" and Chart Id ""(.*)"" is displayed")]
        public void ThenVerifyEnterNewDiagnosisDataPageResultGridHasRowDiagnosisDataAndProviderIdAndClaimNumberAndChartIdIsDisplayed(string p0, string p1, string p2, string p3)
        {

        }


        [Then(@"Verify Enter New Diagnosis Data page Result Grid has row Diagnosis Data ""(.*)"" and Claim Number ""(.*)"" and Chart Id ""(.*)"" is displayed")]
        public void ThenVerifyEnterNewDiagnosisDataPageResultGridHasRowDiagnosisDataAndClaimNumberAndChartIdIsDisplayed(string p0, string p1, string p2)
        {
            string diagnosis_code = tmsCommon.GenerateData(p0.ToString());
            string claim_number = tmsCommon.GenerateData(p1);
            string chart_id = tmsCommon.GenerateData(p2);
            bool hasrow = false;
            // int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//input[@role='spinbutton']")).GetAttribute("aria-valuemax"));
            //int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("aria-valuemax"));
            int totalPagesIntheGrid = ReUsableFunctions.getTotalPages();
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {
                    hasrow = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='searchDiag-grid-member']//td[contains(.,'" + diagnosis_code + "')]/following-sibling::td[contains(.,'" + claim_number + "')]/following-sibling::td[contains(.,'" + chart_id + "')]")).Displayed;
                    break;
                }
                catch
                {

                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);
                }

            }

            Assert.IsTrue(hasrow, "There is no such row Present");
        }





        [Then(@"Verify Enter New Diagnosis Data page Result Grid has row Diagnosis Data ""(.*)"" Provider Id ""(.*)"" Claim Number ""(.*)"" Chart Id ""(.*)"" is displayed")]
        public void ThenVerifyEnterNewDiagnosisDataPageResultGridHasRowDiagnosisDataEncounterDateFromEncounterDateToProviderIdClaimNumberChartIdIsDisplayed(int p0, int p1, string p2, string p3, string p4, string p5)
        {
            string diagnosis_code = tmsCommon.GenerateData(p0.ToString());
            string encounter_date_from = tmsCommon.GenerateData(p1.ToString());
            string encounter_date_to = tmsCommon.GenerateData(p2);
            string provider_id = tmsCommon.GenerateData(p3);
            string claim_number = tmsCommon.GenerateData(p4);
            string chart_id = tmsCommon.GenerateData(p5);
            bool hasrow = false;
            int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {
                    hasrow = Browser.Wd.FindElement(By.XPath("//div[@test-id='searchDiag-grid-member']//td[contains(.,'" + diagnosis_code + "')]/following-sibling::td[contains(.,'" + encounter_date_from + "')]/following-sibling::td[contains(.,'" + encounter_date_to + "')]/following-sibling::td[contains(.,'" + provider_id + "')]/following-sibling::td[contains(.,'" + claim_number + "')]/following-sibling::td[contains(.,'" + chart_id + "')]")).Displayed;
                    break;
                }
                catch
                {

                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);
                }

            }
            //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed);

            Assert.IsTrue(hasrow, "There is no such row Present");
        }

        [When(@"Enter New Diagnosis Data page Replicate button is clicked for row has Diagnosis Code ""(.*)"" and Provider Id ""(.*)""")]
        public void WhenEnterNewDiagnosisDataPageReplicateButtonIsClickedForRowHasDiagnosisCodeAndProviderId(string p0, string p1)
        {
            string diagnosis_code = tmsCommon.GenerateData(p0.ToString());
            //string encounter_date_from = tmsCommon.GenerateData(p1.ToString());
            //string encounter_date_to = tmsCommon.GenerateData(p2);
            string provider_id = tmsCommon.GenerateData(p1);

            bool hasrow = false;
            int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {
                    hasrow = Browser.Wd.FindElement(By.XPath("//div[@test-id='searchDiag-grid-member']//td[contains(.,'" + diagnosis_code + "')]/following-sibling::td[contains(.,'" + provider_id + "')]/parent::tr//a[2]")).Displayed;
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@test-id='searchDiag-grid-member']//td[contains(.,'" + diagnosis_code + "')]/following-sibling::td[contains(.,'" + provider_id + "')]/parent::tr//a[2]")));
                    break;
                }
                catch
                {

                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);
                }

            }
            //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed);

            Assert.IsTrue(hasrow, "There is no such row Present");
        }




        [When(@"Enter New Diagnosis Data page Replicate button is clicked for row has Diag Code ""(.*)"" and EFromDate""(.*)"" and EToDate ""(.*)"" and Provider Id ""(.*)"" and cNumber ""(.*)"" and Service ""(.*)"" and RiskCode ""(.*)""")]
        public void WhenEnterNewDiagnosisDataPageReplicateButtonIsClickedForRowHasDiagCodeAndEFromDateAndEToDateAndProviderIdAndCNumberAndServiceAndRiskCode(string p0, string p1, string p2, string p3, string p4, string p5, string p6)
        {
            string diagnosis_code = tmsCommon.GenerateData(p0.ToString());
            string encounter_date_from = tmsCommon.GenerateData(p1.ToString());
            string encounter_date_to = tmsCommon.GenerateData(p2);
            string provider_id = tmsCommon.GenerateData(p3);
            string claim_number = tmsCommon.GenerateData(p4.ToString());
            string type_of_service = tmsCommon.GenerateData(p5.ToString());
            string risk_assess_code = tmsCommon.GenerateData(p6.ToString());

            bool hasrow = false;
            int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {
                    hasrow = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='searchDiag-grid-member']//td[contains(.,'" + diagnosis_code + "')]/following-sibling::td[contains(.,'" + encounter_date_from + "')]/following-sibling::td[contains(.,'" + encounter_date_to + "')]/following-sibling::td[contains(.,'" + provider_id + "')]/following-sibling::td[contains(.,'" + claim_number + "')]/following-sibling::td[contains(.,'" + type_of_service + "')]/following-sibling::td[contains(.,'" + risk_assess_code + "')]/parent::tr//a")).Displayed;
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@test-id='searchDiag-grid-member']//td[contains(.,'" + diagnosis_code + "')]/following-sibling::td[contains(.,'" + encounter_date_from + "')]/following-sibling::td[contains(.,'" + encounter_date_to + "')]/following-sibling::td[contains(.,'" + provider_id + "')]/following-sibling::td[contains(.,'" + claim_number + "')]/following-sibling::td[contains(.,'" + type_of_service + "')]/following-sibling::td[contains(.,'" + risk_assess_code + "')]/parent::tr//a")));
                    break;
                }
                catch
                {

                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);
                }

            }
            //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed);

            Assert.IsTrue(hasrow, "There is no such row Present");
        }

        [When(@"Enter New Diagnosis Data page Replicate button is clicked for row has Diag Code ""(.*)"" and EFromDate""(.*)"" and EToDate ""(.*)"" and cNumber ""(.*)"" and Service ""(.*)"" and RiskCode ""(.*)""")]
        public void WhenEnterNewDiagnosisDataPageReplicateButtonIsClickedForRowHasDiagCodeAndEFromDateAndEToDateAndCNumberAndServiceAndRiskCode(string p0, string p1, string p2, string p3, string p4, string p5)
        {
            string diagnosis_code = tmsCommon.GenerateData(p0.ToString());
            string encounter_date_from = tmsCommon.GenerateData(p1);
            string encounter_date_to = tmsCommon.GenerateData(p2);
            string claim_number = tmsCommon.GenerateData(p3.ToString());
            string type_of_service = tmsCommon.GenerateData(p4.ToString());
            string risk_assess_code = tmsCommon.GenerateData(p5.ToString());

            bool hasrow = false;
            int totalPagesIntheGrid = ReUsableFunctions.getTotalPages();
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {
                    hasrow = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='searchDiag-grid-member']//td[contains(.,'" + diagnosis_code + "')]/following-sibling::td[contains(.,'" + encounter_date_from + "')]/following-sibling::td[contains(.,'" + encounter_date_to + "')]/following-sibling::td[contains(.,'" + claim_number + "')]/following-sibling::td[contains(.,'" + type_of_service + "')]/following-sibling::td[contains(.,'" + risk_assess_code + "')]/parent::tr//a")).Displayed;
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='searchDiag-grid-member']//td[contains(.,'" + diagnosis_code + "')]/following-sibling::td[contains(.,'" + encounter_date_from + "')]/following-sibling::td[contains(.,'" + encounter_date_to + "')]/following-sibling::td[contains(.,'" + claim_number + "')]/following-sibling::td[contains(.,'" + type_of_service + "')]/following-sibling::td[contains(.,'" + risk_assess_code + "')]/parent::tr//a")));
                    break;
                }
                catch
                {

                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);
                }

            }
            Assert.IsTrue(hasrow, "There is no such row Present");
        }



        [When(@"Enter New Diagnosis Data page Replicate button is clicked for row has Diagnosis Code ""(.*)"" Encounter Date From ""(.*)"" Encounter Date To ""(.*)"" Provider Id ""(.*)""")]
        public void WhenEnterNewDiagnosisDataPageReplicateButtonIsClickedForRowHasDiagnosisCodeEncounterDateFromEncounterDateToProviderId(int p0, string p1, string p2, string p3)
        {
            string diagnosis_code = tmsCommon.GenerateData(p0.ToString());
            string encounter_date_from = tmsCommon.GenerateData(p1.ToString());
            string encounter_date_to = tmsCommon.GenerateData(p2);
            string provider_id = tmsCommon.GenerateData(p3);

            bool hasrow = false;
            int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {
                    hasrow = Browser.Wd.FindElement(By.XPath("//div[@test-id='searchDiag-grid-member']//td[contains(.,'" + diagnosis_code + "')]/following-sibling::td[contains(.,'" + encounter_date_from + "')]/following-sibling::td[contains(.,'" + encounter_date_to + "')]/following-sibling::td[contains(.,'" + provider_id + "')]/parent::tr//a")).Displayed;
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@test-id='searchDiag-grid-member']//td[contains(.,'" + diagnosis_code + "')]/following-sibling::td[contains(.,'" + encounter_date_from + "')]/following-sibling::td[contains(.,'" + encounter_date_to + "')]/following-sibling::td[contains(.,'" + provider_id + "')]/parent::tr//a")));
                    break;
                }
                catch
                {

                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);
                }

            }
            //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed);

            Assert.IsTrue(hasrow, "There is no such row Present");
        }

        [Then(@"Verify Enter New Diagnosis Data page Form is displayed ""(.*)"" as ""(.*)""")]
        public void ThenVerifyEnterNewDiagnosisDataPageFormIsDisplayedAs(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            string actual_value = null;
            bool elementpresence = false;
            switch (field.ToLower())
            {
                case "diagnosis code":
                    actual_value = Browser.Wd.FindElement(By.XPath("//input[@test-id='searchDiag-txt-txtDiagCode']")).GetAttribute("value");
                    break;
                case "encounter from date":
                    elementpresence = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='searchMember-txt-encounterFromDate']//span[contains(.,'" + value + "')]")).Displayed;
                    Assert.IsTrue(elementpresence, "Element is not present");
                    break;
                case "encounter to date":
                    elementpresence = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='txtEncounterToDate']//span[contains(.,'" + value + "')]")).Displayed;
                    Assert.IsTrue(elementpresence, "Element is not present");
                    break;
                case "provider id":
                    actual_value = Browser.Wd.FindElement(By.XPath("//input[@test-id='searchDiag-txt-txtProviderId']")).GetAttribute("value");
                    break;
            }
            Assert.IsTrue(actual_value.Contains(value));
        }











        [When(@"Update PIR Provider ""(.*)"" label is displayed")]
        public void WhenUpdatePIRProviderLabelIsDisplayed(string labelName)
        {
            labelName = labelName.ToUpper().Trim();
            IWebElement labelObj = null;
            if (labelName.Equals("SEARCH BY:")) labelObj = Suspects.UpdatePIRProviderInfo.SearchByLabel;
            if (labelName.Equals("PAYMENT YEAR")) labelObj = Suspects.UpdatePIRProviderInfo.PaymentYearLabel;
            Assert.IsTrue(labelObj.Text.ToUpper().Trim().Equals(labelName.ToUpper()), labelName + " is not displayed");
        }

        [When(@"Update PIR Provider Search by ""(.*)"" is selected")]
        public void WhenUpdatePIRProviderSearchByIsSelected(string valueToSelect)
        {
            tmsWait.Hard(5);
            AngularFunction.selectDropDownValue(Suspects.UpdatePIRProviderInfo.SearchByDropdown, valueToSelect);
            //SelectElement thiselement = new SelectElement(Suspects.UpdatePIRProviderInfo.SearchByDropdown);
            //thiselement.SelectByText(valueToSelect.Trim());
        }

        [When(@"Update PIR Provider page Provider is set to ""(.*)""")]
        public void WhenUpdatePIRProviderPageProviderIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            By loc = By.CssSelector("[test-id='updatePirProvider-input-type']");
            AngularFunction.sendKeysWithClear(loc, value);
            tmsWait.Hard(180);
        }

        [Then(@"Verify Update PIR Provider page displayed ""(.*)""")]
        public void ThenVerifyUpdatePIRProviderPageDisplayed(string p0)
        {
            tmsWait.Hard(5);
            string value = tmsCommon.GenerateData(p0);
            By loc = By.XPath("(//kendo-grid[@test-id='updatePirProvider-label-grdPrv']//td[contains(.,'" + value + "')])[1]");
            AngularFunction.elementPresenceUsingLocators(loc);
        }

        [When(@"Verify label name is displayed as ""(.*)"" if Search By ""(.*)""")]
        public void WhenVerifyLabelNameIsDisplayedAsIfSearchBy(string expectedLabel, string fieldName)
        {
            IWebElement labelObj = null;
            labelObj = Suspects.UpdatePIRProviderInfo.SearchByOptionLabel;
            Assert.IsTrue(labelObj.Text.Equals(expectedLabel), expectedLabel + "is not displayed when " + fieldName + "is selected");
        }

        [When(@"Verify Search By textbox is displayed with watermark as ""(.*)""")]
        public void WhenVerifySearchByTextboxIsDisplayedWithWatermarkAs(string watermarkText)
        {
            Assert.IsTrue(Suspects.UpdatePIRProviderInfo.SearchByWatermark.GetAttribute("placeholder").Equals(watermarkText), watermarkText + "watermark is not displayed");
        }

        [Then(@"Update PIR Provider ""(.*)"" button is  displayed")]
        [When(@"Update PIR Provider ""(.*)"" button is  displayed")]
        public void WhenUpdatePIRProviderButtonIsDisplayed(string Btn)
        {
            IWebElement labelObj = null;
            Btn = Btn.Trim().ToUpper();
            if (Btn.Equals("RESET")) labelObj = Suspects.UpdatePIRProviderInfo.resetBtn;
            if (Btn.Equals("SEARCH")) labelObj = Suspects.UpdatePIRProviderInfo.searchBtn;
            if (Btn.Equals("UPDATE PROVIDER")) labelObj = Suspects.UpdatePIRProviderInfo.UpdateProviderBtn;
            if (Btn.Equals("DESELECT")) labelObj = Suspects.UpdatePIRProviderInfo.DeselectBtn;
            Assert.IsTrue(labelObj.Displayed, Btn + " is not displayed");
        }
        [Then(@"Update PIR Provider ""(.*)"" button is clicked")]
        [When(@"Update PIR Provider ""(.*)"" button is clicked")]
        public void WhenUpdatePIRProviderButtonIsClicked(string Btn)
        {
            tmsWait.Hard(60);
            IWebElement labelObj = null;
            Btn = Btn.Trim().ToUpper();
            if (Btn.Equals("RESET")) labelObj = Suspects.UpdatePIRProviderInfo.resetBtn;
            if (Btn.Equals("SEARCH")) labelObj = Suspects.UpdatePIRProviderInfo.searchBtn;
            if (Btn.Equals("UPDATE PROVIDER")) labelObj = Suspects.UpdatePIRProviderInfo.UpdateProviderBtn;
            if (Btn.Equals("DESELECT")) labelObj = Suspects.UpdatePIRProviderInfo.DeselectBtn;
            fw.ExecuteJavascript(labelObj);
            tmsWait.Hard(180);
        }

        [Then(@"Update PIR Provider first record is selected")]
        public void ThenUpdatePIRProviderFirstRecordIsSelected()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//input[@type='checkbox'])[1]")));
            tmsWait.Hard(1);
        }

        [When(@"Provider Lookup Provider ID is set to ""(.*)""")]
        public void WhenProviderLookupProviderIDIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            string value = tmsCommon.GenerateData(p0);
            By providerid = By.CssSelector("[test-id='provider-input-SearchBytxt']");
            AngularFunction.sendKeysWithClear(providerid, value);
        }


        [Then(@"Update PIR Provider second record is selected")]
        public void ThenUpdatePIRProviderSecondRecordIsSelected()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//input[@type='checkbox'])[2]")));
            tmsWait.Hard(1);
        }


        [Then(@"Update PIR Provider Provider Lookup icon is clicked")]
        public void ThenUpdatePIRProviderProviderLookupIconIsClicked()
        {
            fw.ExecuteJavascript(Suspects.UpdatePIRProviderInfo.providerIDLookupIcon);
        }

        [When(@"Update PIR provider ""(.*)"" lookup icon is clicked")]
        public void WhenUpdatePIRProviderLookupIconIsClicked(string LookupName)
        {
            fw.ExecuteJavascript(Suspects.UpdatePIRProviderInfo.SearchByLookupIcon);
        }


        [Then(@"verify Update PIR Provider Result Grid ""(.*)"" is displayed")]
        public void ThenVerifyUpdatePIRProviderResultGridIsDisplayed(string ObjectTocheck)
        {
            tmsWait.Hard(5);
            IWebElement labelObj = null;
            ObjectTocheck = ObjectTocheck.Trim().ToUpper();
            switch (ObjectTocheck)
            {
                case "PAGINATION": labelObj = Suspects.UpdatePIRProviderInfo.resultGridPagination; break;
                case "PROVIDER NAME": labelObj = Suspects.UpdatePIRProviderInfo.providerNameTextbox; break;
                case "PROVIDER LOOKUP": break;//to be added
            }
            Assert.IsTrue(labelObj.Displayed, ObjectTocheck + " is not displayed");
        }
        [Then(@"verify Update PIR Provider Result Grid is displayed")]
        public void ThenVerifyUpdatePIRProviderResultGridIsDisplayed()
        {
            tmsWait.Hard(180);
            tmsWait.WaitForElement(By.XPath("//kendo-grid[@test-id='updatePirProvider-label-grdPrv']"), 60);
            Assert.IsTrue(Suspects.UpdatePIRProviderInfo.Resultgrid.Displayed, "Update Provider Info Result grid is not displayed");
        }
        [Then(@"verify Update PIR Provider Result Grid label ""(.*)"" is displayed")]
        public void ThenVerifyUpdatePIRProviderResultGridLabelIsDisplayed(string label)
        {
            tmsWait.Hard(3);
            IWebElement labelObj = null;
            if (label.Contains("Provider Name")) labelObj = Suspects.UpdatePIRProviderInfo.providerNameLabel;
            if (label.Contains("Provider ID")) labelObj = Suspects.UpdatePIRProviderInfo.providerIDlabel;
            if (label.Contains("New Provider")) labelObj = Suspects.UpdatePIRProviderInfo.NewProviderLabel;
            Assert.IsTrue(labelObj.Text.Equals(label), label + " is not displayed");
        }


        [When(@"Update PIR Provider Payment year ""(.*)"" is selected")]
        public void WhenUpdatePIRProviderPaymentYearIsSelected(string Paymentyear)
        {
            AngularFunction.selectDropDownValue(Suspects.UpdatePIRProviderInfo.paymentyearDropdown, Paymentyear);

            //SelectElement paymentyearDropdown = new SelectElement(Suspects.UpdatePIRProviderInfo.paymentyearDropdown);
            //try { 
            //paymentyearDropdown.SelectByText(Paymentyear.Trim());
            //tmsWait.Hard(10);
            //}
            //catch
            //{
            //    paymentyearDropdown.SelectByIndex(0);
            //    tmsWait.Hard(10);
            //}
        }
        [Then(@"Update PIR Provider select ""(.*)"" corresponding to  ""(.*)"" is selected")]
        public void ThenUpdatePIRProviderSelectCorrespondingToIsSelected(string columnToselect, string expectedRow)
        {
            tmsWait.Hard(2);
            IWebElement objWebTable = null;
            if (columnToselect.ToUpper().Trim().Equals("SELECT"))
                objWebTable = Browser.Wd.FindElement(By.XPath("(//input[@type='checkbox'])[1]"));
            fw.ExecuteJavascript(objWebTable);
        }

        [Then(@"Update PIR Provider select ""(.*)""")]
        public void ThenUpdatePIRProviderSelect(string hcc1)
        {
            tmsWait.Hard(5);
            string hcc = tmsCommon.GenerateData(hcc1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + hcc + "')]/parent::td/preceding-sibling::td/input")));
        }


        [Then(@"Update PIR Provider ""(.*)"" textbox is set as ""(.*)""")]
        [When(@"Update PIR Provider ""(.*)"" textbox is set as  ""(.*)""")]
        public void WhenUpdatePIRProviderTextboxIsSetAs(string Textboxname, string ValueToSet)
        {
            tmsWait.Hard(2);
            if (!Suspects.UpdatePIRProviderInfo.SearchByDropdown.Displayed)
                fw.ExecuteJavascript(Suspects.UpdatePIRProviderInfo.SearchAccordian);
            Suspects.UpdatePIRProviderInfo.SearchByTxtbox.Clear();
            Textboxname = Textboxname.ToUpper().Trim();
            ValueToSet = tmsCommon.GenerateData(ValueToSet);
            Suspects.UpdatePIRProviderInfo.SearchByTxtbox.SendKeys(ValueToSet);
        }

        [Then(@"Update PIR Provider Search accordian is expended")]
        public void ThenUpdatePIRProviderSearchAccordianIsExpended()
        {
            fw.ExecuteJavascript(Suspects.UpdatePIRProviderInfo.SearchAccordian);
        }

        [Then(@"Update PIR Provider Result accordian providerID is entered as ""(.*)""")]
        public void ThenUpdatePIRProviderResultAccordianProviderIDIsEnteredAs(string ValuetoSet)
        {
            ValuetoSet = tmsCommon.GenerateData(ValuetoSet);
            Suspects.UpdatePIRProviderInfo.providerIDTextbox.SendKeys(ValuetoSet);
        }

        [When(@"Update PIR Provider providerid is set to to ""(.*)""")]
        public void WhenUpdatePIRProviderProvideridIsSetToTo(string p0)
        {
            string id = tmsCommon.GenerateData(p0);
            IWebElement prid = Browser.Wd.FindElement(By.XPath("//input[@test-id='updatePirProvider-input-type']"));
            prid.SendKeys(id);
        }

        [Then(@"Update PIR Provider new providerid is set to ""(.*)""")]
        public void ThenUpdatePIRProviderNewProvideridIsSetTo(string p0)
        {
            string newprid = tmsCommon.GenerateData(p0);
            IWebElement prid = Browser.Wd.FindElement(By.XPath("//input[@test-id='updatePirProvider-input-pirProviderId']"));
            prid.SendKeys(newprid);
        }

    }
}
