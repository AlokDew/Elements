﻿using OpenQA.Selenium;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.HCC_RAM
{
    class RAM
    {
        public static RAMHomePage RAMHomePage { get { return new RAMHomePage(); } }
        public static AddOnHoldReasonPage AddOnHoldReasonPage { get { return new AddOnHoldReasonPage(); } }
        public static EnterNewDiagnosticDataPage EnterNewDiagnosticDataPage { get { return new EnterNewDiagnosticDataPage(); } }

        public static EnterNewDiagnosisCode EnterNewDiagnosisCode { get { return new EnterNewDiagnosisCode(); } }
        public static RAMDashboardPage RAMDashboardPage { get { return new RAMDashboardPage(); } }
        public static AdminSubmenu AdminSubmenu { get { return new AdminSubmenu(); } }
        public static AddDiagnosisCodesPage AddDiagnosisCodesPage { get { return new AddDiagnosisCodesPage(); } }
        public static AddReasonsPage AddReasonsPage { get { return new AddReasonsPage(); } }
        public static AddCoderIDsPage AddCoderIDsPage { get { return new AddCoderIDsPage(); } }
        public static AddPaymentYearPage AddPaymentYearPage { get { return new AddPaymentYearPage(); } }
        public static PIRCoverLetter PIRCoverLetter { get { return new PIRCoverLetter(); } }
        public static WorkflowOptions WorkflowOptions { get { return new WorkflowOptions(); } }
        public static ExcludeIncludeProviderPage ExcludeIncludeProviderPage { get { return new ExcludeIncludeProviderPage(); } }
        public static SetClientOptions SetClientOptions { get { return new SetClientOptions(); } }
        public static SetPlanStarRating SetPlanStarRating { get { return new SetPlanStarRating(); } }
        public static RAMMainmenu RAMMainmenu { get { return new RAMMainmenu(); } }
        public static RAMReportPage RAMReportPage { get { return new RAMReportPage(); } }
        public static ExportPage ExportPage { get { return new ExportPage(); } }
        public static ManageSuspectsSearchResultpage ManageSuspectsSearchResultpage { get { return new ManageSuspectsSearchResultpage(); } }
        public static ManageSuspectPage ManageSuspectPage { get { return new ManageSuspectPage(); } }
        public static TasksSubmenu TasksSubmenu { get { return new TasksSubmenu(); } }
        public static ImportsPage ImportsPage { get { return new ImportsPage(); } }
        public static ViewandUndoPIRResponses ViewandUndoPIRResponses { get { return new ViewandUndoPIRResponses(); } }
        public static Allentereddiagnosiscodes Allentereddiagnosiscodes { get { return new Allentereddiagnosiscodes(); } }
        public static CancelSuspectPage CancelSuspectPage { get { return new CancelSuspectPage(); } }
        public static CMSFileDetailsReport CMSFileDetailsReport { get { return new CMSFileDetailsReport(); } }
        public static AssignmentHistoryReport AssignmentHistoryReport { get { return new AssignmentHistoryReport(); } }
        public static DataLoadDetailReport DataLoadDetailReport { get { return new DataLoadDetailReport(); } }
        public static RAMScheduling RAMScheduling { get { return new RAMScheduling(); } }
        public static RAMProspectiveEvaulation RAMProspectiveEvaulation { get { return new RAMProspectiveEvaulation(); } }
        public static ControlNumberPage ControlNumberPage { get { return new ControlNumberPage(); } }
        public static ProspectiveEvaluationAssignments ProspectiveEvaluationAssignments { get { return new ProspectiveEvaluationAssignments(); } }
        public static PIRResultSummary PIRResultSummary { get { return new PIRResultSummary(); } }
        public static CustomCoverLetterPIR CustomCoverLetterPIR { get { return new CustomCoverLetterPIR(); } }
        public static UserManagement UserManagement { get { return new UserManagement(); } }
        public static ViewOnHoldDiagnosisCode ViewOnHoldDiagnosisCode { get { return new ViewOnHoldDiagnosisCode(); } }
        public static AddOnHoldReasons AddOnHoldReasons { get { return new AddOnHoldReasons(); } }
        public static AddSourcePage AddSourcePage { get { return new AddSourcePage(); } }
        public static DeleteSubmittedDiagCodes DeleteSubmittedDiagCodes { get { return new DeleteSubmittedDiagCodes(); } }
        public static RAMAuditorReview RAMAuditorReview { get { return new RAMAuditorReview(); } }
        public static PIRPage PIRPage { get { return new PIRPage(); } }
        // public static RAMMainLookup RAMMainLookup { get { return new RAMMainLookup(); } }




    }

    

        [Binding]
    public class AddOnHoldReasonPage
    {
        public IWebElement AddButton { get { return Browser.Wd.FindElement(By.XPath("//button[contains(.,'ADD')]")); } }
    }
        [Binding]
    public class EnterNewDiagnosticDataPage
    {
        public IWebElement title { get { return Browser.Wd.FindElement(By.XPath("//div[@class='adminTitle']/span")); } }
        public IWebElement resetButton { get { return Browser.Wd.FindElement(By.XPath("//button[@class='btn  secondaryButton']")); } }
        public IWebElement EncounterToDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMember-txt-encounterToDate']")); } }
        public IWebElement TypeOfServiceDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlTypeofservice_listbox']")); } }
        public IWebElement ProviderID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchDiag-txt-txtProviderId']")); } }
        public IWebElement ReferenceInformation { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchDiag-txt-txtReferenceInformation']")); } }
        public IWebElement SaveButton { get { return Browser.Wd.FindElement(By.XPath("(//button[contains(.,'SAVE')])[1]")); } }
        public IWebElement ClaimNumber { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchDiag-txt-txtPlanClaimId']")); } }
        public IWebElement OnHoldReasonDrpdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlonHoldReason_listbox']")); } }
        public IWebElement OnHoldCheckbox { get { return Browser.Wd.FindElement(By.Id("lblIsEnableOnHold")); } }

        public IWebElement CoderIDDrpdown { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pirResponse-select-coders']")); } }
        public IWebElement ReasonDrpdown { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pirResponse-select-unconfirmedSuspects']")); } }
        public IWebElement memberFirstName { get { return Browser.Wd.FindElement(By.Id("txtFirstName")); } }

        public IWebElement memberLastName { get { return Browser.Wd.FindElement(By.Id("txtLastName")); } }

        public IWebElement memberDOB { get { return Browser.Wd.FindElement(By.Id("txtDateOfBirth")); } }

        public IWebElement searchMemberResetButton { get { return Browser.Wd.FindElement(By.Id("btnReset")); } }

    }

    [Binding]
    public class PIRPage
    {
        public IWebElement DiagCode { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchDiag-txt-txtDiagCode']")); } }
        public IWebElement EncounterFromDate { get { return Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='searchMember-txt-encounterFromDate']//span[@role='button']")); } }
        public IWebElement EncounterToDate { get { return Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='searchMember-txt-encounterToDate']//span[@role='button']")); } }
        public IWebElement TypeOfServiceDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlTypeofservice_listbox']")); } }
        public IWebElement ProviderID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchDiag-txt-txtProviderId']")); } }
        public IWebElement ReferenceInformation { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchDiag-txt-txtReferenceInformation']")); } }
        public IWebElement SaveButton { get { return Browser.Wd.FindElement(By.XPath("(//button[contains(.,'SAVE')])[1]")); } }
        public IWebElement MemberTopUnknownHCCLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pirResponse-span-memberTopHcc']")); } }
        public IWebElement ClaimNumber { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchDiag-txt-txtPlanClaimId']")); } }
        public IWebElement AddNoteButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pirResponse-soan-viewNotes']")); } }
        public IWebElement AllPIRNoteTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pirViewEditNotes-txt-addNoteValue']")); } }
        public IWebElement AllPIRADDButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pirViewEditNotes-btn-addNote']")); } }

        public IWebElement OnHoldReasonDrpdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlonHoldReason_listbox']")); } }

        public IWebElement CoderIDDrpdown { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pirResponse-select-coders']")); } }
        public IWebElement ReasonDrpdown { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pirResponse-select-unconfirmedSuspects']")); } }

    }

    [Binding]
    public class UserManagement
    {


    }

    [Binding]
    public class CustomCoverLetterPIR
    {
        public IWebElement ClientDropdown { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ClientID']")); } }
        public IWebElement PaymentYearDropdown { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PaymentYear']")); } }
        public IWebElement StatusDropdown { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Status']")); } }

    }

    [Binding]
    public class ControlNumberPage
    {
        public IWebElement BackButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pirDiagnosisCodes-span-back']")); } }
    }

    public class ProspectiveEvaluationAssignments
    {
        public IWebElement AssigmentTitle { get { return Browser.Wd.FindElement(By.XPath("//div[@class='adminTitle ']//span[contains(.,'Prospective Evaluation')]")); } }
        public IWebElement SearchButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='assignment-search-button']")); } }
        public IWebElement IndividualUpdate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='peAssignments-lbl-individualUpdate']")); } }
        public IWebElement batchUpdate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='peAssignments-lbl-batchUpdate']")); } }
        public IWebElement projectName { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='prospectiveEvaluation-lbl-projectName']//following-sibling::span")); } }
        public IWebElement MemberOutreachTreeQueue { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Member Outreach')]")); } }
        public IWebElement ProviderOutreachTreeQueue { get { return Browser.Wd.FindElement(By.XPath("//li[@role='treeitem']//div[contains(.,'Provider Outreach')]/span")); } }
        public IWebElement EvaulationTreeQueue { get { return Browser.Wd.FindElement(By.XPath("//li[@role='treeitem']//div[contains(.,'Evaluation')]/span")); } }
        public IWebElement MemberidText { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='workflow-txt-memberId']")); } }
        public IWebElement Queue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='workflow-txt-queue']")); } }
        public IWebElement QueueStatus { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='workflow-txt-queueSatus']")); } }
        public IWebElement updateButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='workflow-btn-search']")); } }
        public IWebElement HistoryButton { get { return Browser.Wd.FindElement(By.XPath("//button[contains(.,'HISTORY')]")); } }
        public IWebElement HistoryPopUpBack { get { return Browser.Wd.FindElement(By.XPath("//i[@class='fas fa-arrow-left']")); } }
        public IWebElement MemberProfileReportButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='workflow-btn-memberProfileReport']")); } }
        public IWebElement actionDueDatePicker { get { return Browser.Wd.FindElement(By.CssSelector("//label[contains(.,'Action Due Date')]/parent::div//span/input")); } }
        public IWebElement assignmentListProject { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='assignment-list-project']")); } }
        public IWebElement FilterSection { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='assignments-title-filter']")); } }
        public IWebElement MemeberWithoutHCCLabel { get { return Browser.Wd.FindElement(By.Id("lblMemWithoutHCC")); } }
        public IWebElement PayementYearLabel { get { return Browser.Wd.FindElement(By.Id("lblDataExists")); } }
        public IWebElement RiskScoreLabel { get { return Browser.Wd.FindElement(By.Id("lblRiskscore")); } }
        public IWebElement RaftTypeLabel { get { return Browser.Wd.FindElement(By.Id("lblRaftType")); } }
        public IWebElement AgeGroupLabel { get { return Browser.Wd.FindElement(By.Id("lblAgeGroup")); } }
        public IWebElement ProviderInfoTitle { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='workflow-title-ProviderInfo']")); } }
        public IWebElement MemberInfoTitle { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Member Information')]")); } }
        public IWebElement ProviderIDLabel { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='workflow-lbl-providerId']")); } }
        public IWebElement MemberIDLabel { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='workflow-lbl-memberId']")); } }
        public IWebElement MemberNameLabel { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='workflow-lbl-memberName']")); } }
        public IWebElement MemberAddressLabel { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='workflow-lbl-memberAddress']")); } }
        public IWebElement QueueStatusLabel { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='workflow-lbl-queueSatus']")); } }
        public IWebElement DueDatePicker { get { return Browser.Wd.FindElement(By.Id("dueDatePicker")); } }
        public IWebElement EditLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='workflow-spn-editProvider']")); } }
        public IWebElement SearchPCPButton { get { return Browser.Wd.FindElement(By.XPath("//button[contains(.,'SEARCH') and @test-id='pcplookup-btn-Search']")); } }
        public IWebElement ProviderGridCell { get { return Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='lookup-grid-searchresult']//tr//td/input)[1]")); } }
        public IWebElement BackButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='grouplookup-img-BackToRecord']")); } }
        public IWebElement ProviderIDText { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='workflow-spn-providerId']")); } }
    }

    [Binding]
    public class RAMScheduling
    {
        public IWebElement SearchProviderButton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='maintainProjects-button-search']")); } }
        public IWebElement ProviderSearchResult { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='scheduling-title-ProviderInfo']")); } }
        public IWebElement QueueDropdown { get { return Browser.Wd.FindElement(By.Id("queue")); } }
        public IWebElement ResetButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='maintainProjects-button-resetSearch']")); } }
        public IWebElement ProviderIDPlusIcon { get { return Browser.Wd.FindElement(By.XPath("//span[@class='k-icon k-i-expand']")); } }
        public IWebElement MemberIDInfo { get { return Browser.Wd.FindElement(By.XPath("(//span[contains(.,'Member :')])[1]")); } }
        public IWebElement MemberIDText { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberfill-txt-Memberid']")); } }
        public IWebElement QueueText { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberfill-txt-Queue']")); } }
        public IWebElement NameText { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='scheduling-spn-providerName']")); } }
        public IWebElement PhoneText { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='scheduling-txt-providerPhone']")); } }
        public IWebElement FaxText { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='addProject-txt-providerFax']")); } }
        public IWebElement schedulingFaxText { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='scheduling-lbl-providerFax']")); } }



        public IWebElement MemberNameText { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberfill-txt-MemberName']")); } }
        public IWebElement QueueStatusDropdown { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='scheduling-select-QueueStatus']")); } }
        public IWebElement UserDate { get { return Browser.Wd.FindElement(By.Id("UserEnteredDate")); } }
        public IWebElement NoteTextArea { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberfill-txt-Note']")); } }
        public IWebElement ProviderDropdown { get { return Browser.Wd.FindElement(By.Id("providers")); } }
        public IWebElement UpdateQueueStatusButton { get { return Browser.Wd.FindElement(By.XPath("//button[contains(.,'UPDATE QUEUE STATUS')]")); } }
        public IWebElement SuccessMessage { get { return Browser.Wd.FindElement(By.ClassName("toast-message")); } }
        public IWebElement EditProviderLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='scheduling-spn-editProvider']")); } }
        public IWebElement CityTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='addProject-txt-providerCity']")); } }
        public IWebElement ProviderStateDropdown { get { return Browser.Wd.FindElement(By.Id("providerState")); } }
        public IWebElement ProviderSaveButton { get { return Browser.Wd.FindElement(By.Id("btnSaveProviderInfo")); } }
        public IWebElement ProviderResetButton { get { return Browser.Wd.FindElement(By.Id("btnResetProviderInfo")); } }
        public IWebElement FaxTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='addProject-txt-providerFax']")); } }
        public IWebElement ZipTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='addProject-txt-providerZip']")); } }
        public IWebElement CreateNewProjectLink { get { return Browser.Wd.FindElement(By.XPath("//button[contains(.,'CREATE PROJECT')]")); } }
        public IWebElement ProjectNameTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='addProject-txt-projectName']")); } }
        public IWebElement AddNewProjectButton { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'ADD')]")); } }
        public IWebElement ProjectAddMessage { get { return Browser.Wd.FindElement(By.ClassName("k-notification-container")); } }
        public IWebElement SearchProjectButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='maintainProjects-button-search']")); } }
        public IWebElement ProjectSearchResult { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='maintainProjects-label-grdSuspectAssignment']")); } }
        public IWebElement PaymentYearDropdown { get { return Browser.Wd.FindElement(By.Id("paymentYears")); } }
        public IWebElement PlanIDDropdown { get { return Browser.Wd.FindElement(By.Id("planId")); } }
        public IWebElement SuspectTypeDropdown { get { return Browser.Wd.FindElement(By.Id("suspectType")); } }
        public IWebElement PriorityDropdown { get { return Browser.Wd.FindElement(By.Id("priority")); } }
        public IWebElement ResetProjectButton { get { return Browser.Wd.FindElement(By.Id("btnReset")); } }
    }


    [Binding]
    public class CMSFileDetailsReport
    {
        public IWebElement startdate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Mindate']")); } }
        public IWebElement enddate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Maxdate']")); } }
        public IWebElement MinDate { get { return Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl03_txtValue")); } }
        public IWebElement MaxDate { get { return Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl05_txtValue")); } }
        public IWebElement ViewReport { get { return Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl00")); } }
    }


    [Binding]
    public class AssignmentHistoryReport
    {
        public IWebElement MemberIDLookup { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-link-group']")); } }
        public IWebElement SearchMemberButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='lookup-btn-Search']")); } }
        public IWebElement FirstMemberNo { get { return Browser.Wd.FindElement(By.XPath("//td[@role='gridcell']/span")); } }
        public IWebElement BackButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pcpLookup-txt-backToRecord']")); } }
    }

    [Binding]
    public class DataLoadDetailReport
    {
        public IWebElement StartDatePicker { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='fromDate']")); } }
        public IWebElement EndDatePicker { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ToDate']")); } }
    }


    [Binding]
    public class PIRResultSummary
    {
        public IWebElement StartDatePicker { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='fromDate']")); } }
        public IWebElement EndDatePicker { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ToDate']")); } }
    }
    [Binding]
    public class CancelSuspectPage
    {
        public IWebElement CancelSuspectsByDropdown { get { return Browser.Wd.FindElement(By.Id("drpSuspectTypes")); } }
        public IWebElement ProviderSuspectDropdown { get { return Browser.Wd.FindElement(By.Id("drpProviderSuspects")); } }
        public IWebElement PaymentYearsDropdown { get { return Browser.Wd.FindElement(By.XPath("//select[@test-id='cancelSuspects-select-paymentYear']")); } }
        public IWebElement ResetButton { get { return Browser.Wd.FindElement(By.Id("btnReset")); } }
        public IWebElement CancelSuspectsButton { get { return Browser.Wd.FindElement(By.Id("btnSearch")); } }
        public IWebElement ConfirmationYesButton { get { return Browser.Wd.FindElement(By.Id("confirmationDialogYes")); } }
        public IWebElement SuspectTypeDropdown { get { return Browser.Wd.FindElement(By.Id("suspectTypes")); } }
        public IWebElement PIRControlNumberTextbox { get { return Browser.Wd.FindElement(By.Id("controlNumber")); } }
        public IWebElement ErrorMessageControlNumber { get { return Browser.Wd.FindElement(By.XPath("//span[@id='controlNumber-error-msg']")); } }
        public IWebElement HCCNameTextbox { get { return Browser.Wd.FindElement(By.Id("hccName")); } }
        public IWebElement ErrorMessageHCCName { get { return Browser.Wd.FindElement(By.XPath("//span[@id='hccName-error-msg']")); } }
        //public IWebElement BlankProviderErrorMessage { get { return Browser.Wd.FindElement(By.XPath("//kendo-dialog-titlebar[contains(@id,'kendo-dialog-title')]/following-sibling::div/p")); } }
        public IWebElement BlankProviderErrorMessage { get { return Browser.Wd.FindElement(By.XPath("//kendo-dialog-titlebar[contains(@id,'kendo-dialog-title')]/following-sibling::div/div[@class='m-3 ng-tns-c35-1 ng-star-inserted']")); } }
                
        public IWebElement ProviderSearchPanel { get { return Browser.Wd.FindElement(By.XPath("//table[@role='presentation']")); } }
        public IWebElement LastNameTextbox { get { return Browser.Wd.FindElement(By.Id("providerLastName")); } }
        public IWebElement SearchButton { get { return Browser.Wd.FindElement(By.Id("btnSearch")); } }
        public IWebElement CancelSuspectActionButton { get { return Browser.Wd.FindElement(By.CssSelector(".fa.fa-close")); } }
        public IWebElement GroupRadiobutton { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='manageSuspects-label-rdGroup']")); } }
        public IWebElement ProviderRadiobutton { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='manageSuspects-label-rdProvider']")); } }
        public IWebElement NoResultMessage { get { return Browser.Wd.FindElement(By.XPath("//div[contains(.,'No result found for this search criteria')]")); } }
        public IWebElement ICDCodeTextbox { get { return Browser.Wd.FindElement(By.Id("icdCode")); } }
    }

    [Binding]

    public class Allentereddiagnosiscodes
    {
        public IWebElement ViewNotes { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pirDiagnosisCodes-span-viewNotes']")); } }
    }


    [Binding]
    public class ViewandUndoPIRResponses
    {
        public IWebElement SearchBydrpdown { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Search By')]/parent::div//span[@class='k-select'])[1]")); } }
        public IWebElement ControlNumber { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='viewUndoPir-input-controlNumber']")); } }
        public IWebElement SearchButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='viewUndoPir-button-search']")); } }
        public IWebElement StartDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='viewUndoPir-txt-startDate']")); } }
        public IWebElement EndDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='viewUndoPir-txt-endDate']")); } }
        public IWebElement MemberID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='viewUndoPir-txt-memberId']")); } }
    }

    [Binding]
    public class RAMDashboardPage
    {
        public IWebElement PaymentYeardrpdown { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ramDashboard-select-paymentYear']")); } }
        public IWebElement SuspectSummaryGrid { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ramDashboard-lbl-suspectSummary']")); } }
        public IWebElement ProviderSummaryGrid { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ramDashboard-lbl-providerSummary']")); } }
        public IWebElement RiskScore { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ramDashboard-lbl-riskScore']")); } }
        public IWebElement Revenue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ramDashboard-lbl-revenue']")); } }
    }



    [Binding]
    public class RAMReportPage
    {
        public IWebElement RunReportButton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='report-btn-runReport']")); } }
        public IWebElement SearchButton { get { return Browser.Wd.FindElement(By.XPath("//button[@ng-click='searchReports();']")); } }
        public IWebElement StartDateText { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='Mindate']")); } }
        public IWebElement EffDateFrom { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='EffDate_From']")); } }
        public IWebElement EffDateTo { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='EffDate_To']")); } }
        public IWebElement FromDate { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='FromDate']")); } }

        public IWebElement EffDate { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='EffDate']")); } }

        public IWebElement ClientDropdown { get { return Browser.Wd.FindElement(By.XPath("//select[@test-id='ClientId']")); } }
        public IWebElement MemberIDSearchButton { get { return Browser.Wd.FindElement(By.CssSelector(".fa.fa-search")); } }
        public IWebElement MemberLookupSearchButton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='lookup-btn-Search']")); } }
        public IWebElement ProviderLookupSearchButton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='searchProvider-btn-search']")); } }
        public IWebElement FirstMemberRecord { get { return Browser.Wd.FindElement(By.XPath("//div[2]/table/tbody/tr[1]/td[2]")); } }
        public IWebElement FirstMemberRecord_CheckBox { get { return Browser.Wd.FindElement(By.XPath("//*[@id='auditMembersListGrid']/div[2]/table/tbody/tr[1]/td[1]/input")); } }
        public IWebElement MemberLookupBackButton { get { return Browser.Wd.FindElement(By.CssSelector(".icon-back_32px")); } }
        public IWebElement ProviderLookupButton { get { return Browser.Wd.FindElement(By.XPath("(//a/i[@class='fas fa-search text-secondary'])[1]")); } }
        public IWebElement GroupLookupButton { get { return Browser.Wd.FindElement(By.XPath("(//*[@test-id='report-link-group']/a)[2]")); } }
        public IWebElement SearchProviderIDButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='member-btn-search']")); } }
        public IWebElement FirstRecordProvider { get { return Browser.Wd.FindElement(By.XPath("//tbody[@role='rowgroup']//tr[1]/td")); } }
        public IWebElement FirstRecordHCC { get { return Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='lookup-grid-hccLookup']//tr)[2]")); } }
        public IWebElement BackProviderLookupButton { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Back') and @class='ng-binding']")); } }
        public IWebElement RESETButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='lookup-btn-Reset']")); } }
        public IWebElement ProviderInput { get { return Browser.Wd.FindElement(By.CssSelector(".input.ng-pristine.ng-untouched.ng-valid")); } }
        public IWebElement ProviderSearchGrid { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='lookup-grid-hccLookup']")); } }
        public IWebElement ProviderInvalidCharacter { get { return Browser.Wd.FindElement(By.XPath("//span[@id='txtSearchBytxt-error-msg']")); } }
        public IWebElement ProviderIDTextbox { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='searchProvider-txt-ProviderID']")); } }
        public IWebElement MemberIDTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='member-input-SearchBytxt']")); } }
        public IWebElement UpdateProviderInfoProviderLookupButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='updatePirProvider-button-search']")); } }
        public IWebElement PCPLookupSearchButton { get { return Browser.Wd.FindElement(By.XPath("//i[@class='fas fa-search text-secondary']")); } }
        public IWebElement HCCLookupSearchButton { get { return Browser.Wd.FindElement(By.XPath("//span[@test-id='report-link-group']//a//i")); } }
        public IWebElement HCCSearchByDropdown { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pcpLookup-list-searchBy']")); } }
        public IWebElement HCCIDTextbox { get { return Browser.Wd.FindElement(By.Id("txtSearchBytxt")); } }
        public IWebElement SearchByDropdown { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='updatePirProvider-select-searchby']")); } }
        public IWebElement PCPSEARCHButton { get { return Browser.Wd.FindElement(By.Id("btnSearch")); } }
        public IWebElement HCCSEARCHButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='batchUpdate-btn-search']")); } }
        public IWebElement ControlNumberTextbox { get { return Browser.Wd.FindElement(By.Id("txtUpdatePirProviderId")); } }
        public IWebElement RESETPIRProviderButton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='member-btn-reset']")); } }
        public IWebElement PIRProviderIDTextbox { get { return Browser.Wd.FindElement(By.Id("txtUpdatePirProviderId")); } }
        public IWebElement BackPCPLookupButton { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Back')]")); } }
        public IWebElement PCPSearchBySelectionbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pcpLookup-list-searchBy']")); } }
        public IWebElement PCPIDTextbox { get { return Browser.Wd.FindElement(By.Id("txtSearchBytxt")); } }
        public IWebElement RESETPCPButton { get { return Browser.Wd.FindElement(By.Id("btnReset")); } }
        public IWebElement RESETHCCButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='batchUpdate-btn-reset']")); } }
        public IWebElement SearchResult { get { return Browser.Wd.FindElement(By.XPath(".//div[contains(@id, 'lookupGrid')]//td[1]")); } }
        public IWebElement MemberIDLookupButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='updatePirProvider-lnk-openlookup']")); } }
        public IWebElement MemberIDLookupButton1 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='updatePirProvider-lnk-openlookup']")); } }
        public IWebElement ToastMessage { get { return Browser.Wd.FindElement(By.ClassName("toast-message")); } }
        public IWebElement InvalidMessage { get { return Browser.Wd.FindElement(By.XPath("//span[@id='txtSearchBytxt-error-msg']")); } }
        public IWebElement ErrorMessage { get { return Browser.Wd.FindElement(By.XPath("//span[@id='txtLookUpId-error-msg']")); } }
        public IWebElement PaginationGrid { get { return Browser.Wd.FindElement(By.XPath("//div[@test-id='lookup-grid-searchresult']//div[@data-role='pager']")); } }
        public IWebElement RESETSearchByDropdown { get { return Browser.Wd.FindElement(By.CssSelector(".k-input.ng-scope")); } }
        public IWebElement UpdatePIRSearchBy { get { return Browser.Wd.FindElement(By.CssSelector("select[test-id='updatePirProvider-select-searchby']")); } }
        public IWebElement ProviderIDLookupButton { get { return Browser.Wd.FindElement(By.CssSelector(".fa.fa-search")); } }
        public IWebElement StartKendoDate { get { return Browser.Wd.FindElement(By.CssSelector("input[test-id='Mindate']")); } }
        public IWebElement EndKendoDate { get { return Browser.Wd.FindElement(By.CssSelector("input[test-id='Maxdate']")); } }
        public IWebElement Memberlookuppagenumber { get { return Browser.Wd.FindElement(By.XPath(".//div[contains(@id, 'lookupGrid')]//span[@class='k-pager-input k-label']/input")); } }
        public IWebElement MemberLookupnextbutton { get { return Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='lookup-grid-memberLookup']//span[@aria-label='Go to the next page']")); } }
        public IWebElement MemberLookuppreviousbutton { get { return Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='lookup-grid-memberLookup']//span[@aria-label='Go to the previous page']")); } }
        public IWebElement NewProviderLookuppagenumber { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='providerLookupGridOptions']//input[@class='k-textbox']")); } }
        public IWebElement NewProviderLookupPreviousBtn { get { return Browser.Wd.FindElement(By.XPath("//span[@class='k-icon k-i-arrow-w']")); } }
        public IWebElement NewProviderLookupNextBtn { get { return Browser.Wd.FindElement(By.XPath("//span[@class='k-icon k-i-arrow-e']")); } }
        public IWebElement ProviderGroupLookupID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pcpLookup-txt-searchBy']")); } }
        public IWebElement NoRxStartDate { get { return Browser.Wd.FindElement(By.CssSelector("input[test-id='StartDate']")); } }
        public IWebElement NoRxFileName { get { return Browser.Wd.FindElement(By.CssSelector("select[test-id='Fileid']")); } }
        public IWebElement NoRxErrorReason { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Reasonid']")); } }
        public IWebElement NoRxEndDate { get { return Browser.Wd.FindElement(By.CssSelector("input[test-id='EndDate']")); } }
        public IWebElement FalloutFileName { get { return Browser.Wd.FindElement(By.CssSelector("select[test-id='Files']")); } }


    }

    [Binding]
    public class ExportPage
    {

        
        public IWebElement txtLookUpProviderId2 { get { return Browser.Wd.FindElement(By.XPath("(//a/i[@class='ml-2 text-secondary fas fa-search'])[1]")); } }
        public IWebElement txtLookUpProviderId { get { return Browser.Wd.FindElement(By.XPath("(//a/i[@class='ml-2 text-secondary fas fa-search'])[2]")); } }
        public IWebElement CMSExtractLink { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'CMS Extract')]")); } }
        public IWebElement PIRMailExtractLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='2']")); } }
        public IWebElement MemberHCCExtractLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='3']")); } }
        public IWebElement SuspectbyCoderExtractLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='4']")); } }
        public IWebElement PIRExtractLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='5']")); } }
        public IWebElement PIRExtract { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'PIR Extract')]")); } }
        public IWebElement PIRExtractByControlNumberLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='6']")); } }
        public IWebElement PlanId { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PlanId']")); } }
        public IWebElement FileType { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='FileType']")); } }
        public IWebElement PaymentYear { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PaymentYear']")); } }
        // public IWebElement PirpageStatus { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='SuspectStatus']")); } }
        public IWebElement CoderId { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='CoderId']")); } }
        public IWebElement SuspectType { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='SuspectType']")); } }
        public IWebElement SuspectStatus { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='SuspectStatus']")); } }
        public IWebElement PIRStatus { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PirStatus']")); } }
        public IWebElement MemberId { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='MemberId']")); } }
        public IWebElement ProviderId { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ProviderId']")); } }
        public IWebElement Priority { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Priority']")); } }
        public IWebElement EnrolledMonths { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='EnrolledMonths']")); } }
        public IWebElement UpdatePirCheckbox { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='UpdatePir']")); } }
        public IWebElement IncludePirCheckbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='IncludePir']")); } }
        public IWebElement ExportsTitle { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='exports-title-exportList']")); } }
        public IWebElement ResetButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-reset']")); } }
        public IWebElement ExportButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='export-btn-runReport']")); } }
        public IWebElement Authentication { get { return Browser.Wd.FindElement(By.Id("ddlAuthentication")); } }
        public IWebElement EditDatabaseUserTextBox { get { return Browser.Wd.FindElement(By.Id("EditDatabaseUserTextBox")); } }
        public IWebElement EditDatabasePasswordTextBox { get { return Browser.Wd.FindElement(By.Id("EditDatabasePasswordTextBox")); } }
        public IWebElement txtLookUpId { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pcpLookup-txt-searchBy']")); } }
        public IWebElement ControlNumber { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='ControlNumber']")); } }
        public IWebElement searchButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='lookup-btn-Search']")); } }
        public IWebElement expandButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='header-btn-expanMenu']")); } }
        public IWebElement dropdownProduct { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='menu-btn-productDetails']")); } }
        public IWebElement FileProcessingPageLink { get { return Browser.Wd.FindElement(By.LinkText("Job Processing Status page")); } }
        public IWebElement txtLookemmberUpId { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='member-input-SearchBytxt']")); } }
    }

    [Binding]
    public class RAMMainmenu
    {
        public IWebElement Menulist { get { return Browser.Wd.FindElement(By.XPath("//ul[@test-id='menu-titleList']/li")); } }
        public IWebElement Administration { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='menu-23']")); } }
        public IWebElement Dashboard { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='menu-16']")); } }
        public IWebElement Main { get { return Browser.Wd.FindElement(By.CssSelector("a[title='Main']")); } }
        public IWebElement Tasks { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='menu-18']")); } }
        public IWebElement Suspects { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='menu-19']")); } }
        public IWebElement FileProcessingStatus { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='menu-20']")); } }
        public IWebElement Reports { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='menu-21']")); } }
        public IWebElement ReportManager { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='menu-22']")); } }
        public IWebElement ManageSuspects { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='subMenu-20']")); } }
        public IWebElement ManageSuspectsAssignment { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='subMenu-21']")); } }
        public IWebElement ProspectiveEvaluation { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='subMenu-22']")); } }



    }


    [Binding]
    public class AdminSubmenu
    {
        public IWebElement RAMAaddDiagnosisCodes { get { return Browser.Wd.FindElement(By.XPath("//li[@test-id='subMenu-30']")); } }
        public IWebElement RAMAaddReasons { get { return Browser.Wd.FindElement(By.XPath("//li[@test-id='subMenu-31']")); } }
        public IWebElement RAMAaddCoderIds { get { return Browser.Wd.FindElement(By.XPath("//li[@test-id='subMenu-32']")); } }
        public IWebElement addPaymentYear { get { return Browser.Wd.FindElement(By.XPath("//li[@test-id='subMenu-33']")); } }
        public IWebElement ExcludeIncludeProvider { get { return Browser.Wd.FindElement(By.XPath("//li[@test-id='subMenu-34']")); } }
        public IWebElement CustomizePIRCoverLetter { get { return Browser.Wd.FindElement(By.XPath("//li[@test-id='subMenu-38']")); } }
    }


    [Binding]
    public class TasksSubmenu
    {
        public IWebElement Import { get { return Browser.Wd.FindElement(By.XPath("//a[@title='Import']/span")); } }
        public IWebElement Export { get { return Browser.Wd.FindElement(By.XPath("//a[@title='Export']/span")); } }
        public IWebElement RiskAdjustmentUpdates { get { return Browser.Wd.FindElement(By.XPath("//a[@title='Risk Adjustment Updates']/span")); } }
        public IWebElement NotesAction { get { return Browser.Wd.FindElement(By.XPath("//li[@test-id='subMenu-26']")); } }
    }

    [Binding]
    public class ImportsPage
    {
        public IWebElement Title { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Import List')]")); } }
        public IWebElement ExportList { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Export List')]")); } }
        public IWebElement PIRResponse { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'PIR Response')]")); } }
        public IWebElement ClientIdentifiedSuspects { get { return Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Client Identified Suspects')])[1]")); } }
        public IWebElement PIRSelectFileBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='import-input-fileUpload'] input")); } }
        public IWebElement PIRImportBtn { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id='import-btn-import']")); } }
        public IWebElement UploadFilesBtn { get { return Browser.Wd.FindElement(By.XPath(".//button[contains(text(), 'Upload')]")); } }
        public IWebElement ImportBtn { get { return Browser.Wd.FindElement(By.XPath(".//button[@test-id='import-btn-import']")); } }
        //.//button[contains(text(), 'Upload')]
        public IWebElement PipeDelimitedRadioBtn { get { return Browser.Wd.FindElement(By.Id("pipeDelimied")); } }
    }

    [Binding]
    public class RAMHomePage
    {
        public IWebElement RAMexpandMenu { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='header-btn-expanMenu']")); } }
        public IWebElement RAMAdministration { get { return Browser.Wd.FindElement(By.XPath("//li[@test-id='menu-24']")); } }
        public IWebElement RAMTitle { get { return Browser.Wd.FindElement(By.XPath("//span[@test-id='header-title-applicationName']")); } }


    }

    [Binding]
    public class AddDiagnosisCodesPage
    {
        //public IWebElement RAMAaddDiagnosisCodeslable { get { return Browser.Wd.FindElement(By.XPath("//*[@id='fisrtLevelMenu']/li[1]/a/span")); } }
        public IWebElement RAMAaddDiagnosisCodeslable { get { return Browser.Wd.FindElement(By.XPath("(//div[contains(.,'Add Diagnosis Codes')])[4]")); } }
        public IWebElement RAMAaddICD9Code { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='diagnosisCodes-radio-icd9']")); } }

        public IWebElement RAMAaddICD10CodeRadio { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='diagnosisCodes-radio-icd10']")); } }

        public IWebElement RAMAaddICD10Code { get { return Browser.Wd.FindElement(By.XPath("//label[@for='idICD10']")); } }
        public IWebElement RAMAICDCode { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='diagnosisCodes-txt-diagnosisCode']")); } }
        public IWebElement RAMAICDDescription { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='diagnosisCodes-txt-txtDescription']")); } }
        public IWebElement RAMAICDNewDescription { get { return Browser.Wd.FindElement(By.XPath("//input[@id='description']")); } }
        public IWebElement RAMAICDCodeAddButton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='diagnosisCodes-btn-save']")); } }
        // public IWebElement RAMAICDCodeGrid { get { return Browser.Wd.FindElement(By.CssSelector("td > span.ng-binding")); } }
        public IWebElement RAMAaddDiagnosisCodesGrid { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='diagnosisCodes-table-codes']")); } }
        public IWebElement RAMAICDCodeResetButton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='diagnosisCodes-btn-reset']")); } }
        public IWebElement RAMAaddDiagnosisCodesPagination { get { return Browser.Wd.FindElement(By.Id("codesPaging")); } }
    }

    [Binding]
    public class AddSourcePage
    {
        public IWebElement RAMAddSourcetxt { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='addSource-txt-source']")); } }
        public IWebElement RAMSourceAddButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='addSource-btn-add']")); } }
        //public IWebElement RAMAaddReasonAddbutton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='addReasons-btn-add']")); } }
        public IWebElement WarningLabel { get { return Browser.Wd.FindElement(By.XPath("//*[@id='addReasonPopUp']//label")); } }
        public IWebElement WarningYesButton { get { return Browser.Wd.FindElement(By.Id("confirmationDialogYes")); } }
        public IWebElement WarningNoButton { get { return Browser.Wd.FindElement(By.Id("confirmationDialogNo")); } }
    }


    [Binding]
    public class AddReasonsPage
    {
        public IWebElement RAMAaddReasonslable { get { return Browser.Wd.FindElement(By.XPath("(//div[contains(.,'Add Reasons')])[4]")); } }
        public IWebElement RAMAaddReason { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='addReasons-txt-reason']")); } }
        public IWebElement RAMAaddReasonAddbutton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='addReasons-btn-save']")); } }
        public IWebElement WarningLabel { get { return Browser.Wd.FindElement(By.XPath("//*[@id='addReasonPopUp']//label")); } }
        public IWebElement WarningYesButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='confirmationDialog-btn-Yes']")); } }
        public IWebElement WarningNoButton { get { return Browser.Wd.FindElement(By.Id("deleteNo")); } }
    }


    [Binding]
    public class AddCoderIDsPage
    {
        public IWebElement RAMAaddCoderIDslable { get { return Browser.Wd.FindElement(By.CssSelector("span.padding0")); } }
        public IWebElement RAMAaddCoderId { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='coderIds-txt-txtCoderId']")); } }
        public IWebElement RAMAaddCoderIDsAddbutton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='coderIds-btn-save']")); } }
        public IWebElement DeleteYesButton { get { return Browser.Wd.FindElement(By.CssSelector("button[test-id='confirmationDialog-btn-Yes']")); } }
    }



    [Binding]
    public class ExcludeIncludeProviderPage
    {
        public IWebElement ProviderId { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='excludeProviders-txt-providerId']")); } }
        public IWebElement ProviderLastName { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='excludeProviders-txt-txtDescription']")); } }
        public IWebElement Findbutton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='excludeProviders-btn-search']")); } }
        public IWebElement FindProviderTitle { get { return Browser.Wd.FindElement(By.XPath("(//div[contains(.,'Exclude/Include Provider')])[4]")); } }
        public IWebElement ProviderListNote { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='excludeProviders-lbl-message']")); } }
        public IWebElement CheckboxforfirstProvider { get { return Browser.Wd.FindElement(By.XPath("//table[@class='k-grid-table']/tbody[@role='presentation']/tr[1]/td[1]/input")); } }
        //public IWebElement CheckboxforSecondProvider { get { return Browser.Wd.FindElement(By.XPath("//div[@test-id='excludeProviders-grid-providers']//tr[2]//td//input[@type='checkbox']")); } }
        public IWebElement CheckboxforSecondProvider { get { return Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='excludeProviders-grid-providers']//tr[2]//input")); } }
        public IWebElement ProviderID_First { get { return Browser.Wd.FindElement(By.XPath("//div[@id='providersGrid']/div/div[1]/div[2]/div/div[1]/div/div[2]")); } }
        public IWebElement ProviderID_First_LastName { get { return Browser.Wd.FindElement(By.XPath("//div[@id='providersGrid']/div/div[1]/div[2]/div/div[1]/div/div[2]")); } }
        public IWebElement UpdateButton { get { return Browser.Wd.FindElement(By.XPath("//button[@id='btnUpdate']")); } }
        public IWebElement ResetButton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='provider-btn-reset']")); } }
        public IWebElement CancleButton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='excludeProviders-btn-cancel']")); } }
        public IWebElement ProviderList { get { return Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='excludeProviders-grid-providers']//tr[1]//td[5]")); } }
        public IWebElement ProviderLookupIcon { get { return Browser.Wd.FindElement(By.XPath("//a[@test-id='excludeProviders-a-providerLookup']")); } }
        public IWebElement ProviderLookupNextIcon { get { return Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='lookup-grid-providerLookup']//kendo-pager-next-buttons/a[1]")); } }
        public IWebElement ExcludeProviderMessage { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='excludeProviders-lbl-message']")); } }

    }

    [Binding]
    public class PIRCoverLetter
    {
        public IWebElement PIRCoverLetterTitle { get { return Browser.Wd.FindElement(By.XPath("(//div[contains(.,'Customize PIR Cover Letter')])[4]")); } }
        public IWebElement PIRCoverLetterTxtArea { get { return Browser.Wd.FindElement(By.XPath("//textarea[@test-id='coverLetter-txtarea-coverLettertext']")); } }
        public IWebElement PIRCoverLetterUpdateBtn { get { return Browser.Wd.FindElement(By.XPath("//button[@id='btnUpdate']")); } }
        public IWebElement PIRCoverLetterResetBtn { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='coverLetter-btn-reset']")); } }
        public IWebElement PIRCoverLetterInstructionMark { get { return Browser.Wd.FindElement(By.XPath("coverLetter-span-instructions")); } }
        public IWebElement PIRCoverLetterQuestionMark { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='memberDemographics-i-sexToolTip']")); } }
        public IWebElement PIRCoverLetterErrorPopoupWhenNoUpdate { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='toast-container']/div/div/div")); } }
        public IWebElement PIRCoverLetterUpdateAlert { get { return Browser.Wd.FindElement(By.XPath("//*[@id='kendo-dialog-title-961488']")); } }
        public IWebElement PIRCoverLetterUpdateYes { get { return Browser.Wd.FindElement(By.Id("confirmationDialogYes")); } }


    }

    [Binding]

    public class AddPaymentYearPage
    {
        public IWebElement PaymentYearinput { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='paymentYear-txt-paymentYear']")); } }
        public IWebElement RiskPercentageinput { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='paymentYear-txt-riskPercentage']")); } }
        public IWebElement StartDatePicker { get { return Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='paymentYear-txt-startDate']//span/input")); } }
        public IWebElement EndDatePicker { get { return Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='paymentYear-txt-endDate']//span/input")); } }
        public IWebElement StartDate { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='paymentYear-btn-startDate']")); } }
        public IWebElement EndDate { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='paymentYear-btn-endDate']")); } }
        public IWebElement Resetbutton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='paymentYear-btn-reset']")); } }
        public IWebElement Addbutton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='paymentYear-btn-save']")); } }
        public IWebElement Editbutton { get { return Browser.Wd.FindElement(By.XPath("//tr[1]//span[@class='fas fa-pencil-alt']")); } }
        public IWebElement Deletebutton { get { return Browser.Wd.FindElement(By.XPath("(//*[@id='paymentYearGrid']//td//span[@class='fas fa-trash-alt'])[1]")); } }
        public IWebElement DeletePaymentYearbutton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='paymentYear-btn-delete']")); } }
        public IWebElement DeletePaymentYearYesbutton { get { return Browser.Wd.FindElement(By.Id("deleteYes")); } }
        public IWebElement Savebutton { get { return Browser.Wd.FindElement(By.XPath("//tr[1]//td/button[@class='k-button k-grid-save-command']")); } }
        public IWebElement Cancelbutton { get { return Browser.Wd.FindElement(By.XPath("//tr[1]//td/button[@class='k-button k-grid-save-command']")); } }
        public IWebElement AddPaymentYearTitle { get { return Browser.Wd.FindElement(By.XPath("//span[@test-id='paymentYear-span-addPaymentYear']")); } }
        public IWebElement YesDeleteConfirmButton { get { return Browser.Wd.FindElement(By.Id("deleteYes")); } }
        public IWebElement ToastMessge { get { return Browser.Wd.FindElement(By.ClassName("k-notification-content")); } }
        public IWebElement ErrorMsgYear { get { return Browser.Wd.FindElement(By.XPath("//span[@id='txtPaymentYear-error-msg']")); } }
        public IWebElement ErrorMsgPercentage { get { return Browser.Wd.FindElement(By.XPath("//span[@id='txtRiskPercentage-error-msg']")); } }
        public IWebElement EditRiskPercentage { get { return Browser.Wd.FindElement(By.XPath("//input[@name='riskPercentage']")); } }
        public IWebElement PaymentYearGrid { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='paymentYear-grid-paymentYear']")); } }




    }

    [Binding]
    public class SetClientOptions
    {
        public IWebElement ThresholdValue { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='configuration-txt-clientThreshold']")); } }
        public IWebElement Savebutton { get { return Browser.Wd.FindElement(By.XPath("//button[@ test-id='configuration-btn-save']")); } }
        public IWebElement Optionchoice { get { return Browser.Wd.FindElement(By.XPath("//select[@ test-id='configuration-select-choice']")); } }
        public IWebElement ErrorMessageThresholdValue { get { return Browser.Wd.FindElement(By.XPath("//span[@test-id='configuration-span-clientThreshold']")); } }
        public IWebElement configurationSelectPaymentYear { get { return Browser.Wd.FindElement(By.XPath("//select[@test-id='configuration-select-paymentYear']")); } }
        public IWebElement PaymentYear { get { return Browser.Wd.FindElement(By.XPath("//select[@test-id='PaymentYear']")); } }


    }

    [Binding]
    public class WorkflowOptions
    {
        public IWebElement ProspectiveMgmntTitle { get { return Browser.Wd.FindElement(By.XPath("(//div[contains(.,'Suspect Assignment Options')])[6]")); } }
        public IWebElement ProspectiveMgmtAcknwldgMsg { get { return Browser.Wd.FindElement(By.ClassName("toast-message")); } }
        public IWebElement AddQCodeTextbox { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='workflowOptions-input-queueCode']")); } }
        public IWebElement AddQCodeBtn { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='workflowOptions-btn-addQueueCode']")); } }
        public IWebElement QCodeTable { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='workflowOptions-table-queueCodesList']")); } }
        public IWebElement DeleteQueueCodeAlert { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='deleteQueueCodePopUp']/div/div")); } }
        public IWebElement DeleteQueueCodeAlertMsg { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id='workflowOptions-span-deleteQueueCodes']")); } }
        public IWebElement QCodeDeleteYesButton { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='workflowOptions-btn-deleteYesQueueCode']")); } }
        public IWebElement AddQStatusCodeTextBox { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='workflowOptions-input-queueStatusCode']")); } }
        public IWebElement AddQStatusCodeBtn { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='workflowOptions-btn-addStatusCode']")); } }
        public IWebElement QStatusCodeTable { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id='workflowOptions-table-statusCodes']")); } }
        public IWebElement QStatusCodeDeleteAlertMsg { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id='workflowOptions-span-deleteQueueStatusCodeMessage']")); } }
        public IWebElement QStatusCodeYesBtn { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id='workflowOptions-btn-deleteYesQueueStatus']")); } }
        public IWebElement AddActionCodeTextbox { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='workflowOptions-input-actionCode']")); } }
        public IWebElement AddActionCodeBtn { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='workflowOptions-btn-addActionCode']")); } }
        public IWebElement ActionCodeTable { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='workflowOptions-table-actionCodes']")); } }
        public IWebElement ActionCodeDeleteAlertMsg { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='workflowOptions-div-deleteActionMessage']")); } }
        public IWebElement ActionYesBtn { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='workflowOptions-btn-deleteYesAction']")); } }
        public IWebElement Applyrulesqcode { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='workflowOptions-select-queueCodes']")); } }
        public IWebElement Applyrulesqstatuscode { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='workflowOptions-select-queueStatusCodes']")); } }
        public IWebElement ApplyrulesqSaveBtn { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='workflowOptions-btn-save']")); } }
    }

    [Binding]
    public class SetPlanStarRating
    {
        public IWebElement PlanStarRatinglink { get { return Browser.Wd.FindElement(By.XPath("//li[@id='k-tabstrip-tab-1']")); } }
        public IWebElement labelNote { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='configuration-lbl-note']")); } }
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.XPath("//select[@test-id='configuration-select-planId']")); } }
        public IWebElement PaymentYear { get { return Browser.Wd.FindElement(By.XPath("//label[@id='lblPaymentYear']/parent::div//select[@test-id='configuration-select-paymentYear']")); } }
        public IWebElement StarRating { get { return Browser.Wd.FindElement(By.XPath("//select[@test-id='configuration-select-starRating']")); } }
        public IWebElement Savebutton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='configuration-btn-save']")); } }
        public IWebElement SaveSetClientOptionButton { get { return Browser.Wd.FindElement(By.CssSelector("button[test-id='configuration-btn-save']")); } }
        public IWebElement Errormessageplan { get { return Browser.Wd.FindElement(By.XPath("//span[@id='ddlPlanId-error-msg']")); } }
        public IWebElement SendToDropdown { get { return Browser.Wd.FindElement(By.Id("ddlOptionChoice")); } }
        public IWebElement ClaimThersholdYearTextbox { get { return Browser.Wd.FindElement(By.CssSelector("input[test-id='configuration-txt-clientThreshold']")); } }
        public IWebElement ErrorMsgClaimThersholdValue { get { return Browser.Wd.FindElement(By.CssSelector("span[test-id='configuration-span-thresholdRequired']")); } }
    }

    public class ManageSuspectsSearchResultpage
    {
        public IWebElement ManageSuspectSearchType { get { return Browser.Wd.FindElement(By.XPath("//select[@test-id='manageSuspects-select-searchType']")); } }
        public IWebElement ManageSuspectInputlastName { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='manageSuspects-input-lastName']")); } }
        public IWebElement ManageSuspectInputProviderId { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='manageSuspects-txt-providerId']")); } }
        public IWebElement ManageSuspectSearchButton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='manageSuspects-button-search']")); } }
        public IWebElement ManageSuspectResetButton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='manageSuspects-button-resetSearch']")); } }
        public IWebElement ManageSuspectInputPIRNumber { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='manageSuspects-input-pitControlNumber']")); } }
        public IWebElement ManageSuspectPIRNumberErrorMessage { get { return Browser.Wd.FindElement(By.XPath("//span[@test-id='manageSuspects-span-pirRequuiredError']")); } }
        public IWebElement ManageSuspectSearchPageProviderLabel { get { return Browser.Wd.FindElement(By.XPath("//div[text()='Manage Suspects']")); } }
        public IWebElement MemberLastName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='manageSuspects-input-memberLastName']")); } }
        public IWebElement PlanMemberIDTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='manageSuspects-input-planMemberId']")); } }
        public IWebElement ActionEditLink { get { return Browser.Wd.FindElement(By.CssSelector(".k-button")); } }
        public IWebElement CoderIDDrp { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@id='coderIds']//span[@class='k-select']")); } }
    }

    public class ManageSuspectPage
    {
        public IWebElement PotentialRelatedDiagnosesLink { get { return Browser.Wd.FindElement(By.XPath("//span[@test-id='pirResponse-title-potentialRelatedDiagnoses']")); } }
        public IWebElement PIRResponsePageViewNotes { get { return Browser.Wd.FindElement(By.XPath("//span[@test-id='pirResponse-soan-viewNotes']")); } }
        public IWebElement PageMemberTopKnownHCC { get { return Browser.Wd.FindElement(By.XPath("//span[@test-id='pirResponse-span-memberTopHcc']")); } }
        public IWebElement AddDiagnosesButton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='pirResponse-btn-add']")); } }
        public IWebElement PIRResponsePageMemberTopKnownHCC { get { return Browser.Wd.FindElement(By.XPath("//span[@test-id='pirResponse-span-memberTopHcc']")); } }
        public IWebElement PIRResponsePageAddDiagnosesButton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='pirResponse-btn-add']")); } }
        public IWebElement AddNote { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='pirViewEditNotes-txt-addNoteValue']")); } }
        public IWebElement AddNoteBtn { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='pirViewEditNotes-btn-addNote']")); } }
        public IWebElement AddNotePopupYesBtn { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='pirViewEditNotes-btn-addYes']")); } }
        public IWebElement EditNoteText { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='pirNotes']//td/input")); } }
        public IWebElement SaveNoteIcon { get { return Browser.Wd.FindElement(By.XPath(".//td/a[contains(@class, 'k-button k-button-icontext k-primary k-grid-update')]")); } }
        public IWebElement ManageSuspectAcknowledgmentMsg { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='toast-container']/div/div/div")); } }
        public IWebElement AdditionalDiagnosesLink { get { return Browser.Wd.FindElement(By.XPath("//span[@test-id='pirResponse-title-additionalDiagnoses']")); } }
        public IWebElement AdditionaldiagLink { get { return Browser.Wd.FindElement(By.XPath("//span[contains(text(),'Additional Diagnosis')]")); } }
        public IWebElement AdditionalDiagnosesAddNewRecordlink { get { return Browser.Wd.FindElement(By.LinkText("Add new record")); } }
        public IWebElement ProviderRadio { get { return Browser.Wd.FindElement(By.XPath("(//label[@test-id='manageSuspects-label-selectType']/parent::div//input)[1]")); } }
        public IWebElement GroupRadio { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='genSearchCrt-inp-partValue2']")); } }
        public IWebElement AffiliationRadio { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='manageSuspects-radip-affiliation']")); } }
        public IWebElement LastName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='manageSuspects-input-memberLastName']")); } }
        public IWebElement ProviderLastName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='manageSuspects-input-lastName']")); } }
        public IWebElement ProviderID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='manageSuspects-txt-providerId']")); } }
        public IWebElement SearchTypeDrpdownlist { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Search By')]/parent::div//span[@class='k-select']")); } }
        public IWebElement SearchButton { get { return Browser.Wd.FindElement(By.XPath("//button[contains(.,'SEARCH')]")); } }
        public IWebElement ResetButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='manageSuspects-button-resetSearch']")); } }
        public IWebElement ViewNotes { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pirResponse-soan-viewNotes']")); } }
        public IWebElement PIRmsg { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='pirResponse-label-responseSubmittedError']")); } }

        public IWebElement NewNotes { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pirViewEditNotes-txt-addNoteValue']")); } }
        public IWebElement ADDNotebutton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pirViewEditNotes-btn-addNote']")); } }
        public IWebElement WarningdialogYes { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='confirmationDialog-btn-Yes']")); } }
        public IWebElement WarningdialogNO { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pirViewEditNotes-btn-addNo']")); } }
        public IWebElement BackToRecord { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pirResponse-span-back']")); } }
        public IWebElement PIRNumber { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='manageSuspects-input-pitControlNumber']")); } }
        public IWebElement PIRNumber_undoPIR { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='viewUndoPir-input-pirControlNumber']")); } }
        public IWebElement WarningdialogOK { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='confirmationDialog-btn-Yes']")); } }
        public IWebElement WarningdialogCancel { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='confirmationDialog-btn-No']")); } }
        public IWebElement WarningdialogForOnHold { get { return Browser.Wd.FindElement(By.XPath("//div[contains(text(), 'Are you sure you are completed with this record?')]")); } }
        public IWebElement PIRInformationalmsg { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='pirResponse-label-responseSubmittedError']")); } }
        public IWebElement AdditionalDiagnoses { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Additional Diagnosis')]")); } }

        public IWebElement AddNewRecord { get { return Browser.Wd.FindElement(By.XPath("//a[@class='k-button k-button-icontext k-grid-add']")); } }
        public IWebElement AgreeCheckbox { get { return Browser.Wd.FindElement(By.Id("certifyCheck")); } }
        public IWebElement ManageSuspectBlock { get { return Browser.Wd.FindElement(By.XPath("(//kendo-dropdownlist[@test-id='manageSuspects-select-searchType']//span)[3]")); } }
        public IWebElement PotentialRelatedSection { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Potential Related Diagnosis')]")); } }
        public IWebElement AdditionalDiagnosisSection { get { return Browser.Wd.FindElement(By.XPath("(//i[@class='fa fa-plus-square minusPlusIcon pointerCursor'])[2]")); } }
        public IWebElement EditActionButton { get { return Browser.Wd.FindElement(By.XPath("(//td//span[@class='fas fa-edit'])[1]")); } }
        public IWebElement AddCheckbox { get { return Browser.Wd.FindElement(By.XPath("//input[@name='add']")); } }
        public IWebElement EncounterDateTextbox { get { return Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@id='txtFromDate']//span[@role='button']")); } }
        public IWebElement SaveButton { get { return Browser.Wd.FindElement(By.XPath("//table[@role='presentation']//tr[1]//button/span[@class='fas fa-save']")); } }
        public IWebElement RiskAccessCodeTextbox { get { return Browser.Wd.FindElement(By.Id("riskAssessCode")); } }
        public IWebElement ClaimNumber { get { return Browser.Wd.FindElement(By.XPath("//input[@name='claimNumber']")); } }
        public IWebElement NextButton { get { return Browser.Wd.FindElement(By.CssSelector(".k-icon.k-i-arrow-e")); } }
        public IWebElement ConfirmationYesButton { get { return Browser.Wd.FindElement(By.Id("confirmationDialogYes")); } }
        public IWebElement ProviderResultGrid { get { return Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='manageSuspects-grid-providerResult']")); } }
        public IWebElement AdditionaldiagCode { get { return Browser.Wd.FindElement(By.XPath(".//input[@name='code']")); } }
        public IWebElement AdditionaldiagECounterDate { get { return Browser.Wd.FindElement(By.XPath(".//input[@name='code']/following::input[@data-bind='value:encounterDate']")); } }
        public IWebElement AdddiagProviderId { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='additionalDiagnosesGrid']//input[@name='providerId']")); } }
        public IWebElement AdddiagRiskCode { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='additionalDiagnosesGrid']//input[@name='riskAssessCode']")); } }
        public IWebElement AdddiagClaimnumber { get { return Browser.Wd.FindElement(By.XPath(".//input[@name='claimNumber']")); } }
        public IWebElement AdddiagOnHoldcheckbox { get { return Browser.Wd.FindElement(By.CssSelector("input[test-id='searchdiag-chk-onhold']")); } }
        public IWebElement DropdownOnHoldReason { get { return Browser.Wd.FindElement(By.CssSelector("input[test-id='searchDiag-txt-ddlonholdreason']")); } }
        public IWebElement Adddiagsaveaction { get { return Browser.Wd.FindElement(By.XPath(".//a[@class ='k-button k-button-icontext k-primary k-grid-update']")); } }
        public IWebElement DateofService { get { return Browser.Wd.FindElement(By.XPath("//span[@test-id='pirResponse-span-dosTxt']")); } }
        public IWebElement MemberId { get { return Browser.Wd.FindElement(By.XPath("//span[@test-id='pirResponse-span-memberIdTxt']")); } }
        public IWebElement OnHoldPIRConfirmMsg { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='pirResponse-label-responseSubmittedError']")); } }
        public IWebElement PotentialdiagcodeGrid { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='potentialDiagnosesGrid']//table/tbody")); } }

        //** Additonal diagnosis new UI on manage suspect page
        public IWebElement AdditionalDiagCode { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='searchDiag-txt-txtDiagCode']")); } }
        public IWebElement AdditionalEncounterFromDate { get { return Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@id='txtEncounterFromDate']//span[@role='button']")); } }
        public IWebElement AdditionalEncounterToDate { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='searchMember-txt-encounterToDate']")); } }
        public IWebElement AdditionalProviderId { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='searchDiag-txt-txtProviderId']")); } }
        public IWebElement AdditionalSavebutton { get { return Browser.Wd.FindElement(By.XPath("(//button[contains(.,'SAVE')])[1]")); } }
        public IWebElement AdditionalSaveReplicateButton { get { return Browser.Wd.FindElement(By.XPath("(//button[contains(.,'SAVE')])[2]")); } }

        public IWebElement MemberTopKnownHCC { get { return Browser.Wd.FindElement(By.XPath("//span[@test-id='pirResponse-span-memberTopHcc']")); } }

        public IWebElement MaintainProjectCreateProjectButton { get { return Browser.Wd.FindElement(By.XPath("//button[contains(text(),'CREATE PROJECT')]")); } }

        public IWebElement MaintainProjectAddProjectButton { get { return Browser.Wd.FindElement(By.XPath("//span[contains(text(),'ADD')]")); } }

        public IWebElement MaintainProjectEnterProjectName { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='addProject-txt-projectName']")); } }

        public IWebElement MaintainProjectSearchButton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='maintainProjects-button-search']")); } }

        public IWebElement MaintainProjectSortButton { get { return Browser.Wd.FindElement(By.XPath("//span[contains(text(),'Provider ID')]/span")); } }



    }

    public class Suspects
    {
        public static EnterNewDiagnosisCode EnterNewDiagnosisCode { get { return new EnterNewDiagnosisCode(); } }
        public static UpdateProviderInfo UpdateProviderInfo { get { return new UpdateProviderInfo(); } }
        public static UpdatePIRProviderInfo UpdatePIRProviderInfo { get { return new UpdatePIRProviderInfo(); } }
    }

    public class RAMMainLookup
    {
        public static Lookup Lookup { get { return new Lookup(); } }
        //public static MemberIDLookup MemberIDLookup { get { return new MemberIDLookup(); } }
    }

    public class Lookup
    {
        public IWebElement lookupTitle { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Provider Lookup')]")); } }
        public IWebElement backToRecord { get { return Browser.Wd.FindElement(By.XPath("//div/span/i")); } }
        public IWebElement searchBylabel { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Provider')]")); } }
        public IWebElement searchByValue { get { return Browser.Wd.FindElement(By.XPath(".//label[@test-id='pcpLookup-lbl-searchBy']/following-sibling::span/span/span[1]")); } }
        public IWebElement searchBySelectValue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pcpLookup-list-searchBy']")); } }
        //public IWebElement searchByValue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pcpLookup-lbl-searchBy']")); } }
        public IWebElement searchbylabel { get { return Browser.Wd.FindElement(By.XPath(".//label[@test-id='lookup-lbl-txtlabel']/span")); } }
        public IWebElement searchbyValue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='provider-input-SearchBytxt']")); } }
        public IWebElement LookupResultGrid { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='lookup-grid-searchresult']")); } }
        public IWebElement LookupSearchBtn { get { return Browser.Wd.FindElement(By.XPath("(//button[contains(.,'SEARCH')])[2]")); } }
        public IWebElement MemberLookupSearchBtn { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='member-btn-search']")); } }

      
    }

    public class EnterNewDiagnosisCode
    {

        //*****Elements of New UI for enter new diagnosis****//
        public IWebElement MemberIDlookupWindowTextBox { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id='searchMember-txt-MemberID']")); } }
        public IWebElement SearchButton { get { return Browser.Wd.FindElement(By.XPath("//button[@id='btnsearch']")); } }

        public IWebElement memberLookupCancelBtn { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id='searchMember-btn-cancel']")); } }

        public IWebElement EncounterFromDate { get { return Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@id='txtEncounterFromDate']//span[@role='button']")); } }
        public IWebElement EncounterToDate { get { return Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@id='txtEncounterToDate']//span[@role='button']")); } }
        public IWebElement ProviderIDTextbox { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id='searchDiag-txt-txtProviderId']")); } }
        public IWebElement OnHoldCheckBox { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='searchDiag-chk-chkonHoldReason']")); } }
        public IWebElement EnableOnHoldCheckBox { get { return Browser.Wd.FindElement(By.Id("chkonHoldReason")); } }
        public IWebElement OnHoldReasonlistbox { get { return Browser.Wd.FindElement(By.XPath("//span[@aria-owns='ddlonHoldReason_listbox']")); } }
        public IWebElement chartID { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='searchDiag-txt-txtChartId']")); } }


        //***********************************//


        public IWebElement MemberIDLabel { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchDiag-lbl-member']")); } }
        public IWebElement MemberIDLookup { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchDiag-link-member']")); } }
        public IWebElement providerIDLookup { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchDiag-link-provider']")); } }
        public IWebElement MemberIDLookuptxtbox { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id='searchDiag-txt-txtMemberId']")); } }

        public IWebElement GetMemberID { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Member ID:')]/following-sibling::span")); } }

        //public IWebElement MemberLookupSearch { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='lookup-btn-Search']")); } }
        public IWebElement LookupSearchBtn { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id='searchMember-btn-search']")); } }
        public IWebElement LookupProviderSearchBtn { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id='searchProvider-btn-search']")); } }
        public IWebElement SearchMemberIDButton { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='encounter-btn-search']")); } }
        public IWebElement BackButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pcpLookup-txt-backToRecord']")); } }
        public IWebElement addButton { get { return Browser.Wd.FindElement(By.XPath("//button[contains(.,'ADD')]")); } }
        public IWebElement ResetButton { get { return Browser.Wd.FindElement(By.XPath("//button[contains(., 'RESET')]")); } }
        public IWebElement Address1 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='provider-txt-add1']")); } }
        public IWebElement Address2 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='provider-txt-add2']")); } }
        public IWebElement City_Town { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='provider-txt-city']")); } }
        public IWebElement State { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='provider-list-state']")); } }
        public IWebElement Telephone { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='provider-txt-phone']")); } }
        public IWebElement ZIP { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='provider-txt-zip']")); } }
        public IWebElement Contactname { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='provider-txt-contact']")); } }
        public IWebElement Fax { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='provider-txt-fax']")); } }
        public IWebElement AddnewCodeGrid { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='addDiagnosisFrm']//table")); } }
        public IWebElement ResultFirstname { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMember-spn-firstName']")); } }
        public IWebElement ResultFirstnameVal { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchDiag-spn-firstName']")); } }
        public IWebElement ResultLastname { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMember-spn-lastName']")); } }
        public IWebElement ResultLastnameVal { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchDiag-spn-lastName']")); } }
        public IWebElement ResultMemberID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMember-spn-memberid']")); } }
        public IWebElement ResultMemberIDVal { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchDiag-spn-memberId']")); } }
        public IWebElement ResultGroupID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMember-spn-grpid']")); } }
        public IWebElement ResultGroupIDVal { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchDiag-spn-groupId']")); } }
        public IWebElement ResultDOB { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMember-spn-dob']")); } }
        public IWebElement ResultDOBVal { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchDiag-spn-memberDob']")); } }
        public IWebElement ResultPCPname { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMember-spn-pcpname']")); } }
        public IWebElement ResultPCPnameVal { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchDiag-spn-pcpName']")); } }
        public IWebElement ResultIntmemberID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMember-spn-internalid']")); } }
        public IWebElement ResultIntmemberIDVal { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchDiag-spn-internalMemberId']")); } }
        public IWebElement addDiagnosisCodeBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMember-btn-addDiagnosisCode']")); } }
        public IWebElement DiagCodegrTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchDiag-txt-txtDiagCode']")); } }

        public IWebElement ClaimIDgrid { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchDiag-txt-txtPlanClaimId']")); } }
        public IWebElement CoderIDgrid { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchDiag-txt-ddlCoderId']")); } }
        public IWebElement EncounterDategrid { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMember-txt-encounterDate']")); } }
        public IWebElement TypeOfServicegrid { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchDiag-txt-ddlTypeofservice']")); } }
        public IWebElement RiskAssessmentgrid { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchDiag-txt-riskAssessment']")); } }
        public IWebElement TypeofServiceDropdown { get { return Browser.Wd.FindElement(By.XPath("//*[@aria-owns='ddlTypeofservice_listbox']")); } }

        public IWebElement riskAssessmentDropdown { get { return Browser.Wd.FindElement(By.XPath("//*[@aria-owns='ddlRiskAssessment_listbox']")); } }
        public IWebElement coderIDropdown { get { return Browser.Wd.FindElement(By.XPath("//*[@aria-owns='ddlCoderId_listbox']")); } }

        public IWebElement chartReviewSourceDDL { get { return Browser.Wd.FindElement(By.XPath("//*[@aria-owns='ddlDiagnosisSource_listbox']")); } }
        public IWebElement referenceInfoTextBox { get { return Browser.Wd.FindElement(By.Id("txtReferenceInformation")); } }

        public IWebElement providerNameText { get { return Browser.Wd.FindElement(By.Id("txtProviderName")); } }


        public IWebElement SaveBtngrid { get { return Browser.Wd.FindElement(By.XPath("(//button[contains(.,'SAVE')])[1]")); } }
        public IWebElement resetbtnAddDiagCode { get { return Browser.Wd.FindElement(By.XPath("//form[@id='addDiagnosisFrm']//button[@class='btn secondaryButton'][1]")); } }
        public IWebElement saveAndReplicateBtnAddDiagCode { get { return Browser.Wd.FindElement(By.XPath("//form[@id='addDiagnosisFrm']//button[contains(.,'SAVE AND REPLICATE')]")); } }
        public IWebElement SavedCodetable { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMember-btn-save']")); } }// may be need an update
        public IWebElement ViewAllEntriesSearch { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMember-btn-search']")); } }
        public IWebElement ViewAllEntriesRESET { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMember-btn-reset']")); } }
        public IWebElement ViewAllEntriesTitle { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'Undo New Diagnosis Entries')]")); } }
        public IWebElement ViewAllEntriesBack { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMember-txt-backToRecord']")); } }
        public IWebElement ViewAllEntriesCodeList { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id='searchMember-grid-diag']/div[2]/table")); } }
        public IWebElement ViewAllEntryCodegridheader { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id='searchMember-grid-diag']//table//thead")); } }
        public IWebElement ViewAllEntryMembergridheader { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id='searchMember-grid-member']//table//thead")); } }
        public IWebElement ViewAllEntriesLink { get { return Browser.Wd.FindElement(By.XPath("//button[contains(.,'VIEW EXISTING DIAG ENTRIES')]")); } }
        public IWebElement StartDateTxtbox { get { return Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='searchMember-txt-startDatePicker']//span[@role='button']")); } }
        public IWebElement EnddateTxtbox { get { return Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='searchMember-txt-endDatePicker']//span[@role='button']")); } }
        public IWebElement ViewAllEntryMemberList { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id='searchMember-grid-member']/div[2]/table")); } }
        public IWebElement DeleteConfirmationPopup { get { return Browser.Wd.FindElement(By.Id("dialog")); } }// need to be updated
        public IWebElement DleConfirmTitle { get { return Browser.Wd.FindElement(By.XPath(".//label[text() = 'Confirmation']")); } }
        public IWebElement DeleteConfirmMsg { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='dialog']//span[contains(.,'Are you sure you want to delete this record ?')]")); } }
        public IWebElement DeleteOKBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='confirmationDialog-btn-Yes']")); } }
        public IWebElement DeleteCancelBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='confirmationDialog-btn-No']")); } }
        public IWebElement NextPageBtn { get { return Browser.Wd.FindElement(By.XPath("//a[@title = 'Go to the next page']")); } }
        public IWebElement MemberListGrid { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchMember-grid-member']")); } }
        public IWebElement DiagnosisCodeGrid { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id='searchDiag-grid-member']//table/tbody")); } }
        public IWebElement MemberLookupGrid { get { return Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='searchMember-grid-memberLookup']//tbody")); } }

        public IWebElement MemberLookupTable { get { return Browser.Wd.FindElement(By.XPath("//div[@test-id='searchMember-grid-memberLookup']")); } }
        public IWebElement providerLookupGrid { get { return Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='searchMember-grid-providerLookup']//tbody")); } }
        public IWebElement NewProviderlookuoMI { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='searchProvider-txt-MiddleInitial']")); } }

        public IWebElement OnHoldReason { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id='searchDiag-txt-ddlonholdreason']")); } }
    }

    public class UpdateProviderInfo
    {
        public IWebElement ProviderIDLabel { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='searchprovider-txt-lbl']")); } }//to be updated
        public IWebElement ProviderIDLookup { get { return Browser.Wd.FindElement(By.XPath("//a[@test-id='provider-txt-show']/i")); } }
        public IWebElement ProviderLookuptxtbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='serachprovider-txt-providerId']")); } }
        public IWebElement SearchButton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='providersearch-btn-Search']")); } }
        public IWebElement LookupSearchButton { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='btnUpdate']")); } }
        public IWebElement SearchImageButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='provider-txt-show']")); } }
        public IWebElement ResetButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='providersearch-btn-reset']")); } }
        public IWebElement UpdateBtn { get { return Browser.Wd.FindElement(By.XPath("//button[contains(.,'UPDATE')]")); } }//to be updated
        public IWebElement FirstProviderRow { get { return Browser.Wd.FindElement(By.CssSelector("tr.ng-scope")); } }
        public IWebElement BackButton { get { return Browser.Wd.FindElement(By.XPath("//span[contains(text(),'Back')]")); } }
        public IWebElement ContactNameTextbox { get { return Browser.Wd.FindElement(By.Id("contactName")); } }
        public IWebElement Address1Textbox { get { return Browser.Wd.FindElement(By.Id("address1")); } }
        public IWebElement Address2Textbox { get { return Browser.Wd.FindElement(By.Id("address2")); } }
        public IWebElement CityTextbox { get { return Browser.Wd.FindElement(By.Id("city")); } }
        public IWebElement TelephoneTextbox { get { return Browser.Wd.FindElement(By.Id("phone")); } }
        public IWebElement FaxTextbox { get { return Browser.Wd.FindElement(By.Id("fax")); } }
        public IWebElement ZipTextbox { get { return Browser.Wd.FindElement(By.Id("zip")); } }
        public IWebElement ErrorContactMessage { get { return Browser.Wd.FindElement(By.XPath("//span[@id='contactName-error-msg']")); } }
        public IWebElement ErrorStateMessage { get { return Browser.Wd.FindElement(By.XPath("//span[@id='statedrp-error-msg']")); } }
        public IWebElement ErrorCityMessage { get { return Browser.Wd.FindElement(By.XPath("//span[@id='statedrp-error-msg']")); } }
        public IWebElement ErrorAddressOneMessage { get { return Browser.Wd.FindElement(By.XPath("//span[@id='address1-error-msg']")); } }
        public IWebElement ErrorTelephoneMessage { get { return Browser.Wd.FindElement(By.XPath("//span[@id='phone-error-msg']")); } }
        public IWebElement ErrorZipMessage { get { return Browser.Wd.FindElement(By.XPath("//span[@id='txtzip-error-msg']")); } }
        public IWebElement ErrorFaxMessage { get { return Browser.Wd.FindElement(By.XPath("//span[@id='fax-error-msg']")); } }
        public IWebElement StateSelectedText { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'State')]/parent::div//span[@class='k-input']")); } }
        //public IWebElement StateDropdown { get { return Browser.Wd.FindElement(By.CssSelector("span.k-widget.k-dropdown.k-header.form-control.ng-pristine.ng-untouched.ng-valid.ng-valid-required")); } }
        public IWebElement StateDropdown { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'State')]/parent::div//span[@class='k-select']")); } }

        public string updateBtn { get; internal set; }
    }

    public class UpdatePIRProviderInfo
    {
        public IWebElement SearchByLabel { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Search By')]")); } }
        public IWebElement SearchByDropdown { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Select Type')]/parent::div//span[@class='k-select']")); } }
        public IWebElement SearchByOptionLabel { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='updatePirProvider-label-type']")); } }
        public IWebElement PaymentYearLabel { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Payment Year')]")); } }
        public IWebElement paymentyearDropdown { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Payment Year')]/parent::div//span[@class='k-select']")); } }
        public IWebElement SearchByWatermark { get { return Browser.Wd.FindElement(By.XPath(".//input[@test-id='updatePirProvider-input-type' and @placeholder='All']")); } }
        public IWebElement searchBtn { get { return Browser.Wd.FindElement(By.XPath("//button[contains(.,'SEARCH')]")); } }
        public IWebElement resetBtn { get { return Browser.Wd.FindElement(By.XPath("//button[contains(.,'RESET')]")); } }
        public IWebElement Resultgrid { get { return Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='updatePirProvider-label-grdPrv']")); } }
        public IWebElement updatePIRprovidermemberList { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id='updatePirProvider-label-grdPrv']//div[2]//table")); } }
        public IWebElement resultGridHeader { get { return Browser.Wd.FindElement(By.XPath(".//div[@test-id='updatePirProvider-label-grdPrv']//thead")); } }
        public IWebElement resultControlNumber { get { return Browser.Wd.FindElement(By.XPath(".//div[@test-id='updatePirProvider-label-grdPrv']//thead")); } }
        public IWebElement resultGridPagination { get { return Browser.Wd.FindElement(By.XPath("//kendo-pager")); } }
        public IWebElement NewProviderLabel { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Select New Provider')]")); } }
        public IWebElement providerIDlabel { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='updatePirProvider-label-id']")); } }
        public IWebElement providerIDTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='updatePirProvider-input-pirProviderId']")); } }
        public IWebElement providerIDLookupIcon { get { return Browser.Wd.FindElement(By.XPath("//a[@test-id='updatePirProvider-lnk-openProvider']")); } }
        public IWebElement providerNameLabel { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='updatePirProvider-label-name']")); } }
        public IWebElement providerNameTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='updatePirProvider-input-pirProviderName']")); } }
        public IWebElement UpdateProviderBtn { get { return Browser.Wd.FindElement(By.XPath("//button[contains(.,'UPDATE PROVIDER')]")); } }
        public IWebElement DeselectBtn { get { return Browser.Wd.FindElement(By.XPath("//button[contains(.,'DESELECT')]")); } }
        public IWebElement SearchByLookupIcon { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id='updatePirProvider-input-type']/following-sibling::span/a/i")); } }//to be updated
        public IWebElement SearchByTxtbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='updatePirProvider-input-type']")); } }
        public IWebElement SearchAccordian { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='updatePirProvider-title-searchCriteria']")); } }
        public IWebElement NextButton { get { return Browser.Wd.FindElement(By.CssSelector("a[title='Go to the next page'] span")); } }
        public IWebElement PreviousButton { get { return Browser.Wd.FindElement(By.CssSelector("a[title='Go to the previous page'] span")); } }
        public IWebElement LastButton { get { return Browser.Wd.FindElement(By.CssSelector("a[title='Go to the last page'] span")); } }
        public IWebElement FirstButton { get { return Browser.Wd.FindElement(By.CssSelector("a[title='Go to the first page'] span")); } }
        public IWebElement CurrentPageNo { get { return Browser.Wd.FindElement(By.XPath("//input[@role='spinbutton']")); } }
        public IWebElement LastPageNo { get { return Browser.Wd.FindElement(By.XPath("(//kendo-pager//kendo-pager-input//span)[1]")); } }
        public IWebElement NewproviderlookupResetBtn { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id='searchProvider-btn-reset']")); } }
        public IWebElement ProviderGroupLookupIcon { get { return Browser.Wd.FindElement(By.XPath("(//span[@test-id='report-link-group']/a)[2]")); } }
    }
    [Binding]
    public class RAMProspectiveEvaulation

    {
        public IWebElement manageProjectTitle { get { return Browser.Wd.FindElement(By.XPath("(//div[contains(.,'Manage Projects')])[4]")); } }
        public IWebElement manageProjectViewProject { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'View Project')]")); } }
        public IWebElement manageProjectResultGrid { get { return Browser.Wd.FindElement(By.Id("dgMemberInfo")); } } //need to add test-id
        public IWebElement manageProjectResultGridHeader { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='dgMemberInfo']//thead")); } } //need to add test-id
        public IWebElement createProjectLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='prospectiveEvaluation-btn-addNewProject']")); } }
        public IWebElement createProjectpageTitle { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'manageConfiguration-span-heading']")); } }
        public IWebElement AgeGroupDropdown { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'addProspectiveEvaluation-slct-ageGroup']")); } }
        public IWebElement GenderDropdown { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'addProspectiveEvaluation-slct-gender']")); } }
        public IWebElement ExportBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'prospectiveEvaluation-btn-export']")); } }
        public IWebElement QueueToAssignBtn { get { return Browser.Wd.FindElement(By.CssSelector("button[test-id='prospectiveEvaluation-btn-queue']")); } }
        public IWebElement CreateProjectADDbtn1 { get { return Browser.Wd.FindElement(By.XPath("//button[contains(.,'ADD')]")); } }
        public IWebElement CreateProjectADDbtn { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id ='addProspectiveEvaluation-btn-save']")); } }
        public IWebElement CreateProjectRESETbtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'addProspectiveEvaluation-btn-reset']")); } }

        public IWebElement ProjectNameTextBox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'searchDiag-txt-txtProjectName']")); } }
        public IWebElement FromDate { get { return Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@id='fromDatePicker1']//span[@role='button']")); } }
        public IWebElement ThruDate { get { return Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@id='thruDatePicker1']//span[@role='button']")); } }
        public IWebElement MemberAlreadyExist { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'addProspectiveEvaluation-title-addNewProject']")); } }
        public IWebElement BackToCreateProject { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'addProspectiveEvaluation-img-BackToRecord']")); } }
        public IWebElement MemberExistYESBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'addProspectiveEvaluation-btn-yes']")); } }
        //public IWebElement MemberExistNOBtn  { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'addProspectiveEvaluation-btn-no']")); } }
        public IWebElement MemberExistNOBtn { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id = 'addProspectiveEvaluation-btn-no']")); } }
        public IWebElement ExistYESBtn { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id = 'addProspectiveEvaluation-btn-yes']")); } }
        public IWebElement MemberWithoutHCC { get { return Browser.Wd.FindElement(By.XPath("//input[@id='chkWithoutHcc']")); } }
        public IWebElement MemberWithoutVisit { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'addProspectiveEvaluation-ckb-visits']")); } }
        public IWebElement HCClookupDropdown { get { return Browser.Wd.FindElement(By.Id("hccLookUpDrp")); } }
        public IWebElement RiskScorelookupDropdown { get { return Browser.Wd.FindElement(By.Id("riskScoreLookUpDrp")); } }
        public IWebElement RaftTypelookupDropdown { get { return Browser.Wd.FindElement(By.Id("raftTypeLookUpDrp")); } }
        public IWebElement CountofKnownHCClookupDropdown { get { return Browser.Wd.FindElement(By.Id("knownHccLookUpDrp_taglist")); } }
        public IWebElement PCPlookupDropdown { get { return Browser.Wd.FindElement(By.Id("pcpLookUpDrp_taglist")); } }
        public IWebElement PCPGrouplookupDropdown { get { return Browser.Wd.FindElement(By.Id("pcpGroupLookUpDrp_taglist")); } }
        public IWebElement MemberlookupDropdown { get { return Browser.Wd.FindElement(By.Id("memberLookUpDrp_taglist")); } }
        public IWebElement HCClookupResultGridHeader { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id = 'hcc-grid-dgHccLookup']//thead")); } }
        public IWebElement HCClookupBACK { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'hcc-span-back']")); } }
        public IWebElement HCClookupIcon { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'addProspectiveEvaluation-a-hcc']")); } }
        public IWebElement RiskScorelookupIcon { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'addProspectiveEvaluation-a-riskScore']")); } }
        public IWebElement RaftTypelookupIcon { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'addProspectiveEvaluation-a-raftType']")); } }
        public IWebElement CountOfKnownHCClookupIcon { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'addProspectiveEvaluation-a-perMember']")); } }
        public IWebElement PCPlookupIcon { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'addProspectiveEvaluation-a-pcp']")); } }
        public IWebElement PCPGrouplookupIcon { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'addProspectiveEvaluation-a-pcpGroup']")); } }
        public IWebElement MemberlookupIcon { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'addProspectiveEvaluation-a-member']")); } }

        public IWebElement RiskScorelookupResultGridHeader { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id = 'riskScore-grid-dgRiskScoreLookup']//thead")); } }
        public IWebElement RaftTypelookupResultGridHeader { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id = 'raftType-grid-dgRaftTypeLookup']//thead")); } }
        public IWebElement CountOfKnownHCCResultGridHeader { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id = 'knownHcc-grid-dgKnownHccLookup']//thead")); } }
        public IWebElement PCPlookupResultGridHeader { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id = 'lookup-grid-searchresult']//thead")); } }
        public IWebElement PCPGroupookupResultGridHeader { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id = 'lookup-grid-searchresult']//thead")); } }
        public IWebElement RaftTypelookupBACK { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'raftType-span-backToRecord']")); } }
        public IWebElement RiskScorelookupBACK { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'riskScore-span-backToRecord']")); } }
        public IWebElement CountKnownHCClookupBACK { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'knownHcc-span-backToRecord']")); } }
        public IWebElement PCPlookupBACK { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'pcpLookup-txt-backToRecord']")); } }
        public IWebElement PCPGrouplookupBACK { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'grouplookup-img-BackToRecord']")); } }
        public IWebElement MemberlookupBACK { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'pcpLookup-txt-backToRecord']")); } }
        public IWebElement HCCLookupListBox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'addProspectiveEvaluation-slct-hcc']")); } }
        public IWebElement CountKnownHCCLookupListBox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'addProspectiveEvaluation-slct-perMember']")); } }
        public IWebElement MemberLookupListBox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'addProspectiveEvaluation-slct-member']")); } }
        public IWebElement CountKnownHCCHCClookupDropdown { get { return Browser.Wd.FindElement(By.Id("knownHccLookUpDrp_taglist")); } } //need to be updated
        public IWebElement PCPLookupSEARCH { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'pcplookup-btn-Search']")); } }
        public IWebElement PCPGroupLookupSEARCH { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'pcplookup-btn-Search']")); } }
        public IWebElement MemberLookupSearch { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'lookup-btn-Search']")); } }
        public IWebElement searchByValue { get { return Browser.Wd.FindElement(By.XPath(".//label[@test-id = 'pcpLookup-lbl-searchBy']/following-sibling::span/span/span[1]")); } }
        public IWebElement searchBylabel { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'pcpLookup-lbl-searchBy']")); } }
        public IWebElement searchbylabel { get { return Browser.Wd.FindElement(By.XPath(".//label[@test-id = 'pcpLookup-lbl-providerLookup']/span")); } }
        public IWebElement searchbylabelMember { get { return Browser.Wd.FindElement(By.XPath(".//label[@test-id = 'lookup-lbl-txtlabel']/span")); } }
        public IWebElement LookupSearchBtnMember { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'lookup-btn-Search']")); } }
        public IWebElement LookupSearchBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'pcplookup-btn-Search']")); } }
        public IWebElement searchbyValue { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'pcpLookup-txt-searchBy']")); } }
        public IWebElement MemberExistResultGrid { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'addProspectiveEvaluation-grid-dgMemberInfo']")); } }
        public IWebElement FilterAnchor { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'searchprospectiveEvaluation-anchor']")); } }
        public IWebElement AddprojectpaymentYear { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'addProspectiveEvaluation-slct-dataSourceYear'] input")); } }
        public IWebElement PEOurput { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'prospectiveEvaluation-title-save']")); } }
        public IWebElement PESAVE { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id ='prospectiveEvaluation-btn-save']")); } }
        public IWebElement ConfirmYes { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")); } }
        public IWebElement ConfirmNO { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'confirmationDialog-btn-No']")); } }
        public IWebElement SaveConfirmDialog { get { return Browser.Wd.FindElement(By.Id("dialog")); } } //need to update
        public IWebElement InfoLookup { get { return Browser.Wd.FindElement(By.Id("dialog")); } } //need to update
        public IWebElement ProjectNameDropdownPE { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'prospectiveEvaluation-slct-projectName']")); } }
        public IWebElement DateRangeDropdownPE { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'prospectiveEvaluation-slct-evaluationDates']")); } }
        public IWebElement ViewProjectBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'prospectiveEvaluation-btn-view']")); } }
        public IWebElement InfolookCLOSEBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'gridDialog-btn-Close']")); } }
        public IWebElement InfolookUpResultGridHeader { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id='filter-grid-Dialog']//thead")); } }
        public IWebElement AssignmentsTitle { get { return Browser.Wd.FindElement(By.XPath("//div[text()='Assignments']")); } }
        public IWebElement AssignSEARCHBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'assignment-search-button']")); } }
        public IWebElement AssignSELECTBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'assignment-search-queue']")); } }
        public IWebElement AssignUPDATEBtn { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id = 'btn-batch-update-action']")); } }// need to add test-id
        public IWebElement ProjectNameDropDnAssign { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='assignment-list-project']//span[@class='k-select']")); } }
        public IWebElement EvalDateDropDnAssign { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id = 'assignment-list-projectDuration']//span[@class='k-select']")); } }
        public IWebElement ResultgridAssign { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'assignment-list-projectDuration']")); } }
        public IWebElement ResultgridDataRowsAssign { get { return Browser.Wd.FindElement(By.XPath("//div[@test-id = 'assignment-result-queuegrid']//div[2]")); } }
        public IWebElement ResultgridDataCount { get { return Browser.Wd.FindElement(By.XPath("//div[@test-id = 'assignment-result-queuegrid']//div[3]//span[contains(.,'items')]")); } }
        public IWebElement QueueDropdnAssign { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='assignment-list-queue']//span[@class='k-select']")); } }
        
        public IWebElement QueueStatusDropdnAssign { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='assignment-list-queuestatus']//span[@class='k-select']")); } }
        public IWebElement ActionDropdnAssign { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='member-list-batchUpdateAction']//span[@class='k-select']")); } }
        public IWebElement BatchUpdateGrid { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'grd-workflow-batch-update']")); } }
        public IWebElement BatchUpdateSELECTBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id = 'workflow-batch-update-btn-select']")); } }
        public IWebElement BatchUpdateGridheader { get { return Browser.Wd.FindElement(By.XPath(".//div[@test-id='grd-workflow-batch-update']/div[1]")); } }
        public IWebElement BatchUpdateGridDataRows { get { return Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='grd-workflow-batch-update']")); } }
        public IWebElement BatchUpdatePopupNextPageLink { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id='grd-workflow-batch-update']//span[text() = 'Go to the next page']")); } }
        public IWebElement BatchUpdatePopupFirstPageLink { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id='grd-workflow-batch-update']//span[text() = 'Go to the first page']")); } }
        public IWebElement QueueListBoxAssign { get { return Browser.Wd.FindElement(By.Id("drpQueue_listbox")); } }// need to add test-id
        public IWebElement AssignBatchUpdatePopUp { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='close-btn-select']")); } }// need to add test-id
        public IWebElement AssignBatchUpdatePopUp1 { get { return Browser.Wd.FindElement(By.XPath("//span[text()='Assignments Batch Update']")); } }// need to add test-id
        public IWebElement PCPLookupTextBox { get { return Browser.Wd.FindElement(By.Id("txtLookUpId")); } }// need to add test-id

    }

    [Binding]
    public class AddOnHoldReasons
    {
        public IWebElement PagenumberTextbox { get { return Browser.Wd.FindElement(By.XPath(".//input[@class='k-textbox']")); } }
        public IWebElement AddOnHoldReasonLabel { get { return Browser.Wd.FindElement(By.XPath("//div[text()='Add On Hold Reasons']")); } }
        public IWebElement AddOnHoldReasonsTextBox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id ='onHoldReasons-txt-addReason']")); } }
        public IWebElement Addbutton { get { return Browser.Wd.FindElement(By.Id("btnOnHoldReasonsSave")); } }
        public IWebElement PopupYesBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id= 'confirmationDialog-btn-Yes']")); } }
        public IWebElement PopupNoBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='confirmationDialog-btn-No']")); } }
        public IWebElement NextPage { get { return Browser.Wd.FindElement(By.XPath(".//span[contains(text(), 'Go to the next page')]")); } }

    }

    [Binding]
    public class ViewOnHoldDiagnosisCode
    {
        public IWebElement ViewonHolddiagGrid { get { return Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='viewOnHoldDiagnosis-grid-resultsGrid']//table//tbody")); } }
        public IWebElement MemberIdTxt { get { return Browser.Wd.FindElement(By.XPath(".//input[@test-id='viewOnHolDiagnosis-txt-txtMemberId']")); } }
        public IWebElement ChartIdTxt { get { return Browser.Wd.FindElement(By.XPath(".//input[@test-id='viewOnHolDiagnosis-txt-chartId']")); } }
        public IWebElement SearchButton { get { return Browser.Wd.FindElement(By.XPath(".//button[@test-id='viewOnHolDiagnosis-button-search']")); } }
        public IWebElement ApproveButton { get { return Browser.Wd.FindElement(By.XPath(".//button[@test-id='viewOnHoldDiagnosis-btn-approve']")); } }
        public IWebElement RejectButton { get { return Browser.Wd.FindElement(By.XPath(".//button[@test-id='viewOnHoldDiagnosis-btn-Reject']")); } }
        public IWebElement ApproveConfdialogYes { get { return Browser.Wd.FindElement(By.XPath(".//button[@test-id='confirmationDialog-btn-Yes']")); } }
    }

    [Binding]
    public class
        DeleteSubmittedDiagCodes
    {
        public IWebElement MemberIdLookupBtn { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='orSearchMenu']//button")); } }
        public IWebElement PrividerIdLookupBtn { get { return Browser.Wd.FindElement(By.XPath("//label[@id='lblProviderId']/parent::div//a[@test-id='deleteSubmittedDiagnosis-a-providerLookup']/i")); } }

        public IWebElement ProviderIdText { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='deleteSubmittedDiagnosis-txt-providerId']")); } }

        public IWebElement SearchButton { get { return Browser.Wd.FindElement(By.XPath(".//button[@test-id='deleteSubmittedDiagnosis-button-search']")); } }
        public IWebElement MemberIDLookupOption { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='orSearchMenu']//a[text()='Member ID']")); } }
        public IWebElement MemberIDLookupText { get { return Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='orsearch-mutisel-modeldisplay']//input")); } }
        public IWebElement FromDateofService { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='startDate']")); } }
        public IWebElement ToDateofService { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='endDatepicker']")); } }
        public IWebElement diagCode { get { return Browser.Wd.FindElement(By.XPath(".//*[@ng-model='searchCriteria.diagnosisCode']")); } }
        public IWebElement resetButton { get { return Browser.Wd.FindElement(By.XPath(".//*[@test-id='deleteSubmittedDiagnosis-button-resetSearch']")); } }
        public IWebElement ResultGrid { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='deleteSubmittedDiagnosisCodesGrid']//table/tbody")); } }
        public IWebElement MarkForDeletion { get { return Browser.Wd.FindElement(By.XPath(".//button[@test-id='deleteSubmittedDiagnosisCodes-btn-markForDelete']")); } }
        public IWebElement MarkAllForDeletion { get { return Browser.Wd.FindElement(By.XPath(".//button[@test-id='deleteSubmittedDiagnosisCodes-btn-markAllForDelete']")); } }
        public IWebElement confirmYesBtn { get { return Browser.Wd.FindElement(By.XPath(".//button[@test-id='confirmationDialog-btn-Yes']")); } }
        public IWebElement MemberLookUp { get { return Browser.Wd.FindElement(By.XPath("//div[@id='orSearchMenu']/parent::div//a[@test-id='deleteSubmittedDiagnosis-a-providerLookup']//i")); } }
        public IWebElement MemberLookUpSearchButton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='member-btn-search']")); } }
        public IWebElement AddButton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='member-btn-add']")); } }

        public IWebElement claimNumber { get { return Browser.Wd.FindElement(By.XPath("//label[@id='lblCoderId']//following-sibling::input[@test-id='deleteSubmittedDiagnosis-input-claimNumber']")); } }
        public IWebElement providerNumber { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='searchProvider-txt-ProviderID']")); } }
        public IWebElement resultsGrid { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='deleteSubmittedDiagnosisCodes-grid-resultsGrid']")); } }
        public IWebElement DeleteDiagCodeMBIInputbox { get { return Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='orsearch-mutisel-modeldisplay']//input")); } }

        public IWebElement DeleteDiagCoDeDiagnosisCodeInputbox { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='deleteSubmittedDiagnosis-label-reasonLbl']/following-sibling::input[@test-id='deleteSubmittedDiagnosis-input-claimNumber']")); } }
        
          }


    [Binding]
    public class
   RAMAuditorReview
    {
        public IWebElement AuditorReviewSearchButton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='auditorReview-btn-filesearch']")); } }
        public IWebElement FileRadioButton { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='auditorReview-radio-File']")); } }
    }

}

