﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using OpenQA.Selenium.Interactions;
namespace TMSoR1.FrameworkCode.HCC_RAM
{
    [Binding]
    class fsDeleteSubmittedDiagCode
    {

       
        [When(@"Delete submitted diag code page search button is clicked")]
        [Given(@"Delete submitted diag code page search button is clicked")]
        [Then(@"Delete submitted diag code page search button is clicked")]
        public void WhenDeleteSubmittedDiagCodePageSearchButtonIsClicked()
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(RAM.DeleteSubmittedDiagCodes.SearchButton);
            //More wait time is added as search is taking more time 
            tmsWait.Hard(120);
        }

        [When(@"Delete submitted diag code page search button is clicked and toaster message ""(.*)"" is verified")]
        public void WhenDeleteSubmittedDiagCodePageSearchButtonIsClickedAndToasterMessageIsVerified(string p0)
        {
            tmsWait.Hard(5);
            string toastmessage = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(RAM.DeleteSubmittedDiagCodes.SearchButton);
            //string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).GetAttribute("aria-label");
            //Assert.AreEqual(toastmessage, actualValue, "Toaster message is not displayed");
            By toastMsg = By.XPath("//div[@class='k-notification-content']");
            string actValue = Browser.Wd.FindElement(toastMsg).Text;
            Assert.AreEqual(toastmessage, actValue, "Toaster message is not displayed");


        }


        [When(@"Delete submitted diag code page claim Number set to ""(.*)""")]
        [Given(@"Delete submitted diag code page claim Number set to ""(.*)""")]
        [Then(@"Delete submitted diag code page claim Number set to ""(.*)""")]
        public void WhenDeleteSubmittedDiagCodePageClaimNumberSetTo(string p0)
        {
            tmsWait.Hard(3);
            string GeneratedData = tmsCommon.GenerateData(p0);
            RAM.DeleteSubmittedDiagCodes.claimNumber.Clear();
            tmsWait.Hard(1);
            RAM.DeleteSubmittedDiagCodes.claimNumber.SendKeys(GeneratedData);
            tmsWait.Hard(2);
        }

        [When(@"Delete submitted diag code page MBI set to ""(.*)""")]
        public void WhenDeleteSubmittedDiagCodePageMBISetTo(string p0)
        {
            tmsWait.Hard(3);
            string GeneratedData = tmsCommon.GenerateData(p0);
            RAM.DeleteSubmittedDiagCodes.DeleteDiagCodeMBIInputbox.Clear();
            tmsWait.Hard(1);
            RAM.DeleteSubmittedDiagCodes.DeleteDiagCodeMBIInputbox.SendKeys(GeneratedData);
            tmsWait.Hard(2);
        }


        //Gurdeep Arora
        [When(@"verify UI of Enter New Diagnosis Data page")]
        [Given(@"verify UI of Enter New Diagnosis Data page")]
        [Then(@"verify UI of Enter New Diagnosis Data page")]
        public void ThenVerifyUIOfEnterNewDiagnosisDataPage()
        {
            Assert.IsTrue(RAM.EnterNewDiagnosisCode.chartID.Displayed, "Chart ID is not displayed");
            Assert.IsTrue(RAM.EnterNewDiagnosisCode.DiagnosisCodeGrid.Displayed, "DiagnosisCodeGrid is not displayed");
            Assert.IsTrue(RAM.EnterNewDiagnosisCode.EncounterFromDate.Displayed, "EncounterFromDate is not displayed");
            Assert.IsTrue(RAM.EnterNewDiagnosisCode.EncounterToDate.Displayed, "EncounterToDate is not displayed");
            Assert.IsTrue(RAM.EnterNewDiagnosisCode.ProviderIDTextbox.Displayed, "ProviderIDTextbox is not displayed");
            Assert.IsTrue(RAM.EnterNewDiagnosticDataPage.OnHoldCheckbox.Displayed, "OnHoldCheckBox is not displayed");
            // Assert.IsTrue(RAM.EnterNewDiagnosisCode.OnHoldReason.Displayed, "OnHoldReason is not displayed");
            Assert.IsTrue(RAM.EnterNewDiagnosticDataPage.OnHoldReasonDrpdownlist.Displayed, "OnHoldReasonlistbox is not displayed");
            Assert.IsTrue(RAM.EnterNewDiagnosisCode.DiagCodegrTextbox.Displayed, "DiagCode Textbox is not displayed");
            Assert.IsTrue(RAM.EnterNewDiagnosisCode.TypeofServiceDropdown.Displayed, "TypeOfService Dropdown is not displayed");
            Assert.IsTrue(RAM.EnterNewDiagnosisCode.riskAssessmentDropdown.Displayed, "RiskAssessment Dropdown is not displayed");
            //Assert.IsTrue(RAM.EnterNewDiagnosisCode.ClaimIDgrid.Displayed, "Claim Number Dropdown is not displayed");
            Assert.IsTrue(RAM.EnterNewDiagnosisCode.coderIDropdown.Displayed, "CoderID Dropdown is not displayed");
            Assert.IsTrue(RAM.EnterNewDiagnosisCode.chartReviewSourceDDL.Displayed, "Chart Review Source Dropdown is not displayed");
            Assert.IsTrue(RAM.EnterNewDiagnosisCode.SaveBtngrid.Displayed, "RiskAssessment Dropdown is not displayed");
            Assert.IsTrue(RAM.EnterNewDiagnosisCode.saveAndReplicateBtnAddDiagCode.Displayed, "RiskAssessment Dropdown is not displayed");

        }

        //Gurdeep Arora
        [When(@"verify UI of Enter New Diagnosis Data - Landing page")]
        public void WhenVerifyUIOfEnterNewDiagnosisData_LandingPage()
        {
            Assert.AreEqual("Enter New Diagnosis Data", RAM.EnterNewDiagnosticDataPage.title.Text, "Page Title is incorrect");
            Assert.IsTrue(RAM.EnterNewDiagnosticDataPage.resetButton.Displayed, "Reset button is not displayed");

        }

        //Gurdeep Arora
        [When(@"I click on member lookup button and verify UI of Search Member page")]
        public void WhenIClickOnMemberLookupButtonAndVerifyUIOfSearchMemberPage()
        {
            fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.MemberIDLookup);
            tmsWait.Hard(1);
            Assert.IsTrue(RAM.EnterNewDiagnosticDataPage.memberFirstName.Displayed, "Member First Name Text Box is not displayed");
            Assert.IsTrue(RAM.EnterNewDiagnosticDataPage.memberLastName.Displayed, "Member Last Name Text Box is not displayed");
            Assert.IsTrue(RAM.EnterNewDiagnosticDataPage.memberDOB.Displayed, "Member DOB Name Text Box is not displayed");
            Assert.IsTrue(RAM.EnterNewDiagnosticDataPage.searchMemberResetButton.Displayed, "Reset Button is not displayed");
            Assert.IsTrue(Suspects.EnterNewDiagnosisCode.MemberLookupTable.Displayed, "Member search results grid not displayed");
            fw.ExecuteJavascript(Suspects.EnterNewDiagnosisCode.memberLookupCancelBtn);
            tmsWait.Hard(5);
        }
      
        [When(@"verify UI of Search Member page")]
        public void WhenVerifyUIOfSearchMemberPage()
        {
            
        }



        [Then(@"Verify Delete submitted diag code result grid having diag code ""(.*)"" and diag source ""(.*)""")]
        public void ThenVerifyDeleteSubmittedDiagCodeResultGridHavingDiagCodeAndDiagSource(string dcode, string dsource)
        {
            //string diagcode = dcode.ToString();
            string GeneratedData = tmsCommon.GenerateData(dcode);
            Boolean isexist =false;
            IReadOnlyCollection<IWebElement> allrows = RAM.DeleteSubmittedDiagCodes.ResultGrid.FindElements(By.TagName("tr"));
            foreach (var row in allrows)
            {
                IWebElement actualdcode= row.FindElement(By.XPath("td[8]/span"));
                IWebElement actualdsource = row.FindElement(By.XPath("td[9]/span"));
                if(actualdcode.Text== dcode.ToString() && actualdsource.Text== dsource)
                {
                    GlobalRef.HICN= row.FindElement(By.XPath("td[5]/span")).Text;
                    string myss = GlobalRef.HICN.ToString();
                    isexist = true;
                    break;
                }
                
             }
            Assert.IsTrue(isexist);
        }

        [When(@"Delete submitted diag code page Member ID is set to ""(.*)""")]
        public void WhenDeleteSubmittedDiagCodePageMemberIDIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string memID = tmsCommon.GenerateData(p0);
            RAM.DeleteSubmittedDiagCodes.MemberIDLookupText.Clear();
            RAM.DeleteSubmittedDiagCodes.MemberIDLookupText.SendKeys(memID);
            tmsWait.Hard(1);
            RAM.DeleteSubmittedDiagCodes.MemberIDLookupText.SendKeys(Keys.Enter);

        }


        [Then(@"verify UI features of Delete Submitted Diag Codes page")]
        public void ThenVerifyUIFeaturesOfDeleteSubmittedDiagCodesPage()
        {
            Assert.IsTrue(RAM.DeleteSubmittedDiagCodes.claimNumber.Displayed, "ClaimNumber text box is not displayed");
            Assert.IsTrue(RAM.DeleteSubmittedDiagCodes.ProviderIdText.Displayed, "Provider ID text box is not displayed");
            Assert.IsTrue(RAM.DeleteSubmittedDiagCodes.DeleteDiagCodeMBIInputbox.Displayed, "MBI text box is not displayed");
           //Assert.IsTrue(RAM.DeleteSubmittedDiagCodes.FromDateofService.Displayed, "From Date of Service text box is not displayed");
            //Assert.IsTrue(RAM.DeleteSubmittedDiagCodes.ToDateofService.Displayed, "To Date of Service text box is not displayed");

            //Assert.IsTrue(RAM.DeleteSubmittedDiagCodes.ResultGrid.Displayed, "ClaimNumber text box is not displayed");

         }



        [Then(@"verify Advanced Search options are disabled")]
        public void ThenVerifyAdvancedSearchOptionsAreDisabled()
        {
            //Assert.IsFalse(RAM.DeleteSubmittedDiagCodes.FromDateofService.Enabled, "FromDateofService text box in NOT disabled");
            //Assert.IsFalse(RAM.DeleteSubmittedDiagCodes.ToDateofService.Enabled, "ToDateofService text box in NOT disabled");
            //Assert.IsFalse(RAM.DeleteSubmittedDiagCodes.diagCode.Enabled, "Diagnosis Code text box in NOT disabled");
            
            bool flagfromdateofservice = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='onHoldDiagnosis-txt-startDate']//span/input")).Enabled;
            bool flagTodateofservice = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='onHoldDiagnosis-txt-startDate']//span/input")).Enabled;
            Assert.IsFalse(flagfromdateofservice, "From Date of Service text box is not displayed");
            Assert.IsFalse(flagTodateofservice, "To Date of Service text box is not displayed");
            Assert.IsFalse(RAM.DeleteSubmittedDiagCodes.DeleteDiagCoDeDiagnosisCodeInputbox.Enabled, "Diagnosis Code text box is not displayed");

        }

        [When(@"Delete Submitted Diag Codes Table grid ""(.*)"" and ""(.*)"" are noted")]
        public void WhenDeleteSubmittedDiagCodesTableGridAndAreNoted(string encounter, string payment)
        {
            string encounterDate = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='deleteSubmittedDiagnosisCodes-grid-resultsGrid']//tbody/tr[1]/td[@aria-colindex='7']")).Text;
            fw.setVariable(encounter, encounterDate);

            string paymentyear = (Int32.Parse((encounterDate.Split("/"))[2])+1).ToString();

            fw.setVariable(payment, paymentyear);
        }

        [When(@"Delete Submitted Diag Codes Table grid ""(.*)"" are marked for Deletion")]
        public void WhenDeleteSubmittedDiagCodesTableGridAreMarkedForDeletion(string p0)
        {
            tmsWait.Hard(2);
            string clmNum = tmsCommon.GenerateData(p0);
            By ele = By.XPath("//kendo-grid[@test-id='deleteSubmittedDiagnosisCodes-grid-resultsGrid']//td[contains(.,'"+ clmNum + "')]/preceding-sibling::td/input");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(ele);
        }


        [When(@"Delete submitted result grid page diag code with diag source ""(.*)"" is selected and EncounterFrom Date ""(.*)"" Diag Code ""(.*)"" and Member Id ""(.*)"" is noted")]
        [Then(@"Delete submitted result grid page diag code with diag source ""(.*)"" is selected and EncounterFrom Date ""(.*)"" Diag Code ""(.*)"" and Member Id ""(.*)"" is noted")]
        public void ThenDeleteSubmittedResultGridPageDiagCodeWithDiagSourceIsSelectedAndEncounterFromDateDiagCodeAndMemberIdIsNoted(string p0, string p1, string p2, string p3)
        {
            tmsWait.Hard(3);
            string expDiagSource = tmsCommon.GenerateData(p0);
            IReadOnlyCollection<IWebElement> allrows = RAM.DeleteSubmittedDiagCodes.ResultGrid.FindElements(By.TagName("tr"));
            string actualMemberID;
            string actualDiagCode;
            string actualEncounterFromDate;
            foreach (var row in allrows)
            {
                IWebElement checkbox = row.FindElement(By.XPath("//td[1]/input"));
                IWebElement actualDiagSource = row.FindElement(By.XPath("//td[10]"));
                actualMemberID = row.FindElement(By.XPath("//td[4]")).Text;
                actualDiagCode = row.FindElement(By.XPath("//td[9]")).Text;
                actualEncounterFromDate = row.FindElement(By.XPath("//td[7]")).Text;
                if (expDiagSource == actualDiagSource.Text)
                {
                    fw.ExecuteJavascript(checkbox);
                    fw.setVariable(p1, actualEncounterFromDate);
                    fw.setVariable(p2, actualDiagCode);
                    fw.setVariable(p3, actualMemberID);
                    break;
                }
            }
        }


        [Then(@"Delete submitted result grid page diag code with diag source ""(.*)"" is selected and Member Id ""(.*)"" is noted")]
        public void ThenDeleteSubmittedResultGridPageDiagCodeWithDiagSourceIsSelectedAndMemberIdIsNoted(string p0, string p1)
        {
            string expDiagSource = tmsCommon.GenerateData(p0);
            IReadOnlyCollection<IWebElement> allrows = RAM.DeleteSubmittedDiagCodes.ResultGrid.FindElements(By.TagName("tr"));
            string actualMemberID;
            string actualDiagCode;
            foreach (var row in allrows)
            {
                IWebElement checkbox = row.FindElement(By.XPath("td[1]/input"));
                IWebElement actualDiagSource = row.FindElement(By.XPath("td[10]/span"));
                actualMemberID = row.FindElement(By.XPath("td[4]/span")).Text;
                if (expDiagSource == actualDiagSource.Text)
                {
                    fw.ExecuteJavascript(checkbox);
                    fw.setVariable(p1, actualMemberID);
                    break;
                }
            }
        }

        [When(@"variable ""(.*)"" is set to a valid value from ramx database")]
        public void WhenVariableIsSetToAValidValueFromRamxDatabase(string var)
        {
            string DBName = "FileNameQuery";
            db.CreateConnRAMX(DBName);
            string CurrentYear = tmsCommon.GenerateData("Generate|current");

            int i = 0;
            while (i <= 5)
            {
                string query = tmsCommon.GenerateData("select count(revenue) from [RAMX].[dbo].tbExceptionLetters te join [RAMX].[dbo].vuMembersYearlyPlan tc on te.bntmemberid=tc.bntMemberId where te.intstatus in (-1,0, 8,9) and revenue is not null and tc.PaymentYear='" + CurrentYear + "'");
                db.AddDBQuery(DBName, query);
                string result = db.StoreDBResultsInString(DBName);
                if (result == "0")
                {
                    i++;

                    CurrentYear = tmsCommon.GenerateData("Generate|current-" + i + "");
                }
                else
                {
                    fw.setVariable(var, CurrentYear);
                    break;
                }
            }
        }


        [Then(@"Delete submitted result grid page diag code with diag source ""(.*)"" is selected")]
        public void ThenDeleteSubmittedResultGridPageDiagCodeWithDiagSourceIsSelected(string p0)
        {
           
        }


        [When(@"Delete submitted result grid page diag code ""(.*)"" is selected")]
        public void WhenDeleteSubmittedResultGridPageDiagCodeIsSelected(string dcode)
        {
            string GeneratedData = tmsCommon.GenerateData(dcode);
            IReadOnlyCollection<IWebElement> allrows = RAM.DeleteSubmittedDiagCodes.ResultGrid.FindElements(By.TagName("tr"));
            foreach (var row in allrows)
            {
                IWebElement checkdiagcode = row.FindElement(By.XPath("td[1]/input"));
                IWebElement actualdcode = row.FindElement(By.XPath("td[8]/span"));
                if (GeneratedData == actualdcode.Text)
                {
                    fw.ExecuteJavascript(checkdiagcode);
                    break;
                }
               
            }
        }

        [When(@"Delete submitted diag code page mark for deletion button is clicked")]
        public void WhenDeleteSubmittedDiagCodePageMarkForDeletionButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.DeleteSubmittedDiagCodes.MarkForDeletion);
            fw.ExecuteJavascript(RAM.DeleteSubmittedDiagCodes.confirmYesBtn);

        }

        [When(@"Delete submitted diag code page mark for deletion button is clicked and toaster message is displayed ""(.*)""")]
        public void WhenDeleteSubmittedDiagCodePageMarkForDeletionButtonIsClickedAndToasterMessageIsDisplayed(string p0)
        {
            string toastmessage = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(RAM.DeleteSubmittedDiagCodes.MarkForDeletion);
        }


        [When(@"Delete submitted diag code page mark all for deletion button is clicked and toaster message is displayed ""(.*)""")]
        public void WhenDeleteSubmittedDiagCodePageMarkAllForDeletionButtonIsClickedAndToasterMessageIsDisplayed(string p0)
        {
            tmsWait.Hard(8);
            string toastmessage = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(RAM.DeleteSubmittedDiagCodes.MarkAllForDeletion);
            //string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).GetAttribute("aria-label");
            //tmsWait.Hard(2);
            //Assert.IsTrue(actualValue.Contains(toastmessage), "Message is not displayed");
            //tmsWait.Hard(2);
        }


        [Then(@"verify CMS extract file has deleted writein diag code ""(.*)""")]
        public void ThenVerifyCMSExtractFileHasDeletedWriteinDiagCode(int writeincode)
        {

            string filename = "";
            Boolean isexist = false;
            IReadOnlyCollection<IWebElement> allrows = Browser.Wd.FindElements(By.XPath(".//*[@id='fileProcessStatusGrid']//table//tbody/tr"));
            foreach(var row in allrows)
            {
                string extractname = Browser.Wd.FindElement(By.XPath("//td[4]/span")).Text;
                if (extractname== "CMS Extract")
                {
                    filename = Browser.Wd.FindElement(By.XPath("//td[3]//span")).Text;
                    break;
                }
            }
            string[] appserver = ConfigFile.URL.Split('.');
            string downloadPath = "\\\\" + appserver[1] + "\\TMSSharedFolder\\TMS-QA\\RAM\\output\\"+filename+"";
              //string downloadPath = "\\\\" + appserver[1] + "\\TMSSharedFolder\\TMS-QA\\RAM\\output\\94_cms.txt";
            var readData = ReadFileFunctions.ReadTEXTFile(downloadPath);
            foreach(var rrow in readData)
            {
                // string [] my = rrow.Split(' ');
                string hicin = rrow.Substring(85, 10);
                string actualhicin = GlobalRef.HICN.ToString();
               
                if (hicin== actualhicin)
                //if (hicin == "HICN055676")
                {
                    string deleteindicator = rrow.Substring(68, 1);
                    string deleteddiagcode = rrow.Substring(118, 5);
                    if(deleteindicator=="D" && deleteddiagcode.Trim() == writeincode.ToString())
                    {
                        isexist = true;
                        break;
                    }
                }

            }
            Assert.IsTrue(isexist);
        }



        [When(@"Enter New Diagnosis Data Member Id is set to ""(.*)""")]
        public void WhenEnterNewDiagnosisDataMemberIdIsSetTo(string memid)

        {
            tmsWait.Hard(2);
            string GeneratedData = tmsCommon.GenerateData(memid);
            Suspects.EnterNewDiagnosisCode.MemberIDLookuptxtbox.SendKeys(GeneratedData);
            Suspects.EnterNewDiagnosisCode.MemberIDLookuptxtbox.SendKeys(Keys.Enter);
            tmsWait.Hard(2);
        }

        [When(@"variable ""(.*)"" was set to a value for the member")]
        public void WhenVariableWasSetToAValueForTheMember(string p0)
        {
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@test-id='searchDiag-grid-member']//div[2]//tbody/tr[1]/td[1]/span"));
            fw.setVariable(p0, ele.Text.ToString());
        }


        [When(@"Delete submitted diag code page MBI Look up is clicked")]
        public void WhenDeleteSubmittedDiagCodePageMBILookUpIsClicked()
        {
            fw.ExecuteJavascript(RAM.DeleteSubmittedDiagCodes.MemberLookUp);
        }

        [When(@"Delete submitted diag code page MBI Look up page Search button is clicked")]
        public void WhenDeleteSubmittedDiagCodePageMBILookUpPageSearchButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.DeleteSubmittedDiagCodes.MemberLookUpSearchButton);
            tmsWait.Hard(2);
        }



        [When(@"Delete submitted diag code page MBI Look up multiple records selected")]
        public void WhenDeleteSubmittedDiagCodePageMBILookUpMultipleRecordsSelected()
        {
            
            string MemberIDs="" ;
            for (int i = 3; i < 6; i++)
            {
                string xpath_record = "//kendo-grid[@test-id='member-grid-auditslist']//table[@role='presentation']//tr[" + i + "]//td[1]//input";
                string xpath_selected_record_MBIID = "//kendo-grid[@test-id='member-grid-auditslist']//table[@role='presentation']//tr[" + i + "]//td[3]";
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(xpath_record)));
                string data = Browser.Wd.FindElement(By.XPath(xpath_selected_record_MBIID)).Text;

                if (!MemberIDs.Contains(data))
                    {
                        MemberIDs = MemberIDs + data + "|";
                    }
               
            }

            // GeneratedUserID = tmsCommon.GenerateData(MemberIDs);
            fw.setVariable("MemberIDs", MemberIDs);

        }


       
        [When(@"Delete submitted diag code page Member Look up is clicked")]
        public void WhenDeleteSubmittedDiagCodePageMemberLookUpIsClicked()
        {
            fw.ExecuteJavascript(RAM.DeleteSubmittedDiagCodes.MemberLookUp);
        }

        [When(@"Delete submitted diag code page Member Look up page Search button is clicked")]
        public void WhenDeleteSubmittedDiagCodePageMemberLookUpPageSearchButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.DeleteSubmittedDiagCodes.MemberLookUpSearchButton);
            tmsWait.Hard(5);
        }

        [When(@"Delete submitted diag code page Member Look up multiple records selected")]
        public void WhenDeleteSubmittedDiagCodePageMemberLookUpMultipleRecordsSelected()
        {
            IWebElement NextButton = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
            fw.ExecuteJavascript(NextButton);
            string MemberIDs = null ;
            for (int i = 3; i < 6; i++)
            {
                string xpath_record = "//kendo-grid[@test-id='member-grid-auditslist']//table[@role='presentation']//tr[" + i+"]//td[1]//input";
                string xpath_selected_record_MemberID = "//kendo-grid[@test-id='member-grid-auditslist']//table[@role='presentation']//tr[" + i+"]//td[4]";
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(xpath_record)));
                string data=Browser.Wd.FindElement(By.XPath(xpath_selected_record_MemberID)).Text;
                MemberIDs = MemberIDs+data + "|";

            }

           // GeneratedUserID = tmsCommon.GenerateData(MemberIDs);
            fw.setVariable("MemberIDs", MemberIDs);

        }

        [When(@"Delete submitted diag code page ""(.*)"" option is selected")]
        public void WhenDeleteSubmittedDiagCodePageOptionIsSelected(string p0)
        {
            fw.ExecuteJavascript(RAM.DeleteSubmittedDiagCodes.MemberIdLookupBtn);
            tmsWait.Hard(2);
            IWebElement lookupoption = Browser.Wd.FindElement(By.XPath(".//li[contains(.,'" + p0 + "')]"));
            fw.ExecuteJavascript(lookupoption);
            tmsWait.Hard(1);
        }

        [When(@"Delete submitted diag code page ""(.*)"" option is entered as ""(.*)""")]
        public void WhenDeleteSubmittedDiagCodePageOptionIsEnteredAs(string p0, string p1)
        {
            fw.ExecuteJavascript(RAM.DeleteSubmittedDiagCodes.MemberIdLookupBtn);
            tmsWait.Hard(2);
            IWebElement lookupoption = Browser.Wd.FindElement(By.XPath(".//li[contains(.,'" + p0 + "')]"));
            fw.ExecuteJavascript(lookupoption);
            tmsWait.Hard(1);

            string memID = tmsCommon.GenerateData(p1);
            RAM.DeleteSubmittedDiagCodes.MemberIDLookupText.Clear();
            RAM.DeleteSubmittedDiagCodes.MemberIDLookupText.SendKeys(memID);
            tmsWait.Hard(1);
            RAM.DeleteSubmittedDiagCodes.MemberIDLookupText.SendKeys(Keys.Enter);
            RAM.DeleteSubmittedDiagCodes.MemberIDLookupText.SendKeys(Keys.Tab);
        }


        [When(@"Delete submitted diag code page Provider Look up is clicked")]
        public void WhenDeleteSubmittedDiagCodePageProviderLookUpIsClicked()
        {
            fw.ExecuteJavascript(RAM.DeleteSubmittedDiagCodes.PrividerIdLookupBtn);
        }

        [Then(@"Verify that Advance Search section is disabled")]
        public void ThenVerifyThatAdvanceSearchSectionIsDisabled()
        {
            IWebElement StartDate = Browser.Wd.FindElement(By.XPath("//input[@test-id='onHoldDiagnosis-txt-startDate']"));
            IWebElement EndtDate = Browser.Wd.FindElement(By.XPath("//input[@test-id='onHoldDiagnosis-txt-endDate']"));
            IWebElement claimNumber = Browser.Wd.FindElement(By.XPath("//input[@test-id='deleteSubmittedDiagnosis-input-claimNumber']"));
            Assert.IsFalse(StartDate.Enabled,"Start date is enabled even non of mandetory option is selected");
            Assert.IsFalse(EndtDate.Enabled, "End date is enabled even non of mandetory option is selected");
            Assert.IsFalse(claimNumber.Enabled, "claimNumber is enabled even non of mandetory option is selected");

        }

     

        [When(@"Delete submitted diag code page Provider Look up page ""(.*)"" enter")]
        public void WhenDeleteSubmittedDiagCodePageProviderLookUpPageEnter(string p0)
        {
            tmsWait.Hard(3);
            string GeneratedData = tmsCommon.GenerateData(p0);
            RAM.DeleteSubmittedDiagCodes.providerNumber.SendKeys(GeneratedData);
        }


        [When(@"Delete submitted diag code page Provider Look up page Search button is clicked")]
        public void WhenDeleteSubmittedDiagCodePageProviderLookUpPageSearchButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.RAMReportPage.ProviderLookupSearchButton);
            tmsWait.Hard(5);
        }


        [When(@"Delete submitted diag code page Provider Look up page record ""(.*)"" is selected")]
        public void WhenDeleteSubmittedDiagCodePageProviderLookUpPageRecordIsSelected(string p0)
        {
            string provID = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='searchMember-grid-providerLookup']//tr[contains(.,'" + provID + "')]/td/following-sibling::td//button")));
        }

        [When(@"Delete submitted diag code page back button is clicked")]
        public void WhenDeleteSubmittedDiagCodePageBackButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.RAMReportPage.BackProviderLookupButton);
        }



        [Then(@"Verify Delete submitted diag code result grid having diag code only for selected MemberID")]
        public void ThenVerifyDeleteSubmittedDiagCodeResultGridHavingDiagCodeOnlyForSelectedMemberID()
        {
            tmsWait.Hard(5);
            string GeneratedData = tmsCommon.GenerateData("Generate|variable|MemberIDs");
            string[] MemeberIDs = GeneratedData.Split('|');

            for (int i= 0; i <= MemeberIDs.Length-2; i++)
            {
                 KendoUIFunctions.ResultGridTextValidation(MemeberIDs[i]);
               
            }
        }

        [Then(@"Verify Delete submitted diag code result grid having diag code only for selected ""(.*)""")]
        public void ThenVerifyDeleteSubmittedDiagCodeResultGridHavingDiagCodeOnlyForSelected(string p0)
        {
            tmsWait.Hard(5);
            string GeneratedData = tmsCommon.GenerateData(p0);
            KendoUIFunctions.ResultGridTextValidation(GeneratedData);
        }



        [When(@"Delete submitted diag code page Add  button is clicked")]
        public void WhenDeleteSubmittedDiagCodePageAddButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.DeleteSubmittedDiagCodes.AddButton);
        }


        [Then(@"Result grid Table has row")]
        public void ThenResultGridTableHasRow(Table table)
        {
            Exception thisE = null;
            Boolean bSuccess = false;
            int iCt = 0;
            while (iCt < 5 && !bSuccess)
            {
                iCt++;
                try
                {
                    IWebElement objWebTable = RAM.DeleteSubmittedDiagCodes.resultsGrid;
                    Console.WriteLine("Input data row: [" + table.ToString() + "]");

                    String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                    for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                    {
                        int index = 0;
                        if (int.TryParse(arrRes[i, 0], out index))
                        {
                            if (index < 0)
                            {
                                Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                            }
                        }
                    }
                    bSuccess = true;
                }
                catch (Exception e)
                {
                    thisE = e;
                    Console.WriteLine("Failed trying to hit found hic lookup [" + iCt + "]");
                }
            }
            if (!bSuccess)
            {
                Assert.Fail("Result grid Table has row: {0}", thisE.Message);

            }
        }
    }




}
