﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using OpenQA.Selenium.Interactions;

namespace TMSoR1.FrameworkCode.HCC_RAM
{
    [Binding]
    class fsAddOnHoldReasons
    {

        [When(@"AddOnHoldReason get the count of total onhold reasons")]
        public void WhenAddOnHoldReasonGetTheCountOfTotalOnholdReason()
        {
            tmsWait.Hard(4);
            string ReasonCountText = Browser.Wd.FindElement(By.XPath("//kendo-pager-info[contains(text(), '1 -')]")).Text;
            string[] Reasoncollection = ReasonCountText.Split(' ');
            for(int i=0; i<Reasoncollection.Length;i++)
            {
                Reasoncollection[i] = Reasoncollection[i].Trim();
            }
           GlobalRef.TotalReasonCount = Reasoncollection[4];
        }

        [When(@"AddOnHoldReasons Reasons is set to ""(.*)""")]
        public void WhenAddOnHoldReasonsReasonsIsSetTo(string NewReason)
        {
            string addreasontext = tmsCommon.GenerateData(NewReason);
            RAM.AddOnHoldReasons.AddOnHoldReasonsTextBox.SendKeys(addreasontext);
            tmsWait.Hard(2);
        }

        [When(@"AddOnHoldReason Add button is clicked")]
        public void WhenAddOnHoldReasonAddButtonIsClicked()
        {
            fw.ExecuteJavascript(RAM.AddOnHoldReasons.Addbutton);
            tmsWait.Hard(1);
            
        }
        [Then(@"Verify OnHoldReason ""(.*)"" is displayed in the grid and ""(.*)""")]
        public void ThenVerifyOnHoldReasonIsDisplayedInTheGridAnd(string p0, string p1)
        {
           
            string reasontext = tmsCommon.GenerateData(p0);
            string status = tmsCommon.GenerateData(p1);
           // KendoUIFunctions.ResultGridTextValidation(reasontext);
            KendoUIFunctions.ResultGridTextValidationWithStatus(reasontext,status);
        }

        [When(@"AddOnHoldReason Warningdialog ""(.*)"" button is clicked")]
        public void WhenAddOnHoldReasonWarningdialogButtonIsClicked(string inputaction)
        {
            string button = inputaction.ToString();

            try
            {
                if (button.Equals("Yes"))
                {
                    fw.ExecuteJavascript(RAM.AddOnHoldReasons.PopupYesBtn);
                }

                else if (button.Equals("No"))
                {
                    tmsWait.Hard(2);
                    fw.ExecuteJavascript(RAM.AddOnHoldReasons.PopupNoBtn);
                }
                tmsWait.Hard(2);
            }

            catch
            {
                fw.ConsoleReport("There is no Alert");
            }
        }

        [Then(@"Verify message ""(.*)""")]
        public void ThenVerifyMessage(string toastmessage)
        {

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By toastMsg = By.XPath("//div[@class='k-notification-content']");
                string actValue = Browser.Wd.FindElement(toastMsg).Text;
                //Console.WriteLine(actValue);
                Assert.IsTrue(actValue.Contains(toastmessage));
            }
            else
            {
                tmsWait.Hard(1);
                string expectedvalue = toastmessage.ToString();
                string actualvalue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                Assert.IsTrue(actualvalue.Contains(toastmessage), "Message is not displayed");

            }
        }

        [Then(@"toaster message is displayed ""(.*)""")]
        public void ThenToasterMessageIsDisplayed(string toastmessage)
        {
            //string expectedvalue = toastmessage.ToString();
            //string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).GetAttribute("aria-label");
            //Assert.IsTrue(actualValue.Contains(toastmessage), "Message is not displayed");
        }


        [Then(@"AddOnHoldReason ""(.*)"" is set to ""(.*)""")]
        public void ThenAddOnHoldReasonIsSetTo(string p0, string p1)
        {
            string reasontext = tmsCommon.GenerateData(p0);
            string status = tmsCommon.GenerateData(p1);

            //KendoUIFunctions.ResultGridTextValidation(reasontext);
            KendoUIFunctions.ResultGridDoCheckUncheck(reasontext,status);
        }
        [Then(@"Verify OnHoldReason ""(.*)"" is displayed in the grid with checkbox checked")]
        public void ThenVerifyOnHoldReasonIsDisplayedInTheGridWithCheckboxChecked(string p0)
        {
            

        string reasontext = tmsCommon.GenerateData(p0);

            KendoUIFunctions.ResultGridTextValidation(reasontext);
            IWebElement checkbox = Browser.Wd.FindElement(By.XPath("//td[.='"+ reasontext+ "']/preceding-sibling::td/input"));
            string selected = checkbox.GetAttribute("checked");

            Assert.IsTrue(selected.Equals("true"));

        }


        [Then(@"Verify OnHoldReason ""(.*)"" is displayed in the grid")]
        public void ThenVerifyOnHoldReasonIsDisplayedInTheGrid(string AddedReason)
        {
            string reasontext = tmsCommon.GenerateData(AddedReason);
            KendoUIFunctions.ResultGridTextValidation(reasontext);
            

            //  Please avoid the complex and try to write more unque function which can be re usable.
            //int Treasons = Convert.ToInt32(GlobalRef.TotalReasonCount);
            //if(Treasons<20 && Treasons>=10)
            //{
            //    //RAM.AddOnHoldReasons.PagenumberTextbox.Clear();
            //    //RAM.AddOnHoldReasons.PagenumberTextbox.SendKeys("2");
            //    //Actions builder = new Actions(Browser.Wd);
            //    //builder.SendKeys(Keys.Enter);
            //    fw.ExecuteJavascript(RAM.AddOnHoldReasons.NextPage);


            //}
            //else if(Treasons < 30 && Treasons >= 20)
            //{
            //    fw.ExecuteJavascript(RAM.AddOnHoldReasons.NextPage);
            //    tmsWait.Hard(1);
            //    fw.ExecuteJavascript(RAM.AddOnHoldReasons.NextPage);
            //    //RAM.AddOnHoldReasons.PagenumberTextbox.SendKeys("3");
            //    //Actions builder = new Actions(Browser.Wd);
            //    //builder.SendKeys(Keys.Enter);
            //}
            //else if (Treasons < 40 && Treasons >= 30)
            //{
            //    //RAM.AddOnHoldReasons.PagenumberTextbox.SendKeys("3");
            //    //Actions builder = new Actions(Browser.Wd);
            //    //builder.SendKeys(Keys.Enter);
            //    fw.ExecuteJavascript(RAM.AddOnHoldReasons.NextPage);
            //    tmsWait.Hard(1);
            //    fw.ExecuteJavascript(RAM.AddOnHoldReasons.NextPage);
            //    tmsWait.Hard(1);
            //    fw.ExecuteJavascript(RAM.AddOnHoldReasons.NextPage);
            //}


            //IWebElement ListOfOnHoldReason = Browser.Wd.FindElement(By.XPath(".//table[@role='grid']/tbody"));
            //IReadOnlyCollection <IWebElement> allRows = ListOfOnHoldReason.FindElements(By.TagName("tr"));
            //allRows.Count();
            //Boolean IsSame = false;
            //foreach (var row in allRows)
            //{
            //    string mydata = row.FindElement(By.XPath("td[3]/span")).Text;
            //    if(mydata.Equals(reasontext))
            //    {
            //        IsSame = true;
            //        break;
            //    }
            //}
            //Assert.IsTrue(IsSame);
        }
        //[When(@"AddOnHoldReason Edit icon is clicked for Reason ""(.*)""")]
        //public void WhenAddOnHoldReasonEditIconIsClickedForReason(string AddedReason)
        //{
        //    string reasontext = tmsCommon.GenerateData(AddedReason);
        //    IReadOnlyCollection<IWebElement> allrows = RAM.AddOnHoldReasons.ListOfOnHoldReason.FindElements(By.TagName("tr"));
        //   // Boolean Rsame = false;
        //    foreach(var row in allrows)
        //    {
        //        string myreason = row.FindElement(By.XPath("td[3]/span")).Text;
        //        if(myreason.Equals(reasontext))
        //        {
        //            IWebElement clickreason = row.FindElement(By.XPath("td[5]/a"));
        //            fw.ExecuteJavascript(clickreason);
        //            break;
        //        }
        //    }
        //}

        [When(@"AddOnHoldReason Update Description for Reason ""(.*)"" to ""(.*)""")]
        [Then(@"AddOnHoldReason Update Description for Reason ""(.*)"" to ""(.*)""")]
        public void WhenAddOnHoldReasonUpdateDescriptionForReasonTo(string AddedReason, string UpdatedReason)
        {
            string actualCode = tmsCommon.GenerateData(AddedReason);
            string actualDescription = tmsCommon.GenerateData(UpdatedReason);

            KendoUIFunctions.ResultGridTextValidation(actualCode);
            KendoUIFunctions.EditAndUpdateResultGridRecord(actualCode, actualDescription);


            //IWebElement ListOfOnHoldReason = Browser.Wd.FindElement(By.XPath(".//table[@role='grid']/tbody"));
            //IReadOnlyCollection<IWebElement> allrows = ListOfOnHoldReason.FindElements(By.TagName("tr"));
            //// Boolean Rsame = false;
            
            //foreach (var row in allrows)
            //{

            //    string myreason = row.FindElement(By.XPath("td[3]/span")).Text;
            //    if (myreason.Equals(reasontext))
            //    {
            //        IWebElement clickreason = row.FindElement(By.XPath("td[5]/a"));
            //        fw.ExecuteJavascript(clickreason);
            //        IWebElement newreason = row.FindElement(By.XPath("td[3]/input"));
            //        newreason.Clear();
            //        newreason.SendKeys(ureasontext);
            //        IWebElement savereason = row.FindElement(By.XPath("td[5]/a"));
            //        savereason.Click();
            //        break;
            //    }
            //}
        }
      
        [Then(@"AddOnHoldReason Update Description for Reason ""(.*)"" to ""(.*)"" And message varified")]
        public void ThenAddOnHoldReasonUpdateDescriptionForReasonToAndMessageVarified(string AddedReason, string UpdatedReason)
        {
           
        string actualCode = tmsCommon.GenerateData(AddedReason);
            string actualDescription = tmsCommon.GenerateData(UpdatedReason);

            KendoUIFunctions.ResultGridTextValidation(actualCode);
            KendoUIFunctions.EditAndUpdateResultGridRecord(actualCode, actualDescription);
            //string p2 = "On hold reason updated successfully";
            //By toastMsg = By.XPath("//div[@class='k-notification-content']");
            //string actualvalue = Browser.Wd.FindElement(toastMsg).Text;
            //string expectedvalue = p2.ToString();
            //Assert.IsTrue(actualvalue.Contains(expectedvalue), "Message is displayed successfully");
        }

        [When(@"AddOnHoldReason page mark ""(.*)"" checkbox is ""(.*)""")]
        public void WhenAddOnHoldReasonPageMarkCheckboxIs(string p0, string p1)
        {
            tmsWait.Hard(2);
            string reason = tmsCommon.GenerateData(p0);
            string action = tmsCommon.GenerateData(p1);

            IWebElement element = Browser.Wd.FindElement(By.XPath("//td[contains(.,'"+ reason + "')]/following-sibling::td/button[contains(@class,'edit-command')]"));
            fw.ExecuteJavascript(element);
            tmsWait.Hard(2);
            IWebElement checkbox = Browser.Wd.FindElement(By.XPath("//input[@id='description']/parent::td/preceding-sibling::td/input"));
            if (action.ToLower().Equals("checked")) { 
            if (checkbox.Selected != true)
            {
                ReUsableFunctions.CheckBoxOperations(checkbox, p1);
                tmsWait.Hard(2);
            }
            }
            else
            {
                if (checkbox.Selected == true)
                {
                    ReUsableFunctions.CheckBoxOperations(checkbox, p1);
                    tmsWait.Hard(2);
                }
            }
            IWebElement save = Browser.Wd.FindElement(By.XPath("//input[@id='description']/parent::td/following-sibling::td/button[contains(@class,'save-command')]"));
            fw.ExecuteJavascript(save);
            tmsWait.Hard(2);

        }

        [When(@"AddOnHoldReason mark inactive reason ""(.*)""")]
        public void WhenAddOnHoldReasonMarkInactiveReason(string inactivereason)
        {
            string inactivecheck = tmsCommon.GenerateData(inactivereason);
            IWebElement ListOfOnHoldReason = Browser.Wd.FindElement(By.XPath(".//table[@role='grid']/tbody"));
            IReadOnlyCollection<IWebElement> allrows = ListOfOnHoldReason.FindElements(By.TagName("tr"));
            // Boolean Rsame = false;
            foreach (var row in allrows)
            {
                string myreason = row.FindElement(By.XPath("td[3]/span")).Text;
                if (myreason.Equals(inactivecheck))
                {
                    IWebElement clickreason = row.FindElement(By.XPath("td[5]/a"));
                    fw.ExecuteJavascript(clickreason);
                    IWebElement reasoncheckbox = row.FindElement(By.XPath("td[2]/input"));
                    reasoncheckbox.Click();
                    IWebElement savereason = row.FindElement(By.XPath("td[5]/a"));
                    savereason.Click();
                    break;
                }
            }
        }
    }
}
