﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.Text.RegularExpressions;
using TechTalk.SpecFlow;
using System.Collections.Generic;
using OpenQA.Selenium.Support.UI;

namespace TMSoR1.FrameworkCode.HCC_RAM


{
    [Binding]
    class fsAddCoderIDs
    {
        private bool nextPage;

        [When(@"Administration Main Menu Add Coder IDs sub menu is clicked")]
        public void WhenAdministrationMainMenuAddCoderIDsSubMenuIsClicked()
        {
            RAM.RAMHomePage.RAMAdministration.Click();
            RAM.AdminSubmenu.RAMAaddCoderIds.Click();
        }

        [Then(@"Verify ""(.*)"" page is opened")]
        public void ThenVerifyPageIsOpened(string p0)
        {
            string expected = p0.ToString();
            string actual = RAM.ExcludeIncludeProviderPage.FindProviderTitle.Text;
            Assert.AreEqual(expected, actual, expected + "Title is not getting displayed");
        }

        [Then(@"Find Provider page Provider Last Name is entered as ""(.*)""")]
        public void ThenFindProviderPageProviderLastNameIsEnteredAs(string lastName)
        {
            tmsWait.Hard(2);
            RAM.ExcludeIncludeProviderPage.ProviderLastName.SendKeys(lastName);
        }


        [Then(@"Find Provider page Provider Provider ID is entered as ""(.*)""")]
        public void ThenFindProviderPageProviderProviderIDIsEnteredAs(string id)
        {
            tmsWait.Hard(2);
            RAM.ExcludeIncludeProviderPage.ProviderId.SendKeys(id);
        }


        [Then(@"Verify Provider ID is displayed Last Name ""(.*)""")]
        public void ThenVerifyProviderIDIsDisplayedLastName(string lastName)
        {
            tmsWait.Hard(10);
            string str = RAM.ExcludeIncludeProviderPage.ProviderList.Text.ToLower();
            Assert.IsTrue(str.Contains(lastName.ToLower()));
        }
        
        [Then(@"Verify Add Payment Year page is opened")]
        public void ThenVerifyAddPaymentYearPageIsOpened()
        {
            tmsWait.Hard(5);
            Assert.IsTrue(RAM.AddPaymentYearPage.AddPaymentYearTitle.Text.Equals("Add Payment Year"));
        }




        [When(@"Add CoderId page from grid for Coder IDs added by User ""(.*)"" edit button is clicked And Updated reason And Clicked on Save button")]
        public void WhenAddCoderIdPageFromGridForCoderIDsAddedByUserEditButtonIsClickedAndUpdatedReasonAndClickedOnSaveButton(string editcoderid)
        {
            string updatecoderid = tmsCommon.GenerateData(editcoderid);
            bool hasrow = false;
            int totalPagesIntheGrid;
            tmsWait.Hard(3);

            // KendoUIFunctions.ResultGridTextValidation(updatecoderid);

            string PagesIntheGrid = Browser.Wd.FindElement(By.XPath("//span[@class='k-pager-input k-label']")).Text;
            string[] SplitPagesIntheGrid = PagesIntheGrid.Split(' ');
            totalPagesIntheGrid = Int32.Parse(SplitPagesIntheGrid[1]);
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {

                    hasrow = Browser.Wd.FindElement(By.XPath("//tr[contains(.,'" + updatecoderid + "')]//td//button//span[@class='fas fa-pencil-alt']")).Displayed;
                    Browser.Wd.FindElement(By.XPath("//tr[contains(.,'" + updatecoderid + "')]//td//button//span[@class='fas fa-pencil-alt']")).Click();

                    break;
                }
                catch
                {

                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);
                }

            }



            //Edit Coder Id 
           // Browser.Wd.FindElement(By.XPath("//tr[contains(.,'" + updatecoderid + "')]//td//button//span[@class='fas fa-pencil-alt']")).Click();
            
            string updateddescription = "U" + updatecoderid;
            tmsWait.Hard(3);
            // Update Coderid 
            Browser.Wd.FindElement(By.XPath("//input[@modelname='Coder ID']")).Clear();
            tmsWait.Hard(2);
            Browser.Wd.FindElement(By.XPath("//input[@modelname='Coder ID']")).SendKeys(updateddescription);
            tmsWait.Hard(2);
            //Click on Save Button 
            Browser.Wd.FindElement(By.XPath("//input[@modelname='Coder ID']/parent::td/following-sibling::td//button/span[@class='fas fa-save']")).Click();
            tmsWait.Hard(3);
        }

        [When(@"Add CoderId page from grid for Coder IDs added by User ""(.*)"" edit button is clicked And Updated reason And Clicked on Delete button")]
        public void WhenAddCoderIdPageFromGridForCoderIDsAddedByUserEditButtonIsClickedAndUpdatedReasonAndClickedOnDeleteButton(string editcoderid)
        {
            tmsWait.Hard(3);
            GlobalRef.InitialCoderIDCount = GetReportManagerRecordsCount();
            string updatecoderid = tmsCommon.GenerateData(editcoderid);



            KendoUIFunctions.deleteGridValue(updatecoderid);
            
            tmsWait.Hard(3);
            //do
            //{
            //    nextPage = VerifyCoderID(updatecoderid);
            //    if (nextPage)
            //    {
            //        Browser.Wd.FindElement(By.LinkText("Next")).Click();
            //    }
            //} while (nextPage);

            ////Click on Delete button
            //Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + updatecoderid + "')]/parent::td/following-sibling::td//button[@title='trash']")).Click();
            //tmsWait.Hard(2);

            RAM.AddCoderIDsPage.DeleteYesButton.Click();

            tmsWait.Hard(5);

            var countAfterDelete = GetReportManagerRecordsCount();
            var initialCount = GlobalRef.InitialCoderIDCount;
            int initialCoderIDCount = Convert.ToInt32(initialCount);
            Assert.AreEqual(countAfterDelete + 1, initialCoderIDCount);
        }

        public int GetReportManagerRecordsCount()
        {
            var initialText = Browser.Wd.FindElement(By.XPath("//kendo-pager-info[@class='k-pager-info k-label' and contains(.,'items')]")).Text;
            var partialText = initialText.Substring(initialText.IndexOf("of") + 2, 3);
                //var partialText_1 = partialText.Remove(initialText.IndexOf("items"), 5);
                return Convert.ToInt32(Regex.Match(partialText, @"\d+").Value);
        }

        [When(@"Add Coder ID Page Coder ID is Set to ""(.*)""")]
        public void WhenAddCoderIDPageCoderIDIsSetTo(string coderid)
        {
            string coderidtext = tmsCommon.GenerateData(coderid);
            RAM.AddCoderIDsPage.RAMAaddCoderId.SendKeys(coderidtext);
        }

        [When(@"Add Coder ID Page Add button is Clicked")]
        public void WhenAddCoderIDPageAddButtonIsClicked()
        {
            tmsWait.Hard(6);
            RAM.AddCoderIDsPage.RAMAaddCoderIDsAddbutton.Click();
        }

        [When(@"Add Coder ID Page Add button is Clicked and Verify mesaage ""(.*)""")]
        [Then(@"Add Coder ID Page Add button is Clicked and Verify mesaage ""(.*)""")]
        public void ThenAddCoderIDPageAddButtonIsClickedAndVerifyMesaage(string p0)
        { 
            tmsWait.Hard(5);
            RAM.AddCoderIDsPage.RAMAaddCoderIDsAddbutton.Click();
            string expectedvalue = p0.ToString();
            string actualvalue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;

            Assert.IsTrue(actualvalue.Contains(expectedvalue), "Message is displayed successfully");

        }

        [When(@"Add Coder Add button Clicked and Verify message ""(.*)"" and data varified with added coderid ""(.*)""")]
        [Then(@"Add Coder Add button Clicked and Verify message ""(.*)"" and data varified with added coderid ""(.*)""")]
        public void WhenAddCoderAddButtonClickedAndVerifyMessageAndDataVarifiedWithAddedCoderid(string p0, string p1)
        {
            tmsWait.Hard(5);
            RAM.AddCoderIDsPage.RAMAaddCoderIDsAddbutton.Click();
            try
            {
                By toastMsg = By.XPath("//div[@class='k-notification-content']");
                string actualvalue = Browser.Wd.FindElement(toastMsg).Text;

                //string actualvalue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                string expectedvalue = p0.ToString();
                Assert.IsTrue(actualvalue.Contains(expectedvalue), "Message is displayed successfully");
            }
            catch
            {
                string actualcoderid = tmsCommon.GenerateData(p1);
                KendoUIFunctions.ResultGridTextValidation(actualcoderid);
            }
        }

        [Then(@"Verify Result Gird Next button functionally work per result grid")]
        public void ThenVerifyResultGirdNextButtonFunctionallyWorkPerResultGrid()
        {
            KendoUIFunctions.NextButton();
        }

        [Then(@"Verify Result Gird Previous button functionally work per result grid")]
        public void ThenVerifyResultGirdPreviousButtonFunctionallyWorkPerResultGrid()
        {
            KendoUIFunctions.previousButton();
        }
        [Then(@"Verify Result Gird First Page button functionally work per result grid")]
        public void ThenVerifyResultGirdFirstPageButtonFunctionallyWorkPerResultGrid()
        {
            KendoUIFunctions.GoToFirstPage();
        }

        [Then(@"Verify Result Gird Last Page button functionally work per result grid")]
        public void ThenVerifyResultGirdLastPageButtonFunctionallyWorkPerResultGrid()
        {
            KendoUIFunctions.GoToFirstPage();
        }

        [Then(@"Verify Add Coder ID page is displaying Coder IDs added by User grid with added coderid ""(.*)""")]
        public void ThenVerifyAddCoderIDPageIsDisplayingCoderIDsAddedByUserGridWithAddedCoderid(string addedcoderid)
        {

            string actualcoderid = tmsCommon.GenerateData(addedcoderid);
            KendoUIFunctions.ResultGridTextValidation(actualcoderid);

            //tmsWait.Hard(3);

            //do
            //{
            //    nextPage = VerifyCoderID(actualcoderid);
            //    if (nextPage)
            //    {
            //        Browser.Wd.FindElement(By.LinkText("Next")).Click();
            //    }
            //} while (nextPage);


        }

        public bool VerifyCoderID(string coderid)
        {
            try
            {
                IWebElement coderID = Browser.Wd.FindElement(By.XPath("//table[@test-id='coderIds-table-coderId']//span[contains(@title,'" + coderid + "')]"));
                if (coderID.Displayed)
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                return true;
            }
            return true;
        }

        [When(@"AddReviewChartSource page source is set to ""(.*)""")]
        public void WhenAddReviewChartSourcePageSourceIsSetTo(string p1)
        {
            string p0 = tmsCommon.GenerateData(p1);
            Browser.Wd.FindElement(By.XPath("//input[@test-id='addSource-txt-source']")).SendKeys(p0);
        }

        [When(@"AddReviewChartSource page Add button is clicked")]
        public void WhenAddReviewChartSourcePageAddButtonIsClicked()
        {
           fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='addSource-btn-save']")));
            tmsWait.Hard(5);
            //Accepting Confirmation dialog box
           fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")));
            tmsWait.Hard(5);
        }

        [When(@"AddReviewChartSource page Add button is clicked without accepting confirmation dialog")]
        public void WhenAddReviewChartSourcePageAddButtonIsClickedWithoutAcceptingConfirmationDialog()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='addSource-btn-save']")));
            tmsWait.Hard(3);
        }

        [When(@"AddReviewChartSource page Confirmation dialog box is displayed with message ""(.*)""")]
        public void WhenAddReviewChartSourcePageConfirmationDialogBoxIsDisplayedWithMessage(string p0)
        {
            tmsWait.Hard(3);
            string confirmation_Message = tmsCommon.GenerateData(p0);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[contains(.,'" + confirmation_Message + "')]")).Displayed, "Confirmation dialog message is incorrect or not available");
        }

        [When(@"AddReviewChartSource page Confirmation dialog box ""(.*)"" button is clicked")]
        public void WhenAddReviewChartSourcePageConfirmationDialogBoxButtonIsClicked(string p0)
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-No']")));
        }

        [Then(@"Verify AddReviewChartSource page soruce grid has Chart Review source ""(.*)"" is not displayed")]
        public void ThenVerifyAddReviewChartSourcePageSoruceGridHasChartReviewSourceIsNotDisplayed(string p0)
        {
            string source = tmsCommon.GenerateData(p0);
            bool hasrow = false;
            int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//input[@role='spinbutton']")).GetAttribute("aria-valuemax"));
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {
                    hasrow = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='addSource-grid-source']//td[contains(.,'" + source + "')]")).Displayed;
                    break;
                }
                catch
                {

                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);
                }

            }
            //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed);

            Assert.IsFalse(hasrow, "There is no such row Present");
        }





        [When(@"AddReviewChartSource page Add button is clicked and success Message varified ""(.*)""")]
        [Then(@"AddReviewChartSource page Add button is clicked and success Message varified ""(.*)""")]
        public void ThenAddReviewChartSourcePageAddButtonIsClickedAndSuccessMessageVarified(string p0)
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.Id("btnAdd")));
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")));
            tmsWait.Hard(1);
        }


        [When(@"AddReviewChartSource page source """"(.*)""mytest""")]
        public void WhenAddReviewChartSourcePageSourceMytest(string p0)
        {
            
        }

        [Then(@"Verify AddReviewChartSource page soruce grid has Chart Review source ""(.*)"" is displayed")]
        public void ThenVerifyAddReviewChartSourcePageSoruceGridHasChartReviewSourceIsDisplayed(string p0)
        {
            string source = tmsCommon.GenerateData(p0);
              bool hasrow = false;
            int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//input[@role='spinbutton']")).GetAttribute("aria-valuemax"));
            tmsWait.Hard(1);
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {
                    hasrow = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='addSource-grid-source']//td[contains(.,'"+ source + "')]")).Displayed;
                    break;
                }
                catch
                {

                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);
                }

            }
            //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed);

            Assert.IsTrue(hasrow, "There is no such row Present");
            tmsWait.Hard(3);
        }



        [When(@"AddReviewChartSource page Action button is clicked for System Defined Source and verify message ""(.*)""")]
        public void WhenAddReviewChartSourcePageActionButtonIsClickedForSystemDefinedSourceAndVerifyMessage(string p0)
        {
            string expected_Message = tmsCommon.GenerateData(p0);
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@test-id='addSource-grid-sourceGrid']//tbody/tr[1]//a")));
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='addSource-grid-source']//td[contains(.,'Other')]/following-sibling::td/button)[1]")));
            //string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
            tmsWait.Hard(1);
            By toastMsg = By.XPath("//div[@class='k-notification-content']");
            string actualValue = Browser.Wd.FindElement(toastMsg).Text;
            Assert.IsTrue(actualValue.Contains(expected_Message));
            tmsWait.Hard(3);

        }

        [When(@"AddReviewChartSource page Action button is clicked for source ""(.*)""")]
        public void WhenAddReviewChartSourcePageActionButtonIsClickedForSource(string p0)
        {
            string source = tmsCommon.GenerateData(p0);
            bool hasrow = false;
            int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//input[@role='spinbutton']")).GetAttribute("aria-valuemax"));
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {
                    hasrow = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='addSource-grid-source']//td[contains(.,'" + source + "')]")).Displayed;
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='addSource-grid-source']//td[contains(.,'" + source + "')]/following-sibling::td/button)[1]")));

                    break;
                }
                catch
                {

                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);
                }

            }
            //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed);

            Assert.IsTrue(hasrow, "There is no such row Present");
        }


        [Then(@"Verify AddReviewChartSource page field is editable for source ""(.*)""")]
        public void ThenVerifyAddReviewChartSourcePageFieldIsEditableForSource(string p0)
        {
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='addSource-grid-source']//td/input[@modelname='Source']")).Displayed);

        }





        [When(@"AddReviewChartSource page source ""(.*)"" is updated to ""(.*)""")]
        public void WhenAddReviewChartSourcePageSourceIsUpdatedTo(string p2, string p3)
        {
            tmsWait.Hard(5);
            string p0 = tmsCommon.GenerateData(p2);
            string p1 = tmsCommon.GenerateData(p3);
            IWebElement sourcetable = Browser.Wd.FindElement(By.XPath("//div[@test-id='addSource-grid-sourceGrid']/table/tbody"));
            IReadOnlyCollection<IWebElement> sourcerow = sourcetable.FindElements(By.TagName("tr"));
            foreach(var row in sourcerow)
            {
                string rsource = row.FindElement(By.XPath("td[3]/span")).Text;
                // string[] splitsource = rsource.Split(' ');
                if (rsource == p0)
                {
                    fw.ExecuteJavascript(row.FindElement(By.XPath("td[5]/a/span")));
                    break;
                }
            }
            tmsWait.Hard(3);
            //Browser.Wd.FindElement(By.XPath("//input[@type='text']")).Clear();
            tmsWait.Hard(2);
            Browser.Wd.FindElement(By.XPath("//input[@type='text']")).SendKeys(p1);
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@class='k-i-check fa fa-floppy-o']")));
        }

        [Then(@"Verify AuditConfiguration Warning Note ""(.*)""")]
        public void ThenVerifyAuditConfigurationWarningNote(string p0)
        {
           Browser.Wd.FindElement(By.XPath("//span[contains(.,'"+p0+"')]"));
        }

        [Then(@"AuditConfiguration page Save button is clicked")]
        public void ThenAuditConfigurationPageSaveButtonIsClicked()
        {
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@test-id='auditConfig-btn-save']"));
            fw.ExecuteJavascript(ele);
            tmsWait.Hard(2);
        }


        [Then(@"Verify AuditConfiguration Note ""(.*)""")]
        public void ThenVerifyAuditConfigurationNote(string p0)
        {
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[contains(.,'Warehouse')]")).Text.Contains(p0), "Warning note is not displayed");
        }

        [When(@"RAM Administration Audit Configuration page Save Button is Clicked")]
        public void WhenRAMAdministrationAuditConfigurationPageSaveButtonIsClicked()
        {
            By loc = By.CssSelector("[test-id='auditConfig-btn-save']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            tmsWait.Hard(3);

        }

        [When(@"Audit View Export page ""(.*)"" drop down is set to ""(.*)""")]
        public void WhenAuditViewExportPageDropDownIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = p1;
            By drp;
            By values;

            

            switch (field)
            {
                case "Activity":
                    drp = By.XPath("//multiselect[@test-id='audit-drp-activity']//button");
                    values = By.XPath("//multiselect//li//a[contains(.,'"+value+"')]");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(drp);
                    tmsWait.Hard(2);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(values);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(drp);
                    break;

                case "Action":
                    drp = By.XPath("//multiselect[@test-id='audit-drp-actions']//button");
                    values = By.XPath("//multiselect//li//a[contains(.,'"+value+"')]");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(drp);
                    tmsWait.Hard(2);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(values);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(drp);
                    break;

                case "User":
                    drp = By.CssSelector("[test-id='audit-ddl-users']");
                    new SelectElement(Browser.Wd.FindElement(drp)).SelectByText(value);
                    break;
                    

    }
        }

        [When(@"Audit View Export page Reset Button is Clicked")]
        public void WhenAuditViewExportPageResetButtonIsClicked()
        {
            By loc = By.CssSelector("[test-id='audit-btn-reset']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            tmsWait.Hard(5);
        }

        [Then(@"Verify Audit View Export page ""(.*)"" drop down is displayed as ""(.*)""")]
        public void ThenVerifyAuditViewExportPageDropDownIsDisplayedAs(string p0, string p1)
        {
            string actualresult = Browser.Wd.FindElement(By.XPath("//multiselect[@test-id='audit-drp-activity']//button")).GetAttribute("title").ToString();
            string expectedresult = p1;

            Assert.AreEqual(expectedresult, actualresult, " Both values are not matching");

            fw.ConsoleReport(" Displayed Value " + actualresult);
        }

        [Then(@"Verify Audit View Export page User drop down is displayed as ""(.*)""")]
        public void ThenVerifyAuditViewExportPageUserDropDownIsDisplayedAs(string p0)
        {
            string actualresult = new SelectElement(Browser.Wd.FindElement(By.CssSelector("[test-id='audit-ddl-users']"))).SelectedOption.Text;

            string expectedresult = p0;
            Assert.AreEqual(expectedresult, actualresult, " Both values are not matching");

            fw.ConsoleReport(" Displayed Value " + actualresult);
        }


        [Then(@"AuditConfiguration AllActivity switch is ""(.*)""")]
        [When(@"AuditConfiguration AllActivity switch is ""(.*)""")]
        public void WhenAuditConfigurationAllActivitySwitchIs(string p0)
        {
            tmsWait.Hard(3);
            string swtichchk = Browser.Wd.FindElement(By.XPath("//kendo-switch[@test-id='auditConfig-input-all']")).GetAttribute("class");
            switch (p0.ToLower())
            {
                case "on":
                    
                    if(swtichchk.Contains("off"))
                    {
                        IWebElement all = Browser.Wd.FindElement(By.XPath("//kendo-switch[@test-id='auditConfig-input-all']"));
                        //fw.ExecuteJavascript(all);
                        all.Click();
                        tmsWait.Hard(2);
                    }
                     break;
                case "off":
                    if (swtichchk.Contains("on"))
                    {
                        IWebElement all = Browser.Wd.FindElement(By.XPath("//kendo-switch[@test-id='auditConfig-input-all']"));
                        //fw.ExecuteJavascript(all);
                        all.Click();
                        tmsWait.Hard(2);
                    }
                    break;

                  //  tmsWait.Hard(2);
            }
            tmsWait.Hard(2);
        }

        [Then(@"Verify AuditConfiguration ""(.*)"" activity is set to ""(.*)""")]
        public void ThenVerifyAuditConfigurationActivityIsSetTo(string p0, string p1)
        {
           switch(p0.ToLower())
            {
                case "suspects": 
                    if(p1.ToLower()=="yes")
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//kendo-switch[@test-id='auditConfig-input-activities'])[1]")).Displayed);
                       
                    }
                    else
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//kendo-switch[@test-id='auditConfig-input-activities'])[1]")).Displayed);
                    }
                    break;

                case "diagnosis":
                    if (p1.ToLower() == "yes")
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//kendo-switch[@test-id='auditConfig-input-activities'])[2]")).Displayed);

                    }
                    else
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//kendo-switch[@test-id='auditConfig-input-activities'])[2]")).Displayed);
                    }
                    break;

                case "claims":
                    if (p1.ToLower() == "yes")
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//kendo-switch[@test-id='auditConfig-input-activities'])[3]")).Displayed);

                    }
                    else
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//kendo-switch[@test-id='auditConfig-input-activities'])[3]")).Displayed);
                    }
                    break;
            }
        }

    }

}

