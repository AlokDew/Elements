﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using TechTalk.SpecFlow;


namespace TMSoR1.FrameworkCode.HCC_RAM
{
    [Binding]
    class fsAddPaymentYear
    {
        [When(@"Add Payment Year Page Payment Year is Set to ""(.*)""")]
        public void WhenAddPaymentYearPagePaymentYearIsSetTo(string p0)
        {
            string paymentyear = tmsCommon.GenerateData(p0);
            RAM.AddPaymentYearPage.PaymentYearinput.Clear();
            RAM.AddPaymentYearPage.PaymentYearinput.SendKeys(paymentyear);
            tmsWait.Hard(2);
        }



        [When(@"Add Payment Year Page Risk Percentage is set as ""(.*)""")]
        public void WhenAddPaymentYearPageRiskPercentageIsSetAs(string percent)
        {
            tmsWait.Hard(2);
            RAM.AddPaymentYearPage.RiskPercentageinput.Clear();
            RAM.AddPaymentYearPage.RiskPercentageinput.SendKeys(percent);
            tmsWait.Hard(2);
        }

        [When(@"Add Payment Year Page Start Date is set")]
        public void WhenAddPaymentYearPageStartDateIsSet()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(RAM.AddPaymentYearPage.StartDatePicker);
            tmsWait.Hard(3);
            DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_RETURN, 0, 0, 0);
        }

        [When(@"Add Payment Year Page Start Date is set ""(.*)""")]
        public void WhenAddPaymentYearPageStartDateIsSet(string p0)
        {
            DateTime date = DateTime.Now;
            DateTime firstDayOfMonth = new DateTime(date.Year, date.Month, 1);
            string startDate = firstDayOfMonth.ToString("MM/dd/yyyy");
            tmsWait.Hard(2);
            fw.ExecuteJavascriptSetText(RAM.AddPaymentYearPage.StartDatePicker, startDate);
            RAM.AddPaymentYearPage.StartDatePicker.Click();
        }

        [When(@"Add Payment Year Page End Date is set ""(.*)""")]
        public void WhenAddPaymentYearPageEndDateIsSet(string p0)
        {
            DateTime date = DateTime.Now;
            string currentDate = date.ToString("MM/dd/yyyy");
            tmsWait.Hard(2);
            fw.ExecuteJavascriptSetText(RAM.AddPaymentYearPage.EndDatePicker, currentDate);
            RAM.AddPaymentYearPage.EndDatePicker.Click();
        }


        [When(@"Add Payment Year Page Start Date is set to ""(.*)""")]
        public void WhenAddPaymentYearPageStartDateIsSetTo(string p0)
        {
            string paymentStartDate = tmsCommon.GenerateData(p0);
            string paymentStartDate1 = paymentStartDate.Replace("/", "");
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='paymentYear-txt-startDate']//span/input"));
            ele.Clear();
            ele.SendKeys(paymentStartDate1);
            tmsWait.Hard(2);
        }

        [When(@"Add Payment Year Page End Date is set to ""(.*)""")]
        public void WhenAddPaymentYearPageEndDateIsSetTo(string p0)
        {
            string paymentEndDate = tmsCommon.GenerateData(p0);
            string paymentEndDate1 = paymentEndDate.Replace("/", "");
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='paymentYear-txt-endDate']//span/input"));
            ele.Clear();
            ele.SendKeys(paymentEndDate1);
            tmsWait.Hard(2);
        }


        [When(@"Add Payment Year Page End Date is set")]
        public void WhenAddPaymentYearPageEndDateIsSet()
        {
            tmsWait.Hard(2);
            RAM.AddPaymentYearPage.EndDatePicker.Clear();
            fw.ExecuteJavascript(RAM.AddPaymentYearPage.EndDatePicker);
            tmsWait.Hard(3);
            DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_RETURN, 0, 0, 0);
        }

        [When(@"Add Payment Year Page ADD button is clicked")]
        public void WhenAddPaymentYearPageADDButtonIsClicked()
        {
            tmsWait.Hard(4);
            bool flag = false;
            fw.ExecuteJavascript(RAM.AddPaymentYearPage.Addbutton);
            tmsWait.Hard(1);
            if (RAM.AddPaymentYearPage.ToastMessge.Text.Contains("Payment year added successfully") 
                || RAM.AddPaymentYearPage.ToastMessge.Text.Contains("Payment year or supplied date range already exists.")) {
                flag = true;
            }
            Assert.IsTrue(flag, "Payment year could not be added" );
        }


        [Then(@"Add Payment Year Page ADD button is clicked and success message varified ""(.*)""")]
        [When(@"Add Payment Year Page ADD button is clicked and success message varified ""(.*)""")]
        public void ThenAddPaymentYearPageADDButtonIsClickedAndSuccessMessageVarified(string p0)
        {
            fw.ExecuteJavascript(RAM.AddPaymentYearPage.Addbutton);
        }

        [When(@"Add Payment Year Page ADD button is clicked successfully")]
        public void WhenAddPaymentYearPageADDButtonIsClickedSuccessfully()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(RAM.AddPaymentYearPage.Addbutton);
        }

        [When(@"Verify error message for Payment Year")]
        public void WhenVerifyErrorMessageForPaymentYear()
        {
            tmsWait.Hard(2);
            Assert.IsTrue(RAM.AddPaymentYearPage.ErrorMsgYear.Text.Contains("Please provide Payment Year"));
        }

        [When(@"Verify error message for Risk Percentage textbox")]
        public void WhenVerifyErrorMessageForRiskPercentageTextbox()
        {
            tmsWait.Hard(2);
            Assert.IsTrue(RAM.AddPaymentYearPage.ErrorMsgPercentage.Text.Contains("Please provide Risk Percentage"));
        }
        
        [When(@"Add Payment Year Page ADD button is clicked for duplicate")]
        public void WhenAddPaymentYearPageADDButtonIsClickedForDuplicate()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(RAM.AddPaymentYearPage.Addbutton);
            Assert.IsTrue(RAM.AddPaymentYearPage.ToastMessge.Text.Contains("Payment year or supplied date range already exists."));
        }


        [When(@"Add Payment Year Page ""(.*)"" year is deleted if present")]
        public void WhenAddPaymentYearPageYearIsDeletedIfPresent(string year)
        {
            tmsWait.Hard(5);
            try
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//tr[contains(.,'" + year + "')]//td//a[contains(@class,'remove')]//span")));
                tmsWait.Hard(2);
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@test-id='confirmationDialog-div-dialog']//div//button[@test-id='confirmationDialog-btn-Yes']")));
                tmsWait.Hard(5);
            }
            catch (NoSuchElementException) {
                Console.Write("Payment Year is not present");
            }
        }


        [When(@"Add Payment Year Page Yes button is clicked for Confirmation")]
        public void WhenAddPaymentYearPageYesButtonIsClickedForConfirmation()
        {
            tmsWait.Hard(8);
            fw.ExecuteJavascript(RAM.AddPaymentYearPage.YesDeleteConfirmButton);
        }

        [Then(@"verify ""(.*)"" is displayed")]
        public void ThenVerifyIsDisplayed(string p0)
        {
            switch (p0) {
                case "Reset Button":
                    Assert.IsTrue(RAM.AddPaymentYearPage.Resetbutton.Displayed, "Reset button is not displayed");
                   break;
                case "Payment Years Grid":
                    Assert.IsTrue(RAM.AddPaymentYearPage.PaymentYearGrid.Displayed, "Payment Years Grid is not displayed");
                    break;

            }
        }



        [When(@"Add Payment Year Page  reset button is Clicked")]
        public void WhenAddPaymentYearPageResetButtonIsClicked()
        {
            RAM.AddPaymentYearPage.Resetbutton.Click();
            string expected = "";
            Assert.AreEqual(expected, RAM.AddPaymentYearPage.PaymentYearinput.Text, expected + " Reset Button is not working");
        }

        [When(@"Add Payment Year page from Payment Year List grid edit button is clicked And Updated Risk Percentage as ""(.*)"" And Clicked on Save button")]
        public void WhenAddPaymentYearPageFromPaymentYearListGridEditButtonIsClickedAndUpdatedRiskPercentageAsAndClickedOnSaveButton(String riskpercen)
        {
            fw.ExecuteJavascript(RAM.AddPaymentYearPage.Editbutton);
            tmsWait.Hard(3);
            //IWebElement ele = Browser.Wd.FindElement(By.XPath("//input[@class='k-formatted-value k-input']"));
            //ele.Clear();
            //tmsWait.Hard(1);
            //ele.SendKeys("50");
           // fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@class='k-icon k-i-arrow-60-down']")));
            //Browser.Wd.FindElement(By.XPath("//span[@class='k-icon k-i-arrow-60-down']")).Click();
            Browser.Wd.FindElement(By.XPath("(//input[@modelname='Risk Percentage'])[2]")).Clear();
            Browser.Wd.FindElement(By.XPath("(//input[@modelname='Risk Percentage'])[2]")).SendKeys("49");
            tmsWait.Hard(2);
            ////System.Windows.Forms.SendKeys.SendWait("{TAB}");
            //tmsWait.Hard(3);
            // fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@aria-label='Decrease value']/span")));
            // RAM.AddPaymentYearPage.EditRiskPercentage.Clear();
            // RAM.AddPaymentYearPage.EditRiskPercentage.SendKeys(riskpercen);
            tmsWait.Hard(3);
            AngularFunction.clickOnElement(RAM.AddPaymentYearPage.Savebutton);
            //RAM.AddPaymentYearPage.Savebutton.Click();
            By toastMsg = By.XPath("//div[@class='k-notification-content']");
            //By toastMsg = By.XPath("//kendo-notification[@class='k-notification-container'] ");
            string actualValue = Browser.Wd.FindElement(toastMsg).Text;
            Assert.IsTrue(actualValue.Contains("Payment year updated successfully."), "Message is not displyed successfully ");
        }


        [When(@"Add Payment Year page from Payment Year List grid clicked on Delete button")]
        public void WhenAddPaymentYearPageFromPaymentYearListGridClickedOnDeleteButton()
        {
            tmsWait.Hard(3);
            IWebElement item = Browser.Wd.FindElement(By.XPath("//kendo-pager-info[@class='k-pager-info k-label']"));

            String count = item.Text;
           // String listOfYear1 = null;


            string[] tokens = count.Split(' ');
            String currentCount = tokens[4];

          

            GlobalRef.currentCount = currentCount;

            fw.ExecuteJavascript(RAM.AddPaymentYearPage.Deletebutton);


        }
      
        
        [When(@"I clicked on ""(.*)"" on Warnig popup window for deleting paymentyear")]
        public void WhenIClickedOnOnWarnigPopupWindowForDeletingPaymentyear(string inputaction)
        {
            tmsWait.Hard(10);


            switch (inputaction.ToLower())
            {
                case "yes":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")));
                    break;
                case "no":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-No']")));
                    break;
            }
        }

        [When(@"I clicked on ""(.*)"" on Warnig popup window for deleting paymentyear and Verified success mesaage ""(.*)""")]
        public void WhenIClickedOnOnWarnigPopupWindowForDeletingPaymentyearAndVerifiedSuccessMesaage(string p0, string p1)
        {
            try {
                tmsWait.Hard(7);
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")));
            }catch
            {
                IWebElement item = Browser.Wd.FindElement(By.XPath("//*[@id='paymentYearGrid']/div/span[2]"));
                String count = item.Text;
                // String listOfYear1 = null;


                string[] tokens = count.Split(' ');
                String Finalcount = tokens[4];

                //tmsWait.Hard(5);
                //IList<IWebElement> listOfYear1 = Browser.Wd.FindElements(By.XPath("//div[@test-id='payment-grid-paymentYearGrid']//tr"));
                //int Finalcount = listOfYear1.Count - 1;
                GlobalRef.Finalcount = Finalcount;
               // GlobalRef.Finalcount = Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='8']//tr[8]/td[5]/div/div")).Text;
                //Console.WriteLine(" Column A Count Now --> " + GlobalRef.CurrentColumnAcount);

                int currentCount1 = Convert.ToInt32(GlobalRef.Finalcount);
                int initialCount1 = Convert.ToInt32(GlobalRef.currentCount);
                bool res = initialCount1 > currentCount1;
                Assert.IsTrue(res, "Year is not getting deleted");
            }
        }

        [When(@"Add Payment Year page from Payment Year List grid edit button is clicked And Updated Risk Percentage as ""(.*)"" And Clicked on Cancle button")]
        public void WhenAddPaymentYearPageFromPaymentYearListGridEditButtonIsClickedAndUpdatedRiskPercentageAsAndClickedOnCancleButton(string riskpercen1)
        {
            fw.ExecuteJavascript(RAM.AddPaymentYearPage.Editbutton);
            //RAM.AddPaymentYearPage.Editbutton.Click();
            tmsWait.Hard(2);
            RAM.AddPaymentYearPage.RiskPercentageinput.SendKeys(riskpercen1);
            tmsWait.Hard(1);
            AngularFunction.clickOnElement(RAM.AddPaymentYearPage.Cancelbutton);
            //RAM.AddPaymentYearPage.Cancelbutton.Click();
        }
        [When(@"Add Payment Year Page I Entered Payment Year as ""(.*)"" And Risk Percentage as ""(.*)""")]
        public void WhenAddPaymentYearPageIEnteredPaymentYearAsAndRiskPercentageAs(string paymentyear, string riskpercentage )
        {
            RAM.AddPaymentYearPage.PaymentYearinput.SendKeys(paymentyear);
            RAM.AddPaymentYearPage.RiskPercentageinput.SendKeys(riskpercentage);
        }
        [When(@"""(.*)"" entered as ""(.*)""")]
        public void WhenEnteredAs(string inoutdatetype, string datevalue)
        {
            //((JavascriptExecutor)wd.browser).executeScript("document.getElementById('fromDate').removeAttribute('readonly',0);"); // Enables the from date box

            //WebElement fromDateBox = driver.findElement(By.id("fromDate"));
            //fromDateBox.clear();
            //fromDateBox.sendKeys("8-Dec-2014");

            //switch (inoutdatetype.ToLower())
            //{
            //    case "start date":
            //        RAM.AddPaymentYearPage.StartDate.Click();
            //        tmsWait.Hard(2);
            //        Browser.Wd.FindElement(By.XPath(".//*[@id='reportsBlock']/accordion/div/div[2]/div[2]/div/div/div[5]/div/ul/li/div/table/thead/tr[1]/th[1]/button")).Click();
            //        tmsWait.Hard(2);
            //        Browser.Wd.FindElement(By.XPath("//button/span[contains(.,'07')]")).Click();
            //        break;
            //    case "end date":
            //        RAM.AddPaymentYearPage.EndDate.Click();
            //        tmsWait.Hard(2);
            //        Browser.Wd.FindElement(By.XPath(".//*[@id='reportsBlock']/accordion/div/div[2]/div[2]/div/div/div[6]/div/ul/li/div/table/thead/tr[1]/th[1]/button")).Click();
            //        tmsWait.Hard(2);
            //        Browser.Wd.FindElement(By.XPath("//button/span[contains(.,'07')]")).Click();
            //        break;
            //}

        }






    }
}
