﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows;
using System.Drawing;
using OpenQA.Selenium.Support.UI;
using System.Collections.ObjectModel;
using OpenQA.Selenium.Interactions;
using TMSoR1.FrameworkCode;

namespace TMSoR1
{
    [Binding]
    class fsJobProcessingStatus
    {

        public int StatusValidation(string actualStatus)
        {
            if (actualStatus.Equals("Pending"))
            {
                tmsWait.Hard(3);
                return 1;
            }
            else if (actualStatus.Equals("Executing"))
            {
                return 1;
            }

            else if (actualStatus.Equals("Failed"))
            {
                Assert.Fail("File Processing Job is failed");
                return 0;
            }

            else if (actualStatus.Equals("Disabled"))
            {
                Assert.Fail("File Processing Job is Disabled");
                return 0;
            }
            else if (actualStatus.Equals("Complete"))
            {

                return 0;
            }
            else if (actualStatus.Equals("Success"))
            {

                return 0;
            }
            else if (actualStatus.Equals("Failure"))
            {

                return 0;
            }
            else if (actualStatus.Equals("Complete/No Updates"))
            {

                return 0;
            }


            return 0;
        }


        By importPlus;
        string actualstatus = "";

        [When(@"Job Processing Status page Processed Job Name ""(.*)"" set to status ""(.*)""")]
        public void WhenJobProcessingStatusPageProcessedJobNameSetToStatus(string p0, string p1)
        {
          

           var reports = ScenarioContext.Current["ReportName"].ToString();

            tmsWait.Hard(10);
           

            string jobName = p0.ToString();
            string expectedStatus = p1.ToString();
           

          
                fw.ConsoleReport("------------------>This is new Job Processing page <---------------------------------");

                if (expectedStatus.Contains("Complete"))
                {
                expectedStatus = "Success";
                }
            fw.ConsoleReport("------------------Selecting Drop Down Value ---------------------------------> "+ jobName);
            AngularFunction.selectDropDownValue(cfJobProcessing.RAMJobProcessing.jobDropdown, jobName);
            AngularFunction.clickOnElement(cfJobProcessing.RAMJobProcessing.SearchButton);

            var actualstatus = "";              

                By getCurrentStatus =By.XPath("//td[contains(.,'PIRResponse_20200101.csv.txt')]/following-sibling::td[@aria-colindex='3']");
            
                try
            {
                
                tmsWait.Hard(5);
                AngularFunction.clickOnElement(cfJobProcessing.RAMJobProcessing.importPlusButton);
                tmsWait.Hard(5);

                actualstatus = AngularFunction.getText(getCurrentStatus);
                    fw.ConsoleReport(" Initial Job Processing status" + actualstatus);
                }
                catch
                {

                }
                int ReturnStatus = StatusValidation(actualstatus);

                while (ReturnStatus != 0)
                {

                AngularFunction.clickOnElement(cfJobProcessing.RAMJobProcessing.SearchButton);

                tmsWait.Hard(7); // We put this wait intentionally as File processing is taking time for ESI
                actualstatus = AngularFunction.getText(getCurrentStatus);

                ReturnStatus = StatusValidation(actualstatus);
                    fw.ConsoleReport(" Current Job Processing status --> " + actualstatus);
                actualstatus = AngularFunction.getText(getCurrentStatus);
                }
               

                Assert.AreEqual(expectedStatus, actualstatus, " Both are not matching");

            
            




        }

    }
}
