﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.RxM
{
    [Binding]
    class RxMReports
    {
        [When(@"RxM Application File Menu Processing Status submenu is Clicked")]
        public void WhenRxMApplicationFileMenuProcessingStatusSubmenuIsClicked()
        {
            IWebElement menu = Browser.Wd.FindElement(By.XPath("//a[@id='ctl00_Menu_m1_m0']"));
            fw.ExecuteJavascript(menu);
            tmsWait.Hard(2);
        }

        [Then(@"Verify My Reports Page ""(.*)"" Drop down list is displayed")]
        public void ThenVerifyMyReportsPageDropDownListIsDisplayed(string field)
        {
            IWebElement element;
            bool actualResults;
           switch(field)
            {
                case "Report Type":
                    element = Browser.Wd.FindElement(By.Id("ctl00_MainContent_lstReportName"));
                    actualResults = element.Displayed;
                    Assert.IsTrue(actualResults, field + " is not getting displayed");
                    break;

                case "Plan ID":
                    element = Browser.Wd.FindElement(By.Id("ctl00_MainContent_lstPlanID"));
                    actualResults = element.Displayed;
                    Assert.IsTrue(actualResults, field + " is not getting displayed");
                    break;

                case "PBP":
                    element = Browser.Wd.FindElement(By.Id("ctl00_MainContent_lstPBP"));
                    actualResults = element.Displayed;
                    Assert.IsTrue(actualResults, field + " is not getting displayed");
                    break;
                case "Year":
                    element = Browser.Wd.FindElement(By.Id("ctl00_MainContent_lstStartDate"));
                    actualResults = element.Displayed;
                    Assert.IsTrue(actualResults, field + " is not getting displayed");
                    break;
                case "Status":
                    element = Browser.Wd.FindElement(By.Id("ctl00_MainContent_lstStatus"));
                    actualResults = element.Displayed;
                    Assert.IsTrue(actualResults, field + " is not getting displayed");
                    break;
            }
        }


        [Then(@"Verify Job Processing Status ""(.*)"" field is displayed")]
        public void ThenVerifyJobProcessingStatusFieldIsDisplayed(string p0)
        {
            IWebElement menu = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_MainContent_dataGridJobProcessing_ctl01']//th/a[contains(.,'"+p0+"')]"));
            bool actualResults = menu.Displayed;
            Assert.IsTrue(actualResults, p0 + "is not getting displayed");
        }

        [When(@"RxM Application Report Manager menu is Clicked")]
        public void WhenRxMApplicationReportManagerMenuIsClicked()
        {
            IWebElement menu = Browser.Wd.FindElement(By.XPath("//a[@id='ctl00_Menu_m3']"));
            fw.ExecuteJavascript(menu);
            tmsWait.Hard(2);
        }
        [When(@"RxM Reports Start Date is set to ""(.*)""")]
        public void WhenRxMReportsStartDateIsSetTo(string p0)
        {
            IWebElement start = Browser.Wd.FindElement(By.Id("ctl00_MainContent_StartDate"));
            start.SendKeys(p0);
        }

        [When(@"RxM Reports End Date is set to ""(.*)""")]
        public void WhenRxMReportsEndDateIsSetTo(string p0)
        {
            IWebElement end = Browser.Wd.FindElement(By.Id("ctl00_MainContent_EndDate"));
            end.SendKeys(p0);
        }

        [When(@"RxM Reports Format is set to ""(.*)""")]
        public void WhenRxMReportsFormatIsSetTo(string p0)
        {
            IWebElement drp = Browser.Wd.FindElement(By.Id("ctl00_MainContent_ReportFormat"));
            new SelectElement(drp).SelectByText(p0);

        }

        [When(@"RxM Reports Run Report button is Clicked")]
        public void WhenRxMReportsRunReportButtonIsClicked()
        {
            IWebElement reportbuton = Browser.Wd.FindElement(By.Id("ctl00_MainContent_cmdSubmitAsync"));
            fw.ExecuteJavascript(reportbuton);
            
        }

        [When(@"RxM Reports ""(.*)"" link is Clicked")]
        public void WhenRxMReportsLinkIsClicked(string p0)
        {
            IWebElement fileprocess = Browser.Wd.FindElement(By.LinkText(p0));
            fw.ExecuteJavascript(fileprocess);
        }


        [When(@"Reports menu ""(.*)"" submenu is Clicked")]
        public void WhenReportsMenuSubmenuIsClicked(string submenu)
        {

            IWebElement element;

            switch (submenu)
            {

                case "LICS":
                    element = Browser.Wd.FindElement(By.Id("ctl00_Menu_m2_m0"));
                    fw.ExecuteJavascript(element);
                    break;
                case "Member Distribution":
                    element = Browser.Wd.FindElement(By.Id("ctl00_Menu_m2_m1"));
                    fw.ExecuteJavascript(element);
                    break;

                case "MLR":
                    element = Browser.Wd.FindElement(By.Id("ctl00_Menu_m2_m2"));
                    fw.ExecuteJavascript(element);
                    
                    break;

                case "ReInsure":
                    element = Browser.Wd.FindElement(By.Id("ctl00_Menu_m2_m3"));
                    fw.ExecuteJavascript(element);
                    break;

                case "RiskShare":
                    element = Browser.Wd.FindElement(By.Id("ctl00_Menu_m2_m4"));
                    fw.ExecuteJavascript(element);
                    break;
                case "Troop":
                    element = Browser.Wd.FindElement(By.Id("ctl00_Menu_m2_m5"));
                    fw.ExecuteJavascript(element);
                    break;
                case "Utilization":
                    element = Browser.Wd.FindElement(By.Id("ctl00_Menu_m2_m6"));
                    fw.ExecuteJavascript(element);
                    break;
            }
        }

    }
}
