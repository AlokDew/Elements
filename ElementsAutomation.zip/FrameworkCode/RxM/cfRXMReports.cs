﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.RxM
{

    class cfRXMReports
    {

        public static RXMReports RXMReports { get { return new RXMReports(); } }

    }

    [Binding]
    public class RXMReports
    {
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Plan')]/parent::div//span[@class='k-select']")); } }
        public IWebElement PBP { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'PBP')]/parent::div//span[@class='k-select']")); } }
        public IWebElement YearOfService { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Year Of Service')]/parent::div//span[@class='k-select']")); } }

        public IWebElement StatusID { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'StatusID')]/parent::div//span[@class='k-select']")); } }



    }
}
