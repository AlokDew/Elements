﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using TechTalk.SpecFlow;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using System.Diagnostics;
using System.Windows;
using TDAPIOLELib; // This is the QTP interop library 
using System.Net.Http;
using System.Net;


namespace TMSoR1
{

    [Binding]
    public class FilesProcessingStatus
    {
        public IWebElement FileStatusTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_FileStatusGrid")); } }
        public IWebElement FileProcessingStatusTable { get { return Browser.Wd.FindElement(By.Id("fileProcessStatusGrid")); } }


        public static Boolean WaitOnFileProcessing(string timeOut, string fileName, string status)
        {
            Boolean thisReturnValue = false;
            DateTime Start = DateTime.Now;
            DateTime Current = DateTime.Now;
            int ElapsedSeconds = 0;
            Boolean FoundMatchingDataRow = false;
            int thisTimeout = Convert.ToInt32(timeOut);

            Boolean hasWildCard = false;
            int stringLen = fileName.Length;
            string theLastChar = fileName.Substring(stringLen-1, 1);
            if (theLastChar == "*") { hasWildCard = true; }

            while (!FoundMatchingDataRow && ElapsedSeconds < thisTimeout)
            {
                try
                {
                    IWebElement baseTable = EAM.FilesProcessingStatus.FileStatusTable;
                    ICollection<IWebElement> myRows = baseTable.FindElements(By.TagName("tr"));
                    int RowCount = myRows.Count;
                    //Establish an array of table rows for the page data.
                    TableRow[] thisDataArr = new TableRow[RowCount];
                    //                int EstablishedRowItemCount = 0;
                    //               int iRowCounter = 0;
                    foreach (IWebElement thisRow in myRows)
                    {
                        //For each new data row we look at, add a new instance of the class to the array.
                        ICollection<IWebElement> myElements = thisRow.FindElements(By.TagName("td"));
                        //Row 0 is the header
                        //The rest of the rows are data
                        int i = 0;
                        string thisEntry = "";
                        string thisReportingEntry = "";
                        foreach (IWebElement thisElement in myElements)
                        {
                            i++;

                            if (i == 3 || i == 4)
                            {
                                string ElementText = thisElement.Text.ToString();
                                thisEntry += ElementText;
                            }
                            if (i == 3 || i == 4 || i == 5)
                            {
                                string ElementText = thisElement.Text.ToString();
                                thisReportingEntry += ElementText + " ::: ";
                            }

                        }
                        Console.WriteLine(thisReportingEntry);
                        string ExpectedEntry = fileName + status;
                        if (thisEntry == ExpectedEntry)
                        {
                            FoundMatchingDataRow = true;
                            thisReturnValue = true;
                        }
                        if (hasWildCard && thisEntry.Contains(ExpectedEntry.Substring(0, stringLen - 1)))
                        {
                            FoundMatchingDataRow = true;
                            thisReturnValue = true;
                        }
                    }
                    if (!FoundMatchingDataRow)
                    {
                        Navigation.ClickLink("FilesProcessingStatus");
                        tmsWait.Hard(30);
                    }
                    ElapsedSeconds = Convert.ToInt32((DateTime.Now - Start).TotalSeconds);
                    Console.WriteLine("Time taken to process so far has been:  [" +ElapsedSeconds.ToString()+"]");
                }
                catch { }
            }

            return thisReturnValue;
        }

        public static Boolean WaitOnFileExportProcessing(string timeOut, string fileName, string status)
        {
            Boolean thisReturnValue = false;
            DateTime Start = DateTime.Now;
            DateTime Current = DateTime.Now;
            int ElapsedSeconds = 0;
            Boolean FoundMatchingDataRow = false;
            int thisTimeout = Convert.ToInt32(timeOut);

            while (!FoundMatchingDataRow && ElapsedSeconds < thisTimeout)
            {
                try
                {
                    IWebElement baseTable = EAM.FilesProcessingStatus.FileStatusTable;
                    ICollection<IWebElement> myRows = baseTable.FindElements(By.TagName("tr"));
                    int RowCount = myRows.Count;
                    //Establish an array of table rows for the page data.
                    TableRow[] thisDataArr = new TableRow[RowCount];
                    //                int EstablishedRowItemCount = 0;
                    //               int iRowCounter = 0;
                    foreach (IWebElement thisRow in myRows)
                    {
                        //For each new data row we look at, add a new instance of the class to the array.
                        ICollection<IWebElement> myElements = thisRow.FindElements(By.TagName("td"));
                        //Row 0 is the header
                        //The rest of the rows are data
                        int i = 0;
                        string thisEntry = "";
                        string thisReportingEntry = "";
                        string exportFileName = "";
                        string appStatus = "";
                        foreach (IWebElement thisElement in myElements)
                        {
                            i++;

                            if(i==3)
                            {
                                exportFileName = thisElement.Text.ToString();
                            }
                            if(i==4)
                            {
                                appStatus = thisElement.Text.ToString();
                            }

                            if (i == 3 || i == 4)
                            {
                                string ElementText = thisElement.Text.ToString();
                                thisEntry += ElementText;
                            }
                            if (i == 3 || i == 4 || i == 5)
                            {
                                string ElementText = thisElement.Text.ToString();
                                thisReportingEntry += ElementText + " ::: ";
                            }

                        }
                        Console.WriteLine(thisReportingEntry);
                        string ExpectedEntry = fileName + status;
                        if(exportFileName.Contains(fileName) && appStatus.Equals(status))
                        {
                            FoundMatchingDataRow = true;
                            thisReturnValue = true;

                        }

                        //if (thisEntry.Contains(ExpectedEntry))
                        //{
                        //    FoundMatchingDataRow = true;
                        //    thisReturnValue = true;
                        //}
                    }
                    if (!FoundMatchingDataRow)
                    {
                        Navigation.ClickLink("FilesProcessingStatus");
                    }
                    ElapsedSeconds = Convert.ToInt32((DateTime.Now - Start).TotalSeconds);
                    Console.WriteLine(ElapsedSeconds.ToString());
                }
                catch { }
            }

            return thisReturnValue;
        }


        public static Boolean WaitOnFileExportProcessing_UIModFileProcessing(string timeOut, string fileName, string status)
        {            
            DateTime Start = DateTime.Now;
            DateTime Current = DateTime.Now;
            int ElapsedSeconds = 0;
            Boolean FoundMatchingDataRow = false;
            Boolean thisReturnValue = false;
            int thisTimeout = Convert.ToInt32(timeOut);

            while (!FoundMatchingDataRow && ElapsedSeconds < thisTimeout)
            {
                try { 
                string exportFileName = "";
                        string appStatus = "";
                        IWebElement ele_status = Browser.Wd.FindElement(By.XPath("//*[@test-id='file-grid-fileProcessStatusGrid']//tbody/tr[1]/td[2]"));
                        IWebElement ele_filename = Browser.Wd.FindElement(By.XPath("//*[@test-id='file-grid-fileProcessStatusGrid']//tbody/tr[1]/td[3]"));
                        exportFileName = ele_filename.Text.ToString();
                        appStatus = ele_status.Text.ToString();
                    if (exportFileName.Contains(fileName) && appStatus.Equals(status))
                    {
                        FoundMatchingDataRow = true;
                        thisReturnValue = true;
                    } 
                    
                    if (!FoundMatchingDataRow)
                    {
                        Navigation.ClickLink("FilesProcessingStatus");
                    }
                    ElapsedSeconds = Convert.ToInt32((DateTime.Now - Start).TotalSeconds);
                    Console.WriteLine(ElapsedSeconds.ToString());
                }
                catch { }
            }
            return thisReturnValue;
        }
}
}