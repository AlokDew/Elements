﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.IO;
using System.Linq;
using TechTalk.SpecFlow;

namespace TMSoR1
{
    [Binding]
    public class fsEAMLoadBulkAttachment
    {

        [When(@"Member Attachment page, Config File ALM Project, Test ID ""(.*)"" attached file ""(.*)"" is selected with New File Name ""(.*)""")]
        public void WhenMemberAttachmentPageConfigFileALMProjectTestIDAttachedFileIsSelectedWithNewFileName(string p0, string p1, string p2)
        {
            fw.ConsoleReport(" Deleting temp Folder contents");
            string[] fileExtensions = { ".xml", ".CSV", ".XLS", ".PDF", ".pdf", ".xls", ".csv", ".XLSX", ".txt" };
            DirectoryInfo di = new DirectoryInfo("c:\\temp\\");
            FileInfo[] oldDownloadedFiles = di.EnumerateFiles().Where(p => fileExtensions.Contains(p.Extension, StringComparer.InvariantCultureIgnoreCase)).ToArray();
            // Delete Files

            foreach (var oldFile in oldDownloadedFiles)
            {
                oldFile.Attributes = FileAttributes.Normal;
                File.Delete(oldFile.FullName);
            }
            // Delete Folder
            //foreach (DirectoryInfo dir in di.GetDirectories())
            //{
            //    dir.Delete(true);
            //}

            string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);
            bool keepTrying = true;
            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            string SourceFileLocation = "C:\\SourceFile\\";
            //Boolean didUpload = false;
            string source = SourceFileLocation + p1_gen;
            if (Directory.Exists(SourceFileLocation))
            {
                if (!File.Exists(controllerFileLocation))
                {
                    File.Copy(SourceFileLocation + p1_gen, controllerFileLocation + Path.GetFileName(source), true);
                }
            }
            bool didUpload = false;
            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");
            if (File.Exists(controllerFileLocation + p1_gen))
            {
                File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen, true);
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");
            }
            else
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");
                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
            if (didUpload)
            {
                while (keepTrying)
                {
                    string FileName = "C:\\Temp\\" + p1_gen;
                    string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen);
                    File.Move(@FileName, @newFileName);
                    FileName = newFileName;
                    fw.ExecuteJavascript(cfUIMODViewEditMember.ViewEditMemberPage.ViewAttachmentsBtn);
                    //fw.ExecuteJavascript(EAM.MembersViewEdit.AttachDocBrowse);
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement selectButton = Browser.Wd.FindElement(By.XPath("//span[contains(.,'SELECT FILES')]/preceding-sibling::input"));
                        selectButton.SendKeys(FileName);
                    }

                    else
                    {
                        EAM.MembersViewEdit.AttachDocBrowse.SendKeys(FileName);
                    }

                    fw.ExecuteJavascript(EAM.MembersViewEdit.AttachDocUpload);
              
                    tmsWait.Hard(15);

                    EAM.MembersViewEdit.AttachDocAdd.Click();
                    tmsWait.Hard(1);
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By toastMsg = By.XPath("//div[@class='k-notification-content']");
                        string actValue = Browser.Wd.FindElement(toastMsg).Text;
                        Assert.IsTrue(actValue.Contains("Member document attachment successful"), "Expected Success message is not getting displayed");
                    }

                    else
                    {
                        String msgDisplay = EAM.MemberBulkAttachment.ResponseMessage.Text;

                    Assert.IsTrue(msgDisplay.Contains("Member document attachment successful"), "Expected Success message is not getting displayed");
                    }

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement closeBtn = Browser.Wd.FindElement(By.XPath("//a[contains(@class,'close')]/span"));
                        fw.ExecuteJavascript(closeBtn);
                    }

                    else
                    {
                        fw.ExecuteJavascript(EAM.MembersViewEdit.MemberDocClose);
                   fw.ExecuteJavascript(EAM.MemberBulkAttachment.MemberDocumentsClose);
                    }
                    break;
                }
            }
        }

        [When(@"Load Bulk Attachment page, Config File ALM Project, Test ID ""(.*)"" attached file ""(.*)"" is selected with New File Name ""(.*)""")]
        public void WhenLoadBulkAttachmentPageConfigFileALMProjectTestIDAttachedFileIsSelectedWithNewFileName(string p0, string p1, string p2)
        {
            string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);
            bool keepTrying = true;
            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            bool didUpload = false;
            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");
            if (File.Exists(controllerFileLocation + p1_gen))
            {
                File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen, true);
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");
            }
            else
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");
                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
            if (didUpload)
            {
                while (keepTrying)
                {
                    string FileName = "C:\\Temp\\" + p1_gen;
                    string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen);
                    File.Move(@FileName, @newFileName);
                    FileName = newFileName;
                    EAM.LoadBulkAttachment.BrowseButton.SendKeys(FileName);
                    EAM.LoadBulkAttachment.AttachButton.Click();
                    tmsWait.Hard(5);

                    bool msgDisplay = EAM.LoadBulkAttachment.ResponseMessage.Displayed;
                    Assert.IsTrue(msgDisplay, "Expected Success message is not getting displayed");
                    break;
                }
            }
        }
    }
}
