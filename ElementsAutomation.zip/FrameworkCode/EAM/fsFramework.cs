﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using TechTalk.SpecFlow;
using OpenQA.Selenium.Support.UI;
using System.Collections.ObjectModel;


namespace TMSoR1
{
    [Binding]
    class fsFramework
    {
        [When(@"variable AppServerURL is set to ""(.*)""")]
        [Given(@"variable AppServerURL is set to ""(.*)""")]
        public void WhenVariableAppServerURLIsSetTo(string p0)
        {
            string appServerUrl = ConfigFile.URL;
            int index = appServerUrl.IndexOf('/');
            int index2 = appServerUrl.IndexOf('/', index + 1);

            string subs = appServerUrl.Substring(index2 + 1, 32);

        }

        [Given(@"Application Details link is clicked")]
        public void GivenApplicationDetailsLinkIsClicked()
        {
            try
            {
                IList<IWebElement> theseDetailLinks = Browser.Wd.FindElements(By.LinkText("Details"));
                theseDetailLinks[1].Click();
                tmsWait.Hard(1);
            }
            catch
            {
            }
        }

        [Given(@"I click on Click to Add a Client")]
        public void GivenIClickOnClickToAddAClient()
        {
            IWebElement addClient = EAM.AdministrationPage.AddClientLink;
            addClient.Click();
        }

        [When(@"Client Name is set to ""(.*)""")]
        public void WhenClientNameIsSetTo(string p0)
        {
            string generatedData = tmsCommon.GenerateData(p0);
            EAM.AdministrationPage.ClientName.Clear();
            EAM.AdministrationPage.ClientName.SendKeys(generatedData);
        }

        [Then(@"Add Client button is clicked")]
        public void ThenAddClientButtonIsClicked()
        {
            EAM.AdministrationPage.AddClient.Click();
            tmsWait.Hard(3);
            IAlert conf = Browser.Wd.SwitchTo().Alert();
            conf.Accept();
            
        }

        [Then(@"I delete the client ""(.*)""")]
        public void ThenIDeleteTheClient(string p0)
        {
            string generatedTxt = tmsCommon.GenerateData(p0);
            IWebElement clientTable = EAM.AdministrationPage.ClientTable;
            IList<IWebElement> clients = clientTable.FindElements(By.TagName("tr"));
            foreach (IWebElement client in clients)
            {
                if (client.Text.Contains(generatedTxt))
                {
                    IList<IWebElement> rowImages = client.FindElements(By.TagName("input"));
                    foreach (IWebElement thisImage in rowImages)
                    {
                        if (thisImage.GetAttribute("src").Contains("icon_delete"))
                        {
                            IJavaScriptExecutor js = Browser.Wd as IJavaScriptExecutor;
                            js.ExecuteScript("arguments[0].click();", thisImage);
                            // thisImage.Click();
                            //tmsWait.Hard(2);

                            IAlert conf = Browser.Wd.SwitchTo().Alert();
                            conf.Accept();

                            break;

                        }
                    }

                }
            }
        }

        [Then(@"Verify the client ""(.*)"" is deleted")]
        public void ThenVerifyTheClientIsDeleted(string p0)
        {
            string generatedTxt = tmsCommon.GenerateData(p0);
            IWebElement clientTable = EAM.AdministrationPage.ClientTable;
            IList<IWebElement> clients = clientTable.FindElements(By.TagName("tr"));
            foreach (IWebElement client in clients)
            {
                Assert.IsFalse(client.Text.Contains(generatedTxt));
            }
        }

        [Then(@"Verify ""(.*)"" is present in the Users Assigned Table")]
         public void ThenVerifyIsPresentInTheUsersAssignedTable(string p0)
        {
            string assignedUser = tmsCommon.GenerateData(p0);
            IWebElement assignedUsersTable = EAM.AdministrationPage.UsersGridView;
            int nextPage = 2;
            bool pageExists = true;
            while (pageExists)
            {
                try
                {
                    IWebElement page = assignedUsersTable.FindElement(By.LinkText(nextPage.ToString()));
                    nextPage++;
                }
                catch (Exception)
                {
                   
                    nextPage--;
                    if(nextPage != 1)
                        assignedUsersTable.FindElement(By.LinkText(nextPage.ToString())).Click();
                    tmsWait.Hard(2);
                    pageExists = false;
                }
            }
            assignedUsersTable = EAM.AdministrationPage.UsersGridView;

            IList<IWebElement> assignedUsers = assignedUsersTable.FindElements(By.TagName("tr"));
            bool foundUser = false;
            foreach (IWebElement user in assignedUsers)
            {
                if (user.Text.Contains(assignedUser))
                {
                    IWebElement link = user.FindElement(By.TagName("a"));
                    Assert.AreEqual(assignedUser,user.Text);
                    foundUser = true;
                }
            }
           Assert.IsTrue(foundUser);
        }

        [Then(@"""(.*)"" is deleted")]
        public void ThenIsDeleted(string p0)
        {
            string assignedUser = tmsCommon.GenerateData(p0);
            bool nextPage = false;
            bool isDeleted = false;
            int index = 0;
            int pageCount = Browser.Wd.FindElements(By.XPath("//table[@id='UsersGridView']//tr[@class='pagerArea']//tbody//td")).Count;
            do
            {
                nextPage = IsAssignedUserPresent(assignedUser);
                if (nextPage)
                {
                    index++;
                    Browser.Wd.FindElement(By.XPath("//table[@id='UsersGridView']//tr[@class='pagerArea']//tbody//td[contains(.,'"+index+"')]")).Click();
                }
            } while (nextPage);

            Browser.Wd.FindElement(By.XPath("//table[@id='UsersGridView']//a[contains(.,'"+assignedUser+"')]/parent::td/input")).Click();
            tmsWait.WaitForAlertPresent();
            if (tmsWait.IsAlertPresent())
            {
                IAlert conf = Browser.Wd.SwitchTo().Alert();
                conf.Accept();
                isDeleted = true;
            }
            Assert.IsTrue(isDeleted);
        }

        public bool IsAssignedUserPresent(string p0)
        {
            string assignedUser = tmsCommon.GenerateData(p0);
            try
            {
                if (Browser.Wd.FindElement(By.XPath("//table[@id='UsersGridView']//a[contains(.,'"+assignedUser+"')]")).Displayed)
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                return true;
            }
            return true;
        }

        [Then(@"Verify that ""(.*)"" is displayed")]
        public void ThenVerifyThatIsDisplayed(string p0)
        {
            tmsWait.Hard(2);
            IWebElement loginErrorMsg = EAM.AdministrationPage.ErrorLogin;
            Assert.AreEqual(p0,loginErrorMsg.Text);
        }

        [Then(@"Click on the Assigned User Link for user ""(.*)""")]
        public void ThenClickOnTheAssignedUserLinkForUser(string p0)
        {
            string assignedUser = tmsCommon.GenerateData(p0);
            IWebElement assignedUsersTable = EAM.AdministrationPage.UsersGridView;
            int nextPage = 2;
            bool pageExists = true;
            while (pageExists)
            {
                try
                {
                    IWebElement page = assignedUsersTable.FindElement(By.LinkText(nextPage.ToString()));
                    nextPage++;
                }
                catch (Exception)
                {

                    nextPage--;
                    if (nextPage != 1)
                        assignedUsersTable.FindElement(By.LinkText(nextPage.ToString())).Click();
                    tmsWait.Hard(2);
                    pageExists = false;
                }
            }
            assignedUsersTable = EAM.AdministrationPage.UsersGridView;

            IList<IWebElement> assignedUsers = assignedUsersTable.FindElements(By.TagName("tr"));

            foreach (IWebElement user in assignedUsers)
            {
                if (user.Text.Contains(assignedUser))
                {
                    IWebElement userLink = user.FindElement(By.TagName("a"));
                    userLink.Click();
                    break;
                }
            }
        }

        [Then(@"Update the User First Name to ""(.*)""")]
        public void ThenUpdateTheUserFirstNameTo(string p0)
        {
            string newFirstName = tmsCommon.GenerateData(p0);
            EAM.UserAdministrationCrudUser.EditUserFirstName.Clear();
            EAM.UserAdministrationCrudUser.EditUserFirstName.SendKeys(newFirstName);
        }

        [Then(@"Update the User Last Name to ""(.*)""")]
        public void ThenUpdateTheUserLastNameTo(string p0)
        {
            string newLastName = tmsCommon.GenerateData(p0);
            EAM.UserAdministrationCrudUser.EditUserLastName.Clear();
            EAM.UserAdministrationCrudUser.EditUserLastName.SendKeys(newLastName);
        }

        [Then(@"Verify Administration UserSearchTable Table has row")]
        public void ThenVerifyAdministrationUserSearchTableTableHasRow(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.UserAdministrationSearchUser.UserSearchTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");
                //               Boolean bTransStatusMatching = false;
                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {

                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //if(AppTableRow.Equals(GherkinTableArray[iElementCounter])
                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (appTD.Equals("Canceled"))
                                //{

                                //    Assert.IsTrue(appTD.Equals("Canceled"));
                                //    bTransStatusMatching = true;
                                //    //Console.WriteLine("TC 61 status is found as Canceled");
                                //}

                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //    //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }


                        }

                    }
                    iTableCounter++;
                    //if (bTransStatusMatching)
                    //{
                    //    Console.WriteLine("Transaction status is updated to Canceled in Transaction History");
                    //}
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                //if (bTransStatusMatching)
                //{
                //    Console.WriteLine("Member Info page Transaction status is updated to Canceled in Transaction History table");
                //}

                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.UserAdministrationSearchUser.UserSearchTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }

        }

        [Then(@"Verify the Manage button exists")]
        public void ThenVerifyTheManageButtonExists()
        {
            IWebElement manageBtn = EAM.AdministrationJobsPage.JobsPageManage;
            Assert.IsNotNull(manageBtn);
        }

        [Then(@"Click on the Manage Button")]
        [Given(@"Click on the Manage Button")]
        public void ThenClickOnTheManageButton()
        {
            EAM.AdministrationJobsPage.JobsPageManage.Click();
        }

        [Then(@"Verify the Manage start up Table opens up")]
        public void ThenVerifyTheManageStartUpTableOpensUp()
        {
            IWebElement manageJobsTable = EAM.AdministrationJobsPage.ManageJobsTable;
            Assert.IsNotNull(manageJobsTable);
        }
        [Then(@"Select the enable check for the database ""(.*)""")]
        public void ThenSelectTheEnableCheckForTheDatabase(string p0)
        {
            IWebElement permissionTable = EAM.UserAdministrationCrudUser.EditApplicationPermission;
            string databaseName = tmsCommon.GenerateData(p0);

            IList<IWebElement> allElements1 = permissionTable.FindElements(By.TagName("tr")); // you have all row that are visible
            int thisCount1 = allElements1.Count;
            IWebElement thisWebElement1 = null;
            foreach (IWebElement abc in allElements1)
            {
                thisWebElement1 = abc;
                if (abc.Text.Contains(databaseName))
                {
                    IWebElement checkSel = abc.FindElement(By.XPath("./td[1]"));
                    if(checkSel.Selected)
                        checkSel.Click();

                    IWebElement role = abc.FindElement(By.TagName("select"));
                    SelectElement select = new SelectElement(role);
                    select.SelectByText("Administrator");
                    break;
                }
            }

            SelectElement selectrole = new SelectElement(Browser.Wd.FindElement(By.Id("EditUserAssignedAppsGridView_ctl02_ddlAccessLevel")));
            selectrole.SelectByText("Client Manager");
        }

        [Then(@"I switch to page ""(.*)"" of jobs page")]
        public void ThenISwitchToPageOfJobsPage(int p0)
        {
            string pageNumber = p0.ToString();
            IWebElement manageJobsTable = EAM.AdministrationJobsPage.ManageJobsTable;
            IWebElement footer = manageJobsTable.FindElement(By.CssSelector(("[class='rgPagerCell NextPrevAndNumeric']")));
            IWebElement pageElement = footer.FindElement(By.LinkText(pageNumber));
            pageElement.Click();
        }

        [Then(@"Verify ""(.*)"" page of jobs is open")]
        public void ThenVerifyPageOfJobsIsOpen(int p0)
        {
            string pageNumber = p0.ToString();
            tmsWait.Hard(2);
            IWebElement manageJobsTable = EAM.AdministrationJobsPage.ManageJobsTable;
            IWebElement footer = manageJobsTable.FindElement(By.CssSelector(("[class='rgPagerCell NextPrevAndNumeric']")));
            IWebElement curPage = footer.FindElement(By.CssSelector(("[class='rgCurrentPage']")));
            IWebElement pageNum = curPage.FindElement(By.TagName("span"));
            Assert.AreEqual(pageNum.Text,pageNumber);
        }

        [When(@"I click on last page of Manage JObs")]
        public void WhenIClickOnLastPageOfManageJObs()
        {
            IWebElement manageJobsTable = EAM.AdministrationJobsPage.ManageJobsTable;
            IWebElement footer = manageJobsTable.FindElement(By.CssSelector(("[class='rgPagerCell NextPrevAndNumeric']")));
            IWebElement lastPage = footer.FindElement(By.CssSelector(("[class='rgPageLast']")));
            lastPage.Click();
        }

        [Then(@"Verify the last page is opened")]
        public void ThenVerifyTheLastPageIsOpened()
        {
            tmsWait.Hard(2);
            IWebElement manageJobsTable = EAM.AdministrationJobsPage.ManageJobsTable;
            IWebElement footer = manageJobsTable.FindElement(By.CssSelector(("[class='rgPagerCell NextPrevAndNumeric']")));
            IWebElement curPage = footer.FindElement(By.CssSelector(("[class='rgCurrentPage']")));
            string pageNum = curPage.FindElement(By.TagName("span")).Text;
            int lastPage = Int32.Parse(pageNum);
            int beyondLastPage = lastPage + 1;
            try
            {
                IWebElement pageElement = footer.FindElement(By.LinkText(beyondLastPage.ToString()));
            }
            catch (Exception)
            {
                
                Assert.IsTrue(true);
            }


        }

        [Then(@"close the popup for Jobs page;")]
        public void ThenCloseThePopupForJobsPage()
        {
            IWebElement close = Browser.Wd.FindElement(By.CssSelector(("[class='ui-icon ui-icon-closethick']")));
            close.Click();
        }

        [Then(@"refresh the page")]
        public void ThenRefreshThePage()
        {
            Browser.Wd.Navigate().Refresh();

        }

        [Then(@"Verify ""(.*)"" is displayed under the TriZetto logo")]
        public void ThenVerifyIsDisplayedUnderTheTriZettoLogo(string p0)
        {
            string db = tmsCommon.GenerateData(p0);
            Navigation.VerifyDBExists(db);
        }



        [Then(@"Verify the Disable button exists")]
        public void ThenVerifyTheDisableButtonExists()
        {
            IWebElement disableBtn = EAM.AdministrationJobsPage.DisableBtn;
            Assert.IsNotNull(disableBtn);
        }

        [Then(@"Click on the Disable Button and store ""(.*)""")]
        public void ThenClickOnTheDisableButtonAndStore(string p0)
        {
            IWebElement jobsTable = EAM.AdministrationJobsPage.JobsGrid;
            IList<IWebElement> jobs = jobsTable.FindElements(By.TagName("tr"));
            string jobIdValue = null;
            foreach(IWebElement job in jobs)
            {
                IWebElement actionCheck = job.FindElement(By.XPath("./td[1]"));
                if(actionCheck.Enabled)
                {
                    actionCheck.Click();
                    IWebElement jobIdColumn = job.FindElement(By.XPath("./td[2]"));
                    IWebElement jobId = jobIdColumn.FindElement(By.TagName("a"));
                    jobIdValue = jobId.FindElement(By.TagName("span")).Text;
                    GlobalRef.RequestID = jobIdValue;
                    EAM.AdministrationJobsPage.DisableBtn.Click();
                }
            }

        }

        [Then(@"Click on the Disable Button and store RequestID")]
        public void ThenClickOnTheDisableButtonAndStoreRequestID()
        {

            int count = 0;

            while (count < 8)
            {
                try
                {
                    Browser.Wd.FindElement(By.TagName("body")).SendKeys("Keys.ESCAPE");
                    IWebElement jobsTable = EAM.AdministrationJobsPage.JobsGrid;
                    
                    IList<IWebElement> jobs = jobsTable.FindElements(By.TagName("tr"));

                    string jobIdValue = null;
                    //IWebElement row2 = jobs[1];

                    //IWebElement col1 = row2.FindElement(By.XPath("./td[1]"));
                    //col1.Click();
                    //col1.Click();

                    //IWebElement jobIdColumn = row2.FindElement(By.XPath("./td[2]"));
                    //IWebElement jobId = jobIdColumn.FindElement(By.TagName("a"));
                    //jobIdValue = jobId.Text.ToString();
                    break;


                   /* IList<IWebElement> columns = row2.FindElements(By.TagName("td"));
                    foreach (IWebElement col in columns)
                    {
                        col.Click();
                    }*/
                    foreach (IWebElement job in jobs)
                    {
                        IWebElement actionCheck = job.FindElement(By.XPath("./td[1]"));
                        if (actionCheck.Enabled)
                        {
                            actionCheck.Click();
                            IWebElement jobIdColumn = job.FindElement(By.XPath("./td[2]"));
                            //Browser.Wd.FindElement(By.TagName("body")).SendKeys("Keys.ESCAPE");
                            IWebElement jobId = jobIdColumn.FindElement(By.TagName("a"));
                            jobIdValue = jobId.Text;
                            //jobIdValue = jobId.FindElement(By.TagName("span")).ToString();
                            GlobalRef.RequestID = jobIdValue;
                            //IWebElement disableBtn = EAM.AdministrationJobsPage.DisableBtn;
                            //disableBtn.Refresh();
                            //disableBtn.Click();
                            EAM.AdministrationJobsPage.DisableBtn.Click();
                            break;
                        }
                    }
                }
                catch (StaleElementReferenceException e)
                {
                    tmsWait.Hard(5);
                    e.ToString();
                    count = count + 1;
                }
            }
        }


        [Then(@"Click on the Disable Button and store RequestID in ""(.*)""")]
        public void ThenClickOnTheDisableButtonAndStoreRequestIDIn(string p0)
        {
            int count = 0;

            while (count < 4)
            {
                try
                {
                   // Browser.Wd.FindElement(By.TagName("body")).SendKeys("Keys.ESCAPE");
                    IWebElement jobsTable = EAM.AdministrationJobsPage.JobsGrid;

                    IList<IWebElement> jobs = jobsTable.FindElements(By.TagName("tr"));

                    for( int i =1; i<= jobs.Count; i++)
                    {
                        IWebElement curRow = jobs[i];
                        IWebElement actionCheck = curRow.FindElement(By.XPath("./td[1]"));
                        if (actionCheck.Enabled)
                        {
                            actionCheck.Click();
                            actionCheck.Click();
                            IWebElement jobIdColumn = curRow.FindElement(By.XPath("./td[2]"));
                            //Browser.Wd.FindElement(By.TagName("body")).SendKeys("Keys.ESCAPE");
                            IWebElement jobId = jobIdColumn.FindElement(By.TagName("a"));
                            fw.setVariable(p0, jobId.Text);
                            
                            
                            EAM.AdministrationJobsPage.DisableBtn.Click();
                            break;
                        }

                    }
                }
                catch (StaleElementReferenceException e)
                {
                    tmsWait.Hard(5);
                    e.ToString();
                    count = count + 1;
                }
            }
        }


        [Then(@"Select the Filter By Status as ""(.*)""")]
        public void ThenSelectTheFilterByStatusAs(string p0)
        {
            IWebElement filterByStatus = EAM.AdministrationJobsPage.FilterStatus;
            SelectElement select = new SelectElement(filterByStatus);            
            select.SelectByText(p0);
        }


        [Then(@"Select an enable job which has status ""(.*)""")]
        public void ThenSelectAnEnableJobWhichHasStatus(string p0)
        {
           
        }

        [Then(@"Click on the Disable Button")]
        public void ThenClickOnTheDisableButton()
        {
            
        }

        [Then(@"Verify that ""(.*)"" message is displayed on home page")]
        public void ThenVerifyThatMessageIsDisplayedOnHomePage(string p0)
        {
            Assert.AreEqual(EAM.AdministrationJobsPage.Span1TxtMsg.Text, p0);
        }

        [Then(@"Select the job with ""(.*)"" and status ""(.*)""")]
        public void ThenSelectTheJobWithAndStatus(string p0, string p1)
        {
            
        }

        [Then(@"Change the Disabled job status to Pending")]
        public void ThenChangeTheDisabledJobStatusToPending()
        {
            IWebElement jobsTable = EAM.AdministrationJobsPage.JobsGrid;
            IList<IWebElement> jobs = jobsTable.FindElements(By.TagName("tr"));
            string jobIdValue = null;
            foreach (IWebElement job in jobs)
            {
                IWebElement actionCheck = job.FindElement(By.XPath("./td[1]"));
                if (job.Text.Contains(GlobalRef.RequestID.ToString()))
                {
                    actionCheck.Click();
                    EAM.AdministrationJobsPage.PendingBtn.Click();
                }
            }
        }


        [Then(@"Click on the PENDING Button")]
        public void ThenClickOnThePENDINGButton()
        {
           
        }

        [Then(@"Verify that ""(.*)"" message is displayed")]
        public void ThenVerifyThatMessageIsDisplayed(string p0)
        {
           
        }

        [Given(@"I click on ""(.*)"" Details link on the Client Table")]
        [Then(@"I click on ""(.*)"" Details link on the Client Table")]
        public void GivenIClickOnDetailsLinkOnTheClientTable(string p0)
        {
            string generatedTxt = tmsCommon.GenerateData(p0);
            IWebElement clientTable = EAM.AdministrationPage.ClientTable;
            IList<IWebElement> clients = clientTable.FindElements(By.TagName("tr"));
            foreach (IWebElement client in clients)
            {
                if (client.Text.Contains(generatedTxt))
                {
                    IWebElement detailLink = client.FindElement(By.LinkText("Details"));
                    detailLink.Click();
                    break;
                }
            }
        }

        [Then(@"Verify the ManageJobs Table has")]
        public void ThenVerifyTheManageJobsTableHas(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.AdministrationJobsPage.ManageJobsTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same
                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }

                baseTable = EAM.AdministrationJobsPage.ManageJobsTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }
        }


        //[Then(@"Verify Users Assigned Table has row")]
        //public void ThenVerifyUsersAssignedTableHasRow(Table table)
        //{
        //     //Create Storage for the Gherkin table and the page data
        //    GherkinTable thisGT = new GherkinTable();
        //    TablePaging thisTP = new TablePaging();

        //    //Load the Gherkin table into the storage
        //    thisGT.LoadGherkinTable(table);

        //    //The big loop.  Keep working until all the Gherkin table rows are marked as matched
        //    //Or until we are on the last page of records, then we also quit looking.
        //    while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
        //    {
        //        //Start out with the assumption we are not on the last page of records.  We will check later.
        //        thisTP.bNotAtLastPageOfRecords = true;

        //        //Get the table object again, since the page refreshes we need to get it fresh
        //        IWebElement baseTable = EAM.AdministrationPage.UsersGridView;

        //        //Look for a next page link.  We will set 'last page of records' here also.
        //        thisTP.LoadNextPageLink(baseTable);

        //        //Load the page data off the application.   
        //        //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
        //        thisTP.LoadPageTable(baseTable, "td", "td");

        //        int iTableCounter = 0;
        //        //                string expectedTableCheckboxValue = "";
        //        //for each row in the Gherkin table, start flipping through all the rows in the page data.
        //        foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
        //        {
        //            //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

        //            //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
        //            if (GherkinTableRow == null)
        //            {
        //                break;
        //            }

        //            //If this Gherkin table row is not yet matched, proceed.
        //            if (GherkinTableRow.RowIsMatched == false)
        //            {
        //                //Convert the row to an array so we can do an element by element match.
        //                string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

        //                //For each row in the page data
        //                foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
        //                {
        //                    //Convert page data to array elements
        //                    //Only work with the loaded element rows.  The first unloaded one will be null.
        //                    if (ApplicationRow == null)
        //                    {
        //                        break;
        //                    }

        //                    //Convert the page row to array so we can pair up by elements.
        //                    string[] AppTableRow = ApplicationRow.Row.ToArray();
        //                    int iElementCounter = 0;
        //                    Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

        //                    //In here as we pair up the data you will have custom matching.
        //                    //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
        //                    foreach (string appTD in AppTableRow)
        //                    {
        //                        //if (iElementCounter > 0 && TDA.RowIsData)
        //                        if (ApplicationRow.RowIsData)
        //                        {
        //                            //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
        //                            if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
        //                            {
        //                                bThisRowMatches = false;
        //                            }
        //                        }
        //                        else
        //                        {
        //                            //Also fail row match if the element count of the page data row is 0
        //                            if (iElementCounter > 0)
        //                            {
        //                                bThisRowMatches = false;
        //                            }
        //                        }
        //                        iElementCounter++;
        //                    }
        //                    if (AppTableRow.Length == 0)
        //                    {
        //                        //Another check that if the page data row is 0 long, we didn't match, fail the match.
        //                        bThisRowMatches = false;
        //                    }
        //                    //Instance of TableRow Class for reporting functions
        //                    var TableRow = new TMSString();
        //                    //If we get here and we still match, then the array elements were the same
        //                    if (bThisRowMatches)
        //                    {
        //                        //report the success stuff.  Puts out the row data, etc.
        //                        thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
        //                    }
        //                }
        //            }
        //            iTableCounter++;
        //        }
        //        //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
        //        Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
        //        if (fullMatching)
        //        {
        //            Console.WriteLine("All rows are matched, step completed as passed");
        //        }
        //        else
        //        {
        //            //Click next page link and start over.
        //            if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
        //            {
        //                thisTP.bNotAtLastPageOfRecords = true;
        //                thisTP.NPL.Click();
        //                tmsWait.Hard(2);
        //            }
        //        }

        //        baseTable = EAM.AdministrationPage.UsersGridView;

        //        //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
        //        //Time to boil it down and report which rows didn't get matched.
        //        //Also to fail because we were planning to match the rows.
        //        if (thisTP.bHaveGoodPageLink == false && !fullMatching)
        //        {
        //            thisTP.ReportNotMatching(thisGT.GTable);
        //        }
        //    }
        //}
       }
 
