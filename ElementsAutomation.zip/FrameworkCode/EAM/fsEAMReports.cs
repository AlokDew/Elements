﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows;
using System.Drawing;
using OpenQA.Selenium.Support.UI;
using System.Collections.ObjectModel;
//using System.Windows.Forms;
using System.IO;
using TMSoR1.FrameworkCode;

namespace TMSoR1
{
    /// <summary>
    /// Common class for Reports.
    /// Contains methods which can be used in binding classes.
    /// </summary>
    public static class ReportsCommon
    {
        /// <summary>
        /// MainWindowHandle - handle of current window
        /// </summary>

        public static string MainWindowHandle = "";
        /// <summary>
        /// ReportWindowHandle - handle of new opened window. Initialized if report window is found and is used in other methods like VerifyReportHasData, CloseReport etc.
        /// </summary>
        public static string ReportWindowHandle = "";

        /// <summary>
        /// Find window which is not the same as curent one and initialize MainWindowHandle, ReportWindowHandle with appropriate values.
        /// Waits until expected text appears.
        /// </summary>
        public static string SwitchToReportWindow(By reportViewBy, int timeout, string expectedText)
        {
            tmsWait.Hard(2);
           Boolean applicationName= Browser.Wd.PageSource.Contains("Medicare Solutions | Risk Score Manager");
            string reportHandle = "", currentHandle = "";
            ReadOnlyCollection<string> windowHandles = Browser.Wd.WindowHandles;
            currentHandle = Browser.Wd.CurrentWindowHandle;

            if (MainWindowHandle == "")
            {
                MainWindowHandle = currentHandle;
            }
            if (MainWindowHandle != currentHandle)
            {
                if (ReportWindowHandle == "")
                {
                    ReportWindowHandle = currentHandle;
                }
                return currentHandle;
            }

            ReportWindowHandle = "";

            foreach (string handle in windowHandles)
            {
                if (handle != MainWindowHandle)
                {
                    reportHandle = handle;
                    break;
                }
            }
            for (int i = 0; i < 6; i++)
            {
                try
                {
                    Browser.Wd.SwitchTo().Window(reportHandle).SwitchTo().DefaultContent().SwitchTo().Frame(0);
                    break;
                }
                catch (Exception) { tmsWait.Hard(2); }
            }
            for (int i = 0; i < 6; i++)
            {
                try
                {
                    new WebDriverWait(Browser.Wd.SwitchTo().Window(reportHandle).SwitchTo().DefaultContent().SwitchTo().Frame(0), TimeSpan.FromSeconds(timeout)).Until(drv => drv.FindElement(reportViewBy));
                    break;
                }
                catch (Exception) { tmsWait.Hard(2); }
            }
            for (int i = 0; i < 6; i++)
            {
                try
                {
                    new WebDriverWait(Browser.Wd.SwitchTo().Window(reportHandle).SwitchTo().DefaultContent().SwitchTo().Frame(0), TimeSpan.FromSeconds(timeout)).Until(drv => drv.FindElement(reportViewBy).Text.Contains(expectedText));
                    break;
                }
                catch (Exception) { tmsWait.Hard(2); }
            }
            
            // Updating code as RSM report page don`t have iframe so existing code is not working.
            string reportText;
            
            if (applicationName==false)
            {
                //reportText = Browser.Wd.SwitchTo().Window(reportHandle).SwitchTo().DefaultContent().SwitchTo().Frame(0).FindElement(reportViewBy).Text;
                reportText = Browser.Wd.SwitchTo().Window(reportHandle).SwitchTo().DefaultContent().FindElement(reportViewBy).Text;
            }
            else{
                 reportText = Browser.Wd.SwitchTo().Window(reportHandle).SwitchTo().DefaultContent().FindElement(reportViewBy).Text;
            }

            Assert.IsTrue(reportText.Contains(expectedText), "report was not opened");
            fw.ConsoleReport("Report was opened");

            ReportWindowHandle = reportHandle;
            return reportHandle;
           
        }

        /// <summary>
        /// Navigates to page by index in the Report Window: place index into the input box with current page number and press Enter.
        /// </summary>
        public static void NavigateToReportPageByIndex(string strNextPageIndex)
        {
            IWebElement CurrentPage = Browser.Wd.SwitchTo().Window(ReportWindowHandle).SwitchTo().DefaultContent().SwitchTo().Frame(0).FindElement(EAM.CMSResponseCodeLevelDetailReport.CurentPageBy);
            CurrentPage.Clear();
            CurrentPage.SendKeys(strNextPageIndex);
            CurrentPage.SendKeys(OpenQA.Selenium.Keys.Enter);
            tmsWait.Hard(5);

            Browser.Wd.SwitchTo().Window(MainWindowHandle);
        }

        /// <summary>
        /// Navigates to page (next or previous) in the Report window.
        /// If isNext == true, navigates to the next page, if false - navigates to the previous one
        /// </summary>
        public static bool NavigateToReportPage(bool isNext)
        {
            try
            {
                IWebElement CurrentPage = Browser.Wd.SwitchTo().Window(ReportWindowHandle).SwitchTo().DefaultContent().SwitchTo().Frame(0).FindElement(EAM.CMSResponseCodeLevelDetailReport.CurentPageBy);
                IWebElement TotalPage = Browser.Wd.SwitchTo().Window(ReportWindowHandle).SwitchTo().DefaultContent().SwitchTo().Frame(0).FindElement(EAM.CMSResponseCodeLevelDetailReport.ReportTotalPages);

                string strCurrPageNumber = CurrentPage.GetAttribute("value");
                string strTotalPageNumber = TotalPage.Text;

                //Return false if it is impossible to navigate to the next page
                if (strTotalPageNumber.Contains(strCurrPageNumber) && !strTotalPageNumber.Contains("?"))
                {
                    fw.ConsoleReport(String.Format("Report is opened on the last page = [{0}]", strTotalPageNumber));
                    if (isNext)
                    {
                        Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle);
                        return false;
                    }
                }
                //Return false if it is impossible to navigate to the previous page
                if (strCurrPageNumber == "1" && !isNext)
                {
                    fw.ConsoleReport("Report is opened on the first page");
                    Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle);
                    return false;
                }

                if (isNext)
                {
                    Browser.Wd.SwitchTo().Window(ReportWindowHandle).SwitchTo().DefaultContent().SwitchTo().Frame(0).FindElement(EAM.CMSResponseCodeLevelDetailReport.ReportNextPageLink).Click();
                }
                else
                {
                    Browser.Wd.SwitchTo().Window(ReportWindowHandle).SwitchTo().DefaultContent().SwitchTo().Frame(0).FindElement(EAM.CMSResponseCodeLevelDetailReport.ReportPreviousPageLink).Click();
                }

                tmsWait.Hard(10);

                Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle);
                return true;
            }
            catch (Exception e)
            {
                fw.ConsoleReport(String.Format("Unable to navigate by Report pages: {0}", e.Message));
                return false;
            }
        }

        ///<summary>
        /// Verify if expected Text exists inside HTML report
        /// </summary>
        /// <param name="textarea"></param>
        /// <param name="table"></param>
        /// 

        public static void VerifyHTMLReportHasData(Table table)
        {
            Boolean haveMatchedThisHIC = false;
            Boolean haveMatchedThisFirst = false;
            Boolean haveMatchedThisLast = false;
            Boolean haveMatchedThisMissing = false;
            string dataHIC = "";
            string dataFirst = "";
            string dataLast = "";
            string dataMissingItemOther = "";


            tmsWait.Hard(2);

            if (EAM.Reports.HTMLTextArea.Enabled)
            {
                tmsWait.Hard(1);

                IList<IWebElement> values = Browser.Wd.FindElements(By.Id("TMSTextArea"));

                // retrieving Gherkin Table data
                foreach (var dataRow in table.Rows)
                {
                    dataHIC = tmsCommon.GenerateData(dataRow[0].ToString());
                    dataFirst = tmsCommon.GenerateData(dataRow[1].ToString());
                    dataLast = tmsCommon.GenerateData(dataRow[2].ToString());
                    dataMissingItemOther = tmsCommon.GenerateData(dataRow[3].ToString());
                    List<string> compiledTRText = new List<string>();
                    List<string> compiledTRTextsp = new List<string>();


                    // Removing Back spance and new line charactes from Application retrieved data
                    foreach (IWebElement thisData in values)
                    {
                        string thisTRString = thisData.Text.Replace("\n", "");
                        thisTRString = thisTRString.Replace("\r", "|");
                        if (thisTRString.Trim() != "")
                        {
                            compiledTRText.Add(thisTRString.Trim());
                            string thisTRStringsp = thisData.Text.Replace("\n\r", " ");
                            thisTRStringsp = thisTRStringsp.Replace("\r\n", " ");
                            compiledTRTextsp.Add(thisTRStringsp.Trim());
                        }
                    }

                    // Comparing Application Data with gherkin Data
                    foreach (string AppTRow in compiledTRTextsp)
                    {
                        if (AppTRow.Trim().Contains(dataHIC))
                        {
                            haveMatchedThisHIC = true;
                            Console.WriteLine("Have matched the Gherkin data  [" + dataHIC + "] in HTML Report [" + AppTRow + "]");

                        }
                        if (AppTRow.Trim().Contains(dataFirst))
                        {
                            haveMatchedThisFirst = true;
                            Console.WriteLine("Have matched the Gherkin data  [" + dataFirst + "] in HTML Report [" + AppTRow + "]");

                        }

                        if (AppTRow.Trim().Contains(dataLast))
                        {
                            haveMatchedThisLast = true;
                            Console.WriteLine("Have matched the Gherkin data  [" + dataLast + "] in HTML Report [" + AppTRow + "]");

                        }

                        if (AppTRow.Trim().Contains(dataMissingItemOther))
                        {
                            haveMatchedThisMissing = true;
                            Console.WriteLine("Have matched the Gherkin data  [" + dataMissingItemOther + "] in HTML Report [" + AppTRow + "]");

                        }

                    }

                }




            }

            if (!haveMatchedThisHIC)
            {
                Console.WriteLine("*******");
                Console.WriteLine("Data mismatch trying to find [" + dataHIC + "]");
                Console.WriteLine("*******");
                //                    MessageBox.Show("Was not able to match data pair [" + dataLabelValuePair + "] or [" + dataLabelValuePairNS + "] in the drill down table");
                Assert.AreEqual(true, false, "Was not able to match Gherkin data  [" + dataHIC + "] in the HTML Report");
            }
            if (!haveMatchedThisFirst)
            {
                Console.WriteLine("*******");
                Console.WriteLine("Data mismatch trying to find [" + dataFirst + "]");
                Console.WriteLine("*******");
                //                    MessageBox.Show("Was not able to match data pair [" + dataLabelValuePair + "] or [" + dataLabelValuePairNS + "] in the drill down table");
                Assert.AreEqual(true, false, "Was not able to match Gherkin data [" + dataFirst + "]  in the HTML Report");
            }

            if (!haveMatchedThisLast)
            {
                Console.WriteLine("*******");
                Console.WriteLine("Data mismatch trying to find [" + dataLast + "]");
                Console.WriteLine("*******");
                //                    MessageBox.Show("Was not able to match data pair [" + dataLabelValuePair + "] or [" + dataLabelValuePairNS + "] in the drill down table");
                Assert.AreEqual(true, false, "Was not able to match Gherkin data [" + dataLast + "]  in the HTML Report");
            }
            if (!haveMatchedThisMissing)
            {
                Console.WriteLine("*******");
                Console.WriteLine("Data mismatch trying to find [" + dataFirst + "]");
                Console.WriteLine("*******");
                //                    MessageBox.Show("Was not able to match data pair [" + dataLabelValuePair + "] or [" + dataLabelValuePairNS + "] in the drill down table");
                Assert.AreEqual(true, false, "Was not able to match Gherkin data [" + dataMissingItemOther + "] in the HTML Report");
            }




        }


        /// <summary>
        /// Verify if expected Text exists inside PDF Report
        /// </summary>

        /// <param name="reportExpText"></param>
        /// <param name="table"></param>
        public static void VerifyPDFReportHasData(Table table)
        {

            Boolean haveMatchedThisHIC = false;
            Boolean haveMatchedThisFirst = false;
            Boolean haveMatchedThisLast = false;
            Boolean haveMatchedThisMissing = false;
            string dataHIC = "";
            string dataFirst = "";
            string dataLast = "";
            string dataMissingItemOther = "";


            tmsWait.Hard(2);

            while (EAM.Reports.enrollmentLetterPDFNext.Enabled)
            {
                tmsWait.Hard(1);

                IList<IWebElement> values = Browser.Wd.FindElements(By.XPath("//div[starts-with(@id,'pageContainer')]/div[@class='textLayer']/div"));

                // retrieving Gherkin Table data
                foreach (var dataRow in table.Rows)
                {
                    dataHIC = tmsCommon.GenerateData(dataRow[0].ToString());
                    dataFirst = tmsCommon.GenerateData(dataRow[1].ToString());
                    dataLast = tmsCommon.GenerateData(dataRow[2].ToString());
                    dataMissingItemOther = tmsCommon.GenerateData(dataRow[3].ToString());
                    List<string> compiledTRText = new List<string>();
                    List<string> compiledTRTextsp = new List<string>();


                    // Removing Back spance and new line charactes from Application retrieved data
                    foreach (IWebElement thisData in values)
                    {
                        string thisTRString = thisData.Text.Replace("\n", "");
                        thisTRString = thisTRString.Replace("\r", "");
                        if (thisTRString.Trim() != "")
                        {
                            compiledTRText.Add(thisTRString.Trim());
                            string thisTRStringsp = thisData.Text.Replace("\n\r", " ");
                            thisTRStringsp = thisTRStringsp.Replace("\r\n", " ");
                            compiledTRTextsp.Add(thisTRStringsp.Trim());
                        }
                    }

                    // Comparing Application Data with gherkin Data
                    foreach (string AppTRow in compiledTRTextsp)
                    {
                        if (AppTRow.Trim().Contains(dataHIC))
                        {
                            haveMatchedThisHIC = true;
                            Console.WriteLine("Have matched the Gherkin data  [" + dataHIC + "] in PDF Report [" + AppTRow + "]");

                        }
                        if (AppTRow.Trim().Contains(dataFirst))
                        {
                            haveMatchedThisFirst = true;
                            Console.WriteLine("Have matched the Gherkin data  [" + dataFirst + "] in PDF Report [" + AppTRow + "]");

                        }

                        if (AppTRow.Trim().Contains(dataLast))
                        {
                            haveMatchedThisLast = true;
                            Console.WriteLine("Have matched the Gherkin data  [" + dataLast + "] in PDF Report [" + AppTRow + "]");

                        }

                        if (AppTRow.Trim().Contains(dataMissingItemOther))
                        {
                            haveMatchedThisMissing = true;
                            Console.WriteLine("Have matched the Gherkin data  [" + dataMissingItemOther + "] in PDF Report [" + AppTRow + "]");

                        }

                    }

                }

                if (EAM.Reports.enrollmentLetterPDFNext.Enabled)
                {
                    EAM.Reports.enrollmentLetterPDFNext.Click();
                    EAM.Reports.enrollmentLetterPDFNext.Click();
                }
                else
                {
                    break;
                }
            }

            if (!haveMatchedThisHIC)
            {
                Console.WriteLine("*******");
                Console.WriteLine("Data mismatch trying to find [" + dataHIC + "]");
                Console.WriteLine("*******");
                //                    MessageBox.Show("Was not able to match data pair [" + dataLabelValuePair + "] or [" + dataLabelValuePairNS + "] in the drill down table");
                Assert.AreEqual(true, false, "Was not able to match Gherkin data  [" + dataHIC + "] in the PDF Report");
            }
            if (!haveMatchedThisFirst)
            {
                Console.WriteLine("*******");
                Console.WriteLine("Data mismatch trying to find [" + dataFirst + "]");
                Console.WriteLine("*******");
                //                    MessageBox.Show("Was not able to match data pair [" + dataLabelValuePair + "] or [" + dataLabelValuePairNS + "] in the drill down table");
                Assert.AreEqual(true, false, "Was not able to match Gherkin data [" + dataFirst + "]  in the PDF Report");
            }

            if (!haveMatchedThisLast)
            {
                Console.WriteLine("*******");
                Console.WriteLine("Data mismatch trying to find [" + dataLast + "]");
                Console.WriteLine("*******");
                //                    MessageBox.Show("Was not able to match data pair [" + dataLabelValuePair + "] or [" + dataLabelValuePairNS + "] in the drill down table");
                Assert.AreEqual(true, false, "Was not able to match Gherkin data [" + dataLast + "]  in the PDF Report");
            }
            if (!haveMatchedThisMissing)
            {
                Console.WriteLine("*******");
                Console.WriteLine("Data mismatch trying to find [" + dataFirst + "]");
                Console.WriteLine("*******");
                //                    MessageBox.Show("Was not able to match data pair [" + dataLabelValuePair + "] or [" + dataLabelValuePairNS + "] in the drill down table");
                Assert.AreEqual(true, false, "Was not able to match Gherkin data [" + dataMissingItemOther + "] in the PDF Report");
            }








        }

        /// <summary>
        /// Verify if expected text exists inside Report window's html
        /// </summary>
        public static void VerifyReportHasData(By reportViewBy, string reportExpText, Table table)
        {
            //       string reportText = Browser.Wd.SwitchTo().Window(ReportWindowHandle).SwitchTo().DefaultContent().SwitchTo().Frame(0).FindElement(reportViewBy).Text;
            IWebElement reportTable = Browser.Wd.SwitchTo().Window(ReportWindowHandle).SwitchTo().DefaultContent().SwitchTo().Frame(0).FindElement(reportViewBy);
            IList<IWebElement> theseTDs = reportTable.FindElements(By.TagName("td"));
            IList<IWebElement> theseTRs = reportTable.FindElements(By.TagName("tr"));
            List<string> compiledTRText = new List<string>();
            List<string> compiledTRTextsp = new List<string>();

            foreach (IWebElement thisTR in theseTRs)
            {
                string thisTRString = thisTR.Text.Replace("\n", "");
                thisTRString = thisTRString.Replace("\r", "");
                if (thisTRString.Trim() != "")
                {
                    compiledTRText.Add(thisTRString.Trim());
                    string thisTRStringsp = thisTR.Text.Replace("\n\r", " ");
                    thisTRStringsp = thisTRStringsp.Replace("\r\n", " ");
                    compiledTRTextsp.Add(thisTRStringsp.Trim());
                }
            }

            foreach (var dataRow in table.Rows)
            {
                string dataLabel = tmsCommon.GenerateData(dataRow[0].ToString());
                string dataValue = tmsCommon.GenerateData(dataRow[1].ToString());
                string dataLabelValuePair = dataLabel + " " + dataValue;
                string dataLabelValuePairNS = dataLabel + dataValue;
                Boolean haveMatchedThisPair = false;
                foreach (string AppTRow in compiledTRTextsp)
                {
                    if (AppTRow.Trim().Contains(dataLabelValuePair))
                    {
                        haveMatchedThisPair = true;
                        Console.WriteLine("Have matched the data pair [" + dataLabelValuePair + "] in report td [" + AppTRow + "]");
                        //break;
                    }
                }

                if (!haveMatchedThisPair)
                {
                    Console.WriteLine("*******");
                    Console.WriteLine("Data mismatch trying to find [" + dataLabelValuePair + "]");
                    Console.WriteLine("*******");
                    //                    MessageBox.Show("Was not able to match data pair [" + dataLabelValuePair + "] or [" + dataLabelValuePairNS + "] in the drill down table");
                    Assert.AreEqual(true, false, "Was not able to match data pair [" + dataLabelValuePair + "] or [" + dataLabelValuePairNS + "] in the drill down table");
                }
            }
        }


        public static void VerifyReportHasExpectData(By reportViewBy, string reportExpText, string table)
        {
            IWebElement reportTable = Browser.Wd.SwitchTo().Window(ReportWindowHandle).SwitchTo().DefaultContent().SwitchTo().Frame(0).FindElement(reportViewBy);
            IList<IWebElement> theseTDs = reportTable.FindElements(By.TagName("td"));
            IList<IWebElement> theseTRs = reportTable.FindElements(By.TagName("tr"));
            List<string> compiledTRText = new List<string>();
            List<string> compiledTRTextsp = new List<string>();

            foreach (IWebElement thisTR in theseTRs)
            {
                string thisTRString = thisTR.Text.Replace("\n", "");
                thisTRString = thisTRString.Replace("\r", "");
                if (thisTRString.Trim() != "")
                {
                    compiledTRText.Add(thisTRString.Trim());
                    string thisTRStringsp = thisTR.Text.Replace("\n\r", " ");
                    thisTRStringsp = thisTRStringsp.Replace("\r\n", " ");
                    compiledTRTextsp.Add(thisTRStringsp.Trim());
                }
            }
            string data = compiledTRText[25].ToString();

            if (data.Trim().Equals(table.ToString().Trim()))
            {
                Console.WriteLine("Expected data is mismatched with Actual data on Reports...");
                Console.WriteLine("Have matched the data pair [" + data + "] in report td [" + compiledTRText[25].ToString() + "]");
            }
        }


        public static void VerifyOECEAFFalloutReportDoesNotHaveData(By reportViewBy, string reportExpText, Table table)
        {

            //       string reportText = Browser.Wd.SwitchTo().Window(ReportWindowHandle).SwitchTo().DefaultContent().SwitchTo().Frame(0).FindElement(reportViewBy).Text;
            IWebElement reportTable = Browser.Wd.SwitchTo().Window(ReportWindowHandle).SwitchTo().DefaultContent().SwitchTo().Frame(0).FindElement(reportViewBy);
            IList<IWebElement> theseTDs = reportTable.FindElements(By.TagName("td"));
            IList<IWebElement> theseTRs = reportTable.FindElements(By.TagName("tr"));
            List<string> compiledTRText = new List<string>();
            List<string> compiledTRTextsp = new List<string>();

            foreach (IWebElement thisTR in theseTRs)
            {
                string thisTRString = thisTR.Text.Replace("\n", "");
                thisTRString = thisTRString.Replace("\r", "");
                if (thisTRString.Trim() != "")
                {
                    compiledTRText.Add(thisTRString.Trim());
                    string thisTRStringsp = thisTR.Text.Replace("\n\r", " ");
                    thisTRStringsp = thisTRStringsp.Replace("\r\n", " ");
                    compiledTRTextsp.Add(thisTRStringsp.Trim());
                }
            }

            foreach (var dataRow in table.Rows)
            {
                string dataLabel = tmsCommon.GenerateData(dataRow[0].ToString());
                Boolean haveMatchedThisPair = false;
                foreach (string AppTRow in compiledTRTextsp)
                {
                    if (AppTRow.Trim().Contains(dataLabel))
                    {
                        haveMatchedThisPair = true;

                        Assert.AreEqual(true, haveMatchedThisPair, "Have matched the data pair [" + dataLabel + "] in report td [" + AppTRow + "]");
                        Console.WriteLine("Have matched the data pair [" + dataLabel + "] in report td [" + AppTRow + "]");
                        break;
                    }
                }

                if (!haveMatchedThisPair)
                {
                    Console.WriteLine("*******");
                    Console.WriteLine("Data mismatch trying to find [" + dataLabel + "]");
                    Console.WriteLine("*******");
                    //                    MessageBox.Show("Was not able to match data pair [" + dataLabelValuePair + "] or [" + dataLabelValuePairNS + "] in the drill down table");
                    Assert.AreEqual(true, true, "Was not able to match data pair [" + dataLabel + " in the OEC EAF Fallout Report");
                }
            }

        }

        public static void VerifyReportDoesNotHaveData(By reportViewBy, string reportExpText, Table table)
        {
            //       string reportText = Browser.Wd.SwitchTo().Window(ReportWindowHandle).SwitchTo().DefaultContent().SwitchTo().Frame(0).FindElement(reportViewBy).Text;
            IWebElement reportTable = Browser.Wd.SwitchTo().Window(ReportWindowHandle).SwitchTo().DefaultContent().SwitchTo().Frame(0).FindElement(reportViewBy);
            IList<IWebElement> theseTDs = reportTable.FindElements(By.TagName("td"));
            IList<IWebElement> theseTRs = reportTable.FindElements(By.TagName("tr"));
            List<string> compiledTRText = new List<string>();
            List<string> compiledTRTextsp = new List<string>();

            foreach (IWebElement thisTR in theseTRs)
            {
                string thisTRString = thisTR.Text.Replace("\n", "");
                thisTRString = thisTRString.Replace("\r", "");
                if (thisTRString.Trim() != "")
                {
                    compiledTRText.Add(thisTRString.Trim());
                    string thisTRStringsp = thisTR.Text.Replace("\n\r", " ");
                    thisTRStringsp = thisTRStringsp.Replace("\r\n", " ");
                    compiledTRTextsp.Add(thisTRStringsp.Trim());
                }
            }

            foreach (var dataRow in table.Rows)
            {
                string dataLabel = tmsCommon.GenerateData(dataRow[0].ToString());
                string dataValue = tmsCommon.GenerateData(dataRow[1].ToString());
                string dataLabelValuePair = dataLabel + " " + dataValue;
                string dataLabelValuePairNS = dataLabel + dataValue;
                Boolean haveMatchedThisPair = false;
                foreach (string AppTRow in compiledTRTextsp)
                {
                    if (AppTRow.Trim().Contains(dataLabelValuePair))
                    {
                        haveMatchedThisPair = true;
                        Assert.AreEqual(true, false, "Have matched the data pair [" + dataLabelValuePair + "] in report td [" + AppTRow + "]");
                        //break;
                    }
                }

                if (!haveMatchedThisPair)
                {
                    Console.WriteLine("*******");
                    Console.WriteLine("Data mismatch trying to find [" + dataLabelValuePair + "]");
                    Console.WriteLine("*******");
                    //                    MessageBox.Show("Was not able to match data pair [" + dataLabelValuePair + "] or [" + dataLabelValuePairNS + "] in the drill down table");
                    Assert.AreEqual(true, true, "Was not able to match data pair [" + dataLabelValuePair + "] or [" + dataLabelValuePairNS + "] in the drill down table");
                }
            }
        }

        public static void VerifyReportHasData(By reportViewBy, string reportExpText)
        {
            string reportText = Browser.Wd.SwitchTo().Window(ReportWindowHandle).SwitchTo().DefaultContent().SwitchTo().Frame(0).FindElement(reportViewBy).Text;

            string reportTextLowerCase = reportText.ToLower();

            Assert.IsTrue(reportTextLowerCase.Contains(reportExpText), "Report does not have expected value = [{0}]", reportExpText);
            fw.ConsoleReport(String.Format("Report has expected value = [{0}]", reportExpText));
        }

        public static void VerifyReportDoesNotHaveData(By reportViewBy, string reportExpText)
        {
            string reportText = Browser.Wd.SwitchTo().Window(ReportWindowHandle).SwitchTo().DefaultContent().SwitchTo().Frame(0).FindElement(reportViewBy).Text;

            string reportTextLowerCase = reportText.ToLower();

            Assert.IsFalse(reportTextLowerCase.Contains(reportExpText), "Report have no expected value = [{0}]", reportExpText);
            fw.ConsoleReport(String.Format("Report has expected value = [{0}]", reportExpText));
        }

        /// <summary>
        /// Close Report Window which handle is equal to the previously saved ReportWindowHandle.
        /// If ReportWindowHandle is empty, method will close first window which is not the same to the current window.
        /// ReportWindowHandle will be set to empty.
        /// </summary>
        public static void CloseReport()
        {
            if (ReportWindowHandle == "")
            {
                ReadOnlyCollection<string> windowHandles = Browser.Wd.WindowHandles;
                MainWindowHandle = Browser.Wd.CurrentWindowHandle;

                foreach (string handle in windowHandles)
                {
                    if (handle != MainWindowHandle)
                    {
                        ReportWindowHandle = handle;
                        break;
                    }
                }
            }

            Browser.Wd.SwitchTo().Window(ReportWindowHandle).Close();
            Browser.Wd.SwitchTo().Window(MainWindowHandle);
            fw.ConsoleReport("Report was closed");
            ReportWindowHandle = "";
        }

        /// <summary>
        /// Verify if Report's specific table has appropriate row(e.g. HIC=12TEST, EffDate=01/01/2015) 
        /// </summary>
        public static void VerifyReportTableHasRow(By reportTableBy, Table table)
        {
            //03.25.2016 - Daron.   Changed ReportWindowHandle here, now it finds tables and validates data.
            //leaving note here in case it breaks 500 test cases, the line below was the original.
            //It seems the original line was looking for tables and data on the original window not the report??
            //Call me if you think this should change back to currentwindowhandle, things really started to work once this change was made.
            var objTables = Browser.Wd.SwitchTo().Window(ReportWindowHandle).SwitchTo().DefaultContent().SwitchTo().Frame(0).FindElements(reportTableBy);
            //      var objTables = Browser.Wd.SwitchTo().Window(Browser.Wd.CurrentWindowHandle).SwitchTo().DefaultContent().SwitchTo().Frame(0).FindElements(reportTableBy);
            int tablesCount = objTables.Count;

            if (tablesCount <= 0) { Assert.Fail("Report does not have data."); }

            IWebElement objWebTable = objTables[tablesCount - 1];

            ((IJavaScriptExecutor)Browser.Wd).ExecuteScript("arguments[0].setAttribute(arguments[1], arguments[2]);", objWebTable, "id", "myReportTableID");

            String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
            for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
            {
                int index = 0;
                if (int.TryParse(arrRes[i, 0], out index))
                {
                    if (index < 0)
                    {
                        Assert.Fail("Expected row[{0}] was not found: {1} ", i + 1, arrRes[i, 1]);
                    }
                }
            }
        }
    }

    /**
     *  Common Keywords for All Reports
     * */

    [Binding]
    public class fsCommonReportSteps
    {
        [Then(@"Navigate to the Report Page ""(.*)""")]
        [When(@"Navigate to the Report Page ""(.*)""")]
        public void ThenNavigateToTheTransactionsNewViewTRRDetailPage(string p0)
        {
            try
            {
                tmsWait.Hard(1);
                string GeneratedData = tmsCommon.GenerateData(p0);

                By reportViewBy = EAM.Reports.ReportMainViewBy;
                string reportExpText = "Report Date";
                ReportsCommon.SwitchToReportWindow(reportViewBy, 30, reportExpText);

                ReportsCommon.NavigateToReportPageByIndex(GeneratedData);

            }
            catch (Exception e) { Assert.Fail("Report Page Navigation failed: {0}", e.Message); }
        }

        [Then(@"Navigate to the Report Page (.*)")]
        public void ThenNavigateToTheReportPage(string p0)
        {
            try
            {
                tmsWait.Hard(1);
                string GeneratedData = tmsCommon.GenerateData(p0);

                By reportViewBy = EAM.Reports.ReportMainViewBy;
                string reportExpText = "Report Date";
                ReportsCommon.SwitchToReportWindow(reportViewBy, 30, reportExpText);

                ReportsCommon.NavigateToReportPageByIndex(GeneratedData);

            }
            catch (Exception e) { Assert.Fail("Report Page Navigation failed: {0}", e.Message); }
        }


        [Then(@"Navigate to the Report Pages until ""(.*)"" is found")]
        [When(@"Navigate to the Report Pages until ""(.*)"" is found")]
        public void ThenNavigateToTheReportPageUntilIsFound(string p0)
        {
            try
            {
                string GeneratedData = tmsCommon.GenerateData(p0).ToLower();

                By reportViewBy = EAM.Reports.ReportMainViewBy;
                string reportExpText = "Report Date";

                while (true)
                {
                    ReportsCommon.SwitchToReportWindow(reportViewBy, 30, reportExpText);
                    try
                    {
                        ReportsCommon.VerifyReportHasData(reportViewBy, GeneratedData);
                        return;
                    }
                    catch (Exception e)
                    {
                        if (!ReportsCommon.NavigateToReportPage(true))
                        {
                            Assert.Fail("Report page with expected text [{0}] was not found. Exception: {1}", GeneratedData, e.Message);
                        }
                    }
                }
            }
            catch (Exception e) { Assert.Fail("Navigate to the Report Page until text is found: {0}", e.Message); }
        }
    }

    /***
     *      CMS Response Code Level Detail Report
     * */

    [Binding]
    public class fsCMSResponseCodeLevelDetailReport
    {
        [When(@"Reports CMS Response Code Level Detail TRR Start Date is set to ""(.*)""")]
        [Then(@"Reports CMS Response Code Level Detail TRR Start Date is set to ""(.*)""")]
        public void WhenReportsCMSResponseCodeLevelDetailTRRStartDateIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            string GeneratedData = tmsCommon.GenerateData(p0);
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                tmsWait.Hard(3);
                new SelectElement(Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl03_ddValue"))).SelectByText(GeneratedData);

            }
            else
            {
                SelectElement select = new SelectElement(EAM.CMSResponseCodeLevelDetailReport.TRRStartDate);
                select.SelectByText(GeneratedData);
                tmsWait.Hard(1);
            }
        }

        [When(@"Reports CMS Response Code Level Detail TRR Start Date is set to (.*) to generate report")]
        [Then(@"Reports CMS Response Code Level Detail TRR Start Date is set to (.*) to generate report")]
        public void WhenReportsCMSResponseCodeLevelDetailTRRStartDateIsSetToToGenerateReport(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                tmsWait.Hard(3);
                new SelectElement(Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl03_ddValue"))).SelectByText(GeneratedData);

            }
            else
            {
                SelectElement select = new SelectElement(EAM.CMSResponseCodeLevelDetailReport.TRRStartDate);
                select.SelectByText(GeneratedData);
            }
        }
        [When(@"Reports section CMS Response Code Level Detail page TRR Start Date is set to ""(.*)""")]
        [Then(@"Reports section CMS Response Code Level Detail page TRR Start Date is set to ""(.*)""")]
        public void ThenReportsSectionCMSResponseCodeLevelDetailPageTRRStartDateIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                tmsWait.Hard(3);
                new SelectElement(Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl03_ddValue"))).SelectByText(GeneratedData);

            }
            else
            {
                SelectElement select = new SelectElement(EAM.CMSResponseCodeLevelDetailReport.TRRStartDate);
                select.SelectByText(GeneratedData);
            }
        }

        [When(@"CMS Response Code Level Detail TRR Start Date is set to ""(.*)""")]
        public void WhenCMSResponseCodeLevelDetailTRRStartDateIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                tmsWait.Hard(3);
                new SelectElement(Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl03_ddValue"))).SelectByText(GeneratedData);

            }
            else
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    tmsWait.Hard(1);
                    
                    By Drp = By.XPath("//kendo-dropdownlist[@test-id='TRRStartDate']//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + GeneratedData + "']");

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                }
                else
                {
                    SelectElement select = new SelectElement(EAM.CMSResponseCodeLevelDetailReport.TRRStartDate);
                    select.SelectByText(GeneratedData);
                }
            }
        }

        [When(@"CMS Response Code Level Detail TRR End Date is set to ""(.*)""")]
        public void WhenCMSResponseCodeLevelDetailTRREndDateIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                tmsWait.Hard(3);
                new SelectElement(Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl05_ddValue"))).SelectByText(GeneratedData);

            }
            else
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    tmsWait.Hard(1);
                    
                    By Drp = By.XPath("//kendo-dropdownlist[@test-id='TRREndDate']//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + GeneratedData + "']");

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                }
                else
                {
                    SelectElement select = new SelectElement(EAM.CMSResponseCodeLevelDetailReport.TRREndDate);
                    select.SelectByText(GeneratedData);
                }
            }
        }


        [When(@"Reports CMS Response Code Level Detail TRR End Date is set to ""(.*)""")]
        [Then(@"Reports CMS Response Code Level Detail TRR End Date is set to ""(.*)""")]
        public void WhenReportsCMSResponseCodeLevelDetailTRREndDateIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                tmsWait.Hard(3);
                new SelectElement(Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl05_ddValue"))).SelectByText(GeneratedData);

            }
            else
            {
                SelectElement select = new SelectElement(EAM.CMSResponseCodeLevelDetailReport.TRREndDate);
                select.SelectByText(GeneratedData);
            }
        }

        [When(@"Reports CMS Response Code Level Detail TRR End Date is set to (.*) to generate report")]
        [Then(@"Reports CMS Response Code Level Detail TRR End Date is set to (.*) to generate report")]
        public void WhenReportsCMSResponseCodeLevelDetailTRREndDateIsSetToToGenerateReport(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                tmsWait.Hard(3);
                new SelectElement(Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl05_ddValue"))).SelectByText(GeneratedData);

            }
            else
            {
                SelectElement select = new SelectElement(EAM.CMSResponseCodeLevelDetailReport.TRREndDate);
                select.SelectByText(GeneratedData);
            }
        }


        [When(@"Reports CMS Response Code Level Detail Plan ID is set to ""(.*)""")]
        [Then(@"Reports CMS Response Code Level Detail Plan ID is set to ""(.*)""")]
        public void WhenReportsCMSResponseCodeLevelDetailPlanIDIsSetTo(string p0)
        {
            string strID = EAM.CMSResponseCodeLevelDetailReport.PBPID.GetAttribute("id");

            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.CMSResponseCodeLevelDetailReport.PlanID);
            select.SelectByText(GeneratedData);

            tmsWait.Hard(2);
            tmsWait.WaitForReadyStateComplete(30);
            try
            {
                EAM.CMSResponseCodeLevelDetailReport.PBPID.Click();
                EAM.CMSResponseCodeLevelDetailReport.PBPID.Click();
            }
            catch (Exception) { }

            tmsWait.Hard(2);
            tmsWait.WaitForReadyStateComplete(30);
        }


        [When(@"""(.*)"" is clicked")]
        public void WhenIsClicked(string p0)
        {
            string TRRCode = fw.getVariable(p0);
            IWebElement trrCodesTable = EAM.CMSResponseCodeLevelDetailReport.TRRCodesResponseTable;
            ReadOnlyCollection<IWebElement> allRows = trrCodesTable.FindElements(By.TagName("tr"));

            foreach (IWebElement row in allRows)
            {

                if (row.Text.Contains(TRRCode))
                {
                    ReadOnlyCollection<IWebElement> cells = row.FindElements(By.TagName("td"));

                    foreach (IWebElement cell in cells)
                    {
                        IWebElement trcLink = cell.FindElement(By.TagName("a"));
                        trcLink.Click();                        
                        break;
                    }
                    break;

                }

            }
        }

        [Then(@"verify that ""(.*)"" page is displayed")]
        public void ThenVerifyThatPageIsDisplayed(string p0)
        {
            tmsWait.Hard(5);
            By reportViewBy = EAM.Reports.ReportMainViewBy;
            tmsWait.Hard(5);
            string reportHandle = ReportsCommon.SwitchToReportWindow(reportViewBy, 30, p0);

            if (reportHandle == "")
            {
                Assert.Fail(" Incomplete Transaction Report was not opened");
            }
            List<string> w = new List<string>(Browser.Wd.WindowHandles);
            for (int i = 0; i < w.Count; i++)
            {

                if (Browser.Wd.SwitchTo().Window(w[i]).CurrentWindowHandle == reportHandle)
                {
                    Browser.Wd.SwitchTo().Window(w[i]).Close();
                }
            }
            Browser.SwitchToParentWindow();
        }

        [When(@"""(.*)"" with description ""(.*)""  is clicked")]
        [Then(@"""(.*)"" with description ""(.*)""  is clicked")]
        public void WhenWithDescriptionIsClicked(int p0, string p1)
        {
            IWebElement trrCodesTable = EAM.CMSResponseCodeLevelDetailReport.TRRCodesResponseTable;
            ReadOnlyCollection<IWebElement> allRows = trrCodesTable.FindElements(By.TagName("tr"));

            foreach (IWebElement row in allRows)
            {

                if (row.Text.Contains(p1))
                {
                    ReadOnlyCollection<IWebElement> cells = row.FindElements(By.TagName("td"));

                    foreach (IWebElement cell in cells)
                    {
                        IWebElement trcLink = cell.FindElement(By.TagName("a"));
                        trcLink.Click();
                        break;

                    }

                }

            }
        }



        /***
        *      TRR Member Drill-Down Report
        * */

        [When(@"TRR Member Drill-Down Report is closed")]
        public void WhenTRRMemberDrill_DownReportIsClosed()
        {
            try
            {
                ReportsCommon.CloseReport();
            }
            catch (Exception e)
            {
                Assert.Fail("T/RR Member Drill-Down Report was not closed. Exception: {0}", e.Message);
            }
            tmsWait.Hard(2);
        }

        [Then(@"Verify TRR Member Drill-Down Report has data")]
        public void ThenVerifyTRRMemberDrill_DownReportHasData(Table table)
        {
            string reportExpText = "T/RR Member Drill-Down Report";
            string reportHandle = "";
            By reportViewBy = EAM.Reports.ReportMainViewBy;

            reportHandle = ReportsCommon.SwitchToReportWindow(reportViewBy, 30, reportExpText);

            if (reportHandle == "")
            {
                Assert.Fail("TRR Member Drill-Down Report was not opened");
            }

            try
            {
                ReportsCommon.VerifyReportHasData(reportViewBy, reportExpText, table);
            }
            catch (Exception e)
            {
                try
                {
                    //Browser.Wd.SwitchTo().Window(reportHandle).Close();
                    //Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle).Close();
                }
                catch { }
                Assert.Fail("Verify TRR Member Drill-Down Report has data. Exception: {0}", e.Message);
            }

            Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle);
        }


        /**
         *   OEC EAF Fallout  Report
         * */


        [Then(@"Verify Reports OEC EAF Fallout  Report Table Does Not Exist")]
        public void ThenVerifyReportsOECEAFFalloutReportTableDoesNotExist()
        {
            tmsWait.Hard(5);
            string GeneratedData = "MemberID";
            IList<string> WindowHandles = Browser.Wd.WindowHandles;
            var currentWindow = Browser.Wd.CurrentWindowHandle;
            var reportHandle = WindowHandles[1];
            Browser.Wd.SwitchTo().Window(WindowHandles[1]);
            string BrowserTitle = Browser.Wd.Title;
            By reportViewBy = EAM.ReportsEnrollmentOECEAFFallout.OECEAFFalloutTable;
            string reportTitle = "OEC/EAF Fallout Report";
            try
            {
                IWebElement visibleTable = Browser.Wd.SwitchTo().Window(reportHandle).SwitchTo().DefaultContent().SwitchTo().Frame(0).FindElement(reportViewBy);
                fw.ConsoleReport(reportTitle + "  was opened");

                IList<IWebElement> pageTDs = visibleTable.FindElements(By.TagName("div"));
                Boolean foundTD = false;
                foreach (IWebElement thisTD in pageTDs)
                {
                    if (thisTD.Text == GeneratedData)
                    {
                        foundTD = true;
                        break;
                    }
                }
                Assert.AreEqual(false, foundTD, "Verifying [" + GeneratedData + "] Table Column was not on the reports page for [" + reportTitle + "]");
                Console.WriteLine("Verifying [" + GeneratedData + "] Table Column was not on the reports page for [" + reportTitle + "]");

            }
            catch (Exception e)
            {
                Browser.Wd.SwitchTo().Window(reportHandle).Close();
                Browser.Wd.SwitchTo().Window(currentWindow).Close();
                Assert.Fail("Verify [" + reportTitle + "] report has [" + GeneratedData + "]. Exception: {0}", e.Message);
            }

            Browser.Wd.SwitchTo().Window(currentWindow);
        }

        [Then(@"Verify Reports OEC EAF Fallout Report File Name is ""(.*)""")]
        public void ThenVerifyReportsOECEAFFalloutReportFileNameIs(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            tmsWait.Hard(5);

            IList<string> WindowHandles = Browser.Wd.WindowHandles;
            var currentWindow = Browser.Wd.CurrentWindowHandle;
            var reportHandle = WindowHandles[1];
            Browser.Wd.SwitchTo().Window(WindowHandles[1]);
            string BrowserTitle = Browser.Wd.Title;
            By reportViewBy = EAM.ReportsEnrollmentOECEAFFallout.OECEAFFalloutTable;
            string reportTitle = "OEC/EAF Fallout Report";
            try
            {
                IWebElement visibleTable = Browser.Wd.SwitchTo().Window(reportHandle).SwitchTo().DefaultContent().SwitchTo().Frame(0).FindElement(reportViewBy);
                fw.ConsoleReport(reportTitle + "  was opened");

                IList<IWebElement> pageTDs = visibleTable.FindElements(By.TagName("td"));
                Boolean foundTD = false;
                foreach (IWebElement thisTD in pageTDs)
                {
                    if (thisTD.Text == GeneratedData)
                    {
                        foundTD = true;
                        break;
                    }
                }
                Assert.AreEqual(true, foundTD, "Verifying [" + GeneratedData + "] file name was on the reports page for [" + reportTitle + "]");
                Console.WriteLine("Verifying [" + GeneratedData + "] file name was on the reports page for [" + reportTitle + "]");

            }
            catch (Exception e)
            {
                Browser.Wd.SwitchTo().Window(reportHandle).Close();
                Browser.Wd.SwitchTo().Window(currentWindow).Close();
                Assert.Fail("Verify [" + reportTitle + "] report has [" + GeneratedData + "]. Exception: {0}", e.Message);
            }

            Browser.Wd.SwitchTo().Window(currentWindow);
        }

        /**
         *      CMS Response Code Level Detail
         * */

        [When(@"Reports CMS Response Code Level Detail PBP ID is set to ""(.*)""")]
        [Then(@"Reports CMS Response Code Level Detail PBP ID is set to ""(.*)""")]
        public void WhenReportsCMSResponseCodeLevelDetailPBPIDIsSetTo(string p0)
        {
            tmsWait.Hard(2);

            //string strID = EAM.CMSResponseCodeLevelDetailReport.PBPID.GetAttribute("id");

            string GeneratedData = tmsCommon.GenerateData(p0);
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                new SelectElement(Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl09_ddValue"))).SelectByText(GeneratedData);
            }
            else
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    tmsWait.Hard(1);
                    
                    By Drp = By.XPath("//kendo-dropdownlist[@test-id='PBPID']//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + GeneratedData + "']");

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                }
                else
                {
                    SelectElement select = new SelectElement(EAM.CMSResponseCodeLevelDetailReport.PBPID);
                    select.SelectByText(GeneratedData);
                }
            }
            tmsWait.Hard(4);
            //tmsWait.WaitForReadyStateComplete(30);
        }

        [Then(@"Verify Reports CMS Response Code Level Detail table has row")]
        [Then(@"Verify Reports CMS Response Code Level Detail Table has row")]
        public void ThenVerifyReportsCMSResponseCodeLevelDetailTableHasRow(Table table)
        {
            try
            {
                foreach (var dataRow in table.Rows)
                {
                    string expTRRCode = tmsCommon.GenerateDataForTable(dataRow[0]);
                    string expCodeName = tmsCommon.GenerateDataForTable(dataRow[1]);

                    if (expTRRCode != "[skip]" && expCodeName != "[skip]")
                    {
                        IWebElement objTRRCodeName = Browser.Wd.FindElement(By.XPath("//a[contains(.,'"+ expTRRCode + "')]/parent::td/following-sibling::td"));
                        string strTRRCodeName = objTRRCodeName.Text;
                        Assert.AreEqual(expCodeName, strTRRCodeName, "TRR Code [{0}] was found but Code Name [{1}] does not equal to expected [{2}]", expTRRCode, strTRRCodeName, expCodeName);
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Verify Reports CMS Response Code Level Detail table has row failed: {0}", e.Message);
            }
        }

        [When(@"Reports CMS Response Code Level Detail ""(.*)"" link is entered")]
        public void WhenReportsCMSResponseCodeLevelDetailLinkIsEntered(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            //tmsWait.Hard(2);
            if(ConfigFile.EnvType.Equals("ESI"))
            {
                tmsWait.Hard(2);
                new SelectElement(Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl11_ddValue"))).SelectByText("ALL");
                tmsWait.Hard(2);
                new SelectElement(Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl13_ddValue"))).SelectByText(GeneratedData);

            }
            else
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    tmsWait.Hard(1);
                    IWebElement tmsxElement = Browser.Wd.FindElement(By.XPath("//*[@test-id='transReplyCode']//input"));
                    tmsxElement.SendKeys(GeneratedData);
                    tmsWait.Hard(1);
                    tmsxElement.SendKeys(OpenQA.Selenium.Keys.Tab);
                }
                else
                {
                    IWebElement lookup = Browser.Wd.FindElement(By.XPath("//input[@aria-owns='transReplyCode_listbox']"));
                    lookup.SendKeys(GeneratedData);
                }
            }
            


        }

        [Then(@"Reports CMS Response Code Level Detail ""(.*)"" link is clicked")]
        [When(@"Reports CMS Response Code Level Detail ""(.*)"" link is clicked")]
        public void WhenReportsCMSResponseCodeLevelDetailLinkIsClicked(string p0)
        {
            string GData = tmsCommon.GenerateData(p0);
            tmsWait.Hard(2);
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                tmsWait.Hard(2);
                new SelectElement(Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl11_ddValue"))).SelectByText("ALL");
                tmsWait.Hard(2);
                new SelectElement(Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl13_ddValue"))).SelectByText(GData);
            }
            else
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    tmsWait.Hard(1);
                   
                    IWebElement codeDetail = Browser.Wd.FindElement(By.XPath("//kendo-combobox[@test-id='transReplyCode']//kendo-searchbar//input"));
                    
                    codeDetail.SendKeys(GData);
                    tmsWait.Hard(3);
                    codeDetail.SendKeys(OpenQA.Selenium.Keys.Tab);
                }
                else
                {
                    // click on Report Link
                    // IWebElement lookup = Browser.Wd.FindElement(By.XPath("//span[@test-id='report-link-group']/a"));
                    //fw.ExecuteJavascript(lookup);
                    // tmsWait.Hard(2);
                    //// Enter TRC
                    //IWebElement trrCode = Browser.Wd.FindElement(By.CssSelector("[test-id='trrCodes-txt-trrCodes']"));
                    //trrCode.SendKeys(GeneratedData);
                    //tmsWait.Hard(2);
                    //// Click on Search
                    //IWebElement trrSearchButton = Browser.Wd.FindElement(By.CssSelector("[test-id='trrCodes-btn-search']"));
                    //fw.ExecuteJavascript(trrSearchButton);
                    //tmsWait.Hard(2);
                    //// Click on Checkbox
                    //IWebElement trrRowClick = Browser.Wd.FindElement(By.XPath("//input[@id='" + GeneratedData + "']"));
                    //fw.ExecuteJavascript(trrRowClick);
                    //tmsWait.Hard(2);
                    //// Add button
                    //IWebElement trrAddButton = Browser.Wd.FindElement(By.CssSelector("[test-id='trrCodes-btn-add']"));
                    //fw.ExecuteJavascript(trrAddButton);
                    //tmsWait.Hard(8);
                    IWebElement trrCode = Browser.Wd.FindElement(By.XPath("//input[@aria-owns='transReplyCode_listbox']"));
                    trrCode.SendKeys(GData);
                    tmsWait.Hard(1);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//li//span[contains(.,'" + GData + "')]")));
                    tmsWait.Hard(2);
                    tmsWait.Hard(1);
                }
            }
        }

        [Then(@"Verify Reports CMS Response Code Level Detail Title is displayed as ""(.*)""")]
        public void ThenVerifyReportsCMSResponseCodeLevelDetailTitleIsDisplayedAs(string p0)
        {
            tmsWait.Hard(7);
            Browser.SwitchToChildWindow();            
            Browser.SwitchToIFrame();
            tmsWait.Hard(10);
            string reportPagesource = Browser.Wd.PageSource;           
            string value = tmsCommon.GenerateData(p0);
            if(reportPagesource.Contains(value))
            {
                Assert.IsTrue(true, value + "  is not found on Report");
            }
           
        }


        [When(@"Reports CMS Response Code Level Detail (.*) link is clicked for verification")]
        public void WhenReportsCMSResponseCodeLevelDetailLinkIsClickedForVerification(string p0)
        {
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.LinkText(tmsCommon.GenerateData(p0))));
            tmsWait.Hard(3);
        }


        [When(@"Reports Enrollment OEC/EAF Fallout Report Window is Closed")]
        public void WhenReportsEnrollmentOECEAFFalloutReportWindowIsClosed()
        {
            try
            {
                ReportsCommon.CloseReport();
            }
            catch (Exception e)
            {
                Assert.Fail("Enrollment OEC/EAF Fallout Report was not closed. Exception: {0}", e.Message);
            }
        }

       

        [Then(@"Reports Deemed LIS Detail Report is closed")]
        [When(@"Reports CMS Response Code Level Detail Report is closed")]
        [Then(@"Reports CMS Response Code Level Detail Report is closed")]
        public void WhenReportsCMSResponseCodeLevelDetailReportIsClosed()
        {
            try
            {
                ReportsCommon.CloseReport();
            }
            catch (Exception e)
            {
                Assert.Fail("CMS Response Code Level Detail Report was not closed. Exception: {0}", e.Message);
            }
        }

        [When(@"NoRx Fallout Report is closed")]
        public void WhenNoRxFalloutReportIsClosed()
        {
            try
            {
                ReportsCommon.CloseReport();
            }
            catch (Exception e)
            {
                Assert.Fail("NoRx Fallout Report was not closed. Exception: {0}", e.Message);
            }
        }

        [Then(@"NoRx Fallout Report does not displayed the ""(.*)""")]
        [Then(@"NoRx Fallout Report does not displayed the ""(.*)""")]
        public void ThenNoRxFalloutReportDoesNotDisplayedThe(string p0)
        {
            //EAM.EnrollmentComplianceReport.RunReportButton.Click();
            tmsWait.Hard(2);

            By reportViewBy = EAM.Reports.ReportMainViewBy;
            string reportExpText = "NoRx Fallout Report";
            string reportHandle = "";


            reportHandle = ReportsCommon.SwitchToReportWindow(reportViewBy, 60, reportExpText);

            if (reportHandle == "")
            {
                Assert.Fail("NoRx Fallout Report was not opened");
            }


            string strValue = tmsCommon.GenerateData(p0.ToString());
            try
            {
                ReportsCommon.VerifyReportDoesNotHaveData(reportViewBy, strValue);
            }
            catch (Exception e)
            {
                 Assert.Fail("Verify NoRx Fallout Report Report has data. Exception: {0}", e.Message);
            }
            Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle);
        }

        [Then(@"Verify NoRx Fallout Report there is no record is displayed")]
        public void ThenVerifyNoRxFalloutReportThereIsNoRecordIsDisplayed()
        {
           
        }


        [Then(@"Verify Report Deemed LIS Detail Window does not have data")]
        public void ThenVerifyReportDeemedLISDetailWindowDoesNotHaveData(Table table)
        {
            By reportViewBy = EAM.Reports.ReportMainViewBy;
            string reportExpText = "Deemed LIS Detail Report";
            string reportHandle = "";

            reportHandle = ReportsCommon.SwitchToReportWindow(reportViewBy, 30, reportExpText);

            if (reportHandle == "")
            {
                Assert.Fail(" Deemed LIS Detail Report was not opened");
            }

            try
            {
                ReportsCommon.VerifyReportDoesNotHaveData(reportViewBy, reportExpText, table);
            }
            catch (Exception e)
            {
                Assert.Fail("Verify Deemed LIS Detail Report has data that should not be there. ");
            }
            Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle);
        }

        [Then(@"Verify Report Deemed LIS Detail Window does not have data ""(.*)""")]
        public void ThenVerifyReportDeemedLISDetailWindowDoesNotHaveData(string p0)
        {
            string reportdata = tmsCommon.GenerateData(p0);
            By reportViewBy = EAM.Reports.ReportMainViewBy;
            IList<string> WindowHandles = Browser.Wd.WindowHandles;
            var currentWindow = Browser.Wd.CurrentWindowHandle;
            var reportHandle = WindowHandles[1];
            Browser.Wd.SwitchTo().Window(WindowHandles[1]);
            string reportText = Browser.Wd.SwitchTo().Window(reportHandle).SwitchTo().DefaultContent().FindElement(reportViewBy).Text;
            Assert.IsFalse(reportText.Contains(reportdata));

        }


        [Then(@"Verify Report Deemed LIS Detail Window has data contains ""(.*)""")]
        public void ThenVerifyReportDeemedLISDetailWindowHasDataContains(string table)
        {
            By reportViewBy = EAM.Reports.ReportMainViewBy;
            string reportExpText = "Deemed LIS Detail Report";
            string reportHandle = "";

            reportHandle = ReportsCommon.SwitchToReportWindow(reportViewBy, 30, reportExpText);

            if (reportHandle == "")
            {
                Assert.Fail(" Deemed LIS Detail Report was not opened");
            }

            try
            {
                ReportsCommon.VerifyReportHasExpectData(reportViewBy, reportExpText, table);
            }
            catch (Exception e)
            {
                //      Browser.Wd.SwitchTo().Window(reportHandle).Close();
                //    Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle).Close();
                Assert.Fail("Verify Deemed LIS Detail Report has data. Exception: {0}", e.Message);
            }

            Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle);
        }

        [Then(@"Verify Report Deemed LIS Detail Window has data")]
        public void ThenVerifyReportDeemedLISDetailWindowHasData(Table table)
        {
            By reportViewBy = EAM.Reports.ReportMainViewBy;
            string reportExpText = "Deemed LIS Detail Report";
            string reportHandle = "";

            reportHandle = ReportsCommon.SwitchToReportWindow(reportViewBy, 30, reportExpText);

            if (reportHandle == "")
            {
                Assert.Fail(" Deemed LIS Detail Report was not opened");
            }

            try
            {
                ReportsCommon.VerifyReportHasData(reportViewBy, reportExpText, table);
            }
            catch (Exception e)
            {
                //      Browser.Wd.SwitchTo().Window(reportHandle).Close();
                //    Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle).Close();
                Assert.Fail("Verify Deemed LIS Detail Report has data. Exception: {0}", e.Message);
            }

            Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle);
        }

        [Then(@"Verify Reports CMS Response Code Level Detail Window has data")]
        public void ThenVerifyReportsCMSResponseCodeLevelDetailWindowHasData(Table table)
        {
            By reportViewBy = EAM.Reports.ReportMainViewBy;
            string reportExpText = "TRC Code";
            string reportHandle = "";

            reportHandle = ReportsCommon.SwitchToReportWindow(reportViewBy, 30, reportExpText);

            if (reportHandle == "")
            {
                Assert.Fail("CMS Response Code Level Detail Report was not opened");
            }

            try
            {
                ReportsCommon.VerifyReportHasData(reportViewBy, reportExpText, table);
            }
            catch (Exception e)
            {
                //      Browser.Wd.SwitchTo().Window(reportHandle).Close();
                //    Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle).Close();
                Assert.Fail("Verify CMS Response Code Level Detail Report has data. Exception: {0}", e.Message);
            }

            Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle);
        }


        [Then(@"Verify Reports CMS Response Code Level Detail Window table has row")]
        public void ThenVerifyReportsCMSResponseCodeLevelDetailWindowTableHasRow(Table table)
        {
            By reportViewBy = EAM.Reports.ReportMainViewBy;
            string reportHandle = ReportsCommon.SwitchToReportWindow(reportViewBy, 30, "TRC Code");
            Browser.SwitchToChildWindow();

            //if (reportHandle == "")
            //{
            //    Assert.Fail("CMS Response Code Level Detail Report was not opened");
            //}      
            Boolean haveValidatedTable = false;
            string exceptionMessage = "";
            for (int i = 0; i < 5; i++)
            {
                try
                {
                    //ds 01132016      By reportTableBy = By.XPath("//table[contains(., 'HIC')]");
                    By reportTableBy = By.TagName("table");
                    ReportsCommon.VerifyReportTableHasRow(reportTableBy, table);
                    haveValidatedTable = true;
                    break;
                }
                catch (Exception e)
                {
                    //       Browser.Wd.SwitchTo().Window(ReportsCommon.ReportWindowHandle).Close();
                    //        Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle).Close();
                    //       Assert.Fail("Verify CMS Response Code Level Detail table has row. Exception: {0}", e.Message);
                    exceptionMessage = e.Message;
                }
                try
                {
                    By reportTableBy = By.XPath("//table[contains(., 'HIC')]");
                    //By reportTableBy = By.TagName("table");
                    ReportsCommon.VerifyReportTableHasRow(reportTableBy, table);
                    haveValidatedTable = true;
                    break;
                }
                catch (Exception e)
                {
                    //       Browser.Wd.SwitchTo().Window(ReportsCommon.ReportWindowHandle).Close();
                    //        Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle).Close();
                    //       Assert.Fail("Verify CMS Response Code Level Detail table has row. Exception: {0}", e.Message);
                    exceptionMessage = e.Message;
                }
            }
            if (!haveValidatedTable)
            {
                Assert.Fail("Verify CMS Response Code Level Detail table has row. Exception: {0}", exceptionMessage);
            }
            //Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle);
            Browser.SwitchToParentWindow();
        }


    }

    /**
     *      Enrollment/OEC EAF Fallout Report
     * */

    [Binding]
    public class fsReportsEnrollmentOECEAFFallout
    {
        [When(@"Reports Enrollment OEC/EAF Fallout Run Report Button is Clicked")]
        public void WhenReportsEnrollmentOECEAFFalloutRunReportButtonIsClicked()
        {
            //string MainWindowHandle = Browser.Wd.CurrentWindowHandle;
            //string ReportWindowHandle = "";
            EAM.ReportsEnrollmentOECEAFFallout.RunReport.Click();
            tmsWait.Hard(3);

            ReUsableFunctions.reportAuthenticationHandler();

            #region Commented code : 
            //IAlert alert = Browser.Wd.SwitchTo().Alert();
            //alert.SendKeys("tmsservice");

            //alert.SendKeys(OpenQA.Selenium.Keys.Tab);

            ////alert.SendKeys("TriZetto456");
            ////alert.SendKeys(OpenQA.Selenium.Keys.Tab);
            //////System.Windows.Forms.SendKeys.SendWait("{ENTER}");
            ////alert.Accept();

            //ReadOnlyCollection<string> windowHandles = Browser.Wd.WindowHandles;

            //foreach (string handle in windowHandles)
            //{
            //    if (handle!=MainWindowHandle)
            //    {                    
            //            Browser.Wd.SwitchTo().Window(handle).Close();                      

            //    }
            //}
            #endregion
            //if (ReportWindowHandle == "")
            //{
            //    ReadOnlyCollection<string> windowHandles = Browser.Wd.WindowHandles;
            //    //MainWindowHandle = Browser.Wd.CurrentWindowHandle;

            //    foreach (string handle in windowHandles)
            //    {
            //        if (handle != MainWindowHandle)
            //        {
            //            ReportWindowHandle = handle;
            //            break;
            //        }
            //    }
            //}

            //Browser.Wd.SwitchTo().Window(ReportWindowHandle).Close();
            //tmsWait.Hard(1);
            //Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle);



            //fw.ConsoleReport("Report was closed");
            //ReportWindowHandle = "";

        }

        [Then(@"Verify Reports OEC/EAF Fallout Automated Spans Report has row")]
        public void ThenVerifyReportsOECEAFFalloutAutomatedSpansReportHasRow(Table table)
        {
            By reportViewBy = EAM.Reports.ReportMainViewBy;
            //string reportHandle = ReportsCommon.SwitchToReportWindow(reportViewBy, 30, "OEC/EAF Fallout Report");
            Browser.SwitchWindow();

            //if (reportHandle == "")
            //{
            //    Assert.Fail("CMS Response Code Level Detail Report was not opened");
            //}      
            Boolean haveValidatedTable = false;
            string exceptionMessage = "";
            for (int i = 0; i < 5; i++)
            {
                try
                {
                    //ds 01132016      By reportTableBy = By.XPath("//table[contains(., 'HIC')]");
                    By reportTableBy = By.TagName("table");
                    ReportsCommon.VerifyReportTableHasRow(reportTableBy, table);
                    haveValidatedTable = true;
                    break;
                }
                catch (Exception e)
                {
                    //       Browser.Wd.SwitchTo().Window(ReportsCommon.ReportWindowHandle).Close();
                    //        Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle).Close();
                    //       Assert.Fail("Verify CMS Response Code Level Detail table has row. Exception: {0}", e.Message);
                    exceptionMessage = e.Message;
                }
                try
                {
                    By reportTableBy = By.XPath("//table[contains(., 'HIC')]");
                    //By reportTableBy = By.TagName("table");
                    ReportsCommon.VerifyReportTableHasRow(reportTableBy, table);
                    haveValidatedTable = true;
                    break;
                }
                catch (Exception e)
                {
                    //       Browser.Wd.SwitchTo().Window(ReportsCommon.ReportWindowHandle).Close();
                    //        Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle).Close();
                    //       Assert.Fail("Verify CMS Response Code Level Detail table has row. Exception: {0}", e.Message);
                    exceptionMessage = e.Message;
                }
            }
            if (!haveValidatedTable)
            {
                Assert.Fail("Verify CMS Response Code Level Detail table has row. Exception: {0}", exceptionMessage);
            }
            //Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle);
            Browser.SwitchToParentWindow();
        }



        [When(@"Reports Enrollment Plan ID ""(.*)"" is selected")]
        public void WhenReportsEnrollmentPlanIDIsSelected(string plan)
        {
            SelectElement planID = new SelectElement(EAM.ReportsEnrollmentOECEAFFallout.PlanID);
            planID.SelectByText(plan);
        }

        [When(@"Reports Enrollment File Name ""(.*)"" is selected")]
        public void WhenReportsEnrollmentFileNameIsSelected(string file)
        {
            string GeneratedData = tmsCommon.GenerateData(file);
            SelectElement fileName = new SelectElement(EAM.ReportsEnrollmentOECEAFFallout.FileName);
            fileName.SelectByText(GeneratedData);
        }



        [When(@"Reports Enrollment OEC/EAF Fallout File Name is set to ""(.*)""")]
        public void WhenReportsEnrollmentOECEAFFalloutFileNameIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.ReportsEnrollmentOECEAFFallout.FileName);
            select.SelectByText(GeneratedData);
        }

        [Then(@"Verify Reports Enrollment OEC/EAF Fallout File Name list does not contain ""(.*)""")]
        public void ThenVerifyReportsEnrollmentOECEAFFalloutFileNameListDoesNotContain(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            IList<IWebElement> theseOptions = EAM.ReportsEnrollmentOECEAFFallout.FileName.FindElements(By.TagName("option"));
            Boolean ElementNotFound = true;
            string allElements = "";
            foreach (IWebElement thisOption in theseOptions)
            {
                string thisOptionValue = thisOption.GetAttribute("value");
                allElements += thisOptionValue + "   ";

                if (thisOptionValue == GeneratedData)
                {
                    ElementNotFound = false;
                }
            }
            Assert.AreEqual(true, ElementNotFound, "Do not expect to find element [" + GeneratedData + "] in list [" + allElements + "]");
            Console.WriteLine("Do not expect to find element [" + GeneratedData + "] in list [" + allElements + "]");
        }
    }

    /***
     *      Member/Member TRR History Report
     **/

    [Binding]
    public class fsMemberMemberTRRHistoryReport
    {
        [When(@"Reports Member Member TRR History HIC is set to ""(.*)""")]
        [Then(@"Reports Member Member TRR History HIC is set to ""(.*)""")]
        public void WhenReportsMemberMemberTRRHistoryHICIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MemberMemberTRRHistoryReport.HIC.SendKeys(GeneratedData);
        }

        [When(@"Reports Member Member TRR History Run Report button is clicked")]
        [Then(@"Reports Member Member TRR History Run Report button is clicked")]
        public void WhenReportsMemberMemberTRRHistoryRunReportButtonIsClicked()
        {
            EAM.MemberMemberTRRHistoryReport.RunReportButton.Click();
            tmsWait.WaitForReadyStateComplete(30);
        }

        [Then(@"Verify Reports Member Member TRR History Window has data")]
        public void ThenVerifyReportsMemberMemberTRRHistoryWindowHasData(Table table)
        {
            By reportViewBy = EAM.Reports.ReportMainViewBy;
            string reportExpText = "Member T/RR History";
            string reportHandle = "";

            reportHandle = ReportsCommon.SwitchToReportWindow(reportViewBy, 30, reportExpText);

            if (reportHandle == "")
            {
                Assert.Fail("Member Member TRR History Report was not opened");
            }

            try
            {
                ReportsCommon.VerifyReportHasData(reportViewBy, reportExpText, table);
            }
            catch (Exception e)
            {
                Browser.Wd.SwitchTo().Window(reportHandle).Close();
                Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle).Close();
                Assert.Fail("Verify Member Member TRR History Report has data. Exception: {0}", e.Message);
            }

            Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle);
        }

        [Then(@"Reports Member Member TRR History Window is closed")]
        public void ThenReportsMemberMemberTRRHistoryWindowIsClosed()
        {
            try
            {
                ReportsCommon.CloseReport();
            }
            catch (Exception e)
            {
                Assert.Fail("Member Member TRR History Report was not closed. Exception: {0}", e.Message);
            }
        }

        [Then(@"Verify Reports Member Member TRR History Window table has row")]
        public void ThenVerifyReportsMemberMemberTRRHistoryWindowTableHasRow(Table table)
        {
            By reportViewBy = EAM.Reports.ReportMainViewBy;
            string reportHandle = ReportsCommon.SwitchToReportWindow(reportViewBy, 30, "Member T/RR History");

            if (reportHandle == "")
            {
                Assert.Fail("CMS Response Code Level Detail Report was not opened");
            }

            try
            {
                By reportTableBy = By.XPath("//table[contains(., 'HIC')]");
                ReportsCommon.VerifyReportTableHasRow(reportTableBy, table);

            }
            catch (Exception e)
            {
                Browser.Wd.SwitchTo().Window(ReportsCommon.ReportWindowHandle).Close();
                Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle).Close();
                Assert.Fail("Verify Reports Member Member TRR History Window table has row. Exception: {0}", e.Message);
            }

            Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle);
        }


    }

    /***
     *      TRR Detail Report
     * */

    [Binding]
    public class fsCMSResponseTRRDetailReport
    {

        [When(@"Reports CMS Response TRR Detail TRR Date is set to ""(.*)""")]
        public void WhenReportsCMSResponseTRRDetailTRRDateIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.CMSResponseTRRDetailReport.TRRDate);
            select.SelectByText(GeneratedData);

        }

        [When(@"Reports CMS Response TRR Detail Plan ID is set to ""(.*)""")]
        public void WhenReportsCMSResponseTRRDetailPlanIDIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.CMSResponseTRRDetailReport.PlanID);
            select.SelectByText(GeneratedData);
        }

        [When(@"Reports CMS Response TRR Detail PBP ID is set to ""(.*)""")]
        public void WhenReportsCMSResponseTRRDetailPBPIDIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.CMSResponseTRRDetailReport.PBPID);
            select.SelectByText(GeneratedData);
        }

        [When(@"Reports CMS Response TRR Detail Processed is set to ""(.*)""")]
        public void WhenReportsCMSResponseTRRDetailProcessedIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.CMSResponseTRRDetailReport.Processed);
            select.SelectByText(GeneratedData);
        }

        [When(@"Reports CMS Response TRR Detail Run Report button is clicked")]
        public void WhenReportsCMSResponseTRRDetailRunReportButtonIsClicked()
        {
            EAM.CMSResponseTRRDetailReport.RunReport.Click();
            tmsWait.WaitForReadyStateComplete(30);

        }

        [Then(@"Verify Reports CMS Response TRR Detail Report Window has data")]
        public void ThenVerifyReportsCMSResponseTRRDetailReportWindowHasData(Table table)
        {
            By reportViewBy = EAM.Reports.ReportMainViewBy;
            string reportExpText = "T/RR Detail Report";
            string reportHandle = "";

            reportHandle = ReportsCommon.SwitchToReportWindow(reportViewBy, 30, reportExpText);

            if (reportHandle == "")
            {
                Assert.Fail("CMS Response TRR Detail Report was not opened");
            }

            try
            {
                ReportsCommon.VerifyReportHasData(reportViewBy, reportExpText, table);
            }
            catch (Exception e)
            {
                Browser.Wd.SwitchTo().Window(reportHandle).Close();
                Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle).Close();
                Assert.Fail("Verify CMS Response TRR Detail Report has data. Exception: {0}", e.Message);
            }

            Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle);
        }

        [When(@"CMS Response page Plan ID is set to ""(.*)""")]
        public void WhenCMSResponsePagePlanIDIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                new SelectElement(Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl05_ddValue"))).SelectByText(GeneratedData);
            }
            else
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    tmsWait.Hard(1);
                    
                    By Drp = By.XPath("//kendo-dropdownlist[@test-id='PlanID']//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + GeneratedData + "']");

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                }
                else
                {
                    SelectElement select = new SelectElement(EAM.CMSResponseTRRDetailReport.PlanID);
                    select.SelectByText(GeneratedData);
                }
            }
            
        }
        [When(@"CMS Response page PBP is set to ""(.*)""")]
        public void WhenCMSResponsePagePBPIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                new SelectElement(Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl07_ddValue"))).SelectByText(GeneratedData);
            }
            else
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    tmsWait.Hard(1);
                    
                    By Drp = By.XPath("//kendo-dropdownlist[@test-id='PBPID']//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + GeneratedData + "']");

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                }
                else
                {
                    SelectElement select = new SelectElement(EAM.CMSResponseTRRDetailReport.PBPID);
                    select.SelectByText(GeneratedData);
                }
            }
        }


        [When(@"CMS Response page TRR Date is set to ""(.*)""")]
        public void WhenCMSResponsePageTRRDateIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);

            if(ConfigFile.EnvType.Equals("ESI"))
            {
                new SelectElement(Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl03_ddValue"))).SelectByText(GeneratedData);
            }
            else
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    tmsWait.Hard(1);
                    
                    By Drp = By.XPath("//kendo-dropdownlist[@test-id='TRRMONTH']//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + GeneratedData + "']");

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                }
                else
                {
                    SelectElement select = new SelectElement(EAM.CMSResponseTRRDetailReport.TRRDate);
                    select.SelectByText(GeneratedData);
                }
            }
           
        }

        [Then(@"Reports CMS Response TRR Detail Report Window is closed")]
        public void ThenReportsCMSResponseTRRDetailReportWindowIsClosed()
        {
            try
            {
                ReportsCommon.CloseReport();
            }
            catch (Exception e)
            {
                Assert.Fail("CMS Response TRR Detail Report was not closed. Exception: {0}", e.Message);
            }
        }


    }

    /***
    *      CMS Response - T/RR Summary Report 
    * */

    [Binding]
    public class fsCMSResponseTRRSummaryReport
    {
        [When(@"Reports CMS Response TRR Summary TRR Date is set to ""(.*)""")]
        public void WhenReportsCMSResponseTRRSummaryTRRDateIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);

            if (ConfigFile.EnvType.Equals("ESI"))
            {
                new SelectElement(Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl03_ddValue"))).SelectByText(GeneratedData);
                
            }
            else
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    tmsWait.Hard(1);
                    
                    By Drp = By.XPath("//kendo-dropdownlist[@test-id='TRR_MONTH']//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + GeneratedData + "']");

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                }
                else
                {
                    SelectElement select = new SelectElement(EAM.CMSResponseTRRSummaryReport.TRRDate);
                    select.SelectByText(GeneratedData);
                }
            }
        }

        [When(@"Reports CMS Response TRR Summary Plan ID is set to ""(.*)""")]
        public void WhenReportsCMSResponseTRRSummaryPlanIDIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);

            if (ConfigFile.EnvType.Equals("ESI"))
            {
                new SelectElement(Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl05_ddValue"))).SelectByText(GeneratedData);

            }
            else
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    tmsWait.Hard(1);
                    
                    By Drp = By.XPath("//kendo-dropdownlist[@test-id='PLAN_ID']//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + GeneratedData + "']");

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                }
                else
                {
                    SelectElement select = new SelectElement(EAM.CMSResponseTRRSummaryReport.PlanID);
                    select.SelectByText(GeneratedData);
                }
            }
        }

        [When(@"Reports CMS Response TRR Summary Run Report button is clicked")]
        public void WhenReportsCMSResponseTRRSummaryRunReportButtonIsClicked()
        {
            EAM.CMSResponseTRRSummaryReport.RunReport.Click();
            tmsWait.WaitForReadyStateComplete(30);
        }

        [Then(@"Verify Reports CMS Response TRR Summary Window has data")]
        public void ThenVerifyReportsCMSResponseTRRSummaryWindowHasData(Table table)
        {
            By reportViewBy = EAM.Reports.ReportMainViewBy;
            string reportExpText = "T/RR Summary Report";
            string reportHandle = "";

            reportHandle = ReportsCommon.SwitchToReportWindow(reportViewBy, 30, reportExpText);

            if (reportHandle == "")
            {
                Assert.Fail("CMS Response TRR Summary Report was not opened");
            }

            try
            {
                ReportsCommon.VerifyReportHasData(reportViewBy, reportExpText, table);
            }
            catch (Exception e)
            {
                Browser.Wd.SwitchTo().Window(reportHandle).Close();
                Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle).Close();
                Assert.Fail("Verify CMS Response TRR Summary Report has data. Exception: {0}", e.Message);
            }

            Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle);
        }

        [Then(@"Reports CMS Response TRR Summary Report Window is closed")]
        public void ThenReportsCMSResponseTRRSummaryReportWindowIsClosed()
        {
            try
            {
                ReportsCommon.CloseReport();
            }
            catch (Exception e)
            {
                Assert.Fail("CMS Response TRR Summary Report was not closed. Exception: {0}", e.Message);
            }
        }


    }

    /***
     *     Records Duped Out from T/RR Report 
     * */

    [Binding]
    public class fsCMSResponseRecordsDupedOutFromTRRReport
    {
        [When(@"Reports CMS Response Records Duped Out from TRR TRR Date is set to ""(.*)""")]
        public void WhenReportsCMSResponseRecordsDupedOutFromTRRTRRDateIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.CMSResponseRecordsDupedOutFromTRRReport.TRRDate);
            select.SelectByText(GeneratedData);
        }

        [When(@"Reports CMS Response Records Duped Out from TRR TRR Date (.*) is selected")]
        public void WhenReportsCMSResponseRecordsDupedOutFromTRRTRRDateIsSelected(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.CMSResponseRecordsDupedOutFromTRRReport.TRRDate);
            select.SelectByText(GeneratedData);
        }


        [When(@"Reports CMS Response Records Duped Out from TRR Plan ID is set to ""(.*)""")]
        public void WhenReportsCMSResponseRecordsDupedOutFromTRRPlanIDIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.CMSResponseRecordsDupedOutFromTRRReport.PlanID);
            select.SelectByText(GeneratedData);
        }

        [When(@"Reports CMS Response Records Duped Out from TRR Plan ID (.*) is selected")]
        public void WhenReportsCMSResponseRecordsDupedOutFromTRRPlanIDHIsSelected(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.CMSResponseRecordsDupedOutFromTRRReport.PlanID);
            select.SelectByText(GeneratedData);
        }

        [When(@"Reports CMS Response Records Duped Out from TRR PBP ID is set to ""(.*)""")]
        public void WhenReportsCMSResponseRecordsDupedOutFromTRRPBPIDIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.CMSResponseRecordsDupedOutFromTRRReport.PBPID);
            select.SelectByText(GeneratedData);
        }

        [When(@"Reports CMS Response Records Duped Out from TRR PBP ID (.*) is selected")]
        public void WhenReportsCMSResponseRecordsDupedOutFromTRRPBPIDIsSelected(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.CMSResponseRecordsDupedOutFromTRRReport.PBPID);
            select.SelectByText(GeneratedData);
        }

        [When(@"Reports CMS Response Records Duped Out from TRR Run Report button is clicked")]
        public void WhenReportsCMSResponseRecordsDupedOutFromTRRRunReportButtonIsClicked()
        {
            EAM.CMSResponseRecordsDupedOutFromTRRReport.RunReport.Click();
            tmsWait.WaitForReadyStateComplete(30);
        }

        [Then(@"Verify Reports CMS Response Records Duped Out from TRR Window has data")]
        public void ThenVerifyReportsCMSResponseRecordsDupedOutFromTRRWindowHasData(Table table)
        {
            By reportViewBy = EAM.Reports.ReportMainViewBy;
            string reportExpText = "Records Duped Out from T/RR";
            string reportHandle = "";

            reportHandle = ReportsCommon.SwitchToReportWindow(reportViewBy, 30, reportExpText);

            if (reportHandle == "")
            {
                Assert.Fail("CMS Response TRR Detail Report was not opened");
            }

            try
            {
                ReportsCommon.VerifyReportHasData(reportViewBy, reportExpText, table);
            }
            catch (Exception e)
            {
                Browser.Wd.SwitchTo().Window(reportHandle).Close();
                Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle).Close();
                Assert.Fail("Verify Reports CMS Response Records Duped Out from TRR Window has data. Exception: {0}", e.Message);
            }

            Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle);
        }

        [Then(@"Reports CMS Response Records Duped Out from TRR Report Window is closed")]
        public void ThenReportsCMSResponseRecordsDupedOutFromTRRReportWindowIsClosed()
        {
            try
            {
                ReportsCommon.CloseReport();
            }
            catch (Exception e)
            {
                Assert.Fail("CMS Response Records Duped Out from TRR Report was not closed. Exception: {0}", e.Message);
            }
        }

        [Then(@"Verify Reports CMS Response Automated Spans Report has row")]
        public void ThenVerifyReportsCMSResponseAutomatedSpansReporthasrow(Table table)
        {
            By reportViewBy = EAM.Reports.ReportMainViewBy;
            string reportExpText = "Automated Span Report";
            string reportHandle = "";

            reportHandle = ReportsCommon.SwitchToReportWindow(reportViewBy, 30, reportExpText);

            if (reportHandle == "")
            {
                Assert.Fail("CMS Response Automated Span Report was not opened");
            }

            try
            {
                ReportsCommon.VerifyReportHasData(reportViewBy, reportExpText, table);
            }
            catch (Exception e)
            {
                Browser.Wd.SwitchTo().Window(reportHandle).Close();
                Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle).Close();
                Assert.Fail("Verify CMS Response Automated Span Report has data. Exception: {0}", e.Message);
            }
            Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle);
        }

        [When(@"Reports CMS Response Automated Spans Report is closed")]
        public void WhenReportsCMSResponseAutomatedSpansReportIsClosed()
        {
            try
            {
                ReportsCommon.CloseReport();
            }
            catch (Exception e)
            {
                Assert.Fail("CMS Response Automated Spans Report was not closed. Exception: {0}", e.Message);
            }
        }

        [Given(@"Automated Spans Page TRR Date as ""(.*)"" Plan ID as ""(.*)"" Actions as ""(.*)"" is selected")]
        public void GivenAutomatedSpansPageTRRDateAsPlanIDAsActionsAsIsSelected(string trrDate, string planID, string actions)
        {
            SelectElement trrDateDropdown = new SelectElement(ReportsCMSResponseAutomatedSpans.TRRDataDropdown);
            trrDateDropdown.SelectByText(trrDate);
            SelectElement planIDDropdown = new SelectElement(ReportsCMSResponseAutomatedSpans.PlanIDDropdown);
            planIDDropdown.SelectByText(planID);
            SelectElement actionsDropdown = new SelectElement(ReportsCMSResponseAutomatedSpans.ActionsDropdown);
            actionsDropdown.SelectByText(actions);
        }
        [When(@"EAM Report page Run Report button is Clicked")]
        public void WhenEAMReportPageRunReportButtonIsClicked()
        {
            ReportsCMSResponseAutomatedSpans.RunReportButton.Click();
            tmsWait.Hard(10);
           
            Browser.SwitchToChildWindow();
            Browser.SwitchToIFrame();

        }
        [Then(@"Verify Report page display value as ""(.*)""")]
        public void ThenVerifyReportPageDisplayValueAs(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            IWebElement elementPresence = Browser.Wd.FindElement(By.XPath("//div[contains(.,'"+value+"')]"));
            bool result = elementPresence.Displayed;

            Assert.IsTrue(result, value + "  is not found on Report");
        }



        [When(@"Automated Span Page Run Report button is clicked")]
        public void WhenAutomatedSpanPageRunReportButtonIsClicked()
        {
            ReportsCMSResponseAutomatedSpans.RunReportButton.Click();
        }
        public string CalculateQuartr(string receiptdate)
        {
            string quarter = "";
            DateTime dt = Convert.ToDateTime(receiptdate);

            if (dt.Month <= 3)
                quarter = "1";

            if (dt.Month>3 && dt.Month <= 6)
                quarter = "2";

            if (dt.Month>6 && dt.Month <= 9)
                quarter = "3";
            if(dt.Month>9 && dt.Month<=12)
             quarter = "4";
            return quarter;
        }
        public string EnrlRptelementCount(string receiptDate)
        {
            string[] quarter1CountForElementABCDEF = new string[6];
            string[] quarter2CountForElementABCDEF = new string[6];
            string[] quarter3CountForElementABCDEF = new string[6];
            string[] quarter4CountForElementABCDEF = new string[6];
            string countstring = "";
            var hearderdisplayed = EAM.EnrollmentComplianceReportElement.EnrlReportHeader;

            //EnrlReportHeader.Displayed;
            IWebElement[] quarter1ForElementABCDEFObj = { EAM.EnrollmentComplianceReportElement.ElementAFirstQrtr, EAM.EnrollmentComplianceReportElement.ElementBFirstQrtr, EAM.EnrollmentComplianceReportElement.ElementCFirstQrtr, EAM.EnrollmentComplianceReportElement.ElementDFirstQrtr, EAM.EnrollmentComplianceReportElement.ElementEFirstQrtr, EAM.EnrollmentComplianceReportElement.ElementFFirstQrtr };
            IWebElement[] quarter2ForElementABCDEFObj = { EAM.EnrollmentComplianceReportElement.ElementASecondQrtr, EAM.EnrollmentComplianceReportElement.ElementBSecondQrtr, EAM.EnrollmentComplianceReportElement.ElementCSecondQrtr, EAM.EnrollmentComplianceReportElement.ElementDSecondQrtr, EAM.EnrollmentComplianceReportElement.ElementESecondQrtr, EAM.EnrollmentComplianceReportElement.ElementFSecondQrtr };
            IWebElement[] quarter3ForElementABCDEFObj = { EAM.EnrollmentComplianceReportElement.ElementAThirdQrtr, EAM.EnrollmentComplianceReportElement.ElementBThirdQrtr, EAM.EnrollmentComplianceReportElement.ElementCThirdQrtr, EAM.EnrollmentComplianceReportElement.ElementDThirdQrtr, EAM.EnrollmentComplianceReportElement.ElementEThirdQrtr, EAM.EnrollmentComplianceReportElement.ElementFThirdQrtr };
            IWebElement[] quarter4ForElementABCDEFObj = { EAM.EnrollmentComplianceReportElement.ElementAForthQrtr, EAM.EnrollmentComplianceReportElement.ElementBForthQrtr, EAM.EnrollmentComplianceReportElement.ElementCForthQrtr, EAM.EnrollmentComplianceReportElement.ElementDForthQrtr, EAM.EnrollmentComplianceReportElement.ElementEForthQrtr, EAM.EnrollmentComplianceReportElement.ElementFForthQrtr };
            int arrayLength = quarter1CountForElementABCDEF.Length;

            string receiptdate = tmsCommon.GenerateData(receiptDate);
            string quarter = CalculateQuartr(receiptdate);

            for (int i = 0; i < arrayLength; i++)
            {
                switch (quarter)
                {
                    case "1":
                        quarter1CountForElementABCDEF[i] = quarter1ForElementABCDEFObj[i].Text.ToString();
                        break;
                    case "2":
                        quarter2CountForElementABCDEF[i] = quarter2ForElementABCDEFObj[i].Text.ToString();
                        break;
                    case "3":
                        quarter3CountForElementABCDEF[i] = quarter3ForElementABCDEFObj[i].Text.ToString();
                        break;
                    case "4":
                        quarter4CountForElementABCDEF[i] = quarter4ForElementABCDEFObj[i].Text.ToString();
                        break;

                }
            }
            if (quarter == "1") countstring = string.Join(",", quarter1CountForElementABCDEF);
            if (quarter == "2") countstring = string.Join(",", quarter2CountForElementABCDEF);
            if (quarter == "3") countstring = string.Join(",", quarter3CountForElementABCDEF);
            if (quarter == "4") countstring = string.Join(",", quarter4CountForElementABCDEF);
           
            return countstring;
        }
        [Then(@"Quarterly Enrollment Compliance Report Count is noted for ""(.*)""")]
        [When(@"Quarterly Enrollment Compliance Report Count is noted for ""(.*)""")]
        [Given(@"Quarterly Enrollment Compliance Report Count is noted for ""(.*)""")]
        public void GivenQuarterlyEnrollmentComplianceReportCountIsNotedFor(string receiptDate)
        {
            string countstring = EnrlRptelementCount(receiptDate);
            GlobalRef.InitialreportCountEnrl = Int32.Parse(countstring);
            CloseReport();
        }

        [Then(@"Verify that count in Element ""(.*)"" for ""(.*)"" is ""(.*)"" for ""(.*)""")]
        [Given(@"Verify that count in Element ""(.*)"" for ""(.*)"" is ""(.*)"" for ""(.*)""")]
        [When(@"Verify that count in Element ""(.*)"" for ""(.*)"" is ""(.*)"" for ""(.*)""")]
        public void WhenVerifyThatCountInElementForIsFor(string expectedElement, string receiptDate, string change, string Transactionnumber)
        {
           


            string initialcountstr ; 
            if (Transactionnumber.ToUpper().Equals("TC2")) initialcountstr = GlobalRef.InitialreportCountEnrl.ToString();
            else initialcountstr = GlobalRef.OldreportCountEnrl.ToString();
            tmsWait.Hard(2);
            string newCountstr = EnrlRptelementCount(receiptDate);
            GlobalRef.OldreportCountEnrl = Int32.Parse(newCountstr);


            string[] elementArray = expectedElement.Split(',');
            int initialcount = 0;
            int newCount = 0;
            bool differ = false;
            bool nochange = false;

            ArrayList initialcountary = new ArrayList();
            ArrayList newcountary = new ArrayList();
            initialcountary.AddRange(initialcountstr.Split(new char[] { ',' }));
            newcountary.AddRange(newCountstr.Split(new char[] { ',' }));

            foreach (string element in elementArray)
            {
                switch (element)
                {
                    case "A":
                        initialcount = Int32.Parse(initialcountary[0].ToString());
                        newCount = Int32.Parse(newcountary[0].ToString());
                        Console.WriteLine("initialcount A "+ initialcount);
                        Console.WriteLine("newCount A " + newCount);
                        break;
                    case "B":
                        initialcount = Int32.Parse(initialcountary[1].ToString());
                        newCount = Int32.Parse(newcountary[1].ToString());
                        Console.WriteLine("initialcount b " + initialcount);
                        Console.WriteLine("newCount b " + newCount);
                        break;
                    case "C":
                        initialcount = Int32.Parse(initialcountary[2].ToString());
                        newCount = Int32.Parse(newcountary[2].ToString());
                        Console.WriteLine("initialcount C " + initialcount);
                        Console.WriteLine("newCount C " + newCount);
                        break;
                    case "D":
                        initialcount = Int32.Parse(initialcountary[3].ToString());
                        newCount = Int32.Parse(newcountary[3].ToString());
                        break;
                    case "E":
                        initialcount = Int32.Parse(initialcountary[4].ToString());
                        newCount = Int32.Parse(newcountary[4].ToString());
                        Console.WriteLine("initialcount D " + initialcount);
                        Console.WriteLine("newCount D " + newCount);
                        break;
                    case "F":
                        initialcount = Int32.Parse(initialcountary[5].ToString());
                        newCount = Int32.Parse(newcountary[5].ToString());
                        Console.WriteLine("initialcount F " + initialcount);
                        Console.WriteLine("newCount F " + newCount);
                        break;
                }

                int diff = newCount - initialcount;
                if (diff == 1) differ = true;
                if (diff == -1) differ = true;
                if (diff == 0) nochange = true;

                if (change.Trim().ToLower().Equals("increased")) Assert.IsTrue(differ, "Count is not increased by 1");
                if (change.Trim().ToLower().Equals("decreased")) Assert.IsTrue(differ, "Count is increased by 1");
                if (change.Trim().ToLower().Equals("not increased")) Assert.IsTrue(nochange, "there is a change in count");
                //Read all  the drill down table to make a list of all hIC number present there.

            }
        }

        [Then(@"verify whether ""(.*)"" ""(.*)"" in drill down for ""(.*)"" for ""(.*)""")]
        public void ThenVerifyWhetherInDrillDownForFor(string hic, string present, string Receiptdate, string expectedElement)
        {
            string HIC = tmsCommon.GenerateData(hic);
            string[] elementArray = expectedElement.Split(',');
            List<int> psudoelementList = new List<int>();
           
            string tabindex = "";
            string column = "";
            string basexpath = "";
            int[] elementarryQrt1 = {1,2,9,10,17,18};
            int[] elementarryQrt2 = {3,4,11,12,19,20};
            int[] elementarryQrt3 = {5,6,13,14,21,22};
            int[] elementarryQrt4 = {7,8,15,16,23,24};

            string receiptdate = tmsCommon.GenerateData(Receiptdate);
            string quarter = CalculateQuartr(receiptdate);
            //A->0 b->1
            //    then replace these digits in basexpath = quarter1ForElementABCDEFObj[digit].GetAttribute("xpath");

            var list = new List<string>((string[])elementArray);
            if (list.Contains("A")) psudoelementList.Add(0);
            if (list.Contains("B")) psudoelementList.Add(1);
            if (list.Contains("C")) psudoelementList.Add(2);
            if (list.Contains("D")) psudoelementList.Add(3);
            if (list.Contains("E")) psudoelementList.Add(4);
            if (list.Contains("F")) psudoelementList.Add(5);

         foreach(int psudoelement in psudoelementList)
            {
                IWebElement[] quarter1ForElementABCDEFObj = { EAM.EnrollmentComplianceReportElement.ElementAFirstQrtr, EAM.EnrollmentComplianceReportElement.ElementBFirstQrtr, EAM.EnrollmentComplianceReportElement.ElementCFirstQrtr, EAM.EnrollmentComplianceReportElement.ElementDFirstQrtr, EAM.EnrollmentComplianceReportElement.ElementEFirstQrtr, EAM.EnrollmentComplianceReportElement.ElementFFirstQrtr };
                IWebElement[] quarter2ForElementABCDEFObj = { EAM.EnrollmentComplianceReportElement.ElementASecondQrtr, EAM.EnrollmentComplianceReportElement.ElementBSecondQrtr, EAM.EnrollmentComplianceReportElement.ElementCSecondQrtr, EAM.EnrollmentComplianceReportElement.ElementDSecondQrtr, EAM.EnrollmentComplianceReportElement.ElementESecondQrtr, EAM.EnrollmentComplianceReportElement.ElementFSecondQrtr };
                IWebElement[] quarter3ForElementABCDEFObj = { EAM.EnrollmentComplianceReportElement.ElementAThirdQrtr, EAM.EnrollmentComplianceReportElement.ElementBThirdQrtr, EAM.EnrollmentComplianceReportElement.ElementCThirdQrtr, EAM.EnrollmentComplianceReportElement.ElementDThirdQrtr, EAM.EnrollmentComplianceReportElement.ElementEThirdQrtr, EAM.EnrollmentComplianceReportElement.ElementFThirdQrtr };
                IWebElement[] quarter4ForElementABCDEFObj = { EAM.EnrollmentComplianceReportElement.ElementAForthQrtr, EAM.EnrollmentComplianceReportElement.ElementBForthQrtr, EAM.EnrollmentComplianceReportElement.ElementCForthQrtr, EAM.EnrollmentComplianceReportElement.ElementDForthQrtr, EAM.EnrollmentComplianceReportElement.ElementEForthQrtr, EAM.EnrollmentComplianceReportElement.ElementFForthQrtr };
                int index = 0;
                IWebElement tempelement = null;
                switch (quarter)
                    {
                        case "1":
                            tempelement = quarter1ForElementABCDEFObj[psudoelement];
                            index = elementarryQrt1[psudoelement];
                            break;
                        case "2":
                            tempelement = quarter2ForElementABCDEFObj[psudoelement];
                            index = elementarryQrt2[psudoelement];
                            break;
                        case "3":
                        
                        tempelement = quarter3ForElementABCDEFObj[psudoelement];
                            index = elementarryQrt3[psudoelement];
                            break;
                        case "4":
                            tempelement = quarter4ForElementABCDEFObj[psudoelement];
                            index = elementarryQrt4[psudoelement];
                            break;
                        default:
                            index = elementarryQrt4[psudoelement];
                            break;
                    }

                    if (index % 2 == 0) column = "6"; else column = "5";
                    tabindex = index.ToString();
                    basexpath = ".//a[@tabindex='" + tabindex + "']/parent::node()/parent::td/parent::tr//following-sibling::tr[1]/td[" + column + "]//td//div[contains(.,'" + HIC + "')]";


                    fw.ExecuteJavascript(tempelement.FindElement(By.TagName("img")));
                    tmsWait.Hard(3);
                IWebElement expectedHIC = null;
               
                try {  expectedHIC = Browser.Wd.FindElement(By.XPath(basexpath)); }
                catch
                {
                    if (present.Trim().ToLower() == "not exist") { break; }
                    if (present.Trim().ToLower() == "exist") Assert.IsTrue(expectedHIC==null, HIC + "is not displayed in drill down");
                }                  
            }
            CloseReport();
        }

        public void CloseReport()
        {
            string currentHandle = "";
            ReadOnlyCollection<string> windowHandles = Browser.Wd.WindowHandles;
            currentHandle = Browser.Wd.CurrentWindowHandle;

            Browser.Wd.SwitchTo().Window(windowHandles[1]).Close();
            Browser.Wd.SwitchTo().Window(windowHandles[0]);
        }
        public string DisenrlTotatCountElementD()
        {
            IList<IWebElement> listOftable = EAM.DisenrollmentComplianceReportElement.ReportPage.FindElements(By.TagName("tbody"));
            int countTable = listOftable.Count;
            IList<IWebElement> listOftd = listOftable[countTable - 3].FindElements(By.TagName("td"));
            // IList<IWebElement> listOftd = listOftable[13].FindElements(By.TagName("td"));
            //verify which td has required value and use it.
            string count = listOftd[67].Text;
           // CloseReport();
            return count;
        }
        public string DisenrlTotatCountElementA()
        {
            IList<IWebElement> listOftable = EAM.DisenrollmentComplianceReportElement.ReportPage.FindElements(By.TagName("tbody"));
            int countTable = listOftable.Count;
            IList<IWebElement> listOftd = listOftable[countTable - 3].FindElements(By.TagName("td"));
            //verify which td has required value and use it.
            string count = listOftd[64].Text;
           // CloseReport();
            return count;
        }
        public string DisenrlTotatCountElementB()
        {
            IList<IWebElement> listOftable = EAM.DisenrollmentComplianceReportElement.ReportPage.FindElements(By.TagName("tbody"));
            int countTable = listOftable.Count;
            IList<IWebElement> listOftd = listOftable[countTable - 3].FindElements(By.TagName("td"));
            //IList<IWebElement> listOftd = listOftable[13].FindElements(By.TagName("td"));
            //verify which td has required value and use it.
            string count = listOftd[65].Text;
            //CloseReport();
            return count;
        }
        public string DisenrlTotatCountElementC()
        {            
            IList<IWebElement> listOftable = EAM.DisenrollmentComplianceReportElement.ReportPage.FindElements(By.TagName("tbody"));
            int countTable = listOftable.Count;
            IList<IWebElement> listOftd = listOftable[countTable - 3].FindElements(By.TagName("td"));
            //IList<IWebElement> listOftd = listOftable[13].FindElements(By.TagName("td"));
            //verify which td has required value and use it.
            string count = listOftd[66].Text;
            //CloseReport();
            return count;
        }


        [Given(@"""(.*)"" link is clicked")]
        [Then(@"""(.*)"" link is clicked")]
        public void GivenLinkIsClicked(string p0)
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.Id("ctl00_MainMasterContent_ctl00_Hyperlink4")));
        }

        [Then(@"I close the report")]
        public void ThenICloseTheReport()
        {
            CloseReport();
        }



        [Then(@"Quarterly Disenrollment Compliance Report Total Count is noted for Element A")]
        public void ThenQuarterlyDisenrollmentComplianceReportTotalCountIsNotedForElementA()
        {
            string count = DisenrlTotatCountElementA();
            Console.WriteLine("COUNT IS "+count);
            GlobalRef.InitialreportCount = Int32.Parse(count);
           // CloseReport();
            
        }

        [Then(@"Quarterly Disenrollment Compliance Report Total Count is noted for Element D")]
        public void ThenQuarterlyDisenrollmentComplianceReportTotalCountIsNotedForElementD()
        {
            string count = DisenrlTotatCountElementD();
            //if (File.Exists(@"D:\WriteLines2.txt")) File.Delete(@"D:\WriteLines2.txt");
            //using (System.IO.StreamWriter file =
            //new System.IO.StreamWriter(@"D:\WriteLines2.txt", true))
            //{
            //    file.WriteLine(String.Empty);
            //    file.WriteLine(count);
            //}
            Console.WriteLine("COUNT IS " + count);
            GlobalRef.InitialreportCount = Int32.Parse(count);
            //CloseReport();
        }
        [Then(@"Quarterly Disenrollment Compliance Report Total Count is noted for Element C")]
        public void ThenQuarterlyDisenrollmentComplianceReportTotalCountIsNotedForElementC()
        {
            string count = DisenrlTotatCountElementC();
            GlobalRef.InitialreportCount = Int32.Parse(count);
            GlobalRef.InitialColumnCcount = Int32.Parse(count);
            Console.WriteLine("COUNT IS " + count);

          //CloseReport();
        }
        [Then(@"Quarterly Disenrollment Compliance Report Total Count is noted for Element B")]
        public void ThenQuarterlyDisenrollmentComplianceReportTotalCountIsNotedForElementB()
        {
            tmsWait.Hard(3);
            string count = DisenrlTotatCountElementB();
            GlobalRef.InitialreportCount = Int32.Parse(count);
            Console.WriteLine("COUNT IS " + count);
           // CloseReport();
        }
        [Then(@"Quarterly Voluntary Disenrollment Compliance Report Total Count is noted for Element A")]
        public void ThenQuarterlyVoluntaryDisenrollmentComplianceReportTotalCountIsNotedForElementA()



        {
            string count = DisenrlTotatCountElementA();
            Console.WriteLine("COUNT IS " + count);
            GlobalRef.InitialreportCountA = Int32.Parse(count);
            GlobalRef.InitialreportCount = Int32.Parse(count);
            GlobalRef.InitialColumnAcount = Int32.Parse(count);
            GlobalRef.TotalEnrlReceivedAInit = Int32.Parse(count);


            // CloseReport();

        }


        [Then(@"Quarterly Voluntary Disenrollment Compliance Report Total Count is noted for Element B")]
        public void ThenQuarterlyVoluntaryDisenrollmentComplianceReportTotalCountIsNotedForElementB()
        {
            string count = DisenrlTotatCountElementB();
            Console.WriteLine("COUNT IS " + count);
            GlobalRef.InitialreportCountB = Int32.Parse(count);
            GlobalRef.InitialreportCount = Int32.Parse(count);
            GlobalRef.InitialColumnBcount= Int32.Parse(count);
            GlobalRef.EnrollmentsCompleteattheTimeofInitialReceiptInitB = Int32.Parse(count);
        }


        [Then(@"Verify Quarterly Disenrollment Compliance Report Total Count is decreased for Column A")]
        public void ThenVerifyQuarterlyDisenrollmentComplianceReportTotalCountIsDecreasedForColumnA()
        {
            GlobalRef.CurrentColumnAcount = Int32.Parse(Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='8']//tr[8]/td[5]/div/div")).Text);
            Console.WriteLine(" Column A Count Now --> " + GlobalRef.CurrentColumnAcount);

            int initialCount = Convert.ToInt32(GlobalRef.InitialColumnAcount);
            int currentCount = Convert.ToInt32(GlobalRef.CurrentColumnAcount);
            Assert.AreEqual(initialCount, currentCount, "Letter count is not getting decreased for Cloumn A");
            Browser.SwitchToChildWindow().Close();
            tmsWait.Hard(1);
            Browser.SwitchToParentWindow();
        }
        [Then(@"Verify Quarterly Disenrollment Compliance Report Count is decreased for Column A")]
        public void ThenVerifyQuarterlyDisenrollmentComplianceReportCountIsDecreasedForColumnA()
        {
            GlobalRef.CurrentColumnAcount = Int32.Parse(Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='8']//tr[8]/td[5]/div/div")).Text);
            Console.WriteLine(" Column A Count Now --> " + GlobalRef.CurrentColumnAcount);

            int initialCount = Convert.ToInt32(GlobalRef.FinalColumnAcount);
            int currentCount = Convert.ToInt32(GlobalRef.CurrentColumnAcount);
            bool res = initialCount > currentCount;
            Assert.IsTrue(res, "Letter count is not getting decreased for Cloumn A");
            Browser.SwitchToChildWindow().Close();
            tmsWait.Hard(1);
            //Browser.SwitchToParentWindow();
        }

        [Then(@"Verify Quarterly Disenrollment Compliance Report Total Count is increased for Column A")]
        public void ThenVerifyQuarterlyDisenrollmentComplianceReportTotalCountIsIncreasedForColumnA()
        {
            GlobalRef.FinalColumnAcount = Int32.Parse(Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='8']//tr[8]/td[5]/div")).Text);
            Console.WriteLine(" Column A Count Now --> " + GlobalRef.FinalColumnAcount);

            int initialCount = Convert.ToInt32(GlobalRef.InitialColumnAcount);
            int finalCount = Convert.ToInt32(GlobalRef.FinalColumnAcount);
            bool results = (finalCount >initialCount);
            Assert.IsTrue(results, "Letter count is not getting increased for Cloumn A");
            Browser.SwitchToChildWindow().Close();
            tmsWait.Hard(1);
            Browser.SwitchToParentWindow();

        }
        [Then(@"Verify Quarterly Disenrollment Compliance Report Count is increased for Column A")]
        public void ThenVerifyQuarterlyDisenrollmentComplianceReportCountIsIncreasedForColumnA()
        {
            GlobalRef.FinalColumnAcount = Int32.Parse(Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='8']//tr[8]/td[5]/div")).Text);
            Console.WriteLine(" Column A Count Now --> " + GlobalRef.FinalColumnAcount);

            int initialCount = Convert.ToInt32(GlobalRef.InitialColumnAcount);
            int finalCount = Convert.ToInt32(GlobalRef.FinalColumnAcount);
            bool results = (finalCount > initialCount);
            Assert.IsTrue(results, "Letter count is not getting increased for Cloumn A");
            

        }
        [Then(@"Verify Quarterly Disenrollment Compliance Report Count is increased for Column B")]
        public void ThenVerifyQuarterlyDisenrollmentComplianceReportTotalCountIsIncreasedForColumnB()
        {
            GlobalRef.FinalColumnBcount = Int32.Parse(Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='8']//tr[8]/td[6]/div")).Text);
            Console.WriteLine(" Column B Count Now --> " + GlobalRef.FinalColumnBcount);

            int initialCount = Convert.ToInt32(GlobalRef.InitialColumnBcount);
            int finalCount = Convert.ToInt32(GlobalRef.FinalColumnBcount);
            bool results = (finalCount > initialCount);
            Assert.IsTrue(results, "Letter count is not getting increased for Cloumn B");
            Browser.SwitchToChildWindow().Close();
            tmsWait.Hard(1);
            Browser.SwitchToParentWindow();
        }

        [Then(@"Verify Quarterly Disenrollment Compliance Report Total Count is increased for Column C")]
        public void ThenVerifyQuarterlyDisenrollmentComplianceReportTotalCountIsIncreasedForColumnC()
        {
            GlobalRef.FinalColumnCcount = Int32.Parse(Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='8']//tr[8]/td[7]/div")).Text);
           
            Console.WriteLine(" Column C Count Now --> " + GlobalRef.FinalColumnCcount);

            int initialCount = Convert.ToInt32(GlobalRef.InitialColumnCcount);
            int finalCount = Convert.ToInt32(GlobalRef.FinalColumnCcount);
            bool results = (finalCount > initialCount);
            Assert.IsTrue(results, "Letter count is not getting increased for Cloumn C");
            //Browser.SwitchToChildWindow().Close();
            //tmsWait.Hard(1);
            //Browser.SwitchToParentWindow();
        }


        [Then(@"Verify Quarterly Disenrollment Compliance Report Total Count is not increased for Column A")]
        public void ThenVerifyQuarterlyDisenrollmentComplianceReportTotalCountIsNotIncreasedForColumnA()
        {
            GlobalRef.FinalColumnAcount = Int32.Parse(Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='8']//tr[8]/td[5]/div/div")).Text);
            Console.WriteLine(" Column A Count Now --> " + GlobalRef.FinalColumnAcount);

            int initialCount = Convert.ToInt32(GlobalRef.InitialColumnAcount);
            int finalCount = Convert.ToInt32(GlobalRef.FinalColumnAcount);

            Assert.AreEqual(initialCount, finalCount,"Column A Count is increased ");
            Browser.SwitchToChildWindow().Close();
            tmsWait.Hard(1);
            Browser.SwitchToParentWindow();
        }

        [Then(@"Quarterly Disenrollment Compliance Report Total Count is noted for Column D")]
        public void ThenQuarterlyDisenrollmentComplianceReportTotalCountIsNotedForColumnD()
        {
            GlobalRef.InitialColumnDcount = Int32.Parse(Browser.Wd.FindElement(By.XPath("//tr[8]/td[8]/div/div")).Text);
            Console.WriteLine(" Initial Column D Count Now --> " + GlobalRef.InitialColumnDcount);

            Browser.SwitchToChildWindow().Close();
            tmsWait.Hard(1);
            Browser.SwitchToParentWindow();
        }
        [Then(@"Quarterly Disenrollment Compliance Report Count is noted for Column D")]
        public void ThenQuarterlyDisenrollmentComplianceReportCountIsNotedForColumnD()
        {
            string newcountstr = "";
            newcountstr= DisenrlTotatCountElementD();
            GlobalRef.InitialColumnDcount = Int32.Parse(newcountstr);
            Console.WriteLine(" Initial Column D Count Now --> " + GlobalRef.InitialColumnDcount);

            Browser.SwitchToChildWindow().Close();
            tmsWait.Hard(1);
            Browser.SwitchToParentWindow();
        }

        [Then(@"Verify Quarterly Disenrollment Compliance Report Total Count is not increased for Column D")]
        public void ThenVerifyQuarterlyDisenrollmentComplianceReportTotalCountIsNotIncreasedForColumnD()
        {
            Browser.SwitchToChildWindow();
            GlobalRef.FinalColumnDcount = Int32.Parse(Browser.Wd.FindElement(By.XPath("//tr[8]/td[8]/div/div")).Text);
            Console.WriteLine(" Final Column D Count Now --> " + GlobalRef.FinalColumnDcount);

            int initialCount = Convert.ToInt32(GlobalRef.InitialColumnDcount);
            int finalCount = Convert.ToInt32(GlobalRef.FinalColumnDcount);
            Assert.AreEqual(initialCount, finalCount, "Column A Count is increased ");
            Browser.SwitchToChildWindow().Close();
            tmsWait.Hard(1);
            Browser.SwitchToParentWindow();
        }

        [Then(@"Verify Quarterly Disenrollment Compliance Report Count is not increased for Column D")]
        public void ThenVerifyQuarterlyDisenrollmentComplianceReportCountIsNotIncreasedForColumnD()
        {
            string newcountstr = "";
            newcountstr = DisenrlTotatCountElementD();
            GlobalRef.FinalColumnDcount = Int32.Parse(newcountstr);
            Console.WriteLine(" Final Column D Count Now --> " + GlobalRef.FinalColumnDcount);

            int initialCount = Convert.ToInt32(GlobalRef.InitialColumnDcount);
            int finalCount = Convert.ToInt32(GlobalRef.FinalColumnDcount);
            Assert.AreEqual(initialCount, finalCount, "Column A Count is increased ");
            Browser.SwitchToChildWindow().Close();
            tmsWait.Hard(1);
            Browser.SwitchToParentWindow();
        }
        [Then(@"Quarterly Disenrollment Compliance Report Total Count is noted for Column B")]
        public void ThenQuarterlyDisenrollmentComplianceReportTotalCountIsNotedForColumnB()
        {
            GlobalRef.InitialColumnBcount = Int32.Parse(Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='8']//tr[8]/td[6]/div")).Text);
            //*[@dir="LTR"]table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td/table/tbody/tr[8]/td[5]/div
            fw.ConsoleReport(" Column B Count Now --> " + GlobalRef.InitialColumnBcount);

            Browser.SwitchToChildWindow().Close();
            tmsWait.Hard(1);
            Browser.SwitchToParentWindow();
        }

       

        [Then(@"Quarterly Disenrollment Compliance Report Total Count is noted for Column A and B")]
        public void ThenQuarterlyDisenrollmentComplianceReportTotalCountIsNotedForColumnAAndB()
        {
            try
            {
                GlobalRef.InitialColumnAcount = Int32.Parse(Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='8']//tr[8]/td[5]/div")).Text);

            }
            catch
            {
                GlobalRef.InitialColumnAcount = 0;
            }
           
            
            fw.ConsoleReport(" Quarterly Disenrollment Compliance Report - Column A Count Now --> " + GlobalRef.InitialColumnAcount);

            try
            {
                GlobalRef.InitialColumnBcount = Int32.Parse(Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='8']//tr[8]/td[6]/div")).Text);
            }
            catch
            {
                GlobalRef.InitialColumnBcount = 0;
            }
           
            fw.ConsoleReport("  Quarterly Disenrollment Compliance Report - Column B Count Now --> " + GlobalRef.InitialColumnBcount);
            Browser.SwitchToChildWindow().Close();
            tmsWait.Hard(1);
            Browser.SwitchToParentWindow();

        }

        [Then(@"Quarterly Disenrollment Compliance Report Total Count is noted for Column A and B is decreased")]
        public void ThenQuarterlyDisenrollmentComplianceReportTotalCountIsNotedForColumnAAndBIsDecreased()
        {
            tmsWait.Hard(3);
            try
            {
                GlobalRef.FinalColumnAcount = Int32.Parse(Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='8']//tr[8]/td[5]/div")).Text);

            }
            catch
            {
                GlobalRef.FinalColumnAcount = 0;
            }


            fw.ConsoleReport(" Quarterly Disenrollment Compliance Report - Column A Count Now --> " + GlobalRef.FinalColumnAcount);

            try
            {
                GlobalRef.FinalColumnBcount = Int32.Parse(Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='8']//tr[8]/td[6]/div")).Text);
            }
            catch
            {
                GlobalRef.FinalColumnBcount = 0;
            }

            fw.ConsoleReport("  Quarterly Disenrollment Compliance Report - Column B Count Now --> " + GlobalRef.FinalColumnBcount);
           
            int initA= Convert.ToInt32(GlobalRef.InitialColumnAcount);
            int finalA = Convert.ToInt32(GlobalRef.FinalColumnAcount);
            int initB = Convert.ToInt32(GlobalRef.InitialColumnBcount);
            int finalB = Convert.ToInt32(GlobalRef.FinalColumnBcount);
            bool resultsA = (initA> finalA);
            bool resutlsB = (initB> finalB);
            Assert.IsTrue(resultsA, " Coumn A value is not descreased");
            Assert.IsTrue(resutlsB, " Coumn B value is not descreased");
            Browser.SwitchToChildWindow().Close();
            tmsWait.Hard(1);
            Browser.SwitchToParentWindow();
        }

        [Then(@"Quarterly Disenrollment Compliance Report Total Count is noted for Column A and B is Increased After (.*) TC")]
        public void ThenQuarterlyDisenrollmentComplianceReportTotalCountIsNotedForColumnAAndBIsIncreasedAfterTC(int p0)
        {

            tmsWait.Hard(3);
            try
            {
                GlobalRef.TC51ColumnAcount = Int32.Parse(Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='8']//tr[8]/td[5]/div")).Text);

            }
            catch
            {
                GlobalRef.TC51ColumnAcount = 0;
            }


            fw.ConsoleReport(" Quarterly Disenrollment Compliance Report - Column A Count Now --> " + GlobalRef.TC51ColumnAcount);

            try
            {
                GlobalRef.TC51ColumnBcount = Int32.Parse(Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='8']//tr[8]/td[6]/div")).Text);
            }
            catch
            {
                GlobalRef.TC51ColumnBcount = 0;
            }

            fw.ConsoleReport("  Quarterly Disenrollment Compliance Report - Column B Count Now --> " + GlobalRef.TC51ColumnBcount);

            int beforeTC51A = Convert.ToInt32(GlobalRef.FinalColumnAcount);
            int AfterTC51A = Convert.ToInt32(GlobalRef.TC51ColumnAcount);
            int beforeTC5B = Convert.ToInt32(GlobalRef.FinalColumnBcount);
            int AfterTC51B = Convert.ToInt32(GlobalRef.TC51ColumnBcount);
            bool resultsA = (AfterTC51A > beforeTC51A);
            bool resutlsB = (AfterTC51B > beforeTC5B);
            Assert.IsTrue(resultsA, " Coumn A value is not inscreased");
            Assert.IsTrue(resutlsB, " Coumn B value is not inscreased");
            Browser.SwitchToChildWindow().Close();
            tmsWait.Hard(1);
            Browser.SwitchToParentWindow();
        }

        [Then(@"Quarterly Disenrollment Compliance Report Total Count is noted for Column A is decreased")]
        public void ThenQuarterlyDisenrollmentComplianceReportTotalCountIsNotedForColumnAIsDecreased()
        {
            GlobalRef.FinalColumnAcount = Int32.Parse(Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='8']//tr[8]/td[5]/div")).Text);

            fw.ConsoleReport(" Final Column A Count Now --> " + GlobalRef.FinalColumnAcount);

            int initA = Convert.ToInt32(GlobalRef.InitialColumnAcount);
            int finalA = Convert.ToInt32(GlobalRef.FinalColumnAcount);
          
            bool resultsA = (initA > finalA);
            
            Assert.IsTrue(resultsA, " Coumn A value is not decreased");

            Browser.SwitchToChildWindow().Close();
            tmsWait.Hard(1);
            Browser.SwitchToParentWindow();
        }

        [Then(@"Quarterly Disenrollment Compliance Report Total Count is noted for Column A is not increased")]
        public void ThenQuarterlyDisenrollmentComplianceReportTotalCountIsNotedForColumnAIsNotIncreased()
        {
            GlobalRef.FinalColumnAcount = Int32.Parse(Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='8']//tr[8]/td[5]/div")).Text);

            fw.ConsoleReport(" Final Column A Count Now --> " + GlobalRef.FinalColumnAcount);

            int initA = Convert.ToInt32(GlobalRef.InitialColumnAcount);
            int finalA = Convert.ToInt32(GlobalRef.FinalColumnAcount);

            bool resultsA = (initA == finalA);

            Assert.IsTrue(resultsA, " Coumn A value is increased or decreased");

            Browser.SwitchToChildWindow().Close();
            tmsWait.Hard(1);
            Browser.SwitchToParentWindow();
        }


        [Then(@"Quarterly Disenrollment Compliance Report Total Count is noted for Column A")]
        public void ThenQuarterlyDisenrollmentComplianceReportTotalCountIsNotedForColumnA()
        {
            GlobalRef.InitialColumnAcount = Int32.Parse(Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='8']//tr[8]/td[5]/div")).Text);
            fw.ConsoleReport(" Initial Column A Count Now --> " + GlobalRef.InitialColumnAcount);
            Browser.SwitchToChildWindow().Close();
            tmsWait.Hard(1);
            Browser.SwitchToParentWindow();
        }

        [Then(@"Quarterly Voluntary Disenrollment Compliance Report Count is noted for Element A")]
        public void ThenQuarterlyVoluntaryDisenrollmentComplianceReportCountIsNotedForElementA()
        {

            GlobalRef.InitialColumnAcount = Int32.Parse(Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='8']//tr[8]/td[5]/div")).Text);
            fw.ConsoleReport(" Initial Column A Count Now --> " + GlobalRef.InitialColumnAcount);
            //Browser.SwitchToChildWindow().Close();
            //tmsWait.Hard(1);
            // Browser.SwitchToParentWindow();
        }

        [Then(@"Quarterly Disenrollment Compliance Report Total Count is noted for Column C")]
      
        public void ThenQuarterlyDisenrollmentComplianceReportTotalCountIsNotedForColumnC()
        {
            GlobalRef.InitialColumnCcount= Int32.Parse(Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='8']//tr[8]/td[7]/div")).Text);
            fw.ConsoleReport(" Column C Count Now --> " + GlobalRef.InitialColumnCcount);
            Browser.SwitchToChildWindow().Close();
            tmsWait.Hard(1);
            Browser.SwitchToParentWindow();

        }

        [Then(@"Quarterly Disenrollment Compliance Report Total Count is noted for Column C is increased")]
        public void ThenQuarterlyDisenrollmentComplianceReportTotalCountIsNotedForColumnCIsIncreased()
        {
            tmsWait.Hard(1);
            GlobalRef.FinalColumnCcount = Int32.Parse(Browser.Wd.FindElement(By.XPath("//div[@dir='LTR']//table[@cols='8']//tr[8]/td[5]/div")).Text);

            fw.ConsoleReport(" Final Column C Count Now --> " + GlobalRef.FinalColumnCcount);

            int initC = Convert.ToInt32(GlobalRef.InitialColumnCcount);
            int finalC = Convert.ToInt32(GlobalRef.FinalColumnCcount);

            bool resultsC = (initC < finalC);

            Assert.IsTrue(resultsC, " Coumn C value is not increased");

            Browser.SwitchToChildWindow().Close();
            tmsWait.Hard(1);
            Browser.SwitchToParentWindow();
        }

        [Given(@"Quarterly Disenrollment Compliance Run Report button is clicked successfully")]
        [When(@"Quarterly Disenrollment Compliance Run Report button is clicked successfully")]
        [Then(@"Quarterly Disenrollment Compliance Run Report button is clicked successfully")]
        public void GivenQuarterlyDisenrollmentComplianceRunReportButtonIsClickedSuccessfully()
        {
            fw.ExecuteJavascript(EAM.DisenrollmentComplianceReport.RunReportButton);
            tmsWait.Hard(10);

            Browser.SwitchToChildWindow();
            Browser.SwitchToIFrame();

        }



        [Then(@"Verify the count for Element D is ""(.*)"" by (.*)")]
        [Then(@"Verify the count for Element D is ""(.*)"" for ""(.*)""")]
        [Then(@"Verify the count for Element ""(.*)"" is ""(.*)"" for ""(.*)""")]
        public void ThenVerifyTheCountForElementIsFor(string element, string change, string TC)
        {

            bool differ =false;
            bool nochange = false;
            string newcountstr = "";
            string text="";

           if(element.ToUpper().Equals("D"))  newcountstr = DisenrlTotatCountElementD();
            if (element.ToUpper().Equals("A")) newcountstr = DisenrlTotatCountElementA();
            if (element.ToUpper().Equals("B")) newcountstr = DisenrlTotatCountElementB();
            if (element.ToUpper().Equals("C")) newcountstr = DisenrlTotatCountElementC();
            int newcount = Int32.Parse(newcountstr);
            Console.WriteLine("NewCount "+newcount);
            //string text = System.IO.File.ReadAllText(@"D:\WriteLines2.txt");
           
            if(TC.ToUpper().Equals("TC2")) text = GlobalRef.InitialreportCount.ToString();
            else text = GlobalRef.OldreportCount.ToString();
            GlobalRef.OldreportCount = Int32.Parse(newcountstr);
            int oldcount = Int32.Parse(text);
            Console.WriteLine("OldCount " + oldcount);
            int diff = newcount - oldcount;
            if (diff == 1)  differ = true;
            if (diff == -1) differ = true;
            if (diff == 0) nochange = true;
            
            if (change.Trim().ToLower().Equals("increased")) Assert.IsTrue(differ, "Count is not increased by 1");
            if(change.Trim().ToLower().Equals("decreased")) Assert.IsTrue(differ, "Count is decreased by 1");           
            if (change.Trim().ToLower().Equals("not increased")) Assert.IsTrue(nochange, "there is a change in count");
            CloseReport();
        }



        [Then(@"Verify the count for Element ""(.*)"" and ""(.*)"" is ""(.*)"" by ""(.*)""")]
        public void ThenVerifyTheCountForElementAndIsBy(string element, string element1, string TC, int P0)
        {
         


        bool differ = false;
            bool nochange = false;
            string newcountstr = "";
            string text = "";
            string newcountstr1 = "";
            string text1 = "";
            bool differ1 = false;
            bool nochange1 = false;
            newcountstr = DisenrlTotatCountElementA();
         newcountstr1= DisenrlTotatCountElementB();
            
            int newcountA = Int32.Parse(newcountstr);
            Console.WriteLine("NewCount " + newcountA);
            int newcountB = Int32.Parse(newcountstr1);
            Console.WriteLine("NewCount A" + newcountA);
            Console.WriteLine("NewCount " + newcountB);
            //string text = System.IO.File.ReadAllText(@"D:\WriteLines2.txt");

            text = GlobalRef.InitialreportCountA.ToString();
            text1 = GlobalRef.InitialreportCountB.ToString();
            int oldcountA = Int32.Parse(text);
            int oldcountB = Int32.Parse(text1);
            Console.WriteLine("OldCount " + oldcountB);

            int diff = newcountA - oldcountA;
            int diff1 = newcountB - oldcountB;
            if (diff == 1) differ = true;
            if (diff == -1) differ = true;
            if (diff == 0) nochange = true;
            if (diff1 == 1) differ1 = true;
            if (diff1== -1) differ1 = true;
            if (diff1 == 0) nochange1 = true;
            Assert.IsTrue(differ, "ACount is not increased by 1");
             Assert.IsTrue(differ, "ACount is increased by 1");
         Assert.IsTrue(nochange, "Athere is a change in count");

            Assert.IsTrue(differ1, "BCount is not increased by 1");
            Assert.IsTrue(differ1, "BCount is increased by 1");
            Assert.IsTrue(nochange1, "B there is a change in count");
            CloseReport();
        }

    }
}




