﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1
{

    [Binding]
    public class Reports
    {
        public By CurentPageBy { get { return By.ClassName("PageNumberText"); } }
        public By ReportMainViewBy  {get {return By.Id("ReportViewerControl_fixedTable");}}
        public By DenialReportTable { get { return By.Id("myReportTableID"); } }

        public By ReportNextPageLink { get { return By.XPath("//input[@title='Next Page'][1]"); } }
        public By ReportPreviousPageLink { get { return By.XPath("//input[@title='Previous Page'][1]"); } }
        public By ReportLastPageLink { get { return By.XPath("//input[@title='Next Page'][1]"); } }
        public By ReportFirstPageLink { get { return By.XPath("//input[@title='First Page'][1]"); } }
        public By ReportTotalPages { get { return By.Id("ReportViewerControl_ctl06_ctl00_TotalPages"); } }
        public By enrollmentLetterPDF { get { return By.XPath("//div[contains(@id,'pageContainer')]/div[@class='textLayer']/div"); } }
         public IWebElement enrollmentLetterPDFNext { get { return Browser.Wd.FindElement(By.XPath("//button[@id='next']")); } }
        public IWebElement enrollmentLetterPDFPageNumber { get { return Browser.Wd.FindElement(By.XPath("//input[@id='pageNumber']")); } }

        public IWebElement HTMLTextArea { get { return Browser.Wd.FindElement(By.Id("TMSTextArea")); } }
        public IWebElement ReportsTable { get { return Browser.Wd.FindElement(By.Id("ReportViewerControl_fixedTable")); } }
        public By TotalRecord { get { return By.XPath("//div[@class='A2a51906d6e5d402b806901c2049b7db9144']"); } }

    }

    [Binding]
    public class CMSResponseCodeLevelDetailReport : Reports
    {
        
        public IWebElement TRRStartDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='TRRStartDate']")); } }
        public IWebElement TRREndDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='TRREndDate']")); } }
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PlanID']")); } }
        public IWebElement PBPID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PBPID']")); } }
        public IWebElement TRRCodesTable { get { return Browser.Wd.FindElement(By.XPath("//table[contains(@id, 'dgTrrCodes')]")); } }
        public IWebElement TRRCodesResponseTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dgTrrCodes")); } }
        public string TRRCodeLinkIDPart { get { return "_lnkTRRCode"; } }
        public IWebElement TRRReponseReportTable { get { return Browser.Wd.FindElement(By.Id("ReportViewerControl_fixedTable")); } }
    }

    [Binding]
    public class DisenrollmentComplianceReport :Reports
    {
        public IWebElement PlanIDDropdown { get {   return Browser.Wd.FindElement(By.CssSelector("[test-id='PlanId']")); } }
        public IWebElement YearDropdown { get { return Browser.Wd.FindElement(By.XPath("//select[@test-id='Year']")); } }
        public IWebElement QuarterDropdown { get { return Browser.Wd.FindElement(By.XPath("//multiselect[@test-id='Quarters']//button")); } }
        public IWebElement RunReportButton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='report-btn-runReport']")); } }
        public IWebElement ReportsLink { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_EamNavigation_uiModReportsHyperLink")); } }

        
    }
    [Binding]
    public class EnrollmentComplianceReport : Reports
    {
        public IWebElement EnrollemntLink { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_EamNavigation_hlEnrollment")); } }
        public IWebElement PlanIDDropdown { get { return Browser.Wd.FindElement(By.XPath("//multiselect[@test-id='PlanId']//button")); } }
        public IWebElement AngularPlanIDDropdown { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='PlanId']//div")); } }
        public IWebElement YearDropdown { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Year']")); } }
        public IWebElement QuarterDropdown { get { return Browser.Wd.FindElement(By.XPath("//multiselect[@test-id='Quarters']//button")); } }
        public IWebElement RunReportButton { get { return Browser.Wd.FindElement(By.Id("reportGen")); } }

    }

    [Binding]
    public class NoRxFalloutReport  : Reports
    {
        public IWebElement EnrollemntLink { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_EamNavigation_lnkNoRxFallout")); } }

        public IWebElement PlanIDDropdown { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PLAN_ID']")); } }
        public IWebElement YearDropdown { get { return Browser.Wd.FindElement(By.Id("ctl00_MainMasterContent_Year")); } }
        public IWebElement QuarterDropdown { get { return Browser.Wd.FindElement(By.Id("ctl00_MainMasterContent_Quarters")); } }
        public IWebElement RunReportButton { get { return Browser.Wd.FindElement(By.Id("reportGen")); } }

    }

    [Binding]
    public class DisenrollmentComplianceReportElement : Reports
    {
        public IWebElement ReportPage {get{return Browser.Wd.FindElement(By.Id("VisibleReportContentReportViewerControl_ctl09"));} }
        
    }
        [Binding]
    public class EnrollmentComplianceReportElement : Reports
    {
        public IWebElement EnrlReportHeader{ get { return Browser.Wd.FindElement(By.Id("ReportViewerControl_ReportViewer")); } }
        public IWebElement ReportPage { get { return Browser.Wd.FindElement(By.Id("VisibleReportContentReportViewerControl_ctl09")); } }
        public IWebElement ElementAFirstQrtr { get { return Browser.Wd.FindElement(By.XPath(".//a[@tabindex='1']/parent::node()")); } }
        public IWebElement ElementBFirstQrtr { get { return Browser.Wd.FindElement(By.XPath(".//a[@tabindex='2']/parent::node()")); } }
        public IWebElement ElementASecondQrtr { get { return Browser.Wd.FindElement(By.XPath(".//a[@tabindex='3']/parent::node()")); } }
        public IWebElement ElementBSecondQrtr { get { return Browser.Wd.FindElement(By.XPath(".//a[@tabindex='4']/parent::node()")); } }
        public IWebElement ElementAThirdQrtr { get { return Browser.Wd.FindElement(By.XPath(".//a[@tabindex='5']/parent::node()")); } }
        public IWebElement ElementBThirdQrtr { get { return Browser.Wd.FindElement(By.XPath(".//a[@tabindex='6']/parent::node()")); } }
        public IWebElement ElementAForthQrtr { get { return Browser.Wd.FindElement(By.XPath(".//a[@tabindex='7']/parent::node()")); } }
        public IWebElement ElementBForthQrtr { get { return Browser.Wd.FindElement(By.XPath(".//a[@tabindex='8']/parent::node()")); } }

        public IWebElement ElementCFirstQrtr { get { return Browser.Wd.FindElement(By.XPath(".//a[@tabindex='9']/parent::node()")); } }
        public IWebElement ElementDFirstQrtr { get { return Browser.Wd.FindElement(By.XPath(".//a[@tabindex='10']/parent::node()")); } }
        public IWebElement ElementCSecondQrtr { get { return Browser.Wd.FindElement(By.XPath(".//a[@tabindex='11']/parent::node()")); } }
        public IWebElement ElementDSecondQrtr { get { return Browser.Wd.FindElement(By.XPath(".//a[@tabindex='12']/parent::node()")); } }
        public IWebElement ElementCThirdQrtr { get { return Browser.Wd.FindElement(By.XPath(".//a[@tabindex='13']/parent::node()")); } }
        public IWebElement ElementDThirdQrtr { get { return Browser.Wd.FindElement(By.XPath(".//a[@tabindex='14']/parent::node()")); } }
        public IWebElement ElementCForthQrtr { get { return Browser.Wd.FindElement(By.XPath(".//a[@tabindex='15']/parent::node()")); } }
        public IWebElement ElementDForthQrtr { get { return Browser.Wd.FindElement(By.XPath(".//a[@tabindex='16']/parent::node()")); } }

        public IWebElement ElementEFirstQrtr { get { return Browser.Wd.FindElement(By.XPath(".//a[@tabindex='17']/parent::node()")); } }
        public IWebElement ElementFFirstQrtr { get { return Browser.Wd.FindElement(By.XPath(".//a[@tabindex='18']/parent::node()")); } }
        public IWebElement ElementESecondQrtr { get { return Browser.Wd.FindElement(By.XPath(".//a[@tabindex='19']/parent::node()")); } }
        public IWebElement ElementFSecondQrtr { get { return Browser.Wd.FindElement(By.XPath(".//a[@tabindex='20']/parent::node()")); } }
        public IWebElement ElementEThirdQrtr { get { return Browser.Wd.FindElement(By.XPath(".//a[@tabindex='21']/parent::node()")); } }
        public IWebElement ElementFThirdQrtr { get { return Browser.Wd.FindElement(By.XPath(".//a[@tabindex='22']/parent::node()")); } }
        public IWebElement ElementEForthQrtr { get { return Browser.Wd.FindElement(By.XPath(".//a[@tabindex='23']/parent::node()")); } }
        public IWebElement ElementFForthQrtr { get { return Browser.Wd.FindElement(By.XPath(".//a[@tabindex='24']/parent::node()")); } }
    }

    [Binding]
    public class MemberReportMembersTRRHistory :Reports
    {
        public IWebElement HIC { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Hic']")); } }
        public IWebElement RunReportButton { get { return Browser.Wd.FindElement(By.XPath("//input[contains(@id, 'reportGen')]")); } }

    }

    [Binding]
    public class CMSResponseTRRDetailReport :Reports
    {
        public IWebElement TRRDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='TRRMONTH']")); } }
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PlanID']")); } }
        public IWebElement TRRType { get { return Browser.Wd.FindElement(By.XPath("//*[contains(@id, 'TRR_Type')]")); } }
        public IWebElement PBPID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PBPID']")); } }
        public IWebElement Processed { get { return Browser.Wd.FindElement(By.XPath("//*[contains(@id, 'LoadResult')]")); } }
        public IWebElement RunReport { get { return Browser.Wd.FindElement(By.Id("reportGen")); } }

    }

    [Binding]
    public class CMSResponseTRRSummaryReport :Reports
    {
        public IWebElement TRRDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='TRR_MONTH']")); } }
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PLAN_ID']")); } }
        public IWebElement TRRType { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='TRR_Type']")); } }
        public IWebElement PBPID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PBPID']")); } }
        public IWebElement Processed { get { return Browser.Wd.FindElement(By.XPath("//*[contains(@id, 'LoadResult')]")); } }
        public IWebElement RunReport { get { return Browser.Wd.FindElement(By.Id("reportGen")); } }

    }

    [Binding]
    public class CMSResponseRecordsDupedOutFromTRRReport: Reports
    {
        public IWebElement TRRDate { get { return Browser.Wd.FindElement(By.XPath("//*[contains(@id, 'TRR_MONTH')]")); } }
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.XPath("//*[contains(@id, 'PLAN_ID')]")); } }
        public IWebElement TRRType { get { return Browser.Wd.FindElement(By.XPath("//*[contains(@id, 'TRR_Type')]")); } }
        public IWebElement PBPID { get { return Browser.Wd.FindElement(By.XPath("//*[contains(@id, 'PBPID')]")); } }
        public IWebElement RunReport { get { return Browser.Wd.FindElement(By.Id("reportGen")); } }

    }

    [Binding]
    public class AdministrationJobsPage
    {
        public IWebElement JobsGrid { get { return Browser.Wd.FindElement(By.Id("JobsGridView2")); } }
        public IWebElement JobsPageManage { get { return Browser.Wd.FindElement(By.Id("manageStartUpButton")); } }
        public IWebElement ManageJobsTable { get { return Browser.Wd.FindElement(By.Id("manageStartUpJobsControl_startUpJobs_ctl00")); } }
        public IWebElement DisableBtn { get { return Browser.Wd.FindElement(By.Id("txtDelete")); } }
        public IWebElement PendingBtn { get { return Browser.Wd.FindElement(By.Id("txtPending")); } }
        public IWebElement FilterStatus { get { return Browser.Wd.FindElement(By.Id("RunFlagDropDownList")); } }
        public IWebElement Span1TxtMsg { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='Span1']"));} }
     
    }

    [Binding]
    public class AdministrationPage
    {
        public IWebElement ModifyApplicationDatabase { get { return Browser.Wd.FindElement(By.Id("DetailsView1")); } }
        public IWebElement EnhanceMemberDupeCheck { get { return Browser.Wd.FindElement(By.Id("IsMemberDupe")); } }
        public IWebElement EGHP { get { return Browser.Wd.FindElement(By.Id("IsEGHP")); } }
        public IWebElement DbPassword { get { return Browser.Wd.FindElement(By.Id("EditDatabasePasswordTextBox")); } }
        public IWebElement ERFDBPassword { get { return Browser.Wd.FindElement(By.Id("ERFDBPassword")); } }
        public IWebElement AddAnApplicationLink { get { return Browser.Wd.FindElement(By.Id("A1")); } }
        public IWebElement AddANewDatabaseLink { get { return Browser.Wd.FindElement(By.Id("btn5")); } }
        public IWebElement ApplicationDropdown { get { return Browser.Wd.FindElement(By.Id("ApplicationDropDown")); } }
        public IWebElement DatabaseName { get { return Browser.Wd.FindElement(By.Id("DatabaseName")); } }
        public IWebElement DatabaseServer { get { return Browser.Wd.FindElement(By.Id("DatabaseServer")); } }
        public IWebElement Authentication { get { return Browser.Wd.FindElement(By.Id("ddlAuthenticationNew")); } }
        public IWebElement DatabaseUser { get { return Browser.Wd.FindElement(By.Id("DatabaseUser")); } }
        public IWebElement DatabasePassword { get { return Browser.Wd.FindElement(By.Id("DatabasePassword")); } }
        public IWebElement InputFolder { get { return Browser.Wd.FindElement(By.Id("InputFolder")); } }
        public IWebElement OutputFolder { get { return Browser.Wd.FindElement(By.Id("OutputFolder")); } }
        public IWebElement AttachmentFolder { get { return Browser.Wd.FindElement(By.Id("AttachmentFolder")); } }
        public IWebElement LetterFolder { get { return Browser.Wd.FindElement(By.Id("LetterFolder")); } }
        public IWebElement TCSProcessService { get { return Browser.Wd.FindElement(By.Id("TCSProcSvc")); } }
        public IWebElement EnableTCSCheckbox { get { return Browser.Wd.FindElement(By.Id("IsTcsEnable")); } }
        public IWebElement TCSConfigurationName { get { return Browser.Wd.FindElement(By.Id("TcsConfiguration")); } }
        public IWebElement TCSInquiryService { get { return Browser.Wd.FindElement(By.Id("TCSInqSvc")); } }
        public IWebElement TCSAdministrationService { get { return Browser.Wd.FindElement(By.Id("TCSAdminSvc")); } }
        public IWebElement EnrollmentRequestForm { get { return Browser.Wd.FindElement(By.Id("EnrollmentRequestForm")); } }
        public IWebElement ERFDatabaseName { get { return Browser.Wd.FindElement(By.Id("ERFDBName")); } }
        public IWebElement ERFDatabaseServer { get { return Browser.Wd.FindElement(By.Id("ERFDBServer")); } }
        public IWebElement ERFDatabaseUser { get { return Browser.Wd.FindElement(By.Id("ERFDBUser")); } }
        public IWebElement ERFDatabasePassword { get { return Browser.Wd.FindElement(By.Id("ERFDBPassword")); } }
        public IWebElement AddDatabase { get { return Browser.Wd.FindElement(By.Id("addDatabaseOK")); } }
        public IWebElement AssignApplication { get { return Browser.Wd.FindElement(By.Id("Button4")); } }
        public IWebElement UpdateDatabase { get { return Browser.Wd.FindElement(By.Id("Button1")); } }
        public IWebElement NextButton { get { return Browser.Wd.FindElement(By.Id("btn3")); } }
        //public IWebElement UpdateDatabase { get { return Browser.Wd.FindElement(By.ClassName("smallButton"));}}
        public IWebElement JobsGridView { get { return Browser.Wd.FindElement(By.Id("JobsGridView2")); } }
        public IWebElement ModifyPlanOrEditInfo { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dgPlan")); } }
        public IWebElement ReceiptDateValidation { get { return Browser.Wd.FindElement(By.Id("IsReceiptDateValid")); } }
        public IWebElement SignatureDateValidation { get { return Browser.Wd.FindElement(By.Id("IsSignatureDateValid")); } }
        public IWebElement ElectionTypeValidation { get { return Browser.Wd.FindElement(By.Id("IsElectionType")); } }
        public IWebElement ClientDetails { get { return Browser.Wd.FindElement(By.Id("Customer_GridView")); } }
        public IWebElement PlanChangePreCMS { get { return Browser.Wd.FindElement(By.Id("PLAN_CHANGE_PRE_CMS")); } }
        public IWebElement PlanChangePostCMS { get { return Browser.Wd.FindElement(By.Id("PLAN_CHANGE_POST_CMS")); } }
        public IWebElement WorkFlowEnable { get { return Browser.Wd.FindElement(By.Id("IsWorkloadEnable")); } }
        public IWebElement WorkFlowConfigurationName { get { return Browser.Wd.FindElement(By.Id("WorkloadConfiguration")); } }
        public IWebElement NotesActionCheck { get { return Browser.Wd.FindElement(By.Id("NOTES_ACTIONS_SHOW_ACTIONS")); } }
        public IWebElement FacetsIntegrationCheckbox { get { return Browser.Wd.FindElement(By.Id("FacetsIntegration")); } }
        public IWebElement EnableMemberLookupCheckbox { get { return Browser.Wd.FindElement(By.Id("EnableMemberLookup")); } }
        public IWebElement EnableExportSpanCheckbox { get { return Browser.Wd.FindElement(By.Id("EnableSpanExport")); } }
        public IWebElement FacetEndPointtextbox { get { return Browser.Wd.FindElement(By.Id("FacetsService")); } }
        public IWebElement IdentityTextbox { get { return Browser.Wd.FindElement(By.Id("FacetsIdentity")); } }
        public IWebElement RegionTextbox { get { return Browser.Wd.FindElement(By.Id("FacetsRegion")); } }
        public IWebElement CallingSystemNameTextbox { get { return Browser.Wd.FindElement(By.Id("CallingSystemName")); } }
        public IWebElement DatabasePlatformDropdown { get { return Browser.Wd.FindElement(By.Id("FacetsDatabaseProvider")); } }
        public IWebElement ServerTextbox { get { return Browser.Wd.FindElement(By.Id("FacetsServer")); } }
        public IWebElement DBTextbox { get { return Browser.Wd.FindElement(By.Id("FacetsDB")); } }
        public IWebElement DBUserTextbox { get { return Browser.Wd.FindElement(By.Id("FacetsSpansDBUser")); } }
        public IWebElement DBPasswordTextbox { get { return Browser.Wd.FindElement(By.Id("FacetsSpansDBPassword")); } }
        public IWebElement UserWarningMessageTextbox { get { return Browser.Wd.FindElement(By.Id("UserWarningMessage")); } }
        public IWebElement WarningMessageTermDropdown { get { return Browser.Wd.FindElement(By.Id("WarningMessageTermDate")); } }
        public IWebElement HOSPESRDTermDateDropdown{ get { return Browser.Wd.FindElement(By.Id("AppParamsTitleTable40")); } }
        public IWebElement AddClientLink { get { return Browser.Wd.FindElement(By.LinkText("Click to Add a Client")); } }
        public IWebElement ClientName { get { return Browser.Wd.FindElement(By.Id("customerName")); } }
        public IWebElement AddClient { get { return Browser.Wd.FindElement(By.Id("insertCustomer")); } }
        public IWebElement ClientTable { get { return Browser.Wd.FindElement(By.Id("Customer_GridView"));  } }
        public IWebElement UsersGridView { get { return Browser.Wd.FindElement(By.Id("UsersGridView"));  } }
        public IWebElement ErrorLogin { get { return Browser.Wd.FindElement(By.Id("lcLogin_lblMsg")); } }        
    }

    [Binding]
    public class Recalculations
    {
        public IWebElement YearlyPremiumRecalculateButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='recalculations-btn-recalculateYearly']")); } }
        public IWebElement MonthlyPremiumRecalculateButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='recalculations-btn-recalculateMonthly']")); } }
        public IWebElement ForceReRunJobCheckBox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_forceEnableLisOpenEndedJob")); } }
        public IWebElement ForceReRunJoButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='recalculations-checkbox-chkForceRereun']")); } }
        public IWebElement Plan10 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='recalculations-txt-plan10']")); } }
        public IWebElement JobIdUpdateMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblMessage")); } }
        public IWebElement ProcessInProgress { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblMsg")); } }
        public IWebElement MonthlyJobRunOn { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_LabelText")); } }
    }

    [Binding]
    public class ViewBidData
    {

        public IWebElement GoButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucViewBidData_btnGo")); } }
        public IWebElement ResetButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucViewBidData_btnReset")); } }
        public IWebElement Year { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucViewBidData_ddlYear")); } }
        public IWebElement PlanId  { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucViewBidData_ddlPlan")); } }
        public IWebElement PBPId  { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucViewBidData_ddlPbp")); } }                                                                                
        public IWebElement SegmentId  { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucViewBidData_ddlSegment")); } }
        public IWebElement ResultsCount { get { return Browser.Wd.FindElement(By.XPath("//div[@class = 'rgWrap rgInfoPart']/strong[3]")); } }
        public IWebElement BidDataTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucViewBidData_grdBidData_GridData")); } }
        public IWebElement LastPage { get { return Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")); } }
        public IWebElement LastPageText { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucViewBidData_grdBidData_ctl00_ctl03_ctl01_GoToPageTextBox")); } }
        public IWebElement PagerTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucViewBidData_grdBidData_ctl00_Pager")); } }
        public IWebElement InfoButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucViewBidData_grdBidData_ctl00_ctl08_gbcInfo")); } }
        public IWebElement ViewBidDataTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucViewBidData_grdBidData_ctl00")); } }
        
    }

    [Binding]
    public class EditPLanInfo
    {
        public IWebElement PBPType { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPBPType")); } }
        public IWebElement EditPlanInfoTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dgPlan")); } }
        public IWebElement EditPlanInfoSave { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSave")); } }
        public IWebElement EditPlanInfoReset { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnCancel")); } }
        public IWebElement EditPlanEndDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtEndDate")); } }
        public IWebElement EditPlanEffectiveDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtEffDate")); } }
        public IWebElement PlanModifiedMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblMsg")); } }
        public IWebElement MMPState { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlMMPStates")); } }
        public IWebElement MedicareProductName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtProductName")); } }
        public IWebElement Department { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtDepartment")); } }
        public IWebElement HoursOfOperation { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtHoursOperation")); } }
        public IWebElement PremC { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtPremC")); } }
        public IWebElement PremD { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtPremD")); } }
        public IWebElement Deductible { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtDeduct")); } }
        public IWebElement Address1 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtAddress1")); } }        
        public IWebElement City { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtCity")); } }
        public IWebElement State { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtST")); } }
        public IWebElement ZIP { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtZip")); } }
        public IWebElement RxID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtRxID")); } }
        public IWebElement RxGroup { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtRxGroup")); } }
        public IWebElement EditMMPRuleConfirmation { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_confirmationDialog_acceptButton")); } }
        

    }

    [Binding]
    public class ReportsEnrollmentOECEAFFallout
    {
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.Id("ctl00_MainMasterContent_PlanID")); } }
        public IWebElement StartDate { get { return Browser.Wd.FindElement(By.Id("ctl00_MainMasterContent_StartDate")); } }
        public IWebElement EndDate { get { return Browser.Wd.FindElement(By.Id("ctl00_MainMasterContent_EndDate")); } }
        public IWebElement FileType { get { return Browser.Wd.FindElement(By.Id("ctl00_MainMasterContent_FileType")); } }
        public IWebElement FileName { get { return Browser.Wd.FindElement(By.Id("ctl00_MainMasterContent_FileName")); } }
        public IWebElement RunReport { get { return Browser.Wd.FindElement(By.Id("reportGen")); } }
        public By OECEAFFalloutTable { get { return By.Id("VisibleReportContentReportViewerControl_ctl09"); } }

    }



    [Binding]
    public class ReportsDeemedLISDetailReport
    {
        public IWebElement FileRunDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='LIS_DATE']")); } }
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PLAN_ID']")); } }
        public IWebElement PBPID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='PBP_ID']")); } }
        public IWebElement RunReport { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='report-btn-runReport']")); } }



    }


    [Binding]
    public class ReportsTransMissingCMSData
    {
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.Id("ctl00_MainMasterContent_Planid")); } }   
        public IWebElement RunReport { get { return Browser.Wd.FindElement(By.Id("reportGen")); } }
        public IWebElement FileName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='file_name']")); } }
        public IWebElement FileNameAngular { get { return Browser.Wd.FindElement(By.CssSelector("/label[contains(.,'File Name/Source')]/parent::div//span[@class='k-select']")); } }
    }


    [Binding]
    public static class ReportsCMSResponseAutomatedSpans
    {
        public static IWebElement TRRDataDropdown { get { return Browser.Wd.FindElement(By.Id("ctl00_MainMasterContent_TRR_MONTH")); } }
        public static IWebElement PlanIDDropdown { get { return Browser.Wd.FindElement(By.Id("ctl00_MainMasterContent_PLAN_ID")); } }
        public static IWebElement ActionsDropdown { get { return Browser.Wd.FindElement(By.Id("ctl00_MainMasterContent_Status")); } }
        public static IWebElement RunReportButton { get { return Browser.Wd.FindElement(By.Id("reportGen")); } }
    }


}