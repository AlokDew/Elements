﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.Globalization;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

using TMSoR1.FrameworkCode;

namespace TMSoR1.Features.EAMfeatures
{
    [Binding]
    public class fsSNPUISteps
    {
        [Then(@"View Edit Members page ViewSNP is clicked")]
        public void ThenViewEditMembersPageViewSNPIsClicked()
        {
            IWebElement viewSNPBtn = Browser.Wd.FindElement(By.Id("btnViewSnp"));
            viewSNPBtn.Click();
            tmsWait.Hard(3);
        }
        [Then(@"View Special Need Plan AddSNPSuspect is clicked")]
        public void ThenViewSpecialNeedPlanAddSNPSuspectisclicked()
        {
            IWebElement AddSNPBtn = Browser.Wd.FindElement(By.Id("btnAddSuspect"));
            AddSNPBtn.Click();
            tmsWait.Hard(3);
        }



        [When(@"Check Special Need Plan ""(.*)"" screen is present")]
        public void WhenCheckSpecialNeedPlanScreenIsPresent(string p0)
        {

            String actualValue;
            String expectedValue = tmsCommon.GenerateData(p0);
            By Drp = By.XPath("//label[@test-id='snp-lbl-snpVerificationProcess']");
            actualValue = Browser.Wd.FindElement(Drp).Text;
            Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");
        }



        [When(@"Check Special Need Plan BackToMemberInfo is clicked")]
        public void WhenCheckSpecialNeedPlanBackToMemberInfoIsClicked()
        {
            By BackToMemberInfoBtn = By.XPath("//span[@test-id='snp-span-back']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(BackToMemberInfoBtn);
            tmsWait.Hard(3);
        }

        [When(@"Check Special Need Plan BacktoMemberSearch is clicked")]
        public void WhenCheckSpecialNeedPlanBacktoMemberSearchIsClicked()
        {
            By BacktoMemberSearch = By.XPath("//span[@test-id='memberSearch-span-title']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(BacktoMemberSearch);
            tmsWait.Hard(3);
        }

        [When(@"RESET is clicked")]
        public void WhenRESETIsClicked()
        {
            By resetsearch = By.XPath("//button[@id='btnReset']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(resetsearch);
            tmsWait.Hard(3);
        }


        [Then(@"verify ""(.*)"" screen is displayed")]
        public void ThenVerifyScreenIsDisplayed(string p1)
        {
            string expectedValue = tmsCommon.GenerateData(p1);
            string actualValue;
            By Member = By.XPath("//div[contains(text(),'View/Edit Member')]");
            actualValue = Browser.Wd.FindElement(Member).Text;
            Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");
        }

        [Then(@"Verify control ""(.*)"" is present")]
        public void ThenVerifyControlIsPresent(string p0)
        {
            String actualValue;
            String expectedValue = tmsCommon.GenerateData(p0);
            By Drp = By.XPath("//label[@test-id='snp-lbl-suspectStatus']");
            actualValue = Browser.Wd.FindElement(Drp).Text;
            Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");
        }

        [Then(@"control ""(.*)"" is present")]
        public void ThenControlIsPresent(string p1)
        {
            String expectedValue = tmsCommon.GenerateData(p1);
            switch (expectedValue)
            {
                case "Source Of Verification":
                    ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfSNPUIMOD.View_Special_Need_Plan.snp_lbl_sourceOfVerification);
                    break;
                case "Verification Result":
                    ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfSNPUIMOD.View_Special_Need_Plan.snp_lbl_verificationResult);
                    break;
                case "Months Of Eligiblity":
                    ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfSNPUIMOD.View_Special_Need_Plan.snp_lbl_monthsOfEligibility);
                    break;
                case "End Date Of Grace Period":
                    ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfSNPUIMOD.View_Special_Need_Plan.snp_lbl_endDateGracePeriod);
                    break;
                case "SNP Status":
                    ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfSNPUIMOD.View_Special_Need_Plan.snp_lbl_snpStatus);
                    break;
                case "Follow Up Method":
                    ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfSNPUIMOD.View_Special_Need_Plan.snp_lbl_followUpMethod);
                    break;
                case "Follow Up Date":
                    ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfSNPUIMOD.View_Special_Need_Plan.snp_lbl_followUpDate);
                    break;
                case "User Modified":
                    ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfSNPUIMOD.View_Special_Need_Plan.snp_lbl_userModified);
                    break;
                case "Date Modified":
                    ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfSNPUIMOD.View_Special_Need_Plan.snp_lbl_datemodified);
                    break;
            }
        }


        [Then(@"verify button ""(.*)"" is displayed")]
        public void ThenVerifyButtonIsDisplayed(string p0)
        {
            String expectedValue = tmsCommon.GenerateData(p0);
            switch (expectedValue)
            {

                case "VIEW NOTES AND ACTIONS":
                    //fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODMemDemographics.UIMODEffectiveDate);
                    ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfSNPUIMOD.View_Special_Need_Plan.VIEW_NOTES_AND_ACTIONS);
                    break;
                case "View OOA":
                    ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfSNPUIMOD.View_Special_Need_Plan.VIEW_OOA);
                    break;
                case "View Attachments":
                    ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfSNPUIMOD.View_Special_Need_Plan.VIEW_ATTACHMENTS);
                    break;
                case "Audit HISTORY":
                    ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfSNPUIMOD.View_Special_Need_Plan.AUDIT_HISTORY);
                    break;
                case "View SNP":
                    ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfSNPUIMOD.View_Special_Need_Plan.VIEW_SNP);
                    break;

            }
        }


        [Then(@"verify button VIEW SNP is NOT displayed")]
        public void ThenVerifyButtonVIEWSNPIsNOTDisplayed()
        {
            //UIMODUtilFunctions.elementisNotPresentUsingWebElement(cfSNPUIMOD.View_Special_Need_Plan.VIEW_SNP);

            UIMODUtilFunctions.elementNotPresenceUsingLocators(cfUIMODMemberCreation.UIMODMemberCreation.ViewSNPIconLoc);


            fw.ConsoleReport("View SNP is NOT present");
        }




        [Then(@"checkbox ""(.*)"" is present")]
        public void ThenCheckboxIsPresent(string p0)
        {
            By loc = By.XPath("//Input[@test-id='snp-chk-queueLossOfSnp']");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
            Console.WriteLine("Queue Loss of SNP Letter (check box) is present - " + loc);
        }

        [Then(@"textbox""(.*)"" is present")]
        public void ThenTextboxIsPresent(string p0)
        {
            String actualValue;
            String expectedValue = tmsCommon.GenerateData(p0);
            By Drp8 = By.XPath("//label[@test-id='snp-lbl-snosnpNotestes']");
            actualValue = Browser.Wd.FindElement(Drp8).Text;
            Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");
        }

        [Then(@"button ""(.*)"" is present")]
        public void ThenButtonIsPresent(string p2)
        {
            String expectedValue = tmsCommon.GenerateData(p2);
            switch (expectedValue)
            {
                case "SAVE":
                    ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfSNPUIMOD.View_Special_Need_Plan.snp_button_save);
                    break;
                case "CLOSE":
                    ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfSNPUIMOD.View_Special_Need_Plan.snp_button_cancel);
                    break;
            }

        }

        [Then(@"Variable ""(.*)"" is set to ""(.*)""")]

        public void ThenVariableIsSetTo(string p0, string p1)
        {

            String GeneratedUserID = tmsCommon.GenerateData(p1);
            fw.setVariable(p0, GeneratedUserID);
            if (p0.Equals("SourceOfVerification"))
            {

                //ScenarioContext.Current["Source Of Verification"] = GeneratedUserID;
                GlobalRef.SourceOfVerification = GeneratedUserID;

            }
            if (p0.Equals("VerificationResult"))
            {

                //ScenarioContext.Current["Verification Result"] = GeneratedUserID;
                GlobalRef.VerificationResult = GeneratedUserID;

            }
            if (p0.Equals("Notes"))
            {

                //ScenarioContext.Current["Notes"] = GeneratedUserID;
                GlobalRef.Notes = GeneratedUserID;

            }

            if (p0.Equals("SNP Status"))
            {

                //ScenarioContext.Current["Notes"] = GeneratedUserID;
                GlobalRef.SNPStatus = GeneratedUserID;

            }
        }

        [When(@"Variable ""(.*)"" is set to ""(.*)""")]
        public void WhenVariableIsSetTo(string p0, string p1)
        {
            String GeneratedUserID = tmsCommon.GenerateData(p1);
            fw.setVariable(p0, GeneratedUserID);
            if (p0.Equals("VerificationResult"))
            {

                //ScenarioContext.Current["Verification Result"] = GeneratedUserID;
                GlobalRef.VerificationResult = GeneratedUserID;
            }
        }




        [Then(@"SNP Follow Up Activity Verification Date is set to ""(.*)""")]
        public void ThenSNPFollowUpActivityVerificationDateIsSetTo(string p0)
        {
            String strValue = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                AngularFunction.enterDate(cfSNPUIMOD.View_Special_Need_Plan.VerificationDate, strValue);
            }
            else
            {
                strValue = strValue.Replace("/", "");
                IWebElement objDate = EAM.TransactionsNew.VerificationDate;
                objDate.Clear();
                objDate.Click();
                objDate.SendKeys(strValue);
            }
        }

        [Then(@"SNP Follow Up Activity Source Of Verification is set to ""(.*)""")]
        public void ThenSNPFollowUpActivitySourceOfVerificationIsSetTo(string p0)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                string value = tmsCommon.GenerateData(p0);
                By Drp = By.XPath("//label[@test-id='snp-lbl-sourceOfVerification']/parent::div//span[@class='k-select']");

                By typeapp = By.XPath("//li[text()='" + value + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                tmsWait.Hard(3);
                fw.ConsoleReport("Source of Verification dropdown has value as  " + typeapp);
            }
        }

        [When(@"Letters Search results MBI ""(.*)"" row is selected and Send Check box is selected")]
        public void WhenLettersSearchResultsMBIRowIsSelectedAndSendCheckBoxIsSelected(string p0)
        {
            string mbi = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='letterQueue-grid-resultsGrid']//td[contains(.,'" + mbi + "')]/following-sibling::td/input[@type='checkbox'])[1]")));
        }



        [Then(@"SNP Follow Up Activity Verification Result is set to ""(.*)""")]
        public void ThenSNPFollowUpActivityVerificationResultIsSetTo(string p0)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                string value = tmsCommon.GenerateData(p0);
                By Drp = By.XPath("//label[@test-id='snp-lbl-verificationResult']/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + value + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                tmsWait.Hard(3);

                fw.ConsoleReport("Source of Verification dropdown has value as  "  +typeapp  );
            }

        }

        [When(@"SNP Follow Up Activity Verification Result is set to ""(.*)""")]
        public void WhenSNPFollowUpActivityVerificationResultIsSetTo(string p0)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                string value = tmsCommon.GenerateData(p0);
                By Drp = By.XPath("//label[@test-id='snp-lbl-verificationResult']/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + value + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                tmsWait.Hard(3);

            }
        }



        [When(@"Verify View Special Need Plan page displayed warning msg ""(.*)""")]
        public void WhenVerifyViewSpecialNeedPlanPageDisplayedWarningMsg(string expected)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(3);

                By toastMsg = By.XPath("//div[@class='k-notification-content']");
                string actValue = Browser.Wd.FindElement(toastMsg).Text;
                Assert.IsTrue(actValue.Contains(expected));

            }
            else
            {
                IWebElement menu = Browser.Wd.FindElement(By.XPath("//div[@class='toast-message']"));
                string actual = menu.Text;

                Assert.AreEqual(expected, actual, " Both are not matching");
            }
        }

        [When(@"Verify View Special Need Plan page displayed warning messasge ""(.*)""")]
        public void WhenVerifyViewSpecialNeedPlanPageDisplayedWarningMessasge(string expected)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {

                By toastMsg = By.XPath("//div[@class='k-notification-content']");
                string actValue = Browser.Wd.FindElement(toastMsg).Text;
                Assert.IsTrue(actValue.Contains(expected));

            }
            else
            {
                IWebElement menu = Browser.Wd.FindElement(By.XPath("//div[@class='toast-message']"));
                string actual = menu.Text;

                Assert.AreEqual(expected, actual, " Both are not matching");
            }
        }




        [Then(@"SNP Follow Up Activity SNP Status is set to ""(.*)""")]
        public void ThenSNPFollowUpActivitySNPStatusIsSetTo(string p0)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                string value = tmsCommon.GenerateData(p0);
                By Drp = By.XPath("//label[@test-id='snp-lbl-snpStatus']/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + value + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                tmsWait.Hard(3);

            }
        }

        [Then(@"SNP Follow Up Activity Follow Up Method is set to ""(.*)""")]
        public void ThenSNPFollowUpActivityFollowUpMethodIsSetTo(string p0)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                string value = tmsCommon.GenerateData(p0);
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='snp-select-followUpMethod']/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + value + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                tmsWait.Hard(3);

            }
        }


        [Then(@"SNP Follow Up Activity Follow Up Date is set to ""(.*)""")]
        public void ThenSNPFollowUpActivityFollowUpDateIsSetTo(string p0)
        {
            String strValue = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                AngularFunction.enterDate(cfSNPUIMOD.View_Special_Need_Plan.FollowUpDate, strValue);
            }
            else
            {
                strValue = strValue.Replace("/", "");
                IWebElement objDate = EAM.TransactionsNew.FollowUpDate;
                objDate.Clear();
                objDate.Click();
                objDate.SendKeys(strValue);
            }
        }

        [Then(@"Verify ""(.*)"" textbox is present")]
        public void ThenVerifyTextboxIsPresent(string p0)
        {
            ReUsableFunctions.checkElementDisplayinGrid(By.XPath("//textarea[@test-id='snp-txt-snpNotes']"));
        }

        [Then(@"Enter the new note into SNP New Notes page note area ""(.*)""")]
        public void ThenEnterTheNewNoteIntoSNPNewNotesPageNoteArea(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            tmsWait.Hard(2);
            string strTitle = "EAM - New Note";
            Browser.SwitchToWindowUsingTitle(strTitle);
            tmsWait.Hard(2);
            Browser.Wd.FindElement(By.XPath("//textarea[@test-id='snp-txt-snpNotes']")).SendKeys(GeneratedData);
        }


        [Then(@"View Special Need Plan ""(.*)"" is clicked")]
        public void ThenViewSpecialNeedPlanIsClicked(string p0)
        {
            tmsWait.Hard(1);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//li[@id='k-tabstrip-tab-1']//span"));
            ReUsableFunctions.clickOnWebElement(ele);
        }

        [Then(@"View Special Need Plan tab ""(.*)"" is clicked")]
        public void ThenViewSpecialNeedPlanTabIsClicked(string p0)
        {
            tmsWait.Hard(1);
            IWebElement ele1 = Browser.Wd.FindElement(By.XPath("//li[@id='k-tabstrip-tab-2']//span"));
            ReUsableFunctions.clickOnWebElement(ele1);
        }


        [Then(@"verify SNP New Notes ""(.*)"" is present")]
        public void ThenVerifySNPNewNotesIsPresent(string p0)
        {
            string note = tmsCommon.GenerateData(p0);
            By loc = By.XPath("//div[@test-id='outOfArea-lbl-completedSuspectActions'][contains(.,'" + note + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }


        [When(@"Transactions New DateOfBirth is set to ""(.*)""")]
        public void WhenTransactionsNewDateOfBirthIsSetTo(string p0)
        {
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p0);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='DemographicDetailsDob']//span/input"));
            value = value.Replace("/", "");
            ele.Clear();
            ele.SendKeys(value);
            tmsWait.Hard(3);
        }


        [Then(@"Verify SNP Follow Up Activity section  field ""(.*)"" is displayed as ""(.*)""")]
        public void ThenVerifySNPFollowUpActivitySectionFieldIsDisplayedAs(string p0, string p1)
        {

            string expectedValue = tmsCommon.GenerateData(p1);
            string actualValue;


            By Drp = By.XPath("//input[@test-id='snp-txt-monthsOfEligibility']");
            actualValue = Browser.Wd.FindElement(Drp).GetAttribute("value");
            Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");
        }

        [Then(@"verify SNP New Notes page note area Note is present in Actions ""(.*)""")]
        public void ThenVerifySNPNewNotesPageNoteAreaNoteIsPresentInActions(string p0)
        {
            String value = tmsCommon.GenerateData(p0);
            By loc = By.XPath("//kendo-grid[@test-id='snpActions-grid-gridSnpCompleteActions']//td[contains(.,'" + value + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);


        }

        [Then(@"verify SNP Follow Up Activity field ""(.*)"" is present")]
        public void ThenVerifySNPFollowUpActivityFieldIsPresent(string p0)
        {
            By loc = By.XPath("//input[@test-id='snp-txt-endDateGracePeriod']");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }



        [Then(@"verify SNP Follow Up Activity ""(.*)"" is displayed as ""(.*)""")]
        public void ThenVerifySNPFollowUpActivityIsDisplayedAs(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string expectedValue = tmsCommon.GenerateData(p1);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//input[@test-id='snp-txt-endDateGracePeriod']"));
            string value1 = ele.GetAttribute("value");
            if (expectedValue == "07/31/2021")
            {
                Assert.IsTrue(value1.Contains("07/31/2021"));
            }

        }




        [When(@"Transactions New EffectiveDate is set to ""(.*)""")]
        public void WhenTransactionsNewEffectiveDateIsSetTo(string p0)
        {
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p0);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='DemographicDetailsEffectiveDate']//span/input"));
            value = value.Replace("/", "");
            ele.Clear();
            ele.SendKeys(value);
            tmsWait.Hard(3);
        }

        [When(@"Transactions New SignatureDate is set to ""(.*)""")]
        public void WhenTransactionsNewSignatureDateIsSetTo(string p0)
        {
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p0);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='DemographicDetailsSignatureDate']//span/input"));
            value = value.Replace("/", "");
            ele.Clear();
            ele.SendKeys(value);
            tmsWait.Hard(3);
        }

        [When(@"Transactions New ReceiptDate is set to ""(.*)""")]
        public void WhenTransactionsNewReceiptDateIsSetTo(string p0)
        {
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p0);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='DemographicDetailsReceiptDate']//span/input"));
            value = value.Replace("/", "");
            ele.Clear();
            ele.SendKeys(value);
            tmsWait.Hard(3);
        }




        [Then(@"View Special Need Plan Save button is clicked")]
        public void ThenViewSpecialNeedPlanSaveButtonIsClicked()
        {
            IWebElement saveBtn = Browser.Wd.FindElement(By.XPath("//button[@test-id='snp-button-save']"));
            saveBtn.Click();
            tmsWait.Hard(3);

        }

        [Then(@"verify that validation message is displayed as ""(.*)""")]
        public void ThenVerifyThatValidationMessageIsDisplayedAs(string p0)
        {
            string expectedValue = tmsCommon.GenerateData(p0);
            string actualValue = Browser.Wd.FindElement(By.ClassName("k-notification-content")).Text;
            Assert.IsTrue(actualValue.Equals(expectedValue));
            //Assert.IsTrue(actualValue.Contains(expectedValue));

        }

        [Then(@"Click ""(.*)"" in address popup")]
        public void ThenClickInAddressPopup(string p0)
        {
            IWebElement address = Browser.Wd.FindElement(By.XPath("//*[@test-id='confirmationDialog-btn-Yes']"));
            address.Click();

        }

        [Then(@"click ""(.*)""  in county popup")]
        public void ThenClickInCountyPopup(string p0)
        {
            IWebElement address1 = Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']"));
            address1.Click();

        }

        [Then(@"ViewEdit transaction ""(.*)"" is clicked")]
        public void ThenViewEditTransactionIsClicked(string p0)
        {
            tmsWait.Hard(5);
            IWebElement address2 = Browser.Wd.FindElement(By.XPath("//button[@test-id='transaction-btn-memberInfo']"));
            address2.Click();
        }

        [Then(@"verify  VIEW SNP Follow up activity ""(.*)"" Drop down values as ""(.*)""")]
        public void ThenVerifyVIEWSNPFollowUpActivityDropDownValuesAs(string p0, string p1)
        {
            IList<IWebElement> webdrpValues;

            List<string> ExpectedValues = new List<string>();
            List<string> resultantString;
            List<string> Sourcefinallist = new List<string>();
            switch (p0)
            {
                case "Source of Verification":
                    object var = fw.ExecuteJavascriptReturnText(Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@id='ddSourceOfVerification']//span[@class='k-select']")));
                    tmsWait.Hard(5);
                    webdrpValues = Browser.Wd.FindElements(By.XPath("//kendo-dropdownlist[@test-id='outOfArea-select-ssrs']//li"));

                    tmsWait.Hard(2);
                    int listcount = webdrpValues.Count();
                    List<string> Actuallist = new List<string>();

                    fw.ConsoleReport("Actual Result");
                    foreach (IWebElement temp in webdrpValues)
                    {
                        Actuallist.Add(temp.Text);
                        fw.ConsoleReport(temp.Text);
                    }
                    tmsWait.Hard(2);

                    fw.ConsoleReport("Expected Result");
                    string[] split_value = p1.Split(',');
                    for (int i = 0; i < split_value.Length; i++)
                    {

                        ExpectedValues.Add(split_value[i].Trim());
                        fw.ConsoleReport(split_value[i]);


                    }
                    resultantString = compareTwoList(ExpectedValues, Actuallist);

                    /* foreach (string temp in resultantString)
                     {
                         if (resultantString.Count == 1)
                         {
                             if (temp.Equals("<Select a Value>"))
                             {
                                 Assert.IsTrue(true, " All values are matched");
                                 break;
                             }
                             else
                             {
                                 Assert.Fail("DB values are not displayed on Drop down");
                             }
                         }
                         else
                         {
                             Assert.Fail(" DB values and Drop down values are not matching");
                         }

                     } */
                    break;
            }
        }

        List<string> compareTwoList(List<string> Actuallist, List<string> ExpectedValues)
        {
            List<string> resultantList = new List<string>();

            //Console.WriteLine("Difference in the Drop Down List and DB value lists...");
            IEnumerable<string> list3;
            list3 = Actuallist.Except(ExpectedValues);
            foreach (string value in list3)
            {
                resultantList.Add(value);
            }
            return resultantList;

        }


        List<string> ConvertWebElementInToString(IList<IWebElement> webdrpValues)
        {
            List<string> temp = new List<string>();
            Console.WriteLine(" List of Values in Drop Down list");
            foreach (IWebElement t in webdrpValues)
            {
                temp.Add(t.Text);
                Console.WriteLine(t.Text);
            }
            return temp;

        }

        [Then(@"Verify VIEW SNP Follow up activity Source of Verification selected value displayed as ""(.*)""")]
        public void ThenVerifyVIEWSNPFollowUpActivitySourceOfVerificationSelectedValueDisplayedAs(string expectedValue)
        {
            IWebElement ddele = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='outOfArea-select-ssrs']//span[@class='k-input']"));
            string actual_value = ddele.Text;
            Assert.IsTrue(actual_value.Contains(expectedValue), "Value does not match");
            fw.ConsoleReport("Source of Verification dropdown has value as  " + actual_value);

        }


        [Then(@"View Special Need plan Message ""(.*)"" is displayed")]
        public void ThenViewSpecialNeedPlanMessageIsDisplayed(string p0)
        {
            By toastMsg = By.XPath("//div[@class='k-notification-content']");
            string actValue = Browser.Wd.FindElement(toastMsg).Text;
            fw.ScrollWindowToViewElement(cfSNPUIMOD.View_Special_Need_Plan.snp_lbl_monthsOfEligibility);
        }

        [Then(@"""(.*)"" is checked")]
        public void ThenIsChecked(string p0)
        {
            IWebElement update = Browser.Wd.FindElement(By.CssSelector("[test-id='snp-chk-queueLossOfSnp']"));
            fw.ExecuteJavascript(update);
        }


        [Then(@"""(.*)"" is clicked")]
        public void ThenIsClicked(string p0)
        {

            ReUsableFunctions.clickOnWebElement(cfSNPUIMOD.View_Special_Need_Plan.ComAction);
            tmsWait.Hard(3); ;
        }

        [Then(@"Actions ""(.*)"" is clicked")]
        public void ThenActionsIsClicked(string p0)
        {
            By ActionsEdit = By.XPath("//table[@role='presentation']//td[@aria-colindex='7']//span");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(ActionsEdit);
            tmsWait.Hard(3);
        }


        [Then(@"on clicking YES in Complete Action Warning page")]
        public void ThenOnClickingYESInCompleteActionWarningPage()
        {
            UIMODUtilFunctions.clickOnConfirmationYesDialog();

        }


        [Then(@"View Special Need Plan details is clicked in Historical Suspects")]
        public void ThenViewSpecialNeedPlanDetailsIsClickedInHistoricalSuspects()
        {
            By HistSuspDetails = By.XPath("//table[@role='presentation']//tr//td//span");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(HistSuspDetails);
            tmsWait.Hard(3);
        }

        [Then(@"SNP New Verification Result is set to ""(.*)""")]
        public void ThenSNPNewVerificationResultIsSetTo(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0.ToString());
            AngularFunction.selectDropDownValue(cfSNPUIMOD.View_Special_Need_Plan.VerificationResultDrp, strValue);
        }

        [Then(@"SNP New SNP Status is set to ""(.*)""")]
        public void ThenSNPNewSNPStatusIsSetTo(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0.ToString());
            AngularFunction.selectDropDownValue(cfSNPUIMOD.View_Special_Need_Plan.SNPStatusDrp, strValue);
        }

        [Then(@"make note the value of ""(.*)""")]
        public void ThenMakeNoteTheValueOf(string p0)
        {
            IWebElement UserMod = Browser.Wd.FindElement(By.XPath("//input[@test-id='snp-txt-userModified']"));
            UIMODUtilFunctions.returnTextUsingWebElement(UserMod);


        }

        [Then(@"Verify Actions tab  has below row")]
        public void ThenVerifyActionsTabHasBelowRow(Table table)
        {
            try
            {
                IWebElement objWebTable = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='snpActions-grid-gridsnpActions']"));

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i + 1, arrRes[i, 1]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Verify Members New Tab ID History Table has row: {0}", e.Message);
            }
        }

        [Then(@"Verify View Special Need Plan ""(.*)"" field is displayed as ""(.*)""")]
        public void ThenVerifyViewSpecialNeedPlanFieldIsDisplayedAs(string p0, string p1)
        {
            string value = tmsCommon.GenerateData(p1);
            //By Drp = By.XPath("//label[contains(.,'SNP Status')]/parent::div//span[@class='k-input']");
            IWebElement Drp = Browser.Wd.FindElement(By.XPath("//label[contains(.,'SNP Status')]/parent::div//span[@class='k-input']"));

            //string actualValue = Browser.Wd.FindElement(Drp).GetAttribute("value");
            string actualValue = Drp.Text;
            Assert.AreEqual(value, actualValue, " Both values are not matching");
            fw.ConsoleReport("SNP Status value is" + actualValue);
        }




        [Then(@"also make note the value of ""(.*)""""")]
        public void ThenAlsoMakeNoteTheValueOf(string p0)
        {
            IWebElement DateMod = Browser.Wd.FindElement(By.XPath("//input[@test-id='snp-txt-dateModified']"));
            UIMODUtilFunctions.returnTextUsingWebElement(DateMod);
        }

        [Then(@"Verify SNP Follow Up Activity section ""(.*)"" Textbox Field is disabled")]
        public void ThenVerifySNPFollowUpActivitySectionTextboxFieldIsDisplayed(string p0)
        {
            Boolean isdis = false;
            string isdisabled;
            IWebElement element = Browser.Wd.FindElement(By.XPath("//input[@test-id='snp-txt-userModified']"));
            Assert.IsTrue(element.Displayed, p0 + "is not getting displayed");
            isdisabled = element.GetAttribute("disabled");
            if (isdisabled == "true")
            {
                isdis = true;
            }
            Assert.IsTrue(isdis, "User Modified field is not disabled");

        }

        [Then(@"Verify SNP Follow Up Activity ""(.*)"" Textbox Field is disabled")]
        public void ThenVerifySNPFollowUpActivityTextboxFieldIsDisplayed(string p0)
        {
            Boolean isdis = false;
            string isdisabled;
            IWebElement element = Browser.Wd.FindElement(By.XPath("//input[@test-id='snp-txt-dateModified']"));
            Assert.IsTrue(element.Displayed, p0 + "is not getting displayed");
            isdisabled = element.GetAttribute("disabled");
            if (isdisabled == "true")
            {
                isdis = true;
            }
            Assert.IsTrue(isdis, "User Modified field is not disabled");
        }


        [Then(@"Verify SNP Follow Up Activity Date Modified value is set to current date")]
        public void ThenVerifySNPFollowUpActivityDateModifiedValueIsSetToCurrentDate()
        {
            //Output will be in 06/03/2021 format

            string expecteddate = DateTime.Now.ToString("MM/dd/yyyy");

            string thisFieldValue = Browser.Wd.FindElement(By.XPath("//input[@test-id='snp-txt-dateModified']")).GetAttribute("value");

            string actualdate = (thisFieldValue.Split(' '))[0]; // ouput[0]=06 / 03 / 2021

            Assert.AreEqual(expecteddate, actualdate);

            fw.ConsoleReport("Date Modified is " + actualdate);


        }


        [When(@"verify whether Transactions status ""(.*)"" is set to ""(.*)""")]
        public void WhenVerifyWhetherTransactionsStatusIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            //bool elementpresence = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='ApplicationDispositionActionsOnHoldTransactionStatus']//span[contains(.,'" + value + "')]")).Displayed;
            //Assert.IsTrue(elementpresence, "Element is not present");
            //fw.ConsoleReport("On Hold Transaction Status is " + elementpresence);
            By Drp8 = By.XPath("//kendo-dropdownlist[@test-id='ApplicationDispositionActionsOnHoldTransactionStatus']//span[@class='k-select']");
            AngularFunction.clickOnElement(Drp8);
            By drpValue = By.XPath("//Span[contains(.,'"+ value +"')]");
                bool elementpresence = Browser.Wd.FindElement(drpValue).Displayed;
                Assert.IsTrue(elementpresence, "Element is present");
        }

        [When(@"verify whether Transactions reason ""(.*)"" is set to ""(.*)""")]
        public void WhenVerifyWhetherTransactionsReasonIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            By Drp8 = By.XPath("//kendo-dropdownlist[@test-id='ApplicationDispositionActionsOnHoldReason']//span[@class='k-select']");
            AngularFunction.clickOnElement(Drp8);
            By drpValue = By.XPath("//Span[contains(.,'"+value+"')]");
            bool elementpresence = Browser.Wd.FindElement(drpValue).Displayed;
            Assert.IsTrue(elementpresence, "Element is present");
            
    


        }




        [When(@"verify ""(.*)"" Value is set to ""(.*)""")]
        public void WhenVerifyValueIsSetTo(string p0, string p1)
        {
            By loc = By.XPath("//button[@test-id='transaction-btn-expandAndCollapse']");
            AngularFunction.clickOnElement(loc);
            tmsWait.Hard(3);
            string field = tmsCommon.GenerateData(p0);
            string expectedValue = tmsCommon.GenerateData(p1);
            tmsWait.Hard(3);
            ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfSNPUIMOD.View_Special_Need_Plan.MedicaidLevel);
            fw.ConsoleReport("Medicaid Level value is " + expectedValue);
        }

        [Given(@"navigate to Letters in Dashboard")]
        public void GivenNavigateToLettersInDashboard()
        {
            By loc = By.XPath("//span[@test-id='eamDashboard-lbl-letters']");
            AngularFunction.clickOnElement(loc);
            tmsWait.Hard(3);
        }

        [When(@"navigate to Letters in Dashboard")]
        public void WhenNavigateToLettersInDashboard()
        {
            By loc = By.XPath("//span[@test-id='eamDashboard-lbl-letters']");
            AngularFunction.clickOnElement(loc);
            tmsWait.Hard(3);
        }


        [Then(@"navigate to Letters in Dashboard")]
        public void ThenNavigateToLettersInDashboard()
        {
            By loc = By.XPath("//span[@test-id='eamDashboard-lbl-letters']");
            AngularFunction.clickOnElement(loc);
            tmsWait.Hard(3);
        }




        [Then(@"Letters Page DeSelect All Button is Clicked")]
        public void ThenLettersPageDeSelectAllButtonIsClicked()
        {
            tmsWait.Hard(3);
            fw.ScrollWindowToViewElement(cfUIMODLetters.LettersCollections.DeselctAllButton);
            ReUsableFunctions.clickOnWebElement(cfUIMODLetters.LettersCollections.DeselctAllButton);
        }



        [Then(@"verify MBI as ""(.*)"" is present in Correspondence by Letter Type Report")]
        public void ThenVerifyMBIAsIsPresentInCorrespondenceByLetterTypeReport(string p0)
        {
            String expectedValue = tmsCommon.GenerateData(p0);
            string actualValue = Browser.Wd.FindElement(By.XPath("//table[@cols='6']//tr[contains(.,'" + expectedValue + "')]//td[3]")).Text;
            Assert.AreEqual(expectedValue, actualValue, "MBI does not exist");
        }

        [Then(@"letter ""(.*)"" count is noted as ""(.*)""")]
        public void ThenLetterCountIsNotedAs(string p0, string p1)
        {
            String LetterName = tmsCommon.GenerateData(p0);
            String Lettercount;
            By Count1 = By.XPath("//label[contains(.,'" + LetterName + "')]/parent::div/preceding-sibling::div/a");
            try
            {
                Lettercount = Browser.Wd.FindElement(Count1).Text;

            }
            catch
            {
                Lettercount = "0";

            }
            fw.setVariable(p1,Lettercount);
            fw.ConsoleReport("Letter count for " + LetterName + " is displayed as " + Lettercount);

        }


        [Then(@"letter ""(.*)"" count after disnenrollment is noted as ""(.*)""")]
        public void ThenLetterCountAfterDisnenrollmentIsNotedAs(string p0, string p1)
        {
            String LetterName = tmsCommon.GenerateData(p0);
            String LettercountafterTC51;
            By Count1 = By.XPath("//label[contains(.,'" + LetterName + "')]/parent::div/preceding-sibling::div/a");
            try
            {
                LettercountafterTC51 = Browser.Wd.FindElement(Count1).Text;

            }
            catch
            {
                LettercountafterTC51 = "0";

            }
            fw.setVariable(p1,LettercountafterTC51);
            fw.ConsoleReport("Letter count for" + LetterName + "is displayed as" + LettercountafterTC51);
        }

        [Then(@"letter ""(.*)"" count after Generation of letter is noted as ""(.*)""")]
        public void ThenLetterCountAfterGenerationOfLetterIsNotedAs(string p0, string p1)
        {
            String LetterName = tmsCommon.GenerateData(p0);
            String LettergenerationcountafterTC51;
            By Count1 = By.XPath("//label[contains(.,'" + LetterName + "')]/parent::div/preceding-sibling::div/a");
            try
            {
                LettergenerationcountafterTC51 = Browser.Wd.FindElement(Count1).Text;

            }
            catch
            {
                LettergenerationcountafterTC51 = "0";

            }
            fw.setVariable(p1, LettergenerationcountafterTC51);
            fw.ConsoleReport("Letter count for" + LetterName + "is displayed as" + LettergenerationcountafterTC51);
        }




        [Then(@"User click on count ""(.*)"" corresponding to Letter ""(.*)""")]
        public void ThenUserClickOnCountCorrespondingToLetter(string p0, string p1)
        {
            String LetterName = "Disenroll Loss SNP";
            By Count1 = By.XPath("//label[contains(.,'" + LetterName + "')]/parent::div/preceding-sibling::div/a");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(Count1);
            tmsWait.Hard(3);
        }

        [Then(@"Letters Page Plan ID drop down list ""(.*)"" value is selected")]
        public void ThenLettersPagePlanIDDropDownListValueIsSelected(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Plan ID')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + value + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                tmsWait.Hard(3);
            }
            else
            {
                UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODLetters.LettersCollections.PlanID, value);
            }
        }
        [Then(@"Letters Page PBP ID drop down list ""(.*)"" value is selected")]
        public void ThenLettersPagePBPIDDropDownListValueIsSelected(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'PBP')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + value + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                tmsWait.Hard(3);
            }
            else
            {
                UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODLetters.LettersCollections.PBPID, value);
            }
        }
        [Then(@"Letters Page Search Button is Clicked")]
        public void ThenLettersPageSearchButtonIsClicked()
        {
            ReUsableFunctions.clickOnWebElement(cfUIMODLetters.LettersCollections.SearchButton);
        }

        [Then(@"Run Report button is Clicked successfully")]
        public void ThenRunReportButtonIsClickedSuccessfully()
        {
            AngularFunction.clickOnElement(cfComplianceReport.QuarterlyDisEnrollmentReport.ReportButton);
        }

        [Then(@"I switched to Report Window")]
        public void ThenISwitchedToReportWindow()
        {
            tmsWait.Hard(10);
            Browser.SwitchToChildWindow();
            AngularFunction.resolveCertificateErrors();
            string title = Browser.Wd.Title;

            fw.ConsoleReport(" Child Window Title " + title);
        }


        [When(@"I navigate to Dashboard")]
        public void WhenINavigateToDashboard()
        {
            By loc = By.XPath("//div[@title='Dashboard']");
            AngularFunction.clickOnElement(loc);
            tmsWait.Hard(3);
        }

        [When(@"Letter Templates page MAP TEMPLATES button is clicked")]
        public void WhenLetterTemplatesPageMAPTEMPLATESButtonIsClicked()
        {
            IWebElement save = Browser.Wd.FindElement(By.CssSelector("[test-id='letterTemplate-btn-mapLetters']"));
            fw.ExecuteJavascript(save);
            tmsWait.Hard(4);
        }

        [When(@"Map Templates page ""(.*)"" letter template is selected")]
        public void WhenMapTemplatesPageLetterTemplateIsSelected(string p0)
        {
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='letterTempMapping-select-template']//span[@class='k-select']");

            By typeapp = By.XPath("//li[text()='" + p0 + "']");

            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));

            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }


        /* [When(@"template is ""(.*)"" for for Plan ID ""(.*)"" PBP ID ""(.*)""")]
         public void WhenTemplateIsForForPlanIDPBPID(string p0, string p1, int p2)
         {
             IWebElement lettertemp;
             //bool valuefound = false;
             string planid = tmsCommon.GenerateData(p1);
             //while (!valuefound)
             //{
                 //try
                 //{
                     lettertemp = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='letterTemplate-grid-letterTemplates'][@planid='" + planid + "' and @pbp='" + pbp + "' ]"));
                    if (lettertemp.Displayed)
             {
                 string lt = lettertemp.GetAttribute("checked");
                 if (lt != "true")
                 {
                     fw.ExecuteJavascript(lettertemp);
                     // presence = true;
                 }
                 //presence = true;
             }
                 // }
                // catch
                // {

                   //  AngularFunction.clickonNextLink();
                 //}
             //}

             //Assert.IsTrue(valuefound);
         } */

        /* [When(@"template is ""(.*)"" for for Plan ID ""(.*)"" PBP ""(.*)""")]
         public void WhenTemplateIsForForPlanIDPBP(string p0, string p1, string p2)
         {
             IWebElement lettertemp;
             string planid = tmsCommon.GenerateData(p1);
             string pbp = tmsCommon.GenerateData(p2);
             lettertemp = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='letterTemplate-grid-letterTemplates']//td[1]/Input[@planid='" + planid + "' and @pbp='" + pbp + "' ]"));
             if (lettertemp.Displayed)
             {
                 string lt = lettertemp.GetAttribute("checked");
                 if (lt != "true")
                 {
                     fw.ExecuteJavascript(lettertemp);

                 }

             }

         }*/
        [When(@"letter template page check all is done")]
        public void WhenLetterTemplatePageCheckAllIsDone()
        {
            By checkAll = By.XPath("(//input[@id='selectAllCheckboxId'])[1]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(checkAll);
            tmsWait.Hard(1);

        }





        [When(@"Letter Templates page MAP button is clicked")]
        public void WhenLetterTemplatesPageMAPButtonIsClicked()
        {
            IWebElement save = Browser.Wd.FindElement(By.CssSelector("[test-id='letterTempMapping-btn-MapLetters']"));
            fw.ExecuteJavascript(save);
            tmsWait.Hard(4);

            By MaptempCancel = By.CssSelector("[test-id='letterTempMapping-btn-btnCancel']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(MaptempCancel);
        }


        [When(@"navigate to Dashboard")]
        public void WhenNavigateToDashboard()
        {
            By loc = By.XPath("//div[@title='Dashboard']");
            AngularFunction.clickOnElement(loc);
            tmsWait.Hard(3);
        }

        [When(@"User navigate to Dashboard")]
        public void WhenUserNavigateToDashboard()
        {
            By loc = By.XPath("//div[@title='Dashboard']");
            AngularFunction.clickOnElement(loc);
            tmsWait.Hard(3);
        }


        [Then(@"Verify SNP Letter count ""(.*)"" count is ""(.*)"" than ""(.*)"" count")]
        public void ThenVerifySNPLetterCountCountIsThanCount(string p0, string p1, string p2)
        {
            string value = tmsCommon.GenerateData(p0);
            int Bcount = Int32.Parse(value);
            int Acount = Int32.Parse(tmsCommon.GenerateData(p2));
            bool results;
            if (p1.Equals("increased"))
            {
                results = (Acount > Bcount);

                Assert.IsTrue(results, p2 + " Second count is not increased");
                fw.ConsoleReport("After count is increased");

            }

            if (p1.Equals("same"))
            {
                results = (Acount == Bcount);

                Assert.IsTrue(results, p2 + " No Change. Values are same ");
                fw.ConsoleReport("No Change");

            }

            if (p1.Equals("decreased"))
            {
                results = (Bcount < Acount);

                Assert.IsTrue(results, p2 + " Count is decreased ");
                fw.ConsoleReport("TC51CountAfterGeneration count is decreased");

            }


        }






    }

}

