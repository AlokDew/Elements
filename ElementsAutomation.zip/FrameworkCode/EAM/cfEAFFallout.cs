﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.EAM
{
    [Binding]
    class cfEAFFallout
    {
        public static EAFFalloutRecordsPage EAFFalloutRecordsPage { get { return new EAFFalloutRecordsPage(); } }
        public static EAFFalloutRecordsDetailsPage EAFFalloutRecordsDetailsPage { get { return new EAFFalloutRecordsDetailsPage(); } }
    }


    

    [Binding]
    public class EAFFalloutRecordsDetailsPage
    {
        public IWebElement SaveButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='eafFalloutCorrectionFooter-btn-saveDraft']")); } }
      }

    [Binding]
    public class EAFFalloutRecordsPage
    {
        public IWebElement FileNameDropdown { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='formInputBoxAUD_listbox']")); } }
        public IWebElement TransactionCodeDropdown { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='inputBoxTransCode_listbox']")); } }
        public IWebElement AgingDropdown { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='inputBoxAsignStatus_listbox']")); } }
        public IWebElement StatusDropdown { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='identityProvider-li-claimTransformationSettings']")); } }
        public IWebElement MBI { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='eafFalloutCorrection-input-mbi']")); } }
        public IWebElement FalloutFromDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='eafFalloutCorrection-txt-txtFromDate']")); } }
        public IWebElement FalloutEndDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='eafFalloutCorrection-txt-txtToDate']")); } }
        public IWebElement search { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='eafFalloutCorrection-btn-search']")); } }

    }
    }
