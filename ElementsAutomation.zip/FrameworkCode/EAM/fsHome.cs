﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections;
using System.Collections.Generic;
using TechTalk.SpecFlow;
using TMSoR1;
using TMSoR1.FrameworkCode;

namespace Daron0004
{

    [Binding]
    public class EAM_Home
    {

        [Then(@"Home Page Final Letter count for Confirmation of Disenrollment Due to Passive Enrollment into a Medicare-Medicaid Plan queue table")]
        public void ThenHomePageFinalLetterCountForConfirmationOfDisenrollmentDueToPassiveEnrollmentIntoAMedicare_MedicaidPlanQueueTable(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.Letters.LettersQueueTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            try
                            {
                                if (bThisRowMatches)
                                {
                                    IWebElement thisEditTD = ApplicationRow.Element[0];
                                    IWebElement thisEditLink = thisEditTD.FindElement(By.XPath("//a[contains(@href,'reports/reportmain_letterqueue.aspx?code=030&type=2')]"));
                                    GlobalRef.FinalLetterCount = Int32.Parse(thisEditLink.Text);
                                    Console.WriteLine("Final Letter Count for Confirmation of Disenrollment Due to Passive Enrollment into a Medicare-Medicaid Plan queue" + thisEditLink.Text);
                                    tmsWait.Hard(2);


                                }
                            }
                            catch
                            {
                                GlobalRef.LetterCount = 0;
                            }


                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.Letters.LettersQueueTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

        [Then(@"Verify Home Page Initial Letter count for Confirmation of Cancellation of Enrollment Due to Notice from CMS \(TRC (.*)\) queue table")]
        public void ThenVerifyHomePageInitialLetterCountForConfirmationOfCancellationOfEnrollmentDueToNoticeFromCMSTRCQueueTable(int p0, Table table)
        {


            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.Letters.LettersQueueTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            try
                            {
                                if (bThisRowMatches)
                                {
                                    IWebElement thisEditTD = ApplicationRow.Element[0];
                                    IWebElement thisEditLink = thisEditTD.FindElement(By.XPath("//a[contains(@href,'reports/reportmain_letterqueue.aspx?code=031&type=2')]"));
                                    GlobalRef.InitialLetterCount = Int32.Parse(thisEditLink.Text);
                                    Console.WriteLine("Initial Letter Count for Confirmation of Cancellation of Enrollment Due to Notice from CMS (TRC 015) queue" + thisEditLink.Text);
                                    tmsWait.Hard(2);


                                }
                            }
                            catch
                            {
                                GlobalRef.LetterCount = 0;
                            }


                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.Letters.LettersQueueTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }


        }

        [Then(@"I have navigated to Login Info Home page")]
        public void ThenIHaveNavigatedToLoginInfoHomePage()
        {
            Browser.Wd.FindElement(By.XPath("//div[@class='LoginInfoContent']/a[1]")).Click();
        }


        [Then(@"Verify Home Page Third time Letter count for Confirmation of Disenrollment Due to Passive Enrollment into a Medicare-Medicaid Plan queue")]
        public void ThenVerifyHomePageThirdTimeLetterCountForConfirmationOfDisenrollmentDueToPassiveEnrollmentIntoAMedicare_MedicaidPlanQueue(Table table)
        {
            string fieldName = "letters in Confirmation of Disenrollment Due to Passive Enrollment into a Medicare-Medicaid Plan queue";

            bool flag = true;
            IList<IWebElement> letter = Browser.Wd.FindElements(By.CssSelector("#ctl00_ctl00_MainMasterContent_MainContent_QueuesCtr1_Table2 td:nth-of-type(2)"));

            foreach (IWebElement let in letter)
            {
                if (let.Text.Equals(fieldName))
                {
                    IWebElement thisEditLink = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'reports/reportmain_letterqueue.aspx?code=030&type=2')]"));
                    GlobalRef.ThirdLetterCount = thisEditLink.Text;
                    Console.WriteLine("Third time Letter Count for Confirmation of Disenrollment Due to Passive Enrollment into a Medicare-Medicaid Plan queue " + thisEditLink.Text);
                    tmsWait.Hard(2);
                    flag = false;
                    break;
                }
            }

            if (flag)
            {
                GlobalRef.ThirdLetterCount = "0";
                Console.WriteLine("Third time Letter Count for Confirmation of Disenrollment Due to Passive Enrollment into a Medicare-Medicaid Plan queue" + GlobalRef.ThirdLetterCount.ToString());
            }
            
            int secondLetterCount = Convert.ToInt32(GlobalRef.secondLetterCount.ToString());
            int thirdLetterCount = Convert.ToInt32(GlobalRef.ThirdLetterCount.ToString());


            Assert.AreEqual(true, (thirdLetterCount< secondLetterCount), "Field " + fieldName + " value is [" + thirdLetterCount + "], Before Count [" + secondLetterCount + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " Current Letter count value is [" + thirdLetterCount + "], Before Count [" + secondLetterCount + "] - Home page Letter Count should be decreased.");
            
    }

        [Then(@"I Refereshed whole EAM Application")]
        public void ThenIRefereshedWholeEAMApplication()
        {
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(5);
        }


        [Then(@"Verify Home Page Second time Letter count for Confirmation of Disenrollment Due to Passive Enrollment into a Medicare-Medicaid Plan queue")]
        public void ThenVerifyHomePageSecondTimeLetterCountForConfirmationOfDisenrollmentDueToPassiveEnrollmentIntoAMedicare_MedicaidPlanQueue(Table table)
        {
            tmsWait.Hard(10);
            Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_EamNavigation_lnkHome")).Click();
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.Letters.LettersQueueTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            try
                            {
                                if (bThisRowMatches)
                                {
                                    IWebElement thisEditTD = ApplicationRow.Element[0];
                                    IWebElement thisEditLink = thisEditTD.FindElement(By.XPath("//a[contains(@href,'reports/reportmain_letterqueue.aspx?code=030&type=2')]"));
                                    GlobalRef.secondLetterCount = thisEditLink.Text;
                                    Console.WriteLine("Second Letter Count for Confirmation of Disenrollment Due to Passive Enrollment into a Medicare-Medicaid Plan queue" + thisEditLink.Text);
                                    tmsWait.Hard(2);


                                }
                            }
                            catch
                            {
                                GlobalRef.secondLetterCount = "0";
                            }
                            string fieldName = "letters in Confirmation of Disenrollment Due to Passive Enrollment into a Medicare-Medicaid Plan queue";

                            int InitialLetterCount = Convert.ToInt32(GlobalRef.InitialLetterCount.ToString());
                            int secondLetterCount = Convert.ToInt32(GlobalRef.secondLetterCount.ToString());


                            Assert.AreEqual(true, (secondLetterCount>InitialLetterCount), "Field " + fieldName + " value is [" + secondLetterCount + "], Before Count [" + InitialLetterCount + "]");
                            fw.ConsoleReport("   Verification Point: Field " + fieldName + " Current Letter count value is [" + secondLetterCount + "], Before Count [" + InitialLetterCount + "] - Home page Letter Count should be increased.");



                        

                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.Letters.LettersQueueTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

        [Then(@"Verify Home Page Initial Letter count for Confirmation of Disenrollment Due to Passive Enrollment into a Medicare-Medicaid Plan")]
        public void ThenVerifyHomePageInitialLetterCountForConfirmationOfDisenrollmentDueToPassiveEnrollmentIntoAMedicare_MedicaidPlan()
        {
            IJavaScriptExecutor js = Browser.Wd as IJavaScriptExecutor;
            var ele = (string) js.ExecuteScript("return document.getElementById('ctl00_ctl00_MainMasterContent_MainContent_QueuesCtr1_Table2')");
            var len= (int)js.ExecuteScript("return document.getElementById('ctl00_ctl00_MainMasterContent_MainContent_QueuesCtr1_Table2').getElementsByTagName('tr').length");
            var text= js.ExecuteScript("return document.getElementById('ctl00_ctl00_MainMasterContent_MainContent_QueuesCtr1_Table2').getElementsByTagName('tr')[i].getElementsByTagName('td')[1].textContent");

            for (int i = 0;i<len;i++)
            {

            }

            //var ele = document.getElementById('ctl00_ctl00_MainMasterContent_MainContent_QueuesCtr1_Table2');
            //var len = ele.getElementsByTagName('tr').length;
            //var texts = [];
            //var i;
            //for (i = 0; i < len; i++)
            //{
            //    var text = ele.getElementsByTagName('tr')[i].getElementsByTagName('td')[1].textContent;
            //    texts.push(text);
            //}
            //console.log(texts);



            //if (value == null)
            //{
            //    fw.ConsoleReport(" Element is not found on View Edit Member page");
            //}
            //else
            //{
            //    fw.ConsoleReport(" Element is found on View Edit Member page");
            //}

            
        }


        [Then(@"Verify Home Page Initial Letter count for Confirmation of Disenrollment Due to Passive Enrollment into a Medicare-Medicaid Plan queue")]
        public void ThenVerifyHomePageInitialLetterCountForConfirmationOfDisenrollmentDueToPassiveEnrollmentIntoAMedicare_MedicaidPlanQueue()
        {
            bool flag = true;
            IList<IWebElement> letter = Browser.Wd.FindElements(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_QueuesCtr1_Table2']//td[2]"));

            foreach(IWebElement let in letter)
            {
                if(let.Text.Equals("letters in Confirmation of Disenrollment Due to Passive Enrollment into a Medicare-Medicaid Plan queue"))
                {
                    IWebElement thisEditLink = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'reports/reportmain_letterqueue.aspx?code=030&type=2')]"));
                    GlobalRef.InitialLetterCount = Int32.Parse(thisEditLink.Text);
                    Console.WriteLine("Initial Letter Count for Confirmation of Disenrollment Due to Passive Enrollment into a Medicare-Medicaid Plan queue " + thisEditLink.Text);
                    tmsWait.Hard(2);
                    flag = false;
                    break;
                }
            }

            if(flag)
            {
                GlobalRef.InitialLetterCount = 0;
                Console.WriteLine("Initial Letter Count for Confirmation of Disenrollment Due to Passive Enrollment into a Medicare-Medicaid Plan queue" + GlobalRef.InitialLetterCount.ToString());
            }
        }


        [Then(@"Verify Home Page Initial Letter count for Confirmation of Disenrollment Due to Passive Enrollment into a Medicare-Medicaid Plan queue table")]
        public void ThenVerifyHomePageInitialLetterCountForConfirmationOfDisenrollmentDueToPassiveEnrollmentIntoAMedicare_MedicaidPlanQueueTable(Table table)
        {

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.Letters.LettersQueueTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            try
                            {
                                if (bThisRowMatches)
                                {
                                    IWebElement thisEditTD = ApplicationRow.Element[0];
                                    IWebElement thisEditLink = thisEditTD.FindElement(By.XPath("//a[contains(@href,'reports/reportmain_letterqueue.aspx?code=030&type=2')]"));
                                    GlobalRef.InitialLetterCount = Int32.Parse(thisEditLink.Text);
                                    Console.WriteLine("Initial Letter Count for Confirmation of Disenrollment Due to Passive Enrollment into a Medicare-Medicaid Plan queue" + thisEditLink.Text);
                                    tmsWait.Hard(2);


                                }
                            }
                            catch
                            {
                                GlobalRef.LetterCount = 0;
                            }


                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.Letters.LettersQueueTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }

        }

        [Then(@"Verify Home Page Count for Confirmation of Cancellation of Enrollment Due to Notice from CMS \(TRC (.*)\) queue table is decreased")]
        public void ThenVerifyHomePageCountForConfirmationOfCancellationOfEnrollmentDueToNoticeFromCMSTRCQueueTableIsDecreased(int p0)
        {
            string fieldName = "Letter Count for Confirmation of Cancellation of Enrollment Due to Notice from CMS (TRC 015) queue";

            IWebElement thisEditLink = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'reports/reportmain_letterqueue.aspx?code=031&type=2')]"));
            GlobalRef.DecreaseLetterCount = thisEditLink.Text;
            Console.WriteLine("Final Letter Count for Confirmation of Cancellation of Enrollment Due to Notice from CMS (TRC 015) queue" + thisEditLink.Text);
            tmsWait.Hard(2);
            int InitialLetterCount = Convert.ToInt32(GlobalRef.InitialLetterCount.ToString());
            int DecreaseLetterCount = Convert.ToInt32(GlobalRef.DecreaseLetterCount.ToString());
           

            Assert.AreEqual(true, (DecreaseLetterCount<InitialLetterCount), "Field " + fieldName + " value is [" + DecreaseLetterCount + "], Before Count [" + InitialLetterCount + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " Current Letter count value is [" + DecreaseLetterCount + "], Before Count [" + InitialLetterCount + "] - Home page Letter Count should be decreased.");



        }


        [Then(@"Verify Home Page Count for Confirmation of Cancellation of Enrollment Due to Notice from CMS \(TRC (.*)\) queue table is increased")]
        public void ThenVerifyHomePageCountForConfirmationOfCancellationOfEnrollmentDueToNoticeFromCMSTRCQueueTableIsIncreased(int p0)
        {
            string fieldName = "Letter Count for Confirmation of Cancellation of Enrollment Due to Notice from CMS (TRC 015) queue";
          
            IWebElement thisEditLink = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'reports/reportmain_letterqueue.aspx?code=031&type=2')]"));
            GlobalRef.FinalLetterCount = Int32.Parse(thisEditLink.Text);
            Console.WriteLine("Final Letter Count for Confirmation of Cancellation of Enrollment Due to Notice from CMS (TRC 015) queue" + thisEditLink.Text);
            tmsWait.Hard(2);
            int InitialLetterCount = Convert.ToInt32(GlobalRef.InitialLetterCount.ToString());
            int FinalLetterCount = Convert.ToInt32(GlobalRef.FinalLetterCount.ToString());
            

            Assert.AreEqual(true, (FinalLetterCount > InitialLetterCount), "Field " + fieldName + " value is [" + FinalLetterCount + "], Before Count [" + InitialLetterCount + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " Current Letter count value is [" + FinalLetterCount + "], Before Count [" + InitialLetterCount + "] - Home page Letter Count should be Increased.");

        }

        [Then(@"Verify Home Page Count for Confirmation of Disenrollment Due to Passive Enrollment into a Medicare-Medicaid Plan queue is increased")]
        public void ThenVerifyHomePageCountForConfirmationOfDisenrollmentDueToPassiveEnrollmentIntoAMedicare_MedicaidPlanQueueIsIncreased()
        {
            string fieldName = "Letter Count for Confirmation of Disenrollment Due to Passive Enrollment into a Medicare-Medicaid Plan queue";
            var ScenarioInitialLetterCount = GlobalRef.InitialLetterCount;
            int InitialLetterCount = Convert.ToInt32(ScenarioInitialLetterCount.ToString());
            var ScenarioFinalLetterCount = GlobalRef.FinalLetterCount;
            int FinalLetterCount = Convert.ToInt32(ScenarioFinalLetterCount.ToString());

            Assert.AreEqual(true, (FinalLetterCount > InitialLetterCount), "Field " + fieldName + " value is [" + FinalLetterCount + "], Before Count [" + InitialLetterCount + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " Current Letter count value is [" + FinalLetterCount + "], Before Count [" + InitialLetterCount + "] - Home page Letter Count should be Increased.");
        }

        [Then(@"Verify New Home Page Count for Confirmation of Disenrollment Due to Passive Enrollment into a Medicare-Medicaid Plan queue is increased")]
        public void ThenVerifyNewHomePageCountForConfirmationOfDisenrollmentDueToPassiveEnrollmentIntoAMedicare_MedicaidPlanQueueIsIncreased()
        {
            GlobalRef.FinalLetterCount = Int32.Parse(EAM.LettersPostCMS.LetterCanEnrollNoticeCMS.Text);
            string fieldName = "Letter Count for Confirmation of Disenrollment Due to Passive Enrollment into a Medicare-Medicaid Plan queue";
            var ScenarioInitialLetterCount = GlobalRef.InitialLetterCount;
            int InitialLetterCount = Convert.ToInt32(ScenarioInitialLetterCount.ToString());
            var ScenarioFinalLetterCount = GlobalRef.FinalLetterCount;
            int FinalLetterCount = Convert.ToInt32(ScenarioFinalLetterCount.ToString());

            Assert.AreEqual(true, (FinalLetterCount > InitialLetterCount), "Field " + fieldName + " value is [" + FinalLetterCount + "], Before Count [" + InitialLetterCount + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " Current Letter count value is [" + FinalLetterCount + "], Before Count [" + InitialLetterCount + "] - Home page Letter Count should be Increased.");
        }


        [When(@"Home Queued Items Number Link is clicked for row ""(.*)""")]
        public void WhenHomeQueuedItemsNumberLinkIsClickedForRow(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            Boolean bFoundItem = false;
            string allItems = "";
            IList<IWebElement> TableTRList = EAM.Letters.LettersQueueTable.FindElements(By.TagName("tr"));
            foreach (IWebElement thisTR in TableTRList)
            {
                IList<IWebElement> theseTDs = thisTR.FindElements(By.TagName("td"));
                foreach (IWebElement thisTD in theseTDs)
                {
                    allItems += thisTD.Text;
                    if (thisTD.Text == value)
                    {
                        theseTDs[0].FindElement(By.TagName("a")).Click();
                        tmsWait.Hard(2);
                        bFoundItem = true;
                        break;
                    }
                }
                if (bFoundItem)
                {
                    break;
                }
            }
            Assert.AreEqual(true, bFoundItem, "Expected to find Home page table item [" + value + "] and click the link.  Couldn't find the link in [" + allItems + "]");
        }
        [When(@"Home Queued Items Number Link is stored in variable ""(.*)"" for row ""(.*)""")]
        public void WhenHomeQueuedItemsNumberLinkIsStoredInVariableForRow(string p0, string p1)
        {
            string value = tmsCommon.GenerateData(p0);
            Boolean bFoundItem = false;
            string allItems = "";

            IList<IWebElement> TableTRList = EAM.Letters.LettersQueueTable.FindElements(By.TagName("tr"));
            foreach (IWebElement thisTR in TableTRList)
            {
                IList<IWebElement> theseTDs = thisTR.FindElements(By.TagName("td"));
                foreach (IWebElement thisTD in theseTDs)
                {
                    allItems += thisTD.Text;
                    if (thisTD.Text == value)
                    {
                        fw.setVariable(p0, theseTDs[0].FindElement(By.TagName("a")).Text);
                        bFoundItem = true;
                        break;
                    }
                }
            }
            Assert.AreEqual(true, bFoundItem, "Expected to find Home page table item [" + value + "] and click the link.  Couldn't find the link in [" + allItems + "]");
        }


        [Then(@"Verify updated member with HIC ""(.*)"" is appeared in OOA queue twice")]
        public void ThenVerifyUpdatedMemberWithHICIsAppearedInOOAQueueTwice(string hic)
        {
            int count = 0;
            ArrayList tdCollection = new ArrayList();
            ArrayList tdCollectionData = new ArrayList();
            IWebElement objWebTable = EAM.EAMHomePage.queueTable;
            ICollection<IWebElement> rows = objWebTable.FindElements(By.TagName("tr"));
            foreach (IWebElement row in rows)
            {
                ICollection<IWebElement> cells = row.FindElements(By.XPath("td"));
                foreach (IWebElement cell in cells)
                {
                    tdCollectionData.Add(cell.Text);
                }
            }
            foreach (string data in tdCollectionData)
            {
                if (data.Equals(hic))
                {
                    count++;
                }
            }
            Assert.AreEqual(count, 2, "Mismatch");
        }

        [Then(@"Home Page ""(.*)"" is opened")]
        public void ThenHomePageIsOpened(string letter)
        {

            IList<IWebElement> tdList = EAM.EAMHomePage.QueuedItemsTable.FindElements(By.TagName("td"));
            IWebElement lastItem = null;
            foreach (IWebElement thisItem in tdList)
            {
                Console.WriteLine(thisItem.Text);
                if (thisItem.Text == letter)
                {
                    IWebElement thisA = lastItem.FindElement(By.TagName("a"));
                    thisA.Click();
                    break;
                }
                else
                {
                    lastItem = thisItem;
                }
            }

    //Daron - 04.12.2016 - The code below was replaced with the code above.
            //While the code below gives the link text etc, it won't click the element or go to the page
            //on FF or IE.   Above, we find all the td's, look for the one with the right label, then
            //click on the preceeding td (which also doesn't work), so we find element on it, to get the 
            //<a> tag and click on that.  This does work.  All of it is odd, I think the original code should
            //have worked... but it doesn't.   Thus the change and this message.
    //        Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + letter + "')]//preceding-sibling::td")).Click();
        }

        [Then(@"Letter Queue Page Plan ID ""(.*)"" is selected")]
        public void ThenLetterQueuePagePlanIDIsSelected(string plan)
        {
            SelectElement planID = new SelectElement(EAM.EAMHomePage.PlanIDDropdown);
            planID.SelectByText(plan);
        }

        [Then(@"Letter Queue Page PBP ""(.*)"" is selected")]
        public void ThenLetterQueuePagePBPIsSelected(string pbp)
        {
            SelectElement pbpDropdown = new SelectElement(EAM.EAMHomePage.PBPDropdown);
            pbpDropdown.SelectByText(pbp);
        }
        [When(@"EAM Home page Noting the ""(.*)"" Letter count")]
        public void WhenEAMHomePageNotingTheLetterCount(string p0)
        {
            tmsWait.Hard(5);
            IWebElement letterCount;
            int beforeLetterCount;

            if (ConfigFile.tenantType == "tmsx")
            {
                string OnDemandletterCount = Browser.Wd.FindElement(By.XPath("//label[contains(.,'On Demand Letter')]/parent::div/preceding-sibling::div/a")).Text;
                beforeLetterCount = Convert.ToInt32(OnDemandletterCount);
                fw.ConsoleReport(" Letter Count Before Proceed Actions " + beforeLetterCount);
                GlobalRef.LetterCountBEF = beforeLetterCount;
            }
            else
            {
                letterCount = Browser.Wd.FindElement(By.XPath("//div[@id='onDemandLetter']/div/div/a"));
                beforeLetterCount = Convert.ToInt32(letterCount.Text);
                fw.ConsoleReport(" Letter Count Before Proceed Actions " + beforeLetterCount);
                GlobalRef.LetterCountBEF = beforeLetterCount;
            }

        }


        [When(@"EAM Home page Noting the Letter count for ""(.*)""")]
        public void WhenEAMHomePageNotingTheLetterCountFor(string name)
        {
            tmsWait.Hard(5);
            IWebElement letterCount = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_QueuesCtr1_Table2']//tr/td[contains(.,'" + name + "')]/preceding-sibling::td/a"));
            int beforeLetterCount = Convert.ToInt32(letterCount.Text);

            fw.ConsoleReport(" Letter Count Before Proceed Actions " + beforeLetterCount);
            GlobalRef.LetterCountBEF = beforeLetterCount;
        }

        [When(@"EAM Home page notify the count for letter ""(.*)""")]
        public void WhenEAMHomePageNotifyTheCountForLetter(string name)
        {

            string beforeLetterCount = "";
            if (name.Equals("Transactions in the Missing required CMS fields queue"))
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    By link = By.XPath("(//i[@test-id='eamDashboard-img-activity'])");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(link);
                }
                else
                {
                    By link = By.XPath("(//img[@test-id='eamDashboard-img-activity'])[1]");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(link);
                }

                 beforeLetterCount = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Transactions in the Missing required CMS fields queue')]/parent::div/preceding-sibling::div/a")).Text;
                

            }

            else
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@test-id='eamDashboard-lbl-letters']")));
                tmsWait.Hard(2);
                beforeLetterCount = Browser.Wd.FindElement(By.XPath("//label[contains(.,'"+name+"')]/parent::div/preceding-sibling::div/a")).Text;
            }

            fw.ConsoleReport(" Letter Count Before Proceed Actions for " + name + " " + beforeLetterCount);
            GlobalRef.LetterCountBefore = beforeLetterCount;




        }


        [Then(@"Verify Home page count for letter ""(.*)"" is unchanged")]
        public void ThenVerifyHomePageLetterCountForIsUnchanged(string lettername)
        {
            int actuallettercount=0, i = 0;
            IWebElement EAMLettersTable = Browser.Wd.FindElement(By.XPath(".//*[@id='ctl00_ctl00_MainMasterContent_MainContent_QueuesCtr1_Table2']/tbody"));
            IReadOnlyCollection<IWebElement> EAMLetters = Browser.Wd.FindElements(By.TagName("tr"));
            foreach (var row in EAMLetters)
            {

                if (i > 11)
                {

                    string MyLetter = row.FindElement(By.XPath("td[2]")).Text;
                    if (MyLetter == lettername)
                    {
                        actuallettercount = Int32.Parse(row.FindElement(By.XPath("td[1]")).Text.ToString());
                        
                        break;
                    }


                }

                i++;
            }

            int previouscount = Int32.Parse(GlobalRef.MyLetterCount.ToString());
            Assert.AreEqual(previouscount, actuallettercount, "Letter count has changed, It should be unchanged");
        }


        [Then(@"Verify Home page count for letter ""(.*)"" is Not changed")]
        public void ThenVerifyHomePageCountForLetterIsNotChanged(string name)
        {
            tmsWait.Hard(5);

            IWebElement letterCount = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_QueuesCtr1_Table2']//tr/td[contains(.,'" + name + "')]/preceding-sibling::td/a"));
            int afterLetterCount = Convert.ToInt32(letterCount.Text);

            fw.ConsoleReport(" Letter Count Before Proceed Actions " + afterLetterCount);

           

            int previouscount = Int32.Parse(GlobalRef.LetterCountBefore.ToString());
            Assert.AreEqual(previouscount, afterLetterCount, "Letter count has increased");
            



           

        }

    [Then(@"Verify Home page count for letter ""(.*)"" is changed")]
        public void ThenVerifyHomePageCountForLetterIsChanged(string name)
        {
            
           
            
            if (name.Equals("Transactions in the Missing required CMS fields queue"))
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    By link = By.XPath("(//i[@test-id='eamDashboard-img-activity'])");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(link);
                }
                else
                {
                    By link = By.XPath("(//img[@test-id='eamDashboard-img-activity'])[1]");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(link);
                }

                string afterLetterCount = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Transactions in the Missing required CMS fields queue')]/parent::div/preceding-sibling::div/a")).Text;
                fw.ConsoleReport(" Letter Count After Proceed Actions for " + name + " " + afterLetterCount);
                GlobalRef.LetterCountAfter = afterLetterCount;
                int beforeCount = Int32.Parse(GlobalRef.LetterCountBefore.ToString());
                int afterCount = Int32.Parse(GlobalRef.LetterCountAfter.ToString());

                bool res = afterCount > beforeCount;
                Assert.IsTrue(res, "Letter count has not changed, It should be changed");
            }



           
        }


        [Then(@"Verify Home page Letter count After Queue for letter ""(.*)"" is changed")]
        [When(@"Verify Home page Letter count After Queue for letter ""(.*)"" is changed")]
        public void ThenVerifyHomePageLetterCountAfterQueueForLetterIsChanged(string name)
        {
            tmsWait.Hard(5);
            IWebElement letterCount = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_QueuesCtr1_Table2']//tr/td[contains(.,'" + name + "')]/preceding-sibling::td/a"));
            int AfterLetterCount = Convert.ToInt32(letterCount.Text);
            
            int BeforeLetterCount= Convert.ToInt32(GlobalRef.LetterCountBEF);
            fw.ConsoleReport(" Letter Count Before Proceed Actions " + BeforeLetterCount);
            fw.ConsoleReport(" Letter Count After Proceed Actions " + AfterLetterCount);

            bool results = (AfterLetterCount > BeforeLetterCount);
            Assert.IsTrue(results, " Letter count is not increased");


        }
        [Then(@"Verify Dashboard Letter page """"(.*)"" Letter count After Queue for letter is changed")]
        public void ThenVerifyDashboardLetterPageLetterCountAfterQueueForLetterIsChanged(string p0)
        {
            int AfterLetterCount;

            if (ConfigFile.tenantType == "tmsx")
            {
                tmsWait.Hard(5);
                string OnDemandletterCount = Browser.Wd.FindElement(By.XPath("//label[contains(.,'On Demand Letter')]/parent::div/preceding-sibling::div/a")).Text;
                AfterLetterCount = Convert.ToInt32(OnDemandletterCount);
            }
            else
            {
                tmsWait.Hard(5);
                IWebElement letterCount = Browser.Wd.FindElement(By.XPath("//div[@id='onDemandLetter']/div/div/a"));
                AfterLetterCount = Convert.ToInt32(letterCount.Text);
            }

            int BeforeLetterCount = Convert.ToInt32(GlobalRef.LetterCountBEF);
            fw.ConsoleReport(" Letter Count Before Proceed Actions " + BeforeLetterCount);
            fw.ConsoleReport(" Letter Count After Proceed Actions " + AfterLetterCount);

            bool results = (AfterLetterCount > BeforeLetterCount);
            Assert.IsTrue(results, " Letter count is not increased");
        }

        [When(@"EAM home page click on letter ""(.*)""")]
        public void WhenEAMHomePageClickOnLetter(string p0)
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[@test-id='eamDashboard-lbl-activity']")));
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + p0 + "')]/parent::div/preceding-sibling::div/a")));
            //IWebElement lettertable = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_QueuesCtr1_Table2']/tbody"));
            //IReadOnlyCollection<IWebElement> lettersname = lettertable.FindElements(By.TagName("tr"));
            //foreach(var lettercount in lettersname)
            //{

            //    IWebElement myletter = lettercount.FindElement(By.XPath("td[2]"));
            //    if(myletter.Text.Equals(p0))
            //    {
            //        IWebElement clickcount = lettercount.FindElement(By.XPath("td[1]/a"));
            //        fw.ExecuteJavascript(clickcount);
            //        break;
            //    }
            //}
        }

        [When(@"EAM SEPaction page notify user created for first transid")]
        public void WhenEAMSEPactionPageNotifyUserCreatedForFirstTransid()
        {
            string user = Browser.Wd.FindElement(By.XPath("(//a[contains(@ng-click,'redirectToTransaction')])[2]")).Text;
            GlobalRef.UserCreated = user;
        }

        [When(@"EAM SEPAction page First Transid is clicked")]
        public void WhenEAMSEPActionPageFirstTransidIsClicked()
        {
            IWebElement firsttransid = Browser.Wd.FindElement(By.XPath("(//a[contains(@ng-click,'redirectToTransaction')])[2]"));
            fw.ExecuteJavascript(firsttransid);
            tmsWait.Hard(3);
        }

        [Then(@"Verify Transaction View Edit page UserEntered is display same as SEPaction page")]
        public void ThenVerifyTransactionViewEditPageUserEnteredIsDisplaySameAsSEPactionPage()
        {
            tmsWait.Hard(2);
            string actualuser = EAM.TransactionsViewEdit.Userentered.Text;
            string expecteduser = GlobalRef.UserCreated.ToString();
            Assert.AreEqual(expecteduser, actualuser, "User Entered are not same");
        }


    }

}
