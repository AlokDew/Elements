﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using System.Diagnostics;
using System.Windows;
using System.Drawing;




namespace TMSoR1
{
    [Binding]
    class TMSTables
    { 
    
    
    }
    [Binding]
    class TablePaging
    {
        public Boolean bNotAtLastPageOfRecords = true;
        public string NextPageLinkText;
        public Boolean bHaveGoodPageLink = false;
        public IWebElement NPL = null;
        public TMSTableRow[] PageTable = new TMSTableRow[500];
        public string ArrayToString(string[] inArr)
        {
            string returnString = "";
            foreach (string thisString in inArr)
            {
                returnString += " [" + thisString + "] ";
            }
            return returnString;
        }

        public void ReportFailOnMatching(TMSTableRow Application, TMSTableRow Gherkin, string[] AppRow, string[] GherkinRow)
        {
            //Report the match, first convert the array back to a string we can read.
            Application.RowIsMatched = true;
            Gherkin.RowIsMatched = true;
            string TR0 = ArrayToString(AppRow);
            string TR1 = ArrayToString(GherkinRow);
            Console.WriteLine("Expected Row Data --- " + TR1);
            Console.WriteLine("Found Row Data --- " + TR0);
            Assert.AreEqual(true, false, "Data Row was found when it was not supposed to be in the table.");
        }
        public void ReportMatching(TMSTableRow Application, TMSTableRow Gherkin, string[] AppRow, string[] GherkinRow)
        {
            //Report the match, first convert the array back to a string we can read.
            Application.RowIsMatched = true;
            Gherkin.RowIsMatched = true;
            string TR0 = ArrayToString(AppRow);
            string TR1 = ArrayToString(GherkinRow);
            Console.WriteLine("Expected Row Data --- " + TR1);
            Console.WriteLine("Found Row Data --- " + TR0);
        }
        public void ReportNotMatching(TMSTableRow[] thisTable)
        {
            int iCount = 0;
            var TableRow = new TMSString();
            foreach (TMSTableRow thisTR in thisTable)
            {
                if (thisTR == null)
                {
                    break;
                }
                if (thisTR.RowIsMatched == false && thisTR.RowIsHeader == false)
                {
                    string thisRowData = ArrayToString(thisTR.Row.ToArray());
                    Console.WriteLine("Unmatched Data Row -- " + thisRowData);

                }
                iCount++;

            }
            Assert.AreEqual(true, false, "Not all expected rows in the Gherkin test table were found in the page table data rows.");
        }
        public void ReportPassOnNotMatching(TMSTableRow[] thisTable)
        {
            int iCount = 0;
            var TableRow = new TMSString();
            foreach (TMSTableRow thisTR in thisTable)
            {
                if (thisTR == null)
                {
                    break;
                }
                if (thisTR.RowIsMatched == false && thisTR.RowIsHeader == false)
                {
                    string thisRowData = ArrayToString(thisTR.Row.ToArray());
                    Console.WriteLine("Unmatched Data Row -- " + thisRowData);
                }
                iCount++;
            }
            Assert.AreEqual(true, true, "Rows in the Gherkin test table were not found in the page table as expected.");
        }

        public void LoadNextGreaterThanPageLink(IWebElement table)
        {
            //Get the spans data, this is the current page number.  Derive the next page number.
            ICollection<IWebElement> myTRs = table.FindElements(By.TagName("tr"));
            NPL = table.FindElement(By.LinkText(">"));
//            table.FindElement(By.LinkText(">")).Click();
            tmsWait.Hard(3);
            try
            {
                //NPL = table.FindElement(By.LinkText(NextPageLinkText));
                bNotAtLastPageOfRecords = true;
                bHaveGoodPageLink = true;

            }
            catch
            {
                bNotAtLastPageOfRecords = true;
                bHaveGoodPageLink = false;
            }
        }


        public void LoadDIVNextPageLink(IWebElement pageSystem,string nextPageClass)
        {
            //Get the spans data, this is the current page number.  Derive the next page number.
            ICollection<IWebElement> pageLIs = pageSystem.FindElements(By.TagName("li"));
            foreach (IWebElement thisLI in pageLIs)
            {
                string thisPageClass = thisLI.GetAttribute("class");
                if (thisLI.GetAttribute("class") == nextPageClass)
                {
                    IWebElement myA = thisLI.FindElement(By.TagName("a"));

                    bNotAtLastPageOfRecords = true;
                    bHaveGoodPageLink = true;
                    NPL = myA;
                }
                if (thisPageClass.Contains("last") && thisPageClass.Contains("disabled"))
                {
                    bNotAtLastPageOfRecords = false;
                    bHaveGoodPageLink = false;
                }
            }

        }
        // Clicking on Last button on Pagination
        public void LoadDIVLastPageLink(IWebElement pageSystem, string nextPageClass)
        {
            //Get the spans data, this is the current page number.  Derive the next page number.
            ICollection<IWebElement> pageLIs = pageSystem.FindElements(By.TagName("li"));
            foreach (IWebElement thisLI in pageLIs)
            {
                string thisPageClass = thisLI.GetAttribute("class");
                if (thisLI.GetAttribute("class") == nextPageClass)
                {
                    IWebElement myA = thisLI.FindElement(By.TagName("a"));
                  
                    myA.Click();
                }
                
            }

        }

        // Verify whether Previous button is disabled
        public void PreviousPageLinkDisable(IWebElement pageSystem,string prevPageClass)
        {
            try
            {
                ICollection<IWebElement> pageLIs = pageSystem.FindElements(By.TagName("li"));
                foreach (IWebElement thisLI in pageLIs)
                {
                    string thisPageClass = thisLI.GetAttribute("class");
                    if (thisLI.GetAttribute("class") == prevPageClass)
                    {
                        Assert.IsTrue(thisLI.GetAttribute("class").Contains("disabled"), "Previous button is disabled");

                    }

                }
            }

            catch(NoSuchElementException e)
            {
                fw.ConsoleReport(" Previous button is not in Disabled status");
                Console.WriteLine(e);
            }
        }


        // Verify whether Last button is disabled
        public void LastPageLinkDisable(IWebElement pageSystem, string lastPageClass)
        {
            try
            {
                ICollection<IWebElement> pageLIs = pageSystem.FindElements(By.TagName("li"));
                foreach (IWebElement thisLI in pageLIs)
                {
                    string thisPageClass = thisLI.GetAttribute("class");
                    if (thisLI.GetAttribute("class") == lastPageClass)
                    {

                        Assert.IsTrue(thisLI.GetAttribute("class").Contains("disabled"), "Last button is disabled");
                        
                    }

                }
            }

            catch (NoSuchElementException e)
            {
                fw.ConsoleReport(" Last button is not in Disabled status");
                Console.WriteLine(e);
            }
        }

        public void LoadNextPageLink(IWebElement table)
        {
            //Get the spans data, this is the current page number.  Derive the next page number.
            ICollection<IWebElement> myTRs = table.FindElements(By.TagName("tr"));
            ICollection<IWebElement> mySpans = null;
            foreach (IWebElement thisTR in myTRs)
            {
             //   if (thisTR.GetAttribute("class") == "pager")
                if (thisTR.GetAttribute("class").Contains("pager"))
                {
                    mySpans = thisTR.FindElements(By.TagName("span"));
                }
            }
            if (mySpans != null)
            {
                foreach (IWebElement thisSpan in mySpans)
                {
                    int CurrentPageNumber = Convert.ToInt16(thisSpan.Text);
                    int NextPageNumber = CurrentPageNumber + 1;
                    NextPageLinkText = NextPageNumber.ToString();
                }
            }
            else 
            {
                bNotAtLastPageOfRecords = true;
                bHaveGoodPageLink = false;
            }
            //Find the link for the next page.  (for later)
            try
            {
                NPL = table.FindElement(By.LinkText(NextPageLinkText));
                bNotAtLastPageOfRecords = true;
                bHaveGoodPageLink = true;

            }
            catch
            {
                bNotAtLastPageOfRecords = true;
                bHaveGoodPageLink = false;
            }
        }


        public void LoadDIVPageTable(IWebElement table, string rowClass, string colClass)
        {

            ICollection<IWebElement> allTableDivs = table.FindElements(By.TagName("div"));


            string tableText = table.Text;
            tableText = tableText.Replace("\r\n", "|");

            string[] tableArray = tableText.Split('|');
            int dataElementPerRowCount = 3;
            int rowCount = tableArray.Count() / dataElementPerRowCount;
            int DataElement = 0;
            for (int i = 0; i < rowCount; i++)
            {
                PageTable[i] = new TMSTableRow();
                PageTable[i].RowIsMatched = false;
                PageTable[i].RowIsHeader = false;
                PageTable[i].RowIsData = true;
                for (int j = 0; j < dataElementPerRowCount; j++)
                {
                    PageTable[i].Row.Add(tableArray[DataElement]);
                    DataElement++;
                }

            }
        }

        public void LoadAngularDIVPageTable(IWebElement table, string rowClass, string colClass)
        {

            ICollection<IWebElement> allTableDivs = table.FindElements(By.TagName("div"));


            string tableText = table.Text;
            tableText = tableText.Replace("\r\n", "|");

            string[] tableArray = tableText.Split('|');
            int dataElementPerRowCount = 4;
            int rowCount = tableArray.Count() / dataElementPerRowCount;
            int DataElement = 0;
            for (int i = 0; i < rowCount; i++)
            {
                PageTable[i] = new TMSTableRow();
                PageTable[i].RowIsMatched = false;
                PageTable[i].RowIsHeader = false;
                PageTable[i].RowIsData = true;
                for (int j = 0; j < dataElementPerRowCount; j++)
                {
                    PageTable[i].Row.Add(tableArray[DataElement]);
                    DataElement++;
                }

            }
        }


        /// <summary>
        /// This will handle HIC Name search results in FRM UI Application
        /// </summary>
        /// <param name="table"></param>
        /// <param name="rowClass"></param>
        /// <param name="colClass"></param>
        public void LoadAngularHICNameSearchTable(IWebElement table, string rowClass, string colClass)
        {

            ICollection<IWebElement> allTableDivs = table.FindElements(By.TagName("div"));


            string tableText = table.Text;
            tableText = tableText.Replace("\r\n", "|");

            string[] tableArrayOld = tableText.Split('|');
            List<string> list = new List<string>(tableArrayOld);
            if (list.Contains("View"))
            {
                list.Remove("View");
            }
            else if (list.Contains("Select"))
            {
                list.Remove("Select");

            }

            string[] tableArray = list.ToArray();
            int dataElementPerRowCount = 4;
            int rowCount = tableArray.Count() / dataElementPerRowCount;
            int DataElement = 0;
            for (int i = 0; i < rowCount; i++)
            {
                PageTable[i] = new TMSTableRow();
                PageTable[i].RowIsMatched = false;
                PageTable[i].RowIsHeader = false;
                PageTable[i].RowIsData = true;
                for (int j = 0; j < dataElementPerRowCount; j++)
                {
                    PageTable[i].Row.Add(tableArray[DataElement]);
                    DataElement++;
                }

            }
        }

        
        /// <summary>
        /// This will handle HIC Name search results in FRM UI Application
        /// </summary>
        /// <param name="table"></param>
        /// <param name="rowClass"></param>
        /// <param name="colClass"></param>
        public void LoadRSMApplicationTable(IWebElement table, string rowClass, string colClass,string section)
        {
            int dataElementPerRowCount = 0;

           
            if(section.Equals("Demographic HCCs on File for Member"))
            {
                dataElementPerRowCount = 13;
            }
            else if(section.Equals("Clinical HCCs on File for Member"))
                {
                dataElementPerRowCount = 8;
                }
            ICollection<IWebElement> allTableDivs = table.FindElements(By.TagName("div"));


            string tableText = table.Text;
            tableText = tableText.Replace("\r\n", "|");

            string[] tableArray = tableText.Split('|');          
            int rowCount = tableArray.Count() / dataElementPerRowCount;
            int DataElement = 0;
            for (int i = 0; i < rowCount; i++)
            {
                PageTable[i] = new TMSTableRow();
                PageTable[i].RowIsMatched = false;
                PageTable[i].RowIsHeader = false;
                PageTable[i].RowIsData = true;
                for (int j = 0; j < dataElementPerRowCount; j++)
                {
                    PageTable[i].Row.Add(tableArray[DataElement]);
                    DataElement++;
                }

            }


        }

        /// <summary>
        /// Top 50 Under Over Payment Search table
        /// </summary>
        /// <param name="table"></param>
        /// <param name="rowClass"></param>
        /// <param name="colClass"></param>
        public void LoadTOPFiftyDIVPageTable(IWebElement table, string rowClass, string colClass)
        {

            ICollection<IWebElement> allTableDivs = table.FindElements(By.TagName("div"));


            string tableText = table.Text;
            tableText = tableText.Replace("\r\n", "|");

            string[] tableArray = tableText.Split('|');


            List<string> list = new List<string>(tableArray);
            if (list.Contains("View"))
            {
                list.Remove("View");
            }
            else if (list.Contains("Select"))
            {
                list.Remove("Select");

            }


            //
            //  list.Sort();

            string[] tableArrayNew=list.ToArray();

            int dataElementPerRowCount = 2;
            int rowCount = tableArrayNew.Count() / dataElementPerRowCount;
            int DataElement = 0;
            for (int i = 0; i < rowCount; i++)
            {
                PageTable[i] = new TMSTableRow();
                PageTable[i].RowIsMatched = false;
                PageTable[i].RowIsHeader = false;
                PageTable[i].RowIsData = true;
                for (int j = 0; j < dataElementPerRowCount; j++)
                {
                     PageTable[i].Row.Add(tableArrayNew[DataElement]);
                    DataElement++;
                }
            
            }

      //      ICollection<IWebElement> allTableDivs = table.FindElements(By.TagName("div"));
            //ICollection<IWebElement> rowDivs = table.FindElements(By.TagName("div"));
            //int divCount = allTableDivs.Count;
            ////Establish an array of table rows for the page data.
            ////            TableRow[] thisDataArr = new TableRow[RowCount];
            //int EstablishedRowItemCount = 0;
            //foreach (IWebElement thisDiv in allTableDivs)
            //{
            //    string thisDivClass = thisDiv.GetAttribute("class");
            //    if (thisDivClass.Contains(rowClass))
            //    {
            //        ICollection<IWebElement> colDivs = thisDiv.FindElements(By.TagName("div"));
            //        string RowElements = "";
            //        foreach (IWebElement thisInnerRowDiv in colDivs)
            //        {
            //            string thisInnerDivClass = thisInnerRowDiv.GetAttribute("class");
            //            if (thisInnerDivClass.Contains(colClass))
            //            {
            //                ICollection<IWebElement> contentDivs = thisInnerRowDiv.FindElements(By.TagName("div"));
            //                foreach (IWebElement thisContentDiv in contentDivs)
            //                {
            //                    if (thisInnerDivClass.Contains("contents"))
            //                    {
            //                        RowElements += thisInnerDivClass.ToString();
            //                    }
            //                }
            //            }
            //        }
            //        Console.WriteLine("New Row ["+ RowElements +"]");
            //    }
            //}

            //int iRowCounter = 0;
            //IWebElement lastElementHolder = null;
            //foreach (IWebElement thisRow in rowDivs)
            //{
            //    string rowClassTag = thisRow.GetAttribute("class");
            //    Boolean skipRow = false;
            //    if (rowClassTag != null)
            //    {
            //        if (rowClassTag == "pgn")
            //        {
            //            skipRow = true;
            //        }
            //    }
            //    if (!skipRow)
            //    {

            //        //if (thisRow.Text == "Canceled")
            //        //{
            //        //    Console.WriteLine("Transaction 61 is updated to Canceled Status");
            //        //    break;
            //        //}
            //        //For each new data row we look at, add a new instance of the class to the array.
            //        PageTable[iRowCounter] = new TMSTableRow();
            //        PageTable[iRowCounter].RowIsHeader = true;
            //        PageTable[iRowCounter].RowIsData = false;
            //        PageTable[iRowCounter].RowIsMatched = false;
            //        //Get all of the elements from the row (<td>)
            //        ICollection<IWebElement> myElements = null;
            //        if (iRowCounter == 0 && rowClass != "")
            //        {
            //            myElements = thisRow.FindElements(By.TagName(rowClass));
            //        }
            //        else
            //        {
            //            myElements = thisRow.FindElements(By.TagName(colClass));
            //        }
            //        //Row 0 is the header
            //        //The rest of the rows are data
            //        int elementCount = 0;
            //        foreach (IWebElement thisElement in myElements)
            //        {

            //            elementCount++;
            //            lastElementHolder = thisElement;
            //            if (iRowCounter == 0 && rowClass != "")
            //            {
            //                //Finding the normal item count because the page numbers are a data row.
            //                //Row 0 is the header
            //                EstablishedRowItemCount = myElements.Count;
            //                PageTable[iRowCounter].RowIsHeader = true;
            //                PageTable[iRowCounter].RowIsData = false;
            //            }
            //            else
            //            {
            //                //Other rows are data
            //                PageTable[iRowCounter].RowIsHeader = false;
            //                PageTable[iRowCounter].RowIsData = true;
            //            }
            //            if (myElements.Count == EstablishedRowItemCount || EstablishedRowItemCount == 0)
            //            {
            //                if (EstablishedRowItemCount == 0)
            //                {
            //                    EstablishedRowItemCount = myElements.Count;
            //                }
            //                PageTable[iRowCounter].Row.Add(thisElement.Text.ToString());
            //                PageTable[iRowCounter].Element.Add(thisElement);
            //            }
            //            else
            //            {
            //                //If this row count isn't the right number of items, we didn't match with expected.
            //                PageTable[iRowCounter].RowIsData = false;
            //            }
            //        }
            //        iRowCounter++;
            //    }
            //}
        }


        public void LoadRSMGrid(IWebElement table, int headercnt, string rowClass, string colClass)
        {

            ICollection<IWebElement> allTableDivs = table.FindElements(By.TagName("div"));


            string tableText = table.Text;
            tableText = tableText.Replace("\r\n", "|");

            string[] tableArray = tableText.Split('|');


            List<string> list = new List<string>(tableArray);
            if (list.Contains("View"))
            {
                list.Remove("View");
            }
            else if (list.Contains("Select"))
            {
                list.Remove("Select");

            }
            else if (list.Contains("Details"))
            {
                list.Remove("Details");

            }


            //
            //  list.Sort();

            string[] tableArrayNew = list.ToArray();
            int dataElementPerRowCount = headercnt;
            int rowCount = tableArrayNew.Count() / dataElementPerRowCount;
            int DataElement = 0;
            for (int i = 0; i < rowCount; i++)
            {
                PageTable[i] = new TMSTableRow();
                PageTable[i].RowIsMatched = false;
                PageTable[i].RowIsHeader = false;
                PageTable[i].RowIsData = true;
                for (int j = 0; j < dataElementPerRowCount; j++)
                {
                    PageTable[i].Row.Add(tableArrayNew[DataElement]);
                    DataElement++;
                }

            }
        }

        public void loadRSMAngularTable(IWebElement table)
        {
            ICollection<IWebElement> myRows = table.FindElements(By.XPath("//div[@test-id='clinicalDrillDownGrid']//*[contains(@class,'ui-grid-cell-contents')]"));
            int RowCount = myRows.Count;
            int iRowCounter = 0;
            PageTable[iRowCounter] = new TMSTableRow();
            PageTable[iRowCounter].RowIsHeader = true;
            PageTable[iRowCounter].RowIsData = false;
            PageTable[iRowCounter].RowIsMatched = false;
            int EstablishedRowItemCount = 0;

            int headcount = 0;
            int rowcount = 0;
            ICollection<IWebElement> myElements = null;
            IWebElement rowelement = null;
            foreach (IWebElement thisRow in myRows)
            {
               
                // Adding Header element

                if (headcount < 9)
                {
                    if (thisRow.GetAttribute("class").Equals("ui-grid-cell-contents"))
                    {
                        myElements = thisRow.FindElements(By.TagName("span"));

                        EstablishedRowItemCount = myElements.Count;
                        PageTable[iRowCounter].RowIsHeader = true;
                        PageTable[iRowCounter].RowIsData = false;
                        foreach (IWebElement thisElement in myElements)
                        {
                            if (thisElement.Text.ToString() != "")
                            {
                                PageTable[iRowCounter].Row.Add(thisElement.Text.ToString());
                                PageTable[iRowCounter].Element.Add(thisElement);
                            }
                        }
                    }
                    if (PageTable[iRowCounter].Element.Count == 9)
                    {
                        iRowCounter++;
                        PageTable[iRowCounter] = new TMSTableRow();
                    }

                }
                // Adding Rows  
                

                if (iRowCounter > 0)
                {
                    
                    if (PageTable[iRowCounter] != null)
                    {
                        //PageTable[0].RowIsHeader = false;
                        //PageTable[0].RowIsData = true;

                        if (thisRow.GetAttribute("class").Equals("ui-grid-cell-contents ng-binding ng-scope"))
                        {
                            PageTable[iRowCounter].RowIsHeader = false;
                            PageTable[iRowCounter].RowIsData = true;

                            if (rowcount < 9)
                            {
                                rowelement = thisRow;

                                PageTable[iRowCounter].Row.Add(rowelement.Text.ToString());
                                PageTable[iRowCounter].Element.Add(rowelement);
                                rowcount++;
                            }
                            if (PageTable[iRowCounter].Element.Count == 9)
                            {
                                iRowCounter++;
                                PageTable[iRowCounter] = new TMSTableRow();
                            }
                        }
                    }
                }
                headcount++;

            } //  end for foreach loop

            iRowCounter++;


        }


        public void LoadPlanStarPageTable(IWebElement table, string headerTag, string bodyTag)
        {
            ICollection<IWebElement> myRows = table.FindElements(By.TagName("tr"));
            int RowCount = myRows.Count;
            //Establish an array of table rows for the page data.
            //            TableRow[] thisDataArr = new TableRow[RowCount];
            int EstablishedRowItemCount = 0;
            int iRowCounter = 0;
            IWebElement lastElementHolder = null;
            foreach (IWebElement thisRow in myRows)
            {
                string rowClassTag = thisRow.GetAttribute("class");
                Boolean skipRow = false;
                if (rowClassTag != null)
                {
                    if (rowClassTag == "pgn")
                    {
                        skipRow = true;
                    }
                }
                if (!skipRow)
                {

                    //if (thisRow.Text == "Canceled")
                    //{
                    //    Console.WriteLine("Transaction 61 is updated to Canceled Status");
                    //    break;
                    //}
                    //For each new data row we look at, add a new instance of the class to the array.
                    PageTable[iRowCounter] = new TMSTableRow();
                    PageTable[iRowCounter].RowIsHeader = true;
                    PageTable[iRowCounter].RowIsData = false;
                    PageTable[iRowCounter].RowIsMatched = false;
                    //Get all of the elements from the row (<td>)
                    ICollection<IWebElement> myElements = null;
                    if (iRowCounter == 0 && headerTag != "")
                    {
                        myElements = thisRow.FindElements(By.TagName(headerTag));
                    }
                    else
                    {
                        myElements = thisRow.FindElements(By.TagName(bodyTag));
                    }
                    //Row 0 is the header
                    //The rest of the rows are data
                    int elementCount = 0;
                    foreach (IWebElement thisElement in myElements)
                    {

                        elementCount++;
                        lastElementHolder = thisElement;
                        if (iRowCounter == 0 && headerTag != "")
                        {
                            //Finding the normal item count because the page numbers are a data row.
                            //Row 0 is the header
                            EstablishedRowItemCount = myElements.Count;
                            PageTable[iRowCounter].RowIsHeader = true;
                            PageTable[iRowCounter].RowIsData = false;
                        }
                        else
                        {
                            //Other rows are data
                            PageTable[iRowCounter].RowIsHeader = false;
                            PageTable[iRowCounter].RowIsData = true;
                        }
                        if (myElements.Count == EstablishedRowItemCount || EstablishedRowItemCount == 0)
                        {
                            if (EstablishedRowItemCount == 0)
                            {
                                EstablishedRowItemCount = myElements.Count;
                            }
                            PageTable[iRowCounter].Row.Add(thisElement.Text.ToString());
                            PageTable[iRowCounter].Element.Add(thisElement);
                        }
                        else
                        {
                            //If this row count isn't the right number of items, we didn't match with expected.
                            PageTable[iRowCounter].RowIsData = false;
                        }
                    }
                    iRowCounter++;
                }
            }
        }

        public void LoadGroupdSearchGrid(IWebElement table, string headerTag, string bodyTag)
        {


            IList<IWebElement> myRows = table.FindElements(By.XPath("//div[@test-id='grouplookup-grid-groupLoookupGrid']//*[contains(@class,'ui-grid-cell-contents')]"));



            int RowCount = myRows.Count;
            int iRowCounter = 0;
            PageTable[iRowCounter] = new TMSTableRow();
            PageTable[iRowCounter].RowIsHeader = true;
            PageTable[iRowCounter].RowIsData = false;
            PageTable[iRowCounter].RowIsMatched = false;

            int headcount = 0;
            int rowcount = 0;
            ICollection<IWebElement> myElements = null;
            IWebElement rowelement = null;
            IWebElement emptyElement = null;

            foreach (IWebElement thisRow in myRows)
            {

                // Adding Header element


                if (table.GetAttribute("class").Equals("ui-grid-header-canvas"))
                {
                    if(thisRow.Text.ToString()=="")
                    {
                        PageTable[iRowCounter].RowIsHeader = true;
                        PageTable[iRowCounter].RowIsData = false;
                        PageTable[iRowCounter].Row.Add(thisRow.Text.ToString());
                        PageTable[iRowCounter].Element.Add(thisRow);

                    }
                    try {

                        if (thisRow.FindElement(By.TagName("span")).Displayed)
                        {
                            myElements = thisRow.FindElements(By.TagName("span"));

                            //if (myElements.Count != 0)
                            //{
                            PageTable[iRowCounter].RowIsHeader = true;
                            PageTable[iRowCounter].RowIsData = false;
                            foreach (IWebElement thisElement in myElements)
                            {
                                if (thisElement.Text.ToString() != "")
                                {
                                    PageTable[iRowCounter].Row.Add(thisElement.Text.ToString());
                                    PageTable[iRowCounter].Element.Add(thisElement);
                                }
                            }
                            //}
                        }
                    }
                    catch
                    {

                    }
                    if (PageTable[iRowCounter].Element.Count == 3)
                    {
                        iRowCounter++;
                        PageTable[iRowCounter] = new TMSTableRow();
                    }

                }
                // Adding Rows  


                if (iRowCounter > 0)
                {
                    if ((thisRow.GetAttribute("class").Equals("ui-grid-selection-row-header-buttons ui-grid-icon-ok ng-scope")) || thisRow.GetAttribute("class").Equals("ui-grid-cell-contents ng-binding ng-scope") || thisRow.GetAttribute("class").Equals("ui-grid-cell-contents ng-scope"))
                    {
                       
                        if (thisRow.GetAttribute("class").Equals("ui-grid-cell-contents"))
                        {
                            if (thisRow.Text.ToString() == "")
                            {
                                PageTable[iRowCounter].RowIsHeader = true;
                                PageTable[iRowCounter].RowIsData = false;
                                PageTable[iRowCounter].Row.Add(thisRow.Text.ToString());
                                PageTable[iRowCounter].Element.Add(thisRow);

                            }

                            PageTable[iRowCounter].RowIsHeader = false;
                            PageTable[iRowCounter].RowIsData = true;
                            PageTable[iRowCounter].Row.Add(emptyElement.Text.ToString());
                            PageTable[iRowCounter].Element.Add(emptyElement);

                        }

                        else
                        {
                            PageTable[iRowCounter].RowIsHeader = false;
                            PageTable[iRowCounter].RowIsData = true;

                            if (rowcount < 2)
                            {
                                rowelement = thisRow;

                                PageTable[iRowCounter].Row.Add(rowelement.Text.ToString());
                                PageTable[iRowCounter].Element.Add(rowelement);
                                rowcount++;
                            }
                        }
                        if (PageTable[iRowCounter].Element.Count == 2)
                        {
                            iRowCounter++;
                            rowcount = 0;
                            PageTable[iRowCounter] = new TMSTableRow();
                        }
                    }
               
                }
                headcount++;

            } //  end for foreach loop

            iRowCounter++;
        }

        public void LoadSearchGrid(IWebElement table, string headerTag, string bodyTag)
        {

            IList<IWebElement> myRows = table.FindElements(By.XPath("//div[@test-id='memberDiscrepancy-grid-resultMemberDiscrepancyGrid']//*[contains(@class,'ui-grid-cell-contents')]"));
                

           
            int RowCount = myRows.Count;
            int iRowCounter = 0;
            PageTable[iRowCounter] = new TMSTableRow();
            PageTable[iRowCounter].RowIsHeader = true;
            PageTable[iRowCounter].RowIsData = false;
            PageTable[iRowCounter].RowIsMatched = false;
            int EstablishedRowItemCount = 0;

            int headcount = 0;
            int rowcount = 0;
            ICollection<IWebElement> myElements = null;
            IWebElement rowelement = null;
            foreach (IWebElement thisRow in myRows)
            {

                // Adding Header element

                if (thisRow.GetAttribute("class").Contains("ui-grid-cell-contents"))
                {
                    if (thisRow.GetAttribute("class").Equals("ui-grid-cell-contents"))
                    {
                        myElements = thisRow.FindElements(By.TagName("span"));

                        EstablishedRowItemCount = myElements.Count;
                        PageTable[iRowCounter].RowIsHeader = true;
                        PageTable[iRowCounter].RowIsData = false;
                        foreach (IWebElement thisElement in myElements)
                        {
                            if (thisElement.Text.ToString() != "")
                            {
                                PageTable[iRowCounter].Row.Add(thisElement.Text.ToString());
                                PageTable[iRowCounter].Element.Add(thisElement);
                            }
                        }
                    }
                    if (PageTable[iRowCounter].Element.Count == 5)
                    {
                        iRowCounter++;
                        PageTable[iRowCounter] = new TMSTableRow();
                    }

                }
                // Adding Rows  


                if (iRowCounter > 0)
                {

                    if ((thisRow.GetAttribute("class").Contains("ui-grid-cell-contents ng-scope")) || (thisRow.GetAttribute("class").Contains("ui-grid-cell-contents ng-binding ng-scope")))
                    {
                        

                        if (thisRow.GetAttribute("class").Equals("ui-grid-cell-contents ng-binding ng-scope") || thisRow.GetAttribute("class").Equals("ui-grid-cell-contents ng-scope"))
                        {
                            PageTable[iRowCounter].RowIsHeader = false;
                            PageTable[iRowCounter].RowIsData = true;

                            if (rowcount < 5)
                            {
                                rowelement = thisRow;

                                PageTable[iRowCounter].Row.Add(rowelement.Text.ToString());
                                PageTable[iRowCounter].Element.Add(rowelement);
                                rowcount++;
                            }
                            if (PageTable[iRowCounter].Element.Count == 5)
                            {
                                iRowCounter++;
                                rowcount = 0;
                                PageTable[iRowCounter] = new TMSTableRow();
                            }
                        }
                    }
                }
                headcount++;

            } //  end for foreach loop

            iRowCounter++;

        }

        public void LoadPageTable(IWebElement table, string headerTag, string bodyTag)
        {
            //Daron 04.05.2016  I think someone changed this to div because the new UI
            //uses div without consideration to EAM.   Should be tr I think.
            ICollection<IWebElement> myRows = table.FindElements(By.TagName("tr"));
//            ICollection<IWebElement> myRows = table.FindElements(By.TagName("div"));
            int RowCount = myRows.Count;
            //Establish an array of table rows for the page data.
            //            TableRow[] thisDataArr = new TableRow[RowCount];
            int EstablishedRowItemCount = 0;
            int iRowCounter = 0;
            IWebElement lastElementHolder = null;
            foreach (IWebElement thisRow in myRows)
            {
                string rowClassTag = thisRow.GetAttribute("class");
                Boolean skipRow = false;
                if (rowClassTag != null)
                {
                    if (rowClassTag == "pgn")
                    {
                        skipRow = true;
                    }
                }
                if (!skipRow)
                {

                    //if (thisRow.Text == "Canceled")
                    //{
                    //    Console.WriteLine("Transaction 61 is updated to Canceled Status");
                    //    break;
                    //}
                    //For each new data row we look at, add a new instance of the class to the array.
                    PageTable[iRowCounter] = new TMSTableRow();
                    PageTable[iRowCounter].RowIsHeader = true;
                    PageTable[iRowCounter].RowIsData = false;
                    PageTable[iRowCounter].RowIsMatched = false;
                    //Get all of the elements from the row (<td>)
                    ICollection<IWebElement> myElements = null;
                    if (iRowCounter == 0 && headerTag != "")
                    {
                        myElements = thisRow.FindElements(By.TagName(headerTag));
                    }
                    else
                    {
                        myElements = thisRow.FindElements(By.TagName(bodyTag));
                    }
                    //Row 0 is the header
                    //The rest of the rows are data
                    int elementCount = 0;
                    foreach (IWebElement thisElement in myElements)
                    {

                        elementCount++;
                        lastElementHolder = thisElement;
                        if (iRowCounter == 0 && headerTag != "")
                        {
                            //Finding the normal item count because the page numbers are a data row.
                            //Row 0 is the header
                            EstablishedRowItemCount = myElements.Count;
                            PageTable[iRowCounter].RowIsHeader = true;
                            PageTable[iRowCounter].RowIsData = false;
                        }
                        else
                        {
                            //Other rows are data
                            PageTable[iRowCounter].RowIsHeader = false;
                            PageTable[iRowCounter].RowIsData = true;
                        }
                        if (myElements.Count == EstablishedRowItemCount || EstablishedRowItemCount == 0)
                        {
                            if (EstablishedRowItemCount == 0)
                            {
                                EstablishedRowItemCount = myElements.Count;
                            }
                            PageTable[iRowCounter].Row.Add(thisElement.Text.ToString());
                            PageTable[iRowCounter].Element.Add(thisElement);
                        }
                        else
                        {
                            //If this row count isn't the right number of items, we didn't match with expected.
                            PageTable[iRowCounter].RowIsData = false;
                        }
                    }
                    iRowCounter++;
                }
            }
        }
        public void LoadGherkinTable(Table table)
        {
            bNotAtLastPageOfRecords = false;
            //Get the table object again, since the page refreshes we need to get it fresh
            IWebElement baseTable = EAM.AdministrationPlanDefinedFields.DisenrollReasonTable;
            //Get the spans data, this is the current page number.  Derive the next page number.
            ICollection<IWebElement> myTRs = baseTable.FindElements(By.TagName("tr"));
            ICollection<IWebElement> mySpans = null;
            foreach (IWebElement thisTR in myTRs)
            {
                if (thisTR.GetAttribute("class") == "pager")
                {
                    mySpans = thisTR.FindElements(By.TagName("span"));
                }
            }
            foreach (IWebElement thisSpan in mySpans)
            {
                int CurrentPageNumber = Convert.ToInt16(thisSpan.Text);
                int NextPageNumber = CurrentPageNumber + 1;
                NextPageLinkText = NextPageNumber.ToString();
            }
            //Find the link for the next page.  (for later)
            try
            {
                NPL = baseTable.FindElement(By.LinkText(NextPageLinkText));
            }
            catch
            {
                bNotAtLastPageOfRecords = true;
                bHaveGoodPageLink = false;
            }
        }
    }
    [Binding]
    class GherkinTable
    {
        public TMSTableRow[] GTable = new TMSTableRow[500];
        public string NextPageLinkText = "";
        public Boolean bNotAtLastPageOfRecords = true;
        public Boolean bHaveGoodPageLink = false;
        public IWebElement NextPageLink = null;

        public void LoadGherkinTable(Table table)
        {

            //Get the Table Header off of the test script Gherkin table
            ICollection<string> thisTH = table.Header;
            int thCount = thisTH.Count;
            string[] thisHeader = new string[thisTH.Count];
            thisTH.CopyTo(thisHeader, 0);   //copies the header to an array

            //Set up an array of classes to hold the table data, first one (0) will be the header info
            //The class has flags for this data row being a header, data and if we have yet matched it in our trials
            TMSTableRow[] thisTableArr = new TMSTableRow[table.RowCount + 1];
            thisTableArr[0] = new TMSTableRow();
            thisTableArr[0].RowIsHeader = true;
            thisTableArr[0].RowIsData = false;
            thisTableArr[0].RowIsMatched = false;
            //Add the header data to the array 0 table row instance
            foreach (string thisString in thisHeader)
            {
                thisTableArr[0].Row.Add( tmsCommon.GenerateData(thisString));
            }
            int iCounter = 1;
            //Add the Gherkin table row data to the array of rows.  These are all data, not headers, not matched yet.
            foreach (var row in table.Rows)
            {
                thisTableArr[iCounter] = new TMSTableRow();
                thisTableArr[iCounter].RowIsHeader = false;
                thisTableArr[iCounter].RowIsData = true;
                thisTableArr[iCounter].RowIsMatched = false;

                for (int c = 0; c < row.Count; c++)
                {
                    thisTableArr[iCounter].Row.Add(tmsCommon.GenerateData(row[c]));
                }
                iCounter++;
            }
            thisTableArr.CopyTo(GTable, 0);
        }
    }
    class TMSTableRow
    {
        public Boolean RowIsData;
        public Boolean RowIsHeader;
        public Boolean RowIsMatched;
        public List<string> Row = new List<string>();
        public List<IWebElement> Element = new List<IWebElement>();

        public Boolean AllRowsMatched(TMSTableRow[] thisArr)
        {
            Boolean thisReturnValue = true;
            int Counter = 0;
            foreach (TMSTableRow a in thisArr)
            {
                if (a != null && a.RowIsMatched == false && Counter > 0)
                {
                    thisReturnValue = false;
                }
                Counter++;
            }
            return thisReturnValue;
        }
    }
}
