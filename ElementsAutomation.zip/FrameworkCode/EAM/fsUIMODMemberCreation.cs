﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using TMSoR1.FrameworkCode;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System.Text.RegularExpressions;

namespace TMSoR1
{
    [Binding]
    class fsUIMODMemberCreation
    {
        [When(@"I have Clicked on Expand All Button")]
        [Then(@"I have Clicked on Expand All Button")]
        public void WhenIHaveClickedOnExpandAllButton()
        {
            ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODMemberCreation.ExpanAllBtn);
            tmsWait.Hard(4);
        }

        [Then(@"EAM View Edit Member page Contact section ""(.*)"" is set to ""(.*)""")]
        public void ThenEAMViewEditMemberPageContactSectionIsSetTo(string p0, string p1)
        {
            string expected = tmsCommon.GenerateData(p1);

        string elements = tmsCommon.GenerateData(p0);
            if (elements.ToLower().Contains("scc"))
            {
                By ele = By.CssSelector("[test-id='memberContacts-input-scc']");
                string actualValue = AngularFunction.getAttributeValue(ele);
                fw.ConsoleReport(" Value " + actualValue);
                AngularFunction.compareExpectedValueWithActual(actualValue, expected);
                fw.setVariable(elements, actualValue);
            }
            if(elements.ToLower().Contains("county"))
            {
                
                By ele = By.XPath("//kendo-dropdownlist[@name='county']//span[@class='k-input']");
                string actualValue = AngularFunction.getText(ele);
                fw.ConsoleReport(" Value " + actualValue);
                AngularFunction.compareExpectedValueWithActual(actualValue, expected);
                fw.setVariable(elements, actualValue);
            }
        }

      

        [When(@"View Edit Members page DOB is set to ""(.*)""")]
        public void WhenViewEditMembersPageDOBIsSetTo(string p0)
        {
            By loc = By.CssSelector("[test-id='memberDemographics-txt-dod']");
            UIMODUtilFunctions.enterValueOnWebElementUsingLocators(loc, p0);
        }

        [When(@"View Edit Members page Save Button is Clicked")]
        public void WhenViewEditMembersPageSaveButtonIsClicked()
        {
            IWebElement save = Browser.Wd.FindElement(By.CssSelector("[test-id='memberViewEdit-btn-save']"));
            ReUsableFunctions.clickOnWebElement(save);
            tmsWait.Hard(7);
        }


        [When(@"I have Clicked on Expand All Button on Transaction Page")]
        public void WhenIHaveClickedOnExpandAllButtonOnTransactionPage()
        {
            tmsWait.Hard(5);
            ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.UIMODCreateTransactionBasic.ExpandAllBtn);
            tmsWait.Hard(7);
        }

       


        [Then(@"Verify Transactions New page OSB Drop down is ""(.*)""")]
        public void ThenVerifyTransactionsNewPageOSBDropDownIs(string p0)
        {

            bool isDisabledfield = Boolean.Parse(Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='OptionalSupplementalBenefitsOSBInformationOSB']/span")).GetAttribute("aria-disabled"));
            switch (p0.ToLower())
            {
                case "disabled": Assert.IsTrue(isDisabledfield, "OSB Drop Down is Not Disabled"); break;
                case "enabled": Assert.IsFalse(isDisabledfield, "OSB Drop Down is Disabled"); break;
            }
        }



        [Then(@"I have Expanded ""(.*)"" section")]
        public void ThenIHaveExpandedSection(string p0)
        {
            string section = tmsCommon.GenerateData(p0);
            switch(section.ToLower())
            {
                case "transaction": fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[@test-id='memberViewEdit-lbl-transactions']")));
                    break;
            }
        }


        [When(@"I have Clicked on Plan Defined section")]
        public void WhenIHaveClickedOnPlanDefinedSection()
        {
            ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODMemberCreation.PlanDefinedSection);
            tmsWait.Hard(4);
        }

       
        [When(@"Add New Member page Search MBI ""(.*)""")]
        public void WhenAddNewMemberPageSearchMBI(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemberCreation.UIMODSearchMBItextbox, value);
            ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODMemberCreation.UIMODSearchMBIBtn);
        }

        [Then(@"Verify Toaster info ""(.*)""")]
        public void ThenVerifyToasterInfo(string p0)
        {
            By toastMsg = By.XPath("//div[@class='toast-message']");
            string actValue = Browser.Wd.FindElement(toastMsg).Text;

            Assert.AreEqual(p0, actValue, p0 + " is not displayed");
        }


        [Then(@"Add New Member page ""(.*)"" Component is set to ""(.*)""")]
        [When(@"Add New Member page ""(.*)"" Component is set to ""(.*)""")]
        public void WhenAddNewMemberPageComponentIsSetTo(string p0, string p1)
        {
        string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (componentType)
            {
                case "MBI":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemberCreation.UIMODMBI, value);
                    break;
                case "MemberID":
                    try
                    {
                        if (cfUIMODMemberCreation.UIMODMemberCreation.UIMODMemberID.Enabled == true)
                        {
                            ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemberCreation.UIMODMemberID, value);
                        }
                    }
                    catch
                    {

                    }
                    break;
                case "FirstName":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemberCreation.UIMODfirstName, value);
                    break;
                case "LastName":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemberCreation.UIMODlastName, value);
                    break;
                case "MI":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemberCreation.UIMODMiddleInitial, value);
                    break;

            }
        }
        [When(@"Add New Member page Provider Details Section ""(.*)"" is set to ""(.*)""")]
        public void WhenAddNewMemberPageProviderDetailsSectionIsSetTo(string p0, string p1)
        {
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (componentType)
            {
               
                case "Gyn Name":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODProvider.GynName,value);
                    break;
                case "Gyn PCP ID":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODProvider.GynPCPID,value);
                    break;
                case "Gyn PCP Prv":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODProvider.GynPCPPrv,value);
                    break;
                case "MP Name":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODProvider.MPName, value);
                    break;
                
                case "Hospital Name":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODProvider.HospName, value);
                    break;
            }
        }

        [Then(@"verify Add New Member Plan Defined Fields section ""(.*)"" value is set to ""(.*)""")]
        public void ThenVerifyAddNewMemberPlanDefinedFieldsSectionValueIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(4);
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (componentType)
            {
                case "Plan10":
                    Assert.AreEqual(value, cfUIMODMemberCreation.UIMODPlanDefinedFields.Plan10Label.Text);
                    break;
                case "Plan1":
                    Assert.AreEqual(value, cfUIMODMemberCreation.UIMODPlanDefinedFields.Plan1Label.Text);
                    break;
                case "Plan2":
                    Assert.AreEqual(value, cfUIMODMemberCreation.UIMODPlanDefinedFields.Plan2Label.Text);
                    break;
                case "Plan3":
                    Assert.AreEqual(value, cfUIMODMemberCreation.UIMODPlanDefinedFields.Plan3Label.Text);
                    break;
                case "Plan4":
                    Assert.AreEqual(value, cfUIMODMemberCreation.UIMODPlanDefinedFields.Plan4Label.Text);
                    break;
                case "Plan5":
                    Assert.AreEqual(value, cfUIMODMemberCreation.UIMODPlanDefinedFields.Plan5Label.Text);
                    break;
                case "Plan6":
                    Assert.AreEqual(value, cfUIMODMemberCreation.UIMODPlanDefinedFields.Plan6Label.Text);
                    break;
                case "Plan7":
                    Assert.AreEqual(value, cfUIMODMemberCreation.UIMODPlanDefinedFields.Plan7Label.Text);
                    break;
                case "Plan8":
                    Assert.AreEqual(value, cfUIMODMemberCreation.UIMODPlanDefinedFields.Plan8Label.Text);
                    break;
                case "Plan9":
                    Assert.AreEqual(value, cfUIMODMemberCreation.UIMODPlanDefinedFields.Plan9Label.Text);
                    break;
            }
        }

        [Then(@"verify Add New Transaction Plan Defined Fields section ""(.*)"" value is set to ""(.*)""")]
        public void ThenVerifyAddNewTransactionPlanDefinedFieldsSectionValueIsSetTo(string p0, string p1)
        {
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                switch (componentType)
                {
                    case "Plan10":
                        Assert.AreEqual(value, cfUIMODCreateTransaction.TransactionRelatedPlanFields.labelPlan10AngJS.Text);
                        break;
                    case "Plan1":
                        Assert.AreEqual(value, cfUIMODCreateTransaction.TransactionRelatedPlanFields.labelPlan1AngJS.Text);
                        break;
                    case "Plan2":
                        Assert.AreEqual(value, cfUIMODCreateTransaction.TransactionRelatedPlanFields.labelPlan2AngJS.Text);
                        break;
                    case "Plan3":
                        Assert.AreEqual(value, cfUIMODCreateTransaction.TransactionRelatedPlanFields.labelPlan3AngJS.Text);
                        break;
                    case "Plan4":
                        Assert.AreEqual(value, cfUIMODCreateTransaction.TransactionRelatedPlanFields.labelPlan4AngJS.Text);
                        break;
                    case "Plan5":
                        Assert.AreEqual(value, cfUIMODCreateTransaction.TransactionRelatedPlanFields.labelPlan5AngJS.Text);
                        break;
                    case "Plan6":
                        Assert.AreEqual(value, cfUIMODCreateTransaction.TransactionRelatedPlanFields.labelPlan6AngJS.Text);
                        break;
                    case "Plan7":
                        Assert.AreEqual(value, cfUIMODCreateTransaction.TransactionRelatedPlanFields.labelPlan7AngJS.Text);
                        break;
                    case "Plan8":
                        Assert.AreEqual(value, cfUIMODCreateTransaction.TransactionRelatedPlanFields.labelPlan8AngJS.Text);
                        break;
                    case "Plan9":
                        Assert.AreEqual(value, cfUIMODCreateTransaction.TransactionRelatedPlanFields.labelPlan9AngJS.Text);
                        break;
                }
            }

            else
            {
                switch (componentType)
                {
                    case "Plan10":
                        Assert.AreEqual(value, cfUIMODCreateTransaction.TransactionRelatedPlanFields.labelPlan10.Text);
                        break;
                    case "Plan1":
                        Assert.AreEqual(value, cfUIMODCreateTransaction.TransactionRelatedPlanFields.labelPlan1.Text);
                        break;
                    case "Plan2":
                        Assert.AreEqual(value, cfUIMODCreateTransaction.TransactionRelatedPlanFields.labelPlan2.Text);
                        break;
                    case "Plan3":
                        Assert.AreEqual(value, cfUIMODCreateTransaction.TransactionRelatedPlanFields.labelPlan3.Text);
                        break;
                    case "Plan4":
                        Assert.AreEqual(value, cfUIMODCreateTransaction.TransactionRelatedPlanFields.labelPlan4.Text);
                        break;
                    case "Plan5":
                        Assert.AreEqual(value, cfUIMODCreateTransaction.TransactionRelatedPlanFields.labelPlan5.Text);
                        break;
                    case "Plan6":
                        Assert.AreEqual(value, cfUIMODCreateTransaction.TransactionRelatedPlanFields.labelPlan6.Text);
                        break;
                    case "Plan7":
                        Assert.AreEqual(value, cfUIMODCreateTransaction.TransactionRelatedPlanFields.labelPlan7.Text);
                        break;
                    case "Plan8":
                        Assert.AreEqual(value, cfUIMODCreateTransaction.TransactionRelatedPlanFields.labelPlan8.Text);
                        break;
                    case "Plan9":
                        Assert.AreEqual(value, cfUIMODCreateTransaction.TransactionRelatedPlanFields.labelPlan9.Text);
                        break;
                }
            }
            }

        [Then(@"Verify Add New Member page Plan Defined Fields Details section ""(.*)"" dropdown does not have value ""(.*)""")]
        public void ThenVerifyAddNewMemberPagePlanDefinedFieldsDetailsSectionDropdownDoesNotHaveValue(string p0, string p1)
        {
           
        string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            tmsWait.Hard(3);
            bool present =false;
            switch (componentType)
            {
                case "Group":
                    fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODPlanDefinedFields.GroupDropDownList);
                    present = UIMODUtilFunctions.verifyDropDownValueFromGendoUI(cfUIMODMemberCreation.UIMODPlanDefinedFields.GroupDropDownList, value);
                    break;
                case "Sub-Group":
                    fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODPlanDefinedFields.SubGroupDropDownList);
                    present = UIMODUtilFunctions.verifyDropDownValueFromGendoUI(cfUIMODMemberCreation.UIMODPlanDefinedFields.SubGroupDropDownList, value);
            break;
                case "Class":
                    fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODPlanDefinedFields.ClassDropDownList);
                    present= UIMODUtilFunctions.verifyDropDownValueFromGendoUI(cfUIMODMemberCreation.UIMODPlanDefinedFields.ClassDropDownList, value);
            break;


        }
            Assert.IsTrue(present, componentType+" is not inactivated successfully, value is present in dropdown");
    }

    [When(@"Add New Member page Plan Defined Fields Details section ""(.*)"" is set to ""(.*)""")]
        [Then(@"Add New Member page Plan Defined Fields Details section ""(.*)"" is set to ""(.*)""")]
        public void WhenAddNewMemberPagePlanDefinedFieldsDetailsSectionIsSetTo(string p0, string p1)
        {
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            tmsWait.Hard(3);
            switch (componentType)
            {
                case "Plan10":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODPlanDefinedFields.Plan10, value);
                    break;
                case "Plan1":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODPlanDefinedFields.Plan1, value);
                    break;
                case "Plan2":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODPlanDefinedFields.Plan2, value);
                    break;
                case "Plan3":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODPlanDefinedFields.Plan3, value);
                    break;
                case "Plan4":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODPlanDefinedFields.Plan4, value);
                    break;
                case "Plan5":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODPlanDefinedFields.Plan5, value);
                    break;
                case "Plan6":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODPlanDefinedFields.Plan6, value);
                    break;
                case "Plan7":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODPlanDefinedFields.Plan7, value);
                    break;
                case "Plan8":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODPlanDefinedFields.Plan8, value);
                    break;
                case "Plan9":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODPlanDefinedFields.Plan9, value);
                    break;
                case "Group":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'Group')]/parent::div//span[@class='k-select']");
                        By typeapp = By.XPath("//li[text()='" + value + "']");




                        UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);


                    }

                    else
                    {


                        fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODPlanDefinedFields.GroupDropDownList);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODMemberCreation.UIMODPlanDefinedFields.GroupDropDownList, value);
                    }
                        break;
                case "Sub-Group":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'Sub-Group')]/parent::div//span[@class='k-select']");
                        By typeapp = By.XPath("//li[text()='" + value + "']");




                        UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);


                    }

                    else
                    {
                        fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODPlanDefinedFields.SubGroupDropDownList);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODMemberCreation.UIMODPlanDefinedFields.SubGroupDropDownList, value);
                    } break;
                case "Class":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'Class')]/parent::div//span[@class='k-select']");
                        By typeapp = By.XPath("//li[text()='" + value + "']");




                        UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);



                    }

                    else
                    {
                        fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODPlanDefinedFields.ClassDropDownList);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODMemberCreation.UIMODPlanDefinedFields.ClassDropDownList, value);
                    }
                    break;

            }
        }

        [Then(@"Verify Members New Plan(.*) is set to ""(.*)""")]
        public void ThenVerifyMembersNewPlanIsSetTo(int p0, int p1)
        {
            Assert.AreEqual(p1, EAM.MembersNew.Plan1.Text);
        }

        [When(@"View Edit Members page ""(.*)"" is set to ""(.*)""")]
        public void WhenViewEditMembersPageIsSetTo(string p0, string p1)
        {
            string mem = tmsCommon.GenerateData(p1);
            ReUsableFunctions.enterValueOnWebElement(Browser.Wd.FindElement(By.XPath("//tags-input[@id='tagOrSearch']")), mem);
        }

        [Then(@"View Edit Members page Search results displays ""(.*)""")]
        public void ThenViewEditMembersPageSearchResultsDisplays(string p0)
        {
            string result = tmsCommon.GenerateData(p0);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@id='membersDataGrid']//span[contains(.,'" + result + "')]")).Displayed, "Member Is not displayed");
        }



        [When(@"Add New Member page Plan Defined Fields Details section Send Plan (.*) on Legacy checkbox is Clicked")]
        public void WhenAddNewMemberPagePlanDefinedFieldsDetailsSectionSendPlanOnLegacyCheckboxIsClicked(int p0)
        {
           
        }


        [When(@"Add New Member page Premium LIS details Section ""(.*)"" is set to ""(.*)""")]
        public void WhenAddNewMemberPagePremiumLISDetailsSectionIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(2);
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (componentType)
            {

                case "LEP Waived Amount":
                    fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLEPWaivedAmount);
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLEPWaivedAmount, value);
                    break;
                case "Uncovered Months":
                    fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODUncoveredMonths);
                    // UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODCreditcoverDropDownlist, "N");                      
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODUncoveredMonths, value);
                    break;

                case "Credit Cover":

                    if (ConfigFile.tenantType == "tmsx")
                    {
                        IWebElement drp = Browser.Wd.FindElement(By.XPath("(//*[@test-id='premiumLis-select-creditCover']/span/span)[1]"));
                        fw.ExecuteJavascript(drp);
                        tmsWait.Hard(1);
                        IWebElement element = Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + value + "')]"));
                        fw.ExecuteJavascript(element);
                    }
                    else { 
                        fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODCreditCoverdownList);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUIWithoutAriaOwns(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODCreditCoverdownList, value);
                    }
                        break;


            }

       }

        [Then(@"Verify Members Information Plan Defined Section SubGroup field does not have ""(.*)"" value")]
        public void ThenVerifyMembersInformationPlanDefinedSectionSubGroupFieldDoesNotHaveValue(string p0)
        {
            bool flag = false;
            string subgroupName = tmsCommon.GenerateData(p0);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {

            }
            else { 
                SelectElement ele = new SelectElement(Browser.Wd.FindElement(By.XPath("//*[@id='subGroup']")));
            IList<IWebElement> options = ele.Options;

            for (int i = 0; i <= options.Count - 1; i++)
            {
                if (options[i].GetAttribute("value") == subgroupName)
                {
                    flag = true;
                    break;
                }
            }
            Assert.AreEqual(false, flag, "Subgroup Drop down has value " + subgroupName + " which should not be in the list");
        }

        }

        [Then(@"verify BEQ Information DOD is set to value ""(.*)""")]
        public void ThenVerifyBEQInformationDODIsSetToValue(string p0)
        {
            string expValue = tmsCommon.GenerateData(p0.ToString());
            Console.Write("Expected DOD value is: "+expValue);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//input[@id='txtCmsDod']"));
            string actualValue = ele.GetAttribute("value");
            Console.Write("CMS DOD value is: " + actualValue);
            Assert.AreEqual(expValue, actualValue, "BEQ - CMS DOD input box does not have expected value");
      
        }

        [Then(@"verify BEQ Information state code is set to value ""(.*)""")]
        public void ThenVerifyBEQInformationStateCodeIsSetToValue(int p0)
        {
            string expValue = tmsCommon.GenerateData(p0.ToString());
            Console.Write("Expected State Code value is: " + expValue);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//input[@id='txtStateCode']"));
            string actualValue = ele.GetAttribute("value");
            Console.Write("State Code value is: " + actualValue);
            Assert.AreEqual(expValue, actualValue, "BEQ - State Code input box does not have expected value");
        }


        [When(@"verify BEQ Information country code is set to value ""(.*)""")]
        [Then(@"verify BEQ Information country code is set to value ""(.*)""")]
        public void WhenVerifyBEQInformationCountryCodeIsSetToValue(string p0)
        {
            string expValue = tmsCommon.GenerateData(p0.ToString());
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//input[@id='txtCountyCode']"));
            string actualValue = ele.GetAttribute("value");
            if (Regex.IsMatch(expValue, @"[0-9]") == true)
            {
                if (expValue != "0")
                {
                    Assert.AreEqual(expValue, actualValue, "Country Code input box does not have expected value");
                }
            }
            else
            {
                Assert.IsTrue(ele.Enabled == false, "Passed" + "CountryCode {0} set to expected value", false);
            }
        }


        [Then(@"Verify Members Information Plan Defined Section Group field does not have ""(.*)"" value")]
        [When(@"Verify Members Information Plan Defined Section Group field does not have ""(.*)"" value")]
        [Given(@"Verify Members Information Plan Defined Section Group field does not have ""(.*)"" value")]
        public void ThenVerifyMembersInformationPlanDefinedSectionGroupFieldDoesNotHaveValue(string p0)
        {
            string groupName = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Group')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + groupName + "']");




                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                try {
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                }
                catch
                {

                }

            }
            else { 
                bool flag = false;
           
            SelectElement ele = new SelectElement(Browser.Wd.FindElement(By.Id("group")));
            IList<IWebElement> options = ele.Options;

            for (int i = 0; i <= options.Count - 1; i++)
            {
                if (options[i].GetAttribute("value") == groupName)
                {
                    flag = true;
                    break;
                }
            }
            Assert.AreEqual(false, flag, "Group Drop down has value " + groupName + " which should not be in the list");
        }
        }


        [Then(@"Add New Member page Contact Details Response Details section ""(.*)"" Component is set to ""(.*)""")]
        public void ThenAddNewMemberPageContactDetailsResponseDetailsSectionComponentIsSetTo(string p0, string p1)
        {
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (componentType)
            {
                case "ResponseRelation":
                   
                    //SelectElement ele = new SelectElement(Browser.Wd.FindElement(By.Id("responseRelations")));
               
                    //ele.SelectByText(value);
                    fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODMemContacts.UIMODResponseRelationDropdownlist);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODMemberCreation.UIMODMemContacts.UIMODResponseRelationDropdownlist, value);
                    break;
            }
        }

       




        [When(@"Add New Member page Contact Details Secondary Address section ""(.*)"" Component is set to ""(.*)""")]
        public void WhenAddNewMemberPageContactDetailsSecondaryAddressSectionComponentIsSetTo(string p0, string p1)
        {
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            tmsWait.Hard(4);
            switch (componentType)

            {
                case "AddressType":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("(//kendo-dropdownlist[@test-id='memberContacts-select-secondaryAddressTypes']//span)[3]");

                        By typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        //tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                        tmsWait.Hard(3);

                    }
                    else
                    {

                        ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODMemContacts.UIMODSecondAddressTypeDropdownlist);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODMemberCreation.UIMODMemContacts.UIMODSecondAddressTypeDropdownlist, value);
                    }
                    break;
                case "Address1":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemContacts.UIMODSecondAddress1, value);
                    break;
                case "Address2":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemContacts.UIMODSecondAddress2, value);
                    break;
                case "Phone":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemContacts.UIMODSecondPhone, value);
                    break;
                case "Zip":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemContacts.UIMODSecondZip, value);
                    //System.Windows.Forms.SendKeys.SendWait("{TAB}");
                    //System.Windows.Forms.SendKeys.SendWait("{TAB}");
                    break;
            }
            }
        [Then(@"Add New Member page Contact Details Primary Address section ""(.*)"" Component is set to ""(.*)""")]
        [When(@"Add New Member page Contact Details Primary Address section ""(.*)"" Component is set to ""(.*)""")]
        public void WhenAddNewMemberPageContactDetailsPrimaryAddressSectionComponentIsSetTo(string p0, string p1)
        {
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            tmsWait.Hard(5);
            switch (componentType)
            {
                case "AddressType":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("(//label[text()='Address Type']/parent::div//span)[3]");

                        By typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        //tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                        tmsWait.Hard(3);
                    }
                    else
                    {
                     ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODMemContacts.UIMODPrimaryAddressTypeDropdownlist);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODMemberCreation.UIMODMemContacts.UIMODPrimaryAddressTypeDropdownlist, value);
                    }
                    break;
                case "County":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//kendo-dropdownlist[@id='county']//span[@class='k-select']");
                        By typeapp = By.XPath("//li[text()='" + value + "']");
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                    }
                    else
                    {
                    ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODMemContacts.UIMODPrimaryCountyDropdownlist);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODMemberCreation.UIMODMemContacts.UIMODPrimaryCountyDropdownlist, value);
                    }

                    break;
                case "Address1":
                    ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODMemContacts.UIMODPrimaryAddress1);
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemContacts.UIMODPrimaryAddress1, value);
                    break;
                case "Address2":
                    ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODMemContacts.UIMODPrimaryAddress2);
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemContacts.UIMODPrimaryAddress2, value);
                    break;
                case "Phone":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemContacts.UIMODPrimaryPhone, value);
                    break;
                case "Zip":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemContacts.UIMODPrimaryZip, value);
                    ////System.Windows.Forms.SendKeys.SendWait("{TAB}");
                    cfUIMODMemberCreation.UIMODMemContacts.UIMODPrimaryZip.SendKeys(Keys.Tab);
                    break;
                case "City":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemContacts.UIMODPrimaryCity, value);
                    //System.Windows.Forms.SendKeys.SendWait("{TAB}");
                    break;
            }
            tmsWait.Hard(10);
                
        }

        [Then(@"Verify system displayed error toaster message as ""(.*)""")]
        public void ThenVerifySystemDisplayedErrorToasterMessageAs(string p0)
        {
            ReUsableFunctions.toasterMessageDisplay(p0);
        }

        [When(@"Add New Member page Span Details Click on Save Button")]
        [Then(@"Add New Member page Span Details Click on Save Button")]
        public void WhenAddNewMemberPageSpanDetailsClickOnSaveButton()
        {
            ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODSpan.UIMODSave);
        }

        [When(@"Add New Member page Eligibility Details ""(.*)"" Component is set to ""(.*)""")]
        public void WhenAddNewMemberPageEligibilityDetailsComponentIsSetTo(string p0, string p1)
        {
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (componentType)
            {
                case "PlanPartAEffDate":
                    tmsWait.Hard(4);
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='eligibility-txt-planPartAEffDate']//span/input"));
                        string value1 = value.Replace("/", "");
                        ele.Clear();
                        ele.SendKeys(value1);
                        tmsWait.Hard(3);
                    }
                    else
                    {

                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODMemberCreation.UIMODEligibility.UIMODPlanPartAEffectiveDate, value);
                    }
                    tmsWait.Hard(4);
                    break;
                case "PlanPartBEffDate":
                    tmsWait.Hard(4);
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='eligibility-txt-planPartBEffDate']//span/input"));
                        string value1 = value.Replace("/", "");
                        ele.Clear();
                        ele.SendKeys(value1);
                        tmsWait.Hard(3);
                    }
                    else
                    {
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODMemberCreation.UIMODEligibility.UIMODPlanPartBEffectiveDate, value);
                    }
                    tmsWait.Hard(4);
                    break;
                case "PlanPartDEffDate":
                    tmsWait.Hard(2);
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='eligibility-txt-planPartDEffDate']//span/input"));
                        string value1 = value.Replace("/", "");
                        ele.Clear();
                        ele.SendKeys(value1);
                        tmsWait.Hard(3);
                    }
                    else
                    {
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODMemberCreation.UIMODEligibility.UIMODPlanPartDEffectiveDate, value);
                    }
                    tmsWait.Hard(4);
                    break;
            }
        }
        [When(@"Add New Member page Correspondence Details for Letter type ""(.*)"" Letter Name Component is set to ""(.*)""")]
        public void WhenAddNewMemberPageCorrespondenceDetailsForLetterTypeLetterNameComponentIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(2);
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (componentType)
            {
                case "On Demand Letters":

                   
                        By Drp = By.XPath("//label[contains(.,'Letter Name')]/parent::div/parent::div//span[@class='k-select']");
                        By typeapp = By.XPath("//li[text()='" + value + "']");
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                        tmsWait.Hard(3);
                   
                       
                    break;
                case "Pre-CMS Letters":
                    //    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODCorrespondence., value);
                    break;
                case "Post-CMS Letters":
                    //   ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODCorrespondence., value);
                    break;
            }
        }

        [When(@"Add New Member page Edit Span Details ""(.*)"" Component is set to ""(.*)""")]
        public void WhenAddNewMemberPageEditSpanDetailsComponentIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(4);
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            string dateValue = value.Replace("/", "");
            switch (componentType)
            {
                case "EndDate":
                    By throughDate = By.XPath("//kendo-datepicker[@id='throughDate']//input");
                    Browser.Wd.FindElement(throughDate).Clear();
                    Browser.Wd.FindElement(throughDate).SendKeys(dateValue);
                    tmsWait.Hard(3);
                    break;
                case "StartDate":
                    By startDate = By.XPath("//kendo-datepicker[@id='fromDate']//input");
                    Browser.Wd.FindElement(startDate).Clear();
                    Browser.Wd.FindElement(startDate).SendKeys(dateValue);
                    tmsWait.Hard(3);
                    break;
            }
         }
        [When(@"Add New Member page OEC Details ""(.*)"" Component is set to ""(.*)""")]

        [Then(@"Add New Member page OEC Details ""(.*)"" Component is set to ""(.*)""")]
        public void WhenAddNewMemberPageOECDetailsComponentIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(4);
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (componentType)
            {
                case "Medicaid Number":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement Institutionname = Browser.Wd.FindElement(By.XPath("//input[@test-id='oecSales-txt-medicaidNumber']"));
                        Institutionname.SendKeys(value);
                    }
                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODOECSales.MedcaidNumber);
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODOECSales.MedcaidNumber, value);
                    }
                    break;
                case "Sales Rep":
                    ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODOECSales.SalesRepDroDownlist);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODMemberCreation.UIMODOECSales.SalesRepDroDownlist, value);
                    break;
                case "Institution Name":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement Institutionname = Browser.Wd.FindElement(By.XPath("//input[@test-id='oecSales-txt-institutionName']"));
                        Institutionname.SendKeys(value);
                    }
                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODOECSales.InstitutionName);
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODOECSales.InstitutionName, value);
                    }
                    break;
                case "Institution Address":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement Institutionname = Browser.Wd.FindElement(By.XPath("//input[@test-id='oecSales-txt-institutionAddress']"));
                        Institutionname.SendKeys(value);
                    }
                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODOECSales.InstitutionAddress);
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODOECSales.InstitutionAddress, value);
                    }
                    break;
                case "Institution Phone":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement Institutionname = Browser.Wd.FindElement(By.XPath("//input[@test-id='oecSales-txt-institutionPhone']"));
                        Institutionname.SendKeys(value);
                    }
                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODOECSales.InstitutionPhone);
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODOECSales.InstitutionPhone, value);
                    }
                    break;
            }
        }

        [Then(@"Verify New Member page Span Details Plan ID as ""(.*)"" Span Type as ""(.*)"" Value as ""(.*)"" is not getting displayed")]
        public void ThenVerifyNewMemberPageSpanDetailsPlanIDAsSpanTypeAsValueAsIsNotGettingDisplayed(string plan, string spanType, string value)
        {
            By loc = By.XPath("//div[@test-id='memberSpan-grid-memberSpansGrid']//td[contains(.,'"+ plan + "')]/following-sibling::td[contains(.,'"+ spanType + "')]//following-sibling::td[contains(.,'"+value+"')]");
            UIMODUtilFunctions.elementNotPresenceUsingLocators(loc);
        }


        [When(@"Add New Member page Span Details ""(.*)"" Component is set to ""(.*)""")]
        [Then(@"Add New Member page Span Details ""(.*)"" Component is set to ""(.*)""")]
        public void WhenAddNewMemberPageSpanDetailsComponentIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(4);
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement ele;
                switch (componentType)
                {
                    case "PlanID":
                         ele= Browser.Wd.FindElement(By.XPath("//*[@test-id='memberSpan-select-planId']/parent::div//span[@class='k-select']"));
                       
                        tmsWait.Hard(2);
                       
                        UIMODUtilFunctions.selectDropDownValueFromKendoDropDown(ele, value);
                        break;
                        
                    case "StatusType":
                    case "Status Type":
                        tmsWait.Hard(3);
                         ele = Browser.Wd.FindElement(By.XPath("//*[@test-id='memberSpan-select-statusType']/parent::div//span[@class='k-select']"));

                        tmsWait.Hard(2);

                        UIMODUtilFunctions.selectDropDownValueFromKendoDropDown(ele, value);
                        break;
                    case "SpanValue":
                        //ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODSpan.UIMODSpanValue, value);
                      

                          //  UIMODUtilFunctions.selectDropDownValueFromGendoUI(field, value, index);
                    

                        cfUIMODMemberCreation.UIMODSpan.UIMODSpanValue.SendKeys(value);
                        break;
                    case "StartDate":
                        AngularFunction.enterDate(cfUIMODMemberCreation.UIMODSpan.UIMODStartDate, value);

                        break;
                    case "EndDate":
                        AngularFunction.enterDate(cfUIMODMemberCreation.UIMODSpan.UIMODEndDate, value);
                   
                        break;


                }
            }
            else
            {

           
            switch (componentType)
            {
                case "PlanID":
                    fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODSpan.UIMODPlanIDDropdownlist);
                    ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODSpan.UIMODPlanIDDropdownlist);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODMemberCreation.UIMODSpan.UIMODPlanIDDropdownlist, value);                    
                    break;
                case "Status Type":
                    tmsWait.Hard(3);
                    fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODSpan.UIMODStatusTypeDropdownlist);
                    ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODSpan.UIMODStatusTypeDropdownlist);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODMemberCreation.UIMODSpan.UIMODStatusTypeDropdownlist, value);                   
                    break;
                case "SpanValue":
                    //ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODSpan.UIMODSpanValue, value);
                    cfUIMODMemberCreation.UIMODSpan.UIMODSpanValue.SendKeys(value);
                    break;
                case "StartDate":
                    fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODSpan.UIMODStartDate);
                    cfUIMODMemberCreation.UIMODSpan.UIMODStartDateTextbox.SendKeys(Keys.Home);
                    ReUsableFunctions.enterValueOnWebElementWithoutClear(cfUIMODMemberCreation.UIMODSpan.UIMODStartDateTextbox, value);
                    cfUIMODMemberCreation.UIMODSpan.UIMODStartDateTextbox.SendKeys(Keys.Tab);
                    break;
                case "EndDate":
                    fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODSpan.UIMODEndDate);
                    cfUIMODMemberCreation.UIMODSpan.UIMODEndDateTextbox.SendKeys(Keys.Home);
                    ReUsableFunctions.enterValueOnWebElementWithoutClear(cfUIMODMemberCreation.UIMODSpan.UIMODEndDateTextbox, value);
                    cfUIMODMemberCreation.UIMODSpan.UIMODEndDateTextbox.SendKeys(Keys.Tab);
                    break;


                }

            }
        }

        [Then(@"Add New Member page Payment Details ""(.*)"" Component is set to ""(.*)""")]
        public void WhenAddNewMemberPagePaymentDetailsComponentIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(4);
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (componentType)
            {
                case "Bank":

                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODPayment.Bank, value);
                    break;
                case "Account Type":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'Account Type')]/parent::div//span[@class='k-select']");

                        By typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        //tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                        tmsWait.Hard(3);

                    }
                    else
                    {

                        ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODPayment.AccountTypeDropDownlist);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODMemberCreation.UIMODPayment.AccountTypeDropDownlist, value);
                    }

                    break;
                case "Suppress Date":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='payment-txt-suppressDate']//span/input"));
                        string value1 = value.Replace("/", "");
                        ele.Clear();
                        ele.SendKeys(value1);
                        tmsWait.Hard(3);
                    }
                    else
                    {
                        UIMODUtilFunctions.setValueAttributeAfterScrollingInToComponent(cfUIMODMemberCreation.UIMODPayment.AccountTypeDropDownlist, value);
                        //ReUsableFunctions.enterValueOnWebElementWithoutClear(cfUIMODMemberCreation.UIMODPayment.SupressDate, value);
                    }
                    break;
                case "Card Expiration":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='payment-txt-cardExpiration']//span/input"));
                        string value1 = value.Replace("/", "");
                        ele.Clear();
                        ele.SendKeys(value1);
                        tmsWait.Hard(3);
                    }
                    else
                    {
                        //  ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODPayment.AccountTypeDropDownlist);
                        UIMODUtilFunctions.setValueAttributeAfterScrollingInToComponent(cfUIMODMemberCreation.UIMODPayment.AccountTypeDropDownlist, value);
                    }
                    break;
            }
        }
        [When(@"Add New Member page RX Details section ""(.*)"" Component is set to ""(.*)""")]
        public void WhenAddNewMemberPageRXDetailsSectionComponentIsSetTo(string p0, string p1)
        {
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (componentType)
            {
                case "RxID":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemRxDetails.UIMODRxID, value);
                    break;
                case "RxGroup":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemRxDetails.UIMODRxGroup, value);
                    break;
                case "RxBIN":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemRxDetails.UIMODRxBIN, value);
                    break;
                case "RxPCN":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemRxDetails.UIMODRxPCN, value);
                    break;

            }
        }
        [When(@"Add New Member page Demographics section ""(.*)"" checkbox is ""(.*)""")]
        public void WhenAddNewMemberPageDemographicsSectionCheckboxIs(string p0, string p1)
        {
            string componentType = tmsCommon.GenerateData(p0);
            string typeofAction = tmsCommon.GenerateData(p1);
            switch (componentType)
            {
                case "EGHP":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ele = Browser.Wd.FindElement(By.XPath("//label[@test-id='memberDemographics-lbl-eghp']/preceding-sibling::input"));
                        ReUsableFunctions.CheckBoxOperations(ele, typeofAction);
                    }
                    else
                    {
                        ReUsableFunctions.CheckBoxOperations(cfUIMODMemberCreation.UIMODMemDemographics.UIMODEGHPCheckbox, typeofAction);
                    }
                    break;
            }
        }

        [Then(@"Verify Member Information Demographics section ""(.*)"" checkbox is ""(.*)""")]
        public void ThenVerifyMemberInformationDemographicsSectionCheckboxIs(string p0, string p1)
        {
            string componentType = tmsCommon.GenerateData(p0);
            string typeofAction = tmsCommon.GenerateData(p1);
            switch (componentType)
            {
                case "EGHP":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ele = Browser.Wd.FindElement(By.XPath("//label[@test-id='memberDemographics-lbl-eghp']/preceding-sibling::input"));
                        ReUsableFunctions.CheckBoxStatus(ele, typeofAction);
                    }

                    else
                    {
                        ReUsableFunctions.CheckBoxStatus(cfUIMODMemberCreation.UIMODMemDemographics.UIMODEGHPCheckbox, typeofAction);
                    }
                    break;
            }
        }

        [Then(@"Verify View Edit Member page displayed Alert Message as ""(.*)""")]
        public void ThenVerifyViewEditMemberPageDisplayedAlertMessageAs(string p0)
        {
            string actualMessage = Browser.alertMessage();
            string expectedMessage = tmsCommon.GenerateData(p0);
            ReUsableFunctions.CompareTwoStrings(expectedMessage, actualMessage);

        }


        [When(@"View Edit Member page Demographics section ""(.*)"" Component is set to ""(.*)""")]
        public void WhenViewEditMemberPageDemographicsSectionComponentIsSetTo(string p0, string p1)
        {
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (componentType)
            {
                case "EffectiveDate":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemDemographics.UIMODEffectiveDate, value);
                    break;
            }
        }

        [When(@"Add New Member page Invalid ""(.*)"" is entered as ""(.*)""")]
        public void WhenAddNewMemberPageInvalidIsEnteredAs(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);

            switch(field.ToLower())
            {
                case "effective date":IWebElement effdate = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='memberDemographics-txt-effectiveDate']//input"));
                    effdate.SendKeys(value);
                    effdate.SendKeys(Keys.Tab);

                    break;
            }
        }

        [Then(@"Add New Member page Demographics section ""(.*)"" Component is set to ""(.*)""")]
        [When(@"Add New Member page Demographics section ""(.*)"" Component is set to ""(.*)""")]
        public void WhenAddNewMemberPageDemographicsSectionComponentIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(5);
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            tmsWait.Hard(3);
            switch (componentType)
            {
             
                case "Appel":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemDemographics.UIMODAppel, value);
                    break;
                case "DOB":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        
                        IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='memberDemographics-txt-dob']//span[@role='button']"));
                        
                        AngularFunction.enterDate(ele, value);
                        tmsWait.Hard(3);
                    }

                    else
                    {
                        cfUIMODMemberCreation.UIMODMemDemographics.UIMODDOB.SendKeys(OpenQA.Selenium.Keys.Home);
                    //ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemDemographics.UIMODDOB, value);
                    cfUIMODMemberCreation.UIMODMemDemographics.UIMODDOB.SendKeys(value);
                    }
                    break;
                case "Sex":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'Gender')]/parent::div//span[@class='k-select']");

                        By typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        //tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                     tmsWait.Hard(3);

                    }
                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODMemDemographics.UIMODSexDropDownList);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODMemberCreation.UIMODMemDemographics.UIMODSexDropDownList, value);
                    }
                    break;
                case "SSN":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemDemographics.UIMODSSN, value);
                    break;
                case "MaritalStatus":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'Marital Status')]/parent::div//span[@class='k-select']");

                        By typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        //tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                        tmsWait.Hard(3);

                    }
                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODMemDemographics.UIMODMaritalStatusDropDownList);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODMemberCreation.UIMODMemDemographics.UIMODMaritalStatusDropDownList, value);
                    }
                    break;
                case "Language":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'Language')]/parent::div//span[@class='k-select']");


                        By typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        //tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                        tmsWait.Hard(3);

                    }
                    else
                    {

                        fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODMemDemographics.UIMODLanguageDropdownlist);
                    ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODMemDemographics.UIMODLanguageDropdownlist);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODMemberCreation.UIMODMemDemographics.UIMODLanguageDropdownlist, value);
                    }
                    break;
                case "SegmentID":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'Segment ID')]/parent::div//span[@class='k-select']");

                        By typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        //tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                        tmsWait.Hard(3);

                    }
                    else
                    {
                        fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODMemDemographics.UIMODSegmentIDPDropdownlist);
                    ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODMemDemographics.UIMODSegmentIDPDropdownlist);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODMemberCreation.UIMODMemDemographics.UIMODSegmentIDPDropdownlist, value);
                    }

                    break;
                case "Race":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'Race')]/parent::div//span[@class='k-select']");

                        By typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        //tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                        tmsWait.Hard(3);

                    }
                    else
                    {
                        fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODMemDemographics.UIMODRaceDropdownlist);
                    ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODMemDemographics.UIMODRaceDropdownlist);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODMemberCreation.UIMODMemDemographics.UIMODRaceDropdownlist, value);
                    }
                    break;
                case "PlanID":
                    // Updated below code to handle ESI EAM

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        //By Drp = By.XPath("//label[contains(.,'Plan ID')]/parent::div//span[@class='k-select']");
                        By Drp = By.XPath("//kendo-dropdownlist[@test-id='memberDemographics-select-planId']//span[@class='k-select']");

                        By typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        //tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                        tmsWait.Hard(3);

                    }
                    else
                    {
                        try
                    {
                        fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODMemDemographics.UIMODPlanIdDropdownlist);
                        tmsWait.Hard(3);
                        ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODMemDemographics.UIMODPlanIdDropdownlist);
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODMemberCreation.UIMODMemDemographics.UIMODPlanIdDropdownlist, value);
                        tmsWait.Hard(3);
                    }
                    catch
                    {
                        fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODMemDemographics.UIMODPlanIdDropdownlist);
                        tmsWait.Hard(3);
                        ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODMemDemographics.UIMODPlanIdDropdownlist);
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODMemberCreation.UIMODMemDemographics.UIMODPlanIdDropdownlist, "H0004");
                        tmsWait.Hard(3);
                    }
                    }
                    break;
                case "PBPID":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        tmsWait.Hard(5);
                        By Drp = By.XPath("//label[contains(.,'PBP')]/parent::div//span[@class='k-select']");

                        By typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        //tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                        tmsWait.Hard(3);

                    }
                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODMemDemographics.UIMODPBPDropdownlist);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODMemberCreation.UIMODMemDemographics.UIMODPBPDropdownlist, value);
                    tmsWait.Hard(3);
                    }
                    break;
                case "ElectionType":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'Latest Election Type')]/parent::div//span[@class='k-select']");

                        By typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        //tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                        tmsWait.Hard(3);

                    }
                    else
                    {
                        fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODMemDemographics.UIMODElectionTypeDropdownlist);
                    ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODMemDemographics.UIMODElectionTypeDropdownlist);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODMemberCreation.UIMODMemDemographics.UIMODElectionTypeDropdownlist, value);
                    }
                    break;
                case "PartDOptOut":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'Part D Opt-Out')]/parent::div//span[@class='k-select']");

                        By typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        //tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                        tmsWait.Hard(3);

                    }
                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODMemDemographics.UIMODPartDOptOutDropdownlist);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODMemberCreation.UIMODMemDemographics.UIMODPartDOptOutDropdownlist, value);
                    }
                    break;

                case "EffectiveDate":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='memberDemographics-txt-effectiveDate']//span[@role='button']"));
                       
                        AngularFunction.enterDate(ele, value);
                        tmsWait.Hard(3);
                    }

                    else
                    {
                        tmsWait.Hard(2);
                    cfUIMODMemberCreation.UIMODMemDemographics.UIMODEffectiveDate.SendKeys(OpenQA.Selenium.Keys.Home);
                    cfUIMODMemberCreation.UIMODMemDemographics.UIMODEffectiveDate.SendKeys(value);
                    //ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemDemographics.UIMODEffectiveDate, value);
                    tmsWait.Hard(3);
                    }
                    break;
                case "TermDate":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='memberDemographics-txt-termDate']//span[@role='button']"));
                       
                        AngularFunction.enterDate(ele, value);
                        tmsWait.Hard(3);
                    }

                    else
                    {
                        tmsWait.Hard(3);
                    cfUIMODMemberCreation.UIMODMemDemographics.UIMODTermDate.SendKeys(OpenQA.Selenium.Keys.Home);
                    ReUsableFunctions.enterValueOnWebElementWithoutClear(cfUIMODMemberCreation.UIMODMemDemographics.UIMODTermDate, value);
                    }
                    break;
                case "DeathDate":
//tmsWait.Hard(3);
                   // cfUIMODMemberCreation.UIMODMemDemographics.UIMODDOD.SendKeys(OpenQA.Selenium.Keys.Home);
                 //   tmsWait.Hard(1);
                  //  ReUsableFunctions.enterValueOnWebElementWithoutClear(cfUIMODMemberCreation.UIMODMemDemographics.UIMODDOD, value);
              //     ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemDemographics.UIMODDOD, value);
                  //  tmsWait.Hard(3);


                    tmsWait.Hard(1);
                    string generatedData = tmsCommon.GenerateData(p1);
                    string value1 = generatedData.Replace("/", "");
                  // cfUIMODMemberCreation.UIMODMemDemographics.UIMODDOD.SendKeys(Keys.Home);
                    //tmsWait.Hard(1);
                    //ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemDemographics.UIMODDOD, value1);
                    //tmsWait.Hard(3);

                    cfUIMODMemberCreation.UIMODMemDemographics.UIMODDOD.Clear();
                    tmsWait.Hard(3);
                    cfUIMODMemberCreation.UIMODMemDemographics.UIMODDOD.SendKeys(value1);
                    tmsWait.Hard(3);
                    break;
            }
            tmsWait.Hard(3);
        }

        [When(@"Add New Member page Effective Date is set to ""(.*)""")]
        public void WhenAddNewMemberPageEffectiveDateIsSetTo(string p0)
        {
            string generatedData = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='memberDemographics-txt-effectiveDate']//span[@role='button']"));

                AngularFunction.enterDate(ele, generatedData);
                tmsWait.Hard(3);

               
            }

            else
            {
                tmsWait.Hard(1);
            
            //string value = generatedData.Replace("/", "");
            //cfUIMODMemberCreation.UIMODMemDemographics.UIMODEffectiveDate.SendKeys(Keys.Home);
            //tmsWait.Hard(1);
            //ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemDemographics.UIMODEffectiveDate, value);
            tmsWait.Hard(2);
            cfUIMODMemberCreation.UIMODMemDemographics.UIMODEffectiveDate.SendKeys(OpenQA.Selenium.Keys.Home);
            cfUIMODMemberCreation.UIMODMemDemographics.UIMODEffectiveDate.SendKeys(generatedData);
            }
            tmsWait.Hard(3);
        }
        [When(@"Add New Member page Demographics section DeathDate Component is set to ""(.*)""")]
       
        [Then(@"Add New Member page Demographics section DeathDate Component is set to ""(.*)""")]
        public void ThenAddNewMemberPageDemographicsSectionDeathDateComponentIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            string generatedData = tmsCommon.GenerateData(p0);
            string value = generatedData.Replace("/", "");
            cfUIMODMemberCreation.UIMODMemDemographics.UIMODDOD.SendKeys(Keys.Home);
            tmsWait.Hard(1);
            ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemDemographics.UIMODDOD, value);
            tmsWait.Hard(3);
        }

        [Then(@"New Note page Action due date ""(.*)"" is entered")]
        public void ThenNewNotePageActionDueDateIsEntered(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            By Drp = By.XPath("//kendo-datepicker[@id='dueDate']//span[@role='button']");
            AngularFunction.enterDate(Drp, value);
            tmsWait.Hard(3);
        }

        [When(@"Add New Member page DOB is set to ""(.*)""")]
        public void WhenAddNewMemberPageDOBIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            string value = tmsCommon.GenerateData(p0);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='memberDemographics-txt-dob']//span[@role='button']"));

            AngularFunction.enterDate(ele, value);
            tmsWait.Hard(3);

        }

        [Then(@"Add New Member page Save button is clicked")]
        public void ThenAddNewMemberPageSaveButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODMemberCreation.SaveBtn);
            ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODMemberCreation.SaveBtn);
            tmsWait.Hard(30);
        }

        [Then(@"I click on Add New Member page Save button and verify message ""(.*)""")]
         public void ThenIClickOnAddNewMemberPageSaveButtonAndVerifyMessage(string p0)
        {
            tmsWait.Hard(5);
           //fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODMemberCreation.SaveBtn);
            //ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODMemberCreation.SaveBtn);
            cfUIMODMemberCreation.UIMODMemberCreation.SaveBtn.Click();
            // Toaster message verification comment due to Time out issue
            /* string actualvalue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
             //Console.Write(actualvalue);
             Assert.IsTrue(p0.ToString().Contains(actualvalue), "Message is not displayed"); */
            tmsWait.Hard(20);

        }


        [Then(@"Verify EAM Field in Database ""(.*)"" is equal to ""(.*)""")]
        public void ThenVerifyEAMFieldInDatabaseIsEqualTo(string p0, string p1)
        {
            string actual_status = tmsCommon.GenerateData(p0);
            string expected_status = tmsCommon.GenerateData(p1.ToString());
            Assert.IsTrue(actual_status.Contains(expected_status));
        }



        [Then(@"Add New Member page Correspondence Add Transaction button is clicked")]
        public void ThenAddNewMemberPageCorrespondenceAddTransactionIsClicked()
        {
            tmsWait.Hard(1);
            ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODCorrespondence.UIMODAddTransactionBtn);
        }
        [Then(@"Add New Member page Correspondence Transaction checkbox is clicked")]
        public void ThenAddNewMemberPageCorrespondenceTransactioncheckboxIsClicked()
        {
            tmsWait.Hard(3);

           
                ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODCorrespondence.AngularUIMODSelectTransaction);
           
               
        }
        [Then(@"Add New Member page Correspondence Transaction Add to Queue button is clicked")]
        public void ThenAddNewMemberPageCorrespondenceTransactionAddtoQueueIsClicked()
        {
            tmsWait.Hard(1);
            ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODCorrespondence.UIMODAddToQueueBtn);
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[contains(@class,'dialog-close')]")));
            tmsWait.Hard(1);
        }
        [Then(@"Verify Member Information Correspondence tab Letter Name ""(.*)"" is displayed")]
        public void ThenVerifyMemberInformationCorrespondenceTabLetterNameIsDisplayed(string p0)
        {
            
       
        ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(p0,cfUIMODMemberCreation.UIMODCorrespondence.UIMODLettersName);
        }
        [Then(@"Add New Member page Cancel button is clicked")]
        public void ThenAddNewMemberPageCancelButtonIsClicked()
        {
            ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODMemberCreation.CancelBtn);
            tmsWait.Hard(5);
        }

        [Then(@"Verify Successful Toaster message display ""(.*)""")]
        public void ThenVerifySuccessfulToasterMessageDisplay(string p0)
        {
            ReUsableFunctions.toasterMessageDisplayVerification(p0);
            tmsWait.Hard(8);
        }

        [Then(@"Verify New Member Page Display Missing Fields of MemberInfo Error Messages as ""(.*)""")]
        public void ThenVerifyNewMemberPageDisplayMissingFieldsOfMemberInfoErrorMessagesAs(string p0)
        {

        ReUsableFunctions.ErrorMessageDisplay(p0);
        }

        [Then(@"Verify Member Information Plan Defined Fields section ""(.*)"" checkbox is ""(.*)""")]
        public void ThenVerifyMemberInformationPlanDefinedFieldsSectionCheckboxIs(string p0, string p1)
        {
            string componentType = tmsCommon.GenerateData(p0);
            string typeofAction = tmsCommon.GenerateData(p1);
            switch (componentType)
            {
                case "Send Plan 10 on Legacy":
                    ReUsableFunctions.CheckBoxStatus(cfUIMODMemberCreation.UIMODPlanDefinedFields.SendPlan10OnLegacyCheckbox, typeofAction);
                    break;
                case "Use Mapping":
                    ReUsableFunctions.CheckBoxStatus(cfUIMODMemberCreation.UIMODPlanDefinedFields.UseMappingCheckbox, typeofAction);
                    break;
                default:
                    break;
            }
        }
    }


}

