﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1
{
    [Binding]
    class fsOSB
    {

        [When(@"Create EAM Database connection ""(.*)"" Execute Query ""(.*)"" and Verify below Table Values")]
        public void WhenCreateEAMDatabaseConnectionExecuteQueryAndVerifyBelowTableValues(string connection, string p1, Table table)
        {
            string query = tmsCommon.GenerateData(p1);

            //Creating connection for EAM dB

            db.CreateConn(connection);

            //
            string dbQuery = tmsCommon.GenerateData(query);
            db.AddDBQuery(connection, dbQuery);
            db.VerifyDBResultsToTable(connection, table);
        }

        

        [When(@"Make EAM DB connection ""(.*)"" Execute Delete Query ""(.*)""")]
        public void WhenMakeEAMDBConnectionExecuteDeleteQuery(string connection, string p1)
        {
            string query = tmsCommon.GenerateData(p1);

            //Creating connection for EAM dB


            db.CreateConn(connection);

            //
            string dbQuery = tmsCommon.GenerateData(query);
            db.AddDBQuery(connection, dbQuery);
            tmsWait.Hard(15); // Reason for more Wait is Table field updation is taking time. please do not remove this wait
           
            string result = db.returnSQLQueryresultsBasedOnIndex(query, 0);

        }

        [When(@"Create RAM DB connection ""(.*)"" Execute Query ""(.*)"" based on Index ""(.*)"" Generate Payment Year assign to variable ""(.*)""")]
        public void WhenCreateRAMDBConnectionExecuteQueryBasedOnIndexGeneratePaymentYearAssignToVariable(string connection, string p1, int p2, string p3)
        {
            string query = tmsCommon.GenerateData(p1);
            int index = p2;
            string outputVar = tmsCommon.GenerateData(p3);

            //Creating connection for RAM dB


            db.CreateConnRAM(connection);

            // adding Query
            string dbQuery = tmsCommon.GenerateData(query);
            db.AddDBQuery(connection, dbQuery);

            
            string result = db.returnSQLQueryresultsBasedOnIndex(connection, index);

            // Generate Payment Year and assign 
            string currentYearPlusOne = (Convert.ToInt32(((result.Split('/')[2]).Split(' '))[0]) + 1).ToString();
            fw.ConsoleReport(" Payment Year " + currentYearPlusOne);
            fw.setVariable(outputVar, currentYearPlusOne);
        }


        [When(@"Create RAM DB connection ""(.*)"" Execute Query ""(.*)"" based on Index ""(.*)"" assign this value to variable ""(.*)""")]
        public void WhenCreateRAMDBConnectionExecuteQueryBasedOnIndexAssignThisValueToVariable(string connection, string p1, int p2, string p3)
        {

            string query = tmsCommon.GenerateData(p1);
            int index = p2;
            string outputVar = tmsCommon.GenerateData(p3);

            //Creating connection for RAM dB


            db.CreateConnRAM(connection);

            //
            string dbQuery = tmsCommon.GenerateData(query);
            db.AddDBQuery(connection, dbQuery);

            //tmsWait.Hard(15); // Reason for more Wait is Table field updation is taking time. please do not remove this wait
           // db.OutputDBResults(connection);

           // fw.ConsoleReport(" Executed SQL query related to Delete");

            string result = db.returnSQLQueryresultsBasedOnIndex(connection, index);

            // Commenting below statement as SQL Message box wont return anything
            
            fw.setVariable(outputVar, result.Trim());

        }


        [When(@"Create EAM DB connection ""(.*)"" Execute Query ""(.*)"" based on Index ""(.*)"" assign this value to variable ""(.*)""")]
        public void WhenCreateEAMDBConnectionExecuteQueryBasedOnIndexAssignThisValueToVariable(string connection, string p1, int p2, string p3)
        {
          
            string query = tmsCommon.GenerateData(p1);
            int index = p2;
            string outputVar = tmsCommon.GenerateData(p3);

            //Creating connection for EAM dB


           db.CreateConn(connection);

           //
           string dbQuery = tmsCommon.GenerateData(query);
            db.AddDBQuery(connection, dbQuery);

            tmsWait.Hard(15); // Reason for more Wait is Table field updation is taking time. please do not remove this wait
           // db.OutputDBResults(connection);

            string result = db.returnSQLQueryresultsBasedOnIndex(connection, index);

            fw.ConsoleReport(" Executed SQL query related to Delete");

        }

        [When(@"Create PDEM DB connection ""(.*)"" Execute Query ""(.*)"" based on Index ""(.*)"" assign this value to variable ""(.*)""")]
        public void WhenCreatePDEMDBConnectionExecuteQueryBasedOnIndexAssignThisValueToVariable(string connection, string p1, int p2, string p3)
        {

            string query = tmsCommon.GenerateData(p1);
            int index = p2;
            string outputVar = tmsCommon.GenerateData(p3);

            //Creating connection for PDEM DB


            db.CreateConnPDEM(connection);

            //
            string dbQuery = tmsCommon.GenerateData(query);
            db.AddDBQuery(connection, dbQuery);

            //tmsWait.Hard(15); // Reason for more Wait is Table field updation is taking time. please do not remove this wait
            // db.OutputDBResults(connection);

            // fw.ConsoleReport(" Executed SQL query related to Delete");

            string result = db.returnSQLQueryresultsBasedOnIndex(connection, index);

            // Commenting below statement as SQL Message box wont return anything

            fw.setVariable(outputVar, result.Trim());

        }
    }
    }
