﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using OpenQA.Selenium.Support.UI;

namespace TMSoR1.FrameworkCode.EAM
{
    [Binding]
    class fsTestMember
    {
        [When(@"New Member page MBI Value is set to ""(.*)""")]
        public void WhenNewMemberPageMBIValueIsSetTo(string p0)
        {
            string mbi = tmsCommon.GenerateData(p0);
            cfTestMember.TestMemberPage.MBI.SendKeys(mbi);
        }


        [When(@"New Member page Save button is Clicked")]
        public void WhenNewMemberPageSaveButtonIsClicked()
        {
            fw.ExecuteJavascript(cfTestMember.TestMemberPage.Save);
            //cfTestMember.TestMemberPage.Save.Click();
        }

        [Then(@"Verify New Member page displayed Error message as ""(.*)""")]
        public void ThenVerifyNewMemberPageDisplayedErrorMessageAs(string p0)
        {
            string msg = tmsCommon.GenerateData(p0);

            IWebElement errorMsg = Browser.Wd.FindElement(By.XPath("//div[@id='ctl00_ctl00_MainMasterContent_MainContent_ValidationSummary1']//li[contains(.,'"+ msg + "')]"));
            bool elementPresence = errorMsg.Displayed;

            Assert.IsTrue(elementPresence,p0+" is not displayed");
        }

        [When(@"New Members page PlanID is set to ""(.*)""")]
        public void WhenNewMembersPagePlanIDIsSetTo(string planid1)
        {
            String planid = tmsCommon.GenerateData(planid1);
            SelectElement select = new SelectElement(cfTestMember.TestMemberPage.PlanID);
            select.SelectByText(planid);

            
        }
        [When(@"New Members page Firstname is set to ""(.*)""")]
        public void WhenNewMembersPageFirstnameIsSetTo(string fname1)
        {
            
        }

        


        [When(@"New Members page Lname is set to ""(.*)""")]
        public void WhenNewMembersPageLnameIsSetTo(string lname1)
        {
            String lname = tmsCommon.GenerateData(lname1);
            fw.ExecuteJavascriptSetText(cfTestMember.TestMemberPage.Lname, lname1);
        }

        [When(@"New Members page EffDate is set to ""(.*)""")]
        public void WhenNewMembersPageEffDateIsSetTo(string effDate)
        {
            String effdate = tmsCommon.GenerateData(effDate);
            fw.ExecuteJavascriptSetText(cfTestMember.TestMemberPage.EffDate, effdate);

        }

        [When(@"New Members page PBP is set to ""(.*)""")]
        public void WhenNewMembersPagePBPIsSetTo(String pbp1)
        {
           String pbp = tmsCommon.GenerateData(pbp1);
            fw.ExecuteJavascriptSetText(cfTestMember.TestMemberPage.PBP, pbp);

        }
        [When(@"New Members page  sex is set to ""(.*)""")]
        public void WhenNewMembersPageSexIsSetTo(string s)
        {
            String sex = tmsCommon.GenerateData(s);
            fw.ExecuteJavascriptSetText(cfTestMember.TestMemberPage.Sex, sex);
        }

        [Then(@"Verify New Member page displayed Success message as ""(.*)""")]
        public void ThenVerifyNewMemberPageDisplayedSuccessMessageAs(string msg)
        {
            IWebElement successMsg = Browser.Wd.FindElement(By.XPath("//span[@id='ctl00_ctl00_MainMasterContent_MainContent_lblMsg']"));
            bool msg1 = successMsg.Displayed;
            Assert.IsTrue(msg1, msg + "not displayed");
        }

        [When(@"New Members page DOB  is set to ""(.*)""")]
        public void WhenNewMembersPageDOBIsSetTo(string dob1)
        {
            String dob = tmsCommon.GenerateData(dob1);
            fw.ExecuteJavascriptSetText(cfTestMember.TestMemberPage.DOB, dob1);
        }

        [When(@"New Members page RX ID is set to ""(.*)""")]
        public void WhenNewMembersPageRXIDIsSetTo(string rx)
        {
            String rxId = tmsCommon.GenerateData(rx);
            fw.ExecuteJavascriptSetText(cfTestMember.TestMemberPage.RxID, rxId);
        }
        [When(@"New Members page MemberID is set to ""(.*)""")]
        public void WhenNewMembersPageMemberIDIsSetTo(string mem)
        {
            String mem1 = tmsCommon.GenerateData(mem);
            fw.ExecuteJavascriptSetText(cfTestMember.TestMemberPage.MemberId, mem1);
        }

    }


}
