﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using TMSoR1.FrameworkCode;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;


namespace TMSoR1.FrameworkCode.EAM
{
    [Binding]
    class fsUIMODNewTransaction
    {

       

        [When(@"Add New Transaction page ""(.*)"" Component is set to ""(.*)""")]
        public void WhenAddNewTransactionPageComponentIsSetTo(string p0, string p1)
        {
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (componentType)
            {
                case "Transaction Code":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By TCDrp = By.XPath("//*[@test-id='transaction-select-code']//span[@class='k-select']");
                        By TCCode = By.XPath("//li[text()='" + value + "']");


                        UIMODUtilFunctions.clickOnWebElementUsingLocators(TCDrp);
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(TCCode);



                    }
                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.UIMODCreateTransactionBasic.TCCodeDropDownList);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODCreateTransaction.UIMODCreateTransactionBasic.TCCodeDropDownList, value);
                        tmsWait.Hard(3);
                    }
                    break;
          
                case "Type of Application":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By TCDrp = By.XPath("//label[contains(.,'Type of Application')]/parent::div//span[@class='k-select']");
                        By TCCode = By.XPath("//li[text()='" + value + "']");


                        UIMODUtilFunctions.clickOnWebElementUsingLocators(TCDrp);
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(TCCode);



                    }
                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.UIMODCreateTransactionBasic.TypeOfApplicationDropDownList);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODCreateTransaction.UIMODCreateTransactionBasic.TypeOfApplicationDropDownList, value);
                    }
                    break;
                  case "Address2":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {

                        By Drp = By.XPath("//label[contains(.,'Residence Address 2')]/parent::div//input");
                        Browser.Wd.FindElement(Drp).Clear();
                        Browser.Wd.FindElement(Drp).SendKeys(value);

                        tmsWait.Hard(3);

                    }
                    else
                    {
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemContacts.UIMODSecondAddress2, value);
                    }
                    break;
                   case "Phone":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {

                        By Drp = By.XPath("(//label[text()='Phone']/parent::div//input)[1]");
                        Browser.Wd.FindElement(Drp).Clear();
                        Browser.Wd.FindElement(Drp).SendKeys(value);

                        tmsWait.Hard(3);

                    }
                    else
                    {
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemContacts.UIMODSecondPhone, value);
                    }
                       break;
                   case "Zip":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {

                        By Drp = By.XPath("(//label[text()='Zip']/parent::div//input)[1]");
                        Browser.Wd.FindElement(Drp).Clear();
                        Browser.Wd.FindElement(Drp).SendKeys(value);

                        tmsWait.Hard(3);

                    }
                    else
                    {
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemContacts.UIMODSecondZip, value);
                        //System.Windows.Forms.SendKeys.SendWait("{TAB}");
                    }
                    break;
                case "Segment Id":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By TCDrp = By.XPath("//label[contains(.,'Segment ID')]/parent::div//span[@class='k-select']");
                        By TCCode = By.XPath("//li[text()='" + value + "']");


                        UIMODUtilFunctions.clickOnWebElementUsingLocators(TCDrp);
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(TCCode);



                    }
                    else
                    {

                        By plan = By.XPath("//div[@id='div_DemographicDetailsPlanId']/span");
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(plan);
                        tmsWait.Hard(1);
                        UIMODUtilFunctions.selectTransDrpValue(value);
                    }
                    break;
                case "Receipt Date":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                         value = value.Replace("/", "");
                        By Drp = By.XPath("//label[contains(.,'Receipt Date')]/parent::div//input");
                        Browser.Wd.FindElement(Drp).Clear();
                        Browser.Wd.FindElement(Drp).SendKeys(value);

                        tmsWait.Hard(3);

                    }
                    else
                    {
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransDemographics.ReceiptDate, value);
                        //System.Windows.Forms.SendKeys.SendWait("{TAB}");
                    }
                    break;
                case "MemberID":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                      
                        By Drp = By.XPath("//label[contains(.,'Member ID')]/parent::div//input");
                        Browser.Wd.FindElement(Drp).Clear();
                        Browser.Wd.FindElement(Drp).SendKeys(value);

                        tmsWait.Hard(3);

                    }
                    else
                    {
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransDemographics.MemberID, value);
                        //System.Windows.Forms.SendKeys.SendWait("{TAB}");
                    }
                    break;
            }
        }



        //[When(@"Add New Transaction page ""(.*)"" Component is set to ""(.*)""")]
        //public void WhenAddNewTransactionPageComponentIsSetTo(string p0, string p1)
        //{
        //    string componentType = tmsCommon.GenerateData(p0);
        //    string value = tmsCommon.GenerateData(p1);
        //    switch (componentType)
        //    {
        //        case "Transaction Code":
        //            ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.UIMODCreateTransactionBasic.TCCodeDropDownList);
        //            UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODCreateTransaction.UIMODCreateTransactionBasic.TCCodeDropDownList, value);
        //            break;
        //        case "Type of Application":
        //            ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.UIMODCreateTransactionBasic.TypeOfApplicationDropDownList);
        //            UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODCreateTransaction.UIMODCreateTransactionBasic.TypeOfApplicationDropDownList, value);
        //            break;
        //            //case "Address2":
        //            //    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemContacts.UIMODSecondAddress2, value);
        //            //    break;
        //            //case "Phone":
        //            //    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemContacts.UIMODSecondPhone, value);
        //            //    break;
        //            //case "Zip":
        //            //    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemContacts.UIMODSecondZip, value);
        //            //    //System.Windows.Forms.SendKeys.SendWait("{TAB}");
        //            //    break;
        //    }
        //}
    }
}
