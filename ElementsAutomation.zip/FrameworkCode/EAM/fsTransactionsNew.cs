﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows;
using System.Drawing;
using OpenQA.Selenium.Support.UI;
using System.Collections.ObjectModel;
using OpenQA.Selenium.Interactions;
using TMSoR1.FrameworkCode;

namespace TMSoR1
{
    [Binding]
    class fsTransactionsNew
    {

        public string Displayed;
        public string FieldStatus;

        [When(@"Transactions New page City is set to ""(.*)""")]
        public void WhenTransactionsNewPageCityIsSetTo(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0);
            Assert.IsTrue(EAM.TransactionsNew76.City.Text.Equals(strValue));
        }

        [When(@"Transactions New page State is set to ""(.*)""")]
        public void WhenTransactionsNewPageStateIsSetTo(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0);
            Assert.IsTrue(EAM.TransactionsNew76.State.Text.Equals(strValue));
        }

        [When(@"Transactions Newpage County is set to ""(.*)""")]
        public void WhenTransactionsNewpageCountyIsSetTo(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0);
            Assert.IsTrue(EAM.TransactionsNew61.County.Text.Equals(strValue));
        }

        [When(@"Transactions New (.*) Zip code is set to ""(.*)""")]
        public void WhenTransactionsNewZipCodeIsSetTo(int p0, string p1)
        {
            string strValue = tmsCommon.GenerateData(p1);
            tmsWait.Hard(2);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Zip')]/parent::div//input");
                EAM.TransactionsNew61.AngZip.Click();
                tmsWait.Hard(2);
                EAM.TransactionsNew61.AngZip.SendKeys(strValue);
                tmsWait.Hard(2);
                EAM.TransactionsNew61.AngZip.SendKeys(Keys.Tab);
                tmsWait.Hard(2);
            }
            else
            {


                EAM.TransactionsNew61.Zip.Click();
                tmsWait.Hard(2);
                EAM.TransactionsNew61.Zip.SendKeys(strValue);
                tmsWait.Hard(2);
                EAM.TransactionsNew61.Zip.SendKeys(Keys.Tab);
                tmsWait.Hard(2);

            }
        }


        [When(@"Verify Transactions New HIC is set to ""(.*)""")]
        [Then(@"Verify Transactions New HIC is set to ""(.*)""")]
        public void WhenVerifyTransactionsNewHICIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            string strValue = tmsCommon.GenerateData(p0).ToLower();
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'MBI')]/parent::div//input");

                string actValue = Browser.Wd.FindElement(Drp).GetAttribute("value");

                Assert.AreEqual(strValue.ToUpper(), actValue.ToUpper(), " Both values are not matching");

                tmsWait.Hard(3);


            }
            else
            {
                string thisFieldValue = EAM.TransactionsNew.HIC.GetAttribute("value").ToLower();
                Assert.AreEqual(strValue, thisFieldValue, "Field HIC value is [{0}], expected [{1}]", thisFieldValue, strValue);
                fw.ConsoleReport(string.Format("   Verification Point: Field HIC value is [{0}], expected [{1}] - They are expected to match.", thisFieldValue, strValue));
            }
        }



        [Then(@"Verify Transactions New Program Source is set to ""(.*)""")]
        public void ThenVerifyTransactionsNewProgramSourceIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            string strValue = tmsCommon.GenerateData(p0).ToLower();
            string thisFieldValue = EAM.TransactionsNew.ProgramSource.Text.ToLower();
            Assert.AreEqual(strValue, thisFieldValue, "Field Program source is [{0}], expected [{1}]", thisFieldValue, strValue);
            fw.ConsoleReport(string.Format("   Verification Point: Field Program Source is [{0}], expected [{1}] - They are expected to match.", thisFieldValue, strValue));
        }




        [Then(@"Verify Transactions New PW Option is set to ""(.*)""")]
        public void ThenVerifyTransactionsNewPWOptionIsSetTo(string p0)
        {
            if (p0.Contains("|"))
            {
                string[] value = p0.Split('|');
                tmsWait.Hard(1);
                string strValue = tmsCommon.GenerateData(p0);
                string thisFieldValue = EAM.TransactionsNew.PremWithholdOption.GetAttribute("value");
                if (thisFieldValue.Contains(value[0]))
                {
                    Assert.AreEqual(thisFieldValue, value[0], "Expected value of PW option is not matching with catual value");
                }
                else
                {

                    Assert.AreEqual(thisFieldValue, value[1], "Expected value of PW option is not matching with catual value");
                }
            }
            else
            {
                tmsWait.Hard(1);
                string strValue = tmsCommon.GenerateData(p0);
                string thisFieldValue = Browser.Wd.FindElement(By.XPath("//select[@id='ctl00_ctl00_MainMasterContent_MainContent_drpPremium_18']//option[@selected='selected']")).Text;
                Assert.AreEqual(strValue, thisFieldValue, "Field HIC value is [{0}], expected [{1}]", thisFieldValue, strValue);
                fw.ConsoleReport(string.Format("   Verification Point: Field HIC value is [{0}], expected [{1}] - They are expected to match.", thisFieldValue, strValue));
            }
        }


        [When(@"Transactions New EGHP is set to ""(.*)""")]
        public void WhenTransactionsNewEGHPIsSetTo(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {

                if (p0.Contains("Y"))
                {
                    p0 = "Yes";
                }
                if (p0.Contains("N"))
                {
                    p0 = "No";
                }
                By Drp = By.XPath("//label[contains(.,'EGHP')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + strValue + "']");


                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
            }
            else
            {
                By eghp = By.XPath("//div[@id='div_DemographicDetailsEGHP']/span");

                UIMODUtilFunctions.clickOnWebElementUsingLocators(eghp);
                tmsWait.Hard(1);
                By value = By.XPath("(//ul[@role='listbox']/li[.='" + strValue + "'])[2]");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(value);
                // Browser.Wd.FindElement(value).SendKeys(Keys.Tab);
            }

        }


        [When(@"Transactions New ""(.*)"" EGHP is set to ""(.*)""")]
        public void WhenTransactionsNewEGHPIsSetTo(int p0, string p1)
        {

            string transcode = tmsCommon.GenerateData(p0.ToString());
            string value = tmsCommon.GenerateData(p1);

            if (ConfigFile.tenantType.Equals("tmsx") && (transcode.Equals("80") || transcode.Equals("81") || transcode.Equals("74") || transcode.Equals("51")))
            {

                if (value.Contains("Y"))
                {
                    value = "Yes";
                }
                if (value.Contains("N"))
                {
                    value = "No";
                }
                By Drp = By.XPath("//label[contains(.,'EGHP')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + value + "']");


                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
            }
            else
            {

                By eghp = By.XPath("//div[@id='div_DemographicDetailsEGHP']/span");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(eghp);
                tmsWait.Hard(1);
                if (transcode == "81" || transcode == "51" || transcode == "74" || transcode == "80")
                {
                    transcode = "other";
                }

                switch (transcode)
                {
                    case "other":
                        By listvalue = By.XPath("//li[text()='" + value + "']");
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(listvalue);
                        break;
                        //case "51": By listvalue1 = By.XPath("//li[text()='" + value + "']");
                        //           UIMODUtilFunctions.clickOnWebElementUsingLocators(listvalue1);
                        //           break;
                }
            }
        }



        [When(@"Transactions New PartD OptOut is set to ""(.*)""")]
        public void WhenTransactionsNewPartDOptOutIsSetTo(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0.ToString());
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Part D Opt-Out')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + strValue + "']");


                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);



            }
            else
            {
                By partD = By.XPath("//div[@id='div_DemographicDetailsPartDOptOut']/span");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(partD);
                tmsWait.Hard(1);
                UIMODUtilFunctions.selectTransDrpValue(strValue);
            }
        }
        IWebElement eam;
        [Then(@"Verify EAM Application is Opened Successfully")]
        public void ThenVerifyEAMApplicationIsOpenedSuccessfully()
        {
            tmsWait.Hard(2);
            try
            {
                eam = Browser.Wd.FindElement(By.CssSelector("[test-id='eamDashboard-span-title']"));
                Assert.IsTrue(eam.Displayed, "EAM Application is Opened successfully");
            }
            catch
            {
                Assert.Fail("EAM Application is not loaded with in Specified time.");
            }

            //   Assert.IsTrue(eam.Displayed, "EAM is not geting Opened");

        }
        IWebElement cdm;
        [Then(@"Verify CDM Application is Opened Successfully")]
        public void ThenVerifyCDMApplicationIsOpenedSuccessfully()
        {
            tmsWait.Hard(5);
            try
            {
                cdm = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Claims Data Manager')]"));
            }

            catch
            {
                Assert.Fail(" CDM Application is not loaded with in Specified time.");
            }
            Assert.IsTrue(cdm.Displayed, "CDM is not getting Opened");

        }
        IWebElement dlm;
        [Then(@"Verify DLM Application is Opened Successfully")]
        public void ThenVerifyDLMApplicationIsOpenedSuccessfully()
        {
            tmsWait.Hard(3);
            try
            {
                dlm = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Data Load Manager')]"));
            }
            catch
            {
                Assert.Fail(" DLM Application is not loaded with in Specified time.");
            }
            Assert.IsTrue(dlm.Displayed, "DLM is not getting Opened");
        }
        IWebElement rxm;
        [Then(@"Verify RXM Application is Opened Successfully")]
        public void ThenVerifyRXMApplicationIsOpenedSuccessfully()
        {

            tmsWait.Hard(3);
            try
            {
                rxm = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Rx Reconciliation Manager')]"));
            }
            catch
            {
                Assert.Fail(" RxM Application is not loaded with in Specified time.");
            }
            Assert.IsTrue(rxm.Displayed, "RxM is not getting Opened");


        }
        IWebElement frm;

        [Then(@"Verify FRM Application is Opened Successfully")]
        public void ThenVerifyFRMApplicationIsOpenedSuccessfully()
        {
            tmsWait.Hard(5);
            try
            {
                frm = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Financial Reconciliation Manager')]"));
            }
            catch
            {
                Assert.Fail(" FRM Application is not loaded with in Specified time.");
            }
            Assert.IsTrue(frm.Displayed, "FRM is not getting Opened");

        }

        IWebElement rsm;
        [Then(@"Verify RSM Application is Opened Successfully")]
        public void ThenVerifyRSMApplicationIsOpenedSuccessfully()
        {

            tmsWait.Hard(5);
            try
            {
                rsm = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Risk Score Manager')]"));
            }
            catch
            {
                Assert.Fail(" RSM Application is not loaded with in Specified time.");
            }

            Assert.IsTrue(rsm.Displayed, "RSM is not geting Opened");
        }
        IWebElement pdem;
        [Then(@"Verify PDEM Application is Opened Successfully")]
        public void ThenVerifyPDEMApplicationIsOpenedSuccessfully()
        {
            tmsWait.Hard(5);
            try
            {
                pdem = Browser.Wd.FindElement(By.XPath("//span[contains(.,'PDE Data Manager')]"));
            }
            catch
            {
                Assert.Fail(" PDEM Application is not loaded with in Specified time.");
            }

            Assert.IsTrue(pdem.Displayed, "PDEM is not geting Opened");



        }
        IWebElement ram;
        IWebElement ramx;
        [Then(@"Verify RAMX Application is Opened Successfully")]
        public void ThenVerifyRAMXApplicationIsOpenedSuccessfully()
        {
            tmsWait.Hard(5);
            try
            {
                ramx = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Risk Adjustment Manager for Exchanges')]"));
            }
            catch
            {
                Assert.Fail(" RAMX Application is not loaded with in Specified time.");
            }
            Assert.IsTrue(ramx.Displayed, "RAMX Application is not getting Opened");
        }


        [Then(@"Verify RAM Application is Opened Successfully")]
        public void ThenVerifyRAMApplicationIsOpenedSuccessfully()
        {
            tmsWait.Hard(5);
            try
            {
                ram = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Risk Adjustment Manager')]"));
            }
            catch
            {
                Assert.Fail(" RAM Application is not loaded with in Specified time.");
            }
            Assert.IsTrue(ram.Displayed, "RAM Application is not getting Opened");
        }


        [Then(@"Verify Disenrollment Reason ""(.*)"" is found on drop down")]
        public void ThenVerifyDisenrollmentReasonIsFoundOnDropDown(string p0)
        {
            IWebElement drp = Browser.Wd.FindElement(By.Id("div_DemographicDetailsDisenReason"));
            SelectElement drpdownlist = new SelectElement(drp);
            IList<IWebElement> lidrp = drpdownlist.Options;

            foreach (IWebElement temp in lidrp)
            {
                if (temp.Text.Contains(p0))
                {
                    Console.WriteLine(p0 + " is found on Dis Enrollment Reason");
                    break;
                }
            }
        }

        [When(@"Clicked on DisEnrollment Reason PopUp")]
        public void WhenClickedOnDisEnrollmentReasonPopUp()
        {
            IWebElement drp = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_GlossaryIconButton4"));
            fw.ExecuteJavascript(drp);
            tmsWait.Hard(3);
        }

        [When(@"Transactions New DisEnrollment Reason code is set to ""(.*)""")]
        public void WhenTransactionsNewDisEnrollmentReasonCodeIsSetTo(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0.ToString());
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Disen. Reason')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + strValue + "']");


                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);



            }
            else
            {
                By disenrollReason = By.XPath("//div[@id='div_DemographicDetailsDisenReason']/span");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(disenrollReason);
                tmsWait.Hard(1);
                UIMODUtilFunctions.selectTransDrpValue(strValue);
            }


        }

        [Then(@"Verify DisEnrollment Reason displays ""(.*)""")]
        public void ThenVerifyDisEnrollmentReasonDisplays(string p0)
        {
            IWebElement value = Browser.Wd.FindElement(By.XPath("//div[@id='cboDisenReason_13_glossaryPanel']//table//tr[contains(.,'" + p0 + "')]"));
            Assert.IsTrue(value.Displayed, p0 + " is not getting displayed");
        }


        [Then(@"Main EAF Fallout Records Page Trans Code is set to ""(.*)""")]
        public void ThenMainEAFFalloutRecordsPageTransCodeIsSetTo(String p0)
        {
            string strValue = tmsCommon.GenerateData(p0);

            By TCCode = By.CssSelector("[aria-owns='inputBoxTransCode_listbox']");
            UIMODUtilFunctions.selectDropDownValueFromGendoUI(Browser.Wd.FindElement(TCCode), strValue);

            tmsWait.Hard(8);
        }
        [Then(@"Main EAF Fallout Records Page ""(.*)"" is set to ""(.*)""")]
        public void ThenMainEAFFalloutRecordsPageIsSetTo(string p0, string p1)
        {
            //string strValue = tmsCommon.GenerateData(p0);
            string GeneratedData = tmsCommon.GenerateData(p1);
            switch (p0)
            {
                case "Trans Code":


                    By TCCode = By.CssSelector("[aria-owns='inputBoxTransCode_listbox']");
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(Browser.Wd.FindElement(TCCode), p1);

                    tmsWait.Hard(8);
                    break;

                case "File Name":


                    string id = "formInputBoxAUD_listbox";
                    UIMODUtilFunctions.selectDropDownIndexFromGendoUI(id);

                    tmsWait.Hard(8);
                    break;
            }
        }

        [When(@"Transactions New Trans Code is set to ""(.*)""")]
        [Given(@"Transactions New Trans Code is set to ""(.*)""")]
        [Then(@"Transactions New Trans Code is set to ""(.*)""")]
        public void WhenTransactionsNewTransCodeIsSetTo(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0);
            tmsWait.Hard(5);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                AngularFunction.selectDropDownValue(cfAngularTransaction.AngularNewTransaction.TCCode, strValue);
                

            }
            else
            {
                By TCCode = By.CssSelector("[aria-owns='transactionCode_listbox']");
                UIMODUtilFunctions.selectDropDownValueFromGendoUI(Browser.Wd.FindElement(TCCode), strValue);

                tmsWait.Hard(8);
            }
           

        }
        [When(@"Transactions page EGHP value is set to ""(.*)""")]
        public void WhenTransactionsPageEGHPValueIsSetTo(string p0)
        {
            if (p0.Contains("Y"))
            {
                p0 = "Yes";
            }
            if (p0.Contains("N"))
            {
                p0 = "No";
            }

            if (ConfigFile.tenantType.Equals("tmsx"))
            {

                AngularFunction.selectDropDownValue(cfAngularTransaction.AngularNewTransaction.EGHP, p0);

                //By Drp = By.XPath("//label[contains(.,'EGHP')]/parent::div//span[@class='k-select']");
                //By typeapp = By.XPath("//li[text()='" + p0 + "']");


                //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                //tmsWait.Hard(3);
                //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
            }
            else
            {
                By eghpMOD = By.XPath("//div[@id='div_DemographicDetailsEGHP']/span");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(eghpMOD);
                tmsWait.Hard(1);
                UIMODUtilFunctions.selectTransDrpValue(p0);
            }


        }

        [When(@"Transactions New Employer Group Number is set to ""(.*)""")]
        public void WhenTransactionsNewEmployerGroupNumberIsSetTo(string p0)
        {
            string empgnumber = tmsCommon.GenerateData(p0);
            By Drp = By.XPath("//label[contains(.,'Employer Group Number')]/parent::div//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + empgnumber + "']");
             UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
        }


        [When(@"Transactions New Credit Cover is set to ""(.*)""")]
        public void WhenTransactionsNewCreditCoverIsSetTo(string cover)
        {
            string p0 = tmsCommon.GenerateData(cover);
            tmsWait.Hard(2);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Credit Cover.')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + p0 + "']");


                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

                tmsWait.Hard(3);
            }
            else
            {
                By creditcover = By.XPath("//div[@id='div_DemographicDetailsCreditCover']/span");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(creditcover);
                tmsWait.Hard(1);
                UIMODUtilFunctions.selectTransDrpValue(p0);
            }

        }

        [When(@"Run Report button is Clicked")]
        public void WhenRunReportButtonIsClicked()
        {
            tmsWait.Hard(2);
            IWebElement report = Browser.Wd.FindElement(By.XPath("//input[@id='reportGen']"));
            fw.ExecuteJavascript(report);
        }

        [Then(@"Verify Election Type Validation Report displays ""(.*)""")]
        public void ThenVerifyElectionTypeValidationReportDisplays(string p0)
        {
            Browser.SwitchToChildWindow();
            Browser.SwitchToIFrame();
            bool presence = true;


            while (presence)
            {
                try
                {
                    IWebElement ele = Browser.Wd.FindElement(By.XPath("//table[@id='ReportViewerControl_fixedTable']//div[contains(text(),'OEVTest723')]"));
                    Assert.IsTrue(ele.Displayed);
                    presence = false;

                }
                catch
                {
                    IWebElement next = Browser.Wd.FindElement(By.XPath("//div[@id='ReportViewerControl_ctl05_ctl00_Next_ctl00']//table//input[@id='ReportViewerControl_ctl05_ctl00_Next_ctl00_ctl00']"));
                    fw.ExecuteJavascript(next);

                }

            }
        }

        [When(@"Transactions New Part C Premium Amount is set to ""(.*)""")]
        public void WhenTransactionsNewPartCPremiumAmountIsSetTo(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By partc = By.XPath("//label[contains(.,'Prem. Amount C')]/parent::div/div//input");
                Browser.Wd.FindElement(partc).Clear();
                Browser.Wd.FindElement(partc).SendKeys(strValue);


            }
            else
            {


                By partc = By.CssSelector("[test-id='DemographicDetailsPremAmtC']");
                Browser.Wd.FindElement(partc).Clear();
                Browser.Wd.FindElement(partc).SendKeys(strValue);
            }
        }


        [When(@"Transactions New HIC is set to ""(.*)""")]
        public void WhenTransactionsNewHICIsSetTo(string p0)
        {
            tmsWait.Hard(10);
            string strValue = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                AngularFunction.sendKeysWithClear(cfAngularTransaction.AngularNewTransaction.MBI, strValue);

                GlobalRef.TransMBI = strValue;
                GlobalRef.LTMBI = strValue;
            }
            else
            {
                EAM.TransactionsNew.HIC.SendKeys(strValue);
                tmsWait.Hard(3);
                GlobalRef.TransMBI = strValue;
                GlobalRef.LTMBI = strValue;
            }

        }



        [When(@"Transactions New PBPID Value is set to ""(.*)""")]
        public void WhenTransactionsNewPBPIDValueIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string strValue = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                AngularFunction.selectDropDownValue(cfAngularTransaction.AngularNewTransaction.PBPDrp, strValue);
                
                //By Drp = By.XPath("//label[contains(.,'PBP')]/parent::div//span[@class='k-select']");
                //By typeapp = By.XPath("//li[text()='" + strValue + "']");


                //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                //tmsWait.Hard(3);
                //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
            }
            else
            {

                By pbp = By.XPath("//div[@id='div_DemographicDetailsPbp']/span");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(pbp);
                tmsWait.Hard(2);
                UIMODUtilFunctions.selectTransDrpValue(strValue);
            }

        }

        [Then(@"Transactions New PlanID is set to ""(.*)""")]
        [When(@"Transactions New PlanID is set to ""(.*)""")]
        public void WhenTransactionsNewPlanIDIsSetTo(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                //By Drp = By.XPath("//label[contains(.,'Plan ID')]/parent::div//span[@class='k-select']");
                //By typeapp = By.XPath("//li[text()='" + strValue + "']");
                //fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                //fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                AngularFunction.selectDropDownValue(cfAngularTransaction.AngularNewTransaction.PlanIDDrp, strValue);
                tmsWait.Hard(3);
            }
            else
            {
                By plan = By.XPath("//div[@id='div_DemographicDetailsPlanId']/span");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(plan);
                tmsWait.Hard(1);
                UIMODUtilFunctions.selectTransDrpValue(strValue);
                tmsWait.Hard(1);
                Browser.Wd.FindElement(plan).SendKeys(Keys.Escape);
                tmsWait.Hard(1);
            }
        }

        [When(@"Transactions MemberID is set to ""(.*)""")]
        public void WhenTransactionsMemberIDIsSetTo(string p0)
        {
            By mem;
            string strValue = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType == "tmsx")
                mem=By.XPath("//label[contains(.,'Member ID')]/parent::div//input");
            else
                mem = By.CssSelector("[test-id='DemographicDetailsMemberID']");

            UIMODUtilFunctions.enterValueOnWebElementUsingLocators(mem, strValue);
        }

        [Then(@"Verify Transactions New Disen\.Reason field does not have value ""(.*)""")]
        public void ThenVerifyTransactionsNewDisen_ReasonFieldDoesNotHaveValue(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0);
            Boolean foundValueInList = false;
            IList<IWebElement> theseOptions = EAM.TransactionsNew.DisenReason.FindElements(By.TagName("option"));
            string OptionsList = "";
            foreach (IWebElement thisOption in theseOptions)
            {
                OptionsList += thisOption.Text + " ";
                if (thisOption.Text == strValue)
                {
                    foundValueInList = true;
                }
            }
            Assert.AreEqual(false, foundValueInList, "We expect to not find [" + strValue + "] in option list [" + OptionsList + "]");
            fw.ConsoleReport("We expect to not find [" + strValue + "] in option list [" + OptionsList + "]");
        }

        [Then(@"Verify Transactions New Disenrollment Reason PopUp has value DisEnroll Code as ""(.*)"" DisEnrollDis as ""(.*)""")]
        public void ThenVerifyTransactionsNewDisenrollmentReasonPopUpHasValueDisEnrollCodeAsDisEnrollDisAs(string p0, string p1)
        {

            tmsWait.Hard(3);
            string code = tmsCommon.GenerateData(p0);
            string discription = tmsCommon.GenerateData(p1);
            bool presence = Browser.Wd.FindElement(By.XPath("//table//tr/td[contains(.,'" + code + "')]/following-sibling::td[contains(.,'" + discription + "')]")).Displayed;
            Assert.IsTrue(presence, code + " is not gettting displayed");
        }

        [Then(@"Verify Transactions New Disen\.Reason field has value ""(.*)""")]
        public void ThenVerifyTransactionsNewDisen_ReasonFieldHasValue(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0);
            Boolean foundValueInList = false;
            IList<IWebElement> theseOptions = EAM.TransactionsNew.DisenReason.FindElements(By.TagName("option"));
            string OptionsList = "";
            foreach (IWebElement thisOption in theseOptions)
            {
                OptionsList += thisOption.Text + " ";
                if (thisOption.Text == strValue)
                {
                    foundValueInList = true;
                }
            }
            Assert.AreEqual(true, foundValueInList, "We expect to find [" + strValue + "] in option list [" + OptionsList + "]");
            fw.ConsoleReport("We expect to find [" + strValue + "] in option list [" + OptionsList + "]");
        }

        [When(@"Transactions ON HOLD Transaction Status is set to ""(.*)""")]
        public void WhenTransactionsONHOLDTransactionStatusIsSetTo(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0);
            //expanding the menus 

            By loc =By.XPath("//button[@test-id='transaction-btn-expandAndCollapse']");
            AngularFunction.clickOnElement(loc);
            tmsWait.Hard(3);

            By Drp = By.XPath("//kendo-dropdownlist[@test-id='ApplicationDispositionActionsOnHoldTransactionStatus']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + strValue + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

            //By plan = By.XPath("//div[@id='div_ApplicationDispositionOnHoldTransactionStatus']/span");
            //UIMODUtilFunctions.clickOnWebElementUsingLocators(plan);
            //tmsWait.Hard(1);
            //UIMODUtilFunctions.selectTransDrpValue(strValue);



            tmsWait.Hard(3);
            //IWebElement status = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_DropDownSnpStatus"));
            //new SelectElement(status).SelectByText(p0);
        }

        [When(@"Transactions ON HOLD Reason is set to ""(.*)""")]
        public void WhenTransactionsONHOLDReasonIsSetTo(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0);

            By Drp = By.XPath("//kendo-dropdownlist[@test-id='ApplicationDispositionActionsOnHoldReason']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + strValue + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

            //By plan = By.XPath("//div[@id='div_ApplicationDispositionOnHoldReason']/span");
            //UIMODUtilFunctions.clickOnWebElementUsingLocators(plan);
            //tmsWait.Hard(1);
            //UIMODUtilFunctions.selectTransDrpValue(strValue);

            //IWebElement status = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_DropDownOnHoldReason"));
            //new SelectElement(status).SelectByText(p0);

            //Collapsing the menus 

            By loc = By.XPath("//button[@test-id='transaction-btn-expandAndCollapse']");
            AngularFunction.clickOnElement(loc);
            tmsWait.Hard(3);
        }

        [Then(@"Transactions New PBP is set to ""(.*)""")]
        [When(@"Transactions New PBP is set to ""(.*)""")]
        public void WhenTransactionsNewPBPIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string strValue = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                //By Drp = By.XPath("//label[contains(.,'PBP')]/parent::div//span[@class='k-select']");
                //By typeapp = By.XPath("//li[text()='" + strValue + "']");


                ////UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                //tmsWait.Hard(3);
                ////UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

                AngularFunction.selectDropDownValue(cfAngularTransaction.AngularNewTransaction.PBPDrp, strValue);

                //By Drp = By.XPath("//kendo-dropdownlist[@test-id='DemographicDetailsPbp']//span[@class='k-select']");
                //By typeapp = By.XPath("//li[text()='" + strValue + "']");
                //fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                //fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                tmsWait.Hard(3);

            }
            else
            {

                By pbp = By.XPath("//div[@id='div_DemographicDetailsPbp']/span");

                UIMODUtilFunctions.clickOnWebElementUsingLocators(pbp);
                tmsWait.Hard(2);
                UIMODUtilFunctions.selectTransDrpValue(strValue);
                tmsWait.Hard(2);
            }
        }

        [Then(@"Verify Transactions New ""(.*)"" section is not displayed")]
        public void ThenVerifyTransactionsNewSectionIsNotDisplayed(string p0)
        {
            string section = tmsCommon.GenerateData(p0);
            Boolean isPresent = false;
            try
            {
                isPresent = Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + section + "')]")).Displayed;
            }

            catch
            {

            }

            Assert.IsFalse(isPresent, "Expected section is displayed");
        }
        [Then(@"Verify Transactions New ""(.*)"" section is disabled")]
        public void ThenVerifyTransactionsNewSectionIsDisabled(string p0)
        {
            Boolean isPresent = false;
            try
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {

                    
                    isPresent = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Name of Agent/Broker')]/parent::div//span[@class='k-input']")).Displayed;
                }
                else
                {
                    isPresent = Browser.Wd.FindElement(By.XPath("//div[@id='div_ApplicationDispositionNameOfAgentBroker']/span[@aria-disabled='true']")).Displayed;
                }
            }

            catch
            {
                fw.ConsoleReport(" Element is enabled");
                Assert.Fail("Element is enabled");

            }

            Assert.IsTrue(isPresent, "Test case fail because Drop down is enabled");
        }


        [When(@"Transactions New OSB drop down is set to ""(.*)""")]
        public void WhenTransactionsNewOSBDropDownIsSetTo(string p0)
        {

            tmsWait.Hard(3);
            string strValue = tmsCommon.GenerateData(p0);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='OptionalSupplementalBenefitsOSBInformationOSB']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + strValue + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            //By osb = By.XPath("//div[@id='div_OptionalSupplementalBenefitsOSBInformationOSB']/span");
            //UIMODUtilFunctions.clickOnWebElementUsingLocators(osb);
            ////tmsWait.Hard(2);
            ////UIMODUtilFunctions.selectTransDrpValue(strValue);
            //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//li[.='" + strValue + "'])[4]")));


        }

        [When(@"Transactions New OSB option ""(.*)"" is set to ""(.*)""")]
        public void WhenTransactionsNewOSBOptionIsSetTo(string osbType, string osbvalue)
        {
            string value = tmsCommon.GenerateData(osbvalue);
            //By drp = By.XPath("//input[@test-id='OptionalSupplementalBenefitsOSBInformation" + osbType + "']");
            // tmsWait.Hard(2);
            By Drp;
           if (osbType=="OtherOSB")
            {
                 //Drp = By.XPath("//kendo-multiselect[@test-id='OptionalSupplementalBenefitsOSBInformationOtherOSB']//input");
                IWebElement o_osb = Browser.Wd.FindElement(By.XPath("//label[text()='Other OSB']/parent::div//input"));

                o_osb.SendKeys(value);
                //tmsWait.Hard(3);
                o_osb.SendKeys(OpenQA.Selenium.Keys.Enter);
            }
           else
            {
                Drp = By.XPath("//kendo-dropdownlist[@test-id='OptionalSupplementalBenefitsOSBInformation" + osbType + "']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + value + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            }
             
            

            //IWebElement check = Browser.Wd.FindElement(drp);
            //bool status = false;
            //if (osbTypeCheckStatus.ToLower().Equals("checked"))
            //{
            //    status = true;
            //}

            //if (status)
            //{
            //    if (check.Selected)
            //    {
            //        fw.ConsoleReport(osbType + "  is already checked");

            //    }
            //    else
            //    {
            //        fw.ExecuteJavascript(check);

            //    }
            //}
            //else if (osbTypeCheckStatus.ToLower().Equals("unchecked"))
            //{
            //    if (!check.Selected)
            //    {
            //        fw.ConsoleReport(osbType + "  is already Unchecked");

            //    }
            //    else
            //    {
            //        fw.ExecuteJavascript(check);

            //    }
            //}


        }


        [Then(@"Verify Transactions New Part C Premium value should be equal to the addition of MedicalOSB ""(.*)"" VisionOSB ""(.*)"" DentalOSB ""(.*)""")]
        public void ThenVerifyTransactionsNewPartCPremiumValueShouldBeEqualToTheAdditionOfMedicalOSBVisionOSBDentalOSB(string p0, string p1, string p2)
        {
            string mpremium = tmsCommon.GenerateData(p0);
            string vpremium = tmsCommon.GenerateData(p1);
            string dpremium = tmsCommon.GenerateData(p2);
            int medicalpremium = Int32.Parse(mpremium);
            int visionpremium = Int32.Parse(vpremium);
            int dentalpremium = Int32.Parse(dpremium);
            int partCPremium = Int32.Parse(Browser.Wd.FindElement(By.XPath("//input[@test-id='DemographicDetailsPremAmtC']")).GetAttribute("value"));
            Assert.AreEqual(partCPremium, medicalpremium + visionpremium + dentalpremium, "part C premium does not calculated correctly");


        }

        [When(@"Calculate the total of MedicalOSB ""(.*)"" VisionOSB ""(.*)"" DentalOSB ""(.*)"" and assigned to ""(.*)""")]
        public void WhenCalculateTheTotalOfMedicalOSBVisionOSBDentalOSBAndAssignedTo(string p0, string p1, string p2, string p3)
        {
            string mpremium = tmsCommon.GenerateData(p0);
            string vpremium = tmsCommon.GenerateData(p1);
            string dpremium = tmsCommon.GenerateData(p2);
            int medicalpremium = Int32.Parse(mpremium);
            int visionpremium = Int32.Parse(vpremium);
            int dentalpremium = Int32.Parse(dpremium);
            int TOSB = medicalpremium + visionpremium + dentalpremium;
            fw.setVariable(p3, TOSB.ToString());
        }

        [When(@"Calculate the total of MedicalOSB ""(.*)"" VisionOSB ""(.*)"" DentalOSB ""(.*)"" OtherOSB ""(.*)"" and finally assigned to ""(.*)""")]
        public void WhenCalculateTheTotalOfMedicalOSBVisionOSBDentalOSBOtherOSBAndFinallyAssignedTo(string p0, string p1, string p2, string p3, string p4)
        {
            string mpremium = tmsCommon.GenerateData(p0);
            string vpremium = tmsCommon.GenerateData(p1);
            string dpremium = tmsCommon.GenerateData(p2);
            string opremium = tmsCommon.GenerateData(p3);
            int medicalpremium = Int32.Parse(mpremium);
            int visionpremium = Int32.Parse(vpremium);
            int dentalpremium = Int32.Parse(dpremium);
            int otherpremium = Int32.Parse(opremium);
            int TOSB = medicalpremium + visionpremium + dentalpremium + otherpremium;
            fw.setVariable(p4, TOSB.ToString());
        }


        [Then(@"Verify View Edit Member page Premium LIS Part C Premium value is addition of OSB ""(.*)"" and ""(.*)""")]
        public void ThenVerifyViewEditMemberPagePremiumLISPartCPremiumValueIsAdditionOfOSBAnd(string p0, string p1)
        {
            string tosb = tmsCommon.GenerateData(p0);
            string partc = tmsCommon.GenerateData(p1);
            bool istrueflag = false;
            int totalOfOSBPremium = Int32.Parse(tosb);
            decimal value;
            if (decimal.TryParse(partc, out value))
            {
                value = Math.Round(value);
                partc = value.ToString();
                // Do something with the new text value
            }
            else
            {
                // Tell the user their input is invalid
            }


            int partCPremium = int.Parse(partc);
            int ExpectedPremium = totalOfOSBPremium + partCPremium;
            string actualprem = Browser.Wd.FindElement(By.XPath("//input[@test-id='premiumLis-input-partCPremium']")).GetAttribute("value");

            decimal eval;
            if (decimal.TryParse(actualprem, out eval))
            {
                eval = Math.Round(eval);
                actualprem = eval.ToString();
                // Do something with the new text value
            }
            else
            {
                // Tell the user their input is invalid
            }

            int ActualpartCPremium = int.Parse(actualprem);
            if (ExpectedPremium == ActualpartCPremium)
            {
                istrueflag = true;
            }
            
            Assert.IsTrue(istrueflag, "part C premium does not calculated correctly");
        }




        [Then(@"Verify View Edit Transaction page PartCPremium is set to addition of OSBPremium ""(.*)"" and BasicPremium ""(.*)""")]
        public void ThenVerifyViewEditTransactionPagePartCPremiumIsSetToAdditionOfOSBPremiumAndBasicPremium(string p0, string p1)
        {
            string tosb = tmsCommon.GenerateData(p0);
            string partc = tmsCommon.GenerateData(p1);
            bool istrueflag = false;
            int totalOfOSBPremium = Int32.Parse(tosb);
            //int partCPremium = Int32.Parse(partc);
            decimal eval;
            if (decimal.TryParse(partc, out eval))
            {
                eval = Math.Round(eval);
                partc = eval.ToString();
                // Do something with the new text value
            }
            else
            {
                // Tell the user their input is invalid
            }


            int partCPremium = int.Parse(partc);
            int ExpectedPremium = totalOfOSBPremium + partCPremium;

            string partCPrem = Browser.Wd.FindElement(By.XPath("//input[@test-id='DemographicDetailsPremAmtC']")).GetAttribute("value");
            decimal value;
            if (decimal.TryParse(partCPrem, out value))
            {
                value = Math.Round(value);
                partCPrem = value.ToString();
                // Do something with the new text value
            }
            else
            {
                // Tell the user their input is invalid
            }

            int ActualpartCPremium = int.Parse(partCPrem);
            if (ExpectedPremium == ActualpartCPremium)
            {
                istrueflag = true;
            }
            Assert.IsTrue(istrueflag, "part C premium does not calculated correctly");
        }


        [Then(@"Verify Transactions New Part C Premium value should be equal to the addition of BidData Basic Premium ""(.*)"" MedicalOSB ""(.*)"" VisionOSB ""(.*)"" DentalOSB ""(.*)""")]
        public void ThenVerifyTransactionsNewPartCPremiumValueShouldBeEqualToTheAdditionOfBidDataBasicPremiumMedicalOSBVisionOSBDentalOSB(string p0, string p1, string p2, string p3)
        {
            string basicpremium = tmsCommon.GenerateData(p0);
            string mpremium = tmsCommon.GenerateData(p1);
            string vpremium = tmsCommon.GenerateData(p2);
            string dpremium = tmsCommon.GenerateData(p3);
            double medicalpremium=0.00;
            double visionpremium = 0.00;
            double dentalpremium = 0.00;
            double basicpremiumPartc = double.Parse(basicpremium);
            if(mpremium=="" || vpremium==""|| dpremium=="")
            {

            }
            else
            {
                medicalpremium = double.Parse(mpremium);
                visionpremium = double.Parse(vpremium);
                dentalpremium = double.Parse(dpremium);
            }
            
            string partCPrem = Browser.Wd.FindElement(By.XPath("//input[@test-id='DemographicDetailsPremAmtC']")).GetAttribute("value");
            decimal value;

            if (decimal.TryParse(partCPrem, out value))
            {
                value = Math.Round(value);
                partCPrem = value.ToString();
                // Do something with the new text value
            }
            else
            {
                // Tell the user their input is invalid
            }

            string expected_partCPrem = (basicpremiumPartc + medicalpremium + visionpremium + dentalpremium).ToString();
            decimal value1;
            if (decimal.TryParse(expected_partCPrem, out value1))
            {
                value1 = Math.Round(value1);
                expected_partCPrem = value1.ToString();
                // Do something with the new text value
            }
            int partCPremium = int.Parse(partCPrem); 
            int exp_partCPrem = int.Parse(expected_partCPrem);
            Assert.AreEqual(partCPremium, exp_partCPrem, "part C premium does not calculated correctly");
        }


        [Then(@"Verify Transaction New Part C Premium value should be equal to the addition of BidData Basic Premium ""(.*)"" MedicalOSB ""(.*)"" VisionOSB ""(.*)"" DentalOSB ""(.*)"" and OtherOSB ""(.*)""")]
        public void ThenVerifyTransactionNewPartCPremiumValueShouldBeEqualToTheAdditionOfBidDataBasicPremiumMedicalOSBVisionOSBDentalOSBAndOtherOSB(string p0, string p1, string p2, string p3, string p4)
        {
            string basicpremium = tmsCommon.GenerateData(p0);
            string mpremium = tmsCommon.GenerateData(p1);
            string vpremium = tmsCommon.GenerateData(p2);
            string dpremium = tmsCommon.GenerateData(p3);
            string opremium = tmsCommon.GenerateData(p4);
            double medicalpremium = 0.00;
            double visionpremium = 0.00;
            double dentalpremium = 0.00;
            double otherpremium = 0.00;
            double basicpremiumPartc = double.Parse(basicpremium);
            if (mpremium == "" || vpremium == "" || dpremium == "")
            {

            }
            else
            {
                medicalpremium = double.Parse(mpremium);
                visionpremium = double.Parse(vpremium);
                dentalpremium = double.Parse(dpremium);
                otherpremium = double.Parse(opremium);
            }

            string partCPrem = Browser.Wd.FindElement(By.XPath("//input[@test-id='DemographicDetailsPremAmtC']")).GetAttribute("value");
            decimal value;

            if (decimal.TryParse(partCPrem, out value))
            {
                value = Math.Round(value);
                partCPrem = value.ToString();
                // Do something with the new text value
            }
            else
            {
                // Tell the user their input is invalid
            }

            string expected_partCPrem = (basicpremiumPartc + medicalpremium + visionpremium + dentalpremium + otherpremium).ToString();
            decimal value1;
            if (decimal.TryParse(expected_partCPrem, out value1))
            {
                value1 = Math.Round(value1);
                expected_partCPrem = value1.ToString();
                // Do something with the new text value
            }
            int partCPremium = int.Parse(partCPrem);
            int exp_partCPrem = int.Parse(expected_partCPrem);
            Assert.AreEqual(partCPremium, exp_partCPrem, "part C premium does not calculated correctly");
        }


        [Then(@"Verify Query retuned ""(.*)""")]
        public void ThenVerifyQueryRetuned(string p0)
        {
            string retunredresult = tmsCommon.GenerateData(p0);
            Assert.IsTrue(retunredresult.Contains("0"));
        }


        [Then(@"Verify Query result ""(.*)"" should match with value ""(.*)""")]
        public void ThenVerifyQueryResultShouldMatchWithValue(string p0, string p1)
        {
            string expected_result = tmsCommon.GenerateData(p1);
            string actual_result = tmsCommon.GenerateData(p0);
            Assert.AreEqual(expected_result, actual_result, "Bothe result does not match");
        }


        [Then(@"Verify the Transaction Page displaye the ""(.*)"" as ""(.*)""")]
        public void ThenVerifyTheTransactionPageDisplayeTheAs(string p0, string p1)
        {
            string Value;
            string GeneratedData = tmsCommon.GenerateData(p1);
            switch (p1)
            {
                case "RXGroup":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        Value = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Primary Rx Group')]/parent::div//input")).GetAttribute("value");
                        Assert.AreEqual(Value, GeneratedData, "Actual and Expected result not matching");
                    }
                    else
                    {
                        Value = Browser.Wd.FindElement(By.Id("RxDetailsPrimaryRxGroup")).Text;
                        Assert.AreEqual(Value, GeneratedData, "Actual and Expected result not matching");

                    }
                    break;
                case "RXBIN":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        Value = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Primary Rx BIN')]/parent::div//input")).GetAttribute("value");
                        Assert.AreEqual(Value, GeneratedData, "Actual and Expected result not matching");
                    }
                    else
                    {
                        Value = Browser.Wd.FindElement(By.Id("RxDetailsPrimaryRxBIN")).Text;
                        Assert.AreEqual(Value, GeneratedData, "Actual and Expected result not matching");
                    }

                    break;
                case "RXPCN":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        Value = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Primary Rx PCN')]/parent::div//input")).GetAttribute("value");
                        Assert.AreEqual(Value, GeneratedData, "Actual and Expected result not matching");
                    }
                    else
                    {
                        Value = Browser.Wd.FindElement(By.Id("RxDetailsPrimaryRxPCN")).Text;
                        Assert.AreEqual(Value, GeneratedData, "Actual and Expected result not matching");
                    }

                    break;
                case "RXID":
                    if (p1.Contains("TMS"))
                    {
                        if (ConfigFile.tenantType.Equals("tmsx"))
                        {
                            Value = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Primary Rx ID')]/parent::div//input")).GetAttribute("value");
                            Assert.AreEqual(Value, GeneratedData, "Actual and Expected result not matching");
                        }
                        else
                        {
                            Value = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtPrimaryRxID_39")).Text;
                            if (!Value.Contains("TMS"))
                            {
                                Assert.Fail("TMS is not auto populating here");
                            }
                        }
                    }
                    else
                    {
                        if (ConfigFile.tenantType.Equals("tmsx"))
                        {
                            Value = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Primary Rx ID')]/parent::div//input")).GetAttribute("value");
                            Assert.AreEqual(Value, GeneratedData, "Actual and Expected result not matching");
                        }
                        else
                        {
                            Value = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtPrimaryRxID_39")).Text;
                            Assert.AreEqual(Value, GeneratedData, "Actual and Expected result not matching");
                        }
                    }
                    break;


            }
        }



        [Then(@"Verify the Transaction Page displaye the ""(.*)"" is disabled")]
        public void ThenVerifyTheTransactionPageDisplayeTheIsDisabled(string p0)
        {
            Boolean Value;
            switch (p0)
            {
                case "RXGroup":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        Value = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Primary Rx Group')]/parent::div//input")).Enabled;
                        Assert.IsFalse(Value, p0 + " is not disabled");
                    }
                    else
                    {
                        Value = Browser.Wd.FindElement(By.Id("RxDetailsPrimaryRxGroup")).Enabled;
                        Assert.IsFalse(Value, p0 + " is not disabled");
                    }
                    break;
                case "RXBIN":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        Value = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Primary Rx BIN')]/parent::div//input")).Enabled;
                        Assert.IsFalse(Value, p0 + " is not disabled");
                    }
                    else
                    {
                        Value = Browser.Wd.FindElement(By.Id("RxDetailsPrimaryRxBIN")).Enabled;
                        Assert.IsFalse(Value, p0 + " is not disabled");
                    }
                    break;
                case "RXPCN":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        Value = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Primary Rx PCN')]/parent::div//input")).Enabled;
                        Assert.IsFalse(Value, p0 + " is not disabled");
                    }
                    else
                    {
                        Value = Browser.Wd.FindElement(By.Id("RxDetailsPrimaryRxPCN")).Enabled;
                        Assert.IsFalse(Value, p0 + " is not disabled");
                    }
                    break;

                case "DateEditOverirde":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        Value = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Date Edit Override')]/parent::div//span[@class='k-input']")).Enabled;
                        Assert.IsFalse(Value, p0 + " is not disabled");
                    }
                    else
                    {
                        Value = Browser.Wd.FindElement(By.Id("DemographicDetailsDateEditOverride")).Enabled;
                        Assert.IsFalse(Value, p0 + " is not disabled");
                    }
                    break;
            }

        }


        [Then(@"Verify Transactions New PBP is set to ""(.*)""")]
        public void ThenVerifyTransactionsNewPBPIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            string exp = tmsCommon.GenerateData(p0);
            SelectElement pbp = new SelectElement(EAM.TransactionsNew.PBP);
            string actual = pbp.SelectedOption.Text;


            Assert.IsTrue(exp == actual, "Field PBP value is [{0}], expected [{1}]", actual, exp);
        }

        [When(@"Transactions View Edit Page New RxID is set to ""(.*)""")]
        public void WhenTransactionsViewEditPageNewRxIDIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string rxID = tmsCommon.GenerateData(p0);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                try
                {
                    IWebElement RxId = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Primary Rx ID')]/following-sibling::div//input"));
                    RxId.SendKeys(rxID);
                }
                catch
                {

                }
            }

            else
            {
                try
                {

                    EAM.TransactionsNew.PrimaryRxID.Clear();
                    EAM.TransactionsNew.PrimaryRxID.SendKeys(rxID);
                }
                catch
                {

                }
            }
        }
        [When(@"Verify EAM Administration page View Edit Plan Info section ""(.*)"" is ""(.*)""")]
        public void WhenVerifyEAMAdministrationPageViewEditPlanInfoSectionIs(string p0, string p1)
        {
            string Value;
            tmsWait.Hard(2);
            string action = tmsCommon.GenerateData(p1);
            string GeneratedData = tmsCommon.GenerateData(p0);
            switch (GeneratedData)
            {
                case "Primary Rx ID":
                    if (action.Equals("enabled"))
                    {
                        tmsWait.Hard(2);
                        EAM.TransactionsNew.PrimaryRxID.SendKeys("ritu");
                        Assert.IsTrue(EAM.TransactionsNew.PrimaryRxID.Enabled);
                    }
                    else if (action.Equals("disabled"))
                    {
                        tmsWait.Hard(2);
                        Assert.IsFalse(EAM.TransactionsNew.PrimaryRxID.Enabled);
                    }
                    break;
            }
        }


        [When(@"Transactions New Premium Withhold Option is set to ""(.*)""")]
        public void WhenTransactionsNewPremiumWithholdOptionIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string option = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                //By Drp = By.XPath("//label[contains(.,'Prem. Withhold Option')]/parent::div//span[@class='k-select']");
                //By typeapp = By.XPath("//li[text()='" + option + "']");


                //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                //tmsWait.Hard(3);
                //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

                AngularFunction.selectDropDownValue(cfAngularTransaction.AngularNewTransaction.PWODrp, option);

                tmsWait.Hard(5);
            }
            else
            {
                By pwo = By.XPath("//div[@id='div_DemographicDetailsPremWithholdOption']/span");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(pwo);
                tmsWait.Hard(2);
                UIMODUtilFunctions.selectTransDrpValue(option);
            }
        }

        [When(@"Transactions New Segment ID is set to ""(.*)""")]
        public void WhenTransactionsNewSegmentIDIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string option = tmsCommon.GenerateData(p0);
            By Drp = By.XPath("//label[contains(.,'Segment ID')]/parent::div//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + option + "']");


            UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
            //By pwo = By.XPath("//div[@id='div_DemographicDetailsSegID']/span");
            //UIMODUtilFunctions.clickOnWebElementUsingLocators(pwo);
            //tmsWait.Hard(2);
            //By Value = By.XPath("(//li[.='" + option + "'])[2]");
            //tmsWait.Hard(2);
            //fw.ExecuteJavascript(Browser.Wd.FindElement(Value));
            //tmsWait.Hard(2);
        }

        [When(@"Transactions New DateEditOverride is set to ""(.*)""")]
        [Then(@"Transactions New DateEditOverride is set to ""(.*)""")]
        public void WhenTransactionNewDateEditOverrideIsSetTo(string p0)
        {
            tmsWait.Hard(2);

            string value = tmsCommon.GenerateData(p0);

            By Drp = By.XPath("//label[contains(.,'Date Edit Override')]/parent::div//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + value + "']");


            UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
        }

        [Then(@"Verify View Edit Transaction page display message ""(.*)""")]
        public void ThenVerifyViewEditTransactionPageDisplayMessage(string p0)
        {
            IWebElement errmsg;
            try
            {
                errmsg = Browser.Wd.FindElement(By.XPath("//div[@class='messageText']//ul"));
                if (errmsg.Text.Contains("Receipt Date is required when Transcode is 51 and Election type is MADP"))
                {
                    tmsWait.Hard(5);
                    String strValue = "01/01/2014";
                    strValue = strValue.Replace("/", "");

                    IWebElement objDate = EAM.TransactionsNew.ReceiptDate;
                    objDate.Clear();
                    objDate.SendKeys(strValue);
                    tmsWait.Hard(2);
                    fw.ExecuteJavascript(EAM.TransactionsNew.SaveButton);

                }
            }
            catch
            {

            }
            tmsWait.Hard(3);
            IWebElement msg = Browser.Wd.FindElement(By.XPath("//span[@id='ctl00_ctl00_MainMasterContent_MainContent_lblMsg']"));
            bool actualmsg = msg.Text.Contains(p0);
            Assert.IsTrue(actualmsg, " Expected mesasge is not gettign displayed");
        }


        [When(@"Transactions New Enrollment Source is set to ""(.*)""")]
        public void WhenTransactionsNewEnrollmentSourceIsSetTo(string p0)
        {
            string source = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                //By Drp = By.XPath("//label[contains(.,'Enrollment Source')]/parent::div//span[@class='k-select']");
                //By typeapp = By.XPath("//li[text()='" + source + "']");
                //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                //tmsWait.Hard(3);
                //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                tmsWait.Hard(5);
                string Enrollsourcevalue = tmsCommon.GenerateData(p0);
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='DemographicDetailsEnrollmentSource']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + Enrollsourcevalue + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                tmsWait.Hard(5);


            }
            else
            {
                //By enrollSource = By.XPath("//div[@id='div_DemographicDetailsEnrollmentSource']/span");
                //UIMODUtilFunctions.clickOnWebElementUsingLocators(enrollSource);
                //tmsWait.Hard(2);
                //UIMODUtilFunctions.selectTransDrpValue(source);
                tmsWait.Hard(5);
                string Enrollsourcevalue = tmsCommon.GenerateData(p0);
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='DemographicDetailsEnrollmentSource']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + Enrollsourcevalue + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                tmsWait.Hard(5);
            }

        }

        [Then(@"Verify Attestation Questions page I recently was released from incarceration\. I was released on \(insert date\) field displayed")]
        public void ThenVerifyAttestationQuestionsPageIRecentlyWasReleasedFromIncarceration_IWasReleasedOnInsertDateFieldDisplayed()
        {
            tmsWait.Hard(2);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {

                IWebElement field = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='attestationQuestions-date-incarcerationReleaseDate']//input"));
                Assert.IsTrue(field.Displayed, "Expected field is not getting displayed");

                tmsWait.Hard(3);


            }
            else
            {
                IWebElement field = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtDate10"));
                Assert.IsTrue(field.Displayed, "Expected field is not getting displayed");
            }
        }
        [Then(@"I recently obtained lawful presence status in the United States\. I got this status on \(insert date\) field displayed")]
        public void ThenIRecentlyObtainedLawfulPresenceStatusInTheUnitedStates_IGotThisStatusOnInsertDateFieldDisplayed()
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {

                IWebElement field = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='attestationQuestions-date-lawfulPresenceStatusDate']//input"));
                Assert.IsTrue(field.Displayed, "Expected field is not getting displayed");

                tmsWait.Hard(3);


            }
            else
            {
                IWebElement field = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtDate11"));
                Assert.IsTrue(field.Displayed, "Expected field is not getting displayed");
            }
        }


        [When(@"Attestation Questions link is Clicked")]
        public void WhenAttestationQuestionsLinkIsClicked()
        {
            tmsWait.Hard(2);
            IWebElement quest = Browser.Wd.FindElement(By.CssSelector("[test-id='transaction-i-transactionAttestation']"));
            fw.ExecuteJavascript(quest);

        }
        [Then(@"Verify Election Type is set to ""(.*)""")]
        public void ThenVerifyElectionTypeIsSetTo(string p0)
        {

            tmsWait.Hard(10);
            string exp = tmsCommon.GenerateData(p0);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(3);

                By Drp = By.XPath("//label[contains(.,'Election Type')]/parent::div//span[@class='k-input']");
                string actualValue = Browser.Wd.FindElement(Drp).Text;
                Assert.AreEqual(exp, actualValue, " Both values are not matching");
            }
            else
            {
                SelectElement elc = new SelectElement(Browser.Wd.FindElement(By.Id("div_DemographicDetailsElectionType")));
                string actual = elc.SelectedOption.Text;

                Assert.AreEqual(actual, exp, exp + "Election Type is not gettting displayed");
            }
        }

        [Then(@"Verify View Edit Transaction page displayed message ""(.*)""")]
        public void ThenVerifyViewEditTransactionPageDisplayedMessage(string p0)
        {
            tmsWait.Hard(5);
            IWebElement msg = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]"));
            Assert.IsTrue(msg.Displayed, msg + " is not getting displayed");
        }


        [When(@"Attestation Questions dialog I recently returned to the United States after living permanently outside of the U\.S\. I returned to the U\.S\. is set to ""(.*)""")]
        public void WhenAttestationQuestionsDialogIRecentlyReturnedToTheUnitedStatesAfterLivingPermanentlyOutsideOfTheU_S_IReturnedToTheU_S_IsSetTo(string p0)
        {
            tmsWait.Hard(5);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                string value = p0.Replace("/", "");
                By Drp = By.XPath("//kendo-datepicker[@test-id='attestationQuestions-date-recentReturnDateUs']//input");
                Browser.Wd.FindElement(Drp).Clear();
                Browser.Wd.FindElement(Drp).SendKeys(value);

                tmsWait.Hard(3);


            }
            else
            {

                IWebElement dates = Browser.Wd.FindElement(By.CssSelector("[test-id='attestationQuestions-date-recentReturnDateUs']"));
                fw.ExecuteJavascriptSetText(dates, p0);
            }
            tmsWait.Hard(5);
        }

        [When(@"Attestation Questions dialog I recently moved outside of the service area for my current plan or I recently moved and this plan is a new option for me\. I moved on \(insert date\) is set to ""(.*)""")]
        public void WhenAttestationQuestionsDialogIRecentlyMovedOutsideOfTheServiceAreaForMyCurrentPlanOrIRecentlyMovedAndThisPlanIsANewOptionForMe_IMovedOnInsertDateIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                string value = p0.Replace("/", "");
                By Drp = By.XPath("//kendo-datepicker[@test-id='attestationQuestions-date-recentlyMovedDate']//input");
                Browser.Wd.FindElement(Drp).Clear();
                Browser.Wd.FindElement(Drp).SendKeys(value);

                tmsWait.Hard(3);


            }
            else
            {
                IWebElement dates = Browser.Wd.FindElement(By.CssSelector("[test-id='attestationQuestions-date-recentlyMovedDate']"));
                dates.SendKeys(p0);
            }
        }


        [When(@"Attestation Questions dialog I recently was released from incarceration\. I was released on is set to ""(.*)""")]
        public void WhenAttestationQuestionsDialogIRecentlyWasReleasedFromIncarceration_IWasReleasedOnIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                string value = p0.Replace("/", "");
                By Drp = By.XPath("//kendo-datepicker[@test-id='attestationQuestions-date-incarcerationReleaseDate']//input");
                Browser.Wd.FindElement(Drp).Clear();
                Browser.Wd.FindElement(Drp).SendKeys(value);

                tmsWait.Hard(3);


            }
            else
            {
                IWebElement dates = Browser.Wd.FindElement(By.CssSelector("[test-id='attestationQuestions-date-incarcerationReleaseDate']"));
                fw.ExecuteJavascriptSetText(dates, p0);
                tmsWait.Hard(2);
            }
        }

        [When(@"Attestation Questions dialog I recently moved outside of the service area for my current plan or I recently moved and this plan is a new option for me is set to ""(.*)""")]
        public void WhenAttestationQuestionsDialogIRecentlyMovedOutsideOfTheServiceAreaForMyCurrentPlanOrIRecentlyMovedAndThisPlanIsANewOptionForMeIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            tmsWait.Hard(5);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                string value = p0.Replace("/", "");
                By Drp = By.XPath("//kendo-datepicker[@test-id='attestationQuestions-date-recentlyMovedDate']//input");
                Browser.Wd.FindElement(Drp).Clear();
                Browser.Wd.FindElement(Drp).SendKeys(value);

                tmsWait.Hard(3);


            }
            else
            {
                IWebElement dates = Browser.Wd.FindElement(By.CssSelector("[test-id='attestationQuestions-date-recentlyMovedDate']"));
                fw.ExecuteJavascriptSetText(dates, p0);
            }
            tmsWait.Hard(5);
        }

        [When(@"Letter Status Report page ""(.*)"" is set ""(.*)""")]
        public void WhenLetterStatusReportPageIsSet(string field, string p1)
        {
            tmsWait.Hard(5);
            IWebElement dates = Browser.Wd.FindElement(By.CssSelector("[test-id='" + field + "']"));
            fw.ExecuteJavascriptSetText(dates, p1);
            tmsWait.Hard(5);
        }


        [Then(@"Verify Letter Status Report page ""(.*)"" is displayed")]
        public void ThenVerifyLetterStatusReportPageIsDisplayed(string hic)
        {
            bool flag = true;
            string[] expected = tmsCommon.GenerateData(hic).Split(',');
            tmsWait.Hard(2);
            Browser.SwitchToChildWindow();
            //Browser.SwitchToIFrame();
            tmsWait.Hard(5);

            while (flag)
            {
                IWebElement table = Browser.Wd.FindElement(By.Id("ReportViewerControl_fixedTable"));
                string values = table.Text;

                foreach (string temp in expected)
                {
                    if (values.Contains(temp))
                    {
                        Console.WriteLine(temp + " is getting displayed on Report");

                        // break;
                    }
                    else
                    {
                        Assert.Fail(temp + " is not found");
                        break;


                    }
                }
                flag = false;
                // Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl05_ctl00_Next_ctl00_ctl00")).Click();
            }


        }

        [When(@"Letter Status Report page Letter Status dropdown list is set ""(.*)""")]
        public void WhenLetterStatusReportPageLetterStatusDropdownListIsSet(string p0)
        {
            SelectElement sel;
            IWebElement drp;
            string[] drpvalue = p0.Split(',');
            foreach (string name in drpvalue)
            {
                drp = Browser.Wd.FindElement(By.Id("ctl00_MainMasterContent_LetterStatusDescription"));
                sel = new SelectElement(drp);
                sel.SelectByText(name);

            }
        }

        [Then(@"Letter Page DeSelect All button is Clicked")]
        public void ThenLetterPageDeSelectAllButtonIsClicked()
        {
            tmsWait.Hard(5);
            Browser.Wd.FindElement(By.LinkText("DeSelect All")).Click();
            tmsWait.Hard(2);
        }

        [When(@"Letter page ""(.*)"" is ""(.*)"" from Letter Queue")]
        public void WhenLetterPageIsFromLetterQueue(string p0, string p1)
        {
            IWebElement element;
            IWebElement button;

            switch (p1)
            {
                case "Removed":
                    element = Browser.Wd.FindElement(By.XPath("(//td[contains(.,'" + p0 + "')]/following-sibling::td//*[@type='checkbox'])[2]"));
                    fw.ExecuteJavascript(element);
                    button = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cmdRemove"));
                    fw.ExecuteJavascript(button);
                    tmsWait.Hard(5);
                    tmsWait.IsAlertPresent();
                    tmsWait.Hard(5);
                    break;
                case "Sent":
                    element = Browser.Wd.FindElement(By.XPath("(//td[contains(.,'" + p0 + "')]/following-sibling::td//*[@type='checkbox'])[1]"));
                    fw.ExecuteJavascript(element);
                    button = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnGenerateLetters"));
                    fw.ExecuteJavascript(button);
                    tmsWait.Hard(5);
                    tmsWait.IsAlertPresent();
                    tmsWait.Hard(5);
                    break;

            }


        }

        [When(@"Letter Status Report Page Letter Status Multi Select value ""(.*)"" is Selected")]
        public void WhenLetterStatusReportPageLetterStatusMultiSelectValueIsSelected(string Option)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {

                tmsWait.Hard(1);
                IWebElement elecType = Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='LetterStatusDescription']//input"));

                elecType.SendKeys(Option);
                tmsWait.Hard(3);
                elecType.SendKeys(OpenQA.Selenium.Keys.Enter);
            }
            else
            {
                IWebElement multiSelect = Browser.Wd.FindElement(By.CssSelector("[test-id='LetterStatusDescription']"));
                fw.ExecuteJavascript(multiSelect);
                tmsWait.Hard(3);
                IWebElement option = Browser.Wd.FindElement(By.XPath("//a[contains(.,'" + Option + "')]"));
                fw.ExecuteJavascript(option);
                tmsWait.Hard(3);
                fw.ExecuteJavascript(multiSelect);
            }

        }





        [When(@"Letter Status Report page ""(.*)"" dropdown list is set ""(.*)""")]
        public void WhenLetterStatusReportPageDropdownListIsSet(string p0, string p1)
        {
            tmsWait.Hard(10);

            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            IWebElement drp;
            SelectElement sel;
            if (ConfigFile.EnvType.Equals("ESI"))
            {// Not Implemented as of 12/30/2019, Ned to update the test scripts once implementation has done

                switch (field)
                {
                    case "Plan ID":
                        IWebElement PlanIdList = Browser.Wd.FindElement(By.XPath("//select[@id='ReportViewerControl_ctl04_ctl03_ddValue']"));
                        SelectElement pid = new SelectElement(PlanIdList);
                        pid.SelectByText(value);
                        break;
                    case "PBP ID":
                        IWebElement PBPList = Browser.Wd.FindElement(By.XPath("//select[@id='ReportViewerControl_ctl04_ctl05_ddValue']"));
                        SelectElement pbpid = new SelectElement(PBPList);
                        pbpid.SelectByText(value);
                        break;
                }
            }
            else
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    switch (field)
                    {
                        case "Plan ID":
                            By Drp = By.XPath("//kendo-dropdownlist[@test-id='PlanID']//span[@class='k-select']");
                            By typeapp = By.XPath("//li[text()='" + value + "']");

                            UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                            tmsWait.Hard(3);
                            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

                            break;
                        case "PBP ID":
                            Drp = By.XPath("//kendo-dropdownlist[@test-id='PBPID']//span[@class='k-select']");
                            typeapp = By.XPath("//li[text()='" + value + "']");

                            UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                            tmsWait.Hard(3);
                            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

                            break;
                        case "Letter Status":
                            tmsWait.Hard(1);
                            IWebElement elecType = Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='LetterStatusDescription']//input"));

                            elecType.SendKeys(value);
                            tmsWait.Hard(3);
                            elecType.SendKeys(OpenQA.Selenium.Keys.Enter);
                            break;
                    }
                }
                else
                {

                    switch (field)
                    {
                        case "Plan ID":
                            drp = Browser.Wd.FindElement(By.CssSelector("[test-id='PlanID']"));
                            sel = new SelectElement(drp);
                            sel.SelectByText(value);
                            break;
                        case "PBP ID":
                            drp = Browser.Wd.FindElement(By.CssSelector("[test-id='PBPID']"));
                            sel = new SelectElement(drp);
                            sel.SelectByText(value);
                            break;
                        case "Letter Status":
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//multiselect[@test-id='LetterStatusDescription']")));
                            tmsWait.Hard(1);
                            drp = Browser.Wd.FindElement(By.XPath("(//multiselect[@test-id='LetterStatusDescription']//a)[9]"));    //Browser.Wd.FindElement(By.CssSelector("[test-id='LetterStatusDescription']"));
                                                                                                                                    //sel = new SelectElement(drp);
                                                                                                                                    //sel.SelectByText(value);
                            fw.ExecuteJavascript(drp);
                            break;
                    }
                }

            }

        }


        [When(@"Attestation Questions dialog I recently obtained lawful presence status in the United States date is set to ""(.*)""")]
        public void WhenAttestationQuestionsDialogIRecentlyObtainedLawfulPresenceStatusInTheUnitedStatesDateIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                string value = p0.Replace("/", "");
                IWebElement Drp = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='attestationQuestions-date-lawfulPresenceStatusDate']//span[@role='button']"));
                //Browser.Wd.FindElement(Drp).Clear();
                //Browser.Wd.FindElement(Drp).SendKeys(value);
                AngularFunction.enterDate(Drp, p0);
                tmsWait.Hard(3);


            }
            else
            {

                IWebElement dates = Browser.Wd.FindElement(By.CssSelector("[test-id='attestationQuestions-date-lawfulPresenceStatusDate']"));
                fw.ExecuteJavascriptSetText(dates, p0);
                tmsWait.Hard(5);
            }

        }

        [When(@"Attestation Questions dialog Ok button is Clicked")]
        public void WhenAttestationQuestionsDialogOkButtonIsClicked()
        {
            IWebElement ok = Browser.Wd.FindElement(By.CssSelector("[test-id='attestationQuestions-btn-ok']"));
            fw.ExecuteJavascript(ok);
            tmsWait.Hard(3);
        }

        [Then(@"Reports Page Plan Id is set to ""(.*)""")]
        public void ThenReportsPagePlanIdIsSetTo(string planIDv)
        {
            string p0 = tmsCommon.GenerateData(planIDv);
            IWebElement planid = Browser.Wd.FindElement(By.CssSelector("[test-id='PlanID']"));
            new SelectElement(planid).SelectByText(p0);
        }

        [Then(@"Transactions Missing MBI Reports Page Plan Id is set to ""(.*)""")]
        public void ThenTransactionsMissingMBIReportsPagePlanIdIsSetTo(string planIDv)
        {
            string p0 = tmsCommon.GenerateData(planIDv);
            IWebElement planid = Browser.Wd.FindElement(By.CssSelector("[test-id='Planid']"));
            new SelectElement(planid).SelectByText(p0);
        }

        [Then(@"Reports Page PBP Id is set to ""(.*)""")]
        [Given(@"Reports Page PBP Id is set to ""(.*)""")]
        public void ThenReportsPagePBPIdIsSetTo(string pbpID)
        {
            string p0 = tmsCommon.GenerateData(pbpID);
            IWebElement planid = Browser.Wd.FindElement(By.CssSelector("[test-id='PBPID']"));
            new SelectElement(planid).SelectByText(p0);
        }

        [Then(@"Reports Page Run Report button is Clicked")]
        public void ThenReportsPageRunReportButtonIsClicked()
        {
            IWebElement button = Browser.Wd.FindElement(By.Id("reportGen"));
            fw.ExecuteJavascript(button);
            tmsWait.Hard(4);

        }

        [Then(@"Transactions page Save Button is clicked")]
        public void ThenTransactionsPageSaveButtonIsClicked()
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(EAM.TransactionsNew.SaveButton);



            try
            {
                Browser.ClosePopUps(true);
                tmsWait.Hard(3);
            }
            catch
            {
                tmsWait.Hard(5);
            }

            UIMODUtilFunctions.clickOnConfirmationYesDialog();
            
        }


        [Then(@"Verify Transaction New SNP Status field is ""(.*)""")]
        public void ThenVerifyTransactionNewSNPStatusFieldIs(string p0)
        {
            string GenerateData = tmsCommon.GenerateData(p0);
            tmsWait.Hard(2);

            switch (GenerateData.ToLower())
            {
                case "displayed": { Displayed = "displayed"; break; }
                case "Displayed": { Displayed = "displayed"; break; }
                case "DISPLAYED": { Displayed = "displayed"; break; }
                case "NotDisplayed": { Displayed = "notdisplayed"; break; }
                case "notdisplayed": { Displayed = "notdisplayed"; break; }
                case "NOTDISPLAYED": { Displayed = "notdisplayed"; break; }

                default: { Console.WriteLine(" Field should be displayed/Displayed or NotDisplayed/notdisplayed"); break; }
            }

            if (Displayed.Equals("displayed"))
            {
                tmsWait.Hard(3);
                if (EAM.TransactionsNew61.SNPStatus.Displayed == true)
                {
                    Assert.IsTrue(EAM.TransactionsNew61.SNPStatus.Displayed == true, "SNPStatus field is displayed for TC61 as expected");
                }

            }
            else if (Displayed.Equals("notdisplayed"))
            {
                tmsWait.Hard(3);
                try
                {
                    EAM.TransactionsNew61.SNPStatus.Click();
                    Assert.IsTrue(EAM.TransactionsNew61.SNPStatus.Displayed == false, "SNPStatus field is not displayed for TC61 as expected");
                }
                catch (Exception) { }
                tmsWait.WaitForReadyStateComplete(60);
            }


        }

        [When(@"View Edit Member page Race is set to ""(.*)""")]
        public void WhenViewEditMemberPageRaceIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            By race = By.Id("ctl00_ctl00_MainMasterContent_MainContent_drpRace");
            new SelectElement(Browser.Wd.FindElement(race)).SelectByText(p0);
            tmsWait.Hard(2);
        }

        [When(@"View Edit Member page Marital Status is set to ""(.*)""")]
        public void WhenViewEditMemberPageMaritalStatusIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            By marital = By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboMaritalStatus");
            new SelectElement(Browser.Wd.FindElement(marital)).SelectByText(p0);
            tmsWait.Hard(2);
        }

        [When(@"View Edit Member page Save button is Clicked Successfully")]
        public void WhenViewEditMemberPageSaveButtonIsClickedSuccessfully()
        {
            tmsWait.Hard(5);
            By save = By.XPath("//button[@test-id='memberViewEdit-btn-save']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(save));
            tmsWait.Hard(2);
        }


        [When(@"Transactions New First Name is set to ""(.*)""")]
        public void WhenTransactionsNewFirstNameIsSetTo(string p0)
        {
            tmsWait.Hard(4);
            string strValue = tmsCommon.GenerateData(p0.ToString());

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                if (!cfAngularTransaction.AngularNewTransaction.FirstName.Text.Equals(strValue))
                {
                    //By fname = By.XPath("(//label[contains(.,'First Name')]/parent::div/div//input)[1]");
                    //UIMODUtilFunctions.enterValueOnWebElementUsingLocators(fname, strValue);

                    AngularFunction.sendKeysWithClear(cfAngularTransaction.AngularNewTransaction.FirstName, strValue);
                }
            }
            else
            {

                EAM.TransactionsNew.FirstName.SendKeys(strValue);
            }
        }

        [When(@"Transactions New Last Name is set to ""(.*)""")]
        public void WhenTransactionsNewLastNameIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string strValue = tmsCommon.GenerateData(p0.ToString());
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                if (!cfAngularTransaction.AngularNewTransaction.lastName.Text.Equals(strValue))
                {
                    //By fname = By.XPath("(//label[contains(.,'Last Name')]/parent::div/div//input)[1]");
                    //UIMODUtilFunctions.enterValueOnWebElementUsingLocators(fname, strValue);

                    AngularFunction.sendKeysWithClear(cfAngularTransaction.AngularNewTransaction.lastName, strValue);
                }
            }
            else
            {

                EAM.TransactionsNew.LastName.Clear();
                EAM.TransactionsNew.LastName.SendKeys(strValue);
            }
        }

        [When(@"verify Transactions New Primary Rx ID is disabled")]
        public void WhenVerifyTransactionsNewPrimaryRxIDIsDisabled()
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {

                try
                {
                    
                    //IWebElement PrimaryRxID = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Primary Rx ID')]/parent::div//input"));

                    bool isRxIDEnabled = cfAngularTransaction.AngularNewTransaction.PrimaryRxID.Enabled;
                    Assert.IsTrue(!isRxIDEnabled);

                    tmsWait.Hard(3);

                }
                catch
                {

                }

            }
            else
            {
                IWebElement PrimaryRxID = Browser.Wd.FindElement(By.Id("RxDetailsPrimaryRxID"));
                string strValue = PrimaryRxID.GetAttribute("disabled");
                Assert.AreEqual(strValue.ToString(), "true");
            }

        }

        [When(@"Transactions New MI is set to ""(.*)""")]
        public void WhenTransactionsNewMIIsSetTo(string p0)
        {
            string MItext = tmsCommon.GenerateData(p0);
            EAM.TransactionsNew.MI.SendKeys(MItext);
        }

        [When(@"Transactions New Sale Location is set to ""(.*)""")]
        public void WhenTransactionsNewSaleLocationIsSetTo(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0.ToString());

            if (ConfigFile.tenantType.Equals("tmsx"))
            {

                By Drp = By.XPath("//label[contains(.,'Sale Location')]/parent::div//input");
                Browser.Wd.FindElement(Drp).Clear();
                Browser.Wd.FindElement(Drp).SendKeys(strValue);

                tmsWait.Hard(3);


            }
            else
            {

                tmsWait.Hard(2);
                EAM.TransactionsNew.SaleLocation.Clear();
                EAM.TransactionsNew.SaleLocation.SendKeys(strValue);
            }
        }

        [When(@"Transactions New Prem Amt C is set to ""(.*)""")]
        public void WhenTransactionsNewPremAmtCIsSetTo(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0.ToString());
            if (ConfigFile.tenantType.Equals("tmsx") && p0.ToString().Equals("76"))
            {
                By Drp = By.XPath("//label[contains(.,'Prem. Amount C')]/parent::div//input");

                Browser.Wd.FindElement(Drp).SendKeys(strValue);

                tmsWait.Hard(3);


            }
            else if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Prem. Amount C')]/parent::div//input");

                Browser.Wd.FindElement(Drp).SendKeys(strValue);

                tmsWait.Hard(3);


            }
            else
            {
                EAM.TransactionsNew.PremAmtC.Clear();
                EAM.TransactionsNew.PremAmtC.SendKeys(strValue);
            }
        }

        [When(@"Transactions New Sales Rep is set to ""(.*)""")]
        public void WhenTransactionsNewSalesRepIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                //By Drp = By.XPath("//label[contains(.,'Name of Agent/Broker')]/parent::div//span[@class='k-select']");
                //By typeapp = By.XPath("//li[text()='" + value + "']");


                //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                //tmsWait.Hard(3);
                //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                AngularFunction.selectDropDownValue(cfAngularTransaction.AngularNewTransaction.salesRepDrp, value);
                tmsWait.Hard(2);
            }
            else
            {
                By salesRep = By.XPath("//div[@id='div_ApplicationDispositionNameOfAgentBroker']/span");

                tmsWait.Hard(2);
                try
                {
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(salesRep);
                    tmsWait.Hard(2);
                    UIMODUtilFunctions.selectTransDrpValue(value);

                    tmsWait.Hard(1);

                    Browser.Wd.FindElement(salesRep).SendKeys(Keys.Escape);

                }

                catch
                {
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Application Disposition')]/preceding-sibling::i[1]")));
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(salesRep);
                    tmsWait.Hard(2);
                    UIMODUtilFunctions.selectTransDrpValue(value);

                    tmsWait.Hard(1);

                    Browser.Wd.FindElement(salesRep).SendKeys(Keys.Escape);
                }


                tmsWait.Hard(1);

            }
        }
        [Then(@"Transactions New Force Deny is set to ""(.*)""")]
        [When(@"Transactions New Force Deny is set to ""(.*)""")]
        public void WhenTransactionsNewForceDenyIsSetTo(string p0)
        {



            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement ele = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Force Deny')]/parent::div/input"));

                ReUsableFunctions.CheckBoxOperations(ele, p0);
            }
            else
            {
                fw.ExecuteJavascript(EAM.TransactionsNew.ForceDeny);
            }
            tmsWait.Hard(2);
        }

        [When(@"Transactions View Edit Force Deny is set to ""(.*)""")]
        public void WhenTransactionsViewEditForceDenyIsSetTo(string p0)
        {
            fw.ExecuteJavascript(EAM.TransactionsNew.ForceDeny2);
            tmsWait.Hard(2);
        }


        [Then(@"Transactions New Denial Reason set to ""(.*)""")]
        [When(@"Transactions New Denial Reason set to ""(.*)""")]
        public void WhenTransactionsNewDenialReasonSetTo(string p0)
        {
            string inputValue = p0.ToString();
            SelectElement select = new SelectElement(EAM.TransactionsNew.DenialReasonDropDown);
            select.SelectByText(inputValue);
        }

        [When(@"Transactions New Denial Reason on Transaction 51 is set to ""(.*)""")]

        [Then(@"Transactions New Denial Reason Action set to ""(.*)""")]
        [When(@"Transactions New Denial Reason Action set to ""(.*)""")]
        public void WhenTransactionsNewDenialReasonActionSetTo(string p0)
        {

            string strValue = tmsCommon.GenerateData(p0);
            tmsWait.Hard(3);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Denial Reason')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + strValue + "']");


                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);



            }
            else
            {
                By disenReason = By.XPath("//div[@id='div_ApplicationDispositionActionsDenialReason']/span");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(disenReason);
                tmsWait.Hard(1);
                UIMODUtilFunctions.selectTransDrpValue(strValue);
            }
            tmsWait.Hard(2);
        }


        [When(@"Transactions New Sex is set to ""(.*)""")]
        public void WhenTransactionsNewSexIsSetTo(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0.ToString());
            tmsWait.Hard(3);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                //By Drp = By.XPath("//label[contains(.,'Gender')]/parent::div//span[@class='k-select']");
                //By typeapp = By.XPath("//li[text()='" + strValue + "']");


                //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                //tmsWait.Hard(3);
                //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

                AngularFunction.selectDropDownValue(cfAngularTransaction.AngularNewTransaction.SexDrp, strValue);

            }
            else
            {

                By gender = By.XPath("//div[@id='div_DemographicDetailsSex']/span");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(gender);
                tmsWait.Hard(3);
                By value = By.XPath("(//ul[@role='listbox']/li[.='" + strValue + "'])[1]");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(value);
            }
        }


        [When(@"Transactions New Prior Communication is set to ""(.*)""")]
        public void WhenTransactionsNewPriorCommunicationIsSetTo(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0.ToString());
            tmsWait.Hard(3);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Prior Comm')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + strValue + "']");


                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);



            }
            else
            {


                By priorComm = By.XPath("//div[@id='div_DemographicDetailsPriorComm']/span");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(priorComm);
                tmsWait.Hard(2);
                UIMODUtilFunctions.selectTransDrpValue(strValue);
            }

        }

        [When(@"Transactions New DOB is set to ""(.*)""")]
        public void WhenTransactionsNewDOBIsSetTo(string p0)
        {
            String strValue = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                AngularFunction.enterDate(cfAngularTransaction.AngularNewTransaction.DOB, strValue);
               


            }
            else
            {

                strValue = strValue.Replace("/", "");

                IWebElement objDate = EAM.TransactionsNew.DOB;
                objDate.Clear();
                objDate.Click();
                objDate.SendKeys(strValue);
            }
        }

        [When(@"Transactions New DisEnrollment Reason is set to ""(.*)""")]
        public void WhenTransactionsNewDisEnrollmentReasonIsSetTo(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0);
            tmsWait.Hard(3);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Disen. Reason')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + strValue + "']");


                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);



            }
            else
            {

                By disenReason = By.XPath("//div[@id='div_DemographicDetailsDisenReason']/span");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(disenReason);
                tmsWait.Hard(1);
                UIMODUtilFunctions.selectTransDrpValue(strValue);
            }
            tmsWait.Hard(2);
        }

        [When(@"Transactions New Effective Date value is set to ""(.*)""")]
        public void WhenTransactionsNewEffectiveDateValueIsSetTo(string p0)
        {
            String strValue = tmsCommon.GenerateData(p0);
            strValue = strValue.Replace("/", "");
            tmsWait.WaitForElementExist(By.XPath("//*[contains(@id, 'txtEffDate')]"), 30);

            string strSgnDateID = EAM.TransactionsNew.SignatureDate.GetAttribute("id");

            IWebElement objEffDate = EAM.TransactionsNew.EffectiveDate;
            objEffDate.Clear();
            objEffDate.SendKeys(strValue);
        }

        [Then(@"View Edit Transaction page Resubmit button is Clicked")]
        public void ThenViewEditTransactionPageResubmitButtonIsClicked()
        {
            EAM.TransactionsNew.Resubmit.Click();

            IAlert alert = Browser.Wd.SwitchTo().Alert();
            alert.Accept();
        }

        [When(@"Transactions page Address Effective Date field is set to ""(.*)""")]
        public void WhenTransactionsPageAddressEffectiveDateFieldIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string strValue = tmsCommon.GenerateData(p0);
            IWebElement addressEffectDate = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtEffAddress_61"));
            fw.ExecuteJavascriptSetText(addressEffectDate, strValue);
        }

        [Then(@"Transactions New Effective Date is set to ""(.*)""")]
        [When(@"Transactions New Effective Date is set to ""(.*)""")]
        public void WhenTransactionsNewEffectiveDateIsSetTo(string p0)
        {
            tmsWait.Hard(7);
            string value = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
             

                AngularFunction.enterDate(cfAngularTransaction.AngularNewTransaction.effectiveDate, value);


            }
            else
            {

                By effDate = By.CssSelector("[test-id='DemographicDetailsEffectiveDate']");
                // UIMODUtilFunctions.enterValueOnWebElementUsingLocators(effDate, value);
                tmsWait.Hard(2);
                Browser.Wd.FindElement(effDate).Clear();
                Browser.Wd.FindElement(effDate).Click();
                Browser.Wd.FindElement(effDate).SendKeys(value);




            }
        }
        [Then(@"Transactions New ""(.*)"" is set to ""(.*)""")]
        [When(@"Transactions New ""(.*)"" is set to ""(.*)""")]
        public void WhenTransactionsNewIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(7);
            
            if (ConfigFile.tenantType.Equals("tmsx") && p0.Equals("EffectiveDate"))
            {
                string value = tmsCommon.GenerateData(p1);
                By Drp = By.XPath("//kendo-datepicker[@test-id='DemographicDetailsEffectiveDate']//span[@role='button']");
              
                AngularFunction.enterDate(Drp, value);

            }
            else if (ConfigFile.tenantType.Equals("tmsx") && p0.Equals("SignatureDate"))
            {
                string value = tmsCommon.GenerateData(p1);//.ToString().Replace("/", "");
                By Drp = By.XPath("//kendo-datepicker[@test-id='DemographicDetailsSignatureDate']//span[@role='button']");
                
                //Browser.Wd.FindElement(Drp).Clear();
                AngularFunction.enterDate(Drp, value);
            }
            else if (ConfigFile.tenantType.Equals("tmsx") && p0.Equals("ReceiptDate"))
            {
                string value = tmsCommon.GenerateData(p1);//.ToString().Replace("/", "");
                By Drp = By.XPath("//kendo-datepicker[@test-id='DemographicDetailsReceiptDate']//span[@role='button']");
                
                //Browser.Wd.FindElement(Drp).Clear();
                AngularFunction.enterDate(Drp, value);
                
            }
            else if (ConfigFile.tenantType.Equals("tmsx") && p0.Equals("DOB"))
            {
                string value = tmsCommon.GenerateData(p1);//.ToString().Replace("/", "");
                By Drp = By.XPath("//kendo-datepicker[@test-id='DemographicDetailsDob']//span[@role='button']");
                //Browser.Wd.FindElement(Drp).Clear();
                AngularFunction.enterDate(Drp, value);
            }
            else
            {
                Boolean correctDate = false;
                string textDate = "";
                string xpath = "";
                string value = tmsCommon.GenerateData(p0);
                string date = tmsCommon.GenerateData(p1);
                string css = "[test-id='DemographicDetails";
                switch (value.ToLower())
                {
                    case "effectivedate":
                        {
                            xpath = css + "EffectiveDate']"
                                ; break;
                        }

                    case "signaturedate":
                        {
                            xpath = css + "SignatureDate']"
                                ; break;
                        }

                    case "receiptdate":
                        {
                            xpath = css + "ReceiptDate']"
                                ; break;
                        }
                    case "dob":
                        {
                            xpath = css + "Dob']"
                                ; break;
                        }
                }
                //  DemographicDetails
                By effDate = By.CssSelector(xpath);
                tmsWait.Hard(2);
                // UIMODUtilFunctions.enterValueOnWebElementUsingLocators(effDate, value);
                int count = 0;
                while (correctDate == false)
                {
                    if (count < 25)
                    {
                        Browser.Wd.FindElement(effDate).Clear();
                        tmsWait.Hard(2);
                        tmsWait.Hard(1);
                        Browser.Wd.FindElement(effDate).Click();
                        tmsWait.Hard(2);
                        Browser.Wd.FindElement(effDate).SendKeys(date);
                        textDate = Browser.Wd.FindElement(effDate).GetAttribute("value");
                        if (textDate.Equals(date))
                        {
                            correctDate = true;
                            break;
                        }

                    }
                    count = count + 1;
                }
            }
        }


        [When(@"Transaction New RFI Receipt Date is set to ""(.*)""")]
        [Then(@"Transaction New RFI Receipt Date is set to ""(.*)""")]
        public void ThenTransactionNewRFIReceiptDateIsSetTo(string RFIDate)
        {
            tmsWait.Hard(3);
            String strValue = tmsCommon.GenerateData(RFIDate);
            strValue = strValue.Replace("/", "");
            IWebElement objEffDate = EAM.TransactionsNew.RFIDate1;
            objEffDate.Clear();
            tmsWait.Hard(3);
            objEffDate.SendKeys(strValue);
        }

        //[When(@"Transactions ViewEdit RFIReceipt Date is set to ""(.*)""")]
        //[Then(@"Transactions ViewEdit RFIReceipt Date is set to ""(.*)""")]
        ////public void WhenTransactionsViewEditRFIReceiptDateIsSetTo(string p0)
        //{

            //tmsWait.Hard(5);
            //String strValue = tmsCommon.GenerateData(p0);
            //IWebElement objDate = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='ApplicationDispositionActionsRfiReceiptDate']//span[@role='button']"));
            //tmsWait.Hard(10);
            //AngularFunction.enterDate(objDate, strValue);

        //}

        [Then(@"Transactions New Signature Date is set to ""(.*)""")]
        [When(@"Transactions New Signature Date is set to ""(.*)""")]
        public void WhenTransactionsNewSignatureDateIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            String strValue = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                AngularFunction.enterDate(cfAngularTransaction.AngularNewTransaction.signDate, strValue);
               


            }
            else
            {
                // click on calendar icon  - Note this is WorkAround
                IWebElement selectedDate = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Signature Date')]/parent::div/div//span[@role='button']"));
                fw.ExecuteJavascript(selectedDate);


                tmsWait.Hard(2);
                strValue = strValue.Replace("/", "");

                IWebElement objDate = EAM.TransactionsNew.SignatureDate;
                tmsWait.Hard(3);
                objDate.Clear();
                objDate.Click();
                objDate.SendKeys(strValue);
            }
        }
        [When(@"Transactions New Dienrollment Reason code is set to ""(.*)""")]
        public void WhenTransactionsNewDienrollmentReasonCodeIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            String strValue = tmsCommon.GenerateData(p0);
            SelectElement thisField = new SelectElement(EAM.TransactionsNew.DisenrlreasonCode);
            thisField.SelectByText(strValue);

            tmsWait.Hard(3);
            tmsWait.WaitForReadyStateComplete(30);
        }

        [When(@"Transactions Disenrollment Reason is set to ""(.*)""")]
        public void WhenTransactionsDisenrollmentReasonIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            String strValue = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Disen. Reason')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + strValue + "']");


                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);



            }
            else
            {
                By disenroll = By.XPath("//div[@id='div_DemographicDetailsDisenReason']/span");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(disenroll);
                tmsWait.Hard(1);
                UIMODUtilFunctions.selectTransDrpValue(strValue);
            }

        }


        [When(@"Transactions New Save Button is clicked")]
        public void WhenTransactionsNewSaveButtonIsClicked()
        {
            fw.ExecuteJavascript(EAM.TransactionsNew.SaveButton);

            tmsWait.Hard(2);
            try
            {
                Browser.ClosePopUps(true);
                tmsWait.Hard(1);
            }
            catch
            { tmsWait.Hard(1); }

        }

        [When(@"Transactions page Cancel button is click")]
        public void WhenTransactionsPageCancelButtonIsClick()
        {
            fw.ExecuteJavascript(EAM.TransactionsNew.CancelTransaction);
            tmsWait.Hard(2);

            try
            {
                Browser.ClosePopUps(true);
                tmsWait.Hard(1);
            }
            catch
            { tmsWait.Hard(1); }
            try
            {
                Browser.ClosePopUps(true);
                tmsWait.Hard(1);
            }
            catch
            { tmsWait.Hard(1); }
        }

        [Then(@"verify new static messgae ""(.*)"" is displayed")]
        public void ThenVerifyNewStaticMessgaeIsDisplayed(string p0)
        {
            Assert.AreEqual(p0.ToString(), "Transaction 1**** canceled successfully", "Message is not gettting displayed");

        }
        [Then(@"Verify View Edit Member page Member ID field is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageMemberIDFieldIsSetTo(string p0)
        {
            string expected = tmsCommon.GenerateData(p0);


            IWebElement elem = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtMemberID_43"));

            ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expected, elem);

        }
        [Then(@"Variable ""(.*)"" View Edit Member page  field is set to ""(.*)""")]
        public void ThenVariableViewEditMemberPageFieldIsSetTo(string p0, string p1)
        {
            IWebElement elem = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtMemberID_43")); ;
            String MemID = elem.GetAttribute("value");
            GlobalRef.MemberID = MemID;
        }

        [Then(@"Verify Administration Status Override page RX ID field is set to ""(.*)""")]
        public void ThenVerifyAdministrationStatusOverridePageRXIDFieldIsSetTo(string p0)
        {
            string expected = tmsCommon.GenerateData(p0);

            tmsWait.Hard(4);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By loc = By.XPath("//div[@role='presentation']//td[@aria-colindex='8'][contains(.,'" + expected + "')]");
                UIMODUtilFunctions.elementPresenceUsingLocators(loc);

            }
            else
            {
                IWebElement elem = Browser.Wd.FindElement(By.XPath("//table//tr/td[8]/span[contains(.,'" + expected + "')]"));

                ReUsableFunctions.compareExpectedStringActualWebElementStringValue(expected, elem);
            }

        }


        [Then(@"Verify View Edit Member page RX ID field is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageRXIDFieldIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string expected = tmsCommon.GenerateData(p0);
            IWebElement elem = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtRxID_39"));

            ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expected, elem);
        }

        [Then(@"Verify View Edit Member page RX BIN field is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageRXBINFieldIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string expected = tmsCommon.GenerateData(p0);
            IWebElement elem = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtRXBIN_36"));

            ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expected, elem);
        }

        [Then(@"Verify View Edit Member page RX PCN field is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageRXPCNFieldIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string expected = tmsCommon.GenerateData(p0);
            IWebElement elem = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtRXPCN_37"));
            //elem.Clear();
            ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expected, elem);
        }

        [When(@"Transactions page Enrollment Street Address one is set to ""(.*)""")]
        public void WhenTransactionsPageEnrollmentStreetAddressOneIsSetTo(string p0)
        {
            string expected = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                
                By Drp = By.XPath("//label[contains(.,'Residence Address 1')]/parent::div//input");
               
                Browser.Wd.FindElement(Drp).SendKeys(expected);

                tmsWait.Hard(3);


            }
            else
            {
                IWebElement elem = Browser.Wd.FindElement(By.Id("Transactioncode61ResidentialAddressupdateStreetAddress"));
                ReUsableFunctions.enterValueOnWebElement(elem, expected);
            }
        }

        [When(@"Transactions page Street Address Two is set to ""(.*)""")]
        public void WhenTransactionsPageStreetAddressTwoIsSetTo(string p0)
        {
            string expected = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {

                By Drp = By.XPath("//label[contains(.,'Residence Address 2')]/parent::div//input");

                Browser.Wd.FindElement(Drp).SendKeys(expected);

                tmsWait.Hard(3);


            }
            else
            {
                IWebElement elem = Browser.Wd.FindElement(By.Id("Transactioncode76ResidentialAddressupdateStreetAddress2"));
                ReUsableFunctions.enterValueOnWebElement(elem, expected);
            }
        }

        [When(@"Transaction code (.*) Residential Address update Address one is set to ""(.*)""")]
        public void WhenTransactionCodeResidentialAddressUpdateAddressOneIsSetTo(int p0, string p1)
        {
            string expected = tmsCommon.GenerateData(p1);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {

                By Drp = By.XPath("//label[contains(.,'Residence Address 1')]/parent::div//input");

                Browser.Wd.FindElement(Drp).SendKeys(expected);

                tmsWait.Hard(3);


            }
            else
            {
                IWebElement elem = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtStreetAddr"));
                ReUsableFunctions.enterValueOnWebElement(elem, expected);
            }
        }

        [When(@"Transactions page New Address Effective Date is set to ""(.*)""")]
        [Then(@"Transactions page New Address Effective Date is set to ""(.*)""")]
        [Given(@"Transactions page New Address Effective Date is set to ""(.*)""")]
        public void WhenTransactionsPageNewAddressEffectiveDateIsSetTo(string p0)
        {

            tmsWait.Hard(5);
            String strValue = tmsCommon.GenerateData(p0);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
               
                By Drp = By.XPath("//kendo-datepicker[@test-id='Transactioncode76ResidentialAddressupdateAddressEffectiveDate']//span[@role='button']");
                AngularFunction.enterDate(Drp, strValue);

                tmsWait.Hard(3);


            }
            else
            {
                strValue = strValue.Replace("/", "");
                IWebElement elem = Browser.Wd.FindElement(By.Id("Transactioncode76ResidentialAddressupdateAddressEffectiveDate"));
                elem.Clear();
                elem.SendKeys(strValue);
            }

        }

        [Then(@"Verify EAM page displayed error message as ""(.*)""")]
        public void ThenVerifyEAMPageDisplayedErrorMessageAs(string p0)
        {
            string expected = tmsCommon.GenerateData(p0);
            IWebElement elem = Browser.Wd.FindElement(By.XPath("//div[@id='ctl00_ctl00_MainMasterContent_MainContent_ValidationSummary1']//li[contains(.,'" + expected + "')]"));
            tmsWait.Hard(5);
            ReUsableFunctions.verifyStringContainsOnWebElement(expected, elem);
        }


        [When(@"Transactions page New Address End Date is set to ""(.*)""")]
        public void WhenTransactionsPageNewAddressEndDateIsSetTo(string p0)
        {

            tmsWait.Hard(5);
            String strValue = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                //strValue = strValue.Replace("/", ""); /*AngularFunction expects the '/' character to be present, removing to prevent errors*/
                By Drp = By.XPath("//kendo-datepicker[@test-id='Transactioncode76ResidentialAddressupdateAddressEndDate']//span[@role='button']");
                AngularFunction.enterDate(Drp, strValue);

               

            }
            else
            {
                strValue = strValue.Replace("/", "");
                IWebElement elem = Browser.Wd.FindElement(By.Id("Transactioncode76ResidentialAddressupdateAddressEndDate"));
                elem.Clear();
                elem.SendKeys(strValue);
            }

        }

        [When(@"Transactions page Action drop down is set to ""(.*)""")]
        public void WhenTransactionsPageActionDropDownIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string expected = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Action')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + expected + "']");


                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);



            }
            else
            {
                By action = By.XPath("//div[@id='div_Transactioncode76ResidentialAddressupdateAction']/span");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(action);
                tmsWait.Hard(1);
                UIMODUtilFunctions.selectTransDrpValue(expected);
            }

        }

        [When(@"Transactions page Zip Field is set to empty")]
        public void WhenTransactionsPageZipFieldIsSetToEmpty()
        {
            tmsWait.Hard(5);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
               
                By Drp = By.XPath("//label[contains(.,'Zip')]/parent::div//input");
                Browser.Wd.FindElement(Drp).SendKeys(Keys.Space);
                //Browser.Wd.FindElement(Drp).Clear();
               Browser.Wd.FindElement(Drp).SendKeys(Keys.Backspace);
                tmsWait.Hard(1);
                Browser.Wd.FindElement(Drp).SendKeys(Keys.Tab);
                tmsWait.Hard(2);
            }
            else
            {
                IWebElement elem = Browser.Wd.FindElement(By.Id("Transactioncode76ResidentialAddressupdateZip"));
                elem.Clear();
            }
        }

        [When(@"Transactions page Zip Field is set to ""(.*)""")]
        public void WhenTransactionsPageZipFieldIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            string expected = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement elem = Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Zip')]/parent::div//input)[1]"));
                tmsWait.Hard(5);
                elem.SendKeys(expected);
                tmsWait.Hard(1);
                elem.SendKeys(Keys.Tab);
            }
            else
            {
                IWebElement elem = Browser.Wd.FindElement(By.Id("Transactioncode76ResidentialAddressupdateZip"));
                tmsWait.Hard(5);
                elem.SendKeys(expected);
                tmsWait.Hard(1);
                elem.SendKeys(Keys.Tab);
            }
          
            // ReUsableFunctions.enterValueOnWebElement(elem, expected);
        }

        [Then(@"Verify Transactions page Error message on Zip field ""(.*)""")]
        public void ThenVerifyTransactionsPageErrorMessageOnZipField(string p0)
        {
            string expected_Message = tmsCommon.GenerateData(p0);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//span[contains(.,'" + expected_Message + "')])[2]")).Displayed, "Expected message is not displayed");
        }

        [Then(@"Verify Transactions page Error message on ZipFour field ""(.*)""")]
        public void ThenVerifyTransactionsPageErrorMessageOnZipFourField(string p0)
        {
            string expected_Message = tmsCommon.GenerateData(p0);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//span[contains(.,'" + expected_Message + "')])[2]")).Displayed, "Expected message is not displayed");
        }


        [When(@"Transactions page Zip Four Field is set to ""(.*)""")]
        public void WhenTransactionsPageZipFourFieldIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            string expected = tmsCommon.GenerateData(p0);
            IWebElement elem = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtZipFour_59"));

            ReUsableFunctions.enterValueOnWebElement(elem, expected);
        }

        [Then(@"Transactions page Zip Four Field is set to ""(.*)""")]
        public void ThenTransactionsPageZipFourFieldIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            string expected = tmsCommon.GenerateData(p0);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {

                By Drp = By.XPath("//label[contains(.,'ZipFour')]/parent::div//input");

                Browser.Wd.FindElement(Drp).SendKeys(expected);
                tmsWait.Hard(3);


            }
            else
            {

                IWebElement elem = Browser.Wd.FindElement(By.Id("Transactioncode76ResidentialAddressupdateZipFour"));

                elem.SendKeys(expected);
                tmsWait.Hard(1);
                elem.SendKeys(Keys.Tab);
            }

        }
        [When(@"Transactions page Street Address(.*) is set to ""(.*)""")]
        public void WhenTransactionsPageStreetAddressIsSetTo(int p0, string p1)
        {

            tmsWait.Hard(5);
            string expected = tmsCommon.GenerateData(p1);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
              
                By Drp = By.XPath("//label[contains(.,'Residence Address 1')]/parent::div//input");
                Browser.Wd.FindElement(Drp).Clear();
                Browser.Wd.FindElement(Drp).SendKeys(expected);

                tmsWait.Hard(3);


            }
            else
            {
                IWebElement elem = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtStreetAddr"));
                ReUsableFunctions.enterValueOnWebElement(elem, expected);
            }
        }


        [When(@"Transactions page Street Address one is set to ""(.*)""")]
        public void WhenTransactionsPageStreetAddressOneIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            string expected = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
               
                By Drp = By.XPath("//label[contains(.,'Residence Address 1')]/parent::div//input");
                Browser.Wd.FindElement(Drp).Clear();
                Browser.Wd.FindElement(Drp).SendKeys(expected);

                tmsWait.Hard(3);


            }
            else
            {

                IWebElement elem = Browser.Wd.FindElement(By.Id("Transactioncode76ResidentialAddressupdateStreetAddress"));
                elem.Clear();
                ReUsableFunctions.enterValueOnWebElement(elem, expected);
            }
        }

        [When(@"Transactions page Six One Transaction Street Address one is set to ""(.*)""")]
        public void WhenTransactionsPageSixOneTransactionStreetAddressOneIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            string expected = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Residence Address 1')]/parent::div//input");

                Browser.Wd.FindElement(Drp).SendKeys(expected);

                tmsWait.Hard(3);


            }
            else
            {

                IWebElement elem = Browser.Wd.FindElement(By.Id("Transactioncode61ResidentialAddressupdateStreetAddress"));
                elem.Clear();
                ReUsableFunctions.enterValueOnWebElement(elem, expected);
            }
        }

        [When(@"Transactions page Six One Transaction Street Address Two is set to ""(.*)""")]
        public void WhenTransactionsPageSixOneTransactionStreetAddressTwoIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            string expected = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Residence Address 2')]/parent::div//input");

                Browser.Wd.FindElement(Drp).SendKeys(expected);

                tmsWait.Hard(3);


            }
            else
            {
                IWebElement elem = Browser.Wd.FindElement(By.Id("Transactioncode61ResidentialAddressupdateStreetAddress2"));
                elem.Clear();
                ReUsableFunctions.enterValueOnWebElement(elem, expected);
            }
        }

        [When(@"New Member page Member Fields Plan One is set to ""(.*)""")]
        public void WhenNewMemberPageMemberFieldsPlanOneIsSetTo(string p0)
        {
            string expected = tmsCommon.GenerateData(p0);
            IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-input-plan1']"));
            elem.Clear();
            ReUsableFunctions.enterValueOnWebElement(elem, expected);
        }

        [When(@"New Member page Member Fields Plan Two is set to ""(.*)""")]
        public void WhenNewMemberPageMemberFieldsPlanTwoIsSetTo(string p0)
        {
            string expected = tmsCommon.GenerateData(p0);
            IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-input-plan2']"));
            elem.Clear();
            ReUsableFunctions.enterValueOnWebElement(elem, expected);
        }

        [When(@"New Member page Member Fields Plan Three is set to ""(.*)""")]
        public void WhenNewMemberPageMemberFieldsPlanThreeIsSetTo(string p0)
        {
            string expected = tmsCommon.GenerateData(p0);
            IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-input-plan3']"));
            elem.Clear();
            ReUsableFunctions.enterValueOnWebElement(elem, expected);
        }

        [When(@"New Member page Member Fields Plan Four is set to ""(.*)""")]
        public void WhenNewMemberPageMemberFieldsPlanFourIsSetTo(string p0)
        {
            string expected = tmsCommon.GenerateData(p0);
            IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-input-plan4']"));
            elem.Clear();
            ReUsableFunctions.enterValueOnWebElement(elem, expected);
        }

        [When(@"New Member page Member Fields Plan Five is set to ""(.*)""")]
        public void WhenNewMemberPageMemberFieldsPlanFiveIsSetTo(string p0)
        {
            string expected = tmsCommon.GenerateData(p0);
            IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-input-plan5']"));
            elem.Clear();
            ReUsableFunctions.enterValueOnWebElement(elem, expected);
        }

        [When(@"New Member page Member Fields Plan Six is set to ""(.*)""")]
        public void WhenNewMemberPageMemberFieldsPlanSixIsSetTo(string p0)
        {
            string expected = tmsCommon.GenerateData(p0);
            IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-input-plan6']"));
            elem.Clear();
            ReUsableFunctions.enterValueOnWebElement(elem, expected);
        }

        [When(@"New Member page Member Fields Plan Seven is set to ""(.*)""")]
        public void WhenNewMemberPageMemberFieldsPlanSevenIsSetTo(string p0)
        {
            string expected = tmsCommon.GenerateData(p0);
            IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-input-plan7']"));
            elem.Clear();
            ReUsableFunctions.enterValueOnWebElement(elem, expected);
        }

        [When(@"New Member page Member Fields Plan Eight is set to ""(.*)""")]
        public void WhenNewMemberPageMemberFieldsPlanEightIsSetTo(string p0)
        {
            string expected = tmsCommon.GenerateData(p0);
            IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-input-plan8']"));
            elem.Clear();
            ReUsableFunctions.enterValueOnWebElement(elem, expected);
        }

        [When(@"New Member page Member Fields Plan Nine is set to ""(.*)""")]
        public void WhenNewMemberPageMemberFieldsPlanNineIsSetTo(string p0)
        {
            string expected = tmsCommon.GenerateData(p0);
            IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-input-plan9']"));
            elem.Clear();
            ReUsableFunctions.enterValueOnWebElement(elem, expected);
        }

        [When(@"New Member page Member Fields Plan Ten is set to ""(.*)""")]
        public void WhenNewMemberPageMemberFieldsPlanTenIsSetTo(string p0)
        {
            string expected = tmsCommon.GenerateData(p0);
            IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='planDefinedFields-input-plan10']"));
            elem.Clear();
            ReUsableFunctions.enterValueOnWebElement(elem, expected);
        }

        [Then(@"Member New Save Button is clicked")]
        public void ThenMemberNewSaveButtonIsClicked()
        {
          
        }

        [When(@"New Transaction page Transaction Fields Plan One is set to ""(.*)""")]
        public void WhenNewTransactionPageTransactionFieldsPlanOneIsSetTo(string p0)
        {
            string expected = tmsCommon.GenerateData(p0);
            IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='TransactionRelatedPlanFieldsPlan1']"));
            elem.Clear();
            ReUsableFunctions.enterValueOnWebElement(elem, expected);
        }

        [When(@"New Transaction page Transaction Fields Plan Two is set to ""(.*)""")]
        public void WhenNewTransactionPageTransactionFieldsPlanTwoIsSetTo(string p0)
        {
            string expected = tmsCommon.GenerateData(p0);
            IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='TransactionRelatedPlanFieldsPlan2']"));
            elem.Clear();
            ReUsableFunctions.enterValueOnWebElement(elem, expected);
        }

        [When(@"New Transaction page Transaction Fields Plan Three is set to ""(.*)""")]
        public void WhenNewTransactionPageTransactionFieldsPlanThreeIsSetTo(string p0)
        {
            string expected = tmsCommon.GenerateData(p0);
            IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='TransactionRelatedPlanFieldsPlan3']"));
            elem.Clear();
            ReUsableFunctions.enterValueOnWebElement(elem, expected);
        }

        [When(@"New Transaction page Transaction Fields Plan Four is set to ""(.*)""")]
        public void WhenNewTransactionPageTransactionFieldsPlanFourIsSetTo(string p0)
        {
            string expected = tmsCommon.GenerateData(p0);
            IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='TransactionRelatedPlanFieldsPlan4']"));
            elem.Clear();
            ReUsableFunctions.enterValueOnWebElement(elem, expected);
        }

        [When(@"New Transaction page Transaction Fields Plan Five is set to ""(.*)""")]
        public void WhenNewTransactionPageTransactionFieldsPlanFiveIsSetTo(string p0)
        {
            string expected = tmsCommon.GenerateData(p0);
            IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='TransactionRelatedPlanFieldsPlan5']"));
            elem.Clear();
            ReUsableFunctions.enterValueOnWebElement(elem, expected);
        }

        [When(@"New Transaction page Transaction Fields Plan Six is set to ""(.*)""")]
        public void WhenNewTransactionPageTransactionFieldsPlanSixIsSetTo(string p0)
        {
            string expected = tmsCommon.GenerateData(p0);
            IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='TransactionRelatedPlanFieldsPlan6']"));
            elem.Clear();
            ReUsableFunctions.enterValueOnWebElement(elem, expected);
        }

        [When(@"New Transaction page Transaction Fields Plan Seven is set to ""(.*)""")]
        public void WhenNewTransactionPageTransactionFieldsPlanSevenIsSetTo(string p0)
        {
            string expected = tmsCommon.GenerateData(p0);
            IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='TransactionRelatedPlanFieldsPlan7']"));
            elem.Clear();
            ReUsableFunctions.enterValueOnWebElement(elem, expected);
        }

        [When(@"New Transaction page Transaction Fields Plan Eight is set to ""(.*)""")]
        public void WhenNewTransactionPageTransactionFieldsPlanEightIsSetTo(string p0)
        {
            string expected = tmsCommon.GenerateData(p0);
            IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='TransactionRelatedPlanFieldsPlan8']"));
            elem.Clear();
            ReUsableFunctions.enterValueOnWebElement(elem, expected);
        }

        [When(@"New Transaction page Transaction Fields Plan Nine is set to ""(.*)""")]
        public void WhenNewTransactionPageTransactionFieldsPlanNineIsSetTo(string p0)
        {
            string expected = tmsCommon.GenerateData(p0);
            IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='TransactionRelatedPlanFieldsPlan9']"));
            elem.Clear();
            ReUsableFunctions.enterValueOnWebElement(elem, expected);
        }

        [When(@"New Transaction page Transaction Fields Plan Ten is set to ""(.*)""")]
        public void WhenNewTransactionPageTransactionFieldsPlanTenIsSetTo(string p0)
        {
            string expected = tmsCommon.GenerateData(p0);
            IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='TransactionRelatedPlanFieldsPlan10']"));
            elem.Clear();
            ReUsableFunctions.enterValueOnWebElement(elem, expected);
        }



        [When(@"Transactions New RFIReceipt Date is set to ""(.*)""")]
        public void WhenTransactionsNewRFIReceiptDateIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            String strValue = tmsCommon.GenerateData(p0);
            

            IWebElement objDate = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='ApplicationDispositionRfiReceiptDate']//span[@role='button']"));
            AngularFunction.enterDate(objDate, strValue);

           
        }

        [When(@"Transactions ViewEdit RFIReceipt Date is set to ""(.*)""")]
        public void WhenTransactionsViewEditRFIReceiptDateIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            String strValue = tmsCommon.GenerateData(p0);
            
            
            IWebElement objDate = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='ApplicationDispositionActionsRfiReceiptDate']//span[@role='button']"));
            AngularFunction.enterDate(objDate, strValue);

        }


        [When(@"Transactions New InComplete Application check box is ""(.*)""")]
        public void WhenTransactionsNewInCompleteApplicationCheckBoxIs(string p0)
        {
            tmsWait.Hard(5);
            IWebElement elem = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_chkIncomplete_00"));
            if (p0.Equals("ON"))
            {
                if (elem.GetAttribute("Checked") == null)
                {
                    elem.Click();
                }
            }
            else if (p0.Equals("OFF"))
            {
                if (elem.GetAttribute("Checked").Equals(true))
                {
                    elem.Click();
                }
            }
        }


        [Then(@"Transactions New Receipt Date is set to ""(.*)""")]
        [When(@"Transactions New Receipt Date is set to ""(.*)""")]
        public void WhenTransactionsNewReceiptDateIsSetTo(string p0)
        {
            String strValue = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                AngularFunction.enterDate(cfAngularTransaction.AngularNewTransaction.receiptDate, strValue);
                

            }
            else
            {
                // click on calendar icon  - Note this is WorkAround
                IWebElement selectedDate = Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Receipt Date')]/parent::div/div//span[@role='button'])[1]"));
                fw.ExecuteJavascript(selectedDate);
                tmsWait.Hard(5);

                strValue = strValue.Replace("/", "");

                IWebElement objDate = EAM.TransactionsNew.ReceiptDate;
                objDate.Clear();
                objDate.Click();
                objDate.SendKeys(strValue);
            }
        }



        [When(@"Transactions New Member ID is set to ""(.*)""")]
        public void WhenTransactionsNewMemberIDIsSetTo(string p0)
        {
            IWebElement selectedDate = Browser.Wd.FindElement(By.XPath("//input[@test-id='DemographicDetailsMemberID']"));
            selectedDate.SendKeys("547467657");
        }

        [When(@"Transactions New SCC is set to ""(.*)""")]
        public void WhenTransactionsNewSCCIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            string scc = tmsCommon.GenerateData(p0);
            IWebElement element = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlCounty"));
            new SelectElement(element).SelectByText(scc);
        }

        [When(@"Attestation page I am new to Medicare checkbox is ""(.*)""")]
        public void WhenAttestationPageIAmNewToMedicareCheckboxIs(string p0)
        {
            IWebElement elem = Browser.Wd.FindElement(By.Id("chkNewToMedicare"));
            if (p0.Equals("ON"))
            {
                if (elem.GetAttribute("Checked") == null)
                {
                    elem.Click();
                }
            }
            else if (p0.Equals("OFF"))
            {
                if (elem.GetAttribute("Checked").Equals(true))
                {
                    elem.Click();
                }
            }


        }

        [Then(@"Verify Attestation page I am new to Medicare checkbox is ""(.*)""")]
        public void ThenVerifyAttestationPageIAmNewToMedicareCheckboxIs(string p0)
        {
            IWebElement elem = Browser.Wd.FindElement(By.Id("chkNewToMedicare"));
            if (p0.Equals("ON"))
            {
                bool results = elem.GetAttribute("Checked").Contains("true");
                Assert.IsTrue(results, " Element is not checked");

            }
            else if (p0.Equals("OFF"))
            {
                bool results = elem.GetAttribute("Checked") == null;
                Assert.IsTrue(results, " Element is not checked");
            }

        }

        [When(@"Transactions New Attestation link is Clicked")]
        public void WhenTransactionsNewAttestationLinkIsClicked()
        {
            IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='transaction-i-transactionAttestation']"));
            ReUsableFunctions.clickOnWebElement(elem);
            tmsWait.Hard(10);
        }

        [When(@"Attestation page I recently was released from incarceration\. I was released on ""(.*)""")]
        public void WhenAttestationPageIRecentlyWasReleasedFromIncarceration_IWasReleasedOn(string p0)
        {
            tmsWait.Hard(5);
            String strValue = tmsCommon.GenerateData(p0);


            if (ConfigFile.tenantType.Equals("tmsx"))
            {
               
                By Drp = By.XPath("//kendo-datepicker[@test-id='attestationQuestions-date-incarcerationReleaseDate']//span[@role='button']");
                AngularFunction.enterDate(Drp, strValue);

                tmsWait.Hard(3);


            }
            else
            {
                strValue = strValue.Replace("/", "");
                IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='attestationQuestions-date-incarcerationReleaseDate']"));
                elem.Clear();
                elem.SendKeys(strValue);
            }
        }

        [When(@"Attestation page I was enrolled in a Special Needs Plan \(SNP\) but I have lost the special needs qualification required to be in that plan\. I was disenrolled from the SNP is ""(.*)""")]
        public void WhenAttestationPageIWasEnrolledInASpecialNeedsPlanSNPButIHaveLostTheSpecialNeedsQualificationRequiredToBeInThatPlan_IWasDisenrolledFromTheSNPIs(string p0)
        {
            tmsWait.Hard(5);
            String strValue = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//kendo-datepicker[@test-id='attestationQuestions-date-snpDisenrolledDate']//span[@role='button']");
                AngularFunction.enterDate(Drp, strValue);

             
                tmsWait.Hard(3);


            }
            else
            {
                strValue = strValue.Replace("/", "");
                IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='attestationQuestions-date-snpDisenrolledDate']"));
                elem.Clear();
                elem.SendKeys(strValue);
            }
        }

        [When(@"Attestation page I recently left a PACE program on ""(.*)""")]
        public void WhenAttestationPageIRecentlyLeftAPACEProgramOn(string p0)
        {
            tmsWait.Hard(5);
            String strValue = tmsCommon.GenerateData(p0);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//kendo-datepicker[@test-id='attestationQuestions-date-leavingPaceDate']//span[@role='button']");
                AngularFunction.enterDate(Drp, strValue);

               
                tmsWait.Hard(3);


            }
            else
            {
                strValue = strValue.Replace("/", "");
                IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='attestationQuestions-date-leavingPaceDate']"));
                elem.Clear();
                elem.SendKeys(strValue);
            }
        }

        [When(@"Attestation page I am enrolling in a (.*) star plan is ""(.*)""")]
        public void WhenAttestationPageIAmEnrollingInAStarPlanIs(int p0, string p1)
        {
            tmsWait.Hard(5);

            IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='attestationQuestions-chk-isEnrollFiveStar']"));
            if (p0.Equals("ON"))
            {
                if (elem.GetAttribute("Checked") == null)
                {
                    elem.Click();
                }
            }
            else if (p0.Equals("OFF"))
            {
                if (elem.GetAttribute("Checked").Equals(true))
                {
                    elem.Click();
                }
            }

        }


        [When(@"Attestation page I am leaving employer or union coverage on ""(.*)""")]
        public void WhenAttestationPageIAmLeavingEmployerOrUnionCoverageOn(string p0)
        {
            tmsWait.Hard(5);
            String strValue = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//kendo-datepicker[@test-id='attestationQuestions-date-leavingEmployerCoverageDate']//span[@role='button']");
                AngularFunction.enterDate(Drp, strValue);


                tmsWait.Hard(3);


            }
            else
            {
                strValue = strValue.Replace("/", "");
                IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='attestationQuestions-date-leavingEmployerCoverageDate']"));
                elem.Clear();
                elem.SendKeys(strValue);
            }
        }

        [Then(@"Verify Attestation page I was enrolled in a Special Needs Plan \(SNP\) but I have lost the special needs qualification required to be in that plan\. I was disenrolled from the SNP is set to ""(.*)""")]
        public void ThenVerifyAttestationPageIWasEnrolledInASpecialNeedsPlanSNPButIHaveLostTheSpecialNeedsQualificationRequiredToBeInThatPlan_IWasDisenrolledFromTheSNPIsSetTo(string p0)
        {
            string expected = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='attestationQuestions-date-snpDisenrolledDate'] input"));
                ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expected, elem);
            }
            else
            {
                IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='attestationQuestions-date-snpDisenrolledDate']"));
                ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expected, elem);
            }



        }

        [Then(@"Verify Attestation page I recently left a PACE program on ""(.*)""")]
        public void ThenVerifyAttestationPageIRecentlyLeftAPACEProgramOn(string p0)
        {
            string expected = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='attestationQuestions-date-leavingPaceDate'] input"));
                ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expected, elem);
            }
            else
            {
                IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='attestationQuestions-date-leavingPaceDate']"));
                ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expected, elem);
            }
        }


        [Then(@"Verify Attestation page I am enrolling in a (.*) star plan is set to ""(.*)""")]
        public void ThenVerifyAttestationPageIAmEnrollingInAStarPlanIsSetTo(int p0, string p1)
        {
            IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='attestationQuestions-chk-isEnrollFiveStar']"));
            if (p0.Equals("ON"))
            {
                bool results = elem.GetAttribute("Checked").Contains("true");
                Assert.IsTrue(results, " Element is not checked");

            }
            else if (p0.Equals("OFF"))
            {
                bool results = elem.GetAttribute("Checked") == null;
                Assert.IsTrue(results, " Element is not checked");
            }
        }





        [Then(@"Verify Attestation page I recently was released from incarceration\. I was released field is set to ""(.*)""")]
        public void ThenVerifyAttestationPageIRecentlyWasReleasedFromIncarceration_IWasReleasedFieldIsSetTo(string p0)
        {
            string expected = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {


                IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='attestationQuestions-date-incarcerationReleaseDate'] input"));
                ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expected, elem);


            }
            else
            {
                IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='attestationQuestions-date-incarcerationReleaseDate']"));
                ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expected, elem);
            }

        }

        [Then(@"Verify \tAttestation page I recently obtained lawful presence status in the United States\. I got this status field is set to ""(.*)""")]
        public void ThenVerifyAttestationPageIRecentlyObtainedLawfulPresenceStatusInTheUnitedStates_IGotThisStatusFieldIsSetTo(string p0)
        {
            string expected = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {


                IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='attestationQuestions-date-lawfulPresenceStatusDate'] input"));
                ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expected, elem);


            }
            else
            {
                IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='attestationQuestions-date-lawfulPresenceStatusDate']"));
                ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expected, elem);
            }


        }

        [Then(@"Verify Attestation page I am leaving employer or union coverage field is set to ""(.*)""")]
        public void ThenVerifyAttestationPageIAmLeavingEmployerOrUnionCoverageFieldIsSetTo(string p0)
        {
            string expected = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {


                IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='attestationQuestions-date-leavingEmployerCoverageDate'] input"));
                ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expected, elem);


            }
            else
            {
                IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='attestationQuestions-date-leavingEmployerCoverageDate']"));
                ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expected, elem);
            }


        }


        [When(@"Attestation page I recently obtained lawful presence status in the United States\. I got this status on ""(.*)""")]
        public void WhenAttestationPageIRecentlyObtainedLawfulPresenceStatusInTheUnitedStates_IGotThisStatusOn(string p0)
        {
            tmsWait.Hard(5);
            String strValue = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//kendo-datepicker[@test-id='attestationQuestions-date-lawfulPresenceStatusDate']//span[@role='button']");
                AngularFunction.enterDate(Drp, strValue);


                tmsWait.Hard(3);
            }
            else
            {
                strValue = strValue.Replace("/", "");
                IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='attestationQuestions-date-lawfulPresenceStatusDate']"));
                elem.Clear();
                elem.SendKeys(strValue);
            }
        }
        [When(@"Attestation page OK button is Clicked")]
        public void WhenAttestationPageOKButtonIsClicked()
        {
            tmsWait.Hard(10);
            IWebElement elem = Browser.Wd.FindElement(By.CssSelector("[test-id='attestationQuestions-btn-ok']"));
            fw.ExecuteJavascript(elem);

            tmsWait.Hard(10);
        }

        [When(@"Attestation page Close button is Clicked")]
        public void WhenAttestationPageCloseButtonIsClicked()
        {
            IWebElement elem = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ImageButton2"));
            fw.ExecuteJavascript(elem);
            tmsWait.Hard(10);

        }


        [When(@"Effective Date From field is set to ""(.*)""")]
        public void WhenEffectiveDateFromFieldIsSetTo(string p0)
        {

            tmsWait.Hard(5);
            String strValue = tmsCommon.GenerateData(p0);
            strValue = strValue.Replace("/", "");
            IWebElement elem = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtEffAddress_61"));
            elem.Clear();
            elem.SendKeys(strValue);

        }

        [When(@"Election type is set to ""(.*)""")]
        public void WhenElectionTypeIsSetTo(string p0)
        {
            string expected = tmsCommon.GenerateData(p0);
            IWebElement elem = Browser.Wd.FindElement(By.Id("ctl00_MainMasterContent_ElectionType"));
            ReUsableFunctions.selectValueFromDropDown(elem, expected);
        }


        [When(@"Effective Date To field is set to ""(.*)""")]
        public void WhenEffectiveDateToFieldIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            String strValue = tmsCommon.GenerateData(p0);
            strValue = strValue.Replace("/", "");
            IWebElement elem = Browser.Wd.FindElement(By.Id("ctl00_MainMasterContent_EffDate_To"));
            elem.Clear();
            elem.SendKeys(strValue);
        }


        [When(@"Report page Effective Date From field is set to ""(.*)""")]
        public void WhenReportPageEffectiveDateFromFieldIsSetTo(string p0)
        {

            tmsWait.Hard(2);
            String strValue = tmsCommon.GenerateData(p0);
            strValue = strValue.Replace("/", "");
            IWebElement elem = Browser.Wd.FindElement(By.Id("ctl00_MainMasterContent_EffDate_From"));
            elem.Clear();
            elem.SendKeys(strValue);
        }



        public string setCheckboxTo;
        [When(@"Election Type Validation Check box is ""(.*)""")]
        public void WhenElectionTypeValidationCheckBoxIs(string p0)
        {

            string GenerateData = tmsCommon.GenerateData(p0);


            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("unchecked"))
            {

                if (EAM.AdministrationPage.ElectionTypeValidation.Selected == true)
                {
                    EAM.AdministrationPage.ElectionTypeValidation.Click();
                }

            }
            else if (setCheckboxTo.Equals("checked"))
            {
                if (EAM.AdministrationPage.ElectionTypeValidation.Selected == false)
                {
                    EAM.AdministrationPage.ElectionTypeValidation.Click();
                }
            }
        }

        [When(@"Plan Defined Fields page Plan(.*)Star Status tab Update button is clicked")]
        public void WhenPlanDefinedFieldsPagePlanStarStatusTabUpdateButtonIsClicked(int p0)
        {
            if (EAM.AdministrationPlanDefinedFieldsPlan5StarStatus.UpdateButton.Enabled == true)
            {
                EAM.AdministrationPlanDefinedFieldsPlan5StarStatus.UpdateButton.Click();
                IAlert alert = Browser.Wd.SwitchTo().Alert();
                alert.Accept();
            }
        }


        [When(@"Plan Defined Fields page Plan(.*)Star Status tab Plan ID ""(.*)"" Five Star is ""(.*)""")]
        public void WhenPlanDefinedFieldsPagePlanStarStatusTabPlanIDFiveStarIs(int p0, string p1, string p2)
        {
            string xpath = "//table[contains(@id,'MainMasterContent')]//td[contains(.,'" + p1.ToString() + "')]//following-sibling::td//input";
            IWebElement checkBox = Browser.Wd.FindElement(By.XPath(xpath));
            try
            {
                string checkBoxStatus = checkBox.GetAttribute("checked");
                if (checkBoxStatus.Equals("true"))
                {
                    fw.ExecuteJavascript(checkBox);
                }

            }
            catch { }

        }


        [When(@"Plan Defined Fields page Plan5Star Status tab Plan ID Five Star is ""(.*)""")]
        public void WhenPlanDefinedFieldsPagePlan5StarStatusTabPlanIDFiveStarIs(string p1, Table table)
        {
            string GenerateData = tmsCommon.GenerateData(p1);

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.AdministrationPlanDefinedFieldsPlan5StarStatus.PlanStatusTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            if (bThisRowMatches)
                            {
                                IWebElement thisEditTD = ApplicationRow.Element[1];
                                IWebElement thisEditLink = thisEditTD.FindElement(By.TagName("input"));


                                switch (GenerateData.ToLower())
                                {
                                    case "checked": { setCheckboxTo = "checked"; break; }
                                    case "on": { setCheckboxTo = "checked"; break; }
                                    case "yes": { setCheckboxTo = "checked"; break; }
                                    case "unchecked": { setCheckboxTo = "unchecked"; break; }
                                    case "off": { setCheckboxTo = "unchecked"; break; }
                                    case "no": { setCheckboxTo = "unchecked"; break; }
                                    default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
                                }

                                if (setCheckboxTo.Equals("unchecked"))
                                {


                                    if (thisEditLink.Selected == true)
                                    {
                                        thisEditLink.Click();
                                    }

                                }
                                else if (setCheckboxTo.Equals("checked"))
                                {
                                    if (thisEditLink.Selected == false)
                                    {
                                        thisEditLink.Click();
                                    }
                                }

                                //thisEditLink.Click();
                                tmsWait.Hard(2);



                            }

                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.AdministrationPlanDefinedFieldsPlan5StarStatus.PlanStatusTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }

        }


        [When(@"Plan Defined Fields page Plan (.*)Star Status tab has row")]
        public void WhenPlanDefinedFieldsPagePlanStarStatusTabHasRow(int p0, Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.AdministrationPlanDefinedFieldsPlan5StarStatus.PlanStatusTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("On Demand Letter Template Table has row: {0}", e.Message);
            }
        }


        [When(@"Transactions New Type of Application is set to ""(.*)""")]
        public void WhenTransactionsNewTypeOfApplicationIsSetTo(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0.ToString());

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                //By Drp = By.XPath("(//*[@test-id='transaction-select-typeOfApplication']//span)[3]");
                //By typeapp = By.XPath("//li[text()='" + strValue + "']");


                //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                //tmsWait.Hard(3);
                //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

                tmsWait.Hard(3);
                AngularFunction.selectDropDownValue(cfAngularTransaction.AngularNewTransaction.typeOfApplicationDrp, strValue);
                tmsWait.Hard(3);

            }
            else
            {
                IWebElement application = Browser.Wd.FindElement(By.CssSelector("[aria-owns='typeOfApplication_listbox']"));
                UIMODUtilFunctions.selectDropDownValueFromGendoUI(application, strValue);
                tmsWait.Hard(2);
            }

            //SelectElement thisField = new SelectElement(EAM.TransactionsNew61.TypeOfApplication);
            //thisField.SelectByText(strValue);
        }

        [Then(@"Verify Transactions New Type of Application is set to ""(.*)""")]
        public void ThenVerifyTransactionsNewTypeOfApplicationIsSetTo(string p0)
        {
            string exp = tmsCommon.GenerateData(p0);
            SelectElement ToA = new SelectElement(EAM.TransactionsNew61.TypeOfApplication);
            string actual = ToA.SelectedOption.Text;

            Assert.AreEqual(actual, exp, exp + "Election Type is not gettting displayed");
        }

        [When(@"Transactions New Force Acceptance check box is set to ""(.*)""")]
        public void WhenTransactionsNewForceDenyCheckBoxIsSetTo(string p0)
        {
            string GenerateData = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {

                By Drp = By.XPath("//label[contains(.,'Force Acceptance')]/parent::div/input");

                ReUsableFunctions.CheckBoxOperations(Browser.Wd.FindElement(Drp), p0);

                tmsWait.Hard(3);
            }
            else
            {

                switch (GenerateData.ToLower())
                {
                    case "checked": { setCheckboxTo = "checked"; break; }
                    case "on": { setCheckboxTo = "checked"; break; }
                    case "yes": { setCheckboxTo = "checked"; break; }
                    case "unchecked": { setCheckboxTo = "unchecked"; break; }
                    case "off": { setCheckboxTo = "unchecked"; break; }
                    case "no": { setCheckboxTo = "unchecked"; break; }
                    default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
                }

                if (setCheckboxTo.Equals("unchecked"))
                {
                    if (EAM.TransactionsNew.ForceAcceptance.Selected == true)
                    {
                        EAM.TransactionsNew.ForceAcceptance.Click();
                        Console.WriteLine("ForceAcceptance check box is set to " + GenerateData);
                    }


                }
                else
                {
                    if (EAM.TransactionsNew.ForceAcceptance.Selected == false)
                    {
                        fw.ExecuteJavascript(EAM.TransactionsNew.ForceAcceptance);
                        Console.WriteLine("ForceAcceptance check box is set to " + GenerateData);
                    }
                }

            }
        }

        Boolean sepr;
        [When(@"Verify New Transacton page Election Type ""(.*)"" is not displayed")]
        public void WhenVerifyNewTransactonPageElectionTypeIsNotDisplayed(string p0)
        {
            tmsWait.Hard(2);
            string strValue = tmsCommon.GenerateData(p0.ToString());
            SelectElement selectList = new SelectElement(EAM.TransactionsNew.ElectionType);
            IList<IWebElement> options = selectList.Options;

            foreach (IWebElement element in options)
            {
                String var2 = element.Text;
                Console.WriteLine(var2);
                if (var2 != strValue)
                {
                    sepr = true;
                    break;
                }

            }

            if (sepr)
            {
                Console.WriteLine(" The Election Type Drop Down list Doesnt have [{0}] " + p0);
            }


        }

        [When(@"Transactions New Zip Value is set to ""(.*)""")]
        public void WhenTransactionsNewZipValueIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                
                By Drp = By.XPath("(//label[contains(.,'Zip')]/parent::div//input)[1]");
                Browser.Wd.FindElement(Drp).Clear();
                Browser.Wd.FindElement(Drp).SendKeys(value);

                tmsWait.Hard(3);


            }
            else
            {
                By zip = By.XPath("//input[@id='ctl00_ctl00_MainMasterContent_MainContent_txtZip']");
                Browser.Wd.FindElement(zip).SendKeys(value);
                tmsWait.Hard(5);
            }

        }


        [When(@"Transactions New Election Type is set to ""(.*)""")]
        public void WhenTransactionsNewElectionTypeIsSetTo(string p0)
        {

            tmsWait.Hard(5);
            string strValue = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                //By Drp = By.XPath("//label[contains(.,'Election Type')]/parent::div//span[@class='k-select']");
                //By typeapp = By.XPath("//li[text()='" + strValue + "']");


                //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                //tmsWait.Hard(3);
                //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

                AngularFunction.selectDropDownValue(cfAngularTransaction.AngularNewTransaction.ElectionTypeDrp, strValue);

            }
            else
            {


                By pbp = By.XPath("//div[@id='div_DemographicDetailsElectionType']/span");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(pbp);
                tmsWait.Hard(2);
                UIMODUtilFunctions.selectTransDrpValue(strValue);

            }

        }

        [When(@"Transactions New Accessibility Format is set to ""(.*)""")]
        public void WhenTransactionsNewAccessibilityFormatIsSetTo(string p0)
        {

            tmsWait.Hard(5);
            string strValue = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                AngularFunction.selectDropDownValue(cfAngularTransaction.AngularNewTransaction.AccessibilityFormat, strValue);
            }
            else
            {

                By pbp = By.XPath("//div[@id='div_DemographicDetailsAccessibilityFormat']/span");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(pbp);
                tmsWait.Hard(2);
                UIMODUtilFunctions.selectTransDrpValue(strValue);

            }

        }


        [When(@"Transactions New Date Edit Override is set to ""(.*)""")]
        public void WhenTransactionsNewDateEditOverrideIsSetTo(string p0)
        {

            tmsWait.Hard(5);
            string strValue = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                AngularFunction.selectDropDownValue(cfAngularTransaction.AngularNewTransaction.DateEditOvr, strValue);
            }
            else
            {

                By pbp = By.XPath("//div[@id='div_DemographicDetailsDateEditOverride']/span");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(pbp);
                tmsWait.Hard(2);
                UIMODUtilFunctions.selectTransDrpValue(strValue);

            }

        }

        [Then(@"Verify Error Message ""(.*)"" whenn election type is set to ""(.*)""")]
        public void ThenVerifyErrorMessageWhennElectionTypeIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(3);
            string expectedValue = tmsCommon.GenerateData(p0);
            string strValue = tmsCommon.GenerateData(p1);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Election Type')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + strValue + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                ////By toastMsg = By.XPath("//div[@class='k-notification-content']");
               // string actValue = Browser.Wd.FindElement(toastMsg).Text;
               // Assert.IsTrue(actValue.Contains(expectedValue));
            }
            else
            {
                By pbp = By.XPath("//div[@id='div_DemographicDetailsElectionType']/span");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(pbp);
                tmsWait.Hard(2);
                UIMODUtilFunctions.selectTransDrpValue(strValue);

                string actualValue = Browser.Wd.FindElement(By.XPath("//div[@class='toast-message']")).GetAttribute("aria-label");
                Assert.IsTrue(actualValue.Contains(expectedValue));
            }
        }


        [When(@"Transactions New PBP ID is set to ""(.*)""")]
        public void WhenTransactionsNewPBPIDIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string strValue = tmsCommon.GenerateData(p0);

            By pbp = By.XPath("//div[@id='div_DemographicDetailsPbp']/span");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(pbp);
            tmsWait.Hard(2);
            UIMODUtilFunctions.selectTransDrpValue(strValue);
        }


        [Then(@"Transaction New page Accept Alert")]
        public void ThenTransactionNewPageAcceptAlert()
        {
            try
            {
                UIMODUtilFunctions.clickOnConfirmationYesDialog();
            }
            catch
            {

            }
            //tmsWait.WaitForAlertPresent();
            //if (tmsWait.IsAlertPresent())
            //{
            //    Browser.Wd.SwitchTo().Alert().Accept();
            //}
            tmsWait.Hard(2);
        }

        [Then(@"Transaction New page Verify Alert")]
        public void ThenTransactionNewPageVerifyAlert()
        {
            tmsWait.WaitForAlertPresent();
            if (tmsWait.IsAlertPresent())
            {
                String msg = Browser.Wd.SwitchTo().Alert().Text;
                Console.WriteLine(msg);

                Assert.IsTrue(msg.Contains("You cannot select a date other than the first day of month. The date will be automatically changed."));

                Browser.Wd.SwitchTo().Alert().Accept();
            }
        }

        [When(@"Transactions New Force Acceptance is set to ""(.*)""")]
        [Then(@"Transactions New Force Acceptance is set to ""(.*)""")]
        public void WhenTransactionsNewForceAcceptanceIsSetTo(string status)
        {
            if (status == "Checked")
                EAM.TransactionsNew.ForceAcceptance.Click();
            if (status.ToLower().Trim() == "unchecked")
            {
                if (EAM.TransactionsNew.ForceAcceptance.Selected)
                    EAM.TransactionsNew.ForceAcceptance.Click();
            }
            tmsWait.Hard(5);
        }


        [Then(@"Transactions New Incomplete Application is set to ""(.*)""")]
        [When(@"Transactions New Incomplete Application is set to ""(.*)""")]
        public void WhenTransactionsNewIncompleteApplicationIsSetTo(string status)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement checkStatus = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Incomplete Application')]/parent::div//input"));

                bool checkStatusChecked = checkStatus.Selected;
                if (status.ToLower().Equals("checked"))
                {
                    if (!checkStatusChecked)
                    {
                        fw.ExecuteJavascript(checkStatus);
                    }
                }
                else
                {
                    if (checkStatusChecked)
                    {
                        fw.ExecuteJavascript(checkStatus);
                    }

                }

            }
            else
            {
                if (status == "Checked")
                {
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(By.Id("ApplicationDispositionIncompleteApplication"));
                    //EAM.TransactionsNew.IncompleteApplication.Click();
                }
                if (status.ToLower().Trim() == "unchecked")
                {
                    if (EAM.TransactionsNew.IncompleteApplication.Selected) EAM.TransactionsNew.IncompleteApplication.Click();
                }
                tmsWait.Hard(5);
            }
        }


        [When(@"Transactions New Missing Item is set to ""(.*)""")]
        public void WhenTransactionsNewMissingItemIsSetTo(string item)
        {
            tmsWait.Hard(3);
            string missingItem = tmsCommon.GenerateData(item);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Missing Item')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + missingItem + "']");


                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);



            }
            else
            {

                By missItem = By.XPath("//div[@id='div_ApplicationDispositionMissingItem']/span");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(missItem);
                tmsWait.Hard(2);
                UIMODUtilFunctions.selectTransDrpValue(missingItem);
            }
        }

        [When(@"Transactions New Denial Reason is set to ""(.*)""")]
        public void WhenTransactionsNewDenialReasonIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string DenialReason = tmsCommon.GenerateData(p0);
            By Drp = By.XPath("//label[contains(.,'Denial Reason')]/parent::div//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + DenialReason + "']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
            tmsWait.Hard(3);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);


        }


        [Then(@"Verify Transactions New Special Need Plan table Exists and can be expanded")]
        public void ThenVerifyTransactionsNewSpecialNeedPlanTableExistsAndCanBeExpanded()
        {
            if (EAM.TransactionsNew61.SpecialNeedPlan.Displayed == true)
            {
                tmsWait.Hard(2);
                EAM.TransactionsNew61.SpecialNeedPlan.Click();
            }
            else
            {
                Assert.Fail("Special Need Plan Frame cannot be seen");
            }
        }


        [Then(@"Verify Special Need Plan Fields are ""(.*)""")]
        public void ThenVerifySpecialNeedPlanFieldsAre(string p0)
        {

            string GenerateData = tmsCommon.GenerateData(p0);
            tmsWait.Hard(2);

            switch (GenerateData.ToLower())
            {
                case "present": { FieldStatus = "present"; break; }
                case "Present": { FieldStatus = "present"; break; }
                case "PRESENT": { FieldStatus = "present"; break; }
                case "Notpresent": { FieldStatus = "notpresent"; break; }
                case "notpresent": { FieldStatus = "notpresent"; break; }
                case "NOTPRESENT": { FieldStatus = "notpresent"; break; }

                default: { Console.WriteLine(" Field should be present/PRESENT or Notpresent/NOTPRESENT"); break; }
            }

            if (FieldStatus.Equals("present"))
            {
                if (EAM.TransactionsNew61.SpecialNeedPlan.Displayed == true)
                {
                    tmsWait.Hard(2);
                    EAM.TransactionsNew61.SpecialNeedPlan.Click();
                }
                tmsWait.Hard(3);
                Assert.IsTrue(EAM.TransactionsNew61.MedicaidNumber.Displayed == true, "MedicaidNumber Field exists");
                Assert.IsTrue(EAM.TransactionsNew61.MedicaidLevel.Displayed == true, "MedicaidLevel Field exists");
                Assert.IsTrue(EAM.TransactionsNew61.InstitutionName.Displayed == true, "InstitutionName Field exists");
                Assert.IsTrue(EAM.TransactionsNew61.FacilityType.Displayed == true, "FacilityType Field exists");
                Assert.IsTrue(EAM.TransactionsNew61.FacilityEntryDate.Displayed == true, "FacilityEntryDate Field exists");
                Assert.IsTrue(EAM.TransactionsNew61.FollowUpDate.Displayed == true, "FollowUpDate Field exists");
                Assert.IsTrue(EAM.TransactionsNew61.VerificationDate.Displayed == true, "VerificationDate Field exists");
                Assert.IsTrue(EAM.TransactionsNew61.ChronicConditions.Displayed == true, "ChronicConditions Field exists");
                Assert.IsTrue(EAM.TransactionsNew61.CareAssessmentReceivedCompleted.Displayed == true, "CareAssessmentReceivedCompleted Field exists");
                Assert.IsTrue(EAM.TransactionsNew61.GracePeriod.Displayed == true, "GracePeriod Field exists");
                Assert.IsTrue(EAM.TransactionsNew61.ContactInfo.Displayed == true, "ContactInfo Field exists");
                Assert.IsTrue(EAM.TransactionsNew61.InstitutionAddress.Displayed == true, "InstitutionAddress Field exists");

            }
            else if (FieldStatus.Equals("notpresent"))
            {

                try
                {
                    EAM.TransactionsNew61.SpecialNeedPlan.Click();
                    Assert.IsTrue(EAM.TransactionsNew61.SpecialNeedPlan.Displayed == false, "Special need plan fields are not displayed for TC51 as expected");
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    Assert.IsTrue(true);
                    //Assert.IsTrue(EAM.TransactionsNew61.SpecialNeedPlan.Displayed == false, "Special need plan fields are not displayed for TC51 as expected");
                }
            }
        }

        [When(@"Transactions New Primary Rx ID is set to ""(.*)""")]
        [Given(@"Transactions New Primary Rx ID is set to ""(.*)""")]
        public void WhenTransactionsNewPrimaryRxIDIsSetTo(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0);
            tmsWait.Hard(3);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {

             try
             {
                    //By Drp = By.XPath("//label[contains(.,'Primary Rx ID')]/parent::div//input");

                    //Browser.Wd.FindElement(Drp).SendKeys(strValue);

                    //tmsWait.Hard(3);

                    AngularFunction.sendKeysWithClear(cfAngularTransaction.AngularNewTransaction.PrimaryRxID, strValue);

                }
                catch
                {
                    fw.ConsoleReport(" Element is in disabled state");
                }


            }
            else
            {
                try
                {
                    IWebElement objDate = EAM.TransactionsNew.PrimaryRxID;
                    if (objDate.Enabled == true)
                    {
                        objDate.Clear();
                        objDate.SendKeys(strValue);
                    }
                }
                catch
                {
                    fw.ConsoleReport(" Element is in disabled state");
                }
            }
        }


        [When(@"Transactions New Primary Rx ID is saved to variable ""(.*)""")]
        [Then(@"Transactions New Primary Rx ID is saved to variable ""(.*)""")]
        public void WhenTransactionsNewPrimaryRxIDIsSavedToVariable(string p0)
        {
            String strValue = tmsCommon.GenerateData(p0);
            String RxIDValue = EAM.TransactionsNew.PrimaryRxID.Text;

            fw.setVariable(strValue, RxIDValue);
        }

        [When(@"Transactions New Primary RxBIN is set to blank")]
        public void WhenTransactionsNewPrimaryRxBINIsSetToBlank()
        {
            tmsWait.Hard(1);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Primary Rx BIN')]/parent::div//input");

                Browser.Wd.FindElement(Drp).Clear();
                Browser.Wd.FindElement(Drp).SendKeys(Keys.Space);
                Browser.Wd.FindElement(Drp).SendKeys(Keys.Backspace);
                Browser.Wd.FindElement(Drp).SendKeys(Keys.Tab);
                tmsWait.Hard(3);


            }
            else
            {
                IWebElement objDate = EAM.TransactionsNew.PrimaryRxBIN;
                objDate.Clear();
            }
            //objDate.SendKeys(strValue);
        }

        [When(@"Transactions Save Button is clicked")]
        [Then(@"Transactions Save Button is clicked")]
        public void ThenTransactionsSaveButtonIsClicked()
        {
            tmsWait.Hard(1);
            fw.ExecuteJavascript(EAM.TransactionsNew.SaveButton);
            tmsWait.Hard(1);
            try
            {
                Browser.ClosePopUps(true);
                tmsWait.Hard(1);
            }
            catch
            { tmsWait.Hard(1); }
            try
            {
                UIMODUtilFunctions.clickOnConfirmationYesDialog();
                tmsWait.Hard(3);
            }
            catch
            {
                tmsWait.Hard(3);
            }
            tmsWait.Hard(1);
            try
            {
                EAM.TransactionsNew.ContinueAnyway.Click();
                tmsWait.Hard(1);
            }
            catch { tmsWait.Hard(1); }
            try
            {
                EAM.TransactionsNew.ContinueAnyway.Click();
                tmsWait.Hard(1);
            }
            catch { tmsWait.Hard(1); }
            //Browser.Wd.Navigate().Refresh();
            try
            {
                UIMODUtilFunctions.clickOnConfirmationYesDialog();
                tmsWait.Hard(3);
            }
            catch
            {
                tmsWait.Hard(3);
            }
            tmsWait.Hard(1);
        }
        [Then(@"Transactions New page Save Button is clicked")]
        public void ThenTransactionsNewPageSaveButtonIsClicked()
        {
            tmsWait.Hard(3);
            fw.ScrollWindowToViewElement(EAM.TransactionsNew.SaveButton);
            tmsWait.Hard(2);
            //AngularFunction.clickOnElement(EAM.TransactionsNew.SaveButton);
            fw.ExecuteJavascript(EAM.TransactionsNew.SaveButton);
            tmsWait.Hard(3);

            try
            {
                UIMODUtilFunctions.clickOnConfirmationYesDialog();
                tmsWait.Hard(3);

            }
            catch
            {

                Console.WriteLine("No Alert is present now");

            }


            try
            {
                UIMODUtilFunctions.clickOnConfirmationYesDialog();
                tmsWait.Hard(3);

            }
            catch
            {

                Console.WriteLine("No Continue Anyway is present now");

            }

            try
            {
                UIMODUtilFunctions.clickOnConfirmationYesDialog();
                tmsWait.Hard(2);
            }
            catch
            {
                Console.WriteLine("No Confirmation Dialog");
            }

        }

        [When(@"Transactions New Primary RXID is set to ""(.*)""")]
        public void WhenTransactionsNewPrimaryRXIDIsSetTo(string value)
        {
            try
            {
                By Drp = By.XPath("//label[contains(.,'Primary Rx ID')]/parent::div//input");
                Browser.Wd.FindElement(Drp).Clear();
                Browser.Wd.FindElement(Drp).SendKeys(value);

                tmsWait.Hard(3);

            }
            catch
            {
                IWebElement rxid = Browser.Wd.FindElement(By.Id("RxDetailsPrimaryRxID"));
                ReUsableFunctions.clearContentOnWebElement(rxid);
                ReUsableFunctions.enterValueOnWebElement(rxid, value);
            }
        }

        [Then(@"Verify Transactions New Primary RXID is set to ""(.*)""")]
        public void ThenVerifyTransactionsNewPrimaryRXIDIsSetTo(string expected)
        {
            tmsWait.Hard(3);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                string Value = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Primary Rx ID')]/parent::div//input")).GetAttribute("value");
                Assert.AreEqual(Value, expected, "Actual and Expected result not matching");
            }
            else
            {
                IWebElement rxid = Browser.Wd.FindElement(By.Id("RxDetailsPrimaryRxID"));
                ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expected, rxid);
            }
        }

        [Then(@"Transactions page New Save Button is clicked")]
        public void ThenTransactionsPageNewSaveButtonIsClicked()
        {
            tmsWait.Hard(3);
            fw.ExecuteJavascript(EAM.TransactionsNew.SaveButton);
            try
            {
                UIMODUtilFunctions.clickOnConfirmationYesDialog();
            }
            catch
            {
                fw.ConsoleReport(" There is no dialog");
            }
            try
            {
                UIMODUtilFunctions.clickOnConfirmationYesDialog();
                tmsWait.Hard(3);
            }
            catch
            {
                tmsWait.Hard(3);
            }
            tmsWait.Hard(3);
        }
        [Then(@"Transactions page New Save Button is clicked1")]
        public void ThenTransactionsPageNewSaveButtonIsClicked1()
        {
            //tmsWait.Hard(3);
            try
            {

                fw.ExecuteJavascript(EAM.TransactionsNew.SaveButton1);
            }
            catch
            {

                fw.ExecuteJavascript(EAM.TransactionsNew.SaveButton);
            }
            try
            {
                UIMODUtilFunctions.clickOnConfirmationYesDialog();
            }
            catch
            {
                fw.ConsoleReport(" There is no dialog");
            }
            // try
            // {
            //     UIMODUtilFunctions.clickOnConfirmationYesDialog();
            //     //tmsWait.Hard(3);
            // }
            // catch
            // {
            //     //tmsWait.Hard(3);
            // }
            tmsWait.Hard(1);
        }

        [Then(@"EAM Transactions New page Save Button is clicked")]
        public void ThenEAMTransactionsNewPageSaveButtonIsClicked()
        {
            tmsWait.Hard(1);

            fw.ExecuteJavascript(EAM.TransactionsNew.SaveButton);
            tmsWait.Hard(2);
            Browser.ClosePopUps(true);
            try
            {
                UIMODUtilFunctions.clickOnConfirmationYesDialog();
                tmsWait.Hard(3);
            }
            catch
            {
                tmsWait.Hard(3);
            }
            try
            {
                UIMODUtilFunctions.clickOnConfirmationYesDialog();
                tmsWait.Hard(3);
            }
            catch
            {
                tmsWait.Hard(3);
            }
            tmsWait.Hard(4);
        }

        [Then(@"I click on Add New Transaction page Save button and verify message ""(.*)""")]
        public void ThenIClickOnAddNewTransactionPageSaveButtonAndVerifyMessage(string p0)
        {
            // cfUIMODMemberCreation.UIMODMemberCreation.SaveBtn.Click();
            fw.ExecuteJavascript(EAM.TransactionsNew.SaveButton);
            // Toaster message verification comment due to Time out issue
            string actualvalue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
            //Console.Write(actualvalue);
            Assert.IsTrue(p0.ToString().Contains(actualvalue), "Message is not displayed");
            tmsWait.Hard(5);
        }



        [Then(@"Verify Transactions New Page displayed error message as ""(.*)""")]
        public void ThenVerifyTransactionsNewPageDisplayedErrorMessageAs(string p0)
        {
            string expected_message = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {

                By Drp = By.XPath("//div[contains(.,'" + expected_message + "')]");
                bool msgPresence = Browser.Wd.FindElement(Drp).Displayed;
                Assert.IsTrue(msgPresence);

                tmsWait.Hard(3);


            }
            else
            {

                IWebElement errormessage = Browser.Wd.FindElement(By.XPath("//label[@test-id='memberErrors-lbl-errorCount']"));
                string actual_message = errormessage.Text;
                Assert.IsTrue(actual_message.Contains(expected_message), p0 + "is not geting displayed");
            }
        }
        [Then(@"Verify Transactions New Page not displayed error message as ""(.*)""")]
        public void ThenVerifyTransactionsNewPageNotDisplayedErrorMessageAs(string p0)
        {
            string actual_message = null;
            bool flag = false;
            try
            {
                string expected_message = tmsCommon.GenerateData(p0);
                IWebElement errormessage = Browser.Wd.FindElement(By.XPath("//label[@test-id='memberErrors-lbl-errorCount']"));
                actual_message = errormessage.Text;
                flag = actual_message.Contains(p0);

            }
            catch (Exception ex)
            {
                Assert.IsFalse(flag, p0 + "is  geting displayed");
            }

        }







        [Then(@"Transactions New Save Button is clicked")]
        public void ThenTransactionsNewSaveButtonIsClicked()
        {

            tmsWait.Hard(5);
            ReUsableFunctions.clickOnWebElementAfterScrollingInToSpecicElementView(EAM.TransactionsNew.SaveButton);

            tmsWait.Hard(3);
            try
            {
                UIMODUtilFunctions.clickOnConfirmationYesDialog();
                tmsWait.Hard(3);
            }
            catch
            {
                fw.ConsoleReport(" There is no Confirmation dialog");
                tmsWait.Hard(3);
            }
            try
            {
                UIMODUtilFunctions.clickOnConfirmationYesDialog();
                tmsWait.Hard(3);
            }
            catch
            {
                fw.ConsoleReport(" There is no Confirmation dialog");
                tmsWait.Hard(3);
            }
            ////try
            ////{
            ////    Browser.ClosePopUps(true);
            ////    tmsWait.Hard(1);
            ////}
            ////catch
            ////{ tmsWait.Hard(1); }

            //try
            //{
            //    EAM.TransactionsNew.ContinueAnyway.Click();
            //    Browser.ClosePopUps(true);
            //    tmsWait.Hard(1);
            //}
            //catch { tmsWait.Hard(1); }
            //try
            //{
            //    EAM.TransactionsNew.ContinueAnyway.Click();
            //    Browser.ClosePopUps(true);
            //    tmsWait.Hard(1);
            //}
            //catch { tmsWait.Hard(1); }
            //   tmsWait.WaitForReadyStateComplete(60);
            //    tmsWait.WaitForElementExist( By.XPath("//*[contains(@id, 'MainContent_lblMsg')]"), 30);  
            //Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(4);
            //scroll up tyo see if any error while saving the transaction 



        }

        [Then(@"Verify NewTrans page displayed message ""(.*)""")]
        public void ThenVerifyNewTransPageDisplayedMessage(string p0)
        {
            tmsWait.Hard(2);
            string expected = p0.ToString();
            string actual = Browser.Wd.FindElement(By.XPath("//div[@id='ctl00_ctl00_MainMasterContent_MainContent_ValidationSummary1']")).Text;
            Assert.IsFalse(actual.Contains(expected), expected + "error message not displaye");
            //Assert.AreEqual(expected, actual, actual + " is displayed on ERF Page");
        }


        [Then(@"Transactions Summary Message ""(.*)"" is displayed")]
        public void ThenTransactionsSummaryMessageIsDisplayed(string p0)
        {
            try
            {
                string fieldName = "Transactions Summary Message";
                string GeneratedData = tmsCommon.GenerateData(p0);
                string thisFieldValue = EAM.TransactionsNew.SummaryMessage.Text;

                Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
                fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
            }
            catch
            {

            }
        }

        [Then(@"Transactions New Static Message ""(.*)"" is displayed")]
        public void ThenTransactionsNewStaticMessageIsDisplayed(string p0)
        {
            //tmsWait.WaitForReadyStateComplete(20);

            string strValue = tmsCommon.GenerateData(p0);
            ReUsableFunctions.toasterMessageDisplay(strValue);

            ///  bool blnIsTextFound = tmsWait.WaitForElementHasText(By.XPath("//*[contains(@id, 'MainContent_lblMsg')]"), strValue, 30);
            //string thisFieldValue = EAM.TransactionsNew.PageMessage.Text;

            // Assert.IsTrue(blnIsTextFound, "Page Message value is [{0}], expected [{1}]", thisFieldValue, strValue);
            //fw.ConsoleReport(string.Format("   Verification Point: Page Message value is [{0}], expected [{1}] - They are expected to match.", thisFieldValue, strValue));
        }



        [When(@"Transactions New View Member Info Button is clicked")]
        [Then(@"Transactions New View Member Info Button is clicked")]
        public void WhenTransactionsNewViewMemberInfoButtonIsClicked()
        {
            try
            {
                tmsWait.Hard(2);
                fw.ExecuteJavascript(EAM.TransactionsNew.ViewMemberInfoButton);

                tmsWait.Hard(5);

            }
            catch
            {

            }
        }
        [When(@"Transactions New Disen Reason Glossary Icon is clicked")]
        public void WhenTransactionsNewDisenReasonGlossaryIconIsClicked()
        {
            fw.ExecuteJavascript(EAM.TransactionsNew.DisenReasonIcon);
            tmsWait.Hard(1);
        }
        [Then(@"Transactions New Disenrollment Reason PopUp Close Icon is clicked")]
        public void ThenTransactionsNewDisenrollmentReasonPopUpCloseIconIsClicked()
        {
            EAM.TransactionsNew.DisenReasonTableClose.Click();
            tmsWait.Hard(1);
        }

        [Then(@"Verify Transactions New Trans Disen\.Reason field does not have value ""(.*)""")]
        public void ThenVerifyTransactionsNewTransDisen_ReasonFieldDoesNotHaveValue(string p0)
        {
            tmsWait.Hard(1);
            string fieldName = "Disen Reason";
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement dropDownElement = new SelectElement(EAM.TransactionsNew.DisenReason);
            IList<IWebElement> dropDownOptions = dropDownElement.Options;
            Boolean bFoundOptionInList = false;
            string optionCollection = "";
            foreach (IWebElement thisOption in dropDownOptions)
            {
                optionCollection += thisOption.Text + "  ";
                if (thisOption.Text == GeneratedData)
                {
                    bFoundOptionInList = true;
                }
            }
            if (bFoundOptionInList)
            {
                Assert.AreEqual(true, false, "Field " + fieldName + " expected to not find [" + GeneratedData + "], in option list [" + optionCollection + "]");
                fw.ConsoleReport("Field " + fieldName + " expected to not find [" + GeneratedData + "], in option list [" + optionCollection + "]");
            }
            else
            {
                Assert.AreEqual(true, true, "Field " + fieldName + " expected to not find [" + GeneratedData + "], in option list [" + optionCollection + "]");
                fw.ConsoleReport("Field " + fieldName + " expected to not find [" + GeneratedData + "], in option list [" + optionCollection + "]");
            }
        }

        [Then(@"Verify Transactions New Trans Disen\.Reason field has value ""(.*)""")]
        public void ThenVerifyTransactionsNewTransDisen_ReasonFieldHasValue(string p0)
        {
            tmsWait.Hard(1);
            string fieldName = "Disen Reason";
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement dropDownElement = new SelectElement(EAM.TransactionsNew.DisenReason);
            IList<IWebElement> dropDownOptions = dropDownElement.Options;
            Boolean bFoundOptionInList = false;
            string optionCollection = "";
            foreach (IWebElement thisOption in dropDownOptions)
            {
                optionCollection += thisOption.Text + "  ";
                if (thisOption.Text == GeneratedData)
                {
                    bFoundOptionInList = true;
                }
            }
            if (bFoundOptionInList)
            {
                Assert.AreEqual(true, true, "Field " + fieldName + " expected to find [" + GeneratedData + "], in option list [" + optionCollection + "]");
                fw.ConsoleReport("Field " + fieldName + " expected to find [" + GeneratedData + "], in option list [" + optionCollection + "]");
            }
            else
            {
                Assert.AreEqual(true, false, "Field " + fieldName + " expected to find [" + GeneratedData + "], in option list [" + optionCollection + "]");
                fw.ConsoleReport("Field " + fieldName + " expected to find [" + GeneratedData + "], in option list [" + optionCollection + "]");
            }
        }

        [Then(@"Verify Transactions New Plan 1 Label is set to ""(.*)""")]
        public void ThenVerifyTransactionsNewPlan1LabelIsSetTo(string p0)
        {
            string fieldName = "Transactions New Plan 1 Label";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.TransactionsNew.Plan1Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Transactions New Plan 2 Label is set to ""(.*)""")]
        public void ThenVerifyTransactionsNewPlan2LabelIsSetTo(string p0)
        {
            string fieldName = "Transactions New Plan 2 Label";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.TransactionsNew.Plan2Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Transactions New Plan 3 Label is set to ""(.*)""")]
        public void ThenVerifyTransactionsNewPlan3LabelIsSetTo(string p0)
        {
            string fieldName = "Transactions New Plan 3 Label";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.TransactionsNew.Plan3Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Transactions New Plan 4 Label is set to ""(.*)""")]
        public void ThenVerifyTransactionsNewPlan4LabelIsSetTo(string p0)
        {
            string fieldName = "Transactions New Plan 4 Label";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.TransactionsNew.Plan4Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Transactions New Plan 5 Label is set to ""(.*)""")]
        public void ThenVerifyTransactionsNewPlan5LabelIsSetTo(string p0)
        {
            string fieldName = "Transactions New Plan 5 Label";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.TransactionsNew.Plan5Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Transactions New Plan 6 Label is set to ""(.*)""")]
        public void ThenVerifyTransactionsNewPlan6LabelIsSetTo(string p0)
        {
            string fieldName = "Transactions New Plan 6 Label";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.TransactionsNew.Plan6Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Transactions New Plan 7 Label is set to ""(.*)""")]
        public void ThenVerifyTransactionsNewPlan7LabelIsSetTo(string p0)
        {
            string fieldName = "Transactions New Plan 7 Label";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.TransactionsNew.Plan7Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Transactions New Plan 8 Label is set to ""(.*)""")]
        public void ThenVerifyTransactionsNewPlan8LabelIsSetTo(string p0)
        {
            string fieldName = "Transactions New Plan 8 Label";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.TransactionsNew.Plan8Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Transactions New Plan 9 Label is set to ""(.*)""")]
        public void ThenVerifyTransactionsNewPlan9LabelIsSetTo(string p0)
        {
            string fieldName = "Transactions New Plan 9 Label";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.TransactionsNew.Plan9Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Transactions New Plan 10 Label is set to ""(.*)""")]
        public void ThenVerifyTransactionsNewPlan10LabelIsSetTo(string p0)
        {
            string fieldName = "Transactions New Plan 10 Label";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.TransactionsNew.Plan10Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [Then(@"Verify Transactions New Trans Status is set to ""(.*)""")]
        [Then(@"Verify Transactions New Trans\.Status is set to ""(.*)""")]
        public void ThenVerifyTransactionsNewTransStatusIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            //string thisFieldValue = EAM.TransactionsNew.TransStatus.GetAttribute("value");
            string thisFieldValue = EAM.TransactionsNew.TransStatus.Text;
            Assert.IsTrue(GeneratedData == thisFieldValue, "Field Trans Status value is [{0}], expected [{1}]", thisFieldValue, GeneratedData);
        }

        [Then(@"Verify Transactions New Reply Descrip is set to ""(.*)""")]
        public void ThenVerifyTransactionsNewReplyDescripIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.TransactionsNew.ReplyDescrip.GetAttribute("value");
            Assert.IsTrue(GeneratedData == thisFieldValue, "Field Reply Descrip value is [{0}], expected [{1}]", thisFieldValue, GeneratedData);
        }

        [Then(@"Verify Transactions New Reply Code is set to ""(.*)""")]
        public void ThenVerifyTransactionsNewReplyCodeIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.TransactionsNew.ReplyCode.GetAttribute("value");
            Assert.IsTrue(GeneratedData == thisFieldValue, "Field Reply Code value is [{0}], expected [{1}]", thisFieldValue, GeneratedData);
        }

        [When(@"Transactions New View TRR Detail button is Clicked")]
        [When(@"Transactions New View TRR Detail button is clicked")]
        public void WhenTransactionsNewViewTRRDetailButtonIsClicked()
        {
            try
            {
                EAM.TransactionsNew.ViewTRRDetailButton.Click();
                tmsWait.Hard(2);
            }
            catch
            {
                tmsWait.Hard(5);
                EAM.TransactionsNew.ViewTRRDetailButton.SendKeys(Keys.Enter);
            }
            //     tmsWait.WaitForReadyStateComplete(120);
            tmsWait.Hard(10);

            //Actions action = new Actions(Browser.Wd);

            ////System.Windows.Forms.KeyEventArgs e;
            //EAM.TransactionsNew.ViewTRRDetailButton.Click();
            //IAlert alert = Browser.Wd.SwitchTo().Alert();


            //alert.SendKeys("tmsservice");
            //tmsWait.Hard(5);
            //action.SendKeys(OpenQA.Selenium.Keys.Tab);



            ////type(Key.ENTER);

            ////alert.SendKeys(OpenQA.Selenium.Keys.Tab);

            //////System.Windows.Forms.SendKeys.SendWait(Keys.Tab);
            ////alert.SendKeys(Keys.Return);


            //alert.SendKeys("TriZetto456");
            ////tmsWait.Hard(5);
            //action.SendKeys(OpenQA.Selenium.Keys.Tab);
            ////alert.SendKeys(Keys.Return);
            ////alert.SendKeys(OpenQA.Selenium.Keys.Tab);
            //////System.Windows.Forms.SendKeys.SendWait(Keys.Tab);
            //alert.Accept();

            ////try 
            ////{
            ////    EAM.TransactionsNew.ViewTRRDetailButton.SendKeys(Keys.Enter);
            ////}
            ////catch (Exception) { }
            ////tmsWait.WaitForReadyStateComplete(60);
            ////tmsWait.Hard(10);            
        }





        [Then(@"Verify Transactions New Disenrollment Reason PopUp does not have row")]
        public void ThenVerifyTransactionsNewDisenrollmentReasonPopUpDoesNotHaveRow(Table table)
        {
            //Establish the next page link for flipping pages as necessary
            Boolean bNotAtLastPageOfRecords = true;
            //            Boolean bHaveGoodPageLink = true;
            //Get the Table Header off of the test script Gherkin table
            ICollection<string> thisTH = table.Header;
            int thCount = thisTH.Count;
            string[] thisHeader = new string[thisTH.Count];
            thisTH.CopyTo(thisHeader, 0);   //copies the header to an array

            //Set up an array of classes to hold the table data, first one (0) will be the header info
            //The class has flags for this data row being a header, data and if we have yet matched it in our trials
            TableRow[] thisTableArr = new TableRow[table.RowCount + 1];
            thisTableArr[0] = new TableRow();
            thisTableArr[0].RowIsHeader = true;
            thisTableArr[0].RowIsData = false;
            thisTableArr[0].RowIsMatched = false;
            //Add the header data to the array 0 table row instance
            foreach (string thisString in thisHeader)
            {
                thisTableArr[0].Row.Add(thisString);
            }
            int iCounter = 1;
            //Add the Gherkin table row data to the array of rows.  These are all data, not headers, not matched yet.
            foreach (var row in table.Rows)
            {
                thisTableArr[iCounter] = new TableRow();
                thisTableArr[iCounter].RowIsHeader = false;
                thisTableArr[iCounter].RowIsData = true;
                thisTableArr[iCounter].RowIsMatched = false;

                for (int c = 0; c < row.Count; c++)
                {
                    thisTableArr[iCounter].Row.Add(row[c]);
                }
                iCounter++;
            }
            //While we have not matched all rows yet
            //and we are not on the last page of records..
            while (thisTableArr[0].AllRowsMatched(thisTableArr) == false && bNotAtLastPageOfRecords)
            {
                bNotAtLastPageOfRecords = false;
                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.TransactionsNew.DisenReasonTable;
                ICollection<IWebElement> myRows = baseTable.FindElements(By.TagName("tr"));
                int RowCount = myRows.Count;
                //Establish an array of table rows for the page data.
                TableRow[] thisDataArr = new TableRow[RowCount];
                int EstablishedRowItemCount = 0;
                int iRowCounter = 0;
                IWebElement lastElementHolder = null;
                foreach (IWebElement thisRow in myRows)
                {
                    //For each new data row we look at, add a new instance of the class to the array.
                    thisDataArr[iRowCounter] = new TableRow();
                    thisDataArr[iRowCounter].RowIsHeader = true;
                    thisDataArr[iRowCounter].RowIsData = false;
                    thisDataArr[iRowCounter].RowIsMatched = false;
                    //Get all of the elements from the row (<td>)
                    ICollection<IWebElement> myElements = null;
                    if (iRowCounter == 0)
                    {
                        myElements = thisRow.FindElements(By.TagName("td"));
                    }
                    else
                    {
                        myElements = thisRow.FindElements(By.TagName("td"));
                    }
                    //Row 0 is the header
                    //The rest of the rows are data
                    int elementCount = 0;
                    foreach (IWebElement thisElement in myElements)
                    {
                        elementCount++;
                        lastElementHolder = thisElement;
                        if (iRowCounter == -1)
                        {
                            //Finding the normal item count because the page numbers are a data row.
                            //Row 0 is the header
                            EstablishedRowItemCount = myElements.Count;
                            thisDataArr[iRowCounter].RowIsHeader = true;
                            thisDataArr[iRowCounter].RowIsData = false;
                        }
                        else
                        {
                            //Other rows are data
                            thisDataArr[iRowCounter].RowIsHeader = false;
                            thisDataArr[iRowCounter].RowIsData = true;
                            thisDataArr[iRowCounter].Row.Add(thisElement.Text.ToString());
                        }
                    }
                    iRowCounter++;
                }
                int iTableCounter = 0;
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TableRow TTA in thisTableArr)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.
                    if (TTA.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] ta = TTA.Row.ToArray();

                        //For each row in the page data
                        foreach (TableRow TDA in thisDataArr)
                        {
                            //Convert page data to array elements
                            string[] td = TDA.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.
                            foreach (string tde in td)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (TDA.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    //                                    Console.WriteLine("["+ iElementCounter +"] Matching page data ["+ ta[iElementCounter] +"] with gherkin ["+ tde +"]");
                                    if (tde != ta[iElementCounter] && ta[iElementCounter].ToLower() != "[skip]" && iElementCounter != 5)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (td.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //Report the match, first convert the array back to a string we can read.
                                thisTableArr[iTableCounter].RowIsMatched = true;
                                string TR0 = TableRow.ArrayToString(td);
                                string TR1 = TableRow.ArrayToString(ta);
                                Console.WriteLine("Expected Row Data --- " + TR1);
                                Console.WriteLine("Found Row Data --- " + TR0);

                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisTableArr[0].AllRowsMatched(thisTableArr);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                baseTable = EAM.TransactionsNew.DisenReasonTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (!fullMatching)
                {
                    int iCount = 0;
                    var TableRow = new TMSString();
                    foreach (TableRow thisTR in thisTableArr)
                    {
                        if (thisTR.RowIsMatched == false && thisTR.RowIsHeader == false)
                        {
                            string thisRowData = TableRow.ArrayToString(thisTR.Row.ToArray());
                            Console.WriteLine("Unmatched Data Row -- " + thisRowData);
                        }
                        iCount++;
                    }
                    Assert.AreEqual(true, true, "As expected, rows in the Gherkin test table were not found in the page table data rows.");
                    Console.WriteLine("As expected, rows in the Gherkin test table were not found in the page table data rows.");
                }
            }
        }



        [Then(@"Verify Transactions New Disenrollment Reason PopUp has row")]
        public void ThenVerifyTransactionsNewDisenrollmentReasonPopUpHasRow(Table table)
        {
            //Establish the next page link for flipping pages as necessary
            Boolean bNotAtLastPageOfRecords = true;
            Boolean bHaveGoodPageLink = true;
            //Get the Table Header off of the test script Gherkin table
            ICollection<string> thisTH = table.Header;
            int thCount = thisTH.Count;
            string[] thisHeader = new string[thisTH.Count];
            thisTH.CopyTo(thisHeader, 0);   //copies the header to an array

            //Set up an array of classes to hold the table data, first one (0) will be the header info
            //The class has flags for this data row being a header, data and if we have yet matched it in our trials
            TableRow[] thisTableArr = new TableRow[table.RowCount + 1];
            thisTableArr[0] = new TableRow();
            thisTableArr[0].RowIsHeader = true;
            thisTableArr[0].RowIsData = false;
            thisTableArr[0].RowIsMatched = false;
            //Add the header data to the array 0 table row instance
            foreach (string thisString in thisHeader)
            {
                thisTableArr[0].Row.Add(thisString);
            }
            int iCounter = 1;
            //Add the Gherkin table row data to the array of rows.  These are all data, not headers, not matched yet.
            foreach (var row in table.Rows)
            {
                thisTableArr[iCounter] = new TableRow();
                thisTableArr[iCounter].RowIsHeader = false;
                thisTableArr[iCounter].RowIsData = true;
                thisTableArr[iCounter].RowIsMatched = false;

                for (int c = 0; c < row.Count; c++)
                {
                    thisTableArr[iCounter].Row.Add(row[c]);
                }
                iCounter++;
            }
            //While we have not matched all rows yet
            //and we are not on the last page of records..
            while (thisTableArr[0].AllRowsMatched(thisTableArr) == false && bNotAtLastPageOfRecords)
            {
                bNotAtLastPageOfRecords = false;
                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.TransactionsNew.DisenReasonTable;
                ICollection<IWebElement> myRows = baseTable.FindElements(By.TagName("tr"));
                int RowCount = myRows.Count;
                //Establish an array of table rows for the page data.
                TableRow[] thisDataArr = new TableRow[RowCount];
                int EstablishedRowItemCount = 0;
                int iRowCounter = 0;
                IWebElement lastElementHolder = null;
                foreach (IWebElement thisRow in myRows)
                {
                    //For each new data row we look at, add a new instance of the class to the array.
                    thisDataArr[iRowCounter] = new TableRow();
                    thisDataArr[iRowCounter].RowIsHeader = true;
                    thisDataArr[iRowCounter].RowIsData = false;
                    thisDataArr[iRowCounter].RowIsMatched = false;
                    //Get all of the elements from the row (<td>)
                    ICollection<IWebElement> myElements = null;
                    if (iRowCounter == 0)
                    {
                        myElements = thisRow.FindElements(By.TagName("td"));
                    }
                    else
                    {
                        myElements = thisRow.FindElements(By.TagName("td"));
                    }
                    //Row 0 is the header
                    //The rest of the rows are data
                    int elementCount = 0;
                    foreach (IWebElement thisElement in myElements)
                    {
                        elementCount++;
                        lastElementHolder = thisElement;
                        if (iRowCounter == -1)
                        {
                            //Finding the normal item count because the page numbers are a data row.
                            //Row 0 is the header
                            EstablishedRowItemCount = myElements.Count;
                            thisDataArr[iRowCounter].RowIsHeader = true;
                            thisDataArr[iRowCounter].RowIsData = false;
                        }
                        else
                        {
                            //Other rows are data
                            thisDataArr[iRowCounter].RowIsHeader = false;
                            thisDataArr[iRowCounter].RowIsData = true;
                            thisDataArr[iRowCounter].Row.Add(thisElement.Text.ToString());
                        }
                    }
                    iRowCounter++;
                }
                int iTableCounter = 0;
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TableRow TTA in thisTableArr)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.
                    if (TTA.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] ta = TTA.Row.ToArray();

                        //For each row in the page data
                        foreach (TableRow TDA in thisDataArr)
                        {
                            //Convert page data to array elements
                            string[] td = TDA.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.
                            foreach (string tde in td)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (TDA.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    //                                    Console.WriteLine("["+ iElementCounter +"] Matching page data ["+ ta[iElementCounter] +"] with gherkin ["+ tde +"]");
                                    if (tde != ta[iElementCounter] && ta[iElementCounter].ToLower() != "[skip]" && iElementCounter != 5)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (td.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //Report the match, first convert the array back to a string we can read.
                                thisTableArr[iTableCounter].RowIsMatched = true;
                                string TR0 = TableRow.ArrayToString(td);
                                string TR1 = TableRow.ArrayToString(ta);
                                Console.WriteLine("Expected Row Data --- " + TR1);
                                Console.WriteLine("Found Row Data --- " + TR0);

                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisTableArr[0].AllRowsMatched(thisTableArr);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                baseTable = EAM.TransactionsNew.DisenReasonTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (bHaveGoodPageLink == false && !fullMatching)
                {
                    int iCount = 0;
                    var TableRow = new TMSString();
                    foreach (TableRow thisTR in thisTableArr)
                    {
                        if (thisTR.RowIsMatched == false && thisTR.RowIsHeader == false)
                        {
                            string thisRowData = TableRow.ArrayToString(thisTR.Row.ToArray());
                            Console.WriteLine("Unmatched Data Row -- " + thisRowData);
                        }
                        iCount++;
                    }
                    Assert.AreEqual(true, false, "Not all expected rows in the Gherkin test table were found in the page table data rows.");
                }
            }
        }



        //***********************************************
        //      Address Section for TC 61 or 76
        //***********************************************        
        [When(@"Transactions New (.*) Zip is set to ""(.*)""")]
        public void WhenTransactionsNewZipIsSetTo(int p0, string p1)
        {
            tmsWait.Hard(5);
            string strValue = tmsCommon.GenerateData(p1);

            switch (p0)
            {
                case 61:
                    {
                        if (ConfigFile.tenantType.Equals("tmsx"))
                        {
                            //By Drp = By.XPath("(//label[contains(.,'Zip')]/parent::div//input)[1]");

                            //Browser.Wd.FindElement(Drp).SendKeys(strValue);
                            //Browser.Wd.FindElement(Drp).SendKeys(Keys.Tab);
                            //tmsWait.Hard(3);

                            AngularFunction.sendKeysWithClear(cfAngularTransaction.AngularNewTransaction.ZipCode, strValue);
                            cfAngularTransaction.AngularNewTransaction.ZipCode.SendKeys(Keys.Tab);
                        }
                        else
                        {
                            By loc = By.CssSelector("[test-id='Transactioncode61ResidentialAddressupdateZip']");
                            fw.ScrollWindowToViewElementUsingLocators(loc);
                            UIMODUtilFunctions.enterValueOnWebElementUsingLocators(loc, strValue);
                        }
                        break;
                    }
                case 76:
                    {
                        if (ConfigFile.tenantType.Equals("tmsx"))
                        {
                            By Drp = By.XPath("(//label[contains(.,'Zip')]/parent::div//input)[1]");
                            fw.ScrollWindowToViewElementUsingLocators(Drp);
                            Browser.Wd.FindElement(Drp).SendKeys(strValue);
                            Browser.Wd.FindElement(Drp).SendKeys(Keys.Tab);
                            tmsWait.Hard(3);


                        }
                        else
                        {
                            By loc = By.CssSelector("[test-id='Transactioncode76ResidentialAddressupdateZip']");
                            fw.ScrollWindowToViewElementUsingLocators(loc);
                            UIMODUtilFunctions.enterValueOnWebElementUsingLocators(loc, strValue);

                        }
                    }
                    break;
            }
            tmsWait.Hard(5);
                     
        }

        [When(@"Transactions New City is set to ""(.*)""")]
        public void WhenTransactionsNewCityIsSetTo(string p0)
        {
            string city = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                
                By Drp = By.XPath("(//label[contains(.,'City')]/parent::div//input)[1]");
                Browser.Wd.FindElement(Drp).Clear();
                Browser.Wd.FindElement(Drp).SendKeys(city);

                tmsWait.Hard(3);


            }
            else
            {
                tmsWait.Hard(2);
                IWebElement City = Browser.Wd.FindElement(By.Id("Transactioncode61ResidentialAddressupdateCity"));
                City.Clear();
                City.SendKeys(city);
            }
        }
        [When(@"Transactions New (.*) Residence Address is set to ""(.*)""")]
        public void WhenTransactionsNewResidenceAddressIsSetTo(int p0, string p1)
        {
            IWebElement address = Browser.Wd.FindElement(By.XPath("//input[@test-id='Transactioncode76ResidentialAddressupdateStreetAddress']"));
            address.Clear();
            address.SendKeys(p1);
            GlobalRef.MODADD1= p1;
        }

        [Then(@"Verify Transactions page User Entered details Last Name displayed as ""(.*)""")]
        public void ThenVerifyTransactionsPageUserEnteredDetailsLastNameDisplayedAs(string p0)
        {
            string name = tmsCommon.GenerateData(p0).ToLower();
            tmsWait.Hard(3);
            IWebElement user = Browser.Wd.FindElement(By.CssSelector("[test-id='transaction-span-userEntered']"));
            bool presence = user.Text.ToLower().Contains(name);
            Assert.IsTrue(presence);

        }

        [Then(@"Verify Transactions page User Entered details Last Name as ""(.*)""")]
        public void ThenVerifyTransactionsPageUserEnteredDetailsLastNameAs(string p0)
        {
            string name = tmsCommon.GenerateData(p0).ToLower();
            tmsWait.Hard(3);
            IWebElement user = Browser.Wd.FindElement(By.CssSelector("[test-id='transaction-span-userEntered']"));
            bool presence = user.Text.ToLower().Contains(name);
            Assert.IsTrue(presence);
        }

        [Then(@"Verify Transactions page User Entered details as ""(.*)"" and ""(.*)""")]
        public void ThenVerifyTransactionsPageUserEnteredDetailsAsAnd(string p0, string p1)
        {

            string name = tmsCommon.GenerateData(p0);
            tmsWait.Hard(3);
            IWebElement user = Browser.Wd.FindElement(By.CssSelector("[test-id='transaction-span-userEntered']"));
            bool presence = user.Text.Contains(name);
            Assert.IsTrue(presence);
        }

        [When(@"Transactions New (.*) Street Address is set to ""(.*)""")]
        public void WhenTransactionsNewStreetAddressIsSetTo(int p0, string p1)
        {
            string strValue = tmsCommon.GenerateData(p1.ToString());


            IWebElement thisField = null;

                switch (p0)
                {
                    case 76:
                        {
                            if (ConfigFile.tenantType.Equals("tmsx") && p0.ToString().Equals("76"))
                            {
                                By Drp = By.XPath("//label[contains(.,'Residence Address 1')]/parent::div//input");

                            Browser.Wd.FindElement(Drp).SendKeys(strValue);

                            tmsWait.Hard(3);


                        }
                        else
                        {
                            thisField = EAM.TransactionsNew76.StreetAddress;

                        }
                        break;

                        }
                    case 61: {
                            if (ConfigFile.tenantType.Equals("tmsx") && p0.ToString().Equals("61"))
                            {
                                By Drp = By.XPath("//label[contains(.,'Residence Address 1')]/parent::div//input");

                            Browser.Wd.FindElement(Drp).SendKeys(strValue);

                            tmsWait.Hard(3);


                        }
                        else
                        {
                            thisField = EAM.TransactionsNew.StreetAddress;
                        }
                        break;
                    }
                default:
                    {

                        Assert.Fail("Transactions New ({0}) Street Address is set to {1}: Street Address field does not exist for given trans code.", p0, p1);
                        break;
                    }
            }

            if (ConfigFile.tenantType.Equals("tmsx") && (p0.ToString().Equals("61") || p0.ToString().Equals("76")))
            {

            }
            else
            {
                thisField.Click();
                thisField.Clear();
                thisField.SendKeys(strValue);

                tmsWait.Hard(1);
                tmsWait.WaitForReadyStateComplete(20);
            }

        }

        [When(@"Transactions New (.*) County is set to ""(.*)""")]
        public void WhenTransactionsNewCountyIsSetTo(int p0, string p1)
        {
            tmsWait.Hard(5);
            string strValue = tmsCommon.GenerateData(p1);
            IWebElement thisField = null;

            switch (p0)
            {
                case 61: { thisField = EAM.TransactionsNew61.County; break; }
                default: { Assert.Fail("Transactions New ({0}) County is set to {1}: County field does not exist for given trans code.", p0, p1); break; }
            }
            SelectElement thisSelectField = new SelectElement(thisField);
            thisSelectField.SelectByText(strValue);
            tmsWait.Hard(2);

            EAM.TransactionsNew61.Zip.Click();
            tmsWait.Hard(3);
            //   tmsWait.WaitForReadyStateComplete(30);            
        }


        //*************************************
        //  Transaction 76 specific
        //*************************************

        [When(@"Transactions New 76 Action is set to ""(.*)""")]
        public void WhenTransactionsNewActionIsSetTo(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Action')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + strValue + "']");


                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);


            }
            else
            {
                By plan = By.XPath("//div[@id='div_Transactioncode76ResidentialAddressupdateAction']/span");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(plan);
                tmsWait.Hard(1);
                UIMODUtilFunctions.selectTransDrpValue(strValue);
            }


        }
        [Then(@"Transaction File Export page Earliest Effective Date is set to ""(.*)""")]
        public void ThenTransactionFileExportPageEarliestEffectiveDateIsSetTo(string p0)
        {
            IWebElement field = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtEffDate1"));
            String strValue = tmsCommon.GenerateData(p0);
            strValue = strValue.Replace("/", "");
            tmsWait.Hard(2);
            field.Click();
            field.Clear();
            tmsWait.Hard(1);
            field.Clear();
            field.SendKeys(strValue);
        }

        [Then(@"Transaction File Export page Latest Effective Date is set to ""(.*)""")]
        public void ThenTransactionFileExportPageLatestEffectiveDateIsSetTo(string p0)
        {
            IWebElement field = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtEffDate2"));
            String strValue = tmsCommon.GenerateData(p0);
            strValue = strValue.Replace("/", "");
            tmsWait.Hard(2);
            field.Click();
            field.Clear();
            tmsWait.Hard(1);
            field.Clear();
            field.SendKeys(strValue);
        }

        [Then(@"Transaction File Export page Plan ID is set to ""(.*)""")]
        public void ThenTransactionFileExportPagePlanIDIsSetTo(string p0)
        {
            IWebElement field = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPlan"));
            new SelectElement(field).SelectByText(p0);
        }

        [Then(@"Transaction File Export page Transaction Code is set to ""(.*)""")]
        public void ThenTransactionFileExportPageTransactionCodeIsSetTo(string p0)
        {
            IWebElement field = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboTransCode"));
            new SelectElement(field).SelectByText(p0);
        }

        [Then(@"Transaction File Export page Export button is Clicked")]
        public void ThenTransactionFileExportPageExportButtonIsClicked()
        {
            IWebElement field = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnTransFile"));
            fw.ExecuteJavascript(field);
        }


        [When(@"Transactions New 76 Address Effective Date is set to ""(.*)""")]
        public void WhenTransactionsNew76AddressEffectiveDateIsSetTo(string p0)
        {
            String strValue = tmsCommon.GenerateData(p0);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                //string value = strValue.Replace("/", "");//kendo-datepicker[@test-id='Transactioncode76ResidentialAddressupdateAddressEffectiveDate']//input
                By Drp = By.XPath("//kendo-datepicker[@test-id='Transactioncode76ResidentialAddressupdateAddressEffectiveDate']//span[@role='button']");
               
                AngularFunction.enterDate(Drp, strValue);

                tmsWait.Hard(3);



            }
            else
            {

                strValue = strValue.Replace("/", "");
                tmsWait.Hard(2);



                EAM.TransactionsNew76.AddressEffectiveDate.Click();
                EAM.TransactionsNew76.AddressEffectiveDate.Clear();
                tmsWait.Hard(1);
                EAM.TransactionsNew76.AddressEffectiveDate.Clear();
                EAM.TransactionsNew76.AddressEffectiveDate.SendKeys(strValue);
            }
        }

        [When(@"Transactions New 76 Zipfour is set to ""(.*)""")]
        public void WhenTransactionsNew76ZipfourIsSetTo(string p0)
        {
            String strValue = tmsCommon.GenerateData(p0.ToString());
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'ZipFour')]/parent::div//input");

                Browser.Wd.FindElement(Drp).SendKeys(strValue);

                tmsWait.Hard(3);


            }
            else
            {
                EAM.TransactionsNew76.Zipfour.Clear();
                EAM.TransactionsNew76.Zipfour.SendKeys(strValue);
                tmsWait.Hard(1);
            }
        }

        [When(@"Transactions New Seg ID is set to ""(.*)""")]
        public void WhenTransactionsNewSegIDIsSetTo(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0.ToString());
            try
            {

                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    By Drp = By.XPath("//label[contains(.,'Segment ID')]/parent::div//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + strValue + "']");


                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);



                }
                else
                {


                    By segID = By.XPath("//*[@id='div_DemographicDetailsSegID']//span[1]");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(segID);
                    tmsWait.Hard(2);
                    UIMODUtilFunctions.selectTransDrpValue(strValue);

                    tmsWait.Hard(6);
                }
            }

            catch
            {
                fw.ConsoleReport(" Segment ID is not found");
            }
        }

        [Then(@"Verify Transactions New Seg ID field has value ""(.*)""")]
        public void ThenVerifyTransactionsNewSegIdFieldHasValue(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0);
            Boolean foundValueInList = false;
            IList<IWebElement> theseOptions = EAM.TransactionsNew.SegID.FindElements(By.TagName("option"));
            string OptionsList = "";
            foreach (IWebElement thisOption in theseOptions)
            {
                OptionsList += thisOption.Text + " ";
                if (thisOption.Text == strValue)
                {
                    foundValueInList = true;
                }
            }
            Assert.AreEqual(true, foundValueInList, "We expect to find [" + strValue + "] in option list [" + OptionsList + "]");
            fw.ConsoleReport("We expect to find [" + strValue + "] in option list [" + OptionsList + "]");
        }

        [Then(@"Verify Transactions New 61 Denial Reason field has value ""(.*)""")]
        public void ThenVerifyTransactionsNew61DenialReasonFieldHasValue(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0);
            Boolean foundValueInList = false;
            IList<IWebElement> theseOptions = EAM.TransactionsNew.DenialReasonDropDown.FindElements(By.TagName("option"));
            string OptionsList = "";
            foreach (IWebElement thisOption in theseOptions)
            {
                OptionsList += thisOption.Text + " ";
                if (thisOption.Text == strValue)
                {
                    foundValueInList = true;
                }
            }
            Assert.AreEqual(true, foundValueInList, "We expect to find [" + strValue + "] in option list [" + OptionsList + "]");
            fw.ConsoleReport("We expect to find [" + strValue + "] in option list [" + OptionsList + "]");
        }

        [When(@"Transactions New SEPS Reason is set to ""(.*)""")]
        [Then(@"Transactions New SEPS Reason is set to ""(.*)""")]
        public void WhenTransactionsNewSEPSReasonIsSetTo(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0.ToString());
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'SEPS Reason')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + strValue + "']");


                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

            }
            else
            {
                By SEPSReason = By.XPath("//div[@id='div_DemographicDetailsSEPSReason']/span");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(SEPSReason);
                tmsWait.Hard(2);
                UIMODUtilFunctions.selectTransDrpValue(strValue);
            }
            tmsWait.Hard(3);
        }

        [Then(@"Verify Transactions New SEPS Reason field has value ""(.*)""")]
        public void ThenVerifyTransactionsNewSEPSReasonFieldHasValue(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0);
            Boolean foundValueInList = false;
            IList<IWebElement> theseOptions = EAM.TransactionsNew.SEPSReason.FindElements(By.TagName("option"));
            string OptionsList = "";
            foreach (IWebElement thisOption in theseOptions)
            {
                OptionsList += thisOption.Text + " ";
                if (thisOption.Text == strValue)
                {
                    foundValueInList = true;
                }
            }
            Assert.AreEqual(true, foundValueInList, "We expect to find [" + strValue + "] in option list [" + OptionsList + "]");
            fw.ConsoleReport("We expect to find [" + strValue + "] in option list [" + OptionsList + "]");
        }

        [Then(@"Verify Transactions New Missing Item field has value ""(.*)""")]
        public void ThenVerifyTransactionsNewMissingItemFieldHasValue(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0);
            Boolean foundValueInList = false;
            IList<IWebElement> theseOptions = EAM.TransactionsNew.MissingItem.FindElements(By.TagName("option"));
            string OptionsList = "";
            foreach (IWebElement thisOption in theseOptions)
            {
                OptionsList += thisOption.Text + " ";
                if (thisOption.Text == strValue)
                {
                    foundValueInList = true;
                }
            }
            Assert.AreEqual(true, foundValueInList, "We expect to find [" + strValue + "] in option list [" + OptionsList + "]");
            fw.ConsoleReport("We expect to find [" + strValue + "] in option list [" + OptionsList + "]");
        }

        [When(@"Verify Transactions New Primary Rx ID is set to ""(.*)""")]
        [Then(@"Verify Transactions New Primary Rx ID is set to ""(.*)""")]
        public void WhenVerifyTransactionsPrimaryRxIDIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            string strValue = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {

                By Drp = By.XPath("//label[contains(.,'Primary Rx ID')]/parent::div//input");
                string actualValue = Browser.Wd.FindElement(Drp).GetAttribute("value");
                Assert.AreEqual(strValue, actualValue, "Field Primary Rx ID value is [{0}], expected [{1}]", actualValue, strValue);
            }
            else
            {
                string thisFieldValue = EAM.TransactionsNew.PrimaryRxID.GetAttribute("value");
                Assert.AreEqual(strValue, thisFieldValue, "Field Primary Rx ID value is [{0}], expected [{1}]", thisFieldValue, strValue);
                fw.ConsoleReport(string.Format("   Verification Point: Field Primary Rx ID value is [{0}], expected [{1}] - They are expected to match.", thisFieldValue, strValue));
            }
        }


        [When(@"Transactions New RxGroup is set to ""(.*)""")]
        public void WhenTransactionsNewRxGroupIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                try
                {
                    By Drp = By.XPath("//label[contains(.,'Primary Rx Group')]/parent::div//input");

                    Browser.Wd.FindElement(Drp).Clear();
                    tmsWait.Hard(1);
                    Browser.Wd.FindElement(Drp).SendKeys(GeneratedData);
                    tmsWait.Hard(3);
                }
                catch
                {

                }


            }
            else
            {
                EAM.TransactionsNew.PrimaryRxGroup.Clear();
                EAM.TransactionsNew.PrimaryRxGroup.SendKeys(GeneratedData);
                tmsWait.Hard(1);
            }
        }

        [When(@"Transactions New RxPCN is set to ""(.*)""")]
        public void WhenTransactionsNewRxPCNIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                try
                {
                    By Drp = By.XPath("//label[contains(.,'Primary Rx PCN')]/parent::div//input");

                    Browser.Wd.FindElement(Drp).SendKeys(GeneratedData);
                    tmsWait.Hard(3);
                }
                catch
                {

                }


            }
            else
            {
                EAM.TransactionsNew.PrimaryRxPCN.Clear();
                EAM.TransactionsNew.PrimaryRxPCN.SendKeys(GeneratedData);
                tmsWait.Hard(1);
            }
        }

        [When(@"Transactions New RxBIN is set to ""(.*)""")]
        [Given(@"Transactions New RxBIN is set to ""(.*)""")]
        public void WhenTransactionsNewRxBINIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                try
                {
                    By Drp = By.XPath("//label[contains(.,'Primary Rx BIN')]/parent::div//input");
                    Browser.Wd.FindElement(Drp).Clear();
                    Browser.Wd.FindElement(Drp).SendKeys(GeneratedData);
                }
                catch
                {

                }
            }
            else
            {
                EAM.TransactionsNew.PrimaryRxBIN.Clear();
                EAM.TransactionsNew.PrimaryRxBIN.SendKeys(GeneratedData);
                tmsWait.Hard(1);
            }
        }

        [When(@"Transactions New Secondary Insurance Flag is set to ""(.*)""")]
        public void WhenTransactionsNewSecondaryInsuranceFlagIsSetTo(string p0)
        {
            string strValue = tmsCommon.GenerateData(p0.ToString());
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Secondary Rx Insur. Flag')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + strValue + "']");


                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);



            }
            else
            {

                SelectElement InsurFlag = new SelectElement(EAM.TransactionsNew.SecInsurFlag);
                InsurFlag.SelectByText(strValue);
                tmsWait.Hard(1);
            }
        }


        [When(@"Verify Transactions New Effective Date is set to ""(.*)""")]
        [Then(@"Verify Transactions New Effective Date is set to ""(.*)""")]
        public void ThenVerifyTransactionsNewEffectiveDateIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.TransactionsNew.EffectiveDate.GetAttribute("value");
            Assert.IsTrue(GeneratedData == thisFieldValue, "Field Effective Date value is [{0}], expected [{1}]", thisFieldValue, GeneratedData);
        }

        [When(@"I have pressed the TAB key")]
        public void WhenIHavePressedTheTABKey()
        {
            //IWebElement currentElement = Browser.Wd.SwitchTo().ActiveElement();
            //currentElement.SendKeys(Keys.Tab);
        }

        [Then(@"Verify Transactions New page PrimaryRxID value is autopopulated")]
        public void ThenVerifyTransactionsNewPagePrimaryRxIDValueIsAutopopulated()
        {
            tmsWait.Hard(3);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(3);

                By Drp = By.XPath("//label[contains(.,'Primary Rx ID')]/parent::div//input");
                string actualValue = Browser.Wd.FindElement(Drp).GetAttribute("value");
                Assert.IsNotNull(actualValue, "Primary RxId is displaying Null values");
            }
            else
            {
                string autoPrxid = EAM.TransactionsNew.PrimaryRxID.GetAttribute("value");
                Assert.IsNotNull(autoPrxid, "Primary RxId is displaying Null values");
            }
        }

        [Then(@"Verify Transaction New page primaryrxid value is displays as ""(.*)""")]
        public void ThenVerifyTransactionNewPagePrimaryrxidValueIsDisplaysAs(string autoprxid)
        {
            tmsWait.Hard(2);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(3);

                By Drp = By.XPath("//label[contains(.,'Primary Rx ID')]/parent::div//input");
                string actualValue = Browser.Wd.FindElement(Drp).GetAttribute("value");
                Assert.AreEqual(autoprxid, actualValue, " Both values are not matching");
            }
            else
            {

                string prxid = EAM.TransactionsNew.PrimaryRxID.GetAttribute("value");
                Assert.AreEqual(prxid, autoprxid, "Primary Rx Id is not getting displayed as Auto#");
            }
        }


        [Then(@"Verify enable fields for disenrollment transactions")]
        public void ThenVerifyEnableFieldsForDisenrollmentTransactions()
        {
            Boolean flagcheck = false;
            if (EAM.TransactionsNew.EffectiveDate.Enabled)
            {
                if (EAM.TransactionsNew.ElectionType.Enabled)
                {
                    if (EAM.TransactionsNew.DisenrlreasonCode.Enabled)
                    {
                        if (EAM.TransactionsNew.DisenReason.Enabled)
                        {
                            if (EAM.TransactionsNew.ReceiptDate.Displayed)
                            {
                                flagcheck = true;
                            }
                        }
                    }
                }
            }
            Assert.IsTrue(flagcheck, "Some fields are not enabled please check");
        }

        [Then(@"Verify enable fields for disenrollment cancellation transactions")]
        public void ThenVerifyEnableFieldsForDisenrollmentCancellationTransactions()
        {
            Boolean flagcheck = false;
            if (EAM.TransactionsNew.EffectiveDate.Enabled)
            {
                if (EAM.TransactionsNew.EGHP.Enabled)
                {
                    if (EAM.TransactionsNew.ProblemCaseType.Enabled)
                    {
                        if (EAM.TransactionsNew.PBP.Enabled)
                        {

                            flagcheck = true;

                        }
                    }
                }
            }
            Assert.IsTrue(flagcheck, "Some fields are not enabled please check");
        }

        [Then(@"Verify enable fields for misc transactions")]
        public void ThenVerifyEnableFieldsForMiscTransactions()
        {
            Boolean flagcheck = false;
            if (EAM.TransactionsNew.EffectiveDate.Enabled)
            {
                if (EAM.TransactionsNew.EGHP.Enabled)
                {
                    if (EAM.TransactionsNew.ProblemCaseType.Enabled)
                    {
                        if (EAM.TransactionsNew.PBP.Enabled)
                        {

                            flagcheck = true;

                        }
                    }
                }
            }
            Assert.IsTrue(flagcheck, "Some fields are not enabled please check");
        }

        [Then(@"Verify enable fields for ""(.*)"" transaction")]
        public void ThenVerifyEnableFieldsForTransaction(int p0)
        {
            string tcode = p0.ToString();
            Boolean flagcheck = false;
            switch (tcode)
            {

                case "51":

                    if (EAM.TransactionsNew.EffectiveDate.Enabled)
                    {
                        if (EAM.TransactionsNew.ElectionType.Enabled)
                        {
                            if (EAM.TransactionsNew.DisenrlreasonCode.Enabled)
                            {
                                if (EAM.TransactionsNew.DisenReason.Enabled)
                                {
                                    if (EAM.TransactionsNew.ReceiptDate.Displayed)
                                    {
                                        flagcheck = true;
                                    }
                                }
                            }
                        }
                    }
                    break;

                case "81":

                    if (EAM.TransactionsNew.EffectiveDate.Enabled)
                    {
                        if (EAM.TransactionsNew.EGHP.Enabled)
                        {
                            if (EAM.TransactionsNew.ProblemCaseType.Enabled)
                            {
                                if (EAM.TransactionsNew.PBP.Enabled)
                                {

                                    flagcheck = true;
                                }
                            }
                        }
                    }
                    break;

                case "74":
                case "80":
                    if (EAM.TransactionsNew.EffectiveDate.Enabled)
                    {
                        if (EAM.TransactionsNew.EGHP.Enabled)
                        {
                            if (EAM.TransactionsNew.ProblemCaseType.Enabled)
                            {
                                if (EAM.TransactionsNew.PBP.Enabled)
                                {
                                    flagcheck = true;
                                }
                            }
                        }
                    }
                    break;
            }
            Assert.IsTrue(flagcheck, "Some fields are not enabled please check");
        }


        //[Then(@"Verify User Entred displays Login user name")]
        //public void ThenVerifyUserEntredDisplaysLoginUserName()
        //{
        //   string uid =
        //}

        [Then(@"Verify Date entered displays todays date")]
        public void ThenVerifyDateEnteredDisplaysTodaysDate()
        {
            string tdate = DateTime.Today.ToString("MM/dd/yyyy");
            //string tdatetostring = Convert.ToString(tdate);
            //string[] tsplit = tdatetostring.Split(' ');
            //string edate = EAM.TransactionsNew.DateEntered.Text;
            string edate = EAM.TransactionsNew.DateEntered.Text;
            //string[] esplit = edate.Split(' ');
            //Assert.AreEqual(tdate, edate, "Date entered does not displays todays date");
            Assert.IsTrue(edate.Contains(tdate), "Date entered does not displays todays date");
        }

        [Then(@"Verify trasnsaction status displays ""(.*)""")]
        public void ThenVerifyTrasnsactionStatusDisplays(string tstatus)
        {
            tmsWait.Hard(8);
            string transstatus = EAM.TransactionsNew.TransStatus.Text;
            Assert.AreEqual(tstatus, transstatus, "Transaction status " + tstatus + "is not equal to " + transstatus + "");
            //string transstatus = EAM.TransactionsNew.TransStatus.GetAttribute("value");
            //Assert.AreEqual(tstatus,transstatus, "Transaction status is not equal to 2");
        }

        [Then(@"Verify Transaction new page static message ""(.*)""")]
        public void ThenVerifyTransactionNewPageStaticMessage(string expectedmsg)
        {
            tmsWait.Hard(3);
            string actualmsg = EAM.TransactionsNew.PageMessage.Text;
            Assert.AreEqual(expectedmsg, actualmsg, "Static message is not as expected");
        }
        [Then(@"Verify Transaction new page message ""(.*)""")]
        public void ThenVerifyTransactionNewPageMessage(string p0)
        {



            IWebElement b = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]"));

            Assert.IsTrue(b.Displayed, "Expected Message is not getting displayed");
            tmsWait.Hard(5);
        }

        [When(@"Verify Transaction new page summary message ""(.*)""")]
        [Then(@"Verify Transaction new page summary message ""(.*)""")]
        public void ThenVerifyTransactionNewPageSummaryMessage(string p0)
        {
            IWebElement b = Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + p0 + "')]"));

            Assert.IsTrue(b.Displayed, "Expected Message is not getting displayed");
            tmsWait.Hard(5);
        }

        [Then(@"Verify Transaction new page does not show summary message ""(.*)""")]
        public void ThenVerifyTransactionNewPageDoesNotShowSummaryMessage(string p0)
        {
            tmsWait.Hard(5);
            string actualmsg = Browser.Wd.FindElement(By.XPath("//label[@test-id='memberErrors-lbl-errorCount']")).Text;
            bool correctmsg = actualmsg.Contains(p0);
            Assert.IsFalse(correctmsg, "Expected Message is not getting displayed");
            tmsWait.Hard(5);
        }

       

        [Then(@"Verify Transaction new page message shows ""(.*)""")]
        public void ThenVerifyTransactionNewPageMessageShows(string p0)
        {
            string actualmsg = Browser.Wd.FindElement(By.XPath("//label[@test-id='memberErrors-lbl-errorCount']")).Text;
            bool correctmsg = actualmsg.Contains(p0);
            Assert.IsTrue(correctmsg, "Expected Message is not getting displayed");
            tmsWait.Hard(5);
        }
        [Then(@"Verify Transaction new page message shows(.*) ""(.*)""")]
        public void ThenVerifyTransactionNewPageMessageShows(int p0, string p1)
        {
            string actualmsg = null;
            bool element = true;

            try
            {

                element = Browser.Wd.FindElement(By.XPath("(//label[@test-id='memberErrors-lbl-errorCount'])[1]")).Displayed;
                if (actualmsg.Contains(p1))
                {
                    Assert.IsTrue(actualmsg.Contains(p1), "Expected Message is not getting displayed");
                    tmsWait.Hard(5);
                }


            }
            catch
            {

            }

            try
            {
                element = Browser.Wd.FindElement(By.XPath("(//label[@test-id='memberErrors-lbl-errorCount'])[2]")).Displayed;
                if (actualmsg.Contains(p1))
                {
                    Assert.IsTrue(actualmsg.Contains(p1), "Expected Message is not getting displayed");
                    tmsWait.Hard(5);
                }
            }

            catch
            {

            }

            try
            {

                element = Browser.Wd.FindElement(By.XPath("(//label[@test-id='memberErrors-lbl-errorCount'])[3]")).Displayed;
                if (actualmsg.Contains(p1))
                {
                    Assert.IsTrue(actualmsg.Contains(p1), "Expected Message is not getting displayed");
                    tmsWait.Hard(5);
                }


            }

            catch
            {

            }





            //try {
            //actualmsg = Browser.Wd.FindElement(By.XPath("(//label[@test-id='memberErrors-lbl-errorCount'])[3]")).Text;

            //}
            //catch {
            //    actualmsg = Browser.Wd.FindElement(By.XPath("(//label[@test-id='memberErrors-lbl-errorCount'])[2]")).Text;
            //}
            //bool correctmsg = actualmsg.Contains(p1);
            //Assert.IsTrue(correctmsg, "Expected Message is not getting displayed");
            tmsWait.Hard(2);
        }

        [When(@"Verify Transaction new page does not show message ""(.*)""")]
        [Then(@"Verify Transaction new page does not show message ""(.*)""")]
        public void ThenVerifyTransactionNewPageDoesNotShowMessage(string p0)
        {
            string actualmsg = null;
            try
            {
                actualmsg = Browser.Wd.FindElement(By.XPath("(//label[@test-id='memberErrors-lbl-errorCount'])[3]")).Text;
            }
            catch
            {
                actualmsg = Browser.Wd.FindElement(By.XPath("(//label[@test-id='memberErrors-lbl-errorCount'])[1]")).Text;
            }

            bool correctmsg = actualmsg.Contains(p0);
            Assert.IsFalse(correctmsg, "Expected Message is not getting displayed");
            tmsWait.Hard(5);
        }


        [Then(@"Verify Members page static message contains ""(.*)""")]
        [Then(@"Verify View Edit Member page display ""(.*)""")]
        [Then(@"Verify Transaction new page static message contains ""(.*)""")]
        public void ThenVerifyTransactionNewPageStaticMessageContains(string p0)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                fw.ConsoleReport(" ");

            }
            else
            {
                string actualmsg = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblMsg")).Text;
                bool correctmsg = actualmsg.Contains(p0);
                Assert.IsTrue(correctmsg, "Expected Message is not getting displayed");
                tmsWait.Hard(5);
            }
        }


        //span[contains(.,'Please provide Receipt Date')]


        [Then(@"Browser popup is closed")]
        public void ThenBrowserPopupIsClosed()
        {
            Browser.ClosePopUps(true);
        }

        [When(@"Transactions New Effective Date is set to ""(.*)"" months ahead from current month")]
        public void WhenTransactionsNewEffectiveDateIsSetToMonthsAheadFromCurrentMonth(int p0)
        {
            var datem = DateTime.Now;          // This will return system current date 
            var months = datem.AddMonths(2);   //This will add specified number of months in the date
            Console.WriteLine(months);
            Console.WriteLine("Hello months");

        }

        [When(@"Transactions New DOB is set to ""(.*)"" years back from current date")]
        public void WhenTransactionsNewDOBIsSetToYearsBackFromCurrentDate(int p0)
        {
            var date = DateTime.Now;
            var yearss = date.AddYears(2);                     //Will add number of years in the date (Ex; date is 01/01/2016 -> 01/01/2018)  
            Console.WriteLine(yearss);
            Console.WriteLine("Hello Year");
            var onlydate = DateTime.Now.ToString("MM/dd/yyyy");  //Will retrun only date and also in the specified format
            Console.WriteLine(onlydate);
            var onlytime = DateTime.Now.TimeOfDay;               //Will return only time stamp from the the entire date 
            Console.Write(onlytime);

        }


    }
}
