﻿using OpenQA.Selenium;
using TechTalk.SpecFlow;


namespace TMSoR1
{
    public class EAM
    {
        public static AdministrationMMP AdministrationMMP { get { return new AdministrationMMP(); } }
        public static AdministrationEditLISInformation AdministrationEditLISInformation { get { return new AdministrationEditLISInformation(); } }
        public static AdministrationExportSession AdministrationExportSession { get { return new AdministrationExportSession(); } }
        public static AdministrationPlanDefinedFields AdministrationPlanDefinedFields { get { return new AdministrationPlanDefinedFields(); } }
        public static BuisnessRulesFields BuisnessRulesFields { get { return new BuisnessRulesFields(); } }
        public static AdministrationPlanDefinedFieldsTabLanguage AdministrationPlanDefinedFieldsTabLanguage { get { return new AdministrationPlanDefinedFieldsTabLanguage(); } }
        public static AdministrationPlanDefinedFieldsTabRelationship AdministrationPlanDefinedFieldsTabRelationship { get { return new AdministrationPlanDefinedFieldsTabRelationship(); } }
        public static AdministrationPlanDefinedFieldsTabSalesRep AdministrationPlanDefinedFieldsTabSalesRep { get { return new AdministrationPlanDefinedFieldsTabSalesRep(); } }
        public static AdministrationPlanDefinedFieldsTabContact AdministrationPlanDefinedFieldsTabContact { get { return new AdministrationPlanDefinedFieldsTabContact(); } }
        public static AdministrationPlanDefinedFieldsTabDisenrollment AdministrationPlanDefinedFieldsTabDisenrollment { get { return new AdministrationPlanDefinedFieldsTabDisenrollment(); } }
        public static AdministrationPlanDefinedFieldsTabGroups AdministrationPlanDefinedFieldsTabGroups { get { return new AdministrationPlanDefinedFieldsTabGroups(); } }
        public static AdministrationPlanDefinedFieldsTabSpanTypes AdministrationPlanDefinedFieldsTabSpanTypes { get { return new AdministrationPlanDefinedFieldsTabSpanTypes(); } }
        public static AdministrationPlanDefinedFieldsTabSpanConfig AdministrationPlanDefinedFieldsTabSpanConfig { get { return new AdministrationPlanDefinedFieldsTabSpanConfig(); } }
        public static AdministrationPlanDefinedFieldsPlan5StarStatus AdministrationPlanDefinedFieldsPlan5StarStatus { get { return new AdministrationPlanDefinedFieldsPlan5StarStatus(); } }
        public static AdministrationPlanDefinedFieldsOEVLetter AdministrationPlanDefinedFieldsOEVLetter { get { return new AdministrationPlanDefinedFieldsOEVLetter(); } }
        public static AdministrationManagePlanSCCViewEdit AdministrationManagePlanSCCViewEdit { get { return new AdministrationManagePlanSCCViewEdit(); } }

        public static AdministrationElectionTypeValidation AdministrationElectionTypeValidation { get { return new AdministrationElectionTypeValidation(); } }
        public static UserAdministrationCRUDUser UserAdministrationCrudUser { get { return new UserAdministrationCRUDUser(); } }
        public static AdministrationAuditingConfiguration AdministrationAuditingConfiguration { get { return new AdministrationAuditingConfiguration(); } }
        public static AdministrationPlanDefinedFieldsOOATab AdministrationPlanDefinedFieldsOOATab { get { return new AdministrationPlanDefinedFieldsOOATab(); } }
        public static MembersSearch MembersSearch { get { return new MembersSearch(); } }
        public static TransactionsViewEdit TransactionsViewEdit { get { return new TransactionsViewEdit(); } }
        public static MembersViewEdit MembersViewEdit { get { return new MembersViewEdit(); } }
        public static TransactionsNew TransactionsNew { get { return new TransactionsNew(); } }
        public static TransactionsNew61 TransactionsNew61 { get { return new TransactionsNew61(); } }
        public static TransactionsNew76 TransactionsNew76 { get { return new TransactionsNew76(); } }
        public static EAMLogin EAMLogin { get { return new EAMLogin(); } }
        public static EAMLogout EAMLogout { get { return new EAMLogout(); } }

        public static EAMErrorPage EAMErrorPage { get { return new EAMErrorPage(); } }
        public static NavigationBar NavigationBar { get { return new NavigationBar(); } }
        public static MembersNew MembersNew { get { return new MembersNew(); } }
        public static MembersNewTabSpans MembersNewTabSpans { get { return new MembersNewTabSpans(); } }
        public static MembersNewTabEligibility MembersNewTabEligibility { get { return new MembersNewTabEligibility(); } }
        public static MembersNewTabTransactions MembersNewTabTransactions { get { return new MembersNewTabTransactions(); } }
        public static MembersNewTabCorrespondence MembersNewTabCorrespondence { get { return new MembersNewTabCorrespondence(); } }
        public static MembersNewTabIDHistory MembersNewTabIDHistory { get { return new MembersNewTabIDHistory(); } }
        public static MembersNewTabRXBilling MembersNewTabRXBilling { get { return new MembersNewTabRXBilling(); } }
        public static MembersNewTabOECSales MembersNewTabOECSales { get { return new MembersNewTabOECSales(); } }
        public static MembersNewTabProvider MembersNewTabProvider { get { return new MembersNewTabProvider(); } }
        public static MembersNewTabContact MembersNewTabContact { get { return new MembersNewTabContact(); } }
        public static MembersNewTabPayment MembersNewTabPayment { get { return new MembersNewTabPayment(); } }
        public static MembersViewEditTransactionsTab MembersViewEditTransactionsTab { get { return new MembersViewEditTransactionsTab(); } }
        public static MembersViewEditEligibilityTab MembersViewEditEligibilityTab { get { return new MembersViewEditEligibilityTab(); } }
        public static MembersViewEditSpansTab MembersViewEditSpansTab { get { return new MembersViewEditSpansTab(); } }
        public static MembersNewMemberAuditHistory MembersNewMemberAuditHistory { get { return new MembersNewMemberAuditHistory(); } }
        public static UserAdministrationSearchUser UserAdministrationSearchUser { get { return new UserAdministrationSearchUser(); } }
        public static LoadEAFFile LoadEAFFile { get { return new LoadEAFFile(); } }
        public static LoadNoRxFile LoadNoRxFile { get { return new LoadNoRxFile(); } }
        public static UploadNewFile UploadNewFile { get { return new UploadNewFile(); } }
        public static LoadNoPremiumDueFile LoadNoPremiumDueFile { get { return new LoadNoPremiumDueFile(); } }
        public static LoadBulkAttachment LoadBulkAttachment { get { return new LoadBulkAttachment(); } }
        public static MemberBulkAttachment MemberBulkAttachment { get { return new MemberBulkAttachment(); } }
        public static LoadBEQFile LoadBEQFile { get { return new LoadBEQFile(); } }
        public static LoadTRRFile LoadTRRFile { get { return new LoadTRRFile(); } }
        public static LoadProviderFile LoadProviderFile { get { return new LoadProviderFile(); } }
        public static EAMHomePage EAMHomePage { get { return new EAMHomePage(); } }
        public static FilesProcessingStatus FilesProcessingStatus { get { return new FilesProcessingStatus(); } }
        public static Letters Letters { get { return new Letters(); } }
        public static LettersTemplate LettersTemplate { get { return new LettersTemplate(); } }
        public static LettersPostCMS LettersPostCMS { get { return new LettersPostCMS(); } }
        public static CMSResponseCodeLevelDetailReport CMSResponseCodeLevelDetailReport { get { return new CMSResponseCodeLevelDetailReport(); } }
        public static CMSResponseTRRDetailReport CMSResponseTRRDetailReport { get { return new CMSResponseTRRDetailReport(); } }
        public static CMSResponseTRRSummaryReport CMSResponseTRRSummaryReport { get { return new CMSResponseTRRSummaryReport(); } }
        public static CMSResponseRecordsDupedOutFromTRRReport CMSResponseRecordsDupedOutFromTRRReport { get { return new CMSResponseRecordsDupedOutFromTRRReport(); } }
        public static MemberReportMembersTRRHistory MemberMemberTRRHistoryReport { get { return new MemberReportMembersTRRHistory(); } }
        public static DisenrollmentComplianceReport DisenrollmentComplianceReport { get { return new DisenrollmentComplianceReport(); } }
        public static EnrollmentComplianceReport EnrollmentComplianceReport { get { return new EnrollmentComplianceReport(); } }
        public static NoRxFalloutReport NoRxFalloutReport { get { return new NoRxFalloutReport(); } }
        public static EnrollmentComplianceReportElement EnrollmentComplianceReportElement { get { return new EnrollmentComplianceReportElement(); } }
        public static DisenrollmentComplianceReportElement DisenrollmentComplianceReportElement { get { return new DisenrollmentComplianceReportElement(); } }
        public static AdministrationStatusoverride AdministrationStatusoverride { get { return new AdministrationStatusoverride(); } }
        public static MemberInformation MemberInformation { get { return new MemberInformation(); } }
        public static ReportsEnrollmentOECEAFFallout ReportsEnrollmentOECEAFFallout { get { return new ReportsEnrollmentOECEAFFallout(); } }
        public static ReportsDeemedLISDetailReport ReportsDeemedLISDetailReport { get { return new ReportsDeemedLISDetailReport(); } }
        public static AdministrationPage AdministrationPage { get { return new AdministrationPage(); } }
        public static Recalculations Recalculations { get { return new Recalculations(); } }
        public static AdministrationJobsPage AdministrationJobsPage { get { return new AdministrationJobsPage(); } }
        public static Reports Reports { get { return new Reports(); } }
        public static ReportsTransMissingCMSData ReportsTransMissingCMSData { get { return new ReportsTransMissingCMSData(); } }
        public static ViewBidData ViewBidData { get { return new ViewBidData(); } }
        public static EditPLanInfo EditPLanInfo { get { return new EditPLanInfo(); } }
        public static TC90 TC90 { get { return new TC90(); } }
        public static CreateCMSFile CreateCMSFile { get { return new CreateCMSFile(); } }
        public static CreateBEQFile CreateBEQFile { get { return new CreateBEQFile(); } }
        public static CreateRetroFile CreateRetroFile { get { return new CreateRetroFile(); } }
        public static MailingListTransExport MailingListTransExport { get { return new MailingListTransExport(); } }
        public static AdministrationExternalIntegration AdministrationExternalIntegration { get { return new AdministrationExternalIntegration(); } }
        public static AdministrationExternalIntegration AdministrationExternalIntegrationmessage { get { return new AdministrationExternalIntegration(); } }
        public static AdministrationExternalIntegration AdministrationExternalIntegrationexpressionmessage { get { return new AdministrationExternalIntegration(); } }
        public static ERF ERF { get { return new ERF(); } }
        public static ERFAppDisposition ERFAppDisposition { get { return new ERFAppDisposition(); } }
        public static SinglMemberReport SinglMemberReport { get { return new SinglMemberReport(); } }
        public static SendToCMSQueueReport SendToCMSQueueReport { get { return new SendToCMSQueueReport(); } }
        public static IncompleteTransactionReport IncompleteTransactionReport { get { return new IncompleteTransactionReport(); } }
        public static DenialReport DenialReport { get { return new DenialReport(); } }
        public static AdminEAMConfiguration AdminEAMConfiguration { get { return new AdminEAMConfiguration(); } }
        public static WorkFlowConfiguration WorkFlowConfiguration { get { return new WorkFlowConfiguration(); } }
        public static AdministrationWorkflow AdministrationWorkflow { get { return new AdministrationWorkflow(); } }
        public static WFDashboard WFDashboard { get { return new WFDashboard(); } }
        public static WFTaskbarOperations WFTaskbarOperations { get { return new WFTaskbarOperations(); } }
        public static PCPIPALookup PCPIPALookup { get { return new PCPIPALookup(); } }
        public static PDDDConfig PDDDConfig { get { return new PDDDConfig(); } }
        public static TmsOperationalConfiguration TmsOperationalConfiguration { get { return new TmsOperationalConfiguration(); } }
        public static ViewEditMemberContact ViewEditMemberContact { get { return new ViewEditMemberContact(); } }
        public static AdministrationBEQCMSTransfer AdministrationBEQCMSTransfer { get { return new AdministrationBEQCMSTransfer(); } }



        public static CreateNewMember CreateNewMember { get { return new CreateNewMember(); } }
        public static TRRActivityLogging TRRActivityLogging { get { return new TRRActivityLogging(); } }
        public static ViewEditTRC ViewEditTRC { get { return new ViewEditTRC(); } }
        public static FieldsLevel FieldsLevel { get { return new FieldsLevel(); } }
        public static RulesLevel RulesLevel { get { return new RulesLevel(); } }
        public static EGWPConfiguration EGWPConfiguration { get { return new EGWPConfiguration(); } }
    }

    [Binding]
    public class EGWPConfiguration
    {
        //public IWebElement ADDEGWPButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='actLevelSearch-rd-rdbTcTrc']")); } }
        public IWebElement ADDEGWPButton { get { return Browser.Wd.FindElement(By.XPath("(//button[@test-id='manageEgwp-btn-reset'])[1]")); } }
        public IWebElement ADDEmployerGroupNumber { get { return Browser.Wd.FindElement(By.XPath("//input[@modelname='Employer Group Number ']")); } }
        public IWebElement ADDEmployerGroupName { get { return Browser.Wd.FindElement(By.XPath("//input[@id='txtEmployerName']")); } }
        public IWebElement ADDEmployerStartDate { get { return Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='addEditEgwp-txt-startDate']//span[@role='button']")); } }
        public IWebElement ADDEmployeeEndDate { get { return Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='addEditEgwp-txt-endDate']//span[@role='button']")); } }
        public IWebElement ADDSaveEGWPButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='addEditEgwp-btn-add']")); } }
        public IWebElement AssociateEGWPButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='egwpAssociation-btn-addEGWPAssociation']")); } }
        public IWebElement AddAssociateEGWPButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='addEgwpAssociation-btn-add']")); } }
        public IWebElement AssociateEGWPBackToRecord { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='addEgwpAssociation-span-back']")); } }
    }

    [Binding]
    public class RulesLevel
    {
        public IWebElement TRCDrp { get { return Browser.Wd.FindElement(By.XPath("//kendo-multiselect//input")); } }
        public IWebElement TCDrp { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='actLevelSearch-select-tranCodes']//span[@class='k-select']")); } }
        public IWebElement TC_TRC_Option { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='actLevelSearch-rd-rdbTcTrc']")); } }
        public IWebElement Action_Option { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='actLevelSearch-rd-rdbAction']")); } }
        public IWebElement SearchButton { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'SEARCH')]")); } }

     
        public IWebElement RESETButton { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'RESET')]")); } }
    }
    [Binding]
    public class FieldsLevel
    {
        public IWebElement TRCDrp { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='trrConfigurationFieldSearchField-select-TRC']//span[@class='k-select']")); } }
        public IWebElement TCDrp { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='trrConfigurationFieldSearchField-select-tranCode']//span[@class='k-select']")); } }
        public IWebElement Field { get { return Browser.Wd.FindElement(By.XPath("//kendo-multiselect//input")); } }
        public IWebElement SearchButton { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'SEARCH')]")); } }

        public IWebElement CANCELButton { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'CANCEL')]")); } }
    }

        [Binding]
    public class ViewEditTRC
    {
        public IWebElement TRCDrp { get { return Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='viewEditTrc-select-searchTrc']//input")); } }
        public IWebElement TypeDrp { get { return Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='viewEditTrc-select-searchType']//input")); } }
        
        public IWebElement SearchButton { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'SEARCH')]")); } }

        public IWebElement CANCELButton { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'CANCEL')]")); } }
        public IWebElement UserRulesSection { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='actLevelSearch-btn-btnUserAction']")); } }
    }

    [Binding]
    public class TRRActivityLogging
    {
        public IWebElement BeneficiaryID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='trrlogging-txt-txtMemId']")); } }
        public IWebElement Keyword { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='trrlogging-txt-txtMsg']")); } }
        public IWebElement FileNameSearchBar { get { return Browser.Wd.FindElement(By.XPath("//kendo-searchbar/input[@placeholder]")); } }
        public IWebElement SearchButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='trrlogging-btn-reset']")); } }

        
    }

    [Binding]
    public class AdministrationElectionTypeValidation
    {
        public IWebElement ElectionTypeValidationSwitch
        {
            get
            {
                return Browser.Wd.FindElement(By.XPath("//input[@test-id='electionTypeValidation-input-changeElectionTypeValidation']"));
            }


        }
        public IWebElement ElectionTypeValidationSwitchClickable
        {
            get
            {
                return Browser.Wd.FindElement(By.XPath("//input[@test-id='electionTypeValidation-input-changeElectionTypeValidation']/following-sibling::span/span[contains(@class,'k-switch-handle km-switch-handle')]"));
            }
            //input[@test-id='electionTypeValidation-input-changeElectionTypeValidation']/following-sibling::span/span[contains(@class,'k-switch-handle km-switch-handle')
        }
        public IWebElement ElectionTypeValidationSave
        {
            get
            {
                return Browser.Wd.FindElement(By.Id("btnSaveElectionTypeConfig"));
            }
            //input[@test-id='electionTypeValidation-input-changeElectionTypeValidation']/following-sibling::span/span[contains(@class,'k-switch-handle km-switch-handle')
        }

    }
    [Binding]
    public class CreateNewMember
    {
        public IWebElement MedicaidNumber { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtMedicaidNum")); } }
    }

    [Binding]
    public class BuisnessRulesFields
    {
        public IWebElement BuisnessRuleLink { get { return Browser.Wd.FindElement(By.XPath(".//li[@test-id='eamConfigurations-li-eamConfigurationsList']/label[contains(text(), 'Business Rules')]")); } }
        public IWebElement Planchangepostcmscheckbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_chkPlanChangePostCms")); } }
        public IWebElement PlanChangePreCmsCheckbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_chkPlanChangePreCms")); } }
        public IWebElement NotesActionsShowActions { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_chkNotesAction")); } }
        public IWebElement EnhanceMemberDupeCheck { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_chkEnhanceMember")); } }
        public IWebElement EGHPCheckbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='businessRules-chk-EGHPValidation']")); } }
        public IWebElement ElectionTypeValidationCheckbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='businessRules-chk-ElectionTypeValidation']")); } }
        public IWebElement SaveButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='businessRules-btn-saveBusinessRules']")); } }
        public IWebElement BusinessRulesSaveButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_chkNotesAction")); } }
        public IWebElement AddToServiceAreaSCCcodeValidation { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='businessRules-lbl-SCCCodeValidation']")); } }
    }

    [Binding]
    public class ViewEditMemberContact
    {
        public IWebElement ResponsibilityName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtRespName")); } }
        public IWebElement ResponsibilityAddress { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtResponsAdd1")); } }
        public IWebElement ResponsibilityCity { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtRespCity")); } }
        public IWebElement ResponsibilityState { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtRespState")); } }
        public IWebElement ResponsibilityZip { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtRespZip")); } }
        public IWebElement ResponsibilityPhone { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtRespPhone")); } }
        public IWebElement ResponsibilityRelation { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_cboResponsRel")); } }
    }

    [Binding]
    public class TmsOperationalConfiguration
    {
        public IWebElement DBName { get { return Browser.Wd.FindElement(By.Id("txtDatabaseName")); } }
        public IWebElement DBServer { get { return Browser.Wd.FindElement(By.Id("txtDatabaseServer")); } }
        public IWebElement DBUser { get { return Browser.Wd.FindElement(By.Id("txtDatabaseUser")); } }
        public IWebElement Password { get { return Browser.Wd.FindElement(By.Id("txtPassword")); } }
        public IWebElement Save { get { return Browser.Wd.FindElement(By.Id("BtnSave")); } }
        public IWebElement Reset { get { return Browser.Wd.FindElement(By.Id("BtnReset")); } }

    }

    [Binding]

    public class PDDDConfig
    {
        public IWebElement PDDDConfigTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_gvPDDD")); } }
        public IWebElement PDDDConfigYrsdrpdown { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlPDDDYears")); } }
        public IWebElement PDDDConfigGoButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnGo")); } }
    }


    [Binding]
    public class LoadProviderFile
    {
        public IWebElement Browse { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_FileUpload1")); } }
        public IWebElement Import { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnImport")); } }
        public IWebElement ResponseMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblMsg")); } }
    }

    [Binding]
    public class PCPIPALookup
    {
        public IWebElement AcceptsAssignmentdrpdown { get { return Browser.Wd.FindElement(By.XPath("//span[@aria-owns='acceptAssignments_listbox']")); } }
        public IWebElement AcceptNewMembersDropdown { get { return Browser.Wd.FindElement(By.XPath("//span[@aria-owns='acceptNewMembers_listbox']")); } }
        public IWebElement ProviderIDTextbox { get { return Browser.Wd.FindElement(By.Id("txtProvID")); } }
        public IWebElement ProviderFirstName { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='pcpIpa-txt-providerFirstName']")); } }
        public IWebElement ProviderLastName { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='pcpIpa-txt-providerLastName']")); } }
        public IWebElement ProviderLookUpTable { get { return Browser.Wd.FindElement(By.Id("pcpIpaGridView_ctl00")); } }
        public IWebElement NoRecordText { get { return Browser.Wd.FindElement(By.CssSelector(".rgNoRecords >td >div")); } }
        public IWebElement SubmitButton { get { return Browser.Wd.FindElement(By.Id("btnSearch")); } }
        public IWebElement Close { get { return Browser.Wd.FindElement(By.Id("btnCloseForm")); } }
        public IWebElement Reset { get { return Browser.Wd.FindElement(By.Id("cmdReset")); } }
        public IWebElement NewPCPIDTextbox { get { return Browser.Wd.FindElement(By.Id("txtNewPCP")); } }
        public IWebElement NewIPATextbox { get { return Browser.Wd.FindElement(By.Id("txtNewIPA")); } }
        public IWebElement SaveButton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='pcpIpa-btn-savePcp']")); } }
        public IWebElement PCPIDTextbox { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='provider-input-pcpId']")); } }
        public IWebElement GroupIPAIDTextbox { get { return Browser.Wd.FindElement(By.Id("txtIPAid")); } }
        public IWebElement GroupIPANameTextbox { get { return Browser.Wd.FindElement(By.Id("txtIPAName")); } }
        public IWebElement NPI { get { return Browser.Wd.FindElement(By.Id("txtNpi")); } }
        public IWebElement Statesdrpdown { get { return Browser.Wd.FindElement(By.XPath("//span[@aria-owns='pcpState_listbox']")); } }
        public IWebElement ParticipatingFilterdrpdown { get { return Browser.Wd.FindElement(By.Id("ddParticipate")); } }
        public IWebElement PCPLookupTable { get { return Browser.Wd.FindElement(By.Id("pcpIpaGridView_ctl00")); } }
        public IWebElement Message { get { return Browser.Wd.FindElement(By.ClassName("message")); } }
        public IWebElement OKButton { get { return Browser.Wd.FindElement(By.XPath("//button[@type='button']")); } }
        public IWebElement PageSizeText { get { return Browser.Wd.FindElement(By.Id("pcpIpaGridView_ctl00_ctl03_ctl01_ChangePageSizeTextBox")); } }
        public IWebElement LastPageText { get { return Browser.Wd.FindElement(By.Id("pcpIpaGridView_ctl00_ctl03_ctl01_PageOfLabel")); } }
        public IWebElement LastPageNavButton { get { return Browser.Wd.FindElement(By.ClassName("rgPageLast")); } }


    }


    [Binding]
    public class AdminEAMConfiguration
    {
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='osbConfiguration-select-planId']")); } }
        public IWebElement PBPID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='osbConfiguration-select-pbpID']")); } }
        public IWebElement AuditHistory { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='osbConfiguration-lbl-settingHistory']")); } }
        public IWebElement AuditHistoryNoData { get { return Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_OSBConfiguration_osbConfigAuditDialog_osbConfigHistoryGrid_ctl00']//tr/td/div")); } }
        public IWebElement ADDOSBButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='osbConfiguration-button-addOsb']")); } }
        public IWebElement ADDOSBID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='osbAddDetail-txt-txtOsbId']")); } }
        public IWebElement ADDOSBName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='osbAddDetail-txt-txtOsbName']")); } }
        public IWebElement ADDOSBDescription { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='osbAddDetail-input-description']")); } }
        public IWebElement ADDButtonforOSB { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='osbAddDetail-btn-save']")); } }
        public IWebElement BacktoEAMConfigpage { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='addAction-span-back']")); } }

        public IWebElement OSBType { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlOsbType_listbox']")); } }
        public IWebElement Premium { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='osbConfiguration-txt-OsbPremiuim']")); } }
        public IWebElement StartYear { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlOsbStartYear_listbox']")); } }
        public IWebElement EndYear { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlOsbEndYear_listbox']")); } }
        public IWebElement Save { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='osbConfiguration-btn-save']")); } }
        public IWebElement Update { get { return Browser.Wd.FindElement(By.XPath("//span[@class='k-i-check fa fa-floppy-o']/parent::a")); } }
        public IWebElement AngUpdate { get { return Browser.Wd.FindElement(By.XPath("//span[@class='fas fa-save']/parent::a")); } }

        public IWebElement EAMConfigTable { get { return Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_OSBConfiguration_osbGrid_ctl00']")); } }
        public IWebElement CloseOsbConfigHistoryButton { get { return Browser.Wd.FindElement(By.XPath("//*[@id='eamAuditInfoDialog']/div[1]/span[2]/i")); } }

        public IWebElement ResultTableOsbConfigHistory { get { return Browser.Wd.FindElement(By.Id("//*[@id='eamAuditInfoDialog']")); } }

        public IWebElement SuccessMsg { get { return Browser.Wd.FindElement(By.XPath("//div[@id='osbMessageContainer']/span")); } }
        public IWebElement OSBTablePlanIDDropdown { get { return Browser.Wd.FindElement(By.XPath("//a[@id='ctl00_ctl00_MainMasterContent_MainContent_OSBConfiguration_osbGrid_ctl00_ctl02_ctl01_planIdFilterComboBox_Arrow']")); } }
        public IWebElement OSBTablePlanID { get { return Browser.Wd.FindElement(By.XPath("//div[@id='ctl00_ctl00_MainMasterContent_MainContent_OSBConfiguration_osbGrid_ctl00_ctl02_ctl01_planIdFilterComboBox_DropDown']//ul[@class='rcbList']/li[2]")); } }
        public IWebElement OSBTableEditbutton { get { return Browser.Wd.FindElement(By.XPath("//input[@title='Edit']")); } }
        public IWebElement OSBTableDeletebutton { get { return Browser.Wd.FindElement(By.XPath("//input[@title='Delete']")); } }
        public IWebElement OSBTableNoRows { get { return Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_OSBConfiguration_osbGrid_ctl00']//tr[@class='rgNoRecords']//div")); } }
        public IWebElement OSBTableCancelbutton { get { return Browser.Wd.FindElement(By.XPath("//span[@class='k-icon k-i-cancel']/parent::a")); } }
        public IWebElement OSBPlandrpdown { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OSBConfiguration_osbGrid_ctl00_ctl02_ctl01_planIdFilterComboBox_Input")); } }
        public IWebElement OSBPbpdrpdown { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OSBConfiguration_osbGrid_ctl00_ctl02_ctl01_pbpIdFilterComboBox_Input")); } }
        public IWebElement OSBOSBTypedrpdown { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OSBConfiguration_osbGrid_ctl00_ctl02_ctl01_osbTypeFilterComboBox_Input")); } }
        public IWebElement OSBOSBPremiumdrpdown { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OSBConfiguration_osbGrid_ctl00_ctl02_ctl01_osbPremiumFilterComboBox_Input")); } }
        public IWebElement OSBStartDatedrpdown { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OSBConfiguration_osbGrid_ctl00_ctl02_ctl01_osbStartDateFilterComboBox_Input")); } }
        public IWebElement OSBEndDatedrpdown { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OSBConfiguration_osbGrid_ctl00_ctl02_ctl01_osbEndDateFilterComboBox_Input")); } }
        public IWebElement OSBDentalCheckbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_chkBoxDentalOSB")); } }
        public IWebElement OSBSelectiondrpdown { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_DropDownOSBFlag")); } }
        public IWebElement TranspageOSBSelectiondrpdown { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_DropDownOSBFlag")); } }
        public IWebElement MemberSavebutton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='memberViewEdit-btn-save']")); } }
        public IWebElement TranspageSavebutton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSave")); } }
        public IWebElement PartCAmount { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_txtPartC")); } }
        public IWebElement TranspagePartCAmount { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtPremAmtC_19")); } }

        public IWebElement NewTransOSBMedicalCheckbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_chkboxOSBList_0")); } }
        public IWebElement NewTransOSBDentalCheckbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_chkboxOSBList_1")); } }
        public IWebElement NewTransOSBVisionCheckbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_chkboxOSBList_2")); } }
        public IWebElement NewTransOSBOtherCheckbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_chkboxOSBList_3")); } }

        public IWebElement OSBVisionCheckbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_chkBoxVisionOSB")); } }
        public IWebElement OSBMedicalCheckbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_chkBoxMedicalOSB")); } }
        public IWebElement OSBOthersCheckbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_chkBoxOtherOSB")); } }
        public IWebElement TranspageOSBVisionCheckbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_chkboxOSBList_2")); } }
        public IWebElement TranspageOSBMedicalCheckbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_chkboxOSBList_0")); } }
        public IWebElement TranspageOSBOthersCheckbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_chkboxOSBList_3")); } }
        public IWebElement TranspageOSBDentalCheckbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_chkboxOSBList_1")); } }
        public IWebElement TranspageSCCCode { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtSCCCode")); } }
        public IWebElement TranspageCounty { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtCountyForInvalidZip")); } }
        public IWebElement ViewOSBConfigSelectDrpdown { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OSBConfiguration_osbGrid_ctl00_ctl02_ctl01_planIdFilterComboBox_Arrow")); } }
        public IWebElement ViewOSBConfigAllPlanIDDrpdown { get { return Browser.Wd.FindElement(By.XPath("//div[@id='ctl00_ctl00_MainMasterContent_MainContent_OSBConfiguration_osbGrid_ctl00_ctl02_ctl01_planIdFilterComboBox_DropDown']//li[1]")); } }
        public IWebElement ViewOSBConfigH0001PlanIDDrpdown { get { return Browser.Wd.FindElement(By.XPath("//div[@id='ctl00_ctl00_MainMasterContent_MainContent_OSBConfiguration_osbGrid_ctl00_ctl02_ctl01_planIdFilterComboBox_DropDown']//li[2]")); } }

        public IWebElement ViewOSBConfigPBPIDSelectDrpdown { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OSBConfiguration_osbGrid_ctl00_ctl02_ctl01_pbpIdFilterComboBox_Arrow")); } }
        public IWebElement ViewOSBConfigAllPBPIDDrpdown { get { return Browser.Wd.FindElement(By.XPath("//div[@id='ctl00_ctl00_MainMasterContent_MainContent_OSBConfiguration_osbGrid_ctl00_ctl02_ctl01_pbpIdFilterComboBox_DropDown']//li[1]")); } }
        public IWebElement ViewOSBConfig002PlanIDDrpdown { get { return Browser.Wd.FindElement(By.XPath("//div[@id='ctl00_ctl00_MainMasterContent_MainContent_OSBConfiguration_osbGrid_ctl00_ctl02_ctl01_pbpIdFilterComboBox_DropDown']//li[2]")); } }

        public IWebElement ViewOSBConfigOSBTypeSelectDrpdown { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OSBConfiguration_osbGrid_ctl00_ctl02_ctl01_osbTypeFilterComboBox_Arrow")); } }
        public IWebElement ViewOSBConfigAllOSBDrpdown { get { return Browser.Wd.FindElement(By.XPath("//div[@id='ctl00_ctl00_MainMasterContent_MainContent_OSBConfiguration_osbGrid_ctl00_ctl02_ctl01_pbpIdFilterComboBox_DropDown']//li[1]")); } }
        public IWebElement ViewOSBConfigDentalOSBDrpdown { get { return Browser.Wd.FindElement(By.XPath("//div[@id='ctl00_ctl00_MainMasterContent_MainContent_OSBConfiguration_osbGrid_ctl00_ctl02_ctl01_osbTypeFilterComboBox_DropDown']//li[2]")); } }
        public IWebElement ViewOSBConfigMedOSBDrpdown { get { return Browser.Wd.FindElement(By.XPath("//div[@id='ctl00_ctl00_MainMasterContent_MainContent_OSBConfiguration_osbGrid_ctl00_ctl02_ctl01_osbTypeFilterComboBox_DropDown']//li[3]")); } }
        public IWebElement ViewOSBConfigOtherOSBDrpdown { get { return Browser.Wd.FindElement(By.XPath("//div[@id='ctl00_ctl00_MainMasterContent_MainContent_OSBConfiguration_osbGrid_ctl00_ctl02_ctl01_osbTypeFilterComboBox_DropDown']//li[4]")); } }
        public IWebElement ViewOSBConfigVisionOSBDrpdown { get { return Browser.Wd.FindElement(By.XPath("//div[@id='ctl00_ctl00_MainMasterContent_MainContent_OSBConfiguration_osbGrid_ctl00_ctl02_ctl01_osbTypeFilterComboBox_DropDown']//li[5]")); } }
        public IWebElement BusinessRulesTab { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='ctl00_ctl00_MainMasterContent_MainContent_RadTabStrip1']//span[contains(text(), 'Business Rules')]")); } }

    }

    [Binding]
    public class IncompleteTransactionReport
    {
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.Id("ctl00_MainMasterContent_PlanID")); } }
        public IWebElement PBPID { get { return Browser.Wd.FindElement(By.Id("ctl00_MainMasterContent_PBPID")); } }
        public IWebElement RunReportbutton { get { return Browser.Wd.FindElement(By.Id("reportGen")); } }

    }

    [Binding]
    public class SendToCMSQueueReport
    {
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.Id("ctl00_MainMasterContent_PlanID")); } }
        public IWebElement PBPID { get { return Browser.Wd.FindElement(By.Id("ctl00_MainMasterContent_PBPID")); } }
        public IWebElement EffectiveDateFrom { get { return Browser.Wd.FindElement(By.Id("ctl00_MainMasterContent_EffDate_From")); } }
        public IWebElement EffectiveDateTo { get { return Browser.Wd.FindElement(By.Id("ctl00_MainMasterContent_EffDate_To")); } }
        public IWebElement ElectionType { get { return Browser.Wd.FindElement(By.Id("ctl00_MainMasterContent_ElectionType")); } }
        public IWebElement RunReportbutton { get { return Browser.Wd.FindElement(By.Id("reportGen")); } }


    }

    [Binding]
    public class DenialReport
    {
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.Id("ctl00_MainMasterContent_PLAN_ID")); } }
        public IWebElement PBPID { get { return Browser.Wd.FindElement(By.Id("ctl00_MainMasterContent_PBPID")); } }
        public IWebElement ReceiptDate { get { return Browser.Wd.FindElement(By.Id("ctl00_MainMasterContent_ReceiptDate")); } }
        public IWebElement DenialReason { get { return Browser.Wd.FindElement(By.Id("ctl00_MainMasterContent_DenialReason")); } }
        public IWebElement RunReportbutton { get { return Browser.Wd.FindElement(By.Id("reportGen")); } }


    }



    [Binding]
    public class ERFAppDisposition
    {

        public IWebElement InCompleteApplication { get { return Browser.Wd.FindElement(By.Id("IncompleteApplication")); } }
        public IWebElement MissingItem { get { return Browser.Wd.FindElement(By.Id("MissingItem")); } }
        public IWebElement IncompleteOther { get { return Browser.Wd.FindElement(By.Id("IncompleteOther")); } }
        public IWebElement DenyApplication { get { return Browser.Wd.FindElement(By.Id("DenyApplication")); } }
        public IWebElement DenialReason { get { return Browser.Wd.FindElement(By.Id("DenialReason")); } }
        public IWebElement DenialOther { get { return Browser.Wd.FindElement(By.Id("DenialOther")); } }
        public IWebElement SnpStatusType { get { return Browser.Wd.FindElement(By.Id("SnpStatusType")); } }
        public IWebElement MissingItemTooltipmsg { get { return Browser.Wd.FindElement(By.XPath("//*[text()[contains(.,'Missing Item or Other must be entered for Incomplete Application.')]]")); } }
        public IWebElement DenialReasonTooltipmsg { get { return Browser.Wd.FindElement(By.XPath("//*[text()[contains(.,'Denial Reason or Other must be entered for Deny Application')]]")); } }
        public IWebElement NameofAgentBroker { get { return Browser.Wd.FindElement(By.Id("SalesRep")); } }


    }
    [Binding]
    public class MailingListTransExport
    {
        public IWebElement DisenrollDropdownlist { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlDisenroll")); } }
        public IWebElement Exportbutton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cmdExport")); } }
        public IWebElement Gobutton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cmdGo")); } }
    }

    [Binding]
    public class CreateRetroFile
    {
        public IWebElement PlanIDDropdownlist { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlPlan")); } }
        public IWebElement Exportbutton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnExport")); } }
        public IWebElement RetroContractorFileDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtDOB")); } }
        public IWebElement RetroFileRefreshBtn { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cmdReset")); } }
        public IWebElement RetroMarkAsSentBtn { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cmdMark")); } }
    }


    [Binding]
    public class SinglMemberReport
    {
        public IWebElement ClickHereLink { get { return Browser.Wd.FindElement(By.LinkText("Click here to search for value(s)")); } }
        public IWebElement RunReport { get { return Browser.Wd.FindElement(By.Id("reportGen")); } }
        public IWebElement MemberLookupHIC { get { return Browser.Wd.FindElement(By.Id("txtHIC")); } }
        public IWebElement MemberLookupLastName { get { return Browser.Wd.FindElement(By.Id("txtLast")); } }
        public IWebElement MemberLookupFirstName { get { return Browser.Wd.FindElement(By.Id("txtFirst")); } }
        public IWebElement MemberLookupSearchResultsTable { get { return Browser.Wd.FindElement(By.Id("dgNames")); } }
        public IWebElement MemberLookupSearchButton { get { return Browser.Wd.FindElement(By.Id("cmdSearch")); } }
        public IWebElement MemberLookupCloseButton { get { return Browser.Wd.FindElement(By.ClassName("formbutton")); } }



    }

    [Binding]
    public class ERF
    {
        public IWebElement DenyApplicationCheckbox { get { return Browser.Wd.FindElement(By.Id("DenyApplication")); } }
        public IWebElement DenyReasonDrpdownlist { get { return Browser.Wd.FindElement(By.Id("DenialReason")); } }
        public IWebElement ERFPlanIDDropdown { get { return Browser.Wd.FindElement(By.Id("Plan")); } }
        public IWebElement ERFPBPIDDropdown { get { return Browser.Wd.FindElement(By.Id("PBP")); } }
        public IWebElement ERFTypeofApplication { get { return Browser.Wd.FindElement(By.Id("Application")); } }
        public IWebElement ERFSegmentDropdown { get { return Browser.Wd.FindElement(By.Id("Segment")); } }
        public IWebElement ERFElectionTypeDropdown { get { return Browser.Wd.FindElement(By.Id("ElectionType")); } }
        public IWebElement ERFSEPSReason { get { return Browser.Wd.FindElement(By.Id("SepsReason")); } }
        public IWebElement ERFLastName { get { return Browser.Wd.FindElement(By.Id("LastName")); } }
        public IWebElement ERFAppel { get { return Browser.Wd.FindElement(By.Id("Appel")); } }
        public IWebElement SSN { get { return Browser.Wd.FindElement(By.Id("SSN")); } }
        public IWebElement ERFFirstName { get { return Browser.Wd.FindElement(By.Id("FirstName")); } }
        public IWebElement ERFDOB { get { return Browser.Wd.FindElement(By.Id("DOB")); } }
        public IWebElement ERFGenderDropdown { get { return Browser.Wd.FindElement(By.Id("GenderCode")); } }
        public IWebElement ERFEnrollmentSource { get { return Browser.Wd.FindElement(By.Id("EnrollmentSource")); } }
        public IWebElement ElectionTypeDropdown { get { return Browser.Wd.FindElement(By.Id("GenderCode")); } }

        public IWebElement ERFHIC { get { return Browser.Wd.FindElement(By.Id("HIC")); } }
        public IWebElement ERFMemberID { get { return Browser.Wd.FindElement(By.Id("MemberID")); } }
        public IWebElement ERFPrimaryRxID { get { return Browser.Wd.FindElement(By.Id("PrimaryRxId")); } }
        public IWebElement ERFEffectiveDate { get { return Browser.Wd.FindElement(By.Id("EffectiveDate")); } }
        public IWebElement ERFSignatureDate { get { return Browser.Wd.FindElement(By.Id("SignatureDate")); } }
        public IWebElement ERFReceiptDate { get { return Browser.Wd.FindElement(By.Id("ReceiptDate")); } }
        public IWebElement ERFResidenceAddress1 { get { return Browser.Wd.FindElement(By.Id("ResidenceAddress1")); } }
        public IWebElement ERFResidenceZip { get { return Browser.Wd.FindElement(By.Id("ResidenceZip")); } }
        public IWebElement ERFResidenceCity { get { return Browser.Wd.FindElement(By.Id("ResidenceCity")); } }
        public IWebElement ERFResidenceCountry { get { return Browser.Wd.FindElement(By.Id("ResidenceCounty")); } }
        public IWebElement ERFResidenceState { get { return Browser.Wd.FindElement(By.Id("ResidenceState")); } }
        public IWebElement ERFResidenceSCC { get { return Browser.Wd.FindElement(By.Id("ResidenceSCC")); } }

        //Premium Payment Options

        public IWebElement ERFElectrionicFundTransferCheckbox { get { return Browser.Wd.FindElement(By.Id("ElectronicFundsTransfer")); } }
        public IWebElement ERFAccountHolderName { get { return Browser.Wd.FindElement(By.Id("AccountHolderName")); } }
        public IWebElement ERFBankRoutingNumber { get { return Browser.Wd.FindElement(By.Id("BankRoutingNumber")); } }
        public IWebElement ERFBankAccountNumber { get { return Browser.Wd.FindElement(By.Id("BankAccountNumber")); } }
        public IWebElement ERFBankAccountTypeDropdown { get { return Browser.Wd.FindElement(By.Id("BankAccountType")); } }
        public IWebElement ERFPremiumWithholdOption { get { return Browser.Wd.FindElement(By.Id("PremiumWithholdOption")); } }
        // Special Status Section
        public IWebElement ERFLongTermCareCheckbox { get { return Browser.Wd.FindElement(By.Id("LongTermCare")); } }
        public IWebElement ERFInstitutionName { get { return Browser.Wd.FindElement(By.Id("InstitutionName")); } }
        public IWebElement ERFInstitutionAddress { get { return Browser.Wd.FindElement(By.Id("InstitutionAddress")); } }
        public IWebElement ERFInstitutionCity { get { return Browser.Wd.FindElement(By.Id("InstitutionCity")); } }
        public IWebElement ERFInstitutionState { get { return Browser.Wd.FindElement(By.Id("InstitutionState")); } }
        public IWebElement ERFInstitutionZip { get { return Browser.Wd.FindElement(By.Id("InstitutionZip")); } }
        public IWebElement ERFInstitutionPhone { get { return Browser.Wd.FindElement(By.Id("InstitutionPhone")); } }
        public IWebElement ERFEmployerGroupNumberdrpdownlist { get { return Browser.Wd.FindElement(By.Id("EmployerGroup")); } }

        // Other Insurance Section
        public IWebElement ERFOtherInsuranceCheckbox { get { return Browser.Wd.FindElement(By.Id("OtherInsurance")); } }
        public IWebElement ERFOtherInsuranceGroup { get { return Browser.Wd.FindElement(By.Id("OtherInsuranceGroup")); } }
        public IWebElement ERFOtherInsuranceIDNumber { get { return Browser.Wd.FindElement(By.Id("OtherInsuranceNumber")); } }

        public IWebElement ERFSubmitbutton { get { return Browser.Wd.FindElement(By.Id("ButtonSubmitAjax")); } }
        public IWebElement ERFResetbutton { get { return Browser.Wd.FindElement(By.Id("ButtonResetNew")); } }
        public IWebElement ERFNotesbutton { get { return Browser.Wd.FindElement(By.Id("NotesButton")); } }
        public IWebElement ERFAgentDropdown { get { return Browser.Wd.FindElement(By.Id("SalesRep")); } }
        public IWebElement ERFFrame { get { return Browser.Wd.FindElement(By.XPath("//iframe[@staticid='FrameERF']")); } }
        public IWebElement ERFResultsmsg { get { return Browser.Wd.FindElement(By.XPath("//div[@id='ResultMessage']")); } }
        public IWebElement ERFMailingAddressCheckbox { get { return Browser.Wd.FindElement(By.Id("MailingAddressIsResidenceAddress")); } }
        public IWebElement PartAEffectiveDateToolTip { get { return Browser.Wd.FindElement(By.XPath("//*[text()[contains(.,'Part A Effective Date must be a valid date and must be the first day of the Month.')]]")); } }
        public IWebElement PartAEffectiveDateToolTip1 { get { return Browser.Wd.FindElement(By.XPath("//*[text()[contains(.,'Part A Effective Date is not a valid date.')]]")); } }
        public IWebElement PartAEffectiveDateToolTip2 { get { return Browser.Wd.FindElement(By.XPath("//*[text()[contains(.,'Part A Effective Date cannot be less than 01/01/1900 and greater than 06/01/2079.')]]")); } }
        public IWebElement PartAEffectiveDateToolTip3 { get { return Browser.Wd.FindElement(By.XPath("//*[text()[contains(.,'Part A Effective Date cannot be less than 01/01/1900 and greater than 06/01/2079.')]]")); } }
        public IWebElement PartBEffectiveDateToolTip { get { return Browser.Wd.FindElement(By.XPath("//*[text()[contains(.,'Part B Effective Date must be a valid date and must be the first day of the Month.')]]")); } }
        public IWebElement PartBEffectiveDateToolTip1 { get { return Browser.Wd.FindElement(By.XPath("//*[text()[contains(.,'Part B Effective Date is not a valid date.')]]")); } }
        public IWebElement PartBEffectiveDateToolTip2 { get { return Browser.Wd.FindElement(By.XPath("//*[text()[contains(.,'Part B Effective Date cannot be less than 01/01/1900 and greater than 06/01/2079.')]]")); } }
        public IWebElement PartBEffectiveDateToolTip3 { get { return Browser.Wd.FindElement(By.XPath("//*[text()[contains(.,'Part B Effective Date cannot be less than 01/01/1900 and greater than 06/01/2079.')]]")); } }
        public IWebElement MedicareInsurancePartAEffectiveDate { get { return Browser.Wd.FindElement(By.Id("PartAEffectiveDate")); } }
        public IWebElement MedicareInsurancePartBEffectiveDate { get { return Browser.Wd.FindElement(By.Id("PartBEffectiveDate")); } }

        //Special Status Member 
        public IWebElement EGHPMember { get { return Browser.Wd.FindElement(By.Id("EGHP")); } }
        public IWebElement AuthorizedRepresentativeName { get { return Browser.Wd.FindElement(By.Id("AuthorizedRepresentativeName")); } }
        public IWebElement AuthorizedRepresentativeAddress { get { return Browser.Wd.FindElement(By.Id("AuthorizedRepresentativeAddress")); } }
        public IWebElement AuthorizedRepresentativeCity { get { return Browser.Wd.FindElement(By.Id("AuthorizedRepresentativeCity")); } }
        public IWebElement AuthorizedRepresentativePhone { get { return Browser.Wd.FindElement(By.Id("AuthorizedRepresentativePhone")); } }
        public IWebElement AuthorizedRepresentativeState { get { return Browser.Wd.FindElement(By.Id("AuthorizedRepresentativeState")); } }
        public IWebElement AuthorizedRepresentativeZip { get { return Browser.Wd.FindElement(By.Id("AuthorizedRepresentativeZip")); } }
        public IWebElement AuthorizedRepresentativeRelationship { get { return Browser.Wd.FindElement(By.Id("AuthorizedRepresentativeRelationship")); } }
        public IWebElement EmergencyContact { get { return Browser.Wd.FindElement(By.Id("EmergencyContact")); } }
        public IWebElement EmergencyContactPhone { get { return Browser.Wd.FindElement(By.Id("EmergencyContactPhone")); } }
        public IWebElement EmergencyContactRelationship { get { return Browser.Wd.FindElement(By.Id("EmergencyContactRelationship")); } }

        //Attestation Question
        public IWebElement AttestationQuestion { get { return Browser.Wd.FindElement(By.XPath("//select[@id = 'ElectionType']/following-sibling::img")); } }
        public IWebElement AQForm { get { return Browser.Wd.FindElement(By.Id("AttestationQuestionsDialog")); } }
        public IWebElement OKButton { get { return Browser.Wd.FindElement(By.Id("ButtonOk")); } }
    }

    [Binding]
    public class LettersTemplate
    {
        public IWebElement OnDemandLetterTempAddButton { get { return Browser.Wd.FindElement(By.XPath("//kendo-grid-toolbar/a")); } }
        public IWebElement AngularOnDemandLetterTempAddButton { get { return Browser.Wd.FindElement(By.XPath("//*[@id='onDemandLetterResultGrid']/kendo-grid-toolbar/a")); } }
        public IWebElement OnDemandLetterTempTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_gridLetterTemplates")); } }
        public IWebElement AddLetterTempdialogLetterNamedropdown { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlLetterTypes")); } }
        public IWebElement AddLetterTempdialogTCSTemplateIDdropdown { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='templateId_listbox']")); } }
        public IWebElement SaveButton { get { return Browser.Wd.FindElement(By.XPath("//a[contains(@class,'save')]")); } }
        public IWebElement AngularOnDemandSaveButton { get { return Browser.Wd.FindElement(By.XPath("//*[@id='onDemandLetterResultGrid']//table//tr[1]//td[5]/a[2]")); } }
        public IWebElement IsActiveCheckbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cbIsActiveDialog")); } }
        public IWebElement TCSTemplateStaticMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_rfvLetterTemplates")); } }
        public IWebElement OnDemandLetterNamesAddButton { get { return Browser.Wd.FindElement(By.XPath("//a[contains(.,'Add')]")); } }
        public IWebElement OnDemandLetterNamesTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_grdLetterTypes")); } }
        public IWebElement AddLetterNameDialogLetterNameTextBox { get { return Browser.Wd.FindElement(By.Id("letterName")); } }
        public IWebElement EditLetterNameSaveButton { get { return Browser.Wd.FindElement(By.XPath("//span[@class='k-i-check fa fa-floppy-o']/parent::a")); } }
        public IWebElement AngularEditLetterNameSaveButton { get { return Browser.Wd.FindElement(By.XPath("//*[@id='onDemandLetterResultGrid']/div/kendo-grid-list/div/div[1]/table/tbody/tr[1]/td[5]/a[1]/span")); } }
        public IWebElement LettersDropdown { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlLetters")); } }
        public IWebElement LanguageDropdown { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlLang")); } }
        public IWebElement EffectiveYearDropdown { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='letterTemplate-select-effectiveYear']")); } }
        public IWebElement PlanIDDropdown { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='letterTemplate-select-planId']")); } }

        public IWebElement OkButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cmdOK")); } }
        public IWebElement TemplateSaveButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_BtnSave")); } }
        public IWebElement LetterTemplateTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_GridView1")); } }
        public IWebElement LetterNameDropdown { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlLetterType")); } }
        public IWebElement LetterQueuepageLetterName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlLetterType")); } }
        public IWebElement AddLetterNameSaveButton { get { return Browser.Wd.FindElement(By.XPath("//span[@class='fas fa-save']/parent::a")); } }
        public IWebElement LetterTemplateRetireMsg { get { return Browser.Wd.FindElement(By.Id("letterTemplateTooltip_tt_active")); } }
        public IWebElement LetterTemplateRetireMsgTmx { get { return Browser.Wd.FindElement(By.Id("adminLettersTooltipId")); } }
        public IWebElement LetterTemplateRetireMsgLbl { get { return Browser.Wd.FindElement(By.XPath("//kendo-tooltip//span[4]")); } }
        public IWebElement EditLetterTemplateIsActivecheckbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_chbIsActiveEdit")); } }
        public IWebElement EditLetterTemplateSavebutton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSaveMap")); } }
        public IWebElement CorrespondenceMsg { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucCorrespondence_lblMessage")); } }
        public IWebElement AdministrationLetters { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_EamNavigation_pnlUserAdmin_ctl03_item")); } }
        public IWebElement LetterTemplates { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_EamNavigation_pnlUserAdmin_ctl03_ctl01_link")); } }
    }

    [Binding]
    public class TC90
    {
        public IWebElement TC90MBI{ get
        {
                return Browser.Wd.FindElement(By.XPath("//input[@placeholder='Add MBI']"));
            }
}

        public IWebElement TC90HIC { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_tbxHic")); } }
        public IWebElement TC90PlanID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlPlans")); } }
        public IWebElement TC90TCDropdown { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlTransactionCodes")); } }
        public IWebElement TC90FirstName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_tbxFirstName")); } }
        public IWebElement TC90MI { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_tbxMiddleInital")); } }
        public IWebElement TC90Surname { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_tbxSurname")); } }
        public IWebElement TC90DOB { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_tbxDateOfBirth")); } }
        public IWebElement TC90Gender { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_tbxGender")); } }
        public IWebElement TC90UpdateDeleteflag { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlFlags")); } }
        public IWebElement TC90POSDrugEditStatus { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlPosDrugEditStatuses")); } }
        public IWebElement TC90NotificationDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dptbxNotificationDate_dateBox")); } }
        public IWebElement TC90TerminationDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dptbxTerminationDate_dateBox")); } }
        public IWebElement TC90ImplementationDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dptbxImplementationDate_dateBox")); } }
        public IWebElement TC90POSDrugEditClass { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlPosDrugEditClasses")); } }
        public IWebElement TC90POSDrugEditCode { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlPosDrugEditCodes")); } }
        public IWebElement TC90SaveButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='tc90-btn-save']")); } }
        public IWebElement TC90StaticMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblMessage")); } }
       
        public IWebElement TC90ResetButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnReset")); } }

        public IWebElement TC90link { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_EamNavigation_pnlTrans_itemTC90_link")); } }
    }

    [Binding]
    public class MembersViewEdit
    {
        public IWebElement MemberViewEditPrimaryRxGrp { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtPrimaryRxGroup_38")); } }
        public IWebElement MemberViewEditPrimaryRxBIN { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtPrimaryBin_36")); } }
        public IWebElement MemberViewEditPrimaryRxPCN { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtPrimaryPCN_37")); } }
        public IWebElement MemberViewEditSalesLocation { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='oecSales-txt-salesLocation']")); } }
        public IWebElement MemberViewEditSecondaryRxPCN { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txt2ndPCN_41")); } }
        public IWebElement MemberViewEditSalesDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtSaleDate")); } }
        public IWebElement MemberViewEditHIC { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='memberInfo-txt-mbi']")); } }
        public IWebElement MemberViewEditSaveButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSave")); } }
        public IWebElement MemberViewEditResponseMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblMsg")); } }
        public IWebElement MemberViewEditIDHistoryTab { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnIDHistory")); } }
        public IWebElement MemberViewEditIDHistoryTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucIDHistory_dgHistory")); } }
        public IWebElement MemberViewEditSearchForHIC { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtSearchHic")); } }
        public IWebElement MemberViewEditGoButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnGo")); } }
        public IWebElement MemberViewEditFirstName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtFName_03")); } }
        public IWebElement MemberViewEditLastName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtLName_02")); } }
        public IWebElement MemberViewEditEffectiveDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtEffDate_14")); } }
        public IWebElement MemberViewEditResidenceAddress1 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtPAdd1")); } }
        public IWebElement MemberViewEditResidenceAddress2 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtPAdd2")); } }
        public IWebElement MemberViewEditResidenceCity { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtPCity")); } }
        public IWebElement MemberViewEditResidenceState { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtPState")); } }
        public IWebElement MemberViewEditResidenceZip { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtPZip")); } }
        public IWebElement MemberViewEditResidenceCounty { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_ddlCounty")); } }
        public IWebElement MemberViewEditResidenceSCC { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtScc")); } }
        public IWebElement MemberViewEditMailingAddress1 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtMAdd1")); } }
        public IWebElement MemberViewEditMailingAddress2 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtMAdd2")); } }
        public IWebElement MemberViewEditMailingCity { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtMCity")); } }
        public IWebElement MemberViewEditMailingState { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtMState")); } }
        public IWebElement MemberViewEditMailingZip { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtMZip")); } }
        public IWebElement MemberViewEditResidenceInvalidCounty { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtCountyForInvalidZip")); } }
        public IWebElement IPAGroupID { get { return Browser.Wd.FindElement(By.Name("lnk_IPA_Lookup")); } }
        public IWebElement IPAGroupID1 { get { return Browser.Wd.FindElement(By.XPath("//a[@test-id='provider-a-IpaLookup']")); } }
        public IWebElement PCPID { get { return Browser.Wd.FindElement(By.Name("lnk_PCP_Lookup")); } }
        public IWebElement MemberViewEditMailingModAddress1 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtPAdd1")); } }
        public IWebElement MemberViewEditRXID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtRxID_39")); } }
        public IWebElement MemberViewEditViewAction { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lnk_AddAction")); } }
        public IWebElement NotesScreenAddNewAction { get { return Browser.Wd.FindElement(By.Id("Notes1_lnk_AddAction")); } }
        public IWebElement NewActionTextArea { get { return Browser.Wd.FindElement(By.Id("txtAction")); } }
        public IWebElement NewActionDueDate { get { return Browser.Wd.FindElement(By.Id("txtDueDate")); } }
        public IWebElement NewActionAddbutton { get { return Browser.Wd.FindElement(By.Id("cmdAdd")); } }
        public IWebElement NewActionClosebutton { get { return Browser.Wd.FindElement(By.Name("cmdClose")); } }
        //public IWebElement NewNoteCloseButton { get { return Browser.Wd.FindElement(By.Id("cmd_Close")); } }
        public IWebElement NewNoteCloseButton { get { return Browser.Wd.FindElement(By.Id("cmd_Close")); } }
        public IWebElement NotesScreenClosebutton { get { return Browser.Wd.FindElement(By.Id("Notes1_cmdSearch")); } }
        public IWebElement ActionTable { get { return Browser.Wd.FindElement(By.ClassName("Notes1_dgActions")); } }
        public IWebElement NotesScreenAddNewNote { get { return Browser.Wd.FindElement(By.ClassName("Notes1_lnk_AddNote")); } }
        public IWebElement NewNotesTextArea { get { return Browser.Wd.FindElement(By.Id("description")); } }
        public IWebElement NewNoteAddbutton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='addNotes-btn-add']")); } }
        public IWebElement NewActionAddbutton1 { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='addNotes-btn-add']")); } }
        public IWebElement NotesTable { get { return Browser.Wd.FindElement(By.ClassName("Notes1_dgNotes")); } }
        public IWebElement NoteImageButton { get { return Browser.Wd.FindElement(By.XPath("//span[@class='fas fa-plus-circle']")); } }
        public IWebElement ViewNoteButton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='memberInfo-btn-viewNotes']")); } }
        public IWebElement ViewNoteTextbox { get { return Browser.Wd.FindElement(By.Id("txtView")); } }
        public IWebElement ViewNoteCloseButton { get { return Browser.Wd.FindElement(By.CssSelector("input[name='cmdClose']")); } }
        public IWebElement AddNoteImageButton { get { return Browser.Wd.FindElement(By.CssSelector("#Notes1_lnk_AddNote>img")); } }
        public IWebElement ViewAttachment { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_memberDocumentsButton")); } }
        public IWebElement MemberDocAttachment { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_memberDocuments_attachButton")); } }
        public IWebElement MemberDocClose { get { return Browser.Wd.FindElement(By.XPath("//*[@id='eamDialog']/div[1]/span[2]")); } }
        public IWebElement MemberDocAttachTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_memberDocuments_MemberDocumentsGrid_ctl00")); } }
        public IWebElement AttachDocBrowse { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDocuments-upload-fileUpload']")); } }
        //public IWebElement AttachDocBrowse { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_memberDocuments_attachDocumentDialog_mbrDocUploadfile0")); } }
        public IWebElement AttachDocDesc { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDocuments-span-description']")); } }
        public IWebElement AttachDocAdd { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberDocuments-btn-upload']")); } }
        public IWebElement AttachDocUpload { get { return Browser.Wd.FindElement(By.XPath("//button[contains(.,'Upload')]")); } }
        public IWebElement AttachDocClose { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_memberDocuments_attachDocumentDialog_closeButton")); } }
        public IWebElement AttachDocDocumentURL { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_memberDocuments_attachDocumentDialog_mbrDocUploadfile0")); } }
        public IWebElement UploadFileMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_memberDocuments_attachDocumentDialog_uploadMessageBoxDialog_messageText")); } }
        public IWebElement UploadFileClose { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_memberDocuments_attachDocumentDialog_uploadMessageBoxDialog_closeButton")); } }
        public IWebElement MemberElectionType { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboElections")); } }
        public IWebElement MemberViewEditSCC { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_scc_id")); } }
        public IWebElement MemberViewEditCountyName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtCountyName_44")); } }
        public IWebElement MemberViewEditViewNoteButton { get { return Browser.Wd.FindElement(By.XPath("(//a[contains(@class,'View')])[1]")); } }
    }

    [Binding]
    public class AdministrationMMP
    {
        public IWebElement MMPState { get { return Browser.Wd.FindElement(By.Id("ddlMmpStatus")); } }
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.Id("ddlPlans")); } }
        public IWebElement PBP { get { return Browser.Wd.FindElement(By.Id("ddlPlanPbp")); } }
        public IWebElement TransactionCode { get { return Browser.Wd.FindElement(By.Id("ddlTransactionCode")); } }
        public IWebElement TransactionStatus { get { return Browser.Wd.FindElement(By.Id("ddlTransactionStatus")); } }
        public IWebElement TRC { get { return Browser.Wd.FindElement(By.Id("ddlTrc")); } }
        public IWebElement EffectiveDate { get { return Browser.Wd.FindElement(By.Id("dtEffDate")); } }
        public IWebElement EffectiveDateCalendar { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_vMmpStateTransactions_uc_dpEffDate_dateIcon")); } }
        public IWebElement TerminationDate { get { return Browser.Wd.FindElement(By.Id("dtTerminationDate")); } }
        public IWebElement TerminationDateCalendar { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_vMmpStateTransactions_uc_dpTermDate_dateIcon")); } }
        public IWebElement Save { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_vMmpStateTransactions_uc_btnSave")); } }
        public IWebElement Add { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='mmpManagement-btn-add']")); } }
        public IWebElement Reset { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='mmpManagement-btn-reset']")); } }
        public IWebElement ParametersTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_vMmpStateTransactions_uc_grdMmpStateTransactions")); } }
        public IWebElement DeleteThisRuleOkButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_vMmpStateTransactions_uc_confirmationDialog_acceptButton")); } }
        public IWebElement RuleMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ruleMessage")); } }
        public IWebElement StaticMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_vMmpStateTransactions_uc_lblMessage")); } }
        public IWebElement StaticMessage2 { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_vMmpStateTransactions_uc_propMessage")); } }
        public IWebElement DeleteRuleMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_vMmpStateTransactions_uc_confirmationDialog_messageText")); } }
        
    }

    [Binding]
    public class AdministrationEditLISInformation
    {
        public IWebElement HICNumber { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='lisInformation-input-mbi']")); } }
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPlan")); } }
        public IWebElement Search { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='lisInformation-btn-search']")); } }
        public IWebElement LISLevel { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='lisLevel_listbox']")); } }
        public IWebElement CoPayCat { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='coPayCat_listbox']")); } }
        public IWebElement StartDate { get { return Browser.Wd.FindElement(By.Id("startDate")); } }
        public IWebElement EndDate { get { return Browser.Wd.FindElement(By.Id("endDate")); } }
        public IWebElement LISType { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='lisType_listbox']")); } }
        public IWebElement Source { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='lisSource_listbox']")); } }
        public IWebElement UpdateLISType { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='lisType_listbox']")); } }
        public IWebElement UpdateSource { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='lisSource_listbox']")); } }
        public IWebElement Valid { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='lisValidText_listbox']")); } }
        public IWebElement Current { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='lisCurrent_listbox']")); } }
        public IWebElement Save { get { return Browser.Wd.FindElement(By.XPath("//span[@class='k-i-check fa fa-floppy-o']/parent::a")); } }
        public IWebElement LISTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_GV_EditLIS")); } }
        public IWebElement Update { get { return Browser.Wd.FindElement(By.XPath("//span[@class='k-i-check fa fa-floppy-o']/parent::a")); } }
        public IWebElement Delete { get { return Browser.Wd.FindElement(By.XPath("(//span[@class='fa fa-trash fa fa-trash']/parent::a)[1]")); } }
        public IWebElement StaticMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblMsg")); } }

        //Definitions for fields in selected for edit row in the LIS table. Note: only one row should be selected
        public IWebElement EditLISLevel { get { return LISTable.FindElement(By.XPath("//select[contains(@id, '_dd_SubSidyLevel_grid')]")); } }
        public IWebElement EditCoPayCat { get { return Browser.Wd.FindElement(By.XPath("//select[contains(@id, '_dd_CoPayCat_grid')]")); } }
        public IWebElement EditStartDate { get { return Browser.Wd.FindElement(By.XPath("//input[contains(@id, '_txtStartDate_grid')]")); } }
        public IWebElement EditEndDate { get { return Browser.Wd.FindElement(By.XPath("//input[contains(@id, '_txtEnddate_grid')]")); } }
        public IWebElement EditLISType { get { return Browser.Wd.FindElement(By.XPath("//select[contains(@id, '_dd_LISType_grid')]")); } }
        public IWebElement EditSource { get { return Browser.Wd.FindElement(By.XPath("//select[contains(@id, '_dd_Source')]")); } }
        public IWebElement EditValid { get { return Browser.Wd.FindElement(By.XPath("//select[contains(@id, '_dd_Valid_grid')]")); } }
        public IWebElement EditCurrent { get { return Browser.Wd.FindElement(By.XPath("//select[contains(@id, '_dd_Current_grid')]")); } }

    }

    [Binding]
    public class AdministrationExportSession
    {
        public IWebElement SessionTable { get { return Browser.Wd.FindElement(By.XPath("//table[contains(@id, 'GridViewSession')]")); } }
        public IWebElement FirstDeleteIcon { get { return Browser.Wd.FindElement(By.XPath("//input[contains(@src, 'icon_delete.gif')][1]")); } }
        public By DeleteIconBy { get { return By.XPath("//input[contains(@src, 'icon_delete.gif')]"); } }

    }

    [Binding]
    public class AdministrationPlanDefinedFieldsPlan5StarStatus
    {
        public IWebElement Plan5StarStatusTabLink { get { return Browser.Wd.FindElement(By.LinkText("Plan 5Star Status")); } }
        public IWebElement PlanStatusTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_GridPlan")); } }
        public IWebElement UpdateButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnUpdateplan")); } }
    }

    [Binding]
    public class AdministrationPlanDefinedFieldsOEVLetter
    {

        public IWebElement OEVLetterConfiguration { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OEVLetterConfiguration_switchConfigBtn")); } }
        public IWebElement ChangePBP { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OEVLetterConfiguration_changePbpChkBox")); } }
        public IWebElement EGHP { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OEVLetterConfiguration_eghpChkBox")); } }
        public IWebElement PassBEQStatus { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OEVLetterConfiguration_passBeqChkBox")); } }
        public IWebElement Save { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OEVLetterConfiguration_saveConfigBtn")); } }
        public IWebElement OEVLetterConfigurationAnchor { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OEVLetterConfiguration_switchConfigBtn_anchor")); } }
        public IWebElement ChangePBPAnchor { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OEVLetterConfiguration_changePbpChkBox_anchor")); } }
        public IWebElement EGHPAnchor { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OEVLetterConfiguration_eghpChkBox_anchor")); } }
        public IWebElement PassBEQStatusAnchor { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OEVLetterConfiguration_passBeqChkBox_anchor")); } }

    }
    [Binding]
    public class AdministrationPlanDefinedFields
    {
        public IWebElement MembersPlan1Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Label11")); } }
        public IWebElement MembersPlan2Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Label12")); } }
        public IWebElement MembersPlan3Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Label13")); } }
        public IWebElement MembersPlan4Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Label14")); } }
        public IWebElement MembersPlan5Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Label15")); } }
        public IWebElement MembersPlan6Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Label16")); } }
        public IWebElement MembersPlan7Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Label17")); } }
        public IWebElement MembersPlan8Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Label18")); } }
        public IWebElement MembersPlan9Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Label19")); } }
        public IWebElement MembersPlan10Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Label20")); } }

        public IWebElement MembersPlan1Value { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_TextBox11")); } }
        public IWebElement MembersPlan2Value { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_TextBox12")); } }
        public IWebElement MembersPlan3Value { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_TextBox13")); } }
        public IWebElement MembersPlan4Value { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_TextBox14")); } }
        public IWebElement MembersPlan5Value { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_TextBox15")); } }
        public IWebElement MembersPlan6Value { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_TextBox16")); } }
        public IWebElement MembersPlan7Value { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_TextBox17")); } }
        public IWebElement MembersPlan8Value { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_TextBox18")); } }
        public IWebElement MembersPlan9Value { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_TextBox19")); } }
        public IWebElement MembersPlan10Value { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_TextBox20")); } }
        public IWebElement SaveMembersFieldsButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnMemberSave")); } }
        public IWebElement TransactionsPlan1Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Label1")); } }
        public IWebElement TransactionsPlan2Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Label2")); } }
        public IWebElement TransactionsPlan3Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Label3")); } }
        public IWebElement TransactionsPlan4Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Label4")); } }
        public IWebElement TransactionsPlan5Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Label5")); } }
        public IWebElement TransactionsPlan6Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Label6")); } }
        public IWebElement TransactionsPlan7Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Label7")); } }
        public IWebElement TransactionsPlan8Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Label8")); } }
        public IWebElement TransactionsPlan9Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Label9")); } }
        public IWebElement TransactionsPlan10Label { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_Label10")); } }

        public IWebElement TransactionsPlan1Value { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_TextBox1")); } }
        public IWebElement TransactionsPlan2Value { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_TextBox2")); } }
        public IWebElement TransactionsPlan3Value { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_TextBox3")); } }
        public IWebElement TransactionsPlan4Value { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_TextBox4")); } }
        public IWebElement TransactionsPlan5Value { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_TextBox5")); } }
        public IWebElement TransactionsPlan6Value { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_TextBox6")); } }
        public IWebElement TransactionsPlan7Value { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_TextBox7")); } }
        public IWebElement TransactionsPlan8Value { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_TextBox8")); } }
        public IWebElement TransactionsPlan9Value { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_TextBox9")); } }
        public IWebElement TransactionsPlan10Value { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_TextBox10")); } }

        public IWebElement SaveTransactionsFieldsButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnTransSave")); } }

        public IWebElement StaticMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblmsg")); } }

        //NL rows below should be commented as separate class AdministrationPlanDefinedFieldsTabDisenrollment is used for Disenrollment TAB
        public IWebElement DisenrollDiv { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_RadPageView10")); } }
        public IWebElement DisenrollMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblDisenroll")); } }
        public IWebElement DisenrollReasonTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_GridDisenroll")); } }

    }
    [Binding]
    public class AdministrationPlanDefinedFieldsTabDisenrollment
    {
        public IWebElement DisenrollmentTabLink { get { return Browser.Wd.FindElement(By.LinkText("Disenrollment")); } }

        public IWebElement StaticMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblDisenroll")); } }

        public IWebElement DisenrollCode { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtDisenrollCode")); } }
        public IWebElement MapTo { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddDisenrolMapTo")); } }
        public IWebElement Description { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtDescrp")); } }
        public IWebElement Save { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnDisenrolSave")); } }
        public IWebElement Table { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_GridDisenroll")); } }
    }
    [Binding]
    public class AdministrationPlanDefinedFieldsTabLanguage
    {
        public IWebElement LanguageTabLink { get { return Browser.Wd.FindElement(By.LinkText("Language")); } }
        public IWebElement Code { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtlangCode")); } }
        public IWebElement Language { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtLang")); } }
        public IWebElement Save { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnlangSave")); } }
        public IWebElement LanguageTabTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_GridLanguage")); } }
        public IWebElement LanguageStaticLabelParent { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_RadPageView2")); } }
        public IWebElement LanguageMessageText { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblmsgLanguage")); } }
    }
    [Binding]
    public class AdministrationPlanDefinedFieldsTabRelationship
    {
        public IWebElement RelationshipTabLink { get { return Browser.Wd.FindElement(By.LinkText("Relationship")); } }
        public IWebElement RelationCode { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtRelationCode")); } }
        public IWebElement Relationship { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtRelationShip")); } }
        public IWebElement Save { get { return Browser.Wd.FindElement(By.XPath("//table//input[@id='ctl00_ctl00_MainMasterContent_MainContent_btnRelationShipSave']")); } }
        public IWebElement RelationshipTabTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_GridRelationship")); } }
        public IWebElement RelationshipStaticLabelParent { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_RadPageView3")); } }
        public IWebElement RelationshipMessageText { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblmsgRelationship")); } }
    }
    [Binding]
    public class AdministrationPlanDefinedFieldsTabSalesRep
    {
        public IWebElement SalesRepTabLink { get { return Browser.Wd.FindElement(By.LinkText("Sales Rep")); } }
        public IWebElement RepID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtRepID")); } }
        public IWebElement RepName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtRepName")); } }
        public IWebElement Save { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSaveRep")); } }
        public IWebElement SalesRepTabTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_gridSalesRep")); } }
        public IWebElement SalesRepStaticLabelParent { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_RadPageView7")); } }
        public IWebElement SalesRepMessageText { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblSalesRep")); } }
    }
    [Binding]
    public class AdministrationPlanDefinedFieldsTabSpanTypes
    {
        public IWebElement SpanTypesTabLink { get { return Browser.Wd.FindElement(By.LinkText("Span Types")); } }
        public IWebElement SpanType { get { return Browser.Wd.FindElement(By.XPath("//input[@id='ctl00_ctl00_MainMasterContent_MainContent_txtSpanType']")); } }
        public IWebElement Save { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSpanTypeSave")); } }
        public IWebElement SpanTypesTabTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_gridSpanTypes")); } }
        public IWebElement SpanTypesStaticLabelParent { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_RadPageView8")); } }
        public IWebElement SpanTypesMessageText { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblSpanType")); } }
        public IWebElement SpanTypesEditTextbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_gridSpanTypes_ctl02_txtSpanTypeEdit")); } }
        public IWebElement SpanTypesUpdateImageButton { get { return Browser.Wd.FindElement(By.Name("ctl00$ctl00$MainMasterContent$MainContent$gridSpanTypes$ctl02$ctl00")); } }

    }
    [Binding]
    public class AdministrationPlanDefinedFieldsTabSpanConfig
    {
        public IWebElement PlanId { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_SNPConfiguration_planIdsDdl")); } }
        public IWebElement SNPAuditPlanId { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_SNPConfiguration_snpConfigAuditDialog_snpConfigHistoryGrid_ctl00_ctl02_ctl02_planIdFilterComboBox")); } }
        public IWebElement SNPAuditPlanIdDropDown { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_SNPConfiguration_snpConfigAuditDialog_snpConfigHistoryGrid_ctl00_ctl02_ctl02_planIdFilterComboBox_DropDown")); } }
        public IWebElement PBP { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_SNPConfiguration_pbpDdl")); } }
        public IWebElement SNPType { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_SNPConfiguration_snpTypesDdl")); } }
        public IWebElement ChronicType { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_SNPConfiguration_snpChronicTypesDdl")); } }
        public IWebElement ChronicTypeAll { get { return Browser.Wd.FindElement(By.ClassName("rlbCheckAllItemsCheckBox")); } }
        public IWebElement SelectChronicTypeMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_SNPConfiguration_ctl01")); } }
        public IWebElement State { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_SNPConfiguration_snpStateDdl")); } }
        public IWebElement MonthsOfEligibility { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_SNPConfiguration_monthsOfEligibility")); } }
        public IWebElement ESRD { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_SNPConfiguration_esrdChkBox")); } }
        public IWebElement Save { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_SNPConfiguration_saveBtn")); } }
        public IWebElement Audit { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_SNPConfiguration_snpAuditBtn")); } }
        public IWebElement SomeValueNotSelected { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_SNPConfiguration_ctl02")); } }
        public IWebElement ViewSNPConfigurations { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_SNPConfiguration_snpGrid")); } }
        public IWebElement SNPConfigurationHistory { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_SNPConfiguration_snpConfigAuditDialog_snpConfigHistoryGrid")); } }


    }

    [Binding]
    public class AdministrationPlanDefinedFieldsTabContact
    {
        public IWebElement ContactTabLink { get { return Browser.Wd.FindElement(By.LinkText("Contact")); } }
        public IWebElement ResponsRelation { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_cboResponsRel")); } }
    }

    [Binding]
    public class AdministrationPlanDefinedFieldsTabGroups
    {
        public IWebElement GroupsTabLink { get { return Browser.Wd.FindElement(By.LinkText("Groups")); } }

        public IWebElement StaticMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblGroups")); } }

        public IWebElement GroupsList { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ListGroupsAdd")); } }
        public IWebElement SubGroupsList { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ListSubGroupAdd")); } }
        public IWebElement ClassesList { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ListClasses")); } }

        public IWebElement ActiveGroupLink { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_LinkActiveGroup")); } }
        public IWebElement InactiveGroupLink { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_LinkInActiveGroup")); } }
        public IWebElement ActiveSubGroupLink { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_LinkActiveSubGroup")); } }
        public IWebElement InactiveSubGroupLink { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_LinkInActiveSubGroup")); } }
        public IWebElement ActiveClassesLink { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_LinkActiveClasses")); } }
        public IWebElement InactiveClassesLink { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_LinkInActiveClasses")); } }

        public IWebElement InactivateGroupButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnInactiveGroup")); } }
        public IWebElement ActivateGroupButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnActivGroup")); } }
        public IWebElement InactivateSubGroupButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnInactiveSubGroup")); } }
        public IWebElement ActivateSubGroupButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnActiveSubGroup")); } }
        public IWebElement InactivateClassesButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnInactiveClasses")); } }
        public IWebElement ActivateClassesButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnActiveClasses")); } }

        public IWebElement GRGRID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtGrgrID")); } }
        public IWebElement GroupName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtGroupName")); } }
        public IWebElement AddGroupButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnGrpAdd")); } }
        public IWebElement SGSGID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtSgSgID")); } }
        public IWebElement SubGroupName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtSGName")); } }
        public IWebElement AddSubGroupButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSubGroupAdd")); } }
        public IWebElement CSCSID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtCSCSId")); } }
        public IWebElement ClassName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtNameClasses")); } }
        public IWebElement AddClassButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnAddClasses")); } }
    }

    [Binding]
    public class AdministrationAuditingConfiguration
    {
        public IWebElement ActivityTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_rgMasterTable")); } }
        public IWebElement SaveButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ctl00_MainContent_btnSave")); } }
        public IWebElement ClearButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ctl00_MainContent_btnClear")); } }
        public IWebElement ViewHistoryButton { get { return Browser.Wd.FindElement(By.Name("ctl00$MainContent$btnAuditHistory")); } }
        public IWebElement StaticMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_activeActionMessageContainer")); } }
        public IWebElement AuditTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_rgrdActivities_ctl00")); } }
       

    }

    [Binding]
    public class AdministrationPlanDefinedFieldsOOATab
    {
        public IWebElement ViewOOAStatus1
        {
            get
            {
                return Browser.Wd.FindElement(By.XPath("//div[@test-id='possibleOoaStatus-grid-possibleOoaStatus']"));
            }
        }
        public IWebElement OOALink { get { return Browser.Wd.FindElement(By.LinkText("OOA")); } }
        public IWebElement ReportStatus { get { return Browser.Wd.FindElement(By.Id("ooaStatusesMessageContainer")); } }
        public IWebElement NewStatus { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OutOfAreaConfiguration_statusesConfigView_uc_newStatusTxtBox")); } }
        public IWebElement AddStatus { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OutOfAreaConfiguration_statusesConfigView_uc_addNewStatusBtn")); } }
        public IWebElement ViewOOAStatus { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OutOfAreaConfiguration_statusesConfigView_uc_statusesGrid_ctl00")); } }
        public IWebElement ChangesSaved { get { return Browser.Wd.FindElement(By.LinkText("Changes saved successfully.")); } }
        public IWebElement PlanId { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OutOfAreaConfiguration_planConfigView_uc_dropDownPlanIdsOOA")); } }
        public IWebElement DisEnrollmentMonths { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OutOfAreaConfiguration_planConfigView_uc_dropDownDisenrOOA")); } }
        public IWebElement DisEnrollmentMonthsLabel { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OutOfAreaConfiguration_planConfigView_uc_lblDisenrolMonths")); } }
        public IWebElement ContinuationArea { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OutOfAreaConfiguration_planConfigView_uc_cbContinuationArea")); } }
        public IWebElement Travellers { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OutOfAreaConfiguration_planConfigView_uc_cbTravelers")); } }
        public IWebElement ICEPConversion { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OutOfAreaConfiguration_planConfigView_uc_cbICEP")); } }
        public IWebElement Update { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OutOfAreaConfiguration_planConfigView_uc_btnUpdateOOA")); } }
        public IWebElement OutofAreaGrid { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OutOfAreaConfiguration_planConfigView_uc_allOOASettingsGrid_ctl00")); } }
        public IWebElement PossibleOOAStatus { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OutOfAreaConfiguration_statusesConfigView_uc_statusesGrid")); } }
        public IWebElement PossibleOOANewStatus { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OutOfAreaConfiguration_statusesConfigView_uc_statusesGrid_ctl00_ctl04_ctl00")); } }
        public IWebElement PossibleOOACompleteStatus { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OutOfAreaConfiguration_statusesConfigView_uc_statusesGrid_ctl00_ctl05_ctl00")); } }
        public IWebElement ContinuousAreaCheckbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OutOfAreaConfiguration_planConfigView_uc_cbContinuationArea")); } }
        public IWebElement TravelersCheckbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OutOfAreaConfiguration_planConfigView_uc_cbTravelers")); } }
        public IWebElement ICEPConversionCheckbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_OutOfAreaConfiguration_planConfigView_uc_cbICEP")); } }
    }

    [Binding]
    public class UserAdministrationCRUDUser
    {
        public IWebElement ClientListDropdown { get { return Browser.Wd.FindElement(By.Id("ClientList")); } }
        public IWebElement UserID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='AddUser-Input-LoginName']")); } }
        //public IWebElement UserID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='AddUser-Input-LoginName']")); } }
        public IWebElement AngularLoginName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='edit-user-input-login-name']")); } }
        public IWebElement DisplayName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='AddUser-Input-DisplayName']")); } }
        public IWebElement EAM_LoginName { get { return Browser.Wd.FindElement(By.XPath("//*[text()[contains(.,'Logged in as')]]")); } }
        public IWebElement EAM_DisplayName { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='header-txt-profileInfo']")); } }
        public IWebElement Username { get { return Browser.Wd.FindElement(By.Id("txtLogin")); } }
        public IWebElement Searchbutton { get { return Browser.Wd.FindElement(By.Id("cmdSearch")); } }
        //public IWebElement Password { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='AddUser-Input-Password']")); } }
        public IWebElement Password { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='AddUser-Input-Password']")); } }
        //public IWebElement ConfirmPassword { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='AddUser-Input-ConfirmPassword']")); } }
        public IWebElement AngularPassword { get { return Browser.Wd.FindElement(By.CssSelector("//label[contains(.,'New Password')]/parent::div//input")); } }
        public IWebElement ConfirmPassword { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='AddUser-Input-ConfirmPassword']")); } }
        public IWebElement AngularConfirmPassword { get { return Browser.Wd.FindElement(By.CssSelector("//label[contains(.'Confirm Password')]/parent::div//input")); } }
        public IWebElement LastName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='AddUser-Input-LastName']")); } }
        public IWebElement AngularLastName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='edit-user-input-last-name']")); } }
        public IWebElement email { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='AddUser-Input-email']")); } }
        public IWebElement AngularEmail { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='EmailUser-Input-email']")); } }
        public IWebElement FirstName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='AddUser-Input-FirstName']")); } }
        public IWebElement AngularFirstName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='edit-user-input-first-name']")); } }
        public IWebElement MODFirstName { get { return Browser.Wd.FindElement(By.XPath("//input[@ng-model='firstName']")); } }
        public IWebElement UserList_ExpandBtn { get { return Browser.Wd.FindElement(By.XPath("//*[@aria-label='Expand'][1]")); } }

        public IWebElement MODLastName { get { return Browser.Wd.FindElement(By.XPath("//input[@ng-model='lastName']")); } }
        public IWebElement MODemail { get { return Browser.Wd.FindElement(By.XPath("//input[@ng-model='email']")); } }
        //public IWebElement LastName { get { return Browser.Wd.FindElement(By.Id("UserLastNameTextBox")); } }
        //public IWebElement FirstName { get { return Browser.Wd.FindElement(By.Id("UserFirstNameTextBox")); } }
        public IWebElement Active { get { return Browser.Wd.FindElement(By.Id("cboActive")); } }
        public IWebElement PermissionsTable { get { return Browser.Wd.FindElement(By.Id("AssignedAppsGridView")); } }
        public IWebElement AddUser { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='AddUser-Button-Add']")); } }
        public IWebElement AngularAddUser { get { return Browser.Wd.FindElement(By.XPath("//*[@id='userDetailsFrm']/div/div[9]/div/span[2]/button")); } }
        public IWebElement DialogOKButton { get { return Browser.Wd.FindElement(By.Id("")); } }
        public IWebElement UpdateUserButton { get { return Browser.Wd.FindElement(By.Id("EditUserButton")); } }

              public IWebElement UpdateExistingUserButton { get { return Browser.Wd.FindElement(By.XPath("(//button[contains(.,'UPDATE')])[1]")); } }
        
        public IWebElement TmsServerList { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='AddUser-Select-Role']")); } }
        // public IWebElement TmsServerList { get { return Browser.Wd.FindElement(By.Id("ClientList")); } }
        public IWebElement TC90DropDown { get { return Browser.Wd.FindElement(By.Id("AssignedAppsGridView_ctl10_ucPermissionAddList_imgBtnOpen")); } }
        public IWebElement TC90Checkbox { get { return Browser.Wd.FindElement(By.Id("AssignedAppsGridView_ctl10_ucPermissionAddList_DDList_1")); } }
        public IWebElement AdministrationPermissionsTable { get { return Browser.Wd.FindElement(By.Id("AssignedAppsGridView")); } }
        public IWebElement TC90DropDownList { get { return Browser.Wd.FindElement(By.Id("AssignedAppsGridView_ctl108_ucPermissionAddList_DDList")); } }
        public IWebElement TC90 { get { return Browser.Wd.FindElement(By.Id("AssignedAppsGridView_ctl03_AllowTC90")); } }
        public IWebElement UserTC90 { get { return Browser.Wd.FindElement(By.Id("AssignedAppsGridView_ctl04_AllowTC90")); } }
        public IWebElement Permissionsdropdown { get { return Browser.Wd.FindElement(By.Id("AssignedAppsGridView_ctl08_ucPermissionAddList_imgBtnOpen")); } }
        public IWebElement PermissionNonecheckbox { get { return Browser.Wd.FindElement(By.Id("AssignedAppsGridView_ctl08_ucPermissionAddList_DDList_0")); } }
        public IWebElement PermissionTC90checkbox { get { return Browser.Wd.FindElement(By.Id("AssignedAppsGridView_ctl08_ucPermissionAddList_DDList_1")); } }
        public IWebElement PermissionCrossButton { get { return Browser.Wd.FindElement(By.Id("AssignedAppsGridView_ctl08_ucPermissionAddList_imgBtnClose")); } }
        public IWebElement EditUserDropdown { get { return Browser.Wd.FindElement(By.Id("EditUserAssignedAppsGridView_ctl08_ucPermissionEditList_imgBtnOpen")); } }
        public IWebElement EditUserTC90 { get { return Browser.Wd.FindElement(By.Id("EditUserAssignedAppsGridView_ctl08_ucPermissionEditList_DDList_2")); } }
        public IWebElement EditUserCrossButton { get { return Browser.Wd.FindElement(By.Id("EditUserAssignedAppsGridView_ctl08_ucPermissionEditList_imgBtnClose")); } }
        public IWebElement EditUserStatusOverride { get { return Browser.Wd.FindElement(By.Id("EditUserAssignedAppsGridView_ctl08_ucPermissionEditList_DDList_1")); } }
        public IWebElement EditUserFirstName { get { return Browser.Wd.FindElement(By.Id("EditUserFirstNameTextBox")); } }
        public IWebElement EditUserLastName { get { return Browser.Wd.FindElement(By.Id("EditUserLastNameTextBox")); } }
        public IWebElement EditApplicationPermission { get { return Browser.Wd.FindElement(By.Id("EditUserAssignedAppsGridView")); } }
        public IWebElement AddNewRecordButton { get { return Browser.Wd.FindElement(By.XPath("//*[@id='applicationAndRolesGrid']/div[1]/a")); } }
        public IWebElement ApplicationDropdown { get { return Browser.Wd.FindElement(By.CssSelector("")); } }
        public IWebElement RoleNameDropdown { get { return Browser.Wd.FindElement(By.Id("")); } }
        public IWebElement SaveActionButton { get { return Browser.Wd.FindElement(By.Id("")); } }
        public IWebElement DeleteActionButton { get { return Browser.Wd.FindElement(By.Id("")); } }
        public IWebElement EAMRolesDropdown { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='Adduser-Select-EAMRoles']")); } }
        public IWebElement TC90AppCheckbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='AddUser-CheckBox-TC90App']")); } }
        public IWebElement StatusOverrideCheckbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='AddUser-CheckBox-StatusOverride']")); } }
        public IWebElement TC90AppCheckbox_update { get { return Browser.Wd.FindElement(By.CssSelector("[name='tc90appRole']")); } }
        public IWebElement StatusOverrideCheckbox_update { get { return Browser.Wd.FindElement(By.CssSelector("[name='statusoverrideRole']")); } }

        public IWebElement DefaultApplicationDropdown { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='AddUser-Select-DefaultApplicationRequired']")); } }
        //public IWebElement AddNewUser { get { return Browser.Wd.FindElement(By.PartialLinkText("ADD USER")); } }
        public IWebElement AddNewUser { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='user-btn-addUser']")); } }
        public IWebElement AngularAddNewUser { get { return Browser.Wd.FindElement(By.XPath("//button[contains(.,'ADD USER')]")); } }
        public IWebElement ADDButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='AddUser-Button-Add']")); } }
        public IWebElement LoginNameTextbox { get { return Browser.Wd.FindElement(By.CssSelector("input[test-id='AddUser-Input-LoginName']")); } }
        public IWebElement PasswordTextbox { get { return Browser.Wd.FindElement(By.CssSelector("input[test-id='AddUser-Input-Password']")); } }
        public IWebElement ConfirmPasswordTextbox { get { return Browser.Wd.FindElement(By.CssSelector("input[test-id='AddUser-Input-ConfirmPassword']")); } }
        public IWebElement FirstNameTextbox { get { return Browser.Wd.FindElement(By.CssSelector("input[test-id='AddUser-Input-FirstName']")); } }
        public IWebElement LastNameTextbox { get { return Browser.Wd.FindElement(By.CssSelector("input[test-id='AddUser-Input-LastName']")); } }
        public IWebElement YesRadiobutton { get { return Browser.Wd.FindElement(By.CssSelector("label[for='activeUser']>span")); } }
        public IWebElement NoRadiobutton { get { return Browser.Wd.FindElement(By.CssSelector("label[for='inActiveUser']>span")); } }
        public IWebElement RoleDropdown { get { return Browser.Wd.FindElement(By.CssSelector("select[test-id='AddUser-Select-Role']")); } }
        public IWebElement UserNameFilter { get { return Browser.Wd.FindElement(By.XPath("//*[@data-title='User Name']/a[@class='k-grid-filter']")); } }
        public IWebElement filterForm { get { return Browser.Wd.FindElement(By.XPath(" //*[@title='Show items with value that:']")); } }
        public IWebElement filterValue { get { return Browser.Wd.FindElement(By.XPath("//*[@title='Value']")); } }
        public IWebElement filterButton { get { return Browser.Wd.FindElement(By.XPath("//*[@type='submit']")); } }
        public IWebElement editRoleDropdown { get { return Browser.Wd.FindElement(By.XPath("//*[@data-ng-model='selctedUserRole']")); } }
        public IWebElement editEAMRoleDropdown { get { return Browser.Wd.FindElement(By.XPath("//*[@data-ng-model='selectedEamRole']")); } }
        public IWebElement EditButton { get { return Browser.Wd.FindElement(By.XPath("//*[@class='k-button k-button-icontext small btn btn-link editUser k-grid-customCommand k-grid-Edit']")); } }
        public IWebElement updateButton { get { return Browser.Wd.FindElement(By.XPath("//button[contains(text(),'UPDATE')]")); } }
        public IWebElement ResetPassword { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='addUserTab-tab-changePassword']")); } }
        public IWebElement ResetPwd_NewPassword { get { return Browser.Wd.FindElement(By.XPath("//input[@type='password' and @ng-model='newPassword']")); } }
        public IWebElement ResetPwd_ConfirmPassword { get { return Browser.Wd.FindElement(By.XPath("//input[@type='password' and @ng-model='confirmPassword']")); } }
        public IWebElement UpdatePasswordBtn { get { return Browser.Wd.FindElement(By.XPath("//button[contains(text(),'UPDATE') and @ng-click='changePassword()']")); } }
        public IWebElement UpdatePasswordMessage { get { return Browser.Wd.FindElement(By.XPath("//[contains(text(),'Password changed successfully')]")); } }
        public IWebElement UserManagement_MenuIcon { get { return Browser.Wd.FindElement(By.XPath("//*[@class= 'icon-Administrator_N manuIcons']")); } }
        public IWebElement EnrollReqFormLink { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='transaction-lbl-code']")); } }
        public IWebElement UsersTable { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='users-grid-users']")); } }

    }

    [Binding]
    public class UserAdministrationSearchUser
    {
        public IWebElement Username { get { return Browser.Wd.FindElement(By.Id("txtLogin")); } }
        public IWebElement Search { get { return Browser.Wd.FindElement(By.Id("cmdSearch")); } }
        public IWebElement UserSearchTable { get { return Browser.Wd.FindElement(By.Id("dgUser")); } }
        public IWebElement UserSearchEditButton { get { return Browser.Wd.FindElement(By.CssSelector("#dgUser a>img[alt='Edit']")); } }
        public IWebElement UserIDReadOnly { get { return Browser.Wd.FindElement(By.Id("EditUserIDTextBox")); } }
    }
 
    [Binding]
    public class AdministrationManagePlanSCCViewEdit
    {
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_plans")); } }
        public IWebElement PBP { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_pbps")); } }
        public IWebElement SCC { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_sccs")); } }
        public IWebElement EffectiveDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_effectiveDate_dateBox")); } }
        public IWebElement EndDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_endDate_dateBox")); } }
        public IWebElement Go { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_goButton")); } }
        public IWebElement EditPlanTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_grid")); } }
        public IWebElement Add { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_add")); } }
        public IWebElement Delete { get { return Browser.Wd.FindElement(By.XPath("(//input[@type='checkbox'])[1]")); } }
        public IWebElement PopupPlanID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_plansEdit")); } }
        public IWebElement PopupPBP { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_pbpsEdit")); } }
        public IWebElement PopupSCC { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_sccsEdit")); } }
        public IWebElement PopupEffectiveDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_effectiveDateEdit_dateBox")); } }
        public IWebElement PopupEndDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_endDateEdit_dateBox")); } }
        public IWebElement PopupSave { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_saveButton")); } }
        public IWebElement Popup { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_editUpdatePanel")); } }

    }
    [Binding]
    public class MemberInformation
    {
        public IWebElement AddTransactionDialogTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucCorrespondence_dgMemberTransactions")); } }
        public IWebElement AddTransactionDialogCheckbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucCorrespondence_dgMemberTransactions_ctl02_chbSelectTransaction")); } }
        public IWebElement AddTransactionDialogAddtoQueuebutton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucCorrespondence_btnAddToQueueTrans")); } }
        public IWebElement CorrespondenceTabAddTransactionbutton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucCorrespondence_btnAddTransaction")); } }
        public IWebElement CorrespondenceTabLetterName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucCorrespondence_ddlLetterTypes")); } }
        public IWebElement CorrespondenceTab { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnCorrespondence")); } }
        public IWebElement TransactionsTab { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnTransactions")); } }
        public IWebElement OECSalesTab { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnOECSales")); } }
        public IWebElement TransactionHistoryTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucTransHistory_dgHistory")); } }
        public IWebElement Transaction90HistoryTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_grdTransactionHistory")); } }
        public IWebElement MemberInfoPlanID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPlanID_10")); } }
        public IWebElement MemberInfoPBPID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPBP_08")); } }
        public IWebElement MemberInfoRXID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtRxID_39")); } }
        public IWebElement MemberInfoTransStatus { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtTStatus")); } }
        public IWebElement MemberInfoReplyCode { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtReplyCode")); } }
        public IWebElement MemberInfoReplyDesc { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtReplyDescrip")); } }
        public IWebElement MemberInfoUserModified { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblUserModified")); } }
        public IWebElement TRRResponseDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lbltrrDate")); } }
        public IWebElement DateModified { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblModifiedDate")); } }
        public IWebElement RXBillingTab { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnBilling")); } }
        public IWebElement EmployerGroupNumber { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_empGrpNumber_Input")); } }
        public IWebElement EmployerGroupNumberEditIcon { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_editEmplGroup")); } }
        public IWebElement EmployerGroupNumberDrpDwnArrow { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_empGrpNumber_Arrow")); } }
        public IWebElement EmployerGroupNumberdropdownEmpGRP { get { return Browser.Wd.FindElement(By.XPath("//ul[@class='rcbList']/li//tr/td[1]")); } }
        public IWebElement EmployerGroupNumberTextbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_employerGroup_empGroupNrValue")); } }
        public IWebElement EmployerGroupNameTextbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_employerGroup_employerNameValue")); } }
        public IWebElement EmployerGroupDialogOKButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_employerGroup_okButton")); } }
        public IWebElement EmployerGroupDialogCloseButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_employerGroup_closeButton")); } }

        public IWebElement EmployerGroupName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_txtEmployer")); } }
        public IWebElement ContactTab { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnContact")); } }
        public IWebElement AddressTypeMailing { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_drpAddType1")); } }
        public IWebElement MailingCity { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtPCity")); } }
        public IWebElement EligibilityTab { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnStatus")); } }
        public IWebElement PlanPartDEffDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberStatus_txtPlanPartD")); } }
        public IWebElement PlanPartAEffDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberStatus_txtPlanPartA")); } }
        public IWebElement PlanPartBEffDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberStatus_txtPlanPartB")); } }
        public IWebElement SpansTab { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSpans")); } }
        public IWebElement TRRTab { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnTrrData")); } }
        public IWebElement EFFbutton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberSpans_btnEff")); } }
        public IWebElement PaymentTab { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnPayment")); } }
        public IWebElement PaymentTabAccNumber { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_txtAccNum")); } }
        public IWebElement BankAccTypeDropdown { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_cboBankAccType")); } }
        public IWebElement SpansTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberSpans_dgHistory")); } }
        public IWebElement ProviderTab { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnProvider")); } }
        public IWebElement ProviderFirstName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucProviderInfo_txtPCPFName")); } }
        public IWebElement ProviderLastName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucProviderInfo_txtPCPLName")); } }
        public IWebElement PCPProviderID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucProviderInfo_txtPCPProvid")); } }
        public IWebElement RXBillingPWoption { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_drpPremium")); } }
        public IWebElement PartDOptOut { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPartDOptOut")); } }
        public IWebElement CreditCover { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_cboCreditCov")); } }
        public IWebElement UnCoveredMonths { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_txtUnCovMons")); } }
        public IWebElement RXBillingLEPamount { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_txtLepAmt")); } }
        public IWebElement MemberInfoPWoption { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_drpPremium_18")); } }
        public IWebElement MemberInfoPrimaryRxGroup { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtRxGroup_38")); } }
        public IWebElement MemberInfoPrimaryRxID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtRxID_39")); } }
        public IWebElement MemberInfoPrimaryRxBIN { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtRXBIN_36")); } }
        public IWebElement MemberInfoPrimaryRxPCN { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtRXPCN_37")); } }
        public IWebElement MemberInfoSecondaryRxPCN { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_txt2ndPCN")); } }
        public IWebElement MemberInfoSalesLocation { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucOECSales_txtSalesLocation")); } }
        public IWebElement MemberInfoSecondaryPhone { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtPhone2")); } }
        public IWebElement MemberInfoOECSalesDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucOECSales_txtSalesDate")); } }
        public IWebElement MemberInfoOECSalesInstName { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucOECSales_txtInstName")); } }
        public IWebElement MemberInfoOECSalesInstAddress { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucOECSales_txtInstAddress")); } }
        public IWebElement MemberInfoOECSalesInstPhone { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucOECSales_txtInstPhone")); } }
        public IWebElement MemberInfoRXBillingPWO { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_drpPremium")); } }
        public IWebElement MemberInfoSCC { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_scc_id")); } }
        public IWebElement ContactTabSCC { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtScc")); } }
        public IWebElement MemberInfoCounty { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtCountyName_44")); } }
        public IWebElement ContactTabCounty { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_ddlCounty")); } }
        public IWebElement SpanTabSpanValue { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberSpans_txtValue")); } }
        public IWebElement SpanTabStaticMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberSpans_lblMessage")); } }
        public IWebElement SpanTabSaveButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberSpans_btnSave")); } }
        public IWebElement MemberInfoPageSaveButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSave")); } }
        public IWebElement MemberInfoTerminationDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtTermDate")); } }
        public IWebElement MemberInfoDeathDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtDOD")); } }
        public IWebElement MemberInfoEffectiveDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtEffDate_14")); } }
        public IWebElement SpansPlanID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberSpans_drpPlanID")); } }
        public IWebElement SpansStatusType { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberSpans_drpStatus")); } }
        public IWebElement Spansvalue { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberSpans_txtValue")); } }
        public IWebElement SpansStartDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberSpans_txtStart")); } }
        public IWebElement SpansEndDate { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberSpans_txtEnd")); } }
        public IWebElement SpansSaveButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberSpans_btnAdd")); } }
        public IWebElement AddNewTransactionLink { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucTransHistory_LinkButton1")); } }
        public IWebElement SegmentID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboSegment_99")); } }
        public IWebElement MemberInfoMemberID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtMemberID_43")); } }
        public IWebElement MemberInfoGroup { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboGroup")); } }
        public IWebElement MemberInfoSubGroup { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboSubGroup")); } }
        public IWebElement MemberInfoClass { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboClass")); } }
        public IWebElement OOAIcon { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_iMageButtonOOA")); } }
        public IWebElement OOAAddNewSuspectbutton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_outOfAreaDialog_addNewSuspectButton")); } }
        public IWebElement SuspectStatusDDL { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_outOfAreaDialog_ooaSuspectStatusesDdl")); } }
        public IWebElement OOAContiuningArea { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_outOfAreaDialog_cbContinuingArea")); } }
        public IWebElement OOATravelersVisitors { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_outOfAreaDialog_cbTravelerVisitorsProgram")); } }
        public IWebElement OOAICEPConversion { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_outOfAreaDialog_cbICEPConversion")); } }

        public IWebElement PossibleSCCDisExists { get { return Browser.Wd.FindElement(By.Id("lblPossibleSccDiscrepancy")); } }
        public IWebElement QueuePotentialOOALetter { get { return Browser.Wd.FindElement(By.Id("lblOoaLetter")); } }
        public IWebElement PotentialOutOfArea { get { return Browser.Wd.FindElement(By.Id("lblPotentialOoa")); } }
        public IWebElement Savebutton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_outOfAreaDialog_btnSaveOOA")); } }
        public IWebElement SuspectClosebutton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_outOfAreaDialog_btnClose")); } }
        public IWebElement AlertTooltip { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_outOfAreaDialog_statusErrorImg")); } }
        public IWebElement PotentialAlertTooltip { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_outOfAreaDialog_ImgMessage")); } }
        public IWebElement AlertTooltipTitle { get { return Browser.Wd.FindElement(By.XPath("//span[@class='tooltipTitle']")); } }
        public IWebElement AlertTooltipMsg { get { return Browser.Wd.FindElement(By.XPath("//span[@class='tooltipMessage']")); } }
        public IWebElement HistoryPane { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_outOfAreaDialog_LeftPane")); } }
        public IWebElement HistoricalSuspectsTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_outOfAreaDialog_historicalSuspects_ctl00")); } }
        public IWebElement SusAlertTooltipTitle { get { return Browser.Wd.FindElement(By.XPath("//span[@class='tooltipTitle']")); } }
        public IWebElement SusAlertTooltipMsg { get { return Browser.Wd.FindElement(By.XPath("//span[@class='tooltipMessage']")); } }
        public IWebElement MemberNotPresentMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblreturn")); } }
        public IWebElement SavebuttonTooltip { get { return Browser.Wd.FindElement(By.XPath("//*[@id='ctl00_ctl00_MainMasterContent_MainContent_outOfAreaDialog_btnSaveOOA']")); } }
        //04.22.2016 - Daron - Changing to CSS to see if it gets picked up better.
        //public IWebElement OOAStaticMsg { get { return Browser.Wd.FindElement(By.XPath("//*[@id='messageContainer']/span")); } }
        public IWebElement OOAStaticMsg { get { return Browser.Wd.FindElement(By.CssSelector("div[id=messageContainer]")); } }
        public IWebElement OOAUserModified { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_outOfAreaDialog_txtBoxUser")); } }
        public IWebElement OOADateModified { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_outOfAreaDialog_txtBoxDateModified")); } }

        public IWebElement CorrespondanceTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucCorrespondence_gvCORR")); } }

          }









    [Binding]
    public class AdministrationStatusoverride
    {
        public IWebElement SearchForMemberCheckbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_chkMember")); } }
        public IWebElement NewTransactionStatus { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboTStatus")); } }

        public IWebElement TransactionTable_TransStatus{ get { return Browser.Wd.FindElement(By.XPath("//*[@id='ctl00_ctl00_MainMasterContent_MainContent_dgTrans']/tbody/tr[2]/td[8]")); } }
        public IWebElement SearchForTransactionCheckbox { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_chkTrans")); } }
        public IWebElement SearchForHIC { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtHic")); } }
        public IWebElement SearchButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSearch")); } }
        public IWebElement CancelButton { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='btnCancel']")); } }
        public IWebElement MemberStatus { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboMStatus")); } }
        public IWebElement MemberEditIcon { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='dgMember']/tbody/tr[2]/td[9]/a")); } }
        public IWebElement TransEditIcon { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='dgTrans']/tbody/tr[2]/td[13]/a")); } }
        public IWebElement TransSaveButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSave")); } }
        public IWebElement MemberSaveButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSaveMember")); } }
        public IWebElement ResponseMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblMsg")); } }
        public IWebElement NewMemberID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtNewMemberID")); } }
        public IWebElement StatusOverrideLink { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_EamNavigation_pnlUserAdmin_itemStatusOverride_link")); } }
        public IWebElement MemberSearchTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dgMember")); } }
        public IWebElement TransactionSearchTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dgTrans")); } }
        public IWebElement DisEnrollmentReason { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtDisenrollReason")); } }
        public IWebElement NewPlanID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPlanid")); } }
        public IWebElement NewPBPID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPBP")); } }
        public IWebElement NewRXID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtRxID")); } }
        public IWebElement NewTxnRXID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtTransRxID")); } }
        public IWebElement NewReplyCode { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtReplyCode")); } }
        public IWebElement NewReplyDate { get { return Browser.Wd.FindElement(By.XPath("//input[@id='ctl00_ctl00_MainMasterContent_MainContent_txtRepDate']")); } }
        public IWebElement NewEffectiveDate { get { return Browser.Wd.FindElement(By.XPath("//input[@id='ctl00_ctl00_MainMasterContent_MainContent_txtEffDate']")); } }
        public IWebElement GetFirstTransId { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='ctl00_ctl00_MainMasterContent_MainContent_dgTrans']/tbody/tr[2]/td[3]")); } }


    }


    [Binding]
    public class AdministrationExternalIntegration   
    {
        public IWebElement PageHeaderText { get { return Browser.Wd.FindElement(By.XPath("//div[@class='main-content-header d-flex']/div/div")); } }
        public IWebElement AtrributeType { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_DDLAttributesList")); } }
        public IWebElement EAMProviderSourcebtn { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='externalIntegration-lbl-rdlEam']")); } }
        public IWebElement QNXTProviderSourcebtn { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='externalIntegration-lbl-rdlQnxt']")); } }
        public IWebElement CurrentProviderSourcetxt { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ProviderSource_currentProviderSource")); } }
        public IWebElement QNXTServiceConfigwindow { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='ctl00_ctl00_MainMasterContent_MainContent_ProviderSource_qnxtDataSourceParamsPanel']/div[2]")); } }
        public IWebElement QNXTURL { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ProviderSource_qnxtUrlTextBox")); } }
        public IWebElement QNXTUpdateBtn { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ProviderSource_updateUrlButton")); } }
        public IWebElement QNXTTestConnectionBtn { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ProviderSource_validateButton")); } }
        public IWebElement QNXTTestConnectionpopup { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_externalSettingUpdatePanel")); } }
        public IWebElement QNXTmessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ProviderSource_RequiredFieldValidator1")); } }
        public IWebElement QNXTmessageexpression { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ProviderSource_RegularExpressionValidator1")); } }

    }


    [Binding]
    public class WorkFlowConfiguration
    {
        public IWebElement WFConfigurationName { get { return Browser.Wd.FindElement(By.Id("txtconfigurationName")); } }
        public IWebElement WFConfigurationAppUrl { get { return Browser.Wd.FindElement(By.Id("txtApplicationUrl")); } }
        public IWebElement WFConfigurationServiceUrl { get { return Browser.Wd.FindElement(By.Id("txtServiceEndpointUrl")); } }
        public IWebElement WFConfigurationSaveBtn { get { return Browser.Wd.FindElement(By.XPath("//button[@id='btnSearch']/span")); } }
        public IWebElement WFConfigurationResetBtn { get { return Browser.Wd.FindElement(By.Id("btnReset")); } }
        public IWebElement WFConfigurationUpdateBtn { get { return Browser.Wd.FindElement(By.XPath(".//*[@value='Update']")); } }
        public IWebElement WFConfigurationListTable { get { return Browser.Wd.FindElement(By.Id("ConfigurationList")); } }
        public IWebElement WFConfigurationLink { get { return Browser.Wd.FindElement(By.Id("Navigation1_menuWorkloadConfiguration")); } }
        public IWebElement WFSummaryChart { get { return Browser.Wd.FindElement(By.CssSelector("[id^='dashboard_inventory_panel_summarychart']")); } }
        public IWebElement ReassignButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnReAssign")); } }
        public IWebElement ErrorMessage { get { return Browser.Wd.FindElement(By.CssSelector("[id$='MainMasterContent_MainContent_lblErrorMessage']")); } }
        public IWebElement QueueDropdown { get { return Browser.Wd.FindElement(By.CssSelector("[id$='MainMasterContent_MainContent_modalPopupReassign_C_ddlQueues']")); } }
        public IWebElement RoleDropdown { get { return Browser.Wd.FindElement(By.CssSelector("[id$='MainMasterContent_MainContent_modalPopupReassign_C_ddlRoles']")); } }
        public IWebElement SubmitButton { get { return Browser.Wd.FindElement(By.CssSelector("[id$='MainMasterContent_MainContent_modalPopupReassign_C_btnSubmitReAssign']")); } }
        public IWebElement SearchImageButton { get { return Browser.Wd.FindElement(By.CssSelector("[id$='innerCt']")); } }
        public IWebElement SearchTextbox { get { return Browser.Wd.FindElement(By.CssSelector("[id$='inputEl']")); } }
        public IWebElement SearchButton { get { return Browser.Wd.FindElement(By.CssSelector("[id$='btnIconEl']")); } }
        public IWebElement BEQOthersBar { get { return Browser.Wd.FindElement(By.CssSelector("[id$='ext-sprite-1784']")); } }
        public IWebElement FailedBEQBar { get { return Browser.Wd.FindElement(By.CssSelector("[id$='ext-sprite-1792']")); } }
        public IWebElement EnrlRejectBar { get { return Browser.Wd.FindElement(By.CssSelector("[id$='ext-sprite-1802']")); } }
        public IWebElement NumcmoInitialEnrlBar { get { return Browser.Wd.FindElement(By.CssSelector("[id$='ext-sprite-1788']")); } }
        public IWebElement PFWFCircle { get { return Browser.Wd.FindElement(By.Id("ext-sprite-1865")); } }
        public IWebElement PFWFCircle1 { get { return Browser.Wd.FindElement(By.Id("ext-sprite-1887")); } }
        public IWebElement MessageIDTextbox { get { return Browser.Wd.FindElement(By.Id("messageIdFilter-inputEl")); } }
        public IWebElement PFWFBackButton { get { return Browser.Wd.FindElement(By.Id("button-1037-btnIconEl")); } }
        public IWebElement GridFirstCell { get { return Browser.Wd.FindElement(By.CssSelector(".x-grid-cell-inner")); } }
        public IWebElement PFWFTable { get { return Browser.Wd.FindElement(By.Id("gridview-1064-table")); } }
        public IWebElement PFWFChangePriorityBtn { get { return Browser.Wd.FindElement(By.Id("button-1069-btnIconEl")); } }
        public IWebElement PFWFSetPriority { get { return Browser.Wd.FindElement(By.Id("combo-1689-inputEl")); } }
        public IWebElement PFWFSavePriority { get { return Browser.Wd.FindElement(By.Id("button-1706-btnIconEl")); } }
        public IWebElement PFWFPriorityModal { get { return Browser.Wd.FindElement(By.Id("window-1682_header_hd-textEl")); } }
        public IWebElement PFWFReassignButton { get { return Browser.Wd.FindElement(By.Id("button-1070-btnIconEl")); } }
        public IWebElement PFWFQueueDropdown { get { return Browser.Wd.FindElement(By.Id("combo-1410-inputE")); } }
        public IWebElement PFWFRoleDropdown { get { return Browser.Wd.FindElement(By.Id("combo-1411-inputEl")); } }
        public IWebElement PFWFSaveButton { get { return Browser.Wd.FindElement(By.Id("button-1415")); } }
        public IWebElement PFWFResendAllButton { get { return Browser.Wd.FindElement(By.Id("btnResendAll")); } }
        public IWebElement PFWFDeleteAllButton { get { return Browser.Wd.FindElement(By.Id("btnDeleteAll")); } }
        public IWebElement BadMessageCount { get { return Browser.Wd.FindElement(By.CssSelector("[id$='MainMasterContent_MainContent_lbBadMesageCount']")); } }
        public IWebElement PFWFRefreshDataButton { get { return Browser.Wd.FindElement(By.CssSelector("[id$='MainMasterContent_MainContent_btnRefresh']")); } }
        public IWebElement PFWFPriorityDropdown { get { return Browser.Wd.FindElement(By.Id("ddlPriorityFilter")); } }
        public IWebElement PFWFApplyButton { get { return Browser.Wd.FindElement(By.CssSelector("[id$='MainMasterContent_MainContent_btnApply']")); } }
        public IWebElement PFWFPriorityFirstCell { get { return Browser.Wd.FindElement(By.CssSelector("#ctl00_ctl00_MainMasterContent_MainContent_dgQueueDetails > tbody>tr:nth-of-type(2)>td:nth-of-type(3)")); } }
        public IWebElement BackToDashboardButton { get { return Browser.Wd.FindElement(By.CssSelector("[id$='MainMasterContent_MainContent_lnkBack']")); } }
        public IWebElement WorkflownameTextbox { get { return Browser.Wd.FindElement(By.Id("txtConfigName")); } }
    }

    [Binding]
    public class AdministrationWorkflow
    {
        public IWebElement WorkflowLink { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_EamNavigation_pnlUserAdmin_workFlowAdministrator_link")); } }
        public IWebElement AdministartionLink { get { return Browser.Wd.FindElement(By.XPath("//div[@class='menuSectionTitle' and contains(.,'Administration')]")); } }
    }

    //Added by Swapna Chappidi on 02/29/2016 for WorkFlow
    [Binding]
    public class WFDashboard
    {

        //**** Newly and Updated WebElements for WorkflowDashboard******

        public IWebElement WFPageTitle { get { return Browser.Wd.FindElement(By.XPath("//kendo-drawer-content//div[text()='Workflow Dashboard']")); } }
        public IWebElement WFRefreshData { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='workflowDashboard-btn-refreshData']")); } }
        public IWebElement SearchMessageIdTextBox { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='workflowDetails-input-messageId']")); } }
        public IWebElement MessageIdSearchButton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='workflowDetails-btn-MessageIdSearch']")); } }
        public IWebElement FoundWorkItemKey { get { return Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='workflowDetails-grid-queueItemDetailGrid']//td[@data-kendo-grid-column-index='1']")); } }
        public IWebElement ChangePriorityBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='workflowDetails-btn-changePriority']")); } }
        public IWebElement ChangePriorityDropDown { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'New Priority')]//parent::div//span[@class='k-select']")); } }
        public IWebElement ChangePrioritySubmitBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='changePriority-btn-submit']")); } }
        public IWebElement ReaasignBtn { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='workflowDetails-btn-reAssign']")); } }
        public IWebElement ReassignQueueDropdown { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='reassignLookup-select-reassignQueue']//span[@class='k-select']")); } }
        public IWebElement ReassignSubmitBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='reassignLookup-btn-submit']")); } }

        //****End of Newly and Updated WebElements******






        public IWebElement WFDashboardTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dgQueueItem")); } }
       
       
        

       
        public IWebElement StatisticsTitle { get { return Browser.Wd.FindElement(By.XPath("//*[@id='dvdashboard']/div/table[1]/tbody/tr/td[1]/b")); } }
        public IWebElement StatisticsCount { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblWaitingItemCount")); } }

       

        public IWebElement BadMsgCount { get { return Browser.Wd.FindElement(By.XPath("//*[@id='ctl00_ctl00_MainMasterContent_MainContent_lbBadMesageCount")); } }
        // public IWebElement SendToWFBtn { get { return Browser.Wd.FindElement(By.Id("ctl00$ctl00$MainMasterContent$MainContent$btnReInitiate")); } }

        public IWebElement SendToWFBtn { get { return Browser.Wd.FindElement(By.Id("btnReInitiate")); } }


        //Resend all and Delete All buttons

        //Queue count for all the queues available
        public IWebElement NumcmoEnrlQueueCnt { get { return Browser.Wd.FindElement(By.Id("//*[@id='ctl00_ctl00_MainMasterContent_MainContent_dgQueueItem_ctl02_lnkCount")); } }

        //WorkItem table
        public IWebElement WorkItemTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dgQueueDetails")); } }

        //Back to Dashboard Home
        public IWebElement BackToWFDashBoard { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lnkBack")); } }

        //WF dashboard homepage title
        public IWebElement WFDashboardTitle { get { return Browser.Wd.FindElement(By.XPath("//*[@id='dvdashboard']/table[1]/tbody/tr[1]/td/b")); } }

        //Priority Button
        public IWebElement PriorityBtn { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnChangePriority")); } }
        public IWebElement WFDashboardPageName { get { return Browser.Wd.FindElement(By.Id("pageName")); } }

        //Change Priority Modal
        public IWebElement PriorityModal { get { return Browser.Wd.FindElement(By.Id("RadWindowWrapper_ctl00_ctl00_MainMasterContent_MainContent_modalPopupPriority")); } }
        public IWebElement PriorityModalcancelBtn { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_modalPopupPriority_C_btnCancelChangePriority")); } }
        public IWebElement NewPriorityDropDown { get { return Browser.Wd.FindElement(By.Id("ddlPriorityAction")); } }
        public IWebElement PriorityTableItems { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_modalPopupPriority_C_dgPriority")); } }
        public IWebElement PriorityModalSubmitBtn { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_modalPopupPriority_C_btnSubmitChangePriority")); } }
        public IWebElement WorkItemPageFlagsRow { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='eamBodyContainer']/div[1]/table/tbody/tr[3]/td")); } }

        public IWebElement WFDashboardSearchWorkItem { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtMessageId")); } }
        public IWebElement WFDashboardSearchBtn { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSearch")); } }

        public IWebElement WFDashboardClearBtn { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnClear")); } }
        public IWebElement WFDashboardSearchNotFoundMessage { get { return Browser.Wd.FindElement(By.XPath(".//*[@id='ctl00_ctl00_MainMasterContent_MainContent_dgQueueDetails']/tbody/tr[2]/td")); } }
        public IWebElement PriorityDropdown { get { return Browser.Wd.FindElement(By.Id("ddlPriorityFilter")); } }
        public IWebElement ApplyButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnApply")); } }

    }

    [Binding]
    public class WFTaskbarOperations
    {
        //**Newly Added or Updated Webelements***

        public IWebElement WorkItemKey { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='workflowControl-lbl-message']/following-sibling::span")); } }
        public IWebElement WorkFlowActionDropDown { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='workflowControl-select-action']//span[@class='k-select']")); } }
        public IWebElement WorkFlowActionSubmitButton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='workflowControl-btn-submit']")); } }
        public IWebElement WorkFlowActionConfirmationYesButton { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")); } }
        public IWebElement WorkFlowActionReason { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='workflowControl-select-reason']//span[@class='k-select']")); } }
        public IWebElement WorkFlowActionQueueDropDown { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='workflowControl-select-queues']//span[@class='k-select']")); } }
        public IWebElement WorkFlowActionNoWorkItemKey { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='workflowControl-btn-submit'][@aria-disabled='true']")); } }
        public IWebElement WorkFlowActionEmptyPageError { get { return Browser.Wd.FindElement(By.XPath("//span[@class='text-danger']")); } }
        public IWebElement WorkflowActiveQueue { get { return Browser.Wd.FindElement(By.XPath("//span[@test-id='workflowControl-span-queue']")); } }
        public IWebElement BackToMemberInfoLink { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pirResponse-span-back']")); } }

        public IWebElement WorkflowModeSaveBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberViewEdit-spn-save']")); } }
        public IWebElement WorkflowModetransactionSaveBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='transaction-btn-save']")); } }
        public IWebElement WorkflowModeSaveAndGetNextBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberViewEdit-btn-saveAndGetNext']")); } }
        //**End of Newly Added or Updated WebElements

        public IWebElement WMtransactionSaveAndGetNextBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='transaction-btn-saveAndGetNext']")); } }


        public IWebElement UserControlTable { get { return Browser.Wd.FindElement(By.Id("usercontrol")); } }
        public IWebElement InformationalTable { get { return Browser.Wd.FindElement(By.Id("informationTable")); } }
        public IWebElement WFActionDropDown { get { return Browser.Wd.FindElement(By.Id("ddlWorkloadAction")); } }
        public IWebElement SetAsideReason { get { return Browser.Wd.FindElement(By.Id("ddlSetAsideReasons")); } }
        public IWebElement SetAsideReactiveAfterTxttime { get { return Browser.Wd.FindElement(By.Id("txtTime")); } }
        public IWebElement SetAsideReactiveAfterTimeUnit { get { return Browser.Wd.FindElement(By.Id("ddlTimeUnit")); } }
        public IWebElement ManuallyRouteReasons { get { return Browser.Wd.FindElement(By.Id("ddlManualRouteReasons")); } }
        public IWebElement ManuallyRouteQueues { get { return Browser.Wd.FindElement(By.Id("ddlQueues")); } }
        public IWebElement ManuallyRouteRoles { get { return Browser.Wd.FindElement(By.Id("ddlRoles")); } }
        public IWebElement TakeABreakReasons { get { return Browser.Wd.FindElement(By.Id("ddlTakeBreakReasons")); } }
        public IWebElement WFTaskbarSubmitBtn { get { return Browser.Wd.FindElement(By.Id("btnSubmit")); } }

        
        public IWebElement WFTaskbarEmptyPageError { get { return Browser.Wd.FindElement(By.XPath("//span[@class='text-danger']")); } }
        public IWebElement WFTaskbarHasWorkItemKey { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ctl05_lbInformation")); } }
        public IWebElement HomebtLink { get { return Browser.Wd.FindElement(By.LinkText("Home")); } }




        // public IWebElement WFTaskbarHasWorkItemKey { get { return Browser.Wd.FindElement(By.XPath("//table[@id='informationTable']//span[@id='ctl00_ctl00_MainMasterContent_MainContent_ctl05_lbInformation']")); } }



    }

    [Binding]
    public class AdministrationBEQCMSTransfer
    {
        public IWebElement MappingTable { get { return Browser.Wd.FindElement(By.XPath("//table[@role='presentation']/tbody")); } }
        public IWebElement Gentranchkbox { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='beqCmsTransfer-radio-genTran']")); } }
        public IWebElement SaveBtn { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='beqCmsTransfer-save-btn']")); } }
        public IWebElement staticmessag { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblMessage")); } }
       

    }

}


