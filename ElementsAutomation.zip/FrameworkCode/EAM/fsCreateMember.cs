﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using OpenQA.Selenium.Support.UI;

namespace TMSoR1
{
    [Binding]
    class fsCreateMember
    {

        [When(@"Members New Medical Number is set to ""(.*)""")]
        public void WhenMembersNewMedicalNumberIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            string medicaidnumber = tmsCommon.GenerateData(p0);
            EAM.CreateNewMember.MedicaidNumber.SendKeys(medicaidnumber);
        }

        [When(@"New Member Page Plan(.*) Text box Field value is set to ""(.*)""")]
        public void WhenNewMemberPagePlanTextBoxFieldValueIsSetTo(int p0, string value)
        {
            cfCreateMember.CreateNewMemberNew.plan2.SendKeys(value);
        }
        [When(@"New Member Page Plan Three Text box Field is set to ""(.*)""")]
        public void WhenNewMemberPagePlanThreeTextBoxFieldIsSetTo(string value)
        {
            cfCreateMember.CreateNewMemberNew.plan3.SendKeys(value);
        }


        [When(@"New Member Page Save Button is clicked")]
        public void WhenNewMemberPageSaveButtonIsClicked()
        {
            cfCreateMember.CreateNewMemberNew.SaveBtn.Click();
        }

        [When(@"Member New Election Type is set to ""(.*)""")]
        public void WhenMemberNewElectionTypeIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            string strValue = tmsCommon.GenerateData(p0.ToString());

           SelectElement thisField = new SelectElement(cfCreateMember.CreateNewMemberNew.ElectionType);
            thisField.SelectByText(strValue);

            tmsWait.Hard(3);
            tmsWait.WaitForReadyStateComplete(30);
        }


        [Then(@"Verify New Member Page Display Missing Fields Error Messages as ""(.*)""")]
        public void ThenVerifyNewMemberPageDisplayMissingFieldsErrorMessagesAs(string error)
        {
            IWebElement errorMsg = Browser.Wd.FindElement(By.XPath("//div[@id='ctl00_ctl00_MainMasterContent_MainContent_ValidationSummary1']//li[contains(.,'"+error+"')]"));
            bool presence = errorMsg.Displayed;

            Assert.IsTrue(presence, "Errror msg is not displayed");


        }


    }
}
