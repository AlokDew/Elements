﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using TMSoR1.FrameworkCode;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace TMSoR1
{
    [Binding]
    class fsUIMODAddNewTransaction
    {

        [When(@"Add New Transaction page Application Disposition section ""(.*)"" checkbox is ""(.*)""")]
        public void WhenAddNewTransactionPageApplicationDispositionSectionCheckboxIs(string p0, string p1)
        {

            string componentType = tmsCommon.GenerateData(p0);
            string typeofAction = tmsCommon.GenerateData(p1);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                switch (componentType)
                {
                    case "Force Acceptance":
                        ReUsableFunctions.CheckBoxOperations(cfUIMODCreateTransaction.ApplicationDisposition.AngForceAcceptanceCheckbox, typeofAction);
                        break;
                    case "Reset Export Legacy":
                        ReUsableFunctions.CheckBoxOperations(cfUIMODCreateTransaction.ApplicationDisposition.AngResetExportLegacycheckbox, typeofAction);
                        break;

                    case "Incomplete Application":
                        ReUsableFunctions.CheckBoxOperations(cfUIMODCreateTransaction.ApplicationDisposition.AngInCompleteApplicationCheckbox, typeofAction);
                        break;
                    case "Force Deny":
                        ReUsableFunctions.CheckBoxOperations(cfUIMODCreateTransaction.ApplicationDisposition.AngForceDenyCheckbox, typeofAction);
                        break;
                }
            }
            else
            {

                switch (componentType)
                {
                    case "Force Acceptance":
                        ReUsableFunctions.CheckBoxOperations(cfUIMODCreateTransaction.ApplicationDisposition.ForceAcceptanceCheckbox, typeofAction);
                        break;
                    case "Reset Export Legacy":
                        ReUsableFunctions.CheckBoxOperations(cfUIMODCreateTransaction.ApplicationDisposition.ResetExportLegacycheckbox, typeofAction);
                        break;

                    case "Incomplete Application":
                        ReUsableFunctions.CheckBoxOperations(cfUIMODCreateTransaction.ApplicationDisposition.InCompleteApplicationCheckbox, typeofAction);
                        break;
                    case "Force Deny":
                        ReUsableFunctions.CheckBoxOperations(cfUIMODCreateTransaction.ApplicationDisposition.ForceDenyCheckbox, typeofAction);
                        break;
                }

            }
        }

        [When(@"Add New Transaction page Application Disposition section ""(.*)"" Drop down List is set to ""(.*)""")]
        public void WhenAddNewTransactionPageApplicationDispositionSectionDropDownListIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(2);
            string strValue = tmsCommon.GenerateData(p1);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                

                By Drp = By.XPath("//label[contains(.,'Denial Reason')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + strValue + "']");





                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

            }
            else
            {
                By pbp = By.XPath("//div[@id='div_ApplicationDispositionDenialReason']/span");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(pbp);
                tmsWait.Hard(1);
                UIMODUtilFunctions.selectTransDrpValue(strValue);
            }
        }

        [When(@"Add New Transaction page Application Disposition section ""(.*)"" is set to ""(.*)""")]
        public void WhenAddNewTransactionPageApplicationDispositionSectionIsSetTo(string p0, string p1)
        {
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (componentType)
            {
                case "Sale Location":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.ApplicationDisposition.SalesLocation, value);
                    break;
                case "Sale Date":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.ApplicationDisposition.SalesDate, value);
                    cfUIMODCreateTransaction.ApplicationDisposition.SalesDate.SendKeys(Keys.Tab);
                    tmsWait.Hard(2);
                    break;
                case "RFI Receipt Date":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.ApplicationDisposition.RFIReceiptDate, value);
                    cfUIMODCreateTransaction.ApplicationDisposition.RFIReceiptDate.SendKeys(Keys.Tab);
                    tmsWait.Hard(2);
                    break;
                case "Missing Item Other":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.ApplicationDisposition.MissingItemOther, value);
                    
                    tmsWait.Hard(2);
                    break;
                case "Denial Reason Other":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.ApplicationDisposition.DenialReasonOther, value);
                 
                    tmsWait.Hard(2);
                    break;
            }
        }


        [When(@"Add New Transaction page Emergency Contact section ""(.*)"" is set to ""(.*)""")]
        public void WhenAddNewTransactionPageEmergencyContactSectionIsSetTo(string p0, string p1)
        {
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (componentType)
            {
                case "Emergency Contact":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.MailingAddress.MailingAddress1, value);
                    break;
                case "Emergency Contact phone":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.MailingAddress.MailingAddress2, value);
                    break;
                case "Emergency Contact Relationship":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.MailingAddress.MailingAddress2, value);
                    break;
            }

            }

        [When(@"Add New Transaction page Medicare Insurance section ""(.*)"" is set to ""(.*)""")]
        public void WhenAddNewTransactionPageMedicareInsuranceSectionIsSetTo(string p0, string p1)
        {
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (componentType)
            {
                case "Emergency Contact":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.MailingAddress.MailingAddress1, value);
                    break;
                case "Emergency Contact phone":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.MailingAddress.MailingAddress2, value);
                    break;
                case "Emergency Contact Relationship":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.MailingAddress.MailingAddress2, value);
                    break;
            }
        }



        [When(@"Add New Transaction page Mailing Address section ""(.*)"" is set to ""(.*)""")]
        public void WhenAddNewTransactionPageMailingAddressSectionIsSetTo(string p0, string p1)
        {
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (componentType)
            {
                case "Mailing Address1":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.MailingAddress.MailingAddress1, value);
                    break;
                case "Mailing Address2":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.MailingAddress.MailingAddress2, value);
                    break;
                case "ZIP":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.MailingAddress.Zip, value);                 
                    break;
                case "City":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.MailingAddress.City, value);
                    break;
                case "State":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.MailingAddress.State, value);
                    break;
                case "County":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.MailingAddress.County, value);
                    break;
                case "SCC":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.MailingAddress.SCCCode, value);
                    break;
            }

        }


        [When(@"Add New Transaction page Residence Address section ""(.*)"" is set to ""(.*)""")]
        public void WhenAddNewTransactionPageResidenceAddressSectionIsSetTo(string p0, string p1)
        {
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (componentType)
            {
                case "Residence Address1":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.ResidenceAddress.StreetAddress1, value);
                    break;
                case "Residence Address2":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.ResidenceAddress.StreetAddress2, value);
                    break;
                case "ZIP":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Txt = By.XPath("(//label[contains(.,'Zip')]/parent::div//input)[1]");
                        Browser.Wd.FindElement(Txt).Clear();
                        Browser.Wd.FindElement(Txt).SendKeys(value);
                        Browser.Wd.FindElement(Txt).SendKeys(Keys.Tab);
                        tmsWait.Hard(3);

                    }
                    else
                    {

                     ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.ResidenceAddress.Zip, value);
                    cfUIMODCreateTransaction.ResidenceAddress.Zip.SendKeys(Keys.Tab);
                    tmsWait.Hard(5);

                    }
                    break;
                case "Phone":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.ResidenceAddress.Phone, value);
                    break;
                case "Alertnate Phone":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.ResidenceAddress.AlternatePhone, value);
                    break;
                case "Email":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.ResidenceAddress.Email, value);
                    break;
                case "Zipfour":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.ResidenceAddress.ZipFour, value);
                    break;
                case "ZIP76":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.ResidenceAddress.Zip76, value);
                    cfUIMODCreateTransaction.ResidenceAddress.Zip76.SendKeys(Keys.Tab);
                    tmsWait.Hard(5);
                    break;
            }  
        }

        [When(@"Add New Transaction page Core Eligibility Details ""(.*)"" drop down list is set to ""(.*)""")]
        public void WhenAddNewTransactionPageCoreEligibilityDetailsDropDownListIsSetTo(string p0, string p1)
        {

            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (componentType)
            {
                case "Group":
                    // Code will be implemented later as there is no unique id in DOM
                    break;
                case "SubGroup":
                    // Code will be implemented later as there is no unique id in DOM
                    break;
                case "Class":
                    // Code will be implemented later as there is no unique id in DOM
                    break;
                case "MedicalID":
                    // Code will be implemented later as there is no unique id in DOM
                    break;
                case "PharmacyID":
                    // Code will be implemented later as there is no unique id in DOM
                    break;
                case "DentalID":
                    // Code will be implemented later as there is no unique id in DOM
                    break;
                case "VisionID":
                    // Code will be implemented later as there is no unique id in DOM
                    break;

            }
        }


        [When(@"Add New Transaction page Member Related Plan Fields ""(.*)"" is set to ""(.*)""")]
        public void WhenAddNewTransactionPageMemberRelatedPlanFieldsIsSetTo(string p0, string p1)
        {        
            
        string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (componentType)
            {
                case "Plan1":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.MemberRelatedPlanFields.Plan1, value);
                    break;
                case "Plan2":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.MemberRelatedPlanFields.Plan2, value);
                    break;
                case "Plan3":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.MemberRelatedPlanFields.Plan3, value);
                    break;
                case "Plan4":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.MemberRelatedPlanFields.Plan4, value);
                    break;
                case "Plan5":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.MemberRelatedPlanFields.Plan5, value);
                    break;
                case "Plan6":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.MemberRelatedPlanFields.Plan6, value);
                    break;
                case "Plan7":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.MemberRelatedPlanFields.Plan7, value);
                    break;
                case "Plan8":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.MemberRelatedPlanFields.Plan8, value);
                    break;
                case "Plan9":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.MemberRelatedPlanFields.Plan9, value);
                    break;
                case "Plan10":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.MemberRelatedPlanFields.Plan10, value);
                    break;

            }
        }


        [When(@"Add New Transaction page Transaction Related Plan Fields ""(.*)"" is set to ""(.*)""")]
        public void WhenAddNewTransactionPageTransactionRelatedPlanFieldsIsSetTo(string p0, string p1)
        {

            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (componentType)
            {
                case "Plan1":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransactionRelatedPlanFields.Plan1, value);
                    break;
                case "Plan2":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransactionRelatedPlanFields.Plan2, value);
                    break;
                case "Plan3":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransactionRelatedPlanFields.Plan3, value);
                    break;
                case "Plan4":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransactionRelatedPlanFields.Plan4, value);
                    break;
                case "Plan5":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransactionRelatedPlanFields.Plan5, value);
                    break;
                case "Plan6":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransactionRelatedPlanFields.Plan6, value);
                    break;
                case "Plan7":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransactionRelatedPlanFields.Plan7, value);
                    break;
                case "Plan8":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransactionRelatedPlanFields.Plan8, value);
                    break;
                case "Plan9":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransactionRelatedPlanFields.Plan9, value);
                    break;
                case "Plan10":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransactionRelatedPlanFields.Plan10, value);
                    break;
            }
        }



        [When(@"Add New Transaction page Rx Details ""(.*)"" drop down list is set to ""(.*)""")]
    public void WhenAddNewTransactionPageRxDetailsDropDownListIsSetTo(string p0, string p1)
    {
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (componentType)
            {
                case "Secondary Rx Insur. Flag":
                    ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.TransDemographics.PlanIDDropDownList);
            UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODCreateTransaction.TransDemographics.PlanIDDropDownList, value);
                    break;
        }

           }
        [When(@"Add New Transaction page Rx Details ""(.*)"" is set to ""(.*)""")]
    public void WhenAddNewTransactionPageRxDetailsIsSetTo(string p0, string p1)
    {
        string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (componentType)
            {
                case "Primary Rx ID":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransRxDetails.PrimaryRxID, value);
                    break;
                case "Primary Rx Group":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransRxDetails.PrimaryRxGroup, value);
                    break;
                case "Primary Rx BIN":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransRxDetails.PrimaryRxBin, value);
                    break;
                case "Primary Rx PCN":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransRxDetails.PrimaryRxPCN, value);
                    break;
                case "Secondary Rx ID":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransRxDetails.SecondaryRxID, value);
                    break;
                case "Secondary Rx Group":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransRxDetails.SecondaryRxGroup, value);
                    break;
                case "Secondary Rx BIN":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransRxDetails.SecondaryRxBin, value);
                    break;
                case "Secondary Rx PCN":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransRxDetails.SecondaryRxPCN, value);
                    break;

            }
        }


        [When(@"Add New Transaction page Demographic Details ""(.*)"" drop down list is set to ""(.*)""")]
        public void WhenAddNewTransactionPageDemographicDetailsDropDownListIsSetTo(string p0, string p1)
        {
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (componentType)
            {
                case "Plan ID":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'Plan ID')]/parent::div//span[@class='k-select']");
                        By drpValue = By.XPath("//li[text()='" + value + "']");


                        UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(drpValue);

                    }
                    else
                    {

                        ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.TransDemographics.PlanIDDropDownList);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODCreateTransaction.TransDemographics.PlanIDDropDownList, value);
                    }
                    break;
                case "PBP ID":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'PBP')]/parent::div//span[@class='k-select']");
                        By drpValue = By.XPath("//li[text()='" + value + "']");


                        UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(drpValue);

                    }
                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.TransDemographics.PBPIDDropDownList);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODCreateTransaction.TransDemographics.PBPIDDropDownList, value);
                    }
                    break;

                case "Segment ID":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'Segment ID')]/parent::div//span[@class='k-select']");
                        By drpValue = By.XPath("//li[text()='" + value + "']");


                        UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(drpValue);

                    }
                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.TransDemographics.SegmentIDDropDownList);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODCreateTransaction.TransDemographics.SegmentIDDropDownList, value);
                    }
                    break;
                case "Segment ID1":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'Segment ID')]/parent::div//span[@class='k-select']");
                        By drpValue = By.XPath("//li[text()='" + value + "']");


                        UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(drpValue);

                    }
                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.TransDemographics.SegmentIDDropDown1);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODCreateTransaction.TransDemographics.SegmentIDDropDown1, value);
                    }
                    break;
                case "Gender":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'Gender')]/parent::div//span[@class='k-select']");
                        By drpValue = By.XPath("//li[text()='" + value + "']");


                        UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(drpValue);

                    }
                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.TransDemographics.GenderDropDownList);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODCreateTransaction.TransDemographics.GenderDropDownList, value);
                    }
                    break;
                case "Enrollment Source":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'Enrollment Source')]/parent::div//span[@class='k-select']");
                        By drpValue = By.XPath("//li[text()='" + value + "']");


                        UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(drpValue);

                    }
                    else
                    { 
                        ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.TransDemographics.EnrollmentSourceDropdownlist);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODCreateTransaction.TransDemographics.EnrollmentSourceDropdownlist, value);
                    }
                    break;
                case "Election Type":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'Election Type')]/parent::div//span[@class='k-select']");
                        By drpValue = By.XPath("//li[text()='" + value + "']");


                        UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(drpValue);

                    }
                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.TransDemographics.ElectionTypeDropdownlist);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODCreateTransaction.TransDemographics.ElectionTypeDropdownlist, value);
                    }
                    break;
                case "SEPS Reason":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'SEPS Reason')]/parent::div//span[@class='k-select']");
                        By drpValue = By.XPath("//li[text()='" + value + "']");


                        UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(drpValue);

                    }
                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.TransDemographics.SEPSReasonDropdownlist);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODCreateTransaction.TransDemographics.SEPSReasonDropdownlist, value);
                    }
                        break;
                case "Language":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'Language')]/parent::div//span[@class='k-select']");
                        By drpValue = By.XPath("//li[text()='" + value + "']");


                        UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(drpValue);

                    }
                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.TransDemographics.SEPSReasonDropdownlist);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODCreateTransaction.TransDemographics.SEPSReasonDropdownlist, value);
                    }
                        break;
                case "Prior Comm":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'Prior Comm')]/parent::div//span[@class='k-select']");
                        By drpValue = By.XPath("//li[text()='" + value + "']");


                        UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(drpValue);

                    }
                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.TransDemographics.SEPSReasonDropdownlist);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODCreateTransaction.TransDemographics.SEPSReasonDropdownlist, value);
                    }
                    break;
                case "Part D OptOut":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'Part D Opt-Out')]/parent::div//span[@class='k-select']");
                        By drpValue = By.XPath("//li[text()='" + value + "']");


                        UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(drpValue);

                    }
                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.TransDemographics.SEPSReasonDropdownlist);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODCreateTransaction.TransDemographics.SEPSReasonDropdownlist, value);
                    }
                        break;
                case "Premium WithHold Option":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'Prem. Withhold Option')]/parent::div//span[@class='k-select']");
                        By drpValue = By.XPath("//li[text()='" + value + "']");


                        UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(drpValue);

                    }
                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.TransDemographics.SEPSReasonDropdownlist);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODCreateTransaction.TransDemographics.SEPSReasonDropdownlist, value);
                    }
                        break;
                case "EGHP":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'EGHP')]/parent::div//span[@class='k-select']");
                        By drpValue = By.XPath("//li[text()='" + value + "']");


                        UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(drpValue);

                    }
                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.TransDemographics.EGHPDropdownlist);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODCreateTransaction.TransDemographics.EGHPDropdownlist, value);
                    }
                        break;
                case "Credit Cover":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'Credit Cover.')]/parent::div//span[@class='k-select']");
                        By drpValue = By.XPath("//li[text()='" + value + "']");


                        UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(drpValue);

                    }
                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.TransDemographics.SEPSReasonDropdownlist);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODCreateTransaction.TransDemographics.SEPSReasonDropdownlist, value);
                    }
                        break;


            }
        }

        [When(@"Add New Transaction page Demographic Details ""(.*)"" is Entered as ""(.*)""")]
        public void WhenAddNewTransactionPageDemographicDetailsIsEnteredAs(string p0, string p1)
        {

            // click on calendar icon  - Note this is WorkAround
            try
            {
                IWebElement selectedDate = Browser.Wd.FindElement(By.XPath("(//div[contains(@ng-if,'transactionUiFieldTypes.datePicker')])[2]//span[@role='button']"));
                fw.ExecuteJavascript(selectedDate);

                IWebElement dateSelect = Browser.Wd.FindElement(By.XPath("(//a[.='1'])[3]")); // Current Date if it is future then select (//a[.='1'])[2]
                fw.ExecuteJavascript(dateSelect);
                

            }
            catch
            {

            }
        }

        [When(@"Add New Transaction page Demographic Details DOB is Entered to ""(.*)""")]
        public void WhenAddNewTransactionPageDemographicDetailsDOBIsEnteredTo(string p0)
        {

            // click on calendar icon  - Note this is WorkAround
            IWebElement selectedDate = Browser.Wd.FindElement(By.XPath("(//div[contains(@ng-if,'transactionUiFieldTypes.datePicker')])[1]//span[@role='button']"));
            fw.ExecuteJavascript(selectedDate);
            bool flag = false;
            int i = 1;
            while(!flag)
            {
                
                IWebElement Prev = Browser.Wd.FindElement(By.XPath("(//a[@aria-label='Previous'])[1]"));
                fw.ExecuteJavascript(Prev);
                i++;
                if(i==60) // // It will click before 60 months
                {
                    flag = true;
                    break;
                }
            }
           
           

            IWebElement dateSelect = Browser.Wd.FindElement(By.XPath("(//a[.='3'])[1]")); // Current Date if it is future then select (//a[.='1'])[2]
            fw.ExecuteJavascript(dateSelect);
          
        }

        [When(@"Add New Transaction page Demographic Details Signature Date is Entered as ""(.*)""")]
        public void WhenAddNewTransactionPageDemographicDetailsSignatureDateIsEnteredAs(string p0)
        {
            // click on calendar icon  - Note this is WorkAround
            IWebElement selectedDate = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Signature Date')]/parent::div/div//span[@role='button']"));
            fw.ExecuteJavascript(selectedDate);

            bool flag = false;
            int i = 1;
            while (!flag)
            {

                IWebElement Prev1 = Browser.Wd.FindElement(By.XPath("(//a[@aria-label='Previous'])[1]"));
                fw.ExecuteJavascript(Prev1);
                i++;
                if (i == 6) // It will click before 6 months
                {
                    flag = true;
                    break;
                }
            }

                IWebElement dateSelect = Browser.Wd.FindElement(By.XPath("(//a[.='3'])[1]")); // Current Date if it is future then select (//a[.='1'])[2]
            fw.ExecuteJavascript(dateSelect);
           
        }

        [When(@"Add New Transaction page Demographic Details Receipt Date is Entered as ""(.*)""")]
        public void WhenAddNewTransactionPageDemographicDetailsReceiptDateIsEnteredAs(string p0)
        {
            // click on calendar icon  - Note this is WorkAround
            IWebElement selectedDate = Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Receipt Date')]/parent::div/div//span[@role='button'])[1]"));
            fw.ExecuteJavascript(selectedDate);


            bool flag = false;
            int i = 1;
            while (!flag)
            {

                IWebElement Prev = Browser.Wd.FindElement(By.XPath("(//a[@aria-label='Previous'])[1]"));
                fw.ExecuteJavascript(Prev);
                i++;
                if (i == 2) // It will click before 2 months
                {
                    flag = true;
                    break;
                }
            }

            IWebElement dateSelect = Browser.Wd.FindElement(By.XPath("(//a[.='1'])[1]")); // Current Date if it is future then select (//a[.='1'])[2]
            fw.ExecuteJavascript(dateSelect);
        }



        [When(@"Add New Transaction page Demographic Details ""(.*)"" is set to ""(.*)""")]
        public void WhenAddNewTransactionPageDemographicDetailsIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(4);
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (componentType)
            {
                case "MBI":
                    //if (ConfigFile.tenantType.Equals("tmsx"))
                    //{
                       
                    //    By Drp = By.XPath("//label[contains(.,'MBI']/parent::div//input");
                    //    Browser.Wd.FindElement(Drp).Clear();
                    //    Browser.Wd.FindElement(Drp).SendKeys(value);

                    //    tmsWait.Hard(3);


                    //}
                    //else
                    //{
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransDemographics.MBITextbox, value);
                    //}
                    break;                 
                case "Last Name":
                    //if (ConfigFile.tenantType.Equals("tmsx"))
                    //{

                    //    By Drp = By.XPath("//label[contains(.,'Last Name')]/parent::div//input");
                    //    Browser.Wd.FindElement(Drp).Clear();
                    //    Browser.Wd.FindElement(Drp).SendKeys(value);

                    //    tmsWait.Hard(3);


                    //}
                    //else
                    //{
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransDemographics.LastNameTextbox, value);
                    //}
                    break;
                case "First Name":
                    //if (ConfigFile.tenantType.Equals("tmsx"))
                    //{

                    //    By Drp = By.XPath("//label[contains(.,'Last Name')]/parent::div//input");
                    //    Browser.Wd.FindElement(Drp).Clear();
                    //    Browser.Wd.FindElement(Drp).SendKeys(value);

                    //    tmsWait.Hard(3);


                    //}
                    //else
                    //{
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransDemographics.FirstNameTextbox, value);
                    //}
                    break;
                case "Middle Initial":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {

                        By Drp = By.XPath("//label[contains(.,'Middle Initial(M.I.)')]/parent::div//input");
                        Browser.Wd.FindElement(Drp).Clear();
                        Browser.Wd.FindElement(Drp).SendKeys(value);

                        tmsWait.Hard(3);


                    }
                    else
                    {
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransDemographics.MITextbox, value);
                    }
                    break;
                case "Salutation":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {

                        By Drp = By.XPath("//label[contains(.,'Salutation')]/parent::div//input");
                        Browser.Wd.FindElement(Drp).Clear();
                        Browser.Wd.FindElement(Drp).SendKeys(value);

                        tmsWait.Hard(3);


                    }
                    else
                    {
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransDemographics.SalutationTextbox, value);
                    }
                    break;
                case "Appel":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {

                        By Drp = By.XPath("//label[contains(.,'Appel')]/parent::div//input");
                        Browser.Wd.FindElement(Drp).Clear();
                        Browser.Wd.FindElement(Drp).SendKeys(value);

                        tmsWait.Hard(3);


                    }
                    else
                    {
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransDemographics.AppelTextbox, value);
                    }
                    break;
                case "SSN":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {

                        By Drp = By.XPath("//label[contains(.,'Middle Initial(M.I.)')]/parent::div//input");
                        Browser.Wd.FindElement(Drp).Clear();
                        Browser.Wd.FindElement(Drp).SendKeys(value);

                        tmsWait.Hard(3);


                    }
                    else
                    {
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransDemographics.SSN, value);
                    }
                    break;
                case "Member ID":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By fname = By.XPath("//label[contains(.,'Member ID')]/parent::div/div//input");
                        try
                        {
                            UIMODUtilFunctions.enterValueOnWebElementUsingLocators(fname, value);
                        }
                        catch
                        {
                            fw.ConsoleReport(" Member ID field is disabled");
                        }

                    }
                    else
                    {
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransDemographics.MemberID, value);
                    }
                    break;
                case "Uncovered Months":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By fname = By.XPath("//label[contains(.,'# Uncovered Months')]/parent::div//input");
                        UIMODUtilFunctions.enterValueOnWebElementUsingLocators(fname, value);

                    }
                    else
                    {
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransDemographics.UncoveredMonths, value);
                    }
                    break;

                case "DOB":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        value = value.Replace("/", "");
                        By Drp = By.XPath("//label[contains(.,'DOB')]/parent::div//input");
                        Browser.Wd.FindElement(Drp).Clear();
                        Browser.Wd.FindElement(Drp).SendKeys(value);

                        tmsWait.Hard(3);


                    }
                    else
                    {
                        ReUsableFunctions.enterValueOnWebElementWithoutClear(cfUIMODCreateTransaction.TransDemographics.DOB, value);
                    }
                    break;
                case "Effective Date":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        value = value.Replace("/", "");
                        By Drp = By.XPath("//label[contains(.,'Effective Date')]/parent::div//input");
                        Browser.Wd.FindElement(Drp).Clear();
                        Browser.Wd.FindElement(Drp).SendKeys(value);

                        tmsWait.Hard(3);


                    }
                    else
                    {
                        ReUsableFunctions.enterValueOnWebElementWithoutClear(cfUIMODCreateTransaction.TransDemographics.EffectiveDate, value);
                    }
                    break;
                case "Signature Date":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                         value = value.Replace("/", "");
                        By Drp = By.XPath("//label[contains(.,'Signature Date')]/parent::div//input");
                        Browser.Wd.FindElement(Drp).Clear();
                        Browser.Wd.FindElement(Drp).SendKeys(value);

                        tmsWait.Hard(3);


                    }
                    else
                    {

                        ReUsableFunctions.enterValueOnWebElementWithoutClear(cfUIMODCreateTransaction.TransDemographics.SignatureDate, value);
                       
                    }
                    break;
                case "Receipt Date":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        value = value.Replace("/", "");
                        By Drp = By.XPath("//label[contains(.,'Receipt Date')]/parent::div//input");
                        Browser.Wd.FindElement(Drp).Clear();
                        Browser.Wd.FindElement(Drp).SendKeys(value);

                        tmsWait.Hard(3);


                    }
                    else
                    {
                        ReUsableFunctions.enterValueOnWebElementWithoutClear(cfUIMODCreateTransaction.TransDemographics.ReceiptDate, value);
                    }
                    break;

            }

            }
        [When(@"Add New Transaction page Disenrollment Reason Code Desc icon is clicked")]
        [Then(@"Add New Transaction page Disenrollment Reason Code Desc icon is clicked")]
        public void ThenAddNewTransactionPageDisenrollmentReasonCodeDescIconIsClicked()
        {

            tmsWait.Hard(2);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("(//span[@test-id='transaction-i-transactionToolTip'])[3]")));
            }
            else
            {
                ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("(//i[@test-id='transaction-i-transactionToolTip'])[3]")));
            }
        }
        [Then(@"Verify Add New Transaction page Disenrollment Reason PopUp has row with code ""(.*)"" and Description ""(.*)""")]
        public void ThenVerifyAddNewTransactionPageDisenrollmentReasonPopUpHasRowWithCodeAndDescription(string p0, string p1)
        {


            string code = tmsCommon.GenerateData(p0);
            string desc = tmsCommon.GenerateData(p1);
            int totalPagesIntheGrid = 0;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                totalPagesIntheGrid = ReUsableFunctions.getTotalPages();
                //div[@role='presentation']//td[.='" + code + "']/following-sibling::td[contains(.,'" + desc + "')]
                string xpath = "//div[@role='presentation']//td[.='" + code + "']/following-sibling::td[contains(.,'" + desc + "')]";
              //  bool hasrow = false;
               // ReUsableFunctions.clickOnGridElement(xpath);
                ReUsableFunctions.verifyGridElementPresence(xpath);

            }
            else
            {
                //   string xpath = "//div[@test-id='disenrollmentReasons-grid-disenrollmentReasons']//td[contains(.,'" + code + "')]/following-sibling::td[contains(.,'" + source + "' )]/following-sibling::td[contains(.,'" + desc + "' )]/following-sibling::td/input[@class='" + classValue + "']/parent::td/following-sibling::td[contains(.,'" + mapto + "')]";
                string xpath = "//div[@id='lookupDataGrid']//span[.='" + code + "']/parent::td/following-sibling::td/span[contains(.,'" + desc + "')]";
                bool hasrow = false;

                 totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
                for (int i = 1; i <= totalPagesIntheGrid; i++)
                {
                    try
                    {

                        hasrow = Browser.Wd.FindElement(By.XPath(xpath)).Displayed;

                        // status = element.GetAttribute("checked").ToString();
                        break;
                    }
                    catch
                    {

                        IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                        ReUsableFunctions.clickOnWebElement(nextpage);
                    }

                }
                //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed);

                Assert.IsTrue(hasrow, "There is no such row Present");
            }
        }
        [When(@"Verify Add New Transaction page Disenrollment Reason PopUp does not have row with code ""(.*)"" and Description ""(.*)""")]
        [Then(@"Verify Add New Transaction page Disenrollment Reason PopUp does not have row with code ""(.*)"" and Description ""(.*)""")]
        public void ThenVerifyAddNewTransactionPageDisenrollmentReasonPopUpDoesNotHaveRowWithCodeAndDescription(string p0, string p1)
        {
            string code = tmsCommon.GenerateData(p0);
            string xpath = "//kendo-grid[@test-id='lookupData-grid-lookupDataGrid']//td[contains(.,'" + code + "')]";
            bool hasrow = false;

            int totalPagesIntheGrid = ReUsableFunctions.getTotalPages();
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {

                    hasrow = Browser.Wd.FindElement(By.XPath(xpath)).Displayed;
                    break;
                }
                catch
                {

                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);
                }

            }
            //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed);

            Assert.IsFalse(hasrow, "There is no such row Present");
        }
   

        [Then(@"Add New Transaction page ""(.*)"" Component is set to ""(.*)""")]
        //[When(@"Add New Transaction page ""(.*)"" Component is set to ""(.*)""")]
        public void WhenAddNewTransactionPageComponentIsSetTo(string p0, string p1)
        {
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (componentType)
            {
                case "Transaction Code":
                    ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.UIMODCreateTransactionBasic.TCCodeDropDownList);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODCreateTransaction.UIMODCreateTransactionBasic.TCCodeDropDownList, value);
                    break;
                case "Type of Application":
                    ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.UIMODCreateTransactionBasic.TypeOfApplicationDropDownList);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODCreateTransaction.UIMODCreateTransactionBasic.TypeOfApplicationDropDownList, value);
                    break;
                case "Segment Id":
                    ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.TransDemographics.SegmentIDDropDownList);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODCreateTransaction.TransDemographics.SegmentIDDropDownList, value);
                   
                    break;
                case "Zip":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.ResidenceAddress.Zip, value);
                    break;
                case "County":
                    ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.ResidenceAddress.CountyDropDownList);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODCreateTransaction.ResidenceAddress.CountyDropDownList, value);
                    break;
                case "Effective Date":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransDemographics.EffectiveDate, value);
                    
                    break;
                case "Receipt Date":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransDemographics.ReceiptDate,value);
                    
                    break;
                case "PBP":
                    ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.TransDemographics.PBPIDDropDownList);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODCreateTransaction.TransDemographics.PBPIDDropDownList, value);
                    break;
                case "Street Address1":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.ResidenceAddress.StreetAddress1,value);
                 
                    break;
                case "ElectionType":
                    ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.TransDemographics.ElectionTypeDropdownlist);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODCreateTransaction.TransDemographics.ElectionTypeDropdownlist, value);
                    break;
                case "MemberID":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransDemographics.MemberID, value);
                    break;
                case "SignatureDate":

                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransDemographics.SignatureDate, value);
                    break;
                case "Action":
                    ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.ResidenceAddress.ActionDropDownList);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODCreateTransaction.TransDemographics.ElectionTypeDropdownlist, value);
                    break;
                case "Zipfour":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.ResidenceAddress.StreetAddress1, value);
                    break;
                case "Address Effective Date":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.ResidenceAddress.StreetAddress1, value);
                    break;
            }
            tmsWait.Hard(4);
        }

        [When(@"View Edit Transaction page Save button is clicked")]
        public void WhenViewEditTransactionPageSaveButtonIsClicked()
        {
            tmsWait.Hard(2);
            ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.UIMODCreateTransactionBasic.SaveBtn);
            try
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")));
            }
             catch
            {

            }
            tmsWait.Hard(5);
        }

        [When(@"View Edit Members page Transactions Section Add Transactions Link is Clicked")]
        public void WhenViewEditMembersPageTransactionsSectionAddTransactionsLinkIsClicked()
        {
            fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODTransaction.AddTransaction);
            ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODTransaction.AddTransaction);
            tmsWait.Hard(3);
        }

        [When(@"Add New Transaction page Transaction Code ""(.*)"" is selected")]
        public void WhenAddNewTransactionPageTransactionCodeIsSelected(string value)
        {
            AngularFunction.selectKendoDropDownValue(cfUIMODCreateTransaction.UIMODCreateTransactionBasic.TCCodeDropDownList, value);
                      
            
        }
        [When(@"Add New Transaction page Zip Four is set to ""(.*)""")]
        public void WhenAddNewTransactionPageZipFourIsSetTo(string value)
        {
            By ele = By.CssSelector("[test-id='Transactioncode76ResidentialAddressupdateZipFour']");
            UIMODUtilFunctions.enterValueOnWebElementUsingLocators(ele, value);
        }

        [When(@"Add New Transaction page Member ID is set to ""(.*)""")]
        public void WhenAddNewTransactionPageMemberIDIsSetTo(string value)
        {
            string po = tmsCommon.GenerateData(value);
            By ele = By.CssSelector("[test-id='DemographicDetailsMemberID']");
            UIMODUtilFunctions.enterValueOnWebElementUsingLocators(ele, po);
        }


        [When(@"Add New Transaction page Residential Address Update section Action Drop down value is set to ""(.*)""")]
        public void WhenAddNewTransactionPageResidentialAddressUpdateSectionActionDropDownValueIsSetTo(string value)
        {
            //UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODCreateTransaction.ResidenceAddress.ActionDropDownList, value);
            //ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.ResidenceAddress.ActionDropDownList);
            //UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODCreateTransaction.ResidenceAddress.ActionDropDownList, value);
            tmsWait.Hard(5);
            string strValue = tmsCommon.GenerateData(value);

            By pbp = By.XPath("//div[@id='div_Transactioncode76ResidentialAddressupdateAction']/span");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(pbp);
            tmsWait.Hard(2);
            UIMODUtilFunctions.selectTransDrpValue(strValue);
            tmsWait.Hard(5);

        }

        [When(@"Add New Transaction page Residential Address Update section Address Effective Date is set to ""(.*)""")]
        public void WhenAddNewTransactionPageResidentialAddressUpdateSectionAddressEffectiveDateIsSetTo(string value)
        {
            ReUsableFunctions.enterValueOnWebElementWithoutClear(cfUIMODCreateTransaction.ResidenceAddress.AddressEffectiveDate, value);
        }

        [When(@"Add New Transaction page Residential Address Update section Address Effective Date is set to ""(.*)"" and Click on Save Button")]
        public void WhenAddNewTransactionPageResidentialAddressUpdateSectionAddressEffectiveDateIsSetToAndClickOnSaveButton(string value)
        {
            tmsWait.Hard(5); // Wait we put intentionally as TC is failing while run through Tool. Do not reduce.
            ReUsableFunctions.enterValueOnWebElementWithoutClear(cfUIMODCreateTransaction.ResidenceAddress.AddressEffectiveDate, value);
            tmsWait.Hard(5);
            // Wait we put intentionally. Do not reduce
            IWebElement endDate = Browser.Wd.FindElement(By.CssSelector("[test-id='Transactioncode76ResidentialAddressupdateAddressEndDate']"));
            ReUsableFunctions.enterValueOnWebElementWithoutClear(endDate, "01/01/2025");
            endDate.SendKeys(Keys.Tab);
            tmsWait.Hard(5);
            By loc = By.XPath("//button[@test-id='transaction-btn-save']/span");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            tmsWait.Hard(5);
            try
            {
                UIMODUtilFunctions.clickOnConfirmationYesDialog();
            }
            catch
            {
                fw.ConsoleReport(" There is no confirmation dialog");
            }
            tmsWait.Hard(5);
        }



        [When(@"Add New Transaction page Residential Address Update section Address Effective End Date is set to ""(.*)""")]
        public void WhenAddNewTransactionPageResidentialAddressUpdateSectionAddressEffectiveEndDateIsSetTo(string p0)
        {
           
        ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.ResidenceAddress.AddressEndDate, p0);
        }
        [When(@"Add New Transaction page Residential Address Update section ZIP is set to ""(.*)""")]
        public void WhenAddNewTransactionPageResidentialAddressUpdateSectionZIPIsSetTo(string p0)
        {
            ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.ResidenceAddress.Zip76, p0);
        }


        [When(@"Add New Transaction page Disenrollment Reason Code ""(.*)"" is selected")]
        public void WhenAddNewTransactionPageDisenrollmentReasonCodeIsSelected(string value)
        {
            By drp=By.XPath("//kendo-dropdownlist[@test-id='DemographicDetailsDisenReason']//span[@class='k-select']");
            AngularFunction.selectKendoDropDownValue(drp, value);
         
        }

        [When(@"Add New Transaction page Effective Date is set to ""(.*)""")]
        public void WhenAddNewTransactionPageEffectiveDateIsSetTo(string value)
        {
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Effective Date')]/parent::div//span[@role='button']"));
            fw.ExecuteJavascript(ele);
                        

            ReUsableFunctions.enterValueOnWebElementWithoutClear(cfUIMODCreateTransaction.TransDemographics.EffectiveDate,value);
        }

        [When(@"Add New Transaction page Election Type is set to ""(.*)""")]
        public void WhenAddNewTransactionPageElectionTypeIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string strValue = tmsCommon.GenerateData(p0);

            By pbp = By.XPath("//kendo-dropdownlist[@test-id='DemographicDetailsElectionType']//span[@class='k-select']");
            AngularFunction.selectKendoDropDownValue(pbp, strValue);
        }


        [When(@"Add New Transaction page Clicked on Save button")]
        public void WhenAddNewTransactionPageClickedOnSaveButton()
        {
            ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.UIMODCreateTransactionBasic.SaveBtn);
            try
            {
                IWebElement el = Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']"));
                if(el.Displayed)
                {
                    fw.ExecuteJavascript(el);
                }
            }
            catch
            {

            }
        }

        [When(@"Add New Transaction page Clicked on Cancel button")]
        public void WhenAddNewTransactionPageClickedOnCancelButton()
        {
            ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.UIMODCreateTransactionBasic.CancelBtn);
        }

        [When(@"Add New Transaction page Receipt Date is set to ""(.*)""")]
        public void WhenAddNewTransactionPageReceiptDateIsSetTo(string value)
        {
            IWebElement ele = Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Receipt Date')]/parent::div//span[@role='button'])[1]"));
            fw.ExecuteJavascript(ele);
            ReUsableFunctions.enterValueOnWebElementWithoutClear(cfUIMODCreateTransaction.TransDemographics.ReceiptDate, value);
        }


        [When(@"Add New Transaction page (.*) ""(.*)"" Component is set to ""(.*)""")]
        public void WhenAddNewTransactionPageComponentIsSetTo(int p0, string p1, string p2)
        {
            string componentType = tmsCommon.GenerateData(p1);
            string value = tmsCommon.GenerateData(p2);
            switch (componentType)
            {
                case "Address Effective Date":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.ResidenceAddressUpdate.AddressEffectiveDate, p2);
                    break;
                case "Zip":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.ResidenceAddressUpdate.ZIP, p2);
                    break;
                case "Action":
                    ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.ResidenceAddressUpdate.Action);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODCreateTransaction.ResidenceAddressUpdate.Action, value);
                  //  SelectElement eghp = new SelectElement(cfUIMODCreateTransaction.ResidenceAddressUpdate.Action);
                  //  eghp.SelectByText(value);
                    
                    break;
                case "ZipFour":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.ResidenceAddressUpdate.ZipFour, p2);
                    break;
                case "Receipt Date":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODCreateTransaction.TransDemographics.ReceiptDate, p2);
                    break;
            }
        }
        [Then(@"Add New Transaction page Save Button is Clicked")]
        [When(@"Add New Transaction page Save Button is Clicked")]
        public void WhenAddNewTransactionPageSaveButtonIsClicked()
        {
            ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.UIMODCreateTransactionBasic.SaveBtn);
            UIMODUtilFunctions.clickOnConfirmationYesDialog();


        }
        [When(@"Add New Transaction page Optional Supplemental Benefits Information section OSB is set to ""(.*)""")]
        public void WhenAddNewTransactionPageOptionalSupplementalBenefitsInformationSectionOSBIsSetTo(string p0)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                    //using test-id because 'abel[contains(.,'OSB')] does not return a unique result
                    By Drp = By.XPath("//kendo-dropdownlist[@test-id='OptionalSupplementalBenefitsOSBInformationOSB']//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + p0 + "']");


                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);



                }
                
            else
            {
                By eghpMOD = By.XPath("//div[@id='div_OptionalSupplementalBenefitsOSBInformationOSB']/span");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(eghpMOD);
                tmsWait.Hard(1);
                By Value = By.XPath("(//li[.='" + p0 + "'])[4]");
                tmsWait.Hard(2);
                fw.ExecuteJavascript(Browser.Wd.FindElement(Value));
            }
            
        }

        [When(@"Add New Transaction page (.*) TC Optional Supplemental Benefits Information section OSB is set to ""(.*)""")]
        public void WhenAddNewTransactionPageTCOptionalSupplementalBenefitsInformationSectionOSBIsSetTo(int p0, string p1)
        {
            tmsWait.Hard(5);
            By eghpMOD = By.XPath("//div[@id='div_OptionalSupplementalBenefitsOSBInformationOSB']/span");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(eghpMOD);
            tmsWait.Hard(1);
            By Value = By.XPath("(//li[.='" + p1 + "'])[1]");
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(Value));
        }

        [When(@"Add New Transaction page Confirmation Yes Button is Clicked")]
        public void WhenAddNewTransactionPageYesButtonIsClicked()
        {
            try { 
            ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.UIMODCreateTransactionBasic.confirmationYesBtn);
            }
            catch (Exception e)
            {

            }
            }


        [Then(@"Add New Transaction page ""(.*)"" button is clicked")]
        public void ThenAddNewTransactionPageButtonIsClicked(string p0)
        {
        string componentType = tmsCommon.GenerateData(p0);

            switch (componentType)
            {
                case "Save":
                    ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.UIMODCreateTransactionBasic.SaveBtn);
                    break;
                case "Member Info Button":
                    tmsWait.Hard(5);
                    ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.UIMODCreateTransactionBasic.ViewMemberBtn);
                    break;
                case "Yes":
                    ReUsableFunctions.clickOnWebElement(cfUIMODCreateTransaction.UIMODCreateTransactionBasic.confirmationYesBtn);
                    tmsWait.Hard(5);
                    break;
            }
        }
    }

}


