﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.EAM
{
    [Binding]
    public static class cfMemberSpanFile
    {
        public static IWebElement ExportSpanFileButton { get { return Browser.Wd.FindElement(By.CssSelector("input[id$='MainMasterContent_MainContent_btnExportSpansJob']")); } }
        public static IWebElement ModifiedOnlyCheckbox { get { return Browser.Wd.FindElement(By.CssSelector("input[id$='MainMasterContent_MainContent_chkModifiedOnly']")); } }
        public static IWebElement CompleteStatus { get { return Browser.Wd.FindElement(By.XPath("//*[@id='ctl00_ctl00_MainMasterContent_MainContent_FileStatusGrid']/tbody/tr[2]/td[4]")); } }
        
    }
}
