﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.IO;
using TechTalk.SpecFlow;
//using System.Windows.Forms;
using System.Data.OleDb;
using System.Data;
using System.Linq;

namespace TMSoR1.FrameworkCode.EAM
{
    [Binding]
    public class fsMailingList
    {
        string documentPath = Path.Combine(Environment.ExpandEnvironmentVariables("%userprofile%"), "My Documents");
        string downloadPath = Path.Combine(Environment.ExpandEnvironmentVariables("%userprofile%"), "Downloads");

        [Given(@"Set TRR Start Date as ""(.*)"" TRR End Date as ""(.*)"" Transaction Processed as ""(.*)"" PlanID as ""(.*)""")]
        public void GivenSetTRRStartDateAsTRREndDateAsTransactionProcessedAsPlanIDAs(string startDate, string endDate, string transaction, string planID)
        {
            SelectElement startDateElement = new SelectElement(cfMailingList.TRRStartDateDropdown);
            startDateElement.SelectByText(startDate);
            tmsWait.Hard(2);
            SelectElement endDateElement = new SelectElement(cfMailingList.TRREndDateDropdown);
            endDateElement.SelectByText(endDate);
            tmsWait.Hard(2);
            //SelectElement trrtransactionElement = new SelectElement(cfMailingList.TRRTransactionProcessed);
            //trrtransactionElement.SelectByText(transaction);
            //tmsWait.Hard(2);
            SelectElement planIDElement = new SelectElement(cfMailingList.TRRPlanID);
            planIDElement.SelectByText(planID);
            tmsWait.Hard(2);
        }

        [Given(@"Member List From TRR page TRR Code ""(.*)"" is clicked")]
        public void GivenMemberListFromTRRPageTRRCodeIsClicked(string trrCode)
        {
            Browser.Wd.FindElement(By.LinkText(trrCode)).Click();
           
        }

        [Given(@"Member List From TRR Export Button is clicked")]
        public void GivenMemberListFromTRRExportButtonIsClicked()
        {
            tmsWait.Hard(3);
            var filePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.csv");
            for (int fileCount = 0; fileCount < filePaths.Length; fileCount++)
            {
                File.Delete(Path.Combine(downloadPath, filePaths[fileCount]));
            }
            if (ConfigFile.BrowserType.ToLower().Equals("chrome"))
            {
                cfMailingList.ExportButton.Click();
            }
            else if (ConfigFile.BrowserType.ToLower().Equals("ff"))
            {
                cfMailingList.ExportButton.Click();
                tmsWait.Hard(2);
              //  SendKeys.SendWait("{DOWN}");
                tmsWait.Hard(2);
                //SendKeys.SendWait("{ENTER}");
            }
            else if (ConfigFile.BrowserType.ToLower().Equals("ie"))
            {
                string moreOptionClick = "$('input#ctl00_ctl00_MainMasterContent_MainContent_TRRCodeUserList1_btnExport').click();";
                fw.ExecuteJavascript(moreOptionClick);
                //tmsWait.Hard(2);
                IWebElement securityWindow = Browser.winium.FindElement(By.Name("Save"));
                securityWindow.Click();
                //DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_TAB, 0, 0, 0);
                //tmsWait.Hard(2);
                //DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_TAB, 0, 0, 0);
                //tmsWait.Hard(2);
                //DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_RETURN, 0, 0, 0);
            }
        }

        [When(@"Single Member Detail Report page Click here to search for Value link is Clicked")]
        public void WhenSingleMemberDetailReportPageClickHereToSearchForValueLinkIsClicked()
        {
            var currentWindow = Browser.Wd.CurrentWindowHandle; // Getting current window                                                          
            try
            {
                string OnClickJavascript = @"window.showModalDialog(location.protocol + '//' + location.host + '/PDMWeb/EENRL/inc/namelookup.aspx',window,'parameters=0,status=0,resizable=1,scrollbars=1,fullscreen=0,toolbar=0,width=350,height=500,top=50,left=50')";

                ((IJavaScriptExecutor)Browser.Wd).ExecuteScript(OnClickJavascript);


            }
            catch
            {

            }
            
            var availableWindows = new System.Collections.Generic.List<string>(Browser.Wd.WindowHandles); // Getting all available windows

            foreach (string w in availableWindows)
            {
                if (w != currentWindow)
                {
                    Browser.Wd.SwitchTo().Window(w);   // Swithcing to Child window
                   
                }
            }
        }

        [When(@"BEQ File Export Import page Plan ID is Set to ""(.*)""")]
        public void WhenBEQFileExportImportPagePlanIDIsSetTo(string p0)
        {
            SelectElement planid = new SelectElement(TMSoR1.EAM.LoadBEQFile.PlanIDDropdownlist);
            planid.SelectByText(p0);
        }

        [When(@"BEQ File Export Import page Export button is Clicked")]
        public void WhenBEQFileExportImportPageExportButtonIsClicked()
        {
            TMSoR1.EAM.LoadBEQFile.ExportButton.Click();
        }

        [Then(@"Verify BEQ File Export Import page displays message ""(.*)""")]
        public void ThenVerifyBEQFileExportImportPageDisplaysMessage(string p0)
        {
            string expected = p0.ToString();

            string actual = TMSoR1.EAM.LoadBEQFile.BEQStaticMsg.Text;

            Assert.AreEqual(expected, actual, expected+" values are getting matched with "+actual);

        }


        [When(@"Member Lookup page HIC Number is set to ""(.*)""")]
        public void WhenMemberLookupPageHICNumberIsSetTo(string p0)
        {
           

             TMSoR1.EAM.SinglMemberReport.MemberLookupHIC.SendKeys(p0);
        }

        [When(@"Member Lookup page Search button is Clicked")]
        public void WhenMemberLookupPageSearchButtonIsClicked()
        {
            TMSoR1.EAM.SinglMemberReport.MemberLookupSearchButton.Click();
        }

        [When(@"Member Looup search result ""(.*)""is Clicked")]
        public void WhenMemberLooupSearchResultIsClicked(string p0)
        {
  
            Browser.Wd.FindElement(By.TagName("a")).Click();
    
         }


     [Then(@"Single Member Detail Report page Run Report is Clicked")]
        public void ThenSingleMemberDetailReportPageRunReportIsClicked()
        {
            tmsWait.Hard(1);
            //var currentWindow = Browser.Wd.CurrentWindowHandle;
            //Browser.Wd.SwitchTo().Window(currentWindow);

            var availableWindows = new System.Collections.Generic.List<string>(Browser.Wd.WindowHandles);
            foreach(string main in availableWindows)
            {
                Browser.Wd.SwitchTo().Window(main);
            }
            TMSoR1.EAM.SinglMemberReport.RunReport.Click();
        }

        [Then(@"Verify Downloaded Legacy Member file Field ""(.*)"" is set to First Record Noted MBI")]
        public void ThenVerifyDownloadedLegacyMemberFileFieldIsSetToFirstRecordNotedMBI(string p0)
        {
            tmsWait.Hard(3);

            string field = p0.ToString();
            tmsWait.Hard(8);    //Wait for download, save and reading purpose
            string expectedValue = GlobalRef.TransMBI.ToString();
            //string expectedValue = tmsCommon.GenerateData(p1);

            var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
            int filecount = newFilePaths.Length;
            var srcFile = Path.Combine(downloadPath, newFilePaths[filecount - 1]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
                var values = line.Split(',');
                if (count > 1)
                {
                    //    if (values[3].Equals("51") || values[3].Equals("61"))
                    //    {
                    if (field.Equals("LIS Level"))
                    {
                        Assert.IsTrue(values[114].Contains(expectedValue), "Expected Field Value is dislayed.");
                        break;
                    }
                    else if (field.Equals("LIS Co-Pay Category"))
                    {
                        Assert.IsTrue(values[115].Contains(expectedValue), "Expected Field Value is dislayed.");
                        break;
                    }
                    else if (field.Equals("LIS Effective Date"))
                    {
                        Assert.IsTrue(values[116].Contains(expectedValue), "Expected Field Value is dislayed.");
                        break;
                    }
                    else if (field.Equals("LIS Amount"))
                    {
                        Assert.IsTrue(values[117].Contains(expectedValue), "Expected Field Value is dislayed.");
                        break;
                    }

                    else if (field.Equals("MBI"))
                    {
                        string va = values[0];

                        Assert.IsTrue(values[0].ToLower().Contains(expectedValue.ToLower()), "Expected field value is not displayed");
                        fw.ConsoleReport(va + " MBI is found on Downloaded File");
                        break;
                    }
                    else if (field.Equals("ADDRESS1"))
                    {
                        string ADD1 = GlobalRef.ADD1.ToString();
                        string va = values[39];

                        Assert.IsTrue(values[39].Contains(ADD1), "Expected field value is not displayed");
                        break;
                    }

                    else if (field.Equals("ADDRESS2"))
                    {
                        string ADD1 = GlobalRef.ADD2.ToString();
                        string va = values[40];

                        Assert.IsTrue(values[40].Contains(ADD1), "Expected field value is not displayed");
                        break;
                    }

                    else
                    {
                        Console.WriteLine(" ");
                        break;
                    }
                }




                
            }
        }


        [Then(@"Verify Downloaded Legacy Member file should contains (.*) records")]
        public void ThenVerifyDownloadedLegacyMemberFileShouldContainsRecords(int p0)
        {
            string field = p0.ToString();
            tmsWait.Hard(5);    //Wait for download, save and reading purpose


            var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
            int filecount = newFilePaths.Length;
            var srcFile = Path.Combine(downloadPath, newFilePaths[filecount - 1]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
                var values = line.Split(',');

            }
            fw.ConsoleReport(" Legacy Member File contains " + (count - 2));
            Assert.AreEqual(p0, (count - 2), " Expected record count are not matching");
        }


        [Then(@"Verify Downloaded Legacy Transaction file should contains (.*) records")]
        public void ThenVerifyDownloadedLegacyTransactionFileShouldContainsRecords(int p0)
        {
            string field = p0.ToString();
            tmsWait.Hard(5);    //Wait for download, save and reading purpose
           

            var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
            int filecount = newFilePaths.Length;
            var srcFile = Path.Combine(downloadPath, newFilePaths[filecount - 1]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
                var values = line.Split(',');

            }
            fw.ConsoleReport(" Legacy Transaction File contains " + (count-2));
            Assert.AreEqual(p0, (count - 2), " Expected record count are not matching");
        }


        [Then(@"Verify Downloaded Legacy Transaction file Field ""(.*)"" is set to First Record Noted MBI")]
        public void ThenVerifyDownloadedLegacyTransactionFileFieldIsSetToFirstRecordNotedMBI(string p0)
        {
            string field = p0.ToString();
            tmsWait.Hard(5);    //Wait for download, save and reading purpose
            string expectedValue = GlobalRef.TransMBI;
            //string expectedValue = tmsCommon.GenerateData(p1);

            var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
            int filecount = newFilePaths.Length;
            var srcFile = Path.Combine(downloadPath, newFilePaths[filecount - 1]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
                var values = line.Split(',');
                if (count > 1)
                {
                    //    if (values[3].Equals("51") || values[3].Equals("61"))
                    //    {
                    if (field.Equals("LIS Level"))
                    {
                        Assert.IsTrue(values[114].Contains(expectedValue), "Expected Field Value is dislayed.");
                        break;
                    }
                    else if (field.Equals("LIS Co-Pay Category"))
                    {
                        Assert.IsTrue(values[115].Contains(expectedValue), "Expected Field Value is dislayed.");
                        break;
                    }
                    else if (field.Equals("LIS Effective Date"))
                    {
                        Assert.IsTrue(values[116].Contains(expectedValue), "Expected Field Value is dislayed.");
                        break;
                    }
                    else if (field.Equals("LIS Amount"))
                    {
                        Assert.IsTrue(values[117].Contains(expectedValue), "Expected Field Value is dislayed.");
                        break;
                    }

                    else if (field.Equals("MBI"))
                    {
                        tmsWait.Hard(2);
                        string va = values[0];
                        tmsWait.Hard(1);
                        Assert.IsTrue(values[0].ToLower().Contains(expectedValue.ToLower()), "Expected field value is not displayed");
                        fw.ConsoleReport(va + " MBI is found on Downloaded File");
                        break;
                    }
                    else if (field.Equals("ADDRESS1"))
                    {
                        string ADD1 = GlobalRef.ADD1.ToString();
                        string va = values[39];

                        Assert.IsTrue(values[39].Contains(ADD1), "Expected field value is not displayed");
                        break;
                    }

                    else if (field.Equals("MODADDRESS1"))
                    {
                        string ADD1 = GlobalRef.MODADD1.ToString();
                        string va = values[39];

                        Assert.IsTrue(values[39].Contains(ADD1), "Expected field value is not displayed");
                        break;
                    }
                    else if (field.Equals("MODADDRESS2"))
                    {
                        string ADD1 = GlobalRef.MODADD2.ToString();
                        string va = values[40];

                        Assert.IsTrue(values[40].Contains(ADD1), "Expected field value is not displayed");
                        break;
                    }

                    else
                    {
                        Console.WriteLine(" ");
                        break;
                    }
                }




                //}
            }

        }



        [Then(@"Verify Downloaded Legacy Transaction file Field ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyDownloadedLegacyTransactionFileFieldIsSetTo(string p0, string p1)
        {
            string field = p0.ToString();
            tmsWait.Hard(5);    //Wait for download, save and reading purpose
            string expectedValue = GlobalRef.TransMBI.ToString();
            //string expectedValue = tmsCommon.GenerateData(p1);
            
            var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
            int filecount = newFilePaths.Length;
            var srcFile = Path.Combine(downloadPath, newFilePaths[filecount-1]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
                var values = line.Split(',');
                if (count > 1)
                {
                //    if (values[3].Equals("51") || values[3].Equals("61"))
                //    {
                        if (field.Equals("LIS Level"))
                        {
                            Assert.IsTrue(values[114].Contains(expectedValue), "Expected Field Value is dislayed.");
                            break;
                        }
                        else if (field.Equals("LIS Co-Pay Category"))
                        {
                            Assert.IsTrue(values[115].Contains(expectedValue), "Expected Field Value is dislayed.");
                            break;
                        }
                        else if (field.Equals("LIS Effective Date"))
                        {
                            Assert.IsTrue(values[116].Contains(expectedValue), "Expected Field Value is dislayed.");
                            break;
                        }
                        else if (field.Equals("LIS Amount"))
                        {
                            Assert.IsTrue(values[117].Contains(expectedValue), "Expected Field Value is dislayed.");
                            break;
                        }

                        else if(field.Equals("MBI"))
                        {
                            string va = values[0];
                            
                            Assert.IsTrue(values[0].Contains(expectedValue), "Expected field value is not displayed");
                            break;
                        }
                    else if (field.Equals("ADDRESS1"))
                    {
                        string ADD1 = GlobalRef.ADD1.ToString();
                        string va = values[39];

                        Assert.IsTrue(values[39].Contains(ADD1), "Expected field value is not displayed");
                        break;
                    }

                    else if (field.Equals("ADDRESS2"))
                    {
                        string ADD1 = GlobalRef.ADD2.ToString();
                        string va = values[40];

                        Assert.IsTrue(values[40].Contains(ADD1), "Expected field value is not displayed");
                        break;
                    }

                    else
                        {
                            Console.WriteLine(" ");
                            break;
                        }
                    }
                            
                            
               
                    
                //}
            }

        }


        [Then(@"Verify Downloaded Legacy file Field (.*) is set to ""(.*)""")]
        public void ThenVerifyDownloadedLegacyFileFieldIsSetTo(int p0, string p1)
        {

            tmsWait.Hard(5);    //Wait for download, save and reading purpose
            string expectedValue = p1.ToString();
            var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
            var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
                var values = line.Split(',');
                if (count > 1)
                {
                    Assert.IsTrue(values[12].Contains(expectedValue), "Expected Field Value is dislayed.");
                    fw.ConsoleReport(" Legacy File Field number 13 displayed Expected value as " + p1);
                    break;
                }
            }

        }


        //Gurdeep Arora - Updated for Angular changes - 09/14/2020
        [When(@"Mailing List From Transactions Export page Disenrollment Reason dropdown list is set to ""(.*)""")]
        public void WhenMailingListFromTransactionsExportPageDisenrollmentReasonDropdownListIsSetTo(string p0)
        {
            tmsWait.Hard(2);

            string reason = tmsCommon.GenerateData(p0);
            GlobalRef.DISENRL = reason;
            IWebElement drp;
            IWebElement element;
            if (ConfigFile.tenantType == "tmsx")
            {
                drp = Browser.Wd.FindElement(By.XPath("//*[@test-id='transMailing-select-disenrollmentReasons']/span/span"));
                fw.ExecuteJavascript(drp);
                tmsWait.Hard(2);
                element = Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + reason + "')]"));
                fw.ExecuteJavascript(element);
            }
            else
            {
                drp = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='disenrollmentReasons_listbox']"));
                fw.ExecuteJavascript(drp);
                tmsWait.Hard(2);
                element = Browser.Wd.FindElement(By.XPath("//ul[@id='disenrollmentReasons_listbox']/li[contains(.,'" + reason + "')]"));
                fw.ExecuteJavascript(element);
            }

        }

        [When(@"Mailing List From Transactions Export page Go button is Clicked")]
        public void WhenMailingListFromTransactionsExportPageGoButtonIsClicked()
        {

            TMSoR1.EAM.MailingListTransExport.Gobutton.Click();
        }

        [When(@"Mailing List From Transactions Export page Export button is Clicked")]
        public void WhenMailingListFromTransactionsExportPageExportButtonIsClicked()
        {
            TMSoR1.EAM.MailingListTransExport.Exportbutton.Click();
        }





        [Then(@"Verify Downloaded Create Retro file Ret Enrl Tab displayed ""(.*)""")]
        public void ThenVerifyDownloadedCreateRetroFileRetEnrlTabDisplayed(string p0)
        {


            tmsWait.Hard(5);    //Wait for download, save and reading purpose
                                //var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.xls");
            var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
            
            String con = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + srcFile + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=2\"";
            object[] meta = new object[10];
            using (OleDbConnection connection = new OleDbConnection(con))
            {
                if (connection.State == ConnectionState.Closed) 

                connection.Open();

                try
                {
                    OleDbCommand command = new OleDbCommand("select * from [Ret Enrl$]", connection);
                    using (OleDbDataReader dr = command.ExecuteReader())
                    {
                        while (dr.Read())
                        {

                            int NumberOfColums = dr.GetValues(meta);

                            for (int i = 0; i < NumberOfColums; i++)
                            {

                                if (meta[i].ToString().Equals(p0))
                                {
                                    Console.Write("Excel file displayed {0} data on RetEnrl tab ", meta[i].ToString());
                                    Assert.AreEqual(p0, meta[i].ToString(), "Both are matching");
                                    break;
                                }
                            }

                            Console.WriteLine();
                            //read = dr.Read();
                        }
                    }
                }

                
                catch
            {
                // Exception Msg 

            }
            finally
            {
               
                    connection.Close();
            }
        }


        }


        [Then(@"Verify Mailing List Excel Disenrollment code ""(.*)"" is displayed")]
        public void ThenVerifyMailingListExcelDisenrollmentCodeIsDisplayed(string p0)
        {

            tmsWait.Hard(5);    //Wait for download, save and reading purpose
            var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.csv");
            var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
                var values = line.Split(',');
                if (values[25].Equals(p0))
                {
                    Assert.IsTrue(values[25].Contains(p0), "Disenrollment Code is not found as per expected.");
                    break;
                }
            }
        }

        [When(@"Mailing List From TRR Export Plan Id drop down is set to ""(.*)""")]
        public void WhenMailingListFromTRRExportPlanIdDropDownIsSetTo(string p0)
        {
            IWebElement planid = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlPlanID"));
            SelectElement plan = new SelectElement(planid);
            plan.SelectByText(p0);
        }

        [When(@"POS Drug Edit page HIC is set to ""(.*)""")]
        public void WhenPOSDrugEditPageHICIsSetTo(string p0)
        {
            IWebElement hic = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_tbxHic"));
            hic.SendKeys(p0);
            
        }

        [When(@"POS Drug Edit page ""(.*)"" button is Clicked")]
        public void WhenPOSDrugEditPageButtonIsClicked(string p0)
        {
            IWebElement hic;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                hic = Browser.Wd.FindElement(By.CssSelector("[test-id='tc90btn-reset']"));
                fw.ExecuteJavascript(hic);
                tmsWait.Hard(3);
            }
            else
            {
                 hic = Browser.Wd.FindElement(By.CssSelector("[test-id='tc90-btn-reset']"));

                fw.ExecuteJavascript(hic);
                tmsWait.Hard(3);
            }
        }

        [Then(@"Verify POS Drug Edit page HIC field is set to ""(.*)""")]
        public void ThenVerifyPOSDrugEditPageHICFieldIsSetTo(string exp)
        {
            
            IWebElement hic = Browser.Wd.FindElement(By.CssSelector("[placeholder='Add MBI']"));
            bool results = hic.Displayed;
            Assert.IsTrue(results," Expeceted MBI is not reset");
           
        }

        [When(@"TC (.*) Drug Edit Transaction Page HIC is set value to ""(.*)""")]
        public void WhenTCDrugEditTransactionPageHICIsSetValueTo(int p0, string p1)
        {
            IWebElement hic = Browser.Wd.FindElement(By.CssSelector("[placeholder='Add MBI']"));
            hic.SendKeys(p1);
            hic.SendKeys(OpenQA.Selenium.Keys.Tab);
        }

        [When(@"TC (.*) Drug Edit Transaction Page HIC is set value to Noted MBI")]
        public void WhenTCDrugEditTransactionPageHICIsSetValueToNotedMBI(int p0)


        {
            string str = GlobalRef.MBI.ToString();
            IWebElement hic = Browser.Wd.FindElement(By.XPath("//input[@placeholder='Add MBI']"));
            hic.SendKeys(str);

           
        }


        [Then(@"Verify POS Drug Edit page Plan field is set to ""(.*)""")]
        public void ThenVerifyPOSDrugEditPagePlanFieldIsSetTo(string expResults)
        {
            IWebElement planid;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                planid = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='tc90-select-planId']//span[@class='k-input']"));
            }
            else
            {
                 planid = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='ddlPlanId_listbox']//span[@class='k-input ng-scope']"));
            }
           string actualResults = planid.Text;
           
            Assert.AreEqual(expResults, actualResults, "Both values not matching");

        }



        [When(@"POS Drug Edit page Plan is set to ""(.*)""")]
        public void WhenPOSDrugEditPagePlanIsSetTo(string p0)
        {
            IWebElement planid = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlPlans"));
            SelectElement plan = new SelectElement(planid);
            plan.SelectByText(p0);
        }


        [Then(@"Verify Mailing List From TRR Export PBP ID drop down displays ""(.*)""")]
        public void ThenVerifyMailingListFromTRRExportPBPIDDropDownDisplays(string expected)
        {
            IWebElement pbp = Browser.Wd.FindElement(By.XPath("//select[@id='ctl00_ctl00_MainMasterContent_MainContent_ddlPBPID']//option[contains(.,'"+expected+"')]"));
            Assert.IsTrue(pbp.Displayed, pbp + "is not getting displayed");         
            
        }


        [Then(@"Verify EAM ""(.*)"" file Contains Election Type Value on Position ""(.*)""")]
        public void ThenVerifyEAMFileContainsElectionTypeValueOnPosition(string type, string position)
        {
            string electionType = position.ToString();

            if (type.Equals("Legacy Member"))
            {
                tmsWait.Hard(5);    //Wait for download, save and reading purpose
                var count = 0;
                var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
                //var newFilePaths = Directory.GetFiles(@"" + downloadPath +"\\"+ "Mailing20180308_1652.txt");
                // var srcFile = @"c:\TMS\FL001_Legacy_Mem_20180309_1288.txt";
                var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
                var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
                while (!reader.EndOfStream)
                {
                    count++;
                    var line = reader.ReadLine();
                    var values = line.Split(',');
                    if (count > 1)
                    {
                        Assert.IsTrue(values[7].Equals(electionType), "Expected Element is not getting Displayed.");
                        break;
                    }
                }
                reader.Close();
            }
        }

        [Then(@"Verify EAM ""(.*)"" flat file Field ""(.*)"" Contains ""(.*)"" is set on Start Position ""(.*)"" Length ""(.*)""")]
        public void ThenVerifyEAMFlatFileFieldContainsIsSetOnStartPositionLength(string typeofExport, string type, string p2, int startPos, int length)
        {
          

        string actualValue;

        string expectedValue = tmsCommon.GenerateData(p2);

            if (typeofExport.Equals("CMS File"))
            {
                tmsWait.Hard(3);    //Wait for download, save and reading purpose
                var count = 0;
                var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");

                var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
                var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
                while (!reader.EndOfStream)
                {
                    count++;
                    var line = reader.ReadLine();
                    var values = line.Split(',');
                    if (count > 1)
                    {

                        if (type.Equals("MBI"))
                        {
                            actualValue = ReUsableFunctions.returnSubStringValue(line, startPos, length);
                               
                            Assert.IsTrue(actualValue.Contains(expectedValue), "Expected MBI is not getting Displayed.");
                            break;
                        }
                        if (type.Equals("Contract"))
                        {
                            actualValue = ReUsableFunctions.returnSubStringValue(line, startPos, length);

                            Assert.IsTrue(actualValue.Contains(expectedValue), "Expected Contract is not getting Displayed.");
                            break;
                        }
                        
                        if (type.Equals("FirstName"))
                        {
                            actualValue = ReUsableFunctions.returnSubStringValue(line, startPos, length);

                            Assert.IsTrue(expectedValue.Contains(actualValue), "Expected FirstName is not getting Displayed.");
                            break;
                        }
                        if (type.Equals("SurName"))
                        {
                            actualValue = ReUsableFunctions.returnSubStringValue(line, startPos, length);

                            Assert.IsTrue(actualValue.Contains(expectedValue), "Expected SureName is not getting Displayed.");
                            break;
                        }

                        if (type.Equals("Male"))
                        {
                            
                            actualValue = ReUsableFunctions.returnSubStringValue(line, startPos, length);

                            Assert.IsTrue(actualValue.Equals(expectedValue), "Expected Gender is not getting Displayed.");
                            break;
                        }

                        if (type.Equals("BirthDate"))
                        {
                            string[] dob= expectedValue.Split('/');
                            string modifiedExpectedValue = dob[2] + dob[1] + dob[0];
                            actualValue = ReUsableFunctions.returnSubStringValue(line, startPos, length);

                            Assert.IsTrue(actualValue.Contains(modifiedExpectedValue), "Expected DOB is not getting Displayed.");
                            break;
                        }
                        if (type.Equals("DeleteFlag"))
                        {
                            actualValue = ReUsableFunctions.returnSubStringValue(line, startPos, length);

                            Assert.IsTrue(actualValue.Equals(expectedValue), "Expected DeleteFlag is not getting Displayed.");
                            break;
                        }
                        if (type.Equals("UpdateFlag"))
                        {
                            actualValue = ReUsableFunctions.returnSubStringValue(line, startPos, length);

                            Assert.IsTrue(actualValue.Equals(expectedValue), "Expected UpdateFlag is not getting Displayed.");
                            break;
                        }
                        if (type.Equals("POSEditStatus"))
                        {
                            actualValue = ReUsableFunctions.returnSubStringValue(line, startPos, length);

                            Assert.IsTrue(actualValue.Equals(expectedValue), "Expected POSEditStatus is not getting Displayed.");
                            break;
                        }

                        

                        //if (type.Equals("LIS LEVEL"))
                        //{
                        //    Assert.IsTrue(values[114].Equals(Value), "Expected Element is not getting Displayed.");
                        //    break;
                        //}

                        //if (type.Equals("COPAY CAT"))
                        //{
                        //    Assert.IsTrue(values[115].Equals(Value), "Expected Element is not getting Displayed.");
                        //    break;
                        //}

                        //if (type.Equals("Election Type"))
                        //{
                        //    Assert.IsTrue(values[7].Equals(Value), "Expected Element is not getting Displayed.");
                        //    break;
                        //}
                        //if (type.Equals("Last Name"))
                        //{
                        //    Assert.IsTrue(values[25].Equals(Value), "Expected Element is not getting Displayed.");
                        //    break;
                        //}


                        //if (type.Equals("SSN"))
                        //{
                        //    Assert.IsTrue(values[13].Equals(Value), "Expected Element is not getting Displayed.");
                        //    break;
                        //}
                        //if (type.Equals("Language"))
                        //{
                        //    Assert.IsTrue(values[33].Equals(Value), "Expected Element is not getting Displayed.");
                        //    break;
                        //}
                        //if (type.Equals("Marital Status"))
                        //{
                        //    Assert.IsTrue(values[31].Equals(Value), "Expected Element is not getting Displayed.");
                        //    break;
                        //}
                    }
                }
                reader.Close();
            }
        }

        [Then(@"Verify EAM Legacy Member file ""(.*)"" field ""(.*)"" value set on Position ""(.*)""")]
        public void ThenVerifyEAMLegacyMemberFileFieldValueSetOnPosition(string type, string p1, int position)
        {
            tmsWait.Hard(3);
            string Value = tmsCommon.GenerateData(p1);

           
                tmsWait.Hard(5);    //Wait for download, save and reading purpose
                var count = 0;
                var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");

                var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
                var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
                while (!reader.EndOfStream)
                {
                    count++;
                    var line = reader.ReadLine();
                    var values = line.Split(',');
                    if (count > 1)
                    {
                                           
                        if (type.Equals("ESRD"))
                        {
                            Assert.IsTrue(values[position-1].Equals(Value), "Expected Element is not getting Displayed.");
                            break;
                        }                                  

                    }
                }
                reader.Close();
            
        }

        [Then(@"Verify EAM Legacy Member file contains value ""(.*)""")]
        public void ThenVerifyEAMLegacyMemberFileContainsValue(string p0)
        {
            tmsWait.Hard(3);
            string value = tmsCommon.GenerateData(p0);

            //if ((typeofExport.Equals("Legacy Member")) || (typeofExport.Equals("Legacy Transaction")))
            //{
                tmsWait.Hard(10);    //Wait for download, save and reading purpose
                var count = 0;
                var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");

                var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
                var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
                while (!reader.EndOfStream)
                {
                    count++;
                    var line = reader.ReadLine();
                    var values = line.Split(',');
                    if (count > 1)
                    {
                        Assert.IsTrue(line.Contains(value));
                        break;
                    }
                }
           // }
        }


        [Then(@"Verify EAM ""(.*)"" file Contains ""(.*)"" is set on Position ""(.*)""")]
        [Given(@"Verify EAM ""(.*)"" file Contains ""(.*)"" is set on Position ""(.*)""")]
        public void ThenVerifyEAMFileContainsIsSetOnPosition(string typeofExport, string type, string p0)
        {
            tmsWait.Hard(3);
            string Value = tmsCommon.GenerateData(p0);

            if ((typeofExport.Equals("Legacy Member")) || (typeofExport.Equals("Legacy Transaction")))
            {
                tmsWait.Hard(10);    //Wait for download, save and reading purpose
                var count = 0;
                var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
                
                var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
                var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
                while (!reader.EndOfStream)
                {
                    count++;
                    var line = reader.ReadLine();
                    var values = line.Split(',');
                    if (count > 1)
                    {

                        if (type.Equals("MBI"))
                        {
                            Assert.IsTrue(values[0].Equals(Value), "Expected Element is not getting Displayed.");
                            break;
                        }
                        if (type.Equals("Medicaid"))
                        {
                            Assert.IsTrue(values[146].Equals(Value), "Expected Element is not getting Displayed.");
                            break;
                        }
                        if (type.Equals("ESRD"))
                        {
                            Assert.IsTrue(values[146].Equals(Value), "Expected Element is not getting Displayed.");
                            break;
                        }


                        if (type.Equals("LIS EFF DATE"))
                        {
                            Assert.IsTrue(values[116].Equals(Value), "Expected Element is not getting Displayed.");
                            break;
                        }

                        if (type.Equals("LIS LEVEL"))
                        {
                            Assert.IsTrue(values[114].Equals(Value), "Expected Element is not getting Displayed.");
                            break;
                        }

                        if (type.Equals("COPAY CAT"))
                        {
                            Assert.IsTrue(values[115].Equals(Value), "Expected Element is not getting Displayed.");
                            break;
                        }

                        if (type.Equals("Election Type"))
                        {
                            Assert.IsTrue(values[7].Equals(Value), "Expected Element is not getting Displayed.");
                            break;
                        }
                        if (type.Equals("Last Name"))
                        {
                            Assert.IsTrue(values[25].Equals(Value.ToUpper()), "Expected Element is not getting Displayed.");
                            break;
                        }

                        
                        if (type.Equals("SSN"))
                        {
                            Assert.IsTrue(values[13].Equals(Value), "Expected Element is not getting Displayed.");
                            break;
                        }
                        if (type.Equals("Language"))
                        {
                            Assert.IsTrue(values[33].Equals(Value), "Expected Element is not getting Displayed.");
                            break;
                        }
                       if (type.Equals("Marital Status"))
                        {
                            Assert.IsTrue(values[31].Equals(Value), "Expected Element is not getting Displayed.");
                            break;
                        }
                        if (type.Equals("Plan10"))
                        {
                            Assert.IsTrue(values[113].Equals(Value), "Expected Element is not getting Displayed.");
                            break;
                        }
                    }
                }
                reader.Close();
            }
        }

        [Then(@"Verify EAM ""(.*)"" file Contains MSRD Value on Position ""(.*)""")]
        public void ThenVerifyEAMFileContainsMSRDValueOnPosition(string type, int position)
        {
            tmsWait.Hard(2);
            string language = position.ToString();

            if (type.Equals("Legacy Member"))
            {
                tmsWait.Hard(8);    //Wait for download, save and reading purpose
                var count = 0;
                var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
                //var newFilePaths = Directory.GetFiles(@"" + downloadPath +"\\"+ "Mailing20180308_1652.txt");
                // var srcFile = @"c:\TMS\FL001_Legacy_Mem_20180309_1288.txt";
                var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
                var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
                while (!reader.EndOfStream)
                {
                    count++;
                    var line = reader.ReadLine();
                    var values = line.Split(',');
                    if (count > 1)
                    {
                        Assert.IsTrue(values[33].Equals(language), "Expected Element is not getting Displayed.");
                        break;
                    }
                }
                reader.Close();
            }

        }


        [Then(@"Verify EAM ""(.*)"" file Contains Language Value on Position ""(.*)""")]
        public void ThenVerifyEAMFileContainsLanguageValueOnPosition(string type, int position)
        {
            tmsWait.Hard(2);
            string language = position.ToString();

            if (type.Equals("Legacy Member"))
            {
                tmsWait.Hard(8);    //Wait for download, save and reading purpose
                var count = 0;
                var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
                //var newFilePaths = Directory.GetFiles(@"" + downloadPath +"\\"+ "Mailing20180308_1652.txt");
                // var srcFile = @"c:\TMS\FL001_Legacy_Mem_20180309_1288.txt";
                var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
                var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
                while (!reader.EndOfStream)
                {
                    count++;
                    var line = reader.ReadLine();
                    var values = line.Split(',');
                    if (count > 1)
                    {
                        Assert.IsTrue(values[33].Equals(language), "Expected Element is not getting Displayed.");
                        break;
                    }
                }
                reader.Close();
            }
            

        }
        [When(@"Verify EAM Legacy Member file Contains ""(.*)"" Value ""(.*)"" and ""(.*)"" and ""(.*)"" and ""(.*)"" are on Position ""(.*)""")]
        public void WhenVerifyEAMLegacyMemberFileContainsValueAndAndAndAreOnPosition(string type, string p1, string p2, string p3, string p4, int position)
        {
           
        string fieldType = tmsCommon.GenerateData(type);
            System.Collections.Generic.List<String> value = new System.Collections.Generic.List<string> { tmsCommon.GenerateData(p1), tmsCommon.GenerateData(p2), tmsCommon.GenerateData(p3), tmsCommon.GenerateData(p4)};
            int pos = position;
            int length = 0;


            tmsWait.Hard(5);    //Wait for download, save and reading purpose
            var count = 0;
            var i = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");

            var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            bool actResults;
            //bool valuateBreakFlag = false;
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
                var values = line.Split(',');
                if (count > 1 && count <=value.Count+1)
                {
                    switch (fieldType)
                    {
                       

                        case "MBI":
                            actResults = filecontentValidation(values, pos, length, value[i]);
                            Assert.IsTrue(actResults, "Expected Value is not getting Displayed on File.");
                          
                            fw.ConsoleReport(fieldType + value[i]+" field is found on Position " + pos);
                            ///valuateBreakFlag = true;
                            i = i + 1;
                            break;

                        case "MBIChange":
                            actResults = filecontentValidation(values, pos, length, value[i]);
                            Assert.IsTrue(actResults, "Expected Value is not getting Displayed on File.");

                            fw.ConsoleReport(fieldType + value[i] + " field is found on Position " + pos);
                            ///valuateBreakFlag = true;
                            i = i + 1;
                            break;

                    }

                }
            }
            reader.Close();

        }


        [When(@"Verify EAM Legacy Member file Contains ""(.*)"" Value ""(.*)"" on Position ""(.*)""")]
        public void WhenVerifyEAMLegacyMemberFileContainsValueOnPosition(string type, string element, string position)
        {
            string fieldType = tmsCommon.GenerateData(type);
            string value = tmsCommon.GenerateData(element);
            int pos = Convert.ToInt32(tmsCommon.GenerateData(position));
            int length = 0;


            tmsWait.Hard(5);    //Wait for download, save and reading purpose
            var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");

            var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            bool actResults;
            bool valuateBreakFlag = false;
            while (!reader.EndOfStream && !valuateBreakFlag)
            {
                count++;
                var line = reader.ReadLine();
                var values = line.Split(',');
                if (count > 1)
                {
                    switch (fieldType)
                    {
                        case "GroupID":
                            actResults = filecontentValidation(values, pos, length, value);
                            Assert.IsTrue(actResults, "Expected Value is not getting Displayed on File.");
                            fw.ConsoleReport(fieldType + " field is found on Position " + pos);
                            valuateBreakFlag = true;
                            break;

                        case "SubGroupID":
                            actResults = filecontentValidation(values, pos, length, value);
                            Assert.IsTrue(actResults, "Expected Value is not getting Displayed on File.");
                            fw.ConsoleReport(fieldType + " field is found on Position " + pos);
                            valuateBreakFlag = true;
                            break;

                        case "Class":
                            actResults = filecontentValidation(values, pos, length, value);
                            Assert.IsTrue(actResults, "Expected Value is not getting Displayed on File.");
                            fw.ConsoleReport(fieldType + " field is found on Position " + pos);
                            valuateBreakFlag = true;
                            break;

                        case "MedicalID":
                            actResults = filecontentValidation(values, pos, length, value);
                            Assert.IsTrue(actResults, "Expected Value is not getting Displayed on File.");
                            fw.ConsoleReport(fieldType + " field is found on Position " + pos);
                            valuateBreakFlag = true;
                            break;

                        case "MBI1":
                            actResults = filecontentValidation(values, pos, length, value);
                            Assert.IsTrue(actResults, "Expected Value is not getting Displayed on File.");
                            fw.ConsoleReport(fieldType + " field is found on Position " + pos);
                            valuateBreakFlag = true;
                            break;

                        case "PharmacyID":
                            actResults = filecontentValidation(values, pos, length, value);
                            Assert.IsTrue(actResults, "Expected Value is not getting Displayed on File.");
                            fw.ConsoleReport(fieldType + " field is found on Position " + pos);
                            valuateBreakFlag = true;
                            break;

                        case "DentalID":
                            actResults = filecontentValidation(values, pos, length, value);
                            Assert.IsTrue(actResults, "Expected Value is not getting Displayed on File.");
                            fw.ConsoleReport(fieldType + " field is found on Position " + pos);
                            valuateBreakFlag = true;
                            break;
                        case "VisionID":
                            actResults = filecontentValidation(values, pos, length, value);
                            Assert.IsTrue(actResults, "Expected Value is not getting Displayed on File.");
                            fw.ConsoleReport(fieldType + " field is found on Position " + pos);
                            valuateBreakFlag = true;
                            break;

                    }

                }
            }
            reader.Close();

        }


        [Then(@"Verify EAM Legacy Transaction file Contains ""(.*)"" Value ""(.*)"" on Position ""(.*)"" and Length ""(.*)""")]
        [Then(@"Verify EAM Legacy Member file Contains ""(.*)"" Value ""(.*)"" on Position ""(.*)"" and Length ""(.*)""")]
       public void ThenVerifyEAMLegacyMemberFileContainsValueOnPositionAndLength(string p0, string p1, string p2, string p3)
        {
            
            string fieldType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            int pos = Convert.ToInt32(tmsCommon.GenerateData(p2));
            int length= Convert.ToInt32(tmsCommon.GenerateData(p3));


            tmsWait.Hard(5);    //Wait for download, save and reading purpose
                var count = 0;
                var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
                
                var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
                var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            bool actResults;
            bool valuateBreakFlag = false;
                while (!reader.EndOfStream && !valuateBreakFlag)
                {
                    count++;
                    var line = reader.ReadLine();
                    var values = line.Split(',');
                    if (count > 1)
                    {
                    switch(fieldType)
                    {
                        case "GroupID":
                            actResults = filecontentValidation(values,pos, length, value);
                            Assert.IsTrue(actResults, "Expected Value is not getting Displayed on File.");
                            fw.ConsoleReport(fieldType + " field is found on Position " + pos);
                            valuateBreakFlag = true;
                            break;

                        case "SubGroupID":
                            actResults = filecontentValidation(values, pos, length, value);
                            Assert.IsTrue(actResults, "Expected Value is not getting Displayed on File.");
                            fw.ConsoleReport(fieldType + " field is found on Position " + pos);
                            valuateBreakFlag = true;
                            break;

                        case "Class":
                            actResults = filecontentValidation(values, pos, length, value);
                            Assert.IsTrue(actResults, "Expected Value is not getting Displayed on File.");
                            fw.ConsoleReport(fieldType + " field is found on Position " + pos);
                            valuateBreakFlag = true;
                            break;

                        case "MedicalID":
                            actResults = filecontentValidation(values, pos, length, value);
                            Assert.IsTrue(actResults, "Expected Value is not getting Displayed on File.");
                            fw.ConsoleReport(fieldType + " field is found on Position " + pos);
                            valuateBreakFlag = true;
                            break;

                        case "PharmacyID":
                            actResults = filecontentValidation(values, pos, length, value);
                            Assert.IsTrue(actResults, "Expected Value is not getting Displayed on File.");
                            fw.ConsoleReport(fieldType + " field is found on Position " + pos);
                            valuateBreakFlag = true;
                            break;

                        case "DentalID":
                            actResults = filecontentValidation(values, pos, length, value);
                            Assert.IsTrue(actResults, "Expected Value is not getting Displayed on File.");
                            fw.ConsoleReport(fieldType + " field is found on Position " + pos);
                            valuateBreakFlag = true;
                            break;
                        case "VisionID":
                            actResults = filecontentValidation(values, pos, length, value);
                            Assert.IsTrue(actResults, "Expected Value is not getting Displayed on File.");
                            fw.ConsoleReport(fieldType + " field is found on Position " + pos);
                            valuateBreakFlag = true;
                            break;

                    }
                       
                    }
                }
                reader.Close();
            
           

        }

        bool filecontentValidation(string[] vals, int posi, int len, string val)
        {

          //  return vals[posi - 1].Substring(0, len).Equals(val);
          return vals[posi - 1].Equals(val);
        }

        [Then(@"Verify EAM ""(.*)"" file Contains ""(.*)"" Value on Position ""(.*)""")]
        public void ThenVerifyEAMFileContainsValueOnPosition(string type, string element, int position)
        {
            tmsWait.Hard(3);
            string maritalstatus = position.ToString();

            ReUsableFunctions.deleteFilesFromDownloadFolder();

            if (type.Equals("Legacy Member"))
            {
                tmsWait.Hard(10);    //Wait for download, save and reading purpose
                var count = 0;
                var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
                //var newFilePaths = Directory.GetFiles(@"" + downloadPath +"\\"+ "Mailing20180308_1652.txt");
                // var srcFile = @"c:\TMS\FL001_Legacy_Mem_20180309_1288.txt";
                var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
                var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
                while (!reader.EndOfStream)
                {
                    count++;
                    var line = reader.ReadLine();
                    var values = line.Split(',');
                    if (count > 1)
                    {
                        Assert.IsTrue(values[31].Equals(maritalstatus), "Expected Element is not getting Displayed.");
                        break;
                    }
                }
                reader.Close();
            }
            else
            {
                tmsWait.Hard(10);    //Wait for download, save and reading purpose
                var count = 0;
                var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.csv");
                //var newFilePaths = Directory.GetFiles(@"" + downloadPath +"\\"+ "Mailing20180308_1652.csv");
                // var srcFile = @"c:\TMS\Mailing20180308_1652.csv";
                var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
                var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
                while (!reader.EndOfStream)
                {
                    count++;
                    var line = reader.ReadLine();
                    var values = line.Split(',');
                    if (count > 1)
                    {
                        Assert.IsTrue(values[position - 1].Contains(element), "Expected Element is not getting Displayed.");
                        break;
                    }
                }
                reader.Close();

            }


        }

        [Then(@"Verify ""(.*)"" file Field Value ""(.*)"" on Position ""(.*)""")]
        public void ThenVerifyFileFieldValueOnPosition(string type, string Field, int position)
        {
            string mbi = GlobalRef.LTMBI.ToString();

            tmsWait.Hard(5);    //Wait for download, save and reading purpose
            var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.csv");         
            var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
                var values = line.Split(',');
                if (count > 1)
                {
                    switch(Field)
                    {
                        case "MBI":
                            Assert.IsTrue(values[position - 1].Contains(mbi), "Expected Element is not getting Displayed.");
                            break;
                    }
                    
               
                }
            }
            reader.Close();
        }


        [Then(@"Verify ""(.*)"" file Contain Value ""(.*)"" on Position ""(.*)""")]
        public void ThenVerifyFileContainValueOnPosition(string type, string element, int position)
        {
            string dis = GlobalRef.DISENRL.ToString();

            if (type.Equals("Legacy Member"))
            {
                tmsWait.Hard(5);    //Wait for download, save and reading purpose
                var count = 0;
                var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
                //var newFilePaths = Directory.GetFiles(@"" + downloadPath +"\\"+ "Mailing20180308_1652.txt");
                // var srcFile = @"c:\TMS\FL001_Legacy_Mem_20180309_1288.txt";
                var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
                var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
                while (!reader.EndOfStream)
                {
                    count++;
                    var line = reader.ReadLine();
                    var values = line.Split(',');
                    if (count > 1)
                    {
                        Assert.IsTrue(values[position - 1].Contains(dis), "Expected Element is not getting Displayed.");
                        break;
                    }
                }
                reader.Close();
            }
            else
            {
                tmsWait.Hard(5);    //Wait for download, save and reading purpose
                var count = 0;
                var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.csv");

                var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
                var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
                while (!reader.EndOfStream)
                {
                    count++;
                    var line = reader.ReadLine();
                    var values = line.Split(',');
                    tmsWait.Hard(1);
                    if (count > 1)
                    {
                        Assert.IsTrue(values[position - 1].Contains(element), "Expected Element is not getting Displayed.");
                        break;
                    }
                }
                reader.Close();

            }

        }

        public string returnSplitStringbyPosition(string input, string start, string end)
        {
            string temp = input.Substring((Convert.ToInt32(start)-1), (Convert.ToInt32(end)-1)); 
            return temp;
        }

        [Then(@"Verify CMS BEQ File file Contains Sex Value ""(.*)"" on Position ""(.*)""")]
        public void ThenVerifyCMSBEQFileFileContainsSexValueOnPosition(string value, string position)
        {
            string MBI = GlobalRef.MBI.ToString();
            string Sex = GlobalRef.Sex.ToString();
            string expectedValue="";
            if (Sex.Equals("M"))
            {
                 expectedValue = "1";
            }

            if (Sex.Equals("F"))
            {
                 expectedValue = "2";
            }
            string[] positions = position.Split('-');
            
            
            string actualValue;
            tmsWait.Hard(5);    //Wait for download, save and reading purpose
            var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");

            var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();

                if (count > 1)
                {
                    if ((line.Contains(expectedValue)) && (line.Contains(MBI)))
                    {
                        actualValue = line.Substring(34, 1);
                        Assert.AreEqual(expectedValue, actualValue.Trim(), " Both values are not matching");
                    }
                }
            }
            reader.Close();

        }


        [Then(@"Verify CMS BEQ File file Contains Date Of Birth Value ""(.*)"" on Position ""(.*)""")]
        public void ThenVerifyCMSBEQFileFileContainsDateOfBirthValueOnPosition(string value, string position)
        {
            string MBI = GlobalRef.MBI.ToString();
            string DOB = GlobalRef.DOB.ToString();
            string[] positions = position.Split('-');
            string expectedValue = tmsCommon.GenerateData(value);
            string actualValue;
            tmsWait.Hard(5);    //Wait for download, save and reading purpose
            var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");

            var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();

                if (count > 1)
                {
                    if ((line.Contains(expectedValue)) && (line.Contains(MBI)))
                    {
                        actualValue = returnSplitStringbyPosition(line, positions[0], positions[1]);
                        Assert.AreEqual(expectedValue, actualValue.Trim(), " Both values are not matching");
                    }
                }
            }
            reader.Close();
        }



        [Then(@"Verify CMS BEQ File file Contains MBI Value ""(.*)"" on Position ""(.*)""")]
        public void ThenVerifyCMSBEQFileFileContainsMBIValueOnPosition(string value, string position)
        {
         
           
        string MBI = GlobalRef.MBI.ToString();
            string[] positions = position.Split('-');
            string expectedValue = tmsCommon.GenerateData(value);
            string actualValue;
            tmsWait.Hard(5);    //Wait for download, save and reading purpose
            var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
           
            var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
                
                if (count > 1)
                {
                    if (line.Contains(expectedValue))
                    {
                        actualValue = returnSplitStringbyPosition(line, positions[0], positions[1]);
                        Assert.AreEqual(expectedValue, actualValue.Trim(), " Both values are not matching");
                    }
                }
            }
            reader.Close();
        }


        [Then(@"Verify CMS BEQ File file does not Contains MBI Value ""(.*)"" on Position ""(.*)""")]
        public void ThenVerifyCMSBEQFileFileDoesNotContainsMBIValueOnPosition(string value, string position)
        {
            string MBI = GlobalRef.MBI.ToString();
            string[] positions = position.Split('-');
            string expectedValue = tmsCommon.GenerateData(value);
            string actualValue;
            tmsWait.Hard(5);    //Wait for download, save and reading purpose
            var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");

            var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();

                if (count > 1)
                {
                    if (line.Contains(expectedValue))
                    {
                        actualValue = returnSplitStringbyPosition(line, positions[0], positions[1]);
                        Assert.AreNotEqual(expectedValue, actualValue.Trim(), " Both values are matching");
                    }
                }
            }
            reader.Close();
        }


        [Then(@"Verify ""(.*)"" file Contains Value ""(.*)"" on Position ""(.*)""")]
        public void ThenVerifyFileContainsValueOnPosition(string type, string element, int position)
        {
            string MBI = GlobalRef.MBI.ToString();
           
            if (type.Equals("Legacy Member"))
            {
                tmsWait.Hard(5);    //Wait for download, save and reading purpose
                var count = 0;
                var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.txt");
               //var newFilePaths = Directory.GetFiles(@"" + downloadPath +"\\"+ "Mailing20180308_1652.txt");
               // var srcFile = @"c:\TMS\FL001_Legacy_Mem_20180309_1288.txt";
                var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
                var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
                while (!reader.EndOfStream)
                {
                    count++;
                    var line = reader.ReadLine();
                    var values = line.Split(',');
                    if (count > 1)
                    {
                        Assert.IsTrue(values[position - 1].Contains(MBI), "Expected Element is not getting Displayed.");
                        fw.ConsoleReport(" Legacy Member File contains " + MBI);
                        break;
                    }
                }
                reader.Close();
            }
            else
            {
                tmsWait.Hard(5);    //Wait for download, save and reading purpose
                var count = 0;
                var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.csv");
                
                var srcFile = Path.Combine(downloadPath, newFilePaths[0]);
                var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
                while (!reader.EndOfStream)
                {
                    count++;
                    var line = reader.ReadLine();
                    var values = line.Split(',');
                    if (count > 1)
                    {
                        Assert.IsTrue(values[position - 1].Contains(element), "Expected Element is not getting Displayed.");
                        break;
                    }
                }
                reader.Close();

            }


        }


        [Then(@"In Excel file Reply Code ""(.*)"" is verified")]
        public void ThenInExcelFileReplyCodeIsVerified(string replyCode)
        {
            tmsWait.Hard(5);    //Wait for download, save and reading purpose
            var count = 0;
            //string[] fileExtensions = { ".txt", ".xls", ".csv" };
            //DirectoryInfo di = new DirectoryInfo(downloadPath);
            //FileInfo[] oldDownloadedFiles = di.EnumerateFiles().Where(p => fileExtensions.Contains(p.Extension, StringComparer.InvariantCultureIgnoreCase)).ToArray();
            //if (oldDownloadedFiles.Count() > 1)
            //{
            //    ReUsableFunctions.deleteFilesFromDownloadFolder();
            //}
            var newFilePaths = Directory.GetFiles(@"" + downloadPath + "", "*_*.csv");
            int tfiles = newFilePaths.Count();
            var srcFile = Path.Combine(downloadPath, newFilePaths[tfiles-1]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
                var values = line.Split(',');
                if (count > 1)
                {
                    Assert.IsTrue(values[40].Contains(replyCode), "Reply Code is as expected.");

                    fw.ConsoleReport(replyCode + " value found on Position 40");
                    break;
                }
            }
            reader.Close();
        }
    }
}
