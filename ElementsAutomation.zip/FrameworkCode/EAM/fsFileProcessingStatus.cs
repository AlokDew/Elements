﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows;
using System.Drawing;
//using System.Windows.Forms;
using System.IO;
using System.Linq;
using TMSoR1.FrameworkCode;

namespace TMSoR1
{
    [Binding]
    public class fsFileProcessingStatus
    {
        [When(@"Files Processed wait a maximum of ""(.*)"" seconds for FileName ""(.*)"" to have Status ""(.*)""")]
        [Given(@"Files Processed wait a maximum of ""(.*)"" seconds for FileName ""(.*)"" to have Status ""(.*)""")]
        [Then(@"Files Processed wait a maximum of ""(.*)"" seconds for FileName ""(.*)"" to have Status ""(.*)""")]
        public void WhenFilesProcessedWaitAMaximumOfSecondsForFileNameToHaveStatus(string p0, string p1, string p2)
        {
            string variableFileName = tmsCommon.GenerateData(p1);
            Boolean WaitingOnFileProcessing = FilesProcessingStatus.WaitOnFileProcessing(p0, variableFileName, p2);
            Console.WriteLine("File Processing Status Wait:  Success[" + WaitingOnFileProcessing + "].  Looking for file [" + variableFileName + "] to have status [" + p2 + "] in under [" + p0 + "] seconds.  Look in output file for what happened to the load.");
            Assert.AreEqual(true, WaitingOnFileProcessing, "File Processing Status Wait:  Success[" + WaitingOnFileProcessing + "].  Looking for file [" + variableFileName + "] to have status [" + p2 + "] in under [" + p0 + "] seconds.  Look in output file for what happened to the load.");
        }

        [When(@"EAM UI MOD File Processing Status page ""(.*)"" link is Clicked")]
        public void WhenEAMUIMODFileProcessingStatusPageLinkIsClicked(string p0)
        {

            string[] fileExtensions = { ".txt", ".xls", ".csv" };
            DirectoryInfo di = new DirectoryInfo(downloadFolderPath);
            tmsWait.Hard(5);
            FileInfo[] oldDownloadedFiles = di.EnumerateFiles().Where(p => fileExtensions.Contains(p.Extension, StringComparer.InvariantCultureIgnoreCase)).ToArray();


            foreach (var oldFile in oldDownloadedFiles)
            {
                oldFile.Attributes = FileAttributes.Normal;
                File.Delete(oldFile.FullName);
            }

            if (ConfigFile.EnvType.Equals("ESI") || ConfigFile.EnvType.Equals("Main"))
            {

                tmsWait.Hard(3);
                string actualPlanID;

                string fileName = tmsCommon.GenerateData(p0);
                if (p0.Equals("Mailing"))
                {
                    fileName = "Mailing" + DateTime.Today.ToString("yyyyMMdd");
                }
                if (p0.Equals("Mailing File"))
                {
                    fileName = "Mailing" + DateTime.Today.ToString("yyyyMMdd");
                }
                if (p0.Equals("Mailing List Transaction"))
                {
                    fileName = "Mailing" + DateTime.Today.ToString("yyyyMMdd");
                }
                if (p0.Equals("Span File"))
                {
                    fileName = "Spans" + DateTime.Today.ToString("yyyyMMdd");
                }


                if (p0.Equals("CMS BEQ File"))
                {
                    actualPlanID = GlobalRef.PlanID.ToString();
                    fileName = actualPlanID + "_BEQ" + DateTime.Today.ToString("yyyyMMdd");
                }



                if (p0.Equals("Legacy Member File"))
                {
                    actualPlanID = GlobalRef.PlanID.ToString();
                    if (actualPlanID.Equals("ALL") || (actualPlanID.Equals("All")))
                    {
                        fileName = "Legacy_Mem_" + DateTime.Today.ToString("yyyyMMdd");
                    }
                    else
                    {
                        fileName = actualPlanID + "_Legacy_Mem_" + DateTime.Today.ToString("yyyyMMdd");
                    }

                }
                if (p0.Equals("CMS Transfer File") || p0.Equals("CMS File"))
                {
                    actualPlanID = GlobalRef.PlanID.ToString();
                    if (actualPlanID.Equals("ALL") || (actualPlanID.Equals("All")))
                    {
                        fileName = "Trans" + DateTime.Today.ToString("yyyyMMdd");
                    }
                    else
                    {
                        fileName = actualPlanID + "_Trans" + DateTime.Today.ToString("yyyyMMdd");
                    }

                }

                if (p0.Equals("Legacy Transaction File"))
                {
                    actualPlanID = GlobalRef.PlanID.ToString();
                    if (actualPlanID.Equals("ALL") || (actualPlanID.Equals("All")))
                    {
                        fileName = "Legacy" + DateTime.Today.ToString("yyyyMMdd");
                    }
                    else
                    {
                        fileName = actualPlanID + "_Legacy" + DateTime.Today.ToString("yyyyMMdd");
                    }

                }

                string jobName = tmsCommon.GenerateData(p0);

                IWebElement drp;

                if (ConfigFile.tenantType == "tmsx")
                {
                    drp = Browser.Wd.FindElement(By.XPath("//*[@test-id='jobProcessingStatus-txt-ddlJobName']/span/span"));
                }
                else
                {
                    drp = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='ddlJobName_listbox']"));
                }

                fw.ExecuteJavascript(drp);
                tmsWait.Hard(2);

                By SearchBtn = By.CssSelector("[test-id='jobProcessingStatus-button-search']");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(SearchBtn);
                tmsWait.Hard(5);

                if (ConfigFile.tenantType == "tmsx")
                    importPlus = By.XPath("(//*[@title='Expand Details'])[1]");
                else
                    importPlus = By.XPath("(//a[@aria-label='Expand'])[1]");

                UIMODUtilFunctions.clickOnWebElementUsingLocators(importPlus);
                string xpath = "";
                if (p0.Equals("Legacy Member File"))
                {
                    if (ConfigFile.tenantType == "tmsx")
                        xpath = "//a[contains(.,'" + fileName + "')]";
                    else
                         xpath = "//a/p[contains(.,'"+fileName+"')]";
                }
                else
                {
                    if (ConfigFile.tenantType == "tmsx")
                        xpath = "//a[contains(.,'" + fileName + "')]";
                    else
                        xpath = "//a[contains(@title,'" + fileName + "')]";
                }
                    

          

                //By SearchButton = By.CssSelector("[test-id='trrlogging-btn-Search']");
                //fw.ExecuteJavascript(Browser.Wd.FindElement(SearchButton)); // Clicking on Serch button to avoid stale Element reference exception
              
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(xpath)));
                tmsWait.Hard(5);
            }
            else
            {
                tmsWait.Hard(3);
                string actualPlanID;

                string fileName = tmsCommon.GenerateData(p0);
                if (p0.Equals("Mailing"))
                {
                    fileName = "Mailing" + DateTime.Today.ToString("yyyyMMdd");
                }
                if (p0.Equals("Mailing File"))
                {
                    fileName = "Mailing" + DateTime.Today.ToString("yyyyMMdd");
                }
                if (p0.Equals("Span File"))
                {
                    fileName = "Spans" + DateTime.Today.ToString("yyyyMMdd");
                }


                if (p0.Equals("CMS BEQ File"))
                {
                    actualPlanID = GlobalRef.PlanID.ToString();
                    fileName = actualPlanID + "_BEQ" + DateTime.Today.ToString("yyyyMMdd");
                }



                if (p0.Equals("Legacy Member File"))
                {
                    actualPlanID = GlobalRef.PlanID.ToString();
                    if (actualPlanID.Equals("ALL") || (actualPlanID.Equals("All")))
                    {
                        fileName = "Legacy_Mem_" + DateTime.Today.ToString("yyyyMMdd");
                    }
                    else
                    {
                        fileName = actualPlanID + "_Legacy_Mem_" + DateTime.Today.ToString("yyyyMMdd");
                    }

                }
                if (p0.Equals("CMS Transfer File") || p0.Equals("CMS File"))
                {
                    actualPlanID = GlobalRef.PlanID.ToString();
                    if (actualPlanID.Equals("ALL") || (actualPlanID.Equals("All")))
                    {
                        fileName = "Trans" + DateTime.Today.ToString("yyyyMMdd");
                    }
                    else
                    {
                        fileName = actualPlanID + "_Trans" + DateTime.Today.ToString("yyyyMMdd");
                    }

                }

                if (p0.Equals("Legacy Transaction File"))
                {
                    actualPlanID = GlobalRef.PlanID.ToString();
                    if (actualPlanID.Equals("ALL") || (actualPlanID.Equals("All")))
                    {
                        fileName = "Legacy" + DateTime.Today.ToString("yyyyMMdd");
                    }
                    else
                    {
                        fileName = actualPlanID + "_Legacy" + DateTime.Today.ToString("yyyyMMdd");
                    }

                }

                string xpath;
                if (ConfigFile.tenantType == "tmsx")
                    xpath = "//tr[contains(., '" + fileName + "')]";
                else
                    xpath = "//tr/td[3][contains(.,'" + fileName + "')]/a";
                By SearchButton = By.CssSelector("[test-id='trrlogging-btn-Search']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(SearchButton)); // Clicking on Serch button to avoid stale Element reference exception
                tmsWait.Hard(2);
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(xpath)));
                tmsWait.Hard(4);
            }


        }

        [When(@"File Processing Status page ""(.*)"" link is Clicked")]
        public void WhenFileProcessingStatusPageLinkIsClicked(string p0)
        {
            string actualPlanID;
           
            string fileName = tmsCommon.GenerateData(p0);
            if (p0.Equals("Mailing"))
            {
                fileName = "Mailing" + DateTime.Today.ToString("yyyyMMdd");
            }
            if (p0.Equals("Legacy Member File"))
            {
                 actualPlanID = GlobalRef.PlanID.ToString();

                if (actualPlanID.Equals("ALL") || actualPlanID.Equals("All"))
                {
                    fileName = "Legacy_Mem_" + DateTime.Today.ToString("yyyyMMdd");
                }
                else
                {
                    fileName = actualPlanID + "_Legacy_Mem_" + DateTime.Today.ToString("yyyyMMdd");
                }
            }

            string xpath = "(//table[@id='ctl00_ctl00_MainMasterContent_MainContent_FileStatusGrid']//td/a[contains(.,'"+ fileName + "')])[1]";
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(xpath)));
        }

        [Then(@"Verify EAM Application File Prcessing status for FileName ""(.*)"" Message section")]
        public void ThenVerifyEAMApplicationFilePrcessingStatusForFileNameMessageSection(string p1)
        {
            if (ConfigFile.EnvType.Equals("ESI") || ConfigFile.EnvType.Equals("Main"))
            {
                fw.ConsoleReport(" There is no TRR Failure");

            }
            else
            {
                Browser.Wd.Navigate().Refresh();
                tmsWait.Hard(10);
                string fileName = tmsCommon.GenerateData(p1);
                string messageTxt;
                string message = "//tr/td[contains(.,'" + fileName + "')]/following-sibling::td/p";
                try
                {
                    messageTxt = Browser.Wd.FindElement(By.XPath(message)).Text.ToString();
                    if (messageTxt.Contains("SSIS package failed"))
                    {

                        Assert.Fail("Error in Loading TRR file due to SSIS Package Failed");
                    }
                }
               
                catch (NoSuchElementException e)
                {
                    fw.ConsoleReport(" TRR file is processed Successfully");
                }
                catch (WebDriverException e)
                {
                    fw.ConsoleReport(" TRR file is processed Successfully");
                }
                catch (Exception e)
                {
                    Assert.Fail("Error in Loading TRR file due to SSIS Package Failed");
                }
            }
        }

        [Then(@"Verify Letter Queue page should not display the Member Last Name as ""(.*)"" First Name as ""(.*)"" MBI as ""(.*)""")]
        public void ThenVerifyLetterQueuePageShouldNotDisplayTheMemberLastNameAsFirstNameAsMBIAs(string fname, string lname, string mbi)
        {
            tmsWait.Hard(5);
            string FirstName = tmsCommon.GenerateData(fname);
            string LastName = tmsCommon.GenerateData(lname);
            string MBIValue = tmsCommon.GenerateData(mbi);

            By letter = By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_dgLetters']//tr/td[contains(.,'" + FirstName + "')]/following-sibling::td[contains(.,'" + LastName + "')]/following-sibling::td[contains(.,'" + MBIValue + "')]");
            try
            {
                bool letterDisplay = Browser.Wd.FindElement(letter).Displayed;
                Assert.Fail(" Letter is generated");
            }
            catch
            {
                Assert.IsTrue(true, MBIValue + "  --> Letter is getting displayed ");
            }
            
        }

        [Then(@"Verify Letter Name ""(.*)"" Letter Type as ""(.*)"" Letter Status ""(.*)"" is displayed")]
        public void ThenVerifyLetterNameLetterTypeAsLetterStatusIsDisplayed(string letter, string type, string status)
        {
            tmsWait.Hard(3);
            By letterQueue = By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_ucCorrespondence_gvCORR']//td[contains(.,'"+ letter + "')]/following-sibling::td[contains(.,'"+ type + "')]/following-sibling::td[contains(.,'"+ status + "')]");

            bool letterQueueDis = Browser.Wd.FindElement(letterQueue).Displayed;
            Assert.IsTrue(letterQueueDis, " Letter is not Queued");
        }


        [Then(@"Verify Letter Name ""(.*)"" is not displayed")]
        public void ThenVerifyLetterNameIsNotDisplayed(string p0)
        {
            By letter = By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_ucCorrespondence_gvCORR']//tr[contains(.,'"+ p0 + "')]");

            try
            {
                bool letterDisplay = Browser.Wd.FindElement(letter).Displayed;
                Assert.Fail(" There is no Letter generated");
            }
            catch
            {
                Assert.IsTrue(true, " Letter is getting generated");
            }
        }

        [Then(@"Verify Letter Queue page displayed Last Name as ""(.*)"" First Name as ""(.*)"" MBI as ""(.*)""")]
        public void ThenVerifyLetterQueuePageDisplayedLastNameAsFirstNameAsMBIAs(string fname, string lname, string mbi)
        {
            tmsWait.Hard(5);
            string FirstName = tmsCommon.GenerateData(fname);
            string LastName = tmsCommon.GenerateData(lname);
            string MBIValue = tmsCommon.GenerateData(mbi);

            By letter = By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_dgLetters']//tr/td[contains(.,'"+ FirstName + "')]/following-sibling::td[contains(.,'"+ LastName + "')]/following-sibling::td[contains(.,'"+ MBIValue + "')]");
            bool letterDisplay = Browser.Wd.FindElement(letter).Displayed;

            Assert.IsTrue(letterDisplay, MBIValue+" is not getting displayed ");
        }


        [Then(@"Verify EAM File Processing Status page ""(.*)"" FileName ""(.*)""status is ""(.*)""")]
        public void ThenVerifyEAMFileProcessingStatusPageFileNameStatusIs(string p0, string p1, string p2)
        {
                       

            string fileName = tmsCommon.GenerateData(p1);
            tmsWait.Hard(5);
            string actualStatus;
            string messageTxt;
            string procesingStatus = p1.ToString();

            string xpath = "//table[@id='ctl00_ctl00_MainMasterContent_MainContent_FileStatusGrid']//td[contains(.,'" + fileName + "')]/following-sibling::td[1]";
            string message = "//table[@id='ctl00_ctl00_MainMasterContent_MainContent_FileStatusGrid']//td[contains(.,'"+ fileName + "')]/following-sibling::td[2]/span";
            actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
            messageTxt = Browser.Wd.FindElement(By.XPath(message)).Text.ToString();
            int ReturnStatus = StatusValidation(actualStatus);

            while (ReturnStatus != 0)
            {
                actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                ReturnStatus = StatusValidation(actualStatus);
            }
            if(messageTxt.Contains("SSIS package failed"))
            {
                Assert.Fail("Error in Loading TRR file due to SSIS Package Failed");
            }
        }
        public string downloadFolderPath = System.IO.Path.Combine(Environment.ExpandEnvironmentVariables("%userprofile%"), "Downloads");

        [Then(@"EAM UI MOD File Processing Status page ""(.*)"" is downloaded successfully")]
        public void ThenEAMUIMODFileProcessingStatusPageIsDownloadedSuccessfully(string p0)
        {
            ReUsableFunctions.deleteFilesFromDownloadFolder();

            tmsWait.Hard(3);


            string fileName = tmsCommon.GenerateData(p0);

            if ((p0.Equals("CMS BEQ File")) || (p0.Equals("Export BEQ File")))
            {
                string actualPlanID = GlobalRef.PlanID.ToString();
                fileName = actualPlanID + "_BEQ" + DateTime.Today.ToString("yyyyMMdd");
            }

            if (p0.Equals("CMS File"))
            {
                string actualPlanID = GlobalRef.PlanID.ToString();
                fileName = actualPlanID + "_Trans" + DateTime.Today.ToString("yyyyMMdd");
            }
            IWebElement fileprocessingLink = Browser.Wd.FindElement(By.XPath("//a[@title='File Processing Status']"));
            fw.ExecuteJavascript(fileprocessingLink);
            tmsWait.Hard(5);
            IWebElement SearchBtn = Browser.Wd.FindElement(By.CssSelector("[test-id='trrlogging-btn-Search']"));
            fw.ExecuteJavascript(SearchBtn);
            tmsWait.Hard(2);


            string xpath= "(//tr/td[3][contains(.,'"+ fileName + "')]/a)[1]";
            //string xpath = "(//tr/td[3][contains(.,'" + fileName + "')]/preceding-sibling::td/span[@class='CompleteIcon'])[1]";
            IWebElement download = Browser.Wd.FindElement(By.XPath(xpath));
            fw.ExecuteJavascript(download);

            

        }

        [Then(@"Verify EAM UI MOD Export task File Processing Status page ""(.*)"" status is ""(.*)""")]
        public void ThenVerifyEAMUIMODExportTaskFileProcessingStatusPageStatusIs(string p0, string p1)
        {
            ReUsableFunctions.deleteFilesFromDownloadFolder();

            tmsWait.Hard(3);

            
            string fileName = tmsCommon.GenerateData(p0);



            if ((p0.Equals("CMS BEQ File")) || (p0.Equals("Export BEQ File")))
            {
                string actualPlanID = GlobalRef.PlanID.ToString();
                fileName = actualPlanID + "_BEQ" + DateTime.Today.ToString("yyyyMM");
            }

            if (p0.Equals("CMS File"))
            {
                string actualPlanID = GlobalRef.PlanID.ToString();
                fileName = actualPlanID + "_Trans" + DateTime.Today.ToString("yyyyMMdd");
                p0 = "CMS Transfer File";
            }
            

            IWebElement fileprocessingLink = Browser.Wd.FindElement(By.XPath("//a[@title='Job Processing Status']"));
            fw.ExecuteJavascript(fileprocessingLink);
            tmsWait.Hard(10);

            IWebElement jobType = Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlJobName_listbox']"));

            string idAttribute = jobType.GetAttribute("aria-owns");
            IWebElement drpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='" + idAttribute + "']/li[.='" + p0 + "']"));
            fw.ExecuteJavascript(drpValue);
            IWebElement SearchBtn = Browser.Wd.FindElement(By.CssSelector("[test-id='jobProcessingStatus-button-search']"));
            fw.ExecuteJavascript(SearchBtn);
            tmsWait.Hard(2);

            importPlus = By.XPath("(//a[@aria-label='Expand'])[1]");
          
            UIMODUtilFunctions.clickOnWebElementUsingLocators(importPlus);
            tmsWait.Hard(7);

            string actualStatus;

            string procesingStatus = p1.ToString();
            string xpath = "";
            if (p0.Equals("CMS BEQ File"))
            {
                xpath = "//a[contains(.,'"+ fileName + "')]/parent::td/following-sibling::td/span[@ng-bind='dataItem.requestStatus']";
            }
            else
            {

                //xpath = "//tr/td[3][contains(.,'" + fileName + "')]/preceding-sibling::td/span[@class='CompleteIcon']";
                xpath = "//a[contains(.,'" + fileName + "')]/parent::td/following-sibling::td/span[@ng-bind='dataItem.requestStatus']";
            }
            tmsWait.Hard(10);
            actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
            int ReturnStatus = StatusValidation(actualStatus);

            while (ReturnStatus != 0)
            {

                tmsWait.Hard(7);
                actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                ReturnStatus = StatusValidation(actualStatus);
            }
        }

        [Given(@"I execute Redis CLI using Flush All command")]
        public void GivenIExecuteRedisCLIUsingFlushAllCommand()
        {
            //System.Diagnostics.Process process = new System.Diagnostics.Process();
            //System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
            //startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
            //startInfo.FileName = "C:\\Program Files\\Redis\\redis-cli.exe";
            //startInfo.Arguments = "flushall";
            //process.StartInfo = startInfo;
            //process.Start();

            //ProcessStartInfo info = new ProcessStartInfo("C:\\PsTools");
            //info.FileName = @"C:\PsTools\psexec.exe";
            //info.Arguments = @"\\"10.90.83.12@" -i C:\WINDOWS\notepad.exe";
            //info.RedirectStandardOutput = true;
            //info.UseShellExecute = false;
            //Process p = Process.Start(info);
        }


        By importPlus;
        string actualstatus;
        
        [Then(@"Verify EAM UI MOD File Processing Status page ""(.*)"" status is ""(.*)""")]
        [When(@"Verify EAM UI MOD File Processing Status page ""(.*)"" status is ""(.*)""")]
        public void ThenVerifyEAMUIMODFileProcessingStatusPageStatusIs(string p0, string p1)
        {

            string[] fileExtensions = { ".txt", ".xls", ".csv" };
            DirectoryInfo di = new DirectoryInfo(downloadFolderPath);
            FileInfo[] oldDownloadedFiles = di.EnumerateFiles().Where(p => fileExtensions.Contains(p.Extension, StringComparer.InvariantCultureIgnoreCase)).ToArray();


            foreach (var oldFile in oldDownloadedFiles)
            {
                oldFile.Attributes = FileAttributes.Normal;
                File.Delete(oldFile.FullName);
            }
            if (ConfigFile.EnvType.Equals("ESI") || ConfigFile.EnvType.Equals("Main"))
            {
                string actualStatus;
                   String jobName = GlobalRef.JobName.ToString();
                tmsWait.Hard(20);
                string procesingStatus = tmsCommon.GenerateData(p1);

                string fileName = tmsCommon.GenerateData(p0);
                if((ConfigFile.EnvType.Equals("ESI") || ConfigFile.EnvType.Equals("Main")) && procesingStatus.Equals("Complete"))
                    {
                    procesingStatus = "Success";
                    }

                
                if (p0.Equals("Mailing"))
                {
                    fileName = "Mailing" + DateTime.Today.ToString("yyyyMMdd");
                }
                if (p0.Equals("Span File"))
                {
                    fileName = "Spans" + DateTime.Today.ToString("yyyyMMdd");
                }

                if (p0.Equals("CMS BEQ File"))
                {
                    string actualPlanID = GlobalRef.PlanID.ToString();
                    fileName = actualPlanID + "_BEQ" + DateTime.Today.ToString("yyyyMMdd");
                }


                if (p0.Equals("Mailing List Transaction"))
                {
                    fileName = "Mailing" + DateTime.Today.ToString("yyyyMMdd");
                }

                if (p0.Equals("Legacy Member File"))
                {
                    string actualPlanID = GlobalRef.PlanID.ToString();
                    if (actualPlanID.Equals("ALL") || (actualPlanID.Equals("All")))
                    {
                        fileName = "Legacy_Mem_" + DateTime.Today.ToString("yyyyMMdd");
                    }
                    else
                    {
                        fileName = actualPlanID + "_Legacy_Mem_" + DateTime.Today.ToString("yyyyMMdd");
                    }
                }

                if (p0.Equals("Legacy Transaction File"))
                {
                    string actualPlanID = GlobalRef.PlanID.ToString();
                    if (actualPlanID.Equals("ALL") || (actualPlanID.Equals("All")))
                    {
                        fileName = "Legacy" + DateTime.Today.ToString("yyyyMMdd");
                    }
                    else
                    {
                        fileName = actualPlanID + "_Legacy" + DateTime.Today.ToString("yyyyMMdd");
                    }
                }

                if (p0.Equals("CMS Transfer File"))
                {
                    string actualPlanID = GlobalRef.PlanID.ToString();
                    if (actualPlanID.Equals("ALL") || (actualPlanID.Equals("All")))
                    {
                        fileName = "Trans" + DateTime.Today.ToString("yyyyMMdd");
                    }
                    else
                    {
                        fileName = actualPlanID + "_Trans" + DateTime.Today.ToString("yyyyMMdd");
                    }
                }

                if (p0.Equals("Mailing List TRR File"))
                {
                    //string actualPlanID = GlobalRef.PlanID.ToString();
                    //if (actualPlanID.Equals("ALL") || (actualPlanID.Equals("All")))
                    //{
                        fileName = "-TrrMailingExport-3-" + DateTime.Today.ToString("yyyyMMdd");
                    //}
                    //else
                    //{
                    //    fileName = actualPlanID + "_TrrMailingExport_" + DateTime.Today.ToString("yyyyMMdd");
                    //}
                }

                // Select Job Type
                IWebElement jobType;
                if (ConfigFile.tenantType == "tmsx")
                {
                    jobType = Browser.Wd.FindElement(By.XPath("//label[text()='Job']/parent::div//span[@class='k-select']"));
                    fw.ExecuteJavascript(jobType);
                    By typeapp = By.XPath("//li[text()='" + jobName + "']");

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                }
                    // 10-05-2020 Venkatesh Updated above line to handle CSM Transfer file for tmsx
              
                else
                jobType = Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlJobName_listbox']"));
                

                if (ConfigFile.tenantType == "tms")
                {
                    if (jobName.Equals("TRR File"))
                    {
                        string idAttribute = jobType.GetAttribute("aria-owns");
                        IWebElement drpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='" + idAttribute + "']/li[.='" + jobName + "']"));
                        fw.ExecuteJavascript(drpValue);

                    }
                    else
                    {
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(jobType, jobName);
                    }
                }
                    

                fw.ConsoleReport(jobName + " File Type Drop is selected and Filtered");

                By SearchBtn = By.CssSelector("[test-id='jobProcessingStatus-button-search']");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(SearchBtn);
                tmsWait.Hard(5);
                //if (jobName.Equals("EAF File") || jobName.Equals("OEC File") || jobName.Equals("TRR File") || jobName.Equals("BQN File"))
                //{
                if (ConfigFile.tenantType == "tmsx")
                    importPlus = By.XPath("(//*[@title='Expand Details'])[1]");
                else
                    importPlus = By.XPath("(//a[@aria-label='Expand'])[1]");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(importPlus);
                //}
                tmsWait.Hard(5);
                fw.ConsoleReport(jobName + " Import Plus Button is Clicked");
                string type = GlobalRef.Type.ToString();
                tmsWait.Hard(3);
                string xpath="";
                if (type.Equals("Import"))
                {
                    xpath = "//p[contains(.,'" + fileName + "')]/parent::td/following-sibling::td/span[@ng-bind='dataItem.requestStatus']";// Indicate Success Status
                }

                else if (type.Equals("Export"))
                {
                    if (ConfigFile.tenantType == "tmsx")
                        xpath= "//tr/td[contains(., '" + fileName + "')]/following-sibling::td[@aria-colindex='2']";
                    // 10-05-2020 Venkatesh Updated above line to handle CSM Transfer file for tmsx
                    else
                        //xpath = "//p[contains(.,'" + fileName + "')]/parent::a/parent::td/following-sibling::td/span[@ng-bind='dataItem.requestStatus']";// Indicate Success Status
                        xpath = "//tr[contains(., '" + fileName + "')]//span[@ng-bind='dataItem.requestStatus']";
                }

                try
                {
                    actualstatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                }
                catch
                {

                }
                fw.ConsoleReport(" Processing File Name -->" + fileName);
                fw.ConsoleReport(" Looking for Success Status for File " + fileName);
                int ReturnStatus = StatusValidation(actualstatus);
               
                while (ReturnStatus != 0)
                {

                    fw.ExecuteJavascript(Browser.Wd.FindElement(SearchBtn));
                    tmsWait.Hard(5);

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(importPlus);
                    tmsWait.Hard(5);
                    actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                    fw.ConsoleReport(" Current File Processing status --> " + actualStatus);
                    ReturnStatus = StatusValidation(actualStatus);
                }
            }
            else
            {
                By SearchButton = By.CssSelector("[test-id='trrlogging-btn-Search']");
                

                tmsWait.Hard(3);
                //IWebElement fileProcess = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_EamNavigation_lnkFileProcessed"));
                //fw.ExecuteJavascript(fileProcess);

                string fileName = tmsCommon.GenerateData(p0);
                if (p0.Equals("Mailing"))
                {
                    fileName = "Mailing" + DateTime.Today.ToString("yyyyMMdd");
                }
                if (p0.Equals("Span File"))
                {
                    fileName = "Spans" + DateTime.Today.ToString("yyyyMMdd");
                }

                if (p0.Equals("CMS BEQ File"))
                {
                    string actualPlanID = GlobalRef.PlanID.ToString();
                    fileName = actualPlanID + "_BEQ" + DateTime.Today.ToString("yyyyMMdd");
                }


                if (p0.Equals("Mailing List Transaction"))
                {
                    fileName = "Mailing" + DateTime.Today.ToString("yyyyMMdd");
                }

                if (p0.Equals("Legacy Member File"))
                {
                    string actualPlanID = GlobalRef.PlanID.ToString();
                    if (actualPlanID.Equals("ALL") || (actualPlanID.Equals("All")))
                    {
                        fileName = "Legacy_Mem_" + DateTime.Today.ToString("yyyyMMdd");
                    }
                    else
                    {
                        fileName = actualPlanID + "_Legacy_Mem_" + DateTime.Today.ToString("yyyyMMdd");
                    }
                }

                if (p0.Equals("Legacy Transaction File"))
                {
                    string actualPlanID = GlobalRef.PlanID.ToString();
                    if (actualPlanID.Equals("ALL") || (actualPlanID.Equals("All")))
                    {
                        fileName = "Legacy" + DateTime.Today.ToString("yyyyMMdd");
                    }
                    else
                    {
                        fileName = actualPlanID + "_Legacy" + DateTime.Today.ToString("yyyyMMdd");
                    }
                }

                if (p0.Equals("CMS Transfer File"))
                {
                    string actualPlanID = GlobalRef.PlanID.ToString();
                    if (actualPlanID.Equals("ALL") || (actualPlanID.Equals("All")))
                    {
                        fileName = "Trans" + DateTime.Today.ToString("yyyyMMdd");
                    }
                    else
                    {
                        fileName = actualPlanID + "_Trans" + DateTime.Today.ToString("yyyyMMdd");
                    }
                }



                tmsWait.Hard(5);
                string actualStatus;

                string procesingStatus = p1.ToString();
                string xpath;
                if (ConfigFile.tenantType == "tmsx")
                    xpath = "//tr/td[3][contains(.,'" + fileName + "')]";
                else
                    xpath = "//tr/td[3][contains(.,'" + fileName + "')]/preceding-sibling::td/span[@class='CompleteIcon']";



                fw.ExecuteJavascript(Browser.Wd.FindElement(SearchButton));

                actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                int ReturnStatus = StatusValidation(actualStatus);

                while (ReturnStatus != 0)
                {
                    fw.ExecuteJavascript(Browser.Wd.FindElement(SearchButton));
                    tmsWait.Hard(5);
                    actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                    ReturnStatus = StatusValidation(actualStatus);
                }
            }
        }


        //Gurdeep Arora
        [Then(@"Verify on EAM File Processing Status page ""(.*)"" status is ""(.*)""")]
        public void ThenVerifyOnEAMFileProcessingStatusPageStatusIs(string p0, string p1)
        {

            string[] fileExtensions = { ".txt", ".xls", ".csv" };
            DirectoryInfo di = new DirectoryInfo(downloadFolderPath);
            FileInfo[] oldDownloadedFiles = di.EnumerateFiles().Where(p => fileExtensions.Contains(p.Extension, StringComparer.InvariantCultureIgnoreCase)).ToArray();


            foreach (var oldFile in oldDownloadedFiles)
            {
                oldFile.Attributes = FileAttributes.Normal;
                File.Delete(oldFile.FullName);
            }


            tmsWait.Hard(3);
            if (ConfigFile.EnvType.Equals("ESI") || ConfigFile.EnvType.Equals("Main"))
            {
                string actualStatus;
                String jobName = GlobalRef.JobName.ToString();
                tmsWait.Hard(20);
                string procesingStatus = tmsCommon.GenerateData(p1);

                string fileName = tmsCommon.GenerateData(p0);
                if (ConfigFile.EnvType.Equals("ESI") && procesingStatus.Equals("Complete"))
                {
                    procesingStatus = "Success";
                }


                if (p0.Equals("Mailing"))
                {
                    fileName = "Mailing" + DateTime.Today.ToString("yyyyMMdd");
                }
                if (p0.Equals("Span File"))
                {
                    fileName = "Spans" + DateTime.Today.ToString("yyyyMMdd");
                }

                if (p0.Equals("CMS BEQ File"))
                {
                    //string actualPlanID = GlobalRef.PlanID.ToString();
                    // fileName = "P#EFT.IN.PL"H0002.BEQ4RX.D200531.T0159308"actualPlanID + "_BEQ" + DateTime.Today.ToString("yyyyMMdd");
                }


                if (p0.Equals("Mailing File"))
                {
                    fileName = "Mailing" + DateTime.Today.ToString("yyyyMMdd");
                }

                if (p0.Equals("Legacy Member File"))
                {
                    string actualPlanID = GlobalRef.PlanID.ToString();
                    if (actualPlanID.Equals("ALL") || (actualPlanID.Equals("All")))
                    {
                        fileName = "Legacy_Mem_" + DateTime.Today.ToString("yyyyMMdd");
                    }
                    else
                    {
                        fileName = actualPlanID + "_Legacy_Mem_" + DateTime.Today.ToString("yyyyMMdd");
                    }
                }

                if (p0.Equals("Legacy Transaction File"))
                {
                    string actualPlanID = GlobalRef.PlanID.ToString();
                    if (actualPlanID.Equals("ALL") || (actualPlanID.Equals("All")))
                    {
                        fileName = "Legacy" + DateTime.Today.ToString("yyyyMMdd");
                    }
                    else
                    {
                        fileName = actualPlanID + "_Legacy" + DateTime.Today.ToString("yyyyMMdd");
                    }
                }

                if (p0.Equals("CMS Transfer File"))
                {
                    string actualPlanID = GlobalRef.PlanID.ToString();
                    if (actualPlanID.Equals("ALL") || (actualPlanID.Equals("All")))
                    {
                        fileName = "Trans" + DateTime.Today.ToString("yyyyMMdd");
                    }
                    else
                    {
                        fileName = actualPlanID + "_Trans" + DateTime.Today.ToString("yyyyMMdd");
                    }
                }

                // Select Job Type
                IWebElement jobType = Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlJobName_listbox']"));
                if (jobName.Equals("TRR File"))
                {
                    string idAttribute = jobType.GetAttribute("aria-owns");
                    IWebElement drpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='" + idAttribute + "']/li[.='" + jobName + "']"));
                    fw.ExecuteJavascript(drpValue);

                }
                else
                {
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(jobType, jobName);
                }

                fw.ConsoleReport(jobName + " File Type Drop is selected and Filtered");

                By SearchBtn = By.CssSelector("[test-id='jobProcessingStatus-button-search']");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(SearchBtn);
                tmsWait.Hard(5);
                //if (jobName.Equals("EAF File") || jobName.Equals("OEC File") || jobName.Equals("TRR File") || jobName.Equals("BQN File"))
                //{
                importPlus = By.XPath("(//a[@aria-label='Expand'])[1]");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(importPlus);
                //}
                tmsWait.Hard(5);
                fw.ConsoleReport(jobName + " Import Plus Button is Clicked");
                string type = GlobalRef.Type.ToString();
                string xpath = "";
                if (type.Equals("Import"))
                {
                    xpath = "//p[contains(.,'" + fileName + "')]/parent::td/following-sibling::td/span[@ng-bind='dataItem.requestStatus']";// Indicate Success Status
                }

                else if (type.Equals("Export"))
                {
                    if (p0.Equals("CMS BEQ File"))
                    {
                        xpath = "//tr[contains(.,'CMS BEQ File')]/td[6]";
                    }
                    else
                    {
                        xpath = "//p[contains(.,'" + fileName + "')]/parent::a/parent::td/following-sibling::td/span[@ng-bind='dataItem.requestStatus']";// Indicate Success Status
                    }
                }

                try
                {
                    actualstatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                }
                catch
                {

                }
                fw.ConsoleReport(" Processing File Name -->" + fileName);
                fw.ConsoleReport(" Looking for Success Status for File " + fileName);
                int ReturnStatus = StatusValidation(actualstatus);

                while (ReturnStatus != 0)
                {

                    fw.ExecuteJavascript(Browser.Wd.FindElement(SearchBtn));
                    tmsWait.Hard(5);

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(importPlus);
                    tmsWait.Hard(5);
                    actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                    fw.ConsoleReport(" Current File Processing status --> " + actualStatus);
                    ReturnStatus = StatusValidation(actualStatus);
                }
            }
            else
            {
                IWebElement fileProcess = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_EamNavigation_lnkFileProcessed"));
                fw.ExecuteJavascript(fileProcess);

                string fileName = tmsCommon.GenerateData(p0);
                if (p0.Equals("Mailing"))
                {
                    fileName = "Mailing" + DateTime.Today.ToString("yyyyMMdd");
                }
                if (p0.Equals("Legacy Member File"))
                {
                    string actualPlanID = GlobalRef.PlanID.ToString();
                    if ((actualPlanID.Equals("ALL")) || (actualPlanID.Equals("All")))
                    {
                        fileName = "Legacy_Mem_" + DateTime.Today.ToString("yyyyMMdd");
                    }
                    else
                    {
                        fileName = actualPlanID + "_Legacy_Mem_" + DateTime.Today.ToString("yyyyMMdd");
                    }

                }


                tmsWait.Hard(5);
                string actualStatus;
                tmsWait.Hard(7);
                string procesingStatus = p1.ToString();

                string xpath = "//table[@id='ctl00_ctl00_MainMasterContent_MainContent_FileStatusGrid']//td[contains(.,'" + fileName + "')]/following-sibling::td[1]";
                actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                int ReturnStatus = StatusValidation(actualStatus);

                while (ReturnStatus != 0)
                {
                    actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                    ReturnStatus = StatusValidation(actualStatus);
                }
            }
        }





        [Then(@"Verify EAM File Processing Status page ""(.*)"" status is ""(.*)""")]
        public void ThenVerifyEAMFileProcessingStatusPageStatusIs(string p0, string p1)
        {
            string[] fileExtensions = { ".txt", ".xls", ".csv" };
            DirectoryInfo di = new DirectoryInfo(downloadFolderPath);
            FileInfo[] oldDownloadedFiles = di.EnumerateFiles().Where(p => fileExtensions.Contains(p.Extension, StringComparer.InvariantCultureIgnoreCase)).ToArray();


            foreach (var oldFile in oldDownloadedFiles)
            {
                oldFile.Attributes = FileAttributes.Normal;
                File.Delete(oldFile.FullName);
            }


            tmsWait.Hard(3);
            if (ConfigFile.EnvType.Equals("ESI") || ConfigFile.EnvType.Equals("Main"))
            {
                string actualStatus;
                String jobName = GlobalRef.JobName.ToString();
                tmsWait.Hard(20);
                string procesingStatus = tmsCommon.GenerateData(p1);

                string fileName = tmsCommon.GenerateData(p0);
                if (ConfigFile.EnvType.Equals("ESI") && procesingStatus.Equals("Complete"))
                {
                    procesingStatus = "Success";
                }


                if (p0.Equals("Mailing"))
                {
                    fileName = "Mailing" + DateTime.Today.ToString("yyyyMMdd");
                }
                if (p0.Equals("Span File"))
                {
                    fileName = "Spans" + DateTime.Today.ToString("yyyyMMdd");
                }

                if (p0.Equals("CMS BEQ File"))
                {
                    string actualPlanID = GlobalRef.PlanID.ToString();
                    fileName = actualPlanID + "_BEQ" + DateTime.Today.ToString("yyyyMMdd");
                }


                if (p0.Equals("Mailing File"))
                {
                    fileName = "Mailing" + DateTime.Today.ToString("yyyyMMdd");
                }

                if (p0.Equals("Legacy Member File"))
                {
                    string actualPlanID = GlobalRef.PlanID.ToString();
                    if (actualPlanID.Equals("ALL") || (actualPlanID.Equals("All")))
                    {
                        fileName = "Legacy_Mem_" + DateTime.Today.ToString("yyyyMMdd");
                    }
                    else
                    {
                        fileName = actualPlanID + "_Legacy_Mem_" + DateTime.Today.ToString("yyyyMMdd");
                    }
                }

                if (p0.Equals("Legacy Transaction File"))
                {
                    string actualPlanID = GlobalRef.PlanID.ToString();
                    if (actualPlanID.Equals("ALL") || (actualPlanID.Equals("All")))
                    {
                        fileName = "Legacy" + DateTime.Today.ToString("yyyyMMdd");
                    }
                    else
                    {
                        fileName = actualPlanID + "_Legacy" + DateTime.Today.ToString("yyyyMMdd");
                    }
                }

                if (p0.Equals("CMS Transfer File"))
                {
                    string actualPlanID = GlobalRef.PlanID.ToString();
                    if (actualPlanID.Equals("ALL") || (actualPlanID.Equals("All")))
                    {
                        fileName = "Trans" + DateTime.Today.ToString("yyyyMMdd");
                    }
                    else
                    {
                        fileName = actualPlanID + "_Trans" + DateTime.Today.ToString("yyyyMMdd");
                    }
                }

                // Select Job Type
                IWebElement jobType = Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlJobName_listbox']"));
                if (jobName.Equals("TRR File"))
                {
                    string idAttribute = jobType.GetAttribute("aria-owns");
                    IWebElement drpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='" + idAttribute + "']/li[.='" + jobName + "']"));
                    fw.ExecuteJavascript(drpValue);

                }
                else
                {
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(jobType, jobName);
                }

                fw.ConsoleReport(jobName + " File Type Drop is selected and Filtered");

                By SearchBtn = By.CssSelector("[test-id='jobProcessingStatus-button-search']");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(SearchBtn);
                tmsWait.Hard(5);
                //if (jobName.Equals("EAF File") || jobName.Equals("OEC File") || jobName.Equals("TRR File") || jobName.Equals("BQN File"))
                //{
                importPlus = By.XPath("(//a[@aria-label='Expand'])[1]");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(importPlus);
                //}
                tmsWait.Hard(5);
                fw.ConsoleReport(jobName + " Import Plus Button is Clicked");
                string type = GlobalRef.Type.ToString();
                string xpath = "";
                if (type.Equals("Import"))
                {
                    xpath = "//p[contains(.,'" + fileName + "')]/parent::td/following-sibling::td/span[@ng-bind='dataItem.requestStatus']";// Indicate Success Status
                }

                else if (type.Equals("Export"))
                {
                    xpath = "//p[contains(.,'" + fileName + "')]/parent::a/parent::td/following-sibling::td/span[@ng-bind='dataItem.requestStatus']";// Indicate Success Status
                }

                try
                {
                    actualstatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                }
                catch
                {

                }
                fw.ConsoleReport(" Processing File Name -->" + fileName);
                fw.ConsoleReport(" Looking for Success Status for File " + fileName);
                int ReturnStatus = StatusValidation(actualstatus);

                while (ReturnStatus != 0)
                {

                    fw.ExecuteJavascript(Browser.Wd.FindElement(SearchBtn));
                    tmsWait.Hard(5);

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(importPlus);
                    tmsWait.Hard(5);
                    actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                    fw.ConsoleReport(" Current File Processing status --> " + actualStatus);
                    ReturnStatus = StatusValidation(actualStatus);
                }
            }
            else
            {
                IWebElement fileProcess = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_EamNavigation_lnkFileProcessed"));
            fw.ExecuteJavascript(fileProcess);

            string fileName = tmsCommon.GenerateData(p0);
            if (p0.Equals("Mailing"))
            {
                fileName = "Mailing" + DateTime.Today.ToString("yyyyMMdd");
            }
            if (p0.Equals("Legacy Member File"))
            {
                string actualPlanID = GlobalRef.PlanID.ToString();
                if ((actualPlanID.Equals("ALL")) || (actualPlanID.Equals("All")))
                {
                    fileName = "Legacy_Mem_" + DateTime.Today.ToString("yyyyMMdd");
                }
                else
                {
                    fileName = actualPlanID + "_Legacy_Mem_" + DateTime.Today.ToString("yyyyMMdd");
                }

            }


            tmsWait.Hard(5);
            string actualStatus;
              tmsWait.Hard(7);
                string procesingStatus = p1.ToString();

            string xpath = "//table[@id='ctl00_ctl00_MainMasterContent_MainContent_FileStatusGrid']//td[contains(.,'" + fileName + "')]/following-sibling::td[1]";
            actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
            int ReturnStatus = StatusValidation(actualStatus);

            while (ReturnStatus != 0)
            {
                actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                ReturnStatus = StatusValidation(actualStatus);
            }
        }
    }

       

        public int StatusValidation(string actualStatus)
        {
            tmsWait.Hard(7);
            if (actualStatus.Equals("Pending"))
            {
                tmsWait.Hard(2);
                return 1;
            }
            else if (actualStatus.Equals("Executing"))
            {
                return 1;
            }

            else if (actualStatus.Equals("Failed"))
            {
                Assert.Fail(" Job Processing is failed");
                return 0;
            }
            else if (actualStatus.Equals("Failure"))
            {
                Assert.Fail(" Job Processing is failed");
                return 0;
            }
            else if (actualStatus.Equals("Complete"))
            {

                return 0;
            }
            else if (actualStatus.Equals("Success"))
            {

                return 0;
            }

            return 0;
        }

        [Then(@"Files Processed wait a maximum of ""(.*)"" seconds for FileName that contains ""(.*)"" to have Status ""(.*)""")]
        public void ThenFilesProcessedWaitAMaximumOfSecondsForFileNameThatContainsToHaveStatus(string p0, string p1, string p2)
        {
            string variableFileName = tmsCommon.GenerateData(p1);
            Boolean WaitingOnFileProcessing = FilesProcessingStatus.WaitOnFileProcessing(p0, variableFileName, p2);
            Console.WriteLine("File Processing Status Wait:  Success[" + WaitingOnFileProcessing + "].  Looking for file [" + variableFileName + "] to have status [" + p2 + "] in under [" + p0 + "] seconds.  Look in output file for what happened to the load.");
            Assert.AreEqual(true, WaitingOnFileProcessing, "File Processing Status Wait:  Success[" + WaitingOnFileProcessing + "].  Looking for file [" + variableFileName + "] to have status [" + p2 + "] in under [" + p0 + "] seconds.  Look in output file for what happened to the load.");

        }

       
        string attachedFileContent;
        [When(@"Download Attached BEQ Response File ""(.*)"" and Replace Plan Id ""(.*)"" exported BEQ File from ALM ID ""(.*)""")]
        public void WhenDownloadAttachedBEQResponseFileAndReplacePlanIdExportedBEQFileFromALMID(string p0, string p1, string p2)
        {
            string variableFileName = "";

            variableFileName = p1 + "_BEQ" + DateTime.Today.ToString("yyyyMMdd");

            // replace field 9 - 45 in attched file with the field  7 - 42 from exported file
            string fileLocation = @"C:\SourceFile\" + p0;
            string exportedFileLocation= @"C:\SourceFile\" + variableFileName;


            var result = new List<string>();
          
           
           // source file

            foreach (var line in File.ReadLines(fileLocation))
            {
              if(line.Contains("DTLDTL"))
                {
                    attachedFileContent = line.Substring(8,36);
                }                                  
              
            }

            // exported file

            var allFiles = Directory.GetFiles(@"C:\SourceFile\");

            foreach (string file in allFiles)
            {
                if (file.Contains(exportedFileLocation))
                {
                    foreach (var line in File.ReadLines(file))
                    {
                        if (line.Contains("HIC"))
                        {
                            var position = line.Split(',');
                            line.Replace(line.Substring(5, 40), attachedFileContent);
                           // attachedFileContent = line.Substring(8, 36);
                        }

                    }
                }
            }

        }


        [When(@"File Processing page Plan ID ""(.*)"" FileName ""(.*)"" is downloaded")]
        public void WhenFileProcessingPagePlanIDFileNameIsDownloaded(string p0, string p1)
        {
            string[] fileExtensions = { ".txt", ".xls", ".csv" };
            DirectoryInfo di = new DirectoryInfo(downloadFolderPath);
            tmsWait.Hard(2);
            FileInfo[] oldDownloadedFiles = di.EnumerateFiles().Where(p => fileExtensions.Contains(p.Extension, StringComparer.InvariantCultureIgnoreCase)).ToArray();


            foreach (var oldFile in oldDownloadedFiles)
            {
                oldFile.Attributes = FileAttributes.Normal;
                File.Delete(oldFile.FullName);
            }

            tmsWait.Hard(3);


            if (p1.Equals("CMS BEQ File")) {
                string variableFileName = "";

                variableFileName = p0+"_BEQ"+ DateTime.Today.ToString("yyyyMMdd");
                if (ConfigFile.BrowserType.ToLower().Equals("chrome"))
                {
                    IWebElement link = Browser.Wd.FindElement(By.XPath("(//a[contains(.,'"+variableFileName+"')])[1]"));
                    fw.ExecuteJavascript(link);
                }

                
                else if (ConfigFile.BrowserType.Equals("ff"))
                {

                    Browser.Wd.FindElement(By.PartialLinkText(variableFileName)).Click();

                    tmsWait.Hard(2);
                    //SendKeys.SendWait("{DOWN}");
                    tmsWait.Hard(2);
                    //SendKeys.SendWait("{ENTER}");
                }
                else if (ConfigFile.BrowserType.Equals("ie"))
                {

                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.PartialLinkText(variableFileName)));
                    tmsWait.Hard(1);
//                    SendKeys.SendWait("%{s}");

                    //SendKeys.SendWait("{s}");
                    //DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_RETURN, 0, 0, 0);
                    //tmsWait.Hard(2);
                    //DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_TAB, 0, 0, 0);
                    //tmsWait.Hard(2);
                    //DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_RETURN, 0, 0, 0);
                    //DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_MENU, 0, 0, 0);
                    //DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_S, 0, 0, 0);

                }
            }

                // It will handle Mailing file
                if (p1.Equals("Mailing"))
            {
               
                string variableFileName = "";                

                variableFileName ="Mailing" + DateTime.Today.ToString("yyyyMMdd");
                if (ConfigFile.BrowserType.ToLower().Equals("chrome"))
                {
                    Browser.Wd.FindElement(By.PartialLinkText(variableFileName)).Click();
                }

                else if (ConfigFile.BrowserType.Equals("ff"))
                {

                    Browser.Wd.FindElement(By.PartialLinkText(variableFileName)).Click();

                    tmsWait.Hard(2);
                   // SendKeys.SendWait("{DOWN}");
                    tmsWait.Hard(2);
                    //SendKeys.SendWait("{ENTER}");
                }
                else if (ConfigFile.BrowserType.Equals("ie"))
                {

                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.PartialLinkText(variableFileName)));
                    tmsWait.Hard(1);
                  //  SendKeys.SendWait("%{s}");

                    //SendKeys.SendWait("{s}");
                    //DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_TAB, 0, 0, 0);
                    //tmsWait.Hard(2);
                    //DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_TAB, 0, 0, 0);
                    //tmsWait.Hard(2);
                    //DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_RETURN, 0, 0, 0);
                    //DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_MENU, 0, 0, 0);
                    //DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_S, 0, 0, 0);

                }

            }


            // It will handle Legacy file
            if (p1.Equals("Legacy File"))
            {
                string PlanID = p0.ToString();
                string variableFileName = "";
                string fileName = p1.ToString();

                variableFileName = PlanID + "_Legacy" + DateTime.Today.ToString("yyyyMMdd");
                if (ConfigFile.BrowserType.ToLower().Equals("chrome"))
                {
                    Browser.Wd.FindElement(By.PartialLinkText(variableFileName)).Click();
                }



                else if (ConfigFile.BrowserType.Equals("ff"))
                {

                    Browser.Wd.FindElement(By.PartialLinkText(variableFileName)).Click();

                    tmsWait.Hard(2);
                //    SendKeys.SendWait("{DOWN}");
                    tmsWait.Hard(2);
                  //  SendKeys.SendWait("{ENTER}");
                }
                else if (ConfigFile.BrowserType.Equals("ie"))
                {

                    Browser.Wd.FindElement(By.PartialLinkText(variableFileName)).Click();
                    tmsWait.Hard(3);
                    DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_MENU, 0, 0, 0);
                    DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_S, 0, 0, 0);

                }

            }

            if (p1.Equals("Legacy Mem"))
            {
                string PlanID = p0.ToString();
                string variableFileName = "";
                string fileName = p1.ToString();

                variableFileName = PlanID + "_Legacy_Mem_" + DateTime.Today.ToString("yyyyMMdd");
                if (ConfigFile.BrowserType.ToLower().Equals("chrome"))
                {
                    Browser.Wd.FindElement(By.PartialLinkText(variableFileName)).Click();
                }



                else if (ConfigFile.BrowserType.Equals("ff"))
                {

                    Browser.Wd.FindElement(By.PartialLinkText(variableFileName)).Click();

                    tmsWait.Hard(2);
                   // SendKeys.SendWait("{DOWN}");
                    tmsWait.Hard(2);
                  //  SendKeys.SendWait("{ENTER}");
                }
                else if (ConfigFile.BrowserType.Equals("ie"))
                {

                    Browser.Wd.FindElement(By.PartialLinkText(variableFileName)).Click();
                    tmsWait.Hard(3);
                    DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_MENU, 0, 0, 0);
                    DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_S, 0, 0, 0);

                }

            }

            // It will handle CMS Retro Contractor file
            if (p1.Equals("CMS Retro Contractor"))
            {
                string PlanID = p0.ToString();
                string variableFileName = "";
                string fileName = p1.ToString();

                variableFileName = PlanID + "_Enrl" + DateTime.Today.ToString("yyyyMMdd");
                if (ConfigFile.BrowserType.ToLower().Equals("chrome"))
                {
                    Browser.Wd.FindElement(By.PartialLinkText(variableFileName)).Click();
                }
                
                else if (ConfigFile.BrowserType.Equals("ff"))
                {

                    Browser.Wd.FindElement(By.PartialLinkText(variableFileName)).Click();

                    tmsWait.Hard(2);
                   // SendKeys.SendWait("{DOWN}");
                    tmsWait.Hard(2);
                   // SendKeys.SendWait("{ENTER}");
                }
                else if (ConfigFile.BrowserType.Equals("ie"))
                {

                    Browser.Wd.FindElement(By.PartialLinkText(variableFileName)).Click();
                    tmsWait.Hard(3);
                    DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_MENU, 0, 0, 0);
                    DeskTopWindowHandle.keybd_event(DeskTopWindowHandle.VK_S, 0, 0, 0);

                    
                }

            }
         }
       
        [Given(@"File Exported on UI Mod page wait a maximum of ""(.*)"" seconds for Plan ID ""(.*)"" FileName ""(.*)"" to have Status ""(.*)""")]
        public void GivenFileExportedOnUIModPageWaitAMaximumOfSecondsForPlanIDFileNameToHaveStatus(string p0, string p1, string p2, string p3)
        {
            string PlanID = tmsCommon.GenerateData(p1);
            string variableFileName = "";
            string status = p3.ToString();
            if (p2.Equals("Legacy File"))
            {
                variableFileName = PlanID + "_Legacy" + DateTime.Today.ToString("yyyyMMdd");
            }
            if (p2.Equals("BEQ Export"))
            {
                variableFileName = PlanID + "_BEQ" + DateTime.Today.ToString("yyyyMMdd");
            }
            if (p2.Equals("CMS Retro Contractor"))
            {
                variableFileName = PlanID + "_Enrl" + DateTime.Today.ToString("yyyyMMdd");
            }
            if (p2.Equals("Mailing"))
            {
                variableFileName = "Mailing" + DateTime.Today.ToString("yyyyMMdd");
            }
            if (p2.Equals("CMS File"))
            {
                variableFileName = PlanID + "_Trans" + DateTime.Today.ToString("yyyyMMdd");
            }
            if (p2.Equals("Legacy Mem"))
            {
                variableFileName = PlanID + "_Legacy_Mem_" + DateTime.Today.ToString("yyyyMMdd");
            }

            Boolean WaitingOnFileProcessing = FilesProcessingStatus.WaitOnFileExportProcessing_UIModFileProcessing(p0, variableFileName, p3);
            Console.WriteLine("File Processing Status Wait:  Success[" + WaitingOnFileProcessing + "].  Looking for file [" + variableFileName + "] to have status [" + p3 + "] in under [" + p0 + "] seconds.  Look in output file for what happened to the load.");
            Assert.AreEqual(true, WaitingOnFileProcessing, "File Processing Status Wait:  Success[" + WaitingOnFileProcessing + "].  Looking for file [" + variableFileName + "] to have status [" + p3 + "] in under [" + p0 + "] seconds.  Look in output file for what happened to the load.");

        }

        [When(@"File Exported wait a maximum of ""(.*)"" seconds for Plan ID ""(.*)"" FileName ""(.*)"" to have Status ""(.*)""")]
        [Given(@"File Exported wait a maximum of ""(.*)"" seconds for Plan ID ""(.*)"" FileName ""(.*)"" to have Status ""(.*)""")]
        [Then(@"File Exported wait a maximum of ""(.*)"" seconds for Plan ID ""(.*)"" FileName ""(.*)"" to have Status ""(.*)""")]
        public void WhenFileExportedWaitAMaximumOfSecondsForPlanIDFileNameToHaveStatus(string p0, string p1, string p2, string p3)
        {
            //string PlanID = p1.ToString();
            string PlanID = tmsCommon.GenerateData(p1);
            string variableFileName = "";
            string status = p3.ToString();
            if (p2.Equals("Legacy File"))
            {
                variableFileName = PlanID + "_Legacy" + DateTime.Today.ToString("yyyyMMdd");
            }
            if(p2.Equals("BEQ Export"))
            {
                variableFileName = PlanID + "_BEQ" + DateTime.Today.ToString("yyyyMMdd");
            }
            if(p2.Equals("CMS Retro Contractor"))
            {
                variableFileName = PlanID + "_Enrl" + DateTime.Today.ToString("yyyyMMdd");
            }
            if(p2.Equals("Mailing"))
            {
                variableFileName = "Mailing" + DateTime.Today.ToString("yyyyMMdd");
            }
            if (p2.Equals("CMS File"))
            {
                variableFileName = PlanID + "_Trans" + DateTime.Today.ToString("yyyyMMdd");
            }
            if (p2.Equals("Legacy Mem"))
            {
                variableFileName = PlanID + "_Legacy_Mem_" + DateTime.Today.ToString("yyyyMMdd");
            }


            Boolean WaitingOnFileProcessing = FilesProcessingStatus.WaitOnFileExportProcessing(p0, variableFileName, p3);
            Console.WriteLine("File Processing Status Wait:  Success[" + WaitingOnFileProcessing + "].  Looking for file [" + variableFileName + "] to have status [" + p3 + "] in under [" + p0 + "] seconds.  Look in output file for what happened to the load.");
            Assert.AreEqual(true, WaitingOnFileProcessing, "File Processing Status Wait:  Success[" + WaitingOnFileProcessing + "].  Looking for file [" + variableFileName + "] to have status [" + p3 + "] in under [" + p0 + "] seconds.  Look in output file for what happened to the load.");
        
        }


    }
}