﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows;
using System.Drawing;
//using System.Windows.Forms;
using OpenQA.Selenium.Support.UI;
using System.Collections.ObjectModel;
using OpenQA.Selenium.Interactions;
using System.Text;
using System.Linq;
using TMSoR1.FrameworkCode;
using Microsoft.Data.SqlClient;

namespace TMSoR1
{

    [Binding]
    public class DatabaseTesting
    {
        [When(@"Transaction Search HIC Number is set to ""(.*)""")]
        public void WhenTransactionSearchHICNumberIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(3);
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//input[@test-id='transSearch-input-mbi']")));

                tmsWait.Hard(3);
                By mbi = By.XPath("//input[@test-id='transSearch-input-mbi']");
                UIMODUtilFunctions.enterValueOnWebElementUsingLocators(mbi, GeneratedData);
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='transSearch-btn-search']")));
                tmsWait.Hard(4);
                //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//tr//td[@aria-colindex='3'][contains(.,'" + GeneratedData + "')]/preceding-sibling::td/input")));
                //tmsWait.Hard(2);
                //fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[test-id='member-btn-add']")));
                //tmsWait.Hard(3);
            }
            else
            {

                EAM.TransactionsViewEdit.HICNumber.SendKeys(GeneratedData);
                tmsWait.Hard(1);
                EAM.TransactionsViewEdit.HICNumber.SendKeys(OpenQA.Selenium.Keys.Tab);
            }
        }

        [When(@"Transaction Search Program Source is set to ""(.*)""")]
        public void WhenTransactionSearchProgramSourceIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Program Source')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + GeneratedData + "']");


                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);



            }
            else
            {
                IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[aria-owns='dropdownProgramSource_listbox']"));
                UIMODUtilFunctions.selectDropDownValueFromGendoUI(ele, GeneratedData);
                tmsWait.Hard(2);
            }
        }

        [When(@"Transaction Search Trans Code is set to ""(.*)""")]
        public void WhenTransactionSearchTransCodeIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Transaction Code')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + GeneratedData + "']");


                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);



            }
            else
            {

                IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[aria-owns='inputBoxTransCode_listbox']"));
                UIMODUtilFunctions.selectDropDownValueFromGendoUI(ele, GeneratedData);
                tmsWait.Hard(2);
            }

        }

        [When(@"Transaction Search Trans Status is set to ""(.*)""")]
        public void WhenTransactionSearchTransStatusIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Transaction Status')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + GeneratedData + "']");


                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);



            }
            else
            {

                IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[aria-owns='dropdownTransStatus_listbox']"));
                UIMODUtilFunctions.selectDropDownValueFromGendoUI(ele, GeneratedData);
                tmsWait.Hard(2);
            }

        }

        [Then(@"Transactions View Edit page First Record is clicked")]
        public void ThenTransactionsViewEditPageFirstRecordIsClicked()
        {
            tmsWait.Hard(4);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement link = Browser.Wd.FindElement(By.XPath("(//div[@role='presentation']//td/a)[1]"));
                fw.ExecuteJavascript(link);

            }
            else
            {
                IWebElement link = Browser.Wd.FindElement(By.XPath("(//div[@test-id='transSearch-grid-transactions']//a)[1]"));
                fw.ExecuteJavascript(link);
                tmsWait.Hard(4);
            }
        }

        [When(@"View Edit Transaction page Problem case Type drop down list is set to ""(.*)""")]
        [Then(@"View Edit Transaction page Problem case Type drop down list is set to ""(.*)""")]
        public void ThenViewEditTransactionPageProblemCaseTypeDropDownListIsSetTo(string p0)
        {

            string strValue = tmsCommon.GenerateData(p0);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Problem Case Type')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + strValue + "']");


                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);



            }
            else
            {
                //div[@id='div_ApplicationDispositionProblemCaseType']//li[@data-offset-index='1']
                By pct = By.XPath("//div[@id='div_ApplicationDispositionProblemCaseType']/span");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(pct);
                tmsWait.Hard(2);
                UIMODUtilFunctions.selectTransDrpValue(strValue);

            }


        }
        [Then(@"Verify View Edit Transaction page displayed Warning message as ""(.*)""")]
        public void ThenVerifyViewEditTransactionPageDisplayedWarningMessageAs(string p0)
        {

        }

        [Then(@"Verify View Edit Transaction page displayed Warning message as Address Effective Date is required")]
        public void ThenVerifyViewEditTransactionPageDisplayedWarningMessageAsAddressEffectiveDateIsRequired()
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By loc = By.XPath("//span[contains(.,'Please provide Address Effective Date')]");
                UIMODUtilFunctions.elementPresenceUsingLocators(loc);
            }
            else
            {
                By loc = By.XPath("(//span[contains(.,' Please provide Address Effective Date')])[2]");
                UIMODUtilFunctions.elementPresenceUsingLocators(loc);
            }
        }


        [Then(@"Verify View Edit Transaction page displayed message like ""(.*)""")]
        public void ThenVerifyViewEditTransactionPageDisplayedMessageLike(string p0)
        {
            tmsWait.Hard(2);
            IWebElement msg = Browser.Wd.FindElement(By.XPath("//div[@id='ctl00_ctl00_MainMasterContent_MainContent_ValidationSummary1']//li[contains(.,'" + p0 + "')]"));
            Assert.IsTrue(msg.Displayed, " expected message is not getting displayed");
        }

        [Then(@"Verify View Edit Transaction page Type of Application drop down list is set to ""(.*)""")]
        public void ThenVerifyViewEditTransactionPageTypeOfApplicationDropDownListIsSetTo(string expectedValue)
        {
            IWebElement drp = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboAppType"));
            SelectElement transstatus = new SelectElement(drp);
            string actualValue = transstatus.SelectedOption.Text;

            Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");
        }

        [Then(@"Verify View Edit Transaction page ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyViewEditTransactionPageIsSetTo(string field, string expectedValue)
        {
            IWebElement actualElement;

            bool presence;
            switch (field)
            {
                case "Election Type":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement dropDown = Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Election Type')]/parent::div//span[@class='k-input'])[1]"));
                        string actual_value = dropDown.Text;
                        Assert.IsTrue(actual_value.Contains(expectedValue), "Value does not match");
                    }
                    else
                    {
                        actualElement = Browser.Wd.FindElement(By.XPath("//div[@id='div_DemographicDetailsElectionType']//span[@class='k-input ng-scope'][contains(.,'" + expectedValue + "')]"));
                        presence = actualElement.Displayed;
                        Assert.IsTrue(presence, "expectedValue element is Not displayed");
                    }

                    break;

                case "SEPS Reason":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement dropDown = Browser.Wd.FindElement(By.XPath("(//label[contains(.,'SEPS Reason')]/parent::div//span[@class='k-input'])[1]"));
                        string actual_value = dropDown.Text;
                        Assert.IsTrue(actual_value.Contains(expectedValue), "Value does not match");
                    }
                    else
                    {
                        actualElement = Browser.Wd.FindElement(By.XPath("//div[@id='div_DemographicDetailsSEPSReason']//span[@class='k-input ng-scope'][contains(.,'" + expectedValue + "')]"));
                        presence = actualElement.Displayed;
                        Assert.IsTrue(presence, "expectedValue element is Not displayed");
                    }

                    break;
            }

        }

        [Then(@"Verify View Edit Transaction page SEPS reason is set to ""(.*)""")]
        public void ThenVerifyViewEditTransactionPageSEPSReasonIsSetTo(string expectedValue)
        {

            tmsWait.Hard(2);
            string actualValue = new SelectElement(Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboSEPSReason"))).SelectedOption.Text;
            Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");
        }


        [Then(@"Verify View Edit Transaction page Election Type is set to ""(.*)""")]
        public void ThenVerifyViewEditTransactionPageElectionTypeIsSetTo(string expectedValue)
        {
            tmsWait.Hard(2);
            string actualValue = new SelectElement(Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboElectionPeriod_09"))).SelectedOption.Text;
            Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");
        }


        [Then(@"View Edit Transaction page Type of Application drop down list is set to ""(.*)""")]
        public void ThenViewEditTransactionPageTypeOfApplicationDropDownListIsSetTo(string p0)
        {
            IWebElement application = Browser.Wd.FindElement(By.CssSelector("[aria-owns='typeOfApplication_listbox']"));
            UIMODUtilFunctions.selectDropDownValueFromGendoUI(application, p0);
            tmsWait.Hard(2);
            //IWebElement drp = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboAppType"));
            //SelectElement transstatus = new SelectElement(drp);
            //transstatus.SelectByText(p0);
        }

        [Then(@"View Edit Transaction page Prior Commercial drop down list is set to ""(.*)""")]
        public void ThenViewEditTransactionPagePriorCommercialDropDownListIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string strValue = tmsCommon.GenerateData(p0);

            By priorComm = By.XPath("//div[@id='div_DemographicDetailsPriorComm']/span");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(priorComm);
            tmsWait.Hard(2);
            UIMODUtilFunctions.selectTransDrpValue(strValue);
            //IWebElement drp = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_drpPriorComm_17"));
            //SelectElement prior = new SelectElement(drp);
            //prior.SelectByText(p0);
        }


        [Then(@"View Edit Transaction page ""(.*)"" is set to ""(.*)""")]
        public void ThenViewEditTransactionPageIsSetTo(string p0, string p1)
        {

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                string index = Convert.ToString((p0.ToCharArray())[4]);
                By Drp = By.XPath("//label[text()='" + p0 + "']/parent::div//div//input");
                Browser.Wd.FindElement(Drp).Clear();
                Browser.Wd.FindElement(Drp).SendKeys(p1);


                tmsWait.Hard(3);


            }
            else
            {
                IWebElement plan = Browser.Wd.FindElement(By.Id("TransactionRelatedPlanFields" + p0 + ""));
                plan.Clear();
                plan.SendKeys(p1);
            }
        }

        [Then(@"View Edit Transaction page Save button is Clicked")]
        public void ThenViewEditTransactionPageSaveButtonIsClicked()
        {
            IWebElement save = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSave"));
            fw.ExecuteJavascript(save);
        }


        [Then(@"View Edit Transaction page displayed message ""(.*)""")]
        public void ThenViewEditTransactionPageDisplayedMessage(string p0)
        {
            tmsWait.Hard(2);
            IWebElement plan = Browser.Wd.FindElement(By.XPath("//span[@id='ctl00_ctl00_MainMasterContent_MainContent_lblMsg'][contains(.,'" + p0 + "')]"));
            Assert.IsTrue(plan.Displayed, " message is not getting displayed");

        }
        [When(@"Transaction Search page MBI ""(.*)"" Trans Status ""(.*)"" Trans Code ""(.*)""")]
        public void WhenTransactionSearchPageMBITransStatusTransCode(string p0, string p1, string p2)
        {
            tmsWait.Hard(2);
            string mbi = tmsCommon.GenerateData(p0);
            IWebElement plan = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_dgTrans']//tr//td[contains(.,'" + p2 + "')]/preceding-sibling::td[contains(.,'" + p1 + "')]/preceding-sibling::td[contains(.,'" + mbi + "')]/preceding-sibling::td/a"));
            //IWebElement plan = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_dgTrans']//tr//td[contains(.,'" + mbi + "')]/preceding-sibling::td[contains(.,'" + p1 + "')]/preceding-sibling::td[contains(.,'" + mbi + "')]/preceding-sibling::td/a"));
            fw.ExecuteJavascript(plan);
        }

        [When(@"View Edit Transaction page Part C amount is set to ""(.*)""")]
        public void WhenViewEditTransactionPagePartCAmountIsSetTo(string p0)
        {
            IWebElement partc = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtPremAmtC_19"));
            ReUsableFunctions.enterValueOnWebElement(partc, p0);
        }

        [When(@"View Edit Transaction page Part D amount is set to ""(.*)""")]
        public void WhenViewEditTransactionPagePartDAmountIsSetTo(string p0)
        {
            IWebElement partd = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtPremAmtD_20"));
            ReUsableFunctions.enterValueOnWebElement(partd, p0);
        }



        [When(@"Transaction View Edit Page Search button is Clicked")]
        public void WhenTransactionViewEditPageSearchButtonIsClicked()
        {
            fw.ExecuteJavascript(EAM.TransactionsViewEdit.Search);
            tmsWait.Hard(7);
        }


        [When(@"Main EAF Fallout Records Page Search button is Clicked and Message varified ""(.*)""")]
        public void WhenMainEAFFalloutRecordsPageSearchButtonIsClickedAndMessageVarified(string p0)
        {

            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='eafFalloutCorrection-btn-search']")));
            string actualvalue = Browser.Wd.FindElement(By.ClassName("toast-message")).GetAttribute("aria-label");
            string expectedvalue = p0.ToString();
            Assert.IsTrue(actualvalue.Contains(expectedvalue), "Message is displayed successfully");
        }
        [When(@"Main EAF Fallout Records Page Search button is Clicked")]
        public void WhenMainEAFFalloutRecordsPageSearchButtonIsClicked()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='eafFalloutCorrection-btn-search']")));
            tmsWait.Hard(7);

        }
        [When(@"Verify Main EAF Fallout Records Page Table column Name as ""(.*)"" and ""(.*)"" and ""(.*)"" and ""(.*)"" and ""(.*)"" and ""(.*)"" and ""(.*)"" and ""(.*)"" and ""(.*)"" and ""(.*)""")]
        public void WhenVerifyMainEAFFalloutRecordsPageTableColumnNameAsAndAndAndAndAndAndAndAndAnd(string p0, string p1, string p2, string p3, string p4, string p5, string p6, string p7, string p8, string p9)
        {
            IList<IWebElement> column = Browser.Wd.FindElements(By.XPath("//div[@test-id='eafFalloutCorrection-grid']/table/thead/tr/th/span"));
            int i = 0;
            List<string> headerName = new List<string>();
            //IList<String> headerName2 = null;
            Boolean header = false;
            // column.Contains(p0)
            //   column.eq()
            foreach (IWebElement e in column)
            {

                headerName.Add(e.Text);


            }
            Assert.IsTrue(headerName.Contains(p0), p0 + " not displaying");
            Assert.IsTrue(headerName.Contains(p1), p0 + " not displaying");
            Assert.IsTrue(headerName.Contains(p2), p0 + " not displaying");

            Assert.IsTrue(headerName.Contains(p3), p0 + " not displaying");
            Assert.IsTrue(headerName.Contains(p4), p0 + " not displaying");
            Assert.IsTrue(headerName.Contains(p5), p0 + " not displaying");
            Assert.IsTrue(headerName.Contains(p6), p0 + " not displaying");

            Assert.IsTrue(headerName.Contains(p7), p0 + " not displaying");
        }


        [When(@"Transaction View Edit Page Search result Copy Any MBI and assinged to ""(.*)""")]
        public void WhenTransactionViewEditPageSearchResultCopyAnyMBIAndAssingedTo(string p0)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                string copyMBI = Browser.Wd.FindElement(By.XPath("(//table[@role='presentation']//td[@aria-colindex='2'])[1]")).Text;
                fw.setVariable(p0, copyMBI);

            }
            else
            {

                string copyMBI = Browser.Wd.FindElement(By.XPath("//div[@id='transactionsDataGrid']//tr[2]//td[2]")).Text;
                fw.setVariable(p0, copyMBI);
            }
        }





        [When(@"Transaction Search page ""(.*)"" record is Clicked")]
        public void WhenTransactionSearchPageRecordIsClicked(string p0)
        {
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_dgTrans']//td[contains(.,'" + p0 + "')]/preceding-sibling::td/a"));
            fw.ExecuteJavascript(ele);
            tmsWait.Hard(4);
        }


        [When(@"Transctions View Edit page Force Acceptance checkbox is Clicked")]
        public void WhenTransctionsViewEditPageForceAcceptanceCheckboxIsClicked()
        {
            EAM.TransactionsViewEdit.TransViewEditForceAcceptanceCheck.Click();
        }

        [When(@"Transctions View Edit page Save button is Clicked")]
        public void WhenTransctionsViewEditPageSaveButtonIsClicked()
        {
            EAM.TransactionsViewEdit.TransViewEditSave.Click();

            IAlert save = Browser.Wd.SwitchTo().Alert();
            save.Accept();
        }


        [When(@"Transctions View Edit Table Edit Icon is clicked for row")]
        [Then(@"Transctions View Edit Table Edit Icon is clicked for row")]
        [Given(@"Transctions View Edit Table Edit Icon is clicked for row")]
        public void ThenTransctionsViewEditTableEditIconIsClickedForRow(Table table)
        {


            try
            {
                IWebElement objWebTable = EAM.MembersSearch.TransactionSearchTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index > 0)
                        {
                            index++;
                            string xPath = "//tr[" + index + "]//img[@alt='Edit']";
                            IWebElement editIcon = EAM.MembersSearch.TransactionSearchTable.FindElement(By.XPath(xPath));
                            editIcon.Click();
                            try
                            {
                                editIcon.SendKeys(OpenQA.Selenium.Keys.Enter);
                            }
                            catch (Exception) { }
                            tmsWait.Hard(3);
                            //                            tmsWait.WaitForReadyStateComplete(30);
                            // IWebElement objHIC = tmsWait.WaitForElementExist(By.XPath("//*[contains(@id ,'txtHic_01')]"), 60);
                            Console.WriteLine("Edit icon was clicked");
                        }
                        else { Assert.Fail("Edit Icon for expected row was not found"); }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Transaction Edit Icon is clicked for row: {0}", e.Message);
            }
        }

        [Then(@"View Edit Transctions page MBI as ""(.*)"" First Name as ""(.*)"" Last Name as ""(.*)"" Plan ID as ""(.*)"" Transaction Status as ""(.*)"" Transaction Code as ""(.*)"" is Clicked")]
        public void ThenViewEditTransctionsPageMBIAsFirstNameAsLastNameAsPlanIDAsTransactionStatusAsTransactionCodeAsIsClicked(string p0, string p1, string p2, string p3, string p4, string p5)
        {

            string mbi = tmsCommon.GenerateData(p0);
            string fname = tmsCommon.GenerateData(p1);
            string lname = tmsCommon.GenerateData(p2);
            string planid = tmsCommon.GenerateData(p3);
            string status = tmsCommon.GenerateData(p4);
            string TCcode = tmsCommon.GenerateData(p5);
            By loc;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                loc = By.XPath("//div[@role='presentation']//td[contains(.,'" + mbi + "')]/following-sibling::td[contains(.,'" + fname + "')]/following-sibling::td[contains(.,'" + lname + "')]/following-sibling::td[contains(.,'" + planid + "')]//following-sibling::td[contains(.,'" + status + "')]/following-sibling::td[contains(.,'" + TCcode + "')]/following-sibling::td/a");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            }
            else
            {
                loc = By.XPath("//div[@test-id='transSearch-grid-transactions']//td[contains(.,'" + mbi + "')]/following-sibling::td[contains(.,'" + fname + "')]/following-sibling::td[contains(.,'" + lname + "')]/following-sibling::td[contains(.,'" + planid + "')]//following-sibling::td[contains(.,'" + status + "')]/following-sibling::td[contains(.,'" + TCcode + "')]/following-sibling::td/a");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            }
        }


        [Then(@"View Edit Transctions page displayed MBI as ""(.*)"" First Name as ""(.*)"" Last Name as ""(.*)"" Plan ID as ""(.*)"" Transaction Status as ""(.*)"" Transaction Code as ""(.*)""")]
        public void ThenViewEditTransctionsPageDisplayedMBIAsFirstNameAsLastNameAsPlanIDAsTransactionStatusAsTransactionCodeAs(string p0, string p1, string p2, string p3, string p4, string p5)
        {

            string mbi = tmsCommon.GenerateData(p0);
            string fname = tmsCommon.GenerateData(p1);
            string lname = tmsCommon.GenerateData(p2);
            string planid = tmsCommon.GenerateData(p3);
            string status = tmsCommon.GenerateData(p4);
            string TCcode = tmsCommon.GenerateData(p5);
            By loc;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                loc = By.XPath("//div[@role='presentation']//td[contains(.,'" + mbi + "')]/following-sibling::td[contains(.,'" + fname + "')]/following-sibling::td[contains(.,'" + lname + "')]/following-sibling::td[contains(.,'" + planid + "')]//following-sibling::td[contains(.,'" + status + "')]/following-sibling::td[contains(.,'" + TCcode + "')]");
                UIMODUtilFunctions.elementPresenceUsingLocators(loc);
            }
            else
            {
                loc = By.XPath("//div[@test-id='transSearch-grid-transactions']//td[contains(.,'" + mbi + "')]/following-sibling::td[contains(.,'" + fname + "')]/following-sibling::td[contains(.,'" + lname + "')]/following-sibling::td[contains(.,'" + planid + "')]//following-sibling::td[contains(.,'" + status + "')]/following-sibling::td[contains(.,'" + TCcode + "')]");
                UIMODUtilFunctions.elementPresenceUsingLocators(loc);
            }
        }


        [Then(@"View Edit Transctions page Not displayed MBI as ""(.*)"" First Name as ""(.*)"" Last Name as ""(.*)"" Plan ID as ""(.*)"" Transaction Status as ""(.*)"" Transaction Code as ""(.*)""")]
        public void ThenViewEditTransctionsPageNotDisplayedMBIAsFirstNameAsLastNameAsPlanIDAsTransactionStatusAsTransactionCodeAs(string p0, string p1, string p2, string p3, string p4, string p5)
        {


            string mbi = tmsCommon.GenerateData(p0);
            string fname = tmsCommon.GenerateData(p1);
            string lname = tmsCommon.GenerateData(p2);
            string planid = tmsCommon.GenerateData(p3);
            string status = tmsCommon.GenerateData(p4);
            string TCcode = tmsCommon.GenerateData(p5);
            By loc;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                loc = By.XPath("//div[@role='presentation']//td[contains(.,'" + mbi + "')]/following-sibling::td[contains(.,'" + fname + "')]/following-sibling::td[contains(.,'" + lname + "')]/following-sibling::td[contains(.,'" + planid + "')]//following-sibling::td[contains(.,'" + status + "')]/following-sibling::td[contains(.,'" + TCcode + "')]/following-sibling::td/a");
                UIMODUtilFunctions.elementPresenceUsingLocators(loc);
            }
            else
            {
                loc = By.XPath("//div[@test-id='transSearch-grid-transactions']//td[contains(.,'" + mbi + "')]/following-sibling::td[contains(.,'" + fname + "')]/following-sibling::td[contains(.,'" + lname + "')]/following-sibling::td[contains(.,'" + planid + "')]//following-sibling::td[contains(.,'" + status + "')]/following-sibling::td[contains(.,'" + TCcode + "')]/following-sibling::td/a");
                UIMODUtilFunctions.elementPresenceUsingLocators(loc);
            }


        }

        //[Then(@"View Edit Transctions page Not displayed MBI as ""(.*)"" First Name as ""(.*)"" Last Name as ""(.*)"" Plan ID as ""(.*)"" Transaction Status as ""(.*)"" Transaction Code as ""(.*)""")]
        //public void ThenViewEditTransctionsPageNotDisplayedMBIAsFirstNameAsLastNameAsPlanIDAsTransactionStatusAsTransactionCodeAs(string p0, string p1, string p2, string p3, string p4, string p5)
        //{


        //    string mbi = tmsCommon.GenerateData(p0);
        //    string fname = tmsCommon.GenerateData(p1);
        //    string lname = tmsCommon.GenerateData(p2);
        //    string planid = tmsCommon.GenerateData(p3);
        //    string status = tmsCommon.GenerateData(p4);
        //    string TCcode = tmsCommon.GenerateData(p5);
        //    By loc;
        //    if (ConfigFile.tenantType.Equals("tmsx"))
        //    {
        //        loc = By.XPath("//div[@role='presentation']//td[contains(.,'" + mbi + "')]/following-sibling::td[contains(.,'" + fname + "')]/following-sibling::td[contains(.,'" + lname + "')]/following-sibling::td[contains(.,'" + planid + "')]//following-sibling::td[contains(.,'" + status + "')]/following-sibling::td[contains(.,'" + TCcode + "')]");
        //        UIMODUtilFunctions.elementNotPresenceUsingLocators(loc);
        //    }
        //    else
        //    {

        //         loc = By.XPath("//div[@test-id='transSearch-grid-transactions']//td[contains(.,'" + mbi + "')]/following-sibling::td[contains(.,'" + fname + "')]/following-sibling::td[contains(.,'" + lname + "')]/following-sibling::td[contains(.,'" + planid + "')]//following-sibling::td[contains(.,'" + status + "')]/following-sibling::td[contains(.,'" + TCcode + "')]");
        //        UIMODUtilFunctions.elementNotPresenceUsingLocators(loc);
        //    }
        //}


        [Then(@"Transctions View Edit Table has row")]
        public void ThenTransctionsViewEditTableHasRow(Table table)
        {

            try
            {
                IWebElement objWebTable = EAM.MembersSearch.TransactionSearchTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Members View Edit Table has row: {0}", e.Message);
            }

        }

        [When(@"I create a new EAM database connection ""(.*)"" from the config file")]
        public void WhenICreateANewEAMDatabaseConnectionFromTheConfigFile(string p0)
        {
            db.CreateConn(p0);
        }


        [Given(@"I create a new database connection ""(.*)"" from the config file")]
        [When(@"I create a new database connection ""(.*)"" from the config file")]
        [Then(@"I create a new database connection ""(.*)"" from the config file")]
        public void GivenICreateANewDatabaseConnectionFromTheConfigFile(string p0)
        {
            db.CreateConn(p0);
        }
        [Then(@"Verify EAM_MEMBER_LETTERS table LetterCode column ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyEAM_MEMBER_LETTERSTableLetterCodeColumnIsSetTo(string p0, string p1)
        {
            string actValue = tmsCommon.GenerateData(p0);
            string expValue = p1;
            Assert.AreEqual(expValue, actValue, "Both  values are not matching");
        }

        [When(@"I create a new IdentityServer database connection ""(.*)"" from the config file")]
        public void WhenICreateANewIdentityServerDatabaseConnectionFromTheConfigFile(string p0)
        {
            db.CreateIdentityServerConn(p0);
        }

        [When(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" With MBI ""(.*)"" EAM")]
        public void WhenIExecuteSQLQueryOnDatabaseWithSQLWithMBIEAM(string p0, string p1, string p2)
        {
            string DBname = tmsCommon.GenerateData(p0);

            string sql = tmsCommon.GenerateData(p1);

            string memberid = tmsCommon.GenerateData(p2);

            string SqlString = sql + memberid + "'";
            Console.Write("Query is : " + SqlString);
            tmsWait.Hard(3);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);
        }


        [When(@"I create an ESI FRM database connection ""(.*)"" from the config file")]
        public void WhenICreateAnESIFRMDatabaseConnectionFromTheConfigFile(string p0)
        {
            db.CreateESIFRMConn(p0);

        }

        [When(@"I create a new Warehouse database connection ""(.*)"" from the config file")]
        public void WhenICreateANewWarehouseDatabaseConnectionFromTheConfigFile(string p0)
        {
            db.CreateWarehouseConn(p0);
        }
        [When(@"I create a new PDMMetadata database connection ""(.*)"" from the config file")]
        public void WhenICreateANewPDMMetadataDatabaseConnectionFromTheConfigFile(string p0)
        {
            db.CreatePDMMetaDataConn(p0);
        }


        [When(@"I create a new FRM database connection ""(.*)"" from the config file")]
        public void WhenICreateANewFRMDatabaseConnectionFromTheConfigFile(string p0)
        {
            db.CreateFRMConn(p0);
        }


        [When(@"I create a new ERF database connection ""(.*)"" from the config file")]
        public void WhenICreateANewERFDatabaseConnectionFromTheConfigFile(string p0)
        {
            db.CreateERFConn(p0);
        }

        [When(@"I create a new RAM database connection ""(.*)"" from the config file")]
        public void WhenICreateANewRAMDatabaseConnectionFromTheConfigFile(string p0)
        {
            db.CreateConnRAM(p0);
        }

        [When(@"I create a new RAMX database connection ""(.*)"" from the config file")]
        public void WhenICreateANewRAMXDatabaseConnectionFromTheConfigFile(string p0)
        {
            db.CreateConnRAMX(p0);
        }

        [When(@"I create a new PDEM database connection ""(.*)"" from the config file")]
        public void WhenICreateANewPDEMDatabaseConnectionFromTheConfigFile(string p0)
        {
            db.CreateConnPDEM(p0);
        }

        [When(@"I create a new CDM database connection ""(.*)"" from the config file")]
        public void WhenICreateANewCDMDatabaseConnectionFromTheConfigFile(string p0)
        {
            db.CreateConnCDM(p0);
        }



        [Given(@"I Execute SQL Query on Database ""(.*)"" with SQL ""(.*)""")]
        [When(@"I Execute SQL Query on Database ""(.*)"" with SQL ""(.*)""")]
        [Then(@"I Execute SQL Query on Database ""(.*)"" with SQL ""(.*)""")]
        public void ThenIExecuteSQLQueryOnDatabaseWithSQL(string DbName, string SQLQuery)
        {
            //    db.CreateConnForPDM(ConfigFile.Database);
            //   db.CreateConnForPDM(DbName);
            db.CreateConn(DbName);
            //  db.AddDBQuery(ConfigFile.Database, SQLQuery);
            db.AddDBQuery(DbName, SQLQuery);

        }
        [When(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" With bntMemberId ""(.*)"" on RAMX")]
        public void WhenIExecuteSQLQueryOnDatabaseWithSQLWithBntMemberIdOnRAMX(string DB, string query, string memberid)
        {

            string DBname = tmsCommon.GenerateData(DB);
            tmsWait.Hard(3);
            string memberID = tmsCommon.GenerateData(memberid);
            tmsWait.Hard(3);
            string sql = tmsCommon.GenerateData(query);
            tmsWait.Hard(3);
            string SqlString = sql + "'" + memberID + "'";
            Console.Write("Query is : " + SqlString);
            tmsWait.Hard(3);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);
        }
        [When(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" With Id ""(.*)"" PDEM")]
        public void WhenIExecuteSQLQueryOnDatabaseWithSQLWithIdPDEM(string DB, string query, string memberid)
        {
            string DBname = tmsCommon.GenerateData(DB);
            tmsWait.Hard(3);
            string memberID = tmsCommon.GenerateData(memberid);
            tmsWait.Hard(3);
            string sql = tmsCommon.GenerateData(query);
            tmsWait.Hard(3);
            string SqlString = sql + "'" + memberID + "'";
            Console.Write("Query is : " + SqlString);
            tmsWait.Hard(3);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);
        }

        [Given(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" With Member ID as ""(.*)"" and ""(.*)"" and ""(.*)"" On RAMX")]


        [Then(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" With Member ID as ""(.*)"" and ""(.*)"" and ""(.*)"" On RAMX")]
        [When(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" With Member ID as ""(.*)"" and ""(.*)"" and ""(.*)"" On RAMX")]
        public void ThenIExecuteSQLQueryOnDatabaseWithSQLWithMemberIDAsAndAndOnRAMX(string DB, string query, string memberid1, string memberid2, string memberid3)
        {
            string DBname = tmsCommon.GenerateData(DB);
            //  tmsWait.Hard(3);
            string memberID1 = tmsCommon.GenerateData(memberid1);

            string memberID2 = tmsCommon.GenerateData(memberid2);
            string memberID3 = tmsCommon.GenerateData(memberid3);
            // tmsWait.Hard(3);
            string sql = tmsCommon.GenerateData(query);
            tmsWait.Hard(3);
            string SqlString = sql + memberID1 + "'," + "'" + memberID2 + "'," + "'" + memberID3 + "')";
            Console.Write("Query is : " + SqlString);
            tmsWait.Hard(3);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);

        }


        [Given(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)""")]
        [When(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)""")]
        [Then(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)""")]
        public void GivenIExecuteSQLQueryOnDatabaseWithSQL(string p0, string p1)
        {
            string dbQuery = tmsCommon.GenerateData(p1);
            db.AddDBQuery(p0, dbQuery);
        }
        [Then(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" With noted MBI")]
        public void ThenIExecuteSQLQueryOnDatabaseWithSQLWithNotedMBI(string p0, string p1)
        {
            string dbQuery = tmsCommon.GenerateData(p1);
            //string dbQuery = "select COUNT(*) from EAM.DBO.tbtransaction90 where transid ='16567'";
            string mbi = GlobalRef.MBI.ToString();
            string SqlString = dbQuery + "'" + mbi + "'"; ;
            Console.Write("Query is : " + SqlString);
            db.AddDBQuery(p0, SqlString);
        }
        [Then(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" AND Transid ""(.*)"" EAM")]
        public void ThenIExecuteSQLQueryOnDatabaseWithSQLANDTransidEAM(string p0, string p1, string p2)
        {

            string dbQuery = tmsCommon.GenerateData(p1);
            string TRANSID = tmsCommon.GenerateData(p2);
            string mbi = GlobalRef.MBI.ToString();
            string SqlString = dbQuery + TRANSID + "' and newvalue='" + mbi + "'";
            Console.Write("Query is : " + SqlString);
            db.AddDBQuery(p0, SqlString);
        }

        [When(@"I execute DeleteQuery ""(.*)"" results to the output file")]
        public void WhenIExecuteDeleteQueryResultsToTheOutputFile(string p0)
        {
            Dictionary<int, string[]> table = new Dictionary<int, string[]>();
            SqlCommand thisCommand = null;
            string count = null;
            string Deletequery = tmsCommon.GenerateData(p0);

            List<string> list = new List<string>();
            //try
            //{
            //    //SqlConnection DBConn = new SqlConnection();
            //string thisConnectionString = "user id=tmsservice;" +
            //           "password=TriZetto456;" +
            //           "Server=" + ConfigFile.DataServer + ";" +
            //           "Trusted_Connection = yes; " +
            //           "database=" + DB_NAME + "; " +
            //           "connection timeout=30";
            //DBConn.ConnectionString = thisConnectionString;
            //DBConn.Open();
            //thisCommand = new SqlCommand(Deletequery);
            //SqlDataReader reader = thisCommand.ExecuteNonQuery();


            //SqlConnection con = new SqlConnection(ConfigurationSettings.AppSettings["con"]);

            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = Deletequery;
            //cmd.Connection = con;
            //con.Open();
            int numberDeleted = cmd.ExecuteNonQuery();
            // Response.Write(numberDeleted.ToString() + " employees were deleted.<br>");
            //}

        }


        [When(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" With Memberid ""(.*)"" RAMX")]
        public void WhenIExecuteSQLQueryOnDatabaseWithSQLWithMemberidRAMX(string DB, string query, string memberid)
        {
            string DBname = tmsCommon.GenerateData(DB);
            tmsWait.Hard(3);
            string memberID = tmsCommon.GenerateData(memberid);
            tmsWait.Hard(3);
            string sql = tmsCommon.GenerateData(query);
            tmsWait.Hard(3);
            string SqlString = sql + "'" + memberID + "'";
            Console.Write("Query is : " + SqlString);
            tmsWait.Hard(3);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);
        }
        [When(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" With ChartID ""(.*)"" RAMX")]
        [Then(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" With ChartID ""(.*)"" RAMX")]
        public void ThenIExecuteSQLQueryOnDatabaseWithSQLWithChartIDRAMX(string DB, string query, string chartid)
        {
            string DBname = tmsCommon.GenerateData(DB);
            tmsWait.Hard(3);
            string chartID = tmsCommon.GenerateData(chartid);
            tmsWait.Hard(3);
            string sql = tmsCommon.GenerateData(query);
            tmsWait.Hard(3);
            string SqlString = sql + "' and ChartID = '" + chartID + "'";
            Console.Write("Query is : " + SqlString);
            tmsWait.Hard(3);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);
        }

        [Given(@"I execute SQL Query ""(.*)"" on Database ""(.*)"" with HIC ""(.*)""")]
        [When(@"I execute SQL Query ""(.*)"" on Database ""(.*)"" with HIC ""(.*)""")]
        [Then(@"I execute SQL Query ""(.*)"" on Database ""(.*)"" with HIC ""(.*)""")]


        public void WhenIExecuteSQLQueryOnDatabaseWithHIC(string query, string DB, string hicValue)
        {
            string DBname = tmsCommon.GenerateData(DB);
            tmsWait.Hard(3);
            string HIC = tmsCommon.GenerateData(hicValue);
            tmsWait.Hard(3);
            string sql = tmsCommon.GenerateData(query);
            tmsWait.Hard(3);
            string SqlString = sql + "'" + HIC + "'";
            Console.Write("Query is : " + SqlString);
            tmsWait.Hard(3);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);
        }
        [Then(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" with hic ""(.*)"" On")]
        public void ThenIExecuteSQLQueryOnDatabaseWithSQLWithHicOn(string DB, string query, string hic)
        {
            string DBname = tmsCommon.GenerateData(DB);

            string hic1 = tmsCommon.GenerateData(hic);

            string sql = tmsCommon.GenerateData(query);

            string SqlString = sql + "'" + hic1 + "'";
            Console.Write("Query is : " + SqlString);
            tmsWait.Hard(3);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);
        }

        [Then(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" with ExecutionId ""(.*)"" On eamWareHouse")]
        public void ThenIExecuteSQLQueryOnDatabaseWithSQLWithExecutionIdOnEamWareHouse(string DB, string query, string reqid)
        {

            string DBname = tmsCommon.GenerateData(DB);

            string executionID = tmsCommon.GenerateData(reqid);

            string sql = tmsCommon.GenerateData(query);

            string SqlString = sql + "'" + executionID + "'";
            Console.Write("Query is : " + SqlString);
            tmsWait.Hard(3);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);
        }


        [Then(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" with bntMemberId as ""(.*)"", PaymentYear as ""(.*)"" and HCCSequence as ""(.*)"" on RAMX")]
        public void ThenIExecuteSQLQueryOnDatabaseWithSQLWithBntMemberIdAsPaymentYearAsAndHCCSequenceAsOnRAMX(string DB, string query, string memberid, string paymentYr, string hccseq)
        {
            string DBname = tmsCommon.GenerateData(DB);
            tmsWait.Hard(3);
            string sql = tmsCommon.GenerateData(query);
            tmsWait.Hard(3);
            string memberID = tmsCommon.GenerateData(memberid);
            tmsWait.Hard(3);
            string paymentYear = tmsCommon.GenerateData(paymentYr);
            tmsWait.Hard(3);
            string hccSeq = tmsCommon.GenerateData(hccseq);
            tmsWait.Hard(3);
            string SqlString = sql + memberID + "'" + " and PaymentYear='" + paymentYear + "'" + " and intHCCSequence='" + hccSeq + "'";
            Console.Write("Query is : " + SqlString);
            tmsWait.Hard(3);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);
        }



        [Then(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" with bntMemberId ""(.*)"" on RAMX")]
        public void ThenIExecuteSQLQueryOnDatabaseWithSQLWithBntMemberIdOnRAMX(string DB, string query, string memberid)
        {
            string DBname = tmsCommon.GenerateData(DB);
            tmsWait.Hard(3);
            string sql = tmsCommon.GenerateData(query);
            tmsWait.Hard(3);
            string memberID = tmsCommon.GenerateData(memberid);
            tmsWait.Hard(3);
            string SqlString = sql + "'" + memberID + "'";
            Console.Write("Query is : " + SqlString);
            tmsWait.Hard(3);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);
        }

        [Then(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" with PaymentYear ""(.*)"" and HCCSquence ""(.*)"" on RAMX")]
        public void ThenIExecuteSQLQueryOnDatabaseWithSQLWithPaymentYearAndHCCSquenceOnRAMX(string DB, string query, string PaymentYear, string p3)
        {
            string DBname = tmsCommon.GenerateData(DB);

            string sql = tmsCommon.GenerateData(query);
            string hccseq = tmsCommon.GenerateData(p3);
            string PaymentY = tmsCommon.GenerateData(PaymentYear);

            string SqlString = sql + "'" + PaymentY + "' and intHCCSequence='" + hccseq + "'";
            Console.Write("Query is : " + SqlString);
            tmsWait.Hard(3);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);
        }

        [Then(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" with PaymentYear ""(.*)"" and HCCSquence ""(.*)"" and on RAMX")]
        public void ThenIExecuteSQLQueryOnDatabaseWithSQLWithPaymentYearAndHCCSquenceAndOnRAMX(string DB, string query, string PaymentYear, string p3)
        {
            string DBname = tmsCommon.GenerateData(DB);

            string sql = tmsCommon.GenerateData(query);
            string hcc = tmsCommon.GenerateData(p3);
            string PaymentY = tmsCommon.GenerateData(PaymentYear);
            string hccDB = GlobalRef.HCCValue.ToString();

            string SqlString = sql + hccDB + ") and PaymentYear='" + PaymentY + "')";
            Console.Write("Query is : " + SqlString);
            tmsWait.Hard(3);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);
        }

        [Then(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" with bntMemberId ""(.*)"" and HCCSquence ""(.*)"" and on RAMX")]
        public void ThenIExecuteSQLQueryOnDatabaseWithSQLWithBntMemberIdAndHCCSquenceAndOnRAMX(string DB, string query, string memberid, string HCCSequence)
        {
            string DBname = tmsCommon.GenerateData(DB);
            tmsWait.Hard(3);
            string sql = tmsCommon.GenerateData(query);
            tmsWait.Hard(3);
            string memberID = tmsCommon.GenerateData(memberid);
            tmsWait.Hard(3);
            string HCCSeq = tmsCommon.GenerateData(HCCSequence);
            tmsWait.Hard(3);
            string SqlString = sql + "'" + memberID + "' and intHCCSequence='" + HCCSeq + "'";
            Console.Write("Query is : " + SqlString);
            tmsWait.Hard(3);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);

        }

        [Then(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" with JobId ""(.*)"" On eamWareHouse")]
        public void ThenIExecuteSQLQueryOnDatabaseWithSQLWithJobIdOnEamWareHouse(string DB, string query, string jobid)
        {

            string DBname = tmsCommon.GenerateData(DB);

            string jobID = tmsCommon.GenerateData(jobid);

            string sql = tmsCommon.GenerateData(query);

            string SqlString = sql + "'" + jobID + "'";
            Console.Write("Query is : " + SqlString);
            tmsWait.Hard(3);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);
        }



        [Then(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" with RequestId ""(.*)"" WareHouse")]
        public void ThenIExecuteSQLQueryOnDatabaseWithSQLWithRequestIdWareHouse(string DB, string query, string Reqid)
        {
            string DBname = tmsCommon.GenerateData(DB);



            string sql = tmsCommon.GenerateData(query);
            string REQid = tmsCommon.GenerateData(Reqid);

            string SqlString = sql + "'" + REQid + "') group by ErrorId";
            Console.Write("Quer is : " + SqlString);
            tmsWait.Hard(3);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);
        }
        [When(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" with RequestId ""(.*)"" And memberID ""(.*)"" eamWareHouse")]
        public void ThenIExecuteSQLQueryOnDatabaseWithSQLWithRequestIdAndMemberIDEamWareHouse(string DB, string query, string Reqid, string mem1)
        {
            string DBname = tmsCommon.GenerateData(DB);



            string sql = tmsCommon.GenerateData(query);
            string REQid = tmsCommon.GenerateData(Reqid);
            string mem = tmsCommon.GenerateData(mem1);
            string SqlString = sql + "'" + REQid + "' and EntityData like '%" + mem + "%'";
            Console.Write("Query is : " + SqlString);
            tmsWait.Hard(3);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);

        }
        [When(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" with RequestId ""(.*)"" And memberID ""(.*)"" ON eamWareHouse")]
        public void WhenIExecuteSQLQueryOnDatabaseWithSQLWithRequestIdAndMemberIDONEamWareHouse(string DB, string query, string Reqid, string mem1)
        {
            string DBname = tmsCommon.GenerateData(DB);



            string sql = tmsCommon.GenerateData(query);
            string REQid = tmsCommon.GenerateData(Reqid);
            string mem = tmsCommon.GenerateData(mem1);
            string SqlString = sql + "'" + REQid + "' and EntityData like '%" + mem + "%'";
            Console.Write("Query is : " + SqlString);
            tmsWait.Hard(3);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);
        }

        [When(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" with RequestId ""(.*)"" And memberID ""(.*)"" eamWareHouse(.*)")]
        [Then(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" with RequestId ""(.*)"" And memberID ""(.*)"" eamWareHouse(.*)")]
        public void ThenIExecuteSQLQueryOnDatabaseWithSQLWithRequestIdAndMemberIDEamWareHouse(string DB, string query, string Reqid, string mem1, int i)
        {
            string DBname = tmsCommon.GenerateData(DB);



            string sql = tmsCommon.GenerateData(query);
            string REQid = tmsCommon.GenerateData(Reqid);
            string mem = tmsCommon.GenerateData(mem1);
            string SqlString = sql + "'" + REQid + "' and EntityData like '%" + mem + "%'";
            Console.Write("Query is : " + SqlString);
            tmsWait.Hard(3);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);

        }

        [Then(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" with RequestId ""(.*)"" And memberID ""(.*)"" eamWareHousee")]
        public void ThenIExecuteSQLQueryOnDatabaseWithSQLWithRequestIdAndMemberIDEamWareHousee(string DB, string query, string Reqid, string mem1)
        {


            string DBname = tmsCommon.GenerateData(DB);



            string sql = tmsCommon.GenerateData(query);
            string REQid = tmsCommon.GenerateData(Reqid);
            string mem = tmsCommon.GenerateData(mem1);
            string SqlString = sql + "'" + REQid + "' and EntityData like '%" + mem + "%'";
            Console.Write("Query is : " + SqlString);
            tmsWait.Hard(3);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);

        }
        [Then(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" with RequestId ""(.*)"" On eamWareHouse")]
        public void ThenIExecuteSQLQueryOnDatabaseWithSQLWithRequestIdOnEamWareHouse(string DB, string query, string Reqid)
        {
            string DBname = tmsCommon.GenerateData(DB);



            string sql = tmsCommon.GenerateData(query);
            string REQid = tmsCommon.GenerateData(Reqid);

            string SqlString = sql + "'" + REQid + "')";
            Console.Write("Query is : " + SqlString);
            tmsWait.Hard(3);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);

        }
        [When(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" with RequestId ""(.*)"" And EntityId ""(.*)"" eamWareHouse")]
        [Then(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" with RequestId ""(.*)"" And EntityId ""(.*)"" eamWareHouse")]
        public void ThenIExecuteSQLQueryOnDatabaseWithSQLWithRequestIdAndEntityIdEamWareHouse(string DB, string query, string Reqid, string entityID)
        {

            string DBname = tmsCommon.GenerateData(DB);



            string sql = tmsCommon.GenerateData(query);
            string REQid = tmsCommon.GenerateData(Reqid);
            string entity = tmsCommon.GenerateData(entityID);
            string SqlString = sql + "'" + REQid + "')and EntityId ='" + entity + "'";
            Console.Write("Query is : " + SqlString);
            tmsWait.Hard(3);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);
        }


        [Then(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" with HCCNumber ""(.*)"" and PaymentYear ""(.*)"" on RAMX")]
        public void ThenIExecuteSQLQueryOnDatabaseWithSQLWithHCCNumberAndPaymentYearOnRAMX(string DB, string sql, string HCC, string paymentYear)
        {
            string DBname = tmsCommon.GenerateData(DB);
            //  tmsWait.Hard(3);
            string query = tmsCommon.GenerateData(sql);
            // tmsWait.Hard(3);
            string HCCno = tmsCommon.GenerateData(HCC);
            // tmsWait.Hard(3);
            string paymentY = tmsCommon.GenerateData(paymentYear);
            // tmsWait.Hard(3);
            string SqlString = query + HCCno + "' and PaymentYear='" + paymentY + "'";
            Console.Write("Query is : " + SqlString);
            //tmsWait.Hard(3);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);
        }
        [Then(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" with bntMemberId ""(.*)"" and PaymentYear ""(.*)"" RAMX")]
        public void ThenIExecuteSQLQueryOnDatabaseWithSQLWithBntMemberIdAndPaymentYearRAMX(string DB, string sql, string mem, string paymentYear)
        {
            string DBname = tmsCommon.GenerateData(DB);
            //  tmsWait.Hard(3);
            string query = tmsCommon.GenerateData(sql);
            // tmsWait.Hard(3);
            string mem1 = tmsCommon.GenerateData(mem);
            // tmsWait.Hard(3);
            string paymentY = tmsCommon.GenerateData(paymentYear);
            // tmsWait.Hard(3);
            string SqlString = query + mem1 + "' and PaymentYear='" + paymentY + "'";
            Console.Write("Query is : " + SqlString);
            //tmsWait.Hard(3);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);
        }
        [Then(@"Verify variable ""(.*)"" Then I decide to execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" with bntMemberId ""(.*)"" and PaymentYear ""(.*)"" and intHCCSequence RAMX")]
        public void ThenVerifyVariableThenIDecideToExecuteSQLQueryOnDatabaseWithSQLWithBntMemberIdAndPaymentYearAndIntHCCSequenceRAMX(string unknownStatus, string DB, string sql, string mem, string paymentYear)
        {
            string UnknownStatus = tmsCommon.GenerateData(unknownStatus);


            if (UnknownStatus.Trim().Equals("0"))
            {

            }

            else if (unknownStatus.Trim().Equals("1"))
            {



                string DBname = tmsCommon.GenerateData(DB);
                //  tmsWait.Hard(3);
                string query = tmsCommon.GenerateData(sql);
                // tmsWait.Hard(3);
                string mem1 = tmsCommon.GenerateData(mem);
                // tmsWait.Hard(3);
                string paymentY = tmsCommon.GenerateData(paymentYear);
                // tmsWait.Hard(3);
                string hcc = GlobalRef.HCCValue.ToString();
                string SqlString = query + mem1 + "' and txtICD9Code in(select Codevalue  from ICD9Codes where CodeId in (Select CodeId from PTC_HCC_ICD_Mapping where intHCCSequence = '" + hcc + "'and PaymentYear ='" + paymentY + "'))";
                Console.Write("Query is : " + SqlString);
                //tmsWait.Hard(3);
                string dbQuery = tmsCommon.GenerateData(SqlString);
                db.AddDBQuery(DBname, dbQuery);
                string result = db.StoreDBResultsInString(DBname);
                tmsWait.Hard(5);
                Console.Write("Value is " + result.Trim());
                Assert.IsTrue(result.Trim().Equals("1"));
            }
        }


        [Then(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" with HCCNumber ""(.*)"" and PaymentYear ""(.*)"" on PDMMetaData")]
        public void ThenIExecuteSQLQueryOnDatabaseWithSQLWithHCCNumberAndPaymentYearOnPDMMetaData(string DB, string sql, string HCC, string paymentYear)
        {
            string DBname = tmsCommon.GenerateData(DB);
            tmsWait.Hard(3);
            string query = tmsCommon.GenerateData(sql);
            tmsWait.Hard(3);
            string HCCno = tmsCommon.GenerateData(HCC);
            tmsWait.Hard(3);
            string paymentY = tmsCommon.GenerateData(paymentYear);
            tmsWait.Hard(3);
            string SqlString = query + HCCno + "' and PaymentYear='" + paymentY + "'";
            Console.Write("Query is : " + SqlString);
            tmsWait.Hard(3);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);
        }

        [When(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" with PlanID ""(.*)"" on EAM")]
        public void WhenIExecuteSQLQueryOnDatabaseWithSQLWithPlanIDOnEAM(string DB, string sql, string plan)
        {

            string DBname = tmsCommon.GenerateData(DB);
            tmsWait.Hard(3);
            string query = tmsCommon.GenerateData(sql);
            tmsWait.Hard(3);
            string planid = tmsCommon.GenerateData(plan);
            tmsWait.Hard(3);

            string SqlString = query + " and planid !='" + planid + "'";
            Console.Write("Query is : " + SqlString);
            tmsWait.Hard(3);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);
        }

        [Then(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" with PlanID ""(.*)"" and PBPID ""(.*)"" EAM(.*)")]
        public void ThenIExecuteSQLQueryOnDatabaseWithSQLWithPlanIDAndPBPIDEAM(string DB, string sql, string plan, string pbp, string p4)
        {
            string DBname = tmsCommon.GenerateData(DB);
            tmsWait.Hard(3);
            string query = tmsCommon.GenerateData(sql);
            tmsWait.Hard(3);
            string planid = tmsCommon.GenerateData(plan);
            tmsWait.Hard(3);
            string pbpid = tmsCommon.GenerateData(pbp);
            tmsWait.Hard(3);
            string SqlString = query + "" + planid + "' and PBPID !='" + pbpid + "'";
            Console.Write("Query is : " + SqlString);
            tmsWait.Hard(3);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);
        }

        [Then(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" with Noted RequestID")]
        public void ThenIExecuteSQLQueryOnDatabaseWithSQLWithNotedRequestID(string DB, string sql)
        {

            string DBname = tmsCommon.GenerateData(DB);

            string query = tmsCommon.GenerateData(sql);
            // GlobalRef.requestID = "184187";
            string ReqID = GlobalRef.requestID.ToString();
            string SqlString = query + ReqID + "'";
            Console.Write("Query is : " + SqlString);
            tmsWait.Hard(3);

            db.AddDBQuery(DBname, SqlString);
        }
        [When(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" With PaymentYear  ""(.*)"" on RAMX")]
        public void WhenIExecuteSQLQueryOnDatabaseWithSQLWithPaymentYearOnRAMX(string DBname, string sql, string paymentYear)
        {
            string DB = tmsCommon.GenerateData(DBname);

            string query = tmsCommon.GenerateData(sql);

            string paymentY = tmsCommon.GenerateData(paymentYear);

            string SqlString = query + paymentY + "'";
            Console.Write("Query is : " + SqlString);
            tmsWait.Hard(3);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DB, dbQuery);
        }

        [When(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" With Memberid  ""(.*)"" on RAMX")]
        public void WhenIExecuteSQLQueryOnDatabaseWithSQLWithMemberidOnRAMX(string p0, string p1, string p2)
        {
            string DBname = tmsCommon.GenerateData(p0);

            string sql = tmsCommon.GenerateData(p1);

            string memberid = tmsCommon.GenerateData(p2);

            string SqlString = sql + memberid + "'";
            Console.Write("Query is : " + SqlString);
            tmsWait.Hard(3);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);
        }
        [Then(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" with PaymentYear ""(.*)"" On RAMX")]
        public void ThenIExecuteSQLQueryOnDatabaseWithSQLWithPaymentYearOnRAMX(string p0, string p1, string p2)
        {
            string DBname = tmsCommon.GenerateData(p0);

            string sql = tmsCommon.GenerateData(p1);

            string PaymentYear = tmsCommon.GenerateData(p2);

            string SqlString = sql + PaymentYear + "'";
            Console.Write("Query is : " + SqlString);
            tmsWait.Hard(3);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);
        }

        [When(@"I execute SQL Query on Database ""(.*)"" with SQL ""(.*)"" With Memberid  ""(.*)"" and Hccseq ""(.*)""  RAMX")]
        public void WhenIExecuteSQLQueryOnDatabaseWithSQLWithMemberidAndHccseqRAMX(string p0, string p1, string p2, string p3)
        {
            string DBname = tmsCommon.GenerateData(p0);

            string sql = tmsCommon.GenerateData(p1);

            string memberid = tmsCommon.GenerateData(p2);
            string hccsq = tmsCommon.GenerateData(p3);
            string SqlString = sql + memberid + "'and intHCCSequence='" + hccsq + "'";
            Console.Write("Query is : " + SqlString);
            tmsWait.Hard(3);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);
        }


        [When(@"I execute SQL Query ""(.*)"" on Database ""(.*)"" with ProjectName ""(.*)""")]
        public void WhenIExecuteSQLQueryOnDatabaseWithProjectName(string p0, string p1, string p2)
        {
            string DBname = tmsCommon.GenerateData(p1);
            string ProjectName = tmsCommon.GenerateData(p2);
            string sql = tmsCommon.GenerateData(p0);
            string SqlString = sql + "'" + ProjectName + "')";
            Console.Write("Query is : " + SqlString);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);
        }


        [When(@"I execute SQL Query on Database ""(.*)"" for query HIC ""(.*)""")]
        public void WhenIExecuteSQLQueryOnDatabaseForUser(string dbname, string HICvalue)
        {

        }
        [When(@"I execute SQL Query ""(.*)"" on Database ""(.*)"" with FileName ""(.*)""")]
        public void WhenIExecuteSQLQueryOnDatabaseWithFileName(string p0, string p1, string p2)
        {



            string DBname = tmsCommon.GenerateData(p1);
            string HIC = tmsCommon.GenerateData(p2);
            string sql = tmsCommon.GenerateData(p0);
            string SqlString = sql + "'" + HIC + "'";
            Console.Write("Query is : " + SqlString);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);
        }

       
        [When(@"I execute update query ""(.*)""")]
        public void WhenIExecuteUpdateQuery(string p0)
        {
            //string thisConnectionString = "user id=" + ConfigFile.DBUser + ";" +
            //                      "password=" + ConfigFile.DBPassword + ";" +
            //                      "Data Source=" + ConfigFile.DataServer + "," + ConfigFile.Port + ";" +
            //                      "Network Library=DBMSSOCN;" +
            //                      "Initial Catalog=" + ConfigFile.EAMdb + "; " +
            //                      "connection timeout=30";
            string thisConnectionString = "server=" + ConfigFile.DataServer + ";" + "database=" + ConfigFile.EAMdb + ";" + "user id=" + ConfigFile.DBUser + ";" + "password=" + ConfigFile.DBPassword + ";" + "Max Pool Size=9000;" + "Connection Timeout=150;" + "Min Pool Size=2";
            //Console.WriteLine("Creating DB Connection [" + DBName + "] with Connection String [" + thisConnectionString + "]");
            //DBConns[DBName].ConnectionString = thisConnectionString;
            //DBConns[DBName].Open();

            using (SqlConnection connection = new SqlConnection(thisConnectionString))
            {
                string query = tmsCommon.GenerateData(p0);
                connection.Open();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    //GetExample(command, p);
                    command.ExecuteNonQuery();
                    connection.Close();
                    command.Parameters.Clear();
                }
            }
        }

        private void GetExample(SqlCommand command, object p)
        {
            throw new NotImplementedException();
        }


        [When(@"I execute query ""(.*)"" and db ""(.*)""")]
        public void WhenIExecuteQueryAndDb(string p0, string p1)
        {
            //string query = tmsCommon.GenerateData(p0);
            string dbname = tmsCommon.GenerateData(p1);
            string thisConnectionString = "";
            switch (dbname.ToLower())

            {
                case "eam":
                    thisConnectionString = "server=" + ConfigFile.DataServer + ";" + "database=" + ConfigFile.EAMdb + ";" + "user id=" + ConfigFile.DBUser + ";" + "password=" + ConfigFile.DBPassword + ";" + "Max Pool Size=9000;" + "Connection Timeout=150;" + "Min Pool Size=2";
                    break;

                case "identity server":
                    thisConnectionString = "server=" + ConfigFile.DataServer + ";" + "database=" + ConfigFile.IdentitySdb + ";" + "user id=" + ConfigFile.DBUser + ";" + "password=" + ConfigFile.DBPassword + ";" + "Max Pool Size=9000;" + "Connection Timeout=150;" + "Min Pool Size=2";
                    break;
            }

            using (SqlConnection connection = new SqlConnection(thisConnectionString))
            {
                string query = tmsCommon.GenerateData(p0);
                connection.Open();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    //GetExample(command, p);
                    command.ExecuteNonQuery();
                    connection.Close();
                    command.Parameters.Clear();
                }
            }

        }



        [Then(@"I output database ""(.*)"" results to the output file")]
        [Given(@"I output database ""(.*)"" results to the output file")]
        [When(@"I output database ""(.*)"" results to the output file")]
        public void GivenIOutputDatabaseResultsToTheOutputFile(string p0)
        {
            db.OutputDBResults(p0);

        }

        [When(@"variable ""(.*)"" is set to value from DB ""(.*)""")]
        public void WhenVariableIsSetToValueFromDB(string p0, string p1)
        {
            string result = db.StoreDBResults(p1);

            tmsWait.Hard(5);

            fw.setVariable(p0, result.Trim());
            Console.Write("Value is " + p0);
        }

        [When(@"variable ""(.*)"" is set to value from database ""(.*)""")]
        [Given(@"variable ""(.*)"" is set to value from database ""(.*)""")]
        [Then(@"variable ""(.*)"" is set to value from database ""(.*)""")]
        public void WhenVariableIsSetToValueFromDatabase(string p0, string p1)
        {
            string result = db.StoreDBResultsInString(p1);

            tmsWait.Hard(5);
            //string result = db.StoreDBResults(p1, List<string> res);
            fw.setVariable(p0, result.Trim());
            Console.Write("Value is " + p0);
        }

        [When(@"variable ""(.*)"" is set to date value from database ""(.*)""")]
        public void WhenVariableIsSetToDateValueFromDatabase(string p0, string p1)
        {
            string dboutput = db.StoreDBResultsInString(p1);
            string[] result = dboutput.Split(' ');
            fw.setVariable(p0, result[0].Trim());
        }



        [When(@"on RAMX variable ""(.*)"" is set to value from db ""(.*)""")]
        public void WhenOnRAMXVariableIsSetToValueFromDb(string p0, string p1)
        {
            string result = db.StoreDBResultsInString(p1);
            if (result != "")
                fw.setVariable(p0, result.Trim());
            else
                Assert.Fail("No Data available for selected Payment years (current year/ current year - 1). Please ensure to do Data Load on RAMX or check with Manual Team");
        }


        [When(@"variable ""(.*)"" is set to a valid value from database ""(.*)""")]
        public void WhenVariableIsSetToAValidValueFromDatabase(string var, string sqlquery)
        {
            string paymentYear;
            string result = db.StoreDBResultsInString(sqlquery);
            if (result == "0")
            {
                paymentYear = tmsCommon.GenerateData("Generate|current-1");
            }
            else
            {
                paymentYear = tmsCommon.GenerateData("Generate|current");
            }
            fw.setVariable(var, paymentYear);
        }

        [When(@"variable ""(.*)"" is set to a valid datavalue from ramx database")]
        public void WhenVariableIsSetToAValidDatavalueFromRamxDatabase(string var)
        {
            string DBName = "FileNameQuery";
            db.CreateConnRAMX(DBName);
            string CurrentYear = tmsCommon.GenerateData("Generate|current");

            int i = 0;
            while (i <= 5)
            {
                string query = tmsCommon.GenerateData("select count(revenue) from [RAMX].[dbo].tbExceptionLetters te join [RAMX].[dbo].vuMembersYearlyPlan tc on te.bntmemberid=tc.bntMemberId where te.intstatus in (-1,0, 8,9) and revenue is not null and tc.PaymentYear='" + CurrentYear + "'");
                db.AddDBQuery(DBName, query);
                string result = db.StoreDBResultsInString(DBName);
                if (result == "0")
                {
                    i++;

                    CurrentYear = tmsCommon.GenerateData("Generate|current-" + i + "");
                }
                else
                {
                    fw.setVariable(var, CurrentYear);
                    break;
                }
            }
        }




        [Then(@"variable ""(.*)"" is set to a valid value from ramx database")]
        public void WhenVariableIsSetToAValidValueFromRamxDatabase(string var)
        {
            string DBName = "FileNameQuery";
            db.CreateConnRAMX(DBName);
            string CurrentYear = tmsCommon.GenerateData("Generate|current");

            int i = 0;
            while (i <= 5)
            {
                string query = tmsCommon.GenerateData("select count(revenue) from [RAMX].[dbo].tbExceptionLetters te join [RAMX].[dbo].vuMembersYearlyPlan tc on te.bntmemberid=tc.bntMemberId where te.intstatus in (-1,0, 8,9) and revenue is not null and tc.PaymentYear='" + CurrentYear + "'");
                db.AddDBQuery(DBName, query);
                string result = db.StoreDBResultsInString(DBName);
                if (result == "0")
                {
                    i++;

                    CurrentYear = tmsCommon.GenerateData("Generate|current-" + i + "");
                }
                else
                {
                    fw.setVariable(var, CurrentYear);
                    break;
                }
            }
        }

        [When(@"variable ""(.*)"" is set to a valid value from ramx database for payment year ""(.*)""")]
        public void WhenVariableIsSetToAValidValueFromRamxDatabaseForPaymentYear(string var, string year)
        {
            string paymentYear = tmsCommon.GenerateData(year);
            string DBName = "FileNameQuery";
            db.CreateConnRAMX(DBName);
            string query = tmsCommon.GenerateData(" select top 1 txtPlanID from[RAMX].[dbo].vuMembersYearlyPlan tc join[RAMX].[dbo].tbExceptionLetters te on te.bntmemberid=tc.bntMemberId where te.intstatus in (-1,0, 8,9) and revenue is not null and tc.PaymentYear='" + paymentYear + "'");
            db.AddDBQuery(DBName, query);
            string result = db.StoreDBResultsInString(DBName);
            fw.setVariable(var, result);
        }


        [When(@"variable ""(.*)"" is set to a value from database ""(.*)"" for Member ""(.*)""")]
        public void WhenVariableIsSetToAValueFromDatabaseForMember(string p0, string p1, string p2)
        {
            string DBName = "ICD9CodesQuery";
            string DBName2 = "onHoldClaimQuery";

            db.CreateConnRAMX(DBName);
            string memDiagCodeQuery = tmsCommon.GenerateData(p1);
            string dbQuery = tmsCommon.GenerateData("select top 30 CodeValue from [RAMX].[dbo].[ICD9Codes] order by CodeValue desc");
            db.AddDBQuery(DBName, dbQuery);

            db.CreateConnRAMX(DBName2);
            string dbQueryOnHoldClaims = tmsCommon.GenerateData(p2);
            db.AddDBQuery(DBName2, dbQueryOnHoldClaims);

            IList<string> ICD9CodesList = db.OutputDBResultsToList(DBName);
            IList<string> OnHoldClaims = db.OutputDBResultsToList(DBName2);
            IList<string> MemberDiagCodes = db.OutputDBResultsToList(p1);
            foreach (string ICD9Code in ICD9CodesList)
            {

                if (MemberDiagCodes.Contains(ICD9Code) || OnHoldClaims.Contains(ICD9Code) == false)
                {
                    fw.setVariable(p0, ICD9Code);
                    Console.Write("Diag Code " + ICD9Code);
                    break;
                }
            }
        }

        [Then(@"i perform clear operation ""(.*)""")]
        [Given(@"i perform clear operation ""(.*)""")]
        [When(@"i perform clear operation ""(.*)""")]
        public void ThenIPerformClearOperation(string p0)
        {
            string DBName = "DeleteQuery";
            string deleteQuery = tmsCommon.GenerateData(p0);
            db.CreateConnRAMX(DBName);
            db.AddDBQuery(DBName, deleteQuery);
            db.ExecuteDeleteQuery(DBName);
            tmsWait.Hard(2);
        }


        [Then(@"Verify View Edit Transaction PartC Amount is matching with SQL Query Output Value ""(.*)""")]
        public void ThenVerifyViewEditTransactionPartCAmountIsMatchingWithSQLQueryOutputValue(string p0)
        {
            string partcAmount = GlobalRef.PartCAmtTC78.ToString();
            List<string> sqllist = new List<string>();
            sqllist = db.OutputDBResultsToList(p0);

            valuePresenceOnCollection(sqllist, partcAmount);

        }

        public void valuePresenceOnCollection(List<string> values, string amount)
        {
            string[] sqlarray = values.ToArray();

            bool flag = false;
            for (int i = 0; i < sqlarray.Length; i++)
            {
                if (sqlarray[i].Contains(amount))
                {
                    Assert.IsTrue(true, amount + " Expected Premium Amount is displayed");
                    Console.WriteLine(amount + " Premium Amount is displayed");
                    flag = true;
                    break;
                }
            }

            Assert.IsTrue(flag, "Expected Premium is not getting displayed");
        }

        //[When(@"Fetch TransID from database ""(.*)"" Add it to TRR File ""(.*)"" with values ""(.*)"" ""(.*)"" ""(.*)"" ""(.*)""")]
        //public void WhenFetchTransIDFromDatabaseAddItToTRRFileWithValues(string p0, string p1, string p2, string p3, string p4, string p5)
        //{
        //    string sourceTRR = "c:\\temp\\" + tmsCommon.GenerateData(p1);
        //    string MBI1 = tmsCommon.GenerateData(p2);
        //    string MBI2 = tmsCommon.GenerateData(p3);
        //    string MBI3 = tmsCommon.GenerateData(p4);
        //    string MBI4 = tmsCommon.GenerateData(p5);

        //    List<string> sqllist = new List<string>();
        //    //sqllist = db.OutputDBResultsToList(p0);

        //    //string[] sqlarray = sqllist.ToArray();
        //    string transID;
        //    transID = db.OutputDBResultsToList(p0)[0].ToString();
        //    fw.ConsoleReport(" Trans ID which will be replaced in TRR File is " + transID);
        //    fw.ConsoleReport(" MBI which will be replaced in TRR File is " + MBI1);


        //    string[] lines = System.IO.File.ReadAllLines(sourceTRR);
        //    string[] st1 = new string[lines.Length];

        //    for (int i = 0; i < lines.Length; i++)
        //    {

        //        StringBuilder st = new StringBuilder(lines[i]);

        //        st.Remove(485, 5);
        //        //Console.WriteLine($"Trans ID {sqlarray[i]} - {sqlarray[i].Length}");
        //        st.Insert(485, transID);

        //        st.Remove(0, 11);
        //        st.Insert(0, runTimeMBI);
        //        st1[i] = st.ToString();
        //        Console.WriteLine(st1[i]);


        //    }

        //    System.IO.File.WriteAllLines(sourceTRR, st1);

        //}

        [When(@"Fetch TransID ""(.*)"" ""(.*)"" ""(.*)"" ""(.*)"" Add it to TRR File ""(.*)"" with values ""(.*)"" ""(.*)"" ""(.*)"" ""(.*)""")]
        public void WhenFetchTransIDAddItToTRRFileWithValues(string p0, string p1, string p2, string p3, string p4, string p5, string p6, string p7, string p8)
        {
            string t1 = tmsCommon.GenerateData(p0);
            string t2 = tmsCommon.GenerateData(p1);
            string t3 = tmsCommon.GenerateData(p2);
            string t4 = tmsCommon.GenerateData(p3);
            string fileName = tmsCommon.GenerateData(p4);
            string mbi1 = tmsCommon.GenerateData(p5);
            string mbi2 = tmsCommon.GenerateData(p6);
            string mbi3 = tmsCommon.GenerateData(p7);
            string mbi4 = tmsCommon.GenerateData(p8);
            string transid="";

            string sourceTRR = "c:\\temp\\" + tmsCommon.GenerateData(p4);
            

            List<string> sqllist = new List<string>();
          
            //string transID;
            //transID = db.OutputDBResultsToList(p0)[0].ToString();
            //fw.ConsoleReport(" Trans ID which will be replaced in TRR File is " + transID);
            //fw.ConsoleReport(" MBI which will be replaced in TRR File is " + runTimeMBI);


            string[] lines = System.IO.File.ReadAllLines(sourceTRR);
            string[] st1 = new string[lines.Length];

            for (int i = 0; i < lines.Length; i++)
            {
                if (lines[i].Contains(mbi1))
                {
                    transid = t1;
                }
                if (lines[i].Contains(mbi2))
                {
                    transid = t2;
                }

                if (lines[i].Contains(mbi3))
                {
                    transid = t3;
                }
                if (lines[i].Contains(mbi4))
                {
                    transid = t4;
                }
                StringBuilder st = new StringBuilder(lines[i]);

                    st.Remove(485, 5);
                    st.Insert(485, transid);

                    //st.Remove(0, 11);
                    //st.Insert(0, runTimeMBI);
                    st1[i] = st.ToString();
                    Console.WriteLine(st1[i]);
                


            }

            System.IO.File.WriteAllLines(sourceTRR, st1);

        }


        [When(@"Fetch TransID from database ""(.*)"" Add it to TRR File ""(.*)"" with new MBI ""(.*)"" value")]
        public void WhenFetchTransIDFromDatabaseAddItToTRRFileWithNewMBIValue(string p0, string p1, string p2)
        {
            string sourceTRR = "c:\\temp\\" + tmsCommon.GenerateData(p1);
            string runTimeMBI = tmsCommon.GenerateData(p2);

            List<string> sqllist = new List<string>();
            //sqllist = db.OutputDBResultsToList(p0);

            //string[] sqlarray = sqllist.ToArray();
            string transID;
            transID = db.OutputDBResultsToList(p0)[0].ToString();
            fw.ConsoleReport(" Trans ID which will be replaced in TRR File is " + transID);
            fw.ConsoleReport(" MBI which will be replaced in TRR File is " + runTimeMBI);


            string[] lines = System.IO.File.ReadAllLines(sourceTRR);
            string[] st1 = new string[lines.Length];

            for (int i = 0; i < lines.Length; i++)
            {

                StringBuilder st = new StringBuilder(lines[i]);

                st.Remove(485, 5);
                //Console.WriteLine($"Trans ID {sqlarray[i]} - {sqlarray[i].Length}");
                st.Insert(485, transID);

                st.Remove(0, 11);
                st.Insert(0, runTimeMBI);
                st1[i] = st.ToString();
                Console.WriteLine(st1[i]);


            }

            System.IO.File.WriteAllLines(sourceTRR, st1);
        }

        [When(@"Fetch TransID from database ""(.*)"" and Added to TRR File ""(.*)"" with new MBI ""(.*)"" value")]
        public void WhenFetchTransIDFromDatabaseAndAddedToTRRFileWithNewMBIValue(string p0, string p1, string p2)
        {
            string sourceTRR = "c:\\temp\\" + tmsCommon.GenerateData(p1);
            string runTimeMBI = tmsCommon.GenerateData(p2);

            List<string> sqllist = new List<string>();
            sqllist = db.OutputDBResultsToList(p0);

            string[] sqlarray = sqllist.ToArray();

            string[] lines = System.IO.File.ReadAllLines(sourceTRR);
            string[] st1 = new string[lines.Length];

            for (int i = 0; i < lines.Length; i++)
            {

                StringBuilder st = new StringBuilder(lines[i]);

                st.Remove(485, 5);
                //Console.WriteLine($"Trans ID {sqlarray[i]} - {sqlarray[i].Length}");
                st.Insert(485, sqlarray[i]);

                st.Remove(0, 11);
                st.Insert(0, runTimeMBI);
                st1[i] = st.ToString();
                Console.WriteLine(st1[i]);


            }

            System.IO.File.WriteAllLines(sourceTRR, st1);
        }

        [When(@"Fetch TransID from database ""(.*)"" and Added to TRR File Row ""(.*)""")]
        public void WhenFetchTransIDFromDatabaseAndAddedToTRRFileRow(string p0, string p1)
        {

            string sourceTRR = "c:\\temp\\" + tmsCommon.GenerateData(p1);

            List<string> sqllist = new List<string>();
            sqllist = db.OutputDBResultsToList(p0);

            string[] sqlarray = sqllist.ToArray();

            string[] lines = System.IO.File.ReadAllLines(sourceTRR);
            string[] st1 = new string[lines.Length];

            for (int i = 0; i < lines.Length; i++)
            {

                StringBuilder st = new StringBuilder(lines[i]);

                st.Remove(485, 5);
                Console.WriteLine($"{sqlarray[i]} - {sqlarray[i].Length}");
                st.Insert(485, sqlarray[i]);
                st1[i] = st.ToString();

                Console.WriteLine(st1[i]);


            }

            System.IO.File.WriteAllLines(sourceTRR, st1);
        }

        [When(@"Fetch TransID from database ""(.*)"" and Added in to TRR File Row ""(.*)""")]
        public void WhenFetchTransIDFromDatabaseAndAddedInToTRRFileRow(string p0, string p1)
        {
            string sourceTRR = "c:\\temp\\" + tmsCommon.GenerateData(p1);

            List<string> sqllist = new List<string>();
            sqllist = db.OutputDBResultsToList(p0);

            string[] sqlarray = sqllist.ToArray();

            string[] lines = System.IO.File.ReadAllLines(sourceTRR);
            string[] st1 = new string[lines.Length];

            for (int i = 0; i < lines.Length; i++)
            {
                if ((i == 0) || (i == 1))
                {
                    StringBuilder st = new StringBuilder(lines[i]);

                    st.Remove(485, 5);
                    //Console.WriteLine($"{sqlarray[i]} - {sqlarray[i].Length}");
                    st.Insert(485, sqlarray[0]); // inserting 0 th Trans ID
                    st1[i] = st.ToString();

                    Console.WriteLine(st1[i]);
                }
                if (i == 2)
                {
                    StringBuilder st = new StringBuilder(lines[i]);

                    st.Remove(485, 5);
                    // Console.WriteLine($"{sqlarray[i]} - {sqlarray[i].Length}");
                    st.Insert(485, sqlarray[1]);
                    st1[i] = st.ToString();

                    Console.WriteLine(st1[i]);
                }

                if (i == 3)
                {
                    StringBuilder st = new StringBuilder(lines[i]);

                    st.Remove(485, 5);
                    // Console.WriteLine($"{sqlarray[i]} - {sqlarray[i].Length}");
                    st.Insert(485, sqlarray[2]);
                    st1[i] = st.ToString();

                    Console.WriteLine(st1[i]);
                }


            }

            System.IO.File.WriteAllLines(sourceTRR, st1);
        }


        [When(@"Fetch Single TransID from database ""(.*)"" and Added to TRR File ""(.*)""")]
        public void WhenFetchSingleTransIDFromDatabaseAndAddedToTRRFile(string p0, string p1)
        {
            string sourceTRR = "c:\\temp\\" + tmsCommon.GenerateData(p1);
            string transID;
            //List<string> sqllist = new List<string>();
            transID = db.OutputDBResultsToList(p0)[0].ToString();

            //string[] sqlarray = sqllist.ToArray();

            string[] lines = System.IO.File.ReadAllLines(sourceTRR);
            string[] st1 = new string[lines.Length];

            for (int i = 0; i < lines.Length; i++)
            {

                StringBuilder st = new StringBuilder(lines[i]);

                st.Remove(485, 5);
                fw.ConsoleReport("Replacing Old Trans ID with new TransID" + transID);
                st.Insert(485, transID);
                st1[i] = st.ToString();

                Console.WriteLine(st1[i]);


            }

            System.IO.File.WriteAllLines(sourceTRR, st1);
        }


        [When(@"Fetch TransID from database ""(.*)"" and Added to TRR File ""(.*)""")]
        public void WhenFetchTransIDFromDatabaseAndAddedToTRRFile(string p0, string p1)
        {
            string sourceTRR = "c:\\temp\\" + tmsCommon.GenerateData(p1);

            List<string> sqllist = new List<string>();
            sqllist = db.OutputDBResultsToList(p0);

            string[] sqlarray = sqllist.ToArray();

            string[] lines = System.IO.File.ReadAllLines(sourceTRR);
            string[] st1 = new string[lines.Length];

            for (int i = 0; i < lines.Length; i++)
            {

                StringBuilder st = new StringBuilder(lines[i]);

                st.Remove(485, 5);
                //  Console.WriteLine($"{sqlarray[i]} - {sqlarray[i].Length}");
                st.Insert(485, sqlarray[i]);
                st1[i] = st.ToString();

                Console.WriteLine(st1[i]);


            }

            System.IO.File.WriteAllLines(sourceTRR, st1);
        }


        [When(@"I execute Update Query ""(.*)"" results to the output file")]
        public void WhenIExecuteUpdateQueryResultsToTheOutputFile(string p0)
        {
            db.ExecuteUpdateQuery(p0);
        }




        [Then(@"Verify output database ""(.*)"" has row containing below data")]
        public void ThenVerifyOutputDatabaseHasRowContainingBelowData(string p0, Table table)
        {
            db.VerifyDBResults(p0, table);
        }


        [Then(@"Verify output database ""(.*)"" has row")]
        public void ThenVerifyOutputDatabaseHasRow(string p0, Table table)
        {
            db.VerifyDBResultsToTable(p0, table);
        }

    }
    [Binding]
    public class EAMTransactionsViewEdit
    {
        [Then(@"set Transactions View/Edit First Name to ""(.*)""")]
        public void ThenSetTransactionsViewEditFirstNameTo(string p0)
        {
            EAM.TransactionsViewEdit.FirstName.SendKeys(p0);
        }

        [Then(@"click on Transactions View/Edit Search button")]
        public void ThenClickOnTransactionsViewEditSearchButton()
        {
            EAM.TransactionsViewEdit.SearchButton.Click();
        }
        [Then(@"Verify Transactions View Edit Disen Reason is set to ""(.*)""")]
        public void ThenVerifyTransactionsViewEditDisenReasonIsSetTo(string p0)
        {
            string fieldName = "Disen Reason";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.TransactionsViewEdit.DisenReason.GetAttribute("value");
            IList<IWebElement> thisOptionCollection = EAM.TransactionsViewEdit.DisenReason.FindElements(By.TagName("option"));  //Get the options
            foreach (IWebElement thisOption in thisOptionCollection) //Loop through them
            {
                if (thisOption.GetAttribute("value") == thisFieldValue)  //if this option has the same value we found above (4 lines) then.. See if the text is right
                {
                    thisFieldValue = thisOption.Text;
                    Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
                    fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
                }
            }
        }

        [Then(@"Transactions View/Edit Table has row\(s\)")]
        public void ThenTransactionsViewEditTableHasRowS(Table table)
        {
            //Establish the next page link for flipping pages as necessary
            string NextPageLinkText = "";
            Boolean bNotAtLastPageOfRecords = true;
            Boolean bHaveGoodPageLink = true;
            IWebElement NPL = null;
            //Get the Table Header off of the test script Gherkin table
            ICollection<string> thisTH = table.Header;
            int thCount = thisTH.Count;
            string[] thisHeader = new string[thisTH.Count];
            thisTH.CopyTo(thisHeader, 0);   //copies the header to an array

            //Set up an array of classes to hold the table data, first one (0) will be the header info
            //The class has flags for this data row being a header, data and if we have yet matched it in our trials
            TableRow[] thisTableArr = new TableRow[table.RowCount + 1];
            thisTableArr[0] = new TableRow();
            thisTableArr[0].RowIsHeader = true;
            thisTableArr[0].RowIsData = false;
            thisTableArr[0].RowIsMatched = false;
            //Add the header data to the array 0 table row instance
            foreach (string thisString in thisHeader)
            {
                thisTableArr[0].Row.Add(thisString);
            }
            int iCounter = 1;
            //Add the Gherkin table row data to the array of rows.  These are all data, not headers, not matched yet.
            foreach (var row in table.Rows)
            {
                thisTableArr[iCounter] = new TableRow();
                thisTableArr[iCounter].RowIsHeader = false;
                thisTableArr[iCounter].RowIsData = true;
                thisTableArr[iCounter].RowIsMatched = false;

                for (int c = 0; c < row.Count; c++)
                {
                    thisTableArr[iCounter].Row.Add(row[c]);
                }
                iCounter++;
            }
            //While we have not matched all rows yet
            //and we are not on the last page of records..
            while (thisTableArr[0].AllRowsMatched(thisTableArr) == false && bNotAtLastPageOfRecords)
            {
                bNotAtLastPageOfRecords = false;
                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.TransactionsViewEdit.TransactionsTable;
                //Get the spans data, this is the current page number.  Derive the next page number.
                ICollection<IWebElement> mySpans = baseTable.FindElements(By.TagName("span"));
                foreach (IWebElement thisSpan in mySpans)
                {
                    int CurrentPageNumber = Convert.ToInt16(thisSpan.Text);
                    int NextPageNumber = CurrentPageNumber + 1;
                    NextPageLinkText = NextPageNumber.ToString();
                }
                //Find the link for the next page.  (for later)
                try
                {
                    NPL = baseTable.FindElement(By.LinkText(NextPageLinkText));
                }
                catch
                {
                    bNotAtLastPageOfRecords = true;
                    bHaveGoodPageLink = false;
                }
                //Get rows out of the table on the page, from the table object
                ICollection<IWebElement> myRows = baseTable.FindElements(By.TagName("tr"));
                int RowCount = myRows.Count;
                //Establish an array of table rows for the page data.
                TableRow[] thisDataArr = new TableRow[RowCount];
                int EstablishedRowItemCount = 0;
                int iRowCounter = 0;
                foreach (IWebElement thisRow in myRows)
                {
                    //For each new data row we look at, add a new instance of the class to the array.
                    thisDataArr[iRowCounter] = new TableRow();
                    thisDataArr[iRowCounter].RowIsHeader = true;
                    thisDataArr[iRowCounter].RowIsData = false;
                    thisDataArr[iRowCounter].RowIsMatched = false;
                    //Get all of the elements from the row (<td>)
                    ICollection<IWebElement> myElements = thisRow.FindElements(By.TagName("td"));
                    //Row 0 is the header
                    //The rest of the rows are data
                    foreach (IWebElement thisElement in myElements)
                    {
                        if (iRowCounter == 0)
                        {
                            //Finding the normal item count because the page numbers are a data row.
                            //Row 0 is the header
                            EstablishedRowItemCount = myElements.Count;
                            thisDataArr[iRowCounter].RowIsHeader = true;
                            thisDataArr[iRowCounter].RowIsData = false;
                        }
                        else
                        {
                            //Other rows are data
                            thisDataArr[iRowCounter].RowIsHeader = false;
                            thisDataArr[iRowCounter].RowIsData = true;
                        }
                        if (myElements.Count == EstablishedRowItemCount)
                        {
                            //Only add data if we have a data row, not if we have a 0 length row.
                            thisDataArr[iRowCounter].Row.Add(thisElement.Text.ToString());
                        }
                        else
                        {
                            //If this row count isn't the right number of items, we didn't match with expected.
                            thisDataArr[iRowCounter].RowIsData = false;
                        }
                    }
                    iRowCounter++;
                }
                int iTableCounter = 0;
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TableRow TTA in thisTableArr)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.
                    if (TTA.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] ta = TTA.Row.ToArray();

                        //For each row in the page data
                        foreach (TableRow TDA in thisDataArr)
                        {
                            //Convert page data to array elements
                            string[] td = TDA.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.
                            foreach (string tde in td)
                            {
                                if (iElementCounter > 0 && TDA.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (tde != ta[iElementCounter - 1] && ta[iElementCounter - 1] != "[Skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (td.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same
                            if (bThisRowMatches)
                            {
                                //Report the match, first convert the array back to a string we can read.
                                thisTableArr[iTableCounter].RowIsMatched = true;
                                string TR0 = TableRow.ArrayToString(td);
                                string TR1 = TableRow.ArrayToString(ta);
                                Console.WriteLine("Expected Row Data - " + TR0);
                                Console.WriteLine("Found Row Data ------- " + TR1);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisTableArr[0].AllRowsMatched(thisTableArr);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        bNotAtLastPageOfRecords = true;
                        NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.TransactionsViewEdit.TransactionsTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (bHaveGoodPageLink == false && !fullMatching)
                {
                    int iCount = 0;
                    var TableRow = new TMSString();
                    foreach (TableRow thisTR in thisTableArr)
                    {
                        if (thisTR.RowIsMatched == false && thisTR.RowIsHeader == false)
                        {
                            string thisRowData = TableRow.ArrayToString(thisTR.Row.ToArray());
                            Console.WriteLine("Unmatched Data Row -- " + thisRowData);
                        }
                        iCount++;
                    }
                    Assert.AreEqual(true, false, "Not all expected rows in the Gherkin test table were found in the page table data rows.");
                }
            }
        }
        class TMSString
        {
            public string ArrayToString(string[] inArr)
            {
                string returnString = "";
                foreach (string thisString in inArr)
                {
                    returnString += " [" + thisString + "] ";
                }
                return returnString;
            }
        }
        class TableRow
        {
            public Boolean RowIsData;
            public Boolean RowIsHeader;
            public Boolean RowIsMatched;
            public List<string> Row = new List<string>();

            public Boolean AllRowsMatched(TableRow[] thisArr)
            {
                Boolean thisReturnValue = true;
                int Counter = 0;
                foreach (TableRow a in thisArr)
                {
                    if (a.RowIsMatched == false && Counter > 0)
                    {
                        thisReturnValue = false;
                    }
                    Counter++;
                }
                return thisReturnValue;
            }
        }


        [Then(@"Verify Transaction status ""(.*)""")]
        public void ThenVerifyTransactionStatus(string p0)
        {
            string tstatus = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtTStatus")).GetAttribute("value");
            Assert.AreEqual(p0, tstatus);

        }

        [Then(@"Verify Transaction effective date ""(.*)""")]
        public void ThenVerifyTransactionEffectiveDate(string p0)
        {
            string teffdate = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtEffDate_14")).GetAttribute("value");
            Assert.AreEqual(p0, teffdate);
        }

    }
}
