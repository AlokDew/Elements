﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
//using System.Windows.Forms;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;
using TMSoR1;
using TMSoR1.FrameworkCode;
using Keys = OpenQA.Selenium.Keys;

namespace Daron0004
{

    [Binding]
    public class EAM_Administration_Status_Override_Edit_Member_StatusSteps
    {
        public static string downloadedFilePath = System.IO.Path.Combine(Environment.ExpandEnvironmentVariables("%userprofile%"), "Downloads");
        public IList<IWebElement> EAMallRows;
        public IList<IWebElement> ERFallRows;

        public string setCheckboxTo;
        public bool nextPage = false;

        [When(@"Administration Status Override page New Member Status is set to ""(.*)""")]
        public void WhenAdministrationStatusOverridePageNewMemberStatusIsSetTo(string p0)
        {
            SelectElement status = new SelectElement(EAM.AdministrationStatusoverride.MemberStatus);

            status.SelectByText(p0);
        }




       

        [When(@"Administration Status Override page New Reply Date is set to ""(.*)""")]
        public void WhenAdministrationStatusOverridePageNewReplyDateIsSetTo(string p0)
        {
            string temp = tmsCommon.GenerateData(p0);
            GlobalRef.ReplyDate = temp;
            string TransStatusText = EAM.AdministrationStatusoverride.TransactionTable_TransStatus.Text;
            if (!TransStatusText.Equals("Accepted by CMS"))
            {
                temp = temp.Replace("/", "");
                IWebElement currentElement = Browser.Wd.SwitchTo().ActiveElement();
                currentElement.SendKeys(Keys.Tab);

                
                tmsWait.Hard(1);
                EAM.AdministrationStatusoverride.NewReplyDate.SendKeys(temp);
            }
        }

        [When(@"Administration Status Override page New Member ID is set to ""(.*)""")]
        public void WhenAdministrationStatusOverridePageNewMemberIDIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.AdministrationStatusoverride.NewMemberID.SendKeys(GeneratedData);
        }

        [When(@"Administration Status Override page Transaction Type New RxID is set to ""(.*)""")]
        public void WhenAdministrationStatusOverridePageTransactionTypeNewRxIDIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.AdministrationStatusoverride.NewTxnRXID.Clear();
            EAM.AdministrationStatusoverride.NewTxnRXID.SendKeys(GeneratedData);
        }

        [When(@"Administration Status Override page New RxID is set to ""(.*)""")]
        public void WhenAdministrationStatusOverridePageNewRxIDIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.AdministrationStatusoverride.NewRXID.Clear();
            EAM.AdministrationStatusoverride.NewRXID.SendKeys(GeneratedData);

        }
        [Then(@"Verify View Edit Member page Contact Tab ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageContactTabIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string expValue = tmsCommon.GenerateData(p1);
            IWebElement actValue;

            switch (field)
            {
                case "SCC":
                    actValue = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtScc"));
                    TMSoR1.FrameworkCode.ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expValue, actValue);
                    break;
                case "County":
                    actValue = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_ddlCounty"));
                    TMSoR1.FrameworkCode.ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expValue, actValue);
                    break;

                case "City":
                    actValue = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtPCity"));
                    TMSoR1.FrameworkCode.ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expValue, actValue);
                    break;
                case "State":
                    actValue = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberAddr_txtPState"));
                    TMSoR1.FrameworkCode.ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expValue, actValue);
                    break;

            }

        }


        [Then(@"Verify Spans tab displayed message as ""(.*)""")]
        public void ThenVerifySpansTabDisplayedMessageAs(string expectedValue)
        {
            tmsWait.Hard(3);
            IWebElement element = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucMemberSpans_lblMessage"));
            string actualValue = element.Text;
            Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");
        }


        [Then(@"Verify View Edit Member Page ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string expValue = tmsCommon.GenerateData(p1);
            IWebElement actValue;

            switch (field)
            {
                case "SCC":
                    actValue = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_scc_id"));
                    TMSoR1.FrameworkCode.ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expValue, actValue);
                    break;
                case "County":
                    actValue = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtCountyName_44"));
                    TMSoR1.FrameworkCode.ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expValue, actValue);
                    break;

            }
        }


        [When(@"Administration Status Override page New Effective Date is set to ""(.*)""")]
        public void WhenAdministrationStatusOverridePageNewEffectiveDateIsSetTo(string p0)
        {
            if (p0.Equals("Greater Than CCM"))
            {
                tmsWait.Hard(2);
                string GeneratedData = tmsCommon.GenerateData(p0);
                GeneratedData = GeneratedData.Replace("/", "");
                EAM.AdministrationStatusoverride.NewEffectiveDate.Clear();

                GeneratedData = DateTime.Today.AddMonths(-3).ToString("MM01yyyy");
                EAM.AdministrationStatusoverride.NewEffectiveDate.SendKeys(GeneratedData);
            }

            else if (p0.Equals("Future Effective Date"))
            {
                tmsWait.Hard(2);
                string GeneratedData = tmsCommon.GenerateData(p0);
                GeneratedData = GeneratedData.Replace("/", "");
                EAM.AdministrationStatusoverride.NewEffectiveDate.Clear();

                GeneratedData = DateTime.Today.AddMonths(1).ToString("MM01yyyy");
                EAM.AdministrationStatusoverride.NewEffectiveDate.SendKeys(GeneratedData);
            }
            else if (p0.Equals("Current Month"))
            {
                tmsWait.Hard(2);
                EAM.AdministrationStatusoverride.NewEffectiveDate.Clear();
                string GeneratedData = DateTime.Today.ToString("MM01yyyy");
                EAM.AdministrationStatusoverride.NewEffectiveDate.SendKeys(GeneratedData);
            }

            else
            {
                tmsWait.Hard(2);
                string GeneratedData = tmsCommon.GenerateData(p0);
                fw.ExecuteJavascriptSetText(EAM.AdministrationStatusoverride.NewEffectiveDate, GeneratedData);
                tmsWait.Hard(2);
                EAM.AdministrationStatusoverride.NewEffectiveDate.SendKeys(OpenQA.Selenium.Keys.Tab);
                //tmsWait.Hard(2);
                //string GeneratedData = tmsCommon.GenerateData(p0);
                //GeneratedData = GeneratedData.Replace("/", "");
                //EAM.AdministrationStatusoverride.NewEffectiveDate.Clear();
                //tmsWait.Hard(1);
                //EAM.AdministrationStatusoverride.NewEffectiveDate.SendKeys(GeneratedData);
            }

        }


        [When(@"Administration Status Override page New Reply code is set to ""(.*)""")]
        public void WhenAdministrationStatusOverridePageNewReplyCodeIsSetTo(String p0)
        {
            string TransStatusText = EAM.AdministrationStatusoverride.TransactionTable_TransStatus.Text;
            if (TransStatusText != "Accepted by CMS")
            {
                tmsWait.Hard(5);
                string GeneratedData = tmsCommon.GenerateData(p0);
                EAM.AdministrationStatusoverride.NewReplyCode.Clear();
                EAM.AdministrationStatusoverride.NewReplyCode.SendKeys(GeneratedData);
            }
        }

        [When(@"Administration Status Override page New Trans Status is set to ""(.*)""")]
        public void WhenAdministrationStatusOverridePageNewTransStatusIsSetTo(string p0)
        {
            SelectElement status = new SelectElement(EAM.AdministrationStatusoverride.NewTransactionStatus);

            status.SelectByText(p0);
        }


        [When(@"Administration Status Override page New PBP ID is set to ""(.*)""")]
        public void WhenAdministrationStatusOverridePageNewPBPIDIsSetTo(string p0)
        {
            SelectElement status = new SelectElement(EAM.AdministrationStatusoverride.NewPBPID);

            status.SelectByText(p0);
        }
        [When(@"Administration Status Override page New Plan ID is set to ""(.*)""")]
        public void WhenAdministrationStatusOverridePageNewPlanIDIsSetTo(string p0)
        {
            SelectElement status = new SelectElement(EAM.AdministrationStatusoverride.NewPlanID);

            status.SelectByText(p0);
        }

        [When(@"Administration Status Override page Edit Member Save Button is Clicked")]
        [Then(@"Administration Status Override page Edit Member Save Button is Clicked")]
        public void WhenAdministrationStatusOverridePageEditMemberSaveButtonIsClicked()
        {
            EAM.AdministrationStatusoverride.MemberSaveButton.Click();
        }
        [When(@"Administration Status Override page Edit Transaction Save Button is Clicked")]
        public void WhenAdministrationStatusOverridePageEditTransactionSaveButtonIsClicked()
        {
            string TransStatusText = EAM.AdministrationStatusoverride.TransactionTable_TransStatus.Text;
            if (TransStatusText != "Accepted by CMS")
            {
                EAM.AdministrationStatusoverride.TransSaveButton.Click();
                tmsWait.Hard(2);
                Browser.ClosePopUps(true);
            }
        }
        [When(@"Administration Status Override page Edit Transaction Save Button is Clicked for above transaction")]
        [Then(@"Administration Status Override page Edit Transaction Save Button is Clicked for above transaction")]
        public void WhenAdministrationStatusOverridePageEditTransactionSaveButtonIsClickedForAboveTransaction()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSave")));
            tmsWait.Hard(2);
            try
            {
                Browser.ClosePopUps(true);
                tmsWait.Hard(1);
            }
            catch
            {
                Console.WriteLine("No Alert is present now");

            }

        }

        [When(@"Retro Contractor File Export page Plan ID is set to ""(.*)""")]
        public void WhenRetroContractorFileExportPagePlanIDIsSetTo(string p0)
        {
            SelectElement planid = new SelectElement(EAM.CreateRetroFile.PlanIDDropdownlist);
            planid.SelectByText(p0);
        }


        [When(@"Retro Contractor File Export page Export button is Clicked")]
        [Then(@"Retro Contractor File Export page Export button is Clicked")]
        public void WhenRetroContractorFileExportPageExportButtonIsClicked()
        {
            EAM.CreateRetroFile.Exportbutton.Click();
        }
        [Then(@"I click on Create Retro File Export Button")]
        public void ThenIClickOnCreateRetroFileExportButton()
        {
            EAM.CreateRetroFile.Exportbutton.Click();
        }


        [Then(@"I click on Create Retro File Mark as Sent Button for file ""(.*)""")]
        public void ThenIClickOnCreateCMSFileMarkAsSentButtonForFile(string p0)
        {
            Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dgRaps_ctl03_chk")).Click();
            tmsWait.Hard(3);
        }

        [Then(@"Verify Retro Table Send Checkbox Disabled")]
        public void ThenVerifyRetroTableSendCheckboxDisabled()
        {
            tmsWait.Hard(2);
            IWebElement sendCheck = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dgRaps_ctl03_chk"));
            Assert.AreEqual(sendCheck.Selected, false);
        }

        [Given(@"Create Retro File Sent CMSDate is set to ""(.*)""")]
        [Then(@"Create Retro File Sent CMSDate is set to ""(.*)""")]
        [When(@"Create Retro File Sent CMSDate is set to ""(.*)""")]
        public void ThenCreateRetroFileSentCMSDateIsSetTo(String p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string ExpectedData = GeneratedData;

            GeneratedData = GeneratedData.Replace("/", "");
            for (int i = 0; i < 5; i++)
            {
                EAM.CreateRetroFile.RetroContractorFileDate.SendKeys(GeneratedData);
                tmsWait.Hard(1);
                string thisValue = EAM.CreateRetroFile.RetroContractorFileDate.GetAttribute("value");
                tmsWait.Hard(1);
                if (thisValue == ExpectedData)
                {
                    break;
                }
                else
                {
                    EAM.CreateRetroFile.RetroContractorFileDate.Clear();
                    tmsWait.Hard(1);
                }
            }


        }

        [Given(@"Retro Table with ""(.*)"" Send Checkbox Enable")]
        [Then(@"Retro Table with ""(.*)"" Send Checkbox Enable")]
        [When(@"Retro Table with ""(.*)"" Send Checkbox Enable")]
        public void ThenRetroTableWithSendCheckboxEnable(string p0)
        {
            Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dgRaps_ctl03_chk")).Click();
        }

        [Then(@"I click on Create CMS File Mark as Sent Button")]
        public void ThenIClickOnCreateCMSFileMarkAsSentButton()
        {
            EAM.CreateRetroFile.RetroMarkAsSentBtn.Click();
        }


        [Then(@"I click on Create Retro File Refresh Button")]
        public void ThenIClickOnCreateRetroFileRefreshButton()
        {
            EAM.CreateRetroFile.RetroFileRefreshBtn.Click();
            tmsWait.Hard(2);
        }

        [Then(@"Retro Table with ""(.*)"" Send Checkbox is deselected")]
        public void ThenRetroTableWithSendCheckboxIsDeselected(string p0)
        {
            
            tmsWait.Hard(2);
            IWebElement sendCheck = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dgRaps_ctl03_chk"));
            Assert.AreEqual(sendCheck.Selected, false);
        }



        [Then(@"Verify Members View Edit Page New Plan ID is set to ""(.*)""")]
        public void ThenVerifyMembersViewEditPageNewPlanIDIsSetTo(string p0)
        {
            string fieldName = "Plan ID";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MemberInformation.MemberInfoPlanID.GetAttribute("value");
            IList<IWebElement> thisOptionCollection = EAM.MemberInformation.MemberInfoPlanID.FindElements(By.TagName("option"));  //Get the options
            foreach (IWebElement thisOption in thisOptionCollection) //Loop through them
            {
                if (thisOption.GetAttribute("value") == thisFieldValue)  //if this option has the same value we found above (4 lines) then.. See if the text is right
                {
                    thisFieldValue = thisOption.Text;
                    Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
                    fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
                }
            }
        }


        [Then(@"Verify Members View Edit Page New RxID is set to ""(.*)""")]
        public void ThenVerifyMembersViewEditPageNewRxIDIsSetTo(string p0)
        {

            string fieldName = "RX ID";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MemberInformation.MemberInfoRXID.GetAttribute("value");
            IList<IWebElement> thisOptionCollection = EAM.MemberInformation.MemberInfoRXID.FindElements(By.TagName("option"));  //Get the options
            foreach (IWebElement thisOption in thisOptionCollection) //Loop through them
            {
                if (thisOption.GetAttribute("value") == thisFieldValue)  //if this option has the same value we found above (4 lines) then.. See if the text is right
                {
                    thisFieldValue = thisOption.Text;
                    Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
                    fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
                }
            }
        }


        [Then(@"Verify Members View Edit Page New PBP ID is set to ""(.*)""")]
        public void ThenVerifyMembersViewEditPageNewPBPIDIsSetTo(string p0)
        {
            string fieldName = "PBP ID";
            string PBPID = p0.ToString();
            string GeneratedData = tmsCommon.GenerateData(PBPID);
            string thisFieldValue = EAM.MemberInformation.MemberInfoPBPID.GetAttribute("value");
            IList<IWebElement> thisOptionCollection = EAM.MemberInformation.MemberInfoPBPID.FindElements(By.TagName("option"));  //Get the options
            foreach (IWebElement thisOption in thisOptionCollection) //Loop through them
            {
                if (thisOption.GetAttribute("value") == thisFieldValue)  //if this option has the same value we found above (4 lines) then.. See if the text is right
                {
                    thisFieldValue = thisOption.Text;
                    Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
                    fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
                }
            }

        }

        [Then(@"verify Letter Queue page displays HIC Number as ""(.*)""")]
        public void ThenVerifyLetterQueuePageDisplaysHICNumberAs(string p0)
        {
            string inputhic = tmsCommon.GenerateData(p0).ToUpper();
            tmsWait.Hard(5);
            IWebElement hic = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_dgLetters']//td[contains(.,'" + inputhic + "')]"));
            Assert.IsTrue(hic.Displayed, "Expected HIC is not getting displayed");
        }

        [Then(@"Verify View Edit Member page Correspondence tab displays Letter name as ""(.*)""")]
        public void ThenVerifyViewEditMemberPageCorrespondenceTabDisplaysLetterNameAs(string p0)
        {
            string inputhic = tmsCommon.GenerateData(p0);
            tmsWait.Hard(5);
            IWebElement hic = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_ucCorrespondence_gvCORR']//td[contains(.,'" + inputhic + "')]"));
            Assert.IsTrue(hic.Displayed, "Expected HIC is not getting displayed");
        }


        [Then(@"Letter Queue page Generate Letters button is Clicked")]
        public void ThenLetterQueuePageGenerateLettersButtonIsClicked()
        {
            tmsWait.Hard(2);
            IWebElement button = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnGenerateLetters"));
            button.Click();
            tmsWait.Hard(10);
        }

        [Then(@"Letter Queue page Deselect All button is Clicked")]
        public void ThenLetterQueuePageDeselectAllButtonIsClicked()
        {
            IWebElement button = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lnkDeSelectAll"));
            button.Click();
            tmsWait.Hard(4);
        }

        [Then(@"Letter Queue page ""(.*)"" Send Checkbox is Clicked")]
        public void ThenLetterQueuePageSendCheckboxIsClicked(string p0)
        {
            tmsWait.Hard(2);
            string hic = tmsCommon.GenerateData(p0).ToUpper();
            IWebElement button = Browser.Wd.FindElement(By.XPath("(//table[@id='ctl00_ctl00_MainMasterContent_MainContent_dgLetters']//td[contains(.,'" + hic + "')]/following-sibling::td/input)[1]"));
            button.Click();
            tmsWait.Hard(2);

        }


        [When(@"Letter Queue Page Go button is clicked")]
        [Then(@"Letter Queue Page Go button is clicked")]
        public void ThenLetterQueuePageGoButtonIsClicked()
        {
            tmsWait.Hard(2);
            EAM.Letters.GoButton.Click();

            tmsWait.Hard(3);
        }
        [Then(@"Verify Letter Queue displays ""(.*)""")]
        public void ThenVerifyLetterQueueDisplays(string p0)
        {
            tmsWait.Hard(3);
            string value = tmsCommon.GenerateData(p0);
            By loc = By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_dgLetters']//tr[contains(.,'" + value + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }


        [Then(@"Verify Letters Queue Page has ""(.*)"" HIC ""(.*)""")]
        public void ThenVerifyLettersQueuePageHasHIC(string status, string p0)
        {
            string hic = tmsCommon.GenerateData(p0.ToString());
            bool flag = false;
            int countOfRows = Browser.Wd.FindElements(By.XPath("//*[@id='ctl00_ctl00_MainMasterContent_MainContent_dgLetters']/tbody/*/td[3]")).Count;
            for (int index = 3; index < countOfRows + 1; index++)
            {
                if (Browser.Wd.FindElement(By.XPath(".//*[@id='ctl00_ctl00_MainMasterContent_MainContent_dgLetters']/tbody/tr[" + index + "]/td[3]")).Equals(hic))
                {
                    flag = true;
                    break;
                }
            }
            if (status.ToLower().Equals("displayed"))
            {
                Assert.IsTrue(flag, "Letter Queue page has displayed hic" + hic);
            }
            else
            {
                Assert.IsFalse(flag, "Letter Queue page has displayed hic" + hic);
            }
        }



        [Then(@"Letter Queue Page Deselect All buton is clicked")]
        public void ThenLetterQueuePageDeselectAllButonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(EAM.Letters.DeSelectAll);
        }

        [Then(@"Letter Queue Page Select Checkbox is checked for HIC ""(.*)""")]
        public void ThenLetterQueuePageSelectCheckboxIsCheckedForHIC(string p0)
        {
            tmsWait.Hard(3);
            int count = 1;
            string hic = tmsCommon.GenerateData(p0);
            nextPage = CheckHICOnLetterQueue(hic);
            if (!nextPage)
            {
                do
                {
                    count++;
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@text='" + count + "']")));
                } while (!nextPage);
            }
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + hic + "')]/parent::tr/td/input[contains(@id,'ctl00_ctl00_MainMasterContent_MainContent_dgLetters')]")));
        }

        public bool CheckHICOnLetterQueue(string hic)
        {
            try
            {
                if (Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + hic + "')]")).Displayed)
                {
                    return true;
                }
            } catch (Exception ex)
            {
                return false;
            }
            return false;
        }

        [Then(@"Letter Queue Page select All buton is clicked")]
        public void ThenLetterQueuePageselectAllButonIsClicked()
        {
            tmsWait.Hard(2);
            EAM.Letters.SelectAll.Click();
        }

        [Then(@"Letter Queue Acknowledgment of Disenrollment Letter page Plan ID is set to ""(.*)""")]
        public void ThenLetterQueueAcknowledgmentOfDisenrollmentLetterPagePlanIDIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            SelectElement planid = new SelectElement(EAM.Letters.PlanID);

            planid.SelectByText(p0);
        }

        [Then(@"Letter Queue Acknowledgment of Disenrollment Letter page PBP ID is set to ""(.*)""")]
        public void ThenLetterQueueAcknowledgmentOfDisenrollmentLetterPagePBPIDIsSetTo(int p0)
        {
         
        }
        [When(@"Letter Queue Page Plan ID is set to ""(.*)""")]
        [Then(@"Letter Queue Page Plan ID is set to ""(.*)""")]
        public void ThenLetterQueuePagePlanIDIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            string PlanID = tmsCommon.GenerateData(p0);
            SelectElement planid = new SelectElement(EAM.Letters.PlanID);

            planid.SelectByText(PlanID);
        }

        [Then(@"Letter Queue Page SortBy is set to ""(.*)""")]
        public void ThenLetterQueuePageSortByIsSetTo(string p0)
        {
            tmsWait.Hard(1);

            SelectElement sortby = new SelectElement(EAM.Letters.SortBy);

            sortby.SelectByText(p0);
        }

        [Then(@"Verify Letter page Title ""(.*)"" is displayed")]
        public void ThenVerifyLetterPageTitleIsDisplayed(string expected_lettername)
        {
            tmsWait.Hard(2);
            string actual_lettername = Browser.Wd.FindElement(By.XPath("//span[@id='pageName']")).Text;
            Assert.AreEqual(expected_lettername, actual_lettername, "Letter Title displayed incorrectly or missing");
            tmsWait.Hard(2);
        }

        [When(@"Verify Letters Page Title ""(.*)"" is displayed")]
        [Then(@"Verify Letters Page Title ""(.*)"" is displayed")]
        public void ThenVerifyLettersPageTitleIsDisplayed(string expected_lettername)
        {
            tmsWait.Hard(2);
            bool actual_lettername = Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + expected_lettername + "')]")).Displayed;
            Assert.IsTrue(actual_lettername, "Letter Title displayed incorrectly or missing");

            tmsWait.Hard(2);
        }

        [Then(@"Letter Queue Page Letter Name is set to ""(.*)""")]
        [When(@"Letter Queue Page Letter Name is set to ""(.*)""")]
        [Given(@"Letter Queue Page Letter Name is set to ""(.*)""")]
        public void ThenLetterQueuePageLetterNameIsSetTo(string p0)
        {
            SelectElement lettername = new SelectElement(EAM.Letters.LetterName);

            lettername.SelectByText(p0);
        }


        [Then(@"Letter Queue Page Values is set to ""(.*)""")]
        public void ThenLetterQueuePageValuesIsSetTo(string p0)
        {

            tmsWait.Hard(3);
            SelectElement values = new SelectElement(EAM.Letters.Values);

            values.SelectByText(p0);
        }
        [When(@"Letter Queue Page PBP ID is set to ""(.*)""")]
        [Then(@"Letter Queue Page PBP ID is set to ""(.*)""")]
        public void ThenLetterQueuePagePBPIDIsSetTo(string p0)
        {
            tmsWait.Hard(4);
            string Pbp = tmsCommon.GenerateData(p0);
            Pbp = Pbp.Substring(0, 3);
            SelectElement PBP = new SelectElement(EAM.Letters.PBP);

            PBP.SelectByText(Pbp);
        }
        [When(@"Letter Queue page Letter Name Drop down ""(.*)"" is Selected")]
        [Given(@"Letter Queue page Letter Name Drop down ""(.*)"" is Selected")]
        public void WhenLetterQueuePageLetterNameDropDownIsSelected(string TemplateName)
        {
            TemplateName = tmsCommon.GenerateData(TemplateName);
            SelectElement LetterName = new SelectElement(EAM.LettersTemplate.LetterQueuepageLetterName);
            LetterName.SelectByText(TemplateName);
            tmsWait.Hard(1);
        }

        [Then(@"Letter Queue Page Language is set to ""(.*)""")]
        public void ThenLetterQueuePageLanguageIsSetTo(string p0)
        {
            tmsWait.Implicit(2);
            SelectElement language = new SelectElement(EAM.Letters.Language);

            language.SelectByText(p0);

        }

        [Then(@"Verify Confirmation of Enrollment in Another Plan Letter Window has data")]
        public void ThenVerifyConfirmationOfEnrollmentInAnotherPlanLetterWindowHasData(Table table)
        {
            By reportViewBy = EAM.Reports.ReportMainViewBy;
            string reportExpText = "Confirmation of Enrollment in Another Plan Letter";
            string reportHandle = "";

            reportHandle = ReportsCommon.SwitchToReportWindow(reportViewBy, 30, reportExpText);

            if (reportHandle == "")
            {
                Assert.Fail("Confirmation of Enrollment in Another Plan Letter was not opened");
            }

            try
            {
                ReportsCommon.VerifyReportHasData(reportViewBy, reportExpText, table);
            }
            catch (Exception e)
            {
                Browser.Wd.SwitchTo().Window(reportHandle).Close();
                Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle).Close();
                Assert.Fail("Verify Confirmation of Enrollment in Another Plan Letter has data. Exception: {0}", e.Message);
            }

            Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle);
        }
        string currentHandle = null;
        [Then(@"Enrollment Letter page Generate Letters button is clicked")]
        public void ThenEnrollmentLetterPageGenerateLettersButtonIsClicked()
        {

            ReadOnlyCollection<string> windowHandles = Browser.Wd.WindowHandles;
            string childWindow = null;

            foreach (string handle in windowHandles)
            {
                if (handle != currentHandle)
                {
                    childWindow = handle;
                    Browser.Wd.SwitchTo().Window(childWindow);
                    Browser.Wd.FindElement(By.Id("btnSubmitJob")).Click();
                    IAlert alert = Browser.Wd.SwitchTo().Alert();
                    alert.Accept();

                }
            }



        }


        [When(@"Letters Queue Page Preview button is clicked")]
        [Then(@"Letters Queue Page Preview button is clicked")]
        public void ThenLettersQueuePagePreviewButtonIsClicked()
        {
            currentHandle = Browser.Wd.CurrentWindowHandle;
            try
            {
                // EAM.Letters.PreviewButton.Click();
                tmsWait.Hard(10);
            }
            catch
            { }
            //Browser.Wd.FindElement(By.Id("btnSubmitJob")).Click();
        }

        [Then(@"Letters Queue Page Generate Letter button is clicked")]
        public void ThenLettersQueuePageGenerateLetterButtonIsClicked()
        {
            EAM.Letters.GenerateLetterButton.Click();
            if (tmsWait.IsAlertPresent())
            {
                Browser.Wd.SwitchTo().Alert().Accept();
            }
        }

        [Then(@"Enrollment Letter window Generate button is clicked")]
        public void ThenEnrollmentLetterWindowGenerateButtonIsClicked()
        {
            EAM.Letters.GenerateButton.Click();
        }

        [Then(@"Correspondence tab for the member for just Sent Letter has row")]
        public void ThenCorrespondenceTabForTheMemberForJustSentLetterHasRow(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.MemberInformation.CorrespondanceTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Members View Edit Table has row: {0}", e.Message);
            }
        }


        [Then(@"Verify EENRL Letter window PDF Frame has row")]
        public void ThenVerifyEENRLLetterWindowPDFFrameHasRow(Table table)
        {
            tmsWait.Hard(5);

            // It deals with Firefox Browsers

            if (ConfigFile.BrowserType.ToLower().Equals("ff"))
            {
                string titleWin = "E*ENRL Letter";
                string expectedText = "HIC";
                string reportText = "";

                //Add ids of all the opened window on screen.These ids will be set to specific windows which are opened in order.
                List<string> w = new List<string>(Browser.Wd.WindowHandles);
                By reportViewBy = EAM.Reports.enrollmentLetterPDF;

                // Set window id and switch to any window
                for (int i = 0; i < w.Count; i++)
                {
                    if (Browser.Wd.SwitchTo().Window(w[i]).Title.Equals(titleWin))
                    {
                        // Switcing to Frame
                        Browser.Wd.SwitchTo().Window(w[i]).SwitchTo().Frame("PDFFrame");

                        reportText = Browser.Wd.SwitchTo().Window(w[i]).SwitchTo().Frame("PDFFrame").FindElement(reportViewBy).Text;
                        Assert.IsTrue(reportText.Contains(expectedText), "Report was not opened");
                        fw.ConsoleReport("Report was opened");

                    }
                }


                try
                {
                    ReportsCommon.VerifyPDFReportHasData(table);

                }
                catch
                {

                }

            }

            // It deals with IE Browsers
            else if (ConfigFile.BrowserType.ToLower().Equals("ie"))
            {

                string TMSMainPage = "";
                string titleWin = "E*ENRL Letter";
                //Add ids of all the opened window on screen.These ids will be set to specific windows which are opened in order.
                List<string> w = new List<string>(Browser.Wd.WindowHandles);
                By reportViewBy = EAM.Reports.enrollmentLetterPDF;

                // Set window id and switch to any window
                for (int i = 0; i < w.Count; i++)
                {
                    if (Browser.Wd.SwitchTo().Window(w[i]).Title.Equals(titleWin))
                    {

                        string currentURL = Browser.Wd.Url;
                        tmsWait.Hard(1);
                        Browser.Wd.SwitchTo().Window(w[i]).Close();

                        tmsWait.Hard(2);
                        List<string> w1 = new List<string>(Browser.Wd.WindowHandles);
                        for (int j = 0; j < w.Count; j++)
                        {
                            tmsWait.Hard(2);
                            if (Browser.Wd.SwitchTo().Window(w[j]).Title.Equals("Letter Queues"))
                            {
                                Browser.Wd.SwitchTo().Window(w[j]);
                                TMSMainPage = Browser.Wd.Url;

                                Browser.Wd.SwitchTo().Window(w[j]).Navigate().GoToUrl(currentURL);
                                tmsWait.Hard(5);
                                //SendKeys.SendWait("{TAB}");
                                //tmsWait.Hard(1);
                                //SendKeys.SendWait("{TAB}");
                                //tmsWait.Hard(1);
                                //SendKeys.SendWait("{TAB}");
                                //tmsWait.Hard(1);
                                //SendKeys.SendWait("{TAB}");
                                //tmsWait.Hard(1);
                                //SendKeys.SendWait("{TAB}");
                                //tmsWait.Hard(1);
                                //SendKeys.SendWait("{TAB}");
                                //tmsWait.Hard(1);
                                //SendKeys.SendWait("{TAB}");
                                //tmsWait.Hard(1);
                                //SendKeys.SendWait("{TAB}");
                                //tmsWait.Hard(1);
                                //SendKeys.SendWait("{TAB}");
                                //tmsWait.Hard(1);
                                //SendKeys.SendWait("{TAB}");
                                //tmsWait.Hard(2);
                                //SendKeys.SendWait("^{a}");

                                //tmsWait.Hard(2);
                                //SendKeys.SendWait("^{c}");
                                //tmsWait.Hard(2);
                                //var buf = Clipboard.GetDataObject();
                                //Boolean cbdText = Clipboard.ContainsData(TextDataFormat.Text.ToString());

                                //using (FileStream fs = new FileStream("C:\\tms\\TextArea.html", FileMode.Create))
                                //{
                                //    using (StreamWriter sw = new StreamWriter(fs, Encoding.UTF8))
                                //    {

                                //        sw.WriteLine("<html lang=\"en - us\" >");
                                //        sw.WriteLine("<textarea id=\"TMSTextArea\" rows=\"75\" cols=\"125\">");
                                //        sw.WriteLine("</textarea>");
                                //        sw.WriteLine("</html>");
                                //    }
                                //}

                                Browser.Wd.SwitchTo().Window(w[j]).Navigate().GoToUrl("c:\\tms\\TextArea.html");
                                tmsWait.Hard(2);
                                IWebElement thisTB = Browser.Wd.FindElement(By.TagName("textarea"));
                                thisTB.Clear();
                                tmsWait.Hard(2);
                                //SendKeys.SendWait("^{v}");
                                tmsWait.Hard(1);

                                break; // Exit from first for loop
                            }
                        }
                        break; //  exit from second for loop                                          


                    }
                }


                try
                {
                    ReportsCommon.VerifyHTMLReportHasData(table);

                }
                catch
                {

                }

                tmsWait.Hard(2);
                Browser.Wd.Navigate().GoToUrl(TMSMainPage);  // Navigate to TMS Main page

            }

        }


        [When(@"Create HTML File")]
        public void WhenCreateHTMLFile()
        {
            using (FileStream fs = new FileStream("C:\\tms\\TextArea1.html", FileMode.Create))
            {
                using (StreamWriter w = new StreamWriter(fs, Encoding.UTF8))
                {

                    w.WriteLine("<html lang=\"en - us\" >");
                    w.WriteLine("<textarea id=\"TMSTextArea\" rows=\"75\" cols=\"125\">");
                    w.WriteLine("</textarea>");
                    w.WriteLine("</html>");
                }
            }



        }



        [When(@"Administration Status Override page HIC is set to ""(.*)""")]
        public void WhenAdministrationStatusOverridePageHICIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            EAM.AdministrationStatusoverride.SearchForHIC.Clear();
            EAM.AdministrationStatusoverride.SearchForHIC.SendKeys(value);
        }

        [Then(@"Letter Templates page Letters Drop down ""(.*)"" is Selected")]
        [When(@"Letter Templates page Letters Drop down ""(.*)"" is Selected")]
        [Given(@"Letter Templates page Letters Drop down ""(.*)"" is Selected")]
        public void WhenLetterTemplatesPageLettersDropDownIsSelected(string p0)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='letterTemplate-select-letter']//span[@class='k-select']");

                By typeapp = By.XPath("//li[text()='" + p0 + "']");

                //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                //tmsWait.Hard(3);
                //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            }
            else
            {
                IWebElement drp = Browser.Wd.FindElement(By.CssSelector("[aria-owns='drpLetter_listbox']"));
                UIMODUtilFunctions.selectDropDownValueFromGendoUI(drp, p0);
            }
            tmsWait.Hard(2);
            //SelectElement planid = new SelectElement(EAM.LettersTemplate.LettersDropdown);
            //planid.SelectByText(p0);
            //if (p0 == "On Demand Letter")
            //{
            //    try
            //    {
            //        tmsWait.Hard(2);
            //        SelectElement LetterPick = new SelectElement(EAM.LettersTemplate.LetterNameDropdown);
            //        LetterPick.SelectByText("OnDemand_Test_1");
            //    }
            //    catch { }
            //}

        }
        [When(@"Letter Templates page Letters Drop down ""(.*)"" is Selected and templatename is selected as ""(.*)""")]
        public void WhenLetterTemplatesPageLettersDropDownIsSelectedAndTemplatenameIsSelectedAs(string p0, string TemplateName)
        {
            tmsWait.Hard(1);
            SelectElement LetterName = new SelectElement(EAM.LettersTemplate.LettersDropdown);
            TemplateName = tmsCommon.GenerateData(TemplateName);
            LetterName.SelectByText(p0);
            try
            {
                tmsWait.Hard(2);
                SelectElement LetterPick = new SelectElement(EAM.LettersTemplate.AddLetterTempdialogLetterNamedropdown);
                LetterPick.SelectByText(TemplateName);
            }
            catch { }
        }

        [When(@"Letter Templates page Letter Name Drop down ""(.*)"" is Selected")]
        public void WhenLetterTemplatesPageLetterNameDropDownIsSelected(string p0)
        {
            string LetterName = tmsCommon.GenerateData(p0);
            tmsWait.Hard(1);
            SelectElement planid = new SelectElement(EAM.LettersTemplate.LetterNameDropdown);

            planid.SelectByText(LetterName);

        }

        [When(@"Letter Templates page Language Drop down ""(.*)"" is Selected")]
        public void WhenLetterTemplatesPageLanguageDropDownIsSelected(string p0)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='letterTemplate-select-language']//span[@class='k-select']");

                By typeapp = By.XPath("//li[text()='" + p0 + "']");

                //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                //tmsWait.Hard(3);
                //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

            }
            else
            {
                IWebElement drp = Browser.Wd.FindElement(By.CssSelector("[aria-owns='drplanguage_listbox']"));
                UIMODUtilFunctions.selectDropDownValueFromGendoUI(drp, p0);
            }
            tmsWait.Hard(2);
            //tmsWait.Hard(1);
            //SelectElement planid = new SelectElement(EAM.LettersTemplate.LanguageDropdown);
            //string gd = tmsCommon.GenerateData(p0);

            //planid.SelectByText(gd);
        }

        [When(@"Letter Templates page Effective Year Drop down ""(.*)"" is Selected")]
        [Given(@"Letter Templates page Effective Year Drop down ""(.*)"" is Selected")]
        public void WhenLetterTemplatesPageEffectiveYearDropDownIsSelected(string p0)
        {

            tmsWait.Hard(3);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {


                //kendo-dropdownlist[@test-id='letterTemplate-select-effectiveYear']//span[@class='k-select']
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='letterTemplate-select-effectiveYear']//span[@class='k-select']");

                By typeapp = By.XPath("//li[text()='" + p0 + "']");

                //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                //tmsWait.Hard(3);
                //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

            }
            else
            {
                SelectElement planid = new SelectElement(EAM.LettersTemplate.EffectiveYearDropdown);
                string gd = tmsCommon.GenerateData(p0);
                planid.SelectByText(gd);
            }
            tmsWait.Hard(3);
            //IWebElement lang = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlLang"));
            //SelectElement langdrp = new SelectElement(lang);
            //langdrp.SelectByText("English");

        }

        [When(@"Letter Templates page Plan ID Drop down ""(.*)"" is Selected")]
        public void WhenLetterTemplatesPagePlanIDDropDownIsSelected(string p0)
        {
            tmsWait.Hard(3);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='letterTemplate-select-planId']//span[@class='k-select']");

                By typeapp = By.XPath("//li[text()='" + p0 + "']");

                //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                //tmsWait.Hard(3);
                //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            }
            else
            {
                SelectElement planid = new SelectElement(EAM.LettersTemplate.PlanIDDropdown);
                string gd = tmsCommon.GenerateData(p0);
                planid.SelectByText(gd);
            }
        }


        [When(@"Letter Templates page OK button is clicked")]
        [Given(@"Letter Templates page OK button is clicked")]
        [Then(@"Letter Templates page OK button is clicked")]
        public void WhenLetterTemplatesPageOKButtonIsClicked()
        {
            //fw.ExecuteJavascript(EAM.LettersTemplate.OkButton);
            //tmsWait.Hard(4);
            IWebElement save = Browser.Wd.FindElement(By.CssSelector("[test-id='letterTemplate-btn-searchLetters']"));
            fw.ExecuteJavascript(save);
            tmsWait.Hard(4);

        }

        [When(@"Letter Templates for PlanID ""(.*)"" and PBPID ""(.*)"" Template Name ""(.*)"" checkbox is ""(.*)""")]
        public void WhenLetterTemplatesForPlanIDAndPBPIDTemplateNameCheckboxIs(string p0, int p1, string p2, string p3)
        {
            tmsWait.Hard(4);
            IWebElement template = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_GridView1']//td[contains(.,'" + p0 + "')]/following-sibling::td/span[@templatename='" + p2 + "' and contains(@pbpid, '" + p1 + "')]"));
            IWebElement save = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_BtnSave"));
            if (!template.Selected)
            {
                template.Click();
                tmsWait.Hard(2);
                fw.ExecuteJavascript(save);
            }

            tmsWait.Hard(5);

        }

        [When(@"Letter Templates for PlanID ""(.*)"" and PBPID ""(.*)"" ""(.*)"" checkbox is ""(.*)""")]
        public void WhenLetterTemplatesForPlanIDAndPBPIDCheckboxIs(string planID, string pbpID, string templateName, string action)
        {
            bool pageFlag = false;
            TablePaging thisTP = new TablePaging();
            do
            {
                tmsWait.Hard(2);

                if (action.ToLower().Equals("checked"))
                {
                    if (!Browser.Wd.FindElement(By.CssSelector("span[templatename='" + templateName + "'][pbpid='" + pbpID + "'][planid='" + planID + "'] >input")).Selected)
                    {
                        Browser.Wd.FindElement(By.CssSelector("span[templatename='" + templateName + "'][pbpid='" + pbpID + "'][planid='" + planID + "'] >input")).Click();
                    }
                    pageFlag = true;
                }
                else
                {
                    if (Browser.Wd.FindElement(By.CssSelector("span[templatename='" + templateName + "'][pbpid='" + pbpID + "'][planid='" + planID + "'] >input")).Selected)
                    {
                        Browser.Wd.FindElement(By.CssSelector("span[templatename='" + templateName + "'][pbpid='" + pbpID + "'][planid='" + planID + "'] >input")).Click();
                    }
                    pageFlag = true;
                }

                if (!pageFlag)
                {
                    thisTP.bNotAtLastPageOfRecords = true;
                    thisTP.NPL.Click();
                    tmsWait.Hard(2);
                }
            } while (!pageFlag);
        }

        [When(@"Letter Templates page First Column Checkboxes are Checked on all pages")]
        public void WhenLetterTemplatesPageFirstColumnCheckboxesAreCheckedOnAllPages()
        {
            tmsWait.Hard(6);
            IWebElement pageTable = EAM.LettersTemplate.LetterTemplateTable;
            IList<IWebElement> allTH = pageTable.FindElements(By.TagName("th"));
            IWebElement thisSpan = allTH[2].FindElement(By.TagName("span"));
            string thisTemplateName = thisSpan.Text;
            //            string thisTemplateName = allTH[2].Text;

            int nextPage = 2;
            Boolean haveNextPage = true;
            while (haveNextPage)
            {
                IList<IWebElement> allInputs = pageTable.FindElements(By.TagName("input"));
                foreach (IWebElement thisInput in allInputs)
                {
                    if (thisInput.GetAttribute("name").Contains("_" + thisTemplateName))
                    {
                        try
                        {
                            if (thisInput.GetAttribute("CHECKED") == null)
                            {
                                thisInput.Click();
                            }
                        }
                        catch { }
                    }
                }
                IWebElement thisSave = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_BtnSave"));
                thisSave.Click();
                tmsWait.Hard(5);
                pageTable = EAM.LettersTemplate.LetterTemplateTable;
                IList<IWebElement> NPL = pageTable.FindElements(By.LinkText(nextPage.ToString()));
                if (NPL.Count > 0)
                {
                    NPL[0].Click();
                    tmsWait.Hard(8);
                    pageTable = EAM.LettersTemplate.LetterTemplateTable;
                    nextPage++;

                }
                else
                {
                    haveNextPage = false;
                }
            }
        }

        [When(@"Letter Templates page Acknowledgment of Plan Change Letter Template is ""(.*)""")]
        public void WhenLetterTemplatesPageAcknowledgmentOfPlanChangeLetterTemplateIs(string p0, Table table)
        {


            string GenerateData = tmsCommon.GenerateData(p0);

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.LettersTemplate.LetterTemplateTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            if (bThisRowMatches)
                            {
                                IWebElement thisEditTD = ApplicationRow.Element[2];
                                IWebElement thisEditLink = thisEditTD.FindElement(By.TagName("input"));



                                switch (GenerateData.ToLower())
                                {
                                    case "checked": { setCheckboxTo = "checked"; break; }
                                    case "on": { setCheckboxTo = "checked"; break; }
                                    case "yes": { setCheckboxTo = "checked"; break; }
                                    case "unchecked": { setCheckboxTo = "unchecked"; break; }
                                    case "off": { setCheckboxTo = "unchecked"; break; }
                                    case "no": { setCheckboxTo = "unchecked"; break; }
                                    default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
                                }

                                if (setCheckboxTo.Equals("unchecked"))
                                {


                                    if (thisEditLink.Selected == true)
                                    {
                                        thisEditLink.Click();
                                    }

                                }
                                else if (setCheckboxTo.Equals("checked"))
                                {
                                    if (thisEditLink.Selected == false)
                                    {
                                        thisEditLink.Click();
                                    }
                                }

                                //thisEditLink.Click();
                                tmsWait.Hard(2);



                            }

                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.LettersTemplate.LetterTemplateTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }


        }

        [When(@"Letter Templates page Confirmation of Enrollment in Another Plan Letter Template is ""(.*)""")]
        public void WhenLetterTemplatesPageConfirmationOfEnrollmentInAnotherPlanLetterTemplateIs(string p0, Table table)
        {


            string GenerateData = tmsCommon.GenerateData(p0);

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.LettersTemplate.LetterTemplateTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            if (bThisRowMatches)
                            {
                                IWebElement thisEditTD = ApplicationRow.Element[3];
                                IWebElement thisEditLink = thisEditTD.FindElement(By.TagName("input"));



                                switch (GenerateData.ToLower())
                                {
                                    case "checked": { setCheckboxTo = "checked"; break; }
                                    case "on": { setCheckboxTo = "checked"; break; }
                                    case "yes": { setCheckboxTo = "checked"; break; }
                                    case "unchecked": { setCheckboxTo = "unchecked"; break; }
                                    case "off": { setCheckboxTo = "unchecked"; break; }
                                    case "no": { setCheckboxTo = "unchecked"; break; }
                                    default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
                                }

                                if (setCheckboxTo.Equals("unchecked"))
                                {


                                    if (thisEditLink.Selected == true)
                                    {
                                        thisEditLink.Click();
                                    }

                                }
                                else if (setCheckboxTo.Equals("checked"))
                                {
                                    if (thisEditLink.Selected == false)
                                    {
                                        thisEditLink.Click();
                                    }
                                }

                                //thisEditLink.Click();
                                tmsWait.Hard(2);



                            }

                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.LettersTemplate.LetterTemplateTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }

        }
        [When(@"Acknowledge of Enrollment Letter Templates page ""(.*)"" Letter Template is ""(.*)"" for Plan ID ""(.*)"" PBP ID ""(.*)""")]
        public void WhenAcknowledgeOfEnrollmentLetterTemplatesPageLetterTemplateIsForPlanIDPBPID(string p0, string p1, string p2, string p3)
        {
            IWebElement lettertemp;
            int pageno = 1;
            bool presence = false;
            string planid = tmsCommon.GenerateData(p2);

            do
            {
                try
                {
                    lettertemp = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_GridView1']//td/span[@planid='" + planid + "' and @pbpid='" + p3 + "' and @templatename='" + p0 + "' ]/input"));
     //lettertemp = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='letterTempMapping-select-template']//span[@class='k-select'][@planid='" + planid + "' and @pbpid='" + p3 + "' and @templatename='" + p0 + "' ]/input"));
                    if (lettertemp.Displayed)
                    {
                        string lt = lettertemp.GetAttribute("checked");
                        if (lt != "true")
                        {
                            fw.ExecuteJavascript(lettertemp);
                            // presence = true;
                        }
                        presence = true;
                    }
                }
                catch
                {

                    string pagelink = pageno.ToString();
                    IWebElement nextlink = Browser.Wd.FindElement(By.XPath("(//table//a)[" + pagelink + "]"));
                    fw.ExecuteJavascript(nextlink);
                    tmsWait.Hard(3);
                    pageno++;
                }
            }
            while (!presence);


        }



        [When(@"Acknowledge of Enrollment Letter Templates page Letter Template is ""(.*)""")]
        public void WhenAcknowledgeOfEnrollmentLetterTemplatesPageLetterTemplateIs(string p0, Table table)
        {
            string GenerateData = tmsCommon.GenerateData(p0);

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.LettersTemplate.LetterTemplateTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            if (bThisRowMatches)
                            {
                                IWebElement thisEditTD = ApplicationRow.Element[3];
                                IWebElement thisEditLink = thisEditTD.FindElement(By.TagName("input"));



                                switch (GenerateData.ToLower())
                                {
                                    case "checked": { setCheckboxTo = "checked"; break; }
                                    case "on": { setCheckboxTo = "checked"; break; }
                                    case "yes": { setCheckboxTo = "checked"; break; }
                                    case "unchecked": { setCheckboxTo = "unchecked"; break; }
                                    case "off": { setCheckboxTo = "unchecked"; break; }
                                    case "no": { setCheckboxTo = "unchecked"; break; }
                                    default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
                                }

                                if (setCheckboxTo.Equals("unchecked"))
                                {


                                    if (thisEditLink.Selected == true)
                                    {
                                        thisEditLink.Click();
                                    }

                                }
                                else if (setCheckboxTo.Equals("checked"))
                                {
                                    if (thisEditLink.Selected == false)
                                    {
                                        thisEditLink.Click();
                                    }
                                }

                                //thisEditLink.Click();
                                tmsWait.Hard(2);



                            }

                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.LettersTemplate.LetterTemplateTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }


        }


        [When(@"Outbound Enrollment Letter Templates page Letter Template is ""(.*)""")]
        public void WhenOutboundEnrollmentLetterTemplatesPageLetterTemplateIs(string p0, Table table)
        {
            string GenerateData = tmsCommon.GenerateData(p0);

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.LettersTemplate.LetterTemplateTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            if (bThisRowMatches)
                            {
                                IWebElement thisEditTD = ApplicationRow.Element[6];
                                IWebElement thisEditLink = thisEditTD.FindElement(By.TagName("input"));



                                switch (GenerateData.ToLower())
                                {
                                    case "checked": { setCheckboxTo = "checked"; break; }
                                    case "on": { setCheckboxTo = "checked"; break; }
                                    case "yes": { setCheckboxTo = "checked"; break; }
                                    case "unchecked": { setCheckboxTo = "unchecked"; break; }
                                    case "off": { setCheckboxTo = "unchecked"; break; }
                                    case "no": { setCheckboxTo = "unchecked"; break; }
                                    default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
                                }

                                if (setCheckboxTo.Equals("unchecked"))
                                {


                                    if (thisEditLink.Selected == true)
                                    {
                                        thisEditLink.Click();
                                    }

                                }
                                else if (setCheckboxTo.Equals("checked"))
                                {
                                    if (thisEditLink.Selected == false)
                                    {
                                        thisEditLink.Click();
                                    }
                                }

                                //thisEditLink.Click();
                                tmsWait.Hard(2);



                            }

                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.LettersTemplate.LetterTemplateTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }


        }



        [When(@"Denial Enrollment Letter Templates page Letter Template is ""(.*)""")]
        public void WhenDenialEnrollmentLetterTemplatesPageLetterTemplateIs(string p0, Table table)
        {


            string GenerateData = tmsCommon.GenerateData(p0);

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.LettersTemplate.LetterTemplateTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            if (bThisRowMatches)
                            {
                                IWebElement thisEditTD = ApplicationRow.Element[3];
                                IWebElement thisEditLink = thisEditTD.FindElement(By.TagName("input"));



                                switch (GenerateData.ToLower())
                                {
                                    case "checked": { setCheckboxTo = "checked"; break; }
                                    case "on": { setCheckboxTo = "checked"; break; }
                                    case "yes": { setCheckboxTo = "checked"; break; }
                                    case "unchecked": { setCheckboxTo = "unchecked"; break; }
                                    case "off": { setCheckboxTo = "unchecked"; break; }
                                    case "no": { setCheckboxTo = "unchecked"; break; }
                                    default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
                                }

                                if (setCheckboxTo.Equals("unchecked"))
                                {


                                    if (thisEditLink.Selected == true)
                                    {
                                        thisEditLink.Click();
                                    }

                                }
                                else if (setCheckboxTo.Equals("checked"))
                                {
                                    if (thisEditLink.Selected == false)
                                    {
                                        thisEditLink.Click();
                                    }
                                }

                                //thisEditLink.Click();
                                tmsWait.Hard(2);



                            }

                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.LettersTemplate.LetterTemplateTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }

        }
        [When(@"Letter Templates page Letter Template is ""(.*)"" for planid as ""(.*)"" and pbpid as ""(.*)"" and lettertype as OnDemand Letter")]
        public void WhenLetterTemplatesPageLetterTemplateIsForPlanidAsAndPbpidAsAndLettertypeAsOnDemandLetter(string check, string PlanID, string PBP)
        {
            PlanID = tmsCommon.GenerateData(PlanID);
            PBP = tmsCommon.GenerateData(PBP);
            string xpath = ".//span[@pbpid='" + PBP.Substring(0, 3) + "' and @planid ='" + PlanID + "']/input";
            IWebElement checkbox = Browser.Wd.FindElement(By.XPath(xpath));
            if (check.Equals("checked"))
                if (checkbox.Selected == false)
                    checkbox.Click();
                else Console.WriteLine("Check box for" + PlanID + "and" + PBP + " is already checked");

        }




        [When(@"Letter Templates page Letter Template is checked for plan ""(.*)"" and pbp ""(.*)""")]
        public void WhenLetterTemplatesPageLetterTemplateIsCheckedForPlanAndPbp(string p0, int p1)
        {
            tmsWait.Hard(1);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {

            }
            else
            {
                By map = By.CssSelector("[test-id='letterTemplate-btn-mapLetters']");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(map);
                tmsWait.Hard(5);



                SelectElement planid = new SelectElement(Browser.Wd.FindElement(By.CssSelector("[test-id='letterTempMapping-select-template']")));
                planid.SelectByText("005_ConfOfEnrollment");
                tmsWait.Hard(1);
                By checkAll = By.XPath("(//input[@id='checkAll'])[1]");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(checkAll);
                tmsWait.Hard(1);
                By Maptemp = By.CssSelector("[test-id='letterTempMapping-btn-MapLetters']");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(Maptemp);
                tmsWait.Hard(1);
                By MaptempCancel = By.CssSelector("[test-id='letterTempMapping-btn-btnCancel']");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(MaptempCancel);
            }
        }
        [When(@"Verify Letter Templates page Letter Template is ""(.*)""")]
        public void WhenVerifyLetterTemplatesPageLetterTemplateIs(string p0)
        {
            string action = p0.ToLower();
            By check = By.XPath("//div[@test-id='letterTemplate-grid-letterTemplates']//td[contains(.,'FL001')]/following-sibling::td/input");

            ReUsableFunctions.CheckBoxGetStatus(check, action);
        }


        [When(@"Letter Templates page Letter Template is ""(.*)""")]
        [Given(@"Letter Templates page Letter Template is ""(.*)""")]
        public void WhenLetterTemplatesPageLetterTemplateIs(string p0, Table table)
        {

            tmsWait.Hard(12);

            IWebElement ele = Browser.Wd.FindElement(By.XPath("//div[@test-id='letterTemplate-grid-letterTemplates']//td[contains(.,'FL001')]/following-sibling::td/input"));

            //string GenerateData = tmsCommon.GenerateData(p0);

            ////Create Storage for the Gherkin table and the page data
            //GherkinTable thisGT = new GherkinTable();
            //TablePaging thisTP = new TablePaging();

            ////Load the Gherkin table into the storage
            //thisGT.LoadGherkinTable(table);

            ////The big loop.  Keep working until all the Gherkin table rows are marked as matched
            ////Or until we are on the last page of records, then we also quit looking.
            //while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            //{
            //    //Start out with the assumption we are not on the last page of records.  We will check later.
            //    thisTP.bNotAtLastPageOfRecords = false;

            //    //Get the table object again, since the page refreshes we need to get it fresh
            //    IWebElement baseTable = EAM.LettersTemplate.LetterTemplateTable;

            //    //Look for a next page link.  We will set 'last page of records' here also.
            //    thisTP.LoadNextPageLink(baseTable);

            //    //Load the page data off the application.   
            //    //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
            //    thisTP.LoadPageTable(baseTable, "th", "td");

            //    int iTableCounter = 0;
            //    //                string expectedTableCheckboxValue = "";
            //    //for each row in the Gherkin table, start flipping through all the rows in the page data.
            //    foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
            //    {
            //        //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

            //        //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
            //        if (GherkinTableRow == null)
            //        {
            //            break;
            //        }

            //        //If this Gherkin table row is not yet matched, proceed.
            //        if (GherkinTableRow.RowIsMatched == false)
            //        {
            //            //Convert the row to an array so we can do an element by element match.
            //            string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

            //            //For each row in the page data
            //            foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
            //            {
            //                //Convert page data to array elements
            //                //Only work with the loaded element rows.  The first unloaded one will be null.
            //                if (ApplicationRow == null)
            //                {
            //                    break;
            //                }

            //                //Convert the page row to array so we can pair up by elements.
            //                string[] AppTableRow = ApplicationRow.Row.ToArray();
            //                int iElementCounter = 0;
            //                Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

            //                //In here as we pair up the data you will have custom matching.
            //                //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
            //                foreach (string appTD in AppTableRow)
            //                {
            //                    //if (iElementCounter > 0 && TDA.RowIsData)
            //                    if (ApplicationRow.RowIsData)
            //                    {
            //                        //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
            //                        if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
            //                        {

            //                            bThisRowMatches = false;
            //                        }
            //                        //if (iElementCounter == 5)
            //                        //{
            //                        //    expectedTableCheckboxValue = GherkinTableArray[5];
            //                        //}
            //                    }
            //                    else
            //                    {
            //                        //Also fail row match if the element count of the page data row is 0
            //                        if (iElementCounter > 0)
            //                        {
            //                            bThisRowMatches = false;
            //                        }
            //                    }
            //                    iElementCounter++;
            //                }
            //                if (AppTableRow.Length == 0)
            //                {
            //                    //Another check that if the page data row is 0 long, we didn't match, fail the match.
            //                    bThisRowMatches = false;
            //                }
            //                //Instance of TableRow Class for reporting functions
            //                var TableRow = new TMSString();

            //                if (bThisRowMatches)
            //                {
            //                    //report the success stuff.  Puts out the row data, etc.
            //                    thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
            //                }
            //                if (bThisRowMatches)
            //                {
            //                    tmsWait.Hard(1);
            //                    IWebElement thisEditTD = ApplicationRow.Element[2];
            //                    IWebElement thisEditLink = thisEditTD.FindElement(By.TagName("input"));



            //                    switch (GenerateData.ToLower())
            //                    {
            //                        case "checked": { setCheckboxTo = "checked"; break; }
            //                        case "on": { setCheckboxTo = "checked"; break; }
            //                        case "yes": { setCheckboxTo = "checked"; break; }
            //                        case "unchecked": { setCheckboxTo = "unchecked"; break; }
            //                        case "off": { setCheckboxTo = "unchecked"; break; }
            //                        case "no": { setCheckboxTo = "unchecked"; break; }
            //                        default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            //                    }

            //                    if (setCheckboxTo.Equals("unchecked"))
            //                    {


            //                        if (thisEditLink.Selected == true)
            //                        {
            //                            thisEditLink.Click();
            //                        }

            //                    }
            //                    else if (setCheckboxTo.Equals("checked"))
            //                    {
            //                        if (thisEditLink.Selected == false)
            //                        {
            //                            thisEditLink.Click();
            //                        }
            //                    }

            //                    //thisEditLink.Click();
            //                    tmsWait.Hard(2);



            //                }

            //            }
            //        }
            //        iTableCounter++;
            //    }
            //    //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
            //    Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
            //    if (fullMatching)
            //    {
            //        Console.WriteLine("All rows are matched, step completed as passed");
            //    }
            //    else
            //    {
            //        //Click next page link and start over.
            //        if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
            //        {
            //            thisTP.bNotAtLastPageOfRecords = true;
            //            thisTP.NPL.Click();
            //            tmsWait.Hard(4);
            //        }
            //    }
            //    baseTable = EAM.LettersTemplate.LetterTemplateTable;


            //    //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
            //    //Time to boil it down and report which rows didn't get matched.
            //    //Also to fail because we were planning to match the rows.
            //    if (thisTP.bHaveGoodPageLink == false && !fullMatching)
            //    {
            //        thisTP.ReportNotMatching(thisGT.GTable);
            //    }
            //}
        }

        [When(@"Letter Templates page Save button is clicked")]
        [Given(@"Letter Templates page Save button is clicked")]
        public void WhenLetterTemplatesPageSaveButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(EAM.LettersTemplate.TemplateSaveButton);
            tmsWait.Hard(2);
        }


        [Then(@"view Edit Memmber page Correspondence tab ""(.*)"" is Selected")]
        public void ThenViewEditMemmberPageCorrespondenceTabIsSelected(string p0)
        {
            string LetterName = tmsCommon.GenerateData(p0);
            tmsWait.Hard(1);
            SelectElement planid = new SelectElement(EAM.MemberInformation.CorrespondenceTabLetterName);

            planid.SelectByText(LetterName);
        }
        [Then(@"View Edit Memeber page Add Transaction dialog Add to Queue button is Clicked for ""(.*)""")]
        [When(@"View Edit Memeber page Add Transaction dialog Add to Queue button is Clicked for ""(.*)""")]
        [Given(@"View Edit Memeber page Add Transaction dialog Add to Queue button is Clicked for ""(.*)""")]
        public void ThenViewEditMemeberPageAddTransactionDialogAddToQueueButtonIsClickedFor(string Lettername)
        {
            tmsWait.Hard(5);
            string LetterName = tmsCommon.GenerateData(Lettername);
            bool exist = CheckIfmemberAlreadyQueued();
            if (exist == false)
            {
                EAM.MemberInformation.AddTransactionDialogAddtoQueuebutton.Click();
                string message = "\"" + Lettername + "\" letter is queued.";
                string alrdypresent = "Letter is already in queue and can't be queued again.";
                string msg = EAM.LettersTemplate.CorrespondenceMsg.Text;
                if (msg.Equals(message)) { Console.WriteLine("Letter is successfully queued"); }
                if (msg.Equals(alrdypresent)) { Console.WriteLine("Letter is already in queue"); }
            }
            else Console.WriteLine("Letter is already Queued");
        }

        [Then(@"view Edit Memmber page Correspondence tab Add Transaction button is Clicked")]
        [When(@"view Edit Memmber page Correspondence tab Add Transaction button is Clicked")]
        public void ThenViewEditMemmberPageCorrespondenceTabAddTransactionButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(EAM.MemberInformation.CorrespondenceTabAddTransactionbutton);
            tmsWait.Hard(4);
            //EAM.MemberInformation.CorrespondenceTabAddTransactionbutton.Click();

            //string msg = EAM.LettersTemplate.CorrespondenceMsg.Text;
            ////string success="\"OnDemand_Test_1\"" + "letter is queued.";
            //string alreadyinqueue="Letter is already in queue and can't be queued again.";
            ////if (msg.Equals(success))
            ////{

            ////    Console.WriteLine(" Letter Template is Added successfully");
            ////}
            //if(msg.Equals(alreadyinqueue))
            //{
            //    Console.WriteLine(" Letter Template is already Added in Queue");
            //}


        }

        [Then(@"View Edit Memeber page Add Transaction dialog TC(.*) is selected")]
        [Given(@"View Edit Memeber page Add Transaction dialog TC(.*) is selected")]
        [When(@"View Edit Memeber page Add Transaction dialog TC(.*) is selected")]
        public void ThenViewEditMemeberPageAddTransactionDialogTCIsSelected(int p0, Table table)
        {
            tmsWait.Hard(10);
            bool exist = CheckIfmemberAlreadyQueued();
            if (exist == false)
            {
                //Create Storage for the Gherkin table and the page data
                GherkinTable thisGT = new GherkinTable();
                TablePaging thisTP = new TablePaging();

                //Load the Gherkin table into the storage
                thisGT.LoadGherkinTable(table);

                //The big loop.  Keep working until all the Gherkin table rows are marked as matched
                //Or until we are on the last page of records, then we also quit looking.
                while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
                {
                    //Start out with the assumption we are not on the last page of records.  We will check later.
                    thisTP.bNotAtLastPageOfRecords = false;

                    //Get the table object again, since the page refreshes we need to get it fresh
                    IWebElement baseTable = EAM.MemberInformation.AddTransactionDialogTable;

                    //Look for a next page link.  We will set 'last page of records' here also.
                    thisTP.LoadNextPageLink(baseTable);

                    //Load the page data off the application.   
                    //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                    thisTP.LoadPageTable(baseTable, "td", "td");

                    int iTableCounter = 0;
                    //                string expectedTableCheckboxValue = "";
                    //for each row in the Gherkin table, start flipping through all the rows in the page data.
                    foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                    {
                        //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                        //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                        if (GherkinTableRow == null)
                        {
                            break;
                        }

                        //If this Gherkin table row is not yet matched, proceed.
                        if (GherkinTableRow.RowIsMatched == false)
                        {
                            //Convert the row to an array so we can do an element by element match.
                            string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                            //For each row in the page data
                            foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                            {
                                //Convert page data to array elements
                                //Only work with the loaded element rows.  The first unloaded one will be null.
                                if (ApplicationRow == null)
                                {
                                    break;
                                }

                                //Convert the page row to array so we can pair up by elements.
                                string[] AppTableRow = ApplicationRow.Row.ToArray();
                                int iElementCounter = 0;
                                Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                                //In here as we pair up the data you will have custom matching.
                                //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                                foreach (string appTD in AppTableRow)
                                {
                                    //if (iElementCounter > 0 && TDA.RowIsData)
                                    if (ApplicationRow.RowIsData)
                                    {
                                        //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                        if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                        {

                                            bThisRowMatches = false;
                                        }
                                        //if (iElementCounter == 5)
                                        //{
                                        //    expectedTableCheckboxValue = GherkinTableArray[5];
                                        //}
                                    }
                                    else
                                    {
                                        //Also fail row match if the element count of the page data row is 0
                                        if (iElementCounter > 0)
                                        {
                                            bThisRowMatches = false;
                                        }
                                    }
                                    iElementCounter++;
                                }
                                if (AppTableRow.Length == 0)
                                {
                                    //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                    bThisRowMatches = false;
                                }
                                //Instance of TableRow Class for reporting functions
                                var TableRow = new TMSString();

                                if (bThisRowMatches)
                                {
                                    //report the success stuff.  Puts out the row data, etc.
                                    thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                                }
                                if (bThisRowMatches)
                                {
                                    IWebElement thisEditTD = ApplicationRow.Element[0];
                                    IWebElement thisEditLink = thisEditTD.FindElement(By.TagName("input"));
                                    thisEditLink.Click();
                                    //tmsWait.Hard(2);

                                }

                            }
                        }
                        iTableCounter++;
                    }
                    //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                    Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                    if (fullMatching)
                    {
                        Console.WriteLine("All rows are matched, step completed as passed");
                    }
                    else
                    {
                        //Click next page link and start over.
                        if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                        {
                            thisTP.bNotAtLastPageOfRecords = true;
                            thisTP.NPL.Click();
                            tmsWait.Hard(2);
                        }
                    }
                    //baseTable = EAM.AdministrationStatusoverride.TransactionSearchTable;
                    //    baseTable =EAM.MemberInformation.TransactionHistoryTable;


                    //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                    //Time to boil it down and report which rows didn't get matched.
                    //Also to fail because we were planning to match the rows.
                    if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                    {
                        thisTP.ReportNotMatching(thisGT.GTable);
                    }
                }
            }
            else Console.WriteLine("Member is already Queued");
        }
        public bool CheckIfmemberAlreadyQueued()
        {
            string alrdypresent = "Letter is already in queue and can't be queued again.";
            try
            {
                string msg = EAM.LettersTemplate.CorrespondenceMsg.Text;
                if (msg.Equals(alrdypresent)) { Console.WriteLine("Letter is already in queue"); return true; }
            }
            catch (Exception)
            {
                Console.WriteLine("member is not already queued");
            }


            return false;
        }

        [Then(@"View Edit Memeber page Add Transaction dialog Add to Queue button is Clicked")]
        public void ThenViewEditMemeberPageAddTransactionDialogAddToQueueButtonIsClicked()
        {
            EAM.MemberInformation.AddTransactionDialogAddtoQueuebutton.Click();
        }

        [Then(@"Member Info page Correspondence tab is Clicked")]
        public void ThenMemberInfoPageCorrespondenceTabIsClicked()
        {
            EAM.MemberInformation.CorrespondenceTab.Click();
        }
        [Then(@"Member Info page OEC Sales tab is Clicked")]
        public void ThenMemberInfoPageOECSalesTabIsClicked()
        {
            tmsWait.Hard(3);
            IWebElement link = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnOECSales"));
            fw.ExecuteJavascript(link);
        }

        [Then(@"Verify Member Info page OEC Sales tab Sales Rep is set to""(.*)""")]
        public void ThenVerifyMemberInfoPageOECSalesTabSalesRepIsSetTo(string expected)
        {
            tmsWait.Hard(3);
            IWebElement link = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucOECSales_RadComboBox1_Input"));
            string actual = link.GetAttribute("value");

            Assert.AreEqual(expected, actual, "Both are not matching");


        }

        [Then(@"Add New Transaction link is Clicked")]
        public void ThenAddNewTransactionLinkIsClicked()
        {
            IWebElement link = Browser.Wd.FindElement(By.Id("LinkButton1"));
            fw.ExecuteJavascript(link);
        }


        [Given(@"Member Info page Transactions tab is Clicked")]
        [Then(@"Member Info page Transactions tab is Clicked")]
        public void ThenMemberInfoPageTransactionsTabIsClicked()
        {
            tmsWait.Hard(1);
            EAM.MemberInformation.TransactionsTab.Click();
            tmsWait.Hard(1);
        }

        [Then(@"Verify Member Info Page Transaction tab Transaction (.*) is Clicked")]
        public void ThenVerifyMemberInfoPageTransactionTabTransactionIsClicked(int p0)
        {
            tmsWait.Hard(3);
            IWebElement link = Browser.Wd.FindElement(By.XPath("(//a/img[@title='click here to edit this Transaction.'])[2]"));
            fw.ExecuteJavascript(link);
        }

        [Then(@"View Edit Transaction page Cancel button is Clicked")]
        public void ThenViewEditTransactionPageCancelButtonIsClicked()
        {
            tmsWait.Hard(3);
            IWebElement link = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnCancelTransaction"));
            fw.ExecuteJavascript(link);
            tmsWait.Hard(3);
            Browser.ClosePopUps(true);
        }


        [Then(@"Verify Transaction tab displays message as ""(.*)""")]
        public void ThenVerifyTransactionTabDisplaysMessageAs(string p0)
        {
            tmsWait.Hard(2);
            IWebElement msg = Browser.Wd.FindElement(By.XPath("//span[contains(.,'"+ p0 + "')]"));
          
            Assert.IsTrue(msg.Enabled);
        }


        [Then(@"I Clicked on Add New Transaction link")]
        public void ThenIClickedOnAddNewTransactionLink()
        {
            tmsWait.Hard(2);
            IWebElement link = Browser.Wd.FindElement(By.XPath("//a[@id='LinkButton1']"));
            fw.ExecuteJavascript(link);
            tmsWait.Hard(2);


        }

        [Then(@"Verify ""(.*)"" page is getting displayed successfully")]
        public void ThenVerifyPageIsGettingDisplayedSuccessfully(string expectedTitle)
        {
            tmsWait.Hard(3);
            string actualTitle = Browser.Wd.Title;
            Assert.AreEqual(expectedTitle, actualTitle, "Both values are not matching");
        }

        [Then(@"Verify Bank Account Type is set to ""(.*)""")]
        public void ThenVerifyBankAccountTypeIsSetTo(string expected)
        {
            IWebElement acc = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucPaymentInfo_cboBankAccType"));
            SelectElement sel = new SelectElement(acc);
            string actual = sel.SelectedOption.Text;
            Assert.AreEqual(expected, actual, "Both values are not matching");

        }


        [Then(@"Member Info page Payment tab is Clicked")]
        public void ThenMemberInfoPagePaymentTabIsClicked()
        {
            EAM.MemberInformation.PaymentTab.Click();

            tmsWait.Hard(3);
        }

        [Then(@"Member Info page Contact tab is Clicked")]
        public void ThenMemberInfoPageContactTabIsClicked()
        {
            EAM.MemberInformation.ContactTab.Click();
        }

        [Then(@"Member Info page RX Billing tab is Clicked")]
        public void ThenMemberInfoPageRXBillingTabIsClicked()
        {
            EAM.MemberInformation.RXBillingTab.Click();
        }


        [Then(@"View Edit Member page Employer Group Number Edit icon is Clicked")]
        public void ThenViewEditMemberPageEmployerGroupNumberEditIconIsClicked()
        {
            EAM.MemberInformation.EmployerGroupNumberEditIcon.Click();
            tmsWait.Hard(1);
        }


        [Then(@"View Edit Member Page Employer Group Number drop down list values are readed")]
        public void ThenViewEditMemberPageEmployerGroupNumberDropDownListValuesAreReaded()
        {
            EAM.MemberInformation.EmployerGroupNumberDrpDwnArrow.Click();
            EAMallRows = Browser.Wd.FindElements(By.XPath("//ul[@class='rcbList']/li//tr/td[1]"));

            fw.ConsoleReport(" EAM List of Employer Group values ");

            foreach (IWebElement emp in this.EAMallRows)
            {
                Console.WriteLine(emp.Text);
            }
        }

        [Then(@"Transactions result page TransID is noted for HIC ""(.*)""")]
        public void ThenTransactionsResultPageTransIDIsNotedForHIC(string planID)
        {
            List<string> alNewtextLine = new List<string>();
            string transID = string.Empty;
            int count = Browser.Wd.FindElements(By.XPath("//*[@id='ctl00_ctl00_MainMasterContent_MainContent_ucTransHistory_dgHistory']/tbody//td[2]")).Count;
            for (int index = 2; index < count + 2; index++)
            {
                if (Browser.Wd.FindElement(By.XPath("//*[@id='ctl00_ctl00_MainMasterContent_MainContent_ucTransHistory_dgHistory']/tbody/tr[" + index + "]/td[5]")).Text.Equals(planID))
                {
                    transID = Browser.Wd.FindElement(By.XPath("//*[@id='ctl00_ctl00_MainMasterContent_MainContent_ucTransHistory_dgHistory']/tbody/tr[" + index + "]/td[2]")).Text;
                    break;
                }
            }
            string newTransID = "-1833857214" + transID;
            string[] lines = File.ReadAllLines(@"C:\temp\tmsAlm\EFTO.RH1001.DTRRD.D201404.118TRCT10");
            foreach (string line in lines)
            {
                StringBuilder sb = new StringBuilder(line);
                sb.Replace("-18338572143375", newTransID);
                alNewtextLine.Add(sb.ToString());
            }
            var newText = alNewtextLine.ToArray();
            File.WriteAllLines(@"C:\temp\tmsAlm\EFTO.RH1001.DTRRD.D201404.118TRCT10", newText);
        }

        [Then(@"Verify ERF Page Employer Group Number drop down value is set to ""(.*)""")]
        public void ThenVerifyERFPageEmployerGroupNumberDropDownValueIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            SelectElement erfdrp = new SelectElement(EAM.ERF.ERFEmployerGroupNumberdrpdownlist);
            erfdrp.SelectByText(value);

        }
        [Then(@"Verify ERF Page Employer Group Name drop down value is set to ""(.*)""")]
        public void ThenVerifyERFPageEmployerGroupNameDropDownValueIsSetTo(string p0)
        {
            string expectedValue = tmsCommon.GenerateData(p0);
            IWebElement ele = Browser.Wd.FindElement(By.Id("EmployerName"));
            string actualValue = ele.GetAttribute("value");

            Assert.AreEqual(expectedValue, actualValue, "Both values are not matching");

        }



        [Then(@"Verify ERF Page Employer Group Number are matching with EAM Group Number drop downlist")]
        public void ThenVerifyERFPageEmployerGroupNumberAreMatchingWithEAMGroupNumberDropDownlist()
        {
            SelectElement erfdrp = new SelectElement(EAM.ERF.ERFEmployerGroupNumberdrpdownlist);


            ERFallRows = erfdrp.Options;

            fw.ConsoleReport(" ERF List of Employer Group values ");

            foreach (IWebElement emp in this.ERFallRows)
            {

                Console.WriteLine(emp.Text);
            }

            if (ERFallRows.Except(EAMallRows).Any())
            {
                fw.ConsoleReport(" EAM and ERF page values are getting matched");
            }
            else
            {
                fw.ConsoleReport(" EAM and ERF page values are not getting matched");
            }



        }

        [Then(@"View Edit Member page Employer Group dialog Employer Group Number is set to ""(.*)""")]
        public void ThenViewEditMemberPageEmployerGroupDialogEmployerGroupNumberIsSetTo(string p0)
        {
            EAM.MemberInformation.EmployerGroupNumberTextbox.SendKeys(p0);
        }

        [Then(@"View Edit Member page Employer Group dialog Employer Name is set to ""(.*)""")]
        public void ThenViewEditMemberPageEmployerGroupDialogEmployerNameIsSetTo(string p0)
        {
            EAM.MemberInformation.EmployerGroupNameTextbox.SendKeys(p0);
        }

        [Then(@"View Edit Member page Employer Group dialog Save button is Clicked")]
        public void ThenViewEditMemberPageEmployerGroupDialogSaveButtonIsClicked()
        {
            EAM.MemberInformation.EmployerGroupDialogOKButton.Click();
            tmsWait.Hard(1);
        }

        [Then(@"View Edit Member page Employer Group dialog Close button is Clicked")]
        public void ThenViewEditMemberPageEmployerGroupDialogCloseButtonIsClicked()
        {
            EAM.MemberInformation.EmployerGroupDialogCloseButton.Click();
        }


        [Then(@"View Edit Member page Contact Tab ""(.*)"" is set to ""(.*)""")]
        public void ThenViewEditMemberPageContactTabIsSetTo(string p0, string p1)
        {
            string field = p0.ToString();

            string expectedValue = p1.ToString();

            switch (field)
            {

                case "Address1":

                    string actualAddress = EAM.MembersViewEdit.MemberViewEditResidenceAddress1.GetAttribute("value");
                    Assert.AreEqual(expectedValue, actualAddress, expectedValue + " value is getting matched with" + actualAddress);
                    break;

                case "City":
                    string actualCity = EAM.MembersViewEdit.MemberViewEditResidenceCity.GetAttribute("value");
                    Assert.AreEqual(expectedValue, actualCity, expectedValue + " value is getting matched with" + actualCity);
                    break;


                case "State":
                    string actualState = EAM.MembersViewEdit.MemberViewEditResidenceState.GetAttribute("value");
                    Assert.AreEqual(expectedValue, actualState, expectedValue + " value is getting matched with" + actualState);
                    break;

                case "Zip":
                    string actualZip = EAM.MembersViewEdit.MemberViewEditResidenceZip.GetAttribute("value");
                    Assert.AreEqual(expectedValue, actualZip, expectedValue + " value is getting matched with" + actualZip);
                    break;

                case "County":
                    string actualCounty = EAM.MembersViewEdit.MemberViewEditResidenceCounty.GetAttribute("value");
                    Assert.AreEqual(expectedValue, actualCounty, expectedValue + " value is getting matched with" + actualCounty);
                    break;

                case "SCC":
                    string actualSCC = EAM.MembersViewEdit.MemberViewEditResidenceSCC.GetAttribute("value");
                    Assert.AreEqual(expectedValue, actualSCC, expectedValue + " value is getting matched with" + actualSCC);
                    break;

            }

        }


        [Then(@"View Edit Member Info page ""(.*)"" is set to ""(.*)""")]
        public void ThenViewEditMemberInfoPageIsSetTo(string p0, string p1)
        {


            string field = p0.ToString();

            string expectedValue = p1.ToString();

            switch (field)
            {

                case "County":

                    string actualCounty = EAM.MemberInformation.MemberInfoCounty.GetAttribute("value");
                    Assert.AreEqual(expectedValue, actualCounty, expectedValue + " value is getting matched with" + actualCounty);
                    break;

                case "SCC":
                    string actualSCC = EAM.MemberInformation.MemberInfoSCC.GetAttribute("value");
                    Assert.AreEqual(expectedValue, actualSCC, expectedValue + " value is getting matched with" + actualSCC);
                    break;
            }

        }




        [Then(@"Verify View Edit Member page Account Number field ""(.*)"" is displayed")]
        public void ThenVerifyViewEditMemberPageAccountNumberFieldIsDisplayed(string p0)
        {
            string expected = p0.ToString();

            string actual = EAM.MemberInformation.PaymentTabAccNumber.GetAttribute("value");

            Assert.AreEqual(expected, actual, "Expected Account number is displayed" + expected);
        }

        [Then(@"Verify View Edit Member page Bank Account Type ""(.*)"" is displayed")]
        public void ThenVerifyViewEditMemberPageBankAccountTypeIsDisplayed(string accountType)
        {
            SelectElement bankAccTypeDD = new SelectElement(EAM.MemberInformation.BankAccTypeDropdown);
            Assert.IsTrue(bankAccTypeDD.SelectedOption.Text.Equals(accountType));
        }


        [Then(@"Verify Member View Edit Page Member Status is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditPageMemberStatusIsSetTo(string p0)
        {

            string fieldName = "Member Status";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNew.Status.Text;

            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [Then(@"Verify Member View Edit Page Member TermDate is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditPageMemberTermDateIsSetTo(string p0)
        {
            string fieldName = "Member Terminate Date";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MembersNew.TermDate.GetAttribute("value");

            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [Then(@"Letters Queue Page Remove button is Clicked")]
        public void ThenLettersQueuePageRemoveButtonIsClicked()
        {
            EAM.Letters.LettersQueueRemovebutton.Click();
            tmsWait.Hard(1);
        }

        [Then(@"Letter Queues page Confirmation dialog Ok button is Clicked")]
        public void ThenLetterQueuesPageConfirmationDialogOkButtonIsClicked()
        {

            IAlert alert = Browser.Wd.SwitchTo().Alert();
            alert.Accept();
            tmsWait.Hard(1);
        }


        [Then(@"Letter Queues page DeSelect All link is Clicked")]
        public void ThenLetterQueuesPageDeSelectAllLinkIsClicked()
        {
            EAM.LettersPostCMS.DeSelectAll.Click();
        }

        [Then(@"Letters Queue Page Letter Queue table Remove Checkbox is Checked")]
        public void ThenLettersQueuePageLetterQueueTableRemoveCheckboxIsChecked(Table table)
        {

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.Letters.LettersTableNew;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            if (bThisRowMatches)
                            {
                                IWebElement thisEditTD = ApplicationRow.Element[6];
                                //      IWebElement thisEditLink = thisEditTD.FindElement(By.TagName("a"));
                                //IWebElement thischeckbox = thisEditTD.FindElement(By.XPath("\\input[@type='checkbox']"));
                                IWebElement thischeckbox = thisEditTD.FindElement(By.TagName("input"));
                                thischeckbox.Click();
                                tmsWait.Hard(2);

                                //if(thischeckbox.Selected)
                                //{



                                //if (setCheckboxTo.Equals("UnChecked"))
                                //{
                                //    if (EAM.AdministrationStatusoverride.SearchForTransactionCheckbox.Selected == true)
                                //    {
                                //        EAM.AdministrationStatusoverride.SearchForTransactionCheckbox.Click();
                                //    }
                                //}
                                //else if (setCheckboxTo.Equals("checked"))
                                //{
                                //    if (EAM.AdministrationStatusoverride.SearchForTransactionCheckbox.Selected == false)
                                //    {
                                //        EAM.AdministrationStatusoverride.SearchForTransactionCheckbox.Click();
                                //    }
                                //}

                            }

                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.Letters.LettersTableNew;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }

        }

        //Added by Tejas for Letter>>OnDemad>>Table to check the Send checkbox
        [Then(@"Letters Queue Page Letter Queue table Send Checkbox is Checked")]
        public void ThenLettersQueuePageLetterQueueTableSendCheckboxIsChecked(Table table)
        {

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.Letters.LettersTableNew;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            if (bThisRowMatches)
                            {
                                IWebElement thisEditTD = ApplicationRow.Element[5];

                                //IWebElement thisEditLink = thisEditTD.FindElement(By.TagName("a"));
                                IWebElement thischeckbox = thisEditTD.FindElement(By.XPath("//input[@type='checkbox']"));
                                //IWebElement thischeckbox = thisEditTD.FindElement(By.TagName("input"));
                                thischeckbox.Click();
                                tmsWait.Hard(2);



                                //if(thischeckbox.Selected)
                                //{




                                //if (setCheckboxTo.Equals("UnChecked"))
                                //{
                                //    if (EAM.AdministrationStatusoverride.SearchForTransactionCheckbox.Selected == true)
                                //    {
                                //        EAM.AdministrationStatusoverride.SearchForTransactionCheckbox.Click();
                                //    }
                                //}
                                //else if (setCheckboxTo.Equals("checked"))
                                //{
                                //    if (EAM.AdministrationStatusoverride.SearchForTransactionCheckbox.Selected == false)
                                //    {
                                //        EAM.AdministrationStatusoverride.SearchForTransactionCheckbox.Click();
                                //    }
                                //}


                            }

                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.Letters.LettersTableNew;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }

        }
        //End of Letter>>OnDemad>>table>>check>>send checkbox


        [Then(@"Letters Queue Page should not display row")]
        public void ThenLettersQueuePageShouldNotDisplayRow(Table table)
        {


            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.Letters.LettersTableNew;

                //Look for a next page link.  We will set 'last page of records' here also.
                //           thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");
                //               Boolean bTransStatusMatching = false;
                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {

                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //if(AppTableRow.Equals(GherkinTableArray[iElementCounter])
                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (appTD.Equals("Canceled"))
                                //{

                                //    Assert.IsTrue(appTD.Equals("Canceled"));
                                //    bTransStatusMatching = true;
                                //    //Console.WriteLine("TC 61 status is found as Canceled");
                                //}

                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //    //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                                Assert.AreEqual(true, false, "Did not expect to match any rows.   This row did match.   Fail");

                            }



                        }

                    }
                    iTableCounter++;
                    //if (bTransStatusMatching)
                    //{
                    //    Console.WriteLine("Transaction status is updated to Canceled in Transaction History");
                    //}
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                //if (bTransStatusMatching)
                //{
                //    Console.WriteLine("Member Info page Transaction status is updated to Canceled in Transaction History table");
                //}

                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                //else
                //{


                //    //Click next page link and start over.
                //    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                //    {
                //        thisTP.bNotAtLastPageOfRecords = true;
                //        thisTP.NPL.Click();
                //        tmsWait.Hard(2);
                //    }
                //}
                baseTable = EAM.Letters.LettersTableNew;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportPassOnNotMatching(thisGT.GTable);
                }
            }

        }


        [Then(@"Letters Queue Page has row")]
        public void ThenLettersQueuePageHasRow(Table table)
        {
            tmsWait.Hard(5);
            Boolean bHaveFailFromAlreadyProcessingMessage = false;
            try
            {
                string message = EAM.LettersPostCMS.LettersMessage.Text;
                if (message == "Not allowed: You are already processing the same task from another browser.")
                {
                    bHaveFailFromAlreadyProcessingMessage = true;
                }
            }
            catch
            {
            }
            if (bHaveFailFromAlreadyProcessingMessage)
            {
                Assert.Fail("Fail For Processing message: [Not allowed: You are already processing the same task from another browser.]");
            }

            try
            {
                IWebElement objWebTable = EAM.Letters.LettersTableNew;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Letters Queue Page has row: {0}", e.Message);
            }
        }



        [Then(@"Letters Queue Page Send checkbox is checked")]
        public void ThenLettersQueuePageSendCheckboxIsChecked(Table table)
        {

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.Letters.OldLettersQueueTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            if (bThisRowMatches)
                            {
                                IWebElement thisEditTD = ApplicationRow.Element[5];
                                //string script = "<script type='text/javascript'>alert('" + thisEditTD + "');</script>";
                                //IWebElement thisEditLink = thisEditTD.FindElement(By.TagName("a"));
                                IWebElement thischeckbox = thisEditTD.FindElement(By.XPath("//input[@type='checkbox']"));
                                thischeckbox.Click();
                                tmsWait.Hard(2);



                                //if(thischeckbox.Selected)
                                //{



                                //if (setCheckboxTo.Equals("UnChecked"))
                                //{
                                //    if (EAM.AdministrationStatusoverride.SearchForTransactionCheckbox.Selected == true)
                                //    {
                                //        EAM.AdministrationStatusoverride.SearchForTransactionCheckbox.Click();
                                //    }
                                //}
                                //else if (setCheckboxTo.Equals("checked"))
                                //{
                                //    if (EAM.AdministrationStatusoverride.SearchForTransactionCheckbox.Selected == false)
                                //    {
                                //        EAM.AdministrationStatusoverride.SearchForTransactionCheckbox.Click();
                                //    }
                                //}

                            }

                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.Letters.OldLettersQueueTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

        [When(@"Letter Queue page Plan ID is set to ""(.*)""")]
        public void WhenLetterQueuePagePlanIDIsSetTo(string planid)
        {
            IWebElement plan = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPlan"));
            new SelectElement(plan).SelectByText(planid);
            tmsWait.Hard(3);
        }

        [When(@"Letter Queue page Go button is Clicked")]
        public void WhenLetterQueuePageGoButtonIsClicked()
        {
            IWebElement Go = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnGo"));
            fw.ExecuteJavascript(Go);
            tmsWait.Hard(3);

        }
        [When(@"Letter Queue page DeSelect All button is Clicked")]
        public void WhenLetterQueuePageDeSelectAllButtonIsClicked()
        {
            IWebElement deSelectAll = Browser.Wd.FindElement(By.LinkText("DeSelect All"));
            fw.ExecuteJavascript(deSelectAll);
            //tmsWait.Hard(3);
        }


        [When(@"Letter Queue page MBI ""(.*)"" row is Selected and Clicked on Send button")]
        public void WhenLetterQueuePageMBIRowIsSelectedAndClickedOnSendButton(string p0)
        {
            string mbi = tmsCommon.GenerateData(p0).ToUpper();
            tmsWait.Hard(3);
            IWebElement sendCheckbox = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_dgLetters']//tr/td[contains(.,'" + mbi + "')]/following-sibling::td[3]//input[@type='checkbox']"));
            fw.ExecuteJavascript(sendCheckbox);
            tmsWait.Hard(2);
        }

        [When(@"Letter Queue Page Preview button is Clicked")]
        public void WhenLetterQueuePagePreviewButtonIsClicked()
        {
            IWebElement preView = Browser.Wd.FindElement(By.XPath("//input[@value='Preview']"));
            fw.ExecuteJavascript(preView);
            tmsWait.Hard(10);
            Browser.SwitchToChildWindow();
            Browser.SwitchToIFrame();
            //IWebElement plugin = Browser.Wd.FindElement(By.XPath("//embed[@id='plugin']"));
            //fw.ExecuteJavascript(plugin);
            string reportPagesource = Browser.Wd.PageSource;
            string reportURL = Browser.Wd.FindElement(By.Id("plugin")).GetAttribute("src");
            if (reportURL != null)
            {
                Assert.IsTrue(true, " Letter is Previewed successfully");
            }

            Browser.SwitchToParentWindow();
        }


        [Then(@"Verify Administration Status Override page Response Message ""(.*)"" is displayed")]
        public void ThenVerifyAdministrationStatusOverridePageResponseMessageIsDisplayed(string p0)
        {
            string TransStatusText = EAM.AdministrationStatusoverride.TransactionTable_TransStatus.Text;
            if (TransStatusText != "Accepted by CMS")
            {
                tmsWait.Hard(2);
                string fieldValue = EAM.AdministrationStatusoverride.ResponseMessage.Text;
                Console.WriteLine("Verify Members status Static Message: Expected [{0}], Actual [{1}]", p0, fieldValue);
                Assert.IsTrue(fieldValue.Contains(p0), "Expected New Static Message is displayed");
                // Assert.IsTrue(String.Compare(fieldValue, p0) == 0, "Verify Members New Static Message: Expected [{0}], Actual [{1}]", p0, fieldValue);
            }
        }

        [Then(@"Verify Administration Status Override page Response Message contains ""(.*)""")]
        public void ThenVerifyAdministrationStatusOverridePageResponseMessageContains(string p0)
        {
            tmsWait.Hard(3);
            string actualmsg = EAM.AdministrationStatusoverride.ResponseMessage.Text;
            Boolean correctmsg = actualmsg.Contains(p0);
            Assert.IsTrue(correctmsg);
        }

        [Then(@"Transactions tab Table has row")]
        public void ThenTransactionsTabTableHasRow(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.MembersSearch.MemberSearchTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Members View Edit Table has row: {0}", e.Message);
            }
        }

        //Gurdeep Arora
        [Given(@"verify Administration Status Override Table has row")]
        [When(@"verify Administration Status Override Table has row")]
        [Then(@"verify Administration Status Override Table has row")]
        public void GivenVerifyAdministrationStatusOverrideTableHasRow(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.AdministrationStatusoverride.TransactionSearchTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Members View Edit Table has row: {0}", e.Message);
            }
        }



        [Then(@"Member Info page Transactions History Table Edit Icon is clicked for row")]
        public void ThenMemberInfoPageTransactionsHistoryTableEditIconIsClickedForRow(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.MemberInformation.TransactionHistoryTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index > 0)
                        {
                            index++;
                            string xPath = "//tr[" + index + "]//img[@alt='Edit']";
                            IWebElement editIcon = EAM.MemberInformation.TransactionHistoryTable.FindElement(By.XPath(xPath));
                            editIcon.Click();
                            try
                            {
                                editIcon.SendKeys(OpenQA.Selenium.Keys.Enter);
                            }
                            catch (Exception) { }
                            tmsWait.Hard(2);
                            tmsWait.WaitForReadyStateComplete(30);
                            IWebElement objHIC = tmsWait.WaitForElementExist(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtHic_01"), 30);
                            Console.WriteLine("Edit icon was clicked");
                        }
                        else { Assert.Fail("Edit Icon for expected row was not found"); }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("New1: {0}", e.Message);
            }



        }

        [When(@"Administration Status Override Page Member Check box is set to ""(.*)""")]
        public void GivenAdministrationStatusOverridePageMemberCheckBoxIsSetTo(string p0)
        {

            string GenerateData = tmsCommon.GenerateData(p0);


            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("UnChecked"))
            {
                if (EAM.AdministrationStatusoverride.SearchForMemberCheckbox.Selected == true)
                {
                    EAM.AdministrationStatusoverride.SearchForMemberCheckbox.Click();
                }
            }
            else if (setCheckboxTo.Equals("checked"))
            {
                if (EAM.AdministrationStatusoverride.SearchForMemberCheckbox.Selected == false)
                {
                    EAM.AdministrationStatusoverride.SearchForMemberCheckbox.Click();
                }
            }



            //Get the state of the checkbox
            //Look at P0 to see what it should be
            //Set it if it is not already correct.


            //switch (thisActiveCBValue.ToLower())
            //{
            //    case "checked": { setCheckboxTo = "true"; break; }
            //    case "on": { setCheckboxTo = "true"; break; }
            //    case "yes": { setCheckboxTo = "true"; break; }
            //    case "unchecked": { setCheckboxTo = null; break; }
            //    case "off": { setCheckboxTo = null; break; }
            //    case "no": { setCheckboxTo = null; break; }
            //}

            //Get the state of the checkbox
            //Look at P0 to see what it should be
            //Set it if it is not already correct.

        }





        [When(@"Administration Status Override page Search button is clicked")]
        public void WhenAdministrationStatusOverridePageSearchButtonIsClicked()
        {
            EAM.AdministrationStatusoverride.SearchButton.Click();
            tmsWait.Hard(5);
        }

        [When(@"I clicked on Edit icon on ""(.*)"" Search results")]
        public void WhenIClickedOnEditIconOnSearchResults(string p0)
        {
            if (p0 == "Member")
            {
                EAM.AdministrationStatusoverride.MemberEditIcon.Click();
            }

            else if (p0 == "Transaction")
            {
                EAM.AdministrationStatusoverride.TransEditIcon.Click();
            }
            else
            {
                Console.WriteLine(" Please provide correct Edit icon name ");
            }
        }

        [When(@"Verify Member Search page displays message as ""(.*)""")]
        public void WhenVerifyMemberSearchPageDisplaysMessageAs(string p0)
        {
            tmsWait.Hard(3);
            IWebElement actual = Browser.Wd.FindElement(By.XPath("//div[@id='eamBodyContainer']/p[contains(.,'" + p0 + "')]"));
            Assert.IsTrue(actual.Displayed, p0 + "is not getting displayed");
        }


        [When(@"Members View Edit Page Search button is Clicked")]
        [Then(@"Members View Edit Page Search button is Clicked")]
        [Given(@"Members View Edit Page Search button is Clicked")]
        public void WhenMembersViewEditPageSearchButtonIsClicked()
        {
            fw.ExecuteJavascript(EAM.MembersSearch.Search);
            tmsWait.Hard(2);
        }

        [When(@"Administration Status Override Page Transaction Check box is set to ""(.*)""")]
        public void WhenAdministrationStatusOverridePageTransactionCheckBoxIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string GenerateData = tmsCommon.GenerateData(p0);
            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("UnChecked"))
            {
                if (EAM.AdministrationStatusoverride.SearchForTransactionCheckbox.Selected == true)
                {
                    fw.ExecuteJavascript(EAM.AdministrationStatusoverride.SearchForTransactionCheckbox);
                }
            }
            else if (setCheckboxTo.Equals("checked"))
            {
                if (EAM.AdministrationStatusoverride.SearchForTransactionCheckbox.Selected == false)
                {
                    fw.ExecuteJavascript(EAM.AdministrationStatusoverride.SearchForTransactionCheckbox);
                }
            }
        }

        // Why do we need two defection of same Gherkin statement. To close the browser please user existing code only. I have hide code. If you have any troble please reach out me.
        //[When(@"Browser will be closed")]
        //[Then(@"Browser will be closed")]
        //public void WhenBrowserWillBeClosed()
        //{
        //    Browser.Wd.Close();
        //}
        [When(@"Administration Status Override Page Member Search Table Edit Link is clicked for first row")]
        public void WhenAdministrationStatusOverridePageMemberSearchTableEditLinkIsClickedForFirstRow()
        {
            IWebElement actual = Browser.Wd.FindElement(By.XPath("//a[@href='javascript:__doPostBack('ctl00$ctl00$MainMasterContent$MainContent$dgTrans$ctl02$ctl00','')')]"));
            actual.Click();
        }



        [When(@"Administration Status Override Page Member Search Table Edit Link is clicked")]
        public void WhenAdministrationStatusOverridePageMemberSearchTableEditLinkIsClicked(Table table)
        {

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.AdministrationStatusoverride.MemberSearchTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            if (bThisRowMatches)
                            {
                                IWebElement thisEditTD = ApplicationRow.Element[8];
                                IWebElement thisEditLink = thisEditTD.FindElement(By.TagName("a"));
                                thisEditLink.Click();
                                tmsWait.Hard(2);

                            }

                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.AdministrationStatusoverride.MemberSearchTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }




        [When(@"Administration Status Override page New DisEnrollment Reason is set to ""(.*)""")]
        public void WhenAdministrationStatusOverridePageNewDisEnrollmentReasonIsSetTo(int p0)
        {
            String DisEnrollmentReason = p0.ToString();
            EAM.AdministrationStatusoverride.DisEnrollmentReason.Clear();
            EAM.AdministrationStatusoverride.DisEnrollmentReason.SendKeys(DisEnrollmentReason);

        }
        [Then(@"Verify Transaction View Edit Page Transaction Status is set to ""(.*)""")]
        public void ThenVerifyTransactionViewEditPageTransactionStatusIsSetTo(string p0)
        {

            string fieldName = "Transaction Status";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MemberInformation.MemberInfoTransStatus.GetAttribute("value");

            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");

        }

        [Then(@"Verify Transaction View Edit Page ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyTransactionViewEditPageIsSetTo(string fieldName, string valuetoBechecked)
        {
            string actualValue = string.Empty;
            if (fieldName.ToLower() == "trr response date")
            {
                actualValue = EAM.MemberInformation.TRRResponseDate.Text;
                Assert.AreEqual(valuetoBechecked, EAM.MemberInformation.TRRResponseDate.Text, fieldName + " value is " + actualValue);
            }
            else if (fieldName.ToLower() == "user modified")
            {
                actualValue = EAM.MemberInformation.MemberInfoUserModified.Text;
                Assert.AreEqual(valuetoBechecked, EAM.MemberInformation.MemberInfoUserModified.Text, fieldName + " value is " + actualValue);
            }
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + actualValue + "], expected [" + valuetoBechecked + "] - They are expected to match.");
        }






        [Then(@"Verify Transaction View Edit Page Reply Code is set to""(.*)""")]
        public void ThenVerifyTransactionViewEditPageReplyCodeIsSetTo(string p0)
        {
            string fieldName = "Reply Code";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MemberInformation.MemberInfoReplyCode.GetAttribute("value");

            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [Then(@"Verify Transaction View Edit Page Reply Description is set to""(.*)""")]
        public void ThenVerifyTransactionViewEditPageReplyDescriptionIsSetTo(string p0)
        {
            string fieldName = "Reply Description";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.MemberInformation.MemberInfoReplyDesc.GetAttribute("value");

            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }


        [Then(@"Verify Transaction View Edit Page Date Modified is set to Current Date")]
        public void ThenVerifyTransactionViewEditPageDateModifiedIsSetToCurrentDate()
        {

            string fieldName = "Date Modified";
            string currentdate = DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString();
            DateTime currentdateDTF = DateTime.Now;

            string thisFieldValue = EAM.MemberInformation.DateModified.Text;
            DateTime fieldDT = DateTime.Parse(thisFieldValue);
            var hours = (fieldDT - currentdateDTF).TotalHours;
            //The server time won't necessarily be same as the desktop time (1hr or 2hrs usually), so we will accept anything within 4 hours
            Assert.AreEqual(true, hours < 4, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + currentdate + "]");
            //   Assert.AreEqual(true, currentdate == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + currentdate + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + currentdate + "] - They are expected to be within 4 hours (accounting for server time vs execution machine time).");
        }


        [Then(@"Verify Transaction View Edit Page T/RR Response Date is set to Reply Date")]
        public void ThenVerifyTransactionViewEditPageTRRResponseDateIsSetToReplyDate()
        {
            string fieldName = "T/RR Response Date";

            var ReplyDate = GlobalRef.ReplyDate;

            String ReplyDateStr = ReplyDate.ToString();

            string thisFieldValue = EAM.MemberInformation.TRRResponseDate.Text;

            Assert.AreEqual(true, ReplyDateStr.Equals(thisFieldValue), "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + ReplyDate + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + ReplyDate + "] - They are expected to match.");
        }

        [When(@"Letter count for Confirmation of Disenrollment Due to Passive Enrollment into a Medicare-Medicaid Plan queue is set to ""(.*)""")]
        public void WhenLetterCountForConfirmationOfDisenrollmentDueToPassiveEnrollmentIntoAMedicare_MedicaidPlanQueueIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.MembersSearch.HICNumber.SendKeys(GeneratedData);
        }

        [Then(@"Verify Home Page Letter count for Acknowledgment of Enrollment in Another Plan Letter is decreased for First Time")]
        public void ThenVerifyHomePageLetterCountForAcknowledgmentOfEnrollmentInAnotherPlanLetterIsDecreasedForFirstTime(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.Letters.LettersQueueTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            try
                            {
                                if (bThisRowMatches)
                                {
                                    IWebElement thisEditTD = ApplicationRow.Element[0];
                                    IWebElement thisEditLink = thisEditTD.FindElement(By.XPath("//a[contains(@href,'reports/reportmain_letterqueue.aspx?code=011&type=1&hImg=imagePreCMS&hDiv=divPreCMS')]"));

                                    GlobalRef.FirstLetterCount = Int32.Parse(thisEditLink.Text);
                                    var firstcount = GlobalRef.FirstLetterCount;
                                    var initcount = GlobalRef.InitialLetterCount;

                                    Console.WriteLine("After Loading TRR file First Time Letter Count for Acknowledgment of Enrollment in Another Plan Letter queue : " + thisEditLink.Text);


                                    int initiallettercount = Convert.ToInt32(initcount);
                                    int firstlettercount = Convert.ToInt32(firstcount);


                                    Assert.IsTrue((initiallettercount > firstlettercount), "Letter Count for Acknowledgment of Enrollment in Another Plan Letter is Decreased by 1");




                                    tmsWait.Hard(2);


                                }
                            }
                            catch
                            {
                                GlobalRef.LetterCount = 0;
                            }


                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.Letters.LettersQueueTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }


        [Then(@"Verify Home Page Letter count for Acknowledgment of Enrollment Letter is decreased for First Time")]
        public void ThenVerifyHomePageLetterCountForAcknowledgmentOfEnrollmentLetterIsDecreasedForFirstTime(Table table)
        {

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.Letters.LettersQueueTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            try
                            {
                                if (bThisRowMatches)
                                {
                                    IWebElement thisEditTD = ApplicationRow.Element[0];
                                    IWebElement thisEditLink = thisEditTD.FindElement(By.XPath("//a[contains(@href,'reports/reportmain_letterqueue.aspx?code=001&type=1&hImg=imagePreCMS&hDiv=divPreCMS')]"));

                                    GlobalRef.FirstLetterCount = Int32.Parse(thisEditLink.Text);
                                    var firstcount = GlobalRef.FirstLetterCount;
                                    var initcount = GlobalRef.InitialLetterCount;

                                    Console.WriteLine("After Loading TRR file First Time Letter Count for Acknowledgment of Enrollment Letter queue : " + thisEditLink.Text);


                                    int initiallettercount = Convert.ToInt32(initcount);
                                    int firstlettercount = Convert.ToInt32(firstcount);


                                    Assert.IsTrue((initiallettercount > firstlettercount), "Letter Count for Acknowledgment of Enrollment Letter is Decreased by 1");
                                                                      



                                    tmsWait.Hard(2);


                                }
                            }
                            catch
                            {
                                GlobalRef.LetterCount = 0;
                            }


                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.Letters.LettersQueueTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }

        }



        [Then(@"Verify Home Page Letter count for Acknowledgment of Enrollment in Another Plan Letter is increased for Second Time")]
        public void ThenVerifyHomePageLetterCountForAcknowledgmentOfEnrollmentInAnotherPlanLetterIsIncreasedForSecondTime(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.Letters.LettersQueueTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            try
                            {
                                if (bThisRowMatches)
                                {
                                    IWebElement thisEditTD = ApplicationRow.Element[0];
                                    IWebElement thisEditLink = thisEditTD.FindElement(By.XPath("//a[contains(@href,'reports/reportmain_letterqueue.aspx?code=011&type=1&hImg=imagePreCMS&hDiv=divPreCMS')]"));


                                    GlobalRef.SecondLetterCount = Int32.Parse(thisEditLink.Text);
                                    var firstcount = GlobalRef.FirstLetterCount;
                                    var secondcount = GlobalRef.SecondLetterCount;

                                    Console.WriteLine("Second time Letter Count for Acknowledgment of Enrollment in Another Plan Letter queue : " + thisEditLink.Text);


                                    int secondlettercount = Convert.ToInt32(secondcount);
                                    int firstlettercount = Convert.ToInt32(firstcount);


                                    Assert.IsTrue((secondlettercount == firstlettercount), "Letter Count for Acknowledgment of Enrollment in Another Plan Letter is Increased by 1");

                                    


                                    tmsWait.Hard(2);


                                }
                            }
                            catch
                            {
                                GlobalRef.LetterCount = 0;
                            }


                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.Letters.LettersQueueTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }



        [Then(@"Verify Home Page Letter count for Acknowledgment of Enrollment Letter is increased for Second Time")]
        public void ThenVerifyHomePageLetterCountForAcknowledgmentOfEnrollmentLetterIsIncreasedForSecondTime(Table table)
        {

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.Letters.LettersQueueTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            try
                            {
                                if (bThisRowMatches)
                                {
                                    IWebElement thisEditTD = ApplicationRow.Element[0];
                                    IWebElement thisEditLink = thisEditTD.FindElement(By.XPath("//a[contains(@href,'reports/reportmain_letterqueue.aspx?code=001&type=1&hImg=imagePreCMS&hDiv=divPreCMS')]"));


                                    GlobalRef.SecondLetterCount = Int32.Parse(thisEditLink.Text);
                                    var firstcount = GlobalRef.FirstLetterCount;
                                    var secondcount = GlobalRef.SecondLetterCount;

                                    Console.WriteLine("Second time Letter Count for Acknowledgment of Enrollment Letter queue : " + thisEditLink.Text);


                                    int secondlettercount = Convert.ToInt32(secondcount);
                                    int firstlettercount = Convert.ToInt32(firstcount);


                                    Assert.IsTrue((secondlettercount == firstlettercount), "Letter Count for Acknowledgment of Enrollment Letter is Increased by 1");

                                   


                                    tmsWait.Hard(2);


                                }
                            }
                            catch
                            {
                                GlobalRef.LetterCount = 0;
                            }


                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.Letters.LettersQueueTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

        [Then(@"Verify Home Page Letter count for Acknowledgment of Enrollment in Another Plan Letter is increased")]
        public void ThenVerifyHomePageLetterCountForAcknowledgmentOfEnrollmentInAnotherPlanLetterIsIncreased(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.Letters.LettersQueueTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            try
                            {
                                if (bThisRowMatches)
                                {
                                    IWebElement thisEditTD = ApplicationRow.Element[0];
                                    IWebElement thisEditLink = thisEditTD.FindElement(By.XPath("//a[contains(@href,'reports/reportmain_letterqueue.aspx?code=011&type=1&hImg=imagePreCMS&hDiv=divPreCMS')]"));


                                    GlobalRef.finalLetterCount = Int32.Parse(thisEditLink.Text);
                                    var finalcount = GlobalRef.finalLetterCount;
                                    var initcount = GlobalRef.InitialLetterCount;

                                    Console.WriteLine("final Letter Count for Acknowledgment of Enrollment in Another Plan Letter queue : " + thisEditLink.Text);


                                    int initiallettercount = Convert.ToInt32(initcount);
                                    int finallettercount = Convert.ToInt32(finalcount);

                                    Assert.IsTrue((initiallettercount < finallettercount), "Letter Count for Acknowledgment of Enrollment in Another Plan Letter is Increased");

                                    //if (initiallettercount < finallettercount)
                                    //{

                                    //    Console.WriteLine(" Letter Count for Acknowledgment of Enrollment Letter is Increased");
                                    //}

                                    //else
                                    //{
                                    //    Console.WriteLine(" Letter Count for Acknowledgment of Enrollment Letter is not getting Increased");
                                    //}



                                    tmsWait.Hard(2);


                                }
                            }
                            catch
                            {
                                GlobalRef.LetterCount = 0;
                            }


                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.Letters.LettersQueueTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }



        [Then(@"Verify Home Page Letter count for Confirmation of Enrollment in Another Plan Letter is increased")]
        public void ThenVerifyHomePageLetterCountForConfirmationOfEnrollmentInAnotherPlanLetterIsIncreased(Table table)
        {

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.Letters.LettersQueueTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            try
                            {
                                if (bThisRowMatches)
                                {
                                    IWebElement thisEditTD = ApplicationRow.Element[0];
                                    IWebElement thisEditLink = thisEditTD.FindElement(By.XPath("//a[contains(@href,'reports/reportmain_letterqueue.aspx?code=012&type=2&hImg=imagePostCMS&hDiv=divPostCMS')]"));


                                    GlobalRef.finalLetterCount = Int32.Parse(thisEditLink.Text);
                                    var finalcount = GlobalRef.finalLetterCount;
                                    var initcount = GlobalRef.InitialLetterCount;

                                    Console.WriteLine("final Letter Count for Confirmation of Enrollment in Another Plan Letter queue : " + thisEditLink.Text);


                                    int initiallettercount = Convert.ToInt32(initcount);
                                    int finallettercount = Convert.ToInt32(finalcount);

                                    Assert.IsTrue((initiallettercount < finallettercount), "Letter Count for Confirmation of Enrollment in Another Plan Letter is Increased");

                                    //if (initiallettercount < finallettercount)
                                    //{

                                    //    Console.WriteLine(" Letter Count for Acknowledgment of Enrollment Letter is Increased");
                                    //}

                                    //else
                                    //{
                                    //    Console.WriteLine(" Letter Count for Acknowledgment of Enrollment Letter is not getting Increased");
                                    //}



                                    tmsWait.Hard(2);


                                }
                            }
                            catch
                            {
                                GlobalRef.LetterCount = 0;
                            }


                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.Letters.LettersQueueTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

        [Then(@"Verify Home Page Letter count for Outbound Enrollment Verification Letter  has remain same")]
        public void ThenVerifyHomePageLetterCountForOutboundEnrollmentVerificationLetterHasRemainSame(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.Letters.LettersQueueTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data

                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;

                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;


                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                                IWebElement thisEditTD = ApplicationRow.Element[0];
                                IWebElement thisEditLink = thisEditTD.FindElement(By.XPath("//a[contains(@href,'reports/reportmain_letterqueue.aspx?code=032&type=1')]"));
                                GlobalRef.MidOEVLetterCount = thisEditLink.Text;

                                Console.WriteLine("Letter Count for Outbound Enrollment Verification Letter queue : " + thisEditLink.Text);
                            }
                            try
                            {
                                if (bThisRowMatches)
                                {
                                    IWebElement thisEditTD = ApplicationRow.Element[0];
                                    IWebElement thisEditLink = thisEditTD.FindElement(By.XPath("//a[contains(@href,'reports/reportmain_letterqueue.aspx?code=032&type=1')]"));


                                    GlobalRef.MidOEVLetterCount = thisEditLink.Text;
                                    var finalcount = GlobalRef.MidOEVLetterCount;
                                    var initcount = GlobalRef.BeforeOEVLetterCount;

                                    Console.WriteLine("Letter Count for Outbound Enrollment Verification Letter queue : " + thisEditLink.Text);


                                    int initiallettercount = Convert.ToInt32(initcount);
                                    int finallettercount = Convert.ToInt32(finalcount);

                                    Assert.IsTrue(initiallettercount == finallettercount, "Letter Count for Outbound Enrollment Verification Letter has the same");




                                    tmsWait.Hard(2);


                                }
                            }
                            catch
                            {
                                GlobalRef.LetterCount = 0;
                            }


                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {

                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.Letters.LettersQueueTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.

                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    //IWebElement thisEditTD = ApplicationRow.Element[0];




                    var finalcount = GlobalRef.MidOEVLetterCount;
                    var initcount = GlobalRef.BeforeOEVLetterCount;



                    int initiallettercount = Convert.ToInt32(initcount);
                    int finallettercount = Convert.ToInt32(finalcount);

                    Assert.IsTrue(initiallettercount == finallettercount, "Letter Count for Outbound Enrollment Verification Letter has the same");
                    break;
                    //thisTP.ReportNotMatching(thisGT.GTable);
                }
            }



        }



        [Then(@"Verify Home Page Letter count for Outbound Enrollment Verification Letter is not increased further")]
        public void ThenVerifyHomePageLetterCountForOutboundEnrollmentVerificationLetterIsNotIncreasedFurther(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.Letters.LettersQueueTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            try
                            {
                                if (bThisRowMatches)
                                {
                                    IWebElement thisEditTD = ApplicationRow.Element[0];
                                    IWebElement thisEditLink = thisEditTD.FindElement(By.XPath("//a[contains(@href,'reports/reportmain_letterqueue.aspx?code=032&type=1')]"));
                                    GlobalRef.furtherOEVLetterCount = thisEditLink.Text;
                                    //Console.WriteLine("Now Letter Count for Outbound Enrollment Verification queue : " + thisEditLink.Text);
                                    tmsWait.Hard(2);

                                    var furthercount = GlobalRef.furtherOEVLetterCount;
                                    var finalcount = GlobalRef.finalOEVLetterCount;

                                    int finallettercount = Convert.ToInt32(finalcount);
                                    int furtherlettercount = Convert.ToInt32(furthercount);
                                    bool result = (finallettercount.CompareTo(furtherlettercount) == 0);
                                    //(initiallettercount == Nowlettercount);
                                    Assert.AreEqual(result, false, "Letter Count for Outbound Enrollment Verification Letter has not same");
                                    Console.WriteLine("Now Letter Count for Outbound Enrollment Verification queue " + GlobalRef.furtherOEVLetterCount);

                                }
                            }
                            catch
                            {
                                GlobalRef.LetterCount = 0;


                            }


                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.Letters.LettersQueueTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    GlobalRef.NowOEVLetterCount = 0;
                    

                    var Nowcount1 = GlobalRef.NowOEVLetterCount;
                    var initcount1 = GlobalRef.BeforeOEVLetterCount;
                    int initiallettercount1 = Convert.ToInt32(initcount1);
                    int Nowlettercount1 = Convert.ToInt32(Nowcount1);
                    bool result1 = (initiallettercount1 == Nowlettercount1);
                    Assert.AreEqual(result1, true, "Letter Count for Outbound Enrollment Verification Letter has the same");
                    Console.WriteLine("Now Letter Count for Outbound Enrollment Verification queue " + GlobalRef.NowOEVLetterCount);
                    //As There is no match with gherkin table so breaking loop - Venkatesh P
                    break;

                }
            }


        }


        [Then(@"Verify Home Page Letter count for ""(.*)"" is increased")]
        public void ThenVerifyHomePageLetterCountForIsIncreased(string letter)
        {
            By letterCount = By.XPath("//td[contains(.,'" + letter + "')]/preceding-sibling::td/a");
            letter = tmsCommon.GenerateData(letter);
            tmsWait.Hard(2);
            GlobalRef.FinalLetterCount = Int32.Parse(Browser.Wd.FindElement(letterCount).Text);
            fw.ConsoleReport("Final Letter Count for " + letter + " queue : " + GlobalRef.FinalLetterCount.ToString());
            var finalcount = GlobalRef.FinalLetterCount;
            var initcount = GlobalRef.InitialLetterCount;
            int initiallettercount = Convert.ToInt32(initcount);
            int finallettercount = Convert.ToInt32(finalcount);
            bool res = (initiallettercount < finallettercount);
            Assert.IsTrue(res, "Letter Count for " + letter + " Letter is Increased");
        }



        [Then(@"Verify Home Page Letter count for Outbound Enrollment Verification Letter  is increased")]
        public void ThenVerifyHomePageLetterCountForOutboundEnrollmentVerificationLetterIsIncreased(Table table)
        {

            IWebElement lettersImg = Browser.Wd.FindElement(By.CssSelector("[test-id='eamDashboard-img-letters']"));
            fw.ExecuteJavascript(lettersImg);
            tmsWait.Hard(1);

            By lettercountelem;

            string letterCount;
            try
            {
                lettercountelem = By.XPath("//label[contains(.,'Outbound Enrollment Verification Letter')]/parent::div/preceding-sibling::div/label");
                if (Browser.Wd.FindElement(lettercountelem).Displayed)
                {
                    letterCount = Browser.Wd.FindElement(lettercountelem).Text;
                    fw.ConsoleReport("Outbound Enrollment Verification Letter count -->" + letterCount);
                    GlobalRef.finalOEVLetterCount = letterCount;
                }
            }
            catch
            {
                try
                {
                    lettercountelem = By.XPath("//label[contains(.,'Outbound Enrollment Verification Letter')]/parent::div/preceding-sibling::div/a");
                    if (Browser.Wd.FindElement(lettercountelem).Displayed)
                    {
                        letterCount = Browser.Wd.FindElement(lettercountelem).Text;
                        fw.ConsoleReport(" Outbound Enrollment Verification Letter  count -->" + letterCount);
                        GlobalRef.finalOEVLetterCount = letterCount;

                    }
                }
                catch
                {
                    GlobalRef.finalOEVLetterCount = "0";
                }
            }

            var finalcount = GlobalRef.finalOEVLetterCount;
            var initcount = GlobalRef.BeforeOEVLetterCount;
            int initiallettercount = Convert.ToInt32(initcount);
            int finallettercount = Convert.ToInt32(finalcount);
            fw.ConsoleReport(" Initial Letter Count  " + initcount);
            fw.ConsoleReport(" Final Letter Count  " + finalcount);
            bool res = (initiallettercount < finallettercount);
            Assert.IsTrue(res, "  Letters count are getting increased");


           


        }



        [Then(@"Verify Home Page Letter count for ""(.*)"" is same")]
        public void ThenVerifyHomePageLetterCountForIsSame(string letter)
        {
            By lettercountelem;

            string letterCount;
            try
            {
                lettercountelem = By.XPath("//label[contains(.,'" + letter + "')]/parent::div/preceding-sibling::div/label");
                if (Browser.Wd.FindElement(lettercountelem).Displayed)
                {
                    letterCount = Browser.Wd.FindElement(lettercountelem).Text;
                    fw.ConsoleReport(letter + " Letter count -->" + letterCount);
                    GlobalRef.FinalLetterCount = Int32.Parse(letterCount);
                }
            }
            catch
            {
                try
                {
                    lettercountelem = By.XPath("//label[contains(.,'" + letter + "')]/parent::div/preceding-sibling::div/a");
                    if (Browser.Wd.FindElement(lettercountelem).Displayed)
                    {
                        letterCount = Browser.Wd.FindElement(lettercountelem).Text;
                        fw.ConsoleReport(letter + " Letter count -->" + letterCount);
                        GlobalRef.FinalLetterCount = Int32.Parse(letterCount);

                    }
                }
                catch
                {
                    GlobalRef.FinalLetterCount = 0;
                }
            }

            var finalcount = GlobalRef.FinalLetterCount;
            var initcount = GlobalRef.InitialLetterCount;
            int initiallettercount = Convert.ToInt32(initcount);
            int finallettercount = Convert.ToInt32(finalcount);
            fw.ConsoleReport(" Initial Letter Count  " + initcount);
            fw.ConsoleReport(" Final Letter Count  " + finalcount);
            bool res = (initiallettercount == finallettercount);
            Assert.IsTrue(res, " Both Letters count are not matching");



           



        }

        [Then(@"Verify Home Page Letter count for Outbound Enrollment Verification Letter is same")]
        public void ThenVerifyHomePageLetterCountForOutboundEnrollmentVerificationLetterIsSame(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.Letters.LettersQueueTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            try
                            {
                                if (bThisRowMatches)
                                {
                                    IWebElement thisEditTD = ApplicationRow.Element[0];
                                    IWebElement thisEditLink = thisEditTD.FindElement(By.XPath("//a[contains(@href,'reports/reportmain_letterqueue.aspx?code=032&type=1')]"));


                                    GlobalRef.finalOEVLetterCount = thisEditLink.Text;
                                    var finalcount = GlobalRef.finalOEVLetterCount;
                                    var initcount = GlobalRef.BeforeOEVLetterCount;

                                    Console.WriteLine("final Letter Count for Outbound Enrollment Verification Letter queue : " + thisEditLink.Text);


                                    int initiallettercount = Convert.ToInt32(initcount);
                                    int finallettercount = Convert.ToInt32(finalcount);
                                    bool res = (initiallettercount == finallettercount);
                                    Assert.IsTrue(res, "Letter Count for Outbound Enrollment Verification Letter is Same with Initial Count");


                                    tmsWait.Hard(2);


                                }
                            }
                            catch
                            {
                                GlobalRef.LetterCount = 0;
                            }


                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.Letters.LettersQueueTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.

                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    fw.ConsoleReport("Count for Outbound Enrollment Verification Letter is not increased by 1");
                    break;
                    //thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

        [When(@"Letter Queue for Outbound Enrollment Verification Letter is cleared")]
        public void WhenLetterQueueForOutboundEnrollmentVerificationLetterIsCleared()
        {
            clickonDashboardSection(); // Click on Dashboard

            tmsWait.Hard(2);
            dashBoardLettersLink();  // Click on Dashboard Letter link
            By lettercountelem;
            By toggleRemove;
            By Remove;
            By oevletterlink;
            By NoLetterQueue;
            String notallowed;
            string letterCount = "0";
            // Checking Letter Presence or not
            try
            {
                lettercountelem = By.XPath("//label[contains(.,'Outbound Enrollment Verification Letter')]/parent::div/preceding-sibling::div/a");
                if (Browser.Wd.FindElement(lettercountelem).Displayed)
                {
                    letterCount = Browser.Wd.FindElement(lettercountelem).Text;
                    fw.ConsoleReport(" Current OEV Letter count -->" + letterCount);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(lettercountelem));  // Clicking on Letter count
                }
            }
            catch
            {
                
                fw.ConsoleReport("Outbound Enrollment Verification Letter is not ON under EAM Configuration");
            }


            if (Convert.ToInt32(letterCount) > 0)  // Clearing the Queue
            {
                By NotAllowedMsg = By.XPath("//label[@test-id='letter-lbl-jobSessionMsg'][contains(.,'Not allowed: You are already processing the same task from another browser.')]");

                try
                {
                    bool msgDisplay = Browser.Wd.FindElement(NotAllowedMsg).Displayed; // If not Allowed message presence

                    if (msgDisplay)
                    {
                        clearingLetterQueue();
                        clickonDashboardSection();

                        tmsWait.Hard(2);
                        dashBoardLettersLink();

                    }
                }
                catch
                {
                    fw.ConsoleReport(" There is no Not allowed: You are already processing the same task from another browser message ");
                }
                
                NoLetterQueue = By.XPath("//label[@test-id='letter-lbl-jobSessionMsg']");
                while (Browser.Wd.FindElement(NoLetterQueue).Text.Equals("Please check the members to run Report"))
                {


                    tmsWait.Hard(2);
                    toggleRemove = By.CssSelector("[test-id='letter-btn-toggleRemoveAll']");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(toggleRemove);
                    Remove = By.CssSelector("[test-id='letter-btn-remove']");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Remove);
                    tmsWait.Hard(2);
                    UIMODUtilFunctions.clickOnConfirmationYesDialog();

                    tmsWait.Hard(2);
                    oevletterlink = By.CssSelector("[test-id='outbound enrollment verification letter']");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(oevletterlink);
                }
            }


        }





        void clickonDashboardSection()
    {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement dashboard = Browser.Wd.FindElement(By.XPath("//div[@title='Dashboard']"));
                fw.ExecuteJavascript(dashboard);
            }
            else
            {
                IWebElement dashboard = Browser.Wd.FindElement(By.XPath("//a[@title='Dashboard']"));
                fw.ExecuteJavascript(dashboard);
            }
        }

     void dashBoardLettersLink()
        {
        IWebElement dashboardLetters = Browser.Wd.FindElement(By.CssSelector("[test-id='eamDashboard-img-letters']"));
    fw.ExecuteJavascript(dashboardLetters);
        }

         void clearingLetterQueue()
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@title='Administration']")));
                tmsWait.Hard(3);
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'Export Session')]")));
            }

            else
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@title='Administration']")));
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@title='Export Session']")));
            }

            By Msg = By.XPath("//span[contains(.,'Currently no user exporting a file.')]");
            bool deleteIconPresence = false;
            try
            {
                if (Browser.Wd.FindElement(Msg).Displayed)
                {
                    Assert.IsTrue(true);
                    fw.ConsoleReport(" There is no Session ");
                }

            }
            catch
            {
                while (!deleteIconPresence)
                {
                    try
                    {
                        //IWebElement delete = Browser.Wd.FindElement(By.XPath("(//span[@class='fa fa-trash']/parent::a)[1]"));
                        if (ConfigFile.tenantType.Equals("tmsx"))
                        {
                            IWebElement del = Browser.Wd.FindElement(By.XPath("//a[contains(@class,'remove')]"));
                            fw.ExecuteJavascript(del);
                        }

                        else
                        {
                            IWebElement delete = Browser.Wd.FindElement(By.XPath("//a[contains(@class,'Delete')]"));
                        fw.ExecuteJavascript(delete);
                        }

                        tmsWait.Hard(2);
                        UIMODUtilFunctions.clickOnConfirmationYesDialog();
                        tmsWait.Hard(2);

                        Browser.Wd.Navigate().Refresh();
                        tmsWait.Hard(8);

                    }
                    catch
                    {
                        deleteIconPresence = true;
                        fw.ConsoleReport(" There is no Session");
                    }
                }
            }

        }


        [Then(@"Verify ""(.*)"" Message is displayed")]
        public void ThenVerifyMessageIsDisplayed(string p0)
        {

            By NotAllowedMsg = By.XPath("//label[@test-id='letter-lbl-jobSessionMsg'][contains(.,'Not allowed: You are already processing the same task from another browser.')]");

            try
            {
                bool msgDisplay = Browser.Wd.FindElement(NotAllowedMsg).Displayed; // If not Allowed message presence

                if (msgDisplay)
                {
                    clearingLetterQueue();

                }

                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@title='Letters']")));
                tmsWait.Hard(3);
                By letterName = By.CssSelector("[test-id='Outbound Enrollment Verification Letter']");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(letterName);
                tmsWait.Hard(3);
                string expectedMessage = tmsCommon.GenerateData(p0);
                string actualMessage = Browser.Wd.FindElement(By.XPath("//label[@test-id='letter-lbl-jobSessionMsg']")).Text;
                Assert.AreEqual(expectedMessage, actualMessage, "Expected message is not displayed");
            }
            catch
            {
             string expectedMessage = tmsCommon.GenerateData(p0);
             string actualMessage = Browser.Wd.FindElement(By.XPath("//label[@test-id='letter-lbl-jobSessionMsg']")).Text;
             Assert.AreEqual(expectedMessage, actualMessage, "Expected message is not displayed");
            }
        }


        [Then(@"Verify Home Page Letter count for Acknowledgment of Enrollment Letter is increased")]
        public void ThenVerifyHomePageLetterCountForAcknowledgmentOfEnrollmentLetterIsIncreased(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.Letters.LettersQueueTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            try
                            {
                                if (bThisRowMatches)
                                {
                                    IWebElement thisEditTD = ApplicationRow.Element[0];
                                    IWebElement thisEditLink = thisEditTD.FindElement(By.XPath("//a[contains(@href,'reports/reportmain_letterqueue.aspx?code=001&type=1&hImg=imagePreCMS&hDiv=divPreCMS')]"));


                                    GlobalRef.finalLetterCount = Int32.Parse(thisEditLink.Text);
                                    var finalcount = GlobalRef.finalLetterCount;
                                    var initcount = GlobalRef.InitialLetterCount;

                                    Console.WriteLine("final Letter Count for Acknowledgment of Enrollment Letter queue : " + thisEditLink.Text);


                                    int initiallettercount = Convert.ToInt32(initcount);
                                    int finallettercount = Convert.ToInt32(finalcount);

                                    Assert.IsTrue(initiallettercount < finallettercount, "Letter Count for Acknowledgment of Enrollment Letter is Increased");

                                    //if (initiallettercount < finallettercount)
                                    //{

                                    //    Console.WriteLine(" Letter Count for Acknowledgment of Enrollment Letter is Increased");
                                    //}

                                    //else
                                    //{
                                    //    Console.WriteLine(" Letter Count for Acknowledgment of Enrollment Letter is not getting Increased");
                                    //}



                                    tmsWait.Hard(2);


                                }
                            }
                            catch
                            {
                                GlobalRef.LetterCount = 0;
                            }


                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.Letters.LettersQueueTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

        [Then(@"Verify Home Page Initial Letter count for Confirmation of Enrollment in Another Plan Letter queue table")]
        public void ThenVerifyHomePageInitialLetterCountForConfirmationOfEnrollmentInAnotherPlanLetterQueueTable(Table table)
        {

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.Letters.LettersQueueTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            try
                            {
                                if (bThisRowMatches)
                                {
                                    IWebElement thisEditTD = ApplicationRow.Element[0];
                                    IWebElement thisEditLink = thisEditTD.FindElement(By.XPath("//a[contains(@href,'reports/reportmain_letterqueue.aspx?code=012&type=2&hImg=imagePostCMS&hDiv=divPostCMS')]"));


                                    GlobalRef.InitialLetterCount = Int32.Parse(thisEditLink.Text);


                                    Console.WriteLine("Initial Letter Count for Confirmation of Enrollment in Another Plan Letter queue : " + thisEditLink.Text);
                                    tmsWait.Hard(2);


                                }
                            }
                            catch
                            {
                                GlobalRef.LetterCount = 0;
                            }


                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.Letters.LettersQueueTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }


        [Then(@"Verify Home Page Initial Letter count for Acknowledgment of Enrollment in Another Plan Letter queue table")]
        public void ThenVerifyHomePageInitialLetterCountForAcknowledgmentOfEnrollmentInAnotherPlanLetterQueueTable(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.Letters.LettersQueueTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            try
                            {
                                if (bThisRowMatches)
                                {
                                    IWebElement thisEditTD = ApplicationRow.Element[0];
                                    IWebElement thisEditLink = thisEditTD.FindElement(By.XPath("//a[contains(@href,'reports/reportmain_letterqueue.aspx?code=011&type=1&hImg=imagePreCMS&hDiv=divPreCMS')]"));


                                    GlobalRef.InitialLetterCount = Int32.Parse(thisEditLink.Text);


                                    Console.WriteLine("Initial Letter Count for Acknowledgment of Enrollment in Another Plan Letter queue : " + thisEditLink.Text);
                                    tmsWait.Hard(2);


                                }
                            }
                            catch
                            {
                                GlobalRef.LetterCount = 0;
                            }


                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.Letters.LettersQueueTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

       [Then(@"Verify Home Page Initial Letter count for ""(.*)"" is noted")]
        public void ThenVerifyHomePageInitialLetterCountForIsNoted(string p0)
        {
            tmsWait.Hard(5);
            int initiallettercount;
            try
            {
                string lettername = tmsCommon.GenerateData(p0);
                IWebElement count = Browser.Wd.FindElement(By.XPath("//table//td[contains(.,'" + lettername + "')]/preceding-sibling::td/a"));
                GlobalRef.InitialLetterCount = Int32.Parse(count.Text);
                 initiallettercount = Convert.ToInt32(GlobalRef.InitialLetterCount);

            }
            catch
            {
                GlobalRef.InitialLetterCount = 0;
                initiallettercount = 0;
            }

        }

        [Then(@"Verify Home Page Letter count ""(.*)"" is increased")]
        public void ThenVerifyHomePageLetterCountIsIncreased(string p0)
        {
            tmsWait.Hard(5);
            int finallettercount;
            int intiallettercount = Convert.ToInt32(GlobalRef.InitialLetterCount);
            try
            {
                string lettername = tmsCommon.GenerateData(p0);
                IWebElement count = Browser.Wd.FindElement(By.XPath("//table//td[contains(.,'" + lettername + "')]/preceding-sibling::td/a"));
                GlobalRef.FinalLetterCount = Int32.Parse(count.Text);
                 finallettercount = Convert.ToInt32(GlobalRef.FinalLetterCount);
            }
            catch
            {
                GlobalRef.FinalLetterCount = 0;
                finallettercount = 0;
            }

            if(finallettercount> intiallettercount)
            {
                Assert.IsTrue(true, " Letter count is not geting increased");
            }
            else
            {
                Assert.IsFalse(false, " Letter count is getting increased");
            }

        }





        [Then(@"Verify Home Page Initial Letter count for Acknowledgment of Enrollment Letter queue table")]
        public void ThenVerifyHomePageInitialLetterCountForAcknowledgmentOfEnrollmentLetterQueueTable(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.Letters.LettersQueueTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            try
                            {
                                if (bThisRowMatches)
                                {
                                    IWebElement thisEditTD = ApplicationRow.Element[0];
                                    IWebElement thisEditLink = thisEditTD.FindElement(By.XPath("//a[contains(@href,'reports/reportmain_letterqueue.aspx?code=001&type=1&hImg=imagePreCMS&hDiv=divPreCMS')]"));


                                    GlobalRef.InitialLetterCount = Int32.Parse(thisEditLink.Text);


                                    Console.WriteLine("Initial Letter Count for Acknowledgment of Enrollment Letter queue : " + thisEditLink.Text);
                                    tmsWait.Hard(2);


                                }
                            }
                            catch
                            {
                                GlobalRef.LetterCount = 0;
                            }


                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.Letters.LettersQueueTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }


        [Then(@"Verify Home Page Letter count for Outbound Enrollment Verification has not increased")]
        public void ThenVerifyHomePageLetterCountForOutboundEnrollmentVerificationHasNotIncreased(Table table)
        {
            IWebElement lettersImg = Browser.Wd.FindElement(By.CssSelector("[test-id='eamDashboard-img-letters']"));
            fw.ExecuteJavascript(lettersImg);
            tmsWait.Hard(1);

            By lettercountelem;

            string letterCount;
            try
            {
                lettercountelem = By.XPath("//label[contains(.,'Outbound Enrollment Verification Letter')]/parent::div/preceding-sibling::div/label");
                if (Browser.Wd.FindElement(lettercountelem).Displayed)
                {
                    letterCount = Browser.Wd.FindElement(lettercountelem).Text;
                    fw.ConsoleReport("Outbound Enrollment Verification Letter count -->" + letterCount);
                    GlobalRef.NowOEVLetterCount = Int32.Parse(letterCount);
                }
            }
            catch
            {
                try
                {
                    lettercountelem = By.XPath("//label[contains(.,'Outbound Enrollment Verification Letter')]/parent::div/preceding-sibling::div/a");
                    if (Browser.Wd.FindElement(lettercountelem).Displayed)
                    {
                        letterCount = Browser.Wd.FindElement(lettercountelem).Text;
                        fw.ConsoleReport(" Outbound Enrollment Verification Letter  count -->" + letterCount);
                        GlobalRef.NowOEVLetterCount = Int32.Parse(letterCount);

                    }
                }
                catch
                {
                    GlobalRef.NowOEVLetterCount = 0;
                }
            }

            var finalcount = GlobalRef.NowOEVLetterCount;
            var initcount = GlobalRef.BeforeOEVLetterCount;
            int initiallettercount = Convert.ToInt32(initcount);
            int finallettercount = Convert.ToInt32(finalcount);
            fw.ConsoleReport(" Initial Letter Count  " + initcount);
            fw.ConsoleReport(" Final Letter Count  " + finalcount);
            bool res = (initiallettercount == finallettercount);
            Assert.IsTrue(res, "  Letters count are getting increased");

            

            


        }

        [Then(@"Verify Home Page Letter Queue for Outbound Enrollment Verification is Cleared")]
        public void ThenVerifyHomePageLetterQueueForOutboundEnrollmentVerificationIsCleared(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.Letters.LettersQueueTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            try
                            {
                                if (bThisRowMatches)
                                {
                                    IWebElement thisEditTD = ApplicationRow.Element[0];
                                    IWebElement thisEditLink = thisEditTD.FindElement(By.XPath("//a[contains(@href,'reports/reportmain_letterqueue.aspx?code=032&type=1')]"));
                                    GlobalRef.InitialLetterCount = Int32.Parse(thisEditLink.Text);
                                    Console.WriteLine("Initial Letter Count for Outbound Enrollment Verification queue : " + thisEditLink.Text);
                                    tmsWait.Hard(2);

                                }
                            }
                            catch
                            {
                                GlobalRef.LetterCount = 0;


                            }


                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.Letters.LettersQueueTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    //As There is no match with gherkin table so breaking loop - Venkatesh P
                    break;

                }
            }

            GlobalRef.BeforeOEVLetterCount = 0;
            Console.WriteLine("Initial Letter Count for Outbound Enrollment Verification queue " + GlobalRef.BeforeOEVLetterCount);
        }

        [When(@"Export Session page queue is cleared")]
        public void WhenExportSessionPageQueueIsCleared()
        {
            tmsWait.Hard(2);
            IWebElement export = Browser.Wd.FindElement(By.LinkText("Export Session"));
            fw.ExecuteJavascript(export);
            try
            {
                IWebElement textPresence = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Currently no user exporting a file.')]"));
                if (textPresence.Displayed)                
                {
                    fw.ConsoleReport("Currently no user exporting a file.");
                }
            } 
            catch
            {
                if (Browser.Wd.FindElement(By.XPath("//input[@type='image']")).Displayed)
                {
                    IWebElement delete = Browser.Wd.FindElement(By.XPath("//input[@type='image']"));
                    do
                    {
                        if (delete.Displayed)
                        {
                            fw.ExecuteJavascript(delete);
                            tmsWait.Hard(2);
                            try
                            {
                                 Browser.Wd.SwitchTo().Alert().Accept();
                                //del.Accept();
                                tmsWait.Hard(4);
                                //Browser.Wd.Navigate().Refresh();

                            }
                            catch
                            {
                                Console.WriteLine("No Alert Presence");
                            }

                        }

                    } while (!delete.Displayed);

                }

            }
        }

        [Then(@"Verify Home Page Initial Letter count for ""(.*)"" has changed")]
        public void ThenVerifyHomePageInitialLetterCountForHasChanged(string letter)
        {
            try
            {
                if (Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + letter + "')]/preceding-sibling::td/a")).Displayed)
                {
                    GlobalRef.finalLetterCount = Int32.Parse(Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + letter + "')]/preceding-sibling::td/a")).Text);
                    Console.WriteLine("Initial Letter Count for Outbound Enrollment Verification queue : " + GlobalRef.finalLetterCount.ToString());
                }
            }
            catch (NoSuchElementException ex)
            {
                GlobalRef.finalLetterCount = 0;
                Console.WriteLine(letter + " is not displayed on Home page." + GlobalRef.finalLetterCount.ToString());
            }



            int intiialcount = Int32.Parse(GlobalRef.InitialLetterCount.ToString());
            int finalcount = Int32.Parse(GlobalRef.finalLetterCount.ToString());
            bool letterCountIncrese = finalcount > intiialcount;
            Assert.IsTrue(letterCountIncrese, "Letter count is not increased, it should be increased");
        }


        [Then(@"Verify Home Page Initial Letter count for ""(.*)"" has not changed")]
        public void ThenVerifyHomePageInitialLetterCountForHasNotChanged(string letter)
        {

            try
            {
                if (Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + letter + "')]/preceding-sibling::td/a")).Displayed)
                {
                    GlobalRef.MidLetterCount = Int32.Parse(Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + letter + "')]/preceding-sibling::td/a")).Text);
                    Console.WriteLine("Initial Letter Count for Outbound Enrollment Verification queue : " + GlobalRef.InitialLetterCount.ToString());
                }
            }
            catch (NoSuchElementException ex)
            {
                GlobalRef.MidLetterCount = 0;
                Console.WriteLine(letter + " is not displayed on Home page." + GlobalRef.InitialLetterCount.ToString());
            }

           

            int intiialcount = Int32.Parse(GlobalRef.InitialLetterCount.ToString());
            int midcount= Int32.Parse(GlobalRef.MidLetterCount.ToString());
            Assert.AreEqual(intiialcount, midcount, "Letter count is increased, it shoudl not be increased");
        }

        [Then(@"Verify Home Page Noted Initial Letter count for ""(.*)""")]
        public void ThenVerifyHomePageNotedInitialLetterCountFor(string letter)
        {
            By letterCount = By.XPath("//td[contains(.,'" + letter + "')]/preceding-sibling::td/a");

            try
            {
                string NoteInitLetterCount = Browser.Wd.FindElement(letterCount).Text;
                GlobalRef.NoteInitialLetterCount =Int32.Parse(NoteInitLetterCount);
                fw.ConsoleReport(" Initial Letter Count is "+ NoteInitLetterCount+" for " + letter);
            }
            catch
            {
                GlobalRef.NoteInitialLetterCount = 0;

                fw.ConsoleReport(" Initial Letter Count is 0 for "+letter);
            }

        }

        [Then(@"Verify Home Page Initial Letter count for ""(.*)"" is same")]
        public void ThenVerifyHomePageInitialLetterCountForIsSame(string letter)
        {
            By letterCount = By.XPath("//td[contains(.,'" + letter + "')]/preceding-sibling::td/a");

            try
            {
                string NoteInitLetterCount = Browser.Wd.FindElement(letterCount).Text;
                GlobalRef.NoteInitialLetterCount = Int32.Parse(NoteInitLetterCount);
                fw.ConsoleReport(" Initial Letter Count is " + NoteInitLetterCount + " for " + letter);
            }
            catch
            {
                GlobalRef.MidLetterCount = 0;

                fw.ConsoleReport(" Mid Letter Count is 0 for " + letter);
            }
            
            int intiialcount = Int32.Parse(GlobalRef.InitialLetterCount.ToString());
            int midcount= Int32.Parse(GlobalRef.MidLetterCount.ToString());
            Assert.AreEqual(intiialcount, midcount, "Letter count is increased, it shoudl not be increased");
        }

        [Then(@"Verify Home Page Initial Letter count ""(.*)"" is same")]
        public void ThenVerifyHomePageInitialLetterCountIsSame(string letter)
        {
            By letterCount = By.XPath("//td[contains(.,'" + letter + "')]/preceding-sibling::td/a");

            try
            {
                string NoteInitLetterCount = Browser.Wd.FindElement(letterCount).Text;
                GlobalRef.CurrentLetterCount = Int32.Parse(NoteInitLetterCount);
                fw.ConsoleReport(" Initial Letter Count is " + NoteInitLetterCount + " for " + letter);
            }
            catch
            {
                GlobalRef.MidLetterCount = 0;

                fw.ConsoleReport(" Mid Letter Count is 0 for " + letter);
                int intiialcount1 = Int32.Parse(GlobalRef.InitialLetterCount.ToString());
                int midcount = Int32.Parse(GlobalRef.MidLetterCount.ToString());
                Assert.AreEqual(intiialcount1, midcount, "Letter count is increased, it shoudl not be increased");
            }

            int intiialcount = Int32.Parse(GlobalRef.InitialLetterCount.ToString());
            int currcount = Int32.Parse(GlobalRef.CurrentLetterCount.ToString());
            Assert.AreEqual(intiialcount, currcount, "Letter count is increased, it shoudl not be increased");
        }

        [When(@"View Edit Transaction page Force Acceptance Check box is checked")]
        public void WhenViewEditTransactionPageForceAcceptanceCheckBoxIsChecked()
        {
            tmsWait.Hard(2);
            By force = By.CssSelector("[id='ctl00_ctl00_MainMasterContent_MainContent_chkForcedAccept']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(force));
            tmsWait.Hard(2);
            By save = By.XPath("//input[@value='Save']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(save));

            Browser.ClosePopUps(true);
        }

        [Then(@"Download CMS Transfer File and Verify MBI ""(.*)"" is displayed successfully")]
        public void ThenDownloadCMSTransferFileAndVerifyMBIIsDisplayedSuccessfully(string p0)
        {

            string mbi = tmsCommon.GenerateData(p0);

            tmsWait.Hard(5);
            var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadedFilePath + "", "*_*.txt");
        
            var srcFile = Path.Combine(downloadedFilePath, newFilePaths[0]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();
                if(line.Contains(mbi))
                {
                    Assert.IsTrue(true);
                }
                
            }
        }

        [When(@"I read Exported BEQ file and Created BEQ Response File""(.*)"" Load it")]
        public void WhenIReadExportedBEQFileAndCreatedBEQResponseFileLoadIt(string p0)
        {
            StringBuilder st;
            string beqResponse = tmsCommon.GenerateData(p0);
       
            tmsWait.Hard(5);    
            var count = 0;
            var newFilePaths = Directory.GetFiles(@"" + downloadedFilePath + "", "*_*.txt");
            // Reading BEQ File from Download
            var srcFile = Path.Combine(downloadedFilePath, newFilePaths[0]);
            var reader = new StreamReader(File.OpenRead(@"" + srcFile + ""));
            while (!reader.EndOfStream)
            {
                count++;
                var line = reader.ReadLine();

                // Taking BEQ Header
                if (count == 1)
                {
                    GlobalRef.BEQHeader = line.Substring(16, 17);
                    fw.ConsoleReport(" BEQ Header contains --> " + GlobalRef.BEQHeader);
                }
                if (count == 2)
                {
                    GlobalRef.BEQMBI = line.Substring(5, 11); // Starting Pos and remaining Length
                    fw.ConsoleReport(" BEQ file MBI is --> " + GlobalRef.BEQMBI);
                    GlobalRef.BEQDOB = line.Substring(26, 17); // Starting Pos and remaining Length
                    fw.ConsoleReport(" BEQ file DOB Gender Record Sequence is --> " + GlobalRef.BEQDOB);
                }
                
                if (count == 3)
                {
                    GlobalRef.BEQTrailer = line.Substring(16, 24); // Starting Pos and remaining Length
                    fw.ConsoleReport(" BEQ Trailer contains --> " + GlobalRef.BEQTrailer);
                }
            }

            string sourceBEQResponseFile = "c:\\temp\\" + tmsCommon.GenerateData(beqResponse);

            // // Reading BEQ File from Temp Folder and Creating BEQN file

            string beqResponseHeader = GlobalRef.BEQHeader.ToString();
            string beqResponseMBI = GlobalRef.BEQMBI.ToString();
            string beqResponseDOB = GlobalRef.BEQDOB.ToString();
            string beqResponseTrailer = GlobalRef.BEQTrailer.ToString();
            string beqResponseOldMBI;
            string beqResponseOldDOB;
            string[] lines = System.IO.File.ReadAllLines(sourceBEQResponseFile);
            string[] st1 = new string[lines.Length];
            var lineBEQRes = 0;
            for (int i = 0; i < lines.Length; i++)
            {
                // Header File
                if (lineBEQRes == 0)
                {
                    st = new StringBuilder(lines[lineBEQRes]);
                    st.Remove(16, 17);
                    st.Insert(16, beqResponseHeader);
                    st1[i] = st.ToString();
                    fw.ConsoleReport(st1[i]);
                }
                // Detailer
                if (lineBEQRes == 1)
                {
                    beqResponseOldMBI = lines[1].Substring(8, 11);
                    st = new StringBuilder(lines[lineBEQRes]);
                    // st.Remove(8, 11);
                    // st.Insert(8, beqResponseMBI);
                    st.Replace(beqResponseOldMBI, beqResponseMBI);
                    //st.Remove(26, 17);
                    beqResponseOldDOB = lines[1].Substring(29, 8);
                    // st.Insert(26, beqResponseDOB);
                    st.Replace(beqResponseOldDOB, beqResponseDOB);
                    st.Remove(45,9);
                    st1[i] = st.ToString();
                    fw.ConsoleReport(st1[i]);
                }

                // Trailer
                if (lineBEQRes == 2)
                {
                    st = new StringBuilder(lines[lineBEQRes]);
                    st.Remove(16, 24);
                    st.Insert(16, beqResponseTrailer);
                    st1[i] = st.ToString();
                    fw.ConsoleReport(st1[i]);
                }

                lineBEQRes++;
            }

            System.IO.File.WriteAllLines(sourceBEQResponseFile, st1);

            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@title='Import']")));
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[contains(.,'BQN File')]")));
            EAM.LoadEAFFile.SelectFiles.SendKeys(sourceBEQResponseFile);
            EAM.LoadEAFFile.Upload.Click();
            tmsWait.Hard(2);
        }



        [Then(@"Verify Home Page Note Final Letter count for ""(.*)"" is incremented")]
        public void ThenVerifyHomePageNoteFinalLetterCountForIsIncremented(string letter)
        {
            By letterCount = By.XPath("//td[contains(.,'" + letter + "')]/preceding-sibling::td/a");

            try
            {
                string NoteFinalLetterCount = Browser.Wd.FindElement(letterCount).Text;
                GlobalRef.NoteFinalLetterCount = Int32.Parse(NoteFinalLetterCount);
                fw.ConsoleReport(" Final Letter Count is " + NoteFinalLetterCount + " for " + letter);
            }
            catch
            {
                GlobalRef.NoteFinalLetterCount = 0;

                fw.ConsoleReport(" Final Letter Count is 0 for " + letter);
            }

            int FirstCount = Convert.ToInt32(GlobalRef.NoteInitialLetterCount);
            int lastCount = Convert.ToInt32(GlobalRef.NoteFinalLetterCount);
            Assert.AreEqual(lastCount, FirstCount, "Letter count is not increased");
                
        }



        [Then(@"Verify Home Page Note Final Letter count for ""(.*)"" is increased")]
        public void ThenVerifyHomePageNoteFinalLetterCountForIsIncreased(string letter)
        {
            By letterCount = By.XPath("//td[contains(.,'" + letter + "')]/preceding-sibling::td/a");

            try
            {
                string NoteFinalLetterCount = Browser.Wd.FindElement(letterCount).Text;
                GlobalRef.NoteFinalLetterCount = Int32.Parse(NoteFinalLetterCount);
                fw.ConsoleReport(" Final Letter Count is " + NoteFinalLetterCount + " for " + letter);
            }
            catch
            {
                GlobalRef.NoteFinalLetterCount = 0;

                fw.ConsoleReport(" Final Letter Count is 0 for " + letter);
            }

            int FirstCount = Convert.ToInt32(GlobalRef.NoteInitialLetterCount);
            int lastCount = Convert.ToInt32(GlobalRef.NoteFinalLetterCount);
            Assert.AreEqual(lastCount > FirstCount, " Letter count is not increased");

        }
        // New Statement 11/15/18

        [Then(@"Home Page Initial Letter count noted for ""(.*)""")]
        public void ThenHomePageInitialLetterCountNotedFor(string letter)
        {
           By letterCount = By.XPath("//td[contains(.,'"+ letter + "')]/preceding-sibling::td/a");

            try
            {
                if(Browser.Wd.FindElement(letterCount).Displayed)
                {
                    GlobalRef.NoOfLetterInit = Browser.Wd.FindElement(letterCount).Text;
                    fw.ConsoleReport("Initial Letter Count for "+ letter +"queue : " + GlobalRef.NoOfLetterInit.ToString());
                }

            }
            catch
            {

                GlobalRef.NoOfLetterInit = "0";
                fw.ConsoleReport(letter + " is not displayed on Home page." + GlobalRef.NoOfLetterInit.ToString());
            }

        }

        [Then(@"Verify Home page Final Letter count is ""(.*)"" for ""(.*)""")]
        public void ThenVerifyHomePageFinalLetterCountIsFor(string countStatus, string letter)
        {
            By letterCount = By.XPath("//td[contains(.,'" + letter + "')]/preceding-sibling::td/a");

            if (countStatus.Equals("Increased"))
            {

                try
                {
                    if (Browser.Wd.FindElement(letterCount).Displayed)
                    {
                        GlobalRef.NoOfLetterFinal = Browser.Wd.FindElement(letterCount).Text;
                        fw.ConsoleReport("Initial Letter Count for '" + letter + "' queue : " + GlobalRef.NoOfLetterFinal.ToString());
                    }
                }
                catch
                {

                    GlobalRef.NoOfLetterFinal = "0";
                    fw.ConsoleReport(letter + " is not displayed on Home page." + GlobalRef.NoOfLetterFinal.ToString());
                }


                int initialCount = Convert.ToInt32(GlobalRef.NoOfLetterInit);
                int finalCount = Convert.ToInt32(GlobalRef.NoOfLetterFinal);

                bool results = (initialCount < finalCount);
              

                Assert.IsTrue(results, "Letter Count for '" + letter + "' Letter is not increased as initial count  ");

            }
            if (countStatus.Equals("Decreased"))
            {

                try
                {
                    if (Browser.Wd.FindElement(letterCount).Displayed)
                    {
                        GlobalRef.NoOfLetterFinal = Browser.Wd.FindElement(letterCount).Text;
                        fw.ConsoleReport("Initial Letter Count for Outbound Enrollment Verification queue : " + GlobalRef.NoOfLetterFinal.ToString());
                    }
                }
                catch
                {

                    GlobalRef.NoOfLetterFinal = "0";
                    fw.ConsoleReport(letter + " is not displayed on Home page." + GlobalRef.NoOfLetterFinal.ToString());
                }


                int initialCount = Convert.ToInt32(GlobalRef.NoOfLetterInit);
                int finalCount = Convert.ToInt32(GlobalRef.NoOfLetterFinal);

                bool results = (initialCount > finalCount);
                Assert.IsTrue(results, "Letter Count for Outbound Enrollment Verification Letter is Decreased as initial count");

                int by = initialCount - finalCount;

                Assert.IsTrue(results, "Letter Count for '" + letter + "' Letter is not decreased count  '" + by + "' ");
            }

            if (countStatus.Equals("Same"))
            {
                try
                {
                    if (Browser.Wd.FindElement(letterCount).Displayed)
                    {
                        GlobalRef.NoOfLetterFinal = Browser.Wd.FindElement(letterCount).Text;
                        fw.ConsoleReport("Initial Letter Count for Outbound Enrollment Verification queue : " + GlobalRef.NoOfLetterFinal.ToString());
                    }
                }
                catch
                {

                    GlobalRef.NoOfLetterFinal = "0";
                    fw.ConsoleReport(letter + " is not displayed on Home page." + GlobalRef.NoOfLetterFinal.ToString());
                }

               
                int initialCount = Convert.ToInt32(GlobalRef.NoOfLetterInit);
                int finalCount = Convert.ToInt32(GlobalRef.NoOfLetterFinal);
               
                bool results = (initialCount == finalCount);
                Assert.IsTrue(results, "Letter Count for Outbound Enrollment Verification Letter is not Same as initial count");


            }
        }


        [Then(@"Verify Home Page Initial Letter count for ""(.*)""")]
        public void ThenVerifyHomePageInitialLetterCountFor(string letter)
        {

            By lettercountelem;
            By toggleRemove;
            By Remove;
            string letterCount;
            try
            {
                lettercountelem = By.XPath("//label[contains(.,'"+ letter + "')]/parent::div/preceding-sibling::div/label");
                if (Browser.Wd.FindElement(lettercountelem).Displayed)
                {
                    letterCount = Browser.Wd.FindElement(lettercountelem).Text;
                    fw.ConsoleReport(letter+" Letter count -->" + letterCount);
                    GlobalRef.InitialLetterCount = Int32.Parse(letterCount);
                }
            }
            catch
            {
                try
                {
                    lettercountelem = By.XPath("//label[contains(.,'" + letter + "')]/parent::div/preceding-sibling::div/a");
                    if (Browser.Wd.FindElement(lettercountelem).Displayed)
                    {
                        letterCount = Browser.Wd.FindElement(lettercountelem).Text;
                        fw.ConsoleReport(letter + " Letter count -->" + letterCount);
                        GlobalRef.InitialLetterCount = Int32.Parse(letterCount);

                    }
                }
                catch
                {
                    GlobalRef.InitialLetterCount = 0;
                }
            }
            
        }

        [When(@"I have navigated Dashboard ""(.*)""")]
        public void WhenIHaveNavigatedDashboard(string p0)
        {
            tmsWait.Hard(5);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                Browser.Wd.FindElement(By.XPath("//i[@test-id='eamDashboard-img-letters']")).Click();
            }
            else
            {

                Browser.Wd.FindElement(By.XPath("//label[contains(text(),'" + p0 + "')]")).Click();
            }
            tmsWait.Hard(5);

        }

        [Then(@"Verify Home Page Letter count for Outbound Enrollment Verification Letter is increased by (.*)")]
        public void ThenVerifyHomePageLetterCountForOutboundEnrollmentVerificationLetterIsIncreasedBy(int p0)
        {
            tmsWait.Hard(5);
            String count= Browser.Wd.FindElement(By.XPath("//label[contains(text(),'Outbound Enrollment Verification Letter')]/parent::div//preceding-sibling::div/a")).Text ;
            Assert.IsTrue(count.Equals("1"));

        }


        [Then(@"Verify Home Page Letter count for Outbound Enrollment Verification Letter is not increased")]
        public void ThenVerifyHomePageLetterCountForOutboundEnrollmentVerificationLetterIsNotIncreased()
        {

            tmsWait.Hard(5);
            try { 
            IWebElement Oev = Browser.Wd.FindElement(By.XPath("//label[contains(text(),'Outbound Enrollment Verification Letter')]/parent::div//preceding-sibling::div/a"));
            }
            catch { 
               
            }
        }


        [Then(@"Verify Home Page Initial Letter count for Outbound Enrollment Verification queue table")]
        public void ThenVerifyHomePageInitialLetterCountForOutboundEnrollmentVerificationQueueTable(Table table)
        {

            IWebElement lettersImg = Browser.Wd.FindElement(By.CssSelector("[test-id='eamDashboard-img-letters']"));
            fw.ExecuteJavascript(lettersImg);
            tmsWait.Hard(1);
            By lettercountelem;

            string letterCount;
            try
            {
                lettercountelem = By.XPath("//label[contains(.,'Outbound Enrollment Verification Letter')]/parent::div/preceding-sibling::div/label");
                if (Browser.Wd.FindElement(lettercountelem).Displayed)
                {
                    letterCount = Browser.Wd.FindElement(lettercountelem).Text;
                    fw.ConsoleReport("Outbound Enrollment Verification Letter count -->" + letterCount);
                    GlobalRef.BeforeOEVLetterCount = Int32.Parse(letterCount);
                }
            }
            catch
            {
                try
                {
                    lettercountelem = By.XPath("//label[contains(.,'Outbound Enrollment Verification Letter')]/parent::div/preceding-sibling::div/a");
                    if (Browser.Wd.FindElement(lettercountelem).Displayed)
                    {
                        letterCount = Browser.Wd.FindElement(lettercountelem).Text;
                        fw.ConsoleReport(" Outbound Enrollment Verification Letter  count -->" + letterCount);
                        GlobalRef.BeforeOEVLetterCount = Int32.Parse(letterCount);

                    }
                }
                catch
                {
                    GlobalRef.BeforeOEVLetterCount = 0;
                }
            }

            


        }


        [Then(@"Verify Home Page Initial Letter count for Confirmation of Enrollment queue table")]
        public void ThenVerifyHomePageInitialLetterCountForConfirmationOfEnrollmentQueueTable(Table table)
        {

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.Letters.LettersQueueTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            try
                            {
                                if (bThisRowMatches)
                                {
                                    IWebElement thisEditTD = ApplicationRow.Element[0];
                                    IWebElement thisEditLink = thisEditTD.FindElement(By.XPath("//a[contains(@href,'reports/reportmain_letterqueue.aspx?code=005&type=2&hImg=imagePostCMS&hDiv=divPostCMS')]"));
                                    GlobalRef.InitialLetterCount = Int32.Parse(thisEditLink.Text);
                                    Console.WriteLine("Initial Letter Count for Confirmation of Disenrollment Due to Passive Enrollment into a Medicare-Medicaid Plan queue : " + thisEditLink.Text);
                                    tmsWait.Hard(2);

                                }
                            }
                            catch
                            {
                                GlobalRef.LetterCount = 0;
                            }


                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.Letters.LettersQueueTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }


        }


        


        


        [Then(@"Confirmation of Cancellation of Enrollment Due to Notice from CMS TRC (.*) Letter")]
        public void ThenConfirmationOfCancellationOfEnrollmentDueToNoticeFromCMSTRCLetter(int p0)
        {
            try
            {
                GlobalRef.InitialLetterCount = Int32.Parse(EAM.LettersPostCMS.LetterCanEnrollNoticeCMS.Text);
                GlobalRef.LetterCount = Int32.Parse(EAM.LettersPostCMS.LetterCanEnrollNoticeCMS.Text);
            }
            catch
            {
                GlobalRef.LetterCount = 0;
                GlobalRef.InitialLetterCount = 0;
            }

        }
        [Then(@"Verify Transaction View Edit Page User Modified is set to ""(.*)""")]
        public void ThenVerifyTransactionViewEditPageUserModifiedIsSetTo(string p0)
        {
            string fieldName = "User Modified";

            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MemberInformation.MemberInfoUserModified.Text;
            actual = actual.Replace(" ", "");
            Assert.AreEqual(true, expected.Equals(actual), "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");

        }

        [Then(@"Verify Transaction View Edit Page User Modified is set to Config file User ID")]
        public void ThenVerifyTransactionViewEditPageUserModifiedIsSetToConfigFileUserID()
        {
            //string fieldName = "User Modified";
            //string expected = ConfigFile.FirstName + " " + ConfigFile.LastName;
            //string actual = EAM.MemberInformation.MemberInfoUserModified.Text;
            //tmsCommon.gen

            //Assert.AreEqual(true, expected.Equals(actual), "Field " + fieldName + " value is [" + actual + "], expected [" + expected + "]");
            //fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + expected + "] - They are expected to match.");
        }


        //[Then(@"Verify Transaction View Edit Page User Modified is set to""(.*)""")]
        //public void ThenVerifyTransactionViewEditPageUserModifiedIsSetTo(string p0)
        //{
        //    string fieldName = "User Modified";
        //    string GeneratedData = tmsCommon.GenerateData(p0);
        //    string thisFieldValue = EAM.MemberInformation.MemberInfoUserModified.Text;

        //    Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
        //    fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        //}

        [When(@"Administration Status Override page New TRC Code is set to ""(.*)""")]
        public void WhenAdministrationStatusOverridePageNewTRCCodeIsSetTo(string trc)
        {
             trc = trc.ToString();

            EAM.AdministrationStatusoverride.NewReplyCode.SendKeys(trc);

        }

        [When(@"Administration Status Override NewReplyDate is set to ""(.*)""")]
        public void WhenAdministrationStatusOverrideNewReplyDateIsSetTo(string ReplyDate)
        {
            tmsWait.Hard(2);
            string GeneratedData = tmsCommon.GenerateData(ReplyDate);
            GeneratedData = GeneratedData.Replace("/", "");
            //EAM.AdministrationStatusoverride.NewReplyDate.Clear();
            //tmsWait.Hard(1);
            EAM.AdministrationStatusoverride.NewReplyCode.SendKeys(OpenQA.Selenium.Keys.Tab);
            EAM.AdministrationStatusoverride.NewReplyDate.SendKeys(GeneratedData);
            //fw.ExecuteJavascriptSetText(EAM.AdministrationStatusoverride.NewReplyDate, GeneratedData);
            tmsWait.Hard(2);
           
            //GeneratedData = GeneratedData.Replace("/", "");
             //EAM.AdministrationStatusoverride.NewReplyDate.SendKeys(GeneratedData);
            ////EAM.AdministrationStatusoverride.NewReplyDate.Click();
            //tmsWait.Hard(1);
            //EAM.AdministrationStatusoverride.NewReplyDate.Clear();
            //EAM.AdministrationStatusoverride.NewReplyDate.SendKeys(ReplyDate);
            ////fw.ExecuteJavascriptSetText(EAM.AdministrationStatusoverride.NewReplyDate, ReplyDate);
            //tmsWait.Hard(2);

            //  string GeneratedData = tmsCommon.GenerateData(ReplyDate);
            //  GeneratedData = GeneratedData.Replace("/", "");
            //tmsWait.Hard(2);
            //EAM.AdministrationStatusoverride.NewReplyDate.Clear();
            //tmsWait.Hard(4);
            ////EAM.AdministrationStatusoverride.NewReplyDate.Click();
            //tmsWait.Hard(3);
            //EAM.AdministrationStatusoverride.NewReplyDate.SendKeys(GeneratedData);
            //tmsWait.Hard(3);
        }


        [When(@"Administration Status Override page New Transaction Status is set to ""(.*)""")]
        public void WhenAdministrationStatusOverridePageNewTransactionStatusIsSetTo(string p0)
        {
            string TransStatusText = EAM.AdministrationStatusoverride.TransactionTable_TransStatus.Text;
            if (TransStatusText != "Accepted by CMS")
            {
                string transStatus = tmsCommon.GenerateData(p0);
                tmsWait.Hard(2);
                SelectElement status = new SelectElement(EAM.AdministrationStatusoverride.NewTransactionStatus);
                tmsWait.Hard(1);
                status.SelectByText(transStatus);
                tmsWait.Hard(2);
            }
        }

        [Then(@"verify Administration Status Override page New Transaction Status is ""(.*)""")]
        public void ThenVerifyAdministrationStatusOverridePageNewTransactionStatusIs(string p0)
        {
           string TransStatusText= EAM.AdministrationStatusoverride.TransactionTable_TransStatus.Text;
           Assert.AreEqual(p0, TransStatusText, "Transaction Status is not as expected");
        }


        [When(@"Administration Status Override Table Transaction Row Edit is clicked")]
        public void WhenAdministrationStatusOverrideTableTransactionRowEditIsClicked()
        {
            IWebElement edit = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_dgTrans']//tr//a"));
            fw.ExecuteJavascript(edit);
        }

       

        [When(@"Administration Status Override Table Transaction Row Edit Link is clicked")]
        public void WhenAdministrationStatusOverrideTableTransactionRowEditLinkIsClicked(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.AdministrationStatusoverride.TransactionSearchTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            if (bThisRowMatches)
                            {
                                IWebElement thisEditTD = ApplicationRow.Element[13];
                                IWebElement thisEditLink = thisEditTD.FindElement(By.TagName("a"));
                                thisEditLink.Click();
                                tmsWait.Hard(2);

                            }

                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.AdministrationStatusoverride.TransactionSearchTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

        [When(@"Administration Status Override page Edit Transaction page ""(.*)"" Row ""(.*)"" TC is Clicked")]
        public void WhenAdministrationStatusOverridePageEditTransactionPageRowTCIsClicked(string hic, string tc)
        {
            string mbiValue = tmsCommon.GenerateData(hic);
            IWebElement mbi = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_dgTrans']//tr/td[contains(.,'"+mbiValue+"')]/following-sibling::td[3][contains(.,'"+tc+"')]/following-sibling::td/a"));
            fw.ExecuteJavascript(mbi);
            tmsWait.Hard(2);
        }

        [When(@"Administration Status Override page Edit Transaction page variable ""(.*)"" is set to value for ""(.*)"" TC row")]
        public void WhenAdministrationStatusOverridePageEditTransactionPageVariableIsSetToValueForTCRow(string p0, string trnCode)
        {
            string trnsCode = tmsCommon.GenerateData(trnCode);
            string TranID = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_dgTrans']//tr/td[3][contains(.,'" + trnCode + "')]")).Text.ToString();
            fw.setVariable(p0, TranID);
            tmsWait.Hard(2);
        }

        

        [When(@"Administration Status Override page Edit Transaction Save Button is Clicked for ""(.*)""")]
        public void WhenAdministrationStatusOverridePageEditTransactionSaveButtonIsClickedFor(string Transaction, Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();
            IWebElement tempElement = null;
            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.AdministrationStatusoverride.TransactionSearchTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                           
                            if (bThisRowMatches)
                            {
                                IWebElement thistransID = ApplicationRow.Element[3];
                                if(thistransID.Text.ToString().Trim().Equals(Transaction))
                                {
                                    IWebElement thisEditTD = ApplicationRow.Element[13];
                                    IWebElement thisEditLink = thisEditTD.FindElement(By.TagName("a"));
                                    tempElement = thisEditLink;
                                    
                                }


                            }

                        }
                       
                    }
                    iTableCounter++;
                }
                fw.ExecuteJavascript(tempElement);
                tmsWait.Hard(2);
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.AdministrationStatusoverride.TransactionSearchTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

        //[When(@"Administration Status Override Table Transaction Row Edit Link is clicked")]
        //public void WhenAdministrationStatusOverrideTableTransactionRowEditLinkIsClicked(Table table)
        //{
        //    try
        //    {
        //        IWebElement objWebTable = EAM.AdministrationStatusoverride.TransactionSearchTable;

        //        String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
        //        for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
        //        {
        //            int index = 0;
        //            if (int.TryParse(arrRes[i, 0], out index))
        //            {
        //                if (index > 0)
        //                {
        //                    index++;
        //                    //string xPath ="//tr[3]//td["+index+"]//a[text()='Edit']";
        //                  //  string xPath = "//tr[" + index + "]//img[@alt='Edit']";
        //                   //a[text()='Edit']";
        //                    string xPath = "//a[text()='Edit']";
        //                    //a[@href='javascript:__doPostBack('dgTrans$ctl03$ctl00','')']";


        //                    IWebElement editIcon = EAM.AdministrationStatusoverride.TransactionSearchTable.FindElement(By.XPath(xPath));
        //                    editIcon.Click();

        //                    try
        //                    {
        //                        editIcon.SendKeys(Keys.Enter);
        //                    }
        //                    catch (Exception) { }
        //                    //tmsWait.Hard(2);
        //                    //tmsWait.WaitForReadyStateComplete(30);
        //                    ////IWebElement objHIC = tmsWait.WaitForElementExist(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtHic_01"),30);
        //                    //IWebElement objHIC = tmsWait.WaitForElementExist(By.XPath(".//*[@id='dgMember']/tbody/tr[2]/td[9]/a"),30);

        //                    Console.WriteLine("Edit icon was clicked");
        //                }
        //                else { Assert.Fail("Edit Icon for expected row was not found"); }
        //            }
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        Assert.Fail("New1: {0}", e.Message);
        //    }
        //}


        [When(@"Member Info Page Transaction History table Transaction (.*) is Clicked")]
        [Then(@"Member Info Page Transaction History table Transaction (.*) is Clicked")]
        public void ThenMemberInfoPageTransactionHistoryTableTransactionIsClicked(int p0, Table table)
        {
            tmsWait.Hard(5);
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.MemberInformation.TransactionHistoryTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            if (bThisRowMatches)
                            {
                                IWebElement thisEditTD = ApplicationRow.Element[0];
                                IWebElement thisEditLink = thisEditTD.FindElement(By.TagName("img"));
                                thisEditLink.Click();
                                tmsWait.Hard(2);

                            }

                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                //baseTable = EAM.AdministrationStatusoverride.TransactionSearchTable;
                //    baseTable =EAM.MemberInformation.TransactionHistoryTable;


                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

        [Then(@"Verify the Member Page displaye the ""(.*)"" as ""(.*)""")]
        public void ThenVerifyTheMemberPageDisplayeTheAs(string p0, string p1)
        {
            string Value;
            string GeneratedData = tmsCommon.GenerateData(p1);
            switch (p1) {
                case "RXGroup":
                    Value = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtRxGroup_38")).Text;
                    Assert.AreEqual(Value, GeneratedData, "Actual and Expected result not matching");
                    break;
                case "RXBIN":
                    Value = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtRXBIN_36")).Text;
                    Assert.AreEqual(Value, GeneratedData, "Actual and Expected result not matching");
                    break;
                case "RXPCN":
                    Value = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtRXPCN_37")).Text;
                    Assert.AreEqual(Value, GeneratedData, "Actual and Expected result not matching");
                    break;
            }
            
        }

        [Then(@"Verify the Member Page displaye the ""(.*)"" is disabled")]
        public void ThenVerifyTheMemberPageDisplayeTheIsDisabled(string p0)
        {
            Boolean Value;
            switch (p0)
            {
                case "RXGroup":
                     Value = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtRxGroup_38")).Enabled;
                     Assert.IsFalse(Value, p0 + " is not disabled");
                    break;
                case "RXBIN":
                    Value = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtRXBIN_36")).Enabled;
                    Assert.IsFalse(Value, p0 + " is not disabled");
                    break;
                case "RXPCN":
                    Value = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtRXPCN_37")).Enabled;
                    Assert.IsFalse(Value, p0 + " is not disabled");
                    break;
            }

        }


        [Then(@"Verify Member Info Page Transaction tab Transaction Status is set to Canceled")]
        public void ThenVerifyMemberInfoPageTransactionTabTransactionStatusIsSetToCanceled(Table table)
        {


            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.MemberInformation.TransactionHistoryTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");
                Boolean bTransStatusMatching = false;
                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {

                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //if(AppTableRow.Equals(GherkinTableArray[iElementCounter])
                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                if (appTD.Equals("Canceled"))
                                {

                                    Assert.IsTrue(appTD.Equals("Canceled"));
                                    bTransStatusMatching = true;
                                    //Console.WriteLine("TC 61 status is found as Canceled");
                                }

                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //    //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }


                        }

                    }
                    iTableCounter++;
                    //if (bTransStatusMatching)
                    //{
                    //    Console.WriteLine("Transaction status is updated to Canceled in Transaction History");
                    //}
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (bTransStatusMatching)
                {
                    Console.WriteLine("Member Info page Transaction status is updated to Canceled in Transaction History table");
                }

                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.MemberInformation.TransactionHistoryTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }

        }



        [Then(@"Verify Member Info Page Transaction tab has row")]
        public void ThenVerifyMemberInfoPageTransactionTabHasRow(Table table)
        {


            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.MemberInformation.TransactionHistoryTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");
                //               Boolean bTransStatusMatching = false;
                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {

                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //if(AppTableRow.Equals(GherkinTableArray[iElementCounter])
                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (appTD.Equals("Canceled"))
                                //{

                                //    Assert.IsTrue(appTD.Equals("Canceled"));
                                //    bTransStatusMatching = true;
                                //    //Console.WriteLine("TC 61 status is found as Canceled");
                                //}

                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //    //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }


                        }

                    }
                    iTableCounter++;
                    //if (bTransStatusMatching)
                    //{
                    //    Console.WriteLine("Transaction status is updated to Canceled in Transaction History");
                    //}
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                //if (bTransStatusMatching)
                //{
                //    Console.WriteLine("Member Info page Transaction status is updated to Canceled in Transaction History table");
                //}

                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                //baseTable = EAM.MemberInformation.TransactionHistoryTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }

        }

        [Then(@"Verify Member Info Page Transaction tab has row for TC ""(.*)""")]

        [Then(@"Verify Member Info Page Transaction tab has row for TC ""(.*)""")]
        public void ThenVerifyMemberInfoPageTransactionTabHasRowForTC(int TC, Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();
            IWebElement tempElement = null;
            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.MemberInformation.TransactionHistoryTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");
                //               Boolean bTransStatusMatching = false;
                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {

                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //if(AppTableRow.Equals(GherkinTableArray[iElementCounter])
                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (appTD.Equals("Canceled"))
                                //{

                                //    Assert.IsTrue(appTD.Equals("Canceled"));
                                //    bTransStatusMatching = true;
                                //    //Console.WriteLine("TC 61 status is found as Canceled");
                                //}

                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //    //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            if (bThisRowMatches)
                            {
                                IWebElement thistransID = ApplicationRow.Element[2];
                                if (thistransID.Text.ToString().Trim().Equals(TC.ToString()))
                                {
                                    IWebElement thisEditTD = ApplicationRow.Element[0];
                                    IWebElement thisEditLink = thisEditTD.FindElement(By.TagName("a"));
                                    tempElement = thisEditLink;

                                }


                            }

                        }

                    }
                    iTableCounter++;
                    //if (bTransStatusMatching)
                    //{
                    //    Console.WriteLine("Transaction status is updated to Canceled in Transaction History");
                    //}
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                //if (bTransStatusMatching)
                //{
                //    Console.WriteLine("Member Info page Transaction status is updated to Canceled in Transaction History table");
                //}
                tempElement.Click();
                tmsWait.Hard(2);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {

                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                //baseTable = EAM.MemberInformation.TransactionHistoryTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            

        }
    }





        [When(@"Administration Status Override Table Member Search Row Edit Link is clicked")]
        public void WhenAdministrationStatusOverrideTableMemberSearchRowEditLinkIsClicked(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.AdministrationStatusoverride.MemberSearchTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index > 0)
                        {
                            index++;
                            //string xPath = "//tr[" + index + "]//img[@alt='Edit']";
                            string xPath = "//a[text()='Edit']";

                            IWebElement editIcon = EAM.AdministrationStatusoverride.MemberSearchTable.FindElement(By.XPath(xPath));
                            editIcon.Click();

                            try
                            {
                                editIcon.SendKeys(OpenQA.Selenium.Keys.Enter);
                            }
                            catch (Exception) { }
                            //tmsWait.Hard(2);
                            //tmsWait.WaitForReadyStateComplete(30);
                            ////IWebElement objHIC = tmsWait.WaitForElementExist(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtHic_01"),30);
                            //IWebElement objHIC = tmsWait.WaitForElementExist(By.XPath(".//*[@id='dgMember']/tbody/tr[2]/td[9]/a"),30);

                            Console.WriteLine("Edit icon was clicked");
                        }
                        else { Assert.Fail("Edit Icon for expected row was not found"); }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("New1: {0}", e.Message);
            }
        }

        [Then(@"Verify ""(.*)"" field is disabled")]
        public void ThenVerifyFieldIsDisabled(string p0)
        {
            tmsWait.Hard(3);
            switch (p0.ToLower())
            {
                case "rxgroup":
                    Boolean isdis = false;
                    string isdisabled = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtRxGroup_38")).GetAttribute("disabled");
                    if(isdisabled=="true")
                    {
                        isdis = true;
                    }
                    Assert.IsTrue(isdis, "rxgroup field is not disabled");
                    break;
                case "rxpcn":
                    Boolean isdispcn = false;
                    string isdisabledpcn = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtRXPCN_37")).GetAttribute("disabled");
                    if (isdisabledpcn == "true")
                    {
                        isdispcn = true;
                    }
                    Assert.IsTrue(isdispcn, "rxgroup field is not disabled");
                    break;
            }
        }


        [Then(@"View Edit Member Page Record source is set to ""(.*)""")]
        public void ThenViewEditMemberPageRecordSourceIsSetTo(string p0)
        {
            string actualsource = Browser.Wd.FindElement(By.XPath("//span[contains(., '" + p0 + "')]")).Text;
            Assert.AreEqual(p0, actualsource, "Program source is not as expected");
        }

    }
}







