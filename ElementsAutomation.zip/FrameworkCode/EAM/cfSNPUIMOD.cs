﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1
{
    [Binding]
    class cfSNPUIMOD
    {

        public static View_Special_Need_Plan View_Special_Need_Plan { get { return new View_Special_Need_Plan(); } }

    }

    [Binding]
    public class View_Special_Need_Plan
    {

        //public IWebElement snp_lbl_suspectStatus { get { return Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='snp-txt-verificationDate']//input[@class='k-input']")); } }
        //public IWebElement snp_lbl_verificationResult { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='snp-select-verificationResult']/parent::div//span[@class='k-select']")); } }
        //public IWebElement snp_lbl_sourceOfVerification { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='outOfArea-select-ssrs']/parent::div//span[@class='k-select']")); } }
        public IWebElement snp_lbl_sourceOfVerification { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='snp-lbl-sourceOfVerification']")); } }
        public IWebElement snp_lbl_verificationResult { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='snp-lbl-verificationResult']")); } }
        public IWebElement snp_lbl_monthsOfEligibility { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='snp-lbl-monthsOfEligibility']")); } }
        public IWebElement snp_lbl_endDateGracePeriod { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='snp-lbl-endDateGracePeriod']")); } }

        public IWebElement snp_lbl_snpStatus { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='snp-lbl-snpStatus']")); } }
        public IWebElement snp_lbl_followUpMethod { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='snp-lbl-followUpMethod']")); } }

        public IWebElement snp_lbl_followUpDate { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='snp-lbl-followUpDate']")); } }

        public IWebElement snp_lbl_userModified { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='snp-lbl-userModified']")); } }

        public IWebElement snp_lbl_datemodified { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='snp-lbl-dateModified']")); } }

        public IWebElement snp_button_save { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='snp-button-save']")); } }

        public IWebElement snp_button_cancel { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='snp-button-cancel']")); } }

        public IWebElement VIEW_NOTES_AND_ACTIONS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='memberInfo-btn-viewNotes']")); } }

        public IWebElement VIEW_OOA { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='memberInfo-btn-viewOoa']")); } }

        public IWebElement VIEW_ATTACHMENTS { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='memberInfo-btn-viewAttachments']")); } }

        public IWebElement AUDIT_HISTORY { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='memberInfo-link-viewAudit']")); } }

        public IWebElement VIEW_SNP { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='memberInfo-btn-viewSnp']")); } }

        public IWebElement VerificationDate { get { return Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='snp-txt-verificationDate']//span[@role='button']")); } }

        public IWebElement FollowUpDate { get { return Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='snp-txt-followUpDate']//span[@role='button']")); } }

        public IWebElement DateModified { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='snp-txt-dateModified']")); } }

        public IWebElement StaticMessage { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_vMmpStateTransactions_uc_lblMessage")); } }

        public IWebElement ComAction { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='snpCompleteAction-button-completeAction']")); } }

        public IWebElement ComActionDialogue { get { return Browser.Wd.FindElement(By.XPath("(//div[@role='dialog'])[2]")); } }

        public IWebElement ComActionDialogueYES { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='confirmationDialog-btn-Yes']")); } }
        public IWebElement ComActionDialogueNO { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='confirmationDialog-btn-No']")); } }

        public IWebElement VerificationResultDrp { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'Verification Result')]/parent::div//span[@class='k-select']")); } }

        public IWebElement SNPStatusDrp { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'SNP Status')]/parent::div//span[@class='k-select']")); } }

        public IWebElement OnholdTransstatus { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='ApplicationDispositionActionsOnHoldTransactionStatus']//span[@class='k-select']")); } }

        public IWebElement ONholdreason { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='ApplicationDispositionActionsOnHoldReason']//span[@class='k-select']")); } }


        public IWebElement MedicaidLevel { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='SpecialNeedPlanMedicaidLevel']")); } }


        public IWebElement DisenrollLossSNPLetterCount { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='frmLetters-spn-preCmsLetterName'][contains(.,'Disenroll Loss SNP')]")); } }
    }
}