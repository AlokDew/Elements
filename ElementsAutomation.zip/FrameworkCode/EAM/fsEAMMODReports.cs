﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using TMSoR1.FrameworkCode;

namespace TMSoR1
{
    [Binding]
    class fsEAMMODReports
    {

        [Given(@"I Clicked on Reports link")]
        [When(@"I Clicked on Reports link")]
        public void GivenIClickedOnReportsLink()
        {
            //Browser.callWiniumDesktopDriver(); // Calling Winium to handle Authentication
            // tmsWait.Hard(2);
            //fw.ExecuteJavascript(cfEAMMODReports.EAMMODReports.EAMReportsLink);
            //tmsWait.Hard(5);
            //tmsWait.Hard(2);
            //fw.ExecuteJavascript(cfEAMMODReports.EAMMODReports.EAMReportsLink);
            //tmsWait.Hard(5);
        }

        [When(@"Edit Transaction diaglog Status drop down is set to ""(.*)""")]
        public void WhenEditTransactionDiaglogStatusDropDownIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            string value = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='statusOverrideTransaction-select-ddlTransactionStatus']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + value + "']");


                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
            }
            else
            {
                UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODEAMAdmin.StatusOverride.StatusDrp, value);
                if (value.Equals("Passed BEQ"))
                {

                }
                else
                {
                    // cfUIMODEAMAdmin.StatusOverride.TRC.SendKeys(Keys.Tab);
                }
            }

        }


        [When(@"Edit Transaction diaglog Effective Date is set to ""(.*)""")]
        public void WhenEditTransactionDiaglogEffectiveDateIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);

            tmsWait.Hard(2);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//kendo-datepicker[@test-id='statusOverrideTransaction-txt-effectiveDate']//span[@role='button']");
                AngularFunction.enterDate(Drp, value);
            }
            else
            {
                ReUsableFunctions.enterValueOnWebElementWithoutClear(cfUIMODEAMAdmin.StatusOverride.EffectiveDate, value);
            }
        }

        [When(@"Edit Transaction diaglog TRC is set to ""(.*)""")]
        public void WhenEditTransactionDiaglogTRCIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string value = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.CssSelector("[test-id='statusOverrideTransaction-txt-trc']");
                Browser.Wd.FindElement(Drp).Clear();
                Browser.Wd.FindElement(Drp).SendKeys(value);
            }
            else
            {
                ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.StatusOverride.TRC, value);
                cfUIMODEAMAdmin.StatusOverride.TRC.SendKeys(Keys.Tab);
            }


        }

        [When(@"Edit Transaction diaglog Reply Date is set to ""(.*)""")]
        public void WhenEditTransactionDiaglogReplyDateIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//kendo-datepicker[@test-id='statusOverrideTransaction-txt-newReplyDate']//span[@role='button']");
                //ReUsableFunctions.enterDateUsingAngularChanges(Drp, value);
                AngularFunction.enterDate(Drp, value);
            }
            else
            {
                ReUsableFunctions.enterValueOnWebElementWithoutClear(cfUIMODEAMAdmin.StatusOverride.ReplyDate, value);

            }
        }

        [When(@"Edit Transaction diaglog ElectionType is set to ""(.*)""")]
        public void WhenEditTransactionDiaglogElectionTypeIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODEAMAdmin.StatusOverride.ElectionType, value);
        }


        [When(@"Edit Transaction diaglog Disenrollment Reason is set to ""(.*)""")]
        public void WhenEditTransactionDiaglogDisenrollmentReasonIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.StatusOverride.DisEnrollmentReason, value);
        }

        [When(@"Edit Transaction diaglog Rx ID is set to ""(.*)""")]
        public void WhenEditTransactionDiaglogRxIDIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            try
            {
                ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.StatusOverride.RxID, value);
            }
            catch
            {
                fw.ConsoleReport(" Elements are not interactible");
            }
        }

        [When(@"Dashboard image ""(.*)"" is Clicked")]
        public void WhenDashboardImageIsClicked(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            string testid = "eamDashboard-img-" + value.ToLower();
            IWebElement ele;

            tmsWait.Hard(2);

            if (ConfigFile.tenantType == "tmsx")
            {
                ele = Browser.Wd.FindElement(By.CssSelector("[test-id='eamDashboard-lbl-letters']"));
                fw.ExecuteJavascript(ele);
            }
            else
            {
                ele = Browser.Wd.FindElement(By.XPath("//img[@test-id='" + testid + "']"));
                fw.ExecuteJavascript(ele);
            }
        }

        [When(@"EAM Dashboard page image ""(.*)"" is Clicked")]
        public void WhenEAMDashboardPageImageIsClicked(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            IWebElement ele;

            tmsWait.Hard(2);

            ele = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + value + "')]"));
            fw.ExecuteJavascript(ele);

            tmsWait.Hard(10);
        }

        [When(@"EAM Dashboard page Key Additional Information section Label ""(.*)"" is saved to variable ""(.*)""")]
        public void WhenEAMDashboardPageKeyAdditionalInformationSectionLabelIsSavedToVariable(string p0, string p1)
        {
            IWebElement ele;
            string value = tmsCommon.GenerateData(p0);

            tmsWait.Hard(2);

            ele = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + value + "')]/following-sibling::span"));

            string result = ele.Text;
            fw.setVariable(p1, result);
        }

        [Then(@"Verify EAM Dashboard page Section ""(.*)"" is Present")]
        public void ThenVerifyEAMDashboardPageSectionIsPresent(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            IWebElement ele;

            tmsWait.Hard(2);

            ele = Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + value + "')]"));
            Assert.IsTrue(ele.Displayed);
        }

        [Then(@"Verify EAM Dashboard page Member Information section Pie Chart is Present")]
        public void ThenVerifyEAMDashboardPageMemberInformationSectionPieChartIsPresent()
        {
            IWebElement ele;

            tmsWait.Hard(2);

            ele = Browser.Wd.FindElement(By.XPath("//kendo-chart[@test-id='memberInformation-div-activeMemberGraph']"));
            Assert.IsTrue(ele.Displayed);
        }

        [When(@"Verify Status Override page displayed warning msg ""(.*)""")]
        public void WhenVerifyStatusOverridePageDisplayedWarningMsg(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            tmsWait.Hard(2);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//span[contains(text(),'" + value + "')]"));
            Assert.IsTrue(ele.Displayed);
        }
        [When(@"Status Override page displayed section ""(.*)"" component is set to ""(.*)""")]
        public void WhenStatusOverridePageDisplayedSectionComponentIsSetTo(string p0, string p1)
        {
            string value = tmsCommon.GenerateData(p1);
            IWebElement drp = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='ddlElectionType_listbox']"));
            fw.ExecuteJavascript(drp);

            tmsWait.Hard(2);
            IWebElement element = Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + value + "')]"));
            fw.ExecuteJavascript(element);
            tmsWait.Hard(2);
        }

        [When(@"Edit Transaction diaglog Save Button is Clicked")]
        public void WhenEditTransactionDiaglogSaveButtonIsClicked()
        {
            ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.StatusOverride.SaveButton);
            tmsWait.Hard(5);

            try
            {
                UIMODUtilFunctions.clickOnConfirmationYesDialog();
            }
            catch
            {
                fw.ConsoleReport(" There is no confirmation dialog");
            }
            tmsWait.Hard(5);
        }

        [When(@"Member Details diaglog New Member is set to ""(.*)""")]
        public void WhenMemberDetailsDiaglogNewMemberIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.StatusOverride.NewMemberID, value);
        }

        [When(@"Member Details diaglog Plan ID drop down is set to ""(.*)""")]
        public void WhenMemberDetailsDiaglogPlanIDDropDownIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='statusOverride-ddl-planId']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + value + "']");





                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);




            }
            else
            {
                new SelectElement(cfUIMODEAMAdmin.StatusOverride.PlanID).SelectByText(value);
            }
        }

        [When(@"Member Details diaglog PBP ID drop down is set to ""(.*)""")]
        public void WhenMemberDetailsDiaglogPBPIDDropDownIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='statusOverride-ddl-pbpId']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + value + "']");





                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);




            }
            else
            {
                new SelectElement(cfUIMODEAMAdmin.StatusOverride.PBPID).SelectByText(value);
            }
        }

        [When(@"Member Details diaglog Member Status drop down is set to ""(.*)""")]
        public void WhenMemberDetailsDiaglogMemberStatusDropDownIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                ReUsableFunctions.selectDropDownValueUsingAngularChanges(cfUIMODEAMAdmin.StatusOverride.AngularMemberStatusDrp, value);

            }
            else
            {

                UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODEAMAdmin.StatusOverride.MemberStatusDrp, value);
            }
        }

        [When(@"Member Details diaglog RxID is set to ""(.*)""")]
        public void WhenMemberDetailsDiaglogRxIDIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.StatusOverride.MemberRxID, value);
        }

        [When(@"Member Details diaglog Save Button is Clicked")]
        public void WhenMemberDetailsDiaglogSaveButtonIsClicked()
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.StatusOverride.AngularMemberSaveButton);
            }
            else
            {
                ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.StatusOverride.MemberSaveButton);
            }

            tmsWait.Hard(3);
        }


        [When(@"I Clicked on Member New link")]
        public void WhenIClickedOnMemberNewLink()
        {
            
        }

        [When(@"I Clicked on Tasks link")]
        public void WhenIClickedOnTasksLink()
        {
            tmsWait.Hard(2);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@title='Tasks']"));
            fw.ExecuteJavascript(ele);
        }

        [When(@"I Clicked on Imports link under Task Section")]
        public void WhenIClickedOnImportsLinkUnderTaskSection()
        {
            // fw.ExecuteJavascript(cfEAMMODReports.EAMMODReports.EAMImportsLink);
        }

        [When(@"I Clicked on Exports link under Task Section")]
        public void WhenIClickedOnExportsLinkUnderTaskSection()
        {
            //fw.ExecuteJavascript(cfEAMMODReports.EAMMODReports.EAMExportsLink);
            //tmsWait.Hard(4);
        }
        [When(@"I Clicked on Actions link under Task Section")]
        public void WhenIClickedOnActionsLinkUnderTaskSection()
        {
            tmsWait.Hard(4);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@title='Tasks']"));
            fw.ExecuteJavascript(ele);
            IWebElement actions = Browser.Wd.FindElement(By.XPath("(//span[contains(.,'Actions')])[1]"));
            //fw.ExecuteJavascript(actions);
            MouseFunctions.MouseMoveToElement(actions);

        }
        [Then(@"Verify Actions link under Task Section is not present")]
        public void ThenVerifyActionsLinkUnderTaskSectionIsNotPresent()
        {
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@title='Tasks']"));
            fw.ExecuteJavascript(ele);
            try
            {
                IWebElement actions = Browser.Wd.FindElement(By.XPath("(//span[contains(.,'Actions')])[1]"));
            }
            catch (TimeoutException e)
            {
                Assert.IsTrue(true);
            }
            catch (WebDriverException e1)
            {
                Assert.IsTrue(true);
            }
        }
        [Then(@"Verify ""(.*)"" page displayed")]
        public void ThenVerifyPageDisplayed(string p0)
        {

            tmsWait.Hard(10);

            IWebElement ele = Browser.Wd.FindElement(By.XPath("//div[@class='flex-fill'][contains(.,'" + p0 + "')]"));
            tmsWait.Hard(4);
            Assert.IsTrue(ele.Displayed);


        }
        [Then(@"I navigated to FRM URL and Verify error ""(.*)""")]
        public void ThenINavigatedToFRMURLAndVerifyError(string p0)
        {
            string url = Browser.Wd.Url;
            string frmurl = url.Replace("ram", "frm");
            Browser.Wd.Navigate().GoToUrl(frmurl);
            tmsWait.Hard(4);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//div/h2[contains(text(),'" + p0 + "')]"));
            tmsWait.Hard(4);
            Assert.IsTrue(ele.Displayed);
        }
        [Then(@"I navigated to ""(.*)"" URL and Verify error ""(.*)""")]
        public void ThenINavigatedToURLAndVerifyError(string p0, string p1)
        {
            string url = Browser.Wd.Url;
            string frmurl = url.Replace("eam", p0.ToLower());
            Browser.Wd.Navigate().GoToUrl(frmurl);
            tmsWait.Hard(4);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//div[contains(text(),'" + p1 + "')]"));
            tmsWait.Hard(4);
            Assert.IsTrue(ele.Displayed);
        }
        [Then(@"I navigated to ""(.*)"" URL replaced with ""(.*)"" and Verify error ""(.*)""")]
        public void ThenINavigatedToURLReplacedWithAndVerifyError(string p0, string p1, string p2)
        {

            string url = Browser.Wd.Url;
            string frmurl = url.Replace(p1.ToLower(), p0.ToLower());
            Browser.Wd.Navigate().GoToUrl(frmurl);
            tmsWait.Hard(4);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//div[contains(text(),'" + p2 + "')]"));
            tmsWait.Hard(4);
            Assert.IsTrue(ele.Displayed);
        }

        [Then(@"Verify error ""(.*)"" is displayed")]
        public void ThenVerifyErrorIsDisplayed(string p0)
        {
            tmsWait.Hard(10);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[contains(text(),'" + p0 + "')]"));
            tmsWait.Hard(4);
            Assert.IsTrue(ele.Displayed);
        }

        [Then(@"Verify TC(.*) page displayed")]
        public void ThenVerifyTCPageDisplayed(int p0)
        {
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//a[@title='TC90']"));
            tmsWait.Hard(4);
            Assert.IsTrue(ele.Displayed);
        }

        [Then(@"Verify Task Section is not displayed")]
        public void ThenVerifyTaskSectionIsNotDisplayed()
        {

            try
            {
                IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@title='Tasks']"));

            }
            catch (TimeoutException e)
            {
                Assert.IsTrue(true);
            }
            catch (WebDriverException e1)
            {
                Assert.IsTrue(true);
            }
        }


        [When(@"File Processing Status page File Type drop down is selected as ""(.*)""")]
        public void WhenFileProcessingStatusPageFileTypeDropDownIsSelectedAs(string p0)
        {
            string filetype = tmsCommon.GenerateData(p0);

            if (ConfigFile.EnvType.Equals("ESI") || ConfigFile.EnvType.Equals("Main"))
            {
                if (filetype.Equals("Legacy File"))
                {
                    filetype = "Legacy Transaction File";
                }

                IWebElement drp;

                if (ConfigFile.tenantType == "tmsx")
                {
                    drp = Browser.Wd.FindElement(By.XPath("//*[@test-id='jobProcessingStatus-txt-ddlJobName']/span/span"));
                }
                else
                {
                    drp = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='ddlJobName_listbox']"));
                }

                fw.ExecuteJavascript(drp);
                tmsWait.Hard(2);
                IWebElement element = Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + filetype + "')]"));
                fw.ExecuteJavascript(element);
                tmsWait.Hard(2);
                IWebElement search = Browser.Wd.FindElement(By.CssSelector("[test-id='jobProcessingStatus-button-search']"));
                fw.ExecuteJavascript(search);
            }
            else
            {

                IWebElement drp = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='formFileType_listbox']"));
                fw.ExecuteJavascript(drp);

                tmsWait.Hard(2);
                IWebElement element = Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + filetype + "')]"));
                fw.ExecuteJavascript(element);
                tmsWait.Hard(2);
                IWebElement search = Browser.Wd.FindElement(By.CssSelector("[test-id='trrlogging-btn-Search']"));
                fw.ExecuteJavascript(search);
            }
        }

        [When(@"Letter Type is set to ""(.*)""")]
        public void WhenLetterTypeIsSetTo(string value)
        {
            tmsWait.Hard(2);
            IWebElement drp = Browser.Wd.FindElement(By.CssSelector("[test-id='LetterType']"));
            new SelectElement(drp).SelectByText(value);
        }


        [When(@"ReportPage Start Date is set to ""(.*)""")]
        public void WhenReportPageStartDateIsSetTo(string p0)
        {
            IWebElement date = Browser.Wd.FindElement(By.CssSelector("[test-id='StartDate']"));
            fw.ExecuteJavascriptSetText(date, p0);

        }

        [Then(@"Verify message display as ""(.*)""")]
        public void ThenVerifyMessageDisplayAs(string p0)
        {
            By loc = By.XPath("//span[@test-id='recalculations-spn-yearlyInProgress'][contains(.,'" + p0 + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }

        [Given(@"ReportPage Earliest Effective Date is set to ""(.*)""")]
        public void GivenReportPageEarliestEffectiveDateIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string GeneratedData = tmsCommon.GenerateData(p0.ToString());
            IWebElement EarliestEffDate = Browser.Wd.FindElement(By.XPath("//*[@id='txtExportCmsEarliestEffDate']"));
            fw.ExecuteJavascriptSetText(EarliestEffDate, GeneratedData);
        }



        [When(@"ReportPage End Date is set to ""(.*)""")]
        public void WhenReportPageEndDateIsSetTo(string p0)
        {
            IWebElement date = Browser.Wd.FindElement(By.CssSelector("[test-id='EndDate']"));
            fw.ExecuteJavascriptSetText(date, p0);
        }


        [Given(@"ReportPage Latest Effective Date is set to ""(.*)""")]
        public void GivenReportPageLatestEffectiveDateIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string GeneratedData = tmsCommon.GenerateData(p0.ToString());
            IWebElement latestEffdate = Browser.Wd.FindElement(By.Id("txtExportCmsLatestEffDate"));
            fw.ExecuteJavascriptSetText(latestEffdate, GeneratedData);
        }

        [Given(@"ReportPage PlanID is set to ""(.*)""")]
        public void GivenReportPagePlanIDIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string GeneratedData = tmsCommon.GenerateData(p0.ToString());
            IWebElement PlanId = Browser.Wd.FindElement(By.Id("planId"));
            //fw.ExecuteJavascript(PlanId);
            fw.ExecuteJavascriptSetText(PlanId, GeneratedData);
            tmsWait.Hard(2);
        }

        [When(@"I have Navigated to EAM Configuration Page ""(.*)"" section")]
        public void WhenIHaveNavigatedToEAMConfigurationPageSection(string link)
        {
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//li[@test-id='eamConfigurations-li-eamConfigurationsList']/label[contains(.,'" + link + "')]")));
            tmsWait.Hard(5);
        }

        [Given(@"i edit the user ""(.*)"" role")]
        public void GivenIEditTheUserRole(string p0)
        {
            IWebElement lastPage = Browser.Wd.FindElement(By.XPath("//*[@title='Go to the last page']"));
            lastPage.Click();
            tmsWait.Hard(3);
            string user = tmsCommon.GenerateData(p0);
            tmsWait.Hard(1);

            IWebElement editIcon = Browser.Wd.FindElement(By.XPath("//tr[contains(.,'" + user + "')]//td[11]/a"));
            editIcon.Click();
            tmsWait.Hard(5);

        }

        [Given(@"i click on UPDATE button")]
        public void GivenIClickOnUPDATEButton()
        {
            IWebElement updateBtn = Browser.Wd.FindElement(By.XPath("//*[@class='btn primaryButton' and contains(.,'UPDATE')][1]"));
            updateBtn.Click();
            tmsWait.Hard(4);
        }
        [When(@"verify UI of the PastDueActions Report page")]
        public void WhenVerifyUIOfThePastDueActionsReportPage()
        {
            string SearchCriteria = "Search Criteria: Past Due Actions";
            string defaultSelected = "All";
            string actTitleText = Browser.Wd.FindElement(By.XPath("//span[@test-id='report-title-searchCriteria']")).Text;
            Assert.AreEqual(SearchCriteria, actTitleText.Trim(), "Heading Notes and Actions is not displayed");
            //   IWebElement Searchs = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Search Criteria: Notes/Actions') ] "));
            //  Assert.IsTrue(Searchs.Displayed, "Search Criteria: Notes/Actions is not displayed");

            tmsWait.Hard(2);
            IWebElement Action_Note = Browser.Wd.FindElement(By.XPath("//select[@test-id='UserCreated']/option[@selected='selected']"));
            Assert.AreEqual(defaultSelected, Action_Note.Text, "UserCreated by default selected option is not displayed");
            IWebElement DateCreated_From = Browser.Wd.FindElement(By.XPath("//input[@test-id='DateCreated_From']"));
            Assert.IsTrue(DateCreated_From.Displayed, "Action_Note by default selected option is not displayed");

            IWebElement DateCreated_To = Browser.Wd.FindElement(By.XPath("//input[@test-id='DateCreated_To']"));
            Assert.IsTrue(DateCreated_To.Displayed, "Action_Note by default selected option is not displayed");

            IWebElement DateDue_From = Browser.Wd.FindElement(By.XPath("//input[@test-id='DateDue_From']"));
            Assert.IsTrue(DateDue_From.Displayed, "Action_Note by default selected option is not displayed");
            IWebElement DateDue_To = Browser.Wd.FindElement(By.XPath("//input[@test-id='DateDue_To']"));
            Assert.IsTrue(DateDue_To.Displayed, "Action_Note by default selected option is not displayed");

            IWebElement Completed = Browser.Wd.FindElement(By.XPath("//input[@test-id='Completed']"));
            Assert.IsTrue(Completed.Displayed, "Action_Note by default selected option is not displaye");


            IWebElement button = Browser.Wd.FindElement(By.XPath("//button[@test-id='report-btn-reset']"));
            Assert.IsTrue(button.Displayed, "Reset button is not displayed");

            IWebElement rdInteractiveYes = Browser.Wd.FindElement(By.XPath("//input[@id='rdInteractiveYes']"));
            Assert.IsTrue(rdInteractiveYes.Selected, "All option is displayed");
            IWebElement CSV = Browser.Wd.FindElement(By.XPath("//input[@type='radio'][@value='CSV']"));
            Assert.IsFalse(CSV.Enabled, "Notes option is not displayed");
            IWebElement PDF = Browser.Wd.FindElement(By.XPath("//input[@type='radio'][@value='PDF']"));
            Assert.IsFalse(PDF.Enabled, "Notes option is not displayed");
            IWebElement XLSX = Browser.Wd.FindElement(By.XPath("//input[@type='radio'][@value='XLSX']"));
            Assert.IsFalse(XLSX.Enabled, "XLSX");
        }

        [When(@"verify UI of the NotesActions Report page")]
        public void WhenVerifyUIOfTheNotesActionsReportPage()
        {
            string SearchCriteria = "Search Criteria: Notes/Actions";
            string defaultSelected = "All";
            string actTitleText = Browser.Wd.FindElement(By.XPath("//span[@test-id='report-title-searchCriteria']")).Text;
            Assert.AreEqual(SearchCriteria, actTitleText.Trim(), "Heading Notes and Actions is not displayed");
            //   IWebElement Searchs = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Search Criteria: Notes/Actions') ] "));
            //  Assert.IsTrue(Searchs.Displayed, "Search Criteria: Notes/Actions is not displayed");

            tmsWait.Hard(2);
            IWebElement Action_Note = Browser.Wd.FindElement(By.XPath("//select[@test-id='Action_Note']/option[@selected='selected']"));
            Assert.AreEqual(defaultSelected, Action_Note.Text, "Action_Note by default selected option is not displayed");
            IWebElement DateCreated_From = Browser.Wd.FindElement(By.XPath("//input[@test-id='DateCreated_From']"));
            Assert.IsTrue(DateCreated_From.Displayed, "Action_Note by default selected option is not displayed");

            IWebElement DateCreated_To = Browser.Wd.FindElement(By.XPath("//input[@test-id='DateCreated_To']"));
            Assert.IsTrue(DateCreated_To.Displayed, "Action_Note by default selected option is not displayed");

            IWebElement DateDue_From = Browser.Wd.FindElement(By.XPath("//input[@test-id='DateDue_From']"));
            Assert.IsTrue(DateDue_From.Displayed, "Action_Note by default selected option is not displayed");
            IWebElement DateDue_To = Browser.Wd.FindElement(By.XPath("//input[@test-id='DateDue_To']"));
            Assert.IsTrue(DateDue_To.Displayed, "Action_Note by default selected option is not displayed");

            IWebElement Completed = Browser.Wd.FindElement(By.XPath("//input[@test-id='Completed']"));
            Assert.IsTrue(Completed.Displayed, "Action_Note by default selected option is not displaye");


            IWebElement button = Browser.Wd.FindElement(By.XPath("//button[@test-id='report-btn-reset']"));
            Assert.IsTrue(button.Displayed, "Reset button is not displayed");

            IWebElement rdInteractiveYes = Browser.Wd.FindElement(By.XPath("//input[@id='rdInteractiveYes']"));
            Assert.IsTrue(rdInteractiveYes.Selected, "All option is displayed");
            IWebElement CSV = Browser.Wd.FindElement(By.XPath("//input[@type='radio'][@value='CSV']"));
            Assert.IsFalse(CSV.Enabled, "Notes option is not displayed");
            IWebElement PDF = Browser.Wd.FindElement(By.XPath("//input[@type='radio'][@value='PDF']"));
            Assert.IsFalse(PDF.Enabled, "Notes option is not displayed");
            IWebElement XLSX = Browser.Wd.FindElement(By.XPath("//input[@type='radio'][@value='XLSX']"));
            Assert.IsFalse(XLSX.Enabled, "XLSX");
            //IWebElement typeActions = Browser.Wd.FindElement(By.XPath("//*[@test-id='notesSearch-label-actions']"));
            //Assert.IsTrue(typeActions.Displayed, "Actions option is not displayed");
            //IWebElement status = Browser.Wd.FindElement(By.XPath("//*[@test-id='notesSearch-lbl-user' and contains(.,'Status')]"));
            //Assert.IsTrue(status.Displayed, "Status field is not displayed");
            //IWebElement resetBtn = Browser.Wd.FindElement(By.Id("btnReset"));
            //Assert.IsTrue(resetBtn.Displayed, "Reset button is not displayed");
            //IWebElement searchBtn = Browser.Wd.FindElement(By.Id("btnSearch"));
            //Assert.IsTrue(searchBtn.Displayed, "Search button is not displayed");
            //IWebElement userDefaultvalue = Browser.Wd.FindElement(By.XPath("//*[@aria-owns='inputBoxUsername_listbox']/span/span[1]"));
            //Assert.IsTrue(userDefaultvalue.Displayed, "User dropdown default value is not correct");
        }

        [When(@"verify UI of the page")]
        [When(@"verify UI of Notes and Actions page")]
        [Given(@"verify UI of Notes and Actions page")]
        [Then(@"verify UI of Notes and Actions page")]
        public void WhenVerifyUIOfThePage()
        {
            string pageTitle = "Notes and Actions";
            string actTitleText = Browser.Wd.FindElement(By.XPath("//*[@test-id='memberSearch-span-title']")).Text;
            Assert.AreEqual(pageTitle, actTitleText, "Heading Notes and Actions is not displayed");
            IWebElement mbiTextbox = Browser.Wd.FindElement(By.XPath("//label[@class='ng-binding' and contains(., 'MBI')]"));
            Assert.IsTrue(mbiTextbox.Displayed, "MBI text box is not displayed");
            IWebElement user = Browser.Wd.FindElement(By.XPath("//*[@test-id='notesSearch-lbl-user' and contains(.,'User')]"));
            Assert.IsTrue(user.Displayed, "User field is not displayed");
            IWebElement typeAll = Browser.Wd.FindElement(By.XPath("//*[@test-id='notesSearch-label-rdAll']"));
            Assert.IsTrue(typeAll.Displayed, "All option is displayed");
            IWebElement typeNotes = Browser.Wd.FindElement(By.XPath("//*[@test-id='notesSearch-label-rdNotes']"));
            Assert.IsTrue(typeNotes.Displayed, "Notes option is not displayed");
            IWebElement typeActions = Browser.Wd.FindElement(By.XPath("//*[@test-id='notesSearch-label-actions']"));
            Assert.IsTrue(typeActions.Displayed, "Actions option is not displayed");
            IWebElement status = Browser.Wd.FindElement(By.XPath("//*[@test-id='notesSearch-lbl-user' and contains(.,'Status')]"));
            Assert.IsTrue(status.Displayed, "Status field is not displayed");
            IWebElement resetBtn = Browser.Wd.FindElement(By.Id("btnReset"));
            Assert.IsTrue(resetBtn.Displayed, "Reset button is not displayed");
            IWebElement searchBtn = Browser.Wd.FindElement(By.Id("btnSearch"));
            Assert.IsTrue(searchBtn.Displayed, "Search button is not displayed");
            IWebElement userDefaultvalue = Browser.Wd.FindElement(By.XPath("//*[@aria-owns='inputBoxUsername_listbox']/span/span[1]"));
            Assert.IsTrue(userDefaultvalue.Displayed, "User dropdown default value is not correct");
        }

        [Given(@"I have Navigated to ""(.*)"" section")]
        [When(@"I have Navigated to ""(.*)"" section")]
        public void GivenIHaveNavigatedToSection(string menu)
        {
            tmsWait.Hard(2);
            IWebElement link = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + menu + "')]"));

            fw.ExecuteJavascript(link);
        }




        [When(@"I have Navigated to RxM Page ""(.*)"" section")]
        [When(@"I have Navigated to EAM Page ""(.*)"" section")]
        [Then(@"I have Navigated to EAM Page ""(.*)"" section")]
        [Given(@"I have Navigated to EAM Page ""(.*)"" section")]
        [When(@"I have Navigated to Framework Page ""(.*)"" section")]
        [Then(@"I have Navigated to Framework Page ""(.*)"" section")]
        [Given(@"I have Navigated to Framework Page ""(.*)"" section")]
        public void WhenIHaveNavigatedToEAMPageSection(string menu)
        {
            tmsWait.Hard(3);


            if ((ConfigFile.EnvType.Equals("ESI") || ConfigFile.EnvType.Equals("Main")) && (menu.Equals("Import") || menu.Equals("Export")))
            {


                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Tasks']")));
                    tmsWait.Hard(3);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(., '" + menu + "')]")));
                    tmsWait.Hard(2);
                    GlobalRef.Type = tmsCommon.GenerateData(menu);
                }

                else
                {
                    GlobalRef.Type = tmsCommon.GenerateData(menu);

                }

            }

            if(menu.Equals("WorkflowStart"))
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Workflow']")));
                tmsWait.Hard(3);
                menu = "Start";
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(., '" + menu + "')]")));
                tmsWait.Hard(2);

            }


            if (menu.Equals("Tasks"))
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Tasks']")));
                tmsWait.Hard(3);
               

            }

            if (menu.Equals("File Processing Status") || menu.Equals("Job Processing Status"))
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    try
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Job Processing Status']")));
                        tmsWait.Hard(3);
                    }
                    catch
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='File Processing Status']")));
                        tmsWait.Hard(3);
                    }
                }

                else
                {
                    IWebElement view = Browser.Wd.FindElement(By.XPath("//a[@title='Job Processing Status']"));
                    fw.ExecuteJavascript(view);
                    tmsWait.Hard(7);

                }
            }

            if ((ConfigFile.EnvType.Equals("ESI") || ConfigFile.EnvType.Equals("Main")) && menu.Equals("File Processing Status"))
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    fw.ConsoleReport(" Already selected Job Processing status");
                }

                else
                {

                    IWebElement view = Browser.Wd.FindElement(By.XPath("//a[@title='Job Processing Status']"));
                    fw.ExecuteJavascript(view);
                    tmsWait.Hard(7);

                }
            }
            else if (ConfigFile.EnvType.Equals("ESI") && menu.Equals("Reports"))
            {
                tmsWait.Hard(2);
                IWebElement link = Browser.Wd.FindElement(By.XPath("//a[@title='" + menu + "']"));

                fw.ExecuteJavascript(link);

                tmsWait.Hard(4);
                if (ConfigFile.BrowserType.ToLower().Equals("chrome"))
                {
                    fw.ConsoleReport("Handling Authentication Dialog");
                    ReUsableFunctions.reportAuthenticationHandler();

                }




                tmsWait.Hard(4);
                fw.ConsoleReport("Switching to Child Window");
                Browser.SwitchToChildWindow();
                tmsWait.Hard(4);
                //// Dont comment this code as we need this code for ESI
                //if (ConfigFile.EnvType.Equals("ESI"))
                //{
                //    string currentURL = Browser.Wd.Url;
                //    Browser.Wd.Navigate().GoToUrl(currentURL);
                //    tmsWait.Hard(4);
                //   }
                if (ConfigFile.BrowserType.Equals("chrome"))
                {
                    try
                    {
                        IWebElement advancedButton = Browser.Wd.FindElement(By.CssSelector("[id='details-button']"));
                        fw.ExecuteJavascript(advancedButton);
                        tmsWait.Hard(5);

                        IWebElement acceptRiskBtn = Browser.Wd.FindElement(By.CssSelector("[id='proceed-link']"));
                        fw.ExecuteJavascript(acceptRiskBtn);
                        tmsWait.Hard(5);

                        IWebElement advancedButton1 = Browser.Wd.FindElement(By.CssSelector("[id='details-button']"));
                        fw.ExecuteJavascript(advancedButton1);
                        tmsWait.Hard(5);

                        IWebElement acceptRiskBtn1 = Browser.Wd.FindElement(By.CssSelector("[id='proceed-link']"));
                        fw.ExecuteJavascript(acceptRiskBtn1);

                    }
                    catch
                    {
                        fw.ConsoleReport("There is no Certiicate Warning");
                    }
                }



                //Browser.Wd.Navigate().Refresh();
                tmsWait.Hard(5);
                string reportTitle = Browser.Wd.Title;
                fw.ConsoleReport(" Current Page Title --> " + reportTitle);
            }

            else
            {
                //tmsWait.Hard(5);
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    if (menu.Equals("New Transaction") || menu.Equals("View/Edit Transaction") || menu.Equals("New Member") || menu.Equals("View/Edit Member") || menu.Equals("TC 90") || menu.Equals("EAF Fallout Records"))
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Main']")));
                        tmsWait.Hard(3);


                    }

                    if (menu.Equals("Import") || menu.Equals("Export") || menu.Equals("Load Bulk Attachment") || menu.Equals("TRR Fallout") || menu.Equals("TRR Activity Logging") || menu.Equals("LEP Data File Status") || menu.Equals("Audit-View/Export"))
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Tasks']")));
                        tmsWait.Hard(3);
                    }

                    if (menu.Equals("External Integration") || menu.Equals("Facets Configuration") || menu.Equals("View/Edit Plan Info.") || menu.Equals("View/Edit Bid Data") || menu.Equals("TRR Configuration") || menu.Equals("Status Override") || menu.Equals("Export Session") || menu.Equals("Recalculations") || menu.Equals("Edit LIS Information") || menu.Equals("EAM Configuration") || menu.Equals("View/Edit Bid Data") || menu.Equals("BEQ/CMS Transfer") || menu.Equals("Manage Plan/SCC") || menu.Equals("MMP Management") || menu.Equals("Auditing Configuration") || menu.Equals("Workflow") || menu.Equals("Workflow Dashboard") || menu.Equals("EAF Fallout Configuration") || menu.Equals("EGWP Configuration") || menu.Equals("Data Transfer to Warehouse") || menu.Equals("Administration"))
                    {
                        tmsWait.Hard(3);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Administration']")));
                        tmsWait.Hard(3);
                    }

                    if (menu.Equals("Reports")) //Reports is clicked like the other menus here, but does not have a sub-menu. The return at the end of this if-then statement is meant to exit the function without executing the submenu code
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Reports']")));
                        tmsWait.Hard(3);
                        return;
                    }

                    if (menu.Equals("Letters"))
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Letters']")));
                        tmsWait.Hard(3);
                        return;
                    }

                    if (menu.Equals("Tenant Set-up"))
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Root Administration']")));
                        tmsWait.Hard(3);
                    }

                    if (menu.Equals("Jobs") || menu.Equals("Job Scheduler"))
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Jobs']")));
                        tmsWait.Hard(3);
                    }

                    if (menu.Equals("Dashboard"))
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Dashboard']")));
                        tmsWait.Hard(3);
                    }

                    try
                    {
                        tmsWait.Hard(3);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(., '" + menu + "')]")));
                        tmsWait.Hard(2);
                    }
                    catch
                    {

                    }

                }

                else
                {
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@title='" + menu + "']")));
                    tmsWait.Hard(2);
                }
            }

            //         Browser.Wd.Navigate().Refresh();

        }

        [When(@"I have Navigated to PDEM Page ""(.*)"" section")]
        [Given(@"I have Navigated to PDEM Page ""(.*)"" section")]
        [Then(@"I have Navigated to PDEM Page ""(.*)"" section")]
        public void WhenIHaveNavigatedToPDEMPageSection(string menu)
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@title='" + menu + "']")));
            tmsWait.Hard(2);
        }

        [Then(@"Verify ""(.*)"" Link is not present")]
        public void ThenVerifyLinkIsNotPresent(string p0)
        {
            IReadOnlyList<IWebElement> links = Browser.Wd.FindElements(By.TagName("a"));

            for (int i = 0; i < links.Count; i++)
            {
                if (links[i].GetAttribute("LinkText").Equals(p0))
                {
                    System.Console.WriteLine("Test Failed" + " Link should not be present");
                    Assert.Fail();
                    break;
                }
                else
                {
                    System.Console.WriteLine("Test Passed" + " Link should not be present");
                    // Assert.IsTrue(true,);
                    break;
                }

            }
        }
        [Then(@"Verify Administration Add MMP Grid does not have Delete Icons")]
        public void ThenVerifyAdministrationAddMMPGridDoesNotHaveDeleteIcons()
        {
            ICollection<IWebElement> myDeleteButtons = Browser.Wd.FindElements(By.XPath("//a[contains(@class,'Delete')]"));
            int DeleteButtonCount = myDeleteButtons.Count;
            if (DeleteButtonCount == 0)
            {
                Console.WriteLine("Confirmed, there are [" + DeleteButtonCount + "] delete buttons in the table as expected");
                Assert.AreEqual(true, true, "Confirmed, there are [" + DeleteButtonCount + "] delete buttons in the table as expected");
            }
            else
            {
                Console.WriteLine("Failed, there are [" + DeleteButtonCount + "] delete buttons in the table.  0 expected");
                Assert.AreEqual(true, false, "Failed, there are [" + DeleteButtonCount + "] delete buttons in the table.  0 expected");
            }
        }

        [Then(@"verify Elements Exist")]
        public void ThenVerifyElementsExist(Table table)
        {
            foreach (var row in table.Rows)
            {
                var thisElementName = row["Element"];
                //                EAMAdministrationMMP.FindClassObjects();
                Console.WriteLine("Testing Element Exists " + thisElementName);
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    switch (thisElementName)
                    {
                        case "PBP": { fw.ReportOn(cfUIMODEAMAdmin.MMPManagement.StateDropdownlistAngJS, thisElementName); break; }
                        case "Transaction Code": { fw.ReportOn(cfUIMODEAMAdmin.MMPManagement.TCCodeDropdownlistAngJS, thisElementName); break; }
                        case "Transaction Status": { fw.ReportOn(cfUIMODEAMAdmin.MMPManagement.TCStatusDropdownlistAngJS, thisElementName); break; }
                        case "TRC": { fw.ReportOn(cfUIMODEAMAdmin.MMPManagement.TCCodeDropdownlistAngJS, thisElementName); break; }
                        case "Effective Date": { fw.ReportOn(cfUIMODEAMAdmin.MMPManagement.EffectiveDateAngJS, thisElementName); break; }
                        case "Termination Date": { fw.ReportOn(cfUIMODEAMAdmin.MMPManagement.TermDatAngJSe, thisElementName); break; }
                        // case "Effective Date Calendar": { fw.ReportOn(EAM.AdministrationMMP.EffectiveDateCalendar, thisElementName); break; }
                        //case "Termination Date Calendar": { fw.ReportOn(EAM.AdministrationMMP.TerminationDateCalendar, thisElementName); break; }
                        case "Save": { fw.ReportOn(cfUIMODEAMAdmin.MMPManagement.ADDBtnAngJS, thisElementName); break; }
                        case "Reset": { fw.ReportOn(cfUIMODEAMAdmin.MMPManagement.ResetBtnAngJS, thisElementName); break; }
                        //  case "Results Table": { fw.ReportOn(cfUIMODEAMAdmin.MMPManagement, thisElementName); break; }
                        default: { Assert.AreEqual(true, false, "No Element handler available in 'ThenElementsExist' for [" + thisElementName + "]"); break; }
                    }
                }

                else
                {
                    switch (thisElementName)
                    {
                        case "PBP": { fw.ReportOn(cfUIMODEAMAdmin.MMPManagement.PBPIDDropdownlist, thisElementName); break; }
                        case "Transaction Code": { fw.ReportOn(cfUIMODEAMAdmin.MMPManagement.TCCodeDropdownlist, thisElementName); break; }
                        case "Transaction Status": { fw.ReportOn(cfUIMODEAMAdmin.MMPManagement.TCStatusDropdownlist, thisElementName); break; }
                        case "TRC": { fw.ReportOn(cfUIMODEAMAdmin.MMPManagement.TRCDropdownlist, thisElementName); break; }
                        case "Effective Date": { fw.ReportOn(cfUIMODEAMAdmin.MMPManagement.EffectiveDate, thisElementName); break; }
                        case "Termination Date": { fw.ReportOn(cfUIMODEAMAdmin.MMPManagement.TermDate, thisElementName); break; }
                        // case "Effective Date Calendar": { fw.ReportOn(EAM.AdministrationMMP.EffectiveDateCalendar, thisElementName); break; }
                        //case "Termination Date Calendar": { fw.ReportOn(EAM.AdministrationMMP.TerminationDateCalendar, thisElementName); break; }
                        case "Save": { fw.ReportOn(cfUIMODEAMAdmin.MMPManagement.ADDBtn, thisElementName); break; }
                        case "Reset": { fw.ReportOn(cfUIMODEAMAdmin.MMPManagement.ResetBtn, thisElementName); break; }
                        //  case "Results Table": { fw.ReportOn(cfUIMODEAMAdmin.MMPManagement, thisElementName); break; }
                        default: { Assert.AreEqual(true, false, "No Element handler available in 'ThenElementsExist' for [" + thisElementName + "]"); break; }
                    }
                }
            }
        }

        [When(@"I Clicked on Expand Menu on EAM UI MOD Page")]
        public void WhenIClickedOnExpandMenuOnEAMUIMODPage()
        {
            By menu = By.CssSelector("[test-id='header-btn-expanMenu']");
            ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(menu));
            tmsWait.Hard(1);
        }

        [When(@"EAM Report Manager page Search button is clicked")]
        [Given(@"EAM Report Manager page Search button is clicked")]
        [Then(@"EAM Report Manager page Search button is clicked")]
        public void WhenEAMReportManagerPageSearchButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@test-id='reportManager-btn-search']")));
            tmsWait.Hard(1);
        }
        [Then(@"EAM Report Manager page Report Name ""(.*)"" is selected")]
        [When(@"EAM Report Manager page Report Name ""(.*)"" is selected")]
        public void ThenReportManagerPageReportNameIsSelected(string p0)
        {
            tmsWait.Hard(10);

            IWebElement elecType = Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='reportManager-select-multiSelectReports']//input"));

            elecType.SendKeys(p0);
            tmsWait.Hard(3);
            elecType.SendKeys(OpenQA.Selenium.Keys.Enter);
        }



        [When(@"Imports Page ""(.*)"" link is Clicked")]
        public void WhenImportsPageLinkIsClicked(string link)
        {
            tmsWait.Hard(3);
            GlobalRef.JobName = link;
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//li[@test-id='import-li-joblist']/label[contains(.,'" + link + "')]")));
        }

        [When(@"Imports Page TRR Activity Logging link is Clicked")]
        public void WhenImportsPageTRRActivityLoggingLinkIsClicked()
        {
            tmsWait.Hard(3);
            GlobalRef.JobName = "TRR Activity Logging";
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'TRR Activity Logging')]")));
        }


        [When(@"Imports Page Information link is Clicked")]
        public void WhenImportsPageInformationLinkIsClicked()
        {
            tmsWait.Hard(4);

            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//i[@test-id='import-tooltip-noteInfoTooltip']")));
        }

        [When(@"Verify Imports Page Information link Displays ""(.*)""")]
        [Then(@"Verify Imports Page Information link Displays ""(.*)""")]
        public void ThenVerifyImportsPageInformationLinkDisplays(string p0)
        {
            string message = tmsCommon.GenerateData(p0);

            tmsWait.Hard(4);

            IWebElement toastMsg = Browser.Wd.FindElement(By.XPath("//div[@id='noteInfoTooltip_tt_active']/div[@class='k-tooltip-content'][contains(.,'" + message + "')]"));
            bool msgDisplay = toastMsg.Displayed;

            Assert.IsTrue(msgDisplay, " Information message is not displayed");
        }

        [When(@"on RAM Page Page Job Processing Status link is Clicked")]
        [When(@"on EAM Page Page Job Processing Status link is Clicked")]
        public void WhenOnEAMPagePageJobProcessingStatusLinkIsClicked()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.Id("fileStatusEnrollmentID")));
            tmsWait.Hard(2);
        }



        IWebElement drpField;
        IWebElement elementMulti;
        [When(@"Mailing List From Transactions Export page ""(.*)"" is set to ""(.*)""")]
        [Given(@"Mailing List From Transactions Export page ""(.*)"" is set to ""(.*)""")]
        [Then(@"Mailing List From Transactions Export page ""(.*)"" is set to ""(.*)""")]
        public void WhenMailingListFromTransactionsExportPageIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (field)
            {
                case "Plan ID":
                    drpField = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='planId_listbox']"));
                    fw.ExecuteJavascript(drpField);

                    tmsWait.Hard(2);
                    elementMulti = Browser.Wd.FindElement(By.XPath("//ul[@id='planId_listbox']/li[contains(.,'" + value + "')]"));
                    fw.ExecuteJavascript(elementMulti);

                    break;

                case "Transaction Status":
                    drpField = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='transactionStatus_listbox']"));
                    fw.ExecuteJavascript(drpField);

                    tmsWait.Hard(2);
                    elementMulti = Browser.Wd.FindElement(By.XPath("//ul[@id='transactionStatus_listbox']/li[contains(.,'" + value + "')]"));
                    fw.ExecuteJavascript(elementMulti);

                    break;
            }

        }

        [Then(@"Verify BEQ File page displayed message as ""(.*)""")]
        public void ThenVerifyBEQFilePageDisplayedMessageAs(string p0)
        {
            IWebElement toastMsg = Browser.Wd.FindElement(By.XPath("//div[@class='toast-message'][contains(.,'There is no file to export with selected Plan ID.')]"));
            bool msgDisplay = toastMsg.Displayed;

            Assert.IsTrue(msgDisplay, " Toaster message is not displayed");
        }


        [When(@"BEQ File page Plan ID is set to ""(.*)"" and Clicked on Export button")]
        public void WhenBEQFilePagePlanIDIsSetToAndClickedOnExportButton(string p0)
        {
            tmsWait.Hard(5);
            string value = tmsCommon.GenerateData(p0);
          
            By Drp = By.XPath("//kendo-dropdownlist[@id='ddlPlanId']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + value + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(2);
            
            IWebElement export = Browser.Wd.FindElement(By.CssSelector("[test-id='exportBeq-btn-export']"));
            fw.ExecuteJavascript(export);
            tmsWait.Hard(5);

        }


        [When(@"BEQ File page Plan ID is set to ""(.*)"" and Clicked on Export button and Verify Message ""(.*)""")]
        public void WhenBEQFilePagePlanIDIsSetToAndClickedOnExportButtonAndVerifyMessage(string p0, string Message)
        {
            string value = tmsCommon.GenerateData(p0);
            IWebElement drpField = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='ddlPlanId_listbox']"));
            fw.ExecuteJavascript(drpField);

            tmsWait.Hard(2);
            elementMulti = Browser.Wd.FindElement(By.XPath("//ul[@id='ddlPlanId_listbox']/li[contains(.,'" + value + "')]"));
            fw.ExecuteJavascript(elementMulti);
            tmsWait.Hard(4);
            IWebElement export = Browser.Wd.FindElement(By.CssSelector("[test-id='exportBeq-btn-export']"));
            fw.ExecuteJavascript(export);
            tmsWait.Hard(1);
            IWebElement toastMsg = Browser.Wd.FindElement(By.XPath("//div[@class='toast-message'][contains(.,'" + Message + "')]"));
            bool msgDisplay = toastMsg.Displayed;

            Assert.IsTrue(msgDisplay, " Toaster message is not displayed");
        }



        [When(@"CMS File Page Earliest Effective Date is set to ""(.*)""")]
        public void WhenCMSFilePageEarliestEffectiveDateIsSetTo(string date)
        {
            tmsWait.Hard(3);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                string value = tmsCommon.GenerateData(date);
                //IWebElement clda = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@id='txtExportCmsEarliestEffDate']//input"));
                //clda.Clear();

                By Drp = By.XPath("//kendo-datepicker[@id='txtExportCmsEarliestEffDate']//span[@role='button']");
                //AngularFunction.enterTodayAsDate(Drp);

                tmsWait.Hard(3);

                AngularFunction.enterDatePreLoadedNew(Drp, value);

                //IWebElement el = Browser.Wd.FindElement(By.XPath("//label[@test-id='exportcms-lbl-earliesteffectivedate']"));
                //el.SendKeys(Keys.Tab);
                //tmsWait.Hard(3);
                ////IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='premiumLis-txt-startDate']//span[@role='button']"));
                //IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@id='txtExportCmsEarliestEffDate']//input"));
                //string[] value1 = value.Split('/');
                //ele.SendKeys(value1[0]);
                //ele.SendKeys(value1[1]);
                //ele.SendKeys(value1[2]);
                //ele.SendKeys(Keys.Tab);
                tmsWait.Hard(3);
                


            }
            else
            {
                IWebElement earlierEffDate = Browser.Wd.FindElement(By.CssSelector("[test-id='exportCms-txt-earliestEffDate']"));
                earlierEffDate.Clear();
                tmsWait.Hard(3);
                earlierEffDate.SendKeys(date);
            }
        }

        [When(@"CMS File Page Latest Effective Date is set to ""(.*)""")]
        public void WhenCMSFilePageLatestEffectiveDateIsSetTo(string date)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                string value = tmsCommon.GenerateData(date);

                By Drp = By.XPath("//kendo-datepicker[@test-id='exportCms-txt-latestEffDate']//span[@role='button']");
                //AngularFunction.enterTodayAsDate(Drp);

                tmsWait.Hard(3);

                AngularFunction.enterDate(Drp, value);

                tmsWait.Hard(3);


            }
            else
            {
                IWebElement latestEffDate = Browser.Wd.FindElement(By.CssSelector("[test-id='exportCms-txt-latestEffDate']"));
                latestEffDate.Clear();
                tmsWait.Hard(3);
                latestEffDate.SendKeys(date);
            }
        }

        [When(@"Retro File Page ""(.*)"" is set to ""(.*)""")]
        public void WhenRetroFilePageIsSetTo(string field, string value)
        {
            string filetype = tmsCommon.GenerateData(field);

            try
            {
                switch (filetype)
                {
                    case "Plan ID":

                        IWebElement drp = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='ddlPlanId_listbox']"));
                        fw.ExecuteJavascript(drp);

                        tmsWait.Hard(2);
                        IWebElement element = Browser.Wd.FindElement(By.XPath("//ul[@id='ddlPlanId_listbox']/li[contains(.,'" + value + "')]"));
                        fw.ExecuteJavascript(element);
                        break;

                }
            }
            catch
            {

            }
        }


        [When(@"CMS File Page ""(.*)"" is set to ""(.*)""")]
        public void WhenCMSFilePageIsSetTo(string field, string gValue)
        {

            string filetype = tmsCommon.GenerateData(field);
            string value = tmsCommon.GenerateData(gValue);
            switch (filetype)
            {
                case "Plan ID":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'Plan Id')]/parent::div//span[@class='k-select']");
                        By typeapp = By.XPath("//li[text()='" + value + "']");


                        UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

                        GlobalRef.PlanID = value;
                    }
                    else
                    {


                        IWebElement drp = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='planId_listbox']"));
                        fw.ExecuteJavascript(drp);

                        tmsWait.Hard(2);
                        IWebElement element = Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + value + "')]"));
                        fw.ExecuteJavascript(element);
                        GlobalRef.PlanID = gValue;
                    }
                    break;
                case "Transaction Code":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        value = value.ToUpper();
                        By Drp = By.XPath("//label[contains(.,'Transaction Code')]/parent::div//span[@class='k-select']");
                        By typeapp = By.XPath("//li[text()='" + value + "']");


                        UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);



                    }
                    else
                    {

                        IWebElement drp1 = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='transactionCodes_listbox']"));
                        fw.ExecuteJavascript(drp1);


                        IWebElement element1 = Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + value + "')]"));

                        fw.ExecuteJavascript(element1);
                        tmsWait.Hard(2);
                    }
                    break;
            }

        }

        [When(@"CMS File Page Export button is clicked")]
        public void WhenCMSFilePageExportButtonIsClicked()
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement element11 = Browser.Wd.FindElement(By.XPath("//button[@id='btnOtherSettingsSave']"));
                fw.ExecuteJavascript(element11);
            }
            else
            {
                IWebElement element1 = Browser.Wd.FindElement(By.CssSelector("[test-id='exportcms-btn-export']"));
                fw.ExecuteJavascript(element1);
            }


        }

        [When(@"Retro File Page Plan ID is selected as ""(.*)""")]
        public void WhenRetroFilePagePlanIDIsSelectedAs(string p0)
        {
            string planId = tmsCommon.GenerateData(p0);

            try
            {

                DateTime date = DateTime.Now;

                // Long date:
                string currentDate = string.Format("{0:D}", date);
                IWebElement calButton = Browser.Wd.FindElement(By.XPath("//span[@role='button']"));
                fw.ExecuteJavascript(calButton);
                tmsWait.Hard(3);

                IWebElement currentDateSele = Browser.Wd.FindElement(By.XPath("//a[@title='" + currentDate + "']"));
                fw.ExecuteJavascript(currentDateSele);
                tmsWait.Hard(3);
                IWebElement check = Browser.Wd.FindElement(By.XPath("(//div[@test-id='retroExport-grid-retroExportGrid']//td[contains(.,'" + planId + "_Enrl')]//following-sibling::td/input)[1]"));
                fw.ExecuteJavascript(check);

                IWebElement mark = Browser.Wd.FindElement(By.CssSelector("[test-id='retro-btn-markAsSent']"));
                fw.ExecuteJavascript(mark);
                tmsWait.Hard(3);
            }
            catch
            {

            }
        }

        [When(@"Retro File Page Export button is clicked")]
        public void WhenRetroFilePageExportButtonIsClicked()
        {
            tmsWait.Hard(2);
            IWebElement element1 = Browser.Wd.FindElement(By.CssSelector("[test-id='exportRetro-btn-export']"));
            fw.ExecuteJavascript(element1);
        }

        [When(@"Retro File page File has been sent Date is set to ""(.*)"" and Send Checkbox is Clicked")]
        public void WhenRetroFilePageFileHasBeenSentDateIsSetToAndSendCheckboxIsClicked(string p0)
        {
            IWebElement date = Browser.Wd.FindElement(By.CssSelector("[test-id='exportRetro-txt-sentDate']"));
            date.SendKeys(p0);
            IWebElement checkbox = Browser.Wd.FindElement(By.XPath("//input[@type='checkbox']"));
            fw.ExecuteJavascript(checkbox);


        }

        [When(@"Retro File page Mark as Sent button is Clicked")]
        public void WhenRetroFilePageMarkAsSentButtonIsClicked()
        {
            IWebElement checkbox = Browser.Wd.FindElement(By.CssSelector("[test-id='retro-btn-markAsSent']"));
            fw.ExecuteJavascript(checkbox);
        }

        [When(@"Export page Span File page Modified Check box is Clicked")]
        public void WhenExportPageSpanFilePageModifiedCheckBoxIsClicked()
        {
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='exportspan-lbl-modifiedonly']"));
            fw.ExecuteJavascript(ele);
        }

        [When(@"Export page Span File page Export button is Clicked")]
        public void WhenExportPageSpanFilePageExportButtonIsClicked()
        {
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='exportspan-btn-export']"));
            fw.ExecuteJavascript(ele);
        }


        IWebElement exportElement;
        [When(@"Exports Page ""(.*)"" link is Clicked")]
        [Given(@"Exports Page ""(.*)"" link is Clicked")]
        [Then(@"Exports Page ""(.*)"" link is Clicked")]
        public void WhenExportsPageLinkIsClicked(string exportType)
        {

            tmsWait.Hard(5);
            switch (exportType)
            {
                case "BEQ File":
                    exportElement = Browser.Wd.FindElement(By.XPath("//label[contains(.,'BEQ File')]"));
                    GlobalRef.JobName = "CMS BEQ File";
                    break;
                case "CMS File":
                    exportElement = Browser.Wd.FindElement(By.XPath("//label[contains(.,'CMS File')]"));
                    GlobalRef.JobName = "CMS Transfer File";
                    break;
                case "Retro File":
                    exportElement = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Retro File')]"));
                    break;
                case "Member File":
                    exportElement = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Member File')]"));
                    break;
                case "Span File":
                    exportElement = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Span File')]"));
                    break;
                case "Spans - Facets File":
                    exportElement = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Spans - Facets File')]"));
                    break;
                case "To Legacy Member":
                    exportElement = Browser.Wd.FindElement(By.XPath("//li[@test-id='export-li-legacyMember']/label[contains(.,'Member')]"));
                    GlobalRef.JobName = "Legacy Member File";
                    break;
                case "To Legacy Transaction":
                    exportElement = Browser.Wd.FindElement(By.XPath("//li[@test-id='export-li-transaction']/label[contains(.,'Transaction')]"));
                    GlobalRef.JobName = "Legacy Transaction File";

                    break;
                case "Mailing List From Transaction":
                    exportElement = Browser.Wd.FindElement(By.XPath("//li[@test-id='export-li-fromtransaction']/label[contains(.,'From Transaction')]"));
                    GlobalRef.JobName = "Mailing List Transaction";

                    break;
                case "Mailing List From TRR":
                    exportElement = Browser.Wd.FindElement(By.XPath("//li[@test-id='export-li-fromtrr']/label[contains(.,'From T/RR')]"));
                    GlobalRef.JobName = "	Mailing List TRR File";
                    break;
            }
            tmsWait.Hard(3);
            fw.ExecuteJavascript(exportElement);
            tmsWait.Implicit(30);


        }


        [When(@"Select any Member from Member Lookup page")]
        public void WhenSelectAnyMemberFromMemberLookupPage()
        {
            //string GeneratedData = tmsCommon.GenerateData(p0);
            tmsWait.Hard(2);
            // click on Report Link
            IWebElement lookup = Browser.Wd.FindElement(By.XPath("//span[@test-id='report-link-group']/a"));
            fw.ExecuteJavascript(lookup);
            tmsWait.Hard(2);

            // Click on Search
            IWebElement trrSearchButton = Browser.Wd.FindElement(By.CssSelector("[test-id='member-btn-search']"));
            fw.ExecuteJavascript(trrSearchButton);
            tmsWait.Hard(2);
            // Click on Checkbox
            IWebElement check = Browser.Wd.FindElement(By.XPath("(//input[@type='checkbox'])[1]"));
            fw.ExecuteJavascript(check);
            tmsWait.Hard(2);
            // Add button
            IWebElement AddButton = Browser.Wd.FindElement(By.CssSelector("[test-id='member-btn-add']"));
            fw.ExecuteJavascript(AddButton);
            tmsWait.Hard(8);

        }

        [Then(@"Verify Reports page displayed ""(.*)"" field")]
        public void ThenVerifyReportsPageDisplayedField(string drp)
        {
            tmsWait.Hard(1);
            IWebElement drpField = Browser.Wd.FindElement(By.CssSelector("[test-id='" + drp + "']"));
            bool presence = drpField.Displayed;
            Assert.IsTrue(presence, drp + " is not getting displayed");
        }

        [When(@"EAM Report page ""(.*)"" report link is clicked")]
        [Then(@"EAM Report page ""(.*)"" report link is clicked")]
        public void ThenEAMReportPageReportLinkIsClicked(string link)
        {
            GlobalRef.ReportName = link;

            tmsWait.Hard(1);
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                IWebElement enr;
                IWebElement oec;
                try
                {


                    if (link.Equals("Denial"))
                    {
                        // not implmented as of 12/30/2019
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Transaction')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("(//a[contains(@href,'Denial')]//span[@class='glyphui glyphui-report'])[1]"));
                        fw.ExecuteJavascript(oec);
                    }


                    if (link.Equals("NoRx Fallout"))
                    {
                        // not implmented as of 12/30/2019
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Transaction')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("(//a[contains(@href,'NoRx')]//span[@class='glyphui glyphui-report'])[1]"));
                        fw.ExecuteJavascript(oec);
                    }

                    if (link.Equals("Auto enrollment 72 Fallout"))
                    {
                        // not implmented as of 12/30/2019
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Transaction')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("(//a[contains(@href,'Auto')]//span[@class='glyphui glyphui-report'])[1]"));
                        fw.ExecuteJavascript(oec);
                    }
                    if (link.Equals("New/changed Transaction"))
                    {
                        // not implmented as of 12/30/2019
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Transaction')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("(//a[contains(@href,'Changed')]//span[@class='glyphui glyphui-report'])[1]"));
                        fw.ExecuteJavascript(oec);
                    }


                    if (link.Equals("Transaction Summary"))
                    {
                        // not implmented as of 12/30/2019
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Transaction')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("(//a[contains(@href,'Summary')]//span[@class='glyphui glyphui-report'])[1]"));
                        fw.ExecuteJavascript(oec);
                    }




                    if (link.Equals("Transaction Detail"))
                    {
                        // not implmented as of 12/30/2019
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Transaction')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("(//a[contains(@href,'Detail')]//span[@class='glyphui glyphui-report'])[1]"));
                        fw.ExecuteJavascript(oec);
                    }

                    if (link.Equals("Quarterly Enrollment Compliance"))
                    {
                        // not implmented as of 12/30/2019
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Compliance')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("(//a[contains(@href,'Quarterly')]//span[@class='glyphui glyphui-report'])[2]"));
                        fw.ExecuteJavascript(oec);
                    }


                    if (link.Equals("Send To CMS Queue"))
                    {

                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Queue')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("(//a[contains(@href,'Send')]//span[@class='glyphui glyphui-report'])[1]"));
                        fw.ExecuteJavascript(oec);
                    }

                    if (link.Equals("Letter Status"))
                    {
                        //Not implemented as of 12/30/2019
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Queue')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("(//a[contains(@href,'Letter')]//span[@class='glyphui glyphui-report'])[1]"));
                        fw.ExecuteJavascript(oec);
                    }

                    if (link.Equals("Past Due Actions"))
                    {
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Notes')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("(//a[contains(@href,'Due')]//span[@class='glyphui glyphui-report'])[1]"));
                        fw.ExecuteJavascript(oec);
                    }

                    if (link.Equals("Notes/Actions"))
                    {
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Notes')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("(//a[contains(@href,'Notes')]//span[@class='glyphui glyphui-report'])[1]"));
                        fw.ExecuteJavascript(oec);
                    }


                    if (link.Equals("Members With LEP"))
                    {
                        tmsWait.Hard(5);
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Member')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("(//a[contains(@href,'LEP')]//span[@class='glyphui glyphui-report'])[1]"));
                        fw.ExecuteJavascript(oec);
                    }


                    if (link.Equals("All Member Detail") || link.Equals("Single Member Detail"))
                    {   // 2 reports are clubbed
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Member')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("(//a[contains(@href,'Member%20Details')]//span[@class='glyphui glyphui-report'])[1]"));
                        fw.ExecuteJavascript(oec);
                    }

                    if (link.Equals("Member SNP Follow up Activity"))
                    {   // Not Implemented as of 12/30/2019
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Member')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'SNP')]//span[@class='glyphui glyphui-report']"));
                        fw.ExecuteJavascript(oec);
                    }

                    if (link.Equals("Member OOA Status"))
                    {   // Not Implemented as of 12/30/2019
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Member')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'OOA')]//span[@class='glyphui glyphui-report']"));
                        fw.ExecuteJavascript(oec);
                    }
                    if (link.Equals("Member Roster"))
                    {
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Member')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Roster')]//span[@class='glyphui glyphui-report']"));
                        fw.ExecuteJavascript(oec);
                    }


                    if (link.Equals("COB"))
                    {
                        // Not Implemented as of 12/30/2019
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Member')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'COB')]//span[@class='glyphui glyphui-report']"));
                        fw.ExecuteJavascript(oec);
                    }

                    if (link.Equals("Members By Premium Withhold Option"))
                    {

                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Member')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Premium')]//span[@class='glyphui glyphui-report']"));
                        fw.ExecuteJavascript(oec);
                    }
                    if (link.Equals("Missing 4Rx Data"))
                    {

                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Member')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Missing')]//span[@class='glyphui glyphui-report']"));
                        fw.ExecuteJavascript(oec);
                    }






                    if (link.Equals("Members Without Transactions"))
                    {
                        // Not Implemented as of 12/30/2019
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Member')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Without')]//span[@class='glyphui glyphui-report']"));
                        fw.ExecuteJavascript(oec);
                    }

                    if (link.Equals("Member T/ RR History"))
                    {
                        // Not Implemented as of 12/30/2019
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Member')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Member%10T')]//span[@class='glyphui glyphui-report']"));
                        fw.ExecuteJavascript(oec);
                    }

                    if (link.Equals("Deemed LIS Detail"))
                    {
                        // Not Implemented as of 12/30/2019
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'LIS')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Deemed%10LIS%20Detail')]//span[@class='glyphui glyphui-report']"));
                        fw.ExecuteJavascript(oec);
                        tmsWait.Hard(5);
                    }


                    if (link.Equals("LIS Roster"))
                    {
                        // Not Implemented as of 12/30/2019
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'LIS')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'LIS%20Roster')]//span[@class='glyphui glyphui-report']"));
                        fw.ExecuteJavascript(oec);
                    }


                    if (link.Equals("LIS History Data - Single Member Detail"))
                    {
                        // Not Implemented as of 12/30/2019
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'LIS')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'LIS%10History%20Data')]//span[@class='glyphui glyphui-report']"));
                        fw.ExecuteJavascript(oec);
                    }

                    if (link.Equals("LIS History Data"))
                    {
                        // Not Implemented as of 12/30/2019
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'LIS')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'LIS%10History%20Data')]//span[@class='glyphui glyphui-report']"));
                        fw.ExecuteJavascript(oec);
                    }

                    if (link.Equals("Transactions Missing CMS Data"))
                    {
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Enrollment')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Transactions%20Missing%20CMS%20Data')]//span[@class='glyphui glyphui-report']"));
                        fw.ExecuteJavascript(oec);
                    }
                    if (link.Equals("Code Level Detail"))
                    {
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'CMS')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Code')]//span[@class='glyphui glyphui-report']"));
                        fw.ExecuteJavascript(oec);
                        tmsWait.Hard(5);
                    }
                    if (link.Equals("BEQ Mismatches"))
                    {
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Eligibility')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Mismatches')]//span[@class='glyphui glyphui-report']"));
                        fw.ExecuteJavascript(oec);
                    }
                    if (link.Equals("Enrollment Summary"))
                    {
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Enrollment')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Enrollment%20Summary')]//span[@class='glyphui glyphui-report']"));
                        fw.ExecuteJavascript(oec);
                    }


                    if (link.Equals("BEQ Details"))
                    {
                        // Not Implemented as of 12/30/2019
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Eligibility')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Details')]//span[@class='glyphui glyphui-report']"));
                        fw.ExecuteJavascript(oec);
                    }
                    if (link.Equals("Failed BEQ"))
                    {
                        // Not Implemented as of 12/30/2019
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Eligibility')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Failed')]//span[@class='glyphui glyphui-report']"));
                        fw.ExecuteJavascript(oec);
                    }

                    if (link.Equals("Plan vs CMS Discrepancy"))
                    {
                        // Not Implemented as of 12/30/2019
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Eligibility')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Discrepancy')]//span[@class='glyphui glyphui-report']"));
                        fw.ExecuteJavascript(oec);
                    }
                    if (link.Equals("Eligibility Passed Check"))
                    {
                        // Not Implemented as of 12/30/2019
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Eligibility')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Eligibility%20Passed%20Check')]//span[@class='glyphui glyphui-report']"));
                        fw.ExecuteJavascript(oec);
                    }




                    if (link.Equals("OEC/EAF Fallout"))
                    {
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'Enrollment')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'OEC-EAF')]//span[@class='glyphui glyphui-report']"));
                        fw.ExecuteJavascript(oec);
                    }
                    if (link.Equals("TRR Summary") || link.Equals("T/RR Summary Report"))
                    {
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'CMS')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("(//a[contains(@href,'TRR')]//span[@class='glyphui glyphui-report'])[2]"));
                        fw.ExecuteJavascript(oec);
                    }



                    if (link.Equals("TRR Detail"))
                    {
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'CMS')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("(//a[contains(@href,'TRR')]//span[@class='glyphui glyphui-report'])[1]"));
                        fw.ExecuteJavascript(oec);
                    }
                    if (link.Equals("Avoidable TRC Detail"))
                    {
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'CMS')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("(//a[contains(@href,'Avoid')]//span[@class='glyphui glyphui-report'])[1]"));
                        fw.ExecuteJavascript(oec);
                    }

                    if (link.Equals("Avoidable/Unavoidable TRC Summary"))
                    {
                        enr = Browser.Wd.FindElement(By.XPath("//a[contains(@href,'CMS')]//span[@class='glyphui glyphui-folder']"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                        oec = Browser.Wd.FindElement(By.XPath("(//a[contains(@href,'Avoid')]//span[@class='glyphui glyphui-report'])[2]"));
                        fw.ExecuteJavascript(oec);
                    }

                    if (link.Equals("LICS"))
                    {
                        enr = Browser.Wd.FindElement(By.XPath("//span[contains(.,'LICS')]"));
                        fw.ExecuteJavascript(enr);
                        tmsWait.Hard(5);
                    }



                }
                catch
                {
                    Assert.Fail(" Please provide Valid report Name ");
                }


                tmsWait.Hard(20);
                Browser.SwitchToIFrame();
            }
            else
            {
                IWebElement reportlink = Browser.Wd.FindElement(By.CssSelector("[test-id='" + link + "']"));
                fw.ExecuteJavascript(reportlink);
                tmsWait.Hard(3);
            }
        }

        [Then(@"Report page Effective Date From field is set to ""(.*)""")]
        public void ThenReportPageEffectiveDateFromFieldIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            String strValue = tmsCommon.GenerateData(p0);
            strValue = strValue.Replace("/", "");
            IWebElement EffDate = Browser.Wd.FindElement(By.XPath("//input[@test-id='EffDate_From']"));
            EffDate.SendKeys(strValue);
            tmsWait.Hard(3);
        }
        [Then(@"Effective Date To field is set to ""(.*)""")]
        public void ThenEffectiveDateToFieldIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            String strValue = tmsCommon.GenerateData(p0);
            strValue = strValue.Replace("/", "");
            IWebElement EffDate = Browser.Wd.FindElement(By.XPath("//input[@test-id='EffDate_To']"));
            EffDate.SendKeys(strValue);
            tmsWait.Hard(3);
        }


        [Then(@"Reports section CMS Response Code Level Detail page TRR Month is set to ""(.*)""")]
        public void ThenReportsSectionCMSResponseCodeLevelDetailPageTRRMonthIsSetTo(string value)
        {
            ReUsableFunctions.selectValueFromDropDown(cfEAMMODReports.CodeLevelDetailsReport.TRRMonth, value);
        }

        [When(@"I have Navigated to EAM Page Reports Queue section")]
        public void WhenIHaveNavigatedToEAMPageReportsQueueSection()
        {
            tmsWait.Hard(1);
            IWebElement reportQueuelink = Browser.Wd.FindElement(By.Id("imageQue"));
            fw.ExecuteJavascript(reportQueuelink);
            tmsWait.Hard(3);
        }



        [Then(@"Reports section CMS Response Code Level Detail page Plan ID is set to ""(.*)""")]
        public void ThenReportsSectionCMSResponseCodeLevelDetailPagePlanIDIsSetTo(string value)
        {
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                tmsWait.Hard(4);
                new SelectElement(Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl04_ctl07_ddValue"))).SelectByText(value);
            }
            else
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    By Drp = By.XPath("//*[@test-id='PlanID']//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + value + "']");

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                }
                else
                {
                    ReUsableFunctions.selectValueFromDropDown(cfEAMMODReports.CodeLevelDetailsReport.PlanID, value);
                }
            }

        }

        [When(@"Search Criteria page OEC EAF Fallout Report page File Name is set to ""(.*)""")]
        public void WhenSearchCriteriaPageOECEAFFalloutReportPageFileNameIsSetTo(string p0)
        {
            string filename = tmsCommon.GenerateData(p0);
            tmsWait.Hard(3);
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                new SelectElement(Browser.Wd.FindElement(By.CssSelector("[id='ReportViewerControl_ctl04_ctl11_ddValue']"))).SelectByText(filename);
            }
            else
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    By Drp = By.XPath("//*[@test-id='FileName']//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + filename + "']");

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                }
                else
                {
                    ReUsableFunctions.selectValueFromDropDown(cfEAMMODReports.OECEAFReport.FileName, filename);
                }
            }
        }

        [When(@"Search Criteria page Transactions Missing CMS Data page File Name is set to ""(.*)""")]
        public void WhenSearchCriteriaPageTransactionsMissingCMSDataPageFileNameIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string filename = tmsCommon.GenerateData(p0);
            ReUsableFunctions.selectValueFromDropDown(cfEAMMODReports.TransactionsMissingCMSData.FileName, filename);
        }
        [When(@"Search Criteria page Transactions Missing CMS Data page Plan ID is set to ""(.*)""")]
        public void WhenSearchCriteriaPageTransactionsMissingCMSDataPagePlanIDIsSetTo(string p0)
        {
            string filename = tmsCommon.GenerateData(p0);
            ReUsableFunctions.selectValueFromDropDown(cfEAMMODReports.TransactionsMissingCMSData.PlanID, filename);
        }

        [When(@"Search Criteria page Transactions Missing CMS Data page PBP ID is set to ""(.*)""")]
        public void WhenSearchCriteriaPageTransactionsMissingCMSDataPagePBPIDIsSetTo(string p0)
        {
            string filename = tmsCommon.GenerateData(p0);
            ReUsableFunctions.selectValueFromDropDown(cfEAMMODReports.TransactionsMissingCMSData.PBPID, filename);
        }

        [Given(@"I click on Export button")]
        public void GivenIClickOnExportButton()
        {
            IWebElement ExportBtn = Browser.Wd.FindElement(By.XPath("//button[@test-id='exportcms-btn-export']"));
            fw.ExecuteJavascript(ExportBtn);
        }


    }
}
