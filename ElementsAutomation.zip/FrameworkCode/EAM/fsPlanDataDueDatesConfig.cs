﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using TMSoR1;

namespace Daron0004
{
    [Binding]
    class fsPlanDataDueDatesConfig
    {

        [Then(@"Verify EAM Home page EAM Configuration section is not displayed")]
        public void ThenVerifyEAMHomePageEAMConfigurationSectionIsNotDisplayed()
        {
           bool elementpresence= tmsWait.IsElementPresent(By.XPath("//a[@title='EAM Configuration']"));
           Assert.IsFalse(elementpresence, "EAM Configuration Element is Present");

        }

        [When(@"Clicked on Save Button")]
        public void WhenClickedOnSaveButton()
        {
            Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSavePDDDConf")).Click();
        }


        [When(@"EAM Configuration page PDDDConfig section ""(.*)"" is set to ""(.*)""")]
        public void WhenEAMConfigurationPagePDDDConfigSectionIsSetTo(string p0, string p1)
        {
            string field = p0.ToString();
            String strValue = tmsCommon.GenerateData(p1);

            switch (field)
            {
                case "Report Month":
                    
                    tmsWait.Hard(4);

                   
                    strValue = strValue.Replace("/", "");
                    IWebElement repmon = Browser.Wd.FindElement(By.XPath("//input[@id='ctl00_ctl00_MainMasterContent_MainContent_txtRepMonIns']"));
                    repmon.Click();
                    repmon.Clear();
                    tmsWait.Hard(4);
                    repmon.SendKeys(strValue);
                    break;

                case "File Due Date":

                    tmsWait.Hard(4);
                    strValue = strValue.Replace("/", "");
                    IWebElement filedue = Browser.Wd.FindElement(By.XPath("//input[@id='ctl00_ctl00_MainMasterContent_MainContent_txtFileDueDateIns']"));
                    filedue.Click();
                    filedue.Clear();
                    tmsWait.Hard(4);
                    filedue.SendKeys(strValue);
                    break;

                case "File Message":
                    tmsWait.Hard(4);
                    IWebElement filemsg = Browser.Wd.FindElement(By.XPath("//textarea[@id='ctl00_ctl00_MainMasterContent_MainContent_txtFileMessageIns']"));
                    filemsg.Click();
                    filemsg.Clear();
                    tmsWait.Hard(4);
                    filemsg.SendKeys(strValue);
                    break;
                case "Plan Due Date":
                    tmsWait.Hard(4);
                    strValue = strValue.Replace("/", "");
                    IWebElement plandue = Browser.Wd.FindElement(By.XPath("//input[@id='ctl00_ctl00_MainMasterContent_MainContent_txtPlanDueDateIns']"));
                    plandue.Click();
                    plandue.Clear();
                    tmsWait.Hard(4);
                    plandue.SendKeys(strValue);
                    break;

                case "Plan Message":
                    tmsWait.Hard(4);
                    IWebElement planmsg = Browser.Wd.FindElement(By.XPath("//textarea[@id='ctl00_ctl00_MainMasterContent_MainContent_txtPlanMessageIns']"));
                    planmsg.Click();
                    planmsg.Clear();
                    tmsWait.Hard(4);
                    planmsg.SendKeys(strValue);
                    break;

            }
        }


        [Then(@"Verify TmsOperational Configuration page ""(.*)"" Text box is displayed")]
        public void ThenVerifyTmsOperationalConfigurationPageTextBoxIsDisplayed(string p0)
        {
            switch(p0.ToString())
            {
                case "Database Name":
                    Assert.IsTrue(EAM.TmsOperationalConfiguration.DBName.Displayed, p0+" Field is not displayed");
                    break;
                case "Database User":
                    Assert.IsTrue(EAM.TmsOperationalConfiguration.DBUser.Displayed, p0 + " Field is not displayed");
                    break;
                case "Database Server":
                    Assert.IsTrue(EAM.TmsOperationalConfiguration.DBServer.Displayed, p0 + " Field is not displayed");
                    break;
                case "Password":
                    Assert.IsTrue(EAM.TmsOperationalConfiguration.Password.Displayed, p0 + " Field is not displayed");
                    break;
            }
        }

        [Then(@"Verify TmsOperational Configuration page ""(.*)"" Button is displayed")]
        public void ThenVerifyTmsOperationalConfigurationPageButtonIsDisplayed(string p0)
        {
            switch (p0.ToString())
            {
                case "Save":
                    Assert.IsTrue(EAM.TmsOperationalConfiguration.Save.Displayed, p0 + " Field is not displayed");
                    break;
                case "Reset":
                    Assert.IsTrue(EAM.TmsOperationalConfiguration.Reset.Displayed, p0 + " Field is not displayed");
                    break;
               
            }
        }

        [When(@"TmsOperational Configuration page Clicked on Save button")]
        public void WhenTmsOperationalConfigurationPageClickedOnSaveButton()
        {

        EAM.TmsOperationalConfiguration.Save.Click();
        }

        [When(@"TmsOperational Configuration page Clicked on Reset button")]
        public void WhenTmsOperationalConfigurationPageClickedOnResetButton()
        {
            EAM.TmsOperationalConfiguration.Reset.Click();
        }

        [Then(@"Verify TmsOperational Configuration page ""(.*)"" Text box set to ""(.*)""")]
        public void ThenVerifyTmsOperationalConfigurationPageTextBoxSetTo(string p0, string p1)
        {
            string field = p0.ToString();
            string value = p1.ToString();
            switch(field)
            {
                case "Database Name":
                    Assert.AreEqual(value, EAM.TmsOperationalConfiguration.DBName.Text, " Both values are not getting matched");
                    break;
                case "Database Server":
                    Assert.AreEqual(value, EAM.TmsOperationalConfiguration.DBServer.Text, " Both values are not getting matched");
                    break;
                case "Database User":
                    Assert.AreEqual(value, EAM.TmsOperationalConfiguration.DBUser.Text, " Both values are not getting matched");
                    break;
                case "Password":
                    Assert.AreEqual(value, EAM.TmsOperationalConfiguration.Password.Text, " Both values are not getting matched");
                    break;
            }
        }


        [When(@"TmsOperational Configuration page ""(.*)"" Text box is set to ""(.*)""")]
        public void WhenTmsOperationalConfigurationPageTextBoxIsSetTo(string p0, string p1)
        {
            string field = p0.ToString();
            string value = tmsCommon.GenerateData(p1);
            switch(field)
            {
                case "Database Name":
                    EAM.TmsOperationalConfiguration.DBName.SendKeys(value);
                    break;
                case "Database Server":
                    EAM.TmsOperationalConfiguration.DBServer.SendKeys(value);
                    break;
                case "Database User":
                    EAM.TmsOperationalConfiguration.DBUser.SendKeys(value);
                    break;
                case "Password":
                    EAM.TmsOperationalConfiguration.Password.SendKeys(value);
                    break;
            }
        }



        [When(@"EAM Configuration page PDDD Config Plan Data Due Date Year Drop down is set to ""(.*)""")]
        public void WhenEAMConfigurationPagePDDDConfigPlanDataDueDateYearDropDownIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            SelectElement yrs = new SelectElement(EAM.PDDDConfig.PDDDConfigYrsdrpdown);
            yrs.SelectByText(p0);
        }

        [When(@"EAM Configuration page PDDD Config Go Button is Clicked")]
        public void WhenEAMConfigurationPagePDDDConfigGoButtonIsClicked()
        {
            fw.ExecuteJavascript(EAM.PDDDConfig.PDDDConfigGoButton);
            tmsWait.Hard(3);
        }

        [When(@"EAM Configuration page PDDD Config section Plan Due Date is set to ""(.*)""")]
        public void WhenEAMConfigurationPagePDDDConfigSectionPlanDueDateIsSetTo(string p0)
        {
            tmsWait.Hard(4);

            String strValue = tmsCommon.GenerateData(p0);
            strValue = strValue.Replace("/", "");
            IWebElement plandue = Browser.Wd.FindElement(By.XPath("//input[@id='ctl00_ctl00_MainMasterContent_MainContent_gvPDDD_ctl02_txtPlanDueDate']"));
            plandue.Clear();
            tmsWait.Hard(4);
            plandue.SendKeys(strValue);

        }


        [When(@"EAM Configuration page PDDD Config section File Due Date is set to ""(.*)""")]
        public void WhenEAMConfigurationPagePDDDConfigSectionFileDueDateIsSetTo(string p0)
        {
            tmsWait.Hard(4);           
           
            String strValue = tmsCommon.GenerateData(p0);
            strValue = strValue.Replace("/", "");
            IWebElement filedue = Browser.Wd.FindElement(By.XPath("//input[@id='ctl00_ctl00_MainMasterContent_MainContent_gvPDDD_ctl02_txtFileDueDate']"));
            filedue.Clear();
            tmsWait.Hard(4);
            filedue.SendKeys(strValue);
                       
            
        }

        [When(@"PDDConfig section Plan Data Due Date table row is edited and File Due Date is set to ""(.*)""")]
        public void WhenPDDConfigSectionPlanDataDueDateTableRowIsEditedAndFileDueDateIsSetTo(string p0)
        {
           

            String strValue = tmsCommon.GenerateData(p0);
            strValue = strValue.Replace("/", "");
            IWebElement filedue = Browser.Wd.FindElement(By.XPath("//input[@id='ctl00_ctl00_MainMasterContent_MainContent_gvPDDD_ctl08_txtFileDueDate']"));
            filedue.Clear();
            tmsWait.Hard(4);
            filedue.SendKeys(strValue);
        }

        [When(@"PDDConfig section Plan Data Due Date table row File Due Date value ""(.*)"" is edited and File Due Date is set to ""(.*)""")]
        public void WhenPDDConfigSectionPlanDataDueDateTableRowFileDueDateValueIsEditedAndFileDueDateIsSetTo(string exist, string newValue)
        {
            String strValue = tmsCommon.GenerateData(newValue);
            strValue = strValue.Replace("/", "");
            IWebElement filedue = Browser.Wd.FindElement(By.XPath("//input[@value='"+exist+"']"));
            filedue.Clear();
            tmsWait.Hard(4);
            filedue.SendKeys(strValue);
        }


        [When(@"PDDConfig section Plan Data Due Date table row is edited")]
        public void WhenPDDConfigSectionPlanDataDueDateTableRowIsEdited()
        {
            IWebElement edit = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_gvPDDD']//tr[2]//input[@alt='Edit']"));
            fw.ExecuteJavascript(edit);
            tmsWait.Hard(1);
            //Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_gvPDDD_ctl02_txtFileMessage")).Clear();
            //tmsWait.Hard(1);
            //Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_gvPDDD_ctl02_txtFileMessage")).SendKeys("January 1 - 8");
        }

        [When(@"PDDConfig section Plan Data Due Date table row is edited with File Message set to ""(.*)""")]
        public void WhenPDDConfigSectionPlanDataDueDateTableRowIsEditedWithFileMessageSetTo(string p0)
        {
            IWebElement edit = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_gvPDDD']//tr[2]//input[@alt='Edit']"));
            fw.ExecuteJavascript(edit);
            tmsWait.Hard(1);
            Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_gvPDDD_ctl02_txtFileMessage")).Clear();
            tmsWait.Hard(1);
            Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_gvPDDD_ctl02_txtFileMessage")).SendKeys(p0);
        }


        [When(@"PDDConfig section Plan Data Due Date table Update button is clicked")]
        public void WhenPDDConfigSectionPlanDataDueDateTableUpdateButtonIsClicked()
        {
            IWebElement edit = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_gvPDDD']//input[@alt='Update']"));
            fw.ExecuteJavascript(edit);
           
        }

        [Then(@"Verify EAM Configuration page Plan Data Due Date Table has Report Month as ""(.*)"" File Due Date as ""(.*)"" File Message as ""(.*)""")]
        public void ThenVerifyEAMConfigurationPagePlanDataDueDateTableHasReportMonthAsFileDueDateAsFileMessageAs(string p0, string p1, string p2)
        {
            tmsWait.Hard(2);
            string XpathElement = "//table[@id='ctl00_ctl00_MainMasterContent_MainContent_gvPDDD']//tr/td[contains(.,'"+p2+"')]/preceding-sibling::td[contains(.,'"+p1+"')]/preceding-sibling::td[contains(.,'"+p0+"')]";
            IWebElement element = Browser.Wd.FindElement(By.XPath(XpathElement));
            tmsWait.Hard(1);
            Assert.IsTrue(element.Displayed, "Expected Elements are not getting displayed");
        }

        [When(@"EAM Configuration page Plan Data Due Date Table has Report Month as ""(.*)"" File Due Date as ""(.*)"" File Message as ""(.*)"" data is edited")]
        public void WhenEAMConfigurationPagePlanDataDueDateTableHasReportMonthAsFileDueDateAsFileMessageAsDataIsEdited(string p0, string p1, string p2)
        {
            string XpathElement = "//table[@id='ctl00_ctl00_MainMasterContent_MainContent_gvPDDD']//tr/td[contains(.,'" + p2 + "')]/preceding-sibling::td[contains(.,'" + p1 + "')]/preceding-sibling::td[contains(.,'" + p0 + "')]/preceding-sibling::td/input[@alt='Edit']";
            IWebElement element = Browser.Wd.FindElement(By.XPath(XpathElement));
            fw.ExecuteJavascript(element);
            tmsWait.Hard(2);
        }

        [Then(@"Verify EAM Configuration page Plan Data File Message has value ""(.*)""")]
        public void ThenVerifyEAMConfigurationPagePlanDataFileMessageHasValue(string p0)
        {
            tmsWait.Hard(1);
            Assert.IsTrue(Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_gvPDDD_ctl04_lblFileMessage")).Text.Contains(p0), "Value is not exist");
        }

        [Then(@"Verify EAM Configuration page Plan Data File Message displayed value ""(.*)""")]
        public void ThenVerifyEAMConfigurationPagePlanDataFileMessageDisplayedValue(string p0)
        {
            tmsWait.Hard(1);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_gvPDDD']//td[contains(.,'"+p0+"')]")).Displayed, "Value is not exist");
        }


        [Then(@"Verify EAM Configuration page Plan Data Due Date Table has row")]
        public void ThenVerifyEAMConfigurationPagePlanDataDueDateTableHasRow(Table table)
        {
            tmsWait.Hard(5);

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.PDDDConfig.PDDDConfigTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                //            thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 2)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[2];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                //else
                //{
                //    //Click next page link and start over.
                //    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                //    {
                //        thisTP.bNotAtLastPageOfRecords = true;
                //        thisTP.NPL.Click();
                //        tmsWait.Hard(2);
                //    }
                //}
                baseTable = EAM.PDDDConfig.PDDDConfigTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }



        }

    }
}
