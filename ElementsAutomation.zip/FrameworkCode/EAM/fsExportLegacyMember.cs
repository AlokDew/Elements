﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using TMSoR1.FrameworkCode;

namespace TMSoR1
{
    [Binding]
    class fsExportLegacyMember
    {

        [Then(@"Members View Edit Page Marital Status is set to ""(.*)""")]
        public void ThenMembersViewEditPageMaritalStatusIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            SelectElement drp = new SelectElement(EAM.MembersNew.MaritalStatus);
            drp.SelectByText(p0);
        }
        [Then(@"Members View Edit Page Language is set to ""(.*)""")]
        public void ThenMembersViewEditPageLanguageIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            SelectElement drp = new SelectElement(EAM.MembersNew.Language);
            drp.SelectByText(p0);
        }


        [Then(@"Members View Edit Page Election Type is set to ""(.*)""")]
        public void ThenMembersViewEditPageElectionTypeIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            SelectElement drp = new SelectElement(EAM.MembersNew.LatestElectType);
            drp.SelectByText(p0);
        }


        [Then(@"Members View Edit Page Save button is Clicked")]
        public void ThenMembersViewEditPageSaveButtonIsClicked()
        {
            fw.ExecuteJavascript(EAM.MembersNew.Save);
        }

        [Then(@"Verify Legacy Member Result has MBI ""(.*)""")]
        public void ThenVerifyLegacyMemberResultHasMBI(string p0)
        {
            string mbi = tmsCommon.GenerateData(p0);
            bool mbiValuePresence = false;
            By mbipresence = By.XPath("(//table[@id='ctl00_ctl00_MainMasterContent_MainContent_dgRaps']//tr/td[contains(.,'" + mbi + "')])[1]");
            IWebElement link = null;
            int i = 1;

            while(!mbiValuePresence)
            {
                mbiValuePresence=ReUsableFunctions.elementPresence(mbipresence);
                if (!mbiValuePresence)
                {
                    link = Browser.Wd.FindElement(By.XPath("//table//a[" + i + "]"));
                    fw.ExecuteJavascript(link);
                    i++;
                }
            }
            

        }




    }
}
