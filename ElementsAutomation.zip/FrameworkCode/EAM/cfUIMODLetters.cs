﻿
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1
{
    [Binding]
    class cfUIMODLetters
    {

        public static LettersCollections LettersCollections { get { return new LettersCollections(); } }
    }

    [Binding]
    public class LettersCollections
    {
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='letter-select-planId']//span[@class='k-select']")); } }
        public IWebElement PBPID { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='letter-select-pbp']//span[@class='k-select']")); } }
        public IWebElement SortBy { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='dropdownSortBy_listbox']")); } }
        public IWebElement Values { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='dropdownValues_listbox']")); } }
        public IWebElement Language { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='dropdownLanguage_listbox']")); } }
        public IWebElement SearchButton { get { return Browser.Wd.FindElement(By.XPath("//span[contains(.,'SEARCH')]")); } }
        public IWebElement RemoveButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='letter-btn-remove']")); } }
        public IWebElement PreviewButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='letter-btn-preview']")); } }
        public IWebElement GenerateLettersButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='letter-btn-generateLetters']")); } }
        public IWebElement DeselctAllButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='letter-btn-deselectAll']")); } }
        public IWebElement SelectAllButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='letter-btn-selectAll']")); } }
        public IWebElement LetterName { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='dropdownOnDemandLetters_listbox']")); } }
        public IWebElement ToggleRemoveAllButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='letter-btn-toggleRemoveAll']")); } }

        public IWebElement AngPreviewButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='letter-btn-preview']")); } }
        public IWebElement AngGenerateLettersButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='letter-btn-generateLetters']")); } }
        public IWebElement AngDeselctAllButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='letter-btn-deselectAll']")); } }
        public IWebElement AngSelectAllButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='letter-btn-selectAll']")); } }
        public IWebElement AngLetterName { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='dropdownOnDemandLetters_listbox']")); } }
        public IWebElement AngToggleRemoveAllButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='letter-btn-toggleRemoveAll']")); } }
        public IWebElement LettersSection { get { return Browser.Wd.FindElement(By.CssSelector("[title='Letters']")); } }


        
    }
}

