﻿using OpenQA.Selenium;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.EAM
{
    [Binding]
    public static class cfMailingList
    {
        public static IWebElement TRRStartDateDropdown { get { return Browser.Wd.FindElement(By.CssSelector("select[id$='MainMasterContent_MainContent_ddlStartDate']")); } }
        public static IWebElement TRREndDateDropdown { get { return Browser.Wd.FindElement(By.CssSelector("select[id$='MainMasterContent_MainContent_ddlEndDate']")); } }
        public static IWebElement TRRTransactionProcessed { get { return Browser.Wd.FindElement(By.CssSelector("select[id$='MainMasterContent_MainContent_ddlIsProcessed']")); } }
        public static IWebElement TRRPlanID { get { return Browser.Wd.FindElement(By.CssSelector("select[id$='MainMasterContent_MainContent_ddlPlanID']")); } }
        public static IWebElement ExportButton { get { return Browser.Wd.FindElement(By.CssSelector("input[id$='MainMasterContent_MainContent_TRRCodeUserList1_btnExport']")); } }
        public static IWebElement SelectAllCheckbox{ get { return Browser.Wd.FindElement(By.CssSelector("input[id$='MainMasterContent_MainContent_TRRCodeUserList1_CheckBox1']")); } }
        

    }
}
