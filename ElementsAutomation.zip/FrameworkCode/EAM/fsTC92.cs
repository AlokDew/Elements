﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1
{
    [Binding]
   
    class fsTC92
    {

        [Then(@"Verify elecappfile table ""(.*)"" column is set to ""(.*)""")]
        public void ThenVerifyElecappfileTableColumnIsSetTo(string p0, string p1)
        {
            string act = tmsCommon.GenerateData(p0);
            string exp = p1;

            Assert.AreEqual(exp, act);
        }

    }
}
