﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using TMSoR1.FrameworkCode;
namespace TMSoR1
{
    [Binding]
    class fsPremiumBilling
    {

        [Then(@"Verify Rx Billing tab Part C Premium Amount is set to ""(.*)""")]
        public void ThenVerifyRxBillingTabPartCPremiumAmountIsSetTo(string expectedAmount)
        {
            tmsWait.Hard(5);
            string actualAmount = PremiumBilling.RxBillingTab.PartCAmount.GetAttribute("value");
            Assert.AreEqual(expectedAmount, actualAmount, " Both values are not matching");


        }


        [When(@"View Edit Transaction Part C Amount is noted")]
        public void WhenViewEditTransactionPartCAmountIsNoted()
        {
            GlobalRef.PartCAmtTC78 = EAM.TransactionsViewEdit.PartCAmount.GetAttribute("value");
        }


    }
}
