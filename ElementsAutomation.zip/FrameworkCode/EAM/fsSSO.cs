﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using OpenQA.Selenium.Support.UI;
using TMSoR1.FrameworkCode;

namespace TMSoR1
{
    [Binding]
    class fsSSO
    {
        [When(@"Administration page Root Administration menu External System submenu Identifier submenu is Clicked")]
        public void WhenAdministrationPageRootAdministrationMenuExternalSystemSubmenuIdentifierSubmenuIsClicked()
        {
            tmsWait.Hard(5);
            IWebElement admin = Browser.Wd.FindElement(By.CssSelector("[title='Root Administration']"));
            fw.ExecuteJavascript(admin);
            tmsWait.Hard(1);
            IWebElement externalSys = Browser.Wd.FindElement(By.XPath("//span[contains(.,'External Systems')]"));
            fw.ExecuteJavascript(externalSys);
            tmsWait.Hard(1);
            IWebElement submenu = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Identity Server')]"));
            fw.ExecuteJavascript(submenu);

        }

        [When(@"External Systems page Current Tenant is Clicked")]
        public void WhenExternalSystemsPageCurrentTenantIsClicked()
        {
            string currentTenant = "Identity Server_" + ReUsableFunctions.returnCurrentTenant();

            IWebElement submenu = Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='ids-grid-grdssisconfiguration']//td[contains(.,'"+ currentTenant + "')]/following-sibling::td/a)[1]"));
            fw.ExecuteJavascript(submenu);
            tmsWait.Hard(5);

            Browser.SwitchToChildWindow();
        }


        [When(@"User Management page Click on any ""(.*)"" Role is Clicked")]
        public void WhenUserManagementPageClickOnAnyRoleIsClicked(string p0)
        {
            string RootAdmin = tmsCommon.GenerateData(p0);

            if (RootAdmin.Equals("RootAdmin"))
            {
                string link = "//div[@test-id='users-grid-users']//td[contains(.,'tmsapp')]/following-sibling::td[contains(.,'" + RootAdmin + "')]/following-sibling::td/a";
                GlobalRef.RootAdmin = RootAdmin;
                IWebElement LinkEle = Browser.Wd.FindElement(By.XPath(link));
                fw.ExecuteJavascript(LinkEle);
                tmsWait.Hard(3);
            }

            if (RootAdmin.Equals("TenantAdmin"))
            {
                string userName = Browser.Wd.FindElement(By.XPath("(//div[@test-id='users-grid-users']//td[contains(.,'TenantAdmin')]/preceding-sibling::td/span[@ng-bind='dataItem.name'])[1]")).Text;
                GlobalRef.UserName = userName;
                GlobalRef.TenantAdmin = RootAdmin;
                string link = "(//div[@test-id='users-grid-users']//td[contains(.,'TenantAdmin')]/following-sibling::td/a)[1]";

                IWebElement LinkEle = Browser.Wd.FindElement(By.XPath(link));
                fw.ExecuteJavascript(LinkEle);
                tmsWait.Hard(3);

                
            }
            if (RootAdmin.Equals("User"))
            {
                string userName = Browser.Wd.FindElement(By.XPath("(//div[@test-id='users-grid-users']//td[contains(.,'User')]/preceding-sibling::td/span[@ng-bind='dataItem.name'])[1]")).Text;
                GlobalRef.UserName = userName;
                GlobalRef.TenantAdmin = RootAdmin;
                string link = "(//div[@test-id='users-grid-users']//td[contains(.,'User')]/following-sibling::td/a)[1]";

                IWebElement LinkEle = Browser.Wd.FindElement(By.XPath(link));
                fw.ExecuteJavascript(LinkEle);
                tmsWait.Hard(3);


            }



        }

        [Then(@"Verify Login page displayed message as ""(.*)""")]
        public void ThenVerifyLoginPageDisplayedMessageAs(string expResult)
        {
            tmsWait.Hard(5);
            string msg = Browser.Wd.FindElement(By.XPath("//div[@class='alert alert-danger col-xs-12 error-msg-block error-message']")).Text;
            string actualResult = msg.Trim();

            Assert.AreEqual(expResult, actualResult, " Both are not matching");
        }

        [Then(@"Verify User is able to login to Elements application with ""(.*)"" user ID ""(.*)"" password")]
        public void ThenVerifyUserIsAbleToLoginToElementsApplicationWithUserIDPassword(string p0, string p1)
        {
            tmsWait.Hard(10);
            string user = tmsCommon.GenerateData(p0);
            string pass = tmsCommon.GenerateData(p1);

            Navigation.navigate();

            Browser.Wd.Manage().Window.Maximize();
            tmsWait.Hard(10);
            EAM.EAMLogin.UserID.Clear();
            EAM.EAMLogin.UserID.SendKeys(user);
            EAM.EAMLogin.Password.Clear();
            EAM.EAMLogin.Password.SendKeys(pass);
            fw.ExecuteJavascript(EAM.EAMLogin.Submit);
        }

        [Then(@"Verify User is able to login to Elements application with ""(.*)"" user ""(.*)"" password")]
        public void ThenVerifyUserIsAbleToLoginToElementsApplicationWithUserPassword(string p0, string p1)
        {
            string user = tmsCommon.GenerateData(p0);
            string pass = tmsCommon.GenerateData(p1);
            string userrole;
            try
            {
                userrole = GlobalRef.RootAdmin.ToString();
                fw.ConsoleReport(" we are using user as " + userrole);
            }
            catch
            {
                try
                {
                    userrole = GlobalRef.TenantAdmin.ToString();
                    fw.ConsoleReport(" we are using user as " + userrole);
                }
                catch
                {
                    userrole = GlobalRef.User.ToString();
                    fw.ConsoleReport(" we are using user as " + userrole);
                }
            }

            if (userrole.Equals("RootAdmin"))
            {
                Navigation.navigate();

                Browser.Wd.Manage().Window.Maximize();

                EAM.EAMLogin.UserID.Clear();
                EAM.EAMLogin.UserID.SendKeys(user);
                EAM.EAMLogin.Password.Clear();
                EAM.EAMLogin.Password.SendKeys(pass);
                EAM.EAMLogin.Submit.Click();
            }
            if (userrole.Equals("TenantAdmin"))
            {
                user = GlobalRef.UserName.ToString();
                Navigation.navigate();
                Browser.Wd.Manage().Window.Maximize();
                EAM.EAMLogin.UserID.Clear();
                EAM.EAMLogin.UserID.SendKeys(user);
                EAM.EAMLogin.Password.Clear();
                EAM.EAMLogin.Password.SendKeys(pass);
                EAM.EAMLogin.Submit.Click();
            }
            if (userrole.Equals("User"))
            {
                user = GlobalRef.UserName.ToString();
                Navigation.navigate();
                Browser.Wd.Manage().Window.Maximize();
                EAM.EAMLogin.UserID.Clear();
                EAM.EAMLogin.UserID.SendKeys(user);
                EAM.EAMLogin.Password.Clear();
                EAM.EAMLogin.Password.SendKeys(pass);
                EAM.EAMLogin.Submit.Click();
            }




        }


        [When(@"Edit User page Click on any Reset Password tab is Clicked")]
        public void WhenEditUserPageClickOnAnyResetPasswordTabIsClicked()
        {
            IWebElement DefaultApp = Browser.Wd.FindElement(By.XPath("//select[@data-ng-model='defaultApplication']/option[@selected='selected']"));
            if(DefaultApp.Text.Equals("Select"))
            {

                IWebElement addnewrecord = Browser.Wd.FindElement(By.XPath("//a[@class='k-button k-button-icontext k-grid-add']"));
                fw.ExecuteJavascript(addnewrecord);
                IWebElement appDrp = Browser.Wd.FindElement(By.XPath("(//span[@class='k-dropdown-wrap k-state-default'])[1]"));
                fw.ExecuteJavascript(appDrp);
                tmsWait.Hard(1);
                IWebElement selectDB = Browser.Wd.FindElement(By.XPath("//ul[@data-role='staticlist']/li[contains(.,'Framework')]"));
                fw.ExecuteJavascript(selectDB);

                tmsWait.Hard(2);
                IWebElement roleDrp = Browser.Wd.FindElement(By.XPath("(//span[@class='k-select'])[2]"));
                fw.ExecuteJavascript(roleDrp);
                tmsWait.Hard(1);
                IWebElement selectRole = Browser.Wd.FindElement(By.XPath("//ul[@data-role='staticlist']/li[contains(.,'Administrator')]"));
                fw.ExecuteJavascript(selectRole);

                IWebElement save = Browser.Wd.FindElement(By.XPath("//a[@class='k-button k-button-icontext k-primary k-grid-update']"));
                fw.ExecuteJavascript(save);
                new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@data-ng-model='defaultApplication']"))).SelectByText("Framework");

                IWebElement Button = Browser.Wd.FindElement(By.XPath("(//button[@class='btn primaryButton'])[1]"));

                fw.ExecuteJavascript(Button);


                
            }
           

            IWebElement Reset = Browser.Wd.FindElement(By.CssSelector("[aria-controls='tabStrip-2']"));
            fw.ExecuteJavascript(Reset);

        }

        [When(@"Edit User page New Password text box is set to ""(.*)""")]
        public void WhenEditUserPageNewPasswordTextBoxIsSetTo(string p0)
        {
            string pass = tmsCommon.GenerateData(p0);
            IWebElement password = Browser.Wd.FindElement(By.XPath("(//input[@type='password'])[1]"));

            password.SendKeys(pass);
        }

        [When(@"Edit User page Confirm Password text box is set to ""(.*)""")]
        public void WhenEditUserPageConfirmPasswordTextBoxIsSetTo(string p0)
        {
            string pass = tmsCommon.GenerateData(p0);
            IWebElement confpassword = Browser.Wd.FindElement(By.XPath("(//input[@type='password'])[2]"));

            confpassword.SendKeys(pass);
        }

        [When(@"Edit User page Update Button is Clicked")]
        public void WhenEditUserPageUpdateButtonIsClicked()
        {
            IWebElement LinkEle = Browser.Wd.FindElement(By.XPath("(//button[@class='btn primaryButton'])[2]"));
            fw.ExecuteJavascript(LinkEle);
            tmsWait.Hard(1);
            
            
        }


        [Then(@"Verify Framework Administration page is displayed successfully")]
        public void ThenVerifyFrameworkAdministrationPageIsDisplayedSuccessfully()
        {
            By loc = By.XPath("//div[@class='adminTitle formGroup'][contains(.,'Framework Administration')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }



        [When(@"Tenant Configuration ""(.*)"" application is detached")]
        public void WhenTenantConfigurationApplicationIsDetached(string p0)
        {
            string application_name = tmsCommon.GenerateData(p0);
            IWebElement delete_icon = Browser.Wd.FindElement(By.XPath("(//div[@test-id='tenantConfiguration-grid-grdTenantSetUp']//td[contains(.,'" +application_name+ "')])[1]/parent::tr//td/a[2]"));
            fw.ExecuteJavascript(delete_icon);
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")));
            tmsWait.Hard(10);
        }

        [When(@"Tenant Configuration Add ""(.*)"" application")]
        public void WhenTenantConfigurationAddApplication(string p0)
        {
            string application_name = tmsCommon.GenerateData(p0);
            IWebElement application = Browser.Wd.FindElement(By.XPath("//select[@test-id='tenantConfiguration-select-application']"));
            SelectElement app_name = new SelectElement(application);
            app_name.SelectByText(application_name);
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='tenantConfiguration-btn-add']")));
            tmsWait.Hard(3);
           
        }

        [When(@"Tenant Configuration attach ""(.*)"" database to ""(.*)"" application")]
        public void WhenTenantConfigurationAttachDatabaseToApplication(string p0, string p1)
        {
            string application_name = tmsCommon.GenerateData(p1);
            string database_name = tmsCommon.GenerateData(p0);
            IWebElement Edit_Icon = Browser.Wd.FindElement(By.XPath("(//div[@test-id='tenantConfiguration-grid-grdTenantSetUp']//td[contains(.,'" + application_name + "')])[1]/parent::tr//td/a[1]"));
            fw.ExecuteJavascript(Edit_Icon);
            IWebElement Application_Connection = Browser.Wd.FindElement(By.XPath("//select[@test-id='applicationLevelConfiguration-select-applicationDatabases']"));
            SelectElement App_connection = new SelectElement(Application_Connection);
            App_connection.SelectByText(database_name);
            IWebElement Save_btn = Browser.Wd.FindElement(By.XPath("//button[@test-id='applicationLevelConfiguration-btn-save']"));
            fw.ExecuteJavascript(Save_btn);
            tmsWait.Hard(3);
        }

        [Then(@"Verify Tenant Configuration Grid has row with application name ""(.*)"" and connection name ""(.*)""")]
        public void ThenVerifyTenantConfigurationGridHasRowWithApplicationNameAndConnectionName(string p0, string p1)
        {
            string application_name = tmsCommon.GenerateData(p0);
            string connection_name=tmsCommon.GenerateData(p1);
            
            bool hasrow = false;
            
             try
                {
                    hasrow = Browser.Wd.FindElement(By.XPath("//div[@test-id='tenantConfiguration-grid-grdTenantSetUp']//td[contains(.,'" + application_name + "')]/parent::tr//td[contains(.,'" + connection_name + "')]")).Displayed;
                   
                }
                catch
                {

                }

           
            //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed);

            Assert.IsTrue(hasrow, "There is no such row Present");

        }




    }

}
