﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TMSoR1;
using OpenQA.Selenium.Support.UI;

namespace TMSoR1.FrameworkCode.EAM
{
    [Binding]
    class fsUIMODEAMMemberInformation
    {
        [When(@"Verify Member Information Provider section ""(.*)"" Text box is set to ""(.*)""")]
        [Then(@"Verify Member Information Provider section ""(.*)"" Text box is set to ""(.*)""")]
        public void ThenVerifyMemberInformationProviderSectionTextBoxIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string expectedValue = tmsCommon.GenerateData(p1);
            tmsWait.Hard(3);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                switch (field)
                {
                    case "Gyn Name":
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODProvider.GynName);
                        break;
                    case "IPA Group ID":
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODProvider.IPAGroupID);
                        break;
                    case "Gyn PCP ID":
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODProvider.GynPCPID);
                        break;
                    case "Gyn PCP Prv":
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODProvider.GynPCPPrv);
                        break;
                    case "First Name":
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODProvider.FirstName);
                        break;
                    case "Last Name":
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODProvider.LastName);
                        break;
                    case "PCP ID":
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODProvider.PCPID);
                        break;
                    case "PCP Provider ID":
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODProvider.PCPPrvIDAngular);
                        break;
                        
                }
            }
            else
            {
                switch (field)
                {
                    case "Gyn Name":
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODProvider.GynName);
                        break;
                    case "IPA Group ID":
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODProvider.IPAGroupID);
                        break;
                    case "Gyn PCP ID":
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODProvider.GynPCPID);
                        break;
                    case "Gyn PCP Prv":
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODProvider.GynPCPPrv);
                        break;
                    case "First Name":
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODProvider.FirstName);
                        break;
                    case "Last Name":
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODProvider.LastName);
                        break;
                    case "PCP ID":
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODProvider.PCPID);
                        break;
                }
            }

        }

        [Then(@"Verify Member Information Premium LIS Information section ""(.*)"" Text box is set to ""(.*)""")]
        [Given(@"Verify Member Information Premium LIS Information section ""(.*)"" Text box is set to ""(.*)""")]
        [When(@"Verify Member Information Premium LIS Information section ""(.*)"" Text box is set to ""(.*)""")]
        public void ThenVerifyMemberInformationPremiumLISInformationSectionTextBoxIsSetTo(string p0, string p1)
        {

            string field = tmsCommon.GenerateData(p0);
            string expectedValue = tmsCommon.GenerateData(p1);

            switch (field)
            {
                case "LEP Waived Amount":
                    ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLEPWaivedAmount);
                    break;

                case "Part D Premium":
                    ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODPremiumLIS.UIMODPartDPremium);
                    break;
            }
        }

        [Then(@"Verify Member Information Premium LIS section ""(.*)"" Text box is set to ""(.*)""")]
        public void ThenVerifyMemberInformationPremiumLISSectionTextBoxIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string expectedValue = tmsCommon.GenerateData(p1);

            switch (field)
            {
                case "PW Option":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'PW Option')]/parent::div//span[@class='k-input']");
                        fw.ScrollWindowToViewElementUsingLocators(Drp);
                        ReUsableFunctions.compareExpectedValueWithKendoDropDownValue(expectedValue, Drp);
                    }
                    else
                    {
                        ReUsableFunctions.compareExpectedValueWithKendoDropDownValue(expectedValue, cfUIMODMemberCreation.UIMODPremiumLIS.UIMODPWODropdownList);
                    }
                    break;
            }
        }


        [Then(@"Verify Member Information Payment section ""(.*)"" Drop down is set to ""(.*)""")]
        public void ThenVerifyMemberInformationPaymentSectionDropDownIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string expectedValue = tmsCommon.GenerateData(p1);

            switch (field)
            {
                case "Bank Account Type":

                    ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODPayment.BankAccountTypeDropDownlist);
                    break;
                case "Account Type":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ddele = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Account Type')]/parent::div//span[@class='k-input']"));
                        string actual_value = ddele.Text;
                        Assert.IsTrue(actual_value.Contains(expectedValue), "Value does not match");
                    }

                    else
                    {
                        //ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODPayment.AccountTypeDropDownlist);
                        ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfUIMODMemberCreation.UIMODPayment.AccountTypeDropDownlist);
                    }
                    break;
                case "Bank":
                    ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODPayment.Bank);
                    break;
            }


        }
        [Then(@"Verify Member Information RX Details section ""(.*)"" is Disabled")]
        public void ThenVerifyMemberInformationRXDetailsSectionIsDisabled(string p0)
        {
            string field = tmsCommon.GenerateData(p0);


            switch (field)
            {
                case "RXID":
                    ReUsableFunctions.verifyComponentDisabled(cfUIMODMemberCreation.UIMODMemRxDetails.UIMODRxID);
                    break;
                case "RXGroup":
                    ReUsableFunctions.verifyComponentDisabled(cfUIMODMemberCreation.UIMODMemRxDetails.UIMODRxGroup);
                    break;
                case "RXBIN":
                    ReUsableFunctions.verifyComponentDisabled(cfUIMODMemberCreation.UIMODMemRxDetails.UIMODRxBIN);
                    break;
                case "RXPCN":
                    ReUsableFunctions.verifyComponentDisabled(cfUIMODMemberCreation.UIMODMemRxDetails.UIMODRxPCN);
                    break;

            }
        }


        [Then(@"Verify View Edit Members Transaction page RX Details section ""(.*)"" is displayed as ""(.*)""")]
        public void ThenViewEditMembersTransactionPageRXDetailsSectionIsDisplayedAs(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string expectedValue = tmsCommon.GenerateData(p1.ToString());

            if (ConfigFile.EnvType.Equals("ESI"))
            {
                switch (field)
                {
                    case "RXID":
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODTransactions.TransPageRXID);
                        break;
                    case "PWO":
                        tmsWait.Hard(4);
                        IWebElement ele = Browser.Wd.FindElement(By.XPath("(//span[contains(.,'" + expectedValue + "')])[3]"));
                        string act = ele.Text;

                        Assert.AreEqual(expectedValue, act, "Both values are not matching");
                        break;

                }
            }
            else
            {
                switch (field)
                {
                    case "RXID":
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODTransactions.TransPageRXID);
                        break;
                    case "PWO":
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODTransactions.PWOOption);
                        break;

                }
            }
        }


        [Then(@"Verify Member Information RX Details section ""(.*)"" is displayed as ""(.*)""")]
        public void ThenVerifyMemberInformationRXDetailsSectionIsDisplayedAs(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string expectedValue = tmsCommon.GenerateData(p1);

            switch (field)
            {
                case "RXID":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        tmsWait.Hard(3);

                        By Drp = By.XPath("//label[contains(.,'RX ID')]/parent::div//input");
                        string actualValue = Browser.Wd.FindElement(Drp).GetAttribute("value");
                        Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");
                    }
                    else
                    {
                        ReUsableFunctions.ScrollingInToSpecicElementView(cfUIMODMemberCreation.UIMODMemRxDetails.UIMODRxID);
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemRxDetails.UIMODRxID);
                    }
                    break;
                case "RXGroup":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        tmsWait.Hard(3);

                        By Drp = By.XPath("//label[contains(.,'RX Group')]/parent::div//input");
                        string actualValue = Browser.Wd.FindElement(Drp).GetAttribute("value");
                        Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");
                    }
                    else
                    {
                        ReUsableFunctions.ScrollingInToSpecicElementView(cfUIMODMemberCreation.UIMODMemRxDetails.UIMODRxGroup);
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemRxDetails.UIMODRxGroup);
                    }
                    break;
                case "RXBIN":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        tmsWait.Hard(3);

                        By Drp = By.XPath("//label[contains(.,'RX BIN')]/parent::div//input");
                        string actualValue = Browser.Wd.FindElement(Drp).GetAttribute("value");
                        Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");
                    }
                    else
                    {
                        ReUsableFunctions.ScrollingInToSpecicElementView(cfUIMODMemberCreation.UIMODMemRxDetails.UIMODRxBIN);
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemRxDetails.UIMODRxBIN);
                    }
                    break;
                case "RXPCN":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        tmsWait.Hard(3);

                        By Drp = By.XPath("//label[contains(.,'RX PCN')]/parent::div//input");
                        string actualValue = Browser.Wd.FindElement(Drp).GetAttribute("value");
                        Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");
                    }
                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemRxDetails.UIMODRxPCN);
                    }
                    break;
                case "SecondaryRXID":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        tmsWait.Hard(3);

                        By Drp = By.XPath("//label[contains(.,'Secondary Rx ID')]/parent::div//input");
                        string actualValue = Browser.Wd.FindElement(Drp).GetAttribute("value");
                        Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");
                    }
                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemRxDetails.UIMODSecondaryRxID);
                    }
                    break;
                case "SecondaryRXGroup":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        tmsWait.Hard(3);

                        By Drp = By.XPath("//label[contains(.,'Secondary Rx Group')]/parent::div//input");
                        string actualValue = Browser.Wd.FindElement(Drp).GetAttribute("value");
                        Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");
                    }
                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemRxDetails.UIMODSecondaryRxGroup);
                    }
                        break;
                case "SecondaryRXBIN":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        tmsWait.Hard(3);

                        By Drp = By.XPath("//label[contains(.,'Secondary BIN')]/parent::div//input");
                        string actualValue = Browser.Wd.FindElement(Drp).GetAttribute("value");
                        Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");
                    }
                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemRxDetails.UIMODSecondaryRxBIN);
                    }
                    break;
                case "SecondaryRXPCN":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        tmsWait.Hard(3);

                        By Drp = By.XPath("//label[contains(.,'Secondary PCN')]/parent::div//input");
                        string actualValue = Browser.Wd.FindElement(Drp).GetAttribute("value");
                        Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");
                    }
                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemRxDetails.UIMODSecondaryRxPCN);
                    }
                    break;
            }
        }

        [Then(@"Verify Member Information Rx Details section ""(.*)"" is disabled")]
        public void ThenVerifyMemberInformationRxDetailsSectionIsdisabled(string p0)
        {
            string field = tmsCommon.GenerateData(p0);

            Boolean isdis = false;
            string isdisabled;
            switch (field)
            {
                case "Rx BIN":
                    IWebElement RxBIN = cfUIMODMemberCreation.UIMODMemRxDetails.UIMODRxBIN;

                    isdisabled = RxBIN.GetAttribute("disabled");
                    if (isdisabled == "true")
                    {
                        isdis = true;
                    }
                    Assert.IsTrue(isdis, "rxBIN field is not disabled");
                    break;

                case "Rx PCN":
                    IWebElement RxPCN = cfUIMODMemberCreation.UIMODMemRxDetails.UIMODRxPCN;

                    isdisabled = RxPCN.GetAttribute("disabled");
                    if (isdisabled == "true")
                    {
                        isdis = true;
                    }
                    Assert.IsTrue(isdis, "rxPCN field is not disabled");

                    break;
                case "Rx Group":
                    IWebElement RxGroup = cfUIMODMemberCreation.UIMODMemRxDetails.UIMODRxPCN;

                    isdisabled = RxGroup.GetAttribute("disabled");
                    if (isdisabled == "true")
                    {
                        isdis = true;
                    }
                    Assert.IsTrue(isdis, "rxgroup field is not disabled");

                    break;
            }
        }

        [Then(@"Verify Member Information Spans section displays message  as ""(.*)""")]
        public void ThenVerifyMemberInformationSpansSectionDisplaysMessageAs(string p0)
        {
            By msg = By.XPath("//label[@test-id='memberDemographics-lbl-noSpanRecords'][contains(.,'" + p0 + "')]");

            Assert.IsTrue(Browser.Wd.FindElement(msg).Displayed);
        }

        [Then(@"Verify Member Information Contact Details section ""(.*)"" is displayed as ""(.*)""")]
        [When(@"Verify Member Information Contact Details section ""(.*)"" is displayed as ""(.*)""")]
        public void ThenVerifyMemberInformationContactDetailsSectionIsDisplayedAs(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string expectedValue = tmsCommon.GenerateData(p1);

            switch (field)
            {
                case "Primary Address":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ddele = Browser.Wd.FindElement(By.XPath("(//label[contains(.,'Address Type')]/parent::div//span[@class='k-input'])[1]"));
                        string actual_value = ddele.Text;
                        Assert.IsTrue(actual_value.Contains(expectedValue), "Value does not match");
                    }

                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfUIMODMemberCreation.UIMODMemContacts.UIMODPrimaryAddressTypeDropdownlist);
                    }
                    break;
                case "Address1":
                    ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemContacts.UIMODPrimaryAddress1);
                    break;
                case "Address2":
                    ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemContacts.UIMODPrimaryAddress2);
                    break;
                case "Phone":
                    ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemContacts.UIMODPrimaryPhone);
                    break;
                case "City":
                    ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemContacts.UIMODPrimaryCity);
                    break;
                case "State":
                    ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemContacts.UIMODPrimaryState);
                    break;
                case "Zip":
                    ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemContacts.UIMODPrimaryZip);
                    break;
                case "County":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        /*changed to use test-id of label instead of text, as the text "County" points to the wrong object or is ambiguous in some circumstances*/
                        IWebElement ddele = Browser.Wd.FindElement(By.XPath("//label[@test-id='memberContacts-lbl-county']/parent::div//span[@class='k-input']"));
                        string actual_value = ddele.Text;
                        Assert.IsTrue(actual_value.Contains(expectedValue), "Value does not match");
                    }

                    else
                    {
                     fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODMemContacts.UIMODPrimaryCountyDropdownlist);
                     ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfUIMODMemberCreation.UIMODMemContacts.UIMODPrimaryCountyDropdownlist);
                    }
                    break;
                case "SCC":
                    ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemContacts.UIMODPrimarySCC);
                    break;
                case "Response City":
                    ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemContacts.UIMODResponseCity);
                    break;
                case "Response State":
                    ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemContacts.UIMODResponseState);
                    break;
                case "Response Zip":
                    ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemContacts.UIMODResponseZip);
                    break;
                case "Response Relation":
                    ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfUIMODMemberCreation.UIMODMemContacts.UIMODResponseRelationDropdownlist);
                    break;
                case "EmergContact":
                    ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemContacts.UIMODEmergencyContact);
                    break;
                case "EmergRelation":
                    ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemContacts.UIMODEmergencyRelation);
                    break;
                case "EmergPhone":
                    ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemContacts.UIMODEmergenceyPhone);
                    break;
                case "ResponsePhone":
                    ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemContacts.UIMODResponsePhone);
                    break;
                case "Second Phone":
                    ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemContacts.UIMODSecondPhone);
                    break;
                case "Second ZIP":
                    ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemContacts.UIMODSecondZip);
                    break;
                case "Second Address1":
                    ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemContacts.UIMODSecondAddress1);
                    break;
                case "Second Address2":
                    ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemContacts.UIMODSecondAddress2);
                    break;

            }
        }
        [When(@"Verify Member Information Contact Details Secondary Address section ""(.*)"" is displayed as ""(.*)""")]
        [Then(@"Verify Member Information Contact Details Secondary Address section ""(.*)"" is displayed as ""(.*)""")]
        public void ThenVerifyMemberInformationContactDetailsSecondaryAddressSectionIsDisplayedAs(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string expectedValue = tmsCommon.GenerateData(p1);

            switch (field)
            {

                case "Address1":
                    ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemContacts.UIMODSecondAddress1);
                    break;
                case "Address2":
                    ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemContacts.UIMODSecondAddress2);
                    break;

                case "Zip":
                    ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemContacts.UIMODSecondZip);
                    break;

            }
        }

        [Then(@"Verify Member Information Span Details is not displayed Span Type as ""(.*)""")]
        public void ThenVerifyMemberInformationSpanDetailsIsNotDisplayedSpanTypeAs(string p0)
        {
            string span = tmsCommon.GenerateData(p0);
            By ele = By.XPath("//kendo-grid[@test-id='memberSpan-grid-memberSpansGrid']//tr//td[@aria-colindex='2'][contains(.,'"+ span + "')]");
            AngularFunction.elementNotPresenceUsingLocators(ele);
        }


        [Then(@"Verify Member Information Span Details displayed Plan Id as ""(.*)"" Status Type as ""(.*)"" Value as ""(.*)"" Start Date as ""(.*)"" End Date as ""(.*)""")]
        public void ThenVerifyMemberInformationSpanDetailsDisplayedPlanIdAsStatusTypeAsValueAsStartDateAsEndDateAs(string p0, string p1, string p2, string p3, string p4)
        {
            string planID = tmsCommon.GenerateData(p0);
            string statusType = tmsCommon.GenerateData(p1);
            string value = tmsCommon.GenerateData(p2);
            string startDate = tmsCommon.GenerateData(p3);
            string endDate = tmsCommon.GenerateData(p4);

           // if (ConfigFile.tenantType.Equals("tmsx"))
           // {
                By spanDisplay = By.XPath("//kendo-grid[@test-id='memberSpan-grid-memberSpansGrid']//table[@role='presentation']//td[contains(.,'" + planID + "')]/following-sibling::td[contains(.,'" + statusType + "')]/following-sibling::td[contains(.,'" + value + "')]/following::td[contains(.,'" + startDate + "')]/following-sibling::td[contains(.,'" + endDate + "')]");

                UIMODUtilFunctions.elementPresenceUsingLocators(spanDisplay);
            //}
            //else
            //{
            //    By spanDisplay = By.XPath("//div[@test-id='memberSpan-grid-memberSpansGrid']//td[contains(.,'" + planID + "')]/following-sibling::td[contains(.,'" + statusType + "')]/following-sibling::td[contains(.,'" + value + "')]/following::td[contains(.,'" + startDate + "')]/following-sibling::td[contains(.,'" + endDate + "')]");

            //    UIMODUtilFunctions.elementPresenceUsingLocators(spanDisplay);
            //}

        }

        [When(@"Verify Member Information Span Details Plan Id as ""(.*)"" Status Type as ""(.*)"" Value as ""(.*)"" Start Date as ""(.*)"" End Date as ""(.*)"" row is clicked")]
        public void WhenVerifyMemberInformationSpanDetailsPlanIdAsStatusTypeAsValueAsStartDateAsEndDateAsRowIsClicked(string p0, string p1, string p2, string p3, string p4)
        {
            string planID = tmsCommon.GenerateData(p0);
            string statusType = tmsCommon.GenerateData(p1);
            string value = tmsCommon.GenerateData(p2);
            string startDate = tmsCommon.GenerateData(p3);
            string endDate = tmsCommon.GenerateData(p4);
            //kendo-grid[@test-id='memberSpan-grid-memberSpansGrid']//td[contains(.,'H1001')]
            By spanDisplay = By.XPath("//kendo-grid[@test-id='memberSpan-grid-memberSpansGrid']//td[contains(.,'" + planID + "')]/following-sibling::td[contains(.,'" + statusType + "')]/following-sibling::td[contains(.,'" + value + "')]/following::td[contains(.,'" + startDate + "')]/following-sibling::td[contains(.,'" + endDate + "')]/following-sibling::td/a[1]");
            fw.ScrollWindowToViewElementUsingLocators(spanDisplay);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(spanDisplay);
        }

        [When(@"Verify Member Information Span Details Plan Id as ""(.*)"" Status Type as ""(.*)"" Value as ""(.*)"" Start Date as ""(.*)"" End Date as ""(.*)"" row is Deleted")]
        public void WhenVerifyMemberInformationSpanDetailsPlanIdAsStatusTypeAsValueAsStartDateAsEndDateAsRowIsDeleted(string p0, string p1, string p2, string p3, string p4)
        {
            string planID = tmsCommon.GenerateData(p0);
            string statusType = tmsCommon.GenerateData(p1);
            string value = tmsCommon.GenerateData(p2);
            string startDate = tmsCommon.GenerateData(p3);
            string endDate = tmsCommon.GenerateData(p4);
            By spanDisplay;
            if (ConfigFile.tenantType == "tmsx")
            {
                spanDisplay = By.XPath("//*[@test-id='memberSpan-grid-memberSpansGrid']//td[contains(.,'" + planID + "')]/following-sibling::td[contains(.,'" + statusType + "')]/following-sibling::td[contains(.,'" + value + "')]/following::td[contains(.,'" + startDate + "')]/following-sibling::td[contains(.,'" + endDate + "')]/following-sibling::td/a[2]");

            }
            else {
                spanDisplay = By.XPath("//div[@test-id='memberSpan-grid-memberSpansGrid']//td[contains(.,'" + planID + "')]/following-sibling::td[contains(.,'" + statusType + "')]/following-sibling::td[contains(.,'" + value + "')]/following::td[contains(.,'" + startDate + "')]/following-sibling::td[contains(.,'" + endDate + "')]/following-sibling::td/a[2]");

            }
            fw.ScrollWindowToViewElementUsingLocators(spanDisplay);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(spanDisplay);

            try
            {
                UIMODUtilFunctions.clickOnConfirmationYesDialog();

            }
            catch
            {
                fw.ConsoleReport(" There is no Confirmation dialog");
            }
        }


        [Then(@"Verify Member Information Span Details Message ""(.*)"" is displayed")]
        public void ThenVerifyMemberInformationSpanDetailsMessageIsDisplayed(string message)
        {
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[@test-id='memberSpan-span-spanRecords']")).Text.Contains(message));
        }

        [When(@"Member Information Span Details Plan Id as ""(.*)"" Status Type as ""(.*)"" Value as ""(.*)"" Start Date as ""(.*)"" End Date as ""(.*)"" is clicked")]
        public void WhenMemberInformationSpanDetailsPlanIdAsStatusTypeAsValueAsStartDateAsEndDateAsIsClicked(string p0, string p1, string p2, string p3, string p4)
        {
            string planID = tmsCommon.GenerateData(p0);
            string statusType = tmsCommon.GenerateData(p1);
            string value = tmsCommon.GenerateData(p2);
            string startDate = tmsCommon.GenerateData(p3);
            string endDate = tmsCommon.GenerateData(p4);

            By spanDisplay = By.XPath("//kendo-grid[@test-id='memberSpan-grid-memberSpansGrid']//table[@role='presentation']//td[contains(.,'" + planID + "')]/following-sibling::td[contains(.,'" + statusType + "')]/following-sibling::td[contains(.,'" + value + "')]/following::td[contains(.,'" + startDate + "')]/following-sibling::td[contains(.,'" + endDate + "')]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(spanDisplay);
        }

        [Then(@"Verify Member Information ID History Details Type as ""(.*)"" Old Value as ""(.*)"" New Value as ""(.*)"" Change Source as ""(.*)""")]
        public void ThenVerifyMemberInformationIDHistoryDetailsTypeAsOldValueAsNewValueAsChangeSourceAs(string p0, string p1, string p2, string p3)
        {

            string Type = tmsCommon.GenerateData(p0);
            string oldValue = tmsCommon.GenerateData(p1);
            string newValue = tmsCommon.GenerateData(p2);
            string Source = tmsCommon.GenerateData(p3);
            By idHistoryDisplay;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                idHistoryDisplay = By.XPath("//kendo-grid[@test-id='idHistory-grid-memberIdHistoryGrid']//td[contains(.,'" + Type + "')]/following-sibling::td[contains(.,'" + oldValue + "')]/following-sibling::td[contains(.,'" + (newValue.ToUpper()) + "')]/following-sibling::td[contains(.,'" + Source + "')]");
            }
            else
            {
                 idHistoryDisplay = By.XPath("//div[@test-id='idHistory-grid-memberIdHistoryGrid']//td[contains(.,'" + Type + "')]/following-sibling::td[contains(.,'" + oldValue + "')]/following-sibling::td[contains(.,'" + (newValue.ToUpper()) + "')]/following-sibling::td[contains(.,'" + Source + "')]");
            }
            
            UIMODUtilFunctions.elementPresenceUsingLocators(idHistoryDisplay);
        }

        [When(@"Member Information ID History Bypass checkbox set ""(.*)"" corresponding to new MBI ""(.*)"" and Type ""(.*)""")]
        public void WhenMemberInformationIDHistoryBypassCheckboxSetCorrespondingToNewMBIAndType(string p0, string p1, string p2)
        {
            string status = tmsCommon.GenerateData(p0);
            string newValue = tmsCommon.GenerateData(p1);
            string Type = tmsCommon.GenerateData(p2);
            By idHistoryBypass = By.XPath("//kendo-grid[@test-id='idHistory-grid-memberIdHistoryGrid']//td[contains(.,'" + Type + "')]/following-sibling::td[contains(.,'')]/following-sibling::td[contains(.,'" + newValue + "')]/following-sibling::td/input");
            Boolean actStatus = Browser.Wd.FindElement(idHistoryBypass).Selected;
            if (actStatus == false && status.ToUpper().Equals("ON"))
            {
                UIMODUtilFunctions.clickOnWebElementUsingLocators(idHistoryBypass);
            }
            else if (actStatus == true && status.ToUpper().Equals("OFF"))
            {
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(idHistoryBypass);
            }
        }

        [When(@"Member Information ID History Update button is clicked")]
        public void WhenMemberInformationIDHistoryUpdateButtonIsClicked()
        {
            By idHistoryUpdate = By.CssSelector("button[test-id='idHistory-btn-update']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(idHistoryUpdate);
        }


        [When(@"I have Clicked on ""(.*)"" Button")]
        [Then(@"I have Clicked on ""(.*)"" Button")]
        public void WhenIHaveClickedOnButton(string p0)
        {
            string field = tmsCommon.GenerateData(p0);
            switch (field)
            {
                case "OEC/Sales":
                    ReUsableFunctions.clickOnWebElementAfterScrollingInToSpecicElementView(cfUIMODMemberCreation.UIMODOECSales.OECSalesLink);
                    tmsWait.Hard(2);
                    break;

                case "Spans":
                    ReUsableFunctions.clickOnWebElementAfterScrollingInToSpecicElementView(cfUIMODMemberCreation.UIMODSpan.SpansLink);
                    tmsWait.Hard(2);
                    break;

                case "Transactions":
                    ReUsableFunctions.clickOnWebElementAfterScrollingInToSpecicElementView(cfUIMODMemberCreation.UIMODTransaction.UIMODMemberTransactionLink);
                    // ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODTransaction.UIMODMemberTransactionLink);
                    tmsWait.Hard(2);
                    break;
            }
        }



        [Then(@"Verify Member Information OEC Sales section ""(.*)"" Drop down is set to ""(.*)""")]
        public void ThenVerifyMemberInformationOECSalesSectionDropDownIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string Value = tmsCommon.GenerateData(p1);
            tmsWait.Hard(2);
            switch (field)
            {
                case "Sales Rep":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        tmsWait.Hard(3);

                        By Drp = By.XPath("//label[contains(.,'Sales Rep')]/parent::div//input");
                        string actualValue = Browser.Wd.FindElement(Drp).GetAttribute("value");
                        Assert.AreEqual(Value, actualValue, " Both values are not matching");
                    }
                    else
                    {

                        fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODOECSales.SalesRepDroDownlist);
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(Value, cfUIMODMemberCreation.UIMODOECSales.SalesRepDroDownlist);
                    }
                    break;
                case "Sales Date":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        tmsWait.Hard(3);

                        By Drp = By.XPath("//label[contains(.,'Sales Date')]/parent::div//input");
                        string actualValue = Browser.Wd.FindElement(Drp).GetAttribute("value");
                        Assert.AreEqual(Value, actualValue, " Both values are not matching");
                    }
                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementStringValue(Value, cfUIMODMemberCreation.UIMODOECSales.SalesDate);
                    }
                    break;
                case "Institution Address":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        tmsWait.Hard(3);

                        By Drp = By.XPath("//label[contains(.,'Institution Address')]/parent::div//input");
                        string actualValue = Browser.Wd.FindElement(Drp).GetAttribute("value");
                        Assert.AreEqual(Value, actualValue, " Both values are not matching");
                    }
                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(Value, cfUIMODMemberCreation.UIMODOECSales.InstitutionAddress);
                    }
                    break;
                case "Institution Phone":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        tmsWait.Hard(3);

                        By Drp = By.XPath("//label[contains(.,'Institution Phone')]/parent::div//input");
                        string actualValue = Browser.Wd.FindElement(Drp).GetAttribute("value");
                        Assert.AreEqual(Value, actualValue, " Both values are not matching");
                    }
                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(Value, cfUIMODMemberCreation.UIMODOECSales.InstitutionPhone);
                    }
                    break;
                case "Institution Name":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        tmsWait.Hard(3);

                        By Drp = By.XPath("//label[contains(.,'Institution Name')]/parent::div//input");
                        string actualValue = Browser.Wd.FindElement(Drp).GetAttribute("value");
                        Assert.AreEqual(Value, actualValue, " Both values are not matching");
                    }
                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(Value, cfUIMODMemberCreation.UIMODOECSales.InstitutionName);
                    }
                    break;
            }
        }

        [When(@"Member Information Low Income Subsidy Information details ""(.*)"" value is set to ""(.*)""")]
        public void WhenMemberInformationLowIncomeSubsidyInformationDetailsValueIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);

            switch (field)
            {
                case "Start Date":
                    //fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLISStartDate);
                    //ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLISStartDate, value);
                    IWebElement el = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='premiumLis-select-coPayCat']//span"));
                    el.SendKeys(Keys.Tab);
                    tmsWait.Hard(3);
                    IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='premiumLis-txt-startDate']//span[@role='button']"));
                    tmsWait.Hard(3);
                    AngularFunction.enterDate(ele, value);
                    break;
                case "End Date":
                    //fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLISEndDate);
                    //ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLISEndDate, value);
                    IWebElement ele1 = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='premiumLis-txt-endDate']//span[@role='button']"));
                    AngularFunction.enterDate(ele1, value);
                    tmsWait.Hard(3);
                    break;
            }
        }

        [Then(@"Verify Member Information Plan Defined Fields section ""(.*)"" drop down list is set to ""(.*)""")]
        public void ThenVerifyMemberInformationPlanDefinedFieldsSectionDropDownListIsSetTo(string p0, string p1)
        {


            string field = tmsCommon.GenerateData(p0);
            string Value = tmsCommon.GenerateData(p1);

            switch (field)
            {




                case "Group":
                  if (ConfigFile.tenantType.Equals("tmsx"))
                   {
                        By Drp = By.XPath("//label[text()='Group']/parent::div//span[@class='k-input']");
                        string actualValue = Browser.Wd.FindElement(Drp).Text;
                        Assert.AreEqual(Value, actualValue, " Both values are not matching");
                        //fw.ScrollWindowToViewElementUsingLocators(Drp);
                        //ReUsableFunctions.compareExpectedValueWithKendoDropDownValue(Value, Drp);


                   }
                    else
                    {
                        fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODPlanDefinedFields.GroupDropDownList);
                        ReUsableFunctions.compareExpectedValueWithKendoDropDownValue(Value, cfUIMODMemberCreation.UIMODPlanDefinedFields.GroupDropDownList);
                    }
                    break;
                case "Sub-Group":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[text()='Sub-Group']/parent::div//span[@class='k-input']");
                        string actualValue = Browser.Wd.FindElement(Drp).Text;
                        Assert.AreEqual(Value, actualValue, " Both values are not matching");
                    }
                    else
                    {
                        fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODPlanDefinedFields.SubGroupDropDownList);
                        ReUsableFunctions.compareExpectedValueWithKendoDropDownValue(Value, cfUIMODMemberCreation.UIMODPlanDefinedFields.SubGroupDropDownList);
                    }
                    break;
                case "Class":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[text()='Class']/parent::div//span[@class='k-input']");
                        string actualValue = Browser.Wd.FindElement(Drp).Text;
                        Assert.AreEqual(Value, actualValue, " Both values are not matching");
                    }
                    else
                    {
                        fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODPlanDefinedFields.ClassDropDownList);
                        ReUsableFunctions.compareExpectedValueWithKendoDropDownValue(Value, cfUIMODMemberCreation.UIMODPlanDefinedFields.ClassDropDownList);
                    }
                    break;


            }
        }


        [Then(@"Verify Member Information Plan Defined Fields section ""(.*)"" field is set to ""(.*)""")]
        public void ThenVerifyMemberInformationPlanDefinedFieldsSectionFieldIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string Value = tmsCommon.GenerateData(p1);

            switch (field)
            {
                case "Plan2":
                    fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODPlanDefinedFields.Plan2);
                    ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(Value, cfUIMODMemberCreation.UIMODPlanDefinedFields.Plan2);

                    break;
                case "Plan3":
                    fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODPlanDefinedFields.Plan3);
                    ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(Value, cfUIMODMemberCreation.UIMODPlanDefinedFields.Plan3);
                    break;
                case "Plan4":
                    fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODPlanDefinedFields.Plan4);
                    ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(Value, cfUIMODMemberCreation.UIMODPlanDefinedFields.Plan4);
                    break;
                case "Plan5":
                    fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODPlanDefinedFields.Plan5);
                    ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(Value, cfUIMODMemberCreation.UIMODPlanDefinedFields.Plan5);
                    break;
                case "Plan1":
                    fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODPlanDefinedFields.Plan1);
                    ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(Value, cfUIMODMemberCreation.UIMODPlanDefinedFields.Plan1);
                    break;


            }

        }


        [When(@"Member Information Low Income Subsidy Information details ""(.*)"" drop down list is set to ""(.*)""")]
        [Given(@"Member Information Low Income Subsidy Information details ""(.*)"" drop down list is set to ""(.*)""")]
        [Then(@"Member Information Low Income Subsidy Information details ""(.*)"" drop down list is set to ""(.*)""")]
        public void WhenMemberInformationLowIncomeSubsidyInformationDetailsDropDownListIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            tmsWait.Hard(4);
            DateTime dt;
            string day;
            switch (field)
            {
                case "LIS Level":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[text()='LIS Level']/parent::div//span[@class='k-select']");
                        //if (value.Equals("025") || value.Equals("050") || value.Equals("075"))
                        //{
                        //    value = value.TrimStart('0');
                        //}
                        //string strValue = value + "% subsidy level";
                        By typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        //tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                        tmsWait.Hard(3);

                    }

                    else
                    {
                        fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLISDropdownList);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLISDropdownList, value);
                    }
                    break;
                case "Co-Pay Cat":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[text()='Co-Pay Cat']/parent::div//span[@class='k-select']");

                        By typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        //tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                        tmsWait.Hard(1);
                        //IWebElement el = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='premiumLis-select-coPayCat']//span"));
                        //el.SendKeys(Keys.Tab);
                        //tmsWait.Hard(3);

                    }

                    else
                    {
                        fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODCopayCatDropdownList);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODCopayCatDropdownList, value);
                        cfUIMODMemberCreation.UIMODPremiumLIS.UIMODCopayCatDropdownList.SendKeys(Keys.Tab);
                    }
                    break;
                case "LIS Type":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'LIS Type')]/parent::div//span[@class='k-select']");

                        By typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        //tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                        tmsWait.Hard(3);
                    }
                    else
                    {
                        fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLISTypeDropdownList);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLISTypeDropdownList, value);
                    }
                    break;
                case "Start Date":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement el = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='premiumLis-select-coPayCat']//span"));
                        el.SendKeys(Keys.Tab);
                        tmsWait.Hard(3);
                        //IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='premiumLis-txt-startDate']//span[@role='button']"));
                        IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='premiumLis-txt-startDate']//input"));
                        string[] value1 = value.Split('/');
                        ele.SendKeys(value1[0]);
                        ele.SendKeys(value1[1]);
                        ele.SendKeys(value1[2]);
                        ele.SendKeys(Keys.Tab);
                        //ele.Clear();
                        //ele.SendKeys(value1);
                        tmsWait.Hard(3);
                        //AngularFunction.enterDate(ele, value);
                    }

                    else
                    {
                        fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLISStartDate);
                    tmsWait.Hard(2);
                    ReUsableFunctions.enterValueOnWebElementWithoutClear(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLISStartDate, value);
                    tmsWait.Hard(2);
                    cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLISStartDate.SendKeys(Keys.Tab);
                    }
                    //dt = Convert.ToDateTime(value);
                    //day = dt.Day.ToString();
                    //if (day != "1")
                    //{
                    //    cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLISStartDate.SendKeys(Keys.Enter);
                    //    Browser.Wd.SwitchTo().Alert().Accept();
                    //    tmsWait.Hard(1);
                    //    Browser.Wd.SwitchTo().DefaultContent();
                    //}
                    break;
                case "End Date":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        // IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='premiumLis-txt-endDate']//span[@role='button']"));
                        //string value1 = value.Replace("/", "");
                        //ele.Clear();
                        //ele.SendKeys(value1);
                        //IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='premiumLis-txt-startDate']//span[@role='button']"));
                        IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='premiumLis-txt-endDate']//input"));
                        string[] value1 = value.Split('/');
                        ele.SendKeys(value1[0]);
                        ele.SendKeys(value1[1]);
                        ele.SendKeys(value1[2]);
                        ele.SendKeys(Keys.Tab);
                        //ele.Clear();
                        //ele.SendKeys(value1);
                        tmsWait.Hard(3);
                        //AngularFunction.enterDate(ele, value);
                        tmsWait.Hard(3);
                    }

                    else
                    {
                        fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLISEndDate);
                    tmsWait.Hard(2);
                    ReUsableFunctions.enterValueOnWebElementWithoutClear(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLISEndDate, value);
                    tmsWait.Hard(2);
                    cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLISEndDate.SendKeys(Keys.Tab);
                    }
                    //ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLISEndDate, value);
                    //dt = Convert.ToDateTime(value);
                    //day = dt.Day.ToString();
                    //DateTime lastDay = new DateTime(dt.Year, dt.Month + 1, 1).AddDays(-1);
                    //if (day != lastDay.Day.ToString())
                    //{
                    //    Browser.Wd.SwitchTo().Alert().Accept();
                    //    tmsWait.Hard(1);
                    //    Browser.Wd.SwitchTo().DefaultContent();
                    //}
                    //cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLISEndDate.SendKeys(Keys.Tab);
                    break;
            }

            tmsWait.Hard(3);
        }

        [When(@"EAM Configuration page Edit LIS Information section Save Icon is clicked")]
        public void WhenEAMConfigurationPageEditLISInformationSectionSaveIconIsClicked()
        {
            IWebElement save = Browser.Wd.FindElement(By.XPath("//a[contains(@class,'update')]"));
            ReUsableFunctions.clickOnWebElement(save);

            try
            {
                UIMODUtilFunctions.clickOnConfirmationYesDialog();

            }
            catch
            {

            }

        }

        [When(@"Member Information LIS Information details ""(.*)"" drop down list is set to ""(.*)""")]
        public void WhenMemberInformationLISInformationDetailsDropDownListIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            tmsWait.Hard(4);
            bool alertPresent;
            // string day;
            switch (field)
            {
                case "LIS Level":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'LIS Level')]/parent::div//span[@class='k-select']");
                        //if (value.Equals("025") || value.Equals("050") || value.Equals("075"))
                        //{
                        //    value = value.TrimStart('0');
                        //}
                        //string strValue = value + "% subsidy level";
                        By typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        //tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                        tmsWait.Hard(3);

                    }

                    else
                    {
                        fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLISDropdownList);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLISDropdownList, value);
                    }
                    break;
                case "Co-Pay Cat":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'Co-Pay Cat')]/parent::div//span[@class='k-select']");

                        By typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        //tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                        tmsWait.Hard(1);
                       
                        tmsWait.Hard(3);

                    }

                    else
                    {
                        fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODCopayCatDropdownList);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODCopayCatDropdownList, value);
                    }
                    break;


                case "LIS Type":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'LIS Type')]/parent::div//span[@class='k-select']");

                        By typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        //tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                        tmsWait.Hard(3);
                    }
                    else
                    {
                        fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLISTypeDropdownList);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLISTypeDropdownList, value);
                    }

                    break;
                case "Start Date":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        //IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='premiumLis-txt-startDate']//span[@role='button']"));
                        //string value1 = value.Replace("/", "");
                        //ele.Clear();
                        //ele.SendKeys(value1);
                        //AngularFunction.enterDate(ele, value);
                        IWebElement el = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='premiumLis-select-coPayCat']//span"));
                        el.SendKeys(Keys.Tab);
                        tmsWait.Hard(3);
                        IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='premiumLis-txt-startDate']//input"));
                        string[] value1 = value.Split('/');
                        ele.SendKeys(value1[0]);
                        ele.SendKeys(value1[1]);
                        ele.SendKeys(value1[2]);
                        //ele.SendKeys(Keys.Tab);
                        tmsWait.Hard(3);
                    }

                    else
                    {
                        fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLISStartDate);
                        tmsWait.Hard(2);
                        ReUsableFunctions.enterValueOnWebElementWithoutClear(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLISStartDate, value);
                        tmsWait.Hard(2);
                        cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLISStartDate.SendKeys(Keys.Tab);
                        tmsWait.Hard(1);
                        alertPresent = IsAlertPresent();
                        if (alertPresent == true)
                        {
                            Browser.Wd.SwitchTo().Alert().Accept();
                            tmsWait.Hard(1);
                            Browser.Wd.SwitchTo().DefaultContent();
                        }
                        //dt = Convert.ToDateTime(value);
                        //day = dt.Day.ToString();
                        //if (day != "1")
                        //{
                        //    //cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLISStartDate.SendKeys(Keys.Enter);
                        //    Browser.Wd.SwitchTo().Alert().Accept();
                        //    tmsWait.Hard(1);
                        //    Browser.Wd.SwitchTo().DefaultContent();
                    }
                    break;
                case "End Date":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        //IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='premiumLis-txt-endDate']//span[@role='button']"));
                        //string value1 = value.Replace("/", "");
                        IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='premiumLis-txt-endDate']//input"));
                        ele.Clear();
                        //ele.SendKeys(value1);
                        IWebElement eles = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='premiumLis-txt-startDate']//input"));
                        eles.SendKeys(Keys.Tab);
                        tmsWait.Hard(1);
                        //IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='premiumLis-txt-endDate']//input"));
                        string[] value1 = value.Split('/');
                        ele.SendKeys(value1[0]);
                        ele.SendKeys(value1[1]);
                        ele.SendKeys(value1[2]);
                        ele.SendKeys(Keys.Tab);
                        tmsWait.Hard(1);
                        //AngularFunction.enterDate(ele, value);
                    }

                    else
                    {
                        fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLISEndDate);
                        tmsWait.Hard(1);
                        ReUsableFunctions.enterValueOnWebElementWithoutClear(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLISEndDate, value);
                        tmsWait.Hard(1);
                        //cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLISEndDate.SendKeys(Keys.Tab);

                        alertPresent = IsAlertPresent();
                        if (alertPresent == true)
                        {
                            Browser.Wd.SwitchTo().Alert().Accept();
                            tmsWait.Hard(1);
                            Browser.Wd.SwitchTo().DefaultContent();
                        }
                        cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLISEndDate.SendKeys(Keys.Tab);
                    }
                    break;
            }

            tmsWait.Hard(3);
        }

        public static bool IsAlertPresent()
        {
            try
            {
                Browser.Wd.SwitchTo().Alert();
                return true;
            }
            catch (NoAlertPresentException)
            {
                return false;
            }
        }

        [When(@"i press enter key")]
        [Then(@"i press enter key")]
        public void WhenIPressEnterKey()
        {
            IWebElement ele = cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLISStartDate;
            //ele.SendKeys(Keys.Enter);
            ele.SendKeys(Keys.Tab);

        }



        [When(@"Member Information Low Income Subsidy Information details Save Button is Clicked")]
        public void WhenMemberInformationLowIncomeSubsidyInformationDetailsSaveButtonIsClicked()
        {
        tmsWait.Hard(3);
         ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODLISSaveBtn);
         //tmsWait.Hard(2);
        }
        [When(@"Member ViewEdit page Attachment image is Clicked")]
        public void WhenMemberViewEditPageAttachmentImageIsClicked()
        {
            //fw.ExecuteJavascript();
        }

        [When(@"I closed Web Alert Message Popup")]
        public void WhenIClosedWebAlertMessagePopup()
        {
            Browser.ClosePopUps(true);
        }


        [Then(@"Verify Member information Low Income Subsidy information section displays LIS Level as ""(.*)"" CoPay Cat as ""(.*)"" Start Date ""(.*)"" End Date ""(.*)"" LIS Type as ""(.*)"" Source as ""(.*)""")]
        [Given(@"Verify Member information Low Income Subsidy information section displays LIS Level as ""(.*)"" CoPay Cat as ""(.*)"" Start Date ""(.*)"" End Date ""(.*)"" LIS Type as ""(.*)"" Source as ""(.*)""")]
        [When(@"Verify Member information Low Income Subsidy information section displays LIS Level as ""(.*)"" CoPay Cat as ""(.*)"" Start Date ""(.*)"" End Date ""(.*)"" LIS Type as ""(.*)"" Source as ""(.*)""")]
        public void ThenVerifyMemberInformationLowIncomeSubsidyInformationSectionDisplaysLISLevelAsCoPayCatAsStartDateEndDateLISTypeAsSourceAs(string lislevel, string copay, string startdate, string enddate, string listype, string source)
        {
            string LisLevel = tmsCommon.GenerateData(lislevel.ToString());
            string Copay = tmsCommon.GenerateData(copay);
            string StartDate = tmsCommon.GenerateData(startdate);
            string EndDate = tmsCommon.GenerateData(enddate);
            string LisType = tmsCommon.GenerateData(listype);
            string Source = tmsCommon.GenerateData(source);

            tmsWait.Hard(3);
            By lisTable;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                lisTable = By.XPath("//kendo-grid[@test-id='premiumLis-grid-lisDataGrid']//td[contains(.,'" + LisLevel + "')]/following-sibling::td[contains(.,'" + Copay + "')]/following-sibling::td[contains(.,'" + StartDate + "')]/following-sibling::td[contains(.,'" + EndDate + "')]/following-sibling::td[contains(.,'" + LisType + "')]/following-sibling::td[contains(.,'" + Source + "')]");
            }

            else
            {
                lisTable = By.XPath("//div[@test-id='premiumLis-grid-lisDataGrid']//td[contains(.,'" + LisLevel + "')]/following-sibling::td[contains(.,'" + Copay + "')]/following-sibling::td[contains(.,'" + StartDate + "')]/following-sibling::td[contains(.,'" + EndDate + "')]/following-sibling::td[contains(.,'" + LisType + "')]/following-sibling::td[contains(.,'" + Source + "')]");
            }
            UIMODUtilFunctions.elementPresenceUsingLocators(lisTable);
        }

        [Then(@"Verify Member information LIS information section displays LIS Level as ""(.*)"" CoPay Cat as ""(.*)"" Start Date ""(.*)"" End Date ""(.*)"" LIS Type as ""(.*)"" Source as ""(.*)"" Valid as ""(.*)"" current as ""(.*)""")]
        public void ThenVerifyMemberInformationLISInformationSectionDisplaysLISLevelAsCoPayCatAsStartDateEndDateLISTypeAsSourceAsValidAsCurrentAs(int lislevel, string copay, string startdate, string enddate, string listype, string source, string validText, string currentText)
        {
            string LisLevel = tmsCommon.GenerateData(lislevel.ToString());
            string Copay = tmsCommon.GenerateData(copay);
            string StartDate = tmsCommon.GenerateData(startdate);
            string EndDate = tmsCommon.GenerateData(enddate);
            string LisType = tmsCommon.GenerateData(listype);
            string Source = tmsCommon.GenerateData(source);
            string Valid = tmsCommon.GenerateData(validText);
            string Current = tmsCommon.GenerateData(currentText);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
              int  totalPagesIntheGrid = ReUsableFunctions.getTotalPages();

                string xpath = "//div[@role='presentation']//td[contains(.,'" + LisLevel + "')]/following-sibling::td[contains(.,'" + Copay + "')]/following-sibling::td[contains(.,'" + StartDate + "')]/following-sibling::td[contains(.,'" + EndDate + "')]/following-sibling::td[contains(.,'" + LisType + "')]/following-sibling::td[contains(.,'" + Source + "')]/following-sibling::td[contains(.,'" + validText + "')]/following-sibling::td[contains(.,'" + currentText + "')]";
               // ReUsableFunctions.clickOnGridElement(xpath);
                ReUsableFunctions.verifyGridElementPresence(xpath);

            }
            else
            {
            By lisTable = By.XPath("//div[@test-id='premiumLis-grid-lisDataGrid']//td[contains(.,'" + LisLevel + "')]/following-sibling::td[contains(.,'" + Copay + "')]/following-sibling::td[contains(.,'" + StartDate + "')]/following-sibling::td[contains(.,'" + EndDate + "')]/following-sibling::td[contains(.,'" + LisType + "')]/following-sibling::td[contains(.,'" + Source + "')]/following-sibling::td[contains(.,'" + validText + "')]/following-sibling::td[contains(.,'" + currentText + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(lisTable);
            }
        }



        [Then(@"Verify Members View Edit page LEP display with LEP Amount ""(.*)"" Start Date ""(.*)"" Source ""(.*)""")]
        public void ThenVerifyMembersViewEditPageLEPDisplayWithLEPAmountStartDateSource(Decimal p0, string p1, string p2)
        {
            string LEPAmount = tmsCommon.GenerateData(p0.ToString());
            string StartDate = tmsCommon.GenerateData(p1);
            string Source = tmsCommon.GenerateData(p2);

            By lisTable = By.XPath("//kendo-grid[@test-id='premiumLis-grid-lepDataGrid']//td[contains(.,'" + LEPAmount + "')]/parent::tr//td[contains(.,'" + StartDate + "')]/parent::tr//td[contains(.,'" + Source + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(lisTable);
        }

        [Then(@"Verify Members View Edit page LEP display row LEP Amount ""(.*)"" Start Date ""(.*)"" EndDate ""(.*)"" Source ""(.*)""")]
        public void ThenVerifyMembersViewEditPageLEPDisplayRowLEPAmountStartDateEndDateSource(Decimal p0, string p1, string p2, string p3)
        {
            string LEPAmount = tmsCommon.GenerateData(p0.ToString());
            string StartDate = tmsCommon.GenerateData(p1);
            string EndDate = tmsCommon.GenerateData(p2);
            string Source = tmsCommon.GenerateData(p3);

            By lisTable = By.XPath("//kendo-grid[@test-id='premiumLis-grid-lepDataGrid']//td[contains(.,'" + LEPAmount + "')]/parent::tr//td[contains(.,'" + StartDate + "')]/parent::tr//td[contains(.,'" + EndDate + "')]/parent::tr//td[contains(.,'" + Source + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(lisTable);
        }


        [Then(@"Verify View Edit Members page Part D Premium is displayed as addition of LEP amount and ""(.*)""")]
        public void ThenVerifyViewEditMembersPagePartDPremiumIsDisplayedAsAdditionOfLEPAmountAnd(string p0)
        {
            string pamt = tmsCommon.GenerateData(p0);
            decimal preAmt = decimal.Parse(pamt);
            string lAmt = Browser.Wd.FindElement(By.XPath("//input[@test-id='premiumLis-input-lepAmt']")).GetAttribute("value");
            decimal lepAmt = decimal.Parse(lAmt);
            decimal expected_PartD_Prem = preAmt + lepAmt;
            string Actual_PartDPrem = Browser.Wd.FindElement(By.XPath("//input[@test-id='premiumLis-input-partDPremium']")).GetAttribute("value");
            Assert.IsTrue(Actual_PartDPrem.Contains(expected_PartD_Prem.ToString()), " Premium amount does not match");
        }


        [Then(@"Verify View Edit Members page LEP amount is displayed ""(.*)""")]
        public void ThenVerifyViewEditMembersPagePartDPremiumIsDisplayed(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            string lAmt = Browser.Wd.FindElement(By.XPath("//input[@test-id='premiumLis-input-lepAmt']")).GetAttribute("value");
            decimal lepAmt = decimal.Parse(lAmt);
            string lepAmount = Convert.ToInt32(lepAmt).ToString();
            Assert.AreEqual(value, lepAmount, " Values do not match");
        }




        [When(@"View Edit Members page LEP section ""(.*)"" is set to ""(.*)""")]
        public void WhenViewEditMembersPageLEPSectionIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1.ToString());

            switch (field.ToLower())
            {
                case "lep amount":
                    IWebElement lepAmount = Browser.Wd.FindElement(By.XPath("//input[@test-id='premiumLis-input-addLepAmt']"));
                    lepAmount.SendKeys(value); break;

                case "lep startdate":
                    IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='premiumLis-txt-lepStartDate']//input"));
                    //AngularFunction.enterDate(ele, value);
                    //IWebElement lepSDate = Browser.Wd.FindElement(By.XPath("//input[@test-id='premiumLis-txt-lepStartDate']"));
                    //lepSDate.Clear();
                    //lepSDate.SendKeys(value);
                    //lepSDate.SendKeys(Keys.Tab); 
                    IWebElement lepA = Browser.Wd.FindElement(By.XPath("//input[@test-id='premiumLis-input-addLepAmt']"));
                    lepA.SendKeys(Keys.Tab);
                    string[] value1 = value.Split('/');
                    ele.SendKeys(value1[0]);
                    ele.SendKeys(value1[1]);
                    ele.SendKeys(value1[2]);
                    ele.SendKeys(Keys.Tab);
                    break;
            }

        }

        [When(@"View Edit Members page LEP Save button is clicked")]
        public void WhenViewEditMembersPageLEPSaveButtonIsClicked()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='premiumLis-btn-saveLepAmount']")));
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")));
            tmsWait.Hard(2);

        }

        [When(@"View Edit Members page LEP Save button is clicked and Verify Message ""(.*)""")]
        public void WhenViewEditMembersPageLEPSaveButtonIsClickedAndVerifyMessage(string p0)
        {
            string expected_Message = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='premiumLis-btn-saveLepAmount']")));
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")));
            tmsWait.Hard(1);
            //Commenting as failing to read toaster message 
            //string actualMessage = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
            //By toastMsg = By.XPath("//div[@class='k-notification-content']");
            //string actualMessage = Browser.Wd.FindElement(toastMsg).Text;
            //Assert.IsTrue(actualMessage.Contains(expected_Message));
        }


        [When(@"View Edit Members page LEP Save button without Popup is clicked and Verify Message ""(.*)""")]
        public void WhenViewEditMembersPageLEPSaveButtonWithoutPopupIsClickedAndVerifyMessage(string p0)
        {
            string expected_Message = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='premiumLis-btn-saveLepAmount']")));
            tmsWait.Hard(1);
            string actualMessage = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
            Assert.IsTrue(actualMessage.Contains(expected_Message));
        }


        [When(@"View Edit Members page LEP Valid Filter is Cleared")]
        public void WhenViewEditMembersPageLEPValidFilterIsCleared()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='premiumLis-grid-lepDataGrid']//kendo-grid-filter-menu/a[@title='Filter']")));
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[contains(.,'Clear')]")));
            tmsWait.Hard(2);
        }



        [Then(@"Verify Member information LIS information section displays Source as ""(.*)""")]
        public void ThenVerifyMemberInformationLISInformationSectionDisplaysSourceAs(string source)
        {
            string Source = tmsCommon.GenerateData(source);
            By lisTable = By.XPath("//div[@test-id='premiumLis-grid-lisDataGrid']//td[contains(.,'" + source + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(lisTable);

        }



        [Then(@"Verify Member info Low Income Subsidy information section displays LIS Level as ""(.*)"" CoPay Cat as ""(.*)"" Start Date ""(.*)"" End Date ""(.*)"" Source as ""(.*)""")]
        public void ThenVerifyMemberInfoLowIncomeSubsidyInformationSectionDisplaysLISLevelAsCoPayCatAsStartDateEndDateSourceAs(int lislevel, string copay, string startdate, string enddate, string source)
        {
            string LisLevel = tmsCommon.GenerateData(lislevel.ToString());
            string Copay = tmsCommon.GenerateData(copay);
            string StartDate = tmsCommon.GenerateData(startdate);
            string EndDate = tmsCommon.GenerateData(enddate);
            string Source = tmsCommon.GenerateData(source);
           
                By lisTable = By.XPath("//kendo-grid[@test-id='premiumLis-grid-lisDataGrid']//td[contains(.,'" + LisLevel + "')]/following-sibling::td[contains(.,'" + Copay + "')]/following-sibling::td[contains(.,'" + StartDate + "')]/following-sibling::td[contains(.,'" + EndDate + "')]/following-sibling::td[contains(.,'" + Source + "')]");
                UIMODUtilFunctions.elementPresenceUsingLocators(lisTable);
            
        }


        [When(@"Verify Member Information TRR Details TC as ""(.*)"" PlanID as ""(.*)"" TRC as ""(.*)"" PBP as ""(.*)""  Effective Date as ""(.*)""  TRR as  ""(.*)"" TRC Name as ""(.*)""")]

        [Then(@"Verify Member Information TRR Details TC as ""(.*)"" PlanID as ""(.*)"" TRC as ""(.*)"" PBP as ""(.*)""  Effective Date as ""(.*)""  TRR as  ""(.*)"" TRC Name as ""(.*)""")]
        public void ThenVerifyMemberInformationTRRDetailsTCAsPlanIDAsTRCAsPBPAsEffectiveDateAsTRRAsTRCNameAs(string tc, string plan, string trc, string pbp, string effective, string trrdate, string trcName)
        {
            string TransCode = tmsCommon.GenerateData(tc);
            string plan1 = tmsCommon.GenerateData(plan);
            string trc1 = tmsCommon.GenerateData(trc);
            string pbp1 = tmsCommon.GenerateData(pbp);
            string eff = tmsCommon.GenerateData(effective);
            string TRRDate = tmsCommon.GenerateData(trrdate);

            string TRCName = tmsCommon.GenerateData(trcName);
            //div[@test-id='trrView-grid-trrViewGrid']//td/span[contains(.,'"+TransCode+"')]/parent::td//following-sibling::td/span[contains(.,'"+plan1+"')]/parent::td//following-sibling::td/span[contains(.,'+"trc1+"')]/parent::td//following-sibling::td/span[contains(.,'"+pbp1+"')]/parent::td/following-sibling::td[contains(.,'"+eff+"')]/following-sibling::td[contains(.,'"+TRRDate+"')]//following-sibling::td/span[contains(.,'"+TRCName+"')]
            By trrTable = By.XPath("//div[@test-id='trrView-grid-trrViewGrid']//td/span[contains(.,'" + TransCode + "')]/parent::td//following-sibling::td/span[contains(.,'" + plan1 + "')]/parent::td//following-sibling::td/span[contains(.,'" + trc1 + "')]/parent::td//following-sibling::td/span[contains(.,'" + pbp1 + "')]/parent::td/following-sibling::td[contains(.,'" + eff + "')]/following-sibling::td[contains(.,'" + TRRDate + "')]//following-sibling::td/span[contains(.,'" + TRCName + "')]");
            //fw.ScrollWindowToViewElementUsingLocators(trrTable);
            UIMODUtilFunctions.elementPresenceUsingLocators(trrTable);
        }

        [Then(@"Verify Member Information Transactions Details TC as ""(.*)"" Effective Date as ""(.*)"" Plan ID as ""(.*)"" PBP as ""(.*)""  Election Type as ""(.*)"" TRR Date as ""(.*)"" TRC as ""(.*)"" TRC Name as ""(.*)"" TransStatus as ""(.*)"" Program Source as ""(.*)""")]
        public void ThenVerifyMemberInformationTransactionsDetailsTCAsEffectiveDateAsPlanIDAsPBPAsElectionTypeAsTRRDateAsTRCAsTRCNameAsTransStatusAsProgramSourceAs(string TC, string EffDate, string plan, string pbp, string election, string trrdate, string trc, string trcname, string transstatus, string source)
        {

            string TransCode = tmsCommon.GenerateData(TC);
            string EffectiveDate = tmsCommon.GenerateData(EffDate);
            string PlanID = tmsCommon.GenerateData(plan);
            string PBPID = tmsCommon.GenerateData(pbp);
            string ElectionType = tmsCommon.GenerateData(election);
            string TRRDate = tmsCommon.GenerateData(trrdate);
            string TRC = tmsCommon.GenerateData(trc);
            string TRCName = tmsCommon.GenerateData(trcname);
            string TransctionStaus = tmsCommon.GenerateData(transstatus);
            string ProgramSource = tmsCommon.GenerateData(source);
            By trrTable;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                trrTable = By.XPath("//kendo-grid-list[@role='presentation']//td[contains(.,'" + TransCode + "')]/following-sibling::td[contains(.,'" + EffectiveDate + "')]/following-sibling::td[contains(.,'" + PlanID + "')]/following-sibling::td[contains(.,'"+PBPID+"')]/following-sibling::td[contains(.,'" + ElectionType + "')]/following-sibling::td[contains(.,'" + TRRDate + "')]/following-sibling::td[contains(.,'" + TRC + "')]/following-sibling::td[contains(.,'" + TRCName + "')]/following-sibling::td[contains(.,'" + TransctionStaus + "')]/following-sibling::td[contains(.,'" + ProgramSource + "')]");
                UIMODUtilFunctions.elementPresenceUsingLocators(trrTable);
            }
            else
            {

                 trrTable = By.XPath("//div[@test-id='transactions-grid-memberTransactionsGrid']//td/span[contains(.,'" + TransCode + "')]/parent::td//following-sibling::td/span[contains(.,'" + TransctionStaus + "')]");
                //fw.ScrollWindowToViewElementUsingLocators(trrTable);
                UIMODUtilFunctions.elementPresenceUsingLocators(trrTable);
            }

        }

        //Gurdeep Arora
        [Then(@"Verify Member has TC as ""(.*)"" and TransStatus as ""(.*)""")]
        public void ThenVerifyMemberHasTCAsAndTransStatusAs(string TC, string transstatus)
        {
            string TransCode = tmsCommon.GenerateData(TC);
            string TransctionStaus = tmsCommon.GenerateData(transstatus);
            By trrTable = By.XPath("//div[@test-id='transactions-grid-memberTransactionsGrid']//td/span[contains(.,'" + TransCode + "')]/parent::td//following-sibling::td/span[contains(.,'" + TransctionStaus + "')]");
            //fw.ScrollWindowToViewElementUsingLocators(trrTable);
            UIMODUtilFunctions.elementPresenceUsingLocators(trrTable);
        }




        [Then(@"Verify Member Information Transactions Details second row TC as ""(.*)"" Effective Date as ""(.*)"" Plan ID as ""(.*)"" PBP as ""(.*)""  Election Type as ""(.*)"" TRR Date as ""(.*)"" TRC as ""(.*)"" TRC Name as ""(.*)"" TransStatus as ""(.*)"" Program Source as ""(.*)""")]
        public void ThenVerifyMemberInformationTransactionsDetailsSecondRowTCAsEffectiveDateAsPlanIDAsPBPAsElectionTypeAsTRRDateAsTRCAsTRCNameAsTransStatusAsProgramSourceAs(string TC, string EffDate, string plan, string pbp, string election, string trrdate, string trc, string trcname, string transstatus, string source)
        {


            string TransCode = tmsCommon.GenerateData(TC);
            string EffectiveDate = tmsCommon.GenerateData(EffDate);
            string PlanID = tmsCommon.GenerateData(plan);
            string PBPID = tmsCommon.GenerateData(pbp);
            string ElectionType = tmsCommon.GenerateData(election);
            string TRRDate = tmsCommon.GenerateData(trrdate);
            string TRC = tmsCommon.GenerateData(trc);
            string TRCName = tmsCommon.GenerateData(trcname);
            string TransctionStaus = tmsCommon.GenerateData(transstatus);
            //  string ProgramSource = tmsCommon.GenerateData(source);

            By trrTable = By.XPath("(//div[@test-id='transactions-grid-memberTransactionsGrid']//td/span[contains(.,'" + TransCode + "')]/parent::td//following-sibling::td/span[contains(.,'" + TransctionStaus + "')])[2]");
            //fw.ScrollWindowToViewElementUsingLocators(trrTable);
            UIMODUtilFunctions.elementPresenceUsingLocators(trrTable);
        }
        [Then(@"Verify Member Information Transactions Details third row TC as ""(.*)"" Effective Date as ""(.*)""  Plan ID as ""(.*)"" PBP as ""(.*)""  Election Type as ""(.*)"" TRR Date as ""(.*)"" TRC as ""(.*)"" TRC Name as ""(.*)"" TransStatus as ""(.*)"" Program Source as ""(.*)""")]
        public void ThenVerifyMemberInformationTransactionsDetailsThirdRowTCAsEffectiveDateAsPlanIDAsPBPAsElectionTypeAsTRRDateAsTRCAsTRCNameAsTransStatusAsProgramSourceAs(string TC, string EffDate, string plan, string pbp, string election, string trrdate, string trc, string trcname, string transstatus, string source)
        {

            string TransCode = tmsCommon.GenerateData(TC);
            string EffectiveDate = tmsCommon.GenerateData(EffDate);
            string PlanID = tmsCommon.GenerateData(plan);
            string PBPID = tmsCommon.GenerateData(pbp);
            string ElectionType = tmsCommon.GenerateData(election);
            string TRRDate = tmsCommon.GenerateData(trrdate);
            string TRC = tmsCommon.GenerateData(trc);
            string TRCName = tmsCommon.GenerateData(trcname);
            string TransctionStaus = tmsCommon.GenerateData(transstatus);
            //  string ProgramSource = tmsCommon.GenerateData(source);

            By trrTable = By.XPath("(//div[@test-id='transactions-grid-memberTransactionsGrid']//td/span[contains(.,'" + TransCode + "')]/parent::td//following-sibling::td/span[contains(.,'" + TransctionStaus + "')])[3]");
            //fw.ScrollWindowToViewElementUsingLocators(trrTable);
            UIMODUtilFunctions.elementPresenceUsingLocators(trrTable);
        }

        [Then(@"Verify Member Information Transactions Details ""(.*)"" TC as ""(.*)"" Effective Date as """"(.*)"""" PBP as ""(.*)""  Election Type as ""(.*)"" TRR Date as """"(.*)"" ""(.*)"" ""(.*)""Accepted By CMS""(.*)""DataEntry""")]
        public void ThenVerifyMemberInformationTransactionsDetailsTCAsEffectiveDateAsPBPAsElectionTypeAsTRRDateAsAcceptedByCMSDataEntry(int p0, string TC, string EffDate, string plan, string pbp, string election, string trrdate, string trc, string trcname, string transstatus)
        {
            string TransCode = tmsCommon.GenerateData(TC);
            string EffectiveDate = tmsCommon.GenerateData(EffDate);
            string PlanID = tmsCommon.GenerateData(plan);
            string PBPID = tmsCommon.GenerateData(pbp);
            string ElectionType = tmsCommon.GenerateData(election);
            string TRRDate = tmsCommon.GenerateData(trrdate);
            string TRC = tmsCommon.GenerateData(trc);
            string TRCName = tmsCommon.GenerateData(trcname);
            string TransctionStaus = tmsCommon.GenerateData(transstatus);
            //  string ProgramSource = tmsCommon.GenerateData(source);

            By trrTable = By.XPath("(//div[@test-id='transactions-grid-memberTransactionsGrid']//td/span[contains(.,'" + TransCode + "')]/parent::td//following-sibling::td/span[contains(.,'" + TransctionStaus + "')])[2]");
            //fw.ScrollWindowToViewElementUsingLocators(trrTable);
            UIMODUtilFunctions.elementPresenceUsingLocators(trrTable);
        }


        [Then(@"I have Clicked on Transaction Expand All Button")]
        public void ThenIHaveClickedOnTransactionExpandAllButton()
        {
            IWebElement expandbutton = Browser.Wd.FindElement(By.XPath("//button[@test-id='transaction-btn-expandAndCollapse']"));
            fw.ExecuteJavascript(expandbutton);
            tmsWait.Hard(5);
        }


        [Then(@"Verify Member Information Transaction Details TC ""(.*)"" is not exist")]
        public void ThenVerifyMemberInformationTransactionDetailsTCIsNotExist(string p0)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {

                By loc = By.XPath("//div[@id='searchMemberGridSection']//table//td[@aria-colindex='2'][contains(.,'"+ p0 + "')]");
                try
                {
                    fw.ScrollWindowToViewElementUsingLocators(loc);
                    IWebElement ele = Browser.Wd.FindElement(loc);
                    bool presence = ele.Displayed;
                    Assert.IsFalse(presence, "Transaction " + p0 + " is Exist Which should not be");
                }

                catch
                {
                    Console.WriteLine("Transaction " + p0 + " is Not Exist which is expected");
                }
            }
            else
            {
                By loc = By.XPath("//div[@id='memberTransactionsGrid']//td/span[contains(.,'" + p0 + "')]");
                try
                {
                    fw.ScrollWindowToViewElementUsingLocators(loc);
                    IWebElement ele = Browser.Wd.FindElement(loc);
                    bool presence = ele.Displayed;
                    Assert.IsFalse(presence, "Transaction " + p0 + " is Exist Which should not be");
                }

                catch
                {
                    Console.WriteLine("Transaction " + p0 + " is Not Exist which is expected");
                }
            }
        }


        [When(@"Premium/LIS Next Section link is clicked")]
        public void WhenPremiumLISNextSectionLinkIsClicked()
        {
            fw.ScrollWindowToViewElement(Browser.Wd.FindElement(By.XPath("//i[@test-id='memberPremiumLisInfo-info-showPremiumLis']")));
            IWebElement link = Browser.Wd.FindElement(By.XPath("//i[@test-id='memberPremiumLisInfo-info-showPremiumLis']"));
            fw.ExecuteJavascript(link);
            tmsWait.Hard(2);
        }

        [When(@"OEC/Sales Next Section link is clicked")]
        public void WhenOECSalesNextSectionLinkIsClicked()
        {
            tmsWait.Hard(2);
            IWebElement link = Browser.Wd.FindElement(By.XPath("//*[@test-id='memberOecSales-lbl-nextSection']"));
            fw.ExecuteJavascript(link);
            tmsWait.Hard(2);
        }


        [When(@"Add New Member page Plan Defined Fields Details section Send Plan (.*) on Legacy checkbox is ""(.*)""")]
        public void WhenAddNewMemberPagePlanDefinedFieldsDetailsSectionSendPlanOnLegacyCheckboxIs(string p0, string p1)
        {
            ReUsableFunctions.CheckBoxOperations(cfUIMODMemberCreation.UIMODPlanDefinedFields.SendPlan10OnLegacyCheckbox, p1);
        }

        [When(@"Add New Member page Premium LIS details Section Plus Symbol is Clicked")]
        public void WhenAddNewMemberPagePremiumLISDetailsSectionPlusSymbolIsClicked()
        {
            fw.ScrollWindowToViewElement(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODEmployerPlusSymbol);
            ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODEmployerPlusSymbol);
        }

        [When(@"Add New Member page Premium LIS details Employer Group Dialog ""(.*)"" is set to ""(.*)""")]
        public void WhenAddNewMemberPagePremiumLISDetailsEmployerGroupDialogIsSetTo(string p0, string p1)
        {

            string field = tmsCommon.GenerateData(p0);
            string Value = tmsCommon.GenerateData(p1);

            switch (field)
            {
                case "Employer Group Number":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODEmpDialogEmployerGroupNumber, Value);
                    break;
                case "Employer Name":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODEmpDialogEmployerName, Value);
                    break;
            }
        }

        [When(@"Add New Member page Premium LIS details Employer Group Dialog Save buttion is Clicked")]
        public void WhenAddNewMemberPagePremiumLISDetailsEmployerGroupDialogSaveButtionIsClicked()
        {
            ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODPremiumLIS.UIMODEmpDialogSave);
        }
        [Then(@"I have Clicked on Letter status Filter for ""(.*)""")]
        public void ThenIHaveClickedOnLetterStatusFilterFor(string p0)
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@id='correspondenceHistoryGrid']//a[@title='Filter']")));

            tmsWait.Hard(2);

            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//form[@title='Show items with value that:']//span[@title='Value']")));

            tmsWait.Hard(2);

            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[contains(.,'Show items with value that:')]//ul/li[.='Letter Queued']")));
            tmsWait.Hard(2);
            // fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[contains(.,'Filter')]")));
            tmsWait.Hard(2);
        }

        [When(@"Verify Member Information Correspondence History Details Letter Name as ""(.*)"" Letter Type as ""(.*)"" Letter Status as ""(.*)""")]
        [Then(@"Verify Member Information Correspondence History Details Letter Name as ""(.*)"" Letter Type as ""(.*)"" Letter Status as ""(.*)""")]
        public void ThenVerifyMemberInformationCorrespondenceHistoryDetailsLetterNameAsLetterTypeAsLetterStatusAs(string p0, string p1, string p2)
        {
            string LetterName = tmsCommon.GenerateData(p0);
            string LetterType = tmsCommon.GenerateData(p1);
            string LetterStatus = tmsCommon.GenerateData(p2);

            tmsWait.Hard(2);
            By correspondenceDisplay = By.XPath("//kendo-grid[@test-id='correspondence-grid-correspondenceHistory']//td[contains(.,'" + LetterName + "')]/following-sibling::td[contains(.,'" + LetterType + "')]/following-sibling::td[contains(.,'" + LetterStatus + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(correspondenceDisplay);
        }

        [When(@"Member Information Correspondence section Review link is clicked")]
        public void WhenMemberInformationCorrespondenceSectionReviewLinkIsClicked()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@class='text-secondary cursorLink']")));
            tmsWait.Hard(2);
        }



        [Then(@"Verify Member Information Eligibility section ""(.*)"" is displayed as ""(.*)""")]
        public void ThenVerifyMemberInformationEligibilitySectionIsDisplayedAs(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string expectedValue = tmsCommon.GenerateData(p1);

            switch (field)
            {
                case "Plan Part A Eff":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='eligibility-txt-planPartAEffDate']//span/input"));
                        string value1 = ele.GetAttribute("value");
                        if (expectedValue == "")
                        {
                            Assert.IsTrue(value1.Contains("month/day/year"));
                        }
                    }
                    else
                    {
                        tmsWait.Hard(3);
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODEligibility.UIMODPlanPartAEffectiveDate);
                    }
                    break;
                case "Plan Part B Eff":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='eligibility-txt-planPartBEffDate']//span/input"));
                        string value1 = ele.GetAttribute("value");
                        if (expectedValue == "")
                        {
                            Assert.IsTrue(value1.Contains("month/day/year"));
                        }
                    }
                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODEligibility.UIMODPlanPartBEffectiveDate);
                    }

                    break;
                case "Plan Part D Eff":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='eligibility-txt-planPartDEffDate']//span/input"));
                        string value1 = ele.GetAttribute("value");
                        if (expectedValue == "")
                        {
                            Assert.IsTrue(value1.Contains("month/day/year"));
                        }
                    }
                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODEligibility.UIMODPlanPartDEffectiveDate);
                    }

                    break;

                case "County Code":

                    ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfUIMODMemberCreation.UIMODEligibility.UIMODCountyCode);
                    break;
                case "State Code":

                    ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfUIMODMemberCreation.UIMODEligibility.UIMODStateCode);
                    break;
                case "ESRD":

                    ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfUIMODMemberCreation.UIMODEligibility.ESRD);
                    break;
            }
        }

        [Then(@"Verify View Edit Members page ""(.*)"" button is not displayed successfully")]
        public void ThenVerifyViewEditMembersPageButtonIsNotDisplayedSuccessfully(string p0)
        {
            string fieldName = tmsCommon.GenerateData(p0);


            switch (fieldName)
            {
                case "View Notes":
                    UIMODUtilFunctions.elementisNotPresentUsingWebElement(cfUIMODMemberCreation.UIMODMemberCreation.ViewNotesIcon);
                    break;
                case "View OOA":
                    UIMODUtilFunctions.elementisNotPresentUsingWebElement(cfUIMODMemberCreation.UIMODMemberCreation.ViewOOAIcon);
                    break;
                case "View Attachments":
                    UIMODUtilFunctions.elementisNotPresentUsingWebElement(cfUIMODMemberCreation.UIMODMemberCreation.ViewAttachmentsIcon);
                    break;
                case "View SNP":

                    UIMODUtilFunctions.elementNotPresenceUsingLocators(cfUIMODMemberCreation.UIMODMemberCreation.ViewSNPIconLoc);
                    break;
                case "Audit History":
                    UIMODUtilFunctions.elementNotPresenceUsingLocators(cfUIMODMemberCreation.UIMODMemberCreation.ViewAuditHistoryIconLoc);
                    break;
            }
        }


        [Then(@"Verify View Edit Members page ""(.*)"" button is displayed successfully")]
        public void ThenVerifyViewEditMembersPageButtonIsDisplayedSuccessfully(string p0)
        {

            string fieldName = tmsCommon.GenerateData(p0);


            switch (fieldName)
            {
                case "View Notes":
                    UIMODUtilFunctions.elementPresenceUsingWebElement(cfUIMODMemberCreation.UIMODMemberCreation.ViewNotesIcon);
                    break;
                case "View OOA":
                    UIMODUtilFunctions.elementPresenceUsingWebElement(cfUIMODMemberCreation.UIMODMemberCreation.ViewOOAIcon);
                    break;
                case "View Attachments":
                    UIMODUtilFunctions.elementPresenceUsingWebElement(cfUIMODMemberCreation.UIMODMemberCreation.ViewAttachmentsIcon);
                    break;
                case "View SNP":
                    UIMODUtilFunctions.elementPresenceUsingWebElement(cfUIMODMemberCreation.UIMODMemberCreation.ViewSNPIcon);
                    break;
                case "Audit History":
                    UIMODUtilFunctions.elementPresenceUsingWebElement(cfUIMODMemberCreation.UIMODMemberCreation.ViewAuditHistoryIcon);
                    break;
            }

        }
        [Then(@"Verify SNP Status '(.*)' '(.*)' and '(.*)' options are displayed")]
        public void ThenVerifySNPStatusAndOptionsAreDisplayed(string p0, string p1, string p2)
        {
            String[] status = { p0, p1, p2 };
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement SNPStatus = Browser.Wd.FindElement(By.XPath("//label[contains(.,'SNP Status')]/parent::div//span[@class='k-select']"));

                UIMODUtilFunctions.clickOnWebElementUsingLocators(SNPStatus);
                tmsWait.Hard(3);
                IList <IWebElement> SNPStatusoptions = Browser.Wd.FindElements(By.XPath("//kendo-list//li"));
                Assert.AreEqual(status.Length, SNPStatusoptions.Count);
            }
            else { 
              
            IWebElement SNPStatus = Browser.Wd.FindElement(By.XPath("//select[@test-id='snp-select-snpStatus']")); ;
            SelectElement select = new SelectElement(SNPStatus);
            IList<IWebElement> options = select.Options;

            // int len = status.GetUpperBound(0);

            Assert.AreEqual(status.Length, options.Count);
            //for (int i = 0; i < options.Count; i++)
            //{

            //    string y = status[i];
            //    select.SelectByValue(y);
            //    string x = options[1].Text;
            //    Assert.AreEqual(status[i], options[i].Text);
            }
        }

        [Then(@"Verify View Edit Members page ""(.*)"" button is clicked")]
        public void ThenVerifyViewEditMembersPageButtonIsClicked(string p0)
        {
            string fieldName = tmsCommon.GenerateData(p0);


            switch (fieldName)
            {

                case "Add SNP suspect":
                    tmsWait.Hard(3);
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        cfUIMODMemberCreation.UIMODMemberCreation.addSuspectAngJS.Click();
                    }
                    else
                    {
                        cfUIMODMemberCreation.UIMODMemberCreation.addSuspect.Click();
                    }
                    break;
                case "View SNP":
                    tmsWait.Hard(3);
                    cfUIMODMemberCreation.UIMODMemberCreation.ViewSNPIcon.Click(); ;
                    break;

            }
        }


        [Then(@"Verify Member Information Demographics section ""(.*)"" is displayed as ""(.*)""")]
        public void ThenVerifyMemberInformationDemographicsSectionIsDisplayedAs(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string expectedValue = tmsCommon.GenerateData(p1);
            tmsWait.Hard(3);
            switch (field)
            {
                case "Appel":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ddele = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Appel')]/parent::div/input"));
                        string actual_value = ddele.GetAttribute("value");
                        Assert.IsTrue(actual_value.Contains(expectedValue), "Value does not match");
                    }

                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfUIMODMemberCreation.UIMODMemDemographics.UIMODAppel);

                    }
                    break;

                case "DOB":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='memberDemographics-txt-dob']//span/input"));
                        string actualValue = ele.GetAttribute("value");
                        if(expectedValue=="")
                        {
                            Assert.IsTrue(actualValue.Contains("MM/dd/yyyy"), "Value does not match");
                        }
                        else
                        {
                            Assert.IsTrue(actualValue.Contains(expectedValue), "Value does not match");
                        }
                        tmsWait.Hard(3);
                    }

                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemDemographics.UIMODDOB);
                    }
                    break;

                case "Sex":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ddele = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Gender')]/parent::div//span[@class='k-input']"));
                        string actual_value = ddele.Text;
                        Assert.IsTrue(actual_value.Contains(expectedValue), "Value does not match");
                    }

                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfUIMODMemberCreation.UIMODMemDemographics.UIMODSexDropDownList);
                    }
                    break;

                case "SSN":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ddele = Browser.Wd.FindElement(By.XPath("//label[contains(.,'SSN')]/parent::div/input"));
                        string actual_value = ddele.GetAttribute("value");
                        Assert.IsTrue(actual_value.Contains(expectedValue), "Value does not match");
                    }

                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemDemographics.UIMODSSN);

                    }
                    break;

                case "MaritalStatus":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ddele = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Marital Status')]/parent::div//span[@class='k-input']"));
                        string actual_value = ddele.Text;
                        Assert.IsTrue(actual_value.Contains(expectedValue), "Value does not match");
                    }

                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfUIMODMemberCreation.UIMODMemDemographics.UIMODMaritalStatusDropDownList);
                    }
                    break;
                case "Language":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ddele = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Language')]/parent::div//span[@class='k-input']"));
                        string actual_value = ddele.Text;
                        Assert.IsTrue(actual_value.Contains(expectedValue), "Value does not match");
                    }

                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfUIMODMemberCreation.UIMODMemDemographics.UIMODLanguageDropdownlist);
                    }
                    break;
                case "Race":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ddele = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Race')]/parent::div//span[@class='k-input']"));
                        string actual_value = ddele.Text;
                        Assert.IsTrue(actual_value.Contains(expectedValue), "Value does not match");
                    }

                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfUIMODMemberCreation.UIMODMemDemographics.UIMODRaceDropdownlist);
                    }
                    break;

                case "DOD":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='memberDemographics-txt-dod']//span/input"));
                        string actualValue = ele.GetAttribute("value");
                        if (expectedValue == "")
                        {
                            Assert.IsTrue(actualValue.Contains("MM/dd/yyyy"), "Value does not match");
                        }
                        else
                        {
                            Assert.IsTrue(actualValue.Contains(expectedValue), "Value does not match");
                        }
                        tmsWait.Hard(3);
                    }

                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemDemographics.UIMODDOD);
                    }
                    break;
                case "PlanID":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ddele = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Plan ID')]/parent::div//span[@class='k-input']"));
                        string actual_value = ddele.Text;
                        Assert.IsTrue(actual_value.Contains(expectedValue), "Value does not match");
                    }

                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfUIMODMemberCreation.UIMODMemDemographics.UIMODPlanIdDropdownlist);
                    }
                    break;

                case "PBP":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ddele = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Plan ID')]/parent::div//span[@class='k-input']"));
                        string actual_value = ddele.Text;
                        Assert.IsTrue(actual_value.Contains(expectedValue), "Value does not match");
                    }

                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfUIMODMemberCreation.UIMODMemDemographics.UIMODPBPDropdownlist);
                    }
                    break;
                case "SegmentID":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ddele = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Segment ID')]/parent::div//span[@class='k-input']"));
                        string actual_value = ddele.Text;
                        Assert.IsTrue(actual_value.Contains(expectedValue), "Value does not match");
                    }

                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfUIMODMemberCreation.UIMODMemDemographics.UIMODSegmentIDPDropdownlist);
                    }
                    break;
                case "EffectiveDate":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='memberDemographics-txt-effectiveDate']//span/input"));
                        string actualValue = ele.GetAttribute("value");
                        if (expectedValue == "")
                        {
                            Assert.IsTrue(actualValue.Contains("MM/dd/yyyy"), "Value does not match");
                        }
                        else
                        {
                            Assert.IsTrue(actualValue.Contains(expectedValue), "Value does not match");
                        }
                        tmsWait.Hard(3);
                    }

                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemDemographics.UIMODEffectiveDate);
                    }
                    break;
                case "TermDate":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='memberDemographics-txt-termDate']//span/input"));
                        string actualValue = ele.GetAttribute("value");
                        if (expectedValue == "")
                        {
                            Assert.IsTrue(actualValue.Contains("MM/dd/yyyy"), "Value does not match");
                        }
                        else
                        {
                            Assert.IsTrue(actualValue.Contains(expectedValue), "Value does not match");
                        }
                       
                    }

                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODMemberCreation.UIMODMemDemographics.UIMODTermDate);
                    }

                    break;
                case "LatestElectionType":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ddele = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Latest Election Type')]/parent::div//span[@class='k-input']"));
                        string actual_value = ddele.Text;
                        Assert.IsTrue(actual_value.Contains(expectedValue), "Value does not match");
                    }

                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfUIMODMemberCreation.UIMODMemDemographics.UIMODElectionTypeDropdownlist);
                    }
                    break;
                case "Part D Opt-Out":
                    tmsWait.Hard(3);
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ddele = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='memberDemographics-select-partDOptOut']//span[@class='k-input']"));
                        tmsWait.Hard(3);
                        string actual_value = ddele.Text;
                        Assert.IsTrue(actual_value.Contains(expectedValue), "Value does not match");
                    }

                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfUIMODMemberCreation.UIMODMemDemographics.UIMODPartDOptOutDropdownlist);
                    }
                    break;

            }
        }

        [Then(@"Verify Span record displayed Plan ID as ""(.*)"" Status Type as ""(.*)"" Span Value as ""(.*)"" Start Date as ""(.*)"" End Date as ""(.*)""")]
        public void ThenVerifySpanRecordDisplayedPlanIDAsStatusTypeAsSpanValueAsStartDateAsEndDateAs(string p0, string p1, string p2, string p3, string p4)
        {
            tmsWait.Hard(3);
            string plan = tmsCommon.GenerateData(p0);
            string statusType = tmsCommon.GenerateData(p1);
            string spanValue = tmsCommon.GenerateData(p2);
            string start = tmsCommon.GenerateData(p3);
            string end = tmsCommon.GenerateData(p4);

            By loc = By.XPath("//*[@id='memberSpansDataGrid']//td[contains(.,'" + plan + "')]/following-sibling::td[contains(.,'" + statusType + "')]/following-sibling::td[contains(.,'" + spanValue + "')]/following-sibling::td[contains(.,'" + start + "')]/following-sibling::td[contains(.,'" + end + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }

        [When(@"Verify Member Information ""(.*)"" section is expand")]
        public void WhenVerifyMemberInformationSectionIsExpand(string p0)
        {
            try
            {
                By idHistoryDisplay = By.XPath("//div[@test-id='idHistory-grid-memberIdHistoryGrid']");
                UIMODUtilFunctions.elementPresenceUsingLocators(idHistoryDisplay);
            }
            catch
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[@test-id='memberHistory-lbl-idHistory']")));

                tmsWait.Hard(1);
            }
        }

        [When(@"Member Information transaction section Edit Icon is clicked for transaction code ""(.*)"" and transaction status ""(.*)""")]
        public void WhenMemberInformationTransactionSectionEditIconIsClickedForTransactionCodeAndTransactionStatus(int p0, string p1)
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='transactions-grid-memberTransactionsGrid']//td[contains(.,'"+p0+"')]//following-sibling::td[contains(.,'"+p1+"')]//following-sibling::td/a")));
        }



        [Then(@"Member Information ""(.*)"" section is expand")]
        [When(@"Member Information ""(.*)"" section is expand")]
        public void WhenMemberInformationSectionIsExpand(string tab)
        {
            tmsWait.Hard(5);
            string tablower = tab.ToLower();
            switch (tab.ToLower())
            {
                case "contacts":

                    fw.ExecuteJavascriptScroll(Browser.Wd.FindElement(By.XPath("//label[@test-id='memberContacts-lbl-contacts']")));
                    //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[@test-id='memberContacts-lbl-contacts']")));
                    tmsWait.Hard(1);
                    break;
                case "spans":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[@test-id='memberSpanInfo-lbl-span']")));
                    tmsWait.Hard(1);
                    break;
                case "eligibility":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[@test-id='memberEligibility-lbl-eligibilty']")));
                    tmsWait.Hard(1);
                    break;

                case "trrview":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[@test-id='memberTrrInfo-lbl-trrView']")));
                    tmsWait.Hard(1);
                    break;
                case "idhistory":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[@test-id='memberHistory-lbl-idHistory']")));

                    tmsWait.Hard(1);
                    break;
                case "correspondence":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[@test-id='memberCorrespondence-lbl-correspondence']")));
                    tmsWait.Hard(1);
                    break;
                case "transactions":
                    fw.ExecuteJavascriptScroll(Browser.Wd.FindElement(By.XPath("//label[@test-id='memberViewEdit-lbl-transactions']")));
                    tmsWait.Hard(1);
                    break;
                case "premium":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[@test-id='memberPremiumLisInfo-lbl-premiumLis']")));
                    tmsWait.Hard(1);
                    break;
                case "payment":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[@test-id='memberPaymentInfo-lbl-payment']")));
                    tmsWait.Hard(1);
                    break;
                case "provider":
                     fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[@test-id='memberProvider-lbl-provider']")));
                    tmsWait.Hard(1);
                    break;
                case "oecsales":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[@test-id='memberOecSales-lbl-OecSales']")));
                    tmsWait.Hard(1);
                    break;
                case "plandefinedfields":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[@test-id='memberPlanDefinedFields-lbl-planDefinedFields']")));
                    tmsWait.Hard(1);
                    break;
                case "applicationdisposition":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Application Disposition')]")));
                    tmsWait.Hard(1);
                    break;
            }

        }

    }

}
