﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1
{
    [Binding]
    class cfUIMODEAMAdmin
    {

        public static LettersTemplateConfig LettersTemplateConfig { get { return new LettersTemplateConfig(); } }
        public static AddEditLISInfo AddEditLISInfo { get { return new AddEditLISInfo(); } }
        public static UIMODRecalculations UIMODRecalculations { get { return new UIMODRecalculations(); } }
        public static ManagePlanSCC ManagePlanSCC { get { return new ManagePlanSCC(); } }
        public static MMPManagement MMPManagement { get { return new MMPManagement(); } }
        public static View_BidData View_BidData { get { return new View_BidData(); } }
        public static ViewEditPlanInfo ViewEditPlanInfo { get { return new ViewEditPlanInfo(); } }
        public static StatusOverride StatusOverride { get { return new StatusOverride(); } }
    }

    [Binding]
    public class StatusOverride
    {

        public IWebElement MemberOptButton { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='statusoverride-lbl-member']/span")); } }
        public IWebElement TransactionOptButton { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='statusoverride-lbl-transaction']/span")); } }
        public IWebElement MBITextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='statusoverride-txt-txtMbi']")); } }
        public IWebElement SearchBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='statusoverride-btn-search']")); } }
        public IWebElement ResetBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='statusoverride-btn-reset']")); } }
        public IWebElement StatusDrp { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlTransactionStatus_listbox']")); } }
        public IWebElement EffectiveDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='statusOverrideTransaction-txt-effectiveDate']")); } }
        public IWebElement TRC { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='statusOverrideTransaction-txt-trc']")); } }
        public IWebElement ReplyDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='statusOverrideTransaction-txt-newReplyDate']")); } }
        public IWebElement ElectionType { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlElectionType_listbox']")); } }
        public IWebElement DisEnrollmentReason { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='statusOverrideTransaction-txt-DisEnrollReason']")); } }
        public IWebElement RxID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='statusOverrideTransaction-txt-RxID']")); } }
        public IWebElement SaveButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='statusOverrideTransaction-btn-save']")); } }

        public IWebElement NewMemberID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='statusOverrideMember-txt-newMemberID']")); } }
        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='snpConfigure-select-planId']")); } }
        public IWebElement PBPID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='snpConfigure-select-pbpId']")); } }
        public IWebElement MemberRxID { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='statusOverrideMember-txt-newRxID']")); } }
        public IWebElement MemberStatusDrp { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='newMemberStatus_listbox']")); } }
        public IWebElement AngularMemberStatusDrp { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='statusOverride-ddl-newMemberStatus']//span[@class='k-select']")); } }
        public IWebElement AngularMemberSaveButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='statusOverrideTransaction-btn-save']")); } }
        public IWebElement MemberSaveButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='statusOverrideMember-btn-save']")); } }
        public IWebElement MemberNumber { get { return Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='statusoverride-grid-member']//td[@data-kendo-grid-column-index='0']")); } }
        






    }

        [Binding]
    public class MMPManagement
    {
       // public IWebElement StateDropdownlistAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlMmpStatus_listbox']")); } }
        public IWebElement StateDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlMmpStatus_listbox']")); } }
        public IWebElement PlanIDDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlPlans_listbox']")); } }
        public IWebElement PBPIDDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlPlanPbp_listbox']")); } }
        public IWebElement TCCodeDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlTransactionCode_listbox']")); } }
        public IWebElement TCStatusDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlTransactionStatus_listbox']")); } }
        public IWebElement TRCDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlTrc_listbox']")); } }

        public IWebElement EffectiveDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='mmpManagement-date-dtEffDate']")); } }
        public IWebElement TermDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='mmpManagement-date-terminationDate']")); } }
        public IWebElement ResetBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='mmpManagement-btn-cancel']")); } }
        public IWebElement ADDBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='mmpManagement-btn-add']")); } }


       // public IWebElement StateDropdownlistAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlMmpStatus_listbox']")); } }
        public IWebElement StateDropdownlistAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='mmpManagement-select-ddlMmpStatus']")); } }
        public IWebElement PlanIDDropdownlistAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='mmpManagement-select-ddlPlans']")); } }
        public IWebElement PBPIDDropdownlistAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='mmpManagement-select-ddlPlanPbp']")); } }
        public IWebElement TCCodeDropdownlistAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='mmpManagement-select-ddlTransactionCode']")); } }
        public IWebElement TCStatusDropdownlistAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='mmpManagement-select-ddlTransactionStatus']")); } }
        public IWebElement TRCDropdownlistAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='mmpManagement-select-ddlTrc']")); } }

        public IWebElement EffectiveDateAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='mmpManagement-date-dtEffDate']")); } }
        public IWebElement TermDatAngJSe { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='mmpManagement-date-terminationDate']")); } }
        public IWebElement ResetBtnAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='mmpManagement-btn-cancel']")); } }
        public IWebElement ADDBtnAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='mmpManagement-btn-add']")); } }


    }
    [Binding]
    public class ManagePlanSCC
    {
        
        public IWebElement PlanIDDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlPlanId_listbox']")); } }
        public IWebElement PBPIDDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlPbp_listbox']")); } }
        public IWebElement SegmentIDDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlSegmentId_listbox']")); } }
        public IWebElement SCCDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='dllSccId_listbox']")); } }

        public IWebElement EffectiveDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='sccMapping-date-dtEffDate']")); } }

        public IWebElement EndDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='sccMapping-date-dtEndDate']")); } }

        public IWebElement ResetBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='editScc-Reset-btn']")); } }

        public IWebElement SearchBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='editScc-Save-btn']")); } }

        public IWebElement ADDBtn { get { return Browser.Wd.FindElement(By.XPath("//button[contains(.,'ADD')]")); } }
        public IWebElement AddPlanId { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='planId_listbox']")); } }
        public IWebElement AddPBP { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='pbp_listbox']")); } }
        public IWebElement AddSegment { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='segmentId_listbox']")); } }
        public IWebElement AddSCC { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='scc_listbox']")); } }
        public IWebElement AddEffectiveDate { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='effectiveDate_dateview']")); } }
        public IWebElement AddEndDate { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='endDate_dateview']")); } }
        public IWebElement SelectFile { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='scc-input-fileUpload']")); } }

        public IWebElement ImportBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='scc-btn-import']")); } }




    }

    [Binding]
    public class UIMODRecalculations
    {
        public IWebElement MonthlyLISReCalculationButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='recalculationsPremium-btn-recalculate']")); } }
        public IWebElement YearlyPremiumRecalculationsBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='recal-btn']")); } }
        public IWebElement ExtendedLISPeriodsfortheopenendedLISrecordsBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='recalculate-btn-sendTow']")); } }
        public IWebElement MemberUpdatesforEnrollmentBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='rec-btn']")); } }
        public IWebElement Recalculate_checkbox_ForceRereun { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='recalculate-checkbox-chkForceRereun']")); } }
        public IWebElement Plan10Textbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='recalculations-input']")); } }

        

    }

    [Binding]
    public class AddEditLISInfo
    {
        public IWebElement MBITextbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='lisInformation-input-mbi']")); } }
        public IWebElement SearchBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='lisInformation-btn-search']")); } }
        public IWebElement PlanIDDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='planId_listbox']")); } }
        public IWebElement LISLevelDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='lisLevel_listbox']")); } }
        public IWebElement CoPayCatDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='coPayCat_listbox']")); } }
        public IWebElement SourceDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='lisSource_listbox']")); } }
        public IWebElement LISTypeDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='lisType_listbox']")); } }
        public IWebElement AddLISInfo  { get { return Browser.Wd.FindElement(By.XPath("//a[contains(.,'Add LIS Info')]")); } }
        public IWebElement AngularAddLISInfo { get { return Browser.Wd.FindElement(By.XPath("//*[@id='lisDataGrid']/kendo-grid/kendo-grid-toolbar/button")); } }
        public IWebElement ValidDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='lisValidText_listbox']")); } }
        public IWebElement CurrentDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='lisCurrent_listbox']")); } }
        public IWebElement StartDate { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='startDate_dateview']")); } }
        public IWebElement EndDate { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='endDate_dateview']")); } }
       // AngularAddLISInfo
        public IWebElement UpdateIcon { get { return Browser.Wd.FindElement(By.XPath("//a[contains(@class,'update')]")); } }
        public IWebElement SaveIcon { get { return Browser.Wd.FindElement(By.XPath("//a[contains(@class,'update')]")); } }
        public IWebElement EditIcon { get { return Browser.Wd.FindElement(By.XPath("//a[contains(@class,'edit')]")); } }
        public IWebElement DeleteIcon { get { return Browser.Wd.FindElement(By.XPath("//a[contains(@class,'Delete')]")); } }
    }

    [Binding]
    public class LettersTemplateConfig
    {
        public IWebElement LettersDropdownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='drpLetter_listbox']")); } }
        public IWebElement LanguageDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='drplanguage_listbox']")); } }
        public IWebElement EffectiveYearDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='letterTemplate-select-effectiveYear']")); } }
        public IWebElement PlanIdDropdownlist { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='letterTemplate-select-planId']")); } }
        public IWebElement SearchButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='letterTemplate-btn-searchLetters']")); } }
        public IWebElement MapTemplate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='letterTemplate-btn-mapLetters']")); } }
        public IWebElement CopyTemplateMapping { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='letterTemplate-button-copyTemp']")); } }

        

    }

    [Binding]

    public class View_BidData
    {
        public IWebElement PageTitle { get { return Browser.Wd.FindElement(By.XPath("//div[@class='adminTitle']/span")); } }
        public IWebElement YearDropDownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlYear_listbox']")); } }
        public IWebElement PlanIdDropDownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlPlanId_listbox']")); } }
        public IWebElement PBPDropDownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlPbp_listbox']")); } }
        public IWebElement SegmentrDropDownList { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlSegmentId_listbox']")); } }
        public IWebElement SearchBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='bidData-btn-search']")); } }
        public IWebElement ResetBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='bidData-btn-reset']")); } }
        public IWebElement PremiumClaculationWindowHeader { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='bidData-lbl-premium-calculation']")); } }
        public IWebElement PremiumCalculationWindowCloseBtn { get { return Browser.Wd.FindElement(By.XPath("//span[@class='k-icon k-i-x']")); } }

    }

    [Binding]
    public class ViewEditPlanInfo

    {
        public IWebElement ViewEditPlanInfoWindowTitle { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-lbl-planInfoTitle']")); } }
        public IWebElement ViewEditPlanInfoPBPType { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlPbpType_listbox']")); } }
        public IWebElement ViewEditPlanInfoMMPState { get { return Browser.Wd.FindElement(By.CssSelector("[aria-owns='mmpState_listbox']")); } }
        public IWebElement ViewEditPlanInfoMedicareProductName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-medicareProductName']")); } }
        public IWebElement ViewEditPlanInfoEffDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-txt-effDate']")); } }
        public IWebElement ViewEditPlanInfoEndDate { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-txt-endDate']")); } }
        public IWebElement ViewEditPlanInfoRxId { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-rxId']")); } }
        public IWebElement ViewEditPlanInfoRxGroup { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-rxGroup']")); } }
        public IWebElement ViewEditPlanInfoRxBin { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-rxBin']")); } }
        public IWebElement ViewEditPlanInfoRxPCN { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-rxPcn']")); } }
        public IWebElement ViewEditPlanInfoDeductible { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-deductible']")); } }
        public IWebElement ViewEditPlanInfoPremiumC { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-premC']")); } }
        public IWebElement ViewEditPlanInfoPremiumD { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-premD']")); } }
        public IWebElement ViewEditPlanDepartment { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-dept']")); } }
        public IWebElement ViewEditPlanInfoHouseOfOp { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-hrsOfOp']")); } }
        public IWebElement ViewEditPlanInfoAddress1 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-address1']")); } }
        public IWebElement ViewEditPlanInfoAddress2 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-address2']")); } }
        public IWebElement ViewEditPlanInfoCity { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-city']")); } }
        public IWebElement ViewEditPlanInfoStates { get { return Browser.Wd.FindElement(By.CssSelector("[ng-model='planDetail.states']")); } }
        public IWebElement ViewEditPlanInfoStatesAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-state']")); } }
        public IWebElement ViewEditPlanInfoZip { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-zip']")); } }
        public IWebElement ViewEditPlanInfoName1 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-name1']")); } }
        public IWebElement ViewEditPlanInfoPhone1 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-phone1']")); } }
        public IWebElement ViewEditPlanInfoExt1 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-ext1']")); } }
        public IWebElement ViewEditPlanInfoEmail1 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-email']")); } }
        public IWebElement ViewEditPlanInfoName2 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-name2']")); } }
        public IWebElement ViewEditPlanInfoPhone2 { get { return Browser.Wd.FindElement(By.CssSelector("[ng-model='planDetail.phone2']")); } }
        public IWebElement ViewEditPlanInfoExt2 { get { return Browser.Wd.FindElement(By.CssSelector("[ng-model='planDetail.extension2']")); } }
        public IWebElement ViewEditPlanInfoEmail2 { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-email2']")); } }
        public IWebElement ViewEditPlanInfoSaveBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-btn-save']")); } }
        public IWebElement ViewEditPlanInfoCancelBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-btn-cancel']")); } }
        public IWebElement ViewEditPlanInfoResetBtn { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-btn-reset']")); } }
        public IWebElement ViewEditPlanInfoBacktoRecord { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-lbl-back']")); } }
        public IWebElement ViewEditPlanInfoWindowTitleAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-lbl-planInfoTitle']")); } }
        public IWebElement ViewEditPlanInfoPBPTypeAngJS { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'PBP Type')]/parent::div//span[@class='k-select']")); } }
        public IWebElement ViewEditPlanInfoMMPStateAngJS { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'MMP State')]/parent::div//span[@class='k-select']")); } }
        public IWebElement ViewEditPlanInfoMMPStateTextAngJS { get { return Browser.Wd.FindElement(By.XPath("//label[contains(.,'MMP State')]/parent::div//span[@class='k-input']")); } }
        public IWebElement ViewEditPlanInfoMMPStateAreaAngJS { get { return Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='planInfoDetails-select-mmpState']/span")); } }
        public IWebElement ViewEditPlanInfoMedicareProductNameAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-medicareProductName']")); } }
        public IWebElement ViewEditPlanInfoEffDateAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='mmpManagement-date-txtEffectiveDate']")); } }
        public IWebElement ViewEditPlanInfoEndDateAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-txt-endDate']")); } }
        public IWebElement ViewEditPlanInfoRxIdAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-rxId']")); } }
        public IWebElement ViewEditPlanInfoRxGroupAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-rxGroup']")); } }
        public IWebElement ViewEditPlanInfoRxBinAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-rxBin']")); } }
        public IWebElement ViewEditPlanInfoRxPCNAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-rxPcn']")); } }
        public IWebElement ViewEditPlanInfoDeductibleAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-deductible']")); } }
        public IWebElement ViewEditPlanInfoPremiumCAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-premC']")); } }
        public IWebElement ViewEditPlanInfoPremiumDAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-premD']")); } }
        public IWebElement ViewEditPlanDepartmentAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-dept']")); } }
        public IWebElement ViewEditPlanInfoHouseOfOpAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-hrsOfOp']")); } }
        public IWebElement ViewEditPlanInfoAddress1AngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-address1']")); } }
        public IWebElement ViewEditPlanInfoAddress2AngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-address2']")); } }
        public IWebElement ViewEditPlanInfoCityAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-city']")); } }
        //public IWebElement ViewEditPlanInfoStatesAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[ng-model='planDetail.states']")); } }
        public IWebElement ViewEditPlanInfoZipAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-zip']")); } }
        public IWebElement ViewEditPlanInfoName1AngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-name1']")); } }
        public IWebElement ViewEditPlanInfoPhone1AngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-phone1']")); } }
        public IWebElement ViewEditPlanInfoExt1AngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-ext1']")); } }
        public IWebElement ViewEditPlanInfoEmail1AngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-email']")); } }
        public IWebElement ViewEditPlanInfoName2AngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-name2']")); } }
        public IWebElement ViewEditPlanInfoPhone2AngJS { get { return Browser.Wd.FindElement(By.CssSelector("[ng-model='planDetail.phone2']")); } }
        public IWebElement ViewEditPlanInfoExt2AngJS { get { return Browser.Wd.FindElement(By.CssSelector("[ng-model='planDetail.extension2']")); } }
        public IWebElement ViewEditPlanInfoEmail2AngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-input-email2']")); } }
        public IWebElement ViewEditPlanInfoSaveBtnAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-btn-save']")); } }
        public IWebElement ViewEditPlanInfoCancelBtnAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-btn-cancel']")); } }
        public IWebElement ViewEditPlanInfoResetBtnAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-btn-reset']")); } }
        public IWebElement ViewEditPlanInfoBacktoRecordAngJS { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='planInfoDetails-span-back']")); } }
        public IWebElement ViewEditPlanInfoEGWPChkbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='eafFalloutCorrectionContent-chk-egwp']")); } }
        public IWebElement ViewEditPlanInfoEGHPChkbox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='eafFalloutCorrectionContent-chk-eghp']")); } }
        public IWebElement PBPLevelSaveButton { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='pbpLevelFooter-btn-savePbpLevelDetail']")); } }




    }
}

