﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using TechTalk.SpecFlow;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using System.Diagnostics;
using System.Windows;


namespace TMSoR1
{
    [Binding]
    public class cfEAMExport
    {
        // For additional details on SpecFlow hooks see http://go.specflow.org/doc-hooks

        public static ExportLegacyMembers ExportLegacyMembers { get { return new ExportLegacyMembers();} }
        public static ExportSpansToFacets ExportSpansToFacets { get { return new ExportSpansToFacets(); } }
    }

    [Binding]
    public class ExportLegacyMembers
    {
        // For additional details on SpecFlow hooks see http://go.specflow.org/doc-hooks

        public IWebElement PlanID { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlPlan")); } }
        public IWebElement MemberStatus { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlMemberStatus")); } }
        public IWebElement ModifiedCheck { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_chModified"));  } }
        public IWebElement Export { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlExportOption"));  } }
        public IWebElement HICNumber { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboSort"));  } }
        public IWebElement GoButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cmdGo"));  } }
        public IWebElement ExportMemberGrid { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dgRaps")); } }
        public IWebElement ExportmemberJobInfo { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblMsg")); } }
        public IWebElement ExportButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cmdExport"));  } }
        public IWebElement DeselectAll {  get { return Browser.Wd.FindElement(By.CssSelector("[test-id='legacyTrans-btn-deselectAll']")); } }
        public IWebElement ResetButton {  get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cmdReset")); } }
        public IWebElement OrderBy {  get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboSort")); } }
        public IWebElement SelectAll {  get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cmdSelectAll")); } }
        public IWebElement NorecordInQMessage {  get { return Browser.Wd.FindElement(By.XPath(".//*[@id='ctl00_ctl00_MainMasterContent_MainContent_lblMsg']")); } }
                                                                                   
    }

    [Binding]
    public class ExportSpansToFacets
    {
        public IWebElement ExportButton { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='facetsSpan-btn-export']"));  } }
        public IWebElement UserWarningMsgText { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtUserWarnMsg")); } }
        public IWebElement SaveButton { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btntxtUserWarnMsg")); } }
        public IWebElement PageTitle { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='export-lbl-spanfacets']"));  } }
        public IWebElement UserWarningMsgLabel { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblUserWarnMsg")); } }
        public IWebElement CollapsableButton { get { return Browser.Wd.FindElement(By.Id("imgCollapsableButton")); } }
        public IWebElement LogTable { get { return Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dgExportHistory")); } }
        public IWebElement RefreshButton { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='facetsSpan-btn-refresh']")); } }
        public IWebElement ExportDashboardGrid { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='facetsSpan-grid-facetsSpanGrid']/table[@role='grid']/tbody")); } }

        public IWebElement ExportID{ get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='facetsSpan-grid-facetsSpanGrid']/table[@role='grid']/tbody/tr/td")); } }
        public IWebElement ToastMessage { get { return Browser.Wd.FindElement(By.ClassName("toast-message")); } }

    }
}
