﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TechTalk.SpecFlow;
using System.Collections.ObjectModel;
using OpenQA.Selenium;
using TMSoR1.FrameworkCode;
using System.IO;

namespace TMSoR1
{
    [Binding]
    class fsProvider
    {
        public static string MainWindowHandle = "";
        public static string ReportWindowHandle = "";
        [Then(@"View Edit Member page IPA Group ID link is Clicked")]
        public void ThenViewEditMemberPageIPAGroupIDLinkIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascriptScroll(EAM.MembersViewEdit.IPAGroupID1);
            fw.ExecuteJavascript(EAM.MembersViewEdit.IPAGroupID1);
            tmsWait.Hard(2);
           // Browser.SwitchToChildWindow();
        }

        [When(@"PCP IPA Lookup window ""(.*)"" is set to ""(.*)""")]
        public void WhenPCPIPALookupWindowIsSetTo(string field, string value)
        {
            Browser.SwitchToChildWindow();
            switch (field)
            {
                case "Provider ID":
                    EAM.PCPIPALookup.ProviderIDTextbox.SendKeys(value);
                    break;
                case "Provider First Name":
                    EAM.PCPIPALookup.ProviderFirstName.SendKeys(value);
                    break;
                case "Provider Last Name":
                    EAM.PCPIPALookup.ProviderLastName.SendKeys(value);
                    break;
                case "Group IPA ID":
                    EAM.PCPIPALookup.GroupIPAIDTextbox.SendKeys(value);
                    break;
                case "Group IPA Name":
                    EAM.PCPIPALookup.GroupIPANameTextbox.SendKeys(value);
                    break;
                case "NPI":
                    EAM.PCPIPALookup.NPI.SendKeys(value);
                    break;
              
            }
        }

        [Then(@"Verify PCP IPA Lookup window ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyPCPIPALookupWindowIsSetTo(string field, string expvalue)
        {
            switch (field)
            {
                case "Provider ID":
                    Assert.AreEqual(EAM.PCPIPALookup.ProviderIDTextbox.Text, expvalue, "expected value is not getting dislayed");                  
                    break;
                case "Provider First Name":
                    Assert.AreEqual(EAM.PCPIPALookup.ProviderFirstName.Text, expvalue, "expected value is not getting dislayed");
                    
                    break;
                case "Provider Last Name":
                    Assert.AreEqual(EAM.PCPIPALookup.ProviderLastName.Text, expvalue, "expected value is not getting dislayed");
                    
                    break;
                case "Group IPA ID":
                    Assert.AreEqual(EAM.PCPIPALookup.GroupIPAIDTextbox.Text, expvalue, "expected value is not getting dislayed");
                    
                    break;
                case "Group IPA Name":
                    Assert.AreEqual(EAM.PCPIPALookup.GroupIPANameTextbox.Text, expvalue, "expected value is not getting dislayed");
                   
                    break;
                case "NPI":
                    Assert.AreEqual(EAM.PCPIPALookup.NPI.Text, expvalue, "expected value is not getting dislayed");
                      break;
            }
        }

        [Then(@"Verify PCP IPA Lookup Search Results display IPA Group Name as ""(.*)""")]
        public void ThenVerifyPCPIPALookupSearchResultsDisplayIPAGroupNameAs(string p0)
        {
            bool field = Browser.Wd.FindElement(By.XPath("//table[@id='pcpIpaGridView_ctl00']//td[contains(.,'"+p0+"')]")).Displayed;
            Assert.IsTrue(field, p0 + "Is not getting displayed");
        }


        [When(@"PCP IPA Lookup window ""(.*)"" button is Clicked")]
        public void WhenPCPIPALookupWindowButtonIsClicked(string button)
        {
            switch(button)
            {
                case "Save":
                    fw.ExecuteJavascript(EAM.PCPIPALookup.SaveButton);
                    break;
                case "Reset":
                    fw.ExecuteJavascript(EAM.PCPIPALookup.Reset);
                    break;
                case "Submit":
                    fw.ExecuteJavascript(EAM.PCPIPALookup.SubmitButton);
                    break;
                case "Close":
                    fw.ExecuteJavascript(EAM.PCPIPALookup.Close);
                    break;
            }

        }


        [Then(@"PCP LookUp should be opened")]
        public void ThenPCPLookUpShouldBeOpened()
        {
            GlobalRef.CountOfWindow = Browser.GetWindowCount();
            int count = Convert.ToInt32(GlobalRef.CountOfWindow);
            Assert.AreEqual(2, count, "PCP LookUp window is not displayed");

            Browser.SwitchToParentWindow();
        }

        [Then(@"View Edit Member page PCP ID link is Clicked")]
        public void ThenViewEditMemberPagePCPIDLinkIsClicked()
        {
            EAM.MembersViewEdit.PCPID.Click();
            tmsWait.Hard(2);
        }

        [When(@"PCP IPA Lookup Window Submit button is Clicked")]
        public void WhenPCPIPALookupWindowSubmitButtonIsClicked()
        {
            tmsWait.Hard(2);
            EAM.PCPIPALookup.SubmitButton.Click();
           // IJavaScriptExecutor js = Browser.Wd as IJavaScriptExecutor;
           //js.ExecuteScript("document.getElementById('cmdSubmit')");

           
        }

        [Then(@"Verify PCP IPA Lookup window displayed search results")]
        public void ThenVerifyPCPIPALookupWindowDisplayedSearchResults(Table table)
        {
            tmsWait.Hard(2);

           
                IWebElement objWebTable = EAM.PCPIPALookup.PCPLookupTable;

               



        }


        [Then(@"View Edit Member page Provider Tab is Clicked")]
        public void ThenViewEditMemberPageProviderTabIsClicked()
        {
            EAM.MembersNewTabProvider.ProviderTabLink.Click();
        }

        [Then(@"Verify Provider tab PCP Prv ID field is Disabled")]
        public void ThenVerifyProviderTabPCPPrvIDFieldIsDisabled()
        {

            tmsWait.Hard(2);
            Assert.IsFalse(EAM.MembersNewTabProvider.PCPPrvID.Enabled, " PCP Prv ID field is Enabled");
        }

        [Then(@"Verify PCP IPA Lookup window is Opened")]
        public void ThenVerifyPCPIPALookupWindowIsOpened()
        {

            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//span[@test-id='pcpIpa-title-searchCriteria'])[1]")).Displayed, "PCP IPA Lookup page is not displayed");
            //tmsWait.Hard(2);
            //string currentHandle = "";
            //ReadOnlyCollection<string> windowHandles = Browser.Wd.WindowHandles;
            //currentHandle = Browser.Wd.CurrentWindowHandle;

            //for (int i = 0; i < 6; i++)
            //{
            //    try
            //    {
            //        String ReportTitle = Browser.Wd.SwitchTo().Window(currentHandle).Title;
            //        Console.WriteLine(ReportTitle);
            //        break;
            //    }
            //    catch (Exception) { tmsWait.Hard(2); }
            //}
        }


        [Then(@"PCP IPA Lookup Window Accept Assignment drop down is disabled")]
        public void ThenPCPIPALookupWindowAcceptAssignmentDropDownIsDisabled()
        {
            tmsWait.Hard(3);

            //Browser.SwitchToChildWindow();
            //Assert.IsFalse(EAM.PCPIPALookup.AcceptsAssignmentdrpdown.Enabled, " Accepts Assignment Dropdown is Enabled");

            //IWebElement Participatingdd = Browser.Wd.FindElement(By.XPath("(//span[@aria-owns='participating_listbox'])[1]"));
            bool isdisabled; string dis;
            if (ConfigFile.tenantType == "tmsx")
            {
                dis = Browser.Wd.FindElement(By.XPath("//*[@test-id='pcpIpa-select-acceptAssignments']/span")).GetAttribute("aria-disabled"); 
            }
            else
            {
                dis = EAM.PCPIPALookup.AcceptsAssignmentdrpdown.GetAttribute("aria-disabled");
            }
                isdisabled = Boolean.Parse(dis);
                Assert.IsTrue(isdisabled, "Accepts Assignment Dropdown is Not Disabled");
            

        }

        [When(@"Imports Provider page ALM Test ID ""(.*)"" attached File ""(.*)"" is renamed and imported with New File Name ""(.*)"" in EAM Clicked on Upload button")]
        public void WhenImportsProviderPageALMTestIDAttachedFileIsRenamedAndImportedWithNewFileNameInEAMClickedOnUploadButton(string p0, string p1, string p2)
        {

            ReUsableFunctions.deleteFilesFromDownloadFolder();
            ReUsableFunctions.deleteFilesFromTempFolder();
            // Create a Specific Folder
            string activeDir = "c:\\temp\\tmsAlm\\";
            if (!Directory.Exists(activeDir))  //  Verify Specific Folder Exists, if No then Create it.
            {
                Directory.CreateDirectory(activeDir);
            }

            if (ConfigFile.EnvType.Equals("ESI") || ConfigFile.EnvType.Equals("Main"))
            {
                string po_gen = tmsCommon.GenerateData(p0);
                string p1_gen = tmsCommon.GenerateData(p1);
                string p2_gen = tmsCommon.GenerateData(p2);

                Boolean keepTrying = true;

                Console.WriteLine("**Before call to ALM file download**");
                //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
                //if they are there, we copy across.   Otherwise we reach into ALM to get them.
                string controllerFileLocation = "c:\\temp\\tmsAlm\\";
                // We added this code for Jenkins run
                // Do not comment below code as it will be used for Smoke test suite
                string SourceFileLocation = "C:\\SourceFile\\";
                string tempFolder = "c:\\temp\\";
                Boolean didUpload = false;
                string source = SourceFileLocation + p1_gen;
                bool fileDownloadOnALM = false;
                if (Directory.Exists(SourceFileLocation))
                {
                    if (!File.Exists(controllerFileLocation))
                    {
                        File.Copy(SourceFileLocation + p1_gen, tempFolder + p1_gen);
                        fileDownloadOnALM = true;
                        didUpload = true;

                        fw.ConsoleReport(" File is found on Source File Folder");
                    }
                }

                Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");

                if (!fileDownloadOnALM)
                {
                    Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                    didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
                }
                if (didUpload)
                {
                    while (keepTrying)
                    {
                        string FileName = "C:\\Temp\\" + p1_gen;
                        string newFileName = "C:\\Temp\\tmsAlm\\" + tmsCommon.GenerateData(p2_gen);
                        //Move method moves an existing file to a new location with the same or a different file name, move delete original file ( CUT Operation)
                        File.Move(@FileName, @newFileName);
                        fw.ConsoleReport("Renaming File");
                        FileName = newFileName;
                        if (ConfigFile.BrowserType.Equals("edge") || ConfigFile.BrowserType.Equals("edgelegacy"))
                        {
                            fw.ConsoleReport("You are using Edge Browser");
                            string sharedFolderPath = ReUsableFunctions.returnTMSSharedInputFolder(ConfigFile.EAMdb);
                            string destinationLoc = sharedFolderPath + tmsCommon.GenerateData(p2_gen);
                            File.Copy(FileName, destinationLoc);

                        }
                        else
                        {
                            fw.ConsoleReport("Sending File using Send Keys");
                            EAM.LoadEAFFile.SelectFiles.SendKeys(FileName);
                            fw.ConsoleReport("Click on Select File Button");
                            tmsWait.Hard(5); // Currently Application is taking much time to load


                            fw.ExecuteJavascript(EAM.LoadEAFFile.Upload);

                            fw.ConsoleReport("Uploaded File using Upload Button");

                        }
                        break; // Exit from while loop
                    }

                }

                try
                {
                    System.IO.DirectoryInfo di = new DirectoryInfo("c:\\Temp\\");

                    foreach (FileInfo file in di.GetFiles())
                    {
                        file.Delete();
                    }

                }
                catch
                {

                }

                tmsWait.Hard(40);  // we kep this wait for intentionally as EAF file processing is taking time, will remove later
            }
            else
            {

                string po_gen = tmsCommon.GenerateData(p0);
                string p1_gen = tmsCommon.GenerateData(p1);
                string p2_gen = tmsCommon.GenerateData(p2);

                Boolean keepTrying = true;

                Console.WriteLine("**Before call to ALM file download**");
                //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
                //if they are there, we copy across.   Otherwise we reach into ALM to get them.
                string controllerFileLocation = "c:\\temp\\tmsAlm\\";
                string tempFolder = "c:\\temp\\";
                // We added this code for Jenkins run
                // Do not comment below code as it will be used for Smoke test suite
                string SourceFileLocation = "C:\\SourceFile\\";
                Boolean didUpload = false;
                string source = SourceFileLocation + p1_gen;
                bool fileFoundOnTemp = false;
                bool fileDownloadOnALM = false;
                if (Directory.Exists(SourceFileLocation))
                {
                    if (!File.Exists(controllerFileLocation))
                    {
                        fw.ConsoleReport(" Copy File From SourceFile to Temp Folder");
                        File.Copy(SourceFileLocation + p1_gen, tempFolder + p1_gen);
                        fileFoundOnTemp = true;
                        fileDownloadOnALM = true;
                        didUpload = true;
                        fw.ConsoleReport(" File is found on Source File Folder");
                    }
                }

                Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");

                if (!fileDownloadOnALM)
                {
                    Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                    didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
                }
                if (didUpload)
                {
                    while (keepTrying)
                    {
                        string FileName = "C:\\Temp\\" + p1_gen;


                        string newFileName = "C:\\Temp\\tmsAlm\\" + tmsCommon.GenerateData(p2_gen);
                        //Move method moves an existing file to a new location with the same or a different file name, move delete original file
                        File.Move(@FileName, @newFileName);
                        FileName = newFileName;
                        fw.ConsoleReport(" Renaming File");

                        // This Implementation is only for Edge browser

                        if (ConfigFile.BrowserType.Equals("edge") || ConfigFile.BrowserType.Equals("edgelegacy"))
                        {

                            string sharedFolderPath = ReUsableFunctions.returnTMSSharedInputFolder(ConfigFile.EAMdb);
                            string destinationLoc = sharedFolderPath + tmsCommon.GenerateData(p2_gen);
                            File.Copy(FileName, destinationLoc);

                        }
                        else
                        {
                            EAM.LoadEAFFile.SelectFiles.SendKeys(FileName);
                            fw.ConsoleReport(" Sending File");
                            tmsWait.Hard(3);
                            fw.ExecuteJavascript(EAM.LoadEAFFile.Upload);

                            fw.ConsoleReport("Uploaded File using Upload Button");
                        }

                        break; // Exit from while loop
                    }

                }

                try
                {
                    System.IO.DirectoryInfo di = new DirectoryInfo("c:\\Temp\\");

                    foreach (FileInfo file in di.GetFiles())
                    {
                        file.Delete();
                    }

                }
                catch
                {

                }
            }
        }


        [When(@"Imports Provider page ALM Test ID ""(.*)"" attached File ""(.*)"" is renamed and imported with New File Name ""(.*)"" in EAM")]
        public void WhenImportsProviderPageALMTestIDAttachedFileIsRenamedAndImportedWithNewFileNameInEAM(string p0, string p1, string p2)
        {


            ReUsableFunctions.deleteFilesFromDownloadFolder();
            ReUsableFunctions.deleteFilesFromTempFolder();
            // Create a Specific Folder
            string activeDir = GlobalRef.tmsAlmFolder;
            if (!Directory.Exists(activeDir))  //  Verify Specific Folder Exists, if No then Create it.
            {
                Directory.CreateDirectory(activeDir);
            }

            if (ConfigFile.EnvType.Equals("ESI") || ConfigFile.EnvType.Equals("Main"))
            {
                string po_gen = tmsCommon.GenerateData(p0);
                string p1_gen = tmsCommon.GenerateData(p1);
                string p2_gen = tmsCommon.GenerateData(p2);

                Boolean keepTrying = true;

                Console.WriteLine("**Before call to ALM file download**");
                //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
                //if they are there, we copy across.   Otherwise we reach into ALM to get them.
                string controllerFileLocation = activeDir;
                // We added this code for Jenkins run
                // Do not comment below code as it will be used for Smoke test suite
                string SourceFileLocation = "C:\\SourceFile\\";
                string tempFolder = "c:\\temp\\";
                Boolean didUpload = false;
                string source = SourceFileLocation + p1_gen;
                bool fileDownloadOnALM = false;
                if (Directory.Exists(SourceFileLocation))
                {
                    if (!File.Exists(controllerFileLocation))
                    {
                        File.Copy(SourceFileLocation + p1_gen, tempFolder + p1_gen);
                        fileDownloadOnALM = true;
                        didUpload = true;

                        fw.ConsoleReport(" File is found on Source File Folder");
                    }
                }

                Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");

                if (!fileDownloadOnALM)
                {
                    Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                    didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
                }
                if (didUpload)
                {
                    while (keepTrying)
                    {
                        string FileName = "C:\\Temp\\" + p1_gen;
                        string newFileName = activeDir + tmsCommon.GenerateData(p2_gen);
                        //Move method moves an existing file to a new location with the same or a different file name, move delete original file ( CUT Operation)
                        File.Move(@FileName, @newFileName);
                        fw.ConsoleReport("Renaming File");
                        FileName = newFileName;
                        if (ConfigFile.BrowserType.Equals("edge") || ConfigFile.BrowserType.Equals("edgelegacy"))
                        {
                            fw.ConsoleReport("You are using Edge Browser");
                            string sharedFolderPath = ReUsableFunctions.returnTMSSharedInputFolder(ConfigFile.EAMdb);
                            string destinationLoc = sharedFolderPath + tmsCommon.GenerateData(p2_gen);
                            File.Copy(FileName, destinationLoc);

                        }
                        else
                        {
                            fw.ConsoleReport("Sending File using Send Keys");
                            EAM.LoadEAFFile.SelectFiles.SendKeys(FileName);
                            fw.ConsoleReport("Click on Select File Button");
                            tmsWait.Hard(5); // Currently Application is taking much time to load


                            

                        }
                        break; // Exit from while loop
                    }

                }

                try
                {
                    System.IO.DirectoryInfo di = new DirectoryInfo("c:\\Temp\\");

                    foreach (FileInfo file in di.GetFiles())
                    {
                        file.Delete();
                    }

                }
                catch
                {

                }

                tmsWait.Hard(40);  // we kep this wait for intentionally as EAF file processing is taking time, will remove later
            }
            else
            {

                string po_gen = tmsCommon.GenerateData(p0);
                string p1_gen = tmsCommon.GenerateData(p1);
                string p2_gen = tmsCommon.GenerateData(p2);

                Boolean keepTrying = true;

                Console.WriteLine("**Before call to ALM file download**");
                //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
                //if they are there, we copy across.   Otherwise we reach into ALM to get them.
                string controllerFileLocation = "c:\\temp\\tmsAlm\\";
                string tempFolder = "c:\\temp\\";
                // We added this code for Jenkins run
                // Do not comment below code as it will be used for Smoke test suite
                string SourceFileLocation = "C:\\SourceFile\\";
                Boolean didUpload = false;
                string source = SourceFileLocation + p1_gen;
                bool fileFoundOnTemp = false;
                bool fileDownloadOnALM = false;
                if (Directory.Exists(SourceFileLocation))
                {
                    if (!File.Exists(controllerFileLocation))
                    {
                        fw.ConsoleReport(" Copy File From SourceFile to Temp Folder");
                        File.Copy(SourceFileLocation + p1_gen, tempFolder + p1_gen);
                        fileFoundOnTemp = true;
                        fileDownloadOnALM = true;
                        didUpload = true;
                        fw.ConsoleReport(" File is found on Source File Folder");
                    }
                }

                Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");

                if (!fileDownloadOnALM)
                {
                    Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                    didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
                }
                if (didUpload)
                {
                    while (keepTrying)
                    {
                        string FileName = "C:\\Temp\\" + p1_gen;


                        string newFileName = "C:\\Temp\\tmsAlm\\" + tmsCommon.GenerateData(p2_gen);
                        //Move method moves an existing file to a new location with the same or a different file name, move delete original file
                        File.Move(@FileName, @newFileName);
                        FileName = newFileName;
                        fw.ConsoleReport(" Renaming File");

                        // This Implementation is only for Edge browser
                        if (ConfigFile.BrowserType.Equals("edge") || ConfigFile.BrowserType.Equals("edgelegacy"))
                        {

                            string sharedFolderPath = ReUsableFunctions.returnTMSSharedInputFolder(ConfigFile.EAMdb);
                            string destinationLoc = sharedFolderPath + tmsCommon.GenerateData(p2_gen);
                            File.Copy(FileName, destinationLoc);

                        }
                        else
                        {
                            EAM.LoadEAFFile.SelectFiles.SendKeys(FileName);
                            fw.ConsoleReport(" Sending File");
                            tmsWait.Hard(3);
                            
                        }

                        break; // Exit from while loop
                    }

                }

                try
                {
                    System.IO.DirectoryInfo di = new DirectoryInfo("c:\\Temp\\");

                    foreach (FileInfo file in di.GetFiles())
                    {
                        file.Delete();
                    }

                }
                catch
                {

                }
            }
        }


        [Then(@"Verify Import List section displayed ""(.*)"" Link")]
        public void ThenVerifyImportListSectionDisplayedLink(string link)
        {
            By loc = By.XPath("//label[contains(.,'"+ link + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
           
        }

        [Then(@"Verify Provider File displayed ""(.*)""")]
        public void ThenVerifyProviderFileDisplayed(string button)
        {
            By loc = By.XPath("//button[contains(.,'"+button+"')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);

        }

        [Then(@"Verify Provider File is not displayed ""(.*)""")]
        public void ThenVerifyProviderFileIsNotDisplayed(string button)
        {
            By loc = By.XPath("//button[contains(.,'" + button + "')]");
            UIMODUtilFunctions.elementNotPresenceUsingLocators(loc);
        }


        [When(@"Click on Delete uploaded file button")]
        public void WhenClickOnDeleteUploadedFileButton()
        {
            By loc = By.XPath("//button[contains(.,'Delete uploaded file')]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
        }


        [Then(@"Verify Provider File page displayed SELECT FILES Button")]
        public void ThenVerifyProviderFilePageDisplayedSELECTFILESButton()
        {
            By loc = By.XPath("//div[@aria-label='SELECT FILES']");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }


        [Then(@"Verify Provider File page displayed ""(.*)""")]
        public void ThenVerifyProviderFilePageDisplayed(string expRes)
        {

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By loc = By.XPath("//label[@test-id='imports-lbl-validfilename']");
                string actResult = Browser.Wd.FindElement(loc).Text;
                Assert.AreEqual(expRes, actResult, " Both are not matching");
            }
            else
            {
                By loc = By.XPath("//label[@class='importsNoteText']");
                string actRes = Browser.Wd.FindElement(loc).Text;
                Assert.AreEqual(expRes, actRes, " Both are not matching");
            }
           
        }

        [Then(@"Verify that ""(.*)"" page displayed")]
        public void ThenVerifyThatPageDisplayed(string p0)
        {
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[contains(.,'" + p0 + "')]")).Displayed, p0 +"Text not displayed on page");
        }


        [Then(@"Verfiy PCP IPA Lookup Window States drop down is disabled")]
        public void ThenVerfiyPCPIPALookupWindowStatesDropDownIsDisabled()
        {
            tmsWait.Hard(2);
            IWebElement StatesDD; 
            if (ConfigFile.tenantType == "tmsx")
                StatesDD= Browser.Wd.FindElement(By.XPath("//*[@test-id='pcpIpa-select-state']/span"));
            else
                StatesDD = EAM.PCPIPALookup.Statesdrpdown;

            string dis = StatesDD.GetAttribute("aria-disabled");
            bool isdisabled = Boolean.Parse(dis);
            Assert.IsTrue(isdisabled, "States Dropdown is Not Disabled");
        }

        [Then(@"close the child window")]
        public void ThenCloseTheChildWindow()
        {
            Browser.Wd.Close();
        }

        [Then(@"close the child window and Move to Parent Window")]
        public void ThenCloseTheChildWindowAndMoveToParentWindow()
        {
            Browser.Wd.Close();
            Browser.SwitchToWindow(0);
            
        }


        [Then(@"Verfiy PCP IPA Lookup Window Participating Filter drop down is disabled")]
        public void ThenVerfiyPCPIPALookupWindowParticipatingFilterDropDownIsDisabled()
        {
            tmsWait.Hard(2);
            IWebElement Participatingdd;
            if (ConfigFile.tenantType == "tmsx")
            {
                Participatingdd = Browser.Wd.FindElement(By.XPath("//*[@test-id='pcpIpa-select-participating']/span"));
            }
            else
            {
                Participatingdd = Browser.Wd.FindElement(By.XPath("(//span[@aria-owns='participating_listbox'])[1]"));
            }
            string dis = Participatingdd.GetAttribute("aria-disabled");
            bool isdisabled = Boolean.Parse(dis);
            Assert.IsTrue(isdisabled, "Participating Filter Dropdown is Not Disabled");
        }
    }
}
