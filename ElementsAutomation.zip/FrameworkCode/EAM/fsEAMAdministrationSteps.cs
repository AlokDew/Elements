﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Globalization;
using System.Threading;
using System.Collections;
using TMSoR1.FrameworkCode;

namespace TMSoR1
{
    [Binding]
    public class EAMAdministrationMMPSteps
    {

        public string setCheckboxTo;

        [Then(@"Elements Exist")]
        public void ThenElementsExist(Table table)
        {
            foreach (var row in table.Rows)
            {
                var thisElementName = row["Element"];
                //                EAMAdministrationMMP.FindClassObjects();
                Console.WriteLine("Testing Element Exists " + thisElementName);
                tmsWait.Hard(3);
                switch (thisElementName)
                {
                    case "PBP": { fw.ReportOn(EAM.AdministrationMMP.PBP, thisElementName); break; }
                    case "Transaction Code": { fw.ReportOn(EAM.AdministrationMMP.TransactionCode, thisElementName); break; }
                    case "Transaction Status": { fw.ReportOn(EAM.AdministrationMMP.TransactionStatus, thisElementName); break; }
                    case "TRC": { fw.ReportOn(EAM.AdministrationMMP.TRC, thisElementName); break; }
                    case "Effective Date": { fw.ReportOn(EAM.AdministrationMMP.EffectiveDate, thisElementName); break; }
                    case "Termination Date": { fw.ReportOn(EAM.AdministrationMMP.TerminationDate, thisElementName); break; }
                    case "Effective Date Calendar": { fw.ReportOn(EAM.AdministrationMMP.EffectiveDateCalendar, thisElementName); break; }
                    case "Termination Date Calendar": { fw.ReportOn(EAM.AdministrationMMP.TerminationDateCalendar, thisElementName); break; }
                    case "Save": { fw.ReportOn(EAM.AdministrationMMP.Save, thisElementName); break; }
                    case "Add": { fw.ReportOn(EAM.AdministrationMMP.Add, thisElementName); break; }
                    case "Reset": { fw.ReportOn(EAM.AdministrationMMP.Reset, thisElementName); break; }
                    case "Results Table": { fw.ReportOn(EAM.AdministrationMMP.ParametersTable, thisElementName); break; }
                    default: { Assert.AreEqual(true, false, "No Element handler available in 'ThenElementsExist' for [" + thisElementName + "]"); break; }
                }
            }
        }

        [When(@"View Edit Member Page OEC Sales section ""(.*)"" check box is ""(.*)""")]
        public void WhenViewEditMemberPageOECSalesSectionCheckBoxIs(string component, string operation)
        {

        By check = By.XPath("//label[contains(.,'"+ component + "')]/parent::div/input");
            AngularFunction.CheckBoxOperations(check, operation);


        }


        [Then(@"Verify View Edit Member Page OEC Sales section ""(.*)"" check box is ""(.*)""")]
        public void ThenVerifyViewEditMemberPageOECSalesSectionCheckBoxIs(string component, string operation)
        {
            By check = By.XPath("//label[contains(.,'" + component + "')]/parent::div/input");

            bool checkboxStatus = Browser.Wd.FindElement(check).Selected;

            Assert.IsTrue(checkboxStatus, " Check box is not selected ");
        }

        [When(@"Edit TRR Rule Configuration dialog Update button is Clicked")]
        public void WhenEditTRRRuleConfigurationDialogUpdateButtonIsClicked()
        {
            By update = By.XPath("//span[contains(.,'UPDATE')]");
            AngularFunction.clickOnElement(update);
        }

        [When(@"Edit TRR Rule Configuration dialog Enable CMS Initiated checkbox is ""(.*)""")]
        public void WhenEditTRRRuleConfigurationDialogEnableCMSInitiatedCheckboxIs(string p0)
        {
            By check = By.CssSelector("[test-id='editAction-checkbox-cmsInitiated']");

            if(p0.ToLower().Equals("checked"))
            {
                if(Browser.Wd.FindElement(check).Selected)
                {
                    fw.ConsoleReport(" Check box is already selected");
                }
                else
                {
                    AngularFunction.clickOnElement(check);
                }
            }
            else
            {
                if (!Browser.Wd.FindElement(check).Selected)
                {
                    fw.ConsoleReport(" Check box is already not selected");
                }
                else
                {
                    AngularFunction.clickOnElement(check);
                }
            }
           
        }

        [When(@"I havigated to EAM ""(.*)"" menu ""(.*)"" sub menu ""(.*)"" sub menu")]
        public void WhenIHavigatedToEAMMenuSubMenuSubMenu(string p0, string p1, string p2)
        {
            By ele1 = By.CssSelector("[title='Administration']");
            AngularFunction.clickOnElement(ele1);
            By ele2 = By.XPath("//span[contains(.,'TRR Configuration')]");
            AngularFunction.clickOnElement(ele2);
            By ele3 = By.XPath("//span[contains(.,'Rules Level')]");
            AngularFunction.clickOnElement(ele3);
        }

        [When(@"Rules Level page Select TC as ""(.*)"" TRC as ""(.*)"" and Click on Search button")]
        public void WhenRulesLevelPageSelectTCAsTRCAsAndClickOnSearchButton(string tc, string trc)
        {
            By tcDrp = By.XPath("//kendo-dropdownlist[@test-id='actLevelSearch-select-tranCodes']//span[@class='k-select']");
            By trcDrp = By.XPath("//kendo-multiselect[@test-id='actLevelSearch-slct-tranReplyCodes']//input[@class='k-input']");
            By srchButton = By.XPath("//button[@test-id='actLevelSearch-button-search']//span[contains(.,'SEARCH')]");

            AngularFunction.selectKendoDropDownValue(tcDrp,tc);
            AngularFunction.sendKeysWithOutClear(trcDrp,trc);
            AngularFunction.sendKeysWithOutClear(trcDrp, Keys.Tab);
            AngularFunction.clickOnElement(srchButton);

        }

        [When(@"Edit TRR Rule Configuration dialog Forced Letter ""(.*)"" is selected")]
        public void WhenEditTRRRuleConfigurationDialogForcedLetterIsSelected(string p0)
        {
            string lettername = tmsCommon.GenerateData(p0);

            By letter = By.XPath("//kendo-multiselect[@test-id='addField-slct-fields']//input");
            AngularFunction.selectMultiSelectDropDown(letter,lettername);
        }

        [When(@"Rules Level page TC ""(.*)"" TRC ""(.*)"" Action ""(.*)"" record action button is Clicked")]
        public void WhenRulesLevelPageTCTRCActionRecordActionButtonIsClicked(string p0, string p1, string p2)
        {
            string tc = tmsCommon.GenerateData(p0);
            string trc = tmsCommon.GenerateData(p1);
            string action = tmsCommon.GenerateData(p2);


            By grid = By.XPath("//kendo-grid[@test-id='actLvlConfg-grid-mandatoryActionGrid']//td[contains(.,'"+ tc + "')]/following-sibling::td[contains(.,'"+trc+"')]/following-sibling::td[contains(.,'"+action+"')]/following-sibling::td/a");
            AngularFunction.clickOnElement(grid);
        }


        [When(@"View Edit Member Page Save button is Clicked")]
        public void WhenViewEditMemberPageSaveButtonIsClicked()
        {
            By save = By.XPath("//span[@test-id='memberViewEdit-spn-save'][contains(.,'SAVE')]");
            AngularFunction.clickOnElement(save);
            tmsWait.Hard(2);
            AngularFunction.clickOnYESonConfirmationDialog();
        }


        [When(@"I delete existing Adminstration Add MMP table rows")]
        public void WhenIDeleteExistingAdminstrationAddMMPTableRows()
        {
            ICollection<IWebElement> myImages = null;
            try
            {
                myImages = EAM.AdministrationMMP.ParametersTable.FindElements(By.TagName("input"));
            }
            catch { }
            while (myImages != null && myImages.Count > 0)
            {
                foreach (IWebElement thisImage in myImages)
                {
                    string thisId = thisImage.GetAttribute("Id");
                    if (thisId.Contains("btnDelete"))
                    {
                        thisImage.Click();
                        EAM.AdministrationMMP.DeleteThisRuleOkButton.Click();
                        tmsWait.Hard(2);
                        tmsWait.WaitForReadyStateComplete(30);
                        break;
                    }
                }
                myImages = EAM.AdministrationMMP.ParametersTable.FindElements(By.TagName("input"));
            }
        }
        [When(@"Administration Add MMP MMP State is set to ""(.*)""")]
        public void WhenAdministrationAddMMPMMPStateIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            SelectElement MMPStateDropdown = new SelectElement(EAM.AdministrationMMP.MMPState);
            MMPStateDropdown.SelectByText(p0);
            tmsWait.Hard(2);
            //          tmsWait.WaitForReadyStateComplete(30);
        }

        [When(@"I have navigated to EAM Administration section")]
        public void WhenIHaveNavigatedToEAMAdministrationSection()
        {
            By menu = By.CssSelector("[title='Administration']");
            AngularFunction.clickOnElement(menu);
        }

       

        [When(@"I have navigated EAM Administration menu ""(.*)"" sub menu")]
        public void WhenIHaveNavigatedEAMAdministrationMenuSubMenu(string p0)
        {
            string submenu= tmsCommon.GenerateData(p0);
            By menu = By.XPath("//span[contains(.,'"+ submenu + "')]");
            AngularFunction.clickOnElement(menu);
        }

        [When(@"View Edit TRC page TRC is set to ""(.*)""")]
        public void WhenViewEditTRCPageTRCIsSetTo(string p0)
        {
            EAM.ViewEditTRC.TRCDrp.SendKeys(p0);
            tmsWait.Hard(2);
            AngularFunction.clickOnDropDownValue(p0);
        }

        [When(@"View Edit TRC page Click on Search button")]
        public void WhenViewEditTRCPageClickOnSearchButton()
        {
            AngularFunction.clickOnElement(EAM.ViewEditTRC.SearchButton);
        }

        [Then(@"View Edit TRC page Click on Cancel button")]
        public void ThenViewEditTRCPageClickOnCancelButton()
        {
            AngularFunction.clickOnElement(EAM.ViewEditTRC.CANCELButton);
        }

        [When(@"Rules Level page User Rules section is Clicked")]
        public void WhenRulesLevelPageUserRulesSectionIsClicked()
        {
            AngularFunction.clickOnElement(EAM.ViewEditTRC.UserRulesSection);
        }

        [When(@"Rules Level page Reset button is Clicked")]
        public void WhenRulesLevelPageResetButtonIsClicked()
        {
            AngularFunction.clickOnElement(EAM.RulesLevel.RESETButton);
        }


        [When(@"Fields Level page TC is set to ""(.*)""")]
        public void WhenFieldsLevelPageTCIsSetTo(string p0)
        {
            AngularFunction.selectKendoDropDownValue(EAM.FieldsLevel.TCDrp, p0);
        }

        [When(@"Rules Level page TC is set to ""(.*)""")]
        public void WhenRulesLevelPageTCIsSetTo(string p0)
        {
            AngularFunction.selectKendoDropDownValue(EAM.RulesLevel.TCDrp, p0);
        }

        [When(@"Rules Level page TRC is set to ""(.*)""")]
        public void WhenRulesLevelPageTRCIsSetTo(string p0)
        {
            EAM.RulesLevel.TRCDrp.SendKeys(p0);
            tmsWait.Hard(2);
            AngularFunction.clickOnDropDownValue(p0);
        }

        [When(@"Rules Level page Search button is Clicked")]
        public void WhenRulesLevelPageSearchButtonIsClicked()
        {
            AngularFunction.clickOnElement(EAM.RulesLevel.SearchButton);
        }


        [When(@"Fields Level page TRC is set to ""(.*)""")]
        public void WhenFieldsLevelPageTRCIsSetTo(string p0)
        {
            AngularFunction.selectKendoDropDownValue(EAM.FieldsLevel.TRCDrp, p0);
        }

        [When(@"Fields Level page TRC Field is set to ""(.*)""")]
        public void WhenFieldsLevelPageTRCFieldIsSetTo(string p0)
        {
            EAM.FieldsLevel.Field.SendKeys(p0);
            tmsWait.Hard(2);
            AngularFunction.clickOnDropDownValue(p0);
        }

        [When(@"Fields Level page Search button is Clicked")]
        public void WhenFieldsLevelPageSearchButtonIsClicked()
        {
            AngularFunction.clickOnElement(EAM.FieldsLevel.SearchButton);
        }

        [When(@"Fields Level page Cancel button is Clicked")]
        public void WhenFieldsLevelPageCancelButtonIsClicked()
        {
            AngularFunction.clickOnElement(EAM.FieldsLevel.CANCELButton);
        }

        [Then(@"Verify Fields Level page displayed TC as ""(.*)"" TRC as ""(.*)"" Field as ""(.*)"" Transaction Type as ""(.*)""")]
        public void ThenVerifyFieldsLevelPageDisplayedTCAsTRCAsFieldAsTransactionTypeAs(string p0, string p1, string p2, string p3)
        {
            string tc = tmsCommon.GenerateData(p0);
            string trc = tmsCommon.GenerateData(p1);
            string field = tmsCommon.GenerateData(p2);
            string tctype = tmsCommon.GenerateData(p3);

            By ele = By.XPath("//kendo-grid[@test-id='trrConfigurationFieldSearchField-grid-dgFieldsConfiguration']//td[contains(.,'"+tc+"')]/following-sibling::td[contains(.,'"+trc+"')]/following-sibling::td[contains(.,'"+field+"')]/following-sibling::td[contains(.,'"+ tctype + "')]");
            AngularFunction.elementPresenceUsingLocators(ele);
            
        }

        [Then(@"Verify Rules Level page TC as ""(.*)"" TRC as ""(.*)"" Action as ""(.*)""")]
        public void ThenVerifyRulesLevelPageTCAsTRCAsActionAs(string p0, string p1, string p2)
        {
            string tc = tmsCommon.GenerateData(p0);
            string trc = tmsCommon.GenerateData(p1);
            string action = tmsCommon.GenerateData(p2);
           

            By ele = By.XPath("//kendo-grid[@test-id='actLvlConfg-grid-mandatoryActionGrid']//td[contains(.,'" + tc + "')]/following-sibling::td[contains(.,'" + trc + "')]/following-sibling::td[contains(.,'" + action + "')]");
            AngularFunction.elementPresenceUsingLocators(ele);
        }

        [Then(@"Verify Rules Level page User Rules section TC as ""(.*)"" TRC as ""(.*)"" Action as ""(.*)"" CMS Initiated as ""(.*)"" Plan Initiated as ""(.*)""")]
        public void ThenVerifyRulesLevelPageUserRulesSectionTCAsTRCAsActionAsCMSInitiatedAsPlanInitiatedAs(string p0, string p1, string p2, string p3, string p4)
        {
          
            string tc = tmsCommon.GenerateData(p0);
            string trc = tmsCommon.GenerateData(p1);
            string action = tmsCommon.GenerateData(p2);
            string cms = tmsCommon.GenerateData(p3);
            string plan = tmsCommon.GenerateData(p4);

            By ele = By.XPath("//kendo-grid[@test-id='actLvlConfg-grid-userActionGrid']//td[contains(.,'" + tc + "')]/following-sibling::td[contains(.,'" + trc + "')]/following-sibling::td[contains(.,'" + action + "')]/following-sibling::td[contains(.,'" + cms + "')]/following-sibling::td[contains(.,'" + plan + "')]");
            AngularFunction.elementPresenceUsingLocators(ele);
        }

        [Then(@"Verify Fields Level page displayed message as ""(.*)""")]
        public void ThenVerifyFieldsLevelPageDisplayedMessageAs(string p0)
        {
            By ele = By.XPath("//kendo-grid[@test-id='trrConfigurationFieldSearchField-grid-dgFieldsConfiguration']//td[contains(.,'"+ p0 + "')]");
            AngularFunction.elementPresenceUsingLocators(ele);
        }



        [Then(@"Verify View Edit TRC page Search results display TRC as ""(.*)"" Title as ""(.*)"" Type as ""(.*)"" Short Description as ""(.*)"" Plan Action as ""(.*)""")]
        public void ThenVerifyViewEditTRCPageSearchResultsDisplayTRCAsTitleAsTypeAsShortDescriptionAsPlanActionAs(string p0, string p1, string p2, string p3, string p4)
        {
            string trc = tmsCommon.GenerateData(p0);
            string Title = tmsCommon.GenerateData(p1);
            string type = tmsCommon.GenerateData(p2);
            string shortdes = tmsCommon.GenerateData(p3);
            string planaction = tmsCommon.GenerateData(p4);

            By ele = By.XPath("//kendo-grid[@test-id='viewEditTrc-grid-trcGrid']//td[contains(.,'"+trc+"')]/following-sibling::td[contains(.,'"+ Title + "')]/following-sibling::td[contains(.,'"+type+"')]/following-sibling::td[contains(.,'"+shortdes+"')]/following-sibling::td[contains(.,'"+ planaction + "')]");
            AngularFunction.elementPresenceUsingLocators(ele);
        }


        [When(@"TRR Activity Logging page File Name Drop down is selected as  ""(.*)""")]
        public void WhenTRRActivityLoggingPageFileNameDropDownIsSelectedAs(string p0)
        {
            string fileName = tmsCommon.GenerateData(p0);

            EAM.TRRActivityLogging.FileNameSearchBar.SendKeys(fileName);
            tmsWait.Hard(2);
            By file = By.XPath("//li[contains(.,'"+ fileName + "')]");
            AngularFunction.clickOnElement(file);
        }

        [When(@"TRR Activity Logging page Beneficiary ID is set to  ""(.*)""")]
        public void WhenTRRActivityLoggingPageBeneficiaryIDIsSetTo(string p0)
        {
            string mbi = tmsCommon.GenerateData(p0);
            AngularFunction.sendKeysWithClear(EAM.TRRActivityLogging.BeneficiaryID, mbi);
        }

        [When(@"TRR Activity Logging page Keyword is set to  ""(.*)""")]
        public void WhenTRRActivityLoggingPageKeywordIsSetTo(string p0)
        {
            AngularFunction.sendKeysWithClear(EAM.TRRActivityLogging.Keyword, p0);
        }

        [When(@"TRR Activity Logging page Search button is Clicked")]
        public void WhenTRRActivityLoggingPageSearchButtonIsClicked()
        {
            AngularFunction.clickOnElement(EAM.TRRActivityLogging.SearchButton);
        }

        [Then(@"Verify TRR Activity Logging page displayed Message as ""(.*)""")]
        public void ThenVerifyTRRActivityLoggingPageDisplayedMessageAs(string p0)
        {
            By ele = By.XPath("//kendo-grid//tr/td[@aria-colindex='4'][contains(.,'" + p0 + "')]");

            AngularFunction.elementPresenceUsingLocators(ele);
        }


        [When(@"EAM Administration Menu ""(.*)"" submenu is Clicked")]
        public void WhenEAMAdministrationMenuSubmenuIsClicked(string menu)
        {

            By loc = By.CssSelector("[title='" + menu + "']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            tmsWait.Hard(3);
        }

        [When(@"EAM Administration Menu ""(.*)"" submenu displayed")]
        public void WhenEAMAdministrationMenuSubmenuDisplayed(string menu)
        {
            By loc = By.CssSelector("[title='" + menu + "']");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
            tmsWait.Hard(3);
        }

        [Then(@"Verify EAM UI MOD Application displayed ""(.*)"" page successfully")]
        public void ThenVerifyEAMUIMODApplicationDisplayedPageSuccessfully(string page)
        {
            tmsWait.Hard(3);
            By loc = By.XPath("(//span[contains(.,'" + page + "')])[1]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }
        [Then(@"Verify EAM UI Application displayed ""(.*)"" page successfully")]
        public void ThenVerifyEAMUIApplicationDisplayedPageSuccessfully(string page)
        {
            tmsWait.Hard(3);
            By loc = By.XPath("(//span[contains(.,'" + page + "')])[2]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }

        [Then(@"Verify EAM UI MOD Application displayed All ""(.*)"" page successfully")]
        public void ThenVerifyEAMUIMODApplicationDisplayedAllPageSuccessfully(string p0)
        {
            tmsWait.Hard(3);
            By loc = By.XPath("//span[contains(@test-id,'letter-span-letters')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }


        [When(@"Administration Add MMP Plan ID is set to ""(.*)""")]
        public void WhenAdministrationAddMMPPlanIDIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            SelectElement MMPPlanIdDropDown = new SelectElement(EAM.AdministrationMMP.PlanID);
            MMPPlanIdDropDown.SelectByText(p0);

            tmsWait.Hard(2);
            //            tmsWait.WaitForReadyStateComplete(30);
        }
        [Then(@"Verify EAM """"(.*)"" section has valid grid count and pagination and ""(.*)"" and ""(.*)"" button displayed")]
        public void ThenVerifyEAMSectionHasValidGridCountAndPaginationAndAndButtonDisplayed(string p0, string p1, string p2)
        {

            By export = By.XPath("//button[@test-id='reviewQueue-btn-export']");
            UIMODUtilFunctions.elementPresenceUsingLocators(export);
            By completeAll = By.XPath("//button[@test-id='reviewQueue-btn-completeAll']");
            UIMODUtilFunctions.elementPresenceUsingLocators(completeAll);

        }
        [Then(@"Verify EAM """"(.*)"" section ""(.*)"" and ""(.*)"" button is disabled and has valid grid count ""(.*)""")]
        public void ThenVerifyEAMSectionAndButtonIsDisabledAndHasValidGridCount(string p0, string p1, string p2, string p3)
        {


            By export = By.XPath("//button[@test-id='reviewQueue-btn-export']");
            UIMODUtilFunctions.elementEnableUsingLocators(export);
            By completeAll = By.XPath("//button[@test-id='reviewQueue-btn-completeAll']");
            UIMODUtilFunctions.elementEnableUsingLocators(completeAll);


        }
        [Then(@"Verify EAM """"(.*)"" section ""(.*)"" and ""(.*)"" button are ""(.*)"" and has valid grid count ""(.*)""")]
        public void ThenVerifyEAMSectionAndButtonAreAndHasValidGridCount(string p0, string p1, string p2, string p3, string p4)
        {
            String actualstatus = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Total Actions')]")).Text;

            tmsWait.Hard(2);

            string[] Actual = actualstatus.Split(' ');


            if (Int32.Parse(Actual[2]) == 0)
            {

                By export = By.XPath("//button[@test-id='reviewQueue-btn-export']");
                UIMODUtilFunctions.elementEnableUsingLocators(export);
                By completeAll = By.XPath("//button[@test-id='reviewQueue-btn-completeAll']");
                UIMODUtilFunctions.elementEnableUsingLocators(completeAll);
            }
            else
            {
                By export = By.XPath("//button[@test-id='reviewQueue-btn-export']");
                UIMODUtilFunctions.elementDisableUsingLocators(export);
                By completeAll = By.XPath("//button[@test-id='reviewQueue-btn-completeAll']");
                UIMODUtilFunctions.elementDisableUsingLocators(completeAll);
            }


        }

        [Then(@"Verify EAM ""(.*)"" section has redirected to valid  Transaction view edit page")]
        public void ThenVerifyEAMSectionHasRedirectedToValidTransactionViewEditPage(string p0)
        {
            tmsWait.Hard(3);
            SelectElement MMPPBPDropdown = new SelectElement(EAM.AdministrationMMP.PBP);
            MMPPBPDropdown.SelectByIndex(1);
            tmsWait.Hard(2);
        }

        [Then(@"Verify EAM ""(.*)"" section has toater message ""(.*)""")]
        public void ThenVerifyEAMSectionHasToaterMessage(string p0, string p1)
        {

        }
        [Then(@"Verify EAM ""(.*)"" section has serach grid as blank and total records as ""(.*)"" and buttons are disabled")]
        public void ThenVerifyEAMSectionHasSerachGridAsBlankAndTotalRecordsAsAndButtonsAreDisabled(string p0, int p1)
        {

        }


        [When(@"Administration Add MMP Plan ID is set to first from drop down")]
        public void WhenAdministrationAddMMPPlanIDIsSetToFirstFromDropDown()
        {
            tmsWait.Hard(3);
            SelectElement MMPPlanIdDropDown = new SelectElement(EAM.AdministrationMMP.PlanID);
            MMPPlanIdDropDown.SelectByIndex(1);
            tmsWait.Hard(2);
        }
        [When(@"EAM Actions page ""(.*)"" section for ""(.*)""  transaction id ""(.*)"" button is clicked")]
        public void WhenEAMActionsPageSectionForTransactionIdButtonIsClicked(string p0, string p1, string p2)
        {
            tmsWait.Hard(3);
            IWebElement actualstatus = Browser.Wd.FindElement(By.XPath("(//a[@title='View'])[" + p1 + "]"));
            GlobalRef.TransactionId =Browser.Wd.FindElement(By.XPath("(//a[@title='View'])[" + p1 + "]/parent::td/preceding-sibling::td[2]")).Text.ToString();
            actualstatus.Click();

            tmsWait.Hard(3);
        }
        [Then(@"Verify EAM """"(.*)"" section has valid UI for new window ""(.*)""")]
        public void ThenVerifyEAMSectionHasValidUIForNewWindow(string p0, string p1)
        {
            IWebElement save = Browser.Wd.FindElement(By.XPath("//button[@test-id='updateAction-btn-add']"));
            Assert.IsTrue(save.Displayed);
            IWebElement close = Browser.Wd.FindElement(By.XPath("//button[@test-id='Close-btn-cancel']"));
            Assert.IsTrue(close.Displayed);

            IWebElement date = Browser.Wd.FindElement(By.XPath("//input[@test-id='CompletionDate-txt-completion']"));
            Assert.IsTrue(date.Displayed);

            //button[@test-id='Close-btn-cancel']
        }
        [Then(@"EAM """"(.*)"" section window ""(.*)"" and ""(.*)"" button is clicked")]
        public void ThenEAMSectionWindowAndButtonIsClicked(string p0, string p1, string p2)
        {


            switch (p2.ToLower())
            {
                case "save":
                    {
                        IWebElement save = Browser.Wd.FindElement(By.XPath("//button[@test-id='updateAction-btn-add']"));
                        save.Click();
                        break;

                    }
                case "close":
                    {
                        IWebElement save = Browser.Wd.FindElement(By.XPath("//button[@test-id='Close-btn-cancel']"));
                        save.Click();
                        break;

                    }


            }
            tmsWait.Hard(3);
        }


        [Then(@"EAM """"(.*)"" section new window ""(.*)"" is set to ""(.*)""")]
        public void ThenEAMSectionNewWindowIsSetTo(string p0, string p1, string p2)
        {
            IWebElement date = Browser.Wd.FindElement(By.XPath("//input[@test-id='CompletionDate-txt-completion']"));
            // date.SendKeys(p2);
            tmsWait.Hard(2);
            date.Clear();
            tmsWait.Hard(1);
            date.Click();
            tmsWait.Hard(2);
            date.SendKeys(p2);
            tmsWait.Hard(1);

        }
        [Then(@"verify error msg ""(.*)""")]
        public void ThenVerifyErrorMsg(string p0)
        {
            IWebElement date = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]"));
            Assert.IsTrue(date.Displayed);

        }


        [When(@"EAM Actions page ""(.*)"" section ""(.*)"" button is clicked")]
        public void WhenEAMActionsPageSectionButtonIsClicked(string p0, string p1)
        {
            tmsWait.Hard(3);
            switch (p1.ToLower())
            {
                case "search":
                    {
                        IWebElement actualstatus = Browser.Wd.FindElement(By.XPath("//button[@test-id='reviewQueue-btn-search']"));
                        actualstatus.Click();
                        break;
                    }

                case "completed all":
                    {
                        IWebElement actualstatus = Browser.Wd.FindElement(By.XPath("//label[contains(.,'all button will select entire table data grid.')]/preceding-sibling::i/preceding-sibling::button[@test-id='reviewQueue-btn-completeAll']"));
                        actualstatus.Click();
                        break;
                    }
                case "export":
                    {
                        IWebElement actualstatus = Browser.Wd.FindElement(By.XPath("//button[@test-id='reviewQueue-btn-export']"));
                        actualstatus.Click();
                        break;
                    }

                case "no":
                    {
                        IWebElement actualstatus = Browser.Wd.FindElement(By.XPath("//button[@test-id='Close-btn-cancel']"));
                        actualstatus.Click();
                        break;
                    }

                case "yes":
                    {
                        IWebElement actualstatus = Browser.Wd.FindElement(By.XPath("//button[@test-id='updateAction-btn-add']"));
                        actualstatus.Click();
                        break;
                    }
            }


            tmsWait.Hard(3);

        }
        [Then(@"Verify EAM """"(.*)"" section has All actions ""(.*)"" as ""(.*)""")]
        public void ThenVerifyEAMSectionHasAllActionsAs(string p0, string p1, string p2)
        {

            switch (p1)
            {
                case "Total Actions":
                    {
                        //label[contains(.,'Total Actions')]
                        String actualstatus = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Total Actions')]")).Text;

                        tmsWait.Hard(2);
                        String totalItme = Browser.Wd.FindElement(By.XPath("//span[contains(.,'items')]")).Text;
                        tmsWait.Hard(2);
                        string[] Actual = actualstatus.Split(' ');
                        string[] Expected = totalItme.Split(' ');
                        GlobalRef.TotalAction = Actual[2].ToString();
                        Assert.IsTrue(Actual[2].Equals(Expected[4]));
                        break;
                    }
                case "Complete All":
                    {
                        tmsWait.Hard(2);
                        IWebElement actualstatus = Browser.Wd.FindElement(By.XPath("//label[contains(.,'all button will select entire table data grid.')]/preceding-sibling::i/preceding-sibling::button[@test-id='reviewQueue-btn-completeAll']"));
                        Assert.IsTrue(actualstatus.Displayed);
                        break;
                    }
                case "Completed Column":
                    {
                        tmsWait.Hard(2);
                        IWebElement icon = Browser.Wd.FindElement(By.XPath("//a[@title='View']"));
                        Assert.IsTrue(icon.Displayed);
                        break;
                    }

            }
        }



        [Then(@"Verify EAM """"(.*)"" section has All actions created between ""(.*)"" and ""(.*)""")]
        public void ThenVerifyEAMSectionHasAllActionsCreatedBetweenAnd(string p0, string p1, string p2)
        {
            tmsWait.Hard(3);


            IList<IWebElement> count;
            String str = Browser.Wd.FindElement(By.XPath("//span[@class='k-pager-input k-label']")).Text;

            string[] st = str.Split(' ');
            for (int i = 1; i < Int32.Parse(st[1]); i++)
            {
                List<IWebElement> todate = new List<IWebElement>();
                List<string> text = new List<string>();
                count = Browser.Wd.FindElements(By.XPath("//div[@test-id='reviewQueue-grid-reviewQueueGrid']//tr"));

                for (int j = 1; j < count.Count; j++)
                {
                    todate.Add(Browser.Wd.FindElement(By.XPath("//div[@test-id='reviewQueue-grid-reviewQueueGrid']//tr[" + j + "]/td[5]")));

                }

                text = TMSoR1.FrameworkCode.HCC_RAM.OnHoldFunctionality.ConvertWebElementInToStringg(todate);

                DateTime oDate = DateTime.Parse(p1);
                foreach (String t in text)
                {
                    DateTime tDate = DateTime.Parse(t);
                    Assert.IsTrue(oDate <= tDate);
                }
                tmsWait.Hard(3);
                IWebElement NEXT = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                //   NEXT.Click();
                fw.ExecuteJavascript(NEXT);
                tmsWait.Hard(3);

            }




        }


        [When(@"Administration Add MMP PBP is set to first from drop down")]
        public void WhenAdministrationAddMMPPBPIsSetToFirstFromDropDown()
        {

            tmsWait.Hard(3);
            SelectElement MMPPBPDropdown = new SelectElement(EAM.AdministrationMMP.PBP);
            MMPPBPDropdown.SelectByIndex(1);
            tmsWait.Hard(2);
        }

        [When(@"Administration Possible out of area status New status is set to ""(.*)""")]
        public void WhenAdministrationPossibleOutOfAreaStatusNewStatusIsSetTo(string p0)
        {
            string NewStatus = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFieldsOOATab.NewStatus.SendKeys(NewStatus);
            EAM.AdministrationPlanDefinedFieldsOOATab.AddStatus.Click();
            tmsWait.Hard(2);
        }

        [When(@"Administration OOA Out of Area configuration Plan Id is set to ""(.*)""")]
        public void WhenAdministrationOOAOutOfAreaConfigurationPlanIdIsSetTo(string p0)
        {
            SelectElement PlanId = new SelectElement(EAM.AdministrationPlanDefinedFieldsOOATab.PlanId);
            PlanId.SelectByText(p0);
            tmsWait.Hard(2);
        }

        [Then(@"Administration OOA Out of Area configuration Plan Id default value is set to ""(.*)""")]
        public void ThenAdministrationOOAOutOfAreaConfigurationPlanIdDefaultValueIsSetTo(string p0)
        {
            SelectElement PlanId = new SelectElement(EAM.AdministrationPlanDefinedFieldsOOATab.PlanId);
            if (PlanId.SelectedOption.Text == p0)
            {
                Assert.AreEqual(PlanId.SelectedOption.Text, p0, "Passed" + " " + "PlanId value reset to Select on Tab change");
            }
            else
            {
                Assert.Fail("PlanId {0} NOT reset to {1} on Tab change", p0, PlanId.SelectedOption.Text);
            }

        }


        [When(@"Administration OOA Out of Area configuration Disenrollment Months is set to ""(.*)""")]
        public void WhenAdministrationOOAOutOfAreaConfigurationDisenrollmentMonthsIsSetTo(string p0)
        {
            SelectElement DisenrollmentMonths = new SelectElement(EAM.AdministrationPlanDefinedFieldsOOATab.DisEnrollmentMonths);
            DisenrollmentMonths.SelectByText(p0);
            tmsWait.Hard(2);
        }

        [When(@"Administration OOA Out of Area configuration Continuation Area is set to ""(.*)""")]
        public void WhenAdministrationOOAOutOfAreaConfigurationContinuationAreaIsSetTo(string p0)
        {
            string GenerateData = tmsCommon.GenerateData(p0);
            tmsWait.Hard(2);

            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("unchecked"))
            {

                if (EAM.AdministrationPlanDefinedFieldsOOATab.ContinuationArea.Selected == true)
                {
                    EAM.AdministrationPlanDefinedFieldsOOATab.ContinuationArea.Click();
                }

            }
            else if (setCheckboxTo.Equals("checked"))
            {
                if (EAM.AdministrationPlanDefinedFieldsOOATab.ContinuationArea.Selected == false)
                {
                    EAM.AdministrationPlanDefinedFieldsOOATab.ContinuationArea.Click();
                }
            }
        }

        [When(@"Administration OOA Out of Area configuration Travellers/Visitors is set to ""(.*)""")]
        public void WhenAdministrationOOAOutOfAreaConfigurationTravellersVisitorsIsSetTo(string p0)
        {
            string GenerateData = tmsCommon.GenerateData(p0);
            tmsWait.Hard(2);

            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("unchecked"))
            {

                if (EAM.AdministrationPlanDefinedFieldsOOATab.Travellers.Selected == true)
                {
                    EAM.AdministrationPlanDefinedFieldsOOATab.Travellers.Click();
                }

            }
            else if (setCheckboxTo.Equals("checked"))
            {
                if (EAM.AdministrationPlanDefinedFieldsOOATab.Travellers.Selected == false)
                {
                    EAM.AdministrationPlanDefinedFieldsOOATab.Travellers.Click();
                }
            }
        }

        [When(@"Administration OOA Out of Area configuration ICEP Conversion is set to ""(.*)""")]
        public void WhenAdministrationOOAOutOfAreaConfigurationICEPConversionIsSetTo(string p0)
        {
            string GenerateData = tmsCommon.GenerateData(p0);
            tmsWait.Hard(2);

            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("unchecked"))
            {

                if (EAM.AdministrationPlanDefinedFieldsOOATab.ICEPConversion.Selected == true)
                {
                    EAM.AdministrationPlanDefinedFieldsOOATab.ICEPConversion.Click();
                }

            }
            else if (setCheckboxTo.Equals("checked"))
            {
                if (EAM.AdministrationPlanDefinedFieldsOOATab.ICEPConversion.Selected == false)
                {
                    EAM.AdministrationPlanDefinedFieldsOOATab.ICEPConversion.Click();
                }
            }
        }



        [When(@"Administration OOA Out of Area configuration Update is clicked")]
        public void WhenAdministrationOOAOutOfAreaConfigurationUpdateIsClicked()
        {
            fw.ExecuteJavascript(EAM.AdministrationPlanDefinedFieldsOOATab.Update);
            tmsWait.Hard(2);
        }
        [Then(@"Verify Out of Area Configuration Area table has Plan ID as ""(.*)"" Disenrollment Months as ""(.*)""")]
        public void ThenVerifyOutOfAreaConfigurationAreaTableHasPlanIDAsDisenrollmentMonthsAs(string planid, string dis)
        {
            tmsWait.Hard(5);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                //div[@role='presentation']//td[contains(.,'" + planid + "')]//following-sibling::td[contains(.,'" + dis + "')]
                string xpath = "//div[@role='presentation']//td[contains(.,'" + planid + "')]//following-sibling::td[contains(.,'" + dis + "')]";
                ReUsableFunctions.verifyGridElementPresence(xpath);
            }
            else
            {


                IWebElement element = Browser.Wd.FindElement(By.XPath("//div[@test-id='ooa-grid-ooaConfiguration']//tr/td[contains(.,'" + planid + "')]//following-sibling::td/span[contains(.,'" + dis + "')]"));
                tmsWait.Hard(2);
                bool actualResults = element.Displayed;
                Assert.IsTrue(actualResults, "Expected results are not getting displayed");
            }
        }


        [Then(@"Verify Out of Area Configuration Area table has the below row")]
        public void ThenVerifyOutOfAreaConfigurationAreaTableHasTheBelowRow(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.AdministrationPlanDefinedFieldsOOATab.OutofAreaGrid;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Members View Edit Table has row: {0}", e.Message);
            }
        }



        [Then(@"Verify the message ""(.*)""")]
        public void ThenVerifyTheMessage(string p0)
        {
            {
                p0 = tmsCommon.GenerateData(p0);
                IWebElement saved = EAM.AdministrationPlanDefinedFieldsOOATab.ChangesSaved;
                string savemessage = saved.Text.ToString();
                Assert.AreEqual(savemessage, p0, "View Edit Plan info page message expected [" + p0 + "], found [" + savemessage + "]");
            }
        }

        [Then(@"Verify the integration message ""(.*)"" is displayed")]
        public void ThenVerifyTheIntegrationMessageIsDisplayed(string p0)
        {
            {
                tmsWait.Hard(2);
                p0 = tmsCommon.GenerateData(p0);
                string fieldValue = EAM.AdministrationExternalIntegrationmessage.QNXTmessage.Text;
                string subs = fieldValue.Substring(0, 24);
                Assert.AreEqual(p0, fieldValue.Substring(0, 24));
            }
        }
        [Then(@"Verify the integration expression message ""(.*)"" is displayed")]
        public void ThenVerifyTheIntegrationexpressionMessageIsDisplayed(string p0)
        {
            {
                tmsWait.Hard(2);
                p0 = tmsCommon.GenerateData(p0);
                string fieldValue = EAM.AdministrationExternalIntegrationexpressionmessage.QNXTmessageexpression.Text;
                string subs = fieldValue.Substring(0, 13);
                Assert.AreEqual(p0, fieldValue.Substring(0, 13));
            }
        }


        [Then(@"Verify New OOA Status ""(.*)"" id displayed in the grid")]
        public void ThenVerifyNewOOAStatusIdDisplayedInTheGrid(string p0)
        {
            string ooastatus = tmsCommon.GenerateData(p0);
            IWebElement actualstatus = Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + ooastatus + "')]"));
            Assert.IsTrue(actualstatus.Displayed);
        }


        [Then(@"Verify the New OOA Status table has row")]
        public void ThenVerifyTheNewOOAStatusTableHasRow(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.AdministrationPlanDefinedFieldsOOATab.ViewOOAStatus;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row was not found: {0}", arrRes[i, 1]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Verify Letters Table has row: {0}", e.Message);
            }
        }



        [When(@"Administration Add MMP PBP is set to ""(.*)""")]
        public void WhenAdministrationAddMMPPBPIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            p0 = tmsCommon.GenerateData(p0);
            SelectElement MMPPBPDropdown = new SelectElement(EAM.AdministrationMMP.PBP);
            MMPPBPDropdown.SelectByText(p0);
            tmsWait.Hard(2);
            //            tmsWait.WaitForReadyStateComplete(30);
        }

        [When(@"Administration Add MMP Transaction Code is set to ""(.*)""")]
        public void WhenAdministrationAddMMPTransactionCodeIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            SelectElement MMPTransactionCodeDropdown = new SelectElement(EAM.AdministrationMMP.TransactionCode);
            MMPTransactionCodeDropdown.SelectByText(p0);
            tmsWait.Hard(2);
            //tmsWait.WaitForReadyStateComplete(30);
        }

        [When(@"Administration Add MMP Transaction Status is set to ""(.*)""")]
        public void WhenAdministrationAddMMPTransactionStatusIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            SelectElement MMPTransactionStatusDropdown = new SelectElement(EAM.AdministrationMMP.TransactionStatus);
            MMPTransactionStatusDropdown.SelectByText(p0);
            tmsWait.Hard(2);

            //tmsWait.WaitForReadyStateComplete(30);
        }
        [When(@"Administration Add MMP TRC is set to ""(.*)""")]
        [Given(@"Administration Add MMP TRC is set to ""(.*)""")]
        public void WhenAdministrationAddMMPTRCIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            //    tmsWait.WaitForElementAttributeHasValue(By.XPath("//*[contains(@id, 'ctl00_ctl00_MainMasterContent_MainContent_vMmpStateTransactions_uc_ddlDefTransRepCode')]"), 30, "isDisabled", "false");
            SelectElement DropDownElement = new SelectElement(EAM.AdministrationMMP.TRC);
            DropDownElement.SelectByText(p0);
            tmsWait.Hard(2);
            //            tmsWait.WaitForReadyStateComplete(30);
        }

        [When(@"Administration Add MMP Effective Date is set to ""(.*)""")]
        public void WhenAdministrationAddMMPEffectiveDateIsSetTo(string p0)
        {

            tmsWait.Hard(2);
            //tmsWait.WaitForReadyStateComplete(30);

            tmsWait.Hard(3);
            String strValue = tmsCommon.GenerateData(p0);
            strValue = strValue.Replace("/", "");
            IWebElement objEffDate = EAM.AdministrationMMP.EffectiveDate;
            objEffDate.Clear();
            tmsWait.Hard(3);
            objEffDate.SendKeys(strValue);


        }

        [When(@"Administration Add MMP Termination Date is set to ""(.*)""")]
        public void WhenAdministrationAddMMPTerminationDateIsSetTo(string p0)
        {
            tmsWait.Hard(1);

            tmsWait.Hard(3);
            String strValue = tmsCommon.GenerateData(p0);
            strValue = strValue.Replace("/", "");
            IWebElement objEffDate = EAM.AdministrationMMP.TerminationDate;
            objEffDate.Clear();
            tmsWait.Hard(3);
            objEffDate.SendKeys(strValue);



        }
        [When(@"Administration Add MMP table rows count before save button is clicked")]
        public void WhenAdministrationAddMMPTableRowsCountBeforeSaveButtonIsClicked()
        {



            IList<IWebElement> rows = Browser.Wd.FindElements(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_vMmpStateTransactions_uc_grdMmpStateTransactions']/tbody/tr"));
            // Console.WriteLine("Total no of "+rows.);
            GlobalRef.Bcount = rows.Count - 1;
            string c = GlobalRef.Bcount.ToString();
            Console.WriteLine("Total no of" + c);
        }

        [Then(@"Verify Administration Add MMP table rows count after save button is clicked")]
        public void ThenVerifyAdministrationAddMMPTableRowsCountAfterSaveButtonIsClicked()
        {



            tmsWait.Hard(3);


            IList<IWebElement> rows = Browser.Wd.FindElements(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_vMmpStateTransactions_uc_grdMmpStateTransactions']/tbody/tr"));
            GlobalRef.Acount = rows.Count - 1;
            string c0 = GlobalRef.Bcount.ToString();
            string c1 = GlobalRef.Acount.ToString();
            int i0 = int.Parse(c0);
            int i1 = int.Parse(c1);
            Console.WriteLine("Total no of After save Button is clicked" + c1);
            if (i1 > i0)
            {
                Console.WriteLine("Rule saved successfully");
            }
        }


        [When(@"Administration Add MMP Save Button is clicked")]
        public void WhenAdministrationAddMMPSaveButtonIsClicked()
        {
            tmsWait.Hard(4);
            fw.ExecuteJavascript(EAM.AdministrationMMP.Save);
            tmsWait.Hard(5);
        }
        [When(@"Administration Add MMP Reset Button is clicked")]
        public void WhenAdministrationAddMMPResetButtonIsClicked()
        {
            fw.ExecuteJavascript(EAM.AdministrationMMP.Reset);
            //EAM.AdministrationMMP.Reset.Click();
            tmsWait.Hard(2);
            //tmsWait.WaitForReadyStateComplete(30);
        }
        [When(@"Administration Add MMP Response Message ""(.*)"" is displayed")]
        public void WhenAdministrationAddMMPResponseMessageIsDisplayed(string p0)
        {
            string StaticMessage = EAM.AdministrationMMP.StaticMessage.Text;
            string StaticMessage2 = EAM.AdministrationMMP.StaticMessage2.Text;

            string expectedMessage = tmsCommon.GenerateData(p0);
            if (expectedMessage == StaticMessage || expectedMessage == StaticMessage2)
            {
                Console.WriteLine("Expected response Message [" + p0 + "], found response messages [" + StaticMessage + "], [" + StaticMessage2 + "]");
                Assert.AreEqual(true, true, "Expected response Message [" + p0 + "], found response messages [" + StaticMessage + "], [" + StaticMessage2 + "]");
            }
            else
            {
                Console.WriteLine("Expected response Message [" + p0 + "], found response messages [" + StaticMessage + "], [" + StaticMessage2 + "]");
                Assert.AreEqual(true, false, "Expected response Message [" + p0 + "], found response messages [" + StaticMessage + "], [" + StaticMessage2 + "]");
            }
        }

        [When(@"Administration Add MMP Static Message ""(.*)"" is displayed")]
        public void WhenAdministrationAddMMPStaticMessageIsDisplayed(string p0)
        {
            string StaticMessage, StaticMessage2;
            Boolean foundMessage = false;
            for (int i = 0; i < 100; i++)
            {

                if (EAM.AdministrationMMP.StaticMessage.Text.Length > 5 && !foundMessage)
                {
                    Console.WriteLine("[" + EAM.AdministrationMMP.StaticMessage.Text + "]");
                    foundMessage = true;
                }
            }
            StaticMessage = EAM.AdministrationMMP.StaticMessage.Text;
            StaticMessage2 = EAM.AdministrationMMP.StaticMessage2.Text;


            if (StaticMessage == p0 || StaticMessage2 == p0)
            {
                Console.WriteLine("Expected Static Message [" + p0 + "], found static message1 [" + StaticMessage + "] and message2  [" + StaticMessage2 + "]");
            }
            else
            {
                Console.WriteLine("Expected Static Message [" + p0 + "], found static message1 [" + StaticMessage + "] and message2  [" + StaticMessage2 + "]");
                Assert.AreEqual(true, false, "Expected Static Message [" + p0 + "], found static message1 [" + StaticMessage + "] and message2  [" + StaticMessage2 + "]");
            }
        }
        [Then(@"Administration Add MMP Static Message ""(.*)"" is displayed")]
        public void ThenAdministrationAddMMPStaticMessageIsDisplayed(string p0)
        {
            string expectedMessage = tmsCommon.GenerateData(p0);

            string StaticMessage = EAM.AdministrationMMP.StaticMessage.Text;
            if (expectedMessage == StaticMessage)
            {
                Console.WriteLine("Expected Static Message [" + p0 + "], found static message [" + StaticMessage + "]");
                Assert.AreEqual(true, true, "Expected Static Message [" + p0 + "], found static message [" + StaticMessage + "]");
            }
            else
            {
                Console.WriteLine("Expected Static Message [" + p0 + "], found static message [" + StaticMessage + "]");
                Assert.AreEqual(true, false, "Expected Static Message [" + p0 + "], found static message [" + StaticMessage + "]");
            }
        }

        [When(@"Administration Add MMP Rule Message ""(.*)"" is displayed")]
        public void WhenAdministrationAddMMPRuleMessageIsDisplayed(string p0)
        {
            int DisplayCount = 0;
            try
            {
                for (int i = 1; i < 80; i++)
                {
                    string Size = EAM.AdministrationMMP.RuleMessage.Size.ToString();
                    string Location = EAM.AdministrationMMP.RuleMessage.Location.ToString();
                    string Text = EAM.AdministrationMMP.RuleMessage.Text;
                    Boolean size, location, text, WasDisplayed;
                    WasDisplayed = false;

                    size = Size.Length > 19;
                    location = Location.Length > 9;
                    text = Text == p0;
                    WasDisplayed = size && location && text;
                    if (WasDisplayed) { DisplayCount++; break; }
                    Console.WriteLine("[" + i + "] [" + Size + "] [" + Location + "] [" + Text + "] [" + WasDisplayed + "] [" + DisplayCount + "]");
                }
                Boolean passed = DisplayCount > 0;
                Console.WriteLine("Pop up message [" + p0 + "] was displayed [" + passed + "]");
                Assert.AreEqual(true, passed, "Pop up message [" + p0 + "] was displayed");
            }
            catch
            {
                //Console.WriteLine("Pop up message [" + p0 + "] was displayed [Unknown]");
                Console.WriteLine("Pop up message {0} was displayed", "There is a rule which overlaps with new!");

            }

        }
        [Then(@"Verify Administration Add MMP MMP State is disabled")]
        public void ThenVerifyAdministrationAddMMPMMPStateIsDisabled()
        {
            string fieldName = "MMP State";
            string thisFieldValue = EAM.AdministrationMMP.MMPState.GetAttribute("disabled"); //Will give a 1 or -1, etc.  Needs next step to validate text
            Assert.AreEqual(true, "true" == thisFieldValue, "Field " + fieldName + " disabled is [" + thisFieldValue + "] as expected");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " disabled is [" + thisFieldValue + "] as expected");
        }

        [Then(@"Verify Administration Add MMP MMP State is set to ""(.*)""")]
        public void ThenVerifyAdministrationAddMMPMMPStateIsSetTo(string p0)
        {
            string fieldName = "MMP State";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationMMP.MMPState.GetAttribute("value"); //Will give a 1 or -1, etc.  Needs next step to validate text
            IList<IWebElement> thisOptionCollection = EAM.AdministrationMMP.MMPState.FindElements(By.TagName("option"));  //Get the options
            foreach (IWebElement thisOption in thisOptionCollection) //Loop through them
            {
                if (thisOption.GetAttribute("value") == thisFieldValue)  //if this option has the same value we found above (4 lines) then.. See if the text is right
                {
                    thisFieldValue = thisOption.Text;
                    Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
                    fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
                }
            }
        }
        [Then(@"Verify Administration Add MMP Plan ID is disabled")]
        public void ThenVerifyAdministrationAddMMPPlanIDIsDisabled()
        {
            string fieldName = "Plan ID";
            string thisFieldValue = EAM.AdministrationMMP.PlanID.GetAttribute("disabled"); //Will give a 1 or -1, etc.  Needs next step to validate text
            Assert.AreEqual(true, "true" == thisFieldValue, "Field " + fieldName + " disabled is [" + thisFieldValue + "] as expected");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " disabled is [" + thisFieldValue + "] as expected");
        }

        [Then(@"Verify Administration Add MMP Plan ID is set to ""(.*)""")]
        public void ThenVerifyAdministrationAddMMPPlanIDIsSetTo(string p0)
        {
            string fieldName = "Plan ID";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationMMP.PlanID.GetAttribute("value"); //Will give a 1 or -1, etc.  Needs next step to validate text
            IList<IWebElement> thisOptionCollection = EAM.AdministrationMMP.PlanID.FindElements(By.TagName("option"));  //Get the options
            foreach (IWebElement thisOption in thisOptionCollection) //Loop through them
            {
                if (thisOption.GetAttribute("value") == thisFieldValue)  //if this option has the same value we found above (4 lines) then.. See if the text is right
                {
                    thisFieldValue = thisOption.Text;
                    Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
                    fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
                }
            }
        }
        [Then(@"Verify Administration Add MMP PBP is disabled")]
        public void ThenVerifyAdministrationAddMMPPBPIsDisabled()
        {
            string fieldName = "PBP";
            string thisFieldValue = EAM.AdministrationMMP.PBP.GetAttribute("disabled"); //Will give a 1 or -1, etc.  Needs next step to validate text
            Assert.AreEqual(true, "true" == thisFieldValue, "Field " + fieldName + " disabled is [" + thisFieldValue + "] as expected");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " disabled is [" + thisFieldValue + "] as expected");
        }

        [Then(@"Verify Administration Add MMP PBP is set to ""(.*)""")]
        public void ThenVerifyAdministrationAddMMPPBPIsSetTo(string p0)
        {
            string fieldName = "PBP";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationMMP.PBP.GetAttribute("value"); //Will give a 1 or -1, etc.  Needs next step to validate text
            IList<IWebElement> thisOptionCollection = EAM.AdministrationMMP.PBP.FindElements(By.TagName("option"));  //Get the options
            foreach (IWebElement thisOption in thisOptionCollection) //Loop through them
            {
                if (thisOption.GetAttribute("value") == thisFieldValue)  //if this option has the same value we found above (4 lines) then.. See if the text is right
                {
                    thisFieldValue = thisOption.Text;
                    Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
                    fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
                }
            }
        }

        [Then(@"Verify Administration Add MMP Transaction Code is set to ""(.*)""")]
        public void ThenVerifyAdministrationAddMMPTransactionCodeIsSetTo(string p0)
        {
            string fieldName = "Transaction Code";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationMMP.TransactionCode.GetAttribute("value"); //Will give a 1 or -1, etc.  Needs next step to validate text
            IList<IWebElement> thisOptionCollection = EAM.AdministrationMMP.TransactionCode.FindElements(By.TagName("option"));  //Get the options
            foreach (IWebElement thisOption in thisOptionCollection) //Loop through them
            {
                if (thisOption.GetAttribute("value") == thisFieldValue)  //if this option has the same value we found above (4 lines) then.. See if the text is right
                {
                    thisFieldValue = thisOption.Text;
                    Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
                    fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
                }
            }
        }

        [Then(@"Verify Administration Add MMP Transaction Status is set to ""(.*)""")]
        public void ThenVerifyAdministrationAddMMPTransactionStatusIsSetTo(string p0)
        {
            string fieldName = "Transaction Status";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationMMP.TransactionStatus.GetAttribute("value"); //Will give a 1 or -1, etc.  Needs next step to validate text
            IList<IWebElement> thisOptionCollection = EAM.AdministrationMMP.TransactionStatus.FindElements(By.TagName("option"));  //Get the options
            foreach (IWebElement thisOption in thisOptionCollection) //Loop through them
            {
                if (thisOption.GetAttribute("value") == thisFieldValue)  //if this option has the same value we found above (4 lines) then.. See if the text is right
                {
                    thisFieldValue = thisOption.Text;
                    Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
                    fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
                }
            }
        }

        [Then(@"Verify Administration Add MMP TRC is set to ""(.*)""")]
        public void ThenVerifyAdministrationAddMMPTRCIsSetTo(string p0)
        {
            string fieldName = "TRC";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationMMP.TRC.GetAttribute("value"); //Will give a 1 or -1, etc.  Needs next step to validate text
            IList<IWebElement> thisOptionCollection = EAM.AdministrationMMP.TRC.FindElements(By.TagName("option"));  //Get the options
            foreach (IWebElement thisOption in thisOptionCollection) //Loop through them
            {
                if (thisOption.GetAttribute("value") == thisFieldValue)  //if this option has the same value we found above (4 lines) then.. See if the text is right
                {
                    thisFieldValue = thisOption.Text;
                    Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
                    fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
                    break;
                }
            }
        }

        [Then(@"Verify Administration Add MMP Effective Date is set to ""(.*)""")]
        public void ThenVerifyAdministrationAddMMPEffectiveDateIsSetTo(string p0)
        {
            string fieldName = "Effective Date";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationMMP.EffectiveDate.GetAttribute("value");
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [Then(@"Verify Administration Add MMP Delete Rule Message ""(.*)""")]
        public void WhenVerifyAdministrationAddMMPDeleteRuleMessage(string p0)
        {
            string DeleteRuleMessage = EAM.AdministrationMMP.DeleteRuleMessage.Text;
            Boolean MessagesMatch = (DeleteRuleMessage == p0);
            Assert.AreEqual(true, MessagesMatch, "Dialog Message is [" + DeleteRuleMessage + "], expected [" + p0 + "]");
            fw.ConsoleReport("   Verification Point: Dialog Message is [" + DeleteRuleMessage + "], expected [" + p0 + "]");
        }


        [When(@"Administraion Add MMP Delete MMP Members Load Parameters Row OK button is clicked")]
        public void WhenAdministraionAddMMPDeleteMMPMembersLoadParametersRowOKButtonIsClicked()
        {
            EAM.AdministrationMMP.DeleteThisRuleOkButton.Click();
        }

        [When(@"Administration Add MMP Table Edit Icon is clicked")]
        public void WhenAdministrationAddMMPTableEditIconIsClicked()
        {
            IWebElement edit = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_vMmpStateTransactions_uc_grdMmpStateTransactions_ctl02_btnEdit"));
            fw.ExecuteJavascript(edit);
            tmsWait.Hard(2);
        }


        [Then(@"Verify Administration Add MMP Termination Date is set to ""(.*)""")]
        public void ThenVerifyAdministrationAddMMPTerminationDateIsSetTo(string p0)
        {
            string fieldName = "Termination Date";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationMMP.TerminationDate.GetAttribute("value");
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }


        [When(@"Administration MMP Load Parameters Table does not have row")]
        public void WhenAdministrationMMPLoadParametersTableDoesNotHaveRow(Table table)
        {
            //NL 03/27/2015
            //if table is empty return pass
            //Get the table object 
            IWebElement baseTable = EAM.AdministrationMMP.ParametersTable;
            //Get rows out of the table on the page, from the table object
            ICollection<IWebElement> myRows = baseTable.FindElements(By.TagName("tr"));
            if (myRows.Count <= 0)
            {
                Assert.IsTrue(true,"MMP table is empty so row does not exist as expected");
                return;
            }

            //Establish the next page link for flipping pages as necessary
            //string NextPageLinkText = "";
            Boolean bNotAtLastPageOfRecords = true;
            Boolean bHaveGoodPageLink = true;
            Boolean bTimeToExit = false;
            IWebElement NPL = null;
            //Get the Table Header off of the test script Gherkin table
            ICollection<string> thisTH = table.Header;
            int thCount = thisTH.Count;
            string[] thisHeader = new string[thisTH.Count];
            thisTH.CopyTo(thisHeader, 0);   //copies the header to an array

            //Set up an array of classes to hold the table data, first one (0) will be the header info
            //The class has flags for this data row being a header, data and if we have yet matched it in our trials
            TableRow[] thisTableArr = new TableRow[table.RowCount + 1];
            thisTableArr[0] = new TableRow();
            thisTableArr[0].RowIsHeader = true;
            thisTableArr[0].RowIsData = false;
            thisTableArr[0].RowIsMatched = false;
            //Add the header data to the array 0 table row instance
            foreach (string thisString in thisHeader)
            {
                thisTableArr[0].Row.Add(thisString);
            }
            int iCounter = 1;
            //Add the Gherkin table row data to the array of rows.  These are all data, not headers, not matched yet.
            foreach (var row in table.Rows)
            {
                thisTableArr[iCounter] = new TableRow();
                thisTableArr[iCounter].RowIsHeader = false;
                thisTableArr[iCounter].RowIsData = true;
                thisTableArr[iCounter].RowIsMatched = false;

                for (int c = 0; c < row.Count; c++)
                {
                    thisTableArr[iCounter].Row.Add(row[c]);
                }
                iCounter++;
            }
            //While we have not matched all rows yet
            //and we are not on the last page of records..
            while (thisTableArr[0].AllRowsMatched(thisTableArr) == false && bNotAtLastPageOfRecords && bTimeToExit == false)
            {
                bNotAtLastPageOfRecords = false;
                //Get the table object again, since the page refreshes we need to get it fresh
                baseTable = EAM.AdministrationMMP.ParametersTable;
                //Get the spans data, this is the current page number.  Derive the next page number.

                //Get rows out of the table on the page, from the table object
                myRows = baseTable.FindElements(By.TagName("tr"));
                int RowCount = myRows.Count;
                //Establish an array of table rows for the page data.
                TableRow[] thisDataArr = new TableRow[RowCount];
                int EstablishedRowItemCount = 0;
                int iRowCounter = 0;
                foreach (IWebElement thisRow in myRows)
                {
                    //For each new data row we look at, add a new instance of the class to the array.
                    thisDataArr[iRowCounter] = new TableRow();
                    thisDataArr[iRowCounter].RowIsHeader = true;
                    thisDataArr[iRowCounter].RowIsData = false;
                    thisDataArr[iRowCounter].RowIsMatched = false;
                    //Get all of the elements from the row (<td>)
                    ICollection<IWebElement> myElements;
                    if (iRowCounter == 0)
                    {
                        myElements = thisRow.FindElements(By.TagName("th"));
                    }
                    else
                    {
                        myElements = thisRow.FindElements(By.TagName("td"));
                    }
                    //Row 0 is the header
                    //The rest of the rows are data
                    foreach (IWebElement thisElement in myElements)
                    {
                        if (iRowCounter == 0)
                        {
                            //Finding the normal item count because the page numbers are a data row.
                            //Row 0 is the header
                            EstablishedRowItemCount = myElements.Count;
                            thisDataArr[iRowCounter].RowIsHeader = true;
                            thisDataArr[iRowCounter].RowIsData = false;
                        }
                        else
                        {
                            //Other rows are data
                            thisDataArr[iRowCounter].RowIsHeader = false;
                            thisDataArr[iRowCounter].RowIsData = true;
                        }
                        if (myElements.Count == EstablishedRowItemCount)
                        {
                            //Only add data if we have a data row, not if we have a 0 length row.
                            thisDataArr[iRowCounter].Row.Add(thisElement.Text.ToString());
                        }
                        else
                        {
                            //If this row count isn't the right number of items, we didn't match with expected.
                            thisDataArr[iRowCounter].RowIsData = false;
                        }
                    }
                    iRowCounter++;
                }
                int iTableCounter = 0;
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TableRow TTA in thisTableArr)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.
                    if (TTA.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] ta = TTA.Row.ToArray();

                        //For each row in the page data
                        foreach (TableRow TDA in thisDataArr)
                        {
                            //Convert page data to array elements
                            string[] td = TDA.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.
                            foreach (string tde in td)
                            {
                                if (iElementCounter > 0 && TDA.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (tde != ta[iElementCounter - 1] && ta[iElementCounter - 1].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                        break;
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (td.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same
                            if (bThisRowMatches)
                            {
                                //Report the match, first convert the array back to a string we can read.
                                thisTableArr[iTableCounter].RowIsMatched = true;
                                string TR0 = TableRow.ArrayToString(td);
                                string TR1 = TableRow.ArrayToString(ta);
                                Console.WriteLine("We did not expect to have a matching row.   FAIL");
                                Console.WriteLine("Searching Row Data - " + TR0);
                                Console.WriteLine("Found Row Data ------- " + TR1);
                            }
                        }
                    }
                    iTableCounter++;
                }

                Boolean fullMatching = thisTableArr[0].AllRowsMatched(thisTableArr);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as FAIL");
                }

                baseTable = EAM.AdministrationMMP.ParametersTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (!fullMatching)
                {
                    int iCount = 0;
                    var TableRow = new TMSString();
                    foreach (TableRow thisTR in thisTableArr)
                    {
                        if (thisTR.RowIsMatched == false && thisTR.RowIsHeader == false)
                        {
                            string thisRowData = TableRow.ArrayToString(thisTR.Row.ToArray());
                            Console.WriteLine("Unmatched Data Row -- " + thisRowData);
                        }
                        iCount++;
                    }
                    Console.WriteLine("No rows in the Gherkin test table were found in the page table data rows.");
                    Assert.AreEqual(true, true, "No rows in the Gherkin test table were found in the page table data rows.");
                    bTimeToExit = true;
                }
            }

        }





        [When(@"Administration Add MMP Table Edit Icon is clicked for row")]
        public void WhenAdministrationAddMMPTableEditIconIsClickedForRow(Table table)
        {
            tmsWait.Hard(3);
            //Establish the next page link for flipping pages as necessary
            string NextPageLinkText = "";
            Boolean bNotAtLastPageOfRecords = true;
            Boolean bHaveGoodPageLink = true;
            IWebElement NPL = null;
            //Get the Table Header off of the test script Gherkin table
            ICollection<string> thisTH = table.Header;
            int thCount = thisTH.Count;
            string[] thisHeader = new string[thisTH.Count];
            thisTH.CopyTo(thisHeader, 0);   //copies the header to an array

            //Set up an array of classes to hold the table data, first one (0) will be the header info
            //The class has flags for this data row being a header, data and if we have yet matched it in our trials
            TableRow[] thisTableArr = new TableRow[table.RowCount + 1];
            thisTableArr[0] = new TableRow();
            thisTableArr[0].RowIsHeader = true;
            thisTableArr[0].RowIsData = false;
            thisTableArr[0].RowIsMatched = false;
            //Add the header data to the array 0 table row instance
            foreach (string thisString in thisHeader)
            {
                thisTableArr[0].Row.Add(thisString);
            }
            int iCounter = 1;
            //Add the Gherkin table row data to the array of rows.  These are all data, not headers, not matched yet.
            foreach (var row in table.Rows)
            {
                thisTableArr[iCounter] = new TableRow();
                thisTableArr[iCounter].RowIsHeader = false;
                thisTableArr[iCounter].RowIsData = true;
                thisTableArr[iCounter].RowIsMatched = false;

                for (int c = 0; c < row.Count; c++)
                {
                    thisTableArr[iCounter].Row.Add(row[c]);
                }
                iCounter++;
            }
            //While we have not matched all rows yet
            //and we are not on the last page of records..
            while (thisTableArr[0].AllRowsMatched(thisTableArr) == false && bNotAtLastPageOfRecords)
            {
                bNotAtLastPageOfRecords = false;
                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.AdministrationMMP.ParametersTable;
                //Get the spans data, this is the current page number.  Derive the next page number.
                ICollection<IWebElement> mySpans = baseTable.FindElements(By.TagName("span"));

                //----------NL 03/26/2015--------
                //add verification for NextPage icon's existence: skip related steps if icon does not exist
                if (mySpans.Count > 0)
                {
                    foreach (IWebElement thisSpan in mySpans)
                    {
                        int CurrentPageNumber = Convert.ToInt16(thisSpan.Text);
                        int NextPageNumber = CurrentPageNumber + 1;
                        NextPageLinkText = NextPageNumber.ToString();
                    }
                    //Find the link for the next page.  (for later)
                    try
                    {
                        NPL = baseTable.FindElement(By.LinkText(NextPageLinkText));
                    }
                    catch
                    {
                        bNotAtLastPageOfRecords = true;
                        bHaveGoodPageLink = false;
                    }
                }
                else
                {
                    bNotAtLastPageOfRecords = true;
                    bHaveGoodPageLink = false;
                }

                //Get rows out of the table on the page, from the table object
                ICollection<IWebElement> myRows = baseTable.FindElements(By.TagName("tr"));
                int RowCount = myRows.Count;
                //Establish an array of table rows for the page data.
                TableRow[] thisDataArr = new TableRow[RowCount];
                int EstablishedRowItemCount = 0;
                int iRowCounter = 0;
                foreach (IWebElement thisRow in myRows)
                {
                    //For each new data row we look at, add a new instance of the class to the array.
                    thisDataArr[iRowCounter] = new TableRow();
                    thisDataArr[iRowCounter].RowIsHeader = true;
                    thisDataArr[iRowCounter].RowIsData = false;
                    thisDataArr[iRowCounter].RowIsMatched = false;
                    //Get all of the elements from the row (<td>)
                    ICollection<IWebElement> myElements;
                    if (iRowCounter == 0)
                    {
                        myElements = thisRow.FindElements(By.TagName("th"));
                    }
                    else
                    {
                        myElements = thisRow.FindElements(By.TagName("td"));
                    }
                    //Row 0 is the header
                    //The rest of the rows are data
                    foreach (IWebElement thisElement in myElements)
                    {
                        if (iRowCounter == 0)
                        {
                            //Finding the normal item count because the page numbers are a data row.
                            //Row 0 is the header
                            EstablishedRowItemCount = myElements.Count;
                            thisDataArr[iRowCounter].RowIsHeader = true;
                            thisDataArr[iRowCounter].RowIsData = false;
                        }
                        else
                        {
                            //Other rows are data
                            thisDataArr[iRowCounter].RowIsHeader = false;
                            thisDataArr[iRowCounter].RowIsData = true;
                        }
                        if (myElements.Count == EstablishedRowItemCount)
                        {
                            //Only add data if we have a data row, not if we have a 0 length row.
                            thisDataArr[iRowCounter].Row.Add(thisElement.Text.ToString());
                        }
                        else
                        {
                            //If this row count isn't the right number of items, we didn't match with expected.
                            thisDataArr[iRowCounter].RowIsData = false;
                        }
                    }
                    iRowCounter++;
                }
                int iTableCounter = 0;
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TableRow TTA in thisTableArr)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.
                    if (TTA.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] ta = TTA.Row.ToArray();

                        //For each row in the page data
                        foreach (TableRow TDA in thisDataArr)
                        {
                            //Convert page data to array elements
                            string[] td = TDA.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.
                            foreach (string tde in td)
                            {
                                if (iElementCounter > 0 && TDA.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (tde != ta[iElementCounter - 1] && ta[iElementCounter - 1] != "[Skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (td.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same
                            if (bThisRowMatches)
                            {
                                //Report the match, first convert the array back to a string we can read.
                                thisTableArr[iTableCounter].RowIsMatched = true;
                                //           ICollection<IWebElement> myDeleteButtons = baseTable.FindElements(By.CssSelector("img[title='click here to delete this user...']"));
                                ICollection<IWebElement> myEditButtons = baseTable.FindElements(By.CssSelector("input[src='../../images/icon_edit.gif']"));
                                int EditButtonCount = myEditButtons.Count;
                                int iButtonCounter = 1;
                                Boolean buttonWasClicked = false;
                                foreach (IWebElement thisEditButton in myEditButtons)
                                {
                                    if (iButtonCounter == iTableCounter)
                                    {
                                        tmsWait.Hard(2);
                                        fw.ExecuteJavascript(thisEditButton);

                                        //                 thisEditButton.SendKeys(Keys.Enter);
                                        tmsWait.Hard(2);
                                        buttonWasClicked = true;

                                        break;
                                    }
                                    iButtonCounter++;
                                }
                                if (buttonWasClicked)
                                {
                                    string TR0 = TableRow.ArrayToString(td);
                                    string TR1 = TableRow.ArrayToString(ta);
                                    Console.WriteLine("Expected Row Data - " + TR0);
                                    Console.WriteLine("Found Row Data ------- " + TR1);
                                    Console.WriteLine("User Edit Button Clicked.");

                                }
                                else
                                {
                                    Assert.AreEqual(true, false, "There was no user button in the table to click.");
                                }

                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisTableArr[0].AllRowsMatched(thisTableArr);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        bNotAtLastPageOfRecords = true;
                        NPL.Click();
                        System.Threading.Thread.Sleep(2000);
                    }
                }
                baseTable = EAM.AdministrationMMP.ParametersTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (bHaveGoodPageLink == false && !fullMatching)
                {
                    int iCount = 0;
                    var TableRow = new TMSString();
                    foreach (TableRow thisTR in thisTableArr)
                    {
                        if (thisTR.RowIsMatched == false && thisTR.RowIsHeader == false)
                        {
                            string thisRowData = TableRow.ArrayToString(thisTR.Row.ToArray());
                            Console.WriteLine("Unmatched Data Row -- " + thisRowData);
                        }
                        iCount++;
                    }
                    Assert.AreEqual(true, false, "Not all expected rows in the Gherkin test table were found in the page table data rows.");
                }
            }
        }

        [When(@"Administration Add MMP Table Delete Icon is clicked for row")]
        public void WhenAdministrationAddMMPTableDeleteIconIsClickedForRow(Table table)
        {
            //Establish the next page link for flipping pages as necessary
            string NextPageLinkText = "";
            Boolean bNotAtLastPageOfRecords = true;
            Boolean bHaveGoodPageLink = true;
            IWebElement NPL = null;
            //Get the Table Header off of the test script Gherkin table
            ICollection<string> thisTH = table.Header;
            int thCount = thisTH.Count;
            string[] thisHeader = new string[thisTH.Count];
            thisTH.CopyTo(thisHeader, 0);   //copies the header to an array

            //Set up an array of classes to hold the table data, first one (0) will be the header info
            //The class has flags for this data row being a header, data and if we have yet matched it in our trials
            TableRow[] thisTableArr = new TableRow[table.RowCount + 1];
            thisTableArr[0] = new TableRow();
            thisTableArr[0].RowIsHeader = true;
            thisTableArr[0].RowIsData = false;
            thisTableArr[0].RowIsMatched = false;
            //Add the header data to the array 0 table row instance
            foreach (string thisString in thisHeader)
            {
                thisTableArr[0].Row.Add(thisString);
            }
            int iCounter = 1;
            //Add the Gherkin table row data to the array of rows.  These are all data, not headers, not matched yet.
            foreach (var row in table.Rows)
            {
                thisTableArr[iCounter] = new TableRow();
                thisTableArr[iCounter].RowIsHeader = false;
                thisTableArr[iCounter].RowIsData = true;
                thisTableArr[iCounter].RowIsMatched = false;

                for (int c = 0; c < row.Count; c++)
                {
                    string ElementValue = row[c];
                    if (ElementValue.Length > 9)
                    {
                        string leftSide = ElementValue.Substring(0, 9);
                        leftSide = leftSide.ToLower();
                        if (leftSide.ToLower() == "variable[")
                        {
                            int strLength = ElementValue.Length - 1;
                            string varName = ElementValue.Substring(9, strLength - 9);
                            ElementValue = tmsCommon.GenerateData("generate|variable|" + varName);
                        }
                    }
                    thisTableArr[iCounter].Row.Add(ElementValue);
                }
                iCounter++;
            }
            //While we have not matched all rows yet
            //and we are not on the last page of records..
            while (thisTableArr[0].AllRowsMatched(thisTableArr) == false && bNotAtLastPageOfRecords)
            {
                bNotAtLastPageOfRecords = false;
                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.AdministrationMMP.ParametersTable;
                //Get the spans data, this is the current page number.  Derive the next page number.
                ICollection<IWebElement> mySpans = baseTable.FindElements(By.TagName("span"));
                //skip next steps if there are no such elements found
                if (mySpans.Count > 0)
                {
                    foreach (IWebElement thisSpan in mySpans)
                    {
                        int CurrentPageNumber = Convert.ToInt16(thisSpan.Text);
                        int NextPageNumber = CurrentPageNumber + 1;
                        NextPageLinkText = NextPageNumber.ToString();
                    }
                    //Find the link for the next page.  (for later)
                    try
                    {
                        NPL = baseTable.FindElement(By.LinkText(NextPageLinkText));
                    }
                    catch
                    {
                        bNotAtLastPageOfRecords = true;
                        bHaveGoodPageLink = false;
                    }
                }
                else
                {
                    bNotAtLastPageOfRecords = true;
                    bHaveGoodPageLink = false;
                }
                //Get rows out of the table on the page, from the table object
                ICollection<IWebElement> myRows = baseTable.FindElements(By.TagName("tr"));
                int RowCount = myRows.Count;
                //Establish an array of table rows for the page data.
                TableRow[] thisDataArr = new TableRow[RowCount];
                int EstablishedRowItemCount = 0;
                int iRowCounter = 0;
                foreach (IWebElement thisRow in myRows)
                {
                    //For each new data row we look at, add a new instance of the class to the array.
                    thisDataArr[iRowCounter] = new TableRow();
                    thisDataArr[iRowCounter].RowIsHeader = true;
                    thisDataArr[iRowCounter].RowIsData = false;
                    thisDataArr[iRowCounter].RowIsMatched = false;
                    //Get all of the elements from the row (<td>)
                    ICollection<IWebElement> myElements;
                    if (iRowCounter == 0)
                    {
                        myElements = thisRow.FindElements(By.TagName("th"));
                    }
                    else
                    {
                        myElements = thisRow.FindElements(By.TagName("td"));
                    }
                    //Row 0 is the header
                    //The rest of the rows are data
                    foreach (IWebElement thisElement in myElements)
                    {
                        if (iRowCounter == 0)
                        {
                            //Finding the normal item count because the page numbers are a data row.
                            //Row 0 is the header
                            EstablishedRowItemCount = myElements.Count;
                            thisDataArr[iRowCounter].RowIsHeader = true;
                            thisDataArr[iRowCounter].RowIsData = false;
                        }
                        else
                        {
                            //Other rows are data
                            thisDataArr[iRowCounter].RowIsHeader = false;
                            thisDataArr[iRowCounter].RowIsData = true;
                        }
                        if (myElements.Count == EstablishedRowItemCount)
                        {
                            //Only add data if we have a data row, not if we have a 0 length row.
                            thisDataArr[iRowCounter].Row.Add(thisElement.Text.ToString());
                        }
                        else
                        {
                            //If this row count isn't the right number of items, we didn't match with expected.
                            thisDataArr[iRowCounter].RowIsData = false;
                        }
                    }
                    iRowCounter++;
                }
                int iTableCounter = 0;
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TableRow TTA in thisTableArr)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.
                    if (TTA.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] ta = TTA.Row.ToArray();

                        //For each row in the page data
                        int thisTableRow = 0;
                        foreach (TableRow TDA in thisDataArr)
                        {
                            //Convert page data to array elements

                            //The table has 1 more element than the Gherkin table.   Adjust by 1 here
                            string[] td = TDA.Row.ToArray();
                            string[] tdTemp = new string[ta.Length];
                            //              ta.CopyTo(tdTemp, 0);
                            //                   int iClearCounter = 0;
                            //foreach (string tempstring in tdTemp)
                            //{
                            //    tdTemp[iClearCounter] = "";
                            //    iClearCounter++;
                            //}
                            int counter = 0;
                            foreach (string thisString in td)
                            {
                                if (counter == 0)
                                {


                                }
                                else
                                {
                                    tdTemp[counter - 1] = td[counter];
                                }
                                counter++;
                            }
                            //                         int iElementCounter = 0;
                            Boolean arrayMatch = true;
                            int thisCounter = 0;
                            foreach (string thisElement in ta)
                            {
                                //               Console.WriteLine("Individual compare [" + thisTableRow + "] Gherkin [" + ta[thisCounter] + "]  Data [" + tdTemp[thisCounter]  + "]");
                                if (ta[thisCounter] != tdTemp[thisCounter])
                                {
                                    arrayMatch = false;
                                }
                                thisCounter++;
                            }
                            //                   Boolean bThisRowMatches = (ta.ToString() == tdTemp.ToString());
                            Boolean bThisRowMatches = arrayMatch;
                            if (iTableCounter == 0)
                            {
                                bThisRowMatches = false;   //if it's the header row, we don't need a match record
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same
                            if (bThisRowMatches)
                            {
                                //Report the match, first convert the array back to a string we can read.
                                thisTableArr[iTableCounter].RowIsMatched = true;
                                ICollection<IWebElement> myDeleteButtons = baseTable.FindElements(By.CssSelector("input[src='../../images/icon_delete.gif']"));
                                int DeleteButtonCount = myDeleteButtons.Count;
                                int iButtonCounter = 1;
                                foreach (IWebElement thisDeleteButton in myDeleteButtons)
                                {
                                    if (iButtonCounter == thisTableRow)
                                    //if (iButtonCounter == iTableCounter)
                                    {
                                        thisDeleteButton.Click();
                                        thisDeleteButton.SendKeys(Keys.Enter);
                                        tmsWait.Hard(1);
                                        //break the for 
                                        break;

                                        //string thisMessage = Browser.Wd.SwitchTo().Alert().Text;
                                        //Browser.Wd.SwitchTo().Alert().Accept();
                                        //Browser.Wd.SwitchTo().DefaultContent();
                                        //Console.WriteLine("User was deleted as per the matching table row.");
                                    }
                                    iButtonCounter++;
                                }
                                string TR0 = TableRow.ArrayToString(td);
                                string TR1 = TableRow.ArrayToString(ta);
                                Console.WriteLine("Expected Row Data - " + TR0);
                                Console.WriteLine("Found Row Data ------- " + TR1);
                                return;
                            }
                            thisTableRow++;
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisTableArr[0].AllRowsMatched(thisTableArr);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        bNotAtLastPageOfRecords = true;
                        bNotAtLastPageOfRecords = false;  //Overriding, only look at first page

                        // NPL.Click();
                        System.Threading.Thread.Sleep(2000);
                    }
                }
                baseTable = EAM.AdministrationMMP.ParametersTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (bHaveGoodPageLink == false && !fullMatching)
                {
                    int iCount = 0;
                    var TableRow = new TMSString();
                    foreach (TableRow thisTR in thisTableArr)
                    {
                        if (thisTR.RowIsMatched == false && thisTR.RowIsHeader == false)
                        {
                            string thisRowData = TableRow.ArrayToString(thisTR.Row.ToArray());
                            Console.WriteLine("Unmatched Data Row -- " + thisRowData);
                        }
                        iCount++;
                    }
                    Assert.AreEqual(true, false, "Not all expected rows in the Gherkin test table were found in the page table data rows.");
                }
            }
        }
        [Then(@"Verify Administration Add MMP Table does not have Delete Icons")]
        public void ThenVerifyAdministrationAddMMPTableDoesNotHaveDeleteIcons()
        {
            IWebElement baseTable = EAM.AdministrationMMP.ParametersTable;

            ICollection<IWebElement> myDeleteButtons = baseTable.FindElements(By.CssSelector("input[src='../../images/icon_delete.gif']"));
            int DeleteButtonCount = myDeleteButtons.Count;
            if (DeleteButtonCount == 0)
            {
                Console.WriteLine("Confirmed, there are [" + DeleteButtonCount + "] delete buttons in the table as expected");
                Assert.AreEqual(true, true, "Confirmed, there are [" + DeleteButtonCount + "] delete buttons in the table as expected");
            }
            else
            {
                Console.WriteLine("Failed, there are [" + DeleteButtonCount + "] delete buttons in the table.  0 expected");
                Assert.AreEqual(true, false, "Failed, there are [" + DeleteButtonCount + "] delete buttons in the table.  0 expected");
            }
        }

        [Then(@"Verify Administration Add MMP Table displayed Transaction Status as ""(.*)"" Plan Id as ""(.*)""")]
        public void ThenVerifyAdministrationAddMMPTableDisplayedTransactionStatusAsPlanIdAs(string p0, string p1)
        {
            tmsWait.Hard(3);
            IWebElement elementpresence = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_vMmpStateTransactions_uc_grdMmpStateTransactions']//tr/td[contains(.,'" + p0 + "')]/preceding-sibling::td[contains(.,'" + p1 + "')]"));

            Assert.IsTrue(elementpresence.Displayed, p0 + " " + p1 + " are not getting displayed");
        }

        [Then(@"Verify Administration Add MMP Table displayed Plan ID as ""(.*)"" PBP Id as ""(.*)""")]
        public void ThenVerifyAdministrationAddMMPTableDisplayedPlanIDAsPBPIdAs(string p0, String p1)
        {
            tmsWait.Hard(3);
            IWebElement elementpresence = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_vMmpStateTransactions_uc_grdMmpStateTransactions']//tr/td[contains(.,'" + p0 + "')]/following-sibling::td[contains(.,'" + p1 + "')]"));
            Assert.IsTrue(elementpresence.Displayed, p0 + " " + p1 + " are not getting displayed");
        }


        [Then(@"Administration Add MMP Table has row")]
        public void ThenAdministrationAddMMPTableHasRow(Table table)
        {
            //Establish the next page link for flipping pages as necessary
            string NextPageLinkText = "";
            Boolean bNotAtLastPageOfRecords = true;
            Boolean bHaveGoodPageLink = true;
            IWebElement NPL = null;
            //Get the Table Header off of the test script Gherkin table
            ICollection<string> thisTH = table.Header;
            int thCount = thisTH.Count;
            string[] thisHeader = new string[thisTH.Count];
            thisTH.CopyTo(thisHeader, 0);   //copies the header to an array

            //Set up an array of classes to hold the table data, first one (0) will be the header info
            //The class has flags for this data row being a header, data and if we have yet matched it in our trials
            TableRow[] thisTableArr = new TableRow[table.RowCount + 1];
            thisTableArr[0] = new TableRow();
            thisTableArr[0].RowIsHeader = true;
            thisTableArr[0].RowIsData = false;
            thisTableArr[0].RowIsMatched = false;
            //Add the header data to the array 0 table row instance
            foreach (string thisString in thisHeader)
            {
                thisTableArr[0].Row.Add(thisString);
            }
            int iCounter = 1;
            //Add the Gherkin table row data to the array of rows.  These are all data, not headers, not matched yet.
            foreach (var row in table.Rows)
            {
                thisTableArr[iCounter] = new TableRow();
                thisTableArr[iCounter].RowIsHeader = false;
                thisTableArr[iCounter].RowIsData = true;
                thisTableArr[iCounter].RowIsMatched = false;

                for (int c = 0; c < row.Count; c++)
                {
                    thisTableArr[iCounter].Row.Add(row[c]);
                }
                iCounter++;
            }
            //While we have not matched all rows yet
            //and we are not on the last page of records..
            while (thisTableArr[0].AllRowsMatched(thisTableArr) == false && bNotAtLastPageOfRecords)
            {
                bNotAtLastPageOfRecords = false;
                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.AdministrationMMP.ParametersTable;
                //Get the spans data, this is the current page number.  Derive the next page number.
                ICollection<IWebElement> mySpans = baseTable.FindElements(By.TagName("span"));

                //----------NL 03/26/2015--------
                //add verification for NextPage icon's existence: skip related steps if icon does not exist
                if (mySpans.Count > 0)
                {
                    foreach (IWebElement thisSpan in mySpans)
                    {
                        int CurrentPageNumber = Convert.ToInt16(thisSpan.Text);
                        int NextPageNumber = CurrentPageNumber + 1;
                        NextPageLinkText = NextPageNumber.ToString();
                    }
                    //Find the link for the next page.  (for later)
                    try
                    {
                        NPL = baseTable.FindElement(By.LinkText(NextPageLinkText));
                    }
                    catch
                    {
                        bNotAtLastPageOfRecords = true;
                        bHaveGoodPageLink = false;
                    }
                }
                else
                {
                    bNotAtLastPageOfRecords = true;
                    bHaveGoodPageLink = false;
                }
                //---------

                //Get rows out of the table on the page, from the table object
                ICollection<IWebElement> myRows = baseTable.FindElements(By.TagName("tr"));
                int RowCount = myRows.Count;
                //Establish an array of table rows for the page data.
                TableRow[] thisDataArr = new TableRow[RowCount];
                int EstablishedRowItemCount = 0;
                int iRowCounter = 0;
                foreach (IWebElement thisRow in myRows)
                {
                    //For each new data row we look at, add a new instance of the class to the array.
                    thisDataArr[iRowCounter] = new TableRow();
                    thisDataArr[iRowCounter].RowIsHeader = true;
                    thisDataArr[iRowCounter].RowIsData = false;
                    thisDataArr[iRowCounter].RowIsMatched = false;
                    //Get all of the elements from the row (<td>)
                    ICollection<IWebElement> myElements;
                    if (iRowCounter == 0)
                    {
                        myElements = thisRow.FindElements(By.TagName("th"));
                    }
                    else
                    {
                        myElements = thisRow.FindElements(By.TagName("td"));
                    }
                    //Row 0 is the header
                    //The rest of the rows are data
                    foreach (IWebElement thisElement in myElements)
                    {
                        if (iRowCounter == 0)
                        {
                            //Finding the normal item count because the page numbers are a data row.
                            //Row 0 is the header
                            EstablishedRowItemCount = myElements.Count;
                            thisDataArr[iRowCounter].RowIsHeader = true;
                            thisDataArr[iRowCounter].RowIsData = false;
                        }
                        else
                        {
                            //Other rows are data
                            thisDataArr[iRowCounter].RowIsHeader = false;
                            thisDataArr[iRowCounter].RowIsData = true;
                        }
                        if (myElements.Count == EstablishedRowItemCount)
                        {
                            //Only add data if we have a data row, not if we have a 0 length row.
                            thisDataArr[iRowCounter].Row.Add(thisElement.Text.ToString());
                        }
                        else
                        {
                            //If this row count isn't the right number of items, we didn't match with expected.
                            thisDataArr[iRowCounter].RowIsData = false;
                        }
                    }
                    iRowCounter++;
                }
                //----NL 03/26/2015------
                //get count of rows in UA table array
                int iDataArrCount = thisDataArr.Length;

                int iTableCounter = 0;
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TableRow TTA in thisTableArr)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.
                    if (TTA.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] ta = TTA.Row.ToArray();

                        //For each row in the page data
                        //------NL 03/26/2015
                        //-----replace foreach with for to exclude the header of UI table from verification
                        //foreach (TableRow TDA in thisDataArr)
                        for (int i = 1; i < iDataArrCount; i++)
                        {
                            //Convert page data to array elements
                            TableRow TDA = thisDataArr[i];

                            string[] td = TDA.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.
                            foreach (string tde in td)
                            {
                                if (iElementCounter > 0 && TDA.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (tde != ta[iElementCounter - 1] && ta[iElementCounter - 1].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                        //--------NL 03/26/2015
                                        //break the for statement when first mismatch found
                                        break;
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (td.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same
                            if (bThisRowMatches)
                            {
                                //Report the match, first convert the array back to a string we can read.
                                thisTableArr[iTableCounter].RowIsMatched = true;
                                string TR0 = TableRow.ArrayToString(td);
                                string TR1 = TableRow.ArrayToString(ta);
                                Console.WriteLine("Expected Row Data - " + TR1);
                                Console.WriteLine("Found Row Data ------- " + TR0);

                                break;
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisTableArr[0].AllRowsMatched(thisTableArr);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        bNotAtLastPageOfRecords = true;
                        NPL.Click();
                        System.Threading.Thread.Sleep(2000);
                    }
                }
                baseTable = EAM.AdministrationMMP.ParametersTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (bHaveGoodPageLink == false && !fullMatching)
                {
                    int iCount = 0;
                    var TableRow = new TMSString();
                    foreach (TableRow thisTR in thisTableArr)
                    {
                        if (thisTR.RowIsMatched == false && thisTR.RowIsHeader == false)
                        {
                            string thisRowData = TableRow.ArrayToString(thisTR.Row.ToArray());
                            Console.WriteLine("Unmatched Data Row -- " + thisRowData);
                        }
                        iCount++;
                    }
                    Assert.AreEqual(true, false, "Not all expected rows in the Gherkin test table were found in the page table data rows.");
                }
            }
        }

        [When(@"Administration/SNPConfig Page PlanId is set to ""(.*)""")]
        [Given(@"Administration/SNPConfig Page PlanId is set to ""(.*)""")]
        public void WhenAdministrationSNPConfigPagePlanIdIsSetTo(string p0)
        {
            SelectElement PlanId = new SelectElement(EAM.AdministrationPlanDefinedFieldsTabSpanConfig.PlanId);
            PlanId.SelectByText(p0);
        }

        [When(@"Administration/SNPConfig History Page PlanId is set to ""(.*)""")]
        [Given(@"Administration/SNPConfig History Page PlanId is set to ""(.*)""")]
        public void WhenAdministrationSNPConfigHistoryPagePlanIdIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            EAM.AdministrationPlanDefinedFieldsTabSpanConfig.SNPAuditPlanId.Click();

            IList<IWebElement> PlanIds = EAM.AdministrationPlanDefinedFieldsTabSpanConfig.SNPAuditPlanIdDropDown.FindElements(By.TagName("li"));

            foreach (IWebElement PlanId in PlanIds)
            {
                if (PlanId.Text == p0)
                {
                    PlanId.Click(); break;
                }
            }

        }

        [When(@"Administration/SNPConfig Page PBP is set to ""(.*)""")]
        [Given(@"Administration/SNPConfig Page PBP is set to ""(.*)""")]
        public void WhenAdministrationSNPConfigPagePBPIsSetTo(string p0)
        {
            SelectElement PBP = new SelectElement(EAM.AdministrationPlanDefinedFieldsTabSpanConfig.PBP);
            PBP.SelectByText(p0);
        }

        [When(@"Administration/SNPConfig Page SNPType is set to ""(.*)""")]
        [Given(@"Administration/SNPConfig Page SNPType is set to ""(.*)""")]
        public void WhenAdministrationSNPConfigPageSNPTypeIsSetTo(string type)
        {
            tmsWait.Hard(5);

            IWebElement drpele = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_SNPConfiguration_snpTypesDdl"));
            SelectElement drp = new SelectElement(drpele);
            drp.SelectByText(type);
            //  Assert.IsTrue(Browser.Wd.FindElement(By.XPath(".//*[contains(@id,'ctl00_ctl00_MainMasterContent_MainContent_SNPConfiguration_snpChronicTypesDdl')]/label/span[contains(.,'" + type + "')]")).Displayed);
        }

        [When(@"Administration/SNPConfig Page verify chronic types displayed as ""(.*)""")]
        public void WhenAdministrationSNPConfigPageVerifyChronicTypesDisplayedAs(string p0)
        {
            tmsWait.Hard(5);
            IWebElement check = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]/preceding-sibling::input"));
            fw.ExecuteJavascript(check);
        }


        [When(@"Administration/SNPConfig Page ChronicType is set to ""(.*)""")]
        public void WhenAdministrationSNPConfigPageChronicTypeIsSetTo(string p0)
        {
            //Browser.Wd.FindElement(By.LinkText("Check All")).Click();
            var ChronicTypes = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_SNPConfiguration_snpChronicTypesDdl"));

            IList<IWebElement> ChronicType = ChronicTypes.FindElements(By.TagName("Input"));
            foreach (IWebElement Chronic in ChronicType)
            {
                if (Chronic.GetAttribute("class").Contains("rlbCheckAllItemsCheckBox"))
                {
                    Chronic.Click(); break;
                }
            }
        }

        [When(@"Administration/SNPConfig Page ChronicTypeAll is set to ""(.*)""")]
        public void WhenAdministrationSNPConfigPageChronicTypeAllIsSetTo(string p0)
        {
            string GenerateData = tmsCommon.GenerateData(p0);
            tmsWait.Hard(2);

            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("unchecked"))
            {

                if (EAM.AdministrationPlanDefinedFieldsTabSpanConfig.ChronicTypeAll.Selected == true)
                {
                    EAM.AdministrationPlanDefinedFieldsTabSpanConfig.ChronicTypeAll.Click();
                }

            }
            else if (setCheckboxTo.Equals("checked"))
            {
                if (EAM.AdministrationPlanDefinedFieldsTabSpanConfig.ChronicTypeAll.Selected == false)
                {
                    EAM.AdministrationPlanDefinedFieldsTabSpanConfig.ChronicTypeAll.Click();
                }
            }
        }


        [When(@"Administration/SNPConfig Page State is set to ""(.*)""")]
        [Given(@"Administration/SNPConfig Page State is set to ""(.*)""")]
        public void WhenAdministrationSNPConfigPageStateIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            SelectElement State = new SelectElement(EAM.AdministrationPlanDefinedFieldsTabSpanConfig.State);
            State.SelectByText(p0);
        }


        [When(@"Administration/SNPConfig Page MonthsOfEligibility is set to ""(.*)""")]
        [Given(@"Administration/SNPConfig Page MonthsOfEligibility is set to ""(.*)""")]
        public void WhenAdministrationSNPConfigPageMonthsOfEligibilityIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            SelectElement Eligibility = new SelectElement(EAM.AdministrationPlanDefinedFieldsTabSpanConfig.MonthsOfEligibility);
            Eligibility.SelectByText(p0);
        }

        [When(@"Administration SNPConfig Chronic Type is set to ""(.*)""")]
        public void WhenAdministrationSNPConfigChronicTypeIsSetTo(string p0)
        {
            IWebElement check = Browser.Wd.FindElement(By.XPath("//div[@id='ctl00_ctl00_MainMasterContent_MainContent_SNPConfiguration_snpChronicTypesDdl']//span[contains(.,'" + p0 + "')]//preceding-sibling::input"));
            fw.ExecuteJavascript(check);

        }

        [When(@"Administration SNPConfig State is set to ""(.*)""")]
        [Given(@"Administration SNPConfig State is set to ""(.*)""")]
        public void WhenAdministrationSNPConfigStateIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            SelectElement statedrp = new SelectElement(EAM.AdministrationPlanDefinedFieldsTabSpanConfig.State);
            statedrp.SelectByText(p0);
        }


        [When(@"Administration/SNPConfig Page ESRD Checkbox is ""(.*)""")]
        [Given(@"Administration/SNPConfig Page ESRD Checkbox is ""(.*)""")]
        public void WhenAdministrationSNPConfigPageESRDCheckboxIs(string p0)
        {
            string GenerateData = tmsCommon.GenerateData(p0);
            tmsWait.Hard(2);

            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("unchecked"))
            {
                if (EAM.AdministrationPlanDefinedFieldsTabSpanConfig.ESRD.Selected == true)
                {
                    EAM.AdministrationPlanDefinedFieldsTabSpanConfig.ESRD.Click();
                }

            }
            else if (setCheckboxTo.Equals("checked"))
            {
                if (EAM.AdministrationPlanDefinedFieldsTabSpanConfig.ESRD.Selected == false)
                {
                    EAM.AdministrationPlanDefinedFieldsTabSpanConfig.ESRD.Click();
                }
            }
        }

        [When(@"Administration/SNPConfig Page Chronic Type ""(.*)"" is set to ""(.*)""")]
        public void WhenAdministrationSNPConfigPageChronicTypeIsSetTo(string p0, string p1)
        {
            ICollection<IWebElement> chronicTypes = Browser.Wd.FindElements(By.LinkText(p0));
        }


        [Then(@"Administration/SNPConfig Page should get an error message as ""(.*)""")]
        public void ThenAdministrationSNPConfigPageShouldGetAnErrorMessageAs(string p0)
        {
            IWebElement update = EAM.AdministrationPlanDefinedFieldsTabSpanConfig.SelectChronicTypeMessage;
            string updatemessage = update.Text.ToString();

            Assert.IsTrue(p0 == updatemessage, "Passed" + "Asks to select atleast one Chronic Type");
        }

        [Then(@"Verify the \* sign")]
        public void ThenVerifyTheSign()
        {
            if (EAM.AdministrationPlanDefinedFieldsTabSpanConfig.SomeValueNotSelected.Displayed)
            {
                Assert.IsTrue(true,"Passed," + " Mandatory value not selected ");
            }
        }

        [Then(@"Alert window should be shown")]
        public void ThenAlertWindowShouldBeShown()
        {
            Browser.Wd.SwitchTo().Alert().Accept();
            tmsWait.Hard(1);
            Browser.Wd.SwitchTo().DefaultContent();
        }


        [When(@"Administration/SNPConfig Page Save button is Clicked")]
        [Given(@"Administration/SNPConfig Page Save button is Clicked")]
        public void WhenAdministrationSNPConfigPageSaveButtonIsClicked()
        {
            tmsWait.Hard(2);
            EAM.AdministrationPlanDefinedFieldsTabSpanConfig.Save.Click();
            tmsWait.Hard(2);
        }


        [Then(@"Verify\tSNP Configurations added in the grid for SNPType ""(.*)""")]
        public void ThenVerifySNPConfigurationsAddedInTheGridForSNPType(string p0)
        {
            tmsWait.Hard(1);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//tr[@id='ctl00_ctl00_MainMasterContent_MainContent_SNPConfiguration_snpGrid_ctl00__0']/td[contains(.,'" + p0 + "')]")).Displayed);
        }


        [When(@"Administration/SNPConfig Page Audit button is clicked")]
        public void WhenAdministrationSNPConfigPageAuditButtonIsClicked()
        {
            EAM.AdministrationPlanDefinedFieldsTabSpanConfig.Audit.Click();
            tmsWait.Hard(2);
        }

        [Then(@"Verify SNP Configuration History Window has the below row")]
        public void ThenVerifySNPConfigurationHistoryWindowHasTheBelowRow(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.AdministrationPlanDefinedFieldsTabSpanConfig.SNPConfigurationHistory;

                //Look for a next page link.  We will set 'last page of records' here also.
                //           thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "th", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }

                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                //else
                //{
                //    //Click next page link and start over.
                //    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                //    {
                //        thisTP.bNotAtLastPageOfRecords = true;
                //        thisTP.NPL.Click();
                //        tmsWait.Hard(2);
                //    }
                //}
                baseTable = EAM.AdministrationPlanDefinedFieldsTabSpanConfig.SNPConfigurationHistory;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

        [Then(@"Verify SNP Configurations Table has Plan ID as ""(.*)"" PBP as ""(.*)"" SNP Type as ""(.*)"" Months Of Eligibility as ""(.*)""")]
        public void ThenVerifySNPConfigurationsTableHasPlanIDAsPBPAsSNPTypeAsMonthsOfEligibilityAs(string p0, string p1, string p2, string p3)
        {
            string xpathElement = "//table[@id='ctl00_ctl00_MainMasterContent_MainContent_SNPConfiguration_snpGrid_ctl00']//tr/td[contains(.,'" + p3 + "')]/preceding-sibling::td[contains(.,'" + p2 + "')]/preceding-sibling::td[contains(.,'" + p1 + "')]/preceding-sibling::td[contains(.,'" + p0 + "')]";
            bool elementPresence = Browser.Wd.FindElement(By.XPath(xpathElement)).Displayed;

            Assert.IsTrue(elementPresence, "Expected elements are not getting displayed");
        }


        [Then(@"Verify SNP Configurations Table has below row")]
        public void ThenVerifySNPConfigurationsTableHasBelowRow(Table table)
        {
            tmsWait.Hard(2);
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.AdministrationPlanDefinedFieldsTabSpanConfig.ViewSNPConfigurations;

                //Look for a next page link.  We will set 'last page of records' here also.
                //           thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "th", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }

                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                //else
                //{
                //    //Click next page link and start over.
                //    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                //    {
                //        thisTP.bNotAtLastPageOfRecords = true;
                //        thisTP.NPL.Click();
                //        tmsWait.Hard(2);
                //    }
                //}
                baseTable = EAM.AdministrationPlanDefinedFieldsTabSpanConfig.ViewSNPConfigurations;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }


        [Then(@"Verify SNP Configuration History Window is opened up with no records")]
        public void ThenVerifySNPConfigurationHistoryWindowIsOpenedUpWithNoRecords()
        {
            IWebElement baseTable = EAM.AdministrationPlanDefinedFieldsTabSpanConfig.SNPConfigurationHistory;
            //Get rows out of the table on the page, from the table object
            ICollection<IWebElement> myRows = baseTable.FindElements(By.TagName("tr"));
            if (myRows.Count <= 0)
            {
                Assert.IsTrue(true,"SNP Configuration History is empty so row does not exist as expected");
                return;
            }
        }


        [Then(@"Administration Add MMP Table does not have row")]
        [When(@"Administration Add MMP Table does not have row")]
        [Given(@"Administration Add MMP Table does not have row")]
        public void ThenAdministrationAddMMPTableDoesNotHaveRow(Table table)
        {
            //NL 03/27/2015
            //if table is empty return pass
            //Get the table object 
            IWebElement baseTable = EAM.AdministrationMMP.ParametersTable;
            //Get rows out of the table on the page, from the table object
            ICollection<IWebElement> myRows = baseTable.FindElements(By.TagName("tr"));
            if (myRows.Count <= 0)
            {
                Assert.IsTrue(true,"MMP table is empty so row does not exist as expected");
                return;
            }

            //Establish the next page link for flipping pages as necessary
            string NextPageLinkText = "";
            Boolean bNotAtLastPageOfRecords = true;
            Boolean bHaveGoodPageLink = true;
            Boolean bTimeToExit = false;
            IWebElement NPL = null;
            //Get the Table Header off of the test script Gherkin table
            ICollection<string> thisTH = table.Header;
            int thCount = thisTH.Count;
            string[] thisHeader = new string[thisTH.Count];
            thisTH.CopyTo(thisHeader, 0);   //copies the header to an array

            //Set up an array of classes to hold the table data, first one (0) will be the header info
            //The class has flags for this data row being a header, data and if we have yet matched it in our trials
            TableRow[] thisTableArr = new TableRow[table.RowCount + 1];
            thisTableArr[0] = new TableRow();
            thisTableArr[0].RowIsHeader = true;
            thisTableArr[0].RowIsData = false;
            thisTableArr[0].RowIsMatched = false;
            //Add the header data to the array 0 table row instance
            foreach (string thisString in thisHeader)
            {
                thisTableArr[0].Row.Add(thisString);
            }
            int iCounter = 1;
            //Add the Gherkin table row data to the array of rows.  These are all data, not headers, not matched yet.
            foreach (var row in table.Rows)
            {
                thisTableArr[iCounter] = new TableRow();
                thisTableArr[iCounter].RowIsHeader = false;
                thisTableArr[iCounter].RowIsData = true;
                thisTableArr[iCounter].RowIsMatched = false;

                for (int c = 0; c < row.Count; c++)
                {
                    thisTableArr[iCounter].Row.Add(row[c]);
                }
                iCounter++;
            }
            //While we have not matched all rows yet
            //and we are not on the last page of records..
            while (thisTableArr[0].AllRowsMatched(thisTableArr) == false && bNotAtLastPageOfRecords && bTimeToExit == false)
            {
                bNotAtLastPageOfRecords = false;
                //Get the table object again, since the page refreshes we need to get it fresh
                baseTable = EAM.AdministrationMMP.ParametersTable;
                //Get the spans data, this is the current page number.  Derive the next page number.
                ICollection<IWebElement> mySpans = baseTable.FindElements(By.TagName("span"));
                if (mySpans.Count > 0)
                {
                    foreach (IWebElement thisSpan in mySpans)
                    {
                        int CurrentPageNumber = Convert.ToInt16(thisSpan.Text);
                        int NextPageNumber = CurrentPageNumber + 1;
                        NextPageLinkText = NextPageNumber.ToString();
                    }
                    //Find the link for the next page.  (for later)
                    try
                    {
                        if (NextPageLinkText.Length == 0)
                        {
                            NextPageLinkText = "There is no Next page link";
                        }
                        NPL = baseTable.FindElement(By.LinkText(NextPageLinkText));
                    }
                    catch
                    {
                        bNotAtLastPageOfRecords = true;
                        bHaveGoodPageLink = false;
                    }
                }
                else
                {
                    bNotAtLastPageOfRecords = true;
                    bHaveGoodPageLink = false;
                }
                //NL skip next steps if ther are no such elements found

                //Get rows out of the table on the page, from the table object
                myRows = baseTable.FindElements(By.TagName("tr"));
                int RowCount = myRows.Count;
                //Establish an array of table rows for the page data.
                TableRow[] thisDataArr = new TableRow[RowCount];
                int EstablishedRowItemCount = 0;
                int iRowCounter = 0;
                foreach (IWebElement thisRow in myRows)
                {
                    //For each new data row we look at, add a new instance of the class to the array.
                    thisDataArr[iRowCounter] = new TableRow();
                    thisDataArr[iRowCounter].RowIsHeader = true;
                    thisDataArr[iRowCounter].RowIsData = false;
                    thisDataArr[iRowCounter].RowIsMatched = false;
                    //Get all of the elements from the row (<td>)
                    ICollection<IWebElement> myElements;
                    if (iRowCounter == 0)
                    {
                        myElements = thisRow.FindElements(By.TagName("th"));
                    }
                    else
                    {
                        myElements = thisRow.FindElements(By.TagName("td"));
                    }
                    //Row 0 is the header
                    //The rest of the rows are data
                    foreach (IWebElement thisElement in myElements)
                    {
                        if (iRowCounter == 0)
                        {
                            //Finding the normal item count because the page numbers are a data row.
                            //Row 0 is the header
                            EstablishedRowItemCount = myElements.Count;
                            thisDataArr[iRowCounter].RowIsHeader = true;
                            thisDataArr[iRowCounter].RowIsData = false;
                        }
                        else
                        {
                            //Other rows are data
                            thisDataArr[iRowCounter].RowIsHeader = false;
                            thisDataArr[iRowCounter].RowIsData = true;
                        }
                        if (myElements.Count == EstablishedRowItemCount)
                        {
                            //Only add data if we have a data row, not if we have a 0 length row.
                            thisDataArr[iRowCounter].Row.Add(thisElement.Text.ToString());
                        }
                        else
                        {
                            //If this row count isn't the right number of items, we didn't match with expected.
                            thisDataArr[iRowCounter].RowIsData = false;
                        }
                    }
                    iRowCounter++;
                }
                int iTableCounter = 0;
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TableRow TTA in thisTableArr)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.
                    if (TTA.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] ta = TTA.Row.ToArray();

                        //For each row in the page data
                        foreach (TableRow TDA in thisDataArr)
                        {
                            //Convert page data to array elements
                            string[] td = TDA.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.
                            foreach (string tde in td)
                            {
                                if (iElementCounter > 0 && TDA.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (tde != ta[iElementCounter - 1] && ta[iElementCounter - 1].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                        break;
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (td.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same
                            if (bThisRowMatches)
                            {
                                //Report the match, first convert the array back to a string we can read.
                                thisTableArr[iTableCounter].RowIsMatched = true;
                                string TR0 = TableRow.ArrayToString(td);
                                string TR1 = TableRow.ArrayToString(ta);
                                Console.WriteLine("We did not expect to have a matching row.   FAIL");
                                Console.WriteLine("Searching Row Data - " + TR0);
                                Console.WriteLine("Found Row Data ------- " + TR1);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisTableArr[0].AllRowsMatched(thisTableArr);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as FAIL");
                }
                else
                {
                    //Click next page link and start over.
                    if (bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        bNotAtLastPageOfRecords = true;
                        NPL.Click();
                        System.Threading.Thread.Sleep(2000);
                    }
                }
                baseTable = EAM.AdministrationMMP.ParametersTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (bHaveGoodPageLink == false && !fullMatching)
                {
                    int iCount = 0;
                    var TableRow = new TMSString();
                    foreach (TableRow thisTR in thisTableArr)
                    {
                        if (thisTR.RowIsMatched == false && thisTR.RowIsHeader == false)
                        {
                            string thisRowData = TableRow.ArrayToString(thisTR.Row.ToArray());
                            Console.WriteLine("Unmatched Data Row -- " + thisRowData);
                        }
                        iCount++;
                    }
                    Console.WriteLine("No rows in the Gherkin test table were found in the page table data rows.");
                    Assert.AreEqual(true, true, "No rows in the Gherkin test table were found in the page table data rows.");
                    bTimeToExit = true;
                }
            }
        }
    }

    //Nina Lukyanava 03/16/2015
    [Binding]
    public class EAMAdministrationEditLISInformation
    {
        [When(@"Administration Edit LIS Information HIC Number is set to ""(.*)""")]
        public void WhenAdministrationEditLISInformationHICNumberIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            string thisString = tmsCommon.GenerateData(p0);
            EAM.AdministrationEditLISInformation.HICNumber.Clear();
            EAM.AdministrationEditLISInformation.HICNumber.SendKeys(thisString);
        }

        [When(@"Administration Edit LIS Information Search Button is clicked")]
        [Then(@"Administration Edit LIS Information Search Button is clicked")]
        [Given(@"Administration Edit LIS Information Search Button is clicked")]
        public void WhenAdministrationEditLISInformationSearchButtonIsClicked()
        {
            fw.ExecuteJavascript(EAM.AdministrationEditLISInformation.Search);
            tmsWait.Hard(1);
        }



        [When(@"Administration Edit LIS Information Table Select checkbox is set ""(.*)"" for row")]
        public void WhenAdministrationEditLISInformationTableSelectCheckboxIsSetForRow(string p0, Table table)
        {
            try
            {
                tmsWait.Hard(2);
                bool blnCheckBoxValue = false;

                string strCheckBoxValue = tmsCommon.GenerateData(p0).ToUpper();
                List<string> checkValues = new List<string> { "ON", "TRUE", "CHECK" };

                if (checkValues.Contains(strCheckBoxValue))
                {
                    blnCheckBoxValue = true;
                }

                IWebElement objWebTable = EAM.AdministrationEditLISInformation.LISTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index > 0)
                        {
                            index++;
                            string xPath = "//tr[" + index + "]//input[contains(@id,'_chkSelect')]";
                            IWebElement editChkBox = EAM.AdministrationEditLISInformation.LISTable.FindElement(By.XPath(xPath));
                            if (editChkBox.Selected ^ blnCheckBoxValue)
                            {
                                editChkBox.Click();
                                tmsWait.Hard(1);
                                Console.WriteLine("CheckBox was clicked for row[{0}]", index);
                            }
                        }
                        else { Assert.Fail("CheckBox for expected row was not found"); }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Administration Edit LIS Information Table Select checkbox is set: {0}", e.Message);
            }

            tmsWait.Hard(4);
        }

        [When(@"Administration Edit LIS Information Delete Button is clicked")]
        public void WhenAdministrationEditLISInformationDeleteButtonIsClicked()
        {
            EAM.AdministrationEditLISInformation.Delete.Click();
            tmsWait.Hard(1);
            UIMODUtilFunctions.clickOnConfirmationYesDialog();
        }

        [Then(@"Verify popup Message ""(.*)""")]
        public void ThenVerifyPopupMessage(string p0)
        {
            Browser.Wd.SwitchTo().Alert().Accept();
            Browser.Wd.SwitchTo().DefaultContent();
        }

        [When(@"Administration Edit LIS Information Table LIS Level ""(.*)"" Co-Pay Cat ""(.*)"" Start Date ""(.*)"" data check box is Clicked")]
        public void WhenAdministrationEditLISInformationTableLISLevelCo_PayCatStartDateDataCheckBoxIsClicked(string p0, string p1, string p2)
        {
            string xpathElement = "//table[@id='ctl00_ctl00_MainMasterContent_MainContent_GV_EditLIS']//tr/td[contains(.,'" + p0 + "')]/following-sibling::td[contains(.,'" + p1 + "')]/following-sibling::td[contains(.,'" + p2 + "')]/preceding-sibling::td/input[@type='checkbox']";

            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(xpathElement)));
            tmsWait.Hard(2);
        }

        string lisinfo;
        [When(@"Administration Edit LIS information ""(.*)"" is set to ""(.*)""")]
        public void WhenAdministrationEditLISInformationIsSetTo(string p0, string p1)
        {
            string GeneratedData = tmsCommon.GenerateData(p1);

            switch (p0.ToLower())
            {
                case "lisstartdate":

                    IWebElement sdate = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_GV_EditLIS_ctl02_txtStartDate_grid"));
                    lisinfo = GeneratedData.Replace("/", "");
                    sdate.Clear();
                    sdate.SendKeys(lisinfo);
                    tmsWait.Hard(2);
                    break;
                case "lisenddate":
                    tmsWait.Hard(2);
                    IWebElement edate = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_GV_EditLIS_ctl02_txtEnddate_grid"));
                    lisinfo = GeneratedData.Replace("/", "");
                    edate.SendKeys(lisinfo);
                    break;
                case "liscopaycat":
                    break;
                case "listype":
                    SelectElement listype = new SelectElement(Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_GV_EditLIS_ctl04_txtEnddate_grid")));
                    listype.SelectByText(lisinfo);
                    break;
                case "lissource":
                    SelectElement lissource = new SelectElement(Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_GV_EditLIS_ctl04_dd_Source")));
                    lissource.SelectByText(lisinfo);
                    break;
                case "valid":
                    SelectElement lisvalid = new SelectElement(Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_GV_EditLIS_ctl04_dd_Valid_grid")));
                    lisvalid.SelectByText(lisinfo);
                    break;
            }
        }


        [Then(@"Verify Administration Edit LIS Information Table does not have row")]
        public void ThenVerifyAdministrationEditLISInformationTableDoesNotHaveRow(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.AdministrationEditLISInformation.LISTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index >= 0)
                        {
                            Assert.Fail("Row[{0}] was found but shoud NOT ", index);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.IsTrue(true,"Verify Administration Edit LIS Information Table does not have row: {0}", e.Message);
            }
        }

        [When(@"Administration Edit LIS Information Table edit selected row")]
        public void WhenAdministrationEditLISInformationTableEditSelectedRow(Table table)
        {
            string strValue = "", strHeader = "";
            var headersEnum = table.Header.GetEnumerator();

            foreach (var row in table.Rows)
            {
                headersEnum.Reset();

                foreach (var value in row.Values)
                {
                    headersEnum.MoveNext();

                    strValue = tmsCommon.GenerateDataForTable(value);
                    if (strValue.ToLower() != "[skip]")
                    {
                        strHeader = headersEnum.Current.ToLower();
                        switch (strHeader)
                        {
                            case "lis level": new SelectElement(EAM.AdministrationEditLISInformation.EditLISLevel).SelectByText(strValue); break;
                            case "co-pay cat": new SelectElement(EAM.AdministrationEditLISInformation.EditCoPayCat).SelectByText(strValue); break;
                            case "subsidy amt": break;
                            case "start date":
                                {
                                    EAM.AdministrationEditLISInformation.EditStartDate.SendKeys(Keys.Home);
                                    EAM.AdministrationEditLISInformation.EditStartDate.SendKeys(strValue.Replace("/", ""));
                                    break;
                                }
                            case "end date":
                                {
                                    EAM.AdministrationEditLISInformation.EditEndDate.SendKeys(Keys.Home);
                                    EAM.AdministrationEditLISInformation.EditEndDate.SendKeys(strValue.Replace("/", ""));
                                    break;
                                }
                            case "lis type": new SelectElement(EAM.AdministrationEditLISInformation.EditLISType).SelectByText(strValue); break;
                            case "Source": new SelectElement(EAM.AdministrationEditLISInformation.EditSource).SelectByText(strValue); break;
                            case "valid": new SelectElement(EAM.AdministrationEditLISInformation.EditValid).SelectByText(strValue); break;
                            case "current": new SelectElement(EAM.AdministrationEditLISInformation.EditCurrent).SelectByText(strValue); break;
                            default: break;
                        }
                    }
                }
            }
        }

        [When(@"Administration Edit LIS Information Update Button is clicked")]
        public void WhenAdministrationEditLISInformationUpdateButtonIsClicked()
        {

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement savex = Browser.Wd.FindElement(By.XPath("//button[@class='k-button k-grid-save-command']/span"));
                //savex.Click();
                tmsWait.Hard(1);
                fw.ExecuteJavascript(savex);
                tmsWait.Hard(1);
                try
                {
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")));
                    tmsWait.Hard(1);
                }
                catch
                {
                }

                By toastMsg = By.XPath("//div[@class='k-notification-content']");
                string actValue = Browser.Wd.FindElement(toastMsg).Text;
                //Assert.IsTrue(actValue.Contains(msg));
            }

            else
            {
                fw.ExecuteJavascript(EAM.AdministrationEditLISInformation.Update);
                // tmsWait.Hard(1);
                // Browser.ClosePopUps(true);
            }

        }

        [When(@"Administration Edit LIS Information Table LIS Level as ""(.*)"" Copay cat as ""(.*)"" Start Date as ""(.*)"" End Date as ""(.*)"" LIS Type as ""(.*)"" Source as ""(.*)"" Valid as ""(.*)"" Current as ""(.*)""")]
        public void WhenAdministrationEditLISInformationTableLISLevelAsCopayCatAsStartDateAsEndDateAsLISTypeAsSourceAsValidAsCurrentAs(string level, string cat, string start, string end, string LIS, string source, string valid, string current)
        {

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                try
                {
                    tmsWait.Hard(1);
                    By row = By.XPath("//kendo-grid-list[@role='presentation']//td[contains(.,'" + level + "')]/following-sibling::td[contains(.,'" + cat + "')]/following-sibling::td[contains(.,'" + start + "')]/following-sibling::td[contains(.,'" + end + "')]/following-sibling::td[contains(.,'" + source + "')]/following-sibling::td[contains(.,'" + valid + "')]/following-sibling::td[contains(.,'" + current + "')]/following-sibling::td/button[contains(@class,'edit')]");
                    IWebElement element = Browser.Wd.FindElement(row);
                    fw.ExecuteJavascript(element);
                }
                catch (NoSuchElementException ex)
                {
                    Console.WriteLine("No LIS information present");
                }
            }
            else
            {
                try
                {
                    tmsWait.Hard(1);
                    By row = By.XPath("//div[@test-id='lisInformation-grid-lisConfig']//td[contains(.,'" + level + "')]/following-sibling::td[contains(.,'" + cat + "')]/following-sibling::td[contains(.,'" + start + "')]/following-sibling::td[contains(.,'" + end + "')]/following-sibling::td[contains(.,'" + source + "')]/following-sibling::td[contains(.,'" + valid + "')]/following-sibling::td[contains(.,'" + current + "')]/following-sibling::td/a[1]");
                    IWebElement element = Browser.Wd.FindElement(row);
                    fw.ExecuteJavascript(element);
                }
                catch (NoSuchElementException ex)
                {
                    Console.WriteLine("No LIS information present");
                }
            }
            tmsWait.Hard(3);


            //try { 
            //   tmsWait.Hard(1);
            //   string xpathEle = "//table[@id='ctl00_ctl00_MainMasterContent_MainContent_GV_EditLIS']//tr/td[contains(.,'"+current+"')]/preceding-sibling::td[contains(.,'"+valid+"')]/preceding-sibling::td[contains(.,'"+source+"')]/preceding-sibling::td[contains(.,'"+LIS+"')]/preceding-sibling::td[contains(.,'"+end+"')]/preceding-sibling::td[contains(.,'"+start+"')]/preceding-sibling::td[contains(.,'"+cat+"')]/preceding-sibling::td[contains(.,'"+level+"')]/preceding-sibling::td/input";
            //   IWebElement element = Browser.Wd.FindElement(By.XPath(xpathEle));
            //   fw.ExecuteJavascript(element);
            //   }catch(NoSuchElementException ex)
            //   {
            //       Console.WriteLine("No LIS information present");
            //   }
        }

        [When(@"Administration Edit LIS Info Table LIS Level as ""(.*)"" Copay cat as ""(.*)"" Start Date as ""(.*)"" End Date as ""(.*)"" Source as ""(.*)"" Valid as ""(.*)"" Current as ""(.*)""")]
        public void WhenAdministrationEditLISInfoTableLISLevelAsCopayCatAsStartDateAsEndDateAsSourceAsValidAsCurrentAs(string level, string cat, string start, string end, string source, string valid, string current)
        {

            try
            {
                tmsWait.Hard(1);
                By row = By.XPath("//div[@test-id='lisInformation-grid-lisConfig']//td[contains(.,'" + level + "')]/following-sibling::td[contains(.,'" + cat + "')]/following-sibling::td[contains(.,'" + start + "')]/following-sibling::td[contains(.,'" + end + "')]/following-sibling::td[contains(.,'" + source + "')]/following-sibling::td[contains(.,'" + valid + "')]/following-sibling::td[contains(.,'" + current + "')]/following-sibling::td/a[1]");
                IWebElement element = Browser.Wd.FindElement(row);
                fw.ExecuteJavascript(element);
            }
            catch (NoSuchElementException ex)
            {
                Console.WriteLine("No LIS information present");
            }

            tmsWait.Hard(1);
        }



        [Then(@"Verify Members New Tab RXBilling Table has row Level as ""(.*)"" Copay Cat as ""(.*)"" Start Date as ""(.*)"" End Date as ""(.*)"" LIS Type as ""(.*)"" Source as ""(.*)"" Valid as ""(.*)"" current as ""(.*)""")]
        public void ThenVerifyMembersNewTabRXBillingTableHasRowLevelAsCopayCatAsStartDateAsEndDateAsLISTypeAsSourceAsValidAsCurrentAs(string level, string cat, string start, string end, string lis, string source, string valid, string current)
        {
            try
            {

                tmsWait.Hard(2);



                string xpathEle = "//table[@id='ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_RsGrid']//tr/td[contains(.,'" + current + "')]/preceding-sibling::td[contains(.,'" + valid + "')]/preceding-sibling::td[contains(.,'" + source + "')]/preceding-sibling::td[contains(.,'" + lis + "')]/preceding-sibling::td[contains(.,'" + end + "')]/preceding-sibling::td[contains(.,'" + start + "')]/preceding-sibling::td[contains(.,'" + cat + "')]/preceding-sibling::td[contains(.,'" + level + "')]";


                IWebElement element = Browser.Wd.FindElement(By.XPath(xpathEle));

                bool elementPresence = element.Displayed;

                Assert.IsTrue(elementPresence, "Expected Values are not getting displayed");
            }
            catch (NoSuchElementException ex)
            {
                Console.WriteLine("Record Not Found for required Level,Co-Pay" + ex.Message);

            }
        }



        [Then(@"Verify Members New Tab RXBilling Table has second row having ""(.*)"" is ""(.*)""")]
        public void ThenVerifyMembersNewTabRXBillingTableHasSecondRowHavingIs(string p0, string p1)
        {

            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_RsGrid']//tr[3]/td[contains(.,'" + p1 + "')]")).Displayed);

        }

        [Then(@"Verify Members New Tab RXBilling Table has third row having ""(.*)"" is ""(.*)""")]
        public void ThenVerifyMembersNewTabRXBillingTableHasThirdRowHavingIs(string p0, string p1)
        {
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_RsGrid']//tr[4]/td[contains(.,'" + p1 + "')]")).Displayed);
        }



        [When(@"Administration Edit LIS Information table ""(.*)"" field is set to ""(.*)""")]
        public void WhenAdministrationEditLISInformationTableFieldIsSetTo(string field, string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            switch (field)
            {
                case "Source":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("(//kendo-dropdownlist[@test-id='lisInfo-ddlLisSources']//span)[3]");

                        By typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        //tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                        tmsWait.Hard(3);
                    }
                    else
                    {

                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(EAM.AdministrationEditLISInformation.UpdateSource, value);
                    }
                    break;
                case "LIS Type":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("(//kendo-dropdownlist[@test-id='lisInfo-ddlLisType']//span)[3]");

                        By typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        //tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                        tmsWait.Hard(3);
                    }

                    else
                    {
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(EAM.AdministrationEditLISInformation.UpdateLISType, value);
                    }
                    break;
            }

        }


        [Then(@"Verify Administration Edit LIS Information Static Message ""(.*)"" is displayed")]
        public void ThenVerifyAdministrationEditLISInformationStaticMessageIsDisplayed(string p0)
        {
            IWebElement msg = tmsWait.WaitForElementExist(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblMsg"), 15);

            string fieldValue = msg.Text;
            Console.WriteLine("Verify Edit LIS Information Static Message: Expected [{0}], Actual [{1}]", p0, fieldValue);
            Assert.IsTrue(String.Compare(fieldValue, p0) == 0, "VerifyEdit LIS Information Static Message: Expected [{0}], Actual [{1}]", p0, fieldValue);
        }


        [When(@"Administration Edit LIS Information LIS Level is set to ""(.*)""")]
        public void WhenAdministrationEditLISInformationLISLevelIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            string value = tmsCommon.GenerateData(p0);
            UIMODUtilFunctions.selectDropDownValueFromGendoUI(EAM.AdministrationEditLISInformation.LISLevel, value);

        }
        [When(@"Administration Edit LIS Information Add LIS Info button is Clicked")]
        public void WhenAdministrationEditLISInformationAddLISInfoButtonIsClicked()
        {
            IWebElement add = Browser.Wd.FindElement(By.XPath("//span[@class='k-icon k-i-plus']/parent::a"));
            fw.ExecuteJavascript(add);
        }

        [When(@"Administration Edit LIS Information CopayCat is set to ""(.*)""")]
        public void WhenAdministrationEditLISInformationCopayCatIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            string value = tmsCommon.GenerateData(p0);
            UIMODUtilFunctions.selectDropDownValueFromGendoUI(EAM.AdministrationEditLISInformation.CoPayCat, value);

        }

        [When(@"Administration Edit LIS Information StartDate is set to ""(.*)""")]
        public void WhenAdministrationEditLISInformationStartDateIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            fw.ScrollWindowToViewElement(EAM.AdministrationEditLISInformation.StartDate);
            tmsWait.Hard(1);
            ReUsableFunctions.enterValueOnWebElement(EAM.AdministrationEditLISInformation.StartDate, value);
            tmsWait.Hard(1);
            EAM.AdministrationEditLISInformation.StartDate.SendKeys(Keys.Tab);
            // tmsWait.Hard(1);
            // //EAM.AdministrationEditLISInformation.StartDate.SendKeys(Keys.Home);
            // String sdate = "0" + p0.ToString();
            //// EAM.AdministrationEditLISInformation.StartDate.Clear();
            //// EAM.AdministrationEditLISInformation.StartDate.Clear();
            // EAM.AdministrationEditLISInformation.StartDate.SendKeys(sdate.ToString());
            // EAM.AdministrationEditLISInformation.StartDate.SendKeys(Keys.Tab);
            // //fw.ExecuteJavascriptSetText(EAM.AdministrationEditLISInformation.StartDate, p0.ToString());
        }

        [When(@"Administration Edit LIS Information EndDate is set to ""(.*)""")]
        public void WhenAdministrationEditLISInformationEndDateIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            fw.ScrollWindowToViewElement(EAM.AdministrationEditLISInformation.EndDate);
            tmsWait.Hard(1);
            ReUsableFunctions.enterValueOnWebElement(EAM.AdministrationEditLISInformation.EndDate, value);
            tmsWait.Hard(1);
            EAM.AdministrationEditLISInformation.EndDate.SendKeys(Keys.Tab);

            //tmsWait.Hard(1);
            ////EAM.AdministrationEditLISInformation.EndDate.SendKeys(p0.ToString());
            ////EAM.AdministrationEditLISInformation.EndDate.Clear();
            ////EAM.AdministrationEditLISInformation.EndDate.Clear();
            //EAM.AdministrationEditLISInformation.EndDate.SendKeys(p0.ToString());
            //EAM.AdministrationEditLISInformation.StartDate.SendKeys(Keys.Tab);
        }

        [When(@"Administration Edit LIS Information LISType is set to ""(.*)""")]
        public void WhenAdministrationEditLISInformationLISTypeIsSetTo(string p0)
        {
            tmsWait.Hard(1);

            string value = tmsCommon.GenerateData(p0);
            UIMODUtilFunctions.selectDropDownValueFromGendoUI(EAM.AdministrationEditLISInformation.LISType, value);


        }

        [When(@"Administration Edit LIS Information Source is set to ""(.*)""")]
        public void WhenAdministrationEditLISInformationSourceIsSetTo(string p0)
        {
            tmsWait.Hard(1);

            string value = tmsCommon.GenerateData(p0);
            UIMODUtilFunctions.selectDropDownValueFromGendoUI(EAM.AdministrationEditLISInformation.Source, value);

        }

        [When(@"Administration Edit LIS Information Valid is set to ""(.*)""")]
        public void WhenAdministrationEditLISInformationValidIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            SelectElement valid = new SelectElement(EAM.AdministrationEditLISInformation.Valid);
            valid.SelectByText(p0.ToString());
        }

        [When(@"Administration Edit LIS Information Current is set to ""(.*)""")]
        public void WhenAdministrationEditLISInformationCurrentIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            SelectElement current = new SelectElement(EAM.AdministrationEditLISInformation.Current);
            current.SelectByText(p0.ToString());
        }

        [When(@"Administration LIS Information Save Button is clicked")]
        public void WhenAdministrationLISInformationSaveButtonIsClicked()
        {
            tmsWait.Hard(1);
            fw.ExecuteJavascript(EAM.AdministrationEditLISInformation.Save);
            tmsWait.Hard(3);
        }


    }



    //Nina Lukyanava 03/17/2015
    [Binding]
    public class EAMAdministrationPlanDefinedFields
    {
        //**************************************************
        //Plan Defined Fields Tab
        //**************************************************

        //NL 03/31/2015: remove references to Disenrollment Tab as this method is for Plan Definied Fields Tab
        [Then(@"Verify Administration Plan Defined Fields Static Message ""(.*)"" is displayed")]
        public void ThenVerifyAdministrationPlanDefinedFieldsStaticMessageIsDisplayed(string p0)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            try
            {
                var wait = new WebDriverWait(Browser.Wd, TimeSpan.FromSeconds(5));
                wait.Until(ExpectedConditions.ElementIsVisible(By.Id(EAM.AdministrationPlanDefinedFields.StaticMessage.GetAttribute("id"))));
            }
            catch (Exception)
            {
                Console.WriteLine("Time elapsed: {0}", stopwatch.Elapsed.Seconds);
            }
            finally
            {
                stopwatch.Stop();
            }

            //Boolean foundExpectedLabel = false;
            Boolean FoundMessageCorrectly = false;
            string fieldName = "Plan Definied Fields Static Message";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = "";

            try
            {
                string staticMessage = EAM.AdministrationPlanDefinedFields.StaticMessage.Text; //DisenrollMessage.Text;
                if (staticMessage == p0)
                {
                    FoundMessageCorrectly = true;
                    thisFieldValue = staticMessage;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Element {0} was not found. Exception: {1}", fieldName, ex.Message);
            }

            //NL 03/31/2015: commented below because it is not needed for Plan Definied Fields Tab

            //if (!FoundMessageCorrectly)  //If we didn't already find it in the disenrollmessage, try in the DisenrollDiv
            //{
            //    string thisClass = EAM.AdministrationPlanDefinedFields.DisenrollDiv.GetAttribute("class");
            //    IList<IWebElement> thisFieldValueCollection = EAM.AdministrationPlanDefinedFields.DisenrollDiv.FindElements(By.TagName("b"));
            //    foreach (IWebElement thisMessage in thisFieldValueCollection)
            //    {
            //        if (thisMessage.Text == p0)
            //        {
            //            foundExpectedLabel = true;
            //            thisFieldValue = thisMessage.Text;
            //        }
            //    }
            //    FoundMessageCorrectly = (foundExpectedLabel && thisClass == "");
            //}
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
            Assert.AreEqual(true, FoundMessageCorrectly, "Expected Static x Message [" + GeneratedData + "], found static message [" + thisFieldValue + "]");
        }
        [When(@"Administration Plan Defined Fields Transaction Plan 1 is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTransactionPlan1IsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFields.TransactionsPlan1Value.SendKeys(GeneratedData);
        }
        [When(@"Administration Plan Defined Fields Transaction Plan 2 is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTransactionPlan2IsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFields.TransactionsPlan2Value.SendKeys(GeneratedData);
        }
        [When(@"Administration Plan Defined Fields Transaction Plan 3 is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTransactionPlan3IsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFields.TransactionsPlan3Value.SendKeys(GeneratedData);
        }
        [When(@"Administration Plan Defined Fields Transaction Plan 4 is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTransactionPlan4IsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFields.TransactionsPlan4Value.SendKeys(GeneratedData);
        }
        [When(@"Administration Plan Defined Fields Transaction Plan 5 is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTransactionPlan5IsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFields.TransactionsPlan5Value.SendKeys(GeneratedData);
        }
        [When(@"Administration Plan Defined Fields Transaction Plan 6 is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTransactionPlan6IsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFields.TransactionsPlan6Value.SendKeys(GeneratedData);
        }
        [When(@"Administration Plan Defined Fields Transaction Plan 7 is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTransactionPlan7IsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFields.TransactionsPlan7Value.SendKeys(GeneratedData);
        }
        [When(@"Administration Plan Defined Fields Transaction Plan 8 is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTransactionPlan8IsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFields.TransactionsPlan8Value.SendKeys(GeneratedData);
        }
        [When(@"Administration Plan Defined Fields Transaction Plan 9 is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTransactionPlan9IsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFields.TransactionsPlan9Value.SendKeys(GeneratedData);
        }
        [When(@"Administration Plan Defined Fields Transaction Plan 10 is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTransactionPlan10IsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFields.TransactionsPlan10Value.SendKeys(GeneratedData);
        }

        [When(@"Administration Plan Defined Fields Member Plan 1 is set to ""(.*)""")]
        public void ThenAdministrationPlanDefinedFieldsMemberPlan1IsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFields.MembersPlan1Value.SendKeys(GeneratedData);
        }
        [When(@"Administration Plan Defined Fields Member Plan 2 is set to ""(.*)""")]
        public void ThenAdministrationPlanDefinedFieldsMemberPlan2IsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFields.MembersPlan2Value.SendKeys(GeneratedData);
        }
        [When(@"Administration Plan Defined Fields Member Plan 3 is set to ""(.*)""")]
        public void ThenAdministrationPlanDefinedFieldsMemberPlan3IsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFields.MembersPlan3Value.SendKeys(GeneratedData);
        }
        [When(@"Administration Plan Defined Fields Member Plan 4 is set to ""(.*)""")]
        public void ThenAdministrationPlanDefinedFieldsMemberPlan4IsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFields.MembersPlan4Value.SendKeys(GeneratedData);
        }
        [When(@"Administration Plan Defined Fields Member Plan 5 is set to ""(.*)""")]
        public void ThenAdministrationPlanDefinedFieldsMemberPlan5IsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFields.MembersPlan5Value.SendKeys(GeneratedData);
        }
        [When(@"Administration Plan Defined Fields Member Plan 6 is set to ""(.*)""")]
        public void ThenAdministrationPlanDefinedFieldsMemberPlan6IsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFields.MembersPlan6Value.SendKeys(GeneratedData);
        }
        [When(@"Administration Plan Defined Fields Member Plan 7 is set to ""(.*)""")]
        public void ThenAdministrationPlanDefinedFieldsMemberPlan7IsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFields.MembersPlan7Value.SendKeys(GeneratedData);
        }
        [When(@"Administration Plan Defined Fields Member Plan 8 is set to ""(.*)""")]
        public void ThenAdministrationPlanDefinedFieldsMemberPlan8IsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFields.MembersPlan8Value.SendKeys(GeneratedData);
        }

        [When(@"Administration Plan Defined Fields Member Plan 9 is set to ""(.*)""")]
        public void ThenAdministrationPlanDefinedFieldsMemberPlan9IsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFields.MembersPlan9Value.SendKeys(GeneratedData);
        }
        [When(@"Administration Plan Defined Fields Member Plan 10 is set to ""(.*)""")]
        public void ThenAdministrationPlanDefinedFieldsMemberPlan10IsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFields.MembersPlan10Value.SendKeys(GeneratedData);
        }

        [Then(@"Verify Administration Plan Defined Fields Transactions Label Plan 1 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTransactionsLabelPlan1IsSetTo(string p0)
        {
            string fieldName = "Transactions Label Plan 1";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.TransactionsPlan1Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Transactions Label Plan 2 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTransactionsLabelPlan2IsSetTo(string p0)
        {
            string fieldName = "Transactions Label Plan 2";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.TransactionsPlan2Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Transactions Label Plan 3 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTransactionsLabelPlan3IsSetTo(string p0)
        {
            string fieldName = "Transactions Label Plan 3";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.TransactionsPlan3Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Transactions Label Plan 4 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTransactionsLabelPlan4IsSetTo(string p0)
        {
            string fieldName = "Transactions Label Plan 4";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.TransactionsPlan4Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Transactions Label Plan 5 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTransactionsLabelPlan5IsSetTo(string p0)
        {
            string fieldName = "Transactions Label Plan 5";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.TransactionsPlan5Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Transactions Label Plan 6 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTransactionsLabelPlan6IsSetTo(string p0)
        {
            string fieldName = "Transactions Label Plan 6";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.TransactionsPlan6Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Transactions Label Plan 7 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTransactionsLabelPlan7IsSetTo(string p0)
        {
            string fieldName = "Transactions Label Plan 7";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.TransactionsPlan7Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Transactions Label Plan 8 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTransactionsLabelPlan8IsSetTo(string p0)
        {
            string fieldName = "Transactions Label Plan 8";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.TransactionsPlan8Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Transactions Label Plan 9 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTransactionsLabelPlan9IsSetTo(string p0)
        {
            string fieldName = "Transactions Label Plan 9";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.TransactionsPlan9Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Transactions Label Plan 10 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTransactionsLabelPlan10IsSetTo(string p0)
        {
            string fieldName = "Transactions Label Plan 10";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.TransactionsPlan10Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }


        [Then(@"Verify Administration Plan Defined Fields Members Label Plan 1 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsMembersLabelPlan1IsSetTo(string p0)
        {
            string fieldName = "Members Label Plan 1";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.MembersPlan1Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Members Label Plan 2 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsMembersLabelPlan2IsSetTo(string p0)
        {
            string fieldName = "Members Label Plan 2";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.MembersPlan2Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Members Label Plan 3 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsMembersLabelPlan3IsSetTo(string p0)
        {
            string fieldName = "Members Label Plan 3";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.MembersPlan3Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Members Label Plan 4 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsMembersLabelPlan4IsSetTo(string p0)
        {
            string fieldName = "Members Label Plan 4";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.MembersPlan4Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Members Label Plan 5 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsMembersLabelPlan5IsSetTo(string p0)
        {
            string fieldName = "Members Label Plan 5";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.MembersPlan5Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Members Label Plan 6 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsMembersLabelPlan6IsSetTo(string p0)
        {
            string fieldName = "Members Label Plan 6";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.MembersPlan6Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Members Label Plan 7 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsMembersLabelPlan7IsSetTo(string p0)
        {
            string fieldName = "Members Label Plan 7";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.MembersPlan7Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Members Label Plan 8 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsMembersLabelPlan8IsSetTo(string p0)
        {
            string fieldName = "Members Label Plan 8";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.MembersPlan8Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Members Label Plan 9 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsMembersLabelPlan9IsSetTo(string p0)
        {
            string fieldName = "Members Label Plan 9";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.MembersPlan9Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [Then(@"Verify Administration Plan Defined Fields Members Label Plan 10 is set to ""(.*)""")]
        [When(@"Verify Administration Plan Defined Fields Members Label Plan 10 is set to ""(.*)""")]
        [Given(@"Verify Administration Plan Defined Fields Members Label Plan 10 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsMembersLabelPlan10IsSetTo(string p0)
        {
            string fieldName = "Members Label Plan 10";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.MembersPlan10Label.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }


        [Then(@"Verify Administration Plan Defined Fields Members Plan 1 is set to ""(.*)""")]
        [Given(@"Verify Administration Plan Defined Fields Members Plan 1 is set to ""(.*)""")]
        [When(@"Verify Administration Plan Defined Fields Members Plan 1 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsMembersPlan1IsSetTo(string p0)
        {
            string fieldName = "Members Plan 1";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.MembersPlan1Value.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [Then(@"Verify Administration Plan Defined Fields Members Plan 2 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsMembersPlan2IsSetTo(string p0)
        {
            string fieldName = "Members Plan 2";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.MembersPlan2Value.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Members Plan 3 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsMembersPlan3IsSetTo(string p0)
        {
            string fieldName = "Members Plan 3";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.MembersPlan3Value.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Members Plan 4 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsMembersPlan4IsSetTo(string p0)
        {
            string fieldName = "Members Plan 4";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.MembersPlan4Value.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Members Plan 5 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsMembersPlan5IsSetTo(string p0)
        {
            string fieldName = "Members Plan 5";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.MembersPlan5Value.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Members Plan 6 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsMembersPlan6IsSetTo(string p0)
        {
            string fieldName = "Members Plan 6";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.MembersPlan6Value.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Members Plan 7 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsMembersPlan7IsSetTo(string p0)
        {
            string fieldName = "Members Plan 7";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.MembersPlan7Value.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Members Plan 8 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsMembersPlan8IsSetTo(string p0)
        {
            string fieldName = "Members Plan 8";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.MembersPlan8Value.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Members Plan 9 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsMembersPlan9IsSetTo(string p0)
        {
            string fieldName = "Members Plan 9";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.MembersPlan9Value.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Members Plan 10 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsMembersPlan10IsSetTo(string p0)
        {
            string fieldName = "Members Plan 10";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.MembersPlan10Value.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [When(@"Administration Plan Defined Fields Tab Plan (.*)Star Status Plan (.*)Star Status Link is Clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabPlanStarStatusPlanStarStatusLinkIsClicked(int p0, int p1)
        {
            EAM.AdministrationPlanDefinedFieldsPlan5StarStatus.Plan5StarStatusTabLink.Click();
            tmsWait.Hard(1);
        }

        [When(@"Administration Plan Defined Fields Tab Relationship Relationship Link is Clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabRelationshipRelationshipLinkIsClicked()
        {
            EAM.AdministrationPlanDefinedFieldsTabRelationship.RelationshipTabLink.Click();
            tmsWait.Hard(1);
        }

        [When(@"Administration Plan Defined Fields Tab OOA Link is Clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabOOALinkIsClicked()
        {
            fw.ExecuteJavascript(EAM.AdministrationPlanDefinedFieldsOOATab.OOALink);
            tmsWait.Hard(2);
        }
        [When(@"Administration Plan Defined Fields Tab OOA Tab Possible Out of Area Status Tab New Status is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTabOOATabPossibleOutOfAreaStatusTabNewStatusIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFieldsOOATab.NewStatus.SendKeys(GeneratedData);
        }

        [When(@"Administration Plan Defined Fields Tab OOA Tab Possible Out of Area Status Tab Table ""(.*)"" Row Edit Button is Clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabOOATabPossibleOutOfAreaStatusTabTableRowEditButtonIsClicked(string p0)
        {
            tmsWait.Hard(2);
            string editlink = tmsCommon.GenerateData(p0);
            bool hasrow = false;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                string xpath = "//td[contains(.,'" + editlink + "')]/following-sibling::td//span[@class='fas fa-pencil-alt']";
                ReUsableFunctions.clickOnGridElement(xpath);
            }
            else
            {


                int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
                for (int i = 1; i <= totalPagesIntheGrid; i++)
                {
                    try
                    {

                        hasrow = Browser.Wd.FindElement(By.XPath("//div[@test-id='possibleOoaStatus-grid-possibleOoaStatus']//span[contains(.,'" + editlink + "')]/parent::td/following-sibling::td/a")).Displayed;

                        break;
                    }
                    catch
                    {

                        IWebElement nextpage = Browser.Wd.FindElement(By.XPath("(//a[@title='Go to the next page'])[2]"));
                        ReUsableFunctions.clickOnWebElement(nextpage);
                    }

                }
                if (hasrow)
                {
                    IWebElement link = Browser.Wd.FindElement(By.XPath("//div[@test-id='possibleOoaStatus-grid-possibleOoaStatus']//span[contains(.,'" + editlink + "')]/parent::td/following-sibling::td/a"));
                    fw.ExecuteJavascript(link);
                    tmsWait.Hard(2);
                }

            }
        }

        [When(@"Administration Plan Defined Fields Tab OOA Tab Possible Out of Area Status Tab Add button is clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabOOATabPossibleOutOfAreaStatusTabAddButtonIsClicked()
        {

            fw.ExecuteJavascript(EAM.AdministrationPlanDefinedFieldsOOATab.AddStatus);
            tmsWait.Hard(1);

        }
        [When(@"Administration Plan Defined Fields Tab OOA Tab Possible Out of Area Status Tab Table ""(.*)"" Edit link is Clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabOOATabPossibleOutOfAreaStatusTabTableEditLinkIsClicked(string p0)
        {
            string temp = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {//div[@role='presentation']//td[contains(.,'DYtkFGip')]/following-sibling::td/a[contains(@class,'edit')]
                string xpath = "//div[@role='presentation']//td[contains(.,'" + temp + "')]/following-sibling::td/button[contains(@class,'edit')]";
                // fw.ExecuteJavascript(link);
                ReUsableFunctions.clickOnGridElement(xpath);
            }
            else
            {
                IWebElement link = Browser.Wd.FindElement(By.XPath("//div[@id='dgPossibleOoaStatus']//td[contains(.,'" + temp + "')]/following-sibling::td/a"));
                fw.ExecuteJavascript(link);
            }
        }

        [When(@"Administration Plan Defined Fields Tab OOA Tab Possible Out of Area Status Tab Add button is disabled")]
        public void WhenAdministrationPlanDefinedFieldsTabOOATabPossibleOutOfAreaStatusTabAddButtonIsDisabled()
        {
            string enabledStatus = EAM.AdministrationPlanDefinedFieldsOOATab.AddStatus.GetAttribute("disabled");
            if (enabledStatus == "true")
            {
                Console.WriteLine("Add button is disabled as expected");
            }
            else
            {
                Assert.Fail("Administration Plan Defined Fields Tab OOA Tab Possible Out of Area Status Tab Add button was supposed to be disabled");
            }
        }

        [Then(@"Verify Administration Plan Defined Fields Tab OOA Tab Possible Out of Area Status Tab Table Row has data as ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTabOOATabPossibleOutOfAreaStatusTabTableRowHasDataAs(string p0)
        {
            tmsWait.Hard(4);

            string value = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                string xpath = "//div[@role='presentation']//td[contains(.,'" + value + "')]";
                ReUsableFunctions.verifyGridElementPresence(xpath);
            }

            else
            {
                bool elePresence = Browser.Wd.FindElement(By.XPath("//div[@id='dgPossibleOoaStatus']//td[contains(.,'" + value + "')]")).Displayed;

                Assert.IsTrue(elePresence, value + " is not geting displayed");

            }
        }

        [When(@"Administration Plan Defined Fields Tab OOA Tab Possible Out of Area Status Tab Table Edit Row Update Button is clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabOOATabPossibleOutOfAreaStatusTabTableEditRowUpdateButtonIsClicked()
        {
            tmsWait.Hard(2);
            IWebElement elePresence = null;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                elePresence = Browser.Wd.FindElement(By.XPath("//input[@id='name']/parent::td/following-sibling::td//span[@class='fas fa-save']"));
            }
            else
            {
                elePresence = Browser.Wd.FindElement(By.XPath("//div[@test-id='possibleOoaStatus-grid-possibleOoaStatus']//a[contains(@class,'update')]"));
            }
            //  IWebElement elePresence = Browser.Wd.FindElement(By.XPath("//div[@test-id='possibleOoaStatus-grid-possibleOoaStatus']//a[contains(@class,'update')]"));
            // IList <IWebElement> theseInputs = EAM.AdministrationPlanDefinedFieldsOOATab.ViewOOAStatus1.FindElements(By.TagName("a"));
            //foreach (IWebElement thisInput in theseInputs)
            //{
            //    string inputValue = thisInput.GetAttribute("class");
            //    tmsWait.Hard(2);
            //    if (inputValue.Contains("update"))
            //    {
            fw.ExecuteJavascript(elePresence);
            tmsWait.Hard(2);
            //        break;
            //    }
            //}
        }

        [Then(@"Verify Administration Plan Defined Fields Tab OOA Tab Possible Out of Area Status Tab has updated status ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTabOOATabPossibleOutOfAreaStatusTabHasUpdatedStatus(string p0)
        {
            tmsWait.Hard(2);
            string GeneratedData = tmsCommon.GenerateData(p0);
        }

        [Then(@"Verify Administration Plan Defined Fields Tab OOA Tab Possible Out of Area Status Tab status is ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTabOOATabPossibleOutOfAreaStatusTabStatusIs(string expected)
        {
            tmsWait.Hard(2);
            string GeneratedData = tmsCommon.GenerateData(expected);
            string actual1 = (string)fw.ExecuteJavascriptReturnText(EAM.AdministrationPlanDefinedFieldsOOATab.ReportStatus);
            var step1 = Regex.Replace(actual1, @"<[^>]+>|&nbsp;", "").Trim();
            var actual = Regex.Replace(step1, @"\s{2,}", " ");

            if (actual.Contains(GeneratedData))
            {
                Console.WriteLine("Report status message:  expected [" + GeneratedData + "] found [" + actual + "]");
            }
            else
            {
                Assert.Fail("Report status message:  expected [" + GeneratedData + "] found [" + actual + "]");
            }
        }

        [When(@"Administration Plan Defined Fields Tab OOA Tab Possible Out of Area Status Tab Table Name Active Checkbox is ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTabOOATabPossibleOutOfAreaStatusTabTableNameActiveCheckboxIs(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            IList<IWebElement> theseInputs = EAM.AdministrationPlanDefinedFieldsOOATab.ViewOOAStatus.FindElements(By.TagName("input"));
            foreach (IWebElement thisInput in theseInputs)
            {
                string inputValue = thisInput.GetAttribute("value");
                string inputText = thisInput.Text;
                string cbState = "";
                if (thisInput.GetAttribute("type") == "checkbox" && thisInput.GetAttribute("disabled") == null)
                {
                    try
                    {
                        cbState = thisInput.GetAttribute("CHECKED").ToString();
                    }
                    catch
                    {
                        cbState = "null";
                    }
                    if (cbState == "true" && GeneratedData.ToLower() == "off")
                    {
                        thisInput.Click();
                    }
                    if (cbState == "null" && GeneratedData.ToLower() == "on")
                    {
                        thisInput.Click();
                    }

                }
            }

        }
        [When(@"Administration Plan Defined Fields Tab OOA Tab Possible Out of Area Status Tab Table Name Edit field value ""(.*)"" is replaced with ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTabOOATabPossibleOutOfAreaStatusTabTableNameEditFieldValueIsReplacedWith(string p0, string p1)
        {
            tmsWait.Hard(2);
            string GeneratedDataP0 = tmsCommon.GenerateData(p0);
            string GeneratedDataP1 = tmsCommon.GenerateData(p1);
            IWebElement text = null;

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                text = Browser.Wd.FindElement(By.XPath("//input[@id='name']"));
            }
            else
            {
                text = Browser.Wd.FindElement(By.XPath("//div[@id='dgPossibleOoaStatus']//td//input[@type='text']"));


            }
            text.Clear();
            tmsWait.Hard(2);
            text.SendKeys(GeneratedDataP1);
            text.SendKeys(Keys.Tab);
            tmsWait.Hard(2);

        }


        [When(@"Administration Plan Defined Fields Tab OOA Tab Possible Out of Area Status Tab Table Name Edit field with value ""(.*)"" is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTabOOATabPossibleOutOfAreaStatusTabTableNameEditFieldWithValueIsSetTo(string p0, string p1)
        {
            string GeneratedDataP0 = tmsCommon.GenerateData(p0);
            string GeneratedDataP1 = tmsCommon.GenerateData(p1);
            IList<IWebElement> theseInputs = EAM.AdministrationPlanDefinedFieldsOOATab.ViewOOAStatus1.FindElements(By.TagName("input"));
            foreach (IWebElement thisInput in theseInputs)
            {
                string inputValue = thisInput.GetAttribute("value");
                string inputText = thisInput.Text;

                if (thisInput.GetAttribute("value") == GeneratedDataP0)
                {
                    thisInput.Clear();
                    tmsWait.Hard(2);
                    thisInput.SendKeys(GeneratedDataP1);
                    tmsWait.Hard(1);
                }
            }
        }

        [Then(@"Verify Administration Plan Defined Fields Tab OOA Tab Possible Out of Area Status Tab Table Row has data")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTabOOATabPossibleOutOfAreaStatusTabTableRowHasData(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.AdministrationPlanDefinedFieldsOOATab.ViewOOAStatus;

                //Look for a next page link.  We will set 'last page of records' here also.
                //               thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "th", "td");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]" && iElementCounter != 5)
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 5)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[5];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same
                            //if (bThisRowMatches)
                            //{
                            //    IWebElement thisEditTD = ApplicationRow.Element[0];
                            //    IWebElement thisEditImage = thisEditTD.FindElement(By.TagName("input"));
                            //    thisEditImage.Click();
                            //    tmsWait.Hard(2);
                            //}
                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                baseTable = EAM.AdministrationPlanDefinedFieldsOOATab.ViewOOAStatus;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

        [When(@"Administration Plan Defined Fields Tab OOA Tab Possible Out of Area Status Tab Table Row Edit Button is Clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabOOATabPossibleOutOfAreaStatusTabTableRowEditButtonIsClicked(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.AdministrationPlanDefinedFieldsOOATab.ViewOOAStatus;

                //Look for a next page link.  We will set 'last page of records' here also.
                //               thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "th", "td");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]" && iElementCounter != 5)
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 5)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[5];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same
                            if (bThisRowMatches)
                            {
                                tmsWait.Hard(2);
                                IWebElement thisEditTD = ApplicationRow.Element[0];
                                IWebElement thisEditImage = thisEditTD.FindElement(By.TagName("input"));
                                fw.ExecuteJavascript(thisEditImage);

                                tmsWait.Hard(2);
                            }
                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                baseTable = EAM.AdministrationPlanDefinedFieldsOOATab.ViewOOAStatus;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }


        [When(@"Administration Plan Defined Fields Tab Sales Rep Sales Rep Link is Clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabSalesRepSalesRepLinkIsClicked()
        {
            EAM.AdministrationPlanDefinedFieldsTabSalesRep.SalesRepTabLink.Click();
            tmsWait.Hard(1);
        }

        [When(@"Administration Plan Defined Fields Tab Span Types Span Types Link is Clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabSpanTypesSpanTypesLinkIsClicked()
        {
            EAM.AdministrationPlanDefinedFieldsTabSpanTypes.SpanTypesTabLink.Click();
            tmsWait.Hard(1);
        }

        //NL 03/31/2015
        [When(@"Administration Plan Defined Fields Members Fields set values")]
        public void WhenAdministrationPlanDefinedFieldsMembersFieldsSetValues(Table table)
        {
            try
            {
                ICollection<string> thisDataHeader = table.Header;
                foreach (var row in table.Rows)
                {
                    foreach (string header in thisDataHeader)
                    {
                        string rowValue = row[header];
                        string bracketStart = "["; string bracketEnd = "]";
                        string dataValue = "";
                        try
                        {
                            dataValue = rowValue.Substring((rowValue.IndexOf(bracketStart) + bracketStart.Length), (rowValue.IndexOf(bracketEnd) - rowValue.IndexOf(bracketStart) - bracketStart.Length));
                            if (dataValue.ToLower() != "skip") { dataValue = tmsCommon.GenerateData("generate|variable|" + dataValue); }
                        }
                        catch (ArgumentOutOfRangeException e)
                        {
                            dataValue = rowValue;
                            ArgumentOutOfRangeException d = e;
                        }

                        if (dataValue.ToLower() != "skip")
                        {
                            switch (header.ToLower())
                            {
                                case "members changeto1": EAM.AdministrationPlanDefinedFields.MembersPlan1Value.SendKeys(dataValue); break;
                                case "members changeto2": EAM.AdministrationPlanDefinedFields.MembersPlan2Value.SendKeys(dataValue); break;
                                case "members changeto3": EAM.AdministrationPlanDefinedFields.MembersPlan3Value.SendKeys(dataValue); break;
                                case "members changeto4": EAM.AdministrationPlanDefinedFields.MembersPlan4Value.SendKeys(dataValue); break;
                                case "members changeto5": EAM.AdministrationPlanDefinedFields.MembersPlan5Value.SendKeys(dataValue); break;
                                case "members changeto6": EAM.AdministrationPlanDefinedFields.MembersPlan6Value.SendKeys(dataValue); break;
                                case "members changeto7": EAM.AdministrationPlanDefinedFields.MembersPlan7Value.SendKeys(dataValue); break;
                                case "members changeto8": EAM.AdministrationPlanDefinedFields.MembersPlan8Value.SendKeys(dataValue); break;
                                case "members changeto9": EAM.AdministrationPlanDefinedFields.MembersPlan9Value.SendKeys(dataValue); break;
                                case "members changeto10": EAM.AdministrationPlanDefinedFields.MembersPlan10Value.SendKeys(dataValue); break;
                                default: Console.WriteLine("Filed name {0} was not found!", header); break;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Assert.Fail("Administration Plan Defined Fields Members Fields set values. Exception: (0)", ex.Message);
            }
        }

        [When(@"Administration Plan Defined Fields Save Members Fields Button is clicked")]
        public void WhenAdministrationPlanDefinedFieldsSaveMembersFieldsButtonIsClicked()
        {
            EAM.AdministrationPlanDefinedFields.SaveMembersFieldsButton.Click();
            tmsWait.Hard(1);
        }
        [When(@"Administration ""(.*)"" Link is Clicked")]
        public void WhenAdministrationLinkIsClicked(string p0)
        {
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//label[contains(text(),'" + p0 + "')]"));
            fw.ExecuteJavascript(ele);

        }
        [When(@"Administration EAM Configuration ""(.*)"" Link is Clicked")]
        public void WhenAdministrationEAMConfigurationLinkIsClicked(string p0)
        {
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//label[contains(text(),'" + p0 + "')]"));
            fw.ExecuteJavascript(ele);
        }

        [When(@"Administration EAM Configuration page Election Type Validation Switch is ""(.*)""")]
        public void WhenAdministrationEAMConfigurationPageElectionTypeValidationSwitchIs(string p0)
        {
            tmsWait.Hard(4);

            string switchChk = Browser.Wd.FindElement(By.XPath("//div[@test-id='electionTypeValidation-i-allowManualElectionTypeOverride']//span[@role='switch']")).GetAttribute("aria-checked");

            if (p0.ToLower().Equals("on"))
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    if (switchChk.Contains("false"))
                    {
                        Browser.Wd.FindElement(By.XPath("//div[@test-id='electionTypeValidation-i-allowManualElectionTypeOverride']//span[@class='k-switch-handle']")).Click();
                        tmsWait.Hard(4);
                        EAM.AdministrationElectionTypeValidation.ElectionTypeValidationSave.Click();
                        tmsWait.Hard(1);
                        fw.ConsoleReport(" ELECTION Type is set to ON");
                    }
                }
                else
                {
                    if (!(EAM.AdministrationElectionTypeValidation.ElectionTypeValidationSwitch.GetAttribute("value").Equals("true")))
                    {
                        tmsWait.Hard(4);
                        EAM.AdministrationElectionTypeValidation.ElectionTypeValidationSwitchClickable.Click();
                        tmsWait.Hard(4);
                        EAM.AdministrationElectionTypeValidation.ElectionTypeValidationSave.Click();
                        tmsWait.Hard(1);
                        fw.ConsoleReport(" ELECTION Type is set to ON");
                    }
                }
            }
            else
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    if (switchChk.Contains("true"))
                    {
                        tmsWait.Hard(3);
                        Browser.Wd.FindElement(By.XPath("//div[@test-id='electionTypeValidation-i-allowManualElectionTypeOverride']//span[@class='k-switch-handle']")).Click();
                        tmsWait.Hard(3);

                        fw.ConsoleReport(" ELECTION Type is set to OFF");
                    }
                }
                else
                {
                    if (!EAM.AdministrationElectionTypeValidation.ElectionTypeValidationSwitch.GetAttribute("value").Equals("false"))
                    {
                        tmsWait.Hard(3);
                        EAM.AdministrationElectionTypeValidation.ElectionTypeValidationSwitchClickable.Click();
                        fw.ConsoleReport(" ELECTION Type is set to OFF");
                    }
                }
            }

        }



        [When(@"Administration Buisness Rule Link is Clicked")]
        public void WhenAdministrationBuisnessRuleLinkIsClicked()
        {
            tmsWait.Hard(1);

            if (ConfigFile.EnvType.Equals("ESI") || ConfigFile.EnvType.Equals("Main"))
            {
                IWebElement ele;
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    ele = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Business Rules')]"));

                }
                else
                {
                    ele = Browser.Wd.FindElement(By.CssSelector("[test-id='15']"));

                }
                fw.ExecuteJavascript(ele);
            }

            //if (ConfigFile.EnvType.Equals("Main"))
            //{ 
            //    fw.ExecuteJavascript(EAM.BuisnessRulesFields.BuisnessRuleLink);
            //}
            //else { 
            //    fw.ExecuteJavascript(EAM.BuisnessRulesFields.BuisnessRuleLink);
            //}


            tmsWait.Hard(1);
        }

        [When(@"Administration page Modify Assigned Application Details dialog Plan Change PostCMS Check box is ""(.*)""")]
        public void WhenAdministrationPageModifyAssignedApplicationDetailsDialogPlanChangePostCMSCheckBoxIs(string status)
        {
            if (status.ToLower().Equals("checked"))
            {
                if (!EAM.BuisnessRulesFields.Planchangepostcmscheckbox.Selected)
                {
                    EAM.BuisnessRulesFields.Planchangepostcmscheckbox.Click();
                }
            }
            else
            {
                if (EAM.BuisnessRulesFields.Planchangepostcmscheckbox.Selected)
                {
                    EAM.BuisnessRulesFields.Planchangepostcmscheckbox.Click();
                }
            }
        }

        [When(@"Administration page Modify Assigned Application Details dialog ""(.*)"" Check box is ""(.*)""")]
        public void WhenAdministrationPageModifyAssignedApplicationDetailsDialogCheckBoxIs(string p0, string p1)
        {
            IWebElement ElementCheck = null;
            switch (p0.ToString())
            {
                case "Plan Change PostCMS":
                    ElementCheck = EAM.BuisnessRulesFields.Planchangepostcmscheckbox;
                    break;
                case "Enhance Member Dupe Check":
                    ElementCheck = EAM.BuisnessRulesFields.EnhanceMemberDupeCheck;
                    break;
            }

            CheckStatusCheckBox(ElementCheck, p1.ToString());

        }

        public void CheckStatusCheckBox(IWebElement ElementCheck, string status)
        {
            if (status.ToLower().Equals("checked"))
            {
                if (!ElementCheck.Selected)
                {
                    fw.ExecuteJavascript(ElementCheck);
                }
            }
            else
            {
                if (ElementCheck.Selected)
                {
                    fw.ExecuteJavascript(ElementCheck);
                }
            }
        }


        string oevswitch;
        [When(@"Administration page Election Type Validation Check box is ""(.*)""")]
        public void WhenAdministrationPageElectionTypeValidationCheckBoxIs(string status)
        {
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='14']"));
            fw.ExecuteJavascript(ele);

            if (status.ToLower().Equals("checked"))
            {
                oevswitch = "on";
            }
            else
            {
                oevswitch = "off";
            }

            bool iselementpresent = false;
            By OEVStatus = By.XPath("//input[@test-id='electionTypeValidation-input-changeElectionTypeValidation']//span[contains(@class,'switch-" + oevswitch + "')]");
            if (oevswitch.Equals("on"))
            {
                try
                {
                    iselementpresent = Browser.Wd.FindElement(OEVStatus).Displayed;
                    fw.ConsoleReport(" Switch is already in ON Status");
                }
                catch
                {
                    Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-container km-switch-container'])[1]")).Click();
                    tmsWait.Hard(2);
                }
            }

            else if (oevswitch.Equals("off"))

            {
                try
                {
                    iselementpresent = Browser.Wd.FindElement(OEVStatus).Displayed;
                    fw.ConsoleReport(" Switch is already in OFF Status");
                }
                catch
                {
                    Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-container km-switch-container'])[1]")).Click();
                    tmsWait.Hard(2);
                }
            }


            //if (status.ToLower().Equals("checked"))
            //{
            //    if (!EAM.BuisnessRulesFields.ElectionTypeValidationCheckbox.Selected)
            //    {
            //        fw.ExecuteJavascript(EAM.BuisnessRulesFields.ElectionTypeValidationCheckbox);
            //    }
            //}
            //else
            //{
            //    if (EAM.BuisnessRulesFields.ElectionTypeValidationCheckbox.Selected)
            //    {
            //        fw.ExecuteJavascript(EAM.BuisnessRulesFields.ElectionTypeValidationCheckbox);
            //    }
            //}
        }


        [When(@"Administration page Modify Assigned Application Details dialog Plan Change PreCMS Check box is ""(.*)""")]
        public void WhenAdministrationPageModifyAssignedApplicationDetailsDialogPlanChangePreCMSCheckBoxIs(string status)
        {
            tmsWait.Hard(4);
            if (status.ToLower().Equals("checked"))
            {
                if (!EAM.BuisnessRulesFields.PlanChangePreCmsCheckbox.Selected)
                {
                    fw.ExecuteJavascript(EAM.BuisnessRulesFields.PlanChangePreCmsCheckbox);
                }
            }
            else
            {
                if (EAM.BuisnessRulesFields.PlanChangePreCmsCheckbox.Selected)
                {
                    fw.ExecuteJavascript(EAM.BuisnessRulesFields.PlanChangePreCmsCheckbox);
                }
            }
        }

        [Given(@"Administration/BusinessRules Page NotesActions_ShowActions Check box is ""(.*)""")]
        [When(@"Administration/BusinessRules Page NotesActions_ShowActions Check box is ""(.*)""")]
        [Then(@"Administration/BusinessRules Page NotesActions_ShowActions Check box is ""(.*)""")]
        public void WhenAdministrationBusinessRulesPageNotesActions_ShowActionsCheckBoxIs(string p0)
        {
            tmsWait.Hard(4);
            if (p0.ToLower().Equals("checked"))
            {
                if (!EAM.BuisnessRulesFields.NotesActionsShowActions.Selected)
                {
                    fw.ExecuteJavascript(EAM.BuisnessRulesFields.NotesActionsShowActions);
                }
            }
            else
            {
                if (EAM.BuisnessRulesFields.NotesActionsShowActions.Selected)
                {
                    fw.ExecuteJavascript(EAM.BuisnessRulesFields.NotesActionsShowActions);
                }
            }
        }


        [Given(@"Administration/BusinessRules Page Save button is Clicked")]
        [When(@"Administration/BusinessRules Page Save button is Clicked")]
        [Then(@"Administration/BusinessRules Page Save button is Clicked")]
        public void WhenAdministrationBusinessRulesPageSaveButtonIsClicked()
        {
            fw.ExecuteJavascript(EAM.BuisnessRulesFields.BusinessRulesSaveButton);
        }


        [When(@"Administration page EGHP Validation Check box is ""(.*)""")]
        public void WhenAdministrationPageEGHPValidationCheckBoxIs(string status)
        {
            tmsWait.Hard(4);
            string expStatus = tmsCommon.GenerateData(status).ToLower();

            ReUsableFunctions.CheckBoxOperations(EAM.BuisnessRulesFields.EGHPCheckbox, expStatus);

            //if (status.ToLower().Equals("checked"))
            //{
            //    if (!EAM.BuisnessRulesFields.EGHPCheckbox.Selected)
            //    {
            //        EAM.BuisnessRulesFields.EGHPCheckbox.Click();
            //    }
            //}
            //else
            //{
            //    if (EAM.BuisnessRulesFields.EGHPCheckbox.Selected)
            //    {
            //        EAM.BuisnessRulesFields.EGHPCheckbox.Click();
            //    }
            //}
        }

        [When(@"Administration page Save button is clicked")]
        public void WhenAdministrationPageSaveButtonIsClicked()
        {
            fw.ExecuteJavascript(EAM.BuisnessRulesFields.SaveButton);

            tmsWait.Hard(5);
        }


        [Then(@"Verify Administration Plan Defined Fields Members Fields have values")]
        public void ThenVerifyAdministrationPlanDefinedFieldsMembersFieldsHaveValues(Table table)
        {
            int i = 1;
            String actualName = "", actualValue = "";
            foreach (var row in table.Rows)
            {
                string thisElementName = row["Current Name"];
                string bracketStart = "["; string bracketEnd = "]";
                string dataValue = "";
                try
                {
                    dataValue = thisElementName.Substring((thisElementName.IndexOf(bracketStart) + bracketStart.Length), (thisElementName.IndexOf(bracketEnd) - thisElementName.IndexOf(bracketStart) - bracketStart.Length));
                    if (dataValue.ToLower() != "skip") { dataValue = tmsCommon.GenerateData("generate|variable|" + dataValue); }
                }
                catch (ArgumentOutOfRangeException e)
                {
                    dataValue = thisElementName;
                    ArgumentOutOfRangeException d = e;
                }

                thisElementName = dataValue;

                String thisElementValue = row["Change to"];
                dataValue = "";
                try
                {
                    dataValue = thisElementName.Substring((thisElementValue.IndexOf(bracketStart) + bracketStart.Length), (thisElementValue.IndexOf(bracketEnd) - thisElementValue.IndexOf(bracketStart) - bracketStart.Length));
                    if (dataValue.ToLower() != "skip") { dataValue = tmsCommon.GenerateData("generate|variable|" + dataValue); }
                }
                catch (ArgumentOutOfRangeException e)
                {
                    dataValue = thisElementValue;
                    ArgumentOutOfRangeException d = e;
                }
                thisElementValue = dataValue;

                if (thisElementName.ToLower() != "[skip]" & thisElementValue.ToLower() != "[skip]")
                {
                    switch (i)
                    {
                        case 1: { actualName = EAM.AdministrationPlanDefinedFields.MembersPlan1Label.Text; actualValue = EAM.AdministrationPlanDefinedFields.MembersPlan1Value.Text; break; }
                        case 2: { actualName = EAM.AdministrationPlanDefinedFields.MembersPlan2Label.Text; actualValue = EAM.AdministrationPlanDefinedFields.MembersPlan2Value.Text; break; }
                        case 3: { actualName = EAM.AdministrationPlanDefinedFields.MembersPlan3Label.Text; actualValue = EAM.AdministrationPlanDefinedFields.MembersPlan3Value.Text; break; }
                        case 4: { actualName = EAM.AdministrationPlanDefinedFields.MembersPlan4Label.Text; actualValue = EAM.AdministrationPlanDefinedFields.MembersPlan4Value.Text; break; }
                        case 5: { actualName = EAM.AdministrationPlanDefinedFields.MembersPlan5Label.Text; actualValue = EAM.AdministrationPlanDefinedFields.MembersPlan5Value.Text; break; }
                        case 6: { actualName = EAM.AdministrationPlanDefinedFields.MembersPlan6Label.Text; actualValue = EAM.AdministrationPlanDefinedFields.MembersPlan6Value.Text; break; }
                        case 7: { actualName = EAM.AdministrationPlanDefinedFields.MembersPlan7Label.Text; actualValue = EAM.AdministrationPlanDefinedFields.MembersPlan7Value.Text; break; }
                        case 8: { actualName = EAM.AdministrationPlanDefinedFields.MembersPlan8Label.Text; actualValue = EAM.AdministrationPlanDefinedFields.MembersPlan8Value.Text; break; }
                        case 9: { actualName = EAM.AdministrationPlanDefinedFields.MembersPlan9Label.Text; actualValue = EAM.AdministrationPlanDefinedFields.MembersPlan9Value.Text; break; }
                        case 10: { actualName = EAM.AdministrationPlanDefinedFields.MembersPlan10Label.Text; actualValue = EAM.AdministrationPlanDefinedFields.MembersPlan10Value.Text; break; }
                        default: { Assert.AreEqual(true, false, "Members Field with index [" + i + "] not exist"); break; }

                    }
                    Console.WriteLine("Members Fields[{0}]: {1} - {2}", i, thisElementName, thisElementValue);
                    Assert.AreEqual(thisElementName, actualName, "Members Fields[" + i + "]: " + thisElementName + " - " + thisElementValue);
                    Assert.AreEqual(thisElementValue, actualValue, "Members Fields[" + i + "]: " + thisElementName + " - " + thisElementValue);
                }

                i++;
            }
        }
        [Then(@"Verify Administration Plan Defined Fields Transactions Plan 1 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTransactionsPlan1IsSetTo(string p0)
        {
            string fieldName = "Transactions Plan 1";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.TransactionsPlan1Value.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Transactions Plan 2 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTransactionsPlan2IsSetTo(string p0)
        {
            string fieldName = "Transactions Plan 2";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.TransactionsPlan2Value.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Transactions Plan 3 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTransactionsPlan3IsSetTo(string p0)
        {
            string fieldName = "Transactions Plan 3";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.TransactionsPlan3Value.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Transactions Plan 4 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTransactionsPlan4IsSetTo(string p0)
        {
            string fieldName = "Transactions Plan 4";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.TransactionsPlan4Value.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Transactions Plan 5 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTransactionsPlan5IsSetTo(string p0)
        {
            string fieldName = "Transactions Plan 5";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.TransactionsPlan5Value.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Transactions Plan 6 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTransactionsPlan6IsSetTo(string p0)
        {
            string fieldName = "Transactions Plan 6";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.TransactionsPlan6Value.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Transactions Plan 7 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTransactionsPlan7IsSetTo(string p0)
        {
            string fieldName = "Transactions Plan 7";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.TransactionsPlan7Value.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Transactions Plan 8 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTransactionsPlan8IsSetTo(string p0)
        {
            string fieldName = "Transactions Plan 8";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.TransactionsPlan8Value.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Transactions Plan 9 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTransactionsPlan9IsSetTo(string p0)
        {
            string fieldName = "Transactions Plan 9";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.TransactionsPlan9Value.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Transactions Plan 10 is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTransactionsPlan10IsSetTo(string p0)
        {
            string fieldName = "Transactions Plan 10";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.AdministrationPlanDefinedFields.TransactionsPlan10Value.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [When(@"Administration Plan Defined Fields Transactions Fields set values")]
        public void WhenAdministrationPlanDefinedFieldsTransactionsFieldsSetValues(Table table)
        {
            try
            {
                ICollection<string> thisDataHeader = table.Header;
                foreach (var row in table.Rows)
                {
                    foreach (string header in thisDataHeader)
                    {
                        string rowValue = row[header];
                        string bracketStart = "["; string bracketEnd = "]";
                        string dataValue = "";
                        try
                        {
                            dataValue = rowValue.Substring((rowValue.IndexOf(bracketStart) + bracketStart.Length), (rowValue.IndexOf(bracketEnd) - rowValue.IndexOf(bracketStart) - bracketStart.Length));
                            if (dataValue.ToLower() != "skip") { dataValue = tmsCommon.GenerateData("generate|variable|" + dataValue); }
                        }
                        catch (ArgumentOutOfRangeException e)
                        {
                            dataValue = rowValue;
                            ArgumentOutOfRangeException d = e;
                        }

                        if (dataValue.ToLower() != "skip")
                        {
                            switch (header.ToLower())
                            {
                                case "transactions changeto1": EAM.AdministrationPlanDefinedFields.TransactionsPlan1Value.SendKeys(dataValue); break;
                                case "transactions changeto2": EAM.AdministrationPlanDefinedFields.TransactionsPlan2Value.SendKeys(dataValue); break;
                                case "transactions changeto3": EAM.AdministrationPlanDefinedFields.TransactionsPlan3Value.SendKeys(dataValue); break;
                                case "transactions changeto4": EAM.AdministrationPlanDefinedFields.TransactionsPlan4Value.SendKeys(dataValue); break;
                                case "transactions changeto5": EAM.AdministrationPlanDefinedFields.TransactionsPlan5Value.SendKeys(dataValue); break;
                                case "transactions changeto6": EAM.AdministrationPlanDefinedFields.TransactionsPlan6Value.SendKeys(dataValue); break;
                                case "transactions changeto7": EAM.AdministrationPlanDefinedFields.TransactionsPlan7Value.SendKeys(dataValue); break;
                                case "transactions changeto8": EAM.AdministrationPlanDefinedFields.TransactionsPlan8Value.SendKeys(dataValue); break;
                                case "transactions changeto9": EAM.AdministrationPlanDefinedFields.TransactionsPlan9Value.SendKeys(dataValue); break;
                                case "transactions changeto10": EAM.AdministrationPlanDefinedFields.TransactionsPlan10Value.SendKeys(dataValue); break;
                                default: Console.WriteLine("Filed name {0} was not found!", header); break;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Assert.Fail("Administration Plan Defined Fields Transactions Fields set values. Exception: (0)", ex.Message);
            }
        }

        [When(@"Administration Plan Defined Fields Save Transactions Fields Button is clicked")]
        public void WhenAdministrationPlanDefinedFieldsSaveTransactionsFieldsButtonIsClicked()
        {
            EAM.AdministrationPlanDefinedFields.SaveTransactionsFieldsButton.Click();
        }



        [Then(@"Verify Administration Plan Defined Fields Transactions Fields have values")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTransactionsFieldsHaveValues(Table table)
        {
            int i = 1;
            String actualName = "", actualValue = "";
            foreach (var row in table.Rows)
            {
                string thisElementName = row["Current Name"];
                string bracketStart = "["; string bracketEnd = "]";
                string dataValue = "";
                try
                {
                    dataValue = thisElementName.Substring((thisElementName.IndexOf(bracketStart) + bracketStart.Length), (thisElementName.IndexOf(bracketEnd) - thisElementName.IndexOf(bracketStart) - bracketStart.Length));
                    if (dataValue.ToLower() != "skip") { dataValue = tmsCommon.GenerateData("generate|variable|" + dataValue); }
                }
                catch (ArgumentOutOfRangeException e)
                {
                    dataValue = thisElementName;
                    ArgumentOutOfRangeException d = e;
                }

                thisElementName = dataValue;

                String thisElementValue = row["Change to"];
                dataValue = "";
                try
                {
                    dataValue = thisElementName.Substring((thisElementValue.IndexOf(bracketStart) + bracketStart.Length), (thisElementValue.IndexOf(bracketEnd) - thisElementValue.IndexOf(bracketStart) - bracketStart.Length));
                    if (dataValue.ToLower() != "skip") { dataValue = tmsCommon.GenerateData("generate|variable|" + dataValue); }
                }
                catch (ArgumentOutOfRangeException e)
                {
                    dataValue = thisElementValue;
                    ArgumentOutOfRangeException d = e;
                }
                thisElementValue = dataValue;

                if (thisElementName.ToLower() != "[skip]" & thisElementValue.ToLower() != "[skip]")
                {
                    switch (i)
                    {
                        case 1: { actualName = EAM.AdministrationPlanDefinedFields.TransactionsPlan1Label.Text; actualValue = EAM.AdministrationPlanDefinedFields.TransactionsPlan1Value.Text; break; }
                        case 2: { actualName = EAM.AdministrationPlanDefinedFields.TransactionsPlan2Label.Text; actualValue = EAM.AdministrationPlanDefinedFields.TransactionsPlan2Value.Text; break; }
                        case 3: { actualName = EAM.AdministrationPlanDefinedFields.TransactionsPlan3Label.Text; actualValue = EAM.AdministrationPlanDefinedFields.TransactionsPlan3Value.Text; break; }
                        case 4: { actualName = EAM.AdministrationPlanDefinedFields.TransactionsPlan4Label.Text; actualValue = EAM.AdministrationPlanDefinedFields.TransactionsPlan4Value.Text; break; }
                        case 5: { actualName = EAM.AdministrationPlanDefinedFields.TransactionsPlan5Label.Text; actualValue = EAM.AdministrationPlanDefinedFields.TransactionsPlan5Value.Text; break; }
                        case 6: { actualName = EAM.AdministrationPlanDefinedFields.TransactionsPlan6Label.Text; actualValue = EAM.AdministrationPlanDefinedFields.TransactionsPlan6Value.Text; break; }
                        case 7: { actualName = EAM.AdministrationPlanDefinedFields.TransactionsPlan7Label.Text; actualValue = EAM.AdministrationPlanDefinedFields.TransactionsPlan7Value.Text; break; }
                        case 8: { actualName = EAM.AdministrationPlanDefinedFields.TransactionsPlan8Label.Text; actualValue = EAM.AdministrationPlanDefinedFields.TransactionsPlan8Value.Text; break; }
                        case 9: { actualName = EAM.AdministrationPlanDefinedFields.TransactionsPlan9Label.Text; actualValue = EAM.AdministrationPlanDefinedFields.TransactionsPlan9Value.Text; break; }
                        case 10: { actualName = EAM.AdministrationPlanDefinedFields.TransactionsPlan10Label.Text; actualValue = EAM.AdministrationPlanDefinedFields.TransactionsPlan10Value.Text; break; }
                        default: { Assert.Fail("Transactions Field with index [{0}] not exist", i); break; }

                    }

                    Console.WriteLine("Transactions Fields[" + i + "]: " + thisElementName + " - " + thisElementValue);
                    Assert.AreEqual(thisElementName, actualName, "Transactions Fields[" + i + "]: " + thisElementName + " - " + thisElementValue);
                    Assert.AreEqual(thisElementValue, actualValue, "Transactions Fields[" + i + "]: " + thisElementName + " - " + thisElementValue);
                }
                i++;
            }
        }



        [When(@"Administration Plan Defined Fields Tab Span Types Table edited row is updated with values")]
        public void WhenAdministrationPlanDefinedFieldsTabSpanTypesTableEditedRowIsUpdatedWithValues(Table table)
        {
            GherkinTable thisGT = new GherkinTable();
            thisGT.LoadGherkinTable(table);
            string thisSpanTypeValue = thisGT.GTable[1].Row[1];
            string thisActiveCBValue = thisGT.GTable[1].Row[2];
            string setCheckboxTo = "[skip]";
            switch (thisActiveCBValue.ToLower())
            {
                case "checked": { setCheckboxTo = "true"; break; }
                case "on": { setCheckboxTo = "true"; break; }
                case "yes": { setCheckboxTo = "true"; break; }
                case "unchecked": { setCheckboxTo = null; break; }
                case "off": { setCheckboxTo = null; break; }
                case "no": { setCheckboxTo = null; break; }
            }

            IList<IWebElement> theseEditFields = EAM.AdministrationPlanDefinedFieldsTabSpanTypes.SpanTypesTabTable.FindElements(By.TagName("Input"));
            foreach (IWebElement thisEditBox in theseEditFields)
            {
                if (thisEditBox.GetAttribute("type") == "text" && thisSpanTypeValue != "[skip]")
                {
                    thisEditBox.Clear();
                    thisEditBox.SendKeys(thisSpanTypeValue);
                }
            }
            foreach (IWebElement thisCheckBox in theseEditFields)
            {
                if (thisCheckBox.GetAttribute("type") == "checkbox")
                {
                    string actualCheckboxValue = thisCheckBox.GetAttribute("checked");
                    if (thisCheckBox.GetAttribute("type") == "checkbox" && setCheckboxTo != "[skip]")
                    {
                        if (setCheckboxTo == "true" && actualCheckboxValue != "true")
                            thisCheckBox.Click();
                        if (setCheckboxTo == null && actualCheckboxValue == "true")
                            thisCheckBox.Click();
                    }
                }
            }
        }
        [When(@"Administration Plan Defined Fields Tab Sales Rep Table edited row is updated with values")]
        public void WhenAdministrationPlanDefinedFieldsTabSalesRepTableEditedRowIsUpdatedWithValues(Table table)
        {
            GherkinTable thisGT = new GherkinTable();
            thisGT.LoadGherkinTable(table);
            string thisRepNameValue = thisGT.GTable[1].Row[3];
            string thisActiveCBValue = thisGT.GTable[1].Row[4];
            string setCheckboxTo = "[skip]";
            switch (thisActiveCBValue.ToLower())
            {
                case "checked": { setCheckboxTo = "true"; break; }
                case "on": { setCheckboxTo = "true"; break; }
                case "yes": { setCheckboxTo = "true"; break; }
                case "unchecked": { setCheckboxTo = null; break; }
                case "off": { setCheckboxTo = null; break; }
                case "no": { setCheckboxTo = null; break; }
            }

            IList<IWebElement> theseEditFields = EAM.AdministrationPlanDefinedFieldsTabSalesRep.SalesRepTabTable.FindElements(By.TagName("Input"));
            foreach (IWebElement thisEditBox in theseEditFields)
            {
                if (thisEditBox.GetAttribute("type") == "text" && thisRepNameValue != "[skip]")
                {
                    thisEditBox.Clear();
                    thisEditBox.SendKeys(thisRepNameValue);
                }
            }
            foreach (IWebElement thisCheckBox in theseEditFields)
            {
                if (thisCheckBox.GetAttribute("type") == "checkbox")
                {
                    string actualCheckboxValue = thisCheckBox.GetAttribute("checked");
                    if (thisCheckBox.GetAttribute("type") == "checkbox" && setCheckboxTo != "[skip]")
                    {
                        if (setCheckboxTo == "true" && actualCheckboxValue != "true")
                        {
                            thisCheckBox.Click();
                            tmsWait.Hard(2);
                        }
                        if (setCheckboxTo == null && actualCheckboxValue == "true")
                        {
                            thisCheckBox.Click();
                            tmsWait.Hard(2);
                        }
                    }
                }
            }
        }
        [When(@"Administration Plan Defined Fields Tab Sales Rep Table Update Icon is clicked for edited row")]
        public void WhenAdministrationPlanDefinedFieldsTabSalesRepTableUpdateIconIsClickedForEditedRow()
        {
            IList<IWebElement> theseEditFields = EAM.AdministrationPlanDefinedFieldsTabSalesRep.SalesRepTabTable.FindElements(By.TagName("Input"));
            Boolean foundButton = false;
            foreach (IWebElement thisUpdateIcon in theseEditFields)
            {
                if (thisUpdateIcon.GetAttribute("type") == "image" && thisUpdateIcon.GetAttribute("src").Contains("Update.gif"))
                {
                    fw.ExecuteJavascript(thisUpdateIcon);
                    tmsWait.Hard(2);
                    foundButton = true;
                    break;
                }
            }
            Assert.AreEqual(true, foundButton, "Was looking to click the row update button but didn't find it.");
        }
        [When(@"Administration Plan Defined Fields Tab Span Types Table Update Icon is clicked for edited row")]
        public void WhenAdministrationPlanDefinedFieldsTabSpanTypesTableUpdateIconIsClickedForEditedRow()
        {
            IList<IWebElement> theseEditFields = EAM.AdministrationPlanDefinedFieldsTabSpanTypes.SpanTypesTabTable.FindElements(By.TagName("Input"));
            foreach (IWebElement thisUpdateIcon in theseEditFields)
            {
                if (thisUpdateIcon.GetAttribute("type") == "image" && thisUpdateIcon.GetAttribute("src").Contains("Update.gif"))
                {
                    thisUpdateIcon.Click();
                    tmsWait.Hard(4);
                    break;
                }
            }
        }

        [When(@"Administration Plan Defined Fields Tab Span Types Table Edit Icon is clicked for row")]
        public void WhenAdministrationPlanDefinedFieldsTabSpanTypesTableEditIconIsClickedForRow(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.AdministrationPlanDefinedFieldsTabSpanTypes.SpanTypesTabTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                //               thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "th", "td");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]" && iElementCounter != 2)
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 2)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[2];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same
                            if (bThisRowMatches)
                            {
                                IWebElement thisEditTD = ApplicationRow.Element[0];
                                IWebElement thisEditImage = thisEditTD.FindElement(By.TagName("input"));
                                thisEditImage.Click();
                                tmsWait.Hard(2);
                            }
                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                baseTable = EAM.AdministrationPlanDefinedFieldsTabSpanTypes.SpanTypesTabTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

        [Then(@"Administration Plan Defined Fields Tab Span Types Table edited row ""(.*)"" is updated with values ""(.*)""")]
        public void ThenAdministrationPlanDefinedFieldsTabSpanTypesTableEditedRowIsUpdatedWithValues(string p0, string p1)
        {
            string oldvalue = tmsCommon.GenerateData(p0);
            string newvalue = tmsCommon.GenerateData(p1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + oldvalue + "')]/parent::td/preceding-sibling::td/input")));
            tmsWait.Hard(2);
            Browser.Wd.FindElement(By.XPath("//input[@value='" + oldvalue + "']")).Clear();
            tmsWait.Hard(2);
            Browser.Wd.FindElement(By.CssSelector("input[id$='txtSpanTypeEdit']")).SendKeys(newvalue);
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//input[@alt='Update']")));
        }



        [When(@"Administration Plan Defined Fields Tab Sales Rep Table Edit Icon is clicked for row")]
        public void WhenAdministrationPlanDefinedFieldsTabSalesRepTableEditIconIsClickedForRow(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.AdministrationPlanDefinedFieldsTabSalesRep.SalesRepTabTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                //               thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "th", "td");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]" && iElementCounter != 5)
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 5)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[5];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same
                            if (bThisRowMatches)
                            {
                                IWebElement thisEditTD = ApplicationRow.Element[0];
                                IWebElement thisEditImage = thisEditTD.FindElement(By.TagName("input"));
                                thisEditImage.Click();
                                tmsWait.Hard(2);
                            }
                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                baseTable = EAM.AdministrationPlanDefinedFieldsTabSalesRep.SalesRepTabTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }


        [Then(@"Verify  Administration Plan Defined Fields Tab Span Types Table has row ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTabSpanTypesTableHasRow(string p0)
        {
            tmsWait.Hard(1);
            string temp = tmsCommon.GenerateData(p0);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_gridSpanTypes']//tr/td[contains(.,'" + temp + "')]"));
            Assert.IsTrue(ele.Displayed, ele + "is no getting displayed");
            IWebElement link = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_gridSpanTypes']//tr/td[contains(.,'" + temp + "')]/preceding-sibling::td/input"));
            fw.ExecuteJavascript(link);

        }

        [Then(@"Administration Plan Defined Fields Tab Span Types Table edited row is updated with values ""(.*)"" and Updated")]
        public void ThenAdministrationPlanDefinedFieldsTabSpanTypesTableEditedRowIsUpdatedWithValuesAndUpdated(string p0)
        {
            string newvalue = tmsCommon.GenerateData(p0);
            IWebElement text = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_gridSpanTypes']//td//input[@type='text']"));
            text.Clear();
            text.SendKeys(newvalue);
            tmsWait.Hard(1);
            IWebElement update = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_gridSpanTypes']//td//input[@alt='Update']"));
            fw.ExecuteJavascript(update);

        }
        [Then(@"Verify  Administration Plan Defined Fields Tab Span Types Table has values ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTabSpanTypesTableHasValues(string p0)
        {
            string[] values = p0.Split(',');
            IWebElement exp;

            foreach (string temp in values)
            {
                exp = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_gridSpanTypes']//tr[contains(.,'" + temp + "')]"));
                Assert.IsTrue(exp.Displayed, exp + "is not getting displayed");
            }
        }


        [Then(@"Verify  Administration Plan Defined Fields Tab Span Types Table has row")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTabSpanTypesTableHasRow(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.AdministrationPlanDefinedFieldsTabSpanTypes.SpanTypesTabTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "th", "td");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]" && iElementCounter != 2)
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 2)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[2];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same
                            if (bThisRowMatches)
                            {
                                IWebElement thisCheckbox = ApplicationRow.Element[2];
                                string checkboxCheckedAttribute = thisCheckbox.GetAttribute("checked");
                                string expectedCheckboxValue = GherkinTableRow.Row[2].ToString();
                                string expectedValue = "";
                                switch (expectedCheckboxValue.ToLower())
                                {
                                    case "checked": { expectedValue = "true"; break; }
                                    case "on": { expectedValue = "true"; break; }
                                    case "yes": { expectedValue = "true"; break; }
                                    case "unchecked": { expectedValue = null; break; }
                                    case "off": { expectedValue = null; break; }
                                    case "no": { expectedValue = null; break; }
                                }
                                if (checkboxCheckedAttribute != expectedValue && expectedCheckboxValue.ToLower() != "[skip]")
                                {
                                    bThisRowMatches = false;
                                }

                            }

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.AdministrationPlanDefinedFieldsTabSpanTypes.SpanTypesTabTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }
        [Then(@"Verify Administration Plan Defined Fields Tab Sales Rep table has row")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTabSalesRepTableHasRow(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.AdministrationPlanDefinedFieldsTabSalesRep.SalesRepTabTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                //               thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "th", "td");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]" && iElementCounter != 4)
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 4)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[4];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same
                            if (bThisRowMatches)
                            {
                                IWebElement thisCheckbox = ApplicationRow.Element[4];
                                string checkboxCheckedAttribute = thisCheckbox.GetAttribute("checked");
                                string expectedCheckboxValue = GherkinTableRow.Row[4].ToString();
                                string expectedValue = "";
                                switch (expectedCheckboxValue.ToLower())
                                {
                                    case "checked": { expectedValue = "true"; break; }
                                    case "on": { expectedValue = "true"; break; }
                                    case "yes": { expectedValue = "true"; break; }
                                    case "unchecked": { expectedValue = null; break; }
                                    case "off": { expectedValue = null; break; }
                                    case "no": { expectedValue = null; break; }
                                }
                                if (checkboxCheckedAttribute != expectedValue && expectedCheckboxValue.ToLower() != "[skip]")
                                {
                                    bThisRowMatches = false;
                                }

                            }

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                //else
                //{
                //    //Click next page link and start over.
                //    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                //    {
                //        thisTP.bNotAtLastPageOfRecords = true;
                //        thisTP.NPL.Click();
                //        tmsWait.Hard(2);
                //    }
                //}
                baseTable = EAM.AdministrationPlanDefinedFieldsTabSalesRep.SalesRepTabTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }
        [Then(@"Verify Administration Plan Defined Fields Tab Disenrollment Table has row")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTabDisenrollmentTableHasRow(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.AdministrationPlanDefinedFields.DisenrollReasonTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "th", "td");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]" && iElementCounter != 5)
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 5)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[5];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same
                            if (bThisRowMatches)
                            {
                                IWebElement thisCheckbox = ApplicationRow.Element[5];
                                string checkboxCheckedAttribute = thisCheckbox.GetAttribute("checked");
                                string expectedCheckboxValue = GherkinTableRow.Row[5].ToString();
                                string expectedValue = "";
                                switch (expectedCheckboxValue.ToLower())
                                {
                                    case "checked": { expectedValue = "true"; break; }
                                    case "on": { expectedValue = "true"; break; }
                                    case "yes": { expectedValue = "true"; break; }
                                    case "unchecked": { expectedValue = null; break; }
                                    case "off": { expectedValue = null; break; }
                                    case "no": { expectedValue = null; break; }
                                }
                                if (checkboxCheckedAttribute != expectedValue && expectedCheckboxValue.ToLower() != "[skip]")
                                {
                                    bThisRowMatches = false;
                                }

                            }

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.AdministrationPlanDefinedFields.DisenrollReasonTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

        [Then(@"Administration Plan Defined Fields Tab Disenrollment Table Edit icon is clicked for row")]
        public void ThenAdministrationPlanDefinedFieldsTabDisenrollmentTableEditIconIsClickedForRow(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.AdministrationPlanDefinedFields.DisenrollReasonTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "th", "td");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]" && iElementCounter != 5)
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 5)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[5];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same
                            if (bThisRowMatches)
                            {
                                IList<IWebElement> theseElements = ApplicationRow.Element[0].FindElements(By.TagName("input"));
                                foreach (IWebElement thisElement in theseElements)
                                {
                                    if (thisElement.GetAttribute("type").Contains("image"))
                                    {
                                        thisElement.Click();
                                        tmsWait.Hard(1);
                                    }
                                }
                            }
                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.AdministrationPlanDefinedFields.DisenrollReasonTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

        [Then(@"Administration Plan Defined Fields Tab Disenrollment Table Edit Row Update icon is clicked")]
        public void ThenAdministrationPlanDefinedFieldsTabDisenrollmentTableEditRowUpdateIconIsClicked()
        {
            IWebElement baseTable = EAM.AdministrationPlanDefinedFields.DisenrollReasonTable;
            ICollection<IWebElement> theseInputs = baseTable.FindElements(By.TagName("input"));
            foreach (IWebElement thisInput in theseInputs)
            {
                if (thisInput.GetAttribute("src").Contains("Update.gif"))
                {
                    fw.ExecuteJavascript(thisInput);
                    tmsWait.Hard(1);
                    return;
                }
            }
        }



        [Then(@"Administration Plan Defined Fields Tab Disenrollment Table Edit Row values are set to")]
        public void ThenAdministrationPlanDefinedFieldsTabDisenrollmentTableEditRowValuesAreSetTo(Table table)
        {
            try
            {
                tmsWait.Hard(1);
                IWebElement editDescription = EAM.AdministrationPlanDefinedFieldsTabDisenrollment.Table.FindElement(By.XPath("//input[contains(@id, '_GridtxtDescription')]"));
                string editDescriptionID = editDescription.GetAttribute("id");
                string idPartValue = editDescriptionID.Split('_')[5];
                SelectElement editMapTo = new SelectElement(EAM.AdministrationPlanDefinedFieldsTabDisenrollment.Table.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_GridDisenroll_" + idPartValue + "_ddMapToInGrid")));
                IWebElement editActiveChkBox = EAM.AdministrationPlanDefinedFieldsTabDisenrollment.Table.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_GridDisenroll_" + idPartValue + "_cbActiveEdit"));

                IList<IWebElement> activeEditCheckboxes = EAM.AdministrationPlanDefinedFieldsTabDisenrollment.Table.FindElements(By.TagName("input"));
                IWebElement useCheckbox = null;
                foreach (IWebElement thisEditCheckbox in activeEditCheckboxes)
                {
                    if (thisEditCheckbox.GetAttribute("id").Contains("cbActiveEdit") && (thisEditCheckbox.GetAttribute("type").Contains("checkbox")))
                    {
                        useCheckbox = thisEditCheckbox;
                        break;
                    }
                }


                foreach (var row in table.Rows)
                {
                    foreach (var header in table.Header)
                    {
                        string rowValue = row[header];
                        //string bracketStart = "["; string bracketEnd = "]";
                        //string dataValue = "";

                        if (rowValue.ToLower() != "[skip]")
                        {

                            switch (header.ToLower())
                            {

                                case "description":
                                    {
                                        tmsWait.Hard(2);
                                        editDescription = EAM.AdministrationPlanDefinedFieldsTabDisenrollment.Table.FindElement(By.XPath("//input[contains(@id, '_GridtxtDescription')]"));
                                        editDescription.Clear();
                                        editDescription.SendKeys(rowValue);
                                        tmsWait.Hard(1);
                                        break;
                                    }
                                case "active":
                                    {

                                        string CheckboxStatus = useCheckbox.GetAttribute("checked");
                                        //         string CheckboxStatus = editActiveChkBox.GetAttribute("status");
                                        switch (CheckboxStatus)
                                        {
                                            case "true":   //Checkbox is checked.   if our data is off/no/false/unchecked we want to click it.
                                                {
                                                    //                bool isChecked = Convert.ToBoolean(editActiveChkBox.GetAttribute("status").ToString());
                                                    if (new HashSet<string> { "off", "no", "false", "unchecked" }.Contains(rowValue.ToLower()))
                                                    {
                                                        useCheckbox.Click();
                                                        tmsWait.Hard(1);
                                                    }
                                                    break;
                                                }
                                            case null://Checkbox is not checked.   if our data is on/yes/true/checked we want to click it.
                                                {
                                                    if ((new HashSet<string> { "on", "yes", "true", "check" }.Contains(rowValue.ToLower())))
                                                    {
                                                        useCheckbox.Click();
                                                        tmsWait.Hard(1);
                                                    }
                                                    break;
                                                }
                                        }
                                        break;
                                    }
                                case "mapto": { editMapTo.SelectByText(rowValue); break; }
                                default: { Console.WriteLine("Field {0} cannot be edit", header); break; }
                            }
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                Assert.Fail("Administration Plan Defined Fields Tab Disenrollment Table Edit Row values are set to: Exception [{0}]", ex.Message);
            }
        }

        [When(@"Administration Plan Defined Fields Tab Disenrollment Disenrollment Link is Clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabDisenrollmentDisenrollmentLinkIsClicked()
        {
            EAM.AdministrationPlanDefinedFieldsTabDisenrollment.DisenrollmentTabLink.Click();
            tmsWait.Hard(1);

        }

        [When(@"Administration Plan Defined Fields Tab Disenrollment Disenroll Code is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTabDisenrollmentDisenrollCodeIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFieldsTabDisenrollment.DisenrollCode.SendKeys(value);
        }
        [When(@"Administration Plan Defined Fields Tab Disenrollment MapTo is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTabDisenrollmentMapToIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFieldsTabDisenrollment.MapTo.SendKeys(value);
        }
        [When(@"Administration Plan Defined Fields Tab Disenrollment Description is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTabDisenrollmentDescriptionIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFieldsTabDisenrollment.Description.SendKeys(value);
        }
        [When(@"Administration Plan Defined Fields Tab Disenrollment Save Button is clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabDisenrollmentSaveButtonIsClicked()
        {
            EAM.AdministrationPlanDefinedFieldsTabDisenrollment.Save.Click();
            tmsWait.Hard(1);
        }

        [Then(@"Verify Administration Plan Defined Fields Tab Disenrollment Static Message ""(.*)"" is displayed")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTabDisenrollmentStaticMessageIsDisplayed(string p0)
        {
            string StaticMessage;
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            try
            {
                var wait = new WebDriverWait(Browser.Wd, TimeSpan.FromSeconds(5));
                wait.Until(ExpectedConditions.ElementIsVisible(By.Id(EAM.AdministrationPlanDefinedFieldsTabDisenrollment.StaticMessage.GetAttribute("id"))));
            }
            catch (Exception)
            {
                Console.WriteLine("Time elapsed: {0}", stopwatch.Elapsed.Seconds);
            }
            finally
            {
                stopwatch.Stop();
            }
            StaticMessage = EAM.AdministrationPlanDefinedFieldsTabDisenrollment.StaticMessage.Text;
            Assert.AreEqual(true, (StaticMessage == p0), "Expected Static Message [" + p0 + "], found static message [" + StaticMessage + "]");
            fw.ConsoleReport("   Verification Point: StaticMessage is [" + StaticMessage + "], expected [" + p0 + "] - They are expected to match.");
        }

        /**********************************************
         * Plan Defined Fileds Page Tab Groups
         **********************************************/
        [When(@"Administration Plan Defined Fields Tab Groups Groups Link is Clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabGroupsGroupsLinkIsClicked()
        {

            tmsWait.Hard(2);
            EAM.AdministrationPlanDefinedFieldsTabGroups.GroupsTabLink.Click();
            tmsWait.Hard(1);
        }

        [When(@"Administration Plan Defined Fields Tab SGSG ID is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTabSGSGIDIsSetTo(string p0)
        {

            tmsWait.Hard(2);
            string grp = tmsCommon.GenerateData(p0);
            IWebElement text1 = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtSgSgID"));
            text1.SendKeys(grp);
        }

        [When(@"Administration Plan Defined Fields Tab CSCS ID is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTabCSCSIDIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string grp = tmsCommon.GenerateData(p0);
            IWebElement text1 = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtCSCSId"));
            text1.SendKeys(grp);

        }

        [When(@"Administration Plan Defined Fields Tab Class Name is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTabClassNameIsSetTo(string p0)
        {

            tmsWait.Hard(2);
            string grp = tmsCommon.GenerateData(p0);
            IWebElement text1 = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtNameClasses"));
            text1.SendKeys(grp);
        }


        [When(@"Administration Plan Defined Fields Tab GRGR ID is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTabGRGRIDIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string grp = tmsCommon.GenerateData(p0);
            IWebElement text1 = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtGrgrID"));
            text1.SendKeys(grp);

        }

        [When(@"Administration Plan Defined Fields Tab Name is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTabNameIsSetTo(string p0)
        {
            string grp = tmsCommon.GenerateData(p0);
            IWebElement text1 = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtGroupName"));
            text1.SendKeys(grp);
        }

        [When(@"Administration Plan Defined Fields Tab Sub group Name is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTabSubGroupNameIsSetTo(string p0)
        {
            string grp = tmsCommon.GenerateData(p0);
            IWebElement text1 = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_txtSGName"));
            text1.SendKeys(grp);
        }


        [When(@"Administration Plan Defined Fields Tab ""(.*)"" is selected")]
        public void WhenAdministrationPlanDefinedFieldsTabIsSelected(string grp)
        {
            tmsWait.Hard(3);
            string p0 = tmsCommon.GenerateData(grp);
            //IWebElement element = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ListGroupsAdd"));
            //SelectElement drp = new SelectElement(element);
            //drp.SelectByText(p0);
            SelectElement select = new SelectElement(EAM.AdministrationPlanDefinedFieldsTabGroups.GroupsList);
            select.SelectByText(p0);
            tmsWait.Hard(2);
        }


        [When(@"Administration Plan Defined Fields Tab Add Group button is Clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabAddGroupButtonIsClicked()
        {
            IWebElement button = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnGrpAdd"));
            fw.ExecuteJavascript(button);
        }

        [When(@"Administration Plan Defined Fields Tab Add sub Group button is Clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabAddSubGroupButtonIsClicked()
        {
            IWebElement button = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSubGroupAdd"));
            fw.ExecuteJavascript(button);
            tmsWait.Hard(3);
        }

        [When(@"Administration Plan Defined Fields Tab Add Class button is Clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabAddClassButtonIsClicked()
        {
            IWebElement button = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnAddClasses"));
            fw.ExecuteJavascript(button);
        }


        [When(@"Administration Plan Defined Fields Tab Language Language Link is Clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabLanguageLanguageLinkIsClicked()
        {
            EAM.AdministrationPlanDefinedFieldsTabLanguage.LanguageTabLink.Click();
            tmsWait.Hard(1);
        }
        [Then(@"Verify Administration Plan Defined Fields Language Tab Static Message ""(.*)"" is displayed")]
        public void ThenVerifyAdministrationPlanDefinedFieldsLanguageTabStaticMessageIsDisplayed(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string fieldName = "Language Tab Static Message";
            string thisFieldValue = EAM.AdministrationPlanDefinedFieldsTabLanguage.LanguageMessageText.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Relationship Tab Response Message ""(.*)"" is displayed")]
        public void ThenVerifyAdministrationPlanDefinedFieldsRelationshipTabResponseMessageIsDisplayed(string p0)
        {
            tmsWait.Hard(2);
            string GeneratedData = tmsCommon.GenerateData(p0);
            string fieldName = "Relationship Tab Response Message";
            string thisFieldValue = EAM.AdministrationPlanDefinedFieldsTabRelationship.RelationshipMessageText.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Language Tab Response Message ""(.*)"" is displayed")]
        public void ThenVerifyAdministrationPlanDefinedFieldsLanguageTabResponseMessageIsDisplayed(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string fieldName = "Language Tab Response Message";
            string thisFieldValue = EAM.AdministrationPlanDefinedFieldsTabLanguage.LanguageMessageText.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [Then(@"Verify Administration Plan Defined Fields Sales Rep Tab Response Message ""(.*)"" is displayed")]
        public void ThenVerifyAdministrationPlanDefinedFieldsSalesRepTabResponseMessageIsDisplayed(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string fieldName = "Sales Rep Tab Static Message";
            string thisFieldValue = EAM.AdministrationPlanDefinedFieldsTabSalesRep.SalesRepMessageText.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Tab Span Types Response Message ""(.*)"" is displayed")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTabSpanTypesResponseMessageIsDisplayed(string expected)
        {
            tmsWait.Hard(6);
            string GeneratedData = tmsCommon.GenerateData(expected);
            string actual1 = (string)fw.ExecuteJavascriptReturnText(EAM.AdministrationPlanDefinedFieldsTabSpanTypes.SpanTypesMessageText);
            var step1 = Regex.Replace(actual1, @"<[^>]+>|&nbsp;", "").Trim();
            string thisFieldValue = Regex.Replace(step1, @"\s{2,}", " ");

            //string GeneratedData = tmsCommon.GenerateData(p0);
            string fieldName = "Span Types Tab Static Message";
            //string thisFieldValue = EAM.AdministrationPlanDefinedFieldsTabSpanTypes.SpanTypesMessageText.Text;
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [Then(@"Verify Administration Plan Defined Fields Relationship Tab Static Message ""(.*)"" is displayed")]
        public void ThenVerifyAdministrationPlanDefinedFieldsRelationshipTabStaticMessageIsDisplayed(string p0)
        {
            string fieldName = "Administration Plan Defined Fields Relationship tag message";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = "";
            IList<IWebElement> theseElements = EAM.AdministrationPlanDefinedFieldsTabRelationship.RelationshipStaticLabelParent.FindElements(By.TagName("b"));
            Boolean bFoundCorrectTag = false;
            foreach (IWebElement thisElement in theseElements)
            {
                if (thisElement.Text == GeneratedData)
                {
                    bFoundCorrectTag = true;
                    thisFieldValue = thisElement.Text;
                }
            }
            Assert.AreEqual(true, bFoundCorrectTag, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Sales Rep Tab Static Message ""(.*)"" is displayed")]
        public void ThenVerifyAdministrationPlanDefinedFieldsSalesRepTabStaticMessageIsDisplayed(string p0)
        {
            string fieldName = "Administration Plan Defined Fields Sales Rep tag message";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = "";
            IList<IWebElement> theseElements = EAM.AdministrationPlanDefinedFieldsTabSalesRep.SalesRepStaticLabelParent.FindElements(By.TagName("b"));
            Boolean bFoundCorrectTag = false;
            foreach (IWebElement thisElement in theseElements)
            {
                if (thisElement.Text == GeneratedData)
                {
                    bFoundCorrectTag = true;
                    thisFieldValue = thisElement.Text;
                }
            }
            Assert.AreEqual(true, bFoundCorrectTag, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [When(@"Administration Plan Defined Fields Tab Relationship Relation Code is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTabRelationshipRelationCodeIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFieldsTabRelationship.RelationCode.SendKeys(value);
        }
        [When(@"Administration Plan Defined Fields Tab Sales Rep Rep ID is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTabSalesRepRepIDIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFieldsTabSalesRep.RepID.SendKeys(value);
        }
        [When(@"Administration Plan Defined Fields Tab Span Types Span Type is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTabSpanTypesSpanTypeIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string value = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFieldsTabSpanTypes.SpanType.SendKeys(value);
        }
        [When(@"Administration Plan Defined Fields Tab Span Types Save Button is clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabSpanTypesSaveButtonIsClicked()
        {
            EAM.AdministrationPlanDefinedFieldsTabSpanTypes.Save.Click();
            tmsWait.Hard(2);
        }

        [When(@"Administration Plan Defined Fields Tab Sales Rep Rep Name is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTabSalesRepRepNameIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFieldsTabSalesRep.RepName.SendKeys(value);
        }

        [When(@"Administration Plan Defined Fields Tab Relationship Relationship is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTabRelationshipRelationshipIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFieldsTabRelationship.Relationship.SendKeys(value);
        }
        [Then(@"Verify Administration Plan Defined Fields Tab Relationship Relation Code is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTabRelationshipRelationCodeIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string GeneratedData = tmsCommon.GenerateData(p0);
            string fieldName = "Relationship Tab Relation Code Message";
            string thisFieldValue = EAM.AdministrationPlanDefinedFieldsTabRelationship.RelationCode.GetAttribute("value");
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }
        [Then(@"Verify Administration Plan Defined Fields Tab Relationship Relationship is set to ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTabRelationshipRelationshipIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string GeneratedData = tmsCommon.GenerateData(p0);
            string fieldName = "Relationship Tab Relationship Message";
            string thisFieldValue = EAM.AdministrationPlanDefinedFieldsTabRelationship.Relationship.GetAttribute("value");
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [When(@"Administration Plan Defined Fields Tab Relationship Save Button is clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabRelationshipSaveButtonIsClicked()
        {
            fw.ExecuteJavascript(EAM.AdministrationPlanDefinedFieldsTabRelationship.Save);
            tmsWait.Hard(5);
        }
        [When(@"Administration Plan Defined Fields Tab Sales Rep Save Button is clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabSalesRepSaveButtonIsClicked()
        {
            fw.ExecuteJavascript(EAM.AdministrationPlanDefinedFieldsTabSalesRep.Save);
            tmsWait.Hard(4);
        }

        [Then(@"Administration Plan Defined Fields Tab Sales Rep Name ""(.*)"" is not available")]
        public void ThenAdministrationPlanDefinedFieldsTabSalesRepNameIsNotAvailable(string p0)
        {
            //IWebElement salesRepTable = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_gridSalesRep']/tbody"));
            //IReadOnlyCollection<IWebElement> salesreprows = Browser.Wd.FindElements(By.TagName("tr"));
            //foreach(var row in salesreprows)
            //{

            //}
            string repname = tmsCommon.GenerateData(p0);
            Assert.IsFalse((Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_gridSalesRep_ctl09_Label1"))).Text.Contains(repname), "It is allowing more than 20 chars for sale rep name");
        }



        [Then(@"Verify Administration Plan Defined Fields Language Tap Static Message ""(.*)"" is displayed")]
        public void ThenVerifyAdministrationPlanDefinedFieldsLanguageTapStaticMessageIsDisplayed(string p0)
        {
            string fieldName = "Administration Plan Defined Fields Language tag message";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = "";
            IList<IWebElement> theseElements = EAM.AdministrationPlanDefinedFieldsTabLanguage.LanguageStaticLabelParent.FindElements(By.TagName("b"));
            Boolean bFoundCorrectTag = false;
            foreach (IWebElement thisElement in theseElements)
            {
                if (thisElement.Text == GeneratedData)
                {
                    bFoundCorrectTag = true;
                    thisFieldValue = thisElement.Text;
                }
            }
            Assert.AreEqual(true, bFoundCorrectTag, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [When(@"Administration Plan Defined Fields Tab Language Code is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTabLanguageCodeIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFieldsTabLanguage.Code.SendKeys(value);
        }
        [When(@"Administration Plan Defined Fields Tab Language Language is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTabLanguageLanguageIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            EAM.AdministrationPlanDefinedFieldsTabLanguage.Language.SendKeys(value);
        }
        [When(@"Members New Tab Contact Response Relation is set to ""(.*)""")]
        public void ThenMembersNewTabContactResponseRelationIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.AdministrationPlanDefinedFieldsTabContact.ResponsRelation);
            select.SelectByText(value);
            tmsWait.Hard(2);
        }

        [When(@"Administration Plan Defined Fields Tab Language Save Button is clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabLanguageSaveButtonIsClicked()
        {
            fw.ExecuteJavascript(EAM.AdministrationPlanDefinedFieldsTabLanguage.Save);
            tmsWait.Hard(5);
        }
        [Then(@"Varify Administration Plan Defined Fields Tab Relationship Table has row")]
        public void ThenVarifyAdministrationPlanDefinedFieldsTabRelationshipTableHasRow(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.AdministrationPlanDefinedFieldsTabRelationship.RelationshipTabTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "th", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same
                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }

                baseTable = EAM.AdministrationPlanDefinedFieldsTabRelationship.RelationshipTabTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

        [When(@"Verify Administration Plan Defined Fields Tab Relationship Existing Relationship Table has row")]
        [Given(@"Verify Administration Plan Defined Fields Tab Relationship Existing Relationship Table has row")]

        [Then(@"Verify Administration Plan Defined Fields Tab Relationship Existing Relationship Table has row")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTabRelationshipExistingRelationshipTableHasRow(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.AdministrationPlanDefinedFieldsTabRelationship.RelationshipTabTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "th", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]" && iElementCounter != 5)
                                    {
                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.AdministrationPlanDefinedFieldsTabRelationship.RelationshipTabTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }
        [Then(@"Verify Administration Plan Defined Fields Tab Language Existing Language Table has row")]
        [When(@"Verify Administration Plan Defined Fields Tab Language Existing Language Table has row")]
        public void WhenVerifyAdministrationPlanDefinedFieldsTabLanguageExistingLanguageTableHasRow(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.AdministrationPlanDefinedFieldsTabLanguage.LanguageTabTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "th", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]" && iElementCounter != 5)
                                    {
                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.AdministrationPlanDefinedFieldsTabLanguage.LanguageTabTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

        [When(@"Administration Plan Defined Fields Tab Groups Inactive Groups is set to ""(.*)""")]
        [When(@"Administration Plan Defined Fields Tab Groups Active Groups is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTabGroupsActiveGroupsIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            string value = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.AdministrationPlanDefinedFieldsTabGroups.GroupsList);
            select.SelectByText(value);
            tmsWait.Hard(2);
        }
        [When(@"Administration Plan Defined Fields Tab Groups Inactive Sub Group is set to ""(.*)""")]
        [When(@"Administration Plan Defined Fields Tab Groups Active Sub Group is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTabGroupsActiveSubGroupIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string value = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.AdministrationPlanDefinedFieldsTabGroups.SubGroupsList);
            select.SelectByText(value);
            tmsWait.Hard(3);
        }
        [When(@"Administration Plan Defined Fields Tab Groups Inactive Classes is set to ""(.*)""")]
        [When(@"Administration Plan Defined Fields Tab Groups Active Classes is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTabGroupsActiveClassesIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string value = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.AdministrationPlanDefinedFieldsTabGroups.ClassesList);
            select.SelectByText(value);
            tmsWait.Hard(2);
        }
        [When(@"Administration Plan Defined Fields Tab Groups Active Classes Inactivate Button is clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabGroupsActiveClassesInactivateButtonIsClicked()
        {
            EAM.AdministrationPlanDefinedFieldsTabGroups.InactivateClassesButton.Click();
        }
        [When(@"Administration Plan Defined Fields Tab Groups Inactive Classes Activate Button is clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabGroupsInactiveClassesActivateButtonIsClicked()
        {
            EAM.AdministrationPlanDefinedFieldsTabGroups.ActivateClassesButton.Click();
        }
        [Then(@"Verify Administration Plan Defined Fields Tab Groups Static Message ""(.*)"" is displayed")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTabGroupsStaticMessageIsDisplayed(string p0)
        {
            string StaticMessage;
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            try
            {
                var wait = new WebDriverWait(Browser.Wd, TimeSpan.FromSeconds(10));
                wait.Until(ExpectedConditions.ElementIsVisible(By.Id(EAM.AdministrationPlanDefinedFieldsTabGroups.StaticMessage.GetAttribute("id"))));
            }
            catch (Exception)
            {
                Console.WriteLine("Time elapsed: {0}", stopwatch.Elapsed.Seconds);
            }
            finally
            {
                stopwatch.Stop();
            }
            StaticMessage = EAM.AdministrationPlanDefinedFieldsTabGroups.StaticMessage.Text;
            Assert.AreEqual(true, (StaticMessage == p0), "Expected Static Message [" + p0 + "], found static message [" + StaticMessage + "]");
        }
        [Then(@"Verify Administration Plan Defined Fields Tab Groups Inactive Classes does not have value ""(.*)""")]
        [Then(@"Verify Administration Plan Defined Fields Tab Groups Active Classes does not have value ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTabGroupsActiveClassesDoesNotHaveValue(string p0)
        {
            Console.WriteLine("Verify Administration Plan Defined Fields Tab Groups Classes does not have value {0}", p0);

            string expectedValue = (tmsCommon.GenerateData(p0));
            string listValues = "";
            SelectElement selectList = new SelectElement(EAM.AdministrationPlanDefinedFieldsTabGroups.ClassesList);
            IList<IWebElement> options = selectList.Options;
            Boolean isFound = false;
            foreach (IWebElement option in options)
            {
                listValues = listValues + option.Text + ";";
                if (option.Text == expectedValue)
                {
                    isFound = true;
                    break;
                }
            }
            Console.WriteLine("Classes List values are: {0}", listValues);
            Assert.AreEqual(isFound, false, "Classes List has [" + expectedValue + "] value, but should not");
        }


        [When(@"Administration Plan Defined Fields Tab Groups Active Classes Inactive Link is clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabGroupsActiveClassesInactiveLinkIsClicked()
        {
            Console.WriteLine("Administration Plan Defined Fields Tab Groups Active Classes Inactive Link is clicked");

            EAM.AdministrationPlanDefinedFieldsTabGroups.InactiveClassesLink.Click();
        }
        [Then(@"Verify Administration Plan Defined Fields Tab Groups Active Classes has value ""(.*)""")]
        [Then(@"Verify Administration Plan Defined Fields Tab Groups Inactive Classes has value ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTabGroupsInactiveClassesHasValue(string p0)
        {
            tmsWait.Hard(2);
            string expectedValue = (tmsCommon.GenerateData(p0));
            string listValues = "";
            Console.WriteLine("Verify Administration Plan Defined Fields Tab Groups Inactive Classes has value {0}", expectedValue);

            SelectElement selectList = new SelectElement(EAM.AdministrationPlanDefinedFieldsTabGroups.ClassesList);
            IList<IWebElement> options = selectList.Options;
            Boolean isFound = false;
            foreach (IWebElement option in options)
            {
                listValues = listValues + option.Text + ";";
                if (option.Text == expectedValue)
                {
                    isFound = true;
                    break;
                }
            }
            Console.WriteLine("Classes List values are: {0}", listValues);
            Assert.AreEqual(isFound, true, "Classes List does not have [" + expectedValue + "] value, but should");
        }

        [Then(@"Verify Administration Plan Defined Fields Tab Groups Inactive Sub Group does not have value ""(.*)""")]
        [Then(@"Verify Administration Plan Defined Fields Tab Groups Active Sub Group does not have value ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTabGroupsActiveSubGroupDoesNotHaveValue(string p0)
        {
            tmsWait.Hard(2);
            string expectedValue = (tmsCommon.GenerateData(p0));
            string listValues = "";
            Console.WriteLine("Verify Administration Plan Defined Fields Tab Groups Sub Group List does not have value {0}", expectedValue);

            SelectElement selectList = new SelectElement(EAM.AdministrationPlanDefinedFieldsTabGroups.SubGroupsList);
            IList<IWebElement> options = selectList.Options;
            Boolean isFound = false;
            foreach (IWebElement option in options)
            {
                listValues = listValues + option.Text + ";";
                if (option.Text == expectedValue)
                {
                    isFound = true;
                    break;
                }
            }
            Console.WriteLine("Sub Group List values are: {0}", listValues);
            Assert.AreEqual(isFound, false, "Sub Group List has [" + expectedValue + "] value, but should not");
        }

        [When(@"Administration Plan Defined Fields Tab Groups Active Sub Group Inactive Link is clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabGroupsActiveSubGroupInactiveLinkIsClicked()
        {
            EAM.AdministrationPlanDefinedFieldsTabGroups.InactiveSubGroupLink.Click();
        }

        [Then(@"Verify Administration Plan Defined Fields Tab Groups Active Sub Group has value ""(.*)""")]
        [Then(@"Verify Administration Plan Defined Fields Tab Groups Inactive Sub Group has value ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTabGroupsInactiveSubGroupHasValue(string p0)
        {
            tmsWait.Hard(2);
            string expectedValue = (tmsCommon.GenerateData(p0));
            string listValues = "";
            Console.WriteLine("Verify Administration Plan Defined Fields Tab Groups Sub Group List has value {0}", expectedValue);

            SelectElement selectList = new SelectElement(EAM.AdministrationPlanDefinedFieldsTabGroups.SubGroupsList);
            IList<IWebElement> options = selectList.Options;
            Boolean isFound = false;
            foreach (IWebElement option in options)
            {
                listValues = listValues + option.Text + ";";
                if (option.Text == expectedValue)
                {
                    isFound = true;
                    break;
                }
            }
            Console.WriteLine(" Sub Group List values are: {0}", listValues);
            Assert.AreEqual(isFound, true, " Sub Group List does not have [" + expectedValue + "] value, but should");
        }
        [When(@"Administration Plan Defined Fields Tab Groups Inactive Sub Group Activate Button is clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabGroupsInactiveSubGroupActivateButtonIsClicked()
        {
            EAM.AdministrationPlanDefinedFieldsTabGroups.ActivateSubGroupButton.Click();
        }

        [When(@"Administration Plan Defined Fields Tab Groups Add New Class CSCS ID is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTabGroupsAddNewClassCSCSIDIsSetTo(string p0)
        {
            string expectedValue = (tmsCommon.GenerateData(p0));
            EAM.AdministrationPlanDefinedFieldsTabGroups.CSCSID.SendKeys(expectedValue);
        }

        [When(@"Administration Plan Defined Fields Tab Groups Add New Class Name is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTabGroupsAddNewClassNameIsSetTo(string p0)
        {
            string expectedValue = (tmsCommon.GenerateData(p0));
            EAM.AdministrationPlanDefinedFieldsTabGroups.ClassName.SendKeys(expectedValue);
        }
        [When(@"Administration Plan Defined Fields Tab Groups Add Classes Button is clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabGroupsAddClassesButtonIsClicked()
        {
            EAM.AdministrationPlanDefinedFieldsTabGroups.AddClassButton.Click();
        }
        [When(@"Administration Plan Defined Fields Tab Groups Add New Group GRGR ID is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTabGroupsAddNewGroupGRGRIDIsSetTo(string p0)
        {
            string expectedValue = (tmsCommon.GenerateData(p0));
            EAM.AdministrationPlanDefinedFieldsTabGroups.GRGRID.SendKeys(expectedValue);
        }
        [When(@"Administration Plan Defined Fields Tab Groups Add New Group Name is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTabGroupsAddNewGroupNameIsSetTo(string p0)
        {
            string expectedValue = (tmsCommon.GenerateData(p0));
            EAM.AdministrationPlanDefinedFieldsTabGroups.GroupName.SendKeys(expectedValue);
        }
        [When(@"Administration Plan Defined Fields Tab Groups Add Group Button is clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabGroupsAddGroupButtonIsClicked()
        {
            EAM.AdministrationPlanDefinedFieldsTabGroups.AddGroupButton.Click();
            tmsWait.Hard(2);
        }
        [When(@"Administration Plan Defined Fields Tab Groups Add New Sub Group SGSG ID is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTabGroupsAddNewSubGroupSGSGIDIsSetTo(string p0)
        {
            string expectedValue = (tmsCommon.GenerateData(p0));
            EAM.AdministrationPlanDefinedFieldsTabGroups.SGSGID.SendKeys(expectedValue);
        }
        [When(@"Administration Plan Defined Fields Tab Groups Add New Sub Group Name is set to ""(.*)""")]
        public void WhenAdministrationPlanDefinedFieldsTabGroupsAddNewSubGroupNameIsSetTo(string p0)
        {
            string expectedValue = (tmsCommon.GenerateData(p0));
            EAM.AdministrationPlanDefinedFieldsTabGroups.SubGroupName.SendKeys(expectedValue);
        }
        [When(@"Administration Plan Defined Fields Tab Groups Add Sub Group Button is clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabGroupsAddSubGroupButtonIsClicked()
        {
            EAM.AdministrationPlanDefinedFieldsTabGroups.AddSubGroupButton.Click();
            tmsWait.Hard(2);
        }
        [When(@"Administration Plan Defined Fields Tab Groups Active Groups Inactivate Button is clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabGroupsActiveGroupsInactivateButtonIsClicked()
        {
            EAM.AdministrationPlanDefinedFieldsTabGroups.InactivateGroupButton.Click();
            tmsWait.Hard(2);
        }
        [When(@"Administration Plan Defined Fields Tab Groups Active Groups Activate Button is clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabGroupsActiveGroupsActivateButtonIsClicked()
        {
            EAM.AdministrationPlanDefinedFieldsTabGroups.ActivateGroupButton.Click();
            tmsWait.Hard(2);
        }


        [Then(@"Verify Administration Plan Defined Fields Tab Groups Inactive Groups does not have value ""(.*)""")]
        [Then(@"Verify Administration Plan Defined Fields Tab Groups Active Groups does not have value ""(.*)""")]
        public void ThenVerifyAdministrationPlanDefinedFieldsTabGroupsActiveGroupsDoesNotHaveValue(string p0)
        {
            string expectedValue = (tmsCommon.GenerateData(p0));
            string listValues = "";
            Console.WriteLine("Verify Administration Plan Defined Fields Tab Groups Groups List does not have value {0}", expectedValue);

            SelectElement selectList = new SelectElement(EAM.AdministrationPlanDefinedFieldsTabGroups.GroupsList);
            IList<IWebElement> options = selectList.Options;
            Boolean isFound = false;
            foreach (IWebElement option in options)
            {
                listValues = listValues + option.Text + ";";
                if (option.Text == expectedValue)
                {
                    isFound = true;
                    break;
                }
            }
            Console.WriteLine("Groups List values are: {0}", listValues);
            Assert.AreEqual(isFound, false, "Groups List has [" + expectedValue + "] value, but should not");
        }
        [Then(@"Verify Administration Plan Defined Fields Tab Groups Inactive Groups have value ""(.*)""")]
        [Then(@"Verify Administration Plan Defined Fields Tab Groups Active Groups have value ""(.*)""")]
        public void WhenVerifyAdministrationPlanDefinedFieldsTabGroupsActiveGroupsHaveValue(string p0)
        {
            string expectedValue = (tmsCommon.GenerateData(p0));
            string listValues = "";
            Console.WriteLine("Verify Administration Plan Defined Fields Tab Groups Groups List have value {0}", expectedValue);

            SelectElement selectList = new SelectElement(EAM.AdministrationPlanDefinedFieldsTabGroups.GroupsList);
            IList<IWebElement> options = selectList.Options;
            Boolean isFound = false;
            foreach (IWebElement option in options)
            {
                listValues = listValues + option.Text + ";";
                if (option.Text == expectedValue)
                {
                    isFound = true;
                    break;
                }
            }
            Console.WriteLine("Groups List values are: {0}", listValues);
            Assert.AreEqual(isFound, true, "Groups List does not have [" + expectedValue + "] value, but should");
        }

        [When(@"Administration Plan Defined Fields Tab Groups Active Sub Grousp Inactivate Button is clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabGroupsActiveSubGrouspInactivateButtonIsClicked()
        {
            EAM.AdministrationPlanDefinedFieldsTabGroups.InactivateSubGroupButton.Click();
            tmsWait.Hard(2);
        }
        [When(@"Administration Plan Defined Fields Tab Groups Active Groups Inactive Link is clicked")]
        public void WhenAdministrationPlanDefinedFieldsTabGroupsActiveGroupsInactiveLinkIsClicked()
        {
            EAM.AdministrationPlanDefinedFieldsTabGroups.InactiveGroupLink.Click();
            tmsWait.Hard(2);
        }












    }


    //Nina Lukyanava 04/27/2015
    [Binding]
    public class EAMAdministrationAuditingConfiguration
    {
        [When(@"Administration Auditing Configuration ""(.*)"" is set to ""(.*)""")]
        public void WhenAdministrationEditLISInformationHICNumberIsSetTo(string p0, string p1)
        {
            string strActivityName = tmsCommon.GenerateData(p0);
            string strCheckBoxValue = tmsCommon.GenerateData(p1);
            //TODO !!!
        }
    }

    //Nina Lukyanava 05/18/2015
    [Binding]



    public class EAMAdministrationExportSession
    {
        [When(@"Administration Export Session Table Delete icon is clicked for row")]
        [When(@"Administration Export Session Table Delete Icon is Clicked for Row")]
        public void WhenAdministrationExportSessionDeleteIconIsClickedForRow(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.AdministrationExportSession.SessionTable;

                var deleteIcons = EAM.AdministrationExportSession.SessionTable.FindElements(EAM.AdministrationExportSession.DeleteIconBy);
                if (deleteIcons.Count <= 0)
                {
                    fw.ConsoleReport("Administration Export Session Table Delete Icon is Clicked for Row: table is empty");
                    return;
                }

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index > 0)
                        {
                            index++;

                            deleteIcons[index].Click();
                            try
                            {
                                deleteIcons[index].Click();
                            }
                            catch (Exception) { }
                            tmsWait.Hard(2);
                            tmsWait.WaitForReadyStateComplete(30);
                            Browser.ClosePopUps(true);
                            fw.ConsoleReport(string.Format("Delete icon was clicked for row [{0}]", index));
                        }
                        else { Assert.Fail("Delete Icon for row [{0}] was not found", i + 1); }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Administration Export Session Table Delete Icon is Clicked for Row: {0}", e.Message);
            }
        }

        [When(@"verify row is created on Export Session")]
        public void WhenVerifyRowIsCreatedOnExportSession()
        {
            IWebElement objWebTable = EAM.AdministrationExportSession.SessionTable;
            var deleteIcons = EAM.AdministrationExportSession.SessionTable.FindElements(EAM.AdministrationExportSession.DeleteIconBy);
            if (deleteIcons.Count != 1)
            {
                Assert.IsTrue(true,"Row is created for On Demand letter on Export Session page");
            }
        }


        [When(@"Administration Export Session Table All Rows are Deleted")]
        [When(@"Administration Export Session Table All Rows are deleted")]
        [Then(@"Administration Export Session Table All Rows are deleted")]
        [Then(@"Administration Export Session Table All Rows are Deleted")]
        [Given(@"Administration Export Session Table All Rows are deleted")]
        [Given(@"Administration Export Session Table All Rows are Deleted")]
        public void WhenAdministrationExportSessionDeleteIconIsClickedForRow()
        {
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.CssSelector("[title='Administration']")));
            tmsWait.Hard(3);
            By exportsession = By.XPath("//span[contains(.,'Export Session')]");
            AngularFunction.clickOnElement(exportsession);

            tmsWait.Hard(3);
            By noUser = By.XPath("//label[@test-id='onDemandLetter-lbl-mismatchedTemplates']/span[contains(.,'Currently no user exporting a file')]");

            try
            {
                if (Browser.Wd.FindElement(noUser).Displayed)
                {
                    Assert.IsTrue(true, " Some User Exporting");
                }
            }
            catch
            {
                try
                {
                    IWebElement delete;
                    if (ConfigFile.tenantType == "tmsx")
                        delete = Browser.Wd.FindElement(By.XPath("//span[@class='fas fa-trash-alt']/parent::a"));
                    else
                        delete = Browser.Wd.FindElement(By.XPath("//span[@class='fa fa-trash']/parent::a"));
                    while (delete.Displayed)
                    {
                        fw.ExecuteJavascript(delete);
                        tmsWait.Hard(1);
                        UIMODUtilFunctions.clickOnConfirmationYesDialog();
                        tmsWait.Hard(1);
                        Browser.Wd.Navigate().Refresh();
                        tmsWait.Hard(20);
                    }
                }
                catch
                {
                    fw.ConsoleReport("Currently no user exporting a file");
                }
            }

            //IWebElement deleteIcon;
            //while (true)
            //  {
            //      try
            //      {
            //          deleteIcon = EAM.AdministrationExportSession.FirstDeleteIcon;
            //          fw.ExecuteJavascript(deleteIcon);
            //          tmsWait.Hard(1);
            //          Browser.ClosePopUps(true);
            //          tmsWait.Hard(1);

            //      }
            //      catch 
            //      {
            //          fw.ConsoleReport("Administration Export Session Table: all rows were deleted");
            //          return;
            //      }

            //  }
        }

    }




    [Binding]
    public class UserAdministration
    {
        public static string GeneratedUserID;
        public static string GeneratedFirstName;
        public static string GeneratedLastName;

        [When(@"var ""(.*)"" is set to ""(.*)"" for Column ID ""(.*)""")]
        [Given(@"var ""(.*)"" is set to ""(.*)"" for Column ID ""(.*)""")]
        [When(@"var ""(.*)"" is set to ""(.*)"" for Member ID ""(.*)""")]
        public void WhenVarIsSetToForMemberID(string p0, string p1, string p2)
        {
            string MemberID = tmsCommon.GenerateData(p2);
            string queryVar = p1;
            string joinedQuery = queryVar + "'" + MemberID + "''";
            string finalquery = tmsCommon.GenerateData(joinedQuery);
            fw.setVariable(p0, finalquery);
        }

        [When(@"var ""(.*)"" is set to ""(.*)"" for Sub Query Column ID ""(.*)""")]
        public void WhenVarIsSetToForSubQueryColumnID(string p0, string p1, string p2)
        {
            string ColumnID = tmsCommon.GenerateData(p2);
            string queryVar = p1;
            string joinedQuery = queryVar + "'" + ColumnID + "')'";
            string finalquery = tmsCommon.GenerateData(joinedQuery);
            fw.setVariable(p0, finalquery);
        }

        [When(@"variable ""(.*)"" is assigned to ""(.*)"" for Column ID ""(.*)""")]
        public void WhenVariableIsAssignedToForColumnID(string p0, string p1, string p2)
        {
            string MemberID = tmsCommon.GenerateData(p2);
            string queryVar = p1;
            string joinedQuery = queryVar + "'%" + MemberID + "%''";
            string finalquery = tmsCommon.GenerateData(joinedQuery);
            fw.ConsoleReport(" Final Joined SQL Query --> " + finalquery);
            fw.setVariable(p0, finalquery);
        }


        [When(@"var ""(.*)"" is set to ""(.*)"" for cmsfileinfoid ""(.*)""")]
        public void WhenVarIsSetToForCmsfileinfoid(string p0, string p1, string p2)
        {
            string cmsfileinfoid = tmsCommon.GenerateData(p2);
            string queryVar = p1;
            string joinedQuery = queryVar + "'" + cmsfileinfoid + "''";
            string finalquery = tmsCommon.GenerateData(joinedQuery);
            fw.setVariable(p0, finalquery);
        }

        [When(@"var ""(.*)"" is set to ""(.*)"" Column ID ""(.*)"" with ""(.*)""")]
        public void WhenVarIsSetToColumnIDWith(string p0, string p1, string p2, string p3)
        {
            string MemberID = tmsCommon.GenerateData(p2);
            string queryVar = p1;
            string endString = p3;
            string joinedQuery = queryVar + "'" + MemberID + "''";
            string finalquery = tmsCommon.GenerateData(joinedQuery) + endString;
            fw.setVariable(p0, finalquery);
        }
        [When(@"variable ""(.*)"" is set With ""(.*)"" With PlanID ID ""(.*)"" With ""(.*)""PBPID ""(.*)""")]
        public void WhenVariableIsSetWithWithPlanIDIDWithPBPID(string p0, string p1, string p2, string p3, string p4)
        {
            string PlanID = tmsCommon.GenerateData(p2);
            string PbpID = tmsCommon.GenerateData(p4);
            string queryVar = p1;
            string joinedQuery = queryVar + "'" + PlanID + "'" + p3 + "'" + PbpID + "''";
            string finalquery = tmsCommon.GenerateData(joinedQuery);
            fw.setVariable(p0, finalquery);
        }

        [When(@"variable ""(.*)"" is set With ""(.*)"" With Member ID ""(.*)"" With ""(.*)""Coder ID ""(.*)""")]
        public void WhenVariableIsSetWithWithMemberIDWithCoderID(string p0, string p1, string p2, string p3, string p4)
        {


            string MemberID = tmsCommon.GenerateData(p2);
            string coderID = tmsCommon.GenerateData(p4);
            string queryVar = p1;
            string joinedQuery = queryVar + "'" + MemberID + "'" + p3 + "'" + coderID + "''";
            string finalquery = tmsCommon.GenerateData(joinedQuery);
            fw.setVariable(p0, finalquery);
        }


        [When(@"variable ""(.*)"" is set to ""(.*)""")]
        [Given(@"variable ""(.*)"" is set to ""(.*)""")]
        [Then(@"variable ""(.*)"" is set to ""(.*)""")]
        public void WhenVariableIsSetTo(string p0, string p1)
        {
            GeneratedUserID = tmsCommon.GenerateData(p1);
            fw.setVariable(p0, GeneratedUserID);
            tmsWait.Hard(5);
            if ((p0.Equals("HIC")) || (p0.Equals("MBI")))
            {
                GlobalRef.TransMBI = GeneratedUserID;
                GlobalRef.LTMBI = GeneratedUserID;
                GlobalRef.PlanID = GeneratedUserID;
                GlobalRef.MBI = GeneratedUserID;
               


            }
            if (p0.Equals("PlanID"))
            {
                GlobalRef.PlanID = GeneratedUserID;
              

            }

            if (p0.Equals("NewFileName"))
            {
                GlobalRef.NewFileName= GeneratedUserID;
             

            }
            if (p0.Equals("DOB"))
            {
                GlobalRef.DOB = GeneratedUserID;
                

            }

            if (p0.Equals("Sex"))
            {
                GlobalRef.Sex = GeneratedUserID;
               

            }

            if (p0.Equals("VerificationDate"))
            {
                GlobalRef.VerificationDate = GeneratedUserID;


            }

            if (p0.Equals("FollowUpDate"))
            {
                GlobalRef.FollowUpDate = GeneratedUserID;


            }

        }


        [When(@"HIC is set to the value returned from DB on executing ""(.*)""")]
        public void WhenHICIsSetToTheValueReturnedFromDBOnExecuting(string Querystring)
        {
            Dictionary<int, string[]> table = new Dictionary<int, string[]>();
            string SqlString = tmsCommon.GenerateData(Querystring);
            fsRSMLogin Executequery = new fsRSMLogin();
            table = Executequery.ExecuteSingleQuery(SqlString, ConfigFile.EAMdb, 5);
            //1st key of the dictionary will return 1st row from DB
            string[] valuesFromDB = table[0];
            GeneratedUserID = tmsCommon.GenerateData(valuesFromDB[4]);
            fw.setVariable("HIC", GeneratedUserID);
        }

        [Then(@"Verify Administration Edit LIS Information Table has row")]
        public void ThenVerifyAdministrationEditLISInformationTableHasRow(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.AdministrationEditLISInformation.LISTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", index, arrRes[i, i]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Verify Administration Edit LIS Information Table has row: {0}", e.Message);
            }
        }


        [Given(@"Client List value selected ""(.*)""")]
        [Then(@"Client List value selected ""(.*)""")]
        [When(@"Client List value selected ""(.*)""")]
        public void GivenClientListValueSelected(string p0)
        {
            tmsWait.Hard(1);
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.UserAdministrationCrudUser.TmsServerList);
            select.SelectByText(GeneratedData);
            tmsWait.Hard(5);
        }


        [Given(@"variable ""(.*)"" is set to")]
        [Then(@"variable ""(.*)"" is set to")]
        public void GivenVariableIsSetTo(string p0, string multilineText)
        {
            string GeneratedData = tmsCommon.GenerateData(multilineText);
            fw.setVariable(p0, multilineText);
        }


        [When(@"IdentityManager Menu ""(.*)"" clicked")]
        public void WhenIdentityManagerMenuClicked(string p0)
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='header-btn-expanMenu']")));

            switch (p0)
            {
                case "Tenant Configuration":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]")));
                    break;
                case "User Management":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]")));
                    break;
                case "Identity Provider Administration":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]")));
                    break;
                case "Secrets Configuration":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]")));
                    break;
            }
        }


        [When(@"IdentityManager TenantConfiguration Edit icon is clicked for client redirect url")]
        public void WhenIdentityManagerTenantConfigurationEditIconIsClickedForClientRedirectUrl()
        {
            tmsWait.Hard(1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//tr[1]/td/a[@class='k-button k-button-icontext small btn btn-link editUser k-grid-edit'])[1]")));    //Clicking edit link for the first record
        }

        [When(@"IdentityManager TenantConfiguration Save icon is clicked client redirect url")]
        public void WhenIdentityManagerTenantConfigurationSaveIconIsClickedClientRedirectUrl()
        {
            tmsWait.Hard(1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@class='k-i-check fa fa-floppy-o']")));    //Clicking edit link for the first record
        }

        [Then(@"I clicked Back Button")]
        public void ThenIClickedBackButton()
        {

            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(text(),'Back')]")));
            tmsWait.Hard(5);
        }

        [Given(@"I click Add New User link")]
        [Then(@"I click Add New User link")]
        [When(@"I click Add New User link")]
        public void GivenIClickAddNewUserLink()
        {
            tmsWait.Implicit(30);
            tmsWait.Hard(5);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                fw.ExecuteJavascript(EAM.UserAdministrationCrudUser.AngularAddNewUser);
            }
            else
            {
                fw.ExecuteJavascript(EAM.UserAdministrationCrudUser.AddNewUser);
            }

        }


        [Given(@"Administration New User Display Name field to ""(.*)""")]
        public void GivenAdministrationNewUserDisplayNameFieldTo(string p0)
        {
            string GeneratedLoginName = tmsCommon.GenerateData(p0);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                EAM.UserAdministrationCrudUser.AngularLoginName.SendKeys(GeneratedLoginName);
            }
            else
            {
                EAM.UserAdministrationCrudUser.DisplayName.SendKeys(GeneratedLoginName);
            }

           
        }

        [Given(@"Administration New User User ID field to ""(.*)""")]
        [When(@"Administration New User User ID field to ""(.*)""")]
        [Then(@"Administration New User User ID field to ""(.*)""")]
        public void GivenAdministrationNewUserUserIDFieldTo(string p0)
        {
            tmsWait.Implicit(30);
            GeneratedUserID = tmsCommon.GenerateData(p0);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                EAM.UserAdministrationCrudUser.AngularLoginName.SendKeys(GeneratedUserID);
            }
            else
            {
                EAM.UserAdministrationCrudUser.UserID.SendKeys(GeneratedUserID);
            }


        }

        [Given(@"User Management page Login Name is set to ""(.*)""")]
        public void GivenUserManagementPageLoginNameIsSetTo(string p0)
        {
            GeneratedUserID = tmsCommon.GenerateData(p0);
            EAM.UserAdministrationCrudUser.UserID.SendKeys(GeneratedUserID);
        }


        [Given(@"Administration New User User ID field ""(.*)"" for ""(.*)""")]
        [Then(@"Administration New User User ID field ""(.*)"" for ""(.*)""")]
        public void GivenAdministrationNewUserUserIDFieldFor(string p0, string p1)
        {
            //it looks like a new control came on the page, we need to select the
            //TMS-QA from client drop down
            try
            {
                SelectElement select = new SelectElement(EAM.UserAdministrationCrudUser.ClientListDropdown);
                select.SelectByText(p1);
                tmsWait.Hard(5);
            }
            catch
            { }
            GeneratedUserID = tmsCommon.GenerateData(p0);
            EAM.UserAdministrationCrudUser.UserID.SendKeys(GeneratedUserID);
        }


        [Then(@"Verify UserID can not be edited")]
        public void ThenVerifyUserIDCanNotBeEdited()
        {
            IWebElement userIdText = EAM.UserAdministrationSearchUser.Username;
            try
            {
                userIdText.SendKeys("test");
            }
            catch
            {
            }
        }

        [Given(@"I click logout from IDM")]
        public void GivenIClickLogoutFromIDM()
        {
            fw.ExecuteJavascript(EAM.EAMLogout.headerButton);
            tmsWait.Hard(2);
            fw.ExecuteJavascript(EAM.EAMLogout.Logout);
            tmsWait.Implicit(30);
        }

        //Gurdeep Arora
        [Given(@"I click on a user ""(.*)"" to edit")]
        public void GivenIClickOnAUserToEdit(string p0)
        {
            tmsWait.Hard(8);
            fw.ExecuteJavascript(EAM.UserAdministrationCrudUser.UserNameFilter);
            tmsWait.Hard(2);
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.UserAdministrationCrudUser.filterValue.SendKeys(GeneratedData);
            tmsWait.Hard(1);
            EAM.UserAdministrationCrudUser.filterButton.Click();
            tmsWait.Hard(3);
            EAM.UserAdministrationCrudUser.EditButton.Click();
            tmsWait.Implicit(30);
            tmsWait.Hard(2);
        }


        //Gurdeep Arora
        [Given(@"verify User ""(.*)"" has User Role")]
        public void GivenVerifyUserHasUserRole(string p0)
        {
            tmsWait.Hard(8);
            fw.ExecuteJavascript(EAM.UserAdministrationCrudUser.UserNameFilter);
            tmsWait.Hard(2);
            EAM.UserAdministrationCrudUser.filterValue.SendKeys(p0);
            tmsWait.Hard(1);
            EAM.UserAdministrationCrudUser.filterButton.Click();
            tmsWait.Hard(3);
            EAM.UserAdministrationCrudUser.EditButton.Click();
            tmsWait.Implicit(30);
            tmsWait.Hard(2);
            SelectElement roleDropdown = new SelectElement(EAM.UserAdministrationCrudUser.editRoleDropdown);
            string roleValue = roleDropdown.SelectedOption.Text;
            Console.WriteLine("role text " + roleValue);
            if (roleValue != "User")
            {
                string GeneratedData = tmsCommon.GenerateData("User");
                roleDropdown.SelectByText(GeneratedData);
            }

            SelectElement EAMRoleDropdown = new SelectElement(EAM.UserAdministrationCrudUser.editEAMRoleDropdown);
            string eamroleValue = EAMRoleDropdown.SelectedOption.Text;
            Console.WriteLine("role text " + eamroleValue);
            if (eamroleValue != "User")
            {
                string GeneratedData = tmsCommon.GenerateData("User");
                EAMRoleDropdown.SelectByText(GeneratedData);
            }
            EAM.UserAdministrationCrudUser.updateButton.Click();
            tmsWait.Hard(5);
        }

        //Gurdeep Arora
        [Given(@"Administration New User ""(.*)"" is displayed on the screen")]
        public void GivenAdministrationNewUserIsDisplayedOnTheScreen(string p0)
        {
            tmsWait.Hard(8);
            string GeneratedData = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(EAM.UserAdministrationCrudUser.UserNameFilter);
            tmsWait.Hard(2);
            EAM.UserAdministrationCrudUser.filterValue.SendKeys(GeneratedData);
            tmsWait.Hard(1);
            EAM.UserAdministrationCrudUser.filterButton.Click();
            tmsWait.Hard(3);
            EAM.UserAdministrationCrudUser.EditButton.Click();
            tmsWait.Hard(2);
        }

        [Given(@"Administration New User Password field to ""(.*)""")]
        [When(@"Administration New User Password field to ""(.*)""")]
        [Then(@"Administration New User Password field to ""(.*)""")]
        public void GivenAdministrationNewUserPasswordFieldTo(string p0)
        {
            string pwdValue = tmsCommon.GenerateData(p0);
            tmsWait.Hard(2);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                EAM.UserAdministrationCrudUser.AngularPassword.SendKeys(pwdValue);
            }
            else
            {
                EAM.UserAdministrationCrudUser.Password.SendKeys(pwdValue);
            }
        }

        [Given(@"User Management page Password is set to ""(.*)""")]
        public void GivenUserManagementPagePasswordIsSetTo(string password)
        {
            string pwd = tmsCommon.GenerateData(password);
            EAM.UserAdministrationCrudUser.Password.SendKeys(pwd);
        }

        [Given(@"Administration New User Confirm Password to ""(.*)""")]
        [When(@"Administration New User Confirm Password to ""(.*)""")]
        [Then(@"Administration New User Confirm Password to ""(.*)""")]
        public void GivenAdministrationNewUserConfirmPasswordTo(string p0)
        {
            string pwd = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                EAM.UserAdministrationCrudUser.AngularConfirmPassword.SendKeys(pwd);
            }
            else
            {
                EAM.UserAdministrationCrudUser.ConfirmPassword.SendKeys(pwd);
            }

               
        }

        [Given(@"User Management page New User Confirm Password to ""(.*)""")]
        public void GivenUserManagementPageNewUserConfirmPasswordTo(string confirmpwd)
        {
            string pwd = tmsCommon.GenerateData(confirmpwd);
            EAM.UserAdministrationCrudUser.ConfirmPassword.SendKeys(pwd);
        }


        [Given(@"Administration New User First Name to ""(.*)""")]
        [When(@"Administration New User First Name to ""(.*)""")]
        [Then(@"Administration New User First Name to ""(.*)""")]
        public void GivenAdministrationNewUserFirstNameTo(string p0)
        {
            string GeneratedFirstName = tmsCommon.GenerateData(p0);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                EAM.UserAdministrationCrudUser.AngularFirstName.Clear();
                EAM.UserAdministrationCrudUser.AngularFirstName.SendKeys(GeneratedFirstName);
            }
            else
            {
                EAM.UserAdministrationCrudUser.FirstName.Clear();
                EAM.UserAdministrationCrudUser.FirstName.SendKeys(GeneratedFirstName);
            }
                
        }

        [Given(@"Administration Existing User First Name to ""(.*)""")]
        public void GivenAdministrationExistingUserFirstNameTo(string p0)
        {
            string GeneratedFirstName = tmsCommon.GenerateData(p0);
            EAM.UserAdministrationCrudUser.MODFirstName.Clear();
            EAM.UserAdministrationCrudUser.MODFirstName.SendKeys(GeneratedFirstName);
        }

        [Given(@"Administration Existing User Last Name to ""(.*)""")]
        public void GivenAdministrationExistingUserLastNameTo(string p0)
        {
            string GeneratedLastName = tmsCommon.GenerateData(p0);
            EAM.UserAdministrationCrudUser.MODLastName.Clear();
            EAM.UserAdministrationCrudUser.MODLastName.SendKeys(GeneratedLastName);
        }

        [Given(@"Administration Existing User Email to ""(.*)""")]
        public void GivenAdministrationExistingUserEmailTo(string p0)
        {
            string GeneratedLastName = tmsCommon.GenerateData(p0);
            EAM.UserAdministrationCrudUser.MODemail.Clear();
            EAM.UserAdministrationCrudUser.MODemail.SendKeys(GeneratedLastName);
        }

        [Then(@"Administration New User Phone no Set to ""(.*)""")]
        public void ThenAdministrationNewUserPhoneNoSetTo(string p0)
        {
            string GeneratedFirstName = tmsCommon.GenerateData(p0);
            IWebElement ph = Browser.Wd.FindElement(By.XPath("//input[@test-id='AddUser-Input-PhoneNumber']"));
            ph.SendKeys(GeneratedFirstName);
        }

        [Given(@"User Management page New User First Name to ""(.*)""")]
        public void GivenUserManagementPageNewUserFirstNameTo(string p0)
        {
            string GeneratedFirstName = tmsCommon.GenerateData(p0);
            EAM.UserAdministrationCrudUser.FirstName.SendKeys(GeneratedFirstName);
        }

        [Given(@"Administration New User Last Name to ""(.*)""")]
        [When(@"Administration New User Last Name to ""(.*)""")]
        [Then(@"Administration New User Last Name to ""(.*)""")]
        public void GivenAdministrationNewUserLastNameTo(string p0)
        {
            string GeneratedLastName = tmsCommon.GenerateData(p0);
            EAM.UserAdministrationCrudUser.LastName.SendKeys(GeneratedLastName);
        }

        [Given(@"Administration New User Email to ""(.*)""")]
        [When(@"Administration New User Email to ""(.*)""")]
        [Then(@"Administration New User Email to ""(.*)""")]
        public void GivenAdministrationNewUserEmailTo(string p0)
        {
            string GeneratedEmail = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                EAM.UserAdministrationCrudUser.AngularEmail.SendKeys(GeneratedEmail);
            }
            else
            {
                EAM.UserAdministrationCrudUser.email.SendKeys(GeneratedEmail);
            }
        }

        [Given(@"User Management page New User Last Name to ""(.*)""")]
        public void GivenUserManagementPageNewUserLastNameTo(string p0)
        {
            string GeneratedLastName = tmsCommon.GenerateData(p0);
            EAM.UserAdministrationCrudUser.LastName.SendKeys(GeneratedLastName);
        }


        [Then(@"Verify User Name ""(.*)"" of the user on EAM Application")]
        public void ThenVerifyUserNameOfTheUserOnEAMApplication(string p0)
        {
            tmsWait.Implicit(30);
            string expected; string actual;
            expected = tmsCommon.GenerateData(p0);
            actual = EAM.UserAdministrationCrudUser.EAM_LoginName.Text;
            Assert.AreEqual("Logged in as " + expected, actual, "Dispaly Name value is not as expected");
            tmsWait.Hard(2);
        }



        [Then(@"Verify Display Name ""(.*)"" of the user on EAM Application")]
        public void ThenVerifyDisplayNameOfTheUserOnEAMApplication(string p0)
        {
            tmsWait.Implicit(30);
            string expected; string actual;
            expected = tmsCommon.GenerateData(p0);
            actual = EAM.UserAdministrationCrudUser.EAM_DisplayName.Text;
            Assert.AreEqual(expected, actual, "Dispaly Name value is not as expected");
            tmsWait.Hard(2);
        }

        [Given(@"I click on Workflow in Administration and verify the Workflow page is loaded")]
        public void GivenIClickOnWorkflowInAdministrationAndVerifyTheWorkflowPageIsLoaded()
        {
            EAM.AdministrationWorkflow.WorkflowLink.Click();
            Browser.SwitchToWindowUsingTitle("Workflow Engine");
            tmsWait.Implicit(30);
        }

        [Given(@"Administration New User Checkbox Enable for active database row value set role to ""(.*)""")]
        public void GivenAdministrationNewUserCheckboxEnableForActiveDatabaseRowValueSetRoleTo(string p0)
        {
            IWebElement userroles = Browser.Wd.FindElement(By.XPath("//select[@test-id='AddUser-Select-Role']"));
            SelectElement urole = new SelectElement(userroles);
            urole.SelectByText("User");
            tmsWait.Hard(2);
            IWebElement eamroles = Browser.Wd.FindElement(By.XPath("//select[@data-ng-model='selectedEamRole']"));
            SelectElement role = new SelectElement(eamroles);
            role.SelectByText(p0);
            tmsWait.Hard(2);

            IWebElement drp = Browser.Wd.FindElement(By.CssSelector("[test-id='AddUser-Select-DefaultApplicationRequired']"));
            SelectElement role1 = new SelectElement(drp);
            role1.SelectByIndex(1);

            //fw.ExecuteJavascript(drp);
            tmsWait.Hard(1);
            //IWebElement appselect = Browser.Wd.FindElement(By.XPath("//select//option[contains(.,'EAM')]"));
            //fw.ExecuteJavascript(appselect);

        }
        [Given(@"Administration Role is set to ""(.*)""")]
        public void GivenAdministrationRoleIsSetTo(string p0)
        {
            IWebElement drp = Browser.Wd.FindElement(By.CssSelector("[test-id='AddUser-Select-Role']"));
            SelectElement role1 = new SelectElement(drp);
            role1.SelectByText(p0);
        }


        [Then(@"Verify Enroll Request Form is displayed")]
        public void ThenVerifyEnrollRequestFormIsDisplayed()
        {
            tmsWait.Hard(10);
            Assert.IsTrue(EAM.UserAdministrationCrudUser.EnrollReqFormLink.Displayed, "Enroll Request Form is not getting displayed");
        }

        [Then(@"Verify User Management page displayed User Name as ""(.*)"" First Name as ""(.*)"" Last Name as ""(.*)"" Role as ""(.*)""")]
        public void ThenVerifyUserManagementPageDisplayedUserNameAsFirstNameAsLastNameAsRoleAs(string p0, string p1, string p2, string p3)
        {
            string userid = tmsCommon.GenerateData(p0);
            string first = tmsCommon.GenerateData(p1);
            string last = tmsCommon.GenerateData(p2);
            string role = tmsCommon.GenerateData(p3);
           
            tmsWait.Hard(2);
            By loc = By.XPath("//div[@test-id='users-grid-usersGrid']//td[contains(.,'"+userid+"')]/following-sibling::td[contains(.,'"+first+"')]/following-sibling::td[contains(.,'"+last+"')]/following-sibling::td[contains(.,'"+role+"')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }


        [Given(@"Administration New User Active to ""(.*)""")]
        [When(@"Administration New User Active to ""(.*)""")]
        [Then(@"Administration New User Active to ""(.*)""")]
        public void GivenAdministrationNewUserActiveTo(string options)
        {
            IWebElement optionbutton = Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + options + "')]"));
            fw.ExecuteJavascript(optionbutton);

            //tmsWait.Hard(2);
            //if (ConfigFile.BrowserType.ToLower().Equals("ff"))
            //{
            //    EAM.UserAdministrationCrudUser.Active.Click();
            //    tmsWait.Hard(5);

            //    SelectElement select = new SelectElement(EAM.UserAdministrationCrudUser.Active);
            //    select.SelectByText(p0);

            //}
            //else
            //{

            //    SelectElement select = new SelectElement(EAM.UserAdministrationCrudUser.Active);
            //    select.SelectByText(p0);
            //}
            //tmsWait.Hard(2);
        }

        [Given(@"User Management page New User Active to ""(.*)""")]
        public void GivenUserManagementPageNewUserActiveTo(string p0)
        {
       
        }

        [Given(@"User Management page Role is set as ""(.*)""")]
        public void GivenUserManagementPageRoleIsSetAs(string p0)
        {
           
        }

        [Given(@"User Management page Add New User link is clicked")]
        public void GivenUserManagementPageAddNewUserLinkIsClicked()
        {
            tmsWait.Hard(2);
            EAM.UserAdministrationCrudUser.AddNewUser.Click();
        }

        [Given(@"User Details page Login Name is set as ""(.*)""")]
        public void GivenUserDetailsPageLoginNameIsSetAs(string login)
        {
            tmsWait.Hard(2);
            EAM.UserAdministrationCrudUser.LoginNameTextbox.SendKeys(login);
        }

        [Given(@"User Details page Password is set as ""(.*)""")]
        public void GivenUserDetailsPagePasswordIsSetAs(string password)
        {
            tmsWait.Hard(2);
            EAM.UserAdministrationCrudUser.PasswordTextbox.SendKeys(password);
        }

        [Given(@"User Details page Confirm Password is set as ""(.*)""")]
        public void GivenUserDetailsPageConfirmPasswordIsSetAs(string password)
        {
            tmsWait.Hard(2);
            EAM.UserAdministrationCrudUser.ConfirmPasswordTextbox.SendKeys(password);
        }

        [Given(@"User Details page First Name is set as ""(.*)""")]
        public void GivenUserDetailsPageFirstNameIsSetAs(string name)
        {
            tmsWait.Hard(2);
            EAM.UserAdministrationCrudUser.FirstNameTextbox.SendKeys(name);
        }

        [Given(@"User Details page Last Name is set as ""(.*)""")]
        public void GivenUserDetailsPageLastNameIsSetAs(string name)
        {
            tmsWait.Hard(2);
            EAM.UserAdministrationCrudUser.LastNameTextbox.SendKeys(name);
        }

        [Given(@"User Details page Active User selected as ""(.*)""")]
        public void GivenUserDetailsPageActiveUserSelectedAs(string option)
        {
            tmsWait.Hard(2);
            if (option.ToLower().Equals("yes"))
            {
                EAM.UserAdministrationCrudUser.YesRadiobutton.Click();
            }
            else
            {
                EAM.UserAdministrationCrudUser.NoRadiobutton.Click();
            }
        }

        [Given(@"User Details page Role is selected as ""(.*)""")]
        public void GivenUserDetailsPageRoleIsSelectedAs(string option)
        {
            tmsWait.Hard(2);
            SelectElement roleDD = new SelectElement(EAM.UserAdministrationCrudUser.RoleDropdown);
            roleDD.SelectByText(option);
        }

        [Given(@"I click Add New Record button")]
        public void GivenIClickAddNewRecordButton()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(EAM.UserAdministrationCrudUser.AddNewRecordButton);
        }


        [Given(@"User Management page Application is selected as ""(.*)""")]
        public void GivenUserManagementPageApplicationIsSelectedAs(string app)
        {

        }

        [Given(@"User Management page Role Name is selected as ""(.*)""")]
        public void GivenUserManagementPageRoleNameIsSelectedAs(string p0)
        {
           
        }

        [Given(@"User Management page Save Action button is clicked")]
        public void GivenUserManagementPageSaveActionButtonIsClicked()
        {
            
        }

        [Given(@"User Management page EAM Application Role is set as ""(.*)""")]
        public void GivenUserManagementPageEAMApplicationRoleIsSetAs(string app)
        {
            tmsWait.Hard(2);
            SelectElement appDD = new SelectElement(EAM.UserAdministrationCrudUser.EAMRolesDropdown);
            appDD.SelectByText(app);
        }

        [Given(@"User Management page Default Application Role is set as ""(.*)""")]
        public void GivenUserManagementPageDefaultApplicationRoleIsSetAs(string role)
        {
            tmsWait.Hard(2);
            SelectElement roleDD = new SelectElement(EAM.UserAdministrationCrudUser.DefaultApplicationDropdown);
            roleDD.SelectByText(role);
        }

        [Given(@"User Management page Add button is clicked")]
        public void GivenUserManagementPageAddButtonIsClicked()
        {
            //tmsWait.Hard(2);
            //EAM.UserAdministrationCrudUser.ADDButton.Click();
            //Browser.RestartServiceOnRemote("TMSDiscoveryProxyHost", "10.90.44.75");
            //Browser.RestartServiceOnRemote("TMSServerHost", "10.90.44.75");
            //Browser.RestartServiceOnRemote("TMSApplicationHost", "10.90.44.75");
        }


        [Given(@"Administration New User Manager TC90 is set to ""(.*)""")]
        public void GivenAdministrationNewUserManagerTCIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            IWebElement table = EAM.UserAdministrationCrudUser.AdministrationPermissionsTable;
            Boolean elementFound = false;
            IList<IWebElement> allElements = table.FindElements(By.TagName("tr")); // you have all row that are visible
            int thisCount = allElements.Count;
            IWebElement thisWebElement = null;

            foreach (IWebElement abc in allElements)
            {
                thisWebElement = abc;
                if (abc.Text.Contains(ConfigFile.Database))
                {
                    IList<IWebElement> rowInputs = abc.FindElements(By.TagName("input"));
                    foreach (IWebElement thisTableInput in rowInputs)
                    {
                        Console.WriteLine("Input src [" + thisTableInput.GetAttribute("src") + "]");
                        if (thisTableInput.GetAttribute("src").Contains("AdminDDL.png"))
                        {

                            thisTableInput.Click();
                            tmsWait.Hard(4);
                            IList<IWebElement> theseLabels = EAM.UserAdministrationCrudUser.AdministrationPermissionsTable.FindElements(By.TagName("label"));
                            foreach (IWebElement thisLabel in theseLabels)
                            {
                                if (thisLabel.Text.Contains("TC90"))
                                {
                                    string thisID = thisLabel.GetAttribute("for");
                                    string[] labelParts = thisID.Split('_');


                                    string permissionsList = "AssignedAppsGridView_" + labelParts[1] + "_ucPermissionAddList_divCustomCheckBoxList";
                                    string inputString = "AssignedAppsGridView_" + labelParts[1] + "_ucPermissionAddList_DDList_1";
                                    EAM.UserAdministrationCrudUser.AdministrationPermissionsTable.FindElement(By.Id(inputString)).Click();
                                    if (elementFound) break;
                                }
                            }
                        }
                        if (elementFound) break;
                    }
                    if (elementFound) break;
                }
                if (elementFound) break;
            }
        }

        [Given(@"Administration New User UserTC90 is set to ""(.*)""")]
        public void GivenAdministrationNewUserUserTCIsSetTo(string p0)
        {
            string CheckBoxName = "TC90";
            EAM.UserAdministrationCrudUser.TC90DropDown.Click();
            IWebElement thisDropDownList = EAM.UserAdministrationCrudUser.TC90DropDownList;
            IList<IWebElement> theseLabels = thisDropDownList.FindElements(By.TagName("label"));
            foreach (IWebElement thisLabel in theseLabels)
            {
                if (thisLabel.Text == CheckBoxName)
                {
                    string sameID = thisLabel.GetAttribute("for");
                    thisDropDownList.FindElement(By.Id(sameID)).Click();
                    break;
                }
            }
        }

        string defaultApp = null;

        [Given(@"Administration New User Select Database ""(.*)"" and Role to ""(.*)""")]
        public void GivenAdministrationNewUserSelectDatabaseAndRoleTo(string database, string role)
        {

            // Selecting USer
            IWebElement drp = Browser.Wd.FindElement(By.XPath("//select[@test-id='AddUser-Select-Role']"));
            SelectElement roledropdown = new SelectElement(drp);
            roledropdown.SelectByText("User");

            // Click on Add New User
            IWebElement addnewrecord = Browser.Wd.FindElement(By.XPath("//a[@class='k-button k-button-icontext k-grid-add']"));
            fw.ExecuteJavascript(addnewrecord);

            // Select Application
            IWebElement appDrp = Browser.Wd.FindElement(By.XPath("(//span[@class='k-dropdown-wrap k-state-default'])[1]"));
            fw.ExecuteJavascript(appDrp);
            tmsWait.Hard(1);
            IWebElement selectDB = Browser.Wd.FindElement(By.XPath("//ul[@data-role='staticlist']/li[contains(.,'" + database + "')]"));
            fw.ExecuteJavascript(selectDB);
            // select Role
            tmsWait.Hard(2);
            IWebElement roleDrp = Browser.Wd.FindElement(By.XPath("(//span[@class='k-select'])[2]"));
            fw.ExecuteJavascript(roleDrp);
            tmsWait.Hard(1);
            IWebElement selectRole = Browser.Wd.FindElement(By.XPath("//ul[@data-role='staticlist']/li[contains(.,'" + role + "')]"));
            fw.ExecuteJavascript(selectRole);

            IWebElement save = Browser.Wd.FindElement(By.XPath("//a[@class='k-button k-button-icontext k-primary k-grid-update']"));
            fw.ExecuteJavascript(save);

        }

        [When(@"User Management page Add User page Role is set as ""(.*)""")]
        public void WhenUserManagementPageAddUserPageRoleIsSetAs(string role)
        {
            IWebElement drp = Browser.Wd.FindElement(By.XPath("//select[@test-id='AddUser-Select-Role']"));
            SelectElement roledropdown = new SelectElement(drp);
            roledropdown.SelectByText(role);
        }
        [When(@"User Management page Add User page Set Default Application is Set as ""(.*)""")]
        public void WhenUserManagementPageAddUserPageSetDefaultApplicationIsSetAs(string DefaultApp)
        {
            IWebElement defaultAppselection = Browser.Wd.FindElement(By.CssSelector("[test-id='AddUser-Select-DefaultApplicationRequired']"));
            SelectElement defappSel = new SelectElement(defaultAppselection);
            defappSel.SelectByText(DefaultApp);
        }

        [When(@"Administration New User Default application is set to ""(.*)""")]
        public void GivenAdministrationNewUserDefaultApplicationIsSetTo(string p0)
        {
            defaultApp = p0;
            IWebElement defaultAppselection = Browser.Wd.FindElement(By.CssSelector("[test-id='AddUser-Select-DefaultApplicationRequired']"));
            SelectElement defappSel = new SelectElement(defaultAppselection);
            defappSel.SelectByText(defaultApp);
        }

        [Given(@"Administration edit User checkbox Enable for Database ""(.*)"" and Role to ""(.*)"" and set it as ""(.*)""")]
        [When(@"Administration edit User checkbox Enable for Database ""(.*)"" and Role to ""(.*)"" and set it as ""(.*)""")]
        [Then(@"Administration edit User checkbox Enable for Database ""(.*)"" and Role to ""(.*)"" and set it as ""(.*)""")]
        public void GivenAdministrationEditUserCheckboxEnableForDatabaseAndRoleToAndSetItAs(string database, string role, string home)
        {
            //IWebElement drp = Browser.Wd.FindElement(By.XPath("//select[@@data-ng-model='selctedUserRole']"));
            //SelectElement roledropdown = new SelectElement(drp);
            //roledropdown.SelectByText("User");

            tmsWait.Hard(4);
            IWebElement eamrole = Browser.Wd.FindElement(By.XPath("//*[@data-ng-model='selectedEamRole']"));
            SelectElement userRole = new SelectElement(eamrole);
            userRole.SelectByText(role);
            if (home.Equals("Default"))
            {
                defaultApp = database;
                IWebElement defaultAppselection = Browser.Wd.FindElement(By.XPath("//*[@data-ng-model='defaultApplication']"));
                SelectElement defappSel = new SelectElement(defaultAppselection);
                defappSel.SelectByText(defaultApp);
            }
        }

        [Given(@"Map Application and Role section Add New Record button is Clicked")]
        public void GivenMapApplicationAndRoleSectionAddNewRecordButtonIsClicked()
        {
            IWebElement addnewrecord = Browser.Wd.FindElement(By.XPath("//a[contains(.,'Add new record')]"));
            fw.ExecuteJavascript(addnewrecord);
        }

        [When(@"Delete User Management page Application is as ""(.*)""  Role Name is set as ""(.*)"" Default Application is set as ""(.*)""")]
        public void WhenDeleteUserManagementPageApplicationIsAsRoleNameIsSetAsDefaultApplicationIsSetAs(string p0, string p1, string p2)
        {
            By loc = By.XPath("(//div[@id='applicationAndRolesGrid']//td/a[2])[1]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);

        }

        [Then(@"Verify Application ""(.*)"" Role Name is set as ""(.*)"" is not getting displayed")]
        public void ThenVerifyApplicationRoleNameIsSetAsIsNotGettingDisplayed(string p0, string p1)
        {
            By loc = By.XPath("//div[@id='applicationAndRolesGrid']//td[contains(.,'" + p0 + "')]/following-sibling::td[contains(.,'" + p1 + "')]");
            UIMODUtilFunctions.elementNotPresenceUsingLocators(loc);
        }

        [Given(@"User Management page Application is as ""(.*)""  Role Name is set as ""(.*)"" Default Application is set as ""(.*)""")]
        public void GivenUserManagementPageApplicationIsAsRoleNameIsSetAsDefaultApplicationIsSetAs(string database, string roleDsc, string defaultApp)
        {
            IWebElement appDrp = Browser.Wd.FindElement(By.XPath("(//span[@class='k-widget k-dropdown k-header'])[1]"));
            fw.ExecuteJavascript(appDrp);
            tmsWait.Hard(1);
            IWebElement selectDB = Browser.Wd.FindElement(By.XPath("//ul[@data-role='staticlist']/li[contains(.,'" + database + "')]"));
            fw.ExecuteJavascript(selectDB);

            IWebElement role = Browser.Wd.FindElement(By.XPath("(//span[@class='k-widget k-dropdown k-header'])[2]"));
            fw.ExecuteJavascript(role);
            tmsWait.Hard(1);
            IWebElement roleName = Browser.Wd.FindElement(By.XPath("//ul[@data-role='staticlist']/li[contains(.,'" + roleDsc + "')]"));
            fw.ExecuteJavascript(roleName);

            if (defaultApp.Equals(""))
            {

            }

            else
            {
                new SelectElement(Browser.Wd.FindElement(By.CssSelector("[data-ng-model='defaultApplication']"))).SelectByText(defaultApp);
            }


            IWebElement save = Browser.Wd.FindElement(By.XPath("//a[@class='k-button k-button-icontext k-primary k-grid-update']"));
            fw.ExecuteJavascript(save);

        }


        [Given(@"Administration New User checkbox Enable for Database ""(.*)"" and Role to ""(.*)"" and set it as ""(.*)""")]
        [When(@"Administration New User checkbox Enable for Database ""(.*)"" and Role to ""(.*)"" and set it as ""(.*)""")]
        [Then(@"Administration New User checkbox Enable for Database ""(.*)"" and Role to ""(.*)"" and set it as ""(.*)""")]
        public void GivenAdministrationNewUserCheckboxEnableForDatabaseAndRoleToAndSetItAs(string database, string role, string home)
        {


            IWebElement drp = Browser.Wd.FindElement(By.XPath("//select[@test-id='AddUser-Select-Role']"));
            SelectElement roledropdown = new SelectElement(drp);
            roledropdown.SelectByText("User");

            tmsWait.Hard(4);
            if (database.Equals("EAM"))
            {
                IWebElement eamrole = Browser.Wd.FindElement(By.CssSelector("[test-id='Adduser-Select-EAMRoles']"));
                SelectElement userRole = new SelectElement(eamrole);
                userRole.SelectByText(role);

                if (home.Equals("Default"))
                {
                    defaultApp = database;
                    IWebElement defaultAppselection = Browser.Wd.FindElement(By.CssSelector("[test-id='AddUser-Select-DefaultApplicationRequired']"));
                    SelectElement defappSel = new SelectElement(defaultAppselection);
                    defappSel.SelectByText(defaultApp);
                }
            }
            else
            {
                IWebElement addnewrecord = Browser.Wd.FindElement(By.XPath("//a[@class='k-button k-button-icontext k-grid-add']"));
                fw.ExecuteJavascript(addnewrecord);
                IWebElement appDrp = Browser.Wd.FindElement(By.XPath("(//span[@class='k-dropdown-wrap k-state-default'])[1]"));
                fw.ExecuteJavascript(appDrp);
                tmsWait.Hard(1);
                IWebElement selectDB = Browser.Wd.FindElement(By.XPath("//ul[@data-role='staticlist']/li[contains(.,'" + database + "')]"));
                fw.ExecuteJavascript(selectDB);

                tmsWait.Hard(2);
                IWebElement roleDrp = Browser.Wd.FindElement(By.XPath("(//span[@class='k-select'])[2]"));
                fw.ExecuteJavascript(roleDrp);
                tmsWait.Hard(1);
                IWebElement selectRole = Browser.Wd.FindElement(By.XPath("//ul[@data-role='staticlist']/li[contains(.,'" + role + "')]"));
                fw.ExecuteJavascript(selectRole);

                IWebElement save = Browser.Wd.FindElement(By.XPath("//a[@class='k-button k-button-icontext k-primary k-grid-update']"));
                fw.ExecuteJavascript(save);
                if (home.Equals("Default"))
                {
                    defaultApp = database;
                    IWebElement defaultAppselection = Browser.Wd.FindElement(By.CssSelector("[test-id='AddUser-Select-DefaultApplicationRequired']"));
                    SelectElement defappSel = new SelectElement(defaultAppselection);
                    defappSel.SelectByText(defaultApp);
                }

            }



            //}
            //else if (database.Equals("EAM"))
            //{
            //    fw.ExecuteJavascript(addnewrecord);
            //    IWebElement eamrole = Browser.Wd.FindElement(By.CssSelector("[test-id='Adduser-Select-EAMRoles']"));
            //    SelectElement userRole = new SelectElement(eamrole);
            //     userRole.SelectByText(role);
            //}
            //else if (database.Equals("FRM"))
            //{
            //    IWebElement icon = Browser.Wd.FindElement(By.XPath("//span[@class='k-select']/span"));
            //    fw.ExecuteJavascript(icon);
            //    IWebElement eamrole = Browser.Wd.FindElement(By.CssSelector("[test-id='Adduser-Select-EAMRoles']"));
            //    SelectElement userRole = new SelectElement(eamrole);
            //    userRole.SelectByText(role);
            //}

            //tmsWait.Hard(3);
            //if (database.Equals("Administration"))
            //{
            //    //Browser.Wd.FindElement(By.XPath(".//*[@id='AssignedAppsGridView']/tbody/tr/td[contains(., 'Administration')]/preceding-sibling::td/span/input[contains(@id,'AssignedAppsGridView_enableAppForThisUser')]")).Click();
            //    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(".//*[@id='AssignedAppsGridView']/tbody/tr/td[contains(., 'Administration')]/preceding-sibling::td/span/input[contains(@id,'AssignedAppsGridView_enableAppForThisUser')]")));
            //    SelectElement userRole = new SelectElement(Browser.Wd.FindElement(By.XPath(".//*[@id='AssignedAppsGridView']/tbody/tr/td[contains(., 'Administration')]/../td/select[contains(@id,'AssignedAppsGridView_ddlAccessLevel')]")));
            //    userRole.SelectByText(role);
            //    if (home.Equals("Default"))
            //    {
            //        tmsWait.Hard(2);
            //        //Browser.Wd.FindElement(By.XPath(".//*[@id='AssignedAppsGridView']/tbody/tr/td[contains(., 'Administration')]/preceding-sibling::td/span/input[contains(@id,'AssignedAppsGridView_setAsDefault')]")).Click();
            //        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(".//*[@id='AssignedAppsGridView']/tbody/tr/td[contains(., 'Administration')]/preceding-sibling::td/span/input[contains(@id,'AssignedAppsGridView_setAsDefault')]")));
            //    }
            //}
            //else if (database.Equals("EAM"))
            //{
            //    //Browser.Wd.FindElement(By.XPath(".//*[@id='AssignedAppsGridView']/tbody/tr/td[contains(., '" + ConfigFile.EAMdb.ToString() + "')]/preceding-sibling::td/span/input[contains(@id,'AssignedAppsGridView_enableAppForThisUser')]")).Click();
            //    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(".//*[@id='AssignedAppsGridView']/tbody/tr/td[contains(., '" + ConfigFile.EAMdb.ToString() + "')]/preceding-sibling::td/span/input[contains(@id,'AssignedAppsGridView_enableAppForThisUser')]")));
            //    SelectElement userRole = new SelectElement(Browser.Wd.FindElement(By.XPath(".//*[@id='AssignedAppsGridView']/tbody/tr/td[contains(., '" + ConfigFile.EAMdb.ToString() + "')]/../td/select[contains(@id,'AssignedAppsGridView_ddlAccessLevel')]")));
            //    userRole.SelectByText(role);
            //    if (home.Equals("Default"))
            //    {
            //        tmsWait.Hard(2);
            //        //Browser.Wd.FindElement(By.XPath(".//*[@id='AssignedAppsGridView']/tbody/tr/td[contains(., '" + ConfigFile.EAMdb.ToString() + "')]/preceding-sibling::td/span/input[contains(@id,'AssignedAppsGridView_setAsDefault')]")).Click();
            //        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(".//*[@id='AssignedAppsGridView']/tbody/tr/td[contains(., '" + ConfigFile.EAMdb.ToString() + "')]/preceding-sibling::td/span/input[contains(@id,'AssignedAppsGridView_setAsDefault')]")));
            //    }
            //}
            //else if (database.Equals("FRM"))
            //{
            //    //Browser.Wd.FindElement(By.XPath(".//*[@id='AssignedAppsGridView']/tbody/tr/td[contains(., '" + ConfigFile.FRMdb.ToString() + "')]/preceding-sibling::td/span/input[contains(@id,'AssignedAppsGridView_enableAppForThisUser')]")).Click();
            //    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(".//*[@id='AssignedAppsGridView']/tbody/tr/td[contains(., '" + ConfigFile.FRMdb.ToString() + "')]/preceding-sibling::td/span/input[contains(@id,'AssignedAppsGridView_enableAppForThisUser')]")));
            //    SelectElement userRole = new SelectElement(Browser.Wd.FindElement(By.XPath(".//*[@id='AssignedAppsGridView']/tbody/tr/td[contains(., '" + ConfigFile.FRMdb.ToString() + "')]/../td/select[contains(@id,'AssignedAppsGridView_ddlAccessLevel')]")));
            //    userRole.SelectByText(role);
            //    if (home.Equals("Default"))
            //    {
            //        tmsWait.Hard(2);
            //        //Browser.Wd.FindElement(By.XPath(".//*[@id='AssignedAppsGridView']/tbody/tr/td[contains(., '" + ConfigFile.FRMdb.ToString() + "')]/preceding-sibling::td/span/input[contains(@id,'AssignedAppsGridView_setAsDefault')]")).Click();
            //        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(".//*[@id='AssignedAppsGridView']/tbody/tr/td[contains(., '" + ConfigFile.FRMdb.ToString() + "')]/preceding-sibling::td/span/input[contains(@id,'AssignedAppsGridView_setAsDefault')]")));
            //    }
            //}

            //else if (database.Equals("RSM"))
            //{
            //    //Browser.Wd.FindElement(By.XPath(".//*[@id='AssignedAppsGridView']/tbody/tr/td[contains(., '" + ConfigFile.RSMdb.ToString() + "')]/preceding-sibling::td/span/input[contains(@id,'AssignedAppsGridView_enableAppForThisUser')]")).Click();
            //    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(".//*[@id='AssignedAppsGridView']/tbody/tr/td[contains(., '" + ConfigFile.RSMdb.ToString() + "')]/preceding-sibling::td/span/input[contains(@id,'AssignedAppsGridView_enableAppForThisUser')]")));
            //    SelectElement userRole = new SelectElement(Browser.Wd.FindElement(By.XPath(".//*[@id='AssignedAppsGridView']/tbody/tr/td[contains(., '" + ConfigFile.RSMdb.ToString() + "')]/../td/select[contains(@id,'AssignedAppsGridView_ddlAccessLevel')]")));
            //    userRole.SelectByText(role);
            //    if (home.Equals("Default"))
            //    {
            //        tmsWait.Hard(2);
            //        //Browser.Wd.FindElement(By.XPath(".//*[@id='AssignedAppsGridView']/tbody/tr/td[contains(., '" + ConfigFile.RSMdb.ToString() + "')]/preceding-sibling::td/span/input[contains(@id,'AssignedAppsGridView_setAsDefault')]")).Click();
            //        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(".//*[@id='AssignedAppsGridView']/tbody/tr/td[contains(., '" + ConfigFile.RSMdb.ToString() + "')]/preceding-sibling::td/span/input[contains(@id,'AssignedAppsGridView_setAsDefault')]")));
            //    }
            //}
            //else if (database.Equals("RAM"))
            //{
            //    //Browser.Wd.FindElement(By.XPath(".//*[@id='AssignedAppsGridView']/tbody/tr/td[contains(., '" + ConfigFile.RAMdb.ToString() + "')]/preceding-sibling::td/span/input[contains(@id,'AssignedAppsGridView_enableAppForThisUser')]")).Click();
            //    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(".//*[@id='AssignedAppsGridView']/tbody/tr/td[contains(., '" + ConfigFile.RAMdb.ToString() + "')]/preceding-sibling::td/span/input[contains(@id,'AssignedAppsGridView_enableAppForThisUser')]")));
            //    SelectElement userRole = new SelectElement(Browser.Wd.FindElement(By.XPath(".//*[@id='AssignedAppsGridView']/tbody/tr/td[contains(., '" + ConfigFile.RAMdb.ToString() + "')]/../td/select[contains(@id,'AssignedAppsGridView_ddlAccessLevel')]")));
            //    userRole.SelectByText(role);
            //    if (home.Equals("Default"))
            //    {
            //        tmsWait.Hard(2);
            //        //Browser.Wd.FindElement(By.XPath(".//*[@id='AssignedAppsGridView']/tbody/tr/td[contains(., '" + ConfigFile.RAMdb.ToString() + "')]/preceding-sibling::td/span/input[contains(@id,'AssignedAppsGridView_setAsDefault')]")).Click();
            //        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(".//*[@id='AssignedAppsGridView']/tbody/tr/td[contains(., '" + ConfigFile.RAMdb.ToString() + "')]/preceding-sibling::td/span/input[contains(@id,'AssignedAppsGridView_setAsDefault')]")));
            //    }
            //}

            //else if (database.Equals("DLM"))
            //{
            //    //Browser.Wd.FindElement(By.XPath(".//*[@id='AssignedAppsGridView']/tbody/tr/td[contains(., '" + ConfigFile.RAMdb.ToString() + "')]/preceding-sibling::td/span/input[contains(@id,'AssignedAppsGridView_enableAppForThisUser')]")).Click();
            //    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(".//*[@id='AssignedAppsGridView']/tbody/tr/td[contains(., '" + ConfigFile.DLMdb.ToString() + "')]/preceding-sibling::td/span/input[contains(@id,'AssignedAppsGridView_enableAppForThisUser')]")));
            //    SelectElement userRole = new SelectElement(Browser.Wd.FindElement(By.XPath(".//*[@id='AssignedAppsGridView']/tbody/tr/td[contains(., '" + ConfigFile.DLMdb.ToString() + "')]/../td/select[contains(@id,'AssignedAppsGridView_ddlAccessLevel')]")));
            //    userRole.SelectByText(role);
            //    if (home.Equals("Default"))
            //    {
            //        tmsWait.Hard(2);
            //        //Browser.Wd.FindElement(By.XPath(".//*[@id='AssignedAppsGridView']/tbody/tr/td[contains(., '" + ConfigFile.RAMdb.ToString() + "')]/preceding-sibling::td/span/input[contains(@id,'AssignedAppsGridView_setAsDefault')]")).Click();
            //        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(".//*[@id='AssignedAppsGridView']/tbody/tr/td[contains(., '" + ConfigFile.DLMdb.ToString() + "')]/preceding-sibling::td/span/input[contains(@id,'AssignedAppsGridView_setAsDefault')]")));
            //    }
            //}

        }


        [When(@"Administration Update User checkbox Enable for Database ""(.*)"" and Role to ""(.*)"" and set it as ""(.*)""")]
        public void WhenAdministrationUpdateUserCheckboxEnableForDatabaseAndRoleToAndSetItAs(string database, string role, string home)
        {
            string EAMDB = ConfigFile.EAMdb;
            if (database.Equals("EAM"))
            {
                //SelectElement userRole = new SelectElement(Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + database + "')]//select[@id='EditUserAssignedAppsGridView_ddlAccessLevel_1']")));
                //userRole.SelectByText(role);
                SelectElement userRole = new SelectElement(Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + EAMDB + "')]/following-sibling::td//select")));
                userRole.SelectByText(role);

            }
        }

        [When(@"Administration Update User checkbox Enable for Database from config file and Role to ""(.*)""")]
        public void WhenAdministrationUpdateUserCheckboxEnableForDatabaseFromConfigFileAndRoleTo(string p0)
        {
            IWebElement table1 = Browser.Wd.FindElement(By.Id("EditUserAssignedAppsGridView")); // you have the table
            IList<IWebElement> allElements1 = table1.FindElements(By.TagName("tr")); // you have all row that are visible
            int thisCount1 = allElements1.Count;
            IWebElement thisWebElement1 = null;
            String dbName = ConfigFile.EAMdb;
            foreach (IWebElement curRow in allElements1)
            {
                thisWebElement1 = curRow;
                if (curRow.Text.Contains(dbName))
                {
                    //IWebElement role = curRow.FindElement(By.XPath("./td[6])"));
                    IWebElement role = curRow.FindElement(By.TagName("select"));
                    SelectElement select = new SelectElement(role);
                    select.SelectByText(p0);
                    break;
                }
            }
        }

        [Then(@"Verify that the user role for the Database from config file is ""(.*)""")]
        public void ThenVerifyThatTheUserRoleForTheDatabaseFromConfigFileIs(string p0)
        {
            IWebElement table1 = Browser.Wd.FindElement(By.Id("EditUserAssignedAppsGridView")); // you have the table
            IList<IWebElement> allElements1 = table1.FindElements(By.TagName("tr")); // you have all row that are visible
            int thisCount1 = allElements1.Count;
            IWebElement thisWebElement1 = null;
            String dbName = ConfigFile.EAMdb;
            foreach (IWebElement curRow in allElements1)
            {
                thisWebElement1 = curRow;
                if (curRow.Text.Contains(dbName))
                {
                    //IWebElement role = curRow.FindElement(By.XPath("./td[6])"));
                    IWebElement role = curRow.FindElement(By.TagName("select"));
                    SelectElement select = new SelectElement(role);
                    String selectedRole = select.SelectedOption.Text;
                    Assert.AreEqual(selectedRole, p0);
                    break;
                }
            }
        }



        [Then(@"EAM Home Page ""(.*)"" menu should ""(.*)""")]
        public void ThenEAMHomePageMenuShould(string menu, string status)
        {
            bool flag = true;
            try
            {
                if (menu.ToLower().Equals("external integration"))
                {
                    if (status.ToLower().Equals("visible"))
                        Assert.IsTrue(Browser.Wd.FindElement(By.LinkText("External Integration")).Displayed, menu + "is not visible");
                    else
                        Assert.IsFalse(Browser.Wd.FindElement(By.LinkText("External Integration")).Displayed, menu + "is not visible");
                }
            }
            catch (Exception ex)
            {
                flag = false;
                Assert.IsFalse(flag, menu + "is visible");
            }
        }


        [Given(@"Application Permission TMS Application Administration Database set role to ""(.*)""")]
        public void GivenApplicationPermissionTMSApplicationAdministrationDatabaseSetRoleTo(string p0)
        {

            IWebElement table = Browser.Wd.FindElement(By.Id("AssignedAppsGridView")); // you have the table
            IList<IWebElement> allElements = table.FindElements(By.TagName("tr")); // you have all row that are visible
            int thisCount = allElements.Count;
            IWebElement thisWebElement = null;
            foreach (IWebElement abc in allElements)
            {
                thisWebElement = abc;
                if (abc.Text.Contains("Administration"))
                {
                    break;
                }
            }
            string mystr = (thisWebElement.FindElement(By.CssSelector("input[type=checkbox]")).GetAttribute("id"));
            IWebElement thisLineCheckbox = Browser.Wd.FindElement(By.Id(mystr));
            thisLineCheckbox.Click();

            string RoleId = "AssignedAppsGridView_ddlAccessLevel_0";
            IWebElement thisLineSelectRole = Browser.Wd.FindElement(By.Id(RoleId));
            var mySelectDropdown = new SelectElement(thisLineSelectRole);
            mySelectDropdown.SelectByText(p0);

            tmsWait.WaitForReadyStateComplete(30);

        }
        [Given(@"Administration New User Role is set to ""(.*)""")]
        public void GivenAdministrationNewUserRoleIsSetTo(string role)
        {
            tmsWait.Hard(3);
            IWebElement eamrole = Browser.Wd.FindElement(By.CssSelector("[test-id='AddUser-Select-Role']"));
            SelectElement userRole = new SelectElement(eamrole);
            userRole.SelectByText(role);
        }

        [Given(@"Administration Existing User Role is set to ""(.*)""")]
        public void GivenAdministrationExistingUserRoleIsSetTo(string role)
        {
            tmsWait.Hard(3);
            IWebElement eamrole = Browser.Wd.FindElement(By.CssSelector("[data-ng-model='selctedUserRole']"));
            SelectElement userRole = new SelectElement(eamrole);
            userRole.SelectByText(role);
        }

        [Given(@"Administration New User Select Default Application is set to ""(.*)""")]
        public void GivenAdministrationNewUserSelectDefaultApplicationIsSetTo(string app)
        {

            tmsWait.Hard(3);
            IWebElement defaultApp = Browser.Wd.FindElement(By.XPath("//select[@test-id='AddUser-Select-DefaultApplicationRequired']"));
            SelectElement appName = new SelectElement(defaultApp);
            appName.SelectByText(app);
        }

        //Gurdeep Arora
        [Given(@"Administration New User Update button is clicked")]
        public void GivenAdministrationNewUserUpdateButtonIsClicked()
        {
            EAM.UserAdministrationCrudUser.updateButton.Click();
        }

        [Given(@"Verify Administration New User checkbox ""(.*)"" is checked")]
        public void GivenVerifyAdministrationNewUserCheckboxIsChecked(string p0)
        {
            IWebElement ele = null;
            switch (p0)
            {
                case "TC90 App":
                    ele = EAM.UserAdministrationCrudUser.TC90AppCheckbox; break;
                case "Status Override":
                    ele = EAM.UserAdministrationCrudUser.StatusOverrideCheckbox; break;
            }
            if (!ele.Selected)
            {
                ele.Click();
            }
            else if (ele.Selected)
            {
                ele.Click();
            }
        }

        [Given(@"Verify Administration New User checkbox ""(.*)"" is updated and checked")]
        public void GivenVerifyAdministrationNewUserCheckboxIsUpdatedAndChecked(string p0)
        {
            IWebElement ele = null;
            try
            {
                switch (p0)
                {
                    case "TC90 App":
                        ele = EAM.UserAdministrationCrudUser.TC90AppCheckbox_update; break;
                    case "Status Override":
                        ele = EAM.UserAdministrationCrudUser.StatusOverrideCheckbox_update; break;
                }
                if (!ele.Selected)
                {
                    ele.Click();
                }
                else if (ele.Selected)
                {
                    ele.Click();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Please check the name of the check box you want to edit " + e.Message);
            }


        }


        //Gurdeep Arora
        [Given(@"Administration New User edit EAM Role to ""(.*)""")]
        public void GivenAdministrationNewUserEditEAMRoleTo(string p0)
        {
            SelectElement EAMRoleDropdown = new SelectElement(EAM.UserAdministrationCrudUser.editEAMRoleDropdown);
            string GeneratedData = tmsCommon.GenerateData("User");
            EAMRoleDropdown.SelectByText(GeneratedData);
            EAM.UserAdministrationCrudUser.updateButton.Click();
        }


        [Given(@"Administration New User Checkbox Enable for active database row, set role to ""(.*)""")]
        [When(@"Administration New User Checkbox Enable for active database row, set role to ""(.*)""")]
        public void GivenAdministrationNewUserCheckboxEnableForActiveDatabaseRowSetRoleTo(string p0)
        {

            IWebElement eamrole = Browser.Wd.FindElement(By.CssSelector("[test-id='Adduser-Select-EAMRoles']"));
            SelectElement userRole = new SelectElement(eamrole);
            userRole.SelectByText(p0);

            IWebElement defaultAppselection = Browser.Wd.FindElement(By.CssSelector("[test-id='AddUser-Select-DefaultApplicationRequired']"));
            SelectElement defappSel = new SelectElement(defaultAppselection);
            defappSel.SelectByText("EAM");


            //       Console.WriteLine("**If this step fails, it is highly likely that the user trying to create the user isn't an admin");
            //       IWebElement table = Browser.Wd.FindElement(By.Id("AssignedAppsGridView")); // you have the table
            //       IList<IWebElement> allElements = table.FindElements(By.TagName("tr")); // you have all row that are visible
            //       int thisCount = allElements.Count;
            //       IWebElement thisWebElement = null;
            //       foreach (IWebElement abc in allElements)
            //       {
            //           thisWebElement = abc;                
            //           if (abc.Text.Contains(ConfigFile.Database))
            //           {
            //               break;
            //           }
            //       }
            //       string mystr = (thisWebElement.FindElement(By.CssSelector("input[type=checkbox]")).GetAttribute("id"));
            //       IWebElement thisLineCheckbox = Browser.Wd.FindElement(By.Id(mystr));
            //       thisLineCheckbox.Click();

            //       string[] parts = mystr.Split('_');
            //       string thisPart = parts[2];

            //       //trying fix on this 09.16.2015 daron
            // //old      string homePageCheckbox = "AssignedAppsGridView_" + thisPart + "_setAsDefault";
            //       string homePageCheckbox = "AssignedAppsGridView_setAsDefault_" + thisPart;
            //       IWebElement thishomePageCheckbox = Browser.Wd.FindElement(By.Id(homePageCheckbox));
            //       thishomePageCheckbox.Click();

            ////old       string RoleId = "AssignedAppsGridView_" + thisPart + "_ddlAccessLevel";
            //       string RoleId = "AssignedAppsGridView_ddlAccessLevel_"+ thisPart;
            //       IWebElement thisLineSelectRole = Browser.Wd.FindElement(By.Id(RoleId));
            //       var mySelectDropdown = new SelectElement(thisLineSelectRole);
            //       mySelectDropdown.SelectByText(p0);

            //       tmsWait.WaitForReadyStateComplete(30);
        }

        [Given(@"I click on User Management icon")]
        public void GivenIClickOnUserManagementIcon()
        {
            tmsWait.Hard(2);
            EAM.UserAdministrationCrudUser.UserManagement_MenuIcon.Click();
            tmsWait.Implicit(30);
        }
        [When(@"User Management page Checkbox ""(.*)"" is clicked")]
        public void WhenUserManagementPageCheckboxIsClicked(string p0)
        {
            string checkbox = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                switch (checkbox.ToLower())
                {
                    case "tc90":
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//input[@name='tc90appRole']")));
                        break;
                }
            }
            else
            {
                switch (checkbox.ToLower())
                {
                    case "tc90":
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//input[contains(@test-id,'AddUser-CheckBox-TC90App')]")));
                        break;
                }
            }
        }

        [Given(@"Administration New User Checkbox ""(.*)"" is clicked")]
        public void GivenAdministrationNewUserCheckboxIsClicked(string p0)
        {
            string checkbox = tmsCommon.GenerateData(p0);


            switch (checkbox.ToLower())
            {
                case "tc90":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//input[contains(@test-id,'AddUser-CheckBox-TC90App')]")));
                    break;
            }
        }


        [When(@"I execute SQL Query on Database ""(.*)"" for user ""(.*)""")]
        public void WhenIExecuteSQLQueryOnDatabaseForUser(string p0, string p1)
        {
            string DB = tmsCommon.GenerateData(p0);
            string UserId = tmsCommon.GenerateData(p1);
            // string dbQuery = " SELECT Login_Name from [" + DB + "].[dbo].[users] where Login_Name = '" + UserId + "'";
            //string dbQuery = " SELECT Login_Name from [" + DB + "].[dbo].[users] where Login_Name = 'TestUser_aj_50'";
            // string dbQuery = " SELECT Login_Name from [" + DB + "].[dbo].[users] where Login_Name = 'GurdeepArora'";
            string SqlString = "SELECT Login_Name from [" + DB + "].[dbo].[users] where Login_Name = 'GurdeepArora'";
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DB, dbQuery);
        }


        [Given(@"Administration New User Add user button is clicked")]
        [When(@"Administration New User Add user button is clicked")]
        [Then(@"Administration New User Add user button is clicked")]
        public void GivenAdministrationNewUserAddUserButtonIsClicked()
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(5);
                fw.ExecuteJavascript(EAM.UserAdministrationCrudUser.AngularAddUser);
                tmsWait.Hard(5);
            }
            else
            {
                tmsWait.Hard(5);
                fw.ExecuteJavascript(EAM.UserAdministrationCrudUser.AddUser);
                tmsWait.Hard(5);
            }
        }

        [Then(@"verify UI of User Management page")]
        public void ThenVerifyUIOfUserManagementPage()
        {
            string[] columnNames = new string[] { "User Name", "User Type", "First Name", "Last Name", "Display Name", "Role", "Email ID", "Phone Number", "Active", "Edit" };
            foreach (string column in columnNames)
            {
                IWebElement gridElement = Browser.Wd.FindElement(By.XPath("//th[@role='columnheader'][contains(.,'" + column + "')]"));
                Assert.IsTrue(gridElement.Displayed, "Column Name : " + column + " is not displayed in file processing grid ");
            }
        }


        [Given(@"Administration Existing User Update button is clicked")]
        public void GivenAdministrationExistingUserUpdateButtonIsClicked()
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(EAM.UserAdministrationCrudUser.UpdateExistingUserButton);
            tmsWait.Hard(1);

        }

        [When(@"Administration New User Update User button is clicked")]
        public void WhenAdministrationNewUserUpdateUserButtonIsClicked()
        {
            string scrolltoAddUserBtn = "window.scrollBy(0,100)";
            fw.ExecuteJavascript(scrolltoAddUserBtn);
            tmsWait.Hard(2);
            EAM.UserAdministrationCrudUser.UpdateUserButton.Click();
            //tmsWait.WaitForAlertPresent();
            //Browser.Wd.SwitchTo().Alert().Accept();
            //Browser.Wd.SwitchTo().DefaultContent();
            tmsWait.Hard(1);
        }


        [Given(@"Administration New User Add user button is clicked and verify message ""(.*)""")]
        public void GivenAdministrationNewUserAddUserButtonIsClickedAndVerifyMessage(string p0)
        {
            string expectedValue = tmsCommon.GenerateData(p0);
            tmsWait.Hard(6);
            fw.ExecuteJavascript(EAM.UserAdministrationCrudUser.AddUser);
            // string actualValue = Browser.Wd.FindElement(By.XPath("//div[@class='toast-message']")).GetAttribute("aria-label");
            tmsWait.Hard(1);
            string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
            Assert.IsTrue(actualValue.Contains(expectedValue));
        }


        [Then(@"Verify TMS Identity Manager Page New User ""(.*)"" has created")]
        public void ThenVerifyTMSIdentityManagerPageNewUserHasCreated(string p0)
        {
            string expectedusername = tmsCommon.GenerateData(p0);
            bool resultFlag = false;
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")));
            IWebElement userTable = Browser.Wd.FindElement(By.XPath("//div[@id='grdUsers']//tbody"));
            IReadOnlyCollection<IWebElement> users = userTable.FindElements(By.TagName("tr"));

            foreach (var row in users)
            {
                string actualusername = row.FindElement(By.XPath("td[2]/span")).Text;
                if (actualusername.Equals(expectedusername))
                {
                    resultFlag = true;
                    break;
                }
            }

            Assert.IsTrue(resultFlag, "User Does not Exist");
        }

        [Then(@"Verify EAM Application is not displaying Administration Menu")]
        public void ThenVerifyEAMApplicationIsNotDisplayingAdministrationMenu()
        {
            By loc = By.CssSelector("[title='Administration']");
            UIMODUtilFunctions.elementNotPresenceUsingLocators(loc);
        }

        [Then(@"Verify EAM Application display TC(.*) link successfully")]
        public void ThenVerifyEAMApplicationDisplayTCLinkSuccessfully(String p0)
        {
            tmsWait.Hard(5);
            IWebElement elem = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_EamNavigation_pnlTrans_itemTC90_link"));
            Assert.IsTrue(elem.Displayed, " TC 90 is not getting dislayed");
        }


        [Then(@"Verify EAM Application display New TC(.*) link successfully")]
        public void ThenVerifyEAMApplicationDisplayNewTCLinkSuccessfully(String p0)
        {
            tmsWait.Hard(5);
            IWebElement elem = Browser.Wd.FindElement(By.XPath("//span[@test-id='tc90-lbl-drugedit']"));
            Assert.IsTrue(elem.Displayed, " TC 90 is not getting dislayed");
        }
        [Given(@"Administration New User TC90 to ""(.*)""")]
        public void GivenAdministrationNewUserTCTo(string p1)
        {
            string CheckBoxName = "TC90";
            EAM.UserAdministrationCrudUser.TC90DropDown.Click();
            IWebElement thisDropDownList = EAM.UserAdministrationCrudUser.TC90DropDownList;
            IList<IWebElement> theseLabels = thisDropDownList.FindElements(By.TagName("label"));
            foreach (IWebElement thisLabel in theseLabels)
            {
                if (thisLabel.Text == CheckBoxName)
                {
                    string sameID = thisLabel.GetAttribute("for");
                    thisDropDownList.FindElement(By.Id(sameID)).Click();
                    break;
                }
            }


            //tmsWait.Hard(2);            
            //IWebElement table = Browser.Wd.FindElement(By.Id("AssignedAppsGridView")); // you have the table
            //IList<IWebElement> allElements = table.FindElements(By.TagName("tr")); // you have all row that are visible
            //int thisCount = allElements.Count;
            //IWebElement thisWebElement = null;
            //foreach (IWebElement abc in allElements)
            //{
            //    thisWebElement = abc;
            //    Console.WriteLine(abc.Text);
            //    if (abc.Text.Contains(ConfigFile.Database))
            //    {
            //        break;
            //    }
            //}

            //string mystr = (thisWebElement.FindElement(By.CssSelector("input[type=checkbox]")).GetAttribute("id"));
            //string[] parts = mystr.Split('_');
            //string thisPart = parts[1];

            //string tc90 = "AssignedAppsGridView_" + thisPart + "_AllowTC90"; //"EditUserAssignedAppsGridView_" + thisPart + "_TC90AccessLevel"; //
            //try
            //{
            //    IWebElement thisTc90 = table.FindElement(By.Id(tc90)); //Browser.Wd.FindElement(By.Id(tc90));
            //    var mySelectDropdown = new SelectElement(thisTc90);
            //    mySelectDropdown.SelectByText(p1);
            //}
            //catch(Exception e)
            //    {
            //        Assert.Fail("TC90 select box was not found. Exception: " + e.Message);
            //    }
        }

        [Then(@"Menu Administration menu is not available")]
        public void ThenMenuAdministrationMenuIsNotAvailable()
        {
            try
            {
                EAMNavigationBar.FindClassObjects();
                Boolean doesExist = fw.elementExists(EAMNavigationBar.AdministrationLabel);
                Assert.AreEqual(doesExist, false, "Administration heading was not supposed to exist");
            }
            catch (NoSuchElementException)
            {
                Console.WriteLine("Administration Menu heading was not found as expected");
            }
        }
        [Then(@"Menu Administration menu is available")]
        public void ThenMenuAdministrationMenuIsAvailable()
        {
            tmsWait.Implicit(2);
            EAMNavigationBar.FindClassObjects();
            Boolean doesExist = fw.elementExists(EAMNavigationBar.AdministrationLabel);
            Assert.AreEqual(doesExist, true, "Administration heading was supposed to exist");
        }
        [Then(@"Menu Administration Status Override is available")]
        public void ThenMenuAdministrationStatusOverrideIsAvailable()
        {
            Boolean doesExist = fw.elementExists(EAM.NavigationBar.AdministrationStatusOverride);
            Assert.AreEqual(doesExist, true, "Administration heading was supposed to exist");
            EAM.NavigationBar.AdministrationStatusOverride.Click();
        }
        [Then(@"menu Administration External Integration is not available")]
        public void ThenMenuAdministrationExternalIntegrationIsNotAvailable()
        {
            try
            {
                Boolean doesExist = fw.elementExists(EAM.NavigationBar.AdministrationExternalIntegration);
                Assert.AreEqual(doesExist, false, "Administration External Integration heading was supposed to NOT exist");
            }
            catch (NoSuchElementException)
            {

                Console.WriteLine("Administration External Integration was not found as expected");
            }
        }

        [Then(@"menu Administration Export Session is not available")]
        public void ThenMenuAdministrationExportSessionIsNotAvailable()
        {
            try
            {
                Boolean doesExist = fw.elementExists(EAM.NavigationBar.AdministrationExportSession);
                Assert.AreEqual(doesExist, false, "Administration Export Session heading was supposed to NOT exist");
            }
            catch (NoSuchElementException)
            { Console.WriteLine("Administration Export Session was not found as expected"); }
        }
        [When(@"Administration Users Username is set to ""(.*)""")]
        public void WhenAdministrationUsersUsernameIsSetTo(string p0)
        {
            string Generated = tmsCommon.GenerateData(p0);
            EAM.UserAdministrationSearchUser.Username.SendKeys(Generated);
        }

        [When(@"Administration Users Username is set to userId from configFile")]
        public void WhenAdministrationUsersUsernameIsSetToUserIdFromConfigFile()
        {
            EAM.UserAdministrationCrudUser.Username.SendKeys(ConfigFile.UserId);
        }

        [When(@"Adminstration Users Search button is clicked")]
        public void WhenAdminstrationUsersSearchButtonIsClicked()
        {
            EAM.UserAdministrationSearchUser.Search.Click();
        }

        [When(@"Adminstration Users Edit button is clicked")]
        [Then(@"Adminstration Users Edit button is clicked")]
        public void WhenAdminstrationUsersEditButtonIsClicked()
        {
            tmsWait.Hard(2);
            EAM.UserAdministrationSearchUser.UserSearchEditButton.Click();
        }

        [Then(@"Administration Users Table Row is deleted")]
        public void ThenAdministrationUsersTableRowIsDeleted(Table table)
        {
            //Establish the next page link for flipping pages as necessary
            string NextPageLinkText = "";
            Boolean bNotAtLastPageOfRecords = true;
            Boolean bHaveGoodPageLink = true;
            IWebElement NPL = null;
            //Get the Table Header off of the test script Gherkin table
            ICollection<string> thisTH = table.Header;
            int thCount = thisTH.Count;
            string[] thisHeader = new string[thisTH.Count];
            thisTH.CopyTo(thisHeader, 0);   //copies the header to an array

            //Set up an array of classes to hold the table data, first one (0) will be the header info
            //The class has flags for this data row being a header, data and if we have yet matched it in our trials
            TableRow[] thisTableArr = new TableRow[table.RowCount + 1];
            thisTableArr[0] = new TableRow();
            thisTableArr[0].RowIsHeader = true;
            thisTableArr[0].RowIsData = false;
            thisTableArr[0].RowIsMatched = false;
            //Add the header data to the array 0 table row instance
            foreach (string thisString in thisHeader)
            {
                thisTableArr[0].Row.Add(thisString);
            }
            int iCounter = 1;
            //Add the Gherkin table row data to the array of rows.  These are all data, not headers, not matched yet.
            foreach (var row in table.Rows)
            {
                thisTableArr[iCounter] = new TableRow();
                thisTableArr[iCounter].RowIsHeader = false;
                thisTableArr[iCounter].RowIsData = true;
                thisTableArr[iCounter].RowIsMatched = false;

                for (int c = 0; c < row.Count; c++)
                {
                    string ElementValue = row[c];
                    if (ElementValue.Length > 9)
                    {
                        string leftSide = ElementValue.Substring(0, 9);
                        leftSide = leftSide.ToLower();
                        if (leftSide.ToLower() == "variable[")
                        {
                            int strLength = ElementValue.Length - 1;
                            string varName = ElementValue.Substring(9, strLength - 9);
                            ElementValue = tmsCommon.GenerateData("generate|variable|" + varName);
                        }
                    }
                    thisTableArr[iCounter].Row.Add(ElementValue);
                }
                iCounter++;
            }
            //While we have not matched all rows yet
            //and we are not on the last page of records..
            while (thisTableArr[0].AllRowsMatched(thisTableArr) == false && bNotAtLastPageOfRecords)
            {
                bNotAtLastPageOfRecords = false;
                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.UserAdministrationSearchUser.UserSearchTable;
                //Get the spans data, this is the current page number.  Derive the next page number.
                ICollection<IWebElement> mySpans = baseTable.FindElements(By.TagName("span"));
                //NL 03/27/2015 skip next steps if there are no such elements
                if (mySpans.Count > 0)
                {

                    foreach (IWebElement thisSpan in mySpans)
                    {
                        int CurrentPageNumber = Convert.ToInt16(thisSpan.Text);
                        int NextPageNumber = CurrentPageNumber + 1;
                        NextPageLinkText = NextPageNumber.ToString();
                    }
                    //Find the link for the next page.  (for later)
                    try
                    {
                        NPL = baseTable.FindElement(By.LinkText(NextPageLinkText));
                    }
                    catch
                    {
                        bNotAtLastPageOfRecords = true;
                        bHaveGoodPageLink = false;
                    }
                }
                else
                {
                    bNotAtLastPageOfRecords = true;
                    bHaveGoodPageLink = false;
                }
                //Get rows out of the table on the page, from the table object
                ICollection<IWebElement> myRows = baseTable.FindElements(By.TagName("tr"));
                int RowCount = myRows.Count;
                //Establish an array of table rows for the page data.
                TableRow[] thisDataArr = new TableRow[RowCount];
                int EstablishedRowItemCount = 0;
                int iRowCounter = 0;
                foreach (IWebElement thisRow in myRows)
                {
                    //For each new data row we look at, add a new instance of the class to the array.
                    thisDataArr[iRowCounter] = new TableRow();
                    thisDataArr[iRowCounter].RowIsHeader = true;
                    thisDataArr[iRowCounter].RowIsData = false;
                    thisDataArr[iRowCounter].RowIsMatched = false;
                    //Get all of the elements from the row (<td>)
                    ICollection<IWebElement> myElements;
                    if (iRowCounter == 0)
                    {
                        myElements = thisRow.FindElements(By.TagName("td"));
                    }
                    else
                    {
                        myElements = thisRow.FindElements(By.TagName("td"));
                    }
                    //Row 0 is the header
                    //The rest of the rows are data
                    foreach (IWebElement thisElement in myElements)
                    {
                        if (iRowCounter == 0)
                        {
                            //Finding the normal item count because the page numbers are a data row.
                            //Row 0 is the header
                            EstablishedRowItemCount = myElements.Count;
                            thisDataArr[iRowCounter].RowIsHeader = true;
                            thisDataArr[iRowCounter].RowIsData = false;
                        }
                        else
                        {
                            //Other rows are data
                            thisDataArr[iRowCounter].RowIsHeader = false;
                            thisDataArr[iRowCounter].RowIsData = true;
                        }
                        if (myElements.Count == EstablishedRowItemCount)
                        {
                            //Only add data if we have a data row, not if we have a 0 length row.
                            thisDataArr[iRowCounter].Row.Add(thisElement.Text.ToString());
                        }
                        else
                        {
                            //If this row count isn't the right number of items, we didn't match with expected.
                            thisDataArr[iRowCounter].RowIsData = false;
                        }
                    }
                    iRowCounter++;
                }
                int iTableCounter = 0;
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TableRow TTA in thisTableArr)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.
                    if (TTA.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] ta = TTA.Row.ToArray();

                        //For each row in the page data
                        foreach (TableRow TDA in thisDataArr)
                        {
                            //Convert page data to array elements
                            string[] td = TDA.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.
                            foreach (string tde in td)
                            {
                                if (iElementCounter > -1 && TDA.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (tde != ta[iElementCounter] && ta[iElementCounter] != "[Skip]")
                                    {
                                        bThisRowMatches = false;
                                        //NL 03/26/2015 add break statement if first mismatch is found
                                        break;
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (td.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same
                            if (bThisRowMatches)
                            {
                                //Report the match, first convert the array back to a string we can read.
                                thisTableArr[iTableCounter].RowIsMatched = true;
                                ICollection<IWebElement> myDeleteButtons = baseTable.FindElements(By.CssSelector("img[title='click here to delete this user...']"));
                                int DeleteButtonCount = myDeleteButtons.Count;
                                int iButtonCounter = 1;
                                foreach (IWebElement thisDeleteButton in myDeleteButtons)
                                {
                                    if (iButtonCounter == iTableCounter)
                                    {
                                        tmsWait.Hard(2);
                                        fw.ExecuteJavascript(thisDeleteButton);
                                        tmsWait.Hard(5);
                                        Browser.Wd.SwitchTo().Alert().Accept();
                                        Browser.Wd.SwitchTo().DefaultContent();
                                        Console.WriteLine("User was deleted as per the matching table row.");
                                        //NL 03/26/2015 break for if row is found
                                        break;
                                    }
                                    iButtonCounter++;
                                }
                                string TR0 = TableRow.ArrayToString(td);
                                string TR1 = TableRow.ArrayToString(ta);
                                Console.WriteLine("Expected Row Data - " + TR0);
                                Console.WriteLine("Found Row Data ------- " + TR1);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisTableArr[0].AllRowsMatched(thisTableArr);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        bNotAtLastPageOfRecords = true;
                        bNotAtLastPageOfRecords = false;  //Overriding, only look at first page

                        // NPL.Click();
                        System.Threading.Thread.Sleep(2000);
                    }
                }
                try  //putting this in container in case the delete removes the last row and the table is gone
                {
                    baseTable = EAM.UserAdministrationSearchUser.UserSearchTable;
                }
                catch
                { }
                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (bHaveGoodPageLink == false && !fullMatching)
                {
                    int iCount = 0;
                    var TableRow = new TMSString();
                    foreach (TableRow thisTR in thisTableArr)
                    {
                        if (thisTR.RowIsMatched == false && thisTR.RowIsHeader == false)
                        {
                            string thisRowData = TableRow.ArrayToString(thisTR.Row.ToArray());
                            Console.WriteLine("Unmatched Data Row -- " + thisRowData);
                        }
                        iCount++;
                    }
                    Assert.AreEqual(true, false, "Not all expected rows in the Gherkin test table were found in the page table data rows.");
                }
            }
        }
        [When(@"Administration Manage PlanSCC ViewEdit Plan ID is set to ""(.*)""")]
        public void WhenAdministrationManagePlanSCCViewEditPlanIDIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.AdministrationManagePlanSCCViewEdit.PlanID);
            select.SelectByText(value);
            tmsWait.Hard(2);
        }
        [When(@"Administration Manage PlanSCC ViewEdit PBP is set to ""(.*)""")]
        public void WhenAdministrationManagePlanSCCViewEditPBPIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.AdministrationManagePlanSCCViewEdit.PBP);
            select.SelectByText(value);
            tmsWait.Hard(2);

        }
        [When(@"Administration Manage PlanSCC ViewEdit SCC is set to ""(.*)""")]
        public void WhenAdministrationManagePlanSCCViewEditSCCIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.AdministrationManagePlanSCCViewEdit.SCC);
            select.SelectByText(value);
            tmsWait.Hard(2);

        }
        [When(@"Administration Manage PlanSCC ViewEdit GO Button is clicked")]
        public void WhenAdministrationManagePlanSCCViewEditGOButtonIsClicked()
        {
            fw.ExecuteJavascript(EAM.AdministrationManagePlanSCCViewEdit.Go);
            tmsWait.Hard(2);
        }
        [Then(@"Verify Administration Manage PlanSCC ViewEdit Table has rows count ""(.*)""")]
        public void ThenVerifyAdministrationManagePlanSCCViewEditTableHasRowsCount(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            IList<IWebElement> thisRowCount = EAM.AdministrationManagePlanSCCViewEdit.EditPlanTable.FindElements(By.TagName("tr"));
            int iCounter = 0;
            foreach (IWebElement thisRow in thisRowCount)
            {
                iCounter++;
            }
            Assert.AreEqual(2, iCounter, "Expecting [0] data rows in the table, found [" + (iCounter - 2).ToString() + "]");
            Console.WriteLine("Expecting [0] data rows in the table, found [" + (iCounter - 2).ToString() + "]");
        }
        [Then(@"Verify Administrationpage Manage Plan SCC section has rows count ""(.*)""")]
        public void ThenVerifyAdministrationpageManagePlanSCCSectionHasRowsCount(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            IList<IWebElement> thisRowCount = Browser.Wd.FindElements(By.TagName("tr"));
            int iCounter = 0;
            foreach (IWebElement thisRow in thisRowCount)
            {
                iCounter++;
            }
            iCounter = iCounter - 1;
            Assert.AreEqual(value, iCounter, "Expecting [0] data rows in the table, found [" + (iCounter - 2).ToString() + "]");

        }


        [When(@"Administration Manage PlanSCC ViewEdit Table Add Button is clicked")]
        public void WhenAdministrationManagePlanSCCViewEditTableAddButtonIsClicked()
        {
            EAM.AdministrationManagePlanSCCViewEdit.Add.Click();
            tmsWait.Hard(2);
        }
        [Then(@"Administration Manage PlanSCC ViewEdit Edit Dialog is displayed")]
        public void ThenAdministrationManagePlanSCCViewEditEditDialogIsDisplayed()
        {
            Boolean popupDisplayed = EAM.AdministrationManagePlanSCCViewEdit.Popup.Displayed;
            if (popupDisplayed)
            {
                Console.WriteLine("Administration Manage Plan SCC View/Edit Add popup is displayed");
            }
            else
            {
                Assert.AreEqual(true, false, "Administration Manage Plan SCC View/Edit Add popup is not displayed.   It was supposed to be.");
            }
        }
        [When(@"Administration Manage PlanSCC ViewEdit Edit Dialog Plan ID is set to ""(.*)""")]
        public void WhenAdministrationManagePlanSCCViewEditEditDialogPlanIDIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.AdministrationManagePlanSCCViewEdit.PopupPlanID);
            select.SelectByText(value);
            tmsWait.Hard(2);
        }
        [When(@"Administration Manage PlanSCC ViewEdit Edit Dialog PBP is set to ""(.*)""")]
        public void WhenAdministrationManagePlanSCCViewEditEditDialogPBPIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.AdministrationManagePlanSCCViewEdit.PopupPBP);
            select.SelectByText(value);
            tmsWait.Hard(2);
        }
        [When(@"Administration Manage PlanSCC ViewEdit Edit Dialog SCC is set to ""(.*)""")]
        public void WhenAdministrationManagePlanSCCViewEditEditDialogSCCIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.AdministrationManagePlanSCCViewEdit.PopupSCC);
            select.SelectByText(value);
            tmsWait.Hard(2);
        }
        [When(@"Administration Manage PlanSCC ViewEdit Edit Dialog Effective Date is set to ""(.*)""")]
        public void WhenAdministrationManagePlanSCCViewEditEditDialogEffectiveDateIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            GeneratedData = GeneratedData.Replace("/", "");

            EAM.AdministrationManagePlanSCCViewEdit.PopupEffectiveDate.Clear();
            EAM.AdministrationManagePlanSCCViewEdit.PopupEffectiveDate.SendKeys(GeneratedData);
        }
        [When(@"Administration Manage PlanSCC ViewEdit Edit Dialog End Date is set to ""(.*)""")]
        public void WhenAdministrationManagePlanSCCViewEditEditDialogEndDateIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            GeneratedData = GeneratedData.Replace("/", "");

            EAM.AdministrationManagePlanSCCViewEdit.PopupEndDate.Clear();
            EAM.AdministrationManagePlanSCCViewEdit.PopupEndDate.SendKeys(GeneratedData);
        }
        [When(@"Administration Manage PlanSCC ViewEdit Edit Dialog Save Button is clicked")]
        public void WhenAdministrationManagePlanSCCViewEditEditDialogSaveButtonIsClicked()
        {
            fw.ExecuteJavascript(EAM.AdministrationManagePlanSCCViewEdit.PopupSave);
            tmsWait.Hard(2);
        }
        [When(@"Administration Manage PlanSCC ViewEdit Table Delete Button is clicked")]
        public void WhenAdministrationManagePlanSCCViewEditTableDeleteButtonIsClicked()
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(EAM.AdministrationManagePlanSCCViewEdit.Delete);
            tmsWait.Hard(1);
            IWebElement delete = Browser.Wd.FindElement(By.XPath("//input[@id='ctl00_ctl00_MainMasterContent_MainContent_delete']"));
            fw.ExecuteJavascript(delete);
            tmsWait.Hard(1);
        }
        [Then(@"Verify AdministrationManage PlanSCC ViewEdit Delete PopUp Message ""(.*)"" is displayed")]
        public void ThenVerifyAdministrationManagePlanSCCViewEditDeletePopUpMessageIsDisplayed(string p0)
        {
            string AlertText = Browser.Wd.SwitchTo().Alert().Text;
            AlertText = AlertText.Replace("\r\n", " ");
            string value = tmsCommon.GenerateData(p0);
            Assert.IsTrue(AlertText.Contains(value), "Dialog Message [" + value + "] was found as " + AlertText + "");

            Console.WriteLine("Dialog Message [" + value + "] was found as [" + AlertText + "]");
        }
        [When(@"AdministrationManage PlanSCC ViewEdit Delete PopUp ""(.*)"" Button is clicked")]
        public void WhenAdministrationManagePlanSCCViewEditDeletePopUpButtonIsClicked(string p0)
        {
            tmsWait.Hard(3);
            Browser.ClosePopUps(true);
        }

        [When(@"Edit Plan PBP Seg ID to SCC Mapping page Plan ID as ""(.*)"" PBP as ""(.*)"" SCC as ""(.*)"" row is Edited")]
        public void WhenEditPlanPBPSegIDToSCCMappingPagePlanIDAsPBPAsSCCAsRowIsEdited(string Plan, string pbp, string scc)
        {
            //table[@id='ctl00_ctl00_MainMasterContent_MainContent_grid']//tr/td[contains(.,'S2001')]/following-sibling::td[contains(.,'001')]/following-sibling::td[contains(.,'01000')]/preceding::td/input[contains(@id,'ImageButton1')]
            IWebElement edit = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_grid']//tr/td[contains(.,'" + Plan + "')]/following-sibling::td[contains(.,'" + pbp + "')]/following-sibling::td[contains(.,'" + scc + "')]/preceding::td/input[contains(@id,'ImageButton1')]"));
            fw.ExecuteJavascript(edit);
            tmsWait.Hard(3);
        }

        [When(@"Edit Plan PBP Seg ID to SCC Mapping page PlanSCC ViewEdit Edit Dialog is set to ""(.*)""")]
        public void WhenEditPlanPBPSegIDToSCCMappingPagePlanSCCViewEditEditDialogIsSetTo(string scc)
        {
            IWebElement drp = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_sccsEdit"));

            SelectElement viewedit = new SelectElement(drp);
            viewedit.SelectByText(scc);
            tmsWait.Hard(1);
            IWebElement save = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_saveButton"));
            fw.ExecuteJavascript(save);
            tmsWait.Hard(1);

        }


        [Then(@"Verify Edit Plan PBP Seg ID to SCC Mapping page dosent have Plan ID as ""(.*)"" PBP as ""(.*)"" SCC as ""(.*)""")]
        public void ThenVerifyEditPlanPBPSegIDToSCCMappingPageDosentHavePlanIDAsPBPAsSCCAs(string Plan, string pbp, string scc)
        {
            try
            {
                if (Browser.Wd.FindElement(By.XPath("(//table[@id='ctl00_ctl00_MainMasterContent_MainContent_grid']//tr/td[contains(.,'" + Plan + "')]/following-sibling::td[contains(.,'" + pbp + "')]/following-sibling::td[contains(.,'" + scc + "')])[1]")).Displayed)
                {

                    Assert.Fail();
                }

            }

            catch
            {
                Assert.IsTrue(true);
                fw.ConsoleReport(" Plan " + Plan + " PBP " + pbp + "SCC " + scc + " are  deleted");
            }
        }

        [When(@"Administration Manage PlanSCC ViewEdit Table CheckBox is set to ""(.*)"" for row")]
        public void WhenAdministrationManagePlanSCCViewEditTableCheckBoxIsSetToForRow(string p0, Table table)
        {
            {
                //Create Storage for the Gherkin table and the page data
                GherkinTable thisGT = new GherkinTable();
                TablePaging thisTP = new TablePaging();

                //Load the Gherkin table into the storage
                thisGT.LoadGherkinTable(table);

                //The big loop.  Keep working until all the Gherkin table rows are marked as matched
                //Or until we are on the last page of records, then we also quit looking.
                while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
                {
                    //Start out with the assumption we are not on the last page of records.  We will check later.
                    thisTP.bNotAtLastPageOfRecords = true;

                    //Get the table object again, since the page refreshes we need to get it fresh
                    IWebElement baseTable = EAM.AdministrationManagePlanSCCViewEdit.EditPlanTable;

                    //Look for a next page link.  We will set 'last page of records' here also.
                    thisTP.LoadNextPageLink(baseTable);

                    //Load the page data off the application.   
                    //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                    thisTP.LoadPageTable(baseTable, "td", "td");

                    int iTableCounter = 0;
                    //                string expectedTableCheckboxValue = "";
                    //for each row in the Gherkin table, start flipping through all the rows in the page data.
                    foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                    {
                        //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                        //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                        if (GherkinTableRow == null)
                        {
                            break;
                        }

                        //If this Gherkin table row is not yet matched, proceed.
                        if (GherkinTableRow.RowIsMatched == false)
                        {
                            //Convert the row to an array so we can do an element by element match.
                            string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                            //For each row in the page data
                            foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                            {
                                //Convert page data to array elements
                                //Only work with the loaded element rows.  The first unloaded one will be null.
                                if (ApplicationRow == null)
                                {
                                    break;
                                }

                                //Convert the page row to array so we can pair up by elements.
                                string[] AppTableRow = ApplicationRow.Row.ToArray();
                                int iElementCounter = 0;
                                Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                                //In here as we pair up the data you will have custom matching.
                                //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                                foreach (string appTD in AppTableRow)
                                {
                                    //if (iElementCounter > 0 && TDA.RowIsData)
                                    if (ApplicationRow.RowIsData)
                                    {
                                        //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                        if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                        {
                                            bThisRowMatches = false;
                                        }
                                    }
                                    else
                                    {
                                        //Also fail row match if the element count of the page data row is 0
                                        if (iElementCounter > 0)
                                        {
                                            bThisRowMatches = false;
                                        }
                                    }
                                    iElementCounter++;
                                }
                                if (AppTableRow.Length == 0)
                                {
                                    //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                    bThisRowMatches = false;
                                }
                                //Instance of TableRow Class for reporting functions
                                var TableRow = new TMSString();
                                //If we get here and we still match, then the array elements were the same
                                if (bThisRowMatches)
                                {
                                    //report the success stuff.  Puts out the row data, etc.
                                    thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                                }

                            }
                        }
                        iTableCounter++;
                    }
                    //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                    Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                    if (fullMatching)
                    {
                        Console.WriteLine("All rows are matched, step completed as passed");
                    }
                    else
                    {
                        //Click next page link and start over.
                        if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                        {
                            thisTP.bNotAtLastPageOfRecords = true;
                            thisTP.NPL.Click();
                            tmsWait.Hard(2);
                        }
                    }

                    baseTable = EAM.AdministrationManagePlanSCCViewEdit.EditPlanTable;

                    //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                    //Time to boil it down and report which rows didn't get matched.
                    //Also to fail because we were planning to match the rows.
                    if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                    {
                        thisTP.ReportNotMatching(thisGT.GTable);
                    }
                }
            }
        }

        [Then(@"Verify Administration Manage PlanSCC ViewEdit Table has row")]
        public void ThenVerifyAdministrationManagePlanSCCViewEditTableHasRow(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.AdministrationManagePlanSCCViewEdit.EditPlanTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                baseTable = EAM.AdministrationManagePlanSCCViewEdit.EditPlanTable;
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same
                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }

                baseTable = EAM.AdministrationManagePlanSCCViewEdit.EditPlanTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }
    }

    //Jaya Pallempati 08/18/2015
    [Binding]
    public class EAMExternalIntegration
    {
        [Then(@"""(.*)"" page is displayed")]
        public void ThenPageIsDisplayed(string p0)
        {
            string pageheadertext = EAM.AdministrationExternalIntegration.PageHeaderText.Text;
            Assert.AreEqual("External Integration", pageheadertext);
        }

        [When(@"I Selected Attribute type as Provider")]
        public void WhenISelectedAttributeTypeAsProvider()
        {
            EAM.AdministrationExternalIntegration.AtrributeType.SendKeys("Provider");

            tmsWait.Hard(1);
        }

        [Then(@"Provider Source buttons EAM and QNXT are displayed")]
        public void ThenProviderSourceButtonsEAMAndQNXTAreDisplayed()
        {
            Assert.IsTrue(EAM.AdministrationExternalIntegration.EAMProviderSourcebtn.Displayed);
            Assert.IsTrue(EAM.AdministrationExternalIntegration.QNXTProviderSourcebtn.Displayed);
        }

        [When(@"I click on provider source EAM button")]
        public void WhenIClickOnProviderSourceEAMButton()
        {
            EAM.AdministrationExternalIntegration.EAMProviderSourcebtn.Click();
        }

        [Then(@"Current Provider Source text is changed to show EAM")]
        public void ThenCurrentProviderSourceTextIsChangedToShowEAM()
        {
            Assert.AreEqual("EAM", EAM.AdministrationExternalIntegration.CurrentProviderSourcetxt.Text.Trim());
        }

        [When(@"I click on provider source QNXT button")]
        public void WhenIClickOnProviderSourceQNXTButton()
        {

            IWebElement psource = Browser.Wd.FindElement(By.XPath("//label[@test-id='externalIntegration-lbl-currentProviderSource']"));
            string providerSource = psource.Text;
            if (providerSource != "QNXT")
            {
                EAM.AdministrationExternalIntegration.QNXTProviderSourcebtn.Click();
            }


        }

        [Then(@"I Clicked on EAM button under Provider Source")]
        public void ThenIClickedOnEAMButtonUnderProviderSource()
        {
            EAM.AdministrationExternalIntegration.EAMProviderSourcebtn.Click();
        }


        [Then(@"Current Provider Source text is changed to show QNXT")]
        public void ThenCurrentProviderSourceTextIsChangedToShowQNXT()
        {
            Console.WriteLine(EAM.AdministrationExternalIntegration.CurrentProviderSourcetxt.Text);
            Assert.AreEqual("QNXT", EAM.AdministrationExternalIntegration.CurrentProviderSourcetxt.Text.Trim());
        }

        [Then(@"I entered URL ""(.*)""")]
        public void ThenIEnteredURL(string p0)
        {
            EAM.AdministrationExternalIntegration.QNXTURL.Clear();
            EAM.AdministrationExternalIntegration.QNXTURL.SendKeys(p0);
            tmsWait.Hard(2);
        }


        [Then(@"I clicked on Update button and URL is updated as ""(.*)""")]
        public void ThenIClickedOnUpdateButtonAndURLIsUpdatedAs(string p0)
        {
            tmsWait.Hard(2);
            Browser.Wd.SwitchTo().ActiveElement();
            EAM.AdministrationExternalIntegration.QNXTUpdateBtn.Click();
        }


        [Then(@"I Clicked on TestConnection")]
        public void ThenIClickedOnTestConnection()
        {
            tmsWait.Hard(4);
            EAM.AdministrationExternalIntegration.QNXTTestConnectionBtn.Click();
            Console.WriteLine("This step is Passed");
            Assert.IsTrue(EAM.AdministrationExternalIntegration.QNXTTestConnectionpopup.Displayed);
        }

        [Given(@"I have navigated to ""(.*)"" from TriZetto Administration page")]
        public void GivenIHaveNavigatedToFromTriZettoAdministrationPage(string p0)
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@title='Tenant Administration']")));
            tmsWait.Hard(2);
            IWebElement menu = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]"));
            fw.ExecuteJavascript(menu);
        }

        [When(@"Configuration Name is set to ""(.*)""")]
        public void WhenConfigurationNameIsSetTo(string p0)
        {
            IWebElement menu = Browser.Wd.FindElement(By.CssSelector("[test-id='coresystem-txt-configurationnamefacets']"));
            menu.SendKeys(p0);

        }

        [When(@"Facets End Point is set to ""(.*)""")]
        public void WhenFacetsEndPointIsSetTo(string p0)
        {
            IWebElement menu = Browser.Wd.FindElement(By.CssSelector("[test-id='coresystem-txt-facetsendpoint']"));
            menu.SendKeys(p0);
        }

        [When(@"Identity is set to ""(.*)""")]
        public void WhenIdentityIsSetTo(string p0)
        {
            IWebElement menu = Browser.Wd.FindElement(By.CssSelector("[test-id='coresystem-txt-identity']"));
            menu.SendKeys(p0);
        }

        [When(@"Region is set to ""(.*)""")]
        public void WhenRegionIsSetTo(string p0)
        {
            IWebElement menu = Browser.Wd.FindElement(By.CssSelector("[test-id='coresystem-txt-region']"));
            menu.SendKeys(p0);
        }

        [When(@"Server is set to ""(.*)""")]
        public void WhenServerIsSetTo(string p0)
        {
            IWebElement menu = Browser.Wd.FindElement(By.CssSelector("[test-id='coresystem-txt-server']"));
            menu.SendKeys(p0);
        }

        [When(@"Database is set to ""(.*)""")]
        public void WhenDatabaseIsSetTo(string p0)
        {
            IWebElement menu = Browser.Wd.FindElement(By.CssSelector("[test-id='coresystem-txt-database']"));
            menu.SendKeys(p0);
        }

        [When(@"Database User Id is set to ""(.*)""")]
        public void WhenDatabaseUserIdIsSetTo(string p0)
        {
            IWebElement menu = Browser.Wd.FindElement(By.CssSelector("[test-id='coresystem-txt-databaseuserid']"));
            menu.SendKeys(p0);
        }

        [When(@"Database Password is set to ""(.*)""")]
        public void WhenDatabasePasswordIsSetTo(string p0)
        {
            IWebElement menu = Browser.Wd.FindElement(By.CssSelector("[test-id='coresystem-txt-databasepassword']"));
            menu.SendKeys(p0);
        }

        [When(@"Save button is Clicked")]
        public void WhenSaveButtonIsClicked()
        {
            IWebElement menu = Browser.Wd.FindElement(By.XPath("//button[@test-id='coresystem-btn-save']"));
            fw.ExecuteJavascript(menu);
        }

        [When(@"I have navigated to ""(.*)"" from TriZetto Administration page")]
        public void WhenIHaveNavigatedToFromTriZettoAdministrationPage(string p0)
        {
            IWebElement submenu = Browser.Wd.FindElement(By.XPath("//a[@title='" + p0 + "']/span"));
            fw.ExecuteJavascript(submenu);
        }

        [When(@"Manage Configuration page ""(.*)"" drop down value is set to ""(.*)""")]
        public void WhenManageConfigurationPageDropDownValueIsSetTo(string p0, string value)
        {
            IWebElement submenu = Browser.Wd.FindElement(By.XPath("(//span[@class='k-dropdown-wrap k-state-default'])[4]"));
            fw.ExecuteJavascript(submenu);
            tmsWait.Hard(2);
            IWebElement drpvalue = Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + value + "')]"));
            fw.ExecuteJavascript(drpvalue);


            //string comp = "ddl" + p0 + "";
            //IWebElement ele = Browser.Wd.FindElement(By.Id("ddl"+p0+""));
            //SelectElement drp = new SelectElement(ele);
            //drp.SelectByText(value);            
        }

        [When(@"Manage Configuration page Back to Record button is clicked")]
        public void WhenManageConfigurationPageBackToRecordButtonIsClicked()
        {
            IWebElement back = Browser.Wd.FindElement(By.CssSelector("[test-id='manageConfiguration-span-back'] i"));
            fw.ExecuteJavascript(back);
            tmsWait.Hard(5);
        }

        [Then(@"Verify EAM Application ""(.*)"" page is getting displayed")]
        public void ThenVerifyEAMApplicationPageIsGettingDisplayed(string expectedTitle)
        {
            string actualTitle = Browser.Wd.Title;
            Assert.AreEqual(expectedTitle, actualTitle, expectedTitle + "is not getting displayed");
        }




        [When(@"Manage Configuration page Save button is Clicked")]
        public void WhenManageConfigurationPageSaveButtonIsClicked()
        {
            IWebElement save = Browser.Wd.FindElement(By.CssSelector("[test-id='manageConfiguration-btn-save']"));
            fw.ExecuteJavascript(save);
            tmsWait.Hard(5);
        }


        [When(@"Tenant setup page ""(.*)"" link is Clicked")]
        public void WhenTenantSetupPageLinkIsClicked(string p0)
        {
            tmsWait.Hard(3);
            string[] url = ConfigFile.URL.Split('.');
            string currentTenant = url[0].Substring(8);
            if (currentTenant.Equals("tms-qa"))
            {
                string tmsqa = currentTenant.ToUpper();
                IWebElement link = Browser.Wd.FindElement(By.XPath("//div[@id='grdTenantSetUp']//table//td[contains(.,'" + tmsqa + "')]/following-sibling::td/a[contains(.,'Manage Configuration')]"));
                fw.ExecuteJavascript(link);
            }
            else
            {
                CultureInfo cultureInfo = Thread.CurrentThread.CurrentCulture;
                TextInfo textInfo = cultureInfo.TextInfo;
                string otherTenanat = textInfo.ToTitleCase(currentTenant);
                IWebElement link = Browser.Wd.FindElement(By.XPath("//div[@id='grdTenantSetUp']//table//td[contains(.,'" + otherTenanat + "')]/following-sibling::td/a[contains(.,'Manage Configuration')]"));
                fw.ExecuteJavascript(link);

            }



        }





        [When(@"Core Systems ""(.*)"" option is Clicked")]
        public void WhenCoreSystemsOptionIsClicked(string p0)
        {
            IWebElement menu = Browser.Wd.FindElement(By.XPath("//label[@for='coresystem-radio-" + p0 + "']"));
            fw.ExecuteJavascript(menu);
        }


        [Given(@"I Clicked on ""(.*)"" accordion")]
        public void GivenIClickedOnAccordion(string p0)
        {


            tmsWait.Hard(4);
            IWebElement menu = Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + p0 + "')]"));
            fw.ExecuteJavascript(menu);
        }

        [When(@"I Clicked on ""(.*)"" accordion")]
        public void WhenIClickedOnAccordion(string p0)
        {
            tmsWait.Hard(4);
            IWebElement menu = Browser.Wd.FindElement(By.CssSelector("//label[contains(.,'" + p0 + "')]"));
            fw.ExecuteJavascript(menu);
        }


        [Given(@"I Clicked on ""(.*)"" tab")]
        public void GivenIClickedOnTab(string p0)
        {
            IWebElement menu = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Operational')]"));
            fw.ExecuteJavascript(menu);
        }
        [Then(@"Verify Operational tab ""(.*)"" Textbox Field is displayed")]
        public void GivenVerifyOperationalTabTextboxFieldIsDisplayed(string p0)
        {
            IWebElement element = Browser.Wd.FindElement(By.XPath("//input[@test-id='internalDatabases-input-" + p0 + "']"));
            Assert.IsTrue(element.Displayed, p0 + "is not getting displayed");
        }

        [Then(@"Verify Operational tab ""(.*)"" dropdown Field is displayed")]
        public void ThenVerifyOperationalTabDropdownFieldIsDisplayed(string p0)
        {
            IWebElement element = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@test-id='internalDatabases-select-" + p0 + "']"));
            Assert.IsTrue(element.Displayed, p0 + "is not getting displayed");
        }

        [Then(@"Verify Operational tab ""(.*)"" button Field is displayed")]
        public void ThenVerifyOperationalTabButtonFieldIsDisplayed(string p0)
        {
            IWebElement element = Browser.Wd.FindElement(By.XPath("//button[@test-id='internalDatabases-btn-" + p0 + "']"));
            Assert.IsTrue(element.Displayed, p0 + "is not getting displayed");
        }



        [Given(@"Verify ""(.*)"" Textbox Field is displayed")]
        public void GivenVerifyTextboxFieldIsDisplayed(string textboxField)
        {
            textboxField = textboxField.Replace(" ", string.Empty);
            Assert.IsTrue(Browser.Wd.FindElement(By.Id("txt" + textboxField + "")).Displayed);
        }

        [Given(@"Select ""(.*)"" is selected for Authentication")]
        public void GivenSelectIsSelectedForAuthentication(string p0)
        {
            IWebElement authentication = Browser.Wd.FindElement(By.Id("ddlAuthentication"));
            SelectElement select = new SelectElement(authentication);
            select.SelectByText(p0);
        }
        [Given(@"Administration New User default Drop down has all application")]
        public void GivenAdministrationNewUserDefaultDropDownHasAllApplication()
        {
            IWebElement defaultAppselection = Browser.Wd.FindElement(By.CssSelector("[test-id='AddUser-Select-DefaultApplicationRequired']"));
            SelectElement defappSel = new SelectElement(defaultAppselection);
            IList<IWebElement> list = defappSel.Options;
            for (int i = 0; i < list.Count; i++)
            {

                Console.WriteLine(list[i].Text);

            }
        }

        [Given(@"Administration New User Default application ""(.*)"" is selected")]
        public void GivenAdministrationNewUserDefaultApplicationIsSelected(string app)
        {
            IWebElement defaultAppselection = Browser.Wd.FindElement(By.CssSelector("[test-id='AddUser-Select-DefaultApplicationRequired']"));
            SelectElement defappSel = new SelectElement(defaultAppselection);
            defappSel.SelectByText(app);
        }


        [Given(@"Verify ""(.*)"" Button Field is displayed")]
        public void GivenVerifyButtonFieldIsDisplayed(string btnField)
        {
            btnField = btnField.Replace(" ", string.Empty);
            Assert.IsTrue(Browser.Wd.FindElement(By.Id("Btn" + btnField + "")).Displayed);
        }


    }

    //ERF
    [Binding]
    public class EAMERF
    {
        [Then(@"Verify the ""(.*)"" exists in the URL")]
        public void ThenVerifyTheExistsInTheURL(string p0)
        {
            tmsWait.Hard(5);
            Assert.IsTrue(Browser.Wd.Url.Contains(p0));
        }
    }

    [Binding]
    public class AdministrationBEQCMSTransferr
    {
        [When(@"Administration Beqcmstransfer gentran check box is checed")]
        public void WhenAdministrationBeqcmstransferGentranCheckBoxIsCheced()
        {
            fw.ExecuteJavascript(EAM.AdministrationBEQCMSTransfer.Gentranchkbox);
            tmsWait.Hard(2);
        }

        [When(@"Administration Beqcmstransfer enter values ""(.*)"" for all planid")]
        public void WhenAdministrationBeqcmstransferEnterValuesForAllPlanid(int p0)
        {
            IReadOnlyCollection<IWebElement> planrows = EAM.AdministrationBEQCMSTransfer.MappingTable.FindElements(By.TagName("tr"));
            fw.ExecuteJavascript(EAM.AdministrationBEQCMSTransfer.Gentranchkbox);
            int totalplans = planrows.Count;
            int i = 0;
            try
            {
                foreach (var row in planrows)
                {
                    //if (i == 0)
                    //{
                    //    i = 1;
                    //}
                    //else
                    //{
                    IWebElement guid = row.FindElement(By.XPath("(td//input)[1]"));
                    guid.Clear();
                    guid.SendKeys(p0.ToString());
                    tmsWait.Hard(1);
                    IWebElement racfid = row.FindElement(By.XPath("td[3]//input"));
                    racfid.Clear();
                    racfid.SendKeys(p0.ToString());
                    tmsWait.Hard(1);
                    IWebElement eidm = row.FindElement(By.XPath("td[4]//input"));
                    eidm.Clear();
                    eidm.SendKeys("886969");
                    tmsWait.Hard(1);
                    //}
                }
            }
            catch
            {

            }
        }

        [When(@"Administration Beqcmstransfer save button is clicked")]
        public void WhenAdministrationBeqcmstransferSaveButtonIsClicked()
        {
            fw.ExecuteJavascript(EAM.AdministrationBEQCMSTransfer.SaveBtn);
            tmsWait.Hard(1);
        }

        [When(@"Administration Beqcmstransfer save button is clicked and Verify Message ""(.*)""")]
        public void WhenAdministrationBeqcmstransferSaveButtonIsClickedAndVerifyMessage(string p0)
        {
            string Message = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(EAM.AdministrationBEQCMSTransfer.SaveBtn);
            tmsWait.Hard(1);
            IWebElement toastMsg = Browser.Wd.FindElement(By.XPath("//div[@class='toast-message'][contains(.,'" + Message + "')]"));
            bool msgDisplay = toastMsg.Displayed;
            Assert.IsTrue(msgDisplay, " Toaster message is not displayed");
        }


        [When(@"Administration Beqcmstransfer ""(.*)"" Checkbox is Checked")]
        public void WhenAdministrationBeqcmstransferCheckboxIsChecked(string p0)
        {
            string checkbox = tmsCommon.GenerateData(p0);

            switch (p0.ToLower())
            {
                case "connect direct":
                    IWebElement connectdirectchkbox = Browser.Wd.FindElement(By.XPath("//input[@test-id='beqCmsTransfer-radio-connectDirect']"));
                    fw.ExecuteJavascript(connectdirectchkbox);
                    tmsWait.Hard(1);
                    break;
                case "gentran":
                    IWebElement gentranchkbox = Browser.Wd.FindElement(By.XPath("//input[@test-id='beqCmsTransfer-radio-genTran']"));
                    fw.ExecuteJavascript(gentranchkbox);
                    tmsWait.Hard(1);
                    break;
                case "none":
                    IWebElement nonechkbox = Browser.Wd.FindElement(By.XPath("//input[@test-id='beqCmsTransfer-radio-none']"));
                    fw.ExecuteJavascript(nonechkbox);
                    tmsWait.Hard(1);
                    break;
            }
        }

        [Then(@"Verify Administration Beqcmstransfer ""(.*)"" is displays as ""(.*)""")]
        public void ThenVerifyAdministrationBeqcmstransferIsDisplaysAs(string p0, string p1)
        {
            string filetype = tmsCommon.GenerateData(p0);
            string expectedfileformat = tmsCommon.GenerateData(p1);
            string actualfileformat = null;
            switch (filetype.ToLower())
            {
                case "beq file": actualfileformat = Browser.Wd.FindElement(By.XPath("//span[@ng-bind='beqFileFormat']")).GetAttribute("innerText"); break;
                case "cms file": actualfileformat = Browser.Wd.FindElement(By.XPath("//span[@ng-bind='cmsFileFormat']")).GetAttribute("innerText"); break;
            }

            Assert.AreEqual(expectedfileformat, actualfileformat, "Actual file format does not match with the expected file format");
        }

        [Then(@"Verify Administration Beqcmstransfer ""(.*)"" is disabled")]
        public void ThenVerifyAdministrationBeqcmstransferIsDisabled(string p0)
        {
            string field = tmsCommon.GenerateData(p0);

            switch (field.ToLower())
            {
                case "guid":
                    string dis = Browser.Wd.FindElement(By.XPath("//table[@test-id='beqCmsTransfer-table-plans']/tbody/tr[1]/td[2]/input")).GetAttribute("disabled");
                    Assert.IsTrue(bool.Parse(dis), "expected field is not disabled"); break;

                case "racfid":
                    dis = Browser.Wd.FindElement(By.XPath("//table[@test-id='beqCmsTransfer-table-plans']/tbody/tr[1]/td[3]/input")).GetAttribute("disabled");
                    Assert.IsTrue(bool.Parse(dis), "expected field is not disabled");
                    break;
                case "eidm":
                    dis = Browser.Wd.FindElement(By.XPath("//table[@test-id='beqCmsTransfer-table-plans']/tbody/tr[1]/td[4]/input")).GetAttribute("disabled");
                    Assert.IsTrue(bool.Parse(dis), "expected field is not disabled");
                    break;
            }


        }

        [Then(@"Verify Administration Beqcmstransfer ""(.*)"" is enabled")]
        public void ThenVerifyAdministrationBeqcmstransferIsEnabled(string p0)
        {
            string field = tmsCommon.GenerateData(p0);
            string dis = System.String.Empty;

            switch (field.ToLower())
            {
                case "guid":
                    dis = Browser.Wd.FindElement(By.XPath("//table[@test-id='beqCmsTransfer-table-plans']/tbody/tr[1]/td[2]/input")).GetAttribute("disabled");
                    Assert.IsFalse(bool.Parse(dis), "expected field is not enabled");
                    break;
                case "racfid":
                    dis = Browser.Wd.FindElement(By.XPath("//table[@test-id='beqCmsTransfer-table-plans']/tbody/tr[1]/td[3]/input")).GetAttribute("disabled");
                    Assert.IsFalse(bool.Parse(dis), "expected field is not enabled");
                    break;
                case "eidm":
                    dis = Browser.Wd.FindElement(By.XPath("//table[@test-id='beqCmsTransfer-table-plans']/tbody/tr[1]/td[4]/input")).GetAttribute("disabled");
                    Assert.IsFalse(bool.Parse(dis), "expected field is not enabled");
                    break;
            }
        }

        [Then(@"Verify Total records ""(.*)"" is greather than zero")]
        public void ThenVerifyTotalRecordsIsGreatherThanZero(string p0)
        {
            string trecord = tmsCommon.GenerateData(p0);
            int trecord1 = Int32.Parse(trecord);
            bool recordexist = false;
            if (trecord1 > 0)
            {
                recordexist = true;
            }

            Assert.IsTrue(recordexist, "Record does not exist in the database table");
        }



        [Then(@"Verify Administration Manage PlanSCC ViewEdit Table Does Not Have row")]
        public void ThenVerifyAdministrationManagePlanSCCViewEditTableDoesNotHaveRow()
        {
            tmsWait.Hard(2);
            IWebElement objWebTable = EAM.MembersSearch.SearchTabletest;
            IList<IWebElement> tableRowCount = objWebTable.FindElements(By.TagName("tr"));
            int rowCount = tableRowCount.Count;
            Assert.AreEqual(2, rowCount, "Expecting [0] data rows in the table, found [" + rowCount.ToString() + "]");
            Console.WriteLine("Expecting [0] data rows in the table, found [" + rowCount.ToString() + "]");
        }




        [When(@"Administration Manage PlanSCCMapping ViewEdit Table CheckBox is set to ""(.*)"" for row")]
        public void WhenAdministrationManagePlanSCCViewEditTableCheckBoxIsChcekedForRow(string p0, Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.MembersSearch.SearchTabletest;
                IWebElement checkboxIcon = objWebTable.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_grid_ctl03_deleteCheckbox"));
                checkboxIcon.Click();
                Console.WriteLine("Checkbox icon was clicked");
            }
            catch (Exception e)
            {
                Assert.Fail("Checkbox icon is clicked for row: {0}", e.Message);
            }
        }


        [Then(@"Verify Administration Beqcmstransafer static message ""(.*)""")]
        public void ThenVerifyAdministrationBeqcmstransaferStaticMessage(string p0)
        {
            Assert.AreEqual(EAM.AdministrationBEQCMSTransfer.staticmessag.Text, p0, "Data Not saved successfully");
        }

        [When(@"I have navigated to EAM page ""(.*)""")]
        public void WhenIHaveNavigatedToEAMPage(string p0)
        {
            tmsWait.Hard(10);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@title='" + p0 + "']")));
            GlobalRef.ReportName = "Reports";
        }

        [Then(@"Verify the AuditConfiguration Warning Note ""(.*)""")]
        public void ThenVerifyTheAuditConfigurationWarningNote(string p0)
        {
            Assert.AreEqual(Browser.Wd.FindElement(By.XPath("//span[contains(.,'Warning')]")).Text, p0, "Warning note is not displayed");
        }

        [Then(@"Verify the AuditConfiguration Note ""(.*)""")]
        public void ThenVerifyTheAuditConfigurationNote(string p0)
        {
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[contains(.,'Warehouse')]")).Text.Contains(p0), "Warning note is not displayed");
        }
        [Then(@"Verify Audit Configuration Page Message ""(.*)"" is displayed")]
        public void ThenVerifyAuditConfigurationPageMessageIsDisplayed(string p0)
        {
            String msg = p0 + " " + ReUsableFunctions.getCurrentURLandReplaceAWord(1, '.', "app", "sql");

            ReUsableFunctions.ErrorMessageDisplay(msg);
        }

        [When(@"Audit Configuration AllActivity switch is ""(.*)""")]
        public void WhenAuditConfigurationAllActivitySwitchIs(string p0)
        {
            tmsWait.Hard(3);
            //string switchChk = Browser.Wd.FindElement(By.XPath("//kendo-switch[@test-id='auditConfig-input-switchAll']//span[@role='switch']")).GetAttribute("aria-checked");
              string switchChk = Browser.Wd.FindElement(By.XPath("//kendo-switch[@test-id='auditConfig-input-all']//span[@role='switch']")).GetAttribute("aria-checked");

            
            switch (p0.ToLower())
            {
                case "on":

                    if (switchChk.Contains("false"))
                    {
                        Browser.Wd.FindElement(By.XPath("//kendo-switch[@test-id='auditConfig-input-all']//span[@class='k-switch-handle']")).Click();
                    }
                    break;
                case "off":
                    if (switchChk.Contains("true"))
                    {
                        Browser.Wd.FindElement(By.XPath("//kendo-switch[@test-id='auditConfig-input-all']//span[@class='k-switch-handle']")).Click();
                    }
                    break;
            }
            tmsWait.Hard(2);
        }

        [Then(@"Verify EAM EAF Fallout Configuration Resolution  Timeline section has correct data in table")]
        public void ThenVerifyEAMEAFFalloutConfigurationResolutionTimelineSectionHasCorrectDataInTable()
        {



            IList<IWebElement> TransCodeRow = Browser.Wd.FindElements(By.XPath("//div[@test-id='resolutionTimeline-Grid']//tbody/tr/td[2]/span"));
            IList<string> text = TMSoR1.FrameworkCode.HCC_RAM.OnHoldFunctionality.ConvertWebElementInToStringg(TransCodeRow);
            IList<string> TransCode = new List<string>() { "61", "51", "72", "73", "74", "75", "76", "77", "78", "79", "80", "81", "00" };
            bool flag = true;
            foreach (string t in TransCode)
            {
                if (!text.Contains(t))
                {
                    flag = false;
                    break;
                }
            }
            Assert.IsTrue(flag);
            bool flag1 = true;
            IList<IWebElement> enable = Browser.Wd.FindElements(By.XPath("//div[@test-id='resolutionTimeline-Grid']//tbody/tr/td[4]//input[@data-role='switch']"));

            foreach (IWebElement t in enable)
            {
                if (!(t.Enabled))
                {
                    flag1 = true;
                }
                else
                {
                    flag1 = false;
                    break;
                }

            }
            Assert.IsTrue(flag1);
            IList<IWebElement> edit = Browser.Wd.FindElements(By.XPath("//div[@test-id='resolutionTimeline-Grid']//tbody/tr/td[5]/a[contains(@class,'edit')]"));
            Assert.IsTrue(edit.Count.Equals(TransCode.Count));

        }
        [When(@"EAM EAF Fallout Configuration Resolution Timeline section new ""(.*)"" is set to ""(.*)""")]
        public void WhenEAMEAFFalloutConfigurationResolutionTimelineSectionNewIsSetTo(string p0, string p1)
        {

            IWebElement textboc = Browser.Wd.FindElement(By.XPath("(//input[@id='timeLine'])[1]"));
            tmsWait.Hard(2);
            fw.ExecuteJavascript(textboc);
            //textboc.SendKeys(Keys.End);
            textboc.SendKeys(Keys.Control + "a");
            tmsWait.Hard(2);
            textboc.Clear();
            fw.ExecuteJavascriptSetText(textboc, "");
            textboc.SendKeys("07.1");
            
            tmsWait.Hard(2); ;
            fw.ExecuteJavascript(textboc);

            //fw.ExecuteJavascriptSetTextnew(textboc, "");
            tmsWait.Hard(2);
            //fw.ExecuteJavascriptSetText(textboc, p1.ToString());


            // fw.ExecuteJavascript(textboc);
            textboc.Clear();
            //String b = Keys.Delete;
            //textboc.SendKeys(b + b + b + b + b + b + b + b + b + b );
            //  fw.ExecuteJavascriptSetTextnew(textboc,"7.1");
            // tmsWait.Hard(2);
            //fw.ExecuteJavascriptSetText(textboc, p1.ToString());
            // fw.ExecuteJavascript(textboc);
            textboc.SendKeys("07.1");
            textboc.SendKeys(Keys.Tab);
            tmsWait.Hard(2);

        }

        [When(@"EAM EAF Fallout Configuration Resolution  Timeline section ""(.*)""is set to ""(.*)""")]
        public void WhenEAMEAFFalloutConfigurationResolutionTimelineSectionIsSetTo(string p0, string p1)
        {
            IWebElement textboc = Browser.Wd.FindElement(By.XPath("//input[@type='text'][1]"));

            GlobalRef.ResolutionTimeline = textboc.GetAttribute("title");
            tmsWait.Hard(2); ;
            fw.ExecuteJavascript(textboc);
            tmsWait.Hard(2);
            // String b = Keys.Delete;
            // textboc.SendKeys(b + b + b + b + b + b + b + b + b + b );
            fw.ExecuteJavascriptSetText(textboc, "");
            tmsWait.Hard(2);
            fw.ExecuteJavascriptSetText(textboc, p1.ToString());
            // fw.ExecuteJavascript(textboc);
            //textboc.SendKeys(Keys.Tab);
            tmsWait.Hard(2);

            //textboc.Clear();
            //textboc.Click();
            // tmsWait.Hard(2);
            textboc.SendKeys(p1.ToString());
            textboc.SendKeys(Keys.Tab);
            //fw.ExecuteJavascriptSetText(textboc, p1.ToString());

        }

        [When(@"EAM EAF Fallout Configuration Resolution Timeline section Enable is set to ""(.*)""")]
        public void WhenEAMEAFFalloutConfigurationResolutionTimelineSectionEnableIsSetTo(string p0)
        {
            try
            {
                IWebElement edit = Browser.Wd.FindElement(By.XPath("//td[contains(.,'61')]/following-sibling::td//span[contains(@class,'switch-on')]/span[2]"));
                if (p0.ToLower().Equals("off"))
                {
                    fw.ExecuteJavascript(edit);
                    edit.Click();
                    ;
                }
            }
            catch
            {
                IWebElement edit = Browser.Wd.FindElement(By.XPath("//td[contains(.,'61')]/following-sibling::td//span[contains(@class,'switch-off')]/span[2]"));
                if (p0.ToLower().Equals("on"))
                {
                    edit.Click();
                }
            }


        }

        [Then(@"EAM EAF Fallout Configuration Resolution  Timeline section ""(.*)"" button is clicked for Transaction code ""(.*)""")]
        public void ThenEAMEAFFalloutConfigurationResolutionTimelineSectionButtonIsClickedForTransactionCode(string p0, string p1)
        {
            switch (p0.ToLower())
            {
                case "edit":
                    IWebElement edit = Browser.Wd.FindElement(By.XPath("//*[@id='resolutionTimelineGrid']/div/kendo-grid-list/div/div[1]/table/tbody/tr/td[contains(text(),'" + p1 + "')]/following-sibling::td[3]/button[1]/span"));
                    tmsWait.Hard(2);
                    edit.Click();
                    //fw.ExecuteJavascript(edit);
                    tmsWait.Hard(2);
                    break;

                case "cancel":
                    IWebElement cancel = Browser.Wd.FindElement(By.XPath("//*[@id='resolutionTimelineGrid']/div/kendo-grid-list/div/div[1]/table/tbody/tr/td[contains(text(),'" + p1 + "')]/following-sibling::td[3]/button[3]"));
                    //WFDashboard.
                    cancel.Click();
                    //fw.ExecuteJavascript(cancel);
                    tmsWait.Hard(2);
                    break;


                case "update":
                    IWebElement update = Browser.Wd.FindElement(By.XPath("//*[@id='resolutionTimelineGrid']/div/kendo-grid-list/div/div[1]/table/tbody/tr/td[contains(text(),'" + p1 + "')]/following-sibling::td[3]/button[2]"));


                    update.Click();
                    tmsWait.Hard(2);
                    break;
                case "save":
                    IWebElement Save = Browser.Wd.FindElement(By.XPath("//*[@id='resolutionTimelineGrid']/div/kendo-grid-list/div/div[1]/table/tbody/tr/td[contains(text(),'" + p1 + "')]/following-sibling::td[3]/button[2]"));
                    fw.ExecuteJavascript(Save);

                    //Save.Click();
                    tmsWait.Hard(2);
                    break;

            }


        }
        [Then(@"EAM EAF Fallout Configuration Resolution Timeline section Link ""(.*)"" is clicked")]
        public void ThenEAMEAFFalloutConfigurationResolutionTimelineSectionLinkIsClicked(string p0)
        {
            IWebElement AuditHistory = Browser.Wd.FindElement(By.XPath("//a[@test-id='resolutionTimeline-a-auditHistory']"));

            AuditHistory.Click();
        }
        [Then(@"Verify EAM EAF Fallout Configuration Resolution Timeline section link ""(.*)"" page has row for TransactionCode as ""(.*)"" area as ""(.*)"" ChangedFrom as ""(.*)"" Changedto ""(.*)""")]
        public void ThenVerifyEAMEAFFalloutConfigurationResolutionTimelineSectionLinkPageHasRowForTransactionCodeAsAreaAsChangedFromAsChangedto(string p0, string p1, string p2, string p3, string p4)
        {
            String date = DateTime.Now.ToString("M/d/yyyy");
            //String date1 = string.Format("{0:M/d/yyyy}", date);
            String audihis = "//span[contains(.,'" + p1 + "')]/parent::td/following-sibling::td[contains(text(),'" + p2 + "')]/following-sibling::td/p[contains(text(),'" + p3 + "')]/parent::td/following-sibling::td/p[contains(text(),'" + p4 + "')]/parent::td/following-sibling::td[contains(text(),'" + date + "')]";
            // String audihi1s = "//span[contains(.,'61')]/parent::td/following-sibling::td[contains(text(),'Is Audit Enabled')]/following-sibling::td/p[contains(text(),'True')]/parent::td/following-sibling::td/p[contains(text(),'False')]/parent::td/following-sibling::td[contains(text(),'7/14/2020')]";
            IWebElement AuditHistoryrow = Browser.Wd.FindElement(By.XPath(audihis));
            Assert.IsTrue(AuditHistoryrow.Displayed, "AuditHistoryrow is not displayed");
        }

        [Then(@"Verify EAM EAF Fallout Configuration Resolution Timeline section link ""(.*)"" page UI")]
        public void ThenVerifyEAMEAFFalloutConfigurationResolutionTimelineSectionLinkPageUI(string p0)
        {

            IList<IWebElement> AuditHistoryheader = Browser.Wd.FindElements(By.XPath("//div[@id='auditMembersListGrid']//tr/th/span"));
            //Assert.IsTrue(AuditHistory.Displayed, "AuditHistory is not displayed");

            // IList<IWebElement> header = Browser.Wd.FindElements(By.XPath("//div[@id='resolutionTimelineGrid']//th"));
            IList<string> text = TMSoR1.FrameworkCode.HCC_RAM.OnHoldFunctionality.ConvertWebElementInToStringg(AuditHistoryheader);
            IList<string> stringlis = new List<string>() { "Transaction Code", "Area", "Changed From", "Changed To", "Changed By", "Changed At" };
            bool flag = true;
            foreach (string t in stringlis)
            {
                if (!text.Contains(t))
                {
                    flag = false;
                    break;
                }
            }

            Assert.IsTrue(flag);
            IWebElement close = Browser.Wd.FindElement(By.XPath("//*[@id='btnCancel'']"));
            Assert.IsTrue(close.Displayed);

        }

        [Then(@"Verify EAM EAF Fallout Configuration Resolution  Timeline section column ""(.*)"" has value ""(.*)"" for Transaction code ""(.*)""")]
        public void ThenVerifyEAMEAFFalloutConfigurationResolutionTimelineSectionColumnHasValueForTransactionCode(string p0, string p1, int p2)
        {


            string value = Browser.Wd.FindElement(By.XPath("//*[@id='resolutionTimelineGrid']/div/kendo-grid-list/div/div[1]/table/tbody/tr/td[contains(text(),'" + p2 + "')]/following-sibling::td[1]")).Text;
            Assert.IsTrue(value.Equals(p1.ToString()));

        }
        [Then(@"Verify EAM EAF Fallout Configuration Resolution  Timeline section column ""(.*)"" has value not changed for Transaction code ""(.*)""")]
        public void ThenVerifyEAMEAFFalloutConfigurationResolutionTimelineSectionColumnHasValueNotChangedForTransactionCode(string p0, int p1)
        {
            string oldvalue = GlobalRef.ResolutionTimeline.ToString();

            string value = Browser.Wd.FindElement(By.XPath("//span[contains(text(),'" + p1 + "')]/parent::td/following-sibling::td[1]")).Text;
            Assert.IsTrue(value.Equals(oldvalue));
        }


        [Then(@"Verify EAM EAF Fallout Configuration Resolution  Timeline section column ""(.*)"" is not accepting alphanumberic value")]
        public void ThenVerifyEAMEAFFalloutConfigurationResolutionTimelineSectionColumnIsNotAcceptingAlphanumbericValue(string p0)
        {
            IWebElement textboc = Browser.Wd.FindElement(By.XPath("//input[@type='text'][1]"));
            tmsWait.Hard(2);
            fw.ExecuteJavascript(textboc);
            tmsWait.Hard(2);
            fw.ExecuteJavascriptSetText(textboc, "");
            tmsWait.Hard(2);
            ////textboc.Clear();
            fw.ExecuteJavascriptSetText(textboc, "@@@@");
            textboc.SendKeys(Keys.Tab);
            //fw.ExecuteJavascriptSetText(textboc, "9");
            string value = Browser.Wd.FindElement(By.XPath("//span[contains(text(),'61')]/parent::td/following-sibling::td[1]")).Text;
            Assert.IsFalse(value.Equals("@@@@"));


        }
        [Then(@"Verify EAM EAF Fallout Configuration Resolution  Timeline section button ""(.*)"" functionalty")]
        public void ThenVerifyEAMEAFFalloutConfigurationResolutionTimelineSectionButtonFunctionalty(string p0)
        {

        }

        [Then(@"Verify EAM EAF Fallout Configuration Resolution  Timeline section ""(.*)"" and ""(.*)"" button are Displayed")]
        public void ThenVerifyEAMEAFFalloutConfigurationResolutionTimelineSectionAndButtonAreDisplayed(string p0, string p1)
        {
            IWebElement cancel = Browser.Wd.FindElement(By.XPath("//a[contains(@class,'cancel')]/parent::td/preceding-sibling::td/span[contains(.,'61')]"));


            Assert.IsTrue(cancel.Displayed);
            IWebElement update = Browser.Wd.FindElement(By.XPath("//a[contains(@class,'update')]/parent::td/preceding-sibling::td/span[contains(.,'61')]"));


            Assert.IsTrue(update.Displayed);
            tmsWait.Hard(2);
            // update.Click();
            tmsWait.Hard(2);






        }
        [Then(@"Verify EAM ""(.*)"" section has header and Valid UI Elements")]
        public void ThenVerifyEAMSectionHasHeaderAndValidUIElements(string p0)
        {


            // IWebElement AuditHistory = Browser.Wd.FindElement(By.XPath("//a[@test-id='resolutionTimeline-a-auditHistory']"));
            //Assert.IsTrue(AuditHistory.Displayed, "AuditHistory is not displayed");

            IList<IWebElement> header = Browser.Wd.FindElements(By.XPath("//div[@id='transactionReviewQueueGrid']//th[1]/following-sibling::th"));
            IList<string> text = TMSoR1.FrameworkCode.HCC_RAM.OnHoldFunctionality.ConvertWebElementInToStringg(header);
            IList<string> stringlis = new List<string>() { "Transaction ID", "Category", "Action", "Date Created", "User Created", "Date Due", "Date Completed", "Complete" };
            bool flag = true;
            foreach (string t in stringlis)
            {
                if (!text.Contains(t))
                {
                    flag = false;
                    break;
                }
            }
            Assert.IsTrue(flag);

        }


        [Then(@"Verify EAM EAF Fallout Configuration Resolution  Timeline section has header and Audit history link")]
        public void ThenVerifyEAMEAFFalloutConfigurationResolutionTimelineSectionHasHeaderAndAuditHistoryLink()
        {


            IWebElement AuditHistory = Browser.Wd.FindElement(By.XPath("//a[@test-id='resolutionTimeline-a-auditHistory']"));
            Assert.IsTrue(AuditHistory.Displayed, "AuditHistory is not displayed");

            IList<IWebElement> header = Browser.Wd.FindElements(By.XPath("//div[@id='resolutionTimelineGrid']//th"));
            IList<string> text = TMSoR1.FrameworkCode.HCC_RAM.OnHoldFunctionality.ConvertWebElementInToStringg(header);
            IList<string> stringlis = new List<string>() { "Transaction Codes", "Resolution Timeline (In Days)", "Enable", "Edit" };
            bool flag = true;
            foreach (string t in stringlis)
            {
                if (!text.Contains(t))
                {
                    flag = false;
                    break;
                }
            }
            Assert.IsTrue(flag);
        }

        [Then(@"Verify Audit Configuration ""(.*)"" activity is set to ""(.*)""")]
        public void ThenVerifyAuditConfigurationActivityIsSetTo(string p0, string p1)
        {
            switch (p0.ToLower())
            {
                case "member":
                    if (p1.ToLower() == "yes")
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[text()='Member']/following::span[1]/span[@class='k-switch-label-on']")).Displayed);
                    }
                    else
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[text()='Member']/following::span[1]/span[@class='k-switch-label-off']")).Displayed);
                    }
                    break;

                case "transaction":
                    if (p1.ToLower() == "yes")
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[text()='Transaction']/following::span[1]/span[@class='k-switch-label-on']")).Displayed);
                    }
                    else
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[text()='Transaction']/following::span[1]/span[@class='k-switch-label-off']")).Displayed);
                    }
                    break;

                case "lis":
                    if (p1.ToLower() == "yes")
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-label-on km-switch-label-on'])[4]")).Displayed);
                    }
                    else
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-label-off km-switch-label-off'])[4]")).Displayed);
                    }
                    break;

                case "notes/actions":
                    if (p1.ToLower() == "yes")
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-label-on km-switch-label-on'])[5]")).Displayed);
                    }
                    else
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-label-off km-switch-label-off'])[5]")).Displayed);
                    }
                    break;

                case "member ooa process":
                    if (p1.ToLower() == "yes")
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-label-on km-switch-label-on'])[6]")).Displayed);
                    }
                    else
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-label-off km-switch-label-off'])[6]")).Displayed);
                    }
                    break;

                case "oev letter configuration":
                    if (p1.ToLower() == "yes")
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-label-on km-switch-label-on'])[7]")).Displayed);
                    }
                    else
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-label-off km-switch-label-off'])[7]")).Displayed);
                    }
                    break;

                case "snp configuration":
                    if (p1.ToLower() == "yes")
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-label-on km-switch-label-on'])[8]")).Displayed);
                    }
                    else
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-label-off km-switch-label-off'])[8]")).Displayed);
                    }
                    break;

                case "osb configuration":
                    if (p1.ToLower() == "yes")
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-label-on km-switch-label-on'])[9]")).Displayed);
                    }
                    else
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-label-off km-switch-label-off'])[9]")).Displayed);
                    }
                    break;

                case "member snp follow up process":
                    if (p1.ToLower() == "yes")
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-label-on km-switch-label-on'])[10]")).Displayed);
                    }
                    else
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-label-off km-switch-label-off'])[10]")).Displayed);
                    }
                    break;

                case "spans":
                    if (p1.ToLower() == "yes")
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-label-on km-switch-label-on'])[11]")).Displayed);
                    }
                    else
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-label-off km-switch-label-off'])[11]")).Displayed);
                    }
                    break;

                case "trractionconfiguration":
                    if (p1.ToLower() == "yes")
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-label-on km-switch-label-on'])[12]")).Displayed);
                    }
                    else
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-label-off km-switch-label-off'])[12]")).Displayed);
                    }
                    break;

                case "trrupdatefieldconfiguration":
                    if (p1.ToLower() == "yes")
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-label-on km-switch-label-on'])[13]")).Displayed);
                    }
                    else
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-label-off km-switch-label-off'])[13]")).Displayed);
                    }
                    break;

                case "beq on hold":
                    if (p1.ToLower() == "yes")
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-label-on km-switch-label-on'])[14]")).Displayed);
                    }
                    else
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-label-off km-switch-label-off'])[14]")).Displayed);
                    }
                    break;

                case "facets mapping":
                    if (p1.ToLower() == "yes")
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-label-on km-switch-label-on'])[15]")).Displayed);
                    }
                    else
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-label-off km-switch-label-off'])[15]")).Displayed);
                    }
                    break;

                case "eaf Fallout":
                    if (p1.ToLower() == "yes")
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-label-on km-switch-label-on'])[16]")).Displayed);
                    }
                    else
                    {
                        Assert.IsTrue(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-label-off km-switch-label-off'])[16]")).Displayed);
                    }
                    break;
            }
        }

        [When(@"AuditConfiguration page Save button is clicked")]
        public void WhenAuditConfigurationPageSaveButtonIsClicked()
        {
            IWebElement saveButton = Browser.Wd.FindElement(By.XPath("//*[@test-id='auditConfig-btn-save']"));
            fw.ExecuteJavascript(saveButton);
            tmsWait.Hard(2);
        }

        [Then(@"Verify EAM Message ""(.*)""")]
        public void ThenVerifyEAMMessage(string p0)
        {
            tmsWait.Hard(2);
            IWebElement toaster = Browser.Wd.FindElement(By.XPath("//div[@class='toast-message'][contains(.,'" + p0 + "')]"));
            Assert.IsTrue(toaster.Displayed, "Expected Toaster message is not getting displayed");
        }




    }
}
