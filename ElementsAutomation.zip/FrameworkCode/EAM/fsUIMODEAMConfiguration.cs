﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
//using System.Windows.Forms;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.EAM
{
    [Binding]
    class fsUIMODEAMConfiguration
    {
        [Given(@"EAM Configuration page ""(.*)"" link is clicked")]
        [When(@"EAM Configuration page ""(.*)"" link is clicked")]
        [Then(@"EAM Configuration page ""(.*)"" link is clicked")]
        
        public void WhenEAMConfigurationPageLinkIsClicked(string p0)
        {
            IWebElement LinkName;

             string submenu = tmsCommon.GenerateData(p0);
            if(ConfigFile.tenantType.Equals("tmsx")){ 
             LinkName = Browser.Wd.FindElement(By.XPath("//*[@test-id='eamConfigurations-li-eamConfigurationsList']/label[contains(.,'" + submenu + "')]"));

            }
            else
            {
                LinkName = Browser.Wd.FindElement(By.XPath("//li[@test-id='eamConfigurations-li-eamConfigurationsList']/label[contains(.,'" + submenu + "')]"));

            }
            fw.ExecuteJavascript(LinkName);
            tmsWait.Hard(3);
        }

        [When(@"EAM Configuration page Legacy Export section Configuration is ""(.*)""")]
        public void WhenEAMConfigurationPageLegacyExportSectionConfiguration(string p0)
        {
            string config_button = tmsCommon.GenerateData(p0);

            string current_Config = Browser.Wd.FindElement(By.XPath("//input[@test-id='legacyExport-input-changeLegacyExport']")).GetAttribute("value");
            IWebElement switch_Point = Browser.Wd.FindElement(By.XPath("//span[@class='k-switch-handle km-switch-handle']"));
            switch(config_button.ToLower())
            {
                case "off": if(current_Config=="true")
                    {
                        switch_Point.Click();
                        tmsWait.Hard(3);
                    }
                    
                    break;

                case "on": if(current_Config=="false")
                    {
                        switch_Point.Click();
                    }
                    break;
            }
        }


        [When(@"Verify EAM configuration page Language section ""(.*)"" is displayed")]
        public void WhenVerifyEAMConfigurationPageLanguageSectionIsDisplayed(string p0)
        {
            string field = tmsCommon.GenerateData(p0);
            bool present = false;
            present = Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + field + "')]")).Displayed;

            Assert.IsTrue(present);
        }
        [When(@"Verify EAM configuration page Relationship section ""(.*)"" is displayed")]
        public void WhenVerifyEAMConfigurationPageRelationshipSectionIsDisplayed(string p0)
        {
            string field = tmsCommon.GenerateData(p0);
            bool present = false;
            present = Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + field + "')]")).Displayed;

            Assert.IsTrue(present);
        }
        [When(@"Verify EAM configuration page Sales Representative section ""(.*)"" is displayed")]
        public void WhenVerifyEAMConfigurationPageSalesRepresentativeSectionIsDisplayed(string p0)
        {
            string field = tmsCommon.GenerateData(p0);
            bool present = false;
            present = Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + field + "')]")).Displayed;

            Assert.IsTrue(present);
        }


        [When(@"Verify EAM configuration page Disenrollment section ""(.*)"" is displayed")]
        public void WhenVerifyEAMConfigurationPageDisenrollmentSectionIsDisplayed(string p0)
        {
            
            string field = tmsCommon.GenerateData(p0);
            bool present = false;
            present = Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + field + "')]")).Displayed;

            Assert.IsTrue(present);
          
        }
        [When(@"Verify EAM configuration page Language section button ""(.*)"" is displayed")]
        public void WhenVerifyEAMConfigurationPageLanguageSectionButtonIsDisplayed(string p0)
        {
            string field = tmsCommon.GenerateData(p0);
            bool present = false;
            present = Browser.Wd.FindElement(By.XPath("//button[contains(.,'" + field + "')]")).Displayed;

            Assert.IsTrue(present);
        }
        [When(@"Verify EAM configuration page Relationship section button ""(.*)"" is displayed")]
        public void WhenVerifyEAMConfigurationPageRelationshipSectionButtonIsDisplayed(string p0)
        {
            string field = tmsCommon.GenerateData(p0);
            bool present = false;
            present = Browser.Wd.FindElement(By.XPath("//button[contains(.,'" + field + "')]")).Displayed;

            Assert.IsTrue(present);
        }
        [When(@"Verify EAM configuration page Sales Representative section button ""(.*)"" is displayed")]
        public void WhenVerifyEAMConfigurationPageSalesRepresentativeSectionButtonIsDisplayed(string p0)
        {
            string field = tmsCommon.GenerateData(p0);
            bool present = false;
            present = Browser.Wd.FindElement(By.XPath("//button[contains(.,'" + field + "')]")).Displayed;

            Assert.IsTrue(present);
        }


        [When(@"Verify EAM configuration page Disenrollment section button ""(.*)"" is displayed")]
        public void WhenVerifyEAMConfigurationPageDisenrollmentSectionButtonIsDisplayed(string p0)
        {

            string field = tmsCommon.GenerateData(p0);
            bool present = false;
            present = Browser.Wd.FindElement(By.XPath("//button[contains(.,'" + field + "')]")).Displayed;

            Assert.IsTrue(present);
        }
        [When(@"Verify EAM configuration page Relationship section info icon ""(.*)"" is displayed")]
        public void WhenVerifyEAMConfigurationPageRelationshipSectionInfoIconIsDisplayed(string p0)
        {
            string field = tmsCommon.GenerateData(p0);
            bool present = false;
            present = Browser.Wd.FindElement(By.XPath("//i[@test-id='relationship-tooltip-relationshipTooltip']")).Displayed;

            Assert.IsTrue(present);
        }
        [When(@"Verify EAM configuration page Sales Representative section info icon ""(.*)"" is displayed")]
        public void WhenVerifyEAMConfigurationPageSalesRepresentativeSectionInfoIconIsDisplayed(string p0)
        {
            string field = tmsCommon.GenerateData(p0);
            bool present = false;
            present = Browser.Wd.FindElement(By.XPath("//i[@test-id='language-icon-tooltip']")).Displayed;

            Assert.IsTrue(present);
        }


        [When(@"Verify EAM configuration page Language section info icon ""(.*)"" is displayed")]
        public void WhenVerifyEAMConfigurationPageLanguageSectionInfoIconIsDisplayed(string p0)
        {
            string field = tmsCommon.GenerateData(p0);
            bool present = false;
            present = Browser.Wd.FindElement(By.XPath("//i[@test-id='language-icon-tooltip']")).Displayed;

            Assert.IsTrue(present);
        }

        [When(@"Verify EAM configuration page Disenrollment section info icon ""(.*)"" is displayed")]
        public void WhenVerifyEAMConfigurationPageDisenrollmentSectionInfoIconIsDisplayed(string p0)
        {
            string field = tmsCommon.GenerateData(p0);
            bool present = false;
            present = Browser.Wd.FindElement(By.XPath("//i[@test-id='language-icon-tooltip']")).Displayed;

            Assert.IsTrue(present);
        }

        [When(@"EAM configuration page Disenrollment section info icon ""(.*)"" is clicked and verify msg ""(.*)""")]
        public void WhenEAMConfigurationPageDisenrollmentSectionInfoIconIsClickedAndVerifyMsg(string p0, string p1)
        {
            string msg = tmsCommon.GenerateData(p1);
            Browser.Wd.FindElement(By.XPath("//i[@test-id='disenrollmentReasons-lbl-disenrollmentReasonsTooltip']")).Click();
            bool present = false;
            present = Browser.Wd.FindElement(By.XPath("//div[contains(.,'" + msg + "')]")).Displayed;

            Assert.IsTrue(present);
        }
        [When(@"EAM configuration page Language section info icon ""(.*)"" is clicked and verify msg ""(.*)""")]
        public void WhenEAMConfigurationPageLanguageSectionInfoIconIsClickedAndVerifyMsg(string p0, string p1)
        {
            string msg = tmsCommon.GenerateData(p1);
            Browser.Wd.FindElement(By.XPath("//i[@test-id='language-tooltip-languageTooltip']")).Click();
            bool present = false;
            present = Browser.Wd.FindElement(By.XPath("//div[contains(.,'" + msg + "')]")).Displayed;

            Assert.IsTrue(present);
        }
        [When(@"EAM configuration page Relationship section info icon ""(.*)"" is clicked and verify msg ""(.*)""")]
        public void WhenEAMConfigurationPageRelationshipSectionInfoIconIsClickedAndVerifyMsg(string p0, string p1)
        {
            string msg = tmsCommon.GenerateData(p1);
            Browser.Wd.FindElement(By.XPath("//i[@test-id='relationship-tooltip-relationshipTooltip']")).Click();
            bool present = false;
            present = Browser.Wd.FindElement(By.XPath("//div[contains(.,'" + msg + "')]")).Displayed;

            Assert.IsTrue(present);
        }
        [When(@"EAM configuration page Sales Representative section info icon ""(.*)"" is clicked and verify msg ""(.*)""")]
        public void WhenEAMConfigurationPageSalesRepresentativeSectionInfoIconIsClickedAndVerifyMsg(string p0, string p1)
        {
            string msg = tmsCommon.GenerateData(p1);
            Browser.Wd.FindElement(By.XPath("//i[@test-id='salesRepresentative-tooltip-SalesRepresentativeTooltip']")).Click();
            bool present = false;
            present = Browser.Wd.FindElement(By.XPath("//div[contains(.,'" + msg + "')]")).Displayed;

            Assert.IsTrue(present);
        }


        [When(@"EAM Configuration page ""(.*)"" Button is clicked Also Verify message ""(.*)"" is displayed")]
        public void WhenEAMConfigurationPageButtonIsClickedAlsoVerifyMessageIsDisplayed(string p0, string p1)
        {
            string msg = tmsCommon.GenerateData(p1);
            IWebElement updateButton = Browser.Wd.FindElement(By.XPath("//button[@test-id='planStarStatus-btn-updatePlanStarStatus']"));
            fw.ExecuteJavascript(updateButton);
            tmsWait.Hard(3);
            IWebElement warning = Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']"));
            warning.Click();
           string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).GetAttribute("aria-label"); //Toaster message validation is too unreliable at this time
            tmsWait.Hard(1);
            Assert.IsTrue(actualValue.Contains(msg));

        }

        [When(@"EAM Configuration page PDD Config section ""(.*)"" Component is updated to ""(.*)""")]
        public void WhenEAMConfigurationPagePDDConfigSectionComponentIsUpdatedTo(string p0, string p1)
        {
            tmsWait.Hard(3);
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            By Drp;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                switch (field.ToLower())
                {
                    case "report month":
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.PDDDConfiguration.UpdateReportMonth, value);
                        tmsWait.Hard(5);
                        break;
                    case "file due date":
                        tmsWait.Hard(3);
                        Drp = By.XPath("//kendo-datepicker[@id='pdddFileDueDate']//span[@role='button']");
                        //Reseting to Todays date 
                        AngularFunction.enterTodayAsDate(Drp);
                        tmsWait.Hard(3);
                        //Entering desired date 
                        AngularFunction.enterDate(Drp,value);
                        tmsWait.Hard(5);
                        break;
                    case "plan due date":
                        Drp = By.XPath("//kendo-datepicker[@id='pdddPlanDueDate']//span[@role='button']");
                        AngularFunction.enterDate(Drp, value);
                        tmsWait.Hard(1);
                        break;
                    case "file message":
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.PDDDConfiguration.UpdateFileMessageAngJS, value);
                        cfUIMODEAMConfiguration.PDDDConfiguration.UpdateFileMessageAngJS.SendKeys(Keys.Tab);
                        tmsWait.Hard(5);
                        break;
                    case "plan message":
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.PDDDConfiguration.UpdatePlanMessageAngJS, value);
                        tmsWait.Hard(5);
                        break;
                }

            }

            else { 
            switch (field.ToLower())
            {
                case "report month":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.PDDDConfiguration.UpdateReportMonth, value);
                    break;
                case "file due date":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.PDDDConfiguration.UpdateFileDueDate, value);
                    cfUIMODEAMConfiguration.PDDDConfiguration.UpdateFileDueDate.SendKeys(Keys.Tab);
                    tmsWait.Hard(1);
                    break;
                case "plan due date":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.PDDDConfiguration.UpdatePlanDueDate, value);
                    cfUIMODEAMConfiguration.PDDDConfiguration.UpdateFileDueDate.SendKeys(Keys.Tab);
                    tmsWait.Hard(1);
                    break;
                case "file message":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.PDDDConfiguration.UpdateFileMessage, value);
                    cfUIMODEAMConfiguration.PDDDConfiguration.UpdateFileMessage.SendKeys(Keys.Tab);
                    tmsWait.Hard(2);
                    break;
                case "plan message":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.PDDDConfiguration.UpdatePlanMessage, value);
                    break;
            }

            }

        }


        [When(@"EAM Configuration page PDD Config section ""(.*)"" Component is set to ""(.*)""")]
        public void WhenEAMConfigurationPagePDDConfigSectionComponentIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = null;
                switch (field.ToLower())
                {
                    case "report month":
                        //kendo-datepicker[@test-id='pdddConfiguration-date-reportMonth']//input
                        value = value.Replace("/", "");
                         Drp = By.XPath("//kendo-datepicker[@test-id='pdddConfiguration-date-reportMonth']//input");
                        Browser.Wd.FindElement(Drp).Clear();

                        Browser.Wd.FindElement(Drp).SendKeys(value);

                        tmsWait.Hard(3);
                       // ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.PDDDConfiguration.ReportMonthDate, value);
                        break;
                    case "file due date":
                        value = value.Replace("/", "");
                         Drp = By.XPath("//kendo-datepicker[@test-id='pdddConfiguration-date-fileDueDate']//input");
                        Browser.Wd.FindElement(Drp).Clear();

                        Browser.Wd.FindElement(Drp).SendKeys(value);

                        tmsWait.Hard(3);

                        //kendo-datepicker[@test-id='pdddConfiguration-date-fileDueDate']//input
                      //  ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.PDDDConfiguration.FileDueDate, value);
                        break;
                    case "plan due date":

                        value = value.Replace("/", "");
                        Drp = By.XPath("//kendo-datepicker[@test-id='pdddConfiguration-date-planDueDate']//input");
                        Browser.Wd.FindElement(Drp).Clear();

                        Browser.Wd.FindElement(Drp).SendKeys(value);

                        tmsWait.Hard(3);

                      //  ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.PDDDConfiguration.PlanDueDate, value);
                        break;
                    case "file message":
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.PDDDConfiguration.AngFileMessageTextbox, value);
                        break;
                    case "plan message":
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.PDDDConfiguration.AngPlanMessageTextbox, value);
                        break;
                    case "plan due date drop down":
                        string str = "Plan Data Due Date:";
                        // ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.PDDDConfiguration.PlanDataDueDateDropdownlist);
                        // UIMODUtilFunctions.selectDropDownValueAngJS(cfUIMODEAMConfiguration.PDDDConfiguration.PlanDataDueDateDropdownlist, value);
                        UIMODUtilFunctions.selectDropDownValueAngJS(str, value);
                        break;
                }
            }
            else
            {
                switch (field.ToLower())
                {
                    case "report month":
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.PDDDConfiguration.ReportMonthDate, value);
                        break;
                    case "file due date":
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.PDDDConfiguration.FileDueDate, value);
                        break;
                    case "plan due date":
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.PDDDConfiguration.PlanDueDate, value);
                        break;
                    case "file message":
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.PDDDConfiguration.FileMessageTextbox, value);
                        break;
                    case "plan message":
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.PDDDConfiguration.PlanMessageTextbox, value);
                        break;
                    case "plan due date drop down":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.PDDDConfiguration.PlanDataDueDateDropdownlist);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODEAMConfiguration.PDDDConfiguration.PlanDataDueDateDropdownlist, value);
                        //ReUsableFunctions.selectValueFromDropDown(cfUIMODEAMConfiguration.PDDDConfiguration.PlanDataDueDateDropdownlist, value);
                        break;

                }
            }
        }

        
        [When(@"EAM Configuration page PDD Config section ""(.*)"" Button is Clicked and Verify Message ""(.*)""")]
        public void WhenEAMConfigurationPagePDDConfigSectionButtonIsClickedAndVerifyMessage(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string expectedValue = tmsCommon.GenerateData(p1);
            switch (field.ToLower())
            {
                case "save":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.PDDDConfiguration.SaveBtn);
                    tmsWait.Hard(1);
                  //  string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                    //Assert.IsTrue(actualValue.Contains(expectedValue));
                    break;
                case "reset":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.PDDDConfiguration.ResetBtn);
                    break;
                case "search":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.PDDDConfiguration.SearchBtn);
                    tmsWait.Hard(3);
                    break;
            }
        }

        [When(@"EAM Configuration page PDD Config section edit ""(.*)"" Component is set to ""(.*)""")]
        public void WhenEAMConfigurationPagePDDConfigSectionEditComponentIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);

           
            switch (field.ToLower())
            {
                case "plan due date":
                   // By Drp = By.XPath("//kendo-datepicker[@id='planDueDate']//input']");

                    IWebElement el = Browser.Wd.FindElement(By.XPath("//input[@id='fileMessage']"));
                    el.SendKeys(Keys.Tab);
                    tmsWait.Hard(3);
                    //IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='premiumLis-txt-startDate']//span[@role='button']"));
                    IWebElement pduedate = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@id='planDueDate']//input"));
                    string[] value1 = value.Split('/');
                    pduedate.SendKeys(value1[0]);
                    pduedate.SendKeys(value1[1]);
                    pduedate.SendKeys(value1[2]);
                    //AngularFunction.enterDate(Drp, value);

                    tmsWait.Hard(1);
                    break;

                case "file due date":
                    // By Drp = By.XPath("//kendo-datepicker[@id='planDueDate']//input']");

                    IWebElement rmonth = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@id='reportMonth']//input"));
                    rmonth.SendKeys(Keys.Tab);
                    
                   tmsWait.Hard(3);
                   
                    //IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='premiumLis-txt-startDate']//span[@role='button']"));
                    IWebElement fduedate = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@id='fileDueDate']//input"));
                    string[] valuef = value.Split('/');
                    fduedate.SendKeys(valuef[0]);
                    fduedate.SendKeys(valuef[1]);
                    fduedate.SendKeys(valuef[2]);
                    //AngularFunction.enterDate(Drp, value);

                    tmsWait.Hard(1);
                  
                    break;
            }
        }



        [When(@"EAM Configuration page PDD Config section ""(.*)"" Icon is Clicked for File Message ""(.*)"" Also Verify message ""(.*)"" is displayed")]
        public void WhenEAMConfigurationPagePDDConfigSectionIconIsClickedForFileMessageAlsoVerifyMessageIsDisplayed(string p0, string p1, string p2)
        {
            string icon = tmsCommon.GenerateData(p0);
            string filemessage = tmsCommon.GenerateData(p1);
            string expectedValue = tmsCommon.GenerateData(p2);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                switch (icon.ToLower())
                {
                    case "edit":
                        tmsWait.Hard(2);
                        //td[contains(.,'January 1 - 7')]//following-sibling::td/a[contains(@class,'edit')]
                        IWebElement editicon = Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + filemessage + "')]//following-sibling::td//span[@class='fas fa-pencil-alt']"));
                        AngularFunction.clickOnElement(editicon);
                        //ReUsableFunctions.clickOnWebElement(editicon);
                        tmsWait.Hard(4);
                        break;
                    case "update":
                        tmsWait.Hard(2);
                        IWebElement updateicon = Browser.Wd.FindElement(By.XPath("//input[@id='fileMessage']/parent::td/following-sibling::td//span[@class='fas fa-save']"));
                        ReUsableFunctions.clickOnWebElement(updateicon);
                        tmsWait.Hard(4);
                        //tmsWait.Hard(1);
                        //string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                        //tmsWait.Hard(1);
                        //Assert.IsTrue(actualValue.Contains(expectedValue));
                        break;
                    case "delete":
                        tmsWait.Hard(2);
                        IWebElement deleteicon = Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + filemessage + "')]//following-sibling::td/a[contains(@class,'remove')]"));
                        ReUsableFunctions.clickOnWebElement(deleteicon);
                        tmsWait.Hard(2);
                       // string actual = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                       // Assert.IsTrue(actual.Contains(expectedValue));
                        break;
                    case "cancel":
                        IWebElement cancelicon = Browser.Wd.FindElement(By.XPath("//input[@id='fileMessage']/parent::td/following-sibling::td//a[contains(@class,'cancel')]"));
                        ReUsableFunctions.clickOnWebElement(cancelicon);
                        tmsWait.Hard(4);
                        break;
                }
                tmsWait.Hard(1);
            }
            else { 
            switch (icon.ToLower())
            {
                case "edit":
                    IWebElement editicon = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + filemessage + "')]/parent::td//following-sibling::td/a[1]"));
                    ReUsableFunctions.clickOnWebElement(editicon);
                    tmsWait.Hard(2);
                    break;
                case "update":
                    IWebElement updateicon = Browser.Wd.FindElement(By.XPath("//a[contains(@class,'update')]"));
                    ReUsableFunctions.clickOnWebElement(updateicon);
                    //tmsWait.Hard(1);
                    //string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                    //tmsWait.Hard(1);
                    //Assert.IsTrue(actualValue.Contains(expectedValue));
                    break;
                case "delete":
                    IWebElement deleteicon = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + filemessage + "')]/parent::td//following-sibling::td/a[2]"));
                    ReUsableFunctions.clickOnWebElement(deleteicon);
                    tmsWait.Hard(1);
                    string actual = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                    Assert.IsTrue(actual.Contains(expectedValue));
                    break;
                case "cancel":
                    IWebElement cancelicon = Browser.Wd.FindElement(By.XPath("//a[contains(@class,'cancel')]"));
                    ReUsableFunctions.clickOnWebElement(cancelicon);
                    break;
            }
            }
        }

        [Then(@"Verify EAM Configuration page PDD Config section result grid has data Reprot month ""(.*)"" File Due Date ""(.*)"" File Message ""(.*)"" Plan Due date ""(.*)"" Plan Message ""(.*)""")]
        public void ThenVerifyEAMConfigurationPagePDDConfigSectionResultGridHasDataReprotMonthFileDueDateFileMessagePlanDueDatePlanMessage(string p0, string p1, string p2, string p3, string p4)
        {
            string reportmonth = tmsCommon.GenerateData(p0);
            string fileduedate = tmsCommon.GenerateData(p1);
            string filemessage = tmsCommon.GenerateData(p2);
            string planduedate = tmsCommon.GenerateData(p3);
            string planmessage = tmsCommon.GenerateData(p4);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                try
                {
                    int totalPagesIntheGrid = ReUsableFunctions.getTotalPages();
                string xpath = "//div[@role='presentation']//td[contains(.,'" + reportmonth + "')]/following-sibling::td[contains(.,'" + fileduedate + "')]/following-sibling::td[contains(.,'" + filemessage + "')]/following-sibling::td[contains(.,'" + planduedate + "')]/following-sibling::td[contains(.,'" + planmessage + "')]";
                ReUsableFunctions.verifyGridElementPresence(xpath);
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the first page']")));
                tmsWait.Hard(3);
                }

                catch
                {
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")));
                   // int totalPagesIntheGrid = ReUsableFunctions.getTotalPages();
                    string xpath = "//div[@role='presentation']//td[contains(.,'" + reportmonth + "')]/following-sibling::td[contains(.,'" + fileduedate + "')]/following-sibling::td[contains(.,'" + filemessage + "')]/following-sibling::td[contains(.,'" + planduedate + "')]/following-sibling::td[contains(.,'" + planmessage + "')]";
                    ReUsableFunctions.verifyGridElementPresence(xpath);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the first page']")));
                }
            }
            else
            {
                IWebElement expectedRow = Browser.Wd.FindElement(By.XPath("//div[@test-id='pdddConfiguration-grid-pdddConfiguration']//td[contains(.,'" + reportmonth + "')]/following-sibling::td[contains(.,'" + fileduedate + "')]/following-sibling::td/span[contains(.,'" + filemessage + "')]/parent::td/following-sibling::td[contains(.,'" + planduedate + "')]/following-sibling::td/span[contains(.,'" + planmessage + "')]"));
                Assert.IsTrue(expectedRow.Displayed, "Expeted Data in a row does not exist");

            }
        
        }

        [Then(@"Verify EAM Configuraton Add Groups Section ""(.*)"" is not allowing more than four char")]
        public void ThenVerifyEAMConfiguratonAddGroupsSectionIsNotAllowingMoreThanFourChar(string p0)
        {
            string length = cfUIMODEAMConfiguration.AddGroups.CSCSID.GetAttribute("value");
            Console.WriteLine("CSCSID is present CSCSID textbox is--" + length.Length);
            Assert.IsTrue(length.Length <= 4, "length is more than 5 char");

        }
        [When(@"Verify EAM Configuraton Add Groups Section ""(.*)"" drop down should be disabled")]
        public void WhenVerifyEAMConfiguratonAddGroupsSectionDropDownShouldBeDisabled(string p0)
        {
            string field = tmsCommon.GenerateData(p0);

            string flagDisabled = null; ;

            switch (field)
            {       
                case "Select Group":
                    flagDisabled = cfUIMODEAMConfiguration.AddGroups.SelectGroupDropdownlist.GetAttribute("aria-disabled");

                   
                    break;
                case "Select SubGroup":
                    flagDisabled = cfUIMODEAMConfiguration.AddGroups.SelectSubGroupDropdownlist.GetAttribute("aria-disabled");
                    break;
                   

            }
            Assert.IsTrue(flagDisabled.Equals("true"), "Dropdown is not disabled");
        }
        [When(@"Verify EAM Configuraton Add Groups Section ""(.*)"" drop down should be displayed")]
        public void WhenVerifyEAMConfiguratonAddGroupsSectionDropDownShouldBeDisplayed(string p0)
        {
            string flagDisabled = cfUIMODEAMConfiguration.AddGroups.SelectGroupDropdownlist.GetAttribute("aria-disabled");
            Assert.IsTrue(flagDisabled.Equals("false"), "Dropdown is not disabled");
        }

        [Then(@"Verify EAM Configuraton Add Groups Section ""(.*)"" is not allowing more than ""(.*)"" char")]
        public void ThenVerifyEAMConfiguratonAddGroupsSectionIsNotAllowingMoreThanChar(string p0, string p1)
        {
            tmsWait.Hard(1);
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            string length ;
            switch (field.ToUpper())
            {
                case "GRGR ID":
                     length = cfUIMODEAMConfiguration.AddGroups.GRGRID.GetAttribute("value");
                    Console.WriteLine("length of string in textbox--" + length.Length);
                    Assert.IsTrue(length.Length <= 8, "length is more than 5 char");
                    break;
                case "GROUPNAME":
                  
                    length = cfUIMODEAMConfiguration.AddGroups.GroupName.GetAttribute("value");
                    Console.WriteLine("length of string in textbox--" + length.Length);
                    Assert.IsTrue(length.Length <= 50, "length is more than 5 char");
                    break;
                case "SGSG ID":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.AddGroups.SGSGID, value);
                    break;
                case "SUBGROUPNAME":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.AddGroups.SubGroupName, value);
                    break;
                case "CLASSNAME":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.AddGroups.ClassName, value);
                    break;
                case "CSCS ID":
                    length = cfUIMODEAMConfiguration.AddGroups.CSCSID.GetAttribute("value");
                    Console.WriteLine("CSCSID is present CSCSID textbox is--" + length.Length);
                    Assert.IsTrue(length.Length <= 4, "length is more than 5 char");

                    break;
            }
        }

        [Then(@"EAM Configuraton Add Groups Section ""(.*)"" Component is set to ""(.*)""")]
        public void ThenEAMConfiguratonAddGroupsSectionComponentIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(1);
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (field.ToUpper())
            {
                case "GRGR ID":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.AddGroups.GRGRID, value);
                    break;
                case "GROUPNAME":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.AddGroups.GroupName, value);
                    break;
                case "SGSG ID":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.AddGroups.SGSGID, value);
                    break;
                case "SUBGROUPNAME":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.AddGroups.SubGroupName, value);
                    break;
                case "CLASSNAME":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.AddGroups.ClassName, value);
                    break;
                case "CSCS ID":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.AddGroups.CSCSID, value);
                    break;

            }
            tmsWait.Hard(1);
        }
        [Then(@"EAM Configuraton Add Groups Section Add button is clicked")]
        public void ThenEAMConfiguratonAddGroupsSectionAddButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(cfUIMODEAMConfiguration.AddGroups.ADDButton);
            tmsWait.Hard(1);
        }
        [Then(@"EAM Configuraton Add Groups Section Add button is clicked and Verify message ""(.*)""")]
        public void ThenEAMConfiguratonAddGroupsSectionAddButtonIsClickedAndVerifyMessage(string p0)
        {
            tmsWait.Hard(2);
            string activate_Message = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(cfUIMODEAMConfiguration.AddGroups.ADDButton);
            string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
            Assert.IsTrue(actualValue.Contains(activate_Message));
           // tmsWait.Hard(10);
        }

        [When(@"EAM Configuraton Add Groups Page ""(.*)"" Radio Button is Clicked")]

        [Then(@"EAM Configuraton Add Groups Page ""(.*)"" Radio Button is Clicked")]
        public void ThenEAMConfiguratonAddGroupsPageRadioButtonIsClicked(string p0)
        {
            tmsWait.Hard(2);
            string field = tmsCommon.GenerateData(p0);
            tmsWait.Hard(2);
            switch (field.ToUpper())
            {
                 
                case "GROUP":
                    cfUIMODEAMConfiguration.AddGroups.GroupRadioButton.Click();
                    break;
                case "SUBGROUP":
                    cfUIMODEAMConfiguration.AddGroups.SubGroupRadioButton.Click();
                    
                    break;
                case "CLASS":
                    cfUIMODEAMConfiguration.AddGroups.ClassRadioButton.Click(); ;
                    break;
                case "ADD INDEPENDENT":
                    cfUIMODEAMConfiguration.AddGroups.AddIndependent.Click();
                    break;
                case "MAP GROUP":
                    cfUIMODEAMConfiguration.AddGroups.MapGroup.Click();

                    break;
                case "MAP SUBGROUP":
                    cfUIMODEAMConfiguration.AddGroups.MapSubGroup.Click(); ;
                    break;


            }
            tmsWait.Hard(2);
        }
        [Then(@"EAM Configuraton Add Groups Page ""(.*)"" Drop down ""(.*)"" is selected")]
        public void ThenEAMConfiguratonAddGroupsPageDropDownIsSelected(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            
          ;
            tmsWait.Hard(2);
            switch (field.ToUpper())
            {
                case "SELECT GROUP":
                        if (ConfigFile.tenantType.Equals("tmsx"))
                        {

                            By Drp = By.XPath("(//label[text()='Select Group']/parent::div//span)[4]");
                            By typeapp = By.XPath("//li[text()='" + value + "']");




                            UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                            tmsWait.Hard(3);
                            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);





                        }
                        else
                        {
                            ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.AddGroups.SelectGroupDropdownlist);
                            tmsWait.Hard(2);
                            UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODEAMConfiguration.AddGroups.SelectGroupDropdownlist, value);
                        } break;
                case "SELECT SUBGROUP":
                        if (ConfigFile.tenantType.Equals("tmsx"))
                        {

                            By Drp = By.XPath("(//label[text()='Select SubGroup']/parent::div//span)[4]");
                            By typeapp = By.XPath("//li[text()='" + value + "']");




                            UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                            tmsWait.Hard(3);
                            UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);





                        }
                        else
                        {
                            ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.AddGroups.SelectSubGroupDropdownlist);
                            tmsWait.Hard(4);
                            UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODEAMConfiguration.AddGroups.SelectSubGroupDropdownlist, value);
                        }
                    break;
            }
            tmsWait.Hard(2);
        }
           
        
        [Then(@"EAM Configuraton Add Groups Page ""(.*)"" checkbox is ""(.*)"" for GRGRID ""(.*)"" and SGSGID ""(.*)"" and CSCSID ""(.*)"" and message varified")]
        public void ThenEAMConfiguratonAddGroupsPageCheckboxIsForGRGRIDAndSGSGIDAndCSCSIDAndMessageVarified(string p0, string p1, string p2, string p3, string p4)
        {
            string xpath = null;
            string Inactivate_Message = null; 
            string activate_Message = null; 
            string componentType = tmsCommon.GenerateData(p0);
            string typeofAction = tmsCommon.GenerateData(p1);
            string GRGRID = tmsCommon.GenerateData(p2);
            string SGSGID = tmsCommon.GenerateData(p3);
            string CSCSID = tmsCommon.GenerateData(p4);
            string field = tmsCommon.GenerateData(p0);
            bool hasrow = false;
            int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));

            switch (field.ToUpper())
            {
                case "GROUP":
                    xpath = "//div[@test-id='groups-grid']//td[contains(.,'" + GRGRID + "')]/following-sibling::td/input";
                    Inactivate_Message = "An item has been inactivated successfully";
                    activate_Message = "An item has been activated successfully";
                    break;
                case "SUBGROUP":
                    xpath = "//div[@test-id='groups-grid']//td[contains(.,'" + GRGRID + "')]/following-sibling::td[contains(.,'" + SGSGID + "')]/following-sibling::td/input";
                    Inactivate_Message = "A sub group item has been inactivated successfully";
                    activate_Message = "A sub group item has been activated successfully";

                    break;
                case "CLASS":
                    xpath = "//div[@test-id='groups-grid']//td[contains(.,'" + GRGRID + "')]/following-sibling::td[contains(.,'" + SGSGID + "')]/following-sibling::td[contains(.,'" + CSCSID + "')]/following-sibling::td/input";
                    Inactivate_Message= "A class has been inactivated successfully";
                    activate_Message= "A class has been activated successfully";
                    break;


            }

            //By element = By.XPath(xpath);
            //IWebElement element1 = Browser.Wd.FindElement(element);

            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {
                    hasrow = Browser.Wd.FindElement(By.XPath(xpath)).Displayed;
                    break;
                }
                catch
                {

                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);
                }

            }
            //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed);

            //Assert.IsTrue(hasrow, "There is no such row Present");
            //tmsWait.Hard(5);

            switch(typeofAction.ToLower())
            {
                case "checked":
                    string verifyuncheck = Browser.Wd.FindElement(By.XPath(xpath)).GetAttribute("ng-checked");
                    if (!bool.Parse(verifyuncheck))
                    {
                        //ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath(xpath)));
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(xpath)));
                       // tmsWait.Hard(1);
                        //string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                       // Assert.IsTrue(actualValue.Contains(activate_Message));
                        tmsWait.Hard(10);
                    }
                    break;

                case "unchecked":
                    string verifycheck = Browser.Wd.FindElement(By.XPath(xpath)).GetAttribute("ng-checked");
                    if(bool.Parse(verifycheck))
                    {
                        //ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath(xpath)));
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(xpath)));
                       // tmsWait.Hard(1);
                       // string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                       // Assert.IsTrue(actualValue.Contains(Inactivate_Message));
                        tmsWait.Hard(10);
                   }
                    break;
            }
            
            //if (ReUsableFunctions.checkElementDisplayinGrid(element))
            //    if (typeofAction.ToLower().Equals("checked"))
            //    {
            //        string msg = "activated successfully";
            //    ReUsableFunctions.checkBoxOperationsWithMsgVarification(element, typeofAction, msg);

            //    } else if (typeofAction.ToLower().Equals("unchecked"))
            //    {
            //        string msg = "inactivated successfully";
            //        ReUsableFunctions.checkBoxOperationsWithMsgVarification(element, typeofAction, msg);
            //    }
            //tmsWait.Hard(2);
        }
        [When(@"EAM Configuraton Add Groups Page ""(.*)"" checkbox is ""(.*)"" for GRGRID ""(.*)""")]
        public void ThenEAMConfiguratonAddGroupsPageCheckboxIsForGRGRID(string p0, string p1, string p2)
        {
            ;

          
            string typeofAction = tmsCommon.GenerateData(p1);
            string GRGRID = tmsCommon.GenerateData(p2);
     
           
            bool hasrow = false;

         String str=   Browser.Wd.FindElement(By.XPath("//span[contains(.,'Page')]")).Text;
            string[] Count = str.Split(' ');
            int totalPagesIntheGrid = Int32.Parse(Count[1]);
            
                    string xpath  = "//table[@role='presentation']//div[contains(.,'GR1386')]/parent::td//following-sibling::td//input";
                   
                


         

            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {
                    hasrow = Browser.Wd.FindElement(By.XPath(xpath)).Displayed;
                    break;
                }
                catch
                {

                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);
                }

            }
            By element = By.XPath(xpath);
            IWebElement element1 = Browser.Wd.FindElement(element);

            if (ReUsableFunctions.checkElementDisplayinGrid(element))
            {

                ReUsableFunctions.CheckBoxOperations(element, typeofAction);
            }
            tmsWait.Hard(2);
        }

        [Then(@"EAM Configuraton Add Groups Page ""(.*)"" checkbox is ""(.*)"" for GRGRID ""(.*)"" and SGSGID ""(.*)"" and CSCSID ""(.*)""")]
        public void ThenEAMConfiguratonAddGroupsPageCheckboxIsForGRGRIDAndSGSGIDAndCSCSID(string p0, string p1, string p2, string p3, string p4)
        {
            

        string xpath = null;
            tmsWait.Hard(5);
            string componentType = tmsCommon.GenerateData(p0);
            string typeofAction = tmsCommon.GenerateData(p1);
            string GRGRID= tmsCommon.GenerateData(p2);
            string SGSGID= tmsCommon.GenerateData(p3);
            string CSCSID= tmsCommon.GenerateData(p4);
            string field = tmsCommon.GenerateData(p0);
            bool hasrow = false;
            int totalPagesIntheGrid = 0;
            if (ConfigFile.tenantType.Equals("tmsx")) {

                totalPagesIntheGrid = ReUsableFunctions.getTotalPages();

                if(SGSGID.Equals("")&&CSCSID.Equals(""))
                {
                xpath = "//table[@role='presentation']//div[contains(.,'" + GRGRID + "')]/parent::td//following-sibling::td//input";

                }
                else if(CSCSID.Equals("")&&!SGSGID.Equals(""))
                {
                    tmsWait.Hard(5);
                    xpath = "//table[@role='presentation']//div[contains(.,'" + GRGRID + "')]//parent::td/following-sibling::td/div[contains(.,'" + SGSGID + "')]/parent::td//following-sibling::td//input";
                }
                else
                {
                    xpath = "//table[@role='presentation']//div[contains(.,'" + GRGRID + "')]//parent::td/following-sibling::td/div[contains(.,'" + SGSGID + "')]//parent::td/following-sibling::td/div[contains(.,'" + CSCSID + "')]/parent::td//following-sibling::td//input";
                }

            }
            else
            {

            
                totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
            switch (field.ToUpper())
            {
                case "GROUP":
                    xpath = "//div[@test-id='groups-grid']//td[contains(.,'" + GRGRID + "')]/following-sibling::td/input";
                    break;
                case "SUBGROUP":
                    xpath = "//div[@test-id='groups-grid']//td[contains(.,'" + GRGRID + "')]/following-sibling::td[contains(.,'" + SGSGID + "')]/following-sibling::td/input";

                    break;
                case "CLASS":
                    xpath = "//div[@test-id='groups-grid']//td[contains(.,'" + GRGRID + "')]/following-sibling::td[contains(.,'" + SGSGID + "')]/following-sibling::td[contains(.,'" + CSCSID + "')]/following-sibling::td/input";
                    break;


            }
            }
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {

                    tmsWait.Hard(5);
                    hasrow = Browser.Wd.FindElement(By.XPath(xpath)).Displayed;
                    break;
                }
                catch
                {

                    //tmsWait.Hard(5);
                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);

                    tmsWait.Hard(5);
                }

            }
            //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed);

            //Assert.IsTrue(hasrow, "There is no such row Present");
            //tmsWait.Hard(5);

            //switch (typeofAction.ToLower())
            //{
            //    case "checked":
            //        string verifyuncheck = Browser.Wd.FindElement(By.XPath(xpath)).GetAttribute("ng-checked");
            //        if (!bool.Parse(verifyuncheck))
            //        {
            //            ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath(xpath)));
            //            string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
            //            Assert.IsTrue(actualValue.Contains(class_activate_Message));
            //            tmsWait.Hard(10);
            //        }
            //        break;

            //    case "unchecked":
            //        string verifycheck = Browser.Wd.FindElement(By.XPath(xpath)).GetAttribute("ng-checked");
            //        if (bool.Parse(verifycheck))
            //        {
            //            ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath(xpath)));
            //            string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
            //            Assert.IsTrue(actualValue.Contains(class_Inactivate_Message));
            //            tmsWait.Hard(10);
            //        }
            //        break;
            //}

        //xpath = "//div[@test-id='groups-grid']//td[contains(.,'" + GRGRID + "')]/following-sibling::td[contains(.,'" + SGSGID + "')]/following-sibling::td[contains(.,'" + CSCSID + "')]/following-sibling::td/input";
        By element = By.XPath(xpath);
        IWebElement element1 = Browser.Wd.FindElement(element);

            if (ReUsableFunctions.checkElementDisplayinGrid(element))
            { 

            ReUsableFunctions.CheckBoxOperations(element, typeofAction);
            }
    tmsWait.Hard(2);


        }
        [Then(@"Verify EAM Configuration page Plan(.*)StarStatus section checkbox is ""(.*)"" for PlanID ""(.*)""")]
        public void ThenVerifyEAMConfigurationPagePlanStarStatusSectionCheckboxIsForPlanID(int p0, string p1, string p2)
        {
            string xpath = null;
            string planid = tmsCommon.GenerateData(p2);
            string typeofAction = tmsCommon.GenerateData(p1);
           

            xpath = "//span[contains(.,'" + planid + "')]/parent::td/following-sibling::td/input";
            By element = By.XPath(xpath);
           // IWebElement element1 = Browser.Wd.FindElement(element);

            if (ReUsableFunctions.checkElementDisplayinGrid(element))
            {

                Assert.IsTrue(ReUsableFunctions.CheckBoxGetStatus(element, typeofAction));
            }

        }
        [Then(@"Verify EAM Configuration page Disenrollment section Active checkbox for code ""(.*)"" is ""(.*)""")]
        public void ThenVerifyEAMConfigurationPageDisenrollmentSectionActiveCheckboxForCodeIs(string p0, string p1)
        {
            string xpath = null;
            string code = tmsCommon.GenerateData(p0);
            string typeofAction = tmsCommon.GenerateData(p1);

            string xpath1 = "//div[@test-id='groups-grid']//td[contains(.,'" + code + "')]//following-sibling::td/input";
            xpath = "//span[contains(.,'" + code + "')]";
            By element = By.XPath(xpath);
            By element1 = By.XPath(xpath);
            // IWebElement element1 = Browser.Wd.FindElement(element);

            if (ReUsableFunctions.checkElementDisplayinGrid(element))
            {

                Assert.IsTrue(ReUsableFunctions.CheckBoxGetStatus(element1, typeofAction));
            }
        }

        [When(@"EAM Configuration page Disenrollment section edit ""(.*)"" checkbox is ""(.*)""")]


        [Then(@"Vefiry EAM Configuraton Add Groups Page ""(.*)"" checkbox is ""(.*)"" for GRGRID ""(.*)"" and SGSGID ""(.*)"" and CSCSID ""(.*)""")]
        public void ThenVefiryEAMConfiguratonAddGroupsPageCheckboxIsForGRGRIDAndSGSGIDAndCSCSID(string p0, string p1, string p2, string p3, string p4)
        {
            string xpath = null;
            string componentType = tmsCommon.GenerateData(p0);
            string typeofAction = tmsCommon.GenerateData(p1);
            string GRGRID = tmsCommon.GenerateData(p2);
            string SGSGID = tmsCommon.GenerateData(p3);
            string CSCSID = tmsCommon.GenerateData(p4);
            bool hasrow = false;
            int totalPagesIntheGrid = 0;
          
            if (ConfigFile.tenantType.Equals("tmsx"))
            {

                totalPagesIntheGrid = ReUsableFunctions.getTotalPages();
                if (SGSGID.Equals("") && CSCSID.Equals(""))
                {
                    xpath = "//table[@role='presentation']//div[contains(.,'" + GRGRID + "')]/parent::td//following-sibling::td//input";

                }
                else if (CSCSID.Equals("") && !SGSGID.Equals(""))
                {
                    tmsWait.Hard(5);
                    xpath = "//table[@role='presentation']//div[contains(.,'" + GRGRID + "')]//parent::td/following-sibling::td/div[contains(.,'" + SGSGID + "')]/parent::td//following-sibling::td//input";
                }
                else
                {
                    xpath = "//table[@role='presentation']//div[contains(.,'" + GRGRID + "')]//parent::td/following-sibling::td/div[contains(.,'" + SGSGID + "')]//parent::td/following-sibling::td/div[contains(.,'" + CSCSID + "')]/parent::td//following-sibling::td//input";
                }

            }
            else
            {
                switch (componentType.ToUpper())
                {
                    case "GROUP":
                        xpath = "//div[@test-id='groups-grid']//td[contains(.,'" + GRGRID + "')]/following-sibling::td/input";
                        break;
                    case "SUBGROUP":
                        xpath = "//div[@test-id='groups-grid']//td[contains(.,'" + GRGRID + "')]/following-sibling::td[contains(.,'" + SGSGID + "')]/following-sibling::td/input";

                        break;
                    case "CLASS":
                        xpath = "//div[@test-id='groups-grid']//td[contains(.,'" + GRGRID + "')]/following-sibling::td[contains(.,'" + SGSGID + "')]/following-sibling::td[contains(.,'" + CSCSID + "')]/following-sibling::td/input";
                        break;


                }

                for (int i = 1; i <= totalPagesIntheGrid; i++)
                {
                    try
                    {

                        tmsWait.Hard(5);
                        hasrow = Browser.Wd.FindElement(By.XPath(xpath)).Displayed;
                        break;
                    }
                    catch
                    {

                        //tmsWait.Hard(5);
                        IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                        ReUsableFunctions.clickOnWebElement(nextpage);

                        tmsWait.Hard(5);
                    }

                }
                // xpath = "//div[@test-id='groups-grid']//td[contains(.,'" + GRGRID + "')]/following-sibling::td[contains(.,'" + SGSGID + "')]/following-sibling::td[contains(.,'" + CSCSID + "')]/following-sibling::td/input";
                By element = By.XPath(xpath);
                // IWebElement element1 = Browser.Wd.FindElement(element);

                if (ReUsableFunctions.checkElementDisplayinGrid(element))
                {

                    Assert.IsTrue(ReUsableFunctions.CheckBoxGetStatus(element, typeofAction));
                }
            }
        }

        [Then(@"Verify EAM Configuraton Add Groups Page GRGRID ""(.*)"" and SGSGID ""(.*)"" and CSCSID ""(.*)"" is Displayed in Grid")]
        public void ThenVerifyEAMConfiguratonAddGroupsPageGRGRIDAndSGSGIDAndCSCSIDIsDisplayedInGrid(string p0, string p1, string p2)
        {
            string GRGRID = tmsCommon.GenerateData(p0);
            string SGSGID = tmsCommon.GenerateData(p1);
            string CSCSID = tmsCommon.GenerateData(p2);
            string xpath = "//div[@test-id='groups-grid']//td[contains(.,'" + GRGRID + "')]/following-sibling::td[contains(.,'" + SGSGID + "')]/following-sibling::td[contains(.,'" + CSCSID + "')]/following-sibling::td/input";
            By element = By.XPath(xpath);
      

            bool ispresent = ReUsableFunctions.checkElementDisplayinGrid(element);
                 Assert.IsTrue(ispresent, xpath + " is not displayed");
        }



      

        [When(@"EAM page I have navigated to ""(.*)"" of result grid")]
        public void WhenEAMPageIHaveNavigatedToOfResultGrid(string p0)
        {
            string page = tmsCommon.GenerateData(p0);
            switch (page.ToLower())
            {
                case "last page":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")));
                    break;
                case "first page":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the first page']")));
                    break;
                case "next page":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']")));
                    break;
                case "previous page":
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the previous page']")));
                    break;

            }
        }

        [When(@"EAM Configuration page Span Types section Span Type is set to ""(.*)""")]
        [Then(@"EAM Configuration page Span Types section Span Type is set to ""(.*)""")]
        public void EAMConfigurationPageSpanTypesSectionSpanTypeIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);

            ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.SpanTypes.SpanTypeTextbox, value);
        }

        [When(@"EAM Configuration page Span Types section ""(.*)"" button is clicked")]
        [Then(@"EAM Configuration page Span Types section ""(.*)"" button is clicked")]
        public void EAMConfigurationPageSpanTypesSectionButtonIsClicked(string p0)
        {
            string field = tmsCommon.GenerateData(p0);

            switch (field.ToLower())
            {
                case "reset":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.SpanTypes.ResetBtn);
                    break;
                case "save":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.SpanTypes.SaveBtn);
                    break;
                default:
                    break;
            }
        }

        [When(@"EAM Configuration page Span Types section ""(.*)"" Button is Clicked")]
        public void WhenEAMConfigurationPageSpanTypesSectionButtonIsClicked(string p0)
        {
            ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.SpanTypes.SaveBtn);
        }


        [When(@"EAM Configuration page Span Types section ""(.*)"" Button is Clicked and Verify Message ""(.*)""")]
        [Then(@"EAM Configuration page Span Types section ""(.*)"" Button is Clicked and Verify Message ""(.*)""")]
        public void WhenEAMConfigurationPageSpanTypesSectionButtonIsClickedAndVerifyMessage(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string expectedValue = tmsCommon.GenerateData(p1);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {

                switch (field.ToLower())
                {
                    case "reset":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.SpanTypes.ResetBtn);
                        break;
                    case "save":


                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.SpanTypes.SaveBtn);
                       // tmsWait.Hard(1);
                        string actualValue = Browser.Wd.FindElement(By.ClassName("k-notification-container")).Text;
                        Console.WriteLine(actualValue);
                        // Assert.IsTrue(actualValue.Contains(expectedValue));
                        break;
                    default:
                        break;
                }
            }
            else {
            switch (field.ToLower())
            {
                case "reset":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.SpanTypes.ResetBtn);
                    break;
                case "save":


                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.SpanTypes.SaveBtn);
                    tmsWait.Hard(1);
                    string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                    Assert.IsTrue(actualValue.Contains(expectedValue));
                    break;
                default:
                    break;
            }
            }
        }

        [Then(@"Verify EAM Configuraton page Span Types ""(.*)"" is Present in Grid")]
        public void ThenVerifyEAMConfiguratonPageSpanTypesIsPresentInGrid(string p0)
        {
            string spanType = tmsCommon.GenerateData(p0);
            string xpath = "";
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                xpath = "//div[@role='presentation']//td[contains(.,'" + spanType + "')]";
               int totalPagesIntheGrid = ReUsableFunctions.getTotalPages();

              
                ReUsableFunctions.verifyGridElementPresence(xpath);
            }
            else { 
                 xpath = "//div[@test-id='spanTypes-grid-onHoldReasons']//td[contains(.,'" + spanType + "')]";

            By element = By.XPath(xpath);

            bool ispresent = ReUsableFunctions.checkElementDisplayinGrid(element);
            Assert.IsTrue(ispresent, xpath + " is not displayed");

            }
        }

        [When(@"EAM Configuraton page Span Types Value ""(.*)"" is Updated to ""(.*)"" in Grid")]
        public void EAMConfiguratonPageSpanTypesValueIsUpdatedInGrid(string p0, string p1)
        {
            string spanType = tmsCommon.GenerateData(p0);
            string newSpanType = tmsCommon.GenerateData(p1);
            string xpath;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                 xpath = "//div[@role='presentation']//td[contains(.,'" + spanType + "')]/following-sibling::td/button[contains(@class,'edit')]";

            }
            else
            {
                 xpath = "//div[@test-id='spanTypes-grid-onHoldReasons']//td[contains(.,'" + spanType + "')]/following-sibling::td/a";
            }
                By element = By.XPath(xpath);
                if (Browser.Wd.FindElements(element).Count != 0)
                { //click on the edit button for our row in the grid
                    IWebElement element1 = Browser.Wd.FindElement(element);
                    ReUsableFunctions.clickOnWebElement(element1);
                } //else the row is already editable and we can proceed without clicking

                IWebElement spanTypeValue = Browser.Wd.FindElement(By.CssSelector("[name='value']"));

                ReUsableFunctions.enterValueOnWebElementWithClear(spanTypeValue, newSpanType);
            
        }
        [When(@"EAM Configuraton page Span Types Value ""(.*)"" Edit link in Grid is clicked")]
        public void EAMConfiguratonPageSpanTypesValueEditLinkInGridIsClicked(string p0)
        {
            string spanType = tmsCommon.GenerateData(p0);
            string xpath = "//div[@test-id='spanTypes-grid-onHoldReasons']//td[contains(.,'" + spanType + "')]/following-sibling::td/a";

            By element = By.XPath(xpath);
            if (Browser.Wd.FindElements(element).Count != 0)
            { //click on the edit button for our row in the grid
                IWebElement element1 = Browser.Wd.FindElement(element);
                ReUsableFunctions.clickOnWebElement(element1);
            } //else the row is already editable and we can proceed without clicking
        }

        [When(@"EAM Configuraton page Span Types ""(.*)"" checkbox is ""(.*)"" in Grid")]
        public void EAMConfiguratonPageSpanTypesCheckboxIsInGrid(string p0, string p1)
        {
            string checkboxName = tmsCommon.GenerateData(p0);
            string checkboxAction = tmsCommon.GenerateData(p1);
            string name = null;

            switch (checkboxName.ToLower())
            {
                case "active":
                    name = "active";
                    break;
                case "export":
                    name = "exportValue";
                    break;
                case "ui":
                    name = "ui";
                    break;
            }

            IWebElement element = Browser.Wd.FindElement(By.CssSelector("[name='" + name + "']"));
            ReUsableFunctions.CheckBoxOperations(element, checkboxAction);
        }

        [When(@"EAM Configuraton page Span Types Edit Grid Save button is Clicked")]
        public void EAMConfiguratonPageSpanTypesEditGridSaveButtonIsClicked()
        {
            IWebElement saveButton;
if (ConfigFile.tenantType.Equals("tmsx"))
            {

                saveButton = Browser.Wd.FindElement(By.XPath("//input[@name='value']/parent::div/parent::td/following-sibling::td//button[contains(@class,'save')]"));
            }
            else {
           saveButton = Browser.Wd.FindElement(By.XPath("//span[@class='k-i-check fa fa-floppy-o']/parent::a"));
            }
            ReUsableFunctions.clickOnWebElement(saveButton);
        }

        [When(@"EAM Configuration page Plan Defined Field section ""(.*)"" Component for ""(.*)"" is set to ""(.*)""")]
        public void WhenEAMConfigurationPagePlanDefinedFieldSectionComponentForIsSetTo(string p0, string p1, string p2)
        {
            string plan = tmsCommon.GenerateData(p0);
            string type = tmsCommon.GenerateData(p1);
            string value = tmsCommon.GenerateData(p2);
            string[] plannumber = plan.Split('n');
            string value1 = plannumber[1];
            string testID = null;
            switch (type.ToLower())
            {
                case "member":
                    testID = "'planDefiendFields-txt-memberField"+plan+"'";
                    IWebElement planfieldMember = Browser.Wd.FindElement(By.XPath("//input[@test-id="+testID+"]"));
                    ReUsableFunctions.enterValueOnWebElement(planfieldMember, value);
                    break;
                case "transaction":
                    testID = "'planDefiendFields-txt-transactionField" + plan + "'";
                    IWebElement planfieldTransaction = Browser.Wd.FindElement(By.XPath("//input[@test-id=" + testID + "]"));
                    ReUsableFunctions.enterValueOnWebElement(planfieldTransaction, value);
                    break;
            }
        }

        //[When(@"EAM Configuration page Plan Defined Field section ""(.*)"" button is clicked and Verify Message ""(.*)""")]
        //public void WhenEAMConfigurationPagePlanDefinedFieldSectionButtonIsClickedAndVerifyMessage(string p0, string p1)
        //{
        //    string buttonName = tmsCommon.GenerateData(p0);
        //    string Message = tmsCommon.GenerateData(p1);
        //    switch (buttonName.ToLower())
        //    {
        //        case "save member fields": ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.PlanDefinedFields.SaveMemberFieldsButton);

        //            break;
        //        case "save transaction fields": ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.PlanDefinedFields.SaveTransactionFieldsButton);
        //            break;
        //    }

        //   // tmsWait.Hard(1);
        //    //string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
        //    //Assert.IsTrue(actualValue.Contains(Message));
            

        //}

        [When(@"EAM Configuration page Plan Defined Field section ""(.*)"" button is clicked and Verify Message ""(.*)""")]
        public void WhenEAMConfigurationPagePlanDefinedFieldSectionButtonIsClickedAndVerifyMessage(string p0, string p1)
        {
            string buttonName = tmsCommon.GenerateData(p0);
            string Message = tmsCommon.GenerateData(p1);
            string actualValue = "";
            switch (buttonName.ToLower())
            {
                case "save member fields":
                   // ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.PlanDefinedFields.SaveMemberFieldsButton);
                    cfUIMODEAMConfiguration.PlanDefinedFields.SaveMemberFieldsButton.Click();
                   //actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).GetAttribute("aria-label");
                    break;
                case "save transaction fields":
                   cfUIMODEAMConfiguration.PlanDefinedFields.SaveTransactionFieldsButton.Click();
                   // actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).GetAttribute("aria-label");
                    break;
            }

            // tmsWait.Hard(1);
            //string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
            //Assert.IsTrue(actualValue.Contains(Message));


        }


        [Then(@"Verify EAM Configuration page Plan Defined Field section PlanValue label ""(.*)"" is displayed")]
        public void ThenVerifyEAMConfigurationPagePlanDefinedFieldSectionPlanValueLabelIsDisplayed(string p0)
        {
            string expectedValue = tmsCommon.GenerateData(p0);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + expectedValue + "')]")).Displayed);
        }


        [When(@"EAM Configuration page Relationship section ""(.*)"" Component is set to ""(.*)""")]
        public void WhenEAMConfigurationPageRelationshipSectionComponentIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (field.ToLower())
            {
                case "relation code": ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.RelationShip.RelationCode, value);
                        break;
                case "relationship": ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.RelationShip.RelationShipTextbox, value);
                        break;
            }
        }
        [When(@"Verify Configuration page Relationship section ""(.*)"" Component is set to ""(.*)""")]
        [Then(@"Verify Configuration page Relationship section ""(.*)"" Component is set to ""(.*)""")]
        public void ThenVerifyConfigurationPageRelationshipSectionComponentIsSetTo(string p0, string p1)
        {
      
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (field.ToLower())
            {
                case "relation code":
                    string value1= cfUIMODEAMConfiguration.RelationShip.RelationCode.GetAttribute("value");
                    Assert.IsTrue(value1.Equals(""));
                    break;
                case "relationship":
                    string value2=cfUIMODEAMConfiguration.RelationShip.RelationShipTextbox.GetAttribute("value"); ;
                    Assert.IsTrue(value2.Equals(""));
                    break;
                  
            }
        }


        [When(@"EAM Configuration page Relationship section ""(.*)"" button is clicked and Verify Message ""(.*)""")]
        public void WhenEAMConfigurationPageRelationshipSectionButtonIsClickedAndVerifyMessage(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string Message = tmsCommon.GenerateData(p1);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                switch (field.ToLower())
                {
                    case "save":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.RelationShip.SaveButton);
                        break;
                    case "reset":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.RelationShip.ResetButton);
                        break;
                }
            }
            else
            {


                switch (field.ToLower())
                {
                    case "save":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.RelationShip.SaveButton);
                        tmsWait.Hard(1);
                        string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                        Assert.IsTrue(actualValue.Contains(Message));
                        break;
                    case "reset":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.RelationShip.ResetButton);
                        break;
                }
            }
        }

        [Then(@"EAM Configuraton Add Groups Section Add button is clicked and Verify Msg ""(.*)""")]
        public void ThenEAMConfiguratonAddGroupsSectionAddButtonIsClickedAndVerifyMsg(string p0)
        {
            string Message = tmsCommon.GenerateData(p0);
            tmsWait.Hard(2);
            fw.ExecuteJavascript(cfUIMODEAMConfiguration.AddGroups.ADDButton);
            string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
            bool results = actualValue.Contains(Message);
            Assert.IsTrue(results);
        }

        [Then(@"EAM Configuraton Add Groups Section Add button is clicked and Verify Red Msg ""(.*)""")]
        public void ThenEAMConfiguratonAddGroupsSectionAddButtonIsClickedAndVerifyRedMsg(string p0)
        {
            string Message = tmsCommon.GenerateData(p0);
            tmsWait.Hard(2);
            fw.ExecuteJavascript(cfUIMODEAMConfiguration.AddGroups.ADDButton);
            tmsWait.Hard(1);
            string actualValue = Browser.Wd.FindElement(By.XPath("//span[contains(.,'"+ Message+"')]")).Text;
            Assert.IsTrue(actualValue.Contains(Message));
            //cfUIMODEAMConfiguration.AddGroups.CSCSID.Clear();
        }
        [Then(@"EAM Configuraton Add Groups Section textbox ""(.*)"" is Cleared")]
        public void ThenEAMConfiguratonAddGroupsSectionTextboxIsCleared(string p0)
        {
            string field = tmsCommon.GenerateData(p0);
            tmsWait.Hard(1);
            switch (field.ToUpper())
            {
                case "GRGRID":
                    cfUIMODEAMConfiguration.AddGroups.GRGRID.Clear();
                    break;
                case "CSCSID":
                    cfUIMODEAMConfiguration.AddGroups.CSCSID.Clear(); ;
                    break;
                case "SUBGROUPNAME":
                    cfUIMODEAMConfiguration.AddGroups.SubGroupName.Clear(); ;
                    break;
                case "SGSGID":
                    cfUIMODEAMConfiguration.AddGroups.SGSGID.Clear(); ;
                    break;

            }
            tmsWait.Hard(1);
        }


        [Then(@"Verify EAM configuration page Relationship result grid row with RelationCode ""(.*)"" and Relationship ""(.*)"" is displayed")]
    public void ThenVerifyEAMConfigurationPageRelationshipResultGridRowWithRelationCodeAndRelationshipIsDisplayed(string p0, string p1)
    {
        string relationcode = tmsCommon.GenerateData(p0);
        string relationship = tmsCommon.GenerateData(p1);
        bool hasrow = false;
            int totalPagesIntheGrid = 0;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                totalPagesIntheGrid = ReUsableFunctions.getTotalPages();
                string xpath = "//div[@role = 'presentation']//td[normalize-space()='" + relationcode + "']/following-sibling::td[normalize-space()='" + relationship + "']";
                //ReUsableFunctions.clickOnGridElement(xpath);
                ReUsableFunctions.verifyGridElementPresence(xpath);
            }
            else { 
                 totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {
                    hasrow = Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed;
                    break;
                }
                catch
                {
                    
                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);
                }
                
            }
            //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed);

            Assert.IsTrue(hasrow, "There is no such row Present");
            }

        }

        [When(@"EAM Configuration page Language section ""(.*)"" Component is set to ""(.*)""")]
        public void WhenEAMConfigurationPageLanguageSectionComponentIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);

            switch(field.ToLower())
            {
                case "code": ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.Language.Code, value); break;
                case "language": ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.Language.LanguageTextbox, value); break;
            }
        }

        [When(@"EAM Configuration page Language section ""(.*)"" button is clicked and Verify Message ""(.*)""")]
        public void WhenEAMConfigurationPageLanguageSectionButtonIsClickedAndVerifyMessage(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string Message = tmsCommon.GenerateData(p1);
            switch (field.ToLower())
            {
                case "save":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.Language.SaveButton);
                    tmsWait.Hard(1);
                    string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                      tmsWait.Hard(1);
                    Assert.IsTrue(actualValue.Contains(Message));
                    break;
                case "reset":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.Language.ResetButton);
                    break;
            }
           // Browser.Wd.Navigate().Refresh();

        }

        [Then(@"Verify EAM configuration page Language result grid row with Code ""(.*)"" and Language ""(.*)"" is displayed")]
        public void ThenVerifyEAMConfigurationPageLanguageResultGridRowWithCodeAndLanguageIsDisplayed(string p0, string p1)
        {
            string code = tmsCommon.GenerateData(p0);
            string language = tmsCommon.GenerateData(p1);
            bool hasrow = false;
            int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {
                    hasrow = Browser.Wd.FindElement(By.XPath("//div[@test-id='language-grid-languages']//td//span[contains(.,'" + code + "')]/parent::td/following-sibling::td/span[contains(.,'" + language + "')]")).Displayed;
                    break;
                }
                catch
                {

                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);
                }

            }
            //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed);

            Assert.IsTrue(hasrow, "There is no such row Present");
        }
        [Then(@"EAM Configuration page Sales Representative section ""(.*)"" Component is set to ""(.*)""")]
        [When(@"EAM Configuration page Sales Representative section ""(.*)"" Component is set to ""(.*)""")]
        public void WhenEAMConfigurationPageSalesRepresentativeSectionComponentIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);

            switch (field.ToLower())
            {
                case "rep id": ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.SalesRepresentative.RepID, value); break;
                case "rep name": ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.SalesRepresentative.RepName, value); break;
            }
        }

        [When(@"EAM Configuration page On-Hold Reason section ""(.*)"" Component is set to ""(.*)""")]
        public void WhenEAMConfigurationPageOn_HoldReasonSectionComponentIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            tmsWait.Hard(3);
            switch (field.ToLower())
            {
                case "on-hold reason": ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.OnHoldReason.OnHoldReasonTextbox, value); break;
                    //case "rep name": ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.SalesRepresentative.RepName, value); break;
                  
            }
        }

        [When(@"EAM Configuration page Disenrollment section ""(.*)"" Component is set to ""(.*)""")]
        public void WhenEAMConfigurationPageDisenrollmentSectionComponentIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            tmsWait.Hard(3);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                switch (field.ToLower())
                {

                    case "disenrollment code": ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.Disenrollment.DisEnrollmentReasonCodeTextbox, value); break;
                    case "description": ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.Disenrollment.DisEnrollmentReasonDiscriptionTextbox, value); break;
                    case "map to":
                        By Drp = By.XPath("(//label[text()='Map To']/parent::div//span)[4]");
                        By typeapp = By.XPath("//li[text()='" + value + "']");




                        UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        break;

                }

            }
            else
            {
                switch (field.ToLower())
                {
                    case "disenrollment code": ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.Disenrollment.DisEnrollmentReasonCodeTextbox, value); break;
                    case "description": ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.Disenrollment.DisEnrollmentReasonDiscriptionTextbox, value); break;
                    case "map to":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.Disenrollment.MapToDropdownlist);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODEAMConfiguration.Disenrollment.MapToDropdownlist, value); break;
                }

            }
        }

        [Then(@"EAM Configuration page Sales Representative section ""(.*)"" button is clicked and Verify Message ""(.*)""")]
        [When(@"EAM Configuration page Sales Representative section ""(.*)"" button is clicked and Verify Message ""(.*)""")]
        public void WhenEAMConfigurationPageSalesRepresentativeSectionButtonIsClickedAndVerifyMessage(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string Message = tmsCommon.GenerateData(p1);
            switch (field.ToLower())
            {
                case "save":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.SalesRepresentative.SaveBtn);
                    tmsWait.Hard(1);
                 //   string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                 //   Assert.IsTrue(actualValue.Contains(Message));
                    break;
                case "reset":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.SalesRepresentative.ResetBtn);
                    break;
            }
        }
        IWebElement toaterMsg;
        [Then(@"EAM Configuration page Disenrollment section ""(.*)"" button is clicked and Verify Message ""(.*)""")]
        [When(@"EAM Configuration page Disenrollment section ""(.*)"" button is clicked and Verify Message ""(.*)""")]
        public void WhenEAMConfigurationPageDisenrollmentSectionButtonIsClickedAndVerifyMessage(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string Message = tmsCommon.GenerateData(p1);
          
            switch (field.ToLower())
            {
                case "save":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.Disenrollment.SaveBtn);
                   // toaterMsg = Browser.Wd.FindElement(By.ClassName("toast-message"));
                   // Actions actions = new Actions(Browser.Wd);
                    // building mouse moves on the virtual canvas element
                   // actions.Build();
                 //   actions.MoveToElement(toaterMsg);           
                 //  actions.Perform();                    
                  //  string actualValue = toaterMsg.Text;
                   // Assert.IsTrue(actualValue.Contains(Message));
                 //   actions.Release();
                    break;
                case "reset":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.Disenrollment.ResetBtn);
                    break;
            }
        }

        [When(@"EAM Configuration page Disenrollment section ""(.*)"" button is clicked and Verify Entered values has removed")]
        public void WhenEAMConfigurationPageDisenrollmentSectionButtonIsClickedAndVerifyEnteredValuesHasRemoved(string p0)
        {
            ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.Disenrollment.ResetBtn);
           Assert.IsTrue(cfUIMODEAMConfiguration.Disenrollment.DisEnrollmentReasonCodeTextbox.Text.Equals(""));
        }

        [When(@"EAM Configuration page On-Hold Reason section ""(.*)"" button is clicked and Verify Message ""(.*)""")]
        public void WhenEAMConfigurationPageOn_HoldReasonSectionButtonIsClickedAndVerifyMessage(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string Message = tmsCommon.GenerateData(p1);
            switch (field.ToLower())
            {
                case "save":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.OnHoldReason.SaveBtn);
                    //string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                    //Assert.IsTrue(actualValue.Contains(Message));
                    break;
                case "reset":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.OnHoldReason.ResetBtn);
                    break;
            }
        }


        [When(@"EAM Configuration page On-Hold Reason section ""(.*)"" Icon is Clicked for Reason Description ""(.*)"" Also Verify message ""(.*)"" is displayed")]
        public void WhenEAMConfigurationPageOn_HoldReasonSectionIconIsClickedForReasonDescriptionAlsoVerifyMessageIsDisplayed(string p0, string p1, string p2)
        {
            string icon = tmsCommon.GenerateData(p0);
            string ReasonDesc = tmsCommon.GenerateData(p1);
            string expectedValue = tmsCommon.GenerateData(p2);
            switch (icon.ToLower())
            {
                case "edit":
                    IWebElement editicon = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + ReasonDesc + "')]/parent::td//following-sibling::td/a[1]"));
                    ReUsableFunctions.clickOnWebElement(editicon);
                    break;
                case "update":
                    IWebElement updateicon = Browser.Wd.FindElement(By.XPath("//a[contains(@class,'update')]"));
                    ReUsableFunctions.clickOnWebElement(updateicon);
                    tmsWait.Hard(1);
                    string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                    Assert.IsTrue(actualValue.Contains(expectedValue));
                    tmsWait.Hard(3);
                    break;
                case "delete":
                    IWebElement deleteicon = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + ReasonDesc + "')]/parent::td//following-sibling::td/a[2]"));
                    ReUsableFunctions.clickOnWebElement(deleteicon);
                    tmsWait.Hard(1);
                    string actual = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                    Assert.IsTrue(actual.Contains(expectedValue));
                    break;
                case "cancel":
                    IWebElement cancelicon = Browser.Wd.FindElement(By.XPath("//a[contains(@class,'cancel')]"));
                    ReUsableFunctions.clickOnWebElement(cancelicon);
                    break;
            }
        }
     

        [When(@"Verify EAM configuration page Sales Representative section ""(.*)"" is ""(.*)"" for Rep Name ""(.*)"" and RepId ""(.*)""")]
        public void WhenVerifyEAMConfigurationPageSalesRepresentativeSectionIsForRepNameAndRepId(string p0, string p1, string p2, string p3)
        {
           

        string field = tmsCommon.GenerateData(p0);
            string action = tmsCommon.GenerateData(p1);
            string repname = tmsCommon.GenerateData(p2);
            string repID = tmsCommon.GenerateData(p3);
            bool flag = true;
            switch (field.ToLower())
            {
                case "repname":
                    IWebElement editableRepname = Browser.Wd.FindElement(By.XPath("//tr[@data-role='editable']//td/span[contains(.,'"+repID + "')]/parent::td/following-sibling::td/input[@name='repName']"));
                    editableRepname.Clear();
                    tmsWait.Hard(1);
                    editableRepname.SendKeys("VerifyItsEditable");
                   // Assert.IsTrue(editableRepname.Enabled);
                  //  Assert.IsTrue(editableRepname.Selected);
                    tmsWait.Hard(1);
                    string actualValue = editableRepname.GetAttribute("value");
                    Assert.IsTrue(actualValue.Equals("VerifyItsEditable"));
                    break;
                case "checkbox":
                    IWebElement editblecheckbox = Browser.Wd.FindElement(By.XPath("//tr[@data-role='editable']//td/span[contains(.,'" + repID + "')]/parent::td/following-sibling::td/input[@type='checkbox']"));
                    Assert.IsTrue(editblecheckbox.Enabled);
                    Assert.IsTrue(editblecheckbox.Selected);
                    break;
                case "repid":
                    IWebElement noneditablerepid = Browser.Wd.FindElement(By.XPath("//tr[@data-role='editable']//td/span[contains(.,'" + repID + "')]"));
                  
                  

                    try {
                        noneditablerepid.SendKeys("VerifyItsEditable");
                        flag = false;
                    }
                    catch(InvalidOperationException e)
                    {
                        Console.WriteLine(e.Message);
                        Assert.IsTrue(flag);
                       
                    }
                    
                    break;
                case "cancel":
                    IWebElement cancelicon = Browser.Wd.FindElement(By.XPath("//a[contains(@class,'cancel')]"));
                    ReUsableFunctions.clickOnWebElement(cancelicon);
                    break;
            }
        }
        [When(@"Verify EAM configuration page Sales Representative section Actions has save and cancel button for Rep Name ""(.*)"" and RepId ""(.*)""")]
        public void WhenVerifyEAMConfigurationPageSalesRepresentativeSectionActionsHasSaveAndCancelButtonForRepNameAndRepId(string p0, string p1)
        {
           
            string repname = tmsCommon.GenerateData(p0);
            string repID = tmsCommon.GenerateData(p1);

          
          IWebElement savebutton = Browser.Wd.FindElement(By.XPath("//tr[@data-role='editable']//td/span[contains(.,'" + repID + "')]/parent::td/following-sibling::td/a[1]"));
            IWebElement cancelbutton = Browser.Wd.FindElement(By.XPath("//tr[@data-role='editable']//td/span[contains(.,'" + repID + "')]/parent::td/following-sibling::td/a[2]"));

            Assert.IsTrue(savebutton.Displayed);
            Assert.IsTrue(cancelbutton.Displayed);

        }
        [Then(@"Verify EAM Configuration page Sales Representative section Rep ID ""(.*)"" checkbox is ""(.*)""")]
        public void ThenVerifyEAMConfigurationPageSalesRepresentativeSectionRepIDCheckboxIs(string p0, string p1)
        {
          

        string repid = tmsCommon.GenerateData(p0);

            string TypeOfAction = tmsCommon.GenerateData(p1);
            if (TypeOfAction.ToLower().Equals("checked"))
            {

                IWebElement ActiveCheckBox = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + repid + "')]/parent::td//following-sibling::td/input[@type='checkbox']"));
                Assert.IsTrue(ActiveCheckBox.Selected, "checkbox is not selected, verification is failed");
            }

            else if (TypeOfAction.ToLower().Equals("unchecked"))
            {
                IWebElement ActiveCheckBox = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + repid + "')]/parent::td//following-sibling::td/input[@type='checkbox']"));
                Assert.IsTrue(!ActiveCheckBox.Selected, "checkbox is selected, verification is failed");
            }


        }
        [When(@"Verify EAM Configuration page Sales Representative section ""(.*)"" icon displayed for Rep ID ""(.*)""")]
        [Then(@"Verify EAM Configuration page Sales Representative section ""(.*)"" icon displayed for Rep ID ""(.*)""")]
        public void ThenVerifyEAMConfigurationPageSalesRepresentativeSectionIconDisplayedForRepID(string p0, string p1)
        {
            string icon = tmsCommon.GenerateData(p0);
            string repid = tmsCommon.GenerateData(p1);
           
            switch (icon.ToLower())
            {
                
                   
                case "delete":
                    IWebElement delete = Browser.Wd.FindElement(By.XPath("//span[.='" + repid + "']/parent::td//following-sibling::td/a[2]"));
                    Assert.IsTrue(delete.Displayed);

                    break;

            }
        }
        [Then(@"EAM Configuration page Sales Representative section ""(.*)"" Icon is Clicked for Rep ID ""(.*)"" Also Verify message ""(.*)"" is displayed")]
        [When(@"EAM Configuration page Sales Representative section ""(.*)"" Icon is Clicked for Rep ID ""(.*)"" Also Verify message ""(.*)"" is displayed")]
        public void WhenEAMConfigurationPageSalesRepresentativeSectionIconIsClickedForRepIDAlsoVerifyMessageIsDisplayed(string p0, string p1, string p2)
        {
            string icon = tmsCommon.GenerateData(p0);
            string repid = tmsCommon.GenerateData(p1);
            string expectedValue = tmsCommon.GenerateData(p2);
            switch (icon.ToLower())
            {


                case "delete":

                    IWebElement delete = Browser.Wd.FindElement(By.XPath("//span[.='" + repid + "']/parent::td//following-sibling::td/a[2]"));
                    //fw.ExecuteJavascript(delete);
                    tmsWait.Hard(1);
                    ReUsableFunctions.clickOnWebElement(delete);
                    // tmsWait.Hard(1);
                     string actual = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                    Assert.IsTrue(actual.Contains(expectedValue));
                    break;

            }
        }

        [When(@"EAM Configuration page Sales Representative section ""(.*)"" Icon is Clicked for Rep Name ""(.*)"" Also Verify message ""(.*)"" is displayed")]
        public void WhenEAMConfigurationPageSalesRepresentativeSectionIconIsClickedForRepNameAlsoVerifyMessageIsDisplayed(string p0, string p1, string p2)
        {
            string icon = tmsCommon.GenerateData(p0);
            string repname = tmsCommon.GenerateData(p1);
            string expectedValue = tmsCommon.GenerateData(p2);
            tmsWait.Hard(7);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                switch (icon.ToLower())
                {
                    case "edit":
                       
                        //td[contains(.,'" + repname + "')]//parent::td//following-sibling::td/a[@class='k-button k-grid-edit-command']
                        //td[contains(.,'001')]//following-sibling::td[contains(.,'EAM001')]//parent::td//following-sibling::td/a[@class='k-button k-grid-edit-command']
                        IWebElement editicon = Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + repname + "')]//parent::td//following-sibling::td//span[@class='fas fa-pencil-alt']"));
                        ReUsableFunctions.clickOnWebElement(editicon);
                        break;
                    case "update":
                        IWebElement updateicon = Browser.Wd.FindElement(By.XPath("//input[@id='repName']/parent::td//following-sibling::td//span[@class='fas fa-save']"));
                        ReUsableFunctions.clickOnWebElement(updateicon);
                        tmsWait.Hard(1);
                        //string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                        // Assert.IsTrue(actualValue.Contains(expectedValue));
                        tmsWait.Hard(6);
                        break;
                    case "delete":
                        //td[contains(.,'" + repname + "')]//following-sibling::td//a[@class='k-button k-grid-remove-command']
                        //td[contains(.,'qqq')]//following-sibling::td//a[@class='k-button k-grid-remove-command']
                        IWebElement deleteicon = Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + repname + "')]//following-sibling::td//a[@class='k-button k-grid-remove-command']"));
                        ReUsableFunctions.clickOnWebElement(deleteicon);
                        tmsWait.Hard(1);
                        //  string actual = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                        // Assert.IsTrue(actual.Contains(expectedValue));
                        break;
                    case "cancel":
                        IWebElement cancelicon = Browser.Wd.FindElement(By.XPath("//input[@id='repName']/parent::td//following-sibling::td//a[@class='k-button k-grid-cancel-command']"));
                        ReUsableFunctions.clickOnWebElement(cancelicon);
                        break;

                }
            }
            else
            {

                switch (icon.ToLower())
                {
                    case "edit":
                        IWebElement editicon = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + repname + "')]/parent::td//following-sibling::td/a[1]"));
                        ReUsableFunctions.clickOnWebElement(editicon);
                        break;
                    case "update":
                        IWebElement updateicon = Browser.Wd.FindElement(By.XPath("//a[contains(@class,'update')]"));
                        ReUsableFunctions.clickOnWebElement(updateicon);
                        tmsWait.Hard(1);
                        string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                        Assert.IsTrue(actualValue.Contains(expectedValue));
                        tmsWait.Hard(6);
                        break;
                    case "delete":
                        IWebElement deleteicon = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + repname + "')]/parent::td//following-sibling::td/a[2]"));
                        ReUsableFunctions.clickOnWebElement(deleteicon);
                        tmsWait.Hard(1);
                        string actual = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                        Assert.IsTrue(actual.Contains(expectedValue));
                        break;
                    case "cancel":
                        IWebElement cancelicon = Browser.Wd.FindElement(By.XPath("//a[contains(@class,'cancel')]"));
                        ReUsableFunctions.clickOnWebElement(cancelicon);
                        break;
                }

            }
        }

        [When(@"EAM Configuration page Disenrollment section ""(.*)"" Icon is Clicked for code ""(.*)"" Also Verify message ""(.*)"" is displayed")]
        public void WhenEAMConfigurationPageDisenrollmentSectionIconIsClickedForCodeAlsoVerifyMessageIsDisplayed(string p0, string p1, string p2)
        {
            string icon = tmsCommon.GenerateData(p0);
            string code = tmsCommon.GenerateData(p1);
            string expectedValue = tmsCommon.GenerateData(p2);
            int totalPagesIntheGrid = 0;


            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                totalPagesIntheGrid = ReUsableFunctions.getTotalPages();

            }
            else
            {
                totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
            }
           
            switch (icon.ToLower())
            {
                case "edit":
                    bool hasrow = false;
                  
                    for (int i = 1; i <= totalPagesIntheGrid; i++)
                    {
                        try
                        {
                            hasrow = Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + code + "')]//following-sibling::td//span[@class='fas fa-pencil-alt']")).Displayed;
                            break;
                        }
                        catch
                        {

                            IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                            ReUsableFunctions.clickOnWebElement(nextpage);
                        }
                    }
                       IWebElement editicon = Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + code + "')]//following-sibling::td//span[@class='fas fa-pencil-alt']"));
                    ReUsableFunctions.clickOnWebElement(editicon);
                    break;
                case "update":
                    IWebElement updateicon;
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        updateicon = Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + code + "')]//following-sibling::td//span[@class='fas fa-save']"));

                    }
                    else {
                         updateicon = Browser.Wd.FindElement(By.XPath("//a[contains(@class,'update')]"));

                    }
                    ReUsableFunctions.clickOnWebElement(updateicon);
                    tmsWait.Hard(1);
                    //string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                   // Assert.IsTrue(actualValue.Contains(expectedValue));
                   // tmsWait.Hard(3);
                    break;
                case "delete":
                    IWebElement deleteicon = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + code + "')]/parent::td//following-sibling::td/a[2]"));
                    ReUsableFunctions.clickOnWebElement(deleteicon);
                    tmsWait.Hard(1);
                    string actual = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                    Assert.IsTrue(actual.Contains(expectedValue));
                    break;
                case "cancel":
                    IWebElement cancelicon = Browser.Wd.FindElement(By.XPath("//a[contains(@class,'cancel')]"));
                    ReUsableFunctions.clickOnWebElement(cancelicon);
                    break;
            }
        }
        [When(@"Verify EAM Configuration page Disenrollment section ""(.*)"" is enabled")]
        public void WhenVerifyEAMConfigurationPageDisenrollmentSectionIsEnabled(string p0)
        {
            string Field = tmsCommon.GenerateData(p0);
          
            switch (Field.ToLower())
            {
                case "description":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//input[@name='description']")).Enabled);
                    break;
                case "active":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//input[@name='active']")).Enabled);
                    break;
                case "mapto":
                       Assert.IsTrue(cfUIMODEAMConfiguration.Disenrollment.MapToDropdownlist.Enabled);
                    break;
             
            }
        }

        [When(@"EAM Configuration page Sales Representative section Active checkbox for sales repid ""(.*)"" is checked")]
        public void WhenEAMConfigurationPageSalesRepresentativeSectionActiveCheckboxForSalesRepIsChecked(string p0)
        {
            string repid = tmsCommon.GenerateData(p0);
            IWebElement ActiveCheckBox = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + repid + "')]/parent::td//following-sibling::td/input[@type='checkbox']"));
            ReUsableFunctions.clickOnWebElement(ActiveCheckBox);
        }
        [When(@"EAM Configuration page Sales Representative section Rep ID ""(.*)"" checkbox is ""(.*)"" and msg ""(.*)"" is verified")]
        public void WhenEAMConfigurationPageSalesRepresentativeSectionRepIDCheckboxIsAndMsgIsVerified(string p0, string p1, string p2)
        {
            string repid = tmsCommon.GenerateData(p0);

            string TypeOfAction = tmsCommon.GenerateData(p1);
            string msg = tmsCommon.GenerateData(p2);

            IWebElement ActiveCheckBox = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + repid + "')]/parent::td//following-sibling::td/input[@type='checkbox']"));

            if (TypeOfAction.ToLower().Equals("checked"))
            {
                if (!ActiveCheckBox.Selected)
                {
                    fw.ExecuteJavascript(ActiveCheckBox);
                  //  string actual = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                   // Assert.IsTrue(actual.Contains(msg));

                }
            }
            else
            {
                if (ActiveCheckBox.Selected)
                {
                    fw.ExecuteJavascript(ActiveCheckBox);
                  //  string actual = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
//Assert.IsTrue(actual.Contains(msg));
                }
            }
        }

        [When(@"EAM Configuration page Sales Representative section Rep ID ""(.*)"" checkbox is ""(.*)""")]
        public void WhenEAMConfigurationPageSalesRepresentativeSectionRepIDCheckboxIs(string p0, string p1)
        {
            string repid = tmsCommon.GenerateData(p0);
            IWebElement ActiveCheckBox=null;
                 string TypeOfAction = tmsCommon.GenerateData(p1);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                ActiveCheckBox = Browser.Wd.FindElement(By.XPath("//td[normalize-space(.) ='" + repid + "']//following-sibling::td/input[@type='checkbox']"));
            }
            else
            {
                ActiveCheckBox = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + repid + "')]/parent::td//following-sibling::td/input[@type='checkbox']"));
            }
            if (TypeOfAction.ToLower().Equals("checked"))
            {
                if (!ActiveCheckBox.Selected)
                {
                    fw.ExecuteJavascript(ActiveCheckBox);
                    
                }
            }
            else
            {
                if (ActiveCheckBox.Selected)
                {
                    fw.ExecuteJavascript(ActiveCheckBox);
                   
                }
            }
        }


        [When(@"EAM Configuration page On-Hold Reason section ""(.*)"" checkbox is ""(.*)""  Also Verify message ""(.*)"" is displayed")]
        public void WhenEAMConfigurationPageOn_HoldReasonSectionCheckboxIsAlsoVerifyMessageIsDisplayed(string p0, string p1, string p2)
        {
            string CheckBox = tmsCommon.GenerateData(p0);
            string msg = tmsCommon.GenerateData(p2);
            string TypeOfAction = tmsCommon.GenerateData(p1);
            IWebElement ActiveCheckBox = Browser.Wd.FindElement(By.XPath("//input[@test-id='onHoldReasons-chk-preventOnHoldTrans']"));

            if (TypeOfAction.ToLower().Equals("checked"))
            {
                if (!ActiveCheckBox.Selected)
                {
                    fw.ExecuteJavascript(ActiveCheckBox);
                    string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                    Assert.IsTrue(actualValue.Contains(msg));
                }

                else
                {
                    Console.WriteLine("Checkbox is already Checked");
                    fw.setVariable(p1, "No need to verify");
                }
            }
            else
            {
                if (ActiveCheckBox.Selected)
                {
                    fw.ExecuteJavascript(ActiveCheckBox);
                    string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                    Assert.IsTrue(actualValue.Contains(msg));
                }

                else
                {
                    Console.WriteLine("Check box is already unchecked");
                    fw.setVariable(p1, "No need to verify");
                }
            }
        }
        [When(@"EAM Configuration page Plan(.*)StarStatus section checkbox is ""(.*)"" for PlanID ""(.*)""")]
        public void WhenEAMConfigurationPagePlanStarStatusSectionCheckboxIsForPlanID(int p0, string p1, string p2)
        {
            string planid = tmsCommon.GenerateData(p2);
            string TypeOfAction = tmsCommon.GenerateData(p1);
           
           string xpath = "//span[contains(.,'" + planid + "')]";
            By element = By.XPath(xpath);
            // IWebElement element1 = Browser.Wd.FindElement(element);

            if (ReUsableFunctions.checkElementDisplayinGrid(element))
            { 
                IWebElement ActiveCheckBox = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + planid + "')]/parent::td//following-sibling::td/input[@type='checkbox']"));
                if (TypeOfAction.ToLower().Equals("checked"))
            {
                if (!ActiveCheckBox.Selected)
                {
                    fw.ExecuteJavascript(ActiveCheckBox);
                }
            }
            else
            {
                if (ActiveCheckBox.Selected)
                {
                    fw.ExecuteJavascript(ActiveCheckBox);
                }
            }
        }
        }
        [When(@"EAM Configuration page Disenrollment section edit ""(.*)"" checkbox is ""(.*)""")]
        public void WhenEAMConfigurationPageDisenrollmentSectionEditCheckboxIs(string p0, string p1)
        {
            
         
        }

        [When(@"EAM Configuration page Disenrollment section code ""(.*)"" edit ""(.*)"" checkbox is ""(.*)""")]
        public void WhenEAMConfigurationPageDisenrollmentSectionCodeEditCheckboxIs(int p0, string p1, string p2)
        {
            int code = p0;
            string CheckBox = tmsCommon.GenerateData(p1);
            string TypeOfAction = tmsCommon.GenerateData(p2);
            IWebElement ActiveCheckBox = Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + code + "')]//following-sibling::td/input[@type='checkbox']"));

            if (TypeOfAction.ToLower().Equals("checked"))
            {
                if (!ActiveCheckBox.Selected)
                {
                    fw.ExecuteJavascript(ActiveCheckBox);
                }
            }
            else
            {
                if (ActiveCheckBox.Selected)
                {
                    fw.ExecuteJavascript(ActiveCheckBox);

                }
            }
        }


        [When(@"EAM Configuration page On-Hold Reason section ""(.*)"" checkbox is ""(.*)""")]
        public void WhenEAMConfigurationPageOn_HoldReasonSectionCheckboxIs(string p0, string p1)
        {
            string CheckBox = tmsCommon.GenerateData(p0);
            string TypeOfAction = tmsCommon.GenerateData(p1);
            IWebElement ActiveCheckBox = Browser.Wd.FindElement(By.XPath("//input[@test-id='onHoldReasons-chk-preventOnHoldTrans']"));

            if (TypeOfAction.ToLower().Equals("checked"))
            {
                if (!ActiveCheckBox.Selected)
                {
                    fw.ExecuteJavascript(ActiveCheckBox);
                }
            }
            else
            {
                if (ActiveCheckBox.Selected)
                {
                    fw.ExecuteJavascript(ActiveCheckBox);
                }
            }
        }

        [When(@"EAM Configuration page On-Hold Reason section ""(.*)"" link is clicked")]
        public void WhenEAMConfigurationPageOn_HoldReasonSectionLinkIsClicked(string p0)
        {
            string history = tmsCommon.GenerateData(p0);
            IWebElement historylink = Browser.Wd.FindElement(By.LinkText("On-Hold Settings History"));
            ReUsableFunctions.clickOnWebElement(historylink);
            tmsWait.Hard(3);
        }

        [When(@"EAM Configuration page On-Hold Reason section On-Hold Setting History Window is displayed")]
        public void WhenEAMConfigurationPageOn_HoldReasonSectionOn_HoldSettingHistoryWindowIsDisplayed()
        {
            tmsWait.Hard(5);
            IWebElement historyWindow = Browser.Wd.FindElement(By.XPath("//*[@id='eamAuditInfoDialog']/div[1]/span[1]"));
            
            Assert.IsTrue(historyWindow.Displayed, "On-Hold Setting History is not displaying");
        }
        [When(@"EAM Configuration page On-Hold Reason section On-Hold Setting History Window ""(.*)"" Button is displayed")]
        public void WhenEAMConfigurationPageOn_HoldReasonSectionOn_HoldSettingHistoryWindowButtonIsDisplayed(string p0)
        {
            tmsWait.Hard(1);
            IWebElement cancel = Browser.Wd.FindElement(By.XPath("//button[@test-id='auditInfo-btn-cancel']"));
            
            Assert.IsTrue(cancel.Displayed, "On-Hold Setting History is not displaying");
        }

        [When(@"EAM Configuration page On-Hold Reason section On-Hold Setting History Window ""(.*)"" Button is Clicked")]
        public void WhenEAMConfigurationPageOn_HoldReasonSectionOn_HoldSettingHistoryWindowButtonIsClicked(string p0)
        {
            tmsWait.Hard(1);
            IWebElement cancel = Browser.Wd.FindElement(By.XPath("//button[@test-id='auditInfo-btn-cancel']"));
            cancel.Click();
        }

        [Then(@"Verify EAM configuration page Sales Representative result grid row with RepId ""(.*)"" and Rep Name ""(.*)"" is displayed")]
        public void ThenVerifyEAMConfigurationPageSalesRepresentativeResultGridRowWithRepIdAndRepNameIsDisplayed(string p0, string p1)
        {
            string repid = tmsCommon.GenerateData(p0);
            string repname = tmsCommon.GenerateData(p1);
            bool hasrow = false;
            int totalPagesIntheGrid;
            if (ConfigFile.tenantType.Equals("tmsx"))

            {
                tmsWait.Hard(3);
                totalPagesIntheGrid = ReUsableFunctions.getTotalPages();
                string xpath = "//div[@role='presentation']//td[contains(.,'" + repid + "')]//following-sibling::td[contains(.,'" + repname + "')]";

                hasrow= ReUsableFunctions.verifyGridElementPresence(xpath);
            }
            else {
                 totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {
                   
                    hasrow = Browser.Wd.FindElement(By.XPath("//div[@test-id='salesRepresentative-grid-salesRepresentatives']//td//span[contains(.,'" + repid + "')]/parent::td/following-sibling::td/span[contains(.,'" + repname + "')]")).Displayed;
                    break;
                }
                catch
                {

                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);
                }

            }
            }
            //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed);

            Assert.IsTrue(hasrow, "There is no such row Present");
        }

        [Then(@"Verify EAM configuration page Disenrollment result grid row with code ""(.*)"" and Description ""(.*)"" and Map To ""(.*)""is displayed")]
        public void ThenVerifyEAMConfigurationPageDisenrollmentResultGridRowWithCodeAndDescriptionAndMapToIsDisplayed(string p0, string p1, string p2)
        {
            string code = tmsCommon.GenerateData(p0);
            string desc = tmsCommon.GenerateData(p1);
            bool hasrow = false;
            int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {

                    hasrow = Browser.Wd.FindElement(By.XPath("//div[@test-id='disenrollmentReasons-grid-disenrollmentReasons']//td//span[contains(.,'" + code + "')]/parent::td/following-sibling::td/span[contains(.,'" + desc + "')]")).Displayed;
                    break;
                }
                catch
                {

                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);
                }

            }
            //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed);

            Assert.IsTrue(hasrow, "There is no such row Present");
        }

       
        [When(@"Verify EAM configuration page Disenrollment result grid row with code ""(.*)"" and source ""(.*)"" and Description ""(.*)"" and Active checkbox is ""(.*)"" and Map To ""(.*)""is displayed")]
        public void WhenVerifyEAMConfigurationPageDisenrollmentResultGridRowWithCodeAndSourceAndDescriptionAndActiveCheckboxIsAndMapToIsDisplayed(string p0, string p1, string p2, string p3, string p4)
        {
           
       string code = tmsCommon.GenerateData(p0);
            string source = tmsCommon.GenerateData(p1);
            string desc = tmsCommon.GenerateData(p2);
            string checkboxstatus = tmsCommon.GenerateData(p3);
            string mapto = tmsCommon.GenerateData(p4);
            string classValue = "";
            bool hasrow = false;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                hasrow = UIMODUtilFunctions.rowPresenceUsingLocators(code, source, desc, checkboxstatus, mapto);
                Assert.IsTrue(hasrow);
            }

            else {
            if (checkboxstatus.ToLower().Equals("unchecked"))
            {
                classValue = "ng-pristine ng-untouched ng-valid ng-empty";
            }
            else if (checkboxstatus.ToLower().Equals("checked"))
            {
                classValue = "ng-pristine ng-untouched ng-valid ng-not-empty";
            }
            string xpath = "//div[@test-id='disenrollmentReasons-grid-disenrollmentReasons']//td[contains(.,'" + code + "')]/following-sibling::td[contains(.,'" + source + "' )]/following-sibling::td[contains(.,'" + desc + "' )]/following-sibling::td/input[@class='" + classValue + "']/parent::td/following-sibling::td[contains(.,'" + mapto + "')]";
            string checkxpath = "//td[contains(.,'" + code + "')]//following-sibling::td/input";
            string status="";
            int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {

                    hasrow = Browser.Wd.FindElement(By.XPath(xpath)).Displayed;
                    IWebElement element = Browser.Wd.FindElement(By.XPath(checkxpath));
                    // status = element.GetAttribute("checked").ToString();
                    break;
                }
                catch
                {

                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);
                }

            }
            //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed);

            Assert.IsTrue(hasrow, "There is no such row Present");

        }

        }


        [Then(@"Verify EAM configuration page On-Hold Reason result grid row with ReasonID ""(.*)"" and Reason Description ""(.*)"" is displayed")]
        public void ThenVerifyEAMConfigurationPageOn_HoldReasonResultGridRowWithReasonIDAndReasonDescriptionIsDisplayed(string p0, string p1)
        {
           
        string repid = tmsCommon.GenerateData(p0);
            string repname = tmsCommon.GenerateData(p1);
            bool hasrow = false;
            int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {
                    hasrow = Browser.Wd.FindElement(By.XPath("//div[@test-id='OnHoldReasons-grid-onHoldReasons']//td//span[contains(.,'" + repid + "')]/parent::td/following-sibling::td/span[contains(.,'" + repname + "')]")).Displayed;
                    break;
                }
                catch
                {

                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);
                }

            }
            //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed);

            Assert.IsTrue(hasrow, "There is no such row Present");
        }

        [When(@"EAM Configuration page On-Hold Reason section On-Hold Setting History Window has grid row with Changed From ""(.*)"" and Changed To ""(.*)"" and Changed By ""(.*)"" and Changed At ""(.*)"" is displayed")]
        public void WhenEAMConfigurationPageOn_HoldReasonSectionOn_HoldSettingHistoryWindowHasGridRowWithChangedFromAndChangedToAndChangedByAndChangedAtIsDisplayed(string p0, string p1, string p2, string p3)
        {
            

        string ChangedFrom = tmsCommon.GenerateData(p0);
            string Changedto = tmsCommon.GenerateData(p1);
            string ChangedBy = tmsCommon.GenerateData(p2);
            string Changedat = tmsCommon.GenerateData(p3);
            ChangedBy = ConfigFile.UserId;
            bool hasrow = false;
            int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {                                             
                    hasrow = Browser.Wd.FindElement(By.XPath("//div[@test-id='searchProvider-grid-providerLookup']//td//p[contains(.,'" + ChangedFrom + "')]/parent::td/following-sibling::td/p[contains(.,'" + Changedto + "')]/parent::td/following-sibling::td/span[contains(.,'"+ ChangedBy+"')]")).Displayed;
                    break;
                }
                catch
                {

                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);
                }

            }
            //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed);

            Assert.IsTrue(hasrow, "There is no such row Present");
        }


        [When(@"EAM Configuration page On-Hold Reason section On-Hold Setting History Window has grid row with Changed From ""(.*)"" and Changed To ""(.*)"" and Changed By """"(.*)"""" is displayed for operation ""(.*)""")]
        public void WhenEAMConfigurationPageOn_HoldReasonSectionOn_HoldSettingHistoryWindowHasGridRowWithChangedFromAndChangedToAndChangedByIsDisplayedForOperation(string p0, string p1, string p2, string p3)
        {
            string ChangedFrom = tmsCommon.GenerateData(p0);
            string Changedto = tmsCommon.GenerateData(p1);
            string ChangedBy = tmsCommon.GenerateData(p2);
            string Changedat = tmsCommon.GenerateData(p3);
            ChangedBy = ConfigFile.UserId;
            bool hasrow = false;
            int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));

           
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {
                    hasrow = Browser.Wd.FindElement(By.XPath("//div[@test-id='searchProvider-grid-providerLookup']//td//p[contains(.,'" + ChangedFrom + "')]/parent::td/following-sibling::td/p[contains(.,'" + Changedto + "')]/parent::td/following-sibling::td/span[contains(.,'" + ChangedBy + "')]")).Displayed;
                    break;
                }
                catch
                {

                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);
                }

            }
            //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed);

            Assert.IsTrue(hasrow, "There is no such row Present");
        }


        [When(@"EAM Configuration page On-Hold Reason section On-Hold Setting History Window has grid row with Changed From ""(.*)"" and Changed To ""(.*)"" and Changed By ""(.*)"" and Changed At ""(.*)"" is displayed for operation ""(.*)""")]
        public void WhenEAMConfigurationPageOn_HoldReasonSectionOn_HoldSettingHistoryWindowHasGridRowWithChangedFromAndChangedToAndChangedByAndChangedAtIsDisplayedForOperation(string p0, string p1, string p2, string p3, string p4)
        {
            string ChangedFrom = tmsCommon.GenerateData(p0);
            string Changedto = tmsCommon.GenerateData(p1);
            string ChangedBy = tmsCommon.GenerateData(p2);
            string Changedat = tmsCommon.GenerateData(p3);
            string operationtype = tmsCommon.GenerateData(p4);
            ChangedBy = ConfigFile.UserId;
            bool hasrow = false;
            int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));

            if (operationtype != "No need to verify")
            {

          
                for (int i = 1; i <= totalPagesIntheGrid; i++)
                {
                    try
                    {
                        hasrow = Browser.Wd.FindElement(By.XPath("//div[@test-id='searchProvider-grid-providerLookup']//td//p[contains(.,'" + ChangedFrom + "')]/parent::td/following-sibling::td/p[contains(.,'" + Changedto + "')]/parent::td/following-sibling::td/span[contains(.,'" + ChangedBy + "')]")).Displayed;
                        break;
                    }
                    catch
                    {

                        IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                        ReUsableFunctions.clickOnWebElement(nextpage);
                    }

                }
            //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed);

            Assert.IsTrue(hasrow, "There is no such row Present");

            }
        }


        [When(@"EAM Configuration page OSB Config tab OSB Config history setting Window has grid row with PlanId ""(.*)"" and PbpId ""(.*)"" and Area ""(.*)"" and Changed From ""(.*)"" and Changed To ""(.*)"" and Changed By ""(.*)"" and Changed At ""(.*)"" is displayed")]
        public void WhenEAMConfigurationPageOSBConfigTabOSBConfigHistorySettingWindowHasGridRowWithPlanIdAndPbpIdAndAreaAndChangedFromAndChangedToAndChangedByAndChangedAtIsDisplayed(string p0, string p1, string p2, string p3, string p4, string p5, string p6)
        {
            string PlanId = tmsCommon.GenerateData(p0);
            string PbpId = tmsCommon.GenerateData(p1);
            string Area = tmsCommon.GenerateData(p2);
            string ChangedFrom = tmsCommon.GenerateData(p3);
            string ChangedTo = tmsCommon.GenerateData(p4);
            string ChangedBy = tmsCommon.GenerateData(p5);
            string ChangedAt = tmsCommon.GenerateData(p6);
            ChangedBy = ConfigFile.UserId;
            bool hasrow = false;
            int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));

            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {
                    //IWebElement element = Browser.Wd.FindElement(By.XPath("//div[@test-id='searchProvider-grid-providerLookup']//tr[contains(.,'H1001')and contains(.,'001')and contains(.,'OSB Premium') and contains(.,'-') and contains(.,'1.25')and contains(.,'tmsadmin')]"));
                    hasrow = Browser.Wd.FindElement(By.XPath("//div[@test-id='searchProvider-grid-providerLookup']//tr[contains(.,'" + PlanId + "')and contains(.,'" + PbpId + "')and contains(.,'" + Area + "') and contains(.,'" + ChangedFrom + "') and contains(.,'" + ChangedTo + "')and contains(.,'" + ChangedBy + "')]")).Displayed;
                   //hasrow = element.Displayed;
                   //hasrow = Browser.Wd.FindElement(By.XPath("//div[@test-id='searchProvider-grid-providerLookup']//td//span[contains(.,'" + PlanId + "')]/parent::td/following-sibling::td/span[contains(.,'" + PbpId + "')]/parent::td/following-sibling::td[contains(.,'" + Area + "')]/parent::td/following-sibling::td/p[contains(.,'" + ChangedFrom + "')]")).Displayed;
                   // hasrow = Browser.Wd.FindElement(By.XPath("//div[@test-id='searchProvider-grid-providerLookup']//td//span[contains(.,'" + PlanId + "')]")).Displayed;
                    break;
                }
                catch
                {

                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);
                }

            }
            Assert.IsTrue(hasrow, "There is no such row Present");
            tmsWait.Hard(6);
        }

        [When(@"EAM Configuration page Sales Representative section edit ""(.*)"" Component is set to ""(.*)""")]
        public void WhenEAMConfigurationPageSalesRepresentativeSectionEditComponentIsSetTo(string p0, string p1)
        {
            string repname = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.SalesRepresentative.EditRepName, value);
            cfUIMODEAMConfiguration.SalesRepresentative.EditRepName.SendKeys(Keys.Tab);
        }
        [When(@"EAM Configuration page Disenrollment section edit ""(.*)"" Component is set to ""(.*)""")]
        public void WhenEAMConfigurationPageDisenrollmentSectionEditComponentIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (field.ToLower())
            {
                case "description":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.Disenrollment.EditDisEnrollmentReasonDiscriptionTextbox, value);
                    cfUIMODEAMConfiguration.Disenrollment.EditDisEnrollmentReasonDiscriptionTextbox.SendKeys(Keys.Tab);
                    break;
                case "map to":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.Disenrollment.EditMapToDropdownlist);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODEAMConfiguration.Disenrollment.EditMapToDropdownlist, value);


                    break;
                case "active":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.Disenrollment.EditCheckbox);
                    
                    break;
                    
            }
           
            
        }

        [When(@"Verify EAM Configuration page SNP configuration section ""(.*)"" Component has value ""(.*)""")]
        public void WhenVerifyEAMConfigurationPageSNPConfigurationSectionComponentHasValue(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[text()='Chronic Type']/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + value + "']");




                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
              //  UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
            }
            else { 
            tmsWait.Hard(1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'All')]/parent::li/span[@aria-label='delete']")));
            tmsWait.Hard(1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//select[@test-id='snpConfigure-select-drpChronicType']/preceding-sibling::div")));
            tmsWait.Hard(1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + value + "')]")));
            }

        }

        [When(@"Add Edit LIS Info page LIS Level as ""(.*)"" Co Pay Cat as ""(.*)"" LIS Type as ""(.*)"" Source as ""(.*)"" Valid as ""(.*)"" Current as ""(.*)"" row edit buton is Clicked")]
        public void WhenAddEditLISInfoPageLISLevelAsCoPayCatAsLISTypeAsSourceAsValidAsCurrentAsRowEditButonIsClicked(string p0, string p1, string p2, string p3, string p4, string p5)
        {
            By edit = By.XPath("//div[@test-id='lisInformation-grid-lisConfig']//td[contains(.,'"+ p0 + "')]/following-sibling::td[contains(.,'"+p1+"')]/following-sibling::td[contains(.,'"+p2+"')]/following-sibling::td[contains(.,'"+p3+ "')]//following-sibling::td[contains(.,'" + p4 + "')]//following-sibling::td[contains(.,'" + p5 + "')]/following-sibling::td/a[1]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(edit);
        }

        [When(@"Add Edit LIS Info page LIS Level as ""(.*)"" Co Pay Cat as ""(.*)"" LIS Type as ""(.*)"" Source as ""(.*)"" Valid as ""(.*)"" Current as ""(.*)"" row Save buton is Clicked")]
        public void WhenAddEditLISInfoPageLISLevelAsCoPayCatAsLISTypeAsSourceAsValidAsCurrentAsRowSaveButonIsClicked(string p0, string p1, string p2, string p3, string p4, string p5)
        {
            By edit = By.XPath("//div[@test-id='lisInformation-grid-lisConfig']//td[contains(.,'" + p0 + "')]/following-sibling::td[contains(.,'" + p1 + "')]/following-sibling::td[contains(.,'" + p2 + "')]/following-sibling::td[contains(.,'" + p3 + "')]//following-sibling::td[contains(.,'" + p4 + "')]//following-sibling::td[contains(.,'" + p5 + "')]/following-sibling::td/a[1]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(edit);
        }

        [When(@"Verify Add Edit LIS Info page LIS Level as ""(.*)"" Co Pay Cat as ""(.*)"" LIS Type as ""(.*)"" Source as ""(.*)"" Valid as ""(.*)"" Current as ""(.*)"" row Save buton is Clicked Verify Message as ""(.*)""")]
        public void WhenVerifyAddEditLISInfoPageLISLevelAsCoPayCatAsLISTypeAsSourceAsValidAsCurrentAsRowSaveButonIsClickedVerifyMessageAs(string p0, string p1, string p2, string p3, string p4, string p5, string expValue)
        {
            By edit = By.XPath("//div[@test-id='lisInformation-grid-lisConfig']//td[contains(.,'" + p0 + "')]/following-sibling::td[contains(.,'" + p1 + "')]/following-sibling::td[contains(.,'" + p2 + "')]/following-sibling::td[contains(.,'" + p3 + "')]//following-sibling::td[contains(.,'" + p4 + "')]//following-sibling::td[contains(.,'" + p5 + "')]/following-sibling::td/a[1]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(edit);
           

            By toastMsg = By.XPath("//div[contains(@aria-label,'" + expValue + "')]");

            bool msgDisplay = Browser.Wd.FindElement(toastMsg).Displayed;
            Assert.IsTrue(msgDisplay, expValue + " is not displayed");

            tmsWait.Hard(15); // we put this wait intentionaly to disappear toaster message
        }

        [When(@"Add Edit LIS Info page LIS Level as ""(.*)"" Co Pay Cat as ""(.*)"" LIS Type as ""(.*)"" Source as ""(.*)"" Valid as ""(.*)"" Current as ""(.*)"" row Save buton is Clicked Verify Message as ""(.*)""")]
        public void WhenAddEditLISInfoPageLISLevelAsCoPayCatAsLISTypeAsSourceAsValidAsCurrentAsRowSaveButonIsClickedVerifyMessageAs(string p0, string p1, string p2, string p3, string p4, string p5, string expValue)
        {
            By edit = By.XPath("//div[@test-id='lisInformation-grid-lisConfig']//td[contains(.,'" + p0 + "')]/following-sibling::td[contains(.,'" + p1 + "')]/following-sibling::td[contains(.,'" + p2 + "')]/following-sibling::td[contains(.,'" + p3 + "')]//following-sibling::td[contains(.,'" + p4 + "')]//following-sibling::td[contains(.,'" + p5 + "')]/following-sibling::td/a[1]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(edit);
            UIMODUtilFunctions.clickOnConfirmationYesDialog();

            By toastMsg = By.XPath("//div[contains(@aria-label,'"+expValue+"')]");
            
            bool msgDisplay = Browser.Wd.FindElement(toastMsg).Displayed;
            Assert.IsTrue(msgDisplay, expValue + " is not displayed");

            tmsWait.Hard(15); // we put this wait intentionaly to disappear toaster message
        }

        [When(@"EAM Configuration page Edit LIS Information section Save Icon is clicked and Verify Message as ""(.*)""")]
        public void WhenEAMConfigurationPageEditLISInformationSectionSaveIconIsClickedAndVerifyMessageAs(string expValue)
        {
            tmsWait.Hard(3);

            IWebElement save = Browser.Wd.FindElement(By.XPath("//a[contains(@class,'update')]"));
            ReUsableFunctions.clickOnWebElement(save);

            By toastMsg = By.XPath("//div[contains(@aria-label,'" + expValue + "')]");

            bool msgDisplay = Browser.Wd.FindElement(toastMsg).Displayed;
            Assert.IsTrue(msgDisplay, expValue + " is not displayed");

            tmsWait.Hard(15); // we put this wait intentionaly to disappear toaster message
        }

        [When(@"Add Edit LIS Info page Click on Confirmation dialog")]
        public void WhenAddEditLISInfoPageClickOnConfirmationDialog()
        {
            UIMODUtilFunctions.clickOnConfirmationYesDialog();
        }


        [When(@"Add Edit LIS Info page displayed message as ""(.*)""")]
        public void WhenAddEditLISInfoPageDisplayedMessageAs(string msg)
        {
            ReUsableFunctions.toasterMessageDisplay(msg);
        }

        [Then(@"Verify Add Edit LIS Info page LIS Level as ""(.*)"" Co Pay Cat as ""(.*)"" LIS Type as ""(.*)"" Source as ""(.*)"" Valid as ""(.*)"" Current as ""(.*)"" row displayed")]
        public void ThenVerifyAddEditLISInfoPageLISLevelAsCoPayCatAsLISTypeAsSourceAsValidAsCurrentAsRowDisplayed(string p0, string p1, string p2, string p3, string p4, string p5)
        {
            By edit = By.XPath("//div[@test-id='lisInformation-grid-lisConfig']//td[contains(.,'" + p0 + "')]/following-sibling::td[contains(.,'" + p1 + "')]/following-sibling::td[contains(.,'" + p2 + "')]/following-sibling::td[contains(.,'" + p3 + "')]//following-sibling::td[contains(.,'" + p4 + "')]//following-sibling::td[contains(.,'" + p5 + "')]/following-sibling::td/a[1]");
            UIMODUtilFunctions.elementPresenceUsingLocators(edit);
        }

        [When(@"Add Edit LIS Info page Valid Drop down is set to ""(.*)""")]
        public void WhenAddEditLISInfoPageValidDropDownIsSetTo(string p0)
        {
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[aria-owns='lisValidText_listbox']"));
            UIMODUtilFunctions.selectDropDownValueFromGendoUI(ele, p0);
        }

        [When(@"Add Edit LIS Info page Current Drop down is set to ""(.*)""")]
        public void WhenAddEditLISInfoPageCurrentDropDownIsSetTo(string p0)
        {
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[aria-owns='lisCurrent_listbox']"));
            UIMODUtilFunctions.selectDropDownValueFromGendoUI(ele, p0);
        }

        [When(@"Add Edit LIS Info page Source Drop down is set to ""(.*)""")]
        public void WhenAddEditLISInfoPageSourceDropDownIsSetTo(string p0)
        {
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[aria-owns='lisSource_listbox']"));
            UIMODUtilFunctions.selectDropDownValueFromGendoUI(ele, p0);
        }

        [When(@"Add Edit LIS Info page LIS Level Drop down is set to ""(.*)""")]
        public void WhenAddEditLISInfoPageLISLevelDropDownIsSetTo(string p0)
        {
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[aria-owns='lisLevel_listbox']"));
            UIMODUtilFunctions.selectDropDownValueFromGendoUI(ele, p0);
        }

        [When(@"Add Edit LIS Info page CoPay Cat Drop down is set to ""(.*)""")]
        public void WhenAddEditLISInfoPageCoPayCatDropDownIsSetTo(string p0)
        {
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[aria-owns='coPayCat_listbox']"));
            UIMODUtilFunctions.selectDropDownValueFromGendoUI(ele, p0);
        }

        [When(@"Add Edit LIS Info page LIS Type Drop down is set to ""(.*)""")]
        public void WhenAddEditLISInfoPageLISTypeDropDownIsSetTo(string p0)
        {
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[aria-owns='lisType_listbox']"));
            UIMODUtilFunctions.selectDropDownValueFromGendoUI(ele, p0);
        }

        [When(@"EAM Add Edit LIS Info page Start Date is set to ""(.*)""")]
        public void WhenEAMAddEditLISInfoPageStartDateIsSetTo(string p0)
        {
            string currentDateValue = p0;
            IWebElement date = Browser.Wd.FindElement(By.XPath("//div[@test-id='lisInformation-grid-lisConfig']//input[@id='startDate']"));
            date.Clear();
            date.SendKeys(Keys.Home);
            date.SendKeys(currentDateValue);
            date.SendKeys(Keys.Tab);
        }

        [When(@"EAM Add Edit LIS Info page End Date  is set to ""(.*)""")]
        public void WhenEAMAddEditLISInfoPageEndDateIsSetTo(string p0)
        {
            string currentDateValue = p0;
            IWebElement enddate = Browser.Wd.FindElement(By.XPath("//div[@test-id='lisInformation-grid-lisConfig']//input[@id='endDate']"));
            enddate.Clear();
            enddate.SendKeys(Keys.Home);
            enddate.SendKeys(currentDateValue);
            enddate.SendKeys(Keys.Tab);
        }


        [When(@"Add Edit LIS Info page Start Date is set to ""(.*)""")]
        public void WhenAddEditLISInfoPageStartDateIsSetTo(string p0)
        {
            string currentDateValue="";
            if (p0.Equals("CurrentSystemDate"))
            {
                 currentDateValue = UIMODUtilFunctions.returnDateFormatDDMMYYYY();
                
            }
            else
            {
                currentDateValue = "01/01/1947";

            }
            IWebElement date = Browser.Wd.FindElement(By.XPath("//div[@test-id='lisInformation-grid-lisConfig']//input[@id='startDate']"));
            date.Clear();
            date.SendKeys(Keys.Home);
            date.SendKeys(currentDateValue);
            date.SendKeys(Keys.Tab);

        }

        [When(@"Add Edit LIS Info page End Date  is set to ""(.*)""")]
        public void WhenAddEditLISInfoPageEndDateIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string currentDateValue = "";
            if (p0.Equals("CurrentSystemDate"))
            {
                currentDateValue = UIMODUtilFunctions.returnDateFormatDDMMYYYY();

            }
            else
            {
                currentDateValue = "01/01/1948";

            }
            
            IWebElement enddate = Browser.Wd.FindElement(By.XPath("//div[@test-id='lisInformation-grid-lisConfig']//input[@id='endDate']"));
            enddate.Clear();
            enddate.SendKeys(Keys.Home);
            enddate.SendKeys(currentDateValue);
            enddate.SendKeys(Keys.Tab);
        }

        [When(@"EAM Configuration page Edit LIS Information section ""(.*)"" Button is Clicked and displayed message as ""(.*)""")]
        public void WhenEAMConfigurationPageEditLISInformationSectionButtonIsClickedAndDisplayedMessageAs(string p0, string expValue)
        {

            tmsWait.Hard(3);
            ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.AddEditLISInfo.SearchBtn);
            By toastMsg = By.XPath("//div[contains(@aria-label,'" + expValue + "')]");

            bool msgDisplay = Browser.Wd.FindElement(toastMsg).Displayed;
            Assert.IsTrue(msgDisplay, expValue + " is not displayed");

            tmsWait.Hard(15); // we put this wait intentionaly to disappear toaster message
        }

        [When(@"EAM Configuration page Edit LIS Information section Pagination ""(.*)"" is Clicked")]
        public void WhenEAMConfigurationPageEditLISInformationSectionPaginationIsClicked(string p0)
        {
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//a[@title='"+ p0 + "']"));
            fw.ExecuteJavascript(ele);
        }


        [When(@"EAM Configuration page Edit LIS Information section ""(.*)"" Button is Clicked")]
        public void WhenEAMConfigurationPageEditLISInformationSectionButtonIsClicked(string p0)
        {
            string field = tmsCommon.GenerateData(p0);

            tmsWait.Hard(3);
            switch (field)
            {
                case "SEARCH":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.AddEditLISInfo.SearchBtn);
                    tmsWait.Hard(5);
                    break;
                case "Add LIS Info":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.AddEditLISInfo.AngularAddLISInfo);
                        tmsWait.Hard(5);
                    }
                    else
                    {
                        try
                        {
                            ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.AddEditLISInfo.AddLISInfo);
                        }
                        catch
                        {
                            fw.ConsoleReport(" There is no Add LIS Info button");
                        }
                        tmsWait.Hard(5);

                    }
                    break;
            }
        }

        [Then(@"Verify LIS Information UI ""(.*)"" is matching with DB count ""(.*)""")]
        public void ThenVerifyLISInformationUIIsMatchingWithDBCount(string p0, string p1)
        {
            string dbcount = tmsCommon.GenerateData(p1);
        
            IWebElement txt = Browser.Wd.FindElement(By.XPath("//span[@class='k-pager-info k-label']"));
            string UICount = txt.Text.Split(' ')[4];            
            Assert.AreEqual(dbcount, UICount, " Both are not matching");

        }



        [When(@"EAM Configuration page Edit LIS Information section ""(.*)"" Component is set to ""(.*)""")]
        public void WhenEAMConfigurationPageEditLISInformationSectionComponentIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            string currentDateValue = UIMODUtilFunctions.returnDateFormatDDMMYYYY();

            switch (field)
            {
                case "currentMon":
                    tmsWait.Hard(2);
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.AddEditLISInfo.CurrentDropdownlist);
                    tmsWait.Hard(2);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODEAMAdmin.AddEditLISInfo.CurrentDropdownlist, value);

                    tmsWait.Hard(5);
                    break;
                case "CurrentLIS":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//kendo-dropdownlist[@test-id='lisInfo-ddlCurrent']//span[contains(@class,'select')]");

                        By typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                        tmsWait.Hard(3);
                    }

                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.AddEditLISInfo.CurrentDropdownlist);
                        tmsWait.Hard(2);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODEAMAdmin.AddEditLISInfo.CurrentDropdownlist, value);

                        tmsWait.Hard(5);
                    }
                    break;
                case "MBI":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMAdmin.AddEditLISInfo.MBITextbox, value);
                    tmsWait.Hard(5);
                    break;
                case "Plan ID":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.AddEditLISInfo.PlanIDDropdownlist);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODEAMAdmin.AddEditLISInfo.PlanIDDropdownlist, value);
                    tmsWait.Hard(5);
                    break;

                case "LIS Level":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//kendo-dropdownlist[@test-id='lisInfo-ddlLisLevel']//span[@class='k-select']");

                        By typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                        tmsWait.Hard(3);
                    }

                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.AddEditLISInfo.LISLevelDropdownlist);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODEAMAdmin.AddEditLISInfo.LISLevelDropdownlist, value);
                        tmsWait.Hard(5);
                    }
                    break;
                case "Co-Pay Cat":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//kendo-dropdownlist[@test-id='lisInfo-ddlCoPayCat']//span[@class='k-select']");

                    By typeapp = By.XPath("//li[text()='" + value + "']");

                    //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                    tmsWait.Hard(3);
                    //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                    tmsWait.Hard(3);
            }

                    else
                    {
                ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.AddEditLISInfo.CoPayCatDropdownlist);
                UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODEAMAdmin.AddEditLISInfo.CoPayCatDropdownlist, value);
                tmsWait.Hard(5);
            }
                    break;
                case "Start Date":
                    // ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("//span[@aria-controls='startDate_dateview']")));

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@id='txtStartDate']//input"));
                        if(value.Contains("/"))
                        {
                             value = value.Replace("/", "");
                        }
                        ele.Clear();
                        ele.SendKeys(value);
                        tmsWait.Hard(3);
                    }

                    else
                    {
                        if (value.Equals("CurrentSystemDate"))
                    {
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMAdmin.AddEditLISInfo.StartDate, currentDateValue);
                    }
                    else
                    {
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMAdmin.AddEditLISInfo.StartDate, value);
                        tmsWait.Hard(5);
                     }
                    }
                    break;
                case "End Date":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ele = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@id='txtEndDate']//input"));
                        if (value.Contains("/"))
                        {
                            value = value.Replace("/", "");
                        }
                        
                        ele.Clear();
                        ele.SendKeys(value);
                        tmsWait.Hard(3);
                    }
                    else
                    {
                        if (value.Equals("CurrentSystemDate"))
                    {
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMAdmin.AddEditLISInfo.EndDate, currentDateValue);
                    }
                    else
                    {
                        //ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("//span[@aria-controls='endDate_dateview']"))); 
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMAdmin.AddEditLISInfo.EndDate, value);
                        tmsWait.Hard(5);
                      }
                    }
                    break;
                case "LIS Type":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("(//kendo-dropdownlist[@test-id='lisInfo-ddlLisType']//span)[3]");

                        By typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        //tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                        tmsWait.Hard(3);
                    }

                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.AddEditLISInfo.LISTypeDropdownlist);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUIWithoutAriaOwns(cfUIMODEAMAdmin.AddEditLISInfo.LISTypeDropdownlist, value);
                    tmsWait.Hard(4);
                    }
                    break;
                case "Source":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("(//kendo-dropdownlist[@test-id='lisInfo-ddlLisSources']//span)[3]");

                        By typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                        tmsWait.Hard(3);
                    }
                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.AddEditLISInfo.SourceDropdownlist);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODEAMAdmin.AddEditLISInfo.SourceDropdownlist, value);
                    }

                    break;
                case "Valid":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("(//kendo-dropdownlist[@test-id='lisInfo-ddlValid']//span)[3]");

                        By typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                       // tmsWait.Hard(3);
                    }
                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.AddEditLISInfo.ValidDropdownlist);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODEAMAdmin.AddEditLISInfo.ValidDropdownlist, value);
                        tmsWait.Hard(2);
                    }
                    break;
                case "Current":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.AddEditLISInfo.CurrentDropdownlist);
                    //tmsWait.Hard(2);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODEAMAdmin.AddEditLISInfo.CurrentDropdownlist, value);

                    tmsWait.Hard(5);
                    break;
                
            }
        }



        [When(@"EAM Configuration page SNP configuration section ""(.*)"" Component is set to ""(.*)""")]
        public void WhenEAMConfigurationPageSNPConfigurationSectionComponentIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);

            
            switch (field.ToLower())
            {
                case "plan id":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[text()='Plan ID']/parent::div//span[@class='k-select']");

                        By typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        //tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                        tmsWait.Hard(3);

                    }

                    else
                    {
                        ReUsableFunctions.selectValueFromDropDown(cfUIMODEAMConfiguration.SNPConfiguration.PlanIDDropdownlist, value);
                    }
                    break;
                case "pbp":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[text()='PBP']/parent::div//span[@class='k-select']");

                        By typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        //tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                        tmsWait.Hard(3);

                    }
                    else
                    {
                        ReUsableFunctions.selectValueFromDropDown(cfUIMODEAMConfiguration.SNPConfiguration.PBPIDDropdownlist,value);
                    }
                    break;
                case "snp type":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[text()='SNP Type']/parent::div//span[@class='k-select']");

                        By typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        //tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                        tmsWait.Hard(3);

                    }
                    else
                    {
                        ReUsableFunctions.selectValueFromDropDown(cfUIMODEAMConfiguration.SNPConfiguration.SNPTypeDropdownlist,value);
                    }
                    tmsWait.Hard(5);
                      break; 
                case "months of eligibility":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[text()='Months of Eligibility']/parent::div//span[@class='k-select']");

                        By typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        //tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                        tmsWait.Hard(3);

                    }
                    else
                    {
                        ReUsableFunctions.selectValueFromDropDown(cfUIMODEAMConfiguration.SNPConfiguration.MonthsOfeligibilityDropdownlist,value);
                    }
                    break;
                case "chronic type":
                    // fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'All')]/parent::li/span[@aria-label='delete']")));

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//kendo-multiselect[@test-id='snpConfigure-select-drpChronicType']");

                        By typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                        tmsWait.Hard(3);

                    }
                    else
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//select[@test-id='snpConfigure-select-drpChronicType']/preceding-sibling::div")));
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + value + "')]")));
                    }

                    break;
                case "state":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[text()='State']/parent::div//span[@class='k-select']");

                        By typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        //tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                        tmsWait.Hard(3);

                    }
                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.SNPConfiguration.StateDropdownlist);
                      UIMODUtilFunctions.selectDropDownValueFromGendoUIWithoutAriaOwns(cfUIMODEAMConfiguration.SNPConfiguration.StateDropdownlist, value);
                    }
                    break;
            }
            
        }




        [When(@"EAM Configuration page SNP configuration section ESRD checkbox is checked")]
        public void WhenEAMConfigurationPageSNPConfigurationSectionESRDCheckboxIsChecked()
        {
            ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.SNPConfiguration.ESRDCheckbox);
            tmsWait.Hard(1);
        }

        [When(@"EAM Configuration page SNP configuration section ""(.*)"" button is clicked")]
        public void WhenEAMConfigurationPageSNPConfigurationSectionButtonIsClicked(string p0)
        {
            ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.SNPConfiguration.SaveBtn);
        }



        [When(@"EAM Configuration page SNP configuration section ""(.*)"" button is clicked and Verify Message ""(.*)""")]
        public void WhenEAMConfigurationPageSNPConfigurationSectionButtonIsClickedAndVerifyMessage(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string Message = tmsCommon.GenerateData(p1);
            switch (field.ToLower())
            {
                case "save":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.SNPConfiguration.SaveBtn);
                  
                  //  string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                   // Assert.IsTrue(actualValue.Contains(Message));
                    tmsWait.Hard(3);
                    break;
                case "reset":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.SNPConfiguration.ResetBtn);
                    break;
            }
        }


        [Then(@"Verify EAM configuration page SNP configuration result grid row with Planid ""(.*)"" and PBP ""(.*)"" and SNP Type ""(.*)"" is displayed")]
        public void ThenVerifyEAMConfigurationPageSNPConfigurationResultGridRowWithPlanidAndPBPAndSNPTypeIsDisplayed(string p0, string p1, string p2)
        {
            string planid = tmsCommon.GenerateData(p0);
            string pbp = tmsCommon.GenerateData(p1);
            string spantype = tmsCommon.GenerateData(p2);
            bool hasrow = false;
            int totalPagesIntheGrid = 0;

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                totalPagesIntheGrid = ReUsableFunctions.getTotalPages();
                string xpath = "//div[@role='presentation']//td[contains(.,'" + planid + "')]/following-sibling::td[contains(.,'" + pbp + "')]//following-sibling::td[contains(.,'" + spantype + "')]";
                ReUsableFunctions.verifyGridElementPresence(xpath);

            }
            else
            {
                totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
                for (int i = 1; i <= totalPagesIntheGrid; i++)
                {
                    try
                    {
                        hasrow = Browser.Wd.FindElement(By.XPath("//div[@test-id='snpConfigure-grid-dgSnpConfigure']//td//span[contains(.,'" + planid + "')]/parent::td/following-sibling::td/span[contains(.,'" + pbp + "')]/parent::td/following-sibling::td/span[contains(.,'" + spantype + "')]")).Displayed;
                        break;
                    }
                    catch
                    {

                        IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                        ReUsableFunctions.clickOnWebElement(nextpage);
                    }

                }
                //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed);

                Assert.IsTrue(hasrow, "There is no such row Present");
            }
        }

        [Then(@"EAM Configuration page Edit LIS Information section ""(.*)"" Icon is clicked for LISLevel ""(.*)"" and Co-PayCat ""(.*)"" and LISType ""(.*)"" Start Date as ""(.*)""")]
        public void ThenEAMConfigurationPageEditLISInformationSectionIconIsClickedForLISLevelAndCo_PayCatAndLISTypeStartDateAs(string p0, string p1, string p2, string p3, string p4)
        {
           
        string icon = tmsCommon.GenerateData(p0);

            string LISlevel = tmsCommon.GenerateData(p1);
            string CoPay = tmsCommon.GenerateData(p2);
            string startDate = tmsCommon.GenerateData(p4);
            IWebElement editicon;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                 editicon = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='lisInformation-grid-lisConfig']//td[contains(.,'" + LISlevel + "')]//following-sibling::td[contains(.,'" + CoPay + "')]//following-sibling::td[contains(.,'" + startDate + "')]//following-sibling::td/button[contains(@class,'edit-command')]"));
            }

            else
            {
                //IWebElement editicon = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + LISlevel + "')]/parent::td//following-sibling::td/span[contains(.,'" + CoPay + "')]//following - sibling::td[contains(., '" + startDate + "')]/parent::td//following-sibling::td/a[1]"));
                 editicon = Browser.Wd.FindElement(By.XPath("//div[@test-id='lisInformation-grid-lisConfig']//span[contains(.,'" + LISlevel + "')]/parent::td//following-sibling::td[contains(.,'" + CoPay + "')]/following-sibling::td[contains(.,'" + startDate + "')]//following-sibling::td/a[1]"));
            }
            editicon.Click();
            
    
        }

        [Then(@"Verify ""(.*)"" column value is set to ""(.*)""")]
        public void ThenVerifyColumnValueIsSetTo(string p0, string p1)
        {
            string actual = tmsCommon.GenerateData(p0);
            string expected = tmsCommon.GenerateData(p1);

            Assert.AreEqual(expected, actual, " Both are not matching");
        }


        [When(@"EAM Configuration page Edit LIS Information section ""(.*)"" Icon is clicked for LISLevel ""(.*)"" and Co-PayCat ""(.*)"" and LISType ""(.*)"" Also Verify Message ""(.*)""")]
        public void WhenEAMConfigurationPageEditLISInformationSectionIconIsClickedForLISLevelAndCo_PayCatAndLISTypeAlsoVerifyMessage(string p0, string p1, string p2, string p3, string p4)
        {
            string icon = tmsCommon.GenerateData(p0);
           
            string LISlevel = tmsCommon.GenerateData(p1);
            string CoPay = tmsCommon.GenerateData(p2);
            string listType = tmsCommon.GenerateData(p3);

            tmsWait.Hard(3);
            string msg = tmsCommon.GenerateData(p4);
            switch (icon.ToLower())
            {
                case "edit":
                    IWebElement editicon;
                        if (ConfigFile.tenantType.Equals("tmsx"))
                    {


                        editicon = Browser.Wd.FindElement(By.XPath("//kendo-grid-list[@role='presentation']//td[contains(.,'" + LISlevel + "')]//following-sibling::td[contains(.,'" + CoPay + "')]//following-sibling::td[contains(.,'" + listType + "')]//following-sibling::td/button[contains(@class,'edit')]"));

                    }

                    else
                    {
                        editicon = Browser.Wd.FindElement(By.XPath("//div[@test-id='lisInformation-grid-lisConfig']//span[contains(.,'" + LISlevel + "')]/parent::td//following-sibling::td[contains(.,'" + CoPay + "')]//following-sibling::td[contains(.,'" + listType + "')]//following-sibling::td/a[1]"));
                        //IWebElement editicon = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + LISlevel + "')]/parent::td//following-sibling::td/span[contains(.,'" + CoPay + "')]//following-sibling::td/span[contains(.,'" + listType + "')]/parent::td//following-sibling::td/a[1]"));
                    }

                    editicon.Click();
                    tmsWait.Hard(3);
                    break;


                case "delete":
                    IWebElement deleteicon;
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        deleteicon = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='lisInformation-grid-lisConfig']//td[contains(.,'" + LISlevel + "')]//following-sibling::td[contains(.,'" + CoPay + "')]//following-sibling::td[contains(.,'" + listType + "')]//following-sibling::td/a[2]"));
                        deleteicon.Click();
                        IWebElement warning = Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']"));
                        fw.ExecuteJavascript(warning);                                                                      
                        //warning.Click();
                        tmsWait.Hard(1);
                    }
                    else
                    {
                        deleteicon = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + LISlevel + "')]/parent::td//following-sibling::td/span[contains(.,'" + CoPay + "')]/parent::td//following-sibling::td/span[contains(.,'" + listType + "')]/parent::td//following-sibling::td/a[2]"));
                    
                    deleteicon.Click();
                    tmsWait.Hard(1);
                    IWebElement warning=  Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']"));
                    warning.Click();
                     string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                    Assert.IsTrue(actualValue.Contains(msg));
                    tmsWait.Hard(3);
                    }
                    //tmsWait.Hard(1);
                    break;
                case "save":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement savex=  Browser.Wd.FindElement(By.XPath("(//kendo-grid-list[@role='presentation']//td/button[contains(@class,'save-command')])[1]"));
                        //savex.Click();
                        tmsWait.Hard(1);
                        fw.ExecuteJavascript(savex);
                        tmsWait.Hard(1);
                        try
                        {
                            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")));
                            tmsWait.Hard(1);
                        }
                        catch
                        { }

                        By toastMsg = By.XPath("//div[@class='k-notification-content']");
                        string actValue = Browser.Wd.FindElement(toastMsg).Text;
                        Assert.IsTrue(actValue.Contains(msg));
                    }

                    else
                    {
                        IWebElement save = Browser.Wd.FindElement(By.XPath("//a[contains(@class,'update')]"));
                    ReUsableFunctions.clickOnWebElement(save);
                    tmsWait.Hard(2);
                    try
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")));
                        tmsWait.Hard(1);
                    }
                    catch { ReUsableFunctions.clickOnWebElement(save); }
                    string actualValue1 = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                    Assert.IsTrue(actualValue1.Contains(msg));
                    tmsWait.Hard(3);
                    }
                    break;

            }
        }


        [When(@"EAM Configuration page SNP configuration section ""(.*)"" Icon is Clicked for PlanId ""(.*)"" and PBP ""(.*)"" and Span type ""(.*)""")]
        public void WhenEAMConfigurationPageSNPConfigurationSectionIconIsClickedForPlanIdAndPBPAndSpanType(string p0, string p1, string p2, string p3)
        {
            string icon = tmsCommon.GenerateData(p0);
            string planid = tmsCommon.GenerateData(p1);
            string pbp = tmsCommon.GenerateData(p2);
            string spantype = tmsCommon.GenerateData(p3);
            switch (icon.ToLower())
            {
                case "edit":
                    IWebElement editicon = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + planid + "')]/parent::td//following-sibling::td/span[contains(.,'" + pbp + "')]/parent::td//following-sibling::td/span[contains(.,'" + spantype + "')]/parent::td//following-sibling::td/a[1]"));
                    ReUsableFunctions.clickOnWebElement(editicon);
                    tmsWait.Hard(3);
                    break;
                
                case "delete":
                    IWebElement deleteicon = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + planid + "')]/parent::td//following-sibling::td/span[contains(.,'" + pbp + "')]/parent::td//following-sibling::td/span[contains(.,'" + spantype + "')]/parent::td//following-sibling::td/a[2]"));
                    ReUsableFunctions.clickOnWebElement(deleteicon);
                    tmsWait.Hard(1);
                    break;
               
            }
        }

        [When(@"Administration Edit LIS Info Table LIS Level as ""(.*)"" Copay cat as ""(.*)"" LIS Type as ""(.*)"" Start Date as ""(.*)"" End Date as ""(.*)"" Source as ""(.*)"" Valid as ""(.*)"" Current as ""(.*)"" row is Clicked")]
        public void WhenAdministrationEditLISInfoTableLISLevelAsCopayCatAsLISTypeAsStartDateAsEndDateAsSourceAsValidAsCurrentAsRowIsClicked(string p0, string p1, string p2, string p3, string p4, string p5, string p6, string p7)
        {
           


        string LISlevel = tmsCommon.GenerateData(p0);
            string CoPay = tmsCommon.GenerateData(p1);
            string listType = tmsCommon.GenerateData(p2);
            string startDate = tmsCommon.GenerateData(p3);
            string endDate = tmsCommon.GenerateData(p4);
            string source = tmsCommon.GenerateData(p5);
            string current = tmsCommon.GenerateData(p6);
            string valid = tmsCommon.GenerateData(p7);

            IWebElement row=Browser.Wd.FindElement(By.XPath("//div[@test-id='lisInformation-grid-lisConfig']//tbody//td//span[contains(.,'" + LISlevel + "')]/parent::td//following-sibling::td[contains(.,'" + CoPay + "')]/following-sibling::td[contains(.,'" + startDate + "')]/following-sibling::td[contains(.,'" + endDate + "')]/following-sibling::td[contains(.,'" + listType + "')]/following-sibling::td/span[contains(.,'" + source + "')]/parent::td/following-sibling::td[contains(.,'" + current + "')]/following-sibling::td[contains(.,'" + valid + "')]/following-sibling::td/a[1]"));

            fw.ExecuteJavascript(row);
            tmsWait.Hard(2);
        }


        [When(@"Vefiry Administration Edit LIS Info Table LIS Level as ""(.*)"" Copay cat as ""(.*)"" LIS Type as ""(.*)"" Start Date as ""(.*)"" End Date as ""(.*)"" Source as ""(.*)"" Valid as ""(.*)"" Current as ""(.*)""")]
        public void WhenVefiryAdministrationEditLISInfoTableLISLevelAsCopayCatAsLISTypeAsStartDateAsEndDateAsSourceAsValidAsCurrentAs(string p0, string p1, string p2, string p3, string p4, string p5, string p6, string p7)
        {
            
        string LISlevel = tmsCommon.GenerateData(p0);
            string CoPay = tmsCommon.GenerateData(p1);
            string listType = tmsCommon.GenerateData(p2);
            string startDate = tmsCommon.GenerateData(p3);
            string endDate = tmsCommon.GenerateData(p4);
            string source = tmsCommon.GenerateData(p5);
            string current = tmsCommon.GenerateData(p6);
            string valid = tmsCommon.GenerateData(p7);
            //div[@test-id='lisInformation-grid-lisConfig']//tbody//td//span[contains(.,'100')]/parent::td//following-sibling::td[contains(.,'3 - 0')]/following-sibling::td[contains(.,'07/01/2019')]/following-sibling::td[contains(.,'07/31/2019')]/following-sibling::td[contains(.,'SSA')]/following-sibling::td/span[contains(.,'TRR')]/parent::td/following-sibling::td[contains(.,'Yes')]/following-sibling::td[contains(.,'Yes')]            

            bool hasrow = false;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {

                try
                {
                    hasrow = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='lisInformation-grid-lisConfig']//tbody//td[contains(.,'" + LISlevel + "')]//following-sibling::td[contains(.,'"+ CoPay + "')]//following-sibling::td[contains(.,'"+ startDate + "')]//following-sibling::td[contains(.,'"+ endDate + "')]//following-sibling::td[contains(.,'"+ listType + "')]//following-sibling::td[contains(.,'"+ source + "')]//following-sibling::td[contains(.,'"+ current + "')]//following-sibling::td[contains(.,'"+ valid +"')]")).Displayed;
                    
                }
                catch
                {

                    //IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    //ReUsableFunctions.clickOnWebElement(nextpage);
                }
            }
            else 
                {
                    int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {
                    hasrow = Browser.Wd.FindElement(By.XPath("//div[@test-id='lisInformation-grid-lisConfig']//tbody//td//span[contains(.,'" + LISlevel + "')]/parent::td//following-sibling::td[contains(.,'" + CoPay + "')]/following-sibling::td[contains(.,'" + startDate + "')]/following-sibling::td[contains(.,'" + endDate + "')]/following-sibling::td[contains(.,'" + listType + "')]/following-sibling::td/span[contains(.,'" + source + "')]/parent::td/following-sibling::td[contains(.,'" + current + "')]/following-sibling::td[contains(.,'" + valid + "')]")).Displayed;
                    break;
                }
                catch
                {

                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);
                }
                    }
                }
            //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed);

            Assert.IsTrue(hasrow, "There is no such row Present");

        }


        [Then(@"Verify EAM configuration page SNP configuration description ""(.*)"" for planid ""(.*)"" and pbp ""(.*)"" and span type ""(.*)"" is displayed")]
        public void ThenVerifyEAMConfigurationPageSNPConfigurationDescriptionForPlanidAndPbpAndSpanTypeIsDisplayed(string p0, string p1, string p2, string p3)
        {
            string description = tmsCommon.GenerateData(p0);
            string planid = tmsCommon.GenerateData(p1);
            string pbp = tmsCommon.GenerateData(p2);
            string spantype = tmsCommon.GenerateData(p3);
            IWebElement ExpandDescription = Browser.Wd.FindElement(By.XPath("//div[@test-id='snpConfigure-grid-dgSnpConfigure']//tbody//td//span[contains(.,'"+planid+"')]/parent::td//following-sibling::td//span[contains(.,'"+ pbp +"')]/parent::td//following-sibling::td//span[contains(.,'"+spantype+"')]/parent::td/parent::tr[1]/td[1]"));
            ReUsableFunctions.clickOnWebElement(ExpandDescription);
            IWebElement actualdescription = Browser.Wd.FindElement(By.XPath("//div[@test-id='snpConfigure-grid-dgSnpConfigure']//tbody//td//span[contains(.,'"+ planid +"')]/parent::td//following-sibling::td//span[contains(.,'"+pbp+"')]/parent::td//following-sibling::td//span[contains(.,'"+spantype+"')]//parent::td/parent::tr/following-sibling::tr[1]"));
            Assert.IsTrue(actualdescription.Text.Contains(description), "Description is not available");



        }


        


        [When(@"EAM Configuration page SNP configuration section History link is clicked")]
        public void WhenEAMConfigurationPageSNPConfigurationSectionHistoryLinkIsClicked()
        {
            ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.SNPConfiguration.HistoryLink);
            tmsWait.Hard(3);
        }

        [Then(@"Verify EAM configuration page SNP configuration History window is displayed")]
        public void ThenVerifyEAMConfigurationPageSNPConfigurationHistoryWindowIsDisplayed()
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                Assert.IsTrue(cfUIMODEAMConfiguration.SNPConfiguration.SNPHistoryPagAngJS.Displayed, "SNP Configuration History Page is not displayed");
            }
            else
            {
                Assert.IsTrue(cfUIMODEAMConfiguration.SNPConfiguration.SNPHistoryPage.Displayed, "SNP Configuration History Page is not displayed");
            }
        }

        [Then(@"Verify EAM configuration page Edit SNP configuration window is displayed")]
        public void ThenVerifyEAMConfigurationPageEditSNPConfigurationWindowIsDisplayed()
        {
            Assert.IsTrue(cfUIMODEAMConfiguration.SNPConfiguration.SNPEditPage.Displayed, "SNP Configuration Edit Page is not displayed");
        }

        [When(@"EAM Configuration page Edit SNP configuration window ""(.*)"" is set to ""(.*)""")]
        public void WhenEAMConfigurationPageEditSNPConfigurationWindowIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);

            switch (field.ToLower())
            {
                case "snp type":
                    ReUsableFunctions.selectValueFromDropDown(cfUIMODEAMConfiguration.SNPConfiguration.SNPEditSpanType,value);
                    //UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODEAMConfiguration.SNPConfiguration.SNPEditSpanType, value);
                    break;
                case "chronic type":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.SNPConfiguration.SNPEditChronicType);
                    // UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODEAMConfiguration.SNPConfiguration.SNPEditChronicType, value);
                   // fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'All')]/parent::li/span[@aria-label='delete']")));
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//select[@test-id='editSnp-select-drpChronicType']/preceding-sibling::div")));
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + value + "')]")));
                    break;
                case "months of eligibility":
                    ReUsableFunctions.selectValueFromDropDown(cfUIMODEAMConfiguration.SNPConfiguration.SNPEditMonthsEligibility,value);
                   // UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODEAMConfiguration.SNPConfiguration.SNPEditMonthsEligibility, value);
                    break;
                case "state":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.SNPConfiguration.SNPEditState);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODEAMConfiguration.SNPConfiguration.SNPEditState, value);
                    break;
            }
        }

        [When(@"EAM Configuration page Edit SNP configuration window ESRD check box is clicked")]
        public void WhenEAMConfigurationPageEditSNPConfigurationWindowESRDCheckBoxIsClicked()
        {
            ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.SNPConfiguration.SNPEditESRDCheckbox);
        }

        [When(@"EAM Configuration page Edit SNP configuration window ""(.*)"" button is clicked")]
        public void WhenEAMConfigurationPageEditSNPConfigurationWindowButtonIsClicked(string p0)
        {
            string icon = tmsCommon.GenerateData(p0);
            switch (icon.ToLower())
            {
                case "update":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.SNPConfiguration.SNPEditButton);
                    break;
                case "reset":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.SNPConfiguration.SNPResetButton);
                    break;
            }
        }

        [When(@"EAM Configuration page Edit SNP configuration window is closed")]
        public void WhenEAMConfigurationPageEditSNPConfigurationWindowIsClosed()
        {
            ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.SNPConfiguration.SNPEditClose);
            tmsWait.Hard(1);
        }

        [When(@"EAM Configuration page OOA section ""(.*)"" tab is clicked")]
        public void WhenEAMConfigurationPageOOASectionTabIsClicked(string p0)
        {
            string expectedTab = tmsCommon.GenerateData(p0);
            switch(expectedTab.ToLower())
            {
                case "possible ooa status":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ele = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Possible Out of Area Status')]"));
                        fw.ExecuteJavascript(ele);
                    }
                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.OOA.PossibleOutOfAreaStatus);
                                           tmsWait.Hard(2);
                    }
                    break;

                case "ooa configuration":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement ele = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Out of Area Configuration')]"));
                        fw.ExecuteJavascript(ele);
                    }
                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.OOA.OutOfAreaConfiguration);
                        tmsWait.Hard(2);
                    }
                    break;
            }
        }


        [Then(@"Varify EAM Configuration page OOA section checkbox status of ""(.*)"" for PlanId ""(.*)"" and assigned it to ""(.*)""")]
        public void ThenVarifyEAMConfigurationPageOOASectionCheckboxStatusOfForPlanIdAndAssignedItTo(string p0, string p1, string p2)
        {
            string checkboxName = tmsCommon.GenerateData(p0);
            string planid = tmsCommon.GenerateData(p1);
            string checkstatus = "false";

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement editicon=  Browser.Wd.FindElement(By.XPath("//form[@id='ooaConfigurationGridFrm']//td[contains(.,'" + planid + "')]//following-sibling::td/button[contains(@class,'edit')]"));
                editicon.Click();
                IWebElement ele = Browser.Wd.FindElement(By.XPath("//input[@id='"+ checkboxName + "1']"));
                 checkstatus = ele.Selected.ToString().ToLower();
                IWebElement CancelIcon_tmsx = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@id='gdDdlDisenrollMonth']/parent::td/following-sibling::td//button[contains(@class,'cancel')]"));
                ReUsableFunctions.clickOnWebElement(CancelIcon_tmsx);
                tmsWait.Hard(1);

            }
            else
            {
                IWebElement tvp = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + planid + "')]/parent::td/following-sibling::td/input[@ng-model='dataItem." + checkboxName + "']"));
                checkstatus = tvp.GetAttribute("checked");
            }
        
            if(checkstatus.ToLower()!="true")
            {
                checkstatus = "false";
            }
               fw.setVariable(p2, checkstatus);
            
        }



        [When(@"EAM Configuration page OOA section Edit icon is clicked for Plan Id ""(.*)""")]
        public void WhenEAMConfigurationPageOOASectionEditIconIsClickedForPlanId(string p0)
        {
            string planId = tmsCommon.GenerateData(p0);
            IWebElement EditIcon;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                int totalPagesIntheGrid = ReUsableFunctions.getTotalPages();

                
                string xpath="//form[@id='ooaConfigurationGridFrm']//td[contains(.,'"+ planId + "')]//following-sibling::td/button[contains(@class,'edit')]";
                ReUsableFunctions.clickOnGridElement(xpath);
            }

            else
            {
                EditIcon = Browser.Wd.FindElement(By.XPath("//div[@test-id='ooa-grid-ooaConfiguration']//td[contains(.,'" + planId + "')]/parent::tr//td/a"));
                ReUsableFunctions.clickOnWebElement(EditIcon);
               
            }

            tmsWait.Hard(3);
        }


        [When(@"EAM Configuration page OOA section Configuration is saved and Verify Message ""(.*)""")]
        public void WhenEAMConfigurationPageOOASectionConfigurationIsSavedAndVerifyMessage(string p0)
        {
            string expectedMessage = tmsCommon.GenerateData(p0);
            string actualValue;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement SaveIcon_tmsx = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@id='gdDdlDisenrollMonth']/parent::td/following-sibling::td//span[@class='fas fa-save']"));
                ReUsableFunctions.clickOnWebElement(SaveIcon_tmsx);
               // By toastMsg = By.XPath("//div[@class='k-notification-content']");
                //actualValue = Browser.Wd.FindElement(toastMsg).Text;
            }
            else
            {
                IWebElement SaveIcon = Browser.Wd.FindElement(By.XPath("//a[@class='k-button k-button-icontext k-primary k-grid-update']"));
            ReUsableFunctions.clickOnWebElement(SaveIcon);
            tmsWait.Hard(1);
             actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                Assert.IsTrue(actualValue.Contains(expectedMessage));
                tmsWait.Hard(3);
            }
           

        }

        [When(@"EAM Configuration page OOA section Configuration ""(.*)"" checkbox is clicked for PlanId ""(.*)""")]
        public void WhenEAMConfigurationPageOOASectionConfigurationCheckboxIsClickedForPlanId(string p0, string p1)
        {
            string checkboxName =tmsCommon.GenerateData(p0);
            string planId = tmsCommon.GenerateData(p1);
            IWebElement check = null;
            tmsWait.Hard(1);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                 check = Browser.Wd.FindElement(By.XPath("//form[@id='ooaConfigurationGridFrm']//td[contains(.,'" + planId + "')]/parent::tr//input[contains(@name,'" + checkboxName + "')]"));
            }
            else
            {
                 check = Browser.Wd.FindElement(By.XPath("//div[@test-id='ooa-grid-ooaConfiguration']//td[contains(.,'" + planId + "')]/parent::tr//input[contains(@name,'" + checkboxName + "')]"));
            }

            ReUsableFunctions.clickOnWebElement(check);
         }





        [When(@"OOA section Configuration ""(.*)"" checkbox is ""(.*)"" for PlanId ""(.*)"" but verify ""(.*)""")]
        public void WhenOOASectionConfigurationCheckboxIsForPlanIdButVerify(string p0, string p1, string p2, string p3)
        {
            string checkboxName = tmsCommon.GenerateData(p0);
            string operation = tmsCommon.GenerateData(p1);
            string planid = tmsCommon.GenerateData(p2);
            string currentstatus = tmsCommon.GenerateData(p3);
            IWebElement check;
            if (operation=="Checked")
                {
                  if(currentstatus=="false")
                    {
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        check= Browser.Wd.FindElement(By.XPath("//input[@id='" + checkboxName + "1']"));
                        fw.ExecuteJavascript(check);
                    }

                    else
                    {
                      check = Browser.Wd.FindElement(By.XPath("//div[@test-id='ooa-grid-ooaConfiguration']//td[contains(.,'" + planid + "')]/parent::tr//input[contains(@name,'" + checkboxName + "')]"));
                      ReUsableFunctions.clickOnWebElement(check);
                    }
                }

            }
            else
                {
                  if(currentstatus=="true")
                     {

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        check = Browser.Wd.FindElement(By.XPath("//input[@id='" + checkboxName + "1']"));
                        fw.ExecuteJavascript(check);
                    }

                    else
                    {
                        check = Browser.Wd.FindElement(By.XPath("//div[@test-id='ooa-grid-ooaConfiguration']//td[contains(.,'" + planid + "')]/parent::tr//input[contains(@name,'" + checkboxName + "')]"));
                       ReUsableFunctions.clickOnWebElement(check);
                    }
                }
                 }
                    
            }


        [When(@"EAM Configuration page OOA section Configuration Disenrollment Months is set to ""(.*)""")]
        public void WhenEAMConfigurationPageOOASectionConfigurationDisenrollmentMonthsIsSetTo(int p0)
        {
            string value = tmsCommon.GenerateData(p0.ToString());

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='ooaConfiguration-select-gdDdlDisenrollMonth']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + value + "']");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

            }
            else
            {


                ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("//span[@aria-label='select']")));
                ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("//ul[@data-role='staticlist']//li[contains(.,'" + value + "')]")));
            }

        }

        [When(@"EAM Configuration page OOA section Possible OOA Status Tab is Add Status is set to ""(.*)""")]
        public void WhenEAMConfigurationPageOOASectionPossibleOOAStatusTabIsAddStatusIsSetTo(string p0)
        {
            string status = tmsCommon.GenerateData(p0);
            ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.OOA.StatusTextbox, status);
        }

        [When(@"EAM Configuration page OOA section Possible OOA Status save button is clicked")]
        public void WhenEAMConfigurationPageOOASectionPossibleOOAStatusSaveButtonIsClicked()
        {
            ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.OOA.SaveBtn);
            
        }

        [When(@"EAM Configuration page OOA section Possible OOA Status save button is clicked and Verify Message ""(.*)""")]
        public void WhenEAMConfigurationPageOOASectionPossibleOOAStatusSaveButtonIsClickedAndVerifyMessage(string p0)
        {
            string expectedMessage = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {

                ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.OOA.SaveBtn);
            }
            else {

                ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.OOA.SaveBtn);
                // tmsWait.Hard(1);
                // string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;

                string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).GetAttribute("aria-label");
            Assert.IsTrue(actualValue.Contains(expectedMessage));
            tmsWait.Hard(3);

        }
        }

        [Then(@"EAM configuration page OOA section Possible OOA Status has row with status ""(.*)"" is displayed")]
        public void ThenEAMConfigurationPageOOASectionPossibleOOAStatusHasRowWithStatusIsDisplayed(string p0)
        {
            string status = tmsCommon.GenerateData(p0);
            bool hasrow = false;
            int totalPagesIntheGrid = 0;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                totalPagesIntheGrid = ReUsableFunctions.getTotalPages();
                string xpath = "//div[@role='presentation']//td[contains(.,'" + status + "')]";
               // ReUsableFunctions.clickOnGridElement(xpath);
                ReUsableFunctions.verifyGridElementPresence(xpath);
            }
            else
            {
                totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
                for (int i = 1; i <= totalPagesIntheGrid; i++)
                {
                    try
                    {
                        hasrow = Browser.Wd.FindElement(By.XPath("//div[@test-id='possibleOoaStatus-grid-possibleOoaStatus']//td/span[contains(.,'" + status + "')]")).Displayed;
                        break;
                    }
                    catch
                    {

                        IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                        ReUsableFunctions.clickOnWebElement(nextpage);
                    }

                }
                //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed);

                Assert.IsTrue(hasrow, "There is no such row Present");
            }
        }

        [When(@"EAM Configuration page On-Hold Reason section edit ""(.*)"" Component is set to ""(.*)""")]
        public void WhenEAMConfigurationPageOn_HoldReasonSectionEditComponentIsSetTo(string p0, string p1)
        {
            
        }

        [When(@"EAM Configuration page OOA section Edit Icon is clicked for status ""(.*)""")]
        public void WhenEAMConfigurationPageOOASectionEditIconIsClickedForStatus(string p0)
        {
            string status = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@test-id='possibleOoaStatus-grid-possibleOoaStatus']//td[2]/span[contains(.,'" + status + "')]/parent::td/parent::tr//td/a")));
            tmsWait.Hard(2);
        }

        [When(@"EAM Configuration page OOA section Update status is set to ""(.*)""")]
        public void WhenEAMConfigurationPageOOASectionUpdateStatusIsSetTo(string p0)
        {
            string newstatus = tmsCommon.GenerateData(p0);
            IWebElement updatestatus = Browser.Wd.FindElement(By.XPath("//div[@test-id='possibleOoaStatus-grid-possibleOoaStatus']//td[2]/input"));
            updatestatus.Clear();
            updatestatus.SendKeys(newstatus);
            updatestatus.SendKeys(Keys.Tab);
            tmsWait.Hard(2);
        }


        [When(@"EAM Configuration page OOA section Update ActiveStatus to ""(.*)""")]
        public void WhenEAMConfigurationPageOOASectionUpdateActiveStatusTo(string p0)
        {
            string activeInActivestatus = tmsCommon.GenerateData(p0);
            IWebElement checkboxx = Browser.Wd.FindElement(By.XPath("//div[@test-id='possibleOoaStatus-grid-possibleOoaStatus']//td[2]//input/parent::td/parent::tr//td[6]/input"));
            string currentstatus = checkboxx.GetAttribute("data-bind");
            if (activeInActivestatus.ToLower() == "inactive")
            {
                if (currentstatus.Contains("checked"))
                {
                    fw.ExecuteJavascript(checkboxx);
                }
            }
        }

        [When(@"EAM Configuration page OOA section Save Icon is clicked")]
        public void WhenEAMConfigurationPageOOASectionSaveIconIsClicked()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@test-id='possibleOoaStatus-grid-possibleOoaStatus']//td[2]//input/parent::td/parent::tr//a[1]")));
            tmsWait.Hard(3);
        }


        [Then(@"Verify OOA active status ""(.*)"" is set to false")]
        public void ThenVerifyOOAActiveStatusIsSetToFalse(string p0)
        {
            tmsWait.Hard(5);
            string CurrentActiveStatus = tmsCommon.GenerateData(p0);
            bool ispresent = false;
            if(CurrentActiveStatus.Equals("False"))
            {
                ispresent = true;
            }
            Assert.IsTrue(ispresent);

        }

        [Then(@"Verify OOA active status ""(.*)"" is set to true")]
        public void ThenVerifyOOAActiveStatusIsSetToTrue(string p0)
        {
            string CurrentActiveStatus = tmsCommon.GenerateData(p0);
            bool ispresent = false;
            if (CurrentActiveStatus == "True")
            {
                ispresent = true;
            }
            Assert.IsTrue(ispresent);
        }


        [When(@"Execute Query and Verify OOAStatus ""(.*)"" is displayed in database table for DB ""(.*)""")]
        public void WhenExecuteQueryAndVerifyOOAStatusIsDisplayedInDatabaseTableForDB(string p0, string DBName)
        {
            string OOAStatus = tmsCommon.GenerateData(p0);
            bool flag = false;
            IList<string> OOAStatusList = db.OutputDBResultsToList(DBName);
            foreach(string status in OOAStatusList)
            {
                if(status.Equals(OOAStatus))
                {
                    flag = true;
                    break;
                }
            }

            Assert.IsTrue(flag, "Newly Status is not added in the data base.");
        }






        [Then(@"EAM Configuration page OOA section ""(.*)"" is displayed in Status Dropdown")]
        public void ThenEAMConfigurationPageOOASectionIsDisplayedInStatusDropdown(string p0)
        {

            string status = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@aria-owns='ddOoaSuspectStatus_listbox']")));
            tmsWait.Hard(1);
            bool ispresent = false;
            try
            {
                ispresent = Browser.Wd.FindElement(By.XPath("//ul[@id='ddOoaSuspectStatus_listbox']//li[contains(.,'" + status + "')]")).Displayed;
            }

            catch
            {

            }

            Assert.IsTrue(ispresent, "OOA Status is not getting displayed in the dropdown");
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@aria-owns='ddOoaSuspectStatus_listbox']")));
        }




        [Then(@"EAM Configuration page OOA section ""(.*)"" is not displayed in Status Dropdown")]
        public void ThenEAMConfigurationPageOOASectionIsNotDisplayedInStatusDropdown(string p0)
        {
            string status = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@aria-owns='ddOoaSuspectStatus_listbox']")));
            tmsWait.Hard(1);
            bool ispresent = false;
            try
            {
                ispresent = Browser.Wd.FindElement(By.XPath("//ul[@id='ddOoaSuspectStatus_listbox']//li[contains(.,'" + status + "')]")).Displayed;
            }

            catch
            {

            }

            Assert.IsFalse(ispresent, "OOA Status is not getting displayed in the dropdown");
        }






        [When(@"EAM Configuration page OEV Letter section Configuration is set to ""(.*)""")]
        public void WhenEAMConfigurationPageOEVLetterConfigurationIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            string oevswitch = tmsCommon.GenerateData(p0.ToLower());
            bool iselementpresent=false;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                string xpath1 = "//kendo-switch[@name='switchConfigBtn']//span";
                //kendo-switch[@name='switchConfigBtn']//span[@aria-checked='true']
                iselementpresent = bool.Parse(Browser.Wd.FindElement(By.XPath(xpath1)).GetAttribute("aria-checked"));
                if (oevswitch.Equals("off"))
                {
                    if (iselementpresent)
                    {
                        Browser.Wd.FindElement(By.XPath(xpath1)).Click();
                    }
                }
                else
                {
                    if (!iselementpresent)
                    {
                        Browser.Wd.FindElement(By.XPath(xpath1)).Click();

                    }
                }
            }
            else
            {

                string xpath1 = "//div[@id='mainSwitchButtonArea']//span[contains(@class,'switch-" + oevswitch + "')]";
                //bool elementpresence = tmsWait.IsElementPresent(By.XPath(xpath1));

                if (!(Browser.Wd.FindElement(By.XPath("//span[@id='warningIcon']//i")).Displayed))       //Verifying if warning icon is dislaying then it should not enter into the code because in such case user can not edit values 
                {
                    try
                    {
                        iselementpresent = Browser.Wd.FindElement(By.XPath(xpath1)).Displayed;
                    }

                    catch
                    {
                        //ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-container km-switch-container'])[1]")));
                        Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-container km-switch-container'])[1]")).Click();
                        tmsWait.Hard(4);
                        iselementpresent = iselementpresent = Browser.Wd.FindElement(By.XPath(xpath1)).Displayed;
                    }

                    Assert.IsTrue(iselementpresent, "OEV Configuration is already switched " + oevswitch + " or Unable to switch " + oevswitch + "");
                }
            }

        }


        [When(@"EAM Configuration page OEV Letter section ""(.*)"" is set to ""(.*)""")]
        public void WhenEAMConfigurationPageOEVLetterIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(5);
            string field = tmsCommon.GenerateData(p0);
            string switchOnOff = tmsCommon.GenerateData(p1.ToLower());
            bool iselementpresent = false;


            if (ConfigFile.tenantType.Equals("tmsx"))
            {
string xpath1= "//kendo-switch[@test-id='oevletter-input-"+field.ToLower()+ "']/span";
                iselementpresent = bool.Parse(Browser.Wd.FindElement(By.XPath(xpath1)).GetAttribute("aria-checked"));
                if (switchOnOff.Equals("off"))
                {
                    if (iselementpresent)
                    {
                        Browser.Wd.FindElement(By.XPath(xpath1)).Click();
                    }
                }
                else
                {
                    if (!iselementpresent)
                    {
                        Browser.Wd.FindElement(By.XPath(xpath1)).Click();

                    }
                }

            }
            else {
                if (!(Browser.Wd.FindElement(By.XPath("//span[@id='warningIcon']//i")).Displayed))  //Verifying if warning icon is dislaying then it should not enter into the code because in such case user can not edit values 

                {
                    switch (field.ToLower())
                    {
                        case "changepbp":
                            string xpath1 = "//label[contains(.,'Change PBP')]/parent::div/div/span[contains(@class,'switch-" + switchOnOff + "')]";
                            try
                            {
                                iselementpresent = Browser.Wd.FindElement(By.XPath(xpath1)).Displayed;
                            }

                            catch
                            {
                                //ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-container km-switch-container'])[1]")));
                                Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-container km-switch-container'])[2]")).Click();
                                tmsWait.Hard(4);
                                iselementpresent = iselementpresent = Browser.Wd.FindElement(By.XPath(xpath1)).Displayed;
                            }
                            break;
                        case "eghp":
                            string xpatheghp = "//label[contains(.,'EGHP')]/parent::div/div/span[contains(@class,'switch-" + switchOnOff + "')]";
                            try
                            {
                                iselementpresent = Browser.Wd.FindElement(By.XPath(xpatheghp)).Displayed;
                            }

                            catch
                            {
                                //ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-container km-switch-container'])[1]")));
                                Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-container km-switch-container'])[3]")).Click();
                                tmsWait.Hard(4);
                                iselementpresent = iselementpresent = Browser.Wd.FindElement(By.XPath(xpatheghp)).Displayed;
                            }
                            break;
                        case "beqstatus":
                            string xpathbeq = "//label[contains(.,'Pass BEQ Status')]/parent::div/div/span[contains(@class,'switch-" + switchOnOff + "')]";
                            try
                            {
                                iselementpresent = Browser.Wd.FindElement(By.XPath(xpathbeq)).Displayed;
                            }

                            catch
                            {
                                //ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-container km-switch-container'])[1]")));
                                Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-container km-switch-container'])[4]")).Click();
                                tmsWait.Hard(4);
                                iselementpresent = iselementpresent = Browser.Wd.FindElement(By.XPath(xpathbeq)).Displayed;
                            }
                            break;
                    }
                    Assert.IsTrue(iselementpresent, "OEV Configuration is already switched " + switchOnOff + " or Unable to switch " + switchOnOff + "");

                }
            }
        }

        [When(@"EAM Configuration page OEV Letter section Save button is clicked")]
        public void WhenEAMConfigurationPageOEVLetterSectionSaveButtonIsClicked()
        {
            ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.OEVLetter.SaveBtn);
            tmsWait.Hard(3);
           
        }

        [When(@"EAM Configuration page OEV Letter section Save button is clicked and Verify Message ""(.*)""")]
        public void WhenEAMConfigurationPageOEVLetterSectionSaveButtonIsClickedAndVerifyMessage(string p0)
        {
            string expectedValue = tmsCommon.GenerateData(p0);
            ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.OEVLetter.SaveBtn);
            tmsWait.Hard(1);
            string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
            Assert.IsTrue(actualValue.Contains(expectedValue));
        }


        [When(@"EAM Configuration page OSB Configuration section ""(.*)"" is set to ""(.*)""")]
        public void WhenEAMConfigurationPageOSBConfigurationSectionIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            tmsWait.Hard(2);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {

                switch (field)
                {
                    case "Plan ID":
                        ReUsableFunctions.selectValueFromDropDownAngJS(field, value);
                        break;
                    case "PBP":
                        IWebElement elecType = Browser.Wd.FindElement(By.XPath("//label[text()='" + field + "']/parent::div//input"));

                        elecType.SendKeys(value);
                        tmsWait.Hard(3);
                        elecType.SendKeys(OpenQA.Selenium.Keys.Enter);

                        //ReUsableFunctions.selectValueFromDropDownAngJS(field, value);
                        break;
                    case "OSB Type":
                       // ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.OSBConfiguration.OSBTypeDropdownlist);
                        ReUsableFunctions.selectValueFromDropDownAngJS(field, value);
                        tmsWait.Hard(3);
                        break;
                    case "OSB Premium":
                       // ReUsableFunctions.selectValueFromDropDownAngJS(field, value);
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.OSBConfiguration.OSBPremiumTextbox, value);
                        break;
                    case "OSB Start Year":
                        ReUsableFunctions.selectValueFromDropDownAngJS(field, value);
                        //ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.OSBConfiguration.OSBStartYearDropdownlist);
                        //  fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//ul[@id='ddlOsbStartYear_listbox']/li[contains(.,'" + value + "')]")));
                        //UIMODUtilFunctions.selectDropDownValueFromGendoUIWithoutAriaOwns(cfUIMODEAMConfiguration.OSBConfiguration.OSBStartYearDropdownlist, value);
                        tmsWait.Hard(3);
                        break;
                    case "OSB End Year":
                       // ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.OSBConfiguration.OSBEndYearDropdownlist);
                        tmsWait.Hard(1);
                        ReUsableFunctions.selectValueFromDropDownAngJS(field, value);
                        // fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//ul[@id='ddlOsbEndYear_listbox']/li[contains(.,'" + value + "')]")));
                        //UIMODUtilFunctions.selectDropDownValueFromGendoUIWithoutAriaOwns(cfUIMODEAMConfiguration.OSBConfiguration.OSBEndYearDropdownlist, value);
                        break;
                }

            }
            else
            {
                switch (field.ToLower())
                {
                    case "plan id":
                        ReUsableFunctions.selectValueFromDropDown(cfUIMODEAMConfiguration.OSBConfiguration.PlanIDDropdownlist, value);
                        break;
                    case "pbp":
                        ReUsableFunctions.selectValueFromDropDown(cfUIMODEAMConfiguration.OSBConfiguration.PBPIDDropdownlist, value);
                        break;
                    case "osb type":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.OSBConfiguration.OSBTypeDropdownlist);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUIWithoutAriaOwns(cfUIMODEAMConfiguration.OSBConfiguration.OSBTypeDropdownlist, value);
                        tmsWait.Hard(3);
                        break;
                    case "osb premium":
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.OSBConfiguration.OSBPremiumTextbox, value);
                        break;
                    case "osb start year":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.OSBConfiguration.OSBStartYearDropdownlist);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//ul[@id='ddlOsbStartYear_listbox']/li[contains(.,'" + value + "')]")));
                        //UIMODUtilFunctions.selectDropDownValueFromGendoUIWithoutAriaOwns(cfUIMODEAMConfiguration.OSBConfiguration.OSBStartYearDropdownlist, value);
                        tmsWait.Hard(3);
                        break;
                    case "osb end year":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.OSBConfiguration.OSBEndYearDropdownlist);
                        tmsWait.Hard(1);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//ul[@id='ddlOsbEndYear_listbox']/li[contains(.,'" + value + "')]")));
                        //UIMODUtilFunctions.selectDropDownValueFromGendoUIWithoutAriaOwns(cfUIMODEAMConfiguration.OSBConfiguration.OSBEndYearDropdownlist, value);
                        break;
                }
            }
        }

        [When(@"Calculate ""(.*)"" and assigned to variable ""(.*)""")]
        public void WhenCalculateAndAssignedToVariable(string p0, string p1)
        {
            string expected_year = tmsCommon.GenerateData(p0);
            string Cyear = DateTime.Now.Year.ToString();
            switch(expected_year.ToLower())
            {
                case "currentyear":fw.setVariable(p1, Cyear); break;
                case "retroyear": int pastyear = (Int32.Parse(Cyear))-1; fw.setVariable(p1, pastyear.ToString()); break;
                case "futuretocurrentyear":int futureyear = (Int32.Parse(Cyear))+1; fw.setVariable(p1, futureyear.ToString()); break;
            }
        }

        [When(@"Form EffectiveDate for ""(.*)"" and assigned to variable ""(.*)""")]
        public void WhenFormEffectiveDateForAndAssignedToVariable(string p0, string p1)
        {
            string CYear = tmsCommon.GenerateData(p0);
            string EffectiveDate = "01/01/" + CYear;
            fw.setVariable(p1, EffectiveDate);
        }

        [When(@"Form EffectiveDate for Transaction(.*) ""(.*)"" and assigned to variable ""(.*)""")]
        public void WhenFormEffectiveDateForTransactionAndAssignedToVariable(string p0, string p1, string p2)
        {
            string CYear = tmsCommon.GenerateData(p1);
            string EffectiveDate = "06/01/" + CYear;
            fw.setVariable(p2, EffectiveDate);
        }



        [When(@"EAM Configuration page OSB Configuration section ""(.*)"" button is clicked")]
        public void WhenEAMConfigurationPageOSBConfigurationSectionButtonIsClicked(string p0)
        {
            string buttonclick = tmsCommon.GenerateData(p0);
            switch(buttonclick.ToLower())
            {
                case "save": ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.OSBConfiguration.SaveBtn);
                    ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")));
                    tmsWait.Hard(1);
                    //string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                    //Assert.IsTrue(actualValue.Contains(expectedMessage));
                    //tmsWait.Hard(1);
                    break;
                case "reset":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.OSBConfiguration.ResetBtn);
                    tmsWait.Hard(1);
                    break;
            }
        }

        [When(@"EAM Configuration page OSB Configuration section ""(.*)"" button is clicked anv Verify Message ""(.*)""")]
        public void WhenEAMConfigurationPageOSBConfigurationSectionButtonIsClickedAnvVerifyMessage(string p0, string p1)
        {
            string expectedValue = tmsCommon.GenerateData(p1);
            ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.OSBConfiguration.SaveBtn);
            ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")));
            tmsWait.Hard(1);
            By toastMsg = By.XPath("//div[@class='k-notification-content']");
            string actualValue = Browser.Wd.FindElement(toastMsg).Text;
            //tmsWait.Hard(1);
            //string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
            Assert.IsTrue(actualValue.Contains(expectedValue));
            tmsWait.Hard(5);
        }


        [Then(@"Verify EAM Configuration page OSB Configuration section result grid has row with PlanId ""(.*)"" and PBP ""(.*)"" and OSBType ""(.*)""")]
        public void ThenVerifyEAMConfigurationPageOSBConfigurationSectionResultGridHasRowWithPlanIdAndPBPAndOSBType(string p0, string p1, string p2)
        {
            string planid = tmsCommon.GenerateData(p0);
            string pbp = tmsCommon.GenerateData(p1.ToString());
            string osbtype = tmsCommon.GenerateData(p2);
            bool hasrow = false;
            int totalPagesIntheGrid = 0;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                string xpath = "//div[@role='presenatation']//td[contains(.,'" + planid + "')]/following-sibling::td[contains(.,'" + pbp + "')]/following-sibling::td[contains(.,'" + osbtype + "')]";
                    
                ReUsableFunctions.verifyGridElementPresence(xpath);
            }

            else
            {
                totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
                for (int i = 1; i <= totalPagesIntheGrid; i++)
                {
                    try
                    {
                        hasrow = Browser.Wd.FindElement(By.XPath("//div[@test-id='osbConfiguration-grid-osbConfiguration']//td[contains(.,'" + planid + "')]/following-sibling::td[contains(.,'" + pbp + "')]/following-sibling::td[contains(.,'" + osbtype + "')]")).Displayed;
                        break;
                    }
                    catch
                    {

                        IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                        ReUsableFunctions.clickOnWebElement(nextpage);
                    }

                }
                //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed);

                Assert.IsTrue(hasrow, "There is no such row Present");

            }
        }

        [Then(@"Verify EAM Configuration page OSB Configuration section result grid has no row with PlanId ""(.*)"" and PBP ""(.*)"" and OSBType ""(.*)"" and OSB Premium ""(.*)"" and Start Date ""(.*)"" and End Date ""(.*)""")]
        public void ThenVerifyEAMConfigurationPageOSBConfigurationSectionResultGridHasNoRowWithPlanIdAndPBPAndOSBTypeAndOSBPremiumAndStartDateAndEndDate(string p0, string p1, string p2, string p3, string p4, string p5)
        {
            string planid = tmsCommon.GenerateData(p0);
            string pbp = tmsCommon.GenerateData(p1);
            string osbtype = tmsCommon.GenerateData(p2);
            string osbpremium = tmsCommon.GenerateData(p3.ToString());
            string osbstartdate = tmsCommon.GenerateData(p4);
            string osbenddate = tmsCommon.GenerateData(p5);
            bool hasrow = false;
            int totalPagesIntheGrid = 0;
            
                try
                {
                    string xpath = "//div[@role='presentation']//td/div[contains(.,'" + planid + "')]/parent::td/following-sibling::td/div[contains(.,'" + pbp + "')]/parent::td//following-sibling::td[contains(.,'" + osbpremium + "')]";
                    //ReUsableFunctions.verifyGridElementPresence(xpath);
                    hasrow = Browser.Wd.FindElement(By.XPath(xpath)).Displayed;
                }
                catch{

                }                                         
                        
                 Assert.IsFalse(hasrow, "There is no such row Present");
                
            
        }




        [When(@"EAM Configuration page OSB Configuration section ""(.*)"" icon is clicked")]
        public void WhenEAMConfigurationPageOSBConfigurationSectionIconIsClicked(string p0)
        {
            IWebElement updateicon = Browser.Wd.FindElement(By.XPath("//button[contains(@class,'save-command')]/span"));
            ReUsableFunctions.clickOnWebElement(updateicon);
            tmsWait.Hard(2);

        }


        [When(@"EAM Configuration page OSB Configuration section ""(.*)"" icon is clicked and Verify Message ""(.*)""")]
        public void WhenEAMConfigurationPageOSBConfigurationSectionIconIsClickedAndVerifyMessage(string p0, string p1)
        {
            string icon = tmsCommon.GenerateData(p0);
            string expectedValue = tmsCommon.GenerateData(p1);
            
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                switch (icon.ToLower())
                {

                    case "update":
                        IWebElement updateicon = Browser.Wd.FindElement(By.XPath("//button[contains(@class,'save-command')]"));
                        ReUsableFunctions.clickOnWebElement(updateicon);
                        tmsWait.Hard(2);
                        ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")));
                        tmsWait.Hard(1);
                        By toastMsg = By.XPath("//div[@class='k-notification-content']");
                        string actualValue = Browser.Wd.FindElement(toastMsg).Text;
                        //  string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                         Assert.IsTrue(actualValue.Contains(expectedValue));
                        //  tmsWait.Hard(3);
                        break;

                    case "cancel":
                        IWebElement cancelicon = Browser.Wd.FindElement(By.XPath("//button[contains(@class,'cancel-command')]/span"));
                        ReUsableFunctions.clickOnWebElement(cancelicon);
                        break;
                }

            }
            else
            {
                switch (icon.ToLower())
                {

                    case "update":
                        IWebElement updateicon = Browser.Wd.FindElement(By.XPath("//a[contains(@class,'update')]"));
                        ReUsableFunctions.clickOnWebElement(updateicon);
                        tmsWait.Hard(2);
                        ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")));
                        tmsWait.Hard(1);
                        string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
                        Assert.IsTrue(actualValue.Contains(expectedValue));
                        tmsWait.Hard(3);
                        break;

                    case "cancel":
                        IWebElement cancelicon = Browser.Wd.FindElement(By.XPath("//a[contains(@class,'cancel')]"));
                        ReUsableFunctions.clickOnWebElement(cancelicon);
                        break;
                }
                tmsWait.Hard(20);
            }
        }

        [When(@"EAM Configuration page OSB Configuration section Update Popup ""(.*)"" button is clicked")]
        public void WhenEAMConfigurationPageOSBConfigurationSectionUpdatePopupButtonIsClicked(string p0)
        {
            tmsWait.Hard(30);
            string icon = tmsCommon.GenerateData(p0);
            //string expectedValue = tmsCommon.GenerateData(p1);
            switch (icon.ToLower())
            {
                case "cancel":
                    IWebElement cancelicon = Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-No']"));
                    ReUsableFunctions.clickOnWebElement(cancelicon);
                    break;
                case "ok":
                    IWebElement OkButton = Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']"));
                    ReUsableFunctions.clickOnWebElement(OkButton);
                    break;
            }
        }



        [When(@"EAM Configuration page OSB Configuration section ""(.*)"" icon is clicked for row having PlanId ""(.*)"" and PBP ""(.*)"" and OSB Type ""(.*)""")]
        public void WhenEAMConfigurationPageOSBConfigurationSectionIconIsClickedForRowHavingPlanIdAndPBPAndOSBType(string p0, string p1, string p2, string p3)
        {
            string icon = tmsCommon.GenerateData(p0);
            string planid = tmsCommon.GenerateData(p1);
            string pbp = tmsCommon.GenerateData(p2.ToString());
            string osbtype = tmsCommon.GenerateData(p3);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                switch (icon.ToLower())
                {
                    case "edit":
                        IWebElement editicon = Browser.Wd.FindElement(By.XPath("//div[@role='presentation']//td[contains(.,'" + planid + "')]/following-sibling::td[contains(.,'" + pbp + "')]/following-sibling::td[contains(.,'" + osbtype + "')]/parent::tr//button[contains(@class,'edit-command')]"));
                        ReUsableFunctions.clickOnWebElement(editicon);
                        tmsWait.Hard(3);
                        break;

                    case "delete":
                        IWebElement deleteicon = Browser.Wd.FindElement(By.XPath("//div[@role='presentation']//td[contains(.,'" + planid + "')]/following-sibling::td[contains(.,'" + pbp + "')]/following-sibling::td[contains(.,'" + osbtype + "')]/parent::tr//a[contains(@class,'remove')]"));
                        ReUsableFunctions.clickOnWebElement(deleteicon);
                        tmsWait.Hard(1);
                        break;
                    case "update":
                        IWebElement updateicon = Browser.Wd.FindElement(By.XPath("//a[contains(@class,'update')]"));
                        ReUsableFunctions.clickOnWebElement(updateicon);
                        tmsWait.Hard(3);
                        break;
                    case "cancel":
                        IWebElement cancelicon = Browser.Wd.FindElement(By.XPath("//a[contains(@class,'cancel')]"));
                        ReUsableFunctions.clickOnWebElement(cancelicon);
                        tmsWait.Hard(3);
                        break;

                }
            }
            else
            {
                switch (icon.ToLower())
                {
                    case "edit":
                        IWebElement editicon = Browser.Wd.FindElement(By.XPath("//div[@test-id='osbConfiguration-grid-osbConfiguration']//td[contains(.,'" + planid + "')]/following-sibling::td[contains(.,'" + pbp + "')]/following-sibling::td[contains(.,'" + osbtype + "')]/parent::tr//a[1]"));
                        ReUsableFunctions.clickOnWebElement(editicon);
                        tmsWait.Hard(3);
                        break;

                    case "delete":
                        IWebElement deleteicon = Browser.Wd.FindElement(By.XPath("//div[@test-id='osbConfiguration-grid-osbConfiguration']//td[contains(.,'" + planid + "')]/following-sibling::td[contains(.,'" + pbp + "')]/following-sibling::td[contains(.,'" + osbtype + "')]/parent::tr//a[2]"));
                        ReUsableFunctions.clickOnWebElement(deleteicon);
                        tmsWait.Hard(1);
                        break;
                    case "update":
                        IWebElement updateicon = Browser.Wd.FindElement(By.XPath("//a[contains(@class,'update')]"));
                        ReUsableFunctions.clickOnWebElement(updateicon);
                        tmsWait.Hard(3);
                        break;
                    case "cancel":
                        IWebElement cancelicon = Browser.Wd.FindElement(By.XPath("//a[contains(@class,'cancel')]"));
                        ReUsableFunctions.clickOnWebElement(cancelicon);
                        tmsWait.Hard(3);
                        break;

                }
            }
        }

        [When(@"EAM Configuration page OSB Configuration section edit ""(.*)"" Component is set to ""(.*)""")]
        public void WhenEAMConfigurationPageOSBConfigurationSectionEditComponentIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(3);
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                switch (field.ToLower())
                {
                    case "osb premium":
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMConfiguration.OSBConfiguration.EditOSBPremiumAngJS, value);
                        break;
                    case "osb start date":
                        // ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMConfiguration.OSBConfiguration.EditOSBStartDateAngJS, value);
                        
                        cfUIMODEAMConfiguration.OSBConfiguration.EditOSBPremiumAngJS.SendKeys(Keys.Tab);
                        IWebElement sdate = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@id='osbStartDate']//input"));
                        string[] values = value.Split('/');
                        sdate.SendKeys(values[0]);
                        sdate.SendKeys(values[1]);
                        sdate.SendKeys(values[2]);
                        break;

                    case "osb end date":
                        //ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMConfiguration.OSBConfiguration.EditOSBEndDateAngJS, value);
                        // AngularFunction.enterDate(cfUIMODEAMConfiguration.OSBConfiguration.EditOSBEndDateAngJS, value);
                        cfUIMODEAMConfiguration.OSBConfiguration.EditOSBStartDateAngJS.SendKeys(Keys.Tab);
                        IWebElement edate = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@id='osbEndDate']//input"));
                        string[] valuee = value.Split('/');
                        edate.SendKeys(valuee[0]);
                        edate.SendKeys(valuee[1]);
                        edate.SendKeys(valuee[2]);
                        edate.SendKeys(Keys.Tab);
                        break;

                }

            }
            else { 
                switch (field.ToLower())
            {
                case "osb premium":
                    ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMConfiguration.OSBConfiguration.EditOSBPremium, value);
                   break;
                case "osb start date":
                    ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMConfiguration.OSBConfiguration.EditOSBStartDate, value);
                    
                    break;
                case "osb end date":
                    ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMConfiguration.OSBConfiguration.EditOSBEndDate, value);
                   
                    break;
               
            }

            }
        }


        [When(@"EAM Configuration page OSB Configuration ""(.*)"" OSB Premium by ""(.*)""")]
        public void WhenEAMConfigurationPageOSBConfigurationOSBPremiumBy(string p0, string p1)
        {
            tmsWait.Hard(3);
            string move = tmsCommon.GenerateData(p1);
            int expected_move = Int32.Parse(move);
            string move_type = tmsCommon.GenerateData(p0);

            
                Browser.Wd.FindElement(By.XPath("//input[@name='osbPremium']")).Clear();
                Browser.Wd.FindElement(By.XPath("//input[@name='osbPremium']")).SendKeys(move);

            tmsWait.Hard(2);
            cfUIMODEAMConfiguration.OSBConfiguration.EditOSBPremium.SendKeys(Keys.Tab);
        }

        [When(@"EAM Configuration page OSB Configuration ""(.*)"" OSB Premium Amount by ""(.*)""")]
        public void WhenEAMConfigurationPageOSBConfigurationOSBPremiumAmountBy(string p0, string p1)
        {
            string move = tmsCommon.GenerateData(p1);
            int expected_move = Int16.Parse(move);
            string move_type = tmsCommon.GenerateData(p0);
            for (int i = 0; i < expected_move; i++)
            {

                Browser.Wd.FindElement(By.XPath("//span[contains(@title,'" + move_type + "')]/span")).Click();
                int ss = i;
            }

            cfUIMODEAMConfiguration.OSBConfiguration.EditOSBPremium.SendKeys(Keys.Tab);
        }



        [When(@"EAM Dashboard Letters Clear all the ""(.*)"" from the queue")]
        public void WhenEAMDashboardLettersClearAllTheFromTheQueue(string p0)
        {
            string lettername = tmsCommon.GenerateData(p0);
            string oevLetterCount="0";
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//a[@title='Dashboard']")));
            tmsWait.Hard(1);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[@test-id='eamDashboard-lbl-letters']")));
            //Notifying count of OEV Letters
            try
            {
                 oevLetterCount = Browser.Wd.FindElement(By.XPath("//label[contains(.,'" + lettername + "')]/parent::div/preceding-sibling::div/a")).Text;
            }

            catch
            {
               //  oevLetterCount = Browser.Wd.FindElement(By.XPath("//label[contains(.,'Outbound Enrollment Verification Letter')]/parent::div/preceding-sibling::div/label")).Text;
            }
            

            try
            {
                if(oevLetterCount!="0")
                {

                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//label[contains(.,'Outbound Enrollment Verification Letter')]/parent::div/preceding-sibling::div/a")));
                    tmsWait.Hard(3);
                    SelectElement plaiddropdown = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@id='inputBoxPlanId']")));
                    IList<IWebElement> plans = plaiddropdown.Options;
                    
                    int totalplans = plans.Count();
                    
                   for(int i=1;i<=totalplans;i++)
                    {
                        ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("//span[@aria-owns='inputBoxPlanId_listbox']")));
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(Browser.Wd.FindElement(By.XPath("//span[@aria-owns='inputBoxPlanId_listbox']")), plans.ElementAt(i-1).GetAttribute("value"));
                        tmsWait.Hard(2);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='letter-btn-search']")));
                        tmsWait.Hard(2);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='letter-btn-toggleRemoveAll']")));
                        tmsWait.Hard(2);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='letter-btn-remove']")));
                        //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")));
                    }
                    

                }
            }

            catch
            {

            }
        }

    }

}

