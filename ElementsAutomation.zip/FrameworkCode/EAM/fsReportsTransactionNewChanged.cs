﻿using System;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
//using System.Windows.Forms;
using TMSoR1.FrameworkCode.EAM;
using TMSoR1.FrameworkCode;


namespace TMSoR1
{
    [Binding]
    public class ReportsTransactionNewChangedFirstSteps
    {
        [When(@"user clicks on the NewChanged Transaction link")]
        public void ClicksNewChangedTransLnk()
        {
            cfReportsTransactionNewChanged.reportsLinkUIMod.Click();
            tmsWait.Hard(2);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@test-id='New/changed Transaction']")));            
        }
        [When(@"user clicks on the Run Report button")]
        public void ClickRunReportButton()
        {
            tmsWait.Hard(1);
            cfReportsTransactionNewChanged.runReportButton.Click();
        }

        [Then(@"EAM Report page Plan ID MultiSelect ""(.*)"" is selected")]
        public void ThenEAMReportPagePlanIDMultiSelectIsSelected(string p0)
        {
            tmsWait.Hard(3);
            string Planid1 = tmsCommon.GenerateData(p0);            
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@test-id='PLAN_ID']")));
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//multiselect[@test-id='PLAN_ID']//ul/li/a[contains(.,'"+ Planid1 + "')] ")));            
        }

        [When(@"EAM Report page PBP ID MultiSelect ""(.*)"" is selected")]
        public void WhenEAMReportPagePBPIDMultiSelectIsSelected(string pbpid)
        {
            string pbpID = tmsCommon.GenerateData(pbpid);

            SelectElement pbpDrp = new SelectElement(cfReportsTransactionNewChanged.pbpIDDropdownSelect);
            pbpDrp.SelectByText(pbpID);           
        }

        [When(@"EAM Report page Trans Code ""(.*)"" is selected")]
        public void WhenEAMReportPageTransCodeIsSelected(string transcode)
        {
            tmsWait.Hard(3);
            string transcodeDrp = tmsCommon.GenerateData(transcode);            
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@test-id='TRANS_CODE']")));                        
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//multiselect[@test-id='TRANS_CODE']//ul/li/a[contains(.,'" + transcodeDrp + "')]")));
        }
        [When(@"EAM Report page Effective date ""(.*)"" is selected")]
        public void WhenEAMReportPageEffectiveDateIsSelected(string effdate)
        {
            tmsWait.Hard(2);
            string GeneratedData = tmsCommon.GenerateData(effdate);
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                IWebElement effdate_new = Browser.Wd.FindElement(By.XPath("//input[@id='ReportViewerControl_ctl04_ctl07_txtValue']"));
                //fw.ExecuteJavascriptSetText(effdate_new, GeneratedData);
                effdate_new.SendKeys(GeneratedData);
            }

            else
            {
                
                fw.ExecuteJavascriptSetText(cfReportsTransactionNewChanged.effectivedate, GeneratedData);
            }
               

        }


        [When(@"EAM Send to CMS Report page ""(.*)"" is set to ""(.*)""")]
        public void WhenEAMSendToCMSReportPageIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(2);
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);

            if (ConfigFile.EnvType.Equals("ESI"))
            {
                switch (field.ToLower())
                {
                    case "effective date to":

                        if (ConfigFile.tenantType.Equals("tmsx"))
                        {
                            // value = value.Replace("/", "");
                            //By Drp = By.XPath("//label[contains(.,'Eff. Date From')]/parent::div//input");
                            //Browser.Wd.FindElement(Drp).Clear();
                            //Browser.Wd.FindElement(Drp).SendKeys(value);

                            By Drp = By.XPath("//label[contains(.,'Eff. Date From')]/parent::div//span[@role='button']");
                            AngularFunction.enterDate(Drp, value);

                            tmsWait.Hard(3);


                        }
                        else
                        {
                            IWebElement effdate_to = Browser.Wd.FindElement(By.XPath("//input[@id='ReportViewerControl_ctl04_ctl09_txtValue']"));

                            effdate_to.SendKeys(value);
                        }
                        break;
                        
                    case "effective date from":
                        if (ConfigFile.tenantType.Equals("tmsx"))
                        {
                            //value = value.Replace("/", "");
                            //By Drp = By.XPath("//label[contains(.,'Eff. Date To')]/parent::div//input");
                            //Browser.Wd.FindElement(Drp).Clear();
                            //Browser.Wd.FindElement(Drp).SendKeys(value);

                            By Drp = By.XPath("//label[contains(.,'Eff. Date To')]/parent::div//span[@role='button']");
                            AngularFunction.enterDate(Drp, value);

                            tmsWait.Hard(3);


                        }
                        else
                        {
                            IWebElement effdate_from = Browser.Wd.FindElement(By.XPath("//input[@id='ReportViewerControl_ctl04_ctl07_txtValue']"));

                            effdate_from.SendKeys(value);
                        }

                        break;
                }

            }

            else
            {

            }
               
        }



        [When(@"Transactions NewEffective Date is set to ""(.*)""")]
        public void WhenVariableTransactionsNewEffectiveDateIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            
             string GeneratedData = tmsCommon.GenerateData(p0);                         
            fw.ExecuteJavascriptSetText(EAM.TransactionsNew.EffectiveDate, GeneratedData);
        }
    }
}

