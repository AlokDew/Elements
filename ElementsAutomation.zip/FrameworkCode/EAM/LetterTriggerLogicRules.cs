﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using TMSoR1;

namespace TMSoR1.FrameworkCode.EAM
{
    class DoWork
    {
        public IDictionary<int, string[]> ReadGherkinTable(Table table)
        {
            int numberofRows = table.RowCount;
            int i = 1;
            string[] splitted;
            string[] gherkinRowArray;
            ICollection<string> header = table.Header;
            IDictionary<int, string[]> gherkinDicTable = new Dictionary<int, string[]>();
            //Adding the header to the dictonary
            gherkinDicTable.Add(0, header.ToArray());
            //Adding each row in the dictonary
               foreach (var row in table.Rows)
                {
                gherkinRowArray = row.Values.ToArray();
                for (int j=0; j< gherkinRowArray.Length;j++)
                {
                    if (gherkinRowArray[j].Contains("variable["))
                    {
                        splitted = gherkinRowArray[j].Replace(']', ' ').Split('[');

                        gherkinRowArray[j] = tmsCommon.GenerateData("Generate|variable|"+ splitted[1].Trim());
                    }
                    if (gherkinRowArray[j].Contains("value["))
                    {
                        splitted = gherkinRowArray[j].Replace(']', ' ').Split('[');
                        //gherkinRowArray[j] = ScenarioContext.Current[splitted[1].Trim()].ToString();
                        gherkinRowArray[j] = "98180";
                    }
                }
                    gherkinDicTable.Add(i, gherkinRowArray);
                    i++;
                }
            return gherkinDicTable;
        }
        public IDictionary<int, string[]> ReadUItable(IWebElement tableObj)
        {
            IDictionary<int, string[]> UIDicTable = new Dictionary<int, string[]>();
         //   string[] header;
            int i = 0;
            int DicCount=1;
            //modify code as there are some tables for which tagname thead does not exist
            try
            {
                List<string> header = new List<string>();
                //Adding header to the dictonary
                IWebElement headerObj = tableObj.FindElement(By.TagName("thead"));
                IList<IWebElement> headerColumnList = headerObj.FindElements(By.TagName("th"));
                foreach (IWebElement headerValue in headerColumnList)
                {

                    try
                    {
                        if (headerValue.Displayed)
                        {
                            header.Add(headerValue.Text);
                        }
                    }
                    catch
                    {
                        header[i] = headerValue.FindElement(By.TagName("a")).Text.ToString(); i++;
                    }

                }
                UIDicTable.Add(0, header.ToArray());
            }
            catch
            {
                DicCount = 0;
            }

            
            //Adding remaing rows to the dictonary
            IWebElement tableBody = tableObj.FindElement(By.TagName("tbody"));
            IList<IWebElement> rowObjs = tableBody.FindElements(By.TagName("tr"));
            IList<IWebElement> dataObjs = new List<IWebElement>() ;
            List<string> rowList = new List<string>();
            foreach (IWebElement row in rowObjs)
            {
                int j = 0;
                dataObjs = row.FindElements(By.TagName("td"));
                foreach (IWebElement data in dataObjs)
                {
                    try
                    {
                        if (data.Displayed)
                        {
                            rowList.Add(data.FindElement(By.TagName("span")).Text);
                        }
                    }
                    catch
                    {
                        try
                        { rowList.Add(data.FindElement(By.TagName("a")).Text); }
                        catch
                        {
                            rowList.Add(data.Text);
                        }
                    }
                }
                    UIDicTable.Add(DicCount, rowList.ToArray());
                    rowList.Clear();
                    DicCount++;
                }
            
            return UIDicTable;
        }
        public IDictionary<int, string[]> ReadUItableLegacy(IWebElement tableObj)
        {
            IDictionary<int, string[]> UIDicTable = new Dictionary<int, string[]>();
            //   string[] header;
            int i = 0;
            int DicCount = 1;
            //modify code as there are some tables for which tagname thead does not exist
            try
            {
                List<string> header = new List<string>();
                //Adding header to the dictonary
                IWebElement headerObj = tableObj.FindElement(By.TagName("tr"));
                IList<IWebElement> headerColumnList = headerObj.FindElements(By.TagName("th"));
                foreach (IWebElement headerValue in headerColumnList)
                {

                    try
                    {
                        if (headerValue.Displayed)
                        {
                            header.Add(headerValue.Text);
                        }
                    }
                    catch
                    {
                        header[i] = headerValue.FindElement(By.TagName("a")).Text.ToString(); i++;
                    }

                }
                UIDicTable.Add(0, header.ToArray());
            }
            catch
            {
                DicCount = 0;
            }


            //Adding remaing rows to the dictonary
            IWebElement tableBody = tableObj.FindElement(By.TagName("tbody"));
            IList<IWebElement> rowObjs = tableBody.FindElements(By.TagName("tr"));
            IList<IWebElement> dataObjs = new List<IWebElement>();
            List<string> rowList = new List<string>();
            foreach (IWebElement row in rowObjs)
            {
                int j = 0;
                dataObjs = row.FindElements(By.TagName("td"));
                if (dataObjs.Count != 0)
                {
                    foreach (IWebElement data in dataObjs)
                    {
                        try
                        {
                            if (data.Displayed)
                            {
                                rowList.Add(data.Text);
                            }
                        }
                        catch
                        {
                            try
                            { rowList.Add(data.FindElement(By.TagName("a")).Text); }
                            catch
                            {
                                rowList.Add(data.FindElement(By.TagName("span")).Text);
                            }
                        }
                    }
                    UIDicTable.Add(DicCount, rowList.ToArray());
                    rowList.Clear();
                    DicCount++;
                }
                } 
            
            return UIDicTable;
        }
        public void IndexofMatchedRowatUI(IDictionary<int, string[]> GherkinTable, IDictionary<int, string[]> UITable, out bool match, out int matchedRowatUI)
        {

             match = false;
             matchedRowatUI = 0;

            for (int i = 0; i < GherkinTable.Count; i++)
            {

                string[] gherkinRow = GherkinTable[i];
                for (int j = 0; j < UITable.Count; j++)
                {

                    string[] UIRow = UITable[j];
                    for (int k = 0; k < gherkinRow.Length; k++)
                    {
                        for (int l = 0; l < UIRow.Length; l++)
                        {
                            
                            if (gherkinRow[l].Equals(UIRow[l]))
                            { match = true; }
                            else if (gherkinRow[l] == "") match = true;
                            else {match = false; break; }
                            
                        }
                        if (match == false) break;
                    }
                    if (match == true) { matchedRowatUI = j; break; }
                }

            }
        }
        public void SwitchToLetterWindow()
        {
            string MainWindowHandle = "";
            string letterWindow = "";
            //Switch to Letter window
            IReadOnlyCollection<string> windows = Browser.Wd.WindowHandles;
            MainWindowHandle = Browser.Wd.CurrentWindowHandle;
            int windowcount = Browser.GetWindowCount();
            foreach (var window in windows)
            {
                if (window != MainWindowHandle)
                    letterWindow = window;
                //break;

            }
            Browser.Wd.SwitchTo().Window(letterWindow);

        }
    }

    [Binding]
    class LetterTriggerLogicRules
    {
        WebDriverWait wait = new WebDriverWait(Browser.Wd, TimeSpan.FromSeconds(20));
        TMSFrameworkHomepage frameWkPage = new TMSFrameworkHomepage();
        ExternalSystems externalSys = new ExternalSystems();
        TenantSetup tenantSetMenu = new TenantSetup();
        ManageConfiguration manageconfig = new ManageConfiguration();
        Letters letetrPage = new Letters();
        DoWork dowork= new DoWork();
        TMSFrameworkJobs jobspage = new TMSFrameworkJobs();
       // [BeforeFeature("Pre_conditions")]
        [When(@"I navigate to TCS submenu under External System  menu")]
        public void WhenINavigateToTCSSubmenuUnderExternalSystemMenu()
        {
            fw.ExecuteJavascript(frameWkPage.MenuRootAdministration);
            fw.ExecuteJavascript(externalSys.TCSSubMenu);
            Assert.IsTrue(externalSys.TCSPageheader.Displayed, "page title 'Root Administration - External Systems' is not displayed");
            Assert.IsTrue(externalSys.TCSPageTitlebar.Displayed, " Title bar 'TCS' is not displayed");
        }
        [When(@"Verify that TCS configuration exist")]
        public void WhenVerifyThatTCSConfigurationExist(Table table)
        {
            var gherkinTable = table;
            bool match = false;
            int matchedRowatUI=0;
            GlobalRef.TCSConfigExist = false;
            IDictionary<int, string[]> GherkinTable =  dowork.ReadGherkinTable(table);
            IWebElement UITableObj = externalSys.TCSConfigTable;
            IDictionary<int, string[]> UITable = dowork.ReadUItable(UITableObj);
            //for (int i = 0; i < GherkinTable.Count; i++)
            //{

            //    string[] gherkinRow = GherkinTable[i];
            //    for (int j = 0; j < UITable.Count; j++)
            //    {
            //        string[] UIRow = UITable[j];
            //        for (int k = 0; k < gherkinRow.Length; k++)
            //        {
            //            for (int l = 0; l < UIRow.Length; l++)
            //            {
            //                if (gherkinRow[l].Equals(UIRow[l]))
            //                { match = true; }
            //                else { match = false; break; }
            //            }
            //            if (match == false) break;
            //        }
            //        if (match == true) { matchedRowatUI = j; break; }
            //    }

            //}

            dowork.IndexofMatchedRowatUI(GherkinTable, UITable, out match, out matchedRowatUI);

            if (match == true && matchedRowatUI != 0)
            {
                GlobalRef.TCSConfigExist = true;
                IWebElement viewEditIcon = null;
                    viewEditIcon = Browser.Wd.FindElement(By.XPath("//div[@id='grdTcsConfiguration']//tbody/tr[" + matchedRowatUI.ToString() + "]/td/a/span[contains(@class,'square-o')]"));
                fw.ExecuteJavascript(viewEditIcon);
            }
        }

        [Then(@"ADD TCS Configuration as ""(.*)"" and Url as  ""(.*)""")]
        public void ThenADDTCSConfigurationAsAndUrlAs(string name, string url)
        {
            string TCSConfigExists = GlobalRef.TCSConfigExist.ToString();
            name = tmsCommon.GenerateData(name);
            string TCSConfigName;
            string TCSConfigUrlatUI="";
            if (TCSConfigExists.ToLower().Trim() == "true")
            {
                TCSConfigName= Browser.Wd.FindElement(By.XPath(".//*[@id='TcsFrm']/div/div/div[1]/div")).Text;
                TCSConfigName = externalSys.TCSConfigName.Text.ToString();
                TCSConfigUrlatUI = externalSys.TCSConfigUrl.Text.ToString();

                if (!TCSConfigUrlatUI.Equals(url))
                {
                    externalSys.TCSConfigUrl.Clear();
                    externalSys.TCSConfigUrl.SendKeys(url);
                }
            }
            else
            {
                IList<IWebElement> FormObject = externalSys.TCSForm.FindElements(By.TagName("Input"));
                foreach(IWebElement tcsparam in FormObject)
                {
                    if (tcsparam.GetAttribute("test-Id").ToString().ToLower().Trim().Equals("configurationnames-txt-configurationname"))
                        tcsparam.SendKeys(name);
                    else if (tcsparam.GetAttribute("test-Id").ToString().ToLower().Trim().Equals("tcs-txt-applicationurl"))
                        tcsparam.SendKeys(url);
                }
                //fw.ExecuteJavascriptSetText(externalSys.TCSConfigName, name);
                //fw.ExecuteJavascriptSetText(externalSys.TCSConfigUrl, url);
            }
            fw.ExecuteJavascript(externalSys.TCSSAVEBtnl);
            tmsWait.Hard(2);
        }
        [When(@"I navigate to Tenant Set up menu")]
        public void WhenINavigateToTenantSetUpMenu()
        {
            fw.ExecuteJavascript(frameWkPage.MenuRootAdministration);
            fw.ExecuteJavascript(tenantSetMenu.tenanatSetUpMenuLink);

        }

        [When(@"Verify that Tenant configuration exist")]
        public void WhenVerifyThatTenantConfigurationExist(Table table)
        {
            var gherkinTable = table;
            bool match = false;
            int matchedRowatUI = 0;

            IDictionary<int, string[]> GherkinTable = dowork.ReadGherkinTable(table);
            IWebElement UITableObj = tenantSetMenu.tenanatSetUpTable;
            IDictionary<int, string[]> UITable = dowork.ReadUItable(UITableObj);
            dowork.IndexofMatchedRowatUI(GherkinTable, UITable, out match, out matchedRowatUI);

            if (match == true && matchedRowatUI != 0)
            {
                IWebElement manageConfigLink = null;
                manageConfigLink = Browser.Wd.FindElement(By.XPath("//div[@id='grdTenantSetUp']//tbody/tr[" + matchedRowatUI.ToString() + "]/td/a[contains(text(),'Manage Configuration')]"));
                fw.ExecuteJavascript(manageConfigLink);
                WebDriverWait waiting = new WebDriverWait(Browser.Wd,TimeSpan.FromSeconds( 40));
                waiting.Until(ExpectedConditions.ElementToBeClickable(tenantSetMenu.AddTenantButton));
            }

        }

        [When(@"Tenant Set up ""(.*)"" is selected at TCS Dropdown")]
        public void WhenTenantSetUpIsSelectedAtTCSDropdown(string ValueToSelect)
        {
            ValueToSelect = tmsCommon.GenerateData(ValueToSelect);
            string xpath = ".//*[@id='ddlTcs_listbox']/li[text() = '"+ ValueToSelect .Trim()+ "']";
            tmsWait.Hard(7);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(xpath)));
            tmsWait.Hard(3);

            fw.ExecuteJavascript(manageconfig.SaveButton);
            WebDriverWait waiting = new WebDriverWait(Browser.Wd, TimeSpan.FromSeconds(40));
            waiting.Until(ExpectedConditions.ElementToBeClickable(tenantSetMenu.AddTenantButton));

            Assert.IsTrue(tenantSetMenu.ToastMessage.Displayed, "Configuration is not saved successfully");
        }
        [When(@"I have navigated to Letter name ""(.*)""")]
        public void WhenIHaveNavigatedToLetterName(string Lettername)
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.LinkText(Lettername.Trim())));
            tmsWait.Hard(5);
        }

        [When(@"below row is diplayed for ""(.*)"" at Letter queue page")]
        public void WhenBelowRowIsDiplayedForAtLetterQueuePage(string MBI, Table table)
        {

            MBI = tmsCommon.GenerateData(MBI);
            var gherkinTable = table;
            bool match = false;
            string checkboxXpath = ".//td[contains(.,'"+MBI+"')]/parent::tr/td/input[@id = 'ctl00_ctl00_MainMasterContent_MainContent_dgLetters_ctl03_chk']";
            //IDictionary<int, string[]> GherkinTable = dowork.ReadGherkinTable(table);
            //IWebElement UITableObj = letetrPage.OldLettersQueueTable;
            //IDictionary<int, string[]> UITable = dowork.ReadUItable(UITableObj);

            //dowork.IndexofMatchedRowatUI(GherkinTable, UITable, out match, out matchedRowatUI);
            try {
                if (Browser.Wd.FindElement(By.XPath(".//td[contains(.,'" + MBI + "')]")).Displayed)
                {
                    IWebElement checkboxSend = Browser.Wd.FindElement(By.XPath(checkboxXpath));
                        if (checkboxSend.Enabled)
                        {
                       fw.ExecuteJavascript(letetrPage.DeSelectAll);
                        tmsWait.Hard(7);
                        checkboxSend = Browser.Wd.FindElement(By.XPath(checkboxXpath));

                            fw.ExecuteJavascript(checkboxSend);
                            //fw.ExecuteJavascript(letetrPage.PreviewButton);
                        ////wait untill letter preview page opens
                        //wait.Until(ExpectedConditions.ElementIsVisible(By.Id("btnSubmitJob")));
                        //tmsWait.Hard(5);


                        ////Switch to Letter window
                        //IReadOnlyCollection<string> windows = Browser.Wd.WindowHandles;
                        //MainWindowHandle = Browser.Wd.CurrentWindowHandle;
                        //int windowcount = Browser.GetWindowCount();
                        //foreach(var window in windows)
                        //{
                        //    if (window != MainWindowHandle)
                        //        letterWindow = window;
                        //        //break;
                             
                        //}Browser.Wd.SwitchTo().Window(letterWindow);




                            //switch to letter content frame
                            //Browser.Wd.SwitchTo().Frame(Browser.Wd.FindElement(By.Id("form1")));
                        }                    
                }
            }
            catch(Exception e)
            {
                Console.WriteLine("MBI is not displayed at letter page");
            }
        }

        [When(@"Letter Queue Page Preview button is clicked")]
        [Then(@"Letter Queue Page Preview button is clicked")]
        public void WhenLetterQueuePagePreviewButtonIsClicked()
        {
            fw.ExecuteJavascript(letetrPage.PreviewButton);
            tmsWait.Hard(5);
            //user switch to letter window
            dowork.SwitchToLetterWindow();
        }

        [When(@"en logged in to EAM with Config File Parameters")]
        public void WhenEnLoggedInToEAMWithConfigFileParameters()
        {
            //content for different line
            TMSoR1.EAM.EAMLogin.UserID.Clear();
            TMSoR1.EAM.EAMLogin.UserID.SendKeys(ConfigFile.UserId);
            TMSoR1.EAM.EAMLogin.Password.Clear();
            TMSoR1.EAM.EAMLogin.Password.SendKeys(ConfigFile.Password);
            TMSoR1.EAM.EAMLogin.Submit.Click();
        }
        [When(@"Generate Letter button is clicked")]
        [Given(@"Generate Letter button is clicked")]
        public void GivenGenerateLetterButtonIsClicked()
        {
            //wait.Until(ExpectedConditions.ElementIsVisible(By.Id("UpdatePanel1")));
            try { letetrPage.GenerateButton.Click();  } catch {  }
            //letetrPage.GenerateButton.Click();
            Browser.Wd.SwitchTo().Alert().Accept();
            tmsWait.Hard(2);
            ReadLetterGenerationID();
        }
        public void ReadLetterGenerationID()
        {
            string xpath = "//span[contains(.,'Letter Generation job is requested on RequestID')]";
            string message =  Browser.Wd.FindElement(By.XPath(xpath)).Text;
            string[] message1 = message.Split(':');
            string jobID = message1[1].Trim();
            GlobalRef.LetterJOBID = jobID;
        }

        [When(@"Letter window is closed")]
        [Given(@"Letter window is closed")]
        public void GivenLetterWindowIsClosed()
        {
            string windowTitle = "E*ENRL Letter";
            IReadOnlyCollection<string> windows = new List<string>();
            windows = Browser.Wd.WindowHandles;
            foreach(string window in windows)
            {
                if(Browser.Wd.SwitchTo().Window(window).Title.Equals(windowTitle))
                {
                    Browser.Wd.SwitchTo().Window(window).Close();
                    break;
                }
            }
            Browser.SwitchToParentWindow();
        }

        [Then(@"Correspondence History Table Review button is clicked for ""(.*)""")]
        public void ThenCorrespondenceHistoryTableReviewButtonIsClickedFor(string LetterName, Table table)
        {
            TMSoR1.MembersNewTabCorrespondence corrObj = new MembersNewTabCorrespondence();

            var gherkinTable = table;
            bool match = false;
            int matchedRowatUI = 0;

            
            IDictionary<int, string[]> GherkinTable = dowork.ReadGherkinTable(table);
            IWebElement UITableObj = corrObj.CorrespondenceHistory;
            IDictionary<int, string[]> UITable = dowork.ReadUItableLegacy(UITableObj);

            dowork.IndexofMatchedRowatUI(GherkinTable, UITable, out match, out matchedRowatUI);
            string ReviewLinkXpath = ".//*[@id='ctl00_ctl00_MainMasterContent_MainContent_ucCorrespondence_gvCORR']//tr["+( matchedRowatUI+1).ToString() + "]//td/a[text() = 'Review']";
            try { fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(ReviewLinkXpath))); } catch { }
            tmsWait.Hard(15);
            dowork.SwitchToLetterWindow();
            Browser.Wd.Close();
                Browser.SwitchToParentWindow();
            //TMSoR1.EAM.EAMLogin.UserID.Clear();
            //TMSoR1.EAM.EAMLogin.UserID.SendKeys(ConfigFile.UserId);
            //TMSoR1.EAM.EAMLogin.Password.Clear();
            //TMSoR1.EAM.EAMLogin.Password.SendKeys(ConfigFile.Password);
            //TMSoR1.EAM.EAMLogin.Submit.Click();
            //user switch to letter window
            
        }
        [When(@"Verify Generated letter contains ""(.*)""")]
        [Then(@"Verify Generated letter contains ""(.*)""")]
        public void ThenVerifyGeneratedLetterContains(string ValueToVerify)
        {
            
            ValueToVerify = tmsCommon.GenerateData(ValueToVerify);
            string xpath = ".//xhtml:div[contains(.,'"+ ValueToVerify.ToString().Trim() + "')]";
            try
            {

                var element = Browser.Wd.FindElement(By.ClassName("textLayer"));
               string innert =  Browser.Wd.PageSource.ToString();
                innert.Contains(ValueToVerify.ToString().Trim());
                var innerHtml = element.GetAttribute("innerHTML").ToString();
                List<IWebElement> listofObj = new List<IWebElement>();
            listofObj = Browser.Wd.FindElements(By.ClassName("textLayer")).ToList();
            
                Assert.IsTrue(Browser.Wd.FindElement(By.XPath(xpath)).Displayed, ValueToVerify + " is not displayed");
            }
            catch(Exception e) { }
        }
        [When(@"Navigate to ""(.*)"" page at TMSFramework  application")]
        [Then(@"Navigate to ""(.*)"" page at TMSFramework  application")]
        [When(@"Navigate to ""(.*)"" page at TMSFramework  application")]
        [Given(@"Navigate to ""(.*)"" page at TMSFramework  application")]
        public void WhenNavigateToPageAtTMSFrameworkApplication(string TMSADminPage)
        {
            string TMSFramework = "Framework|";
            string jobXpath = ".//li[@test-id='menu-29']/a";
            //IWebElement productMenuList = Browser.Wd.FindElement(By.Id("ctl00_ctl00_ProductMenu1_Menu1-menuItem000-subMenu"));
            IWebElement LogoIcon = Browser.Wd.FindElement(By.Id("ctl00_ctl00_ProductMenu1_Menu1-menuItem000"));
            fw.ExecuteJavascript(LogoIcon);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath(".//td[contains(.,'Framework|')]")));
            wait.Until(ExpectedConditions.ElementIsVisible(By.XPath(jobXpath)));
            TMSFrameworkHomepage menu = new TMSFrameworkHomepage();
            if (TMSADminPage.ToUpper().Trim().Equals("JOBS"))
                fw.ExecuteJavascript(menu.MenuJobs);
            tmsWait.Hard(10);

        }
        [When(@"select ""(.*)"" in the Filter by Job field")]
        public void WhenSelectInTheFilterByJobField(string ValuetoSelect)
        {
            tmsWait.Hard(10);
            //wait.Until(ExpectedConditions.ElementIsVisible(By.CssSelector("test-id='jobs-lbl-filteredbyjob'")));
             SelectElement filterbyJob = new SelectElement(jobspage.FilterByJobDrpdwn);
                filterbyJob.SelectByText(ValuetoSelect);

        }

        [When(@"verify that below row is displayed for generated letter")]
        public void WhenVerifyThatBelowRowIsDisplayedForGeneratedLetter(Table table)
        {

            string jobID = GlobalRef.LetterJOBID.ToString();
            string xpath = "//a[contains(.,'"+ jobID + "')]/parent::td/following-sibling::td/span[contains(.,'Complete')]";
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath(xpath)).Displayed, jobID + " is not completed");

            //var gherkinTable = table;
            //bool match = false;
            //int matchedRowatUI;
            //IDictionary<int, string[]> GherkinTable = dowork.ReadGherkinTable(table);
            //IWebElement UITableObj = jobspage.JobsResultGrid;
            //IDictionary<int, string[]> UITable = dowork.ReadUItable(UITableObj);

            //dowork.IndexofMatchedRowatUI(GherkinTable, UITable, out match, out matchedRowatUI);
            //Assert.IsTrue(match, jobID + " is not completed");
        }

        [When(@"Letter Templates ""(.*)"" letter is selected")]
        public void WhenLetterTemplatesLetterIsSelected(string LetterName)
        {
            SelectElement letterDropdwn = new SelectElement(TMSoR1.EAM.LettersTemplate.LettersDropdown);
            letterDropdwn.SelectByText(LetterName);
        }

        [When(@"Letter Templates ""(.*)"" Effective Year is selected")]
        public void WhenLetterTemplatesEffectiveYearIsSelected(string efectiveDate)
        {
            DateTime effDate = new DateTime(); 
            efectiveDate = tmsCommon.GenerateData(efectiveDate);
            try
            { effDate = Convert.ToDateTime(efectiveDate); }
            catch { }
            string year = effDate.Year.ToString();
            SelectElement effdateDrpdwn = new SelectElement(TMSoR1.EAM.LettersTemplate.EffectiveYearDropdown);
            effdateDrpdwn.SelectByText(year);
        }
        [When(@"Letter Templates OK button is clicked")]
        public void WhenLetterTemplatesOKButtonIsClicked()
        {
            fw.ExecuteJavascript(TMSoR1.EAM.LettersTemplate.OkButton);
            tmsWait.Hard(3);
        }
        [When(@"Letter Templates ""(.*)"" is selected for PlanID ""(.*)"" and PBP ""(.*)""")]
        public void WhenLetterTemplatesIsSelectedForPlanIDAndPBP(string TemplateName, string PlanID, string PBP)
        {
            IWebElement tempObj;
            bool found = false;
            PlanID = tmsCommon.GenerateData(PlanID);
            PBP = tmsCommon.GenerateData(PBP);
            PBP = PBP.Substring(0, 3);
            string xpathchechBox = ".//*[@id='ctl00_ctl00_MainMasterContent_MainContent_GridView1']//td[text()='H0002']/following-sibling::td[text()='010']/following-sibling::td";
            IList<IWebElement> checkObjList = new List<IWebElement>();

            try
            { checkObjList = Browser.Wd.FindElements(By.XPath(xpathchechBox)); }
            catch { }

            foreach(var checkObj in checkObjList)
            {
                try
                {
                    tempObj = checkObj.FindElement(By.TagName("span"));
                    string ObjPlaniD = tempObj.GetAttribute("planid");
                    string ObjPBP = tempObj.GetAttribute("pbpid");
                    string ObjTemplateName = tempObj.GetAttribute("templatename");
                    if (ObjPlaniD.Equals(PlanID) && ObjPBP.Equals(PBP.Trim()) && ObjTemplateName.Equals(TemplateName))
                    {
                        if(!tempObj.FindElement(By.TagName("input")).Selected)
                        fw.ExecuteJavascript(tempObj.FindElement(By.TagName("input"))); found = true; break;
                    }

                }
                catch { }
            }if (found == false) Assert.IsTrue(found, TemplateName + " is not configured");
            //IWebElement GridObj = TMSoR1.EAM.LettersTemplate.LetterTemplateTable;
            //IList<IWebElement> GridRows = new List<IWebElement>();
            //GridRows= GridObj.FindElements(By.TagName("tr"));
            //IList<IWebElement> Rowdata = new List<IWebElement>();
            //Rowdata = GridObj.FindElements(By.TagName("td"));
            

            //foreach (var row in GridRows)
            //{
            //    foreach(var data in Rowdata)
            //    {
            //        try {
            //            tempObj = data.FindElement(By.TagName("span"));
            //            string ObjPlaniD = tempObj.GetAttribute("planid");
            //            string ObjPBP = tempObj.GetAttribute("pbpid");
            //            string ObjTemplateName = tempObj.GetAttribute("templatename");
            //            if (ObjPlaniD.Equals(PlanID) && ObjPBP.Equals(PBP.Trim()) && ObjTemplateName.Equals(TemplateName))
            //            {
            //                fw.ExecuteJavascript(tempObj.FindElement(By.TagName("input")));found = true; break;
            //            }
                        
            //        }
            //        catch { }
                    
            //    }if (found == true) break;
            //}Assert.IsTrue(found, "template is not saved");
        }
        [When(@"Letter Templates SAVE button is clicked")]
        public void WhenLetterTemplatesSAVEButtonIsClicked()
        {
            fw.ExecuteJavascript(TMSoR1.EAM.LettersTemplate.TemplateSaveButton);
            tmsWait.Hard(10);
            
        }
        [When(@"Letter Templates ""(.*)"" message is displayed")]
        public void WhenLetterTemplatesMessageIsDisplayed(string p0)
        {
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[contains(.,'Successfully saved')]")).Displayed, "Template is not saved successfully");
        }

    }


}
