﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using System.Collections.Generic;
using OpenQA.Selenium.Support.UI;
using System.IO;
using TMSoR1.FrameworkCode;
using System.Linq;
using System.Data.SqlClient;
using System.Windows;
using System.Web;
using TMSoR1;
using TMSoR1.FrameworkCode;

namespace TMSoR1
{
    [Binding]
    class fsEAMWorkflow_1
    {
        [When(@"Notify EAM WorkflowDashboard count for queue ""(.*)"" and assigned to variable ""(.*)""")]
        public void WhenNotifyEAMWorkflowDashboardCountForQueueAndAssignedToVariable(string p0, string p1)
        {
            string workflowQueue = tmsCommon.GenerateData(p0);
            IWebElement WorkflowQueueNumberElements = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='workflowQueue-grid-workflow']//td[text()='" + workflowQueue + "']/preceding-sibling::td//a"));
            string workflowQueueCount = WorkflowQueueNumberElements.Text;
            fw.setVariable(p1, workflowQueueCount);    
        }

        [Then(@"Verify EAM WorkflowDashboard count for queue ""(.*)"" has changed from ""(.*)""")]
        public void ThenVerifyEAMWorkflowDashboardCountForQueueHasChangedFrom(string p0, string p1)
        {
            string workflowQueue = "Enrollment Rejection Queue";// tmsCommon.GenerateData(p0);
            string pQueueCount = tmsCommon.GenerateData(p1);
            int previousQueueCount = Int32.Parse(pQueueCount);
            IWebElement WorkflowQueueNumberElements = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='workflowQueue-grid-workflow']//td[text()='" + workflowQueue + "']/preceding-sibling::td//a"));
            int currentQueueCount =Int32.Parse(WorkflowQueueNumberElements.Text);
            Assert.IsTrue(currentQueueCount > previousQueueCount, "Workflow Queue count has not changed please review Worflow Trigger point or Qualifiers ");
            Console.WriteLine("Workitem has inserted into " + workflowQueue + " Queue and count has also increased as expected"); 
        }

        [Then(@"Verify EAM WorkflowDashboard queue ""(.*)"" has new Workitem as ""(.*)""")]
        public void ThenVerifyEAMWorkflowDashboardQueueHasNewWorkitemAs(string p0, string p1)
        {
            string workflowQueue = tmsCommon.GenerateData(p0);
            string workitemKey = tmsCommon.GenerateData(p1);
            //IWebElement WorkflowQueueNumberElements = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='workflowQueue-grid-workflow']//td[text()='" + workflowQueue + "']/preceding-sibling::td//a"));
            //fw.ExecuteJavascript(WorkflowQueueNumberElements);
            EAM.WFDashboard.SearchMessageIdTextBox.Clear();
            tmsWait.Hard(3);
            EAM.WFDashboard.SearchMessageIdTextBox.SendKeys(workitemKey);
            tmsWait.Hard(2);
            fw.ExecuteJavascript(EAM.WFDashboard.MessageIdSearchButton);
            string actualWorkItemKey="";
            tmsWait.Hard(3);
            try
            {
                 actualWorkItemKey = EAM.WFDashboard.FoundWorkItemKey.Text;
            }
            catch
            {
                Console.WriteLine("There are no such Workitem is displayed. Please review your search");
            }

            Assert.AreEqual(actualWorkItemKey, workitemKey, "Searched Workitem Key is incorrect.");
            Console.WriteLine("Workitem is found successfully in "+ workflowQueue + " Queue");
        }


        [When(@"EAM WorkflowDashboard queue ""(.*)"" count is clicked")]
        public void WhenEAMWorkflowDashboardQueueCountIsClicked(string p0)
        {
            string workflowQueue = tmsCommon.GenerateData(p0);
            IWebElement WorkflowQueueNumberElements = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='workflowQueue-grid-workflow']//td[text()='" + workflowQueue + "']/preceding-sibling::td//a"));
            fw.ExecuteJavascript(WorkflowQueueNumberElements);
        }



        [When(@"I get the MemCodNum value and assigned it to variable ""(.*)""")]
        public void WhenIGetTheMemCodNumValueAndAssignedItToVariable(string p0)
        {
            string memberNumber = cfUIMODEAMAdmin.StatusOverride.MemberNumber.Text;
            tmsWait.Hard(1);
            fw.setVariable(p0, memberNumber);
        }


        [When(@"I get the TransID value for TRR workitem and assigned it to variable ""(.*)""")]
        public void WhenIGetTheTransIDValueForTRRWorkitemAndAssignedItToVariable(string p0)
        {
            string tid = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='statusoverride-grid-transaction']//td[text()='121']//preceding-sibling::td[@data-kendo-grid-column-index='2']")).Text;
            tmsWait.Hard(1);
            fw.setVariable(p0, tid);
        }

        [When(@"I get the TransID value having Transaction Status is ""(.*)"" and assigned it to variable ""(.*)""")]
        public void WhenIGetTheTransIDValueHavingTransactionStatusIsAndAssignedItToVariable(string p0, string p1)
        {
            string tstatus = tmsCommon.GenerateData(p0);
            string tid = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='statusoverride-grid-transaction']//td[text()='"+ tstatus + "']//preceding-sibling::td[@data-kendo-grid-column-index='2']")).Text;
            tmsWait.Hard(1);
            fw.setVariable(p1, tid);
        }



        [When(@"Create a ""(.*)"" Workitem key by using ""(.*)"" and assigned it to variable ""(.*)""")]
        public void WhenCreateAWorkitemKeyByUsingAndAssignedItToVariable(string p0, string p1, string p2)
        {
            string workitemtype = tmsCommon.GenerateData(p0);
            string workitemtkeycontent = tmsCommon.GenerateData(p1);
            string workitem="";
            switch (workitemtype.ToLower())
            {
                case "member":  workitem = "Member" + workitemtkeycontent; break;
                case "transaction": workitem = "Transaction" + workitemtkeycontent; break;
                case "trr": workitem = "Trr" + workitemtkeycontent; break;
            }

            fw.setVariable(p2, workitem);
        }

     
        [When(@"Notify EAM WorkflowStartPanel WorkitemKey number and assigned it to variable ""(.*)""")]
        public void WhenNotifyEAMWorkflowStartPanelWorkitemKeyNumberAndAssignedItToVariable(string p0)
        {
            string workitemkey = EAM.WFTaskbarOperations.WorkItemKey.Text;
            tmsWait.Hard(1);
            fw.setVariable(p0, workitemkey);
        }


        [When(@"Notify EAM WorkflowStartPanel Currently Active Queue and assigned it to variable ""(.*)""")]
        public void WhenNotifyEAMWorkflowStartPanelCurrentlyActiveQueueAndAssignedItToVariable(string p0)
        {
            string workitemkey = EAM.WFTaskbarOperations.WorkflowActiveQueue.Text;
            tmsWait.Hard(1);
            fw.setVariable(p0, workitemkey);
        }




        [Then(@"Verify EAM WorkflowStartPanel Workitem Key has changed from Previous Workitem key ""(.*)""")]
        public void ThenVerifyEAMWorkflowStartPanelWorkitemKeyHasChangedFromPreviousWorkitemKey(string p0)
        {
            string previousWorkitem = tmsCommon.GenerateData(p0);
            string currentWorkitem = EAM.WFTaskbarOperations.WorkItemKey.Text;
            tmsWait.Hard(1);
            Assert.AreNotEqual(previousWorkitem, currentWorkitem, "Workitem Key is not displaying next Workitem key");
        }

        [Then(@"Verify EAM WorkflowStartPanel Workitem Key has not changed from Previous Workitem key ""(.*)""")]
        public void ThenVerifyEAMWorkflowStartPanelWorkitemKeyHasNotChangedFromPreviousWorkitemKey(string p0)
        {
            string previousWorkitem = tmsCommon.GenerateData(p0);
            string currentWorkitem = EAM.WFTaskbarOperations.WorkItemKey.Text;
            tmsWait.Hard(1);
            Assert.AreEqual(previousWorkitem, currentWorkitem, "Both Workitem Key are not same it has changed to next Workitem key");
        }

        [When(@"EAM WorkflowStartPanel Workflow Action ""(.*)"" is selected")]
        public void WhenEAMWorkflowStartPanelWorkflowActionIsSelected(string p0)
        {
            tmsWait.Hard(1);
            string workflowActions = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(EAM.WFTaskbarOperations.WorkFlowActionDropDown);
            //tmsWait.Hard(2);
            By typeapp = By.XPath("//li[text()='" + workflowActions + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);
        }


        [When(@"EAM WorkflowStartPanel Workflow Action Submit button is clicked")]
        public void WhenEAMWorkflowStartPanelWorkflowActionSubmitButtonIsClicked()
        {
            fw.ExecuteJavascript(EAM.WFTaskbarOperations.WorkFlowActionSubmitButton);
            tmsWait.Hard(3);
            try
            {
                fw.ExecuteJavascript(EAM.WFTaskbarOperations.WorkFlowActionConfirmationYesButton);
                tmsWait.Hard(3);
            }
            catch
            {
                Console.WriteLine("No Confirmation Message is not displayed");
            }

            tmsWait.Hard(5);
        }


        [When(@"EAM WorkflowStartPanel Workflow Action Reason ""(.*)"" is selected")]
        public void WhenEAMWorkflowStartPanelWorkflowActionReasonIsSelected(string p0)
        {
            string Reason = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(EAM.WFTaskbarOperations.WorkFlowActionReason);
            By typeapp = By.XPath("//li[text()='" + Reason + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(2);
        }

        [When(@"EAM WorkflowStartPanel Workflow Item Manually Route to Queue ""(.*)""")]
        public void WhenEAMWorkflowStartPanelWorkflowItemManuallyRouteToQueue(string p0)
        {
            string queue = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(EAM.WFTaskbarOperations.WorkFlowActionQueueDropDown);
            By typeapp = By.XPath("//li[text()='" + queue + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
        }


        [Then(@"View Edit Transaction page Search Result First MBI is copied and assigned it to ""(.*)""")]
        public void ThenViewEditTransactionPageSearchResultFirstMBIIsCopiedAndAssignedItTo(string p0)
        {
            string firstMBI = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='transSearch-grid-transactions']//tr[1]/td[@data-kendo-grid-column-index='1']")).Text;
            tmsWait.Hard(1);
            fw.setVariable(p0, firstMBI);
        }

        [Then(@"View Edit Transaction page Search Result Second MBI is copied and assigned it to ""(.*)""")]
        public void ThenViewEditTransactionPageSearchResultSecondMBIIsCopiedAndAssignedItTo(string p0)
        {
            string firstMBI = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='transSearch-grid-transactions']//tr[2]/td[@data-kendo-grid-column-index='1']")).Text;
            tmsWait.Hard(1);
            fw.setVariable(p0, firstMBI);
        }

        [Then(@"View Edit Transaction page Edit Icon is clicked for the Second transaction")]
        public void ThenViewEditTransactionPageEditIconIsClickedForTheSecondTransaction()
        {
            IWebElement firstEditIcon = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='transSearch-grid-transactions']//tr[2]/td[@data-kendo-grid-column-index='0']//following-sibling::td/a"));
            fw.ExecuteJavascript(firstEditIcon);
            tmsWait.Hard(10);
        }


        [Then(@"View Edit Transaction page Edit Icon is clicked for the first transaction")]
        public void ThenViewEditTransactionPageEditIconIsClickedForTheFirstTransaction()
        {
            IWebElement firstEditIcon = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='transSearch-grid-transactions']//tr[1]/td[@data-kendo-grid-column-index='0']//following-sibling::td/a"));
            fw.ExecuteJavascript(firstEditIcon);
            tmsWait.Hard(10);
        }

        [Then(@"View Edit Transaction page Resubmit button is clicked")]
        public void ThenViewEditTransactionPageResubmitButtonIsClicked()
        {
            fw.ExecuteJavascript(EAM.TransactionsNew.Resubmit);
            tmsWait.Hard(5);
        }


        [When(@"I get the MBI from Member View Edit page and assigned it to ""(.*)""")]
        public void WhenIGetTheMBIFromMemberViewEditPageAndAssignedItTo(string p0)
        {
            string mb= EAM.MembersViewEdit.MemberViewEditHIC.GetAttribute("value");
            fw.setVariable(p0, mb);
        }

        [Then(@"Verify EAM WorkflowStartPanel Workflow Message ""(.*)"" is displayed")]
        public void ThenVerifyEAMWorkflowStartPanelWorkflowMessageIsDisplayed(string p0)
        {
            try
            {
                if (EAM.WFTaskbarOperations.WorkFlowActionNoWorkItemKey.Displayed)
                {
                    string Actualerrormsg = EAM.WFTaskbarOperations.WorkFlowActionEmptyPageError.Text;
                    Assert.AreEqual(p0, Actualerrormsg, "Error Message is displayed as expected");

                }
            }
            catch (NoSuchElementException)
            {
                fw.ConsoleReport("There is atleast a WorkItem key");
            }
        }

        [Then(@"Verify EAM ""(.*)"" Menu is displayed for Role ""(.*)""")]
        public void ThenVerifyEAMMenuIsDisplayedForRole(string p0, string p1)
        {
            string menu = tmsCommon.GenerateData(p0);
            string role = tmsCommon.GenerateData(p1);
            bool ispresent = false;
            try
            {
                ispresent = Browser.Wd.FindElement(By.XPath("//div[@title='Workflow']")).Displayed;

            }
            catch
            {
                Console.WriteLine("" + menu + "  Menu in EAM is not getting displayed for Role " + role + " ");
            }

            Assert.IsTrue(ispresent, "" + menu + " menu is not gettting displayed for Role " + role + " ");
        }

        [Then(@"Verify EAM ""(.*)"" Menu is Not displayed for Role ""(.*)""")]
        public void ThenVerifyEAMMenuIsNotDisplayedForRole(string p0, string p1)
        {
            string menu = tmsCommon.GenerateData(p0);
            string role = tmsCommon.GenerateData(p1);
            bool ispresent = false;
            try
            {
                ispresent = Browser.Wd.FindElement(By.XPath("//div[@title='Workflow']")).Displayed;

            }
            catch
            {
                Console.WriteLine("" + menu + "  Menu in EAM is getting displayed for Role " + role + " Which is not expected");
            }

            Assert.IsFalse(ispresent, "" + menu + " menu is  gettting displayed for Role " + role + " Which is not expected");

        }

        [Then(@"Verify EAM ""(.*)"" Menu and ""(.*)"" Sub menue is displayed for Role ""(.*)""")]
        public void ThenVerifyEAMMenuAndSubMenueIsDisplayedForRole(string p0, string p1, string p2)
        {
            string menu = tmsCommon.GenerateData(p0);
            string submenu = tmsCommon.GenerateData(p1);
            string role = tmsCommon.GenerateData(p2);
            bool ispresent=false;
            try
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@title='Administration']")));

                ispresent = Browser.Wd.FindElement(By.XPath("//div[contains(@test-id,'submenu')]//span[contains(.,'Workflow Dashboard')]")).Displayed;

            }
            catch
            {
                Console.WriteLine("" + menu + "  Menu in EAM is not getting displayed for Role " + role + " Which is not expected");
            }

            Assert.IsTrue(ispresent, "" + menu + " menu is not gettting displayed for Role " + role + " Which is not expected");



        }

        [Then(@"Verify EAM ""(.*)"" Menu and ""(.*)"" Sub menue is Not displayed for Role ""(.*)""")]
        public void ThenVerifyEAMMenuAndSubMenueIsNotDisplayedForRole(string p0, string p1, string p2)
        {
            string menu = tmsCommon.GenerateData(p0);
            string submenu = tmsCommon.GenerateData(p1);
            string role = tmsCommon.GenerateData(p2);
            bool ispresent = false;
            try
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@title='" + menu + "']")));

                ispresent = Browser.Wd.FindElement(By.XPath("//div[contains(@test-id,'submenu')]//span[contains(.,'Workflow Dashboard')]")).Displayed;

            }
            catch
            {
                Console.WriteLine("" + menu + "  Menu in EAM is getting displayed for Role " + role + " Which is not expected");
            }

            Assert.IsFalse(ispresent, "" + menu + " menu is  gettting displayed for Role " + role + " Which is not expected");


        }

        [When(@"EAM WorkflowDashboard Priority is set to ""(.*)"" for workitem ""(.*)""")]
        public void WhenEAMWorkflowDashboardPriorityIsSetToForWorkitem(string p0, string p1)
        {
            string priority = tmsCommon.GenerateData(p0);
            string workitem = tmsCommon.GenerateData(p1);

            IWebElement CheckboxWorkitem = Browser.Wd.FindElement(By.XPath("//td[text()='" + workitem + "']/preceding-sibling::td/input"));
            fw.ExecuteJavascript(CheckboxWorkitem);
            tmsWait.Hard(2);

        }

        [When(@"EAM WorkflowDashboard Workitem ""(.*)"" is selected")]
        public void WhenEAMWorkflowDashboardWorkitemIsSelected(string p0)
        {
            string workitem = tmsCommon.GenerateData(p0);
            IWebElement CheckboxWorkitem = Browser.Wd.FindElement(By.XPath("//td[text()='" + workitem + "']/preceding-sibling::td/input"));
            fw.ExecuteJavascript(CheckboxWorkitem);
            tmsWait.Hard(2);
        }

        [When(@"EAM WorkflowDashboard Any ""(.*)"" WorkitemKey is selected")]
        public void WhenEAMWorkflowDashboardAnyWorkitemKeyIsSelected(string p0)
        {
            //selecting multiple workitem

            switch (p0.ToLower())
            {
                case "transaction":
                    for (int i = 1; i < 3; i++)
                    {
                        IWebElement CheckboxWorkitem = Browser.Wd.FindElement(By.XPath("(//td[contains(.,'Transaction')]/preceding-sibling::td/input)[" + i + "]"));
                        fw.ExecuteJavascript(CheckboxWorkitem);
                    }
                    break;
            }
        }

        [When(@"EAM WorkflowDashboard Workitem ""(.*)"" button is clicked")]
        public void WhenEAMWorkflowDashboardWorkitemButtonIsClicked(string p0)
        {
            string buttonType = tmsCommon.GenerateData(p0);

            switch(buttonType)
            {
                case "CHANGE PRIORITY":
                    tmsWait.Hard(3);
                    fw.ExecuteJavascript(EAM.WFDashboard.ChangePriorityBtn);
                    tmsWait.Hard(3);
                    break;
                case "RE-ASSIGN":
                    tmsWait.Hard(3);
                    fw.ExecuteJavascript(EAM.WFDashboard.ReaasignBtn);
                    tmsWait.Hard(3);
                    break;

            }
            tmsWait.Hard(5);
        }



        [When(@"EAM WorkflowDashboard Priority is set to ""(.*)""")]
        public void WhenEAMWorkflowDashboardPriorityIsSetTo(string p0)
        {
            string priority = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(EAM.WFDashboard.ChangePriorityDropDown);
            By typeapp = By.XPath("//li[text()='" + priority + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(1);
        }




        [When(@"EAM WorkflowDashboard Change Priority Submit button is clicked")]
        public void WhenEAMWorkflowDashboardChangePrioritySubmitButtonIsClicked()
        {
            fw.ExecuteJavascript(EAM.WFDashboard.ChangePrioritySubmitBtn);
            tmsWait.Hard(5);
        }

     

        [When(@"EAM WorkflowDashboard Workitem Reassign to queue ""(.*)""")]
        public void WhenEAMWorkflowDashboardWorkitemReassignToQueue(string p0)
        {
            string queue = tmsCommon.GenerateData(p0);
            fw.ExecuteJavascript(EAM.WFDashboard.ReassignQueueDropdown);
            By typeapp = By.XPath("//li[text()='" + queue + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(3);

        }


        [When(@"EAM WorkflowDashboard Reassign submit button is clicked")]
        public void WhenEAMWorkflowDashboardReassignSubmitButtonIsClicked()
        {
            fw.ExecuteJavascript(EAM.WFDashboard.ReassignSubmitBtn);
            tmsWait.Hard(5);
        }


        [Then(@"Verify EAM WorkflowStartPanel ""(.*)"" Workitem is displyed")]
        public void ThenVerifyEAMWorkflowStartPanelWorkitemIsDisplyed(string p0)
        {
            string expected_workitem_type = tmsCommon.GenerateData(p0);
            string actual_workitemtypestring = Browser.Wd.FindElement(By.XPath("//label[@test-id='workflowControl-lbl-message']")).Text;
            Assert.IsTrue(actual_workitemtypestring.Contains(expected_workitem_type), "Expected Workitem type is not displyed");
        }

        [When(@"EAM WorkflowStartPanel WorkflowMode ""(.*)"" button is clicked")]
        public void WhenEAMWorkflowStartPanelWorkflowModeButtonIsClicked(string p0)
        {
            string buttontype = tmsCommon.GenerateData(p0);
            switch(buttontype.ToLower())
            {
                case "save":
            fw.ExecuteJavascript(EAM.WFTaskbarOperations.WorkflowModeSaveBtn);
                    break;

                case "save and get next":
                    //fw.ExecuteJavascript(EAM.WFTaskbarOperations.WorkflowModeSaveAndGetNextBtn);
                    fw.ExecuteJavascript(EAM.WFTaskbarOperations.WMtransactionSaveAndGetNextBtn);
                    break;


                case "transaction save and get next":
                    fw.ExecuteJavascript(EAM.WFTaskbarOperations.WMtransactionSaveAndGetNextBtn);
                    break;

                case "transaction save":
                    fw.ExecuteJavascript(EAM.WFTaskbarOperations.WorkflowModetransactionSaveBtn);
                    tmsWait.Hard(3);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")));
                    tmsWait.Hard(1);
                    break;

            }
            tmsWait.Hard(3);
        }


        [When(@"EAM WorkflowStartPanel Back to Member Info link is clicked")]
        public void WhenEAMWorkflowStartPanelBackToMemberInfoLinkIsClicked()
        {
            fw.ExecuteJavascript(EAM.WFTaskbarOperations.BackToMemberInfoLink);
            tmsWait.Hard(2);
        }

        [Then(@"Verify  EAM ""(.*)"" page is displayed")]
        public void ThenVerifyEAMPageIsDisplayed(string p0)
        {
            string expected_eampage = tmsCommon.GenerateData(p0);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[text()='View/Edit Member']")).Displayed, "" + expected_eampage + " page is not displayed");
        }

        [When(@"EAM WorkflowStartPanel Transaction Edit Icon is clicked")]
        public void WhenEAMWorkflowStartPanelTransactionEditIconIsClicked()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='transactions-grid-memberTransactionsGrid']//td/a")));
            tmsWait.Hard(3);
        }

        [When(@"EAM WorkflowStartPanel Member Info Button is clicked")]
        public void WhenEAMWorkflowStartPanelMemberInfoButtonIsClicked()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='transaction-btn-expandAndCollapse']")));
            tmsWait.Hard(3);
        }

    }
}
