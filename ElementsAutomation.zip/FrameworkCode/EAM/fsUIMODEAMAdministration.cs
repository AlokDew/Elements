﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using TMSoR1.FrameworkCode;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using TMSoR1.FrameworkCode.HCC_RAM;


namespace TMSoR1.FrameworkCode.EAM
{
    [Binding]
    class fsUIMODEAMAdministration
    {


        [When(@"Add MMP Member Load Parameters page ""(.*)"" is set as ""(.*)""")]
        public void WhenAddMMPMemberLoadParametersPageIsSetAs(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);

            if (field.Equals("Effective Date"))
            {
                //value = value.Replace("/", "");
                By Drp = By.XPath("//kendo-datepicker[@id='dtEffDate']//span[@role='button']");
                AngularFunction.enterDate(Drp, value);
               

                tmsWait.Hard(3);

                //By Drp1 = By.XPath("//label[text()='Termination Date']/parent::div//input");
                //Browser.Wd.FindElement(Drp1).Clear();
                ////Browser.Wd.FindElement(Drp1).SendKeys(Keys.Home);
                //Browser.Wd.FindElement(Drp1).SendKeys("12312079");

                //tmsWait.Hard(3);

            }
            else
            {
                value = value.Replace("/", "");
                By Drp = By.XPath("//label[text()='Termination Date']/parent::div//input");
                Browser.Wd.FindElement(Drp).Clear();
                Browser.Wd.FindElement(Drp).SendKeys(value);

                tmsWait.Hard(3);

            }

        }

        [When(@"Verify Add MMP Member Load Parameters page ""(.*)"" drop down list is ""(.*)""")]
        public void WhenVerifyAddMMPMemberLoadParametersPageDropDownListIs(string p0, string p1)
        {
            tmsWait.Hard(3);
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            int index = 4;


            if (ConfigFile.tenantType.Equals("tmsx"))
            {

                String b = UIMODUtilFunctions.verifyDropDownValueIsDisabled(field);
                if (value.ToLower().Equals("disabled"))
                {
                    Assert.IsTrue(b.Equals("true"));
                }
            }
            else
            {
                // UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODEAMAdmin.MMPManagement.TRCDropdownlist, value);

            }





        }

        [When(@"Add MMP Member Load Parameters page ""(.*)"" drop down list is set to ""(.*)""")]
        public void WhenAddMMPMemberLoadParametersPageDropDownListIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(5);
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            int index = 4;
            switch (field)
            {
                case "MMP State":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {

                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(field, value, index);
                        tmsWait.Hard(3);
                    }
                    else {
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODEAMAdmin.MMPManagement.StateDropdownlist, value);

                    }
                    break;

                case "Plan ID":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {

                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(field, value, index);
                        tmsWait.Hard(3);
                    }
                    else
                    {
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODEAMAdmin.MMPManagement.PlanIDDropdownlist, value);
                    }
                    break;
                case "PBP":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {

                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(field, value, index);
                        tmsWait.Hard(3);
                    }
                    else
                    {
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODEAMAdmin.MMPManagement.PBPIDDropdownlist, value);
                    } break;
                case "Transaction Code":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {

                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(field, value, index);
                        tmsWait.Hard(3);
                    }
                    else
                    {
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODEAMAdmin.MMPManagement.TCCodeDropdownlist, value);
                    }
                    break;
                case "Transaction Status":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {

                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(field, value, index);
                        tmsWait.Hard(3);
                    }
                    else
                    {
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODEAMAdmin.MMPManagement.TCStatusDropdownlist, value);

                    } break;

                case "TRC":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {

                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(field, value, index);
                    }
                    else
                    {
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODEAMAdmin.MMPManagement.TRCDropdownlist, value);

                    } break;


            }
        }


        [Then(@"Verify add MMP Member Load Paramters page displayed MMP State as ""(.*)"" Plan ID as ""(.*)"" PBP as ""(.*)"" TC code as ""(.*)"" Status as ""(.*)"" TRC as ""(.*)"" Effective Date as ""(.*)"" Term Date as ""(.*)""")]
        public void ThenVerifyAddMMPMemberLoadParamtersPageDisplayedMMPStateAsPlanIDAsPBPAsTCCodeAsStatusAsTRCAsEffectiveDateAsTermDateAs(string p0, string p1, string p2, string p3, string p4, string p5, string p6, string p7)
        {
            tmsWait.Hard(3);
            string state = tmsCommon.GenerateData(p0);
            string plan = tmsCommon.GenerateData(p1);
            string pbp = tmsCommon.GenerateData(p2);
            string tccode = tmsCommon.GenerateData(p3);
            string status = tmsCommon.GenerateData(p4);
            string trc = tmsCommon.GenerateData(p5);
            string effective = tmsCommon.GenerateData(p6);
            string term = tmsCommon.GenerateData(p7);

            bool hasrow = false;
            int totalPagesIntheGrid;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                hasrow = UIMODUtilFunctions.rowPresenceUsingLocators(state, plan, pbp, tccode, status, trc, effective, term);
                Assert.IsTrue(hasrow);

            }
            else
            {
                totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
                for (int i = 1; i <= totalPagesIntheGrid; i++)
                {
                    try
                    {
                        hasrow = Browser.Wd.FindElement(By.XPath("//div[@test-id='mmpManagement-Grid']//td[contains(.,'" + state + "')]/following-sibling::td[contains(.,'" + plan + "')]/following-sibling::td[contains(.,'" + pbp + "')]//following-sibling::td[contains(.,'" + tccode + "')]/following-sibling::td[contains(.,'" + status + "')]/following-sibling::td[contains(.,'" + trc + "')]/following-sibling::td[contains(.,'" + effective + "')]/following-sibling::td[contains(.,'" + term + "')]")).Displayed;
                        By loc = By.XPath("//div[@test-id='mmpManagement-Grid']//td[contains(.,'" + state + "')]/following-sibling::td[contains(.,'" + plan + "')]/following-sibling::td[contains(.,'" + pbp + "')]//following-sibling::td[contains(.,'" + tccode + "')]/following-sibling::td[contains(.,'" + status + "')]/following-sibling::td[contains(.,'" + trc + "')]/following-sibling::td[contains(.,'" + effective + "')]/following-sibling::td[contains(.,'" + term + "')]");

                        UIMODUtilFunctions.elementPresenceUsingLocators(loc);
                        break;
                    }
                    catch
                    {

                        IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                        ReUsableFunctions.clickOnWebElement(nextpage);
                    }

                }
            }



        }

        [When(@"Status Override page MBI text box is set to ""(.*)""")]
        public void WhenStatusOverridePageMBITextBoxIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string value = tmsCommon.GenerateData(p0);
            ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMAdmin.StatusOverride.MBITextbox, value);
            tmsWait.Hard(3);
        }

        [When(@"Status Override ""(.*)"" Option button is Clicked")]
        public void WhenStatusOverrideOptionButtonIsClicked(string p0)
        {
            string typeofOpt = tmsCommon.GenerateData(p0);
            switch (typeofOpt)
            {
                case "Member":
                    fw.ExecuteJavascript(cfUIMODEAMAdmin.StatusOverride.MemberOptButton);
                    break;
                case "Transaction":
                    fw.ExecuteJavascript(cfUIMODEAMAdmin.StatusOverride.TransactionOptButton);
                    break;
            }
        }


        [When(@"Status Override page Search button is Clicked")]
        public void WhenStatusOverridePageSearchButtonIsClicked()
        {
            ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.StatusOverride.SearchBtn);
            tmsWait.Hard(3);
        }

        [Then(@"Verify Member Status Override page displayed Plan ID as ""(.*)"" PBP ID as ""(.*)"" Member Status as ""(.*)"" Rx ID as ""(.*)""")]
        public void ThenVerifyMemberStatusOverridePageDisplayedPlanIDAsPBPIDAsMemberStatusAsRxIDAs(string p0, string p1, string p2, string p3)
        {
            tmsWait.Hard(3);
            string plan = tmsCommon.GenerateData(p0);
            string pbp = tmsCommon.GenerateData(p1);
            string status = tmsCommon.GenerateData(p2);
            string rxid = tmsCommon.GenerateData(p3);
            By loc;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                loc = By.XPath("//div[@role='presentation']//td[contains(.,'" + plan + "')]/following-sibling::td[contains(.,'" + pbp + "')]/following-sibling::td[contains(.,'" + status + "')]/following-sibling::td[contains(.,'" + rxid + "')]");
            }
            else
            {
                loc = By.XPath("//div[@test-id='statusoverride-grid-member']//td[contains(.,'" + plan + "')]/following-sibling::td[contains(.,'" + pbp + "')]/following-sibling::td[contains(.,'" + status + "')]/following-sibling::td[contains(.,'" + rxid + "')]");
            }
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }

        [When(@"Member Status Override page displayed MemberNumber as ""(.*)"" Plan ID as ""(.*)"" PBP ID as ""(.*)"" Member Status as ""(.*)"" Rx ID as ""(.*)"" row is Clicked")]
        public void WhenMemberStatusOverridePageDisplayedMemberNumberAsPlanIDAsPBPIDAsMemberStatusAsRxIDAsRowIsClicked(string p0, string p1, string p2, string p3, string p4)
        {
            tmsWait.Hard(2);
            string memberNumber = tmsCommon.GenerateData(p0);
            string plan = tmsCommon.GenerateData(p1);
            string pbp = tmsCommon.GenerateData(p2);
            string status = tmsCommon.GenerateData(p3);
            string rxid = tmsCommon.GenerateData(p4);
            By loc;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                loc = By.XPath("//div[@role='presentation']//td[contains(.,'" + memberNumber + "')]/following-sibling::td[contains(.,'" + plan + "')]/following-sibling::td[contains(.,'" + pbp + "')]/following-sibling::td[contains(.,'" + status + "')]/following-sibling::td[contains(.,'" + rxid + "')]/following-sibling::td//a");
            }
            else
            {
                loc = By.XPath("//div[@test-id='statusoverride-grid-member']//td[contains(.,'" + memberNumber + "')]/following-sibling::td[contains(.,'" + plan + "')]/following-sibling::td[contains(.,'" + pbp + "')]/following-sibling::td[contains(.,'" + status + "')]/following-sibling::td[contains(.,'" + rxid + "')]/following-sibling::td//a");
            }
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
        }


        [When(@"Member Status Override page displayed Plan ID as ""(.*)"" PBP ID as ""(.*)"" Member Status as ""(.*)"" Rx ID as ""(.*)"" row is Clicked")]
        public void WhenMemberStatusOverridePageDisplayedPlanIDAsPBPIDAsMemberStatusAsRxIDAsRowIsClicked(string p0, string p1, string p2, string p3)
        {
            tmsWait.Hard(2);
            string plan = tmsCommon.GenerateData(p0);
            string pbp = tmsCommon.GenerateData(p1);
            string status = tmsCommon.GenerateData(p2);
            string rxid = tmsCommon.GenerateData(p3);
            By loc;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                loc = By.XPath("//div[@role='presentation']//td[contains(.,'" + plan + "')]/following-sibling::td[contains(.,'" + pbp + "')]/following-sibling::td[contains(.,'" + status + "')]/following-sibling::td[contains(.,'" + rxid + "')]/following-sibling::td//a");
            }
            else
            {
                loc = By.XPath("//div[@test-id='statusoverride-grid-member']//td[contains(.,'" + plan + "')]/following-sibling::td[contains(.,'" + pbp + "')]/following-sibling::td[contains(.,'" + status + "')]/following-sibling::td[contains(.,'" + rxid + "')]/following-sibling::td//a");
            }
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
        }


        [Then(@"Verify Status Override page displayed MBI as ""(.*)"" Plan ID as ""(.*)"" Trans ID as ""(.*)"" TC as ""(.*)"" Effective Date as ""(.*)"" Date Entered as ""(.*)"" Status as ""(.*)""")]
        public void ThenVerifyStatusOverridePageDisplayedMBIAsPlanIDAsTransIDAsTCAsEffectiveDateAsDateEnteredAsStatusAs(string p0, string p1, string p2, string p3, string p4, string p5, string p6)
        {
            tmsWait.Hard(5);
            string mbi = tmsCommon.GenerateData(p0);
            string plan = tmsCommon.GenerateData(p1);
            string transId = tmsCommon.GenerateData(p2);
            string tc = tmsCommon.GenerateData(p3);
            string effective = tmsCommon.GenerateData(p4);
            string dateenter = tmsCommon.GenerateData(p5);
            string status = tmsCommon.GenerateData(p6);
            By loc;

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                loc = By.XPath("//div[@role='presentation']//td[contains(.,'" + mbi + "')]/following-sibling::td[contains(.,'" + plan + "')]/following-sibling::td[contains(.,'" + transId + "')]/following-sibling::td[contains(.,'" + tc + "')]//following-sibling::td[contains(.,'" + effective + "')]/following-sibling::td[contains(.,'" + dateenter + "')]/following-sibling::td[contains(.,'" + status + "')]");
            }
            else
            {
                loc = By.XPath("//div[@test-id='statusoverride-grid-transaction']//td[contains(.,'" + mbi + "')]/following-sibling::td[contains(.,'" + plan + "')]/following-sibling::td[contains(.,'" + transId + "')]/following-sibling::td[contains(.,'" + tc + "')]//following-sibling::td[contains(.,'" + effective + "')]/following-sibling::td[contains(.,'" + dateenter + "')]/following-sibling::td[contains(.,'" + status + "')]");
            }
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }
        [Then(@"Verify Status Override page displayed Plan ID as ""(.*)"" PBP ID as ""(.*)""")]
        public void ThenVerifyStatusOverridePageDisplayedPlanIDAsPBPIDAs(string p0, string p1)
        {
            tmsWait.Hard(2);
            string plan = tmsCommon.GenerateData(p0);
            string pbp = tmsCommon.GenerateData(p1);
            By loc;

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                loc = By.XPath("//div[@role='presentation']//span[contains(.,'" + plan + "')]/parent::td/following-sibling::td[contains(.,'" + pbp + "')]");
            }
            else
            {



                loc = By.XPath("//div[@test-id='statusoverride-grid-member']//span[contains(.,'" + plan + "')]/parent::td/following-sibling::td[contains(.,'" + pbp + "')]");
            }
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }

        [When(@"Status Override page displayed MBI as ""(.*)"" Plan ID as ""(.*)"" Trans ID as ""(.*)"" TC as ""(.*)"" Effective Date as ""(.*)"" Date Entered as ""(.*)"" Status as ""(.*)"" row is Clicked")]
        public void WhenStatusOverridePageDisplayedMBIAsPlanIDAsTransIDAsTCAsEffectiveDateAsDateEnteredAsStatusAsRowIsClicked(string p0, string p1, string p2, string p3, string p4, string p5, string p6)
        {
            tmsWait.Hard(3);
            string mbi = tmsCommon.GenerateData(p0);
            string plan = tmsCommon.GenerateData(p1);
            string transId = tmsCommon.GenerateData(p2);
            string tc = tmsCommon.GenerateData(p3);
            string effective = tmsCommon.GenerateData(p4);
            string dateenter = tmsCommon.GenerateData(p5);
            string status = tmsCommon.GenerateData(p6);
            By loc;

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                loc = By.XPath("//kendo-grid[@test-id='statusoverride-grid-transaction']//td[contains(.,'" + mbi + "')]/following-sibling::td[contains(.,'" + plan + "')]/following-sibling::td[contains(.,'" + transId + "')]/following-sibling::td[contains(.,'" + tc + "')]//following-sibling::td[contains(.,'" + effective + "')]/following-sibling::td[contains(.,'" + dateenter + "')]/following-sibling::td[contains(.,'" + status + "')]/following-sibling::td//a");
            }
            else
            {
                loc = By.XPath("//div[@test-id='statusoverride-grid-transaction']//td[contains(.,'" + mbi + "')]/following-sibling::td[contains(.,'" + plan + "')]/following-sibling::td[contains(.,'" + transId + "')]/following-sibling::td[contains(.,'" + tc + "')]//following-sibling::td[contains(.,'" + effective + "')]/following-sibling::td[contains(.,'" + dateenter + "')]/following-sibling::td[contains(.,'" + status + "')]/following-sibling::td//a");
            }

            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            tmsWait.Hard(8);
        }
        [Then(@"Verify Status Override page displayed MBI as ""(.*)"" Plan ID as ""(.*)"" Trans ID as ""(.*)"" TC as ""(.*)"" Effective Date as ""(.*)"" Date Entered as ""(.*)"" Status as ""(.*)"" row is editable")]
        public void ThenVerifyStatusOverridePageDisplayedMBIAsPlanIDAsTransIDAsTCAsEffectiveDateAsDateEnteredAsStatusAsRowIsEditable(string p0, string p1, string p2, string p3, string p4, string p5, string p6)
        {

            tmsWait.Hard(3);
            string mbi = tmsCommon.GenerateData(p0);
            string plan = tmsCommon.GenerateData(p1);
            string transId = tmsCommon.GenerateData(p2);
            string tc = tmsCommon.GenerateData(p3);
            string effective = tmsCommon.GenerateData(p4);
            string dateenter = tmsCommon.GenerateData(p5);
            string status = tmsCommon.GenerateData(p6);
            By loc;

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                loc = By.XPath("//kendo-grid[@test-id='statusoverride-grid-transaction']//td[contains(.,'" + mbi + "')]/following-sibling::td[contains(.,'" + plan + "')]/following-sibling::td[contains(.,'" + transId + "')]/following-sibling::td[contains(.,'" + tc + "')]//following-sibling::td[contains(.,'" + effective + "')]/following-sibling::td[contains(.,'" + dateenter + "')]/following-sibling::td[contains(.,'" + status + "')]/following-sibling::td//a");
            }
            else
            {
                loc = By.XPath("//div[@test-id='statusoverride-grid-transaction']//td[contains(.,'" + mbi + "')]/following-sibling::td[contains(.,'" + plan + "')]/following-sibling::td[contains(.,'" + transId + "')]/following-sibling::td[contains(.,'" + tc + "')]//following-sibling::td[contains(.,'" + effective + "')]/following-sibling::td[contains(.,'" + dateenter + "')]/following-sibling::td[contains(.,'" + status + "')]/following-sibling::td//a");
            }


            try {
                UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            }
            catch
            {
                Assert.IsTrue(true);
            }
        }

        [Then(@"Verify Transaction Status Override page Response Message ""(.*)"" is displayed")]
        public void ThenVerifyTransactionStatusOverridePageResponseMessageIsDisplayed(string p0)
        {
            //tmsWait.Hard(5);
            //By loc = By.XPath("//span[contains(.,'" + p0 + "')]");

            //UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }
        [Then(@"Verify Member Status Override page Response Message ""(.*)"" is displayed")]
        public void ThenVerifyMemberStatusOverridePageResponseMessageIsDisplayed(string p0)
        {
            By loc = By.XPath("//label[contains(.,'" + p0 + "')]");

            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }


        [When(@"Add MMP Member Load Parameters page ""(.*)"" is set to ""(.*)""")]
        public void WhenAddMMPMemberLoadParametersPageIsSetTo(string p0, string p1)
        {
            // tmsWait.Hard(3);
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (field)
            {
                case "Effective Date":
                    tmsWait.Hard(3);
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        //ReUsableFunctions.enterValueOnWebElementWithClear(field, value);
                        IWebElement MMPEffectiveDate = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='mmpManagement-date-dtEffDate']//span[@role='button']"));
                        AngularFunction.enterDate(MMPEffectiveDate,value);
                        tmsWait.Hard(2);

                    }
                    else {
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.MMPManagement.EffectiveDate, value);
                        cfUIMODEAMAdmin.MMPManagement.EffectiveDate.SendKeys(Keys.Tab);
                        cfUIMODEAMAdmin.MMPManagement.EffectiveDate.SendKeys(Keys.Tab);

                    }


                    break;

                case "Termination Date":
                    tmsWait.Hard(3);

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        //ReUsableFunctions.enterValueOnWebElementWithClear(field, value);
                        IWebElement MMPTerminationDate = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='mmpManagement-date-dtTerminationDate']//span[@role='button']"));
                        AngularFunction.enterDate(MMPTerminationDate, value);
                        tmsWait.Hard(2);

                    }
                    else
                    {
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.MMPManagement.TermDate, value);
                        cfUIMODEAMAdmin.MMPManagement.TermDate.SendKeys(Keys.Tab);
                    }

                    break;



            }
        }

        [When(@"Add MMP Member Load Parameters page ADD button is clicked")]
        public void WhenAddMMPMemberLoadParametersPageADDButtonIsClicked()
        {
            tmsWait.Hard(7);
            fw.ExecuteJavascript(cfUIMODEAMAdmin.MMPManagement.ADDBtn);
            tmsWait.Hard(3);
        }
        [When(@"Add MMP Member Load Parameters page ADD button is clicked and Rule Message ""(.*)"" is displayed")]
        public void WhenAddMMPMemberLoadParametersPageADDButtonIsClickedAndRuleMessageIsDisplayed(string p0)
        {
            fw.ExecuteJavascript(cfUIMODEAMAdmin.MMPManagement.ADDBtn);
            tmsWait.Hard(1);
            string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).Text;
            Assert.IsTrue(actualValue.Contains(p0));
        }


        [When(@"EAM Adminisration page View Bid Data section ""(.*)"" Component is set to ""(.*)""")]
        public void WhenEAMAdminisrationPageViewBidDataSectionComponentIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            By Drp = null;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                switch (field.ToLower())
                {
                    case "year":
                        Drp = By.XPath("//kendo-dropdownlist[@id='ddlYear']//span[@class='k-select']");
                        break;
                    case "plan id":
                        Drp = By.XPath("//kendo-dropdownlist[@id='ddlPlanId']//span[@class='k-select']");
                        break;
                    case "pbp":
                        Drp = By.XPath("//kendo-dropdownlist[@id='ddlPbp']//span[@class='k-select']");
                        break;
                    case "segment id":
                        Drp = By.XPath("//kendo-dropdownlist[@id='ddlSegmentId']//span[@class='k-select']");
                        break;
                }
                tmsWait.Hard(3);
                By typeapp = By.XPath("//li[text()='" + value + "']");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);

                //tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
            }
            else
            {
                switch (field.ToLower())
                {
                    case "year":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.View_BidData.YearDropDownList);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUIWithoutAriaOwns(cfUIMODEAMAdmin.View_BidData.YearDropDownList, value);
                        break;
                    case "plan id":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.View_BidData.PlanIdDropDownList);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUIWithoutAriaOwns(cfUIMODEAMAdmin.View_BidData.PlanIdDropDownList, value);
                        tmsWait.Hard(2);
                        break;
                    case "pbp":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.View_BidData.PBPDropDownList);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUIWithoutAriaOwns(cfUIMODEAMAdmin.View_BidData.PBPDropDownList, value);
                        tmsWait.Hard(2);
                        break;
                    case "segment id":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.View_BidData.SegmentrDropDownList);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUIWithoutAriaOwns(cfUIMODEAMAdmin.View_BidData.SegmentrDropDownList, value);
                        tmsWait.Hard(2);
                        break;

                }
            }
        }

        [When(@"EAM Adminisration page View Bid Data section ""(.*)"" button is clicked")]
        public void WhenEAMAdminisrationPageViewBidDataSectionButtonIsClicked(string p0)
        {
            string buttonclick = tmsCommon.GenerateData(p0);
            switch (buttonclick.ToLower())
            {
                case "search":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.View_BidData.SearchBtn);
                    tmsWait.Hard(1);
                    break;
                case "reset":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.View_BidData.ResetBtn);
                    tmsWait.Hard(1);
                    break;
            }
        }

        [When(@"EAM Administration page View Bid Data section Get the Basic Premium PartC and assigned to ""(.*)""")]
        public void WhenEAMAdministrationPageViewBidDataSectionGetTheBasicPremiumPartCAndAssignedTo(string p0)
        {
            string partcpremium = Browser.Wd.FindElement(By.XPath("//div[@test-id='bidData-grid-bidData']//table//tbody//td[7]")).Text;
            decimal value;

            if (decimal.TryParse(partcpremium, out value))
            {
                value = Math.Round(value);
                partcpremium = value.ToString();
                // Do something with the new text value
            }
            else
            {
                // Tell the user their input is invalid
            }

            fw.setVariable(p0, partcpremium);
        }


        [Then(@"Verify EAM Administration page View Bid Data section PlanId dropdown has value ""(.*)"" and PBP dropdown has value ""(.*)""")]
        public void ThenVerifyEAMAdministrationPageViewBidDataSectionPlanIdDropdownHasValueAndPBPDropdownHasValue(string p0, string p1)
        {

            string CurrentPlanId = tmsCommon.GenerateData(p0);
            string CurrentPBP = tmsCommon.GenerateData(p1);


            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                string actualPlanId = Browser.Wd.FindElement(By.XPath("//label[text()='Plan ID']//parent::div//span[1]/span[1]")).Text;
                string actualPBP = Browser.Wd.FindElement(By.XPath("//label[text()='PBP']//parent::div//span[1]/span[1]")).Text;
                Assert.IsTrue(actualPlanId.Contains(CurrentPlanId), "Plan Id drop dwon not dislays as default value");
                Assert.IsTrue(actualPBP.Contains(CurrentPBP), "PBP drop dwon not dislays as default value");

            }
            else
            {
                string actualPlanId = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='ddlPlanId_listbox']/span[@unselectable='on']")).Text;
                string actualPBP = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='ddlPbp_listbox']/span[@unselectable='on']")).Text;
                Assert.IsTrue(actualPlanId.Contains(CurrentPlanId), "Plan Id drop dwon not dislays as default value");
                Assert.IsTrue(actualPBP.Contains(CurrentPBP), "PBP drop dwon not dislays as default value");

            }

        }


        [When(@"EAM Adminisration page View Bid Data section Information Icon is clicked for Year ""(.*)"" Plan Id ""(.*)"" and PBP ""(.*)""")]
        public void WhenEAMAdminisrationPageViewBidDataSectionInformationIconIsClickedForYearPlanIdAndPBP(string p0, string p1, string p2)
        {
            tmsWait.Hard(7);
            string year = tmsCommon.GenerateData(p0.ToString());
            string planid = tmsCommon.GenerateData(p1.ToString());
            string pbp = tmsCommon.GenerateData(p2.ToString());

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement infoIcon = Browser.Wd.FindElement(By.XPath("//div[@role='presentation']//td[contains(.,'" + pbp + "')]/preceding-sibling::td[contains(.,'" + planid + "')]/preceding-sibling::td[contains(.,'" + year + "')]/preceding-sibling::td/a"));
                ReUsableFunctions.clickOnWebElement(infoIcon);
            }
            else
            {
                IWebElement infoIcon = Browser.Wd.FindElement(By.XPath("//div[@test-id='bidData-grid-bidData']//td/span[contains(.,'" + pbp + "')]/parent::td/preceding-sibling::td/span[contains(.,'" + planid + "')]/parent::td/preceding-sibling::td/span[contains(.,'" + year + "')]/parent::td/preceding-sibling::td/a"));
                ReUsableFunctions.clickOnWebElement(infoIcon);

            }
            tmsWait.Hard(7);

        }


        [When(@"EAM Administration page View Bid Data section Information Icon is clicked")]
        public void WhenEAMAdministrationPageViewBidDataSectionInformationIconIsClicked()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@test-id='bidData-grid-bidData']//td//i")));
            tmsWait.Hard(1);
        }


        [Then(@"Verify EAM Adminisration page View Bid Data section Premium Calculation window is displayed")]
        public void ThenVerifyEAMAdminisrationPageViewBidDataSectionPremiumCalculationWindowIsDisplayed()
        {
            tmsWait.Hard(10);
            if (ConfigFile.tenantType.Equals("tmsx")) {

                Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[contains(.,'Premium Calculation')]")).Displayed);
            }
            else
            {

                Assert.IsTrue(cfUIMODEAMAdmin.View_BidData.PremiumClaculationWindowHeader.Displayed, "Premium Calculation window does not display");
        }
}

        [When(@"EAM Adminisration page View Bid Data section Premium Calculation window ""(.*)"" Grid is displayed")]
        public void WhenEAMAdminisrationPageViewBidDataSectionPremiumCalculationWindowGridIsDisplayed(string p0)
        {
            string expected_Grid = tmsCommon.GenerateData(p0);
            switch (expected_Grid.ToLower())
            {
                case "final part c premiums": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='premium-calculation-grid-partc']")).Displayed, "Part C Premiums Grid is not displayed"); break;
                case "osb premiums amounts": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='premium-calculation-grid-osb']")).Displayed, "Part C Premiums Grid is not displayed"); break;
                case "subsidy amounts": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='premium-calculation-grid-subsidyAmount']")).Displayed, "Part C Premiums Grid is not displayed"); break;

            }
        }

        [When(@"EAM Adminisration page View Bid Data section Premium Calculation window ""(.*)"" Grid data displayed as ""(.*)""")]
        public void WhenEAMAdminisrationPageViewBidDataSectionPremiumCalculationWindowGridDataDisplayedAs(string p0, string p1)
        {
            string expected_Grid = tmsCommon.GenerateData(p0);
            string expected_GridValue = tmsCommon.GenerateData(p1);
            string actual_GridValue = null;
            switch (expected_Grid.ToLower())
            {
                case "final part d prem - non lis": actual_GridValue = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='premium-calculation-grid-partDpremium']//td")).Text; break;
                case "final part d premiums - lis": actual_GridValue = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='premium-calculation-grid-subsidyAmount']//td")).Text; break;
                case "subsidy amounts": actual_GridValue = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='premium-calculation-grid-subsidyAmount']//td")).Text; break;
                case "medical osb": actual_GridValue = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='premium-calculation-grid-osb']//td[1]")).Text; break;


            }

            Assert.IsTrue(actual_GridValue.Contains(expected_GridValue), "Part C Premiums Grid is not displayed");
        }


        [When(@"EAM Administration page View Bid Data section Premium Calculation window ""(.*)"" Premium is set to ""(.*)""")]
        public void WhenEAMAdministrationPageViewBidDataSectionPremiumCalculationWindowPremiumIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = "";
            switch (field.ToLower())
            {
                case "part d non lis": value = Browser.Wd.FindElement(By.XPath("//div[@test-id='premium-calculation-grid-partDpremium']//tbody/tr[1]/td[1]")).Text;
                    break;
            }

            fw.setVariable(p1, value);


        }



        [When(@"EAM Adminisration page View Bid Data section Premium Calculation window ""(.*)"" is displayed")]
        public void WhenEAMAdminisrationPageViewBidDataSectionPremiumCalculationWindowIsDisplayed(string p0)
        {
            string expected_string = tmsCommon.GenerateData(p0);
            bool ispresent = false;
            try
            {
                ispresent = Browser.Wd.FindElement(By.XPath("//p//strong[contains(.,'" + expected_string + "')]")).Displayed;

            }

            catch
            {

            }

            Assert.IsTrue(ispresent, "Formulas are not displayed");
        }



        [Then(@"Verify EAM Administration page View Bid Data section has row with Year ""(.*)"" and PlanId ""(.*)"" and PBP ""(.*)"" and PBPType ""(.*)"" and SegmentId ""(.*)"" is displays")]
        public void ThenVerifyEAMAdministrationPageViewBidDataSectionHasRowWithYearAndPlanIdAndPBPAndPBPTypeAndSegmentIdIsDisplays(string p0, string p1, string p2, string p3, string p4)
        {
            tmsWait.Hard(7);
            string year = tmsCommon.GenerateData(p0.ToString());
            string planid = tmsCommon.GenerateData(p1.ToString());
            string pbp = tmsCommon.GenerateData(p2.ToString());
            string pbptype = tmsCommon.GenerateData(p3.ToString());
            string segmentid = tmsCommon.GenerateData(p4.ToString());
            bool hasrow = false;
            int totalPagesIntheGrid = 0;

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                string xpath = "//div[@role='presentation']//td[contains(.,'" + year + "')]/following-sibling::td[contains(.,'" + planid + "')]/following-sibling::td[contains(.,'" + pbp + "')]/following-sibling::td[contains(.," + pbptype + "')]/following-sibling::td[contains(.,'" + segmentid + "')]";//
       //         string xpath ="//div[@test-id='bidData-grid-bidData']//td/span[contains(.,'" + year + "')]/parent::td/following-sibling::td/span[contains(.,'" + planid + "')]/parent::td/following-sibling::td/span[contains(.,'" + pbp + "')]/parent::td/following-sibling::td[contains(.,'" + pbptype + "')]/following-sibling::td/span[contains(.,'" + segmentid + "')]";
                ReUsableFunctions.verifyGridElementPresence(xpath);
            }
            else
            {
                Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
                for (int i = 1; i <= totalPagesIntheGrid; i++)
                {
                    try
                    {
                        hasrow = Browser.Wd.FindElement(By.XPath("//div[@test-id='bidData-grid-bidData']//td/span[contains(.,'" + year + "')]/parent::td/following-sibling::td/span[contains(.,'" + planid + "')]/parent::td/following-sibling::td/span[contains(.,'" + pbp + "')]/parent::td/following-sibling::td[contains(.,'" + pbptype + "')]/following-sibling::td/span[contains(.,'" + segmentid + "')]")).Displayed;
                        break;
                    }
                    catch
                    {

                        IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                        ReUsableFunctions.clickOnWebElement(nextpage);
                        tmsWait.Hard(7);
                    }

                }
                //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed);

                Assert.IsTrue(hasrow, "There is no such row Present");
            }

        }

        [Then(@"Verify EAM Administration page View Bid Data section has row with Year ""(.*)"" and PlanId ""(.*)"" and PBP ""(.*)"" is displayed")]
        public void ThenVerifyEAMAdministrationPageViewBidDataSectionHasRowWithYearAndPlanIdAndPBPIsDisplayed(int p0, string p1, int p2)
        {
            string year = tmsCommon.GenerateData(p0.ToString());
            string planid = tmsCommon.GenerateData(p1.ToString());
            string pbp = tmsCommon.GenerateData(p2.ToString());
            bool hasrow = false;
            int totalPagesIntheGrid = 0;

            if (ConfigFile.tenantType.Equals("tmsx"))
            {

                string xpath = "//div[@role='presentation']//td[text()='"+year+ "']//following-sibling::td[text()='" + planid + "']/following-sibling::td[text()='" + pbp + "']";
                ReUsableFunctions.verifyGridElementPresence(xpath);
            }
            else
            {
                totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
                for (int i = 1; i <= totalPagesIntheGrid; i++)
                {
                    try
                    {
                        hasrow = Browser.Wd.FindElement(By.XPath("//div[@test-id='bidData-grid-bidData']//td/span[contains(.,'" + year + "')]/parent::td/following-sibling::td/span[contains(.,'" + planid + "')]/parent::td/following-sibling::td/span[contains(.,'" + pbp + "')]")).Displayed;
                        break;
                    }
                    catch
                    {

                        IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                        ReUsableFunctions.clickOnWebElement(nextpage);
                    }

                }
                //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed);

                Assert.IsTrue(hasrow, "There is no such row Present");
            }
        }

        [When(@"EAM Adminisration page View Bid Data section Premium Calculation window Close button is clicked")]
        public void WhenEAMAdminisrationPageViewBidDataSectionPremiumCalculationWindowCloseButtonIsClicked()
        {
            ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.View_BidData.PremiumCalculationWindowCloseBtn);
            tmsWait.Hard(2);
        }



        [Then(@"Verify EAM Adminisration page View Bid Data section default values for ""(.*)"" is ""(.*)""")]
        public void ThenVerifyEAMAdminisrationPageViewBidDataSectionDefaultValuesForIs(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (field.ToLower())
            {
                case "plan id": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[@aria-owns='ddlPlanId_listbox']/span/span[contains(.,'" + value + "')]")).Displayed); break;
                case "pbp": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[@aria-owns='ddlPbp_listbox']/span/span[contains(.,'" + value + "')]")).Displayed); break;
                case "segment id": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[@aria-owns='ddlSegmentId_listbox']/span/span[contains(.,'" + value + "')]")).Displayed); break;
            }
        }



        [Then(@"Verify EAM Administration page View Bid Data section default value for Year dropd down should be current year")]
        public void ThenVerifyEAMAdministrationPageViewBidDataSectionDefaultValueForYearDropdDownShouldBeCurrentYear()
        {
            var currentYear = DateTime.Now.Year;
            string defaultYear = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='ddlYear_listbox']/span/span")).Text;
            Assert.AreEqual(currentYear, defaultYear, "Default value for Year Drop down is not Current Year");
        }

        [Then(@"Verify EAM Administration page View Bid Data section field ""(.*)"" is disabled")]
        public void ThenVerifyEAMAdministrationPageViewBidDataSectionFieldIsDisabled(string p0)
        {
            string field = tmsCommon.GenerateData(p0);
            string checkdisabled = null;
            switch (field.ToLower())
            {
                case "pbp": checkdisabled = cfUIMODEAMAdmin.View_BidData.PBPDropDownList.GetAttribute("aria-disabled");
                    Assert.IsTrue(bool.Parse(checkdisabled), "PBP dropdown is not disabled"); break;
                case "segment id":
                    checkdisabled = cfUIMODEAMAdmin.View_BidData.PBPDropDownList.GetAttribute("aria-disabled");
                    Assert.IsTrue(bool.Parse(checkdisabled), "PBP dropdown is not disabled"); break;
            }
        }

        [Then(@"Verify EAM Administration page View Bid Data section field ""(.*)"" is Enabled")]
        public void ThenVerifyEAMAdministrationPageViewBidDataSectionFieldIsEnabled(string p0)
        {
            string field = tmsCommon.GenerateData(p0);
            string checkdisabled = null;
            switch (field.ToLower())
            {
                case "pbp":
                    checkdisabled = cfUIMODEAMAdmin.View_BidData.PBPDropDownList.GetAttribute("aria-disabled");
                    Assert.IsFalse(bool.Parse(checkdisabled), "PBP dropdown is not disabled"); break;
                case "segment id":
                    checkdisabled = cfUIMODEAMAdmin.View_BidData.PBPDropDownList.GetAttribute("aria-disabled");
                    Assert.IsFalse(bool.Parse(checkdisabled), "PBP dropdown is not disabled"); break;
            }
        }


        [When(@"EAM Adminisration page View Bid Data section Get PBP drop down values")]
        public void WhenEAMAdminisrationPageViewBidDataSectionGetPBPDropDownValues()
        {


        }

        [When(@"EAM Adminisration page View Bid Data section Get count ""(.*)"" drop down values and set as variable ""(.*)""")]
        public void WhenEAMAdminisrationPageViewBidDataSectionGetCountDropDownValuesAndSetAsVariable(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            IList<IWebElement> values = null;

            switch (field.ToLower())
            {

                case "ddlPlanId":
                    SelectElement planiddropdown = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@id='ddlPbp']")));
                    values = planiddropdown.Options;
                    //GlobalRef.TotalPBP = values.Count();

                    break;

                case "pbp":
                    SelectElement pbpdropdown = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@id='ddlPbp']")));
                    values = pbpdropdown.Options;
                    //GlobalRef.TotalPBP = values.Count();

                    break;
                case "segment id":
                    SelectElement segmentiddropdown = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@id='ddlSegmentId']")));
                    values = segmentiddropdown.Options;
                    //GlobalRef.TotalPBP = values.Count();
                    break;
            }
            string countT = values.Count().ToString();
            fw.setVariable(p1, countT);
        }

        List<string> dbValues;

        [When(@"Execute Query on EAM DB ""(.*)"" get all the Date values from Table")]
        public void WhenExecuteQueryOnEAMDBGetAllTheDateValuesFromTable(string dbname)
        {
            tmsWait.Hard(15); // Reason for more Wait is Table field updation is taking time. please do not remove this wait

            dbValues = db.returnSQLQueryresultsWithCompleteRowsInArrayFormat(dbname);
        }

        [When(@"EAM Actions page ""(.*)"" section ""(.*)""  is set to ""(.*)""")]
        public void WhenEAMActionsPageSectionIsSetTo(string p0, string p1, string p2)
        {
            tmsWait.Hard(5);
            string componentType = tmsCommon.GenerateData(p1);
            string value = tmsCommon.GenerateData(p2);
            switch (componentType)
            {
                case "Type":
                    ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("//span[@aria-owns='manualQueueType_listbox']")));
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(By.XPath("//span[@aria-owns='manualQueueType_listbox']"), value);

                    break;
                case "From Date":
                    ReUsableFunctions.enterValueOnWebElement(By.Id("txtFromDate"), value);
                    break;
                case "To Date":
                    ReUsableFunctions.enterValueOnWebElement(By.Id("txtToDate"), value);
                    break;
                case "SSN":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemDemographics.UIMODSSN, value);
                    break;
            }

        }

        [Then(@"Verify EAM page ""(.*)"" section has ""(.*)"" drop down values matched with UI and Database values")]
        public void ThenVerifyEAMPageSectionHasDropDownValuesMatchedWithUIAndDatabaseValues(string p0, string p1)
        {
            IList<IWebElement> webdrpValues;
            List<string> stringdrpValues;
            List<string> stringDBValues;
            List<int> integerDBValues;
            List<DateTime> dateDBValues;
            List<string> resultantString;
            List<string> pbpfinallist = new List<string>();
            switch (p1.ToLower())
            {
                case "pbp":
                    //SelectElement wV = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@id='ddlPbp']")));
                    //webdrpValues = wV.Options;
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@aria-owns='ddlPbp_listbox']//span[@aria-label='select']")));
                    tmsWait.Hard(2);
                    webdrpValues = Browser.Wd.FindElements(By.XPath("//ul[@id='ddlPbp_listbox']/li"));
                    tmsWait.Hard(2);
                    int listcount = webdrpValues.Count();
                    List<string> pbplist = new List<string>();
                    for (int i = 0; i < listcount; i++)
                    {
                        string[] split_value = webdrpValues[i].Text.Split('-');
                        tmsWait.Hard(2);
                        if (i != 0)
                        {
                            pbplist.Add(split_value[0].Trim());
                        }

                    }
                    //foreach (var t in pbplist)
                    //{
                    //    pbpfinallist.Add(t);
                    //    Console.WriteLine(t);
                    //}

                    // stringdrpValues = ConvertWebElementInToString(webdrpValues);
                    stringDBValues = dbValues;
                    tmsWait.Hard(2);
                    resultantString = compareTwoList(pbplist, stringDBValues);
                    foreach (string temp in resultantString)
                    {
                        if (resultantString.Count == 1)
                        {
                            if (temp.Equals("<Select a Value>"))
                            {
                                Assert.IsTrue(true, " All values are matched");
                                break;
                            }
                            else
                            {
                                Assert.Fail("DB values are not displayed on Drop down");
                            }
                        }
                        else
                        {
                            Assert.Fail(" DB values and Drop down values are not matching");
                        }

                    }
                    break;
            }
        }


        [Then(@"Verify EAM page ""(.*)"" drop down values matched with Database values")]
        public void ThenVerifyEAMPageDropDownValuesMatchedWithDatabaseValues(string type)
        {
            IList<IWebElement> webdrpValues;
            List<string> stringdrpValues;
            List<string> stringDBValues;
            List<int> integerDBValues;
            List<DateTime> dateDBValues;
            List<string> resultantString;
            List<string> pbpfinallist = new List<string>();
            switch (type.ToLower())
            {
                case "pbp":
                    //SelectElement wV = new SelectElement(Browser.Wd.FindElement(By.XPath("//select[@id='ddlPbp']")));
                    //webdrpValues = wV.Options;
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@aria-owns='ddlPbp_listbox']//span[@aria-label='select']")));
                    tmsWait.Hard(2);
                    webdrpValues = Browser.Wd.FindElements(By.XPath("//ul[@id='ddlPbp_listbox']/li"));
                    tmsWait.Hard(2);
                    int listcount = webdrpValues.Count();
                    List<string> pbplist = new List<string>();
                    for (int i = 0; i < listcount; i++)
                    {
                        string[] split_value = webdrpValues[i].Text.Split('-');
                        tmsWait.Hard(2);
                        if (i != 0)
                        {
                            pbplist.Add(split_value[0].Trim());
                        }

                    }
                    //foreach (var t in pbplist)
                    //{
                    //    pbpfinallist.Add(t);
                    //    Console.WriteLine(t);
                    //}

                    // stringdrpValues = ConvertWebElementInToString(webdrpValues);
                    stringDBValues = dbValues;
                    tmsWait.Hard(2);
                    resultantString = compareTwoList(pbplist, stringDBValues);
                    foreach (string temp in resultantString)
                    {
                        if (resultantString.Count == 1)
                        {
                            if (temp.Equals("<Select a Value>"))
                            {
                                Assert.IsTrue(true, " All values are matched");
                                break;
                            }
                            else
                            {
                                Assert.Fail("DB values are not displayed on Drop down");
                            }
                        }
                        else
                        {
                            Assert.Fail(" DB values and Drop down values are not matching");
                        }

                    }
                    break;
            }
        }

        List<string> compareTwoList(List<string> drpValues, List<string> dbValues)
        {
            List<string> resultantList = new List<string>();

            Console.WriteLine("Difference in the Drop Down List and DB value lists...");
            IEnumerable<string> list3;
            list3 = drpValues.Except(dbValues);
            foreach (string value in list3)
            {
                resultantList.Add(value);
            }
            return resultantList;
        }


        List<string> ConvertWebElementInToString(IList<IWebElement> webdrpValues)
        {
            List<string> temp = new List<string>();
            Console.WriteLine(" List of Values in Drop Down list");
            foreach (IWebElement t in webdrpValues)
            {
                temp.Add(t.Text);
                Console.WriteLine(t.Text);
            }
            return temp;

        }

        [Then(@"Verify EAM Administration page View Edit Plan Info section has Plan Id ""(.*)"" and PBP ""(.*)"" and PBP Type ""(.*)""")]
        public void ThenVerifyEAMAdministrationPageViewEditPlanInfoSectionHasPlanIdAndPBPAndPBPType(string p0, string p1, string p2)
        {
            string planid = tmsCommon.GenerateData(p0.ToString());
            string pbp = tmsCommon.GenerateData(p1.ToString());
            string pbptype = tmsCommon.GenerateData(p2.ToString());
            bool hasrow = false;
            int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {
                    hasrow = Browser.Wd.FindElement(By.XPath("//div[@test-id='planInfo-grid-plans']//td/span[contains(.,'" + planid + "')]/parent::td/following-sibling::td/span[contains(.,'" + pbp + "')]/parent::td/following-sibling::td[contains(.,'" + pbptype + "')]")).Displayed;

                    break;
                }
                catch
                {

                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);
                }

            }
            //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed);

            Assert.IsTrue(hasrow, "There is no such row Present");
            tmsWait.Hard(5);
        }

        [When(@"EAM Administration page View Edit Plan Info section Edit icon is clicked for Plan Id ""(.*)"" and PBP ""(.*)"" and PBP Type ""(.*)""")]
        public void WhenEAMAdministrationPageViewEditPlanInfoSectionEditIconIsClickedForPlanIdAndPBPAndPBPType(string p0, string p1, string p2)
        {


            string planid = tmsCommon.GenerateData(p0.ToString());
            string pbp = tmsCommon.GenerateData(p1.ToString());
            string pbptype = tmsCommon.GenerateData(p2.ToString());
            bool hasrow = false;

            int totalPagesIntheGrid = 0;
            
                tmsWait.Hard(10);
                string xpath = "//div[@role='presentation']//td[contains(.,'" + planid + "')]/following-sibling::td[contains(.,'" + pbp + "')]/following-sibling::td[contains(.,'" + pbptype + "')]/following-sibling::td/a[@name='edit']";

                hasrow = ReUsableFunctions.clickOnGridElement(xpath);
                // ReUsableFunctions.verifyGridElementPresence(xpath);
            
                    
                //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed);
            
            Assert.IsTrue(hasrow, "There is no such row Present");
            tmsWait.Hard(7);
        }

        [When(@"EAM Administration page View Edit Plan Info section Notify ""(.*)"" and assigned to ""(.*)""")]
        public void WhenEAMAdministrationPageViewEditPlanInfoSectionNotifyAndAssignedTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = null;
            switch (field.ToLower())
            {
                case "planid": value = Browser.Wd.FindElement(By.XPath("//input[@test-id='planInfoDetails-input-planId']")).GetAttribute("value");
                    break;
                case "effectivedate": value = Browser.Wd.FindElement(By.XPath("//input[@test-id='planInfoDetails-txt-effDate']")).GetAttribute("value");
                    break;
            }

            fw.setVariable(p1, value);
        }



        [When(@"EAM Administration page View Edit Plan Info section clear all Field")]
        public void WhenEAMAdministrationPageViewEditPlanInfoSectionClearAllField()
        {
            // tmsWait.Hard(2);
            //cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoEffDate.SendKeys(Keys.Tab);

            cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoEffDate.Clear();
            // tmsWait.Hard(2);
            //  cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoEffDate.SendKeys(Keys.Tab);
            // tmsWait.Hard(2);
            cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoDeductible.Clear();
            //  tmsWait.Hard(2);
            // cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoDeductible.SendKeys(Keys.Tab);

            cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPremiumC.Clear();
            //   tmsWait.Hard(2);
            // cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPremiumC.SendKeys(Keys.Tab);

            cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPremiumD.Clear();
            //  tmsWait.Hard(2);
            //cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoMMPState.SendKeys(Keys.Tab);
        }
        [When(@"EAM Administration page View Edit Plan Info section ""(.*)"" component is set to Other than ""(.*)""")]
        public void WhenEAMAdministrationPageViewEditPlanInfoSectionComponentIsSetToOtherThan(string p0, string p1)
        {
            List<string> stringValues;
            ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoMMPState);
            IList<IWebElement> mmp = Browser.Wd.FindElements(By.XPath("//div[@class='k-animation-container']//li"));
            stringValues = ConvertWebElementInToString(mmp);
            foreach (string value in stringValues)
            {
                if (!(p0.Equals(value)))
                {
                    UIMODUtilFunctions.selectDropDownValueFromGendoUIWithoutAriaOwns(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoMMPState, value);

                    GlobalRef.MMPState = value;
                    break;
                }

            }



        }


        [When(@"EAM Administration page View Edit Plan Info section ""(.*)"" tab is clicked")]
        public void WhenEAMAdministrationPageViewEditPlanInfoSectionTabIsClicked(string p0)
        {
            string field_tab = tmsCommon.GenerateData(p0);

            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + field_tab + "')]")));
            tmsWait.Hard(2);

           
        }

        [When(@"EAM Administration page View Edit Plan Info PBPLevel tab Edit icon is clicked for planid ""(.*)"" and pbpid ""(.*)""")]
        public void WhenEAMAdministrationPageViewEditPlanInfoPBPLevelTabEditIconIsClickedForPlanidAndPbpid(string p0, string p1)
        {
            string planid = tmsCommon.GenerateData(p0);
            string pbp = tmsCommon.GenerateData(p1);
            string tpage = Browser.Wd.FindElement(By.XPath("//kendo-pager-input/span")).Text;
            string[] tsplitpage = tpage.Split("of");
            int totalPagesIntheGrid = Int32.Parse(tsplitpage[1].Trim());
            bool hasrow;
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {

                    tmsWait.Hard(3);
                    hasrow = Browser.Wd.FindElement(By.XPath("//kendo-grid[@dir='ltr']//td[contains(.,'" + planid + "')]/following-sibling::td[contains(.,'" + pbp + "')]//following-sibling::td/a")).Displayed;
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//kendo-grid[@dir='ltr']//td[contains(.,'" + planid + "')]/following-sibling::td[contains(.,'" + pbp + "')]//following-sibling::td/a")));
                    tmsWait.Hard(1);
                    break;
                }
                catch
                {

                    //tmsWait.Hard(5);
                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);

                    tmsWait.Hard(3);
                }

            }

        }

        [When(@"EAM Administration page View Edit Plan Info section ""(.*)"" is set to ""(.*)""")]
        public void WhenEAMAdministrationPageViewEditPlanInfoSectionIsSetTo(string p0, string p1)
        {
            string field= tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);

            switch(field)
            {
                case "EGWP": if(value=="checked")
                    {
                        fw.ExecuteJavascript(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoEGWPChkbox);
                    }
                    break;

                case "EGHP":
                    if (value == "checked")
                    {
                        fw.ExecuteJavascript(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoEGHPChkbox);
                    }
                    break;
            }
        }


        [When(@"EAM Administration page View Edit Plan Info PBPLevel tab ""(.*)"" button is clicked")]
        public void WhenEAMAdministrationPageViewEditPlanInfoPBPLevelTabButtonIsClicked(string p0)
        {
            fw.ExecuteJavascript(cfUIMODEAMAdmin.ViewEditPlanInfo.PBPLevelSaveButton);
            tmsWait.Hard(2);
        }



        [When(@"EAM Administration page View Edit Plan Info section ""(.*)"" component is set to ""(.*)""")]
        public void WhenEAMAdministrationPageViewEditPlanInfoSectionComponentIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            string date = "";
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                switch (field.ToLower())
                {
                    case "pbp type":
                        ReUsableFunctions.clickOnWebElementAngJS(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPBPTypeAngJS, value); break;
                    //  UIMODUtilFunctions.selectDropDownValueFromGendoUIWithoutAriaOwns(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPBPType, value);
                    case "mmp state":
                        tmsWait.Hard(2);

                        //By Drp = By.XPath("(//label[text()='MMP State']/parent::div//span)[4]");
                        //By typeapp = By.XPath("//li[text()='" + value + "']");




                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        //tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        //break;
                        ReUsableFunctions.clickOnWebElementAngJS(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoMMPStateAngJS, value); break; ;
                    //  UIMODUtilFunctions.selectDropDownValueFromGendoUIWithoutAriaOwns(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoMMPState, value); break;
                    case "end date":
                        date = "End Date";
                        //ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoEndDate);
                        ReUsableFunctions.enterValueOnWebElementWithClear(date, value); break;
                    case "effective date":

                        date = "Effective Date";

                        // ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoEffDateAngJS);
                        ReUsableFunctions.enterValueOnWebElementWithClear(date, value); break;
                    case "death date":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoEffDate);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoEffDate, value); break;
                    case "medicare product name":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoMedicareProductName);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoMedicareProductName, value); break;
                    case "department":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanDepartment);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanDepartment, value); break;
                    case "hours of operation":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoHouseOfOp);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoHouseOfOp, value); break;
                    case "premc":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPremiumC);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPremiumC, value); break;
                    case "premd":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPremiumD);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPremiumD, value); break;
                    case "deductible":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoDeductible);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoDeductible, value); break;
                    case "address 1":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoAddress1);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoAddress1, value); break;
                    case "city":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoCity);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoCity, value); break;
                    case "state":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoStates);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoStates, value); break;
                    case "zip":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoZip);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoZip, value); break;
                    case "rx group":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoRxGroup);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoRxGroup, value); break;
                    case "rx id":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoRxId);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoRxId, value); break;
                    case "rx bin":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoRxBin);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoRxBin, value); break;
                    case "rx pcn":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoRxPCN);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoRxPCN, value); break;
                    default:
                        break;

                }
            }
            else
            {

                switch (field.ToLower())
                {
                    case "pbp type":
                        ReUsableFunctions.clickOnWebElementAngJS(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPBPType, value);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUIWithoutAriaOwns(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPBPType, value); break; ;
                    case "mmp state":
                        tmsWait.Hard(2);



                        ReUsableFunctions.clickOnWebElementAngJS(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoMMPState, value);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUIWithoutAriaOwns(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoMMPState, value); break;
                    case "end date":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoEndDate);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoEndDate, value); break;
                    case "effective date":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoEffDate);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoEffDate, value); break;
                    case "death date":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoEffDate);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoEffDate, value); break;
                    case "medicare product name":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoMedicareProductName);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoMedicareProductName, value); break;
                    case "department":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanDepartment);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanDepartment, value); break;
                    case "hours of operation":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoHouseOfOp);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoHouseOfOp, value); break;
                    case "premc":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPremiumC);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPremiumC, value); break;
                    case "premd":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPremiumD);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPremiumD, value); break;
                    case "deductible":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoDeductible);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoDeductible, value); break;
                    case "address 1":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoAddress1);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoAddress1, value); break;
                    case "city":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoCity);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoCity, value); break;
                    case "state":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoStates);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoStates, value); break;
                    case "zip":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoZip);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoZip, value); break;
                    case "rx group":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoRxGroup);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoRxGroup, value); break;
                    case "rx id":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoRxId);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoRxId, value); break;
                    case "rx bin":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoRxBin);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoRxBin, value); break;
                    case "rx pcn":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoRxPCN);
                        ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoRxPCN, value); break;
                    default:
                        break;

                }
            }
        }


        [Then(@"Verify EAM Administration page View Edit Plan Info section ""(.*)"" component is set to ""(.*)""")]
        public void ThenVerifyEAMAdministrationPageViewEditPlanInfoSectionComponentIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                switch (field.ToLower())
                {
                    case "pbp type":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPBPType);
                        ReUsableFunctions.compareExpectedValueWithKendoDropDownValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPBPType); break;
                    case "mmp state":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoMMPState);
                        ReUsableFunctions.compareExpectedValueWithKendoDropDownValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoMMPState); break;
                    case "end date":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoEndDate);
                        ReUsableFunctions.compareExpectedStringActualWebElementStringValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoEndDate); break;
                    case "effective date":
                        // ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoEffDate);
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoEffDate); break;
                    case "medicare product name":
                        //ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoMedicareProductName);
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoMedicareProductName);
                        //string pagesource= cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoMedicareProductName.p
                        break;
                    case "department":
                        // ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanDepartment);
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanDepartment); break;
                    case "hours of operation":
                        //ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoHouseOfOp);
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoHouseOfOp); break;
                    case "premc":
                        // ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPremiumC);
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPremiumC); break;
                    case "premd":
                        //ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPremiumD);
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPremiumD); break;
                    case "deductible":
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoDeductible); break;
                    case "address 1":
                        //ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoAddress1);
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoAddress1); break;
                    case "city":
                        //ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoCity);
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoCity); break;
                    case "state":
                       // ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoMMPStateTextAngJS);
                      ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoStatesAngJS); break;
                    case "zip":
                        // ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoZip);
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoZip); break;
                    case "rx group":
                        //ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoRxGroup);
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoRxGroup); break;
                    case "rx id":
                        //ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoRxId);
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoRxId); break;
                    default:
                        break;
                }
            }
            else
            {
                switch (field.ToLower())
                {
                    case "pbp type":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPBPType);
                        ReUsableFunctions.compareExpectedValueWithKendoDropDownValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPBPType); break;
                    case "mmp state":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoMMPState);
                        ReUsableFunctions.compareExpectedValueWithKendoDropDownValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoMMPState); break;
                    case "end date":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoEndDate);
                        ReUsableFunctions.compareExpectedStringActualWebElementStringValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoEndDate); break;
                    case "effective date":
                        // ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoEffDate);
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoEffDate); break;
                    case "medicare product name":
                        //ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoMedicareProductName);
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoMedicareProductName);
                        //string pagesource= cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoMedicareProductName.p
                        break;
                    case "department":
                        // ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanDepartment);
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanDepartment); break;
                    case "hours of operation":
                        //ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoHouseOfOp);
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoHouseOfOp); break;
                    case "premc":
                        // ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPremiumC);
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPremiumC); break;
                    case "premd":
                        //ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPremiumD);
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPremiumD); break;
                    case "deductible":
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoDeductible); break;
                    case "address 1":
                        //ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoAddress1);
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoAddress1); break;
                    case "city":
                        //ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoCity);
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoCity); break;
                    case "state":
                        //ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoStates);
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoStates); break;
                    case "zip":
                        // ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoZip);
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoZip); break;
                    case "rx group":
                        //ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoRxGroup);
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoRxGroup); break;
                    case "rx id":
                        //ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoRxId);
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(value, cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoRxId); break;
                    default:
                        break;

                }
            }
        }

        [When(@"Verify Status Override page displayed section ""(.*)"" component is set to ""(.*)""")]



        [When(@"Verify Edit Transaction diaglog Status Election Type drop down section ""(.*)"" component is set to ""(.*)""")]
        [Then(@"Verify Edit Transaction diaglog Status Override section ""(.*)"" component is set to ""(.*)""")]
        public void ThenVerifyEditTransactionDiaglogStatusElectionTypeDropDownSectionComponentIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            string actual = null;
            switch (field.ToLower())
            {
                case "transaction status":
                    actual = Browser.Wd.FindElement(By.XPath("//form[@id='statusOverrideTransaction']//span[@aria-owns='ddlTransactionStatus_listbox']")).Text;
                    Assert.IsTrue(actual.Equals(value), "transaction status drop down is not selected required value");
                    break;
                case "election type":

                    actual = Browser.Wd.FindElement(By.XPath("//form[@id='statusOverrideTransaction']//span[@aria-owns='ddlElectionType_listbox']")).Text;
                    Assert.IsTrue(actual.Equals(value), "Election type drop down is not selected required value");
                    break;
            }
        }
        [Then(@"Verify Transactions New ElectionType is set to ""(.*)""")]
        public void ThenVerifyTransactionsNewElectionTypeIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            string actual = Browser.Wd.FindElement(By.XPath("//div[@id='div_DemographicDetailsElectionType']//span[contains(text(),'" + value + "')]")).Text;
            Assert.IsTrue(actual.Equals(value), "Election type drop down is not selected required value");

        }

        [Then(@"Verify Edit Status Override page displayed section ""(.*)"" component is Disabled")]
        [Then(@"Verify Edit Transaction diaglog Status Election Type drop down section ""(.*)"" component is Disabled")]
        public void ThenVerifyEditTransactionDiaglogStatusElectionTypeDropDownSectionComponentIsDisabled(string p0)
        {

            string field = tmsCommon.GenerateData(p0);

            switch (field.ToLower())
            {
                case "pbp type":
                    ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPBPType); break;
                case "election type":

                    string actual = Browser.Wd.FindElement(By.XPath("//div[@id='div_DemographicDetailsElectionType']/span")).GetAttribute("aria-disabled");
                    Assert.IsTrue(Boolean.Parse(actual), "election type drop down is enabled");
                    break;
            }
        }
        [Then(@"Verify Edit Status Override page displayed section ""(.*)"" component is ""(.*)""")]
        public void ThenVerifyEditStatusOverridePageDisplayedSectionComponentIs(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string status = tmsCommon.GenerateData(p1);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
            }
            else { 
                switch (field.ToLower())
            {
                case "pbp type":
                    ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPBPType); break;

                case "election type":
                    if (status.Equals("disabled"))
                    {
                        string actual = Browser.Wd.FindElement(By.XPath("//div[@id='div_DemographicDetailsElectionType']/span")).GetAttribute("aria-disabled");
                        Assert.IsTrue(Boolean.Parse(actual), "election type drop down is enabled");
                    }
                    if (status.Equals("enabled"))
                    {
                        string actual = Browser.Wd.FindElement(By.XPath("//div[@id='div_DemographicDetailsElectionType']/span")).GetAttribute("aria-disabled");
                        Assert.IsFalse(Boolean.Parse(actual), "election type drop down is disabled");
                    }

                    break;
            }

            }
        }

        [Then(@"Verify Transactions New ElectionType is displayed ""(.*)"" component is read only")]
        public void ThenVerifyTransactionsNewElectionTypeIsDisplayedComponentIsReadOnly(string p0)
        {
            string actual = Browser.Wd.FindElement(By.XPath("//div[@id='div_DemographicDetailsElectionType']/span")).GetAttribute("aria-disabled");
            Assert.IsTrue(Boolean.Parse(actual), "election type drop down is enabled");
        }
        [Then(@"Verify Transactions New ElectionType M icon is displayed ""(.*)"" component read only")]
        public void ThenVerifyTransactionsNewElectionTypeMIconIsDisplayedComponentReadOnly(string p0)
        {
            Boolean actual = Browser.Wd.FindElement(By.XPath("//img[@test-id='transaction-i-isElectionTypeManual']")).Displayed;
            Assert.IsTrue((actual), "M ICON IS NOT DISPLAYING");
        }

        [Then(@"Verify EAM Administration page View Edit Plan Info section ""(.*)"" component is enabled")]


        [Then(@"Verify EAM Administration page View Edit Plan Info section ""(.*)"" component is Disabled")]
        public void ThenVerifyEAMAdministrationPageViewEditPlanInfoSectionComponentIsDisabled(string p0)
        {
            string field = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                switch (field.ToLower())
                {
                    case "pbp type":
                        ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPBPTypeAngJS); break;
                    case "mmp state":
                        //ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoMMPState); break;
                        string actual = cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoMMPStateAreaAngJS.GetAttribute("aria-disabled");
                        Assert.IsFalse(Boolean.Parse(actual), "MMP State drop down is enabled");
                        break;
                    case "end date":
                        ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoEndDateAngJS); break;
                    case "effective date":
                        ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoEffDateAngJS); break;
                    case "medicare product name":
                        ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoMedicareProductNameAngJS); break;
                    case "department":
                        ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanDepartmentAngJS); break;
                    case "hours of operation":
                        ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoHouseOfOpAngJS); break;
                    case "premc":
                        ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPremiumCAngJS); break;
                    case "premd":
                        ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPremiumDAngJS); break;
                    case "deductible":
                        ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoDeductibleAngJS); break;
                    case "address 1":
                        ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoAddress1AngJS); break;
                    case "city":
                        ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoCityAngJS); break;
                    case "state":
                        ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoStatesAngJS); break;
                    case "zip":
                        ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoZipAngJS); break;
                    case "rx group":
                        ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoRxGroupAngJS); break;
                    case "rx id":
                        ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoRxIdAngJS); break;
                    default:
                        break;
                }
            }

            else
            {

           
                switch (field.ToLower())
            {
                case "pbp type":
                    ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPBPType); break;
                case "mmp state":
                    //ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoMMPState); break;
                    string actual = cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoMMPState.GetAttribute("aria-disabled");
                    Assert.IsFalse(Boolean.Parse(actual), "MMP State drop down is enabled");
                    break;
                case "end date":
                    ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoEndDate); break;
                case "effective date":
                    ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoEffDate); break;
                case "medicare product name":
                    ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoMedicareProductName); break;
                case "department":
                    ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanDepartment); break;
                case "hours of operation":
                    ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoHouseOfOp); break;
                case "premc":
                    ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPremiumC); break;
                case "premd":
                    ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoPremiumD); break;
                case "deductible":
                    ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoDeductible); break;
                case "address 1":
                    ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoAddress1); break;
                case "city":
                    ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoCity); break;
                case "state":
                    ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoStates); break;
                case "zip":
                    ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoZip); break;
                case "rx group":
                    ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoRxGroup); break;
                case "rx id":
                    ReUsableFunctions.verifyComponentDisabled(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoRxId); break;
                default:
                    break;
                }
            }
        }
        [When(@"Verify EAM Administration page View Edit Plan Info section Warning msg ""(.*)""")]
        public void WhenVerifyEAMAdministrationPageViewEditPlanInfoSectionWarningMsg(string actualwarning)
        {
            tmsWait.Hard(3);
            string expectedwarning = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Changing the MMP State for this Plan/PBP will require changes to existing MMP Member Load Parameter rules for the Plan/PBP/State combination prior to this change. Once the MMP State is changed for Plan/PBP any existing rules will not be valid. You must terminate MMP rules for previous MMP State and enter new rules for new MMP State.')]")).Text;
            Assert.AreEqual(actualwarning, expectedwarning, "Warning message is not correct");
            tmsWait.Hard(1);

        }

        [When(@"Verify EAM Administration page View Edit Plan Info section red error msg ""(.*)""")]
        public void WhenVerifyEAMAdministrationPageViewEditPlanInfoSectionRedErrorMsg(string p0)
        {
            string field = tmsCommon.GenerateData(p0);

            switch (field.ToLower())
            {
                case "Plan Deductable is Required":
                    string Deductable = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Plan Deductable is Required')]")).Text;
                    Assert.IsTrue(Deductable.Contains("Plan Deductable is Required"));
                    break;
                case "Effective Date is Required":
                    string Effective = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Effective Date is Required')]")).Text;
                    Assert.IsTrue(Effective.Contains("Effective Date is Required"));
                    break;
                case "Please provide valid option":
                    string option = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Please provide valid option')]")).Text;
                    Assert.IsTrue(option.Contains("Please provide valid option"));
                    break;
                case "PremC is Required":
                    string PremC = Browser.Wd.FindElement(By.XPath("//span[contains(.,'PremC is Required')]")).Text;
                    Assert.IsTrue(PremC.Contains("PremC is Required"));
                    break;
                case "PremD is Required":
                    string PremD = Browser.Wd.FindElement(By.XPath("//span[contains(.,'PremD is Required')]")).Text;
                    Assert.IsTrue(PremD.Contains("PremD is Required"));
                    break;
            }
        }

        [When(@"EAM Administration page View Edit Plan Info section ""(.*)"" button is clicked")]
        public void WhenEAMAdministrationPageViewEditPlanInfoSectionButtonIsClicked(string p0)
        {
            
       
            string buttonclick = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                switch (buttonclick.ToLower())
                {
                    case "save":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoSaveBtn);
                        tmsWait.Hard(2);
                        break;
                    case "reset":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoResetBtn);
                        tmsWait.Hard(1);
                        break;
                    case "cancel":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoCancelBtn);
                        tmsWait.Hard(1);
                        break;
                    case "back to record":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoBacktoRecordAngJS);
                        tmsWait.Hard(2);
                        break;
                    case "ok":
                        ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("//button[@id='confirmationDialogYes']")));
                        tmsWait.Hard(2);
                        break;
                }
            }
            else
            {
                switch (buttonclick.ToLower())
                {
                    case "save":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoSaveBtn);
                        tmsWait.Hard(2);
                        break;
                    case "reset":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoResetBtn);
                        tmsWait.Hard(1);
                        break;
                    case "cancel":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoCancelBtn);
                        tmsWait.Hard(1);
                        break;
                    case "back to record":
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ViewEditPlanInfo.ViewEditPlanInfoBacktoRecord);
                        tmsWait.Hard(2);
                        break;
                    case "ok":
                        ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("//button[@id='confirmationDialogYes']")));
                        tmsWait.Hard(2);
                        break;

                }

            }
        }

        [When(@"EAM Administration page Manage Plan SCC section ""(.*)"" tab is clicked")]
        public void WhenEAMAdministrationPageManagePlanSCCSectionTabIsClicked(string p0)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                switch (p0)
                {
                    case "View/Edit":
                        ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("//*[@id='k-tabstrip-tab-0']")));
                        tmsWait.Hard(3);
                        break;
                    case "Upload File":
                        ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("//*[@id='k-tabstrip-tab-1']")));
                        tmsWait.Hard(3);
                        break;
                }
            }
            else
            {
                string tab = tmsCommon.GenerateData(p0);
                ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("//div[@id='tabStrip']//span[contains(.,'" + tab + "')]")));
                tmsWait.Hard(3);
            }
        }

        [When(@"Manage Plan SCC Plan ID is set to ""(.*)""")]
        public void WhenManagePlanSCCPlanIDIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlPlanId_listbox']"));
            UIMODUtilFunctions.selectDropDownValueFromGendoUI(ele, value);
        }

        [When(@"Manage Plan SCC PBP ID is set to ""(.*)""")]
        public void WhenManagePlanSCCPBPIDIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlPbp_listbox']"));
            UIMODUtilFunctions.selectDropDownValueFromGendoUI(ele, value);
        }

        [When(@"Manage Plan SCC Search Buton is Clicked")]
        public void WhenManagePlanSCCSearchButonIsClicked()
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@id='managePlanSccViewEditFrm']/div[3]/div/button[2]"));
                fw.ExecuteJavascript(ele);
                tmsWait.Hard(2);
            }
            else
            {
                IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='editScc-Save-btn']"));
                fw.ExecuteJavascript(ele);
                tmsWait.Hard(2);
            }
        }
        [Then(@"Manage Plan SCC Reset Button is Clicked")]
        public void ThenManagePlanSCCResetButtonIsClicked()
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@id='btnReset']"));
                fw.ExecuteJavascript(ele);
                tmsWait.Hard(2);
            }
            else
            {
                IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='editScc-Reset-btn']"));
                fw.ExecuteJavascript(ele);
                tmsWait.Hard(2);
            }
        }


        [Then(@"Verify Manage Plan SCC page displayed Plan ID as ""(.*)"" PBP as ""(.*)""")]
        public void ThenVerifyManagePlanSCCPageDisplayedPlanIDAsPBPAs(string p0, string p1)
        {
            string plan = tmsCommon.GenerateData(p0);
            string pbp = tmsCommon.GenerateData(p1);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//div[@test-id='sccMapping-Grid']//td[contains(.,'"+ plan + "')]/following-sibling::td[contains(.,'"+ pbp + "')]"));
            UIMODUtilFunctions.elementPresenceUsingWebElement(ele);
        }
        [Then(@"Verify Manage Plan SCC page displayed Search results")]
        public void ThenVerifyManagePlanSCCPageDisplayedSearchResults()
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(2);
                IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@id='managePlanSccViewEditGridFrm']/div/div/kendo-grid/div/kendo-grid-list/div/div[1]/table/tbody/tr[1]"));
                UIMODUtilFunctions.elementPresenceUsingWebElement(ele);
            }
            else
            {
                tmsWait.Hard(2);
                IWebElement ele = Browser.Wd.FindElement(By.XPath("//div[@test-id='sccMapping-Grid']//tbody/tr"));
                UIMODUtilFunctions.elementPresenceUsingWebElement(ele);
            }
          
        }

        [Then(@"Verify Manage Plan SCC page does not display Search results")]
        public void ThenVerifyManagePlanSCCPageDoesNotDisplaySearchResults()
        {
            tmsWait.Hard(2);
            try
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@id='managePlanSccViewEditGridFrm']/div/div/kendo-grid/div/kendo-grid-list/div/div[1]/table/tbody/tr[1]"));
                }
                else
                {
                    IWebElement ele = Browser.Wd.FindElement(By.XPath("//div[@test-id='sccMapping-Grid']//tbody/tr"));
                }
                  
            }
            catch
            {
                Assert.IsTrue(true, " Search results are displayed");
            }
           
            
        }

        [When(@"Manage Plan SCC page ADD button is Clicked")]
        public void WhenManagePlanSCCPageADDButtonIsClicked()
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@id='managePlanSccViewEditGridFrm']/div/div/kendo-grid/kendo-grid-toolbar/button"));
                fw.ExecuteJavascript(ele);
            }
            else
            {
                IWebElement ele = Browser.Wd.FindElement(By.XPath("//button[contains(.,'ADD')]"));
                fw.ExecuteJavascript(ele);
            }
            
        }

        [When(@"Manage Plan SCC page Plan ID is set as ""(.*)""")]
        public void WhenManagePlanSCCPagePlanIDIsSetAs(string p0)
        {
            string value = tmsCommon.GenerateData(p0);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//*[@id='gdDdlPlanId']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + value + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                tmsWait.Hard(3);
            }
            else
            {
                IWebElement plan = Browser.Wd.FindElement(By.CssSelector("[aria-owns='planId_listbox']"));
                UIMODUtilFunctions.selectDropDownValueFromGendoUI(plan, value);
            }
        }

        [When(@"Manage Plan SCC page PBP ID is set as ""(.*)""")]
        public void WhenManagePlanSCCPagePBPIDIsSetAs(string p0)
        {
            string value = tmsCommon.GenerateData(p0);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//*[@id='gdDdlPbpId']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + value + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                tmsWait.Hard(3);
            }
            else
            {
                IWebElement plan = Browser.Wd.FindElement(By.CssSelector("[aria-owns='pbp_listbox']"));
                UIMODUtilFunctions.selectDropDownValueFromGendoUI(plan, value);
            }
        }

        [When(@"Manage Plan SCC page Segment ID is set as ""(.*)""")]
        public void WhenManagePlanSCCPageSegmentIDIsSetAs(string p0)
        {
            string value = tmsCommon.GenerateData(p0);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//*[@id='gdDdlSegmentId']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + value + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                tmsWait.Hard(3);
            }
            else
            {
                IWebElement plan = Browser.Wd.FindElement(By.CssSelector("[aria-owns='segmentId_listbox']"));
                UIMODUtilFunctions.selectDropDownValueFromGendoUI(plan, value);
            }

        }

        [When(@"Manage Plan SCC page SCC is set as ""(.*)""")]
        public void WhenManagePlanSCCPageSCCIsSetAs(string p0)
        {

            string value = tmsCommon.GenerateData(p0);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//*[@id='gdDdlSscId']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + value + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                tmsWait.Hard(3);
            }
            else
            {
                IWebElement plan = Browser.Wd.FindElement(By.CssSelector("[aria-owns='scc_listbox']"));
                UIMODUtilFunctions.selectDropDownValueFromGendoUI(plan, value);
            }
        }

        [When(@"Manage Plan SCC page Effective Date is set as ""(.*)""")]
        public void WhenManagePlanSCCPageEffectiveDateIsSetAs(string p0)
        {
            string value = tmsCommon.GenerateData(p0);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
               

                By Drp = By.XPath("//kendo-datepicker[@id='effectiveDate']//span[@role='button']");
                AngularFunction.enterDate(Drp, value);

                tmsWait.Hard(1);

             
            }

            else
            {
                IWebElement eff = Browser.Wd.FindElement(By.XPath("//span[@aria-controls='effectiveDate_dateview']"));
                fw.ExecuteJavascript(eff);

                IWebElement selectedDate = Browser.Wd.FindElement(By.XPath("(//div[@id='effectiveDate_dateview']//table[@class='k-content k-month']//td/a[.='1'])[1]"));
                fw.ExecuteJavascript(selectedDate);

            }

        }

        [When(@"Manage Plan SCC page End Date Date is set as ""(.*)""")]
        public void WhenManagePlanSCCPageEndDateDateIsSetAs(string p0)
        {
            string value = tmsCommon.GenerateData(p0);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//kendo-datepicker[@id='endDate']//span[@role='button']");
                AngularFunction.enterDate(Drp, value);
            }
            else
            {
                IWebElement end = Browser.Wd.FindElement(By.XPath("//span[@aria-controls='endDate_dateview']"));
                fw.ExecuteJavascript(end);

                IWebElement prev = Browser.Wd.FindElement(By.XPath("//div[@id='endDate_dateview']//a[@aria-label='Next']"));
                fw.ExecuteJavascript(prev);
                fw.ExecuteJavascript(prev);
                IWebElement selectedDate = Browser.Wd.FindElement(By.XPath("(//div[@id='endDate_dateview']//table[@class='k-content k-month']//td/a[.='1'])[1]"));
                fw.ExecuteJavascript(selectedDate);

            }

        }

        [When(@"Manage Plan SCC page Click on Save Buton")]
        public void WhenManagePlanSCCPageClickOnSaveButon()
        {
            IWebElement save;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                save = Browser.Wd.FindElement(By.XPath("//button[@role='button']/span[@class='fas fa-save']"));
                fw.ExecuteJavascript(save);
            }
            else
            {
                 save = Browser.Wd.FindElement(By.XPath("//a[@role='button']/span[@class='k-i-check fa fa-floppy-o']"));
                fw.ExecuteJavascript(save);
            }
        }

        [When(@"Manage Plan SCC page Click on Save Buton and Verify Message as ""(.*)""")]
        public void WhenManagePlanSCCPageClickOnSaveButonAndVerifyMessageAs(string msg)
        {
            IWebElement save;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                save = Browser.Wd.FindElement(By.XPath("//button[@role='button']/span[@class='fas fa-save']"));
                fw.ExecuteJavascript(save);
            }
            else
            {
                save = Browser.Wd.FindElement(By.XPath("//a[@role='button']/span[@class='k-i-check fa fa-floppy-o']"));
                fw.ExecuteJavascript(save);
            }
           
            UIMODUtilFunctions.ToasterMessageVerification(msg);
        }

        [When(@"Manage Plan SCC page Plan ID is set as ""(.*)"" and Clicked on Save Button and Verify Error Toaster message as ""(.*)""")]
        public void WhenManagePlanSCCPagePlanIDIsSetAsAndClickedOnSaveButtonAndVerifyErrorToasterMessageAs(string p0, string p1)
        {
            string value = tmsCommon.GenerateData(p0);
            string msg = p1;
            IWebElement plan = Browser.Wd.FindElement(By.CssSelector("[aria-owns='planId_listbox']"));
            UIMODUtilFunctions.selectDropDownValueFromGendoUI(plan, value);
            tmsWait.Hard(2);
            IWebElement save = Browser.Wd.FindElement(By.XPath("//a[@role='button']/span[@class='k-i-check fa fa-floppy-o']"));
            fw.ExecuteJavascript(save);
            UIMODUtilFunctions.ToasterMessageVerification(msg);

            tmsWait.Hard(5);
        }

        [When(@"Manage Plan SCC PlanID is set as ""(.*)"" and clicked on save button and verify error toaster message as ""(.*)"" is required\.""")]
        public void WhenManagePlanSCCPlanIDIsSetAsAndClickedOnSaveButtonAndVerifyErrorToasterMessageAsIsRequired_(string p0, string p1)
        {
            string value = tmsCommon.GenerateData(p0);
            string msg = p1;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='sccMapping-select-gdDdlPlanId']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + value + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                tmsWait.Hard(3);
                IWebElement save_tmsx = Browser.Wd.FindElement(By.XPath("//button[@role='button']/span[@class='fas fa-save']"));
                fw.ExecuteJavascript(save_tmsx);
                string actualmsg = Browser.Wd.FindElement(By.XPath("//span[@id='gdDdlPbpId-error-msg']")).Text;
                Assert.IsTrue(actualmsg.Contains(msg));
                tmsWait.Hard(2);

            }
            else
            {
                IWebElement plan = Browser.Wd.FindElement(By.CssSelector("[aria-owns='planId_listbox']"));
            UIMODUtilFunctions.selectDropDownValueFromGendoUI(plan, value);
            tmsWait.Hard(2);
            IWebElement save = Browser.Wd.FindElement(By.XPath("//a[@role='button']/span[@class='k-i-check fa fa-floppy-o']"));
            fw.ExecuteJavascript(save);
            UIMODUtilFunctions.ToasterMessageVerification(msg);
            }
        }

        [When(@"Manage Plan SCC PlanID is set as ""(.*)"" and clicked on save button and verify all error validaton message ""(.*)"" ""(.*)"" ""(.*)"" ""(.*)"" ""(.*)""")]
        public void WhenManagePlanSCCPlanIDIsSetAsAndClickedOnSaveButtonAndVerifyAllErrorValidatonMessage(string p0, string p1, string p2, string p3, string p4, string p5)
        {
            string value = tmsCommon.GenerateData(p0);
            string pbpMsg = p1;
            string segmentMsg = p2;
            string sccMsg = p3;
            string effMsg = p4;
            string endDMsg = p5;

            By Drp = By.XPath("//kendo-dropdownlist[@test-id='sccMapping-select-gdDdlPlanId']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + value + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                tmsWait.Hard(3);
                IWebElement save_tmsx = Browser.Wd.FindElement(By.XPath("//button[@role='button']/span[@class='fas fa-save']"));
                fw.ExecuteJavascript(save_tmsx);
                string actualPBPmsg = Browser.Wd.FindElement(By.XPath("//span[@id='gdDdlPbpId-error-msg']")).Text;
                Assert.IsTrue(actualPBPmsg.Contains(pbpMsg));
                tmsWait.Hard(1);
            string actualSegmsg = Browser.Wd.FindElement(By.XPath("//span[@id='gdDdlSegmentId-error-msg']")).Text;
            Assert.IsTrue(actualSegmsg.Contains(segmentMsg));
            tmsWait.Hard(1);
            string actualSCCmsg = Browser.Wd.FindElement(By.XPath("//span[@id='gdDdlSscId-error-msg']")).Text;
            Assert.IsTrue(actualSCCmsg.Contains(sccMsg));
            tmsWait.Hard(1);
            string actualEffmsg = Browser.Wd.FindElement(By.XPath("//span[@id='effectiveDate-error-msg']")).Text;
            Assert.IsTrue(actualEffmsg.Contains(effMsg));
            tmsWait.Hard(1);
            string actualEndDmsg = Browser.Wd.FindElement(By.XPath("//span[@id='endDate-error-msg']")).Text;
            Assert.IsTrue(actualEndDmsg.Contains(endDMsg));
        }



        [When(@"Manage Plan SCC page PBP ID is set as ""(.*)"" and Clicked on Save Button and Verify Error Toaster message as ""(.*)""")]
        public void WhenManagePlanSCCPagePBPIDIsSetAsAndClickedOnSaveButtonAndVerifyErrorToasterMessageAs(string p0, string p1)
        {
            tmsWait.Hard(5);
            string value = tmsCommon.GenerateData(p0);
            string msg = p1;
            IWebElement plan = Browser.Wd.FindElement(By.CssSelector("[aria-owns='pbp_listbox']"));
            UIMODUtilFunctions.selectDropDownValueFromGendoUI(plan, value);
            tmsWait.Hard(2);
            IWebElement save = Browser.Wd.FindElement(By.XPath("//a[@role='button']/span[@class='k-i-check fa fa-floppy-o']"));
            fw.ExecuteJavascript(save);
            UIMODUtilFunctions.ToasterMessageVerification(msg);
            tmsWait.Hard(5);
        }

        [When(@"Manage Plan SCC PBPID is set as ""(.*)"" and clicked on save button and verify error toaster message as ""(.*)""")]
        public void WhenManagePlanSCCPBPIDIsSetAsAndClickedOnSaveButtonAndVerifyErrorToasterMessageAs(string p0, string p1)
        {
            tmsWait.Hard(5);
            string value = tmsCommon.GenerateData(p0);
            string msg = p1;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='sccMapping-select-gdDdlPbpId']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + value + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                tmsWait.Hard(3);
                IWebElement save_tmsx = Browser.Wd.FindElement(By.XPath("//a[@role='button']/span[@class='fas fa-save']"));
                fw.ExecuteJavascript(save_tmsx);
                tmsWait.Hard(2);
            }
            else
            {
                IWebElement plan = Browser.Wd.FindElement(By.CssSelector("[aria-owns='pbp_listbox']"));
                UIMODUtilFunctions.selectDropDownValueFromGendoUI(plan, value);
                tmsWait.Hard(2);
                IWebElement save = Browser.Wd.FindElement(By.XPath("//a[@role='button']/span[@class='k-i-check fa fa-floppy-o']"));
                fw.ExecuteJavascript(save);
                UIMODUtilFunctions.ToasterMessageVerification(msg);
                tmsWait.Hard(5);
            }
        }


        [When(@"Manage Plan SCC page Segment ID is set as ""(.*)"" and Clicked on Save Button and Verify Error Toaster message as ""(.*)""")]
        public void WhenManagePlanSCCPageSegmentIDIsSetAsAndClickedOnSaveButtonAndVerifyErrorToasterMessageAs(string p0, string p1)
        {
            tmsWait.Hard(5);
            string value = tmsCommon.GenerateData(p0);
            string msg = p1;
            IWebElement plan = Browser.Wd.FindElement(By.CssSelector("[aria-owns='segmentId_listbox']"));
            UIMODUtilFunctions.selectDropDownValueFromGendoUI(plan, value);
            tmsWait.Hard(2);
            IWebElement save = Browser.Wd.FindElement(By.XPath("//a[@role='button']/span[@class='k-i-check fa fa-floppy-o']"));
            fw.ExecuteJavascript(save);
            UIMODUtilFunctions.ToasterMessageVerification(msg);

            tmsWait.Hard(5);
        }

        [When(@"Manage Plan SCC SegmentID is set as ""(.*)"" and clicked on save button and verify error toaster message as ""(.*)""")]
        public void WhenManagePlanSCCSegmentIDIsSetAsAndClickedOnSaveButtonAndVerifyErrorToasterMessageAs(string p0, string p1)
        {
            tmsWait.Hard(5);
            string value = tmsCommon.GenerateData(p0);
            string msg = p1;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='sccMapping-select-gdDdlSegmentId']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + value + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                tmsWait.Hard(3);
                IWebElement save_tmsx = Browser.Wd.FindElement(By.XPath("//a[@role='button']/span[@class='fas fa-save']"));
                fw.ExecuteJavascript(save_tmsx);
                tmsWait.Hard(2);
            }
            else
            {
                IWebElement plan = Browser.Wd.FindElement(By.CssSelector("[aria-owns='segmentId_listbox']"));
                UIMODUtilFunctions.selectDropDownValueFromGendoUI(plan, value);
                tmsWait.Hard(2);
                IWebElement save = Browser.Wd.FindElement(By.XPath("//a[@role='button']/span[@class='k-i-check fa fa-floppy-o']"));
                fw.ExecuteJavascript(save);
                UIMODUtilFunctions.ToasterMessageVerification(msg);

                tmsWait.Hard(5);
            }
        }

        [When(@"Manage Plan SCC page SCC is set as ""(.*)"" and Clicked on Save Button and Verify Error Toaster message as ""(.*)""")]
        public void WhenManagePlanSCCPageSCCIsSetAsAndClickedOnSaveButtonAndVerifyErrorToasterMessageAs(string p0, string p1)
        {
            tmsWait.Hard(5);
            string value = tmsCommon.GenerateData(p0);
            string msg = p1;
            IWebElement plan = Browser.Wd.FindElement(By.CssSelector("[aria-owns='scc_listbox']"));
            UIMODUtilFunctions.selectDropDownValueFromGendoUI(plan, value);
            tmsWait.Hard(2);
            IWebElement save = Browser.Wd.FindElement(By.XPath("//a[@role='button']/span[@class='k-i-check fa fa-floppy-o']"));
            fw.ExecuteJavascript(save);
            UIMODUtilFunctions.ToasterMessageVerification(msg);

            tmsWait.Hard(5);
        }

        [When(@"Manage Plan SCC SCC is set as ""(.*)"" and clicked on save button and verify error toaster message as ""(.*)""")]
        public void WhenManagePlanSCCSCCIsSetAsAndClickedOnSaveButtonAndVerifyErrorToasterMessageAs(string p0, string p1)
        {
            tmsWait.Hard(5);
            string value = tmsCommon.GenerateData(p0);
            string msg = p1;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='sccMapping-select-gdDdlSscId']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + value + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                tmsWait.Hard(3);
                IWebElement save_tmsx = Browser.Wd.FindElement(By.XPath("//a[@role='button']/span[@class='fas fa-save']"));
                fw.ExecuteJavascript(save_tmsx);
                tmsWait.Hard(2);
            }
            else
            {
                IWebElement plan = Browser.Wd.FindElement(By.CssSelector("[aria-owns='scc_listbox']"));
                UIMODUtilFunctions.selectDropDownValueFromGendoUI(plan, value);
                tmsWait.Hard(2);
                IWebElement save = Browser.Wd.FindElement(By.XPath("//a[@role='button']/span[@class='k-i-check fa fa-floppy-o']"));
                fw.ExecuteJavascript(save);
                UIMODUtilFunctions.ToasterMessageVerification(msg);

                tmsWait.Hard(5);
            }
        }


        [When(@"Manage Plan SCC page Effective Date is set as ""(.*)"" and Clicked on Save Button and Verify Error Toaster message as ""(.*)""")]
        public void WhenManagePlanSCCPageEffectiveDateIsSetAsAndClickedOnSaveButtonAndVerifyErrorToasterMessageAs(string p0, string p1)
        {
            tmsWait.Hard(5);
            string value = tmsCommon.GenerateData(p0);

            IWebElement eff = Browser.Wd.FindElement(By.XPath("//span[@aria-controls='effectiveDate_dateview']"));
            fw.ExecuteJavascript(eff);

            IWebElement selectedDate = Browser.Wd.FindElement(By.XPath("(//div[@id='effectiveDate_dateview']//table[@class='k-content k-month']//td/a[.='1'])[1]"));
            fw.ExecuteJavascript(selectedDate);
            

            string msg = p1;
         
            tmsWait.Hard(2);
            IWebElement save = Browser.Wd.FindElement(By.XPath("//a[@role='button']/span[@class='k-i-check fa fa-floppy-o']"));
            fw.ExecuteJavascript(save);
            UIMODUtilFunctions.ToasterMessageVerification(msg);
            tmsWait.Hard(5);
        }

        [When(@"Manage Plan SCC Effective Date is set as ""(.*)"" and clicked on save button and verify error toaster message as ""(.*)""")]
        public void WhenManagePlanSCCEffectiveDateIsSetAsAndClickedOnSaveButtonAndVerifyErrorToasterMessageAs(string p0, string p1)
        {
            tmsWait.Hard(5);
            string value = tmsCommon.GenerateData(p0);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                value = value.Replace("/", "");
                By Drp = By.XPath("//kendo-datepicker[@test-id='sccMapping-txt-effectiveDate']//kendo-dateinput//input");
                Browser.Wd.FindElement(Drp).Clear();
                Browser.Wd.FindElement(Drp).SendKeys(value);

                tmsWait.Hard(3);
            }
            else
            {
                IWebElement eff = Browser.Wd.FindElement(By.XPath("//span[@aria-controls='effectiveDate_dateview']"));
                fw.ExecuteJavascript(eff);

                IWebElement selectedDate = Browser.Wd.FindElement(By.XPath("(//div[@id='effectiveDate_dateview']//table[@class='k-content k-month']//td/a[.='1'])[1]"));
                fw.ExecuteJavascript(selectedDate);


                string msg = p1;

                tmsWait.Hard(2);
                IWebElement save = Browser.Wd.FindElement(By.XPath("//a[@role='button']/span[@class='k-i-check fa fa-floppy-o']"));
                fw.ExecuteJavascript(save);
                UIMODUtilFunctions.ToasterMessageVerification(msg);
                tmsWait.Hard(5);
            }
        }


        [When(@"Manage Plan SCC page End Date Date is set as ""(.*)"" and Clicked on Save Button and Verify Error Toaster message as ""(.*)""")]
        public void WhenManagePlanSCCPageEndDateDateIsSetAsAndClickedOnSaveButtonAndVerifyErrorToasterMessageAs(string p0, string p1)
        {

            tmsWait.Hard(5);
            IWebElement end = Browser.Wd.FindElement(By.XPath("//span[@aria-controls='endDate_dateview']"));
            fw.ExecuteJavascript(end);

            IWebElement prev = Browser.Wd.FindElement(By.XPath("//div[@id='endDate_dateview']//a[@aria-label='Previous']"));
            fw.ExecuteJavascript(prev);
            fw.ExecuteJavascript(prev);
            IWebElement selectedDate = Browser.Wd.FindElement(By.XPath("(//div[@id='endDate_dateview']//table[@class='k-content k-month']//td/a[.='1'])[1]"));
            fw.ExecuteJavascript(selectedDate);
          

            string msg = p1;
            
            tmsWait.Hard(2);
            IWebElement save = Browser.Wd.FindElement(By.XPath("//a[@role='button']/span[@class='k-i-check fa fa-floppy-o']"));
            fw.ExecuteJavascript(save);
            UIMODUtilFunctions.ToasterMessageVerification(msg);
            tmsWait.Hard(5);
        }

        [When(@"Manage Plan SCC End Date is set as ""(.*)"" and clicked on save button and verify error toaster message as ""(.*)""")]
        public void WhenManagePlanSCCEndDateIsSetAsAndClickedOnSaveButtonAndVerifyErrorToasterMessageAs(string p0, string p1)
        {
            tmsWait.Hard(5);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                String value = p0.Replace("/", "");
                By Drp = By.XPath("//kendo-datepicker[@test-id='sccMapping-txt-endDate']//kendo-dateinput//input");
                Browser.Wd.FindElement(Drp).Clear();
                Browser.Wd.FindElement(Drp).SendKeys(value);

                tmsWait.Hard(3);
            }
            else
            {
                IWebElement end = Browser.Wd.FindElement(By.XPath("//span[@aria-controls='endDate_dateview']"));
                fw.ExecuteJavascript(end);

                IWebElement prev = Browser.Wd.FindElement(By.XPath("//div[@id='endDate_dateview']//a[@aria-label='Previous']"));
                fw.ExecuteJavascript(prev);
                fw.ExecuteJavascript(prev);
                IWebElement selectedDate = Browser.Wd.FindElement(By.XPath("(//div[@id='endDate_dateview']//table[@class='k-content k-month']//td/a[.='1'])[1]"));
                fw.ExecuteJavascript(selectedDate);


                string msg = p1;

                tmsWait.Hard(2);
                IWebElement save = Browser.Wd.FindElement(By.XPath("//a[@role='button']/span[@class='k-i-check fa fa-floppy-o']"));
                fw.ExecuteJavascript(save);
                UIMODUtilFunctions.ToasterMessageVerification(msg);
                tmsWait.Hard(5);
            }
    }


        [Then(@"Verify Manage Plan SCC page ""(.*)"" field is displayed")]
        public void ThenVerifyManagePlanSCCPageFieldIsDisplayed(string p0)
        {
            string fieldName = tmsCommon.GenerateData(p0);
            By loc;

            switch(fieldName)
            {
                case "PlanID":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        loc = By.XPath("//label[text()='Plan ID']/parent::div//span[1]");
                        UIMODUtilFunctions.elementPresenceUsingLocators(loc);
                    }
                    else
                    {
                        loc = By.CssSelector("[aria-owns='ddlPlanId_listbox']");
                        UIMODUtilFunctions.elementPresenceUsingLocators(loc);
                    }
                  
                    break;
                case "PBPID":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        loc = By.XPath("//label[text()='PBP']/parent::div//span[1]");
                        UIMODUtilFunctions.elementPresenceUsingLocators(loc);
                    }
                    else
                    {
                        loc = By.CssSelector("[aria-owns='ddlPbp_listbox']");
                        UIMODUtilFunctions.elementPresenceUsingLocators(loc);
                    }
                    break;

                case "SCC":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        loc = By.XPath("//label[text()='SCC']/parent::div//span[1]");
                        UIMODUtilFunctions.elementPresenceUsingLocators(loc);
                    }
                    else
                    {
                        loc = By.CssSelector("[aria-owns='dllSccId_listbox']");
                        UIMODUtilFunctions.elementPresenceUsingLocators(loc);
                    }
                    break;

                case "SegmentID":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        loc = By.XPath("//label[text()='Segment ID']/parent::div//span[1]");
                        UIMODUtilFunctions.elementPresenceUsingLocators(loc);
                    }
                    else
                    {
                        loc = By.CssSelector("[aria-owns='ddlSegmentId_listbox']");
                        UIMODUtilFunctions.elementPresenceUsingLocators(loc);
                    }
                    break;

                case "RESET":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        loc = By.XPath("//*[@id='btnReset']");
                        UIMODUtilFunctions.elementPresenceUsingLocators(loc);
                    }
                    else
                    {
                        loc = By.CssSelector("[test-id='editScc-Reset-btn']");
                        UIMODUtilFunctions.elementPresenceUsingLocators(loc);
                    }
                    break;

                case "SEARCH":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        loc = By.XPath("//*[@id='managePlanSccViewEditGridFrm']/div/div/kendo-grid/div/kendo-grid-list/div/div[1]/table/tbody/tr[1]");
                        UIMODUtilFunctions.elementPresenceUsingLocators(loc);
                    }
                    else
                    {
                        loc = By.CssSelector("[test-id='editScc-Save-btn']");
                        UIMODUtilFunctions.elementPresenceUsingLocators(loc);
                    }
                    break;
                case "ADD":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        loc = By.XPath("//*[@id='managePlanSccViewEditGridFrm']/div/div/kendo-grid/kendo-grid-toolbar/button");
                        UIMODUtilFunctions.elementPresenceUsingLocators(loc);
                    }
                    else
                    {
                        loc = By.XPath("//button[contains(.,'ADD')]");
                        UIMODUtilFunctions.elementPresenceUsingLocators(loc);
                    }
                    break;
            }
        }

        [When(@"EAM Administration page Manage Plan SCC section ""(.*)"" component is set to ""(.*)""")]
        public void WhenEAMAdministrationPageManagePlanSCCSectionComponentIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            int index = 4;
            tmsWait.Hard(3);
            switch (field.ToLower())
            {
                case "plan id":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {


                        //UIMODUtilFunctions.selectDropDownValueFromGendoUI(field, value, index);

                        By Drp = By.XPath("//kendo-dropdownlist[@test-id='sccMapping-select-ddlPlanId']//span[@class='k-select']");
                        By typeapp = By.XPath("//li[text()='" + value + "']");
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                    }

                else
                {

                   

                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ManagePlanSCC.PlanIDDropdownlist);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUIWithoutAriaOwns(cfUIMODEAMAdmin.ManagePlanSCC.PlanIDDropdownlist, value);
                    tmsWait.Hard(2);
                    }
                    break;
                case "pbp":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {

                        By Drp = By.XPath("//kendo-dropdownlist[@test-id='mmpManagement-select-ddlPbpId']//span[@class='k-select']");
                        By typeapp = By.XPath("//li[text()='" + value + "']");
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                        //UIMODUtilFunctions.selectDropDownValueFromGendoUI(field, value, index);


                    }

                    else
                    {

                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ManagePlanSCC.PBPIDDropdownlist);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUIWithoutAriaOwns(cfUIMODEAMAdmin.ManagePlanSCC.PBPIDDropdownlist, value);
                    }
                    break;
                case "segment id":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {



                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(field, value, index);


                    }

                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ManagePlanSCC.SegmentIDDropdownlist);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUIWithoutAriaOwns(cfUIMODEAMAdmin.ManagePlanSCC.SegmentIDDropdownlist, value);
                    }
                    break;
                case "scc":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {



                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(field, value, index);


                    }

                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ManagePlanSCC.SCCDropdownlist);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUIWithoutAriaOwns(cfUIMODEAMAdmin.ManagePlanSCC.SCCDropdownlist, value);

                    }
                    break;
                case "effective date":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {



                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(field, value, index);


                    }

                    else
                    {
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMAdmin.ManagePlanSCC.EffectiveDate, value);
                    }

                    break;
                case "end date":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {



                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(field, value, index);


                    }

                    else
                    {
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMAdmin.ManagePlanSCC.EndDate, value);
                    }
                    break;
            }
        }




        [When(@"EAM Administration page Manage Plan SCC section ""(.*)"" button is clicked")]
        public void WhenEAMAdministrationPageManagePlanSCCSectionButtonIsClicked(string p0)
        {
            string buttonclick = tmsCommon.GenerateData(p0);
            switch (buttonclick.ToLower())
            {
                case "search":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {



                        ReUsableFunctions.clickOnSearchMMP();


                    }

                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ManagePlanSCC.SearchBtn);
                    } tmsWait.Hard(2);
                    break;
                case "reset":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ManagePlanSCC.ResetBtn);
                    tmsWait.Hard(1);
                    break;
                case "add":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ManagePlanSCC.ADDBtn);
                    tmsWait.Hard(3);
                    break;
            }
        }


        [When(@"EAM Administration page Manage Plan SCC section Add ""(.*)"" is set to ""(.*)""")]
        public void WhenEAMAdministrationPageManagePlanSCCSectionAddIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            string xpath1 = "(//kendo-dropdownlist[@test-id='sccMapping-select-gdDdl";
            string xpath2 ="']//span)[";

            //(//kendo-dropdownlist[@test-id='sccMapping-select-gdDdlPbpId']//span)[3]
            int index = 3;
            switch (field.ToLower())
            {
                case "plan id":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {

                        string full= xpath1+"PlanId"+ xpath2+index+"]";
                        UIMODUtilFunctions.selectDropDownValueFromKendo(full, value);
                    }
                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ManagePlanSCC.AddPlanId);
                        tmsWait.Hard(1);
                        // UIMODUtilFunctions.selectDropDownValueFromGendoUIWithoutAriaOwns(cfUIMODEAMAdmin.ManagePlanSCC.AddPlanId, value);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//ul[@id='planId_listbox']/li[contains(.,'" + value + "')]")));
                        tmsWait.Hard(2);
                    }  break;
                case "pbp":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {

                        string full = xpath1 + "PbpId" + xpath2 + index + "]";
                        UIMODUtilFunctions.selectDropDownValueFromKendo(full, value);
                    }
                    else { 
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ManagePlanSCC.AddPBP);
                    tmsWait.Hard(1);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//ul[@id='pbp_listbox']/li[contains(.,'" + value + "')]")));
                    // UIMODUtilFunctions.selectDropDownValueFromGendoUIWithoutAriaOwns(cfUIMODEAMAdmin.ManagePlanSCC.AddPBP, value);
                    tmsWait.Hard(2);
                    }
                    break;
                case "segment id":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {

                        string fullxpath = xpath1 + "SegmentId" + xpath2 + index + "]";
                        UIMODUtilFunctions.selectDropDownValueFromKendo(fullxpath, value);
                    }
                    else { 
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ManagePlanSCC.AddSegment);
                    tmsWait.Hard(1);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//ul[@id='segmentId_listbox']/li[contains(.,'" + value + "')]")));
                    //UIMODUtilFunctions.selectDropDownValueFromGendoUIWithoutAriaOwns(cfUIMODEAMAdmin.ManagePlanSCC.AddSegment, value);
                    tmsWait.Hard(2);
                    }
                    break;
                case "scc":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {

                        string fullxpath = xpath1 + "SscId" + xpath2 + index + "]";
                        //UIMODUtilFunctions.selectDropDownValueFromGendoUI(field, value, index);
                        UIMODUtilFunctions.selectDropDownValueFromKendo(fullxpath, value);
                    }
                    else
                    {
                        ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.ManagePlanSCC.AddSCC);
                        UIMODUtilFunctions.selectDropDownValueFromGendoUIWithoutAriaOwns(cfUIMODEAMAdmin.ManagePlanSCC.AddSCC, value);
                        cfUIMODEAMAdmin.ManagePlanSCC.AddSCC.SendKeys(Keys.Tab);
                        tmsWait.Hard(2);
                    }
                    break;
                case "effective date":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        //value = value.Replace("/", "");
                        //By Drp = By.XPath("//kendo-datepicker[@id='effectiveDate']//input");
                        //Browser.Wd.FindElement(Drp).Clear();

                        //Browser.Wd.FindElement(Drp).SendKeys(value);
                        IWebElement effectivedate= Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='sccMapping-txt-effectiveDate']//span[@role='button']"));

                        AngularFunction.enterDate(effectivedate, value);

                        tmsWait.Hard(3);
                    }
                    else
                    {
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMAdmin.ManagePlanSCC.EffectiveDate, value);
                        cfUIMODEAMAdmin.ManagePlanSCC.AddEffectiveDate.SendKeys(Keys.Tab);
                    }
                    tmsWait.Hard(2);
                    break;
                case "end date":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        //value = value.Replace("/", "");
                        //By Drp = By.XPath("//kendo-datepicker[@id='endDate']//input");
                        //Browser.Wd.FindElement(Drp).Clear();

                        //Browser.Wd.FindElement(Drp).SendKeys(value);

                        IWebElement effectivedate = Browser.Wd.FindElement(By.XPath("//kendo-datepicker[@test-id='sccMapping-txt-endDate']//span[@role='button']"));

                        AngularFunction.enterDate(effectivedate, value);

                        tmsWait.Hard(3);

                    }
                    else
                    {
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMAdmin.ManagePlanSCC.AddEndDate, value);
                        cfUIMODEAMAdmin.ManagePlanSCC.AddEndDate.SendKeys(Keys.Tab);
                    }
                    tmsWait.Hard(2);
                    break;
            }
            tmsWait.Hard(5);
        }



        // [When(@"EAM Administration page Manage Plan SCC section ""(.*)"" icon is clicked for Plan Id ""(.*)"" and PBP ""(.*)"" and Segment Id ""(.*)"" and SCC ""(.*)"")]

        //public void WhenEAMAdministrationPageManagePlanSCCSectionIconIsClickedForPlanIdAndPBPAndSegmentIdAndSCCAnd(string p0, string p1, int p2, int p3, int p4)
        // {
        //     string icon = tmsCommon.GenerateData(p0);
        //     string planid = tmsCommon.GenerateData(p1);
        //     string pbp = tmsCommon.GenerateData(p2.ToString());
        //     string segmentid = tmsCommon.GenerateData(p3.ToString());
        //     string scc = tmsCommon.GenerateData(p4.ToString());
        // }


        [When(@"EAM Administration page Manage Plan SCC section ""(.*)"" icon is clicked for Plan Id ""(.*)"" and PBP ""(.*)"" and Segment Id ""(.*)"" and SCC ""(.*)""")]
        public void WhenEAMAdministrationPageManagePlanSCCSectionIconIsClickedForPlanIdAndPBPAndSegmentIdAndSCC(string p0, string p1, int p2, int p3, int p4)
        {
            string icon = tmsCommon.GenerateData(p0);
            string planid = tmsCommon.GenerateData(p1);
            string pbp = tmsCommon.GenerateData(p2.ToString());
            string segmentid = tmsCommon.GenerateData(p3.ToString());
            string scc = tmsCommon.GenerateData(p4.ToString());

            switch (icon.ToLower())
            {
                case "edit":
                    IWebElement editicon = Browser.Wd.FindElement(By.XPath("//div[@id='sccMapping-Grid']//span[contains(.,'" + planid + "')]/parent::td/following-sibling::td/span[contains(.,'" + pbp + "')]/parent::td/following-sibling::td/span[contains(.,'" + segmentid + "')]/parent::td/following-sibling::td/span[contains(.,'" + scc + "')]/parent::td//following-sibling::td/a[1]"));
                    ReUsableFunctions.clickOnWebElement(editicon);
                    tmsWait.Hard(3);
                    break;

                case "delete":
                    IWebElement deleteicon = Browser.Wd.FindElement(By.XPath("//div[@id='sccMapping-Grid']//span[contains(.,'" + planid + "')]/parent::td/following-sibling::td/span[contains(.,'" + pbp + "')]/parent::td/following-sibling::td/span[contains(.,'" + segmentid + "')]/parent::td/following-sibling::td/span[contains(.,'" + scc + "')]/parent::td//following-sibling::td/a[2]"));
                    ReUsableFunctions.clickOnWebElement(deleteicon);
                    tmsWait.Hard(1);
                    break;
                case "update":
                    IWebElement updateicon = Browser.Wd.FindElement(By.XPath("//div[@id='sccMapping-Grid']//td/a[contains(@class,'update')]"));
                    tmsWait.Hard(1);
                    ReUsableFunctions.clickOnWebElement(updateicon);
                    break;
              

            }
        }

        [When(@"EAM Administration page Manage Plan SCC section ""(.*)"" icon for Plan Id ""(.*)"" and PBP ""(.*)"" and Segment Id ""(.*)"" and SCC ""(.*)"" is clicked")]
        public void WhenEAMAdministrationPageManagePlanSCCSectionIconForPlanIdAndPBPAndSegmentIdAndSCCIsClicked(string p0, string p1, string p2, string p3, string p4)
        {
            string icon = tmsCommon.GenerateData(p0);
            string planid = tmsCommon.GenerateData(p1);
            string pbp = tmsCommon.GenerateData(p2.ToString());
            string segmentid = tmsCommon.GenerateData(p3.ToString());
            string scc = tmsCommon.GenerateData(p4.ToString());

            switch (icon.ToLower())
            {
                case "edit":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        //div[@role='presentation']//td[contains(.,'" + planid + "')]/following-sibling::td[contains(.,'" + pbp + "')]/following-sibling::td[contains(.,'" + segmentid + "')]/following-sibling::td[contains(.,'" + scc + "')]/following-sibling::td[contains(.,'" + date + "')]/following-sibling::td[contains(.,'12/01/2012')]

                        IWebElement editicon = Browser.Wd.FindElement(By.XPath("//div[@role='presentation']//td[contains(.,'" + planid + "')]/following-sibling::td[contains(.,'" + pbp + "')]/following-sibling::td[contains(.,'" + segmentid + "')]/following-sibling::td[contains(.,'" + scc + "')]/following-sibling::td/button[1]"));

                       // IWebElement editicon = Browser.Wd.FindElement(By.XPath("//div[@id='sccMapping-Grid']//span[contains(.,'" + planid + "')]/parent::td/following-sibling::td/span[contains(.,'" + pbp + "')]/parent::td/following-sibling::td/span[contains(.,'" + segmentid + "')]/parent::td/following-sibling::td/span[contains(.,'" + scc + "')]/parent::td//following-sibling::td/a[1]"));
                        ReUsableFunctions.clickOnWebElement(editicon);
                    }
                    else { 
                        IWebElement editicon = Browser.Wd.FindElement(By.XPath("//div[@id='sccMapping-Grid']//span[contains(.,'" + planid + "')]/parent::td/following-sibling::td/span[contains(.,'" + pbp + "')]/parent::td/following-sibling::td/span[contains(.,'" + segmentid + "')]/parent::td/following-sibling::td/span[contains(.,'" + scc + "')]/parent::td//following-sibling::td/a[1]"));
                    ReUsableFunctions.clickOnWebElement(editicon);
                    tmsWait.Hard(3);
                    }
                    break;

                case "delete":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        IWebElement delete = Browser.Wd.FindElement(By.XPath("//div[@role='presentation']//td[contains(.,'" + planid + "')]/following-sibling::td[contains(.,'" + pbp + "')]/following-sibling::td[contains(.,'" + segmentid + "')]/following-sibling::td[contains(.,'" + scc + "')]/following-sibling::td/button[2]"));

                       // IWebElement editicon = Browser.Wd.FindElement(By.XPath("//div[@id='sccMapping-Grid']//span[contains(.,'" + planid + "')]/parent::td/following-sibling::td/span[contains(.,'" + pbp + "')]/parent::td/following-sibling::td/span[contains(.,'" + segmentid + "')]/parent::td/following-sibling::td/span[contains(.,'" + scc + "')]/parent::td//following-sibling::td/a[1]"));
                        ReUsableFunctions.clickOnWebElement(delete);
                    }
                    else
                    {
                        IWebElement deleteicon = Browser.Wd.FindElement(By.XPath("//div[@id='sccMapping-Grid']//span[contains(.,'" + planid + "')]/parent::td/following-sibling::td/span[contains(.,'" + pbp + "')]/parent::td/following-sibling::td/span[contains(.,'" + segmentid + "')]/parent::td/following-sibling::td/span[contains(.,'" + scc + "')]/parent::td//following-sibling::td/a[2]"));
                        ReUsableFunctions.clickOnWebElement(deleteicon);
                       
                    }
                    tmsWait.Hard(2);
                    ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")));
                    tmsWait.Hard(1);
                    break;
                case "update":

                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {

                        //IWebElement update = Browser.Wd.FindElement(By.XPath("//div[@id='sccMapping-Grid']//span[contains(.,'" + planid + "')]/parent::td/following-sibling::td/span[contains(.,'" + pbp + "')]/parent::td/following-sibling::td/span[contains(.,'" + segmentid + "')]/parent::td/following-sibling::td/span[contains(.,'" + scc + "')]/parent::td//following-sibling::td/a[3]"));
                        IWebElement update = Browser.Wd.FindElement(By.XPath("//div[@role='presentation']//td[contains(.,'" + planid + "')]/following-sibling::td[contains(.,'" + pbp + "')]/following-sibling::td[contains(.,'" + segmentid + "')]/following-sibling::td[contains(.,'" + scc + "')]/following-sibling::td/button[3]"));


                        ReUsableFunctions.clickOnWebElement(update);
                    }
                    else
                    {
                        IWebElement updateicon = Browser.Wd.FindElement(By.XPath("//div[@id='sccMapping-Grid']//td/a[contains(@class,'update')]"));
                        tmsWait.Hard(1);
                        ReUsableFunctions.clickOnWebElement(updateicon);
                    } break;


            }

            
        }



        [When(@"EAM Administration page Manage Plan SCC section Add record Save icon is clicked")]
        public void WhenEAMAdministrationPageManagePlanSCCSectionAddRecordSaveIconIsClicked()
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("//div[@role='presentation']//td//span[@class='fas fa-save']")));
            }
            else
            {
                ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("//div[@id='sccMapping-Grid']//td/a[contains(@class,'update')]")));
            }
                tmsWait.Hard(5);
        }

        [When(@"I have Navigated to EAM Page ""(.*)""")]
        public void WhenIHaveNavigatedToEAMPage(string p0)
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//a[@title='Letters'])[2]")));
            tmsWait.Hard(5);
        }


        [When(@"EAM Administration Letters page ""(.*)"" is selected as ""(.*)""")]
        public void WhenEAMAdministrationLettersPageIsSelectedAs(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);

            switch(field.ToLower())
            {
                case "letters":
                    ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.LettersTemplateConfig.LettersDropdownList);
                    tmsWait.Hard(2);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUIWithoutAriaOwns(cfUIMODEAMAdmin.LettersTemplateConfig.LettersDropdownList, value); break;

                case "effective year": ReUsableFunctions.selectValueFromDropDown(cfUIMODEAMAdmin.LettersTemplateConfig.EffectiveYearDropdownlist, value); break;
                case "planid": ReUsableFunctions.selectValueFromDropDown(cfUIMODEAMAdmin.LettersTemplateConfig.PlanIdDropdownlist, value); break;
            }
        }



        [When(@"EAM Administration Letters page ""(.*)"" button is clicked")]
        public void WhenEAMAdministrationLettersPageButtonIsClicked(string p0)
        {
            string field = tmsCommon.GenerateData(p0);
            
            switch(field.ToLower())
            {
                case "search":ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.LettersTemplateConfig.SearchButton); tmsWait.Hard(3); break;
                case "map templates": ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.LettersTemplateConfig.MapTemplate); tmsWait.Hard(3); break;
                case "copy templates mapping": ReUsableFunctions.clickOnWebElement(cfUIMODEAMAdmin.LettersTemplateConfig.CopyTemplateMapping); tmsWait.Hard(3); break;
            }

        }

        [Then(@"Verify Letters Grid having value PlanId ""(.*)"" PBP ""(.*)"" Template ""(.*)"" is displayed")]
        public void ThenVerifyLettersGridHavingValuePlanIdPBPTemplateIsDisplayed(string p0, string p1, string p2)
        {
            string planid = tmsCommon.GenerateData(p0);
            string pbp = tmsCommon.GenerateData(p1);
            string template = tmsCommon.GenerateData(p2);
            bool hasrow = false;
            int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {
                    IWebElement templaterow = Browser.Wd.FindElement(By.XPath("//div[@test-id='letterTemplate-grid-letterTemplates']//td//span[contains(.,'"+ planid +"')]/parent::td/following-sibling::td/span[contains(.,'" + pbp + "')]/parent::td/following-sibling::td/span[contains(.,'" + template + "')]"));
                    hasrow = templaterow.Displayed;
                    break;
                }
                catch
                {

                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);
                }

            }
            //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed);

            Assert.IsTrue(hasrow, "There is no such row Present");
        }


        [Then(@"Verify Letters Grid having value PlanId ""(.*)"" PBP ""(.*)""")]
        public void ThenVerifyLettersGridHavingValuePlanIdPBP(string p0, string p1)
        {
            string planid = tmsCommon.GenerateData(p0);
            string pbp = tmsCommon.GenerateData(p1);
           // string template = tmsCommon.GenerateData(p2);
            bool hasrow = false;
            int totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
            for (int i = 1; i <= totalPagesIntheGrid; i++)
            {
                try
                {
                    IWebElement templaterow = Browser.Wd.FindElement(By.XPath("//div[@test-id='letterTemplate-grid-letterTemplates']//td//span[contains(.,'" + planid + "')]/parent::td/following-sibling::td/span[contains(.,'" + pbp + "')]"));
                    hasrow = templaterow.Displayed;
                    break;
                }
                catch
                {

                    IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                    ReUsableFunctions.clickOnWebElement(nextpage);
                }

            }
            //Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[@test-id='relationship-grid-relationships']//td//span[contains(.,'" + relationcode + "')]/parent::td/following-sibling::td/span[contains(.,'" + relationship + "')]")).Displayed);

            Assert.IsTrue(hasrow, "There is no such row Present");
        }


        [Then(@"Verify Letters section Map Template page is displayed")]
        public void ThenVerifyLettersSectionMapTemplatePageIsDisplayed()
        {
            tmsWait.Hard(3);
            bool flag = false;
            try
            {
                flag = Browser.Wd.FindElement(By.XPath("//span[contains(.,'Map Template')]")).Displayed;
            }
            catch
            {

            }

            Assert.IsTrue(flag);
        }

        [When(@"EAM Administration Letters section Map Template page select template as ""(.*)""")]
        public void WhenEAMAdministrationLettersSectionMapTemplatePageSelectTemplateAs(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            IWebElement lettertemp = Browser.Wd.FindElement(By.XPath("//select[@test-id='letterTempMapping-select-template']"));
            ReUsableFunctions.selectValueFromDropDown(lettertemp, value);
            tmsWait.Hard(3);
        }


        [When(@"EAM Administration Letters section Map Template page Checkbox is checked for PlanId ""(.*)"" and PBP ""(.*)""")]
        public void WhenEAMAdministrationLettersSectionMapTemplatePageCheckboxIsCheckedForPlanIdAndPBP(string p0, string p1)
        {
            string planid = tmsCommon.GenerateData(p0);
            string pbp = tmsCommon.GenerateData(p1);
            bool flag = false;
            try
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@test-id='letterTemplate-grid-letterTemplates'][1]//td/span[contains(.,'" + planid + "')]/parent::td/parent::tr/td/span[contains(.,'" + pbp + "')]/parent::td/parent::tr//input[1]")));
                flag = true;
            }

            catch { }

            Assert.IsTrue(flag, "Corresponding Checkbox is not clicked");
        }


        [When(@"EAM Administration Letters section Map Template page ""(.*)"" button is clicked")]
        public void WhenEAMAdministrationLettersSectionMapTemplatePageButtonIsClicked(string p0)
        {
            string field = tmsCommon.GenerateData(p0);
            switch(field.ToLower())
            {
                case "map": fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='letterTempMapping-btn-MapLetters']")));tmsWait.Hard(10); break;
                case "cancel": fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@test-id='letterTempMapping-snp-letterTitle']/i"))); tmsWait.Hard(1); break;
            }
        }

        [When(@"EAM Administration Letters page Copy Template Mapping Popup Select Year From is set to ""(.*)""")]
        public void WhenEAMAdministrationLettersPageCopyTemplateMappingPopupSelectYearFromIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            IWebElement lettertemp = Browser.Wd.FindElement(By.XPath("//select[@test-id='copyTempMapping-select-copyFrom']"));
            ReUsableFunctions.selectValueFromDropDown(lettertemp, value);
            tmsWait.Hard(1);

        }



        [When(@"EAM Administration Letters page Copy Template Mapping Popup Select Year To is set to ""(.*)"" and Verify Message ""(.*)""")]
        public void WhenEAMAdministrationLettersPageCopyTemplateMappingPopupSelectYearFromIsSetToAndVerifyMessage(string p0, string p1)
        {
            string cyear = tmsCommon.GenerateData(p0);
            string expectedMessage = tmsCommon.GenerateData(p1);
            IWebElement lettertemp = Browser.Wd.FindElement(By.XPath("//select[@test-id='copyTempMapping-select-copyTo']"));
            ReUsableFunctions.selectValueFromDropDown(lettertemp, cyear);
            if(expectedMessage!="")
            {
                string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).GetAttribute("aria-label");
                Assert.IsTrue(actualValue.Contains(expectedMessage));
            }
            
            tmsWait.Hard(2);
        }



        [When(@"EAM Administration Letters page Copy Template Mapping Popup ""(.*)"" button is clicked")]
        public void WhenEAMAdministrationLettersPageCopyTemplateMappingPopupButtonIsClicked(string p0)
        {
            string field = tmsCommon.GenerateData(p0);
            switch(field.ToLower())
            {
                case "copy": fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='copyTempMapping-btn-copyTemp']"))); tmsWait.Hard(1);break;
                case "reset":break;
            }
        }

        [Then(@"Verify EAM Administration Letters page Copy Template Mapping Warning Message ""(.*)""")]
        public void ThenVerifyEAMAdministrationLettersPageCopyTemplateMappingWarningMessage(string p0)
        {
            string expected_Message = tmsCommon.GenerateData(p0);
            bool ispresent = false;
            try
            {
                ispresent = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + expected_Message + "')]")).Displayed;
                ispresent = true;
            }
            catch { }

            Assert.IsTrue(ispresent, "Warning Message is not displayed");
        }


        [When(@"EAM Administration Letters page Copy Template Mapping Popup Warning Popup ""(.*)"" button is clicked")]
        public void WhenEAMAdministrationLettersPageCopyTemplateMappingPopupWarningPopupButtonIsClicked(string p0)
        {
            string field = tmsCommon.GenerateData(p0);
            switch(field.ToLower())
            {
                case "ok": fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']"))); break;
                case "cancel": break;
            }
        }

        [When(@"EAM Administration Letters page Copy Template Mapping Popup Cross link is clicked")]
        public void WhenEAMAdministrationLettersPageCopyTemplateMappingPopupCrossLinkIsClicked()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@test-id='copyTempMapping-snp-letterTitle']/i")));
            tmsWait.Hard(2);
        }


    }

}
