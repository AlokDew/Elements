﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows;
using TMSoR1.FrameworkCode;

namespace TMSoR1    
{
    [Binding]
    class fsRecalculations
    {

        [When(@"Recalculations page Yearly Premium button is clicked")]
        public void WhenRecalculationsPageYearlyPremiumButtonIsClicked()
        {
            try
            {
                fw.ExecuteJavascript(EAM.Recalculations.YearlyPremiumRecalculateButton);
                tmsWait.Hard(2);
            }
            catch
            {
                fw.ConsoleReport(" This job ran already");
            }
        }


       

        [When(@"Recalculations page Monthly Premium button is clicked")]
        public void WhenRecalculationsPageMonthlyPremiumButtonIsClicked()
        {
            try
            { 
            fw.ExecuteJavascript(EAM.Recalculations.MonthlyPremiumRecalculateButton);
            }
            catch
            {
                fw.ConsoleReport(" This job ran already");
            }
            tmsWait.Hard(1);
        }

        [Then(@"Recalculations page Monthly Premium button is disabled")]
        public void ThenRecalculationsPageMonthlyPremiumButtonIsDisabled()
        {
            //Assert.IsTrue(EAM.Recalculations.MonthlyPremiumRecalculateButton.GetAttribute("disabled") == false,"Monthly Recalculations premium disabled as expected");
            string presense = EAM.Recalculations.MonthlyPremiumRecalculateButton.GetAttribute("disabled");
            Assert.IsTrue(bool.Parse(presense));
        }

        [Then(@"Recalculations page Monthly premium calculation date should be displayed with ""(.*)"" on date  ""(.*)""")]
        public void ThenRecalculationsPageMonthlyPremiumCalculationDateShouldBeDisplayedWithOnDate(string p0, string p1)
        {
            string LastRun = EAM.Recalculations.MonthlyJobRunOn.Text;
            int lengthLastRun = LastRun.Length;
            string subsLastRun = LastRun.Substring(1,27);
            DateTime Today = DateTime.Today.Date;
            string shortDate = Today.ToShortDateString();
            string ExpectedMessage = p0 + p1;
            Assert.IsTrue(ExpectedMessage == (subsLastRun + shortDate), "The message is displayed: {0}", LastRun);
        }


        //[Then(@"Recalculations page Monthly premium calculation date should be displayed with ""(.*)""")]
        //public void ThenRecalculationsPageMonthlyPremiumCalculationDateShouldBeDisplayedWith(string p0)
        //{
        //    DateTime Today = DateTime.Today.Date;
        //    string longDate = Today.ToLongDateString();

        //}


        [Then(@"Recalculations page ""(.*)"" is displayed")]
        public void ThenRecalculationsPageIsDisplayed(string p0)
        {
            p0 = tmsCommon.GenerateData(p0);
            IWebElement update = EAM.Recalculations.ProcessInProgress;
            string updatemessage = update.Text.ToString();

            Assert.AreEqual(updatemessage, p0, "View Edit Plan info page message expected [" + p0 + "], found [" + updatemessage + "]");
            tmsWait.WaitForElementHasText(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblMessage"), "JobId", 300);
        }



        [When(@"Recalculations page plan 10 Date is set to ""(.*)""")]
        public void WhenRecalculationsPagePlanDateIsSetTo(string effectiveDate)
        {
            effectiveDate = tmsCommon.GenerateData(effectiveDate);
            effectiveDate = effectiveDate.Replace("/", "");
            ReUsableFunctions.enterValueOnWebElementWithClear(EAM.Recalculations.Plan10, effectiveDate);
           
     //       EAM.Recalculations.Plan10.Click();
           // tmsWait.Hard(1);
           // EAM.Recalculations.Plan10.SendKeys(effectiveDate);
            //tmsWait.Hard(4);
        }
        [When(@"Recalculations Response Message ID is stored in variable ""(.*)""")]
        public void WhenRecalculationsResponseMessageIDIsStoredInVariable(string p0)
        {

            IWebElement update = EAM.Recalculations.JobIdUpdateMessage;
            string updatemessage = update.Text.ToString();
            string[] getJobRequestId = updatemessage.Split(':');
            string jobId = getJobRequestId[1];
            fw.setVariable(p0, jobId);
            Console.WriteLine("Recalculation page, Response message Job ID ["+ jobId +"] was stored in variable ["+ p0 +"]");
            tmsWait.Hard(4);

        }

        [When(@"I should see the recalculation job request Id on the same page")]
        public void WhenIShouldSeeTheRecalculationJobRequestIdOnTheSamePage()
        {
            IWebElement update = EAM.Recalculations.JobIdUpdateMessage;
            string updatemessage = update.Text.ToString();
            string[] getJobRequestId = updatemessage.Split(':');
            string jobId = getJobRequestId[1];
            //was it blank, error?
            // Assert if the Message is correct and give appropriate result message
        }
    }
       
}
