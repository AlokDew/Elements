﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows;
using OpenQA.Selenium.Support.UI;
using System.Web;
using TMSoR1;
using TMSoR1.FrameworkCode;

namespace TMSoR1
{
    [Binding]
    class fsViewBidData
    {
        [When(@"View Bid Data Go button is clicked")]
        public void WhenViewBidDataGoButtonIsClicked()
        {
            EAM.ViewBidData.GoButton.Click();
            tmsWait.Hard(2);
        }

        [Then(@"Verify on Hover on Info button message ""(.*)"" is displayed")]
        public void ThenVerifyOnHoverOnInfoButtonMessageIsDisplayed(string p0)
        {

        }


        [When(@"View Bid Data Reset button is clicked")]
        public void WhenViewBidDataResetButtonIsClicked()
        {
            fw.ExecuteJavascript(EAM.ViewBidData.ResetButton);
            tmsWait.Hard(2);
        }


        [Then(@"View Bid Data page should display the results with count ""(.*)""")]
        public void ThenViewBidDataPageShouldDisplayTheResultsWithCount(string p0)
        {
            //string Biddatacount = EAM.ViewBidData.ResultsCount.GetAttribute("Text");
            //string Biddatacount = EAM.ViewBidData.ResultsCount.Text;
            string expectedcount = tmsCommon.GenerateData(p0);
            string actualcount = "";
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                actualcount = ReUsableFunctions.getTotalItems();
               /// actualcount = Browser.Wd.FindElement(By.XPath("//div[@test-id='bidData-grid-bidData']//span[@class='k-pager-info k-label']")).Text;
            }
            else
            {
                 actualcount = Browser.Wd.FindElement(By.XPath("//div[@test-id='bidData-grid-bidData']//span[@class='k-pager-info k-label']")).Text;

            }
            Assert.IsTrue(actualcount.Contains(expectedcount), "Default Count of the total number of records does not match");
        }

        [Then(@"Verify results table to have default rows count as ""(.*)""")]
        public void ThenVerifyResultsTableToHaveDefaultRowsCountAs(int p0)
        {
            string expectedcount = tmsCommon.GenerateData(p0.ToString());
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
               string actualcount = ReUsableFunctions.getPerPageItems();
            }
            else
            {
                //IReadOnlyList<IWebElement> rowcount = Browser.Wd.FindElements(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_ucViewBidData_grdBidData_ctl00']/tbody/tr"));

                //Console.WriteLine("Rowcount is : {0}", rowcount.Count);
                //Assert.AreEqual(p0, rowcount.Count, "Passed" + ":" + "Actual rowcount {0} matches the expected rowcount {1}", p0, rowcount);
               
                string actualcount = Browser.Wd.FindElement(By.XPath("//div[@test-id='bidData-grid-bidData']//span[@class='k-pager-info k-label']")).Text;
                Assert.IsTrue(actualcount.Contains(expectedcount), "No of rows on a page does not match");
            }
        }

        [When(@"ViewBidData Page Plan ID is set to ""(.*)""")]
        public void WhenViewBidDataPagePlanIDIsSetTo(string p0)
        {
            SelectElement planId = new SelectElement(EAM.ViewBidData.PlanId);
            planId.SelectByText(p0);
            tmsWait.Hard(1);
        }

        [When(@"ViewBidData Page Year is set to ""(.*)""")]
        public void WhenViewBidDataPageYearIsSetTo(string p0)
        {
            SelectElement Year = new SelectElement(EAM.ViewBidData.Year);
            Year.SelectByText(p0);
        }

        [Then(@"ViewBidData Page Year is reset to ""(.*)""")]
        public void ThenViewBidDataPageYearIsResetTo(string p0)
        {
            SelectElement Year = new SelectElement(EAM.ViewBidData.Year);
            string generatedData = tmsCommon.GenerateData(p0);
            Assert.AreEqual(generatedData, Year.SelectedOption.Text, "Passed" + "Year reset to {0}", Year.SelectedOption.Text);
        }

        [When(@"View/Edit Plan Info Page PBP Type is set to ""(.*)""")]
        public void WhenViewEditPlanInfoPagePBPTypeIsSetTo(string p0)
        {
            SelectElement pbpId = new SelectElement(EAM.EditPLanInfo.PBPType);
            pbpId.SelectByText(p0);
        }

        [Then(@"Member View Edit page Rx Billing tab Part C Premium amount is readed")]
        public void ThenMemberViewEditPageRxBillingTabPartCPremiumAmountIsReaded()
        {
            GlobalRef.InitialPartCAmt = EAM.AdminEAMConfiguration.PartCAmount.GetAttribute("value");

        }
        [Then(@"Transaction View Edit page Part C Premium amount is readed")]
        public void ThenTransactionViewEditPagePartCPremiumAmountIsReaded()
        {
            GlobalRef.InitialTranspagePartCAmt = EAM.AdminEAMConfiguration.TranspagePartCAmount.GetAttribute("value");
        }


        [Then(@"Verify View Edit Member page Rx Billing tab OSB drop down list is selected as ""(.*)""")]
        public void ThenVerifyViewEditMemberPageRxBillingTabOSBDropDownListIsSelectedAs(string p0)
        {

            string expected = p0.ToString();
            string actual = new SelectElement(EAM.AdminEAMConfiguration.OSBSelectiondrpdown).SelectedOption.Text;

            Assert.AreEqual(actual, expected, actual + "value is getting matched with " + expected);

        }

        [Then(@"Verify View Edit Transaction page OSB drop down list is selected as ""(.*)""")]
        public void ThenVerifyViewEditTransactionPageOSBDropDownListIsSelectedAs(string p0)
        {
            string expected = p0.ToString();
            string actual = new SelectElement(EAM.AdminEAMConfiguration.TranspageOSBSelectiondrpdown).SelectedOption.Text;

            Assert.AreEqual(actual, expected, actual + "value is getting matched with " + expected);
        }

        [Then(@"Verify View Edit Transaction page ""(.*)"" check box is set to ""(.*)""")]
        public void ThenVerifyViewEditTransactionPageCheckBoxIsSetTo(string p0, string p1)
        {


            string osbtype = p0.ToString();
            string status = p1.ToString();

            switch (osbtype)
            {
                case "Medical OSB":
                    if (status.ToLower().Equals("checked"))
                    {
                        // Here we were used using Workaround, as per Selenium GetAttribute method will return String but Application returning Boolean

                        Assert.IsTrue(EAM.AdminEAMConfiguration.TranspageOSBMedicalCheckbox.Selected, "Check box is checked");
                    }
                    else if (status.ToLower().Equals("unchecked"))
                    {
                        Assert.IsFalse(EAM.AdminEAMConfiguration.TranspageOSBMedicalCheckbox.Selected, "Check box is Unchecked");
                    }

                    break;

                case "Dental OSB":
                    if (status.ToLower().Equals("checked"))
                    {
                        Assert.IsTrue(EAM.AdminEAMConfiguration.TranspageOSBDentalCheckbox.Selected, "Check box is checked");
                    }
                    else if (status.ToLower().Equals("unchecked"))
                    {
                        Assert.IsFalse(EAM.AdminEAMConfiguration.TranspageOSBDentalCheckbox.Selected, "Check box is Unchecked");
                    }
                    break;


                case "Vision OSB":

                    if (status.ToLower().Equals("checked"))
                    {
                        Assert.IsTrue(EAM.AdminEAMConfiguration.TranspageOSBVisionCheckbox.Selected, "Check box is checked");
                    }
                    else if (status.ToLower().Equals("unchecked"))
                    {
                        Assert.IsFalse(EAM.AdminEAMConfiguration.TranspageOSBVisionCheckbox.Selected, "Check box is Unchecked");
                    }
                    break;

                case "Other OSB":
                    if (status.ToLower().Equals("checked"))
                    {
                        Assert.IsTrue(EAM.AdminEAMConfiguration.TranspageOSBOthersCheckbox.Selected, "Check box is checked");
                    }
                    else if (status.ToLower().Equals("unchecked"))
                    {
                        Assert.IsFalse(EAM.AdminEAMConfiguration.TranspageOSBOthersCheckbox.Selected, "Check box is Unchecked");
                    }
                    break;


            }

        }


        [Then(@"Verify View Edit Member page Rx Billing tab ""(.*)"" check box is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageRxBillingTabCheckBoxIsSetTo(string p0, string p1)
        {

            string osbtype = p0.ToString();
            string status = p1.ToString();

            switch (osbtype)
            {
                case "Medical OSB":
                    if (status.ToLower().Equals("checked"))
                    {
                        // Here we were using Workaround, as per Selenium GetAttribute method will return String but Application returning Boolean

                        Assert.IsTrue(EAM.AdminEAMConfiguration.OSBMedicalCheckbox.Selected, "Check box is checked");
                    }
                    else if (status.ToLower().Equals("unchecked"))
                    {
                        Assert.IsFalse(EAM.AdminEAMConfiguration.OSBMedicalCheckbox.Selected, "Check box is Unchecked");
                    }

                    break;

                case "Dental OSB":
                    if (status.ToLower().Equals("checked"))
                    {
                        Assert.IsTrue(EAM.AdminEAMConfiguration.OSBDentalCheckbox.Selected, "Check box is checked");
                    }
                    else if (status.ToLower().Equals("unchecked"))
                    {
                        Assert.IsFalse(EAM.AdminEAMConfiguration.OSBDentalCheckbox.Selected, "Check box is Unchecked");
                    }
                    break;


                case "Vision OSB":

                    if (status.ToLower().Equals("checked"))
                    {
                        Assert.IsTrue(EAM.AdminEAMConfiguration.OSBVisionCheckbox.Selected, "Check box is checked");
                    }

                    else if (status.ToLower().Equals("unchecked"))
                    {
                        Assert.IsFalse(EAM.AdminEAMConfiguration.OSBVisionCheckbox.Selected, "Check box is Unchecked");
                    }
                    break;

                case "Other OSB":
                    if (status.ToLower().Equals("checked"))
                    {
                        Assert.IsTrue(EAM.AdminEAMConfiguration.OSBVisionCheckbox.Selected, "Check box is checked");
                    }

                    else if (status.ToLower().Equals("unchecked"))
                    {
                        Assert.IsFalse(EAM.AdminEAMConfiguration.OSBVisionCheckbox.Selected, "Check box is Unchecked");
                    }
                    break;


            }
        }

        [Then(@"Transaction View Edit page OSB drop down list is selected as ""(.*)""")]
        public void ThenTransactionViewEditPageOSBDropDownListIsSelectedAs(string p0)
        {

            SelectElement osb = new SelectElement(EAM.AdminEAMConfiguration.TranspageOSBSelectiondrpdown);
            osb.SelectByText(p0);
        }


        [Then(@"View Edit Member page Rx Billing tab OSB drop down list is selected as ""(.*)""")]
        public void ThenViewEditMemberPageRxBillingTabOSBDropDownListIsSelectedAs(string p0)
        {
            SelectElement osb = new SelectElement(EAM.AdminEAMConfiguration.OSBSelectiondrpdown);
            osb.SelectByText(p0);
        }
        public string setCheckboxTo;

        [Then(@"Transaction View Edit page ""(.*)"" checkbox is ""(.*)""")]
        public void ThenTransactionViewEditPageCheckboxIs(string p0, string p1)
        {


            string osbtype = p0.ToString();
            // string value = p1.ToString();
            string GenerateData = tmsCommon.GenerateData(p1);
            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }
            switch (osbtype)

            {
                case "Dental OSB":



                    if (setCheckboxTo.Equals("unchecked"))
                    {
                        if (EAM.AdminEAMConfiguration.TranspageOSBDentalCheckbox.Selected)
                        {
                            EAM.AdminEAMConfiguration.TranspageOSBDentalCheckbox.Click();
                        }
                    }
                    else if (setCheckboxTo.Equals("checked"))
                    {
                        if (!EAM.AdminEAMConfiguration.TranspageOSBDentalCheckbox.Selected)
                        {
                            EAM.AdminEAMConfiguration.TranspageOSBDentalCheckbox.Click();
                        }
                    }
                    break;

                case "Medical OSB":

                    //switch (GenerateData.ToLower())
                    //{
                    //    case "checked": { setCheckboxTo = "checked"; break; }
                    //    case "on": { setCheckboxTo = "checked"; break; }
                    //    case "yes": { setCheckboxTo = "checked"; break; }
                    //    case "unchecked": { setCheckboxTo = "unchecked"; break; }
                    //    case "off": { setCheckboxTo = "unchecked"; break; }
                    //    case "no": { setCheckboxTo = "unchecked"; break; }
                    //    default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
                    //}

                    if (setCheckboxTo.Equals("unchecked"))
                    {
                        if (EAM.AdminEAMConfiguration.TranspageOSBMedicalCheckbox.Selected)
                        {
                            EAM.AdminEAMConfiguration.TranspageOSBMedicalCheckbox.Click();
                        }
                    }
                    else if (setCheckboxTo.Equals("checked"))
                    {
                        if (!EAM.AdminEAMConfiguration.TranspageOSBMedicalCheckbox.Selected)
                        {
                            EAM.AdminEAMConfiguration.TranspageOSBMedicalCheckbox.Click();
                        }
                    }

                    break;

                case "Vision OSB":



                    //switch (GenerateData.ToLower())
                    //{
                    //    case "checked": { setCheckboxTo = "checked"; break; }
                    //    case "on": { setCheckboxTo = "checked"; break; }
                    //    case "yes": { setCheckboxTo = "checked"; break; }
                    //    case "unchecked": { setCheckboxTo = "unchecked"; break; }
                    //    case "off": { setCheckboxTo = "unchecked"; break; }
                    //    case "no": { setCheckboxTo = "unchecked"; break; }
                    //    default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
                    //}

                    if (setCheckboxTo.Equals("unchecked"))
                    {
                        if (EAM.AdminEAMConfiguration.TranspageOSBVisionCheckbox.Selected)
                        {
                            EAM.AdminEAMConfiguration.TranspageOSBVisionCheckbox.Click();
                        }
                    }
                    else if (setCheckboxTo.Equals("checked"))
                    {
                        if (!EAM.AdminEAMConfiguration.TranspageOSBVisionCheckbox.Selected)
                        {
                            EAM.AdminEAMConfiguration.TranspageOSBVisionCheckbox.Click();
                        }
                    }
                    break;

                case "Other OSB":

                    //switch (GenerateData.ToLower())
                    //{
                    //    case "checked": { setCheckboxTo = "checked"; break; }
                    //    case "on": { setCheckboxTo = "checked"; break; }
                    //    case "yes": { setCheckboxTo = "checked"; break; }
                    //    case "unchecked": { setCheckboxTo = "unchecked"; break; }
                    //    case "off": { setCheckboxTo = "unchecked"; break; }
                    //    case "no": { setCheckboxTo = "unchecked"; break; }
                    //    default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
                    //}

                    if (setCheckboxTo.Equals("unchecked"))
                    {
                        if (EAM.AdminEAMConfiguration.TranspageOSBOthersCheckbox.Selected)
                        {
                            EAM.AdminEAMConfiguration.TranspageOSBOthersCheckbox.Click();
                        }
                    }
                    else if (setCheckboxTo.Equals("checked"))
                    {
                        if (!EAM.AdminEAMConfiguration.TranspageOSBOthersCheckbox.Selected)
                        {
                            EAM.AdminEAMConfiguration.TranspageOSBOthersCheckbox.Click();
                        }
                    }

                    break;

            }


        }



        [When(@"Transaction New OSB Value ""(.*)"" checkbox is ""(.*)""")]
        [Then(@"View Edit Member page Rx Billing tab ""(.*)"" checkbox is ""(.*)""")]
        public void ThenViewEditMemberPageRxBillingTabCheckboxIs(string p0, string p1)
        {
            string osbtype = p0.ToString();
            // string value = p1.ToString();
            string GenerateData = tmsCommon.GenerateData(p1);

            //User is on following page
            string pageName = EAM.WFDashboard.WFDashboardPageName.Text;
            IWebElement MedicalOSB = null;
            IWebElement DentalOSB = null;
            IWebElement VisionOSB = null;
            IWebElement OtherOSB = null;
            switch (pageName)
            {
                case "New member":
                    MedicalOSB = EAM.AdminEAMConfiguration.OSBMedicalCheckbox;
                    DentalOSB = EAM.AdminEAMConfiguration.OSBDentalCheckbox;
                    VisionOSB = EAM.AdminEAMConfiguration.OSBVisionCheckbox;
                    OtherOSB = EAM.AdminEAMConfiguration.OSBOthersCheckbox;
                    break;
                case "New Transaction":
                    MedicalOSB = EAM.AdminEAMConfiguration.NewTransOSBMedicalCheckbox;
                    DentalOSB = EAM.AdminEAMConfiguration.NewTransOSBDentalCheckbox;
                    VisionOSB = EAM.AdminEAMConfiguration.NewTransOSBVisionCheckbox;
                    OtherOSB = EAM.AdminEAMConfiguration.NewTransOSBOtherCheckbox;
                    break;
            }


            switch (osbtype)

            {
                case "Dental OSB":


                    switch (GenerateData.ToLower())
                    {
                        case "checked": { setCheckboxTo = "checked"; break; }
                        case "on": { setCheckboxTo = "checked"; break; }
                        case "yes": { setCheckboxTo = "checked"; break; }
                        case "unchecked": { setCheckboxTo = "unchecked"; break; }
                        case "off": { setCheckboxTo = "unchecked"; break; }
                        case "no": { setCheckboxTo = "unchecked"; break; }
                        default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
                    }

                    if (setCheckboxTo.Equals("unchecked"))
                    {
                        if (DentalOSB.Selected)
                        {
                            DentalOSB.Click();
                        }
                    }
                    else if (setCheckboxTo.Equals("checked"))
                    {
                        try
                        {
                            if (!DentalOSB.Selected)
                            {
                                DentalOSB.Click();
                            }
                        }
                        catch { }
                    }
                    break;

                case "Medical OSB":

                    switch (GenerateData.ToLower())
                    {
                        case "checked": { setCheckboxTo = "checked"; break; }
                        case "on": { setCheckboxTo = "checked"; break; }
                        case "yes": { setCheckboxTo = "checked"; break; }
                        case "unchecked": { setCheckboxTo = "unchecked"; break; }
                        case "off": { setCheckboxTo = "unchecked"; break; }
                        case "no": { setCheckboxTo = "unchecked"; break; }
                        default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
                    }

                    if (setCheckboxTo.Equals("unchecked"))
                    {
                        if (MedicalOSB.Selected)
                        {
                            MedicalOSB.Click();
                        }
                    }
                    else if (setCheckboxTo.Equals("checked"))
                    {
                        if (!MedicalOSB.Selected)
                        {
                            MedicalOSB.Click();
                        }
                    }

                    break;

                case "Vision OSB":



                    switch (GenerateData.ToLower())
                    {
                        case "checked": { setCheckboxTo = "checked"; break; }
                        case "on": { setCheckboxTo = "checked"; break; }
                        case "yes": { setCheckboxTo = "checked"; break; }
                        case "unchecked": { setCheckboxTo = "unchecked"; break; }
                        case "off": { setCheckboxTo = "unchecked"; break; }
                        case "no": { setCheckboxTo = "unchecked"; break; }
                        default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
                    }

                    if (setCheckboxTo.Equals("unchecked"))
                    {
                        if (VisionOSB.Selected)
                        {
                            VisionOSB.Click();
                        }
                    }
                    else if (setCheckboxTo.Equals("checked"))
                    {
                        if (!VisionOSB.Selected)
                        {
                            VisionOSB.Click();
                        }
                    }
                    break;

                case "Other OSB":

                    switch (GenerateData.ToLower())
                    {
                        case "checked": { setCheckboxTo = "checked"; break; }
                        case "on": { setCheckboxTo = "checked"; break; }
                        case "yes": { setCheckboxTo = "checked"; break; }
                        case "unchecked": { setCheckboxTo = "unchecked"; break; }
                        case "off": { setCheckboxTo = "unchecked"; break; }
                        case "no": { setCheckboxTo = "unchecked"; break; }
                        default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
                    }

                    if (setCheckboxTo.Equals("unchecked"))
                    {
                        if (OtherOSB.Selected)
                        {
                            OtherOSB.Click();
                        }
                    }
                    else if (setCheckboxTo.Equals("checked"))
                    {
                        if (!OtherOSB.Selected)
                        {
                            OtherOSB.Click();
                        }
                    }

                    break;

            }

        }

        [When(@"View Edit Member page Save button is Clicked")]
        [Then(@"View Edit Member page Save button is Clicked")]
        public void WhenViewEditMemberPageSaveButtonIsClicked()
        {
            EAM.AdminEAMConfiguration.MemberSavebutton.Click();
            tmsWait.Hard(2);
        }

        [When(@"Transaction View Edit page Save button is Clicked")]
        public void WhenTransactionViewEditPageSaveButtonIsClicked()
        {

            EAM.AdminEAMConfiguration.TranspageSavebutton.Click();
        }

        [Then(@"Transaction View Edit page County value is set to ""(.*)""")]
        public void ThenTransactionViewEditPageCountyValueIsSetTo(string p0)
        {
            EAM.AdminEAMConfiguration.TranspageCounty.SendKeys(p0);
        }

        [Then(@"Transaction View Edit page SCC code is set to ""(.*)""")]
        public void ThenTransactionViewEditPageSCCCodeIsSetTo(string p0)
        {
            EAM.AdminEAMConfiguration.TranspageSCCCode.SendKeys(p0);
        }

        [Then(@"Transaction View Edit page Part C Premium Amount is added with ""(.*)"" displayed")]
        public void ThenTransactionViewEditPagePartCPremiumAmountIsAddedWithDisplayed(string p0)
        {


            double PartCInit = Convert.ToDouble(GlobalRef.InitialTranspagePartCAmt);
            double osbamount = Convert.ToDouble(GlobalRef.OSBAmount);

            double finalPartCAmt;

            string osbtype = p0.ToString();

            switch (osbtype)
            {
                case "MedicalDentalVisionOther OSB":

                    finalPartCAmt = PartCInit + (4 * osbamount);
                    Assert.IsTrue((finalPartCAmt > PartCInit), " Part C amount is getting increased by adding Dental, Medical, Other, Vision OSB Amount");

                    break;

                case "DentalVisionOther OSB":

                    finalPartCAmt = PartCInit + (3 * osbamount);
                    Assert.IsTrue((finalPartCAmt > PartCInit), " Part C amount is getting increased by adding Dental,Other, Vision OSB Amount");

                    break;

                case "VisionOther OSB":

                    finalPartCAmt = PartCInit + (2 * osbamount);
                    Assert.IsTrue((finalPartCAmt > PartCInit), " Part C amount is getting increased by adding Dental, Medical OSB Amount");

                    break;

                case "Dental OSB":


                    finalPartCAmt = PartCInit + osbamount;
                    Assert.IsTrue((finalPartCAmt > PartCInit), " Part C amount is getting increased by adding Dental OSB Amount");

                    break;

                case "All OSB":



                    finalPartCAmt = PartCInit + osbamount + osbamount + osbamount + osbamount;

                    Assert.IsTrue((finalPartCAmt > PartCInit), " Part C amount is getting increased by adding All OSB Amount");

                    break;

                case "Vision OSB":


                    finalPartCAmt = PartCInit + osbamount;
                    Assert.IsTrue((finalPartCAmt > PartCInit), " Part C amount is getting increased by adding Vision OSB Amount");

                    break;

                case "Medical OSB":


                    finalPartCAmt = PartCInit + osbamount;
                    Assert.IsTrue((finalPartCAmt > PartCInit), " Part C amount is getting increased by adding Medical OSB Amount");

                    break;
                case "Other OSB":


                    finalPartCAmt = PartCInit + osbamount;
                    Assert.IsTrue((finalPartCAmt > PartCInit), " Part C amount is getting increased by adding Medical OSB Amount");

                    break;

            }

        }


        [Then(@"Verify View Edit Member page RX Billing Tab OSB field is not visible")]
        public void ThenVerifyViewEditMemberPageRXBillingTabOSBFieldIsNotVisible()
        {
            IJavaScriptExecutor js = Browser.Wd as IJavaScriptExecutor;
            var value = (string)js.ExecuteScript("return document.getElementById('ctl00_ctl00_MainMasterContent_MainContent_ucBillingInfo_DropDownOSBFlag')");

            if (value == null)
            {
                fw.ConsoleReport(" Element is not found on View Edit Member page");
            }
            else
            {
                Assert.Fail("Element is found on View Edit Transaction page");
            }

        }

        [Then(@"Verify View Edit Transaction page OSB field is not visible")]
        public void ThenVerifyViewEditTransactionPageOSBFieldIsNotVisible()
        {
            IJavaScriptExecutor js = Browser.Wd as IJavaScriptExecutor;
            var value = (string)js.ExecuteScript("return document.getElementById('ctl00_ctl00_MainMasterContent_MainContent_DropDownOSBFlag')");

            if (value == null)
            {
                fw.ConsoleReport(" Element is not found on View Edit Transaction page");
            }
            else
            {
                Assert.Fail("Element is found on View Edit Transaction page");

            }
        }



        [Then(@"Verify View Edit Member page Part C Premium Amount is added with ""(.*)"" displayed")]
        public void ThenVerifyViewEditMemberPagePartCPremiumAmountIsAddedWithDisplayed(string p0)
        {

            double PartCInit = Convert.ToDouble(GlobalRef.InitialPartCAmt);
            double osbamount = Convert.ToDouble(GlobalRef.OSBAmount);

            double finalPartCAmt;

            string osbtype = p0.ToString();

            switch (osbtype)
            {
                case "MedicalDentalVisionOther OSB":

                    finalPartCAmt = PartCInit + (4 * osbamount);
                    Assert.IsTrue((finalPartCAmt > PartCInit), " Part C amount is getting increased by adding Dental, Medical, Other, Vision OSB Amount");

                    break;

                case "DentalVisionOther OSB":

                    finalPartCAmt = PartCInit + (3 * osbamount);
                    Assert.IsTrue((finalPartCAmt > PartCInit), " Part C amount is getting increased by adding Dental,Other, Vision OSB Amount");

                    break;

                case "VisionOther OSB":

                    finalPartCAmt = PartCInit + (2 * osbamount);
                    Assert.IsTrue((finalPartCAmt > PartCInit), " Part C amount is getting increased by adding Dental, Medical OSB Amount");

                    break;

                case "Dental OSB":


                    finalPartCAmt = PartCInit + osbamount;
                    Assert.IsTrue((finalPartCAmt > PartCInit), " Part C amount is getting increased by adding Dental OSB Amount");

                    break;

                case "All OSB":



                    finalPartCAmt = PartCInit + osbamount + osbamount + osbamount + osbamount;

                    Assert.IsTrue((finalPartCAmt > PartCInit), " Part C amount is getting increased by adding All OSB Amount");

                    break;

                case "Vision OSB":


                    finalPartCAmt = PartCInit + osbamount;
                    Assert.IsTrue((finalPartCAmt > PartCInit), " Part C amount is getting increased by adding Vision OSB Amount");

                    break;

                case "Medical OSB":


                    finalPartCAmt = PartCInit + osbamount;
                    Assert.IsTrue((finalPartCAmt > PartCInit), " Part C amount is getting increased by adding Medical OSB Amount");

                    break;
                case "Other OSB":


                    finalPartCAmt = PartCInit + osbamount;
                    Assert.IsTrue((finalPartCAmt > PartCInit), " Part C amount is getting increased by adding Medical OSB Amount");

                    break;

            }

        }

        [When(@"EAM Configuration section ""(.*)"" link is Clicked")]
        public void WhenEAMConfigurationSectionLinkIsClicked(string p0)
        {
            By loc = By.XPath("//label[contains(.,'"+p0+"')]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
   

        }
       public System.Collections.ObjectModel.ReadOnlyCollection<IWebElement> deleteList;
        [When(@"View OSB Configuration page Delete button is Clicked")]
        public void WhenViewOSBConfigurationPageDeleteButtonIsClicked()
        {
            By delete = By.XPath("(//span[@class='fas fa-trash-alt'])[1]");
            By OSBConfig = By.XPath("//li[@test-id='eamConfigurations-li-eamConfigurationsList']//label[contains(.,'OSB Configuration')]");

            

            do
            {
               
                try
                {
                    deleteList = Browser.Wd.FindElements(By.XPath("//span[@class='fas fa-trash-alt']"));
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(delete);
                    tmsWait.Hard(5);
                    UIMODUtilFunctions.clickOnConfirmationYesDialog();
                    tmsWait.Hard(3);
                    Browser.Wd.Navigate().Refresh();
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(OSBConfig);
                    tmsWait.Hard(3);
                }
                catch
                {

                }

            } 
            while (deleteList.Count > 0);

            
        }


        [When(@"EAM Configuration page Add OSB Id for OSBType ""(.*)"" OSBName ""(.*)"" OSBID ""(.*)"" OSBDescription ""(.*)""")]
        public void WhenEAMConfigurationPageAddOSBIdForOSBTypeOSBNameOSBIDOSBDescription(string p0, string p1, string p2, string p3)
        {
            string osbtype = tmsCommon.GenerateData(p0);
            string osbname = tmsCommon.GenerateData(p1);
            string osbid = tmsCommon.GenerateData(p2);
            string osbdescription = tmsCommon.GenerateData(p3);

            //Clicking Add OSB button
            fw.ExecuteJavascript(EAM.AdminEAMConfiguration.ADDOSBButton);
            tmsWait.Hard(2);

            //Select OSB type
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='osbAddDetail-select-ddlOsbType']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + osbtype + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

            //Enter OSB ID OSB Name and OSB Description
            EAM.AdminEAMConfiguration.ADDOSBID.SendKeys(osbid);
            tmsWait.Hard(2);
            EAM.AdminEAMConfiguration.ADDOSBName.SendKeys(osbname);
            tmsWait.Hard(2);
            EAM.AdminEAMConfiguration.ADDOSBDescription.SendKeys(osbdescription);
            tmsWait.Hard(2);

            //Add button
            fw.ExecuteJavascript(EAM.AdminEAMConfiguration.ADDButtonforOSB);
            tmsWait.Hard(2);

            //Verify OSB Details in the Grid

            //bool hasrow = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='osbDetail-grid-osbDetails']//td[contains(.,'"+osbtype+"')]/parent::tr//td[contains(.,'"+osbid+"')]/parent::tr//td[contains(.,'"+osbname+"')]")).Displayed;
            //Assert.IsTrue(hasrow, "OSB Details not added properly");

            string xpath = "//kendo-grid[@test-id='osbDetail-grid-osbDetails']//td[contains(.,'" + osbtype + "')]/parent::tr//td[contains(.,'" + osbid + "')]/parent::tr//td[contains(.,'" + osbname + "')]";
            ReUsableFunctions.verifyGridElementPresence(xpath);



            fw.ExecuteJavascript(EAM.AdminEAMConfiguration.BacktoEAMConfigpage);
            tmsWait.Hard(2);



        }

        [When(@"EAM Configuration page Create NewOSBName byusing ""(.*)"" ""(.*)"" and  assigned to ""(.*)""")]
        public void WhenEAMConfigurationPageCreateNewOSBNameByusingAndAssignedTo(string p0, string p1, string p2)
        {
            string osbid = tmsCommon.GenerateData(p0);
            string osbname = tmsCommon.GenerateData(p1);
            string fullosbname = osbid + " - " + osbname;
            fw.setVariable(p2, fullosbname);
        }


        [When(@"EAM Configuration page Create ""(.*)"" using ""(.*)"" and ""(.*)""")]
        public void WhenEAMConfigurationPageCreateUsingAnd(string p0, string p1, string p2)
        {
            string osbid = tmsCommon.GenerateData(p1);
            string osbname = tmsCommon.GenerateData(p1);
            string fullosbname = osbid + " - " + osbname;
            fw.setVariable(p0, fullosbname);
        }



        [When(@"EAM Configuration page OSB Config tab ""(.*)"" Dropdown list is set to ""(.*)""")]
        public void WhenEAMConfigurationPageOSBConfigTabDropdownListIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(2);

            string field = p0.ToString();
            string value = p1.ToString();
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = null;

                By typeapp = null;
                switch (field)
                {


                    case "Plan ID":
                        Drp = By.XPath("//kendo-dropdownlist[@test-id='osbConfiguration-select-planId']//span[@class='k-select']");
                         typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                        break;
                    case "PBP ID":
                        IWebElement elecType = Browser.Wd.FindElement(By.XPath("//kendo-multiselect[@test-id='osbConfiguration-select-pbpId']//input"));

                        elecType.SendKeys(value);
                        tmsWait.Hard(3);
                        elecType.SendKeys(OpenQA.Selenium.Keys.Enter);

                        //Drp =   By.XPath("//kendo-multiselect[@test-id='osbConfiguration-select-pbpId']//span[@class='k-select']");
                        //typeapp = By.XPath("//li[text()='" + value + "']");

                        ////UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        //fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        //tmsWait.Hard(3);
                        ////UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        //fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                        break;
                    case "OSB Type":
                        //kendo-dropdownlist[@test-id='osbConfiguration-select-ddlOsbType']//span[@class='k-select']
                        Drp = By.XPath("//kendo-dropdownlist[@test-id='osbConfiguration-select-ddlOsbType']//span[@class='k-select']");
                         typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));

                        break;

                    case "OSB Name":
                        Drp = By.XPath("//kendo-dropdownlist[@test-id='osbConfiguration-select-ddlOsbName']//span[@class='k-select']");
                        string value1 = tmsCommon.GenerateData(value);
                        typeapp = By.XPath("//li[text()='" + value1 + "']");
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                        break;


                    case "OSB Start Year":
                        Drp = By.XPath("//kendo-dropdownlist[@test-id='osbConfiguration-select-ddlOsbStartYear']//span[@class='k-select']");
                        typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                        break;

                    case "OSB End Year":
                        Drp = By.XPath("//kendo-dropdownlist[@test-id='osbConfiguration-select-ddlOsbEndYear']//span[@class='k-select']");
                        typeapp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                        tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                        break;


                    case "EDIT OSB Premium":
                        By prem = By.XPath("//input[@name='osbPremium']");
                        UIMODUtilFunctions.enterValueOnWebElementUsingLocators(prem, value);
                        break;

                    case "EDIT OSB Start Year":
                        By start = By.XPath("//kendo-datepicker[@id='osbStartDate']//input");
                        ReUsableFunctions.enterValueOnWebElementWithClear(Browser.Wd.FindElement(start), value);
                        break;
                    case "EDIT OSB End Year":
                        By end = By.XPath("//kendo-datepicker[@id='osbEndDate']//input");
                        ReUsableFunctions.enterValueOnWebElementWithClear(Browser.Wd.FindElement(end), value);

                        break;

                }
               
            }
            else
            {
                switch (field)
                {


                    case "Plan ID":
                        SelectElement planid = new SelectElement(EAM.AdminEAMConfiguration.PlanID);
                        tmsWait.Hard(1);
                        planid.SelectByText(value);

                        break;
                    case "PBP ID":
                        SelectElement pbpId = new SelectElement(EAM.AdminEAMConfiguration.PBPID);
                        pbpId.SelectByText(value);
                        break;
                    case "OSB Type":
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(EAM.AdminEAMConfiguration.OSBType, value);

                        break;

                    case "OSB Start Year":
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(EAM.AdminEAMConfiguration.StartYear, value);
                        break;

                    case "OSB End Year":
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(EAM.AdminEAMConfiguration.EndYear, value);
                        break;


                    case "EDIT OSB Premium":
                        By prem = By.XPath("//input[@name='osbPremium']/preceding-sibling::input");
                        UIMODUtilFunctions.enterValueOnWebElementUsingLocators(prem, value);
                        break;

                    case "EDIT OSB Start Year":
                        By start = By.CssSelector("input[id='osbStartDate']");
                        ReUsableFunctions.enterValueOnWebElementWithClear(Browser.Wd.FindElement(start), value);
                        break;
                    case "EDIT OSB End Year":
                        By end = By.CssSelector("input[id='osbEndDate']");
                        ReUsableFunctions.enterValueOnWebElementWithClear(Browser.Wd.FindElement(end), value);

                        break;

                }
            }
            tmsWait.Hard(2);
            IWebElement currentElement = Browser.Wd.SwitchTo().ActiveElement();
            currentElement.SendKeys(Keys.Tab);

        }
        [When(@"Verify View OSB Configuration page Plan ID ""(.*)"" PBP ID ""(.*)"" OSB Type ""(.*)"" OSB amount ""(.*)"" Start Year ""(.*)"" End Year ""(.*)"" is filled correctly")]
        public void WhenVerifyViewOSBConfigurationPagePlanIDPBPIDOSBTypeOSBAmountStartYearEndYearIsFilledCorrectly(string p0, string p1, string p2, string p3, string p4, string p5)
        {

            string plan = tmsCommon.GenerateData(p0);
            string PBP = tmsCommon.GenerateData(p1);
            string osb = tmsCommon.GenerateData(p2);
            string amount = tmsCommon.GenerateData(p3);
            string start = tmsCommon.GenerateData(p4);
            string end = tmsCommon.GenerateData(p5);
            SelectElement planid = new SelectElement(EAM.AdminEAMConfiguration.PlanID);
            SelectElement pbpId = new SelectElement(EAM.AdminEAMConfiguration.PBPID);
            string osbselected = EAM.AdminEAMConfiguration.OSBType.Text;
            string amountentered = EAM.AdminEAMConfiguration.Premium.GetAttribute("value");
            string starty = EAM.AdminEAMConfiguration.StartYear.Text;
            string endy = EAM.AdminEAMConfiguration.EndYear.Text;
            tmsWait.Hard(1);
         
            IList<IWebElement> plansel = planid.AllSelectedOptions;
            IList<IWebElement> pbpbid = pbpId.AllSelectedOptions;

            Assert.IsTrue(plansel[0].Text.Equals(plan));

            Assert.IsTrue(pbpbid[0].Text.Equals(PBP));

            //while (!(amountentered.Equals(amount)){

            //}


           // }

            Assert.IsTrue(osbselected.Equals(osb));
            Assert.IsTrue(starty.Equals(start));
            Assert.IsTrue(endy.Equals(end));
        }

        [When(@"EAM Configuration page OSB Config tab OSB Premium is set to ""(.*)""")]
        public void WhenEAMConfigurationPageOSBConfigTabOSBPremiumIsSetTo(string p0)
        {
            tmsWait.Hard(20);
            EAM.AdminEAMConfiguration.Premium.SendKeys(Keys.Delete);
            tmsWait.Hard(10);
            GlobalRef.OSBAmount = p0.ToString();
            if (p0.Equals("10")) // Dont comment this statement as it is created for some TC's
            {
                tmsWait.Hard(1);
                EAM.AdminEAMConfiguration.Premium.Clear();
                tmsWait.Hard(1);
                EAM.AdminEAMConfiguration.Premium.SendKeys(Keys.Home);
                tmsWait.Hard(1);
                EAM.AdminEAMConfiguration.Premium.SendKeys("10");
                tmsWait.Hard(1);
              
            }
            else
            {
                tmsWait.Hard(2);
                string GeneratedData = tmsCommon.GenerateData(p0);
                EAM.AdminEAMConfiguration.Premium.SendKeys(GeneratedData);
            }
        }

        [When(@"EAM Configuration page OSB Config tab Save button is Clicked")]
        public void WhenEAMConfigurationPageOSBConfigTabSaveButtonIsClicked()
        {
            fw.ExecuteJavascript(EAM.AdminEAMConfiguration.Save);
            tmsWait.Hard(15);
            try
            {
                UIMODUtilFunctions.clickOnConfirmationYesDialog();
            }
            catch
            {

            }
        }

        [Then(@"Verify EAM Configuration page OSG Config tab displays message ""(.*)""")]
        public void ThenVerifyEAMConfigurationPageOSGConfigTabDisplaysMessage(string p0)
        {
            string expected = p0.ToString();
            String actual = EAM.AdminEAMConfiguration.SuccessMsg.Text;

            Assert.AreEqual(expected, actual, expected + " are matching with Actual results");

        }


        [When(@"EAM Configuration page OSB Config tab Update button is Clicked")]
        public void WhenEAMConfigurationPageOSBConfigTabUpdateButtonIsClicked()
        {
            tmsWait.Hard(4);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
               fw.ExecuteJavascript(EAM.AdminEAMConfiguration.AngUpdate);
            }
            else { 
            fw.ExecuteJavascript(EAM.AdminEAMConfiguration.Update);

            }
            UIMODUtilFunctions.clickOnConfirmationYesDialog();
            
        }

        [Then(@"EAM Configuration page View OSB Configuration table data has edited")]
        public void ThenEAMConfigurationPageViewOSBConfigurationTableDataHasEdited()
        {
            tmsWait.Hard(5);
            fw.ExecuteJavascript(EAM.AdminEAMConfiguration.OSBTableEditbutton);
        }

        [When(@"EAM Configuration page View OSB section Plan ID ""(.*)"" PBP ID ""(.*)"" OSB Type ""(.*)"" OSB amount ""(.*)"" Start Year ""(.*)"" End Year ""(.*)"" row is Clicked")]
        public void WhenEAMConfigurationPageViewOSBSectionPlanIDPBPIDOSBTypeOSBAmountStartYearEndYearRowIsClicked(string p0, string p1, string p2, string p3, string p4, string p5)
        {
            tmsWait.Hard(2);

            string plan = tmsCommon.GenerateData(p0);
            string PBP = tmsCommon.GenerateData(p1);
            string osb = tmsCommon.GenerateData(p2);
            string amount = tmsCommon.GenerateData(p3);
            string start = tmsCommon.GenerateData(p4);
            string end = tmsCommon.GenerateData(p5);
            
                string xpath = "//div[@role='presentation']//td[contains(.,'" + plan + "')]/following-sibling::td[contains(.,'" + PBP + "')]/following-sibling::td[contains(.,'" + osb + "')]/following-sibling::td[contains(.,'" + amount + "')]//following-sibling::td[contains(.,'" + start + "')]/following-sibling::td[contains(.,'" + end + "')]/following-sibling::td/button[contains(@class,'edit-command')]";
                ReUsableFunctions.clickOnGridElement(xpath);
            
        }

        [Then(@"Verify View OSB Configuration page View OSB Configuration table Plan ID ""(.*)"" PBP ID ""(.*)"" OSB amount ""(.*)"" Start Year ""(.*)"" End Year ""(.*)""")]
        public void ThenVerifyViewOSBConfigurationPageViewOSBConfigurationTablePlanIDPBPIDOSBAmountStartYearEndYear(string p0, string p1, string p2, string p3, string p4)
        {
            tmsWait.Hard(7);
            string plan = tmsCommon.GenerateData(p0);
            string PBP = tmsCommon.GenerateData(p1);
            string amount = tmsCommon.GenerateData(p2);
            string start = tmsCommon.GenerateData(p3);
            string end = tmsCommon.GenerateData(p4);

            By loc = By.XPath("//div[@test-id='osbConfiguration-grid-osbConfiguration']//td[contains(.,'" + plan + "')]/following-sibling::td[contains(.,'" + PBP + "')]/following-sibling::td[contains(.,'" + amount + "')]//following-sibling::td[contains(.,'" + start + "')]/following-sibling::td[contains(.,'" + end + "')]");

            UIMODUtilFunctions.elementPresenceUsingLocators(loc);

        }
        [Then(@"Verify View OSB Configuration page Plan ID ""(.*)"" PBP ID ""(.*)"" OSB Type ""(.*)"" OSB amount ""(.*)"" Start Year ""(.*)"" End Year ""(.*)""")]
        public void ThenVerifyViewOSBConfigurationPagePlanIDPBPIDOSBTypeOSBAmountStartYearEndYear(string p0, string p1, string p2, string p3, string p4, string p5)
        {
            tmsWait.Hard(10);
            string plan = tmsCommon.GenerateData(p0);
            string PBP = tmsCommon.GenerateData(p1);
            string osb = tmsCommon.GenerateData(p2);
            string amount = tmsCommon.GenerateData(p3);
            string start = tmsCommon.GenerateData(p4);
            string end = tmsCommon.GenerateData(p5);

            
                string xpath = "//div[@role='presentation']//td[contains(.,'" + plan + "')]/following-sibling::td[contains(.,'" + PBP + "')]/following-sibling::td[contains(.,'" + osb + "')]/following-sibling::td[contains(.,'" + amount + "')]//following-sibling::td[contains(.,'" + start + "')]/following-sibling::td[contains(.,'" + end + "')]";
                ReUsableFunctions.verifyGridElementPresence(xpath);

           
        }


        [Then(@"EAM Configuration page View OSB Configuration table has edited")]
        public void ThenEAMConfigurationPageViewOSBConfigurationTableHasEdited()
        {
            //second Element is edited
            IWebElement edit = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_OSBConfiguration_osbGrid_ctl00']//input[@title='Edit']"));
            edit.Click();
            tmsWait.Hard(2);
        }

        [When(@"EAM Configuration page View OSB Configuration table row has Edited and Canceled")]
        public void WhenEAMConfigurationPageViewOSBConfigurationTableRowHasEditedAndCanceled()
        {
            //fw.ExecuteJavascript(EAM.AdminEAMConfiguration.OSBTableEditbutton);
            tmsWait.Hard(2);
            fw.ExecuteJavascript(EAM.AdminEAMConfiguration.OSBTableCancelbutton);

        }


        [When(@"EAM Configuration page View OSB Configuration section table Plan ID drop down list is Clicked")]
        public void WhenEAMConfigurationPageViewOSBConfigurationSectionTablePlanIDDropDownListIsClicked()
        {

            fw.ExecuteJavascript(EAM.AdminEAMConfiguration.OSBTablePlanIDDropdown);

        }

        [When(@"EAM Configuration page View OSB Configuration section table Plan ID is set to ""(.*)""")]
        public void WhenEAMConfigurationPageViewOSBConfigurationSectionTablePlanIDIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            EAM.AdminEAMConfiguration.OSBTablePlanID.Click();

        }


        [Then(@"Verify EAM Configuration page View OSB Configuration table has row and delete row")]
        public void ThenVerifyEAMConfigurationPageViewOSBConfigurationTableHasRowAndDeleteRow(Table table)
        {
            tmsWait.Hard(1);

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.AdminEAMConfiguration.EAMConfigTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");
                //               Boolean bTransStatusMatching = false;
                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {

                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //if(AppTableRow.Equals(GherkinTableArray[iElementCounter])
                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (appTD.Equals("Canceled"))
                                //{

                                //    Assert.IsTrue(appTD.Equals("Canceled"));
                                //    bTransStatusMatching = true;
                                //    //Console.WriteLine("TC 61 status is found as Canceled");
                                //}

                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {

                                IWebElement thisEditTD = ApplicationRow.Element[0];
                                tmsWait.Hard(1);
                                IWebElement thisEditLink = thisEditTD.FindElement(By.XPath("//input[@title='Delete']"));
                                thisEditLink.Click();
                                tmsWait.Hard(2);

                                IAlert conf = Browser.Wd.SwitchTo().Alert();
                                conf.Accept();

                                break;

                                //    //report the success stuff.  Puts out the row data, etc.
                                //   thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }


                        }

                    }
                    iTableCounter++;
                    //if (bTransStatusMatching)
                    //{
                    //    Console.WriteLine("Transaction status is updated to Canceled in Transaction History");
                    //}
                }
                break;
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                //if (bTransStatusMatching)
                //{
                //    Console.WriteLine("Member Info page Transaction status is updated to Canceled in Transaction History table");
                //}

                //if (fullMatching)
                //{
                //    Console.WriteLine("All rows are matched, step completed as passed");
                //}
                //else
                //{
                //    //Click next page link and start over.
                //    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                //    {
                //        thisTP.bNotAtLastPageOfRecords = true;
                //        thisTP.NPL.Click();
                //        tmsWait.Hard(2);
                //    }
                //}
                //baseTable = EAM.MemberInformation.TransactionHistoryTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                //if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                //{
                //    thisTP.ReportNotMatching(thisGT.GTable);
                //}
            }


        }
        [Then(@"Verify EAM Configuration page View OSB Configuration table has row ""(.*)""")]
        public void ThenVerifyEAMConfigurationPageViewOSBConfigurationTableHasRow(string p0)
        {
            string expData = p0.ToString();
            string[] expTable = expData.Split(',');

            IWebElement actData = EAM.AdminEAMConfiguration.EAMConfigTable;
            string[] actTable = actData.Text.ToString().Replace("\r\n", "|").Split('|');

            foreach (String exp in expTable)
            {
                foreach (String act in actTable)
                {
                    if (act.Equals(exp))
                    {
                        fw.ConsoleReport("Expected Table row is displayed " + exp);
                        break;
                    }
                }
            }



        }


        [When(@"EAM Configuration page View OSB Configuration table ""(.*)"" drop down ""(.*)"" is selected")]
        public void WhenEAMConfigurationPageViewOSBConfigurationTableDropDownIsSelected(string p0, string p1)
        {
            string dropdown = p0.ToString();
            string value = p1.ToString();


            switch (dropdown)
            {
                case "Plan ID":
                    EAM.AdminEAMConfiguration.ViewOSBConfigSelectDrpdown.Click();
                    tmsWait.Hard(2);

                    switch (value)
                    {
                        case "All":
                            EAM.AdminEAMConfiguration.ViewOSBConfigAllPlanIDDrpdown.Click();
                            break;
                        case "H0001":
                            EAM.AdminEAMConfiguration.ViewOSBConfigH0001PlanIDDrpdown.Click();
                            break;
                    }

                    break;
                case "PBP ID":
                    EAM.AdminEAMConfiguration.ViewOSBConfigPBPIDSelectDrpdown.Click();
                    tmsWait.Hard(2);

                    switch (value)
                    {
                        case "All":
                            EAM.AdminEAMConfiguration.ViewOSBConfigAllPBPIDDrpdown.Click();
                            break;
                        case "002":
                            EAM.AdminEAMConfiguration.ViewOSBConfig002PlanIDDrpdown.Click();
                            break;
                    }

                    break;

                case "OSB Type":
                    EAM.AdminEAMConfiguration.ViewOSBConfigOSBTypeSelectDrpdown.Click();
                    tmsWait.Hard(2);

                    switch (value)
                    {
                        case "All":
                            EAM.AdminEAMConfiguration.ViewOSBConfigAllPBPIDDrpdown.Click();
                            break;
                        case "Medical OSB":
                            EAM.AdminEAMConfiguration.ViewOSBConfigMedOSBDrpdown.Click();
                            break;
                        case "Dental OSB":
                            EAM.AdminEAMConfiguration.ViewOSBConfigDentalOSBDrpdown.Click();
                            break;
                        case "Other OSB":
                            EAM.AdminEAMConfiguration.ViewOSBConfigOtherOSBDrpdown.Click();
                            break;
                        case "Vision OSB":
                            EAM.AdminEAMConfiguration.ViewOSBConfigVisionOSBDrpdown.Click();
                            break;
                    }

                    break;


            }
        }

        [Then(@"Verify EAM Configuration page View OSB Configuration table has values ""(.*)""")]
        public void ThenVerifyEAMConfigurationPageViewOSBConfigurationTableHasValues(string p0)
        {
            IWebElement element;
            string[] values = p0.Split(',');

            foreach (string temp in values)
            {
                element = Browser.Wd.FindElement(By.XPath("//div[@id='ctl00_ctl00_MainMasterContent_MainContent_OSBConfiguration_osbGrid_GridData']//tr[contains(.,'" + temp + "')]"));
                Assert.IsTrue(element.Displayed, element + " is not getting displayed");
            }
        }



        [Then(@"Verify EAM Configuration page View OSB Configuration table has row")]
        public void ThenVerifyEAMConfigurationPageViewOSBConfigurationTableHasRow(Table table)
        {

            tmsWait.Hard(10);

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.AdminEAMConfiguration.EAMConfigTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                //            thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 2)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[2];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                //else
                //{
                //    //Click next page link and start over.
                //    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                //    {
                //        thisTP.bNotAtLastPageOfRecords = true;
                //        thisTP.NPL.Click();
                //        tmsWait.Hard(2);
                //    }
                //}
                baseTable = EAM.AdminEAMConfiguration.EAMConfigTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }



        }

        [Then(@"Verify EAM Configuration page OSB Config tab ""(.*)"" field is set to ""(.*)""")]
        public void ThenVerifyEAMConfigurationPageOSBConfigTabFieldIsSetTo(string p0, string p1)
        {
            string field = p0.ToString();
            string expected = p1.ToString();

            switch (field)
            {
                case "Plan ID":

                    var plan = new SelectElement(EAM.AdminEAMConfiguration.PlanID);
                    string actualplan = plan.SelectedOption.Text;

                    Assert.AreEqual(expected, actualplan, expected + " value is getting matched with " + actualplan);

                    break;

                case "PBP ID":
                    var pbp = new SelectElement(EAM.AdminEAMConfiguration.PBPID);
                    string actualpbp = pbp.SelectedOption.Text;

                    Assert.AreEqual(expected, actualpbp, expected + " value is getting matched with " + actualpbp);

                    break;



            }


        }

        [When(@"EAM Configuration page OSB Config tab ""(.*)"" field is set to ""(.*)""")]
        public void WhenEAMConfigurationPageOSBConfigTabFieldIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(5);
            string field = p0.ToString();
            string value = p1.ToString();

            switch (field)
            {
                case "Plan ID":

                    var plan = new SelectElement(EAM.AdminEAMConfiguration.PlanID);
                    plan.SelectByValue(value);

                    break;

                case "PBP ID":
                    var pbp = new SelectElement(EAM.AdminEAMConfiguration.PBPID);
                    pbp.SelectByValue(value);


                    break;



            }

        }

        [When(@"EAM Configuration page OSB Config tab ""(.*)"" link is clicked")]
        public void WhenEAMConfigurationPageOSBConfigTabLinkIsClicked(string p0)
        {
            tmsWait.Hard(10);
           // fw.ExecuteJavascript(EAM.AdminEAMConfiguration.AuditHistory);
            ReUsableFunctions.clickOnWebElement(EAM.AdminEAMConfiguration.AuditHistory);
            //EAM.AdminEAMConfiguration.AuditHistory.Click();
            tmsWait.Hard(10);
        }

        [When(@"OSB Configuration History popup window Close button is clicked")]
        public void WhenOSBConfigurationHistoryPopupWindowCloseButtonIsClicked()
        {
            //IWebElement link = Browser.Wd.FindElement(By.XPath("//*[@id='eamAuditInfoDialog']/div[1]/span[2]/i"));
            // public IWebElement CloseButton { get { return Browser.Wd.FindElement(By.XPath("//*[@id="eamAuditInfoDialog"]/div[1]/span[2]/i")); } }
            //fw.ExecuteJavascript(EAM.AdminEAMConfiguration.CloseOsbConfigHistoryButton);
            ReUsableFunctions.clickOnWebElement(EAM.AdminEAMConfiguration.CloseOsbConfigHistoryButton);
            //fw.ExecuteJavascript(link);
            tmsWait.Hard(2);
        }



        [When(@"EAM Configuration page OSB Config tab OSB Configuration History is Clicked")]
        public void WhenEAMConfigurationPageOSBConfigTabOSBConfigurationHistoryIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(EAM.AdminEAMConfiguration.AuditHistory);
            //EAM.AdminEAMConfiguration.AuditHistory.Click();
        }

        [Then(@"Verify EAM Configuration page OSB Config tab Configuration History is set to ""(.*)""")]
        public void ThenVerifyEAMConfigurationPageOSBConfigTabConfigurationHistoryIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string expected = p0.ToString();
            string actual = EAM.AdminEAMConfiguration.AuditHistoryNoData.Text;

            Assert.AreEqual(expected, actual, expected + " value is getting matched with " + actual);

        }

        [Then(@"Verify EAM Configuration page View OSB Configuration section ""(.*)"" drop down list is set to ""(.*)""")]
        public void ThenVerifyEAMConfigurationPageViewOSBConfigurationSectionDropDownListIsSetTo(string p0, string p1)
        {
            string field = p0.ToString();
            string expected = p1.ToString();

            switch (field)
            {
                case "Plan ID":

                    string planid = EAM.AdminEAMConfiguration.OSBPlandrpdown.GetAttribute("value").ToString();

                    Assert.AreEqual(expected, planid, "Both are matching");
                    break;

                case "PBP":

                    string pbp = EAM.AdminEAMConfiguration.OSBPbpdrpdown.GetAttribute("value").ToString();

                    Assert.AreEqual(expected, pbp, "Both are matching");
                    break;
                case "OSB Type":

                    string osbtype = EAM.AdminEAMConfiguration.OSBOSBTypedrpdown.GetAttribute("value").ToString();

                    Assert.AreEqual(expected, osbtype, "Both are matching");
                    break;
                case "OSB Premium":

                    string premium = EAM.AdminEAMConfiguration.OSBOSBPremiumdrpdown.GetAttribute("value").ToString();

                    Assert.AreEqual(expected, premium, "Both are matching");
                    break;
                case "Start Date":

                    string start = EAM.AdminEAMConfiguration.OSBStartDatedrpdown.GetAttribute("value").ToString();

                    Assert.AreEqual(expected, start, "Both are matching");
                    break;
                case "End Date":

                    string end = EAM.AdminEAMConfiguration.OSBEndDatedrpdown.GetAttribute("value").ToString();

                    Assert.AreEqual(expected, end, "Both are matching");
                    break;

            }



        }


        [Then(@"Verify View OSB Configuration Plan ID as ""(.*)"" PBP Id as ""(.*)"" OSB Type as ""(.*)"" OSB Premium as ""(.*)""")]
        public void ThenVerifyViewOSBConfigurationPlanIDAsPBPIdAsOSBTypeAsOSBPremiumAs(string plan, string pbp, string osbtype, string osbpremium)
        {
            tmsWait.Hard(3);
            IWebElement data = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_OSBConfiguration_osbGrid_ctl00']//tr//td[contains(.,'" + plan + "')]/following-sibling::td[contains(.,'" + pbp + "')]/following-sibling::td[contains(.,'" + osbtype + "')]/following-sibling::td[contains(.,'" + osbpremium + "')]"));
            Assert.IsTrue(data.Displayed, "Plan " + plan + " PBP " + pbp + " OSB Type " + osbtype + " OSB Premium " + osbpremium + " Are not displayed");

        }

        [Then(@"Verify EAM Configuration page OSB Config tab displayed message ""(.*)""")]
        public void ThenVerifyEAMConfigurationPageOSBConfigTabDisplayedMessage(string p0)
        {
           ReUsableFunctions.toasterMessageDisplayWithoutWait(p0);
        }
        [Then(@"EAM Configuration page View OSB Configuration table row data should be deleted")]
        public void ThenEAMConfigurationPageViewOSBConfigurationTableRowDataShouldBeDeleted()
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Msg = By.XPath(" //div[@role='presentation']//tbody/tr");
             

                //  By Msg = By.XPath("//div[@test-id='osbConfiguration-grid-osbConfiguration']//tbody/tr");
                bool deleteIconPresence = false;
                try
                {
                    if (Browser.Wd.FindElement(Msg).Displayed)
                    {
                        while (!deleteIconPresence)
                        {
                            try
                            {
                                IWebElement delete = Browser.Wd.FindElement(By.XPath("(//div[@role='presentation']//td/a[2])[1]"));
                                tmsWait.Hard(3);
                                //fw.ExecuteJavascript(delete);
                                delete.Click();
                                tmsWait.Hard(2);
                                UIMODUtilFunctions.clickOnConfirmationYesDialog();
                                tmsWait.Hard(2);
                                Browser.Wd.Navigate().Refresh();
                                tmsWait.Hard(10);
                                By loc1 = By.XPath("//label[contains(.,'OSB Configuration')]");
                                UIMODUtilFunctions.clickOnWebElementUsingLocators(loc1);
                                tmsWait.Hard(2);

                            }
                            catch
                            {
                                deleteIconPresence = true;
                                fw.ConsoleReport(" There is no View OSB Configuration Record ");
                            }
                        }

                    }
                    else
                    {

                        fw.ConsoleReport(" There is no View OSB Configuration Record ");
                    }

                } // end of try
                catch
                {

                    fw.ConsoleReport(" There is no View OSB Configuration Record ");
                }

            }
            else { 
                By Msg = By.XPath("//div[@test-id='osbConfiguration-grid-osbConfiguration']//tbody/tr");
            bool deleteIconPresence = false;
            try
            {
                if (Browser.Wd.FindElement(Msg).Displayed)
                {
                    while (!deleteIconPresence)
                    {
                        try
                        {
                            IWebElement delete = Browser.Wd.FindElement(By.XPath("(//div[@test-id='osbConfiguration-grid-osbConfiguration']//td/a[2])[1]"));
                            tmsWait.Hard(3);
                            //fw.ExecuteJavascript(delete);
                            delete.Click();
                            tmsWait.Hard(2);
                            UIMODUtilFunctions.clickOnConfirmationYesDialog();
                            tmsWait.Hard(2);
                            Browser.Wd.Navigate().Refresh();
                            tmsWait.Hard(10);
                            By loc1 = By.XPath("//label[contains(.,'OSB Configuration')]");
                            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc1);
                            tmsWait.Hard(2);

                        }
                        catch
                        {
                            deleteIconPresence = true;
                            fw.ConsoleReport(" There is no View OSB Configuration Record ");
                        }
                    }
                   
                }
                else
                {
                   
                    fw.ConsoleReport(" There is no View OSB Configuration Record ");
                }

            } // end of try
            catch
            {
              
                fw.ConsoleReport(" There is no View OSB Configuration Record ");
            }


        }
        }

        [Then(@"EAM Configuration page View OSB Configuration table row has deleted")]
        public void ThenEAMConfigurationPageViewOSBConfigurationTableRowHasDeleted()
        {
            try
            {
                fw.ExecuteJavascript(EAM.AdminEAMConfiguration.OSBTableDeletebutton);

                Browser.ClosePopUps(true);
            }
            catch
            { }

        }

        [When(@"View/Edit Plan Info Page State is set to ""(.*)""")]
        public void WhenViewEditPlanInfoPageStateIsSetTo(string p0)
        {
            EAM.EditPLanInfo.State.Click();
            EAM.EditPLanInfo.State.SendKeys(p0);
        }

        [When(@"Edited Plan Info for planid ""(.*)"" and PBPID ""(.*)""")]
        public void WhenEditedPlanInfoForPlanidAndPBPID(string p0, int p1)
        {
            string Planid = tmsCommon.GenerateData(p0);
           

        }


        [When(@"View/Edit Plan Info Page MMP State is set to ""(.*)""")]
        public void WhenViewEditPlanInfoPageMMPStateIsSetTo(string p0)
        {
            SelectElement MMPState = new SelectElement(EAM.EditPLanInfo.MMPState);
            MMPState.SelectByText(p0);


        }


        [When(@"View/Edit Plan Info Page Medicare Product Name is set to ""(.*)""")]
        public void WhenViewEditPlanInfoPageMedicareProductNameIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.EditPLanInfo.MedicareProductName.Clear();
            EAM.EditPLanInfo.MedicareProductName.SendKeys(GeneratedData);
        }

        [When(@"View/Edit Plan Info Page Effective Date is set to ""(.*)""")]
        public void WhenViewEditPlanInfoPageEffectiveDateIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            String strValue = tmsCommon.GenerateData(p0);
            strValue = strValue.Replace("/", "");

            IWebElement objDate = EAM.EditPLanInfo.EditPlanEffectiveDate;
            objDate.Clear();
            objDate.SendKeys(strValue);
        }

        [When(@"View/Edit Plan Info Page Department is set to ""(.*)""")]
        public void WhenViewEditPlanInfoPageDepartmentIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.EditPLanInfo.Department.Clear();
            EAM.EditPLanInfo.Department.SendKeys(GeneratedData);
        }

        [Then(@"Verify View Bid Data Table Table")]
        public void ThenVerifyViewBidDataTableTable(Table table)
        {

            try
            {
                IWebElement objWebTable = EAM.ViewBidData.ViewBidDataTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Members View Edit Table has row: {0}", e.Message);
            }
            ////Create Storage for the Gherkin table and the page data
            //GherkinTable thisGT = new GherkinTable();
            //TablePaging thisTP = new TablePaging();

            ////Load the Gherkin table into the storage
            //thisGT.LoadGherkinTable(table);

            ////The big loop.  Keep working until all the Gherkin table rows are marked as matched
            ////Or until we are on the last page of records, then we also quit looking.
            //while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            //{
            //    //Start out with the assumption we are not on the last page of records.  We will check later.
            //    thisTP.bNotAtLastPageOfRecords = false;

            //    //Get the table object again, since the page refreshes we need to get it fresh
            //    IWebElement baseTable = EAM.ViewBidData.ViewBidDataTable;
            //    {

            //    }
            //    //Look for a next page link.  We will set 'last page of records' here also.
            //    //           thisTP.LoadNextPageLink(baseTable);

            //    //Load the page data off the application.   
            //    //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
            //    thisTP.LoadPageTable(baseTable, "th", "td");

            //    int iTableCounter = 0;
            //    //                string expectedTableCheckboxValue = "";
            //    //for each row in the Gherkin table, start flipping through all the rows in the page data.
            //    foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
            //    {
            //        //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

            //        //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
            //        if (GherkinTableRow == null)
            //        {
            //            break;
            //        }

            //        //If this Gherkin table row is not yet matched, proceed.
            //        if (GherkinTableRow.RowIsMatched == false)
            //        {
            //            //Convert the row to an array so we can do an element by element match.
            //            string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

            //            //For each row in the page data
            //            foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
            //            {
            //                //Convert page data to array elements
            //                //Only work with the loaded element rows.  The first unloaded one will be null.
            //                if (ApplicationRow == null)
            //                {
            //                    break;
            //                }

            //                //Convert the page row to array so we can pair up by elements.
            //                string[] AppTableRow = ApplicationRow.Row.ToArray();
            //                int iElementCounter = 0;
            //                Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

            //                //In here as we pair up the data you will have custom matching.
            //                //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
            //                foreach (string appTD in AppTableRow)
            //                {
            //                    //if (iElementCounter > 0 && TDA.RowIsData)
            //                    if (ApplicationRow.RowIsData)
            //                    {
            //                        //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
            //                        if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
            //                        {

            //                            bThisRowMatches = false;
            //                        }
            //                        //if (iElementCounter == 5)
            //                        //{
            //                        //    expectedTableCheckboxValue = GherkinTableArray[5];
            //                        //}
            //                    }
            //                    else
            //                    {
            //                        //Also fail row match if the element count of the page data row is 0
            //                        if (iElementCounter > 0)
            //                        {
            //                            bThisRowMatches = false;
            //                        }
            //                    }
            //                    iElementCounter++;
            //                }
            //                if (AppTableRow.Length == 0)
            //                {
            //                    //Another check that if the page data row is 0 long, we didn't match, fail the match.
            //                    bThisRowMatches = false;
            //                }
            //                //Instance of TableRow Class for reporting functions
            //                var TableRow = new TMSString();

            //                if (bThisRowMatches)
            //                {
            //                    //report the success stuff.  Puts out the row data, etc.
            //                    thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
            //                }
            //                if (bThisRowMatches)
            //                {
            //                    Assert.IsTrue(true,);
            //                }

            //            }
            //        }
            //        iTableCounter++;
            //    }
            //    //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
            //    Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
            //    if (fullMatching)
            //    {
            //        Console.WriteLine("All rows are matched, step completed as passed");
            //    }
            //    baseTable =  EAM.ViewBidData.ViewBidDataTable;

            //    //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
            //    //Time to boil it down and report which rows didn't get matched.
            //    //Also to fail because we were planning to match the rows.
            //    if (thisTP.bHaveGoodPageLink == false && !fullMatching)
            //    {
            //        thisTP.ReportNotMatching(thisGT.GTable);
            //    }
            //}
        }


        [When(@"View/Edit Plan Info Page Hours of Operation is set to ""(.*)""")]
        public void WhenViewEditPlanInfoPageHoursOfOperationIsSetTo(string p0)
        {
            EAM.EditPLanInfo.HoursOfOperation.Clear();
            EAM.EditPLanInfo.HoursOfOperation.SendKeys(p0);
        }

        [When(@"View/Edit Plan Info Page PremC is set to ""(.*)""")]
        public void WhenViewEditPlanInfoPagePremCIsSetTo(string p0)
        {
            EAM.EditPLanInfo.PremC.Clear();
            tmsWait.Hard(3);
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.EditPLanInfo.PremC.SendKeys(GeneratedData);
        }

        [When(@"View/Edit Plan Info Page PremD is set to ""(.*)""")]
        public void WhenViewEditPlanInfoPagePremDIsSetTo(string p0)
        {
            EAM.EditPLanInfo.PremD.Clear();
            tmsWait.Hard(3);
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.EditPLanInfo.PremD.SendKeys(GeneratedData);
        }

        [When(@"View/Edit Plan Info Page Deductible is set to ""(.*)""")]
        public void WhenViewEditPlanInfoPageDeductibleIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.EditPLanInfo.Deductible.Clear();
            EAM.EditPLanInfo.Deductible.SendKeys(GeneratedData);
        }

        [When(@"View/Edit Plan Info Page City is set to ""(.*)""")]
        public void WhenViewEditPlanInfoPageCityIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.EditPLanInfo.City.Clear();
            EAM.EditPLanInfo.City.SendKeys(GeneratedData);
        }


        [When(@"View/Edit Plan Info Page End Date is set to ""(.*)""")]
        public void WhenViewEditPlanInfoPageEndDateIsSetTo(string p0)
        {

            tmsWait.Hard(1);
            String strValue = tmsCommon.GenerateData(p0);
            strValue = strValue.Replace("/", "");
            IWebElement objDate = EAM.EditPLanInfo.EditPlanEndDate;
            objDate.Clear();
            objDate.SendKeys(strValue);

        }

        [Then(@"View/Edit Plan Info Page should get save message as ""(.*)""")]
        public void ThenViewEditPlanInfoPageShouldGetSaveMessageAs(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            IWebElement update = EAM.EditPLanInfo.PlanModifiedMessage;
            string updatemessage = update.Text.ToString();

            Assert.AreEqual(updatemessage, GeneratedData, "View Edit Plan info page message expected [" + GeneratedData + "], found [" + updatemessage + "]");
            tmsWait.Hard(3);
        }


        [Then(@"Verify ViewEdit Plan Info updated ""(.*)"" displayed ""(.*)""")]
        public void ThenVerifyViewEditPlanInfoUpdatedDisplayed(string p0, string p1)
        {
            switch (p0.ToLower())
            {
                case "product name":
                    Assert.AreEqual(EAM.EditPLanInfo.MedicareProductName.GetAttribute("value"), p1, "Product name is not modified correctly.");
                    break;
                case "department":
                    Assert.AreEqual(EAM.EditPLanInfo.Department.GetAttribute("value"), p1, "Department is not modified correctly.");
                    break;
                case "pbp type":
                    SelectElement pbpId = new SelectElement(EAM.EditPLanInfo.PBPType);
                    string pbptype = pbpId.SelectedOption.Text;
                    Assert.IsTrue(pbptype.Equals(p1), "PBP Type is not modified correctly.");

                    break;
            }
        }



        [Then(@"Verify View/Edit Plan Info Page MMP State field default value is set to ""(.*)""")]
        public void ThenVerifyViewEditPlanInfoPageMMPStateFieldDefaultValueIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            IWebElement ddele = Browser.Wd.FindElement(By.XPath("//kendo-dropdownlist[@formcontrolname='businessState']//span[@class='k-input']"));
            string actual_value = ddele.Text;
            Assert.IsTrue(actual_value.Contains(value), "Value does not match");
            
        }


        [Then(@"Verify View/Edit Plan Info Page MMP State field is disabled and default value is set to ""(.*)""")]
        public void ThenVerifyViewEditPlanInfoPageMMPStateFieldIsDisabledAndDefaultValueIsSetTo(string p0)
        {
            SelectElement MMPState = new SelectElement(EAM.EditPLanInfo.MMPState);

            Assert.IsTrue(EAM.EditPLanInfo.MMPState.Enabled == false, "Passed" + "MMPState field is disabled");
            Assert.AreEqual(p0, MMPState.SelectedOption.Text, "Passed" + "MMPState default value is {0}", MMPState.SelectedOption.Text);
        }

        [Then(@"Verify View/Edit Plan Info Page Deductible field has a value set to ""(.*)""")]
        public void ThenVerifyViewEditPlanInfoPageDeductibleFieldHasAValueSetTo(string p0)
        {
            if (EAM.EditPLanInfo.Deductible.Text == p0)
            {
                Assert.IsTrue(true, "Deductible is set to : {0}", p0);
            }
        }




        [Then(@"Verify View/Edit Plan Info Page PremC has a value ""(.*)""")]
        public void ThenVerifyViewEditPlanInfoPagePremCHasAValue(string p0)
        {

            string actualVal = EAM.EditPLanInfo.PremC.GetAttribute("value");
            string GeneratedData = tmsCommon.GenerateData(p0);
            if (actualVal.Equals(GeneratedData))
            {
                Assert.IsTrue(actualVal.Equals(GeneratedData), "PremC default value is set to :{0}", GeneratedData);
            }
            else
            {
                Assert.Fail("PremC {0} value not matching the expected {1}", EAM.EditPLanInfo.PremC.Text, GeneratedData);
            }
        }

        [Then(@"Verify View/Edit Plan Info Page PremD has a value ""(.*)""")]
        public void ThenVerifyViewEditPlanInfoPagePremDHasAValue(string p0)
        {
            EAM.EditPLanInfo.PremD.SendKeys(p0);
            tmsWait.Hard(2);
            string actualVal = EAM.EditPLanInfo.PremD.GetAttribute("value");
            string GeneratedData = tmsCommon.GenerateData(p0);
            if (actualVal.Equals(GeneratedData))
            {
                Assert.IsTrue(actualVal.Equals(GeneratedData), "PremD is set to :{0}", GeneratedData);
            }
            else
            {
                Assert.Fail("PremD {0} value not matching the expected {1}", EAM.EditPLanInfo.PremD.Text, GeneratedData);
            }
        }


        [Then(@"Verify View/Edit Plan Info Page RxID is Empty")]
        public void ThenVerifyViewEditPlanInfoPageRxIDIsEmpty()
        {

            tmsWait.Hard(2);
            if (EAM.EditPLanInfo.RxID.Text == string.Empty)
            {
                Assert.IsTrue(EAM.EditPLanInfo.RxID.Text == string.Empty, "Passed," + "  RxId is Reset to Empty");
            }
        }


        [When(@"View/Edit Plan Info Page RxID is set to ""(.*)""")]
        public void WhenViewEditPlanInfoPageRxIDIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            EAM.EditPLanInfo.RxID.SendKeys(p0);
        }

        [Then(@"Verify View/Edit Plan Info Page PremC field has a value set to ""(.*)""")]
        public void ThenVerifyViewEditPlanInfoPagePremCFieldHasAValueSetTo(string p0)
        {
            if (EAM.EditPLanInfo.PremC.Text == p0)
            {
                Assert.IsTrue(true,"Premc is set to : {0}", p0);
            }
        }

        [Then(@"Verify View/Edit Plan Info Page Medicare Product Name field has a value set to ""(.*)""")]
        public void ThenVerifyViewEditPlanInfoPageMedicareProductNameFieldHasAValueSetTo(string p0)
        {
            if (EAM.EditPLanInfo.MedicareProductName.Text == p0)
            {
                Assert.IsTrue(true,"MedicareProductName is set to : {0}", p0);
            }
        }

        [Then(@"Verify View/Edit Plan Info Page Effective Date is set to ""(.*)""")]
        public void ThenVerifyViewEditPlanInfoPageEffectiveDateIsSetTo(string p0)
        {
            if (EAM.EditPLanInfo.EditPlanEffectiveDate.Text == p0)
            {
                Assert.IsTrue(true,"EditPlanEffectiveDate is set to : {0}", p0);
            }
        }

        [Then(@"Verify View/Edit Plan Info Page Department is set to ""(.*)""")]
        public void ThenVerifyViewEditPlanInfoPageDepartmentIsSetTo(string p0)
        {
            if (EAM.EditPLanInfo.Department.Text == p0)
            {
                Assert.IsTrue(true,"Department is set to : {0}", p0);
            }
        }

        [Then(@"Verify View/Edit Plan Info Page Deductible is set to ""(.*)""")]
        public void ThenVerifyViewEditPlanInfoPageDeductibleIsSetTo(string p0)
        {
            if (EAM.EditPLanInfo.Deductible.Text == p0)
            {
                Assert.IsTrue(true,"Deductible is set to : {0}", p0);
            }
        }

        [Then(@"Verify View/Edit Plan Info Page Address1 is set to ""(.*)""")]
        public void ThenVerifyViewEditPlanInfoPageAddress1IsSetTo(string p0)
        {
            if (EAM.EditPLanInfo.Address1.Text == p0)
            {
                Assert.IsTrue(true,"Address1 is set to : {0}", p0);
            }
        }

        [Then(@"Verify View/Edit Plan Info Page City is set to ""(.*)""")]
        public void ThenVerifyViewEditPlanInfoPageCityIsSetTo(string p0)
        {
            if (EAM.EditPLanInfo.City.Text == p0)
            {
                Assert.IsTrue(true,"City is set to : {0}", p0);
            }
        }

        [Then(@"Verify View/Edit Plan Info Page State is set to ""(.*)""")]
        public void ThenVerifyViewEditPlanInfoPageStateIsSetTo(string p0)
        {
            if (EAM.EditPLanInfo.State.Text == p0)
            {
                Assert.IsTrue(true,"State is set to : {0}", p0);
            }
        }

        [Then(@"Verify View/Edit Plan Info Page ZIP is set to ""(.*)""")]
        public void ThenVerifyViewEditPlanInfoPageZIPIsSetTo(string p0)
        {
            if (EAM.EditPLanInfo.ZIP.Text == p0)
            {
                Assert.IsTrue(true,"ZIP is set to : {0}", p0);
            }
        }




        [Then(@"Verify View/Edit Plan Info Page RxGroup is set to ""(.*)""")]
        public void ThenVerifyViewEditPlanInfoPageRxGroupIsSetTo(string p0)
        {
            if (EAM.EditPLanInfo.RxGroup.Text == p0)
            {
                Assert.IsTrue(true,"RxGroup is set to : {0}", p0);
            }
        }





        [When(@"View/Edit Plan Info Page Save button is clicked")]
        public void WhenViewEditPlanInfoPageSaveButtonIsClicked()
        {
            EAM.EditPLanInfo.EditPlanInfoSave.Click();
            tmsWait.Hard(3);
            if (EAM.EditPLanInfo.EditMMPRuleConfirmation.Displayed)
            {
                tmsWait.Hard(3);
                EAM.EditPLanInfo.EditMMPRuleConfirmation.Click();
            }
            else
            {
                Console.WriteLine("MMP Rule edited successfully");
            }
        }

        [When(@"View/Edit Plan Info Page Reset button is clicked")]
        public void WhenViewEditPlanInfoPageResetButtonIsClicked()
        {
            EAM.EditPLanInfo.EditPlanInfoReset.Click();
        }



        [When(@"ViewBidData Page PBP ID is set to ""(.*)""")]
        public void WhenViewBidDataPagePBPIDIsSetTo(string p0)

        {
            tmsWait.Hard(2);
            SelectElement pbpId = new SelectElement(EAM.ViewBidData.PBPId);
            tmsWait.Hard(2);
            pbpId.SelectByText(p0);
        }

        [When(@"ViewBidData Page Segement Id is set to ""(.*)""")]
        public void WhenViewBidDataPageSegementIdIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            SelectElement segmentId = new SelectElement(EAM.ViewBidData.SegmentId);
            segmentId.SelectByText(p0);
        }

        [Then(@"ViewBidData Page PBP ID is disabled with a default value set to ""(.*)""")]
        public void ThenViewBidDataPagePBPIDIsDisabledWithADefaultValueSetTo(string p0)
        {
            SelectElement pbpId = new SelectElement(EAM.ViewBidData.PBPId);

            Assert.IsTrue(EAM.ViewBidData.PBPId.Enabled == false, "Passed" + "PBPId field is disabled");
            Assert.AreEqual(p0, pbpId.SelectedOption.Text, "Passed" + "PBP Id default value is {0}", pbpId.SelectedOption.Text);
        }

        [Then(@"ViewBidData Page Plan Id is set to ""(.*)""")]
        public void ThenViewBidDataPagePlanIdIsSetTo(string p0)
        {
            SelectElement PlanId = new SelectElement(EAM.ViewBidData.PlanId);
            tmsWait.Hard(2);
            Assert.AreEqual(p0, PlanId.SelectedOption.Text, "Passed" + "PBP Id default value is {0}", PlanId.SelectedOption.Text);
        }

        [Then(@"ViewBidData Page Plan Id is enabled with a default value set to ""(.*)""")]
        public void ThenViewBidDataPagePlanIdIsEnabledWithADefaultValueSetTo(string p0)
        {
            SelectElement PlanId = new SelectElement(EAM.ViewBidData.PlanId);
            tmsWait.Hard(2);
            Assert.IsTrue(EAM.ViewBidData.PBPId.Enabled == true, "Passed" + "PlanId field is enabled");
            Assert.AreEqual(p0, PlanId.SelectedOption.Text, "Passed" + "PBP Id default value is {0}", PlanId.SelectedOption.Text);
        }


        [Then(@"ViewBidData Page PBP ID is enabled with a default value set to ""(.*)""")]
        public void ThenViewBidDataPagePBPIDIsEnabledWithADefaultValueSetTo(string p0)
        {
            tmsWait.Hard(2);
            SelectElement pbpId = new SelectElement(EAM.ViewBidData.PBPId);
            Boolean fieldEnabled = EAM.ViewBidData.PBPId.Enabled;
            Assert.IsTrue(fieldEnabled == true, "Passed" + "PBPId field is disabled");
            Assert.AreEqual(p0, pbpId.SelectedOption.Text, "Passed" + "PBP Id default value is {0}", pbpId.SelectedOption.Text);
        }
        [Then(@"Verify ViewBidData Page Segment ID is set to ""(.*)""")]
        public void ThenVerifyViewBidDataPageSegmentIDIsSetTo(string p0)
        {

            p0 = tmsCommon.GenerateData(p0);
            string selected = "";
            IList<IWebElement> theseOptions = EAM.ViewBidData.SegmentId.FindElements(By.TagName("option"));
            foreach (IWebElement thisOption in theseOptions)
            {
                if (thisOption.Selected)
                {
                    selected = thisOption.Text;
                    break;
                }
            }
            Console.WriteLine("Verifying that ViewBidData Page Segment ID is set to [" + p0 + "], found [" + selected + "]");
            Assert.AreEqual(true, p0 == selected, "Verifying that ViewBidData Page Segment ID is set to [" + p0 + "], found [" + selected + "]");
        }

        [Then(@"ViewBidData Page Segment ID is enabled with a default value set to ""(.*)""")]
        public void ThenViewBidDataPageSegmentIDIsEnabledWithADefaultValueSetTo(string p0)
        {
            tmsWait.Hard(2);
            SelectElement segmentId = new SelectElement(EAM.ViewBidData.SegmentId);
            Assert.IsTrue(EAM.ViewBidData.SegmentId.Enabled, "Passed" + "SegmentId field is disabled");
            // Assert.IsTrue(EAM.ViewBidData.SegmentId.Enabled == true, "Passed" + "SegmentId field is disabled");
            Assert.AreEqual(p0, segmentId.SelectedOption.Text, "Passed" + "SegmentId default value is {0}", segmentId.SelectedOption.Text);
        }

        [Then(@"ViewBidData Page Segment ID is disabled with a default value set to ""(.*)""")]
        public void ThenViewBidDataPageSegmentIDIsDisabledWithADefaultValueSetTo(string p0)
        {
            SelectElement segmentId = new SelectElement(EAM.ViewBidData.SegmentId);

            Assert.IsTrue(EAM.ViewBidData.SegmentId.Enabled == false, "Passed" + "SegmentId field is disabled");
            Assert.AreEqual(p0, segmentId.SelectedOption.Text, "Passed" + "SegmentId default value is {0}", segmentId.SelectedOption.Text);
        }

        [Then(@"Verify that I can navigate to the last page ""(.*)"" of this report")]
        public void ThenVerifyThatICanNavigateToTheLastPageOfThisReport(string p0)
        {
            string totalpages = tmsCommon.GenerateData(p0);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                EAM.ViewBidData.LastPage.Click();
                tmsWait.Hard(3);
            }
            else
            {


                EAM.ViewBidData.LastPage.Click();
                tmsWait.Hard(3);
                //string lastpage = "";
                string currentpagenumber = Browser.Wd.FindElement(By.XPath("//input[@class='k-textbox']")).GetAttribute("aria-label");
                Assert.AreEqual(currentpagenumber, totalpages, "Last page navigation is failed");
                //string lastPage = EAM.ViewBidData.LastPageText.Text;
                //        IWebElement pagerTable = EAM.ViewBidData.PagerTable;
                //        IList<IWebElement> theseButtons = pagerTable.FindElements(By.TagName("a"));
                //        foreach (IWebElement thisButton in theseButtons)
                //        { 
                //            if (thisButton.GetAttribute("class") == "rgCurrentPage")
                //            {
                //                IWebElement thisSpan = thisButton.FindElement(By.TagName("span"));
                //                lastpage = thisSpan.Text;

                //            }

                //        }
                //        Assert.AreEqual(p0, lastpage, "Passed" + " " + "User can navigate to the last Page {0} of the report", lastpage);

                //    }        

                //}
            }
        }

    }
}
