﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Windows;
using System.Drawing;
//using System.Windows.Forms;
using System.Windows.Input;
using System.IO;
using OpenQA.Selenium.Support.UI;
using System.Text;
using TMSoR1.FrameworkCode;
using FileHelpers;

namespace TMSoR1
{
    [Binding]
    public class fsLoadEAFFile
    {
        [When(@"Load EAF File Browse button is clicked")]
        public void WhenLoadEAFFileBrowseButtonIsClicked()
        {
            EAM.LoadEAFFile.Browse.Click();
        }
        [When(@"Load EAF File Import button is clicked")]
        public void WhenLoadEAFFileImportButtonIsClicked()
        {
            EAM.LoadEAFFile.Import.Click();
        }
        string setCheckboxTo;

        [When(@"TMS FRM page First row of worksheet consists of column headers is ""(.*)""")]
        public void WhenTMSFRMPageFirstRowOfWorksheetConsistsOfColumnHeadersIs(string p0)
        {

            string GenerateData = tmsCommon.GenerateData(p0);


            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("unchecked"))
            {

                if (FRM.BatchUpdateProcessing.Checkbox.Selected == true)
                {
                    fw.ExecuteJavascript(FRM.BatchUpdateProcessing.Checkbox);
                }

            }
            else if (setCheckboxTo.Equals("checked"))
            {
                if (FRM.BatchUpdateProcessing.Checkbox.Selected == false)
                {
                    fw.ExecuteJavascript(FRM.BatchUpdateProcessing.Checkbox);
                }
            }
        }

        [Then(@"Verify TMS FRM page Batch Update Processing section displays uploaded File ""(.*)""")]
        public void ThenVerifyTMSFRMPageBatchUpdateProcessingSectionDisplaysUploadedFile(string p0)
        {
            tmsWait.Hard(2);
            string expected = p0.ToString();

            string actual = FRM.BatchUpdateProcessing.UploadedfileName.Text;

            Assert.AreEqual(expected, actual, p0 + " file is getting displayed");
        }

        [Then(@"TMS FRM page Batch Update Processing section Reset button is Clicked")]
        public void ThenTMSFRMPageBatchUpdateProcessingSectionResetButtonIsClicked()
        {
            fw.ExecuteJavascript(FRM.BatchUpdateProcessing.Reset);

        }
        [Then(@"Verify TMS FRM page Batch Update Processing section ""(.*)"" button is not displayed")]
        public void ThenVerifyTMSFRMPageBatchUpdateProcessingSectionButtonIsNotDisplayed(string p0)
        {
            string expected = p0.ToString();

            switch (expected)
            {


                case "Upload":
                    bool UploadVisible = FRM.BatchUpdateProcessing.Upload.Displayed;

                    Assert.IsFalse(UploadVisible, p0 + " button is not displayed");
                    break;

                case "Reset":
                    bool ResetVisible = FRM.BatchUpdateProcessing.Reset.Displayed;

                    Assert.IsFalse(ResetVisible, p0 + " button is not displayed");
                    break;
            }

        }



        [When(@"Load FRM Batch File page, Config File ALM Project, Test ID ""(.*)"" attached file ""(.*)"" is selected with New File Name ""(.*)"" Verify uploaded File display")]
        public void WhenLoadFRMBatchFilePageConfigFileALMProjectTestIDAttachedFileIsSelectedWithNewFileNameVerifyUploadedFileDisplay(string p0, string p1, string p2)
        {


            string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);

            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            Boolean didUpload = false;
            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");
            if (File.Exists(controllerFileLocation + p1_gen))
            {
                File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen, true);
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");

            }
            else
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
            if (didUpload)
            {

                string FileName = "C:\\Temp\\" + p1_gen;

                //For debugging
                string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen);
                File.Move(@FileName, @newFileName);
                FileName = newFileName;
                // FRM.BatchUpdateProcessing.Browse.Click();
                FRM.BatchUpdateProcessing.Browse.SendKeys(FileName);


                tmsWait.Hard(1);



            }
        }

        [When(@"Upload PDE File page, Config File ALM Project, Test ID ""(.*)"" attached file ""(.*)"" is selected with New File Name ""(.*)""")]
        public void WhenUploadPDEFilePageConfigFileALMProjectTestIDAttachedFileIsSelectedWithNewFileName(string p0, string p1, string p2)
        {

            string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);

            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            Boolean didUpload = false;
            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");
            if (File.Exists(controllerFileLocation + p1_gen))
            {
                File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen, true);
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");

            }
            else
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
            if (didUpload)
            {
                string FileName = "C:\\Temp\\" + p1_gen;
                //For debugging
                string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen);
                File.Move(@FileName, @newFileName);
                FileName = newFileName;
                Browser.Wd.FindElement(By.XPath("//input[@name='files']")).SendKeys(FileName);
                tmsWait.Hard(2);
                EAM.LoadEAFFile.Upload.Click();

                //IWebElement browse = Browser.Wd.FindElement(By.Id("ctl00_MainContent_File1"));
                //browse.SendKeys(FileName);
                //IWebElement Upload = Browser.Wd.FindElement(By.Id("ctl00_MainContent_UploadButton"));
                //Upload.Click();           

                tmsWait.Hard(20);
            }
        }

        [Then(@"Verify Administration Manage Plan SCC Message ""(.*)""")]
        public void ThenVerifyAdministrationManagePlanSCCMessage(string p0)
        {
            tmsWait.Hard(3);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]")).Displayed, "Expected Message is not displayed");
            }
            else
            {
                Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]")).Displayed, "Expected Message is not displayed");

            }
        }


        [Then(@"Verify Administration Manage Plan SCC Result Grid Error Message ""(.*)"" is displayed")]
        public void ThenVerifyAdministrationManagePlanSCCResultGridErrorMessageIsDisplayed(string p0)
        {
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + p0 + "')]")).Displayed, "Expected Message is not displayed");
        }

        [Then(@"Verify Administration Manage Plan SCC Toaster Message ""(.*)""")]
        public void ThenVerifyAdministrationManagePlanSCCToasterMessage(string expValue)
        {
            By toastMsg = By.XPath("//div[contains(@aria-label,'" + expValue + "')]");

            bool msgDisplay = Browser.Wd.FindElement(toastMsg).Displayed;
            Assert.IsTrue(msgDisplay, expValue + " is not displayed");

            tmsWait.Hard(15); // we put this wait intentionaly to disappear toaster message
        }

        [When(@"Load Plan PBP Seg ID to SCC Mapping page Show report link is Clicked")]
        public void WhenLoadPlanPBPSegIDToSCCMappingPageShowReportLinkIsClicked()
        {
            IWebElement link = Browser.Wd.FindElement(By.LinkText("Show report"));
            fw.ExecuteJavascript(link);


        }

        [Then(@"Verify ""(.*)"" is getting displayed successfully")]
        public void ThenVerifyIsGettingDisplayedSuccessfully(string p0)
        {
            Browser.SwitchToChildWindow();
            Browser.SwitchToIFrame();
            tmsWait.Hard(5);
            Assert.IsTrue(Browser.Wd.PageSource.Contains(p0));
        }

        [Then(@"Verify Manage Plan SCC page displayed Plan ID as ""(.*)"" PBP ID as ""(.*)"" Error message as ""(.*)""")]
        public void ThenVerifyManagePlanSCCPageDisplayedPlanIDAsPBPIDAsErrorMessageAs(string p0, string p1, string p2)
        {
            tmsWait.Hard(2);
            string plan = tmsCommon.GenerateData(p0);
            string pbp = tmsCommon.GenerateData(p1);
            string msg = tmsCommon.GenerateData(p2);

            By loc = By.XPath("//div[@test-id='scc-grid-planSccExceptions']//td[contains(.,'" + plan + "')]/following-sibling::td[contains(.,'" + pbp + "')]/following-sibling::td[contains(.,'" + msg + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }

        [When(@"Load EAM Batch File page Config File ALM Project Test ID ""(.*)"" attached file ""(.*)"" is selected with New File Name ""(.*)"" Verify Error Toaster message as ""(.*)""")]
        public void WhenLoadEAMBatchFilePageConfigFileALMProjectTestIDAttachedFileIsSelectedWithNewFileNameVerifyErrorToasterMessageAs(string p0, string p1, string p2, string p3)
        {
            tmsWait.Hard(5);
            string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);
            string expMsg = tmsCommon.GenerateData(p3);
            Boolean keepTrying = true;
            int maxAttempts = 11;
            int thisAttempt = 0;
            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            // We added this code for Jenkins run
            string SourceFileLocation = "C:\\SourceFile\\";
            Boolean didUpload = false;
            string source = SourceFileLocation + p1_gen;
            if (Directory.Exists(SourceFileLocation))
            {
                if (!File.Exists(controllerFileLocation))
                {
                    File.Copy(SourceFileLocation + p1_gen, controllerFileLocation + Path.GetFileName(source));
                }
            }

            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");
            if (File.Exists(controllerFileLocation + p1_gen))
            {
                File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen, true);
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");

            }
            else
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
            if (didUpload)
            {
                while (keepTrying)
                {
                    string FileName = "C:\\Temp\\" + p1_gen;


                    string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen);
                    //Move method moves an existing file to a new location with the same or a different file name, move delete original file
                    File.Move(@FileName, @newFileName);
                    FileName = newFileName;
                    EAM.UploadNewFile.Browse.SendKeys(FileName);
                    EAM.UploadNewFile.Import.Click();

                    string actualMsg = Browser.Wd.FindElement(By.XPath("//div[@class='toast-message']")).GetAttribute("aria-label");

                    fw.ConsoleReport(actualMsg);
                    Assert.AreEqual(expMsg, actualMsg, " Both message are not matching");
                    break;

                }

            }
        }


        [When(@"Load EAM Batch File page, Config File ALM Project, Test ID ""(.*)"" attached file ""(.*)"" is selected with New File Name ""(.*)""")]
        public void WhenLoadEAMBatchFilePageConfigFileALMProjectTestIDAttachedFileIsSelectedWithNewFileName(string p0, string p1, string p2)
        {
            string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);
            Boolean keepTrying = true;
            int maxAttempts = 11;
            int thisAttempt = 0;
            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            // We added this code for Jenkins run
            string SourceFileLocation = "C:\\SourceFile\\";
            Boolean didUpload = false;
            string source = SourceFileLocation + p1_gen;
            if (Directory.Exists(SourceFileLocation))
            {
                if (!File.Exists(controllerFileLocation + Path.GetFileName(source)))
                {
                    File.Copy(SourceFileLocation + p1_gen, controllerFileLocation + Path.GetFileName(source));
                }
            }

            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");
            if (File.Exists(controllerFileLocation + p1_gen))
            {
                if (!File.Exists("C:\\Temp\\" + p1_gen))
                {
                    File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen, true);
                    tmsWait.Hard(1);
                    didUpload = true;
                    Console.WriteLine("**Performed local copy because file did exist locally.");
                }
            }
            else
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
            if (didUpload)
            {
                while (keepTrying)
                {
                    string FileName = "C:\\Temp\\" + p1_gen;


                    string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen);
                    //Move method moves an existing file to a new location with the same or a different file name, move delete original file
                    File.Move(@FileName, @newFileName);
                    FileName = newFileName;
                    //EAM.UploadNewFile.Browse.SendKeys(FileName);
                    By Drp = By.CssSelector("[test-id='scc-input-fileUpload'] input");
                    Browser.Wd.FindElement(Drp).Clear();
                    Browser.Wd.FindElement(Drp).SendKeys(FileName);
                    Browser.Wd.FindElement(By.XPath("//kendo-upload[@test-id='scc-input-fileUpload']//button[contains(.,'Upload')]")).Click();
                    EAM.UploadNewFile.Import.Click();

                    break;

                }

            }
        }

        [When(@"Manage Plan SCC page Load the same File ""(.*)"" Again and Verify Error Toaster message as ""(.*)""")]
        public void WhenManagePlanSCCPageLoadTheSameFileAgainAndVerifyErrorToasterMessageAs(string p0, string expMsg)
        {


            tmsWait.Hard(5);
            string DuplicateFile = tmsCommon.GenerateData(p0);
            string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(DuplicateFile);
            EAM.UploadNewFile.Browse.SendKeys(newFileName);
            EAM.UploadNewFile.Import.Click();


            string actualMsg = Browser.Wd.FindElement(By.XPath("//div[@class='toast-message']")).GetAttribute("aria-label");

            fw.ConsoleReport(actualMsg);
            Assert.AreEqual(expMsg, actualMsg, " Both message are not matching");

        }

        [Then(@"Verify Manage Plan SCC page display Error Toaster message as ""(.*)""")]
        public void ThenVerifyManagePlanSCCPageDisplayErrorToasterMessageAs(string p0)
        {
            ReUsableFunctions.toasterMessageDisplay(p0);

        }


        [When(@"Load FRM Batch File page, Config File ALM Project, Test ID ""(.*)"" attached file ""(.*)"" is selected with New File Name ""(.*)""")]
        public void WhenLoadFRMBatchFilePageConfigFileALMProjectTestIDAttachedFileIsSelectedWithNewFileName(string p0, string p1, string p2)
        {


            string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);

            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            string controllerFileLocation1 = "c:\\SourceFile\\";
            Boolean didUpload = false;
            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");
            if (File.Exists(controllerFileLocation + p1_gen))
            {
                File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen, true);
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");

            }
             else if(File.Exists(controllerFileLocation1 + p1_gen))
            {
                File.Copy(controllerFileLocation1 + p1_gen, "C:\\Temp\\" + p1_gen, true);
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");

            }
            //else
            //{
            //    Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

            //    didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            //}
            if (didUpload)
            {
                string FileName = "C:\\Temp\\" + p1_gen;
                //For debugging
                string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen);
                File.Move(@FileName, @newFileName);
                FileName = newFileName;

                fw.ConsoleReport("Sending File using Send Keys on FRM Batch Update page");
                // FRM.BatchUpdateProcessing.Browse.Click();
                FRM.BatchUpdateProcessing.Browse.Clear();
                FRM.BatchUpdateProcessing.Browse.SendKeys(FileName);
                FRM.BatchUpdateProcessing.Upload.Click();
                tmsWait.Hard(1);
            }
        }

        [When(@"Load FRM Batch File page, Config File ALM Project, Test ID ""(.*)"" attached file ""(.*)"" is selected with New File Name ""(.*)"" without upload")]
        public void WhenLoadFRMBatchFilePageConfigFileALMProjectTestIDAttachedFileIsSelectedWithNewFileNameWithoutUpload(string p0, string p1, string p2)
        {


            string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);

            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            string controllerFileLocation1 = "c:\\SourceFile\\";
            Boolean didUpload = false;
            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");
            if (File.Exists(controllerFileLocation + p1_gen))
            {
                File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen, true);
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");

            }
            else if (File.Exists(controllerFileLocation1 + p1_gen))
            {
                File.Copy(controllerFileLocation1 + p1_gen, "C:\\Temp\\" + p1_gen, true);
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");

            }
            else
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
            if (didUpload)
            {
                string FileName = "C:\\Temp\\" + p1_gen;
                //For debugging
                string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen);
                File.Move(@FileName, @newFileName);
                FileName = newFileName;

                fw.ConsoleReport("Sending File using Send Keys on FRM Batch Update page");
                // FRM.BatchUpdateProcessing.Browse.Click();
                FRM.BatchUpdateProcessing.Browse.Clear();
                FRM.BatchUpdateProcessing.Browse.SendKeys(FileName);
                tmsWait.Hard(1);
            }
        }

        string thisResponse;

        [When(@"File Procesing Status page File Type as ""(.*)""  adn Click on Search button")]
        public void WhenFileProcesingStatusPageFileTypeAsAdnClickOnSearchButton(string value)
        {
            IWebElement fileProcessingSection = Browser.Wd.FindElement(By.XPath("//a[@title='File Processing Status']"));
            fw.ExecuteJavascript(fileProcessingSection);
            tmsWait.Hard(5);
            IWebElement serchBtn = Browser.Wd.FindElement(By.CssSelector("[test-id='trrlogging-btn-Search']"));
            IWebElement fileType = Browser.Wd.FindElement(By.CssSelector("[test-id='file-type-select']"));
            ReUsableFunctions.selectValueFromDropDown(fileType, value);
        }


        //Gurdeep Arora
        [Given(@"I select ""(.*)"" on File Processing page")]
        public void GivenISelectOnFileProcessingPage(string p0)
        {
            IWebElement fileProcessingSection = Browser.Wd.FindElement(By.XPath("//a[@title='File Processing Status']"));
            fw.ExecuteJavascript(fileProcessingSection);
            tmsWait.Implicit(30);
            string po_gen = tmsCommon.GenerateData(p0);
            IWebElement fileType = Browser.Wd.FindElement(By.XPath("//*[@aria-owns='formFileType_listbox']/span"));
            fw.ExecuteJavascript(fileType);
            IWebElement option = Browser.Wd.FindElement(By.XPath("//*[@id='formFileType-list']//li[contains(.,'" + p0 + "')]"));
            fw.ExecuteJavascript(option);
            tmsWait.Hard(3);
            IWebElement searchBtn = Browser.Wd.FindElement(By.Id("btnSearch"));
            fw.ExecuteJavascript(searchBtn);
            tmsWait.Hard(2);
        }

        [Given(@"I select ""(.*)"" on File processing page and verify file processing status of ""(.*)""  is ""(.*)""")]
        public void GivenISelectOnFileProcessingPageAndVerifyFileProcessingStatusOfIs(string p0, string fileName, string expStatus)
        {

            IWebElement StatusEle = Browser.Wd.FindElement(By.XPath("//*[@test-id='file-grid-fileProcessStatusGrid']//tbody/tr[1]/td[2]"));
            IWebElement fileNameEle = Browser.Wd.FindElement(By.XPath("//*[@test-id='file-grid-fileProcessStatusGrid']//tbody/tr[1]/td[2]"));
            IWebElement searchBtn = Browser.Wd.FindElement(By.Id("btnSearch"));
            string actualStatus = StatusEle.Text.ToString();
            int ReturnStatus = StatusValidation(actualStatus);
            fw.ConsoleReport(" Processing File Name -->" + fileName);
            while (ReturnStatus != 0)
            {
                fw.ExecuteJavascript(searchBtn);
                tmsWait.Hard(5);
                actualStatus = StatusEle.Text.ToString();
                ReturnStatus = StatusValidation(actualStatus);
            }

            if (fileNameEle.Text.Contains(fileName))
            {
                Assert.AreEqual(expStatus, actualStatus, "File Processing Status is not correct");
            }
            else
                Assert.Fail("CMS file does not exist");
        }
        string actualStatus;
        [When(@"CDM UI Mod Files are Processed ""(.*)"" Status is set to ""(.*)""")]
        public void WhenCDMUIModFilesAreProcessedStatusIsSetTo(string p0, string p1)
        {

            DateTime Start = DateTime.Now;
            tmsWait.Hard(60);
            string fileName = tmsCommon.GenerateData(p0);
            string procesingStatus = tmsCommon.GenerateData(p1);
            string xpath = "(//tr[contains(.,'"+ fileName + "')]//td[@aria-colindex='2']/div)[1]"; // Indicate Complete Status          

            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(20);
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(20);
            bool flag = false;
            while (!flag)
            {

                try
                {
                    actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                    flag = true;
                }
                catch
                {
                    Browser.Wd.Navigate().Refresh();
                    tmsWait.Hard(10);

                }
            }




            int ReturnStatus = StatusValidation(actualStatus);
            fw.ConsoleReport(" Processing File Name -->" + fileName);
            while (ReturnStatus != 0)
            {

                tmsWait.Hard(90);
                actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                ReturnStatus = StatusValidation(actualStatus);
            }
        }

        [When(@"CDM ""(.*)"" Files Processed for FileName ""(.*)"" to have Status ""(.*)""")]
        public void WhenCDMFilesProcessedForFileNameToHaveStatus(string file, string p1, string p2)
        {
            tmsWait.Hard(25);


            string fileName = tmsCommon.GenerateData(p1);
            if (file.Equals("Member Format"))
            {
                fileName = fileName + ".Members.completed";
            }
            if (file.Equals("CMS RAPs Response File"))
            {
                fileName = fileName + ".Claims.completed";
            }
            if (file.Equals("Claims Format"))
            {
                fileName = fileName + ".completed";
            }

            if (file.Equals("Cluster Deletes File"))
            {
                fileName = fileName + ".ClusterDeletes.completed";
            }

            if (file.Equals("CMS Transaction Summary"))
            {
                fileName = fileName + ".RAPS_SUMMARY.completed";
            }
            //if (file.Equals("CMS Transaction Summary"))
            //{
            //    fileName = fileName + ".RAPS_SUMMARY.completed";
            //}

            if (file.Equals("Provider File"))
            {

                fileName = (fileName.Split('.'))[0] + ".Providers.completed";
            }

            string procesingStatus = tmsCommon.GenerateData(p1);
            string xpath = "(//tr[contains(.,'" + fileName + "')]//parent::tr//td[2])[1]"; // Indicate Complete Status          

            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(30);
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(30);
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(30);
            bool flag = false;
            while (!flag)
            {
                try
                {
                    actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                    flag = true;
                }
                catch
                {
                    Browser.Wd.Navigate().Refresh();
                    tmsWait.Hard(10);
                }

            }
            int ReturnStatus = StatusValidation(actualStatus);
            fw.ConsoleReport(" Processing File Name -->" + fileName);
            while (ReturnStatus != 0)
            {

                tmsWait.Hard(5);
                actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                ReturnStatus = StatusValidation(actualStatus);
            }
        }


        [When(@"CDM Files Processed for FileName ""(.*)"" to have Status ""(.*)""")]
        public void WhenCDMFilesProcessedForFileNameToHaveStatus(string p0, string p1)
        {
            tmsWait.Hard(25);
            string fileName = tmsCommon.GenerateData(p0);
            string procesingStatus = tmsCommon.GenerateData(p1);
            string xpath = "//tr[contains(.,'" + fileName + "')]//parent::tr//td[2]"; // Indicate Complete Status          

            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(20);
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(20);

            bool flag = false;
            while (!flag)
            {
                try
                {
                    actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                    flag = true;
                }
                catch
                {
                    Browser.Wd.Navigate().Refresh();
                    tmsWait.Hard(10);
                }

            }
            int ReturnStatus = StatusValidation(actualStatus);
            fw.ConsoleReport(" Processing File Name -->" + fileName);
            while (ReturnStatus != 0)
            {

                tmsWait.Hard(5);
                actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                ReturnStatus = StatusValidation(actualStatus);
            }
        }


        [When(@"EAM UI Mod page Tasks menu ""(.*)"" submenu is Clicked")]
        public void WhenEAMUIModPageTasksMenuSubmenuIsClicked(string p0)
        {
            By menu = By.XPath("//a[@title='" + p0 + "']");
            ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(menu));
            tmsWait.Hard(2);
        }

        [When(@"LEP Data File Status page LEP File Name is selected as ""(.*)""")]
        public void WhenLEPDataFileStatusPageLEPFileNameIsSelectedAs(string p0)
        {
            string po_gen = tmsCommon.GenerateData(p0);
            IWebElement drp = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='ddlFileName_listbox']"));
            fw.ExecuteJavascript(drp);
            tmsWait.Hard(1);
            IWebElement option = Browser.Wd.FindElement(By.XPath("//ul[@id='ddlFileName_listbox']//li[contains(.,'" + po_gen + "')]"));
            fw.ExecuteJavascript(option);
            tmsWait.Hard(3);

        }

        [When(@"LEP Data File Status page search button is Clicked")]
        public void WhenLEPDataFileStatusPageSearchButtonIsClicked()
        {
            By menu = By.CssSelector("[test-id='lepFileStatus-btn-search']");
            ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(menu));
            tmsWait.Hard(2);
        }


        [When(@"verify EAM Files Processed for FileName ""(.*)"" to have Status ""(.*)""")]
        public void WhenVerifyEAMFilesProcessedForFileNameToHaveStatus(string p0, string p1)
        {
            tmsWait.Hard(20);
            string fileName = tmsCommon.GenerateData(p0);
            String actFileNameText = "";
            do
            {
                tmsWait.Hard(10);
                IWebElement FileProcessIcon = Browser.Wd.FindElement(By.CssSelector("[title='File Processing Status']"));
                fw.ExecuteJavascript(FileProcessIcon);
                tmsWait.Hard(10);
                actFileNameText = Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='file-grid-fileProcessStatusGrid']//tr/td[contains(.,'RAPS - Load HCC Risk Adjustment Manager')]/preceding-sibling::td[@aria-colindex='3']//p)[1]")).Text.ToString();
            } while (!actFileNameText.Contains(fileName));
            GlobalRef.JobID = Browser.Wd.FindElement(By.XPath("(//kendo-grid[@test-id='file-grid-fileProcessStatusGrid']//tr/td[contains(.,'RAPS - Load HCC Risk Adjustment Manager')]/preceding-sibling::td[@aria-colindex='1'])[1]")).Text.ToString();
            Console.Write("Job Id: " + GlobalRef.JobID);
            string actualStatus;
            string procesingStatus = tmsCommon.GenerateData(p1);
            string xpath = "//p[contains(text(),'" + fileName + "')]"; // Indicate Complete Status
            actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
            int ReturnStatus = StatusValidation(actualStatus);
            fw.ConsoleReport(" Processing File Name -->" + fileName);
            while (ReturnStatus != 0)
            {
                tmsWait.Hard(3);
                xpath = "//p[contains(text(),'" + fileName + "')]"; // Indicate Complete Status
                actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                ReturnStatus = StatusValidation(actualStatus);
            }

        }

        [When(@"LIS Files Processed for FileName ""(.*)"" to have Status ""(.*)""")]
        public void WhenLISFilesProcessedForFileNameToHaveStatus(string p0, string p1)
        {
            tmsWait.Hard(20);
            string actualStatus;
            string fileName = tmsCommon.GenerateData(p0);
            string procesingStatus = tmsCommon.GenerateData(p1);
            By SearchButton = By.CssSelector("[test-id='trrlogging-btn-Search']");
            string xpath;
            try
            {
                xpath = "(//tr[contains(.,'N/A')]//parent::tr//td[2]/span)[1]"; // Indicate Complete/ No Update Status
                actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();

            }
            catch
            {
                xpath = "(//tr[contains(.,'" + fileName + "')]//parent::tr//td[2]/span)[1]"; // Indicate Complete Status
                actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
            }

            int ReturnStatus = StatusValidation(actualStatus);
            fw.ConsoleReport(" Processing File Name -->" + fileName);
            while (ReturnStatus != 0)
            {
                SearchButton = By.CssSelector("[test-id='trrlogging-btn-Search']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(SearchButton));
                tmsWait.Hard(5);
                actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                ReturnStatus = LISStatusValidation(actualStatus);
            }
        }
        By importPlus;
       string actualstatus;
        [When(@"ESI EAM ""(.*)"" Job Processing Status for FileName ""(.*)"" to have Status ""(.*)""")]
        public void WhenESIEAMJobProcessingStatusForFileNameToHaveStatus(string p0, string p1, string p2)
        {
            tmsWait.Hard(20);

            string jobName = tmsCommon.GenerateData(p0);
            string fileName = tmsCommon.GenerateData(p1);
            string procesingStatus = tmsCommon.GenerateData(p2);

            // Select Job Type
            IWebElement jobType = Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlJobName_listbox']"));
            UIMODUtilFunctions.selectDropDownValueFromGendoUI(jobType, jobName);

            By SearchBtn = By.CssSelector("[test-id='jobProcessingStatus-button-search']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(SearchBtn);
            tmsWait.Hard(5);
            if (jobName.Equals("EAF File"))
            {
                importPlus = By.XPath("(//a[@aria-label='Expand'])[1]");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(importPlus);
            }
            tmsWait.Hard(5);

            string xpath = "//p[contains(.,'" + fileName + "')]/parent::td/following-sibling::td/span[@ng-bind='dataItem.requestStatus']";// Indicate Complete Status

            try
            {
                actualstatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
            }
            catch
            {

            }
            int ReturnStatus = StatusValidation(actualstatus);
            fw.ConsoleReport(" Processing File Name -->" + fileName);
            while (ReturnStatus != 0)
            {

                fw.ExecuteJavascript(Browser.Wd.FindElement(SearchBtn));
                tmsWait.Hard(3);

                UIMODUtilFunctions.clickOnWebElementUsingLocators(importPlus);
                tmsWait.Hard(5);
                actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                ReturnStatus = StatusValidation(actualStatus);
            }
        }

        [Then(@"Verify Job Processing Status Page displayed ""(.*)"" jobs is set to ""(.*)""")]
        public void ThenVerifyJobProcessingStatusPageDisplayedJobsIsSetTo(string p0, string p1)
        {
            string jobName = p0;
            string procesingStatus = tmsCommon.GenerateData(p1);
            IWebElement jobType;

            // Select Job Type

           
                jobType = Browser.Wd.FindElement(By.XPath("//*[@test-id='jobProcessingStatus-txt-ddlJobName']//span[@class='k-select']"));
                fw.ExecuteJavascript(jobType);
                By typeapp = By.XPath("//li[text()='" + jobName + "']");
                tmsWait.Hard(3);
           
            

            fw.ConsoleReport(jobName + " File Type Drop is selected and Filtered");
            tmsWait.Hard(15);
            By SearchBtn = By.CssSelector("[test-id='jobProcessingStatus-button-search']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(SearchBtn);
            tmsWait.Hard(15);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(SearchBtn);
            importPlus = By.XPath("(//a[@title='Expand Details'])[1]");
                tmsWait.Hard(5);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(importPlus);
                tmsWait.Hard(5);
            
            //tmsWait.Hard(15);

            fw.ConsoleReport(jobName + " Import Plus Button is Clicked");
            string xpath = "";
            if (ConfigFile.EnvType.Equals("ESI"))
            {
                xpath = "(//span[@ng-bind='dataItem.jobGroupName']/parent::td/following-sibling::td/span[@ng-bind='dataItem.jobTypeName']/parent::td/following-sibling::td/span[@ng-bind='dataItem.jobStatus'])[1]";// Indicate Complete Status
            }

            if (ConfigFile.EnvType.Equals("Main"))
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    xpath = "//td[contains(.,'" + jobName + "')]//following-sibling::td[@aria-colindex='4']";// Indicate Complete Status
                }
                else
                {
                    xpath = "(//span[@ng-bind='dataItem.jobGroupName']/parent::td/following-sibling::td/span[@ng-bind='dataItem.jobTypeName']/parent::td/following-sibling::td/span[@ng-bind='dataItem.jobStatus'])[1]";// Indicate Complete Status
                }
                    
            }

            try
            {
                actualstatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
            }
            catch
            {

            }
            int ReturnStatus = StatusValidation(actualstatus);
          
            fw.ConsoleReport(" Looking for Success Status for Letter Job Processing " + actualstatus);
            while (ReturnStatus != 0)
            {

                fw.ExecuteJavascript(Browser.Wd.FindElement(SearchBtn));
                tmsWait.Hard(8); // We put this wait intentionally as File processing is taking time for ESI, you can remove it when performance is improved

                UIMODUtilFunctions.clickOnWebElementUsingLocators(importPlus);
                tmsWait.Hard(10); // We put this wait intentionally as File processing is taking time for ESI
                actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                fw.ConsoleReport(" Current File Processing status --> " + actualStatus);
                ReturnStatus = StatusValidation(actualStatus);
            }


            Assert.AreEqual(procesingStatus, actualstatus, "Letter Generation Job Processing is Failed");
        }


        [Then(@"Verify EAM Files Processing page displayed ""(.*)"" to have Status ""(.*)""")]
        public void ThenVerifyEAMFilesProcessingPageDisplayedToHaveStatus(string p0, string p1)
        {
            tmsWait.Hard(20);
            string jobName = tmsCommon.GenerateData(p0);
            string expStatus = tmsCommon.GenerateData(p1);

            IWebElement drp = Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlJobName_listbox']"));
            UIMODUtilFunctions.selectDropDownValueFromGendoUI(drp, jobName);

            By SearchBtn = By.CssSelector("[test-id='jobProcessingStatus-button-search']");
            int i = 0;

            while (i < 5)
            {

                try
                {
                   
                    
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(SearchBtn);
                    tmsWait.Hard(20); //  Due to performance issue on Application we put this wait
                    fw.ConsoleReport(" Clicking on Search Button on File Processing page "+i);
                    i++;
                }
                catch
                {
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(SearchBtn);
                    tmsWait.Hard(20); //  Due to performance issue on Application we put this wait
                    fw.ConsoleReport(" Clicking on Search Button on File Processing page  " + i);
                    i++;
                }
            }
            
            string actstatus = Browser.Wd.FindElement(By.XPath("(//div[@test-id='jobProcessingStatus-grid-jobs']//td[contains(.,'Core System Update properties')]/following-sibling::td/span[@ng-bind='dataItem.jobStatus'])[1]")).Text;

            Assert.AreEqual(expStatus, actstatus, " Expected status is not met. please restart Element Services");


        }

        [When(@"PDEM Files Processed for FileName ""(.*)"" to have Status ""(.*)""")]
        public void WhenPDEMFilesProcessedForFileNameToHaveStatus(string p0, string p1)
        {
          
              
                tmsWait.Hard(20);


                string fileName = tmsCommon.GenerateData(p0);
                string procesingStatus = tmsCommon.GenerateData(p1);              
             

             
                string xpath = "//td/a[contains(@title,'"+ fileName + "')]/parent::td/preceding-sibling::td/span";

                Browser.Wd.Navigate().Refresh();
                tmsWait.Hard(10);

            By xpathRequestID = By.XPath("(//div[@test-id='file-grid-fileProcessStatusGrid']//tr[contains(.,'" + fileName + "')]/td/p)[1]");


            fw.ConsoleReport(" Processing File Name -->" + fileName);
                fw.ConsoleReport(" Looking for Success Status for File " + fileName);
               do
                {
                Browser.Wd.Navigate().Refresh();

                tmsWait.Hard(8); // We put this wait intentionally as File processing is taking time for ESI, you can remove it when performance is improved

                try
                {
                    actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                }
                catch
                {

                }
                    fw.ConsoleReport(" Current File Processing status --> " + actualStatus);
                    
                }
            while (actualStatus != "Complete");

            String RequestID = Browser.Wd.FindElement(xpathRequestID).Text.ToString();
            GlobalRef.RequestID = RequestID;
        }

        [When(@"EAM Files Processed for FileName ""(.*)"" Status is set to ""(.*)""")]
        public void WhenEAMFilesProcessedForFileNameStatusIsSetTo(string p0, string p1)
        {
            if (ConfigFile.EnvType.Equals("ESI") || ConfigFile.EnvType.Equals("Main"))
            {
                String jobName = GlobalRef.JobName.ToString();
                tmsWait.Hard(20);


                string fileName = tmsCommon.GenerateData(p0);
                string procesingStatus = tmsCommon.GenerateData(p1);

                // Select Job Type
                IWebElement jobType = Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlJobName_listbox']"));
                if (jobName.Equals("TRR File"))
                {
                    string idAttribute = jobType.GetAttribute("aria-owns");
                    IWebElement drpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='" + idAttribute + "']/li[.='" + jobName + "']"));
                    fw.ExecuteJavascript(drpValue);

                }
                else if (jobName.Equals("Deemed LIS File"))
                {
                    string idAttribute = jobType.GetAttribute("aria-owns");
                    IWebElement drpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='" + idAttribute + "']/li[.='Deemed LIS file']"));
                    fw.ExecuteJavascript(drpValue);
                }
                else if ((jobName.Equals("Provider File")) || (jobName.Equals("No Rx File")))
                {
                    string idAttribute = jobType.GetAttribute("aria-owns");
                    IWebElement drpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='" + idAttribute + "']/li[.='" + jobName + "']"));
                    fw.ExecuteJavascript(drpValue);
                }
                else
                {
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(jobType, jobName);
                }

                fw.ConsoleReport(jobName + " File Type Drop is selected and Filtered");

                By SearchBtn = By.CssSelector("[test-id='jobProcessingStatus-button-search']");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(SearchBtn);
                tmsWait.Hard(10);
                if (jobName.Equals("Reports") || jobName.Equals("EAF File") || jobName.Equals("OEC File") || jobName.Equals("TRR File") || jobName.Equals("No Rx File") || jobName.Equals("BQN File") || jobName.Equals("Deemed LIS File") || jobName.Equals("No Premium Due") || jobName.Equals("Provider File"))
                {
                    tmsWait.Hard(5);
                    importPlus = By.XPath("(//a[@aria-label='Expand'])[1]");
                    tmsWait.Hard(5);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(importPlus);
                }
                tmsWait.Hard(5);

                fw.ConsoleReport(jobName + " Import Plus Button is Clicked");
                string xpath = "";
                if (ConfigFile.EnvType.Equals("ESI"))
                {
                    // xpath = "//p[contains(.,'" + fileName + "')]/parent::td/following-sibling::td/span[@ng-bind='dataItem.requestStatus']";// Indicate Complete Status
                    xpath = "//tr[contains(.,'" + fileName + "')]//span[@ng-bind='dataItem.requestStatus']";
                }

                if (ConfigFile.EnvType.Equals("Main"))
                {
                    //xpath = "//p[contains(.,'" + fileName + "')]/parent::a/parent::td/following-sibling::td/span[@ng-bind='dataItem.requestStatus']";// Indicate Complete Status
                    xpath = "//tr[contains(.,'" + fileName + "')]//td/span[@ng-bind='dataItem.requestStatus']";
                }

                try
                {
                    actualstatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                }
                catch
                {

                }
                int ReturnStatus = StatusValidation(actualstatus);
                fw.ConsoleReport(" Processing File Name -->" + fileName);
                fw.ConsoleReport(" Looking for Success Status for File " + fileName);
                while (ReturnStatus != 0)
                {

                    fw.ExecuteJavascript(Browser.Wd.FindElement(SearchBtn));
                    tmsWait.Hard(8); // We put this wait intentionally as File processing is taking time for ESI, you can remove it when performance is improved

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(importPlus);
                    tmsWait.Hard(10); // We put this wait intentionally as File processing is taking time for ESI
                    actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                    fw.ConsoleReport(" Current File Processing status --> " + actualStatus);
                    ReturnStatus = StatusValidation(actualStatus);
                }

                Assert.AreEqual(procesingStatus, actualstatus," Both are not matching");
            }
            else
            {
                tmsWait.Hard(45);
                string actualStatus;
                string fileName = tmsCommon.GenerateData(p0);
                string procesingStatus = tmsCommon.GenerateData(p1);
                By SearchButton = By.CssSelector("[test-id='trrlogging-btn-Search']");
                string xpath = "//tr[contains(.,'" + fileName + "')]//td/span[@ng-bind='dataItem.requestStatus']"; // Indicate Complete Status
                actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                int ReturnStatus = StatusValidation(actualStatus);
                fw.ConsoleReport(" Processing File Name -->" + fileName);
                while (ReturnStatus != 0)
                {
                    SearchButton = By.CssSelector("[test-id='trrlogging-btn-Search']");
                    fw.ExecuteJavascript(Browser.Wd.FindElement(SearchButton));
                    tmsWait.Hard(20);
                    actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                    ReturnStatus = StatusValidation(actualStatus);
                }
            }
        }


        [When(@"EAM Files Processed for FileName ""(.*)"" to have Status ""(.*)""")]
        [Given(@"EAM Files Processed for FileName ""(.*)"" to have Status ""(.*)""")]
        [Then(@"EAM Files Processed for FileName ""(.*)"" to have Status ""(.*)""")]

        public void WhenEAMFilesProcessedForFileNameToHaveStatus(string p0, string p1)
        {
            if (ConfigFile.EnvType.Equals("ESI") || ConfigFile.EnvType.Equals("Main"))
            {
                string jobName = GlobalRef.JobName.ToString();

                if (ConfigFile.tenantType.Equals("tmsx") && jobName.Equals("No Premium Due"))
                {
                    jobName = "No Premium Due File";

                }

                tmsWait.Hard(20);
                string fileName = tmsCommon.GenerateData(p0);
                string procesingStatus = tmsCommon.GenerateData(p1);
                if(procesingStatus.Contains("Complete"))
                {
                    procesingStatus = "Success";
                }

                // Select Job Type
                IWebElement jobType=null;
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    fw.ConsoleReport(" No Action is required for tmsx");
                }
                else
                {
                     jobType = Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlJobName_listbox']"));
                }
                if(jobName.Equals("TRR File"))
                {
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {

                        fw.ConsoleReport(" No Action is required for TRR File");


                    }
                    else
                    {

                        string idAttribute = jobType.GetAttribute("aria-owns");
                        IWebElement drpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='" + idAttribute + "']/li[.='" + jobName + "']"));
                        fw.ExecuteJavascript(drpValue);
                    }
                  
                }
                else if (jobName.Equals("Deemed LIS File"))
                {
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        jobType = Browser.Wd.FindElement(By.XPath("//*[@test-id='jobProcessingStatus-txt-ddlJobName']//span[@class='k-select']"));
                        fw.ExecuteJavascript(jobType);
                        By typeapp = By.XPath("//li[text()='Deemed LIS file']");
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);


                    }
                    else
                    {
                        string idAttribute = jobType.GetAttribute("aria-owns");
                        IWebElement drpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='" + idAttribute + "']/li[.='Deemed LIS file']"));
                        fw.ExecuteJavascript(drpValue);
                    }
                }
                else if (jobName.Equals("Provider File"))
                {
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        jobType = Browser.Wd.FindElement(By.XPath("//*[@test-id='jobProcessingStatus-txt-ddlJobName']//span[@class='k-select']"));
                        fw.ExecuteJavascript(jobType);
                        By typeapp = By.XPath("//li[text()='Provider File']");
                        tmsWait.Hard(6);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                    }
                    else
                    {
                        string idAttribute = jobType.GetAttribute("aria-owns");
                        IWebElement drpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='" + idAttribute + "']/li[.='" + jobName + "']"));
                        fw.ExecuteJavascript(drpValue);
                    }
                }
                else if (jobName.Equals("EAF File"))
                {
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        jobType = Browser.Wd.FindElement(By.XPath("//*[@test-id='jobProcessingStatus-txt-ddlJobName']//span[@class='k-select']"));
                        fw.ExecuteJavascript(jobType);
                        By typeapp = By.XPath("//li[text()='EAF File']");
                        tmsWait.Hard(6);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                    }
                    else
                    {
                        string idAttribute = jobType.GetAttribute("aria-owns");
                        IWebElement drpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='" + idAttribute + "']/li[.='EAF File']"));
                        fw.ExecuteJavascript(drpValue);
                    }
                }

                else if (jobName.Equals("No Rx File"))
                {
                   
                        jobType = Browser.Wd.FindElement(By.XPath("//*[@test-id='jobProcessingStatus-txt-ddlJobName']//span[@class='k-select']"));
                        fw.ExecuteJavascript(jobType);
                        By typeapp = By.XPath("//li[text()='No Rx File']");
                        tmsWait.Hard(6);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                   
                }

                else if (jobName.Equals("LIS History"))
                {
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        jobType = Browser.Wd.FindElement(By.XPath("//*[@test-id='jobProcessingStatus-txt-ddlJobName']//span[@class='k-select']"));
                        fw.ExecuteJavascript(jobType);
                        By typeapp = By.XPath("//li[text()='LIS History']");
                        tmsWait.Hard(6);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                    }
                    else
                    {
                        string idAttribute = jobType.GetAttribute("aria-owns");
                        IWebElement drpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='" + idAttribute + "']/li[.='EAF File']"));
                        fw.ExecuteJavascript(drpValue);
                    }
                }
                else
                {
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        jobType = Browser.Wd.FindElement(By.XPath("//*[@test-id='jobProcessingStatus-txt-ddlJobName']//span[@class='k-select']"));
                        fw.ExecuteJavascript(jobType);
                        By typeapp = By.XPath("//li[text()='" + jobName + "']");
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);


                    }
                    else
                    {
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(jobType, jobName);
                    }
                }

                fw.ConsoleReport(jobName+" File Type Drop is selected and Filtered");

                By SearchBtn = By.CssSelector("[test-id='jobProcessingStatus-button-search']");
                By RefreshBtn = By.CssSelector("[test-id='jobProcessingStatus-button-refresh']");

                UIMODUtilFunctions.clickOnWebElementUsingLocators(SearchBtn);
                tmsWait.Hard(10); 
                if (jobName.Equals("Reports") ||jobName.Equals("EAF File") || jobName.Equals("OEC File") || jobName.Equals("TRR File") || jobName.Equals("No Rx File") || jobName.Equals("BQN File") || jobName.Equals("Deemed LIS File") || jobName.Contains("No Premium Due")|| jobName.Equals("Provider File") || jobName.Equals("LIS History") || jobName.Equals("Legacy Reset File"))
                {
                    tmsWait.Hard(5);
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        importPlus = By.XPath("(//a[@title='Expand Details'])[1]");
                        tmsWait.Hard(5);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(importPlus);
                        tmsWait.Hard(5);
                    }
                    else
                    {
                        importPlus = By.XPath("(//a[@aria-label='Expand'])[1]");
                        tmsWait.Hard(5);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(importPlus);
                        tmsWait.Hard(5);
                    }
                }
                tmsWait.Hard(5);

                 fw.ConsoleReport(jobName + " Import Plus Button is Clicked");
                string xpath = "";
                if (ConfigFile.EnvType.Equals("ESI"))
                {
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        if (jobName.Contains("No Premium Due"))
                        {
                            xpath = "//td[contains(.,'" + fileName + "')]//following-sibling::td[@aria-colindex='4']";
                        }
                        else {
                            xpath = "//td[contains(.,'" + fileName + "')]//following-sibling::td[@aria-colindex='3']";
                        }
                        
                    }
                    else
                    {

                        xpath = "//tr[contains(.,'" + fileName + "')]//span[@ng-bind='dataItem.requestStatus']";
                    }
                }

                if (ConfigFile.EnvType.Equals("Main"))
                {
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {

                        xpath = "//td[contains(.,'" + fileName + "')]//following-sibling::td[@aria-colindex='3']";
                    }
                    else
                    {
                        xpath = "//tr[contains(.,'" + fileName + "')]//td/span[@ng-bind='dataItem.requestStatus']";
                    }
                }

                try
                {
                   actualstatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                }
                catch
                {
                   actualstatus = "Pending";
                }
                int ReturnStatus = StatusValidation(actualstatus);
                int defaultExit = 3;

                fw.ConsoleReport(" Processing File Name -->" + fileName);
                fw.ConsoleReport(" Looking for Success Status for File " + fileName);
                while (ReturnStatus != 0)
                {
                    fw.ExecuteJavascript(Browser.Wd.FindElement(RefreshBtn)); /*Changed 5/6/2021: When using the Refresh button the Processing Page details remain expanded and we do not need to reclick the plus button*/
                    tmsWait.Hard(12); // We put this wait intentionally as File processing is taking time for ESI, you can remove it when performance is improved

                    //UIMODUtilFunctions.clickOnWebElementUsingLocators(importPlus);
                    //tmsWait.Hard(10); // We put this wait intentionally as File processing is taking time for ESI
                    try
                    {
                        actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                        fw.ConsoleReport(" Current File Processing status --> " + actualStatus);
                        ReturnStatus = StatusValidation(actualStatus);
                    }
                    catch
                    {
                        tmsWait.Hard(10);
                        if (defaultExit <= 0) { ReturnStatus = 0; fw.ConsoleReport("Exiting due to default counter, not seeing filename above for some reason."); } else { defaultExit--; }
                    }
                }

              //  fw.ConsoleReport(" Final status --> " + actualStatus);
               // Assert.AreEqual(procesingStatus, actualstatus, " Both execution Status are not matching");
            }
            else
            {
                tmsWait.Hard(45);
                string actualStatus;
                string fileName = tmsCommon.GenerateData(p0);
                string procesingStatus = tmsCommon.GenerateData(p1);
                By SearchButton = By.CssSelector("[test-id='trrlogging-btn-Search']");
                string xpath = "//tr[contains(.,'" + fileName + "')]//td/span[@ng-bind='dataItem.requestStatus']"; // Indicate Complete Status
                actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                int ReturnStatus = StatusValidation(actualStatus);
                fw.ConsoleReport(" Processing File Name -->" + fileName);
                while (ReturnStatus != 0)
                {
                    SearchButton = By.CssSelector("[test-id='trrlogging-btn-Search']");
                    fw.ExecuteJavascript(Browser.Wd.FindElement(SearchButton));
                    tmsWait.Hard(20);
                    actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                    ReturnStatus = StatusValidation(actualStatus);
                }
            }
        }


        [When(@"verify file processing status for ""(.*)"" file ""(.*)"" to have Status ""(.*)""")]
        public void WhenVerifyFileProcessingStatusForFileToHaveStatus(string p0, string p1, string p2)
        {
            if (ConfigFile.EnvType.Equals("ESI") || ConfigFile.EnvType.Equals("Main"))
            {
                String jobName = GlobalRef.JobName.ToString();
                tmsWait.Hard(30);


                string fileName = tmsCommon.GenerateData(p1);
                string procesingStatus = tmsCommon.GenerateData(p2);
                IWebElement jobType;
                // Select Job Type
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                     jobType = Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlJobName_listbox']"));

                }
                else
                {
                     jobType = Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlJobName_listbox']"));
                }
                    if (jobName.Equals("TRR File"))
                {
                    string idAttribute = jobType.GetAttribute("aria-owns");
                    IWebElement drpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='" + idAttribute + "']/li[.='" + jobName + "']"));
                    fw.ExecuteJavascript(drpValue);

                }
                else if (jobName.Equals("Deemed LIS File"))
                {
                    string idAttribute = jobType.GetAttribute("aria-owns");
                    IWebElement drpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='" + idAttribute + "']/li[.='Deemed LIS file']"));
                    fw.ExecuteJavascript(drpValue);
                }
                else if ((jobName.Equals("Provider File")) || (jobName.Equals("No Rx File")))
                {
                    string idAttribute = jobType.GetAttribute("aria-owns");
                    IWebElement drpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='" + idAttribute + "']/li[.='" + jobName + "']"));
                    fw.ExecuteJavascript(drpValue);
                }
                else
                {
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(jobType, jobName);
                }

                fw.ConsoleReport(jobName + " File Type Drop is selected and Filtered");

                By SearchBtn = By.CssSelector("[test-id='jobProcessingStatus-button-search']");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(SearchBtn);
                tmsWait.Hard(5);
                if (jobName.Equals("LIS History") || jobName.Equals("EAF File") || jobName.Equals("OEC File") || jobName.Equals("TRR File") || jobName.Equals("No Rx File") || jobName.Equals("BQN File") || jobName.Equals("Deemed LIS File") || jobName.Equals("Provider File"))
                {
                    importPlus = By.XPath("(//a[@aria-label='Expand'])[1]");
                    tmsWait.Hard(2);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(importPlus);
                    
                }
                tmsWait.Hard(8);

                fw.ConsoleReport(jobName + " Import Plus Button is Clicked");
                string xpath = "";

                tmsWait.Hard(5);
               
                    xpath = "//p[contains(.,'" + fileName + "')]/parent::a/parent::td/following-sibling::td/span[@ng-bind='dataItem.requestStatus']";// Indicate Complete Status
                

                try
                {
                    actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                }
                catch
                {

                }

                int ReturnStatus = StatusValidation(actualStatus);
                fw.ConsoleReport(" Processing File Name -->" + fileName);
                fw.ConsoleReport(" Looking for Success Status for File " + fileName);
                while (ReturnStatus != 0)
                {

                    fw.ExecuteJavascript(Browser.Wd.FindElement(SearchBtn));
                    tmsWait.Hard(8); // We put this wait intentionally as File processing is taking time for ESI, you can remove it when performance is improved

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(importPlus);
                    tmsWait.Hard(10); // We put this wait intentionally as File processing is taking time for ESI
                    actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                    fw.ConsoleReport(" Current File Processing status --> " + actualStatus);
                    ReturnStatus = StatusValidation(actualStatus);
                }

               // Assert.AreEqual(procesingStatus, actualStatus, " Expected status is not getting displayed");
            }
            else
            {
                tmsWait.Hard(45);
                string fileType = tmsCommon.GenerateData(p0);
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//tr[contains(.,'"+ fileType + "')]//a[@aria-label='Expand']")));
                string actualStatus;
                string fileName = tmsCommon.GenerateData(p1);
                string procesingStatus = tmsCommon.GenerateData(p2);
                By SearchButton = By.CssSelector("[test-id='trrlogging-btn-Search']");
                string xpath = "//tr[contains(.,'" + fileName + "')]//parent::tr//td[5]/span"; // Indicate Complete Status
                actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                int ReturnStatus = StatusValidation(actualStatus);
                fw.ConsoleReport(" Processing File Name -->" + fileName);
                while (ReturnStatus != 0)
                {
                    SearchButton = By.CssSelector("[test-id='trrlogging-btn-Search']");
                    fw.ExecuteJavascript(Browser.Wd.FindElement(SearchButton));
                    tmsWait.Hard(20);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//tr[contains(.,'" + fileType + "')]//a[@aria-label='Expand']")));
                    tmsWait.Hard(5);
                    actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                    ReturnStatus = StatusValidation(actualStatus);
                }
            }
        }



        //To Verify Failed or incorrect Deemed LIS file
        [When(@"EAM Files Failed for FileName ""(.*)"" to have Status ""(.*)""")]
        public void WhenEAMFilesFailedForFileNameToHaveStatus(string p0, string p1)
        {
            if (ConfigFile.EnvType.Equals("ESI") || ConfigFile.EnvType.Equals("Main"))
            {
                String jobName = GlobalRef.JobName.ToString();
                tmsWait.Hard(20);


                string fileName = tmsCommon.GenerateData(p0);
                string procesingStatus = tmsCommon.GenerateData(p1);

                // Select Job Type
                IWebElement jobType = Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlJobName_listbox']"));
                if (jobName.Equals("TRR File"))
                {
                    string idAttribute = jobType.GetAttribute("aria-owns");
                    IWebElement drpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='" + idAttribute + "']/li[.='" + jobName + "']"));
                    fw.ExecuteJavascript(drpValue);

                }
                else if (jobName.Equals("Deemed LIS File"))
                {
                    string idAttribute = jobType.GetAttribute("aria-owns");
                    IWebElement drpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='" + idAttribute + "']/li[.='Deemed LIS file']"));
                    fw.ExecuteJavascript(drpValue);
                }
                else if ((jobName.Equals("Provider File")) || (jobName.Equals("No Rx File")))
                {
                    string idAttribute = jobType.GetAttribute("aria-owns");
                    IWebElement drpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='" + idAttribute + "']/li[.='" + jobName + "']"));
                    fw.ExecuteJavascript(drpValue);
                }
                else
                {
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(jobType, jobName);
                }

                fw.ConsoleReport(jobName + " File Type Drop is selected and Filtered");

                By SearchBtn = By.CssSelector("[test-id='jobProcessingStatus-button-search']");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(SearchBtn);
                tmsWait.Hard(5);
                if (jobName.Equals("EAF File") || jobName.Equals("OEC File") || jobName.Equals("TRR File") || jobName.Equals("No Rx File") || jobName.Equals("BQN File") || jobName.Equals("Deemed LIS File") || jobName.Equals("Provider File"))
                {
                    importPlus = By.XPath("(//a[@aria-label='Expand'])[1]");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(importPlus);
                }
                tmsWait.Hard(5);

                fw.ConsoleReport(jobName + " Import Plus Button is Clicked");
                string xpath = "";
               
                    xpath = "//p[contains(.,'" + fileName + "')]/parent::a/parent::td/following-sibling::td/span[@ng-bind='dataItem.requestStatus']";// Indicate Complete Status
                

                try
                {
                    actualstatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                }
                catch
                {

                }
                 
                int ReturnStatus = StatusValidation(actualstatus);
                fw.ConsoleReport(" Processing File Name -->" + fileName);
                fw.ConsoleReport(" Looking for Success Status for File " + fileName);
                while (ReturnStatus != 0)
                {

                    fw.ExecuteJavascript(Browser.Wd.FindElement(SearchBtn));
                    tmsWait.Hard(8); // We put this wait intentionally as File processing is taking time for ESI, you can remove it when performance is improved

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(importPlus);
                    tmsWait.Hard(10); // We put this wait intentionally as File processing is taking time for ESI
                    actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                    fw.ConsoleReport(" Current File Processing status --> " + actualStatus);
                    ReturnStatus = StatusValidation(actualStatus);
                }

                //Assert.AreEqual(procesingStatus, actualstatus, procesingStatus+" Status is no getting displayed");
            }
            else
            {
                tmsWait.Hard(20);
                string actualStatus;
                string fileName = tmsCommon.GenerateData(p0);
                string procesingStatus = tmsCommon.GenerateData(p1);
                By SearchButton = By.CssSelector("[test-id='trrlogging-btn-Search']");
                string xpath = "//tr[contains(.,'" + fileName + "')]//parent::tr//td[2]/span"; // Indicate Complete Status
                actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                int ReturnStatus = FailedStatusValidation(actualStatus);
                fw.ConsoleReport(" Processing File Name -->" + fileName);
                while (ReturnStatus != 0)
                {
                    SearchButton = By.CssSelector("[test-id='trrlogging-btn-Search']");
                    fw.ExecuteJavascript(Browser.Wd.FindElement(SearchButton));
                    tmsWait.Hard(5);
                    actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                    ReturnStatus = FailedStatusValidation(actualStatus);
                }
            }
        }

      
        [When(@"EAM File Processing Status for FileName ""(.*)"" is ""(.*)"" or ""(.*)""")]
        public void WhenEAMFilesProcessingStatusForFileNameIsOr(string p0, string p1, string p2)
        {
            tmsWait.Hard(20);
            if (p1.Equals("Complete/No Updates") || p1.Equals("Complete/No Updates"))
            {
                p0 = "N/A";
                p1 = "Complete/No Updates";
            }
            if (p1.Equals("Complete") || p1.Equals("Complete"))
            {
                p0 = "N/A";
                p1 = "Complete/No Updates";
            }

            string actualStatus;
            string fileName = tmsCommon.GenerateData(p0);
            string procesingStatus = tmsCommon.GenerateData(p1);
            By SearchButton = By.CssSelector("[test-id='trrlogging-btn-Search']");
            string xpath = "//tr[contains(.,'" + fileName + "')]//parent::tr//td[2]/span"; // Indicate Complete Status

            actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
            int ReturnStatus = StatusValidation(actualStatus);
            fw.ConsoleReport(" Processing File Name -->" + fileName);
            while (ReturnStatus != 0)
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(SearchButton));
                tmsWait.Hard(5);
                actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                ReturnStatus = StatusValidation(actualStatus);
            }
        }


        [When(@"EAM Files Processing Status for FileName ""(.*)"" is ""(.*)""")]
        public void WhenEAMFilesProcessingStatusForFileNameIs(string p0, string p1)
        {
            tmsWait.Hard(20);
            p1 = tmsCommon.GenerateData(p1);
            if (p1.Equals("Complete/No Updates"))
            {
                p0 = "N/A";
            }
            else {
                p1 = "Complete";
            }
            string actualStatus;
            string fileName = tmsCommon.GenerateData(p0);
            string procesingStatus = tmsCommon.GenerateData(p1);
            By SearchButton = By.CssSelector("[test-id='trrlogging-btn-Search']");
            string xpath = "//tr[contains(.,'" + fileName + "')]//parent::tr//td[2]/span"; // Indicate Complete Status

            actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
            int ReturnStatus = StatusValidation(actualStatus);
            fw.ConsoleReport(" Processing File Name -->" + fileName);
            while (ReturnStatus != 0)
            {
                fw.ExecuteJavascript(Browser.Wd.FindElement(SearchButton));
                tmsWait.Hard(5);
                actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                ReturnStatus = StatusValidation(actualStatus);
            }
        }

        [When(@"EAM Files Processed for FileName ""(.*)"" to have expected Status ""(.*)""")]
        public void WhenEAMFilesProcessedForFileNameToHaveExpectedStatus(string p0, string p1)
        {
            tmsWait.Hard(10);
            string actualStatus;
            string fileName = tmsCommon.GenerateData(p0);
            string procesingStatus = tmsCommon.GenerateData(p1);
            By SearchButton = By.CssSelector("[test-id='trrlogging-btn-Search']");
            string xpath = "//tr[contains(.,'" + fileName + "')]//parent::tr//td[2]/span"; // Indicate Complete Status
            actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
            int ReturnStatus = FailedStatusValidation(actualStatus);
            fw.ConsoleReport(" Processing File Name -->" + fileName);
            while (ReturnStatus != 0)
            {
                SearchButton = By.CssSelector("[test-id='trrlogging-btn-Search']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(SearchButton));
                tmsWait.Hard(5);
                actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                ReturnStatus = FailedStatusValidation(actualStatus);
            }
        }

        public int FailedStatusValidation(string actualStatus)
        {
            if (actualStatus.Equals("Pending"))
            {
                tmsWait.Hard(3);
                return 1;
            }
            else if (actualStatus.Equals("Executing"))
            {
                return 1;
            }

            else if (actualStatus.Equals("Failed"))
            {

                return 0;
            }
            else if (actualStatus.Equals("Disabled"))
            {
                Assert.Fail("File Processing Job is Disabled");
                return 0;
            }
            else if (actualStatus.Equals("Complete"))
            {
                Assert.Fail("File Processing Job is failed");
                return 0;
            }
            else if (actualStatus.Equals("Complete/No Updates"))
            {

                return 0;
            }

            return 0;
        }

        public int LISStatusValidation(string actualStatus)
        {

            if (actualStatus.Equals("Pending"))
            {
                tmsWait.Hard(3);
                return 1;
            }
            else if (actualStatus.Equals("Executing"))
            {
                return 1;
            }

            else if (actualStatus.Equals("Failed"))
            {
                Assert.Fail("File Processing Job is failed");
                return 0;
            }

            else if (actualStatus.Equals("Failure"))
            {
               
                return 0;
            }
            else if (actualStatus.Equals("Disabled"))
            {
                Assert.Fail("File Processing Job is Disabled");
                return 0;
            }
            else if (actualStatus.Equals("Complete"))
            {

                return 0;
            }
            else if (actualStatus.Equals("Complete/No Updates"))
            {

                return 0;
            }

            return 0;
        }
        public int StatusValidation(string actualStatus)
        {
            if (actualStatus.Equals("Pending"))
            {
                tmsWait.Hard(3);
                return 1;
            }
            else if (actualStatus.Equals("Executing"))
            {
                return 1;
            }

            else if (actualStatus.Equals("Failed"))
            {
                Assert.Fail("File Processing Job is failed");
                return 0;
            }
           
            else if (actualStatus.Equals("Disabled"))
            {
                Assert.Fail("File Processing Job is Disabled");
                return 0;
            }
            else if (actualStatus.Equals("Complete"))
            {

                return 0;
            }
            else if (actualStatus.Equals("Success"))
            {

                return 0;
            }
            else if (actualStatus.Equals("Failure"))
            {

                return 0;
            }
            else if (actualStatus.Equals("Complete/No Updates"))
            {

                return 0;
            }
            //else if (actualStatus.Equals("Canceled"))
            //{

            //    return 0;
            //}
            

            return 0;
        }





        [When(@"Imports Page ALM Test ID ""(.*)"" attached File ""(.*)"" is renamed and imported with New File Name ""(.*)"" in EAM and Click on Delete Upload File button")]
        public void WhenImportsPageALMTestIDAttachedFileIsRenamedAndImportedWithNewFileNameInEAMAndClickOnDeleteUploadFileButton(string p0, string p1, string p2)
        {
            ReUsableFunctions.deleteFilesFromTempFolder();

            string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);


            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            // We added this code for Jenkins run
            string SourceFileLocation = "C:\\SourceFile\\";
            Boolean didUpload = false;
            string source = SourceFileLocation + p1_gen;

            if (!Directory.Exists(controllerFileLocation))  //  Verify Specific Folder Exists, if No then Create it.
            {
                Directory.CreateDirectory(controllerFileLocation);
            }

            if (Directory.Exists(SourceFileLocation))
            {
                if (!File.Exists(controllerFileLocation))
                {
                    File.Copy(SourceFileLocation + p1_gen, controllerFileLocation + Path.GetFileName(source));
                }
            }

            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");
            if (File.Exists(controllerFileLocation + p1_gen))
            {
                File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen, true);
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");

            }
            else
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
            if (didUpload)
            {

                string FileName = "C:\\Temp\\" + p1_gen;
                string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen);
                //Move method moves an existing file to a new location with the same or a different file name, move delete original file
                File.Move(@FileName, @newFileName);
                FileName = newFileName;
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    By Drp = By.CssSelector("[test-id='import-input-fileUpload'] input");
                    Browser.Wd.FindElement(Drp).Clear();
                    Browser.Wd.FindElement(Drp).SendKeys(FileName);
                }
                else
                {
                    EAM.LoadEAFFile.SelectFiles.SendKeys(FileName);
                }
                tmsWait.Hard(4);
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    IWebElement deleteBtn = Browser.Wd.FindElement(By.XPath("//button[contains(.,'Delete uploaded files')]"));
                    fw.ExecuteJavascript(deleteBtn);
                }
                else
                {
                    IWebElement deleteBtn = Browser.Wd.FindElement(By.XPath("//button[contains(.,'Delete uploaded file')]"));
                    fw.ExecuteJavascript(deleteBtn);
                }
                tmsWait.Hard(4);


            }

        }

        [When(@"Imports Page ALM Test ID ""(.*)"" attached File ""(.*)"" is renamed and imported with New File Name ""(.*)"" in EAM and Verify")]
        public void WhenImportsPageALMTestIDAttachedFileIsRenamedAndImportedWithNewFileNameInEAMAndVerify(string p0, string p1, string p2)
        {
            ReUsableFunctions.deleteFilesFromTempFolder();
            string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);


            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            string controllerFileLocation = "c:\\temp\\";
            // We added this code for Jenkins run
            string SourceFileLocation = "C:\\SourceFile\\";
            Boolean didUpload = false;
            string source = SourceFileLocation + p1_gen;
            if (Directory.Exists(SourceFileLocation))
            {
                if (!File.Exists(controllerFileLocation))
                {
                    File.Copy(SourceFileLocation + p1_gen, controllerFileLocation + Path.GetFileName(source));
                }
            }

            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");
            if (File.Exists(controllerFileLocation + p1_gen))
            {
              //  File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen, true);
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");

            }
            else
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
            if (didUpload)
            {

                string FileName = "C:\\Temp\\" + p1_gen;
                string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen);
                //Move method moves an existing file to a new location with the same or a different file name, move delete original file
                File.Move(@FileName, @newFileName);
                FileName = newFileName;
                EAM.LoadEAFFile.SelectFiles.SendKeys(FileName);
                tmsWait.Hard(10);




            }
        }

        [When(@"Clicked on Info icon and Verify Tooltip message ""(.*)""")]
        public void WhenClickedOnInfoIconAndVerifyTooltipMessage(string toolTipMsg)
        {
            // Click on Info Icno

            By info = By.CssSelector("[test-id='import-tooltip-noteInfoTooltip']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(info));
            tmsWait.Hard(1);
            // Verify Tooltip message
            By msg = By.XPath("//div[@class='k-tooltip-content'][contains(.,'" + toolTipMsg + "')]");
            bool toolTipDisplay = Browser.Wd.FindElement(msg).Displayed;
            Assert.IsTrue(toolTipDisplay, "Toolip is not displayed");
        }


        [Then(@"Verify Imports page should not display button ""(.*)""")]
        public void ThenVerifyImportsPageShouldNotDisplayButton(string p0)
        {
            try
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    IWebElement deleteBtn = Browser.Wd.FindElement(By.XPath("//button[contains(.,'Delete uploaded file')]"));
                    fw.ExecuteJavascript(deleteBtn);
                }
                else
                {
                    IWebElement deleteBtn = Browser.Wd.FindElement(By.XPath("//button[contains(.,'Delete uploaded file')]"));
                    Assert.Fail(p0 + " button is displayed");
                }
            }
            catch
            {
                Assert.IsTrue(true);
                fw.ConsoleReport(p0 + " button is not displayed");
            }


        }

        [Then(@"Verify Imports page displayed message as ""(.*)""")]
        public void ThenVerifyImportsPageDisplayedMessageAs(string errorMsg)
        {
            tmsWait.Hard(20);
            //IWebElement errorMsgs = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + errorMsg + "')]"));
            IWebElement errorMsgs = Browser.Wd.FindElement(By.XPath("//span[contains(text(),'" + errorMsg + "')]"));
            bool msgPresence = errorMsgs.Displayed;
            Assert.IsTrue(msgPresence, errorMsg + " is not getting displayed");

        }

        [Then(@"Verify File Processing page displayed message as ""(.*)"" for File Name ""(.*)""")]
        public void ThenVerifyFileProcessingPageDisplayedMessageAsForFileName(string errorMsg, string p0)
        {
            string procesingStatus="";
            if (ConfigFile.EnvType.Equals("ESI") || ConfigFile.EnvType.Equals("Main"))
            {
                string jobName = GlobalRef.JobName.ToString();
                tmsWait.Hard(20);


                string fileName = tmsCommon.GenerateData(p0);
                 procesingStatus = "Failure";
                

                // Select Job Type
                IWebElement jobType = null;
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    fw.ConsoleReport(" No Action is required for tmsx");
                }
                else
                {
                    jobType = Browser.Wd.FindElement(By.CssSelector("[aria-owns='ddlJobName_listbox']"));
                }
                if (jobName.Equals("TRR File"))
                {
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {

                        fw.ConsoleReport(" No Action is required for TRR File");


                    }
                    else
                    {

                        string idAttribute = jobType.GetAttribute("aria-owns");
                        IWebElement drpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='" + idAttribute + "']/li[.='" + jobName + "']"));
                        fw.ExecuteJavascript(drpValue);
                    }

                }
                else if (jobName.Equals("Deemed LIS File"))
                {
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        jobType = Browser.Wd.FindElement(By.XPath("//*[@test-id='jobProcessingStatus-txt-ddlJobName']//span[@class='k-select']"));
                        fw.ExecuteJavascript(jobType);
                        By typeapp = By.XPath("//li[text()='Deemed LIS file']");
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);


                    }
                    else
                    {
                        string idAttribute = jobType.GetAttribute("aria-owns");
                        IWebElement drpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='" + idAttribute + "']/li[.='Deemed LIS file']"));
                        fw.ExecuteJavascript(drpValue);
                    }
                }
                else if (jobName.Equals("Provider File"))
                {
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        jobType = Browser.Wd.FindElement(By.XPath("//*[@test-id='jobProcessingStatus-txt-ddlJobName']//span[@class='k-select']"));
                        fw.ExecuteJavascript(jobType);
                        By typeapp = By.XPath("//li[text()='Provider File']");
                        tmsWait.Hard(6);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                    }
                    else
                    {
                        string idAttribute = jobType.GetAttribute("aria-owns");
                        IWebElement drpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='" + idAttribute + "']/li[.='" + jobName + "']"));
                        fw.ExecuteJavascript(drpValue);
                    }
                }
                else if (jobName.Equals("EAF File"))
                {
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        jobType = Browser.Wd.FindElement(By.XPath("//*[@test-id='jobProcessingStatus-txt-ddlJobName']//span[@class='k-select']"));
                        fw.ExecuteJavascript(jobType);
                        By typeapp = By.XPath("//li[text()='EAF File']");
                        tmsWait.Hard(6);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                    }
                    else
                    {
                        string idAttribute = jobType.GetAttribute("aria-owns");
                        IWebElement drpValue = Browser.Wd.FindElement(By.XPath("//ul[@id='" + idAttribute + "']/li[.='EAF File']"));
                        fw.ExecuteJavascript(drpValue);
                    }
                }
                else
                {
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        jobType = Browser.Wd.FindElement(By.XPath("//*[@test-id='jobProcessingStatus-txt-ddlJobName']//span[@class='k-select']"));
                        fw.ExecuteJavascript(jobType);
                        By typeapp = By.XPath("//li[text()='" + jobName + "']");
                        tmsWait.Hard(3);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);


                    }
                    else
                    {
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(jobType, jobName);
                    }
                }

                fw.ConsoleReport(jobName + " File Type Drop is selected and Filtered");

                By SearchBtn = By.CssSelector("[test-id='jobProcessingStatus-button-search']");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(SearchBtn);
                tmsWait.Hard(10);
                if (jobName.Equals("Reports") || jobName.Equals("EAF File") || jobName.Equals("OEC File") || jobName.Equals("TRR File") || jobName.Equals("No Rx File") || jobName.Equals("BQN File") || jobName.Equals("Deemed LIS File") || jobName.Equals("No Premium Due") || jobName.Equals("Provider File") || jobName.Equals("LIS History") || jobName.Equals("Legacy Reset File"))
                {
                    tmsWait.Hard(5);
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        importPlus = By.XPath("(//a[@title='Expand Details'])[1]");
                        tmsWait.Hard(5);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(importPlus);
                        tmsWait.Hard(5);
                    }
                    else
                    {
                        importPlus = By.XPath("(//a[@aria-label='Expand'])[1]");
                        tmsWait.Hard(5);
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(importPlus);
                        tmsWait.Hard(5);
                    }
                }
                tmsWait.Hard(5);

                fw.ConsoleReport(jobName + " Import Plus Button is Clicked");
                string xpath = "";
                if (ConfigFile.EnvType.Equals("ESI"))
                {
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        xpath = "//td[contains(.,'" + fileName + "')]//following-sibling::td[@aria-colindex='3']";
                    }
                    else
                    {

                        xpath = "//tr[contains(.,'" + fileName + "')]//span[@ng-bind='dataItem.requestStatus']";
                    }
                }

                if (ConfigFile.EnvType.Equals("Main"))
                {
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        xpath = "//td[contains(.,'" + fileName + "')]//following-sibling::td[@aria-colindex='3']";
                    }
                    else
                    {
                        xpath = "//tr[contains(.,'" + fileName + "')]//td/span[@ng-bind='dataItem.requestStatus']";
                    }
                }

                try
                {
                    actualstatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                }
                catch
                {

                }
                int ReturnStatus = StatusValidation(actualstatus);
                fw.ConsoleReport(" Processing File Name -->" + fileName);
                fw.ConsoleReport(" Looking for Success Status for File " + fileName);
                while (ReturnStatus != 0)
                {

                    fw.ExecuteJavascript(Browser.Wd.FindElement(SearchBtn));
                    tmsWait.Hard(8); // We put this wait intentionally as File processing is taking time for ESI, you can remove it when performance is improved

                    UIMODUtilFunctions.clickOnWebElementUsingLocators(importPlus);
                    tmsWait.Hard(10); // We put this wait intentionally as File processing is taking time for ESI
                    actualStatus = Browser.Wd.FindElement(By.XPath(xpath)).Text.ToString();
                    fw.ConsoleReport(" Current File Processing status --> " + actualStatus);
                    ReturnStatus = StatusValidation(actualStatus);
                }

                By loc = By.XPath("//td[contains(.,'" + fileName + "')]/following-sibling::td[contains(.,'Failure')]/following-sibling::td[@aria-colindex='10']/p");

                string actualMsg=UIMODUtilFunctions.returnTextUsingLocators(loc);

               
                 Assert.IsTrue(actualMsg.Contains(errorMsg), " Both execution Status are not matching");
            }

            

            
        }

        [Then(@"Verify Imports page displayed warning message ""(.*)""")]
        public void ThenVerifyImportsPageDisplayedWarningMessage(string p0)
        {
            tmsWait.Hard(9);

            IWebElement warnMsg = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + p0 + "')]"));
            bool results = warnMsg.Displayed;

            Assert.IsTrue(results, " Expected Error message is not displayed");
        }

        [When(@"On Hold Reason page On Hold Reason text box is set to ""(.*)""")]
        public void WhenOnHoldReasonPageOnHoldReasonTextBoxIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[test-id='onHoldReasons-txt-addReason']"));
            ReUsableFunctions.enterValueOnWebElement(ele, value);
        }

        [When(@"Transaction page On Hold Transaction Status drop down value is set to ""(.*)""")]
        public void WhenTransactionPageOnHoldTransactionStatusDropDownValueIsSetTo(string item)
        {
            tmsWait.Hard(3);
            string missingItem = tmsCommon.GenerateData(item);
            By missItem = By.XPath("//div[@id='div_ApplicationDispositionOnHoldTransactionStatus']/span");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(missItem);
            tmsWait.Hard(2);
            UIMODUtilFunctions.selectTransDrpValue(missingItem);

        }

        [When(@"Transaction page On Hold Reason drop down value is set to ""(.*)""")]
        public void WhenTransactionPageOnHoldReasonDropDownValueIsSetTo(string item)
        {
            tmsWait.Hard(3);
            string missingItem = tmsCommon.GenerateData(item);
            By missItem = By.XPath("//div[@id='div_ApplicationDispositionOnHoldReason']/span");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(missItem);
            tmsWait.Hard(2);
            UIMODUtilFunctions.selectTransDrpValue(missingItem);
        }

        [Then(@"Delete ""(.*)"" from On Hold Reason section")]
        public void ThenDeleteFromOnHoldReasonSection(string p0)
        {
            string reason = tmsCommon.GenerateData(p0);
            IWebElement editele = Browser.Wd.FindElement(By.XPath("//div[@test-id='OnHoldReasons-grid-onHoldReasons']//td[contains(.,'" + reason + "')]/following-sibling::td/a[1]"));
            fw.ExecuteJavascript(editele);
            IWebElement editcheck = Browser.Wd.FindElement(By.XPath("//input[@data-bind='checked:active']"));
            fw.ExecuteJavascript(editcheck);
            IWebElement saveBtn = Browser.Wd.FindElement(By.XPath("//a/span[@class='k-i-check fa fa-floppy-o']"));
            fw.ExecuteJavascript(saveBtn);

            IWebElement deleteele = Browser.Wd.FindElement(By.XPath("//div[@test-id='OnHoldReasons-grid-onHoldReasons']//td[contains(.,'" + reason + "')]/following-sibling::td/a[2]"));
            fw.ExecuteJavascript(deleteele);
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnConfirmationYesDialog();

        }

        [Then(@"Edit ""(.*)"" from On Hold Reason section and Verify System dislayed message as ""(.*)""")]
        public void ThenEditFromOnHoldReasonSectionAndVerifySystemDislayedMessageAs(string p0, string msg)
        {

            string reason = tmsCommon.GenerateData(p0);
            IWebElement editele = Browser.Wd.FindElement(By.XPath("//div[@test-id='OnHoldReasons-grid-onHoldReasons']//td[contains(.,'" + reason + "')]/following-sibling::td/a[1]"));
            fw.ExecuteJavascript(editele);
            IWebElement editcheck = Browser.Wd.FindElement(By.XPath("//input[@data-bind='checked:active']"));
            fw.ExecuteJavascript(editcheck);
            IWebElement saveBtn = Browser.Wd.FindElement(By.XPath("//a/span[@class='k-i-check fa fa-floppy-o']"));
            fw.ExecuteJavascript(saveBtn);
            ReUsableFunctions.toasterMessageDisplay(msg);

        }


        [Then(@"Verify Deleted ""(.*)"" is not found on On Hold Reason section")]
        public void ThenVerifyDeletedIsNotFoundOnOnHoldReasonSection(string p0)
        {
            string reason = tmsCommon.GenerateData(p0);
            By loc = By.XPath("//div[@test-id='OnHoldReasons-grid-onHoldReasons']//td[contains(.,'" + reason + "')]");
            UIMODUtilFunctions.elementNotPresenceUsingLocators(loc);

        }


        [When(@"On Hold Reason page Save buton is Clicked")]
        public void WhenOnHoldReasonPageSaveButonIsClicked()
        {
            IWebElement save = Browser.Wd.FindElement(By.CssSelector("[test-id='OnHoldReasons-btn-save']"));
            ReUsableFunctions.clickOnWebElement(save);

        }

        [When(@"Imports Page ALM Test ID ""(.*)"" attached File ""(.*)"" imported with New File Name ""(.*)"" and Verify message as ""(.*)""")]
        public void WhenImportsPageALMTestIDAttachedFileImportedWithNewFileNameAndVerifyMessageAs(string p0, string p1, string p2, string p3)
        {
            ReUsableFunctions.deleteFilesFromTempFolder();

            string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);
            string expMsg = tmsCommon.GenerateData(p3);

            Boolean keepTrying = true;
            int maxAttempts = 11;
            int thisAttempt = 0;
            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            string controllerFileLocation = "c:\\temp\\";
            // We added this code for Jenkins run
            string SourceFileLocation = "C:\\SourceFile\\";
            Boolean didUpload = false;
            string source = SourceFileLocation + p1_gen;
            if (Directory.Exists(SourceFileLocation))
            {
                if (!File.Exists(controllerFileLocation))
                {
                    File.Copy(SourceFileLocation + p1_gen, controllerFileLocation + Path.GetFileName(source));
                }
            }

            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");
            if (File.Exists(controllerFileLocation + p1_gen))
            {
                //File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen, true);
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");

            }
            else
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
            if (didUpload)
            {

                string FileName = "C:\\Temp\\" + p1_gen;


                string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen);
                //Move method moves an existing file to a new location with the same or a different file name, move delete original file
                File.Move(@FileName, @newFileName);
                FileName = newFileName;
                EAM.LoadEAFFile.SelectFiles.SendKeys(FileName);
                EAM.LoadEAFFile.Upload.Click();
                tmsWait.Hard(5);
                //string actualMsg = Browser.Wd.FindElement(By.XPath("//div[@class='k-notification-content']")).Text;


                string actualMsg = Browser.Wd.FindElement(By.XPath("//label[@test-id='imports-lbl-errormessage']//span")).Text;
            

                fw.ConsoleReport(actualMsg);
              
                //Assert.AreEqual(expMsg, actualMsg, " Both are not matching");

            }

            try
            {
                System.IO.DirectoryInfo di = new DirectoryInfo("c:\\Temp\\");

                foreach (FileInfo file in di.GetFiles())
                {
                    file.Delete();
                }
                foreach (DirectoryInfo dir in di.GetDirectories())
                {
                    dir.Delete(true);
                }
            }
            catch
            {

            }

        }


        [When(@"Imports Page ALM Test ID ""(.*)"" attached File ""(.*)"" imported with New File Name ""(.*)"" in EAM")]
        public void WhenImportsPageALMTestIDAttachedFileImportedWithNewFileNameInEAM(string p0, string p1, string p2)
        {
            
            string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);

            Boolean keepTrying = true;

            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            string tempFolder = "c:\\temp\\";
            // We added this code for Jenkins run
            // Do not comment below code as it will be used for Smoke test suite
            string SourceFileLocation = "C:\\SourceFile\\";
            Boolean didUpload = false;
            string source = SourceFileLocation + p1_gen;
            bool fileFoundOnTemp = false;
            bool fileDownloadOnALM = false;
            if (Directory.Exists(SourceFileLocation))
            {
                if (!File.Exists(controllerFileLocation))
                {
                    File.Copy(SourceFileLocation + p1_gen, tempFolder + p1_gen);
                    fileFoundOnTemp = true;
                    fileDownloadOnALM = true;
                    didUpload = true;
                }
            }

            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");

            if (!fileDownloadOnALM)
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
            if (didUpload)
            {
                while (keepTrying)
                {
                    string FileName = "C:\\Temp\\" + p1_gen;


                    string newFileName = "C:\\Temp\\tmsAlm\\" + tmsCommon.GenerateData(p2_gen);
                    //Move method moves an existing file to a new location with the same or a different file name, move delete original file
                    File.Move(@FileName, @newFileName);
                    FileName = newFileName;
                    EAM.LoadEAFFile.SelectFiles.SendKeys(FileName);

                  
                    tmsWait.Hard(5);
                    fw.ConsoleReport(" Verifying Application is throwing any error message like Duplicate file or file format issue etc after uploading the File  ");
                    

                    break; // Exit from while loop
                }

            }

            try
            {
                System.IO.DirectoryInfo di = new DirectoryInfo("c:\\Temp\\");

                foreach (FileInfo file in di.GetFiles())
                {
                    file.Delete();
                }

            }
            catch
            {

            }
        }

        [Then(@"Verify Flag for Audit page File Processing Summary File Name """"(.*)""Completed""")]
        public void ThenVerifyFlagForAuditPageFileProcessingSummaryFileNameCompleted(string p0)
        {



        }

        [DelimitedRecord("|")]
        [IgnoreEmptyLines()]
        [IgnoreFirst()]
        public class CSVFileContent
        {

            public string MemberID { get; set; }
            //Description, this attribute will handle the double quotes issue
            //[FieldQuoted('"', QuoteMode.OptionalForBoth)]
            public string HCC { get; set; }
            public string PaymentYear { get; set; }

            public string ProviderID { get; set; }
            public string ProviderName { get; set; }

        }
        [When(@"Create Client Identified Suspect File ""(.*)"" With MemberID ""(.*)"" and ""(.*)"" and ""(.*)"" and ""(.*)"" and ""(.*)"" on RAMX")]
        public void WhenCreateClientIdentifiedSuspectFileWithMemberIDAndAndAndAndOnRAMX(string p0, string Memid1, string Memid2, string HCCNo1, string HCCNo2, string PaymentY)
        {
            string FileName = tmsCommon.GenerateData(p0);
            string MemberId1 = tmsCommon.GenerateData(Memid1);
            string MemberId2 = tmsCommon.GenerateData(Memid2);
            string HCC1 = tmsCommon.GenerateData(HCCNo1);
            string HCC2 = tmsCommon.GenerateData(HCCNo2);
            string PaymentYear = tmsCommon.GenerateData(PaymentY);
            try
            {


                IList<CSVFileContent> studentList = new List<CSVFileContent>() {
                      new CSVFileContent(){ MemberID=MemberId1,HCC=HCC1,PaymentYear=PaymentYear,ProviderID=" ",ProviderName=" " },
new CSVFileContent(){ MemberID=MemberId2,HCC=HCC2,PaymentYear=PaymentYear,ProviderID=" ",ProviderName=" "},
            };
                //filehelper object
                FileHelperEngine engine = new FileHelperEngine(typeof(CSVFileContent));
                //csv object
                List<CSVFileContent> csv = new List<CSVFileContent>();
                //convert any datasource to csv based object

                int i = 0;
                foreach (var item in studentList)
                {
                    CSVFileContent temp = new CSVFileContent();

                    temp.MemberID = item.MemberID;
                    temp.HCC = item.HCC;
                    temp.PaymentYear = item.PaymentYear;
                    temp.ProviderID = item.ProviderID;
                    temp.ProviderName = item.ProviderName;

                    csv.Add(temp);

                }

                //give file a name and header text
                string filename = "C:\\SourceFile\\" + FileName;
                string filename1 = "C:\\temp\\" + FileName;
                engine.HeaderText = "Member ID|HCC|Payment Year|Provider ID|Provider Name";
                //save file locally

                engine.WriteFile(filename, csv);
                engine.WriteFile(filename1, csv);
            }
            catch (Exception ex)
            {

            }
        }

        [When(@"Create Client Identified Suspect File ""(.*)"" With MemberID ""(.*)""")]
        public void WhenCreateClientIdentifiedSuspectFileWithMemberID(string p0, string p1)
        {

            string FileName = tmsCommon.GenerateData(p0);
            string MemberId = tmsCommon.GenerateData(p1);
            try
            {


                IList<CSVFileContent> studentList = new List<CSVFileContent>() {
                      new CSVFileContent(){ MemberID=MemberId,HCC="4",PaymentYear="2018",ProviderID="1155484",ProviderName=" " },

            };
                //filehelper object
                FileHelperEngine engine = new FileHelperEngine(typeof(CSVFileContent));
                //csv object
                List<CSVFileContent> csv = new List<CSVFileContent>();
                //convert any datasource to csv based object
                CSVFileContent temp = new CSVFileContent();
                foreach (var item in studentList)
                {


                    temp.MemberID = item.MemberID;
                    temp.HCC = item.HCC;
                    temp.PaymentYear = item.PaymentYear;
                    temp.ProviderID = item.ProviderID;
                    temp.ProviderName = item.ProviderName;
                    csv.Add(temp);

                }
                //give file a name and header text
                string filename = "C:\\SourceFile\\" + FileName;
                engine.HeaderText = "Member ID|HCC|Payment Year|Provider ID|Provider Name";
                //save file locally
                engine.WriteFile(filename, csv);

            }
            catch (Exception ex)
            {

            }
        }

        [When(@"Create Client Identified Suspect File")]
        public void WhenCreateClientIdentifiedSuspectFile()
        {
            try
            {


                IList<CSVFileContent> studentList = new List<CSVFileContent>() {
                      new CSVFileContent(){ MemberID="MEM00002715",HCC="4",PaymentYear="2018",ProviderID="1155484",ProviderName=" "},
                     new CSVFileContent(){ MemberID="MEM00002715",HCC="4",PaymentYear="2018",ProviderID="1155484",ProviderName=" "},
            };
                //filehelper object
                FileHelperEngine engine = new FileHelperEngine(typeof(CSVFileContent));
                //csv object
                List<CSVFileContent> csv = new List<CSVFileContent>();
                //convert any datasource to csv based object
                CSVFileContent temp = new CSVFileContent();
                foreach (var item in studentList)
                {


                    temp.MemberID = item.MemberID;
                    temp.HCC = item.HCC;
                    temp.PaymentYear = item.PaymentYear;
                    temp.ProviderID = item.ProviderID;
                    temp.ProviderName = item.ProviderName;
                    csv.Add(temp);

                }
                //give file a name and header text
                string filename = "C:\\temp\\CIS_Suspects_20190228_040120.csv";
                engine.HeaderText = "Member ID|HCC|Payment Year|Provider ID|Provider Name";
                //save file locally
                engine.WriteFile(filename, csv);

            }
            catch (Exception ex)
            {

            }
        }
        [When(@"RAMX Application Imports Newly Created Client Identified Suspect File imported with New File Name ""(.*)""")]
        public void WhenRAMXApplicationImportsNewlyCreatedClientIdentifiedSuspectFileImportedWithNewFileName(string p0)
        {
            string p1_gen = tmsCommon.GenerateData(p0);



            string SourceFileLocation = @"C:\temp\";
            Boolean didUpload = false;
            string source = SourceFileLocation + p1_gen;
            //string source1 = source + ".csv";
            string source1 = source;
            string FileName = "";
            if (Directory.Exists(SourceFileLocation))
            
            {
                if (File.Exists(source))
                {
                    didUpload = true;
                   FileName = source;
                }
               
                else if(File.Exists(source1))
                        {
                    didUpload = true;
                    FileName = source1;
                }
            }


            if (didUpload)
            {
                //fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//input[@test-id='import-input-fileUpload']")));

                IWebElement selectButton = Browser.Wd.FindElement(By.CssSelector("[test-id='import-input-fileUpload'] input"));
                selectButton.SendKeys(FileName);

                By uploadBtn = By.XPath("//button[contains(.,'Upload')]");
                IWebElement uploadButton = Browser.Wd.FindElement(uploadBtn);
                fw.ExecuteJavascript(uploadButton);
                tmsWait.Hard(2);


               // RAM.ImportsPage.PIRSelectFileBtn.SendKeys(FileName);
              //  RAM.ImportsPage.UploadFilesBtn.Click();
                tmsWait.Hard(1);




                // By import = By.CssSelector("[test-id='import-btn-import']");
                // IWebElement importBtn = Browser.Wd.FindElement(import);
                // fw.ExecuteJavascript(importBtn);
                tmsWait.Hard(8);
                try {
                By fileProcess = By.LinkText("Job Processing Status page");
                fw.ExecuteJavascript(Browser.Wd.FindElement(fileProcess));
                }
                catch
                {
                    By fileProcess = By.LinkText("File Processing Status page");
                    fw.ExecuteJavascript(Browser.Wd.FindElement(fileProcess));
                }
                tmsWait.Hard(30);



            }
        }


        [When(@"RAMX Application Imports Page ALM Test ID ""(.*)"" attached File ""(.*)"" is renamed and imported with New File Name ""(.*)""")]
        public void WhenRAMXApplicationImportsPageALMTestIDAttachedFileIsRenamedAndImportedWithNewFileName(string p0, string p1, string p2)
        {
            string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);

            Boolean keepTrying = true;
            int maxAttempts = 11;
            int thisAttempt = 0;

            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            ReUsableFunctions.deleteFilesFromDownloadFolder();
            ReUsableFunctions.deleteFilesFromTempFolder();
            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            // We added this code for Jenkins run
            string SourceFileLocation = "C:\\SourceFile\\";
            string SourceFileLocationNew = "C:\\temp\\";
            Boolean didUpload = false;
            string source = SourceFileLocation + p1_gen;
            if (Directory.Exists(SourceFileLocation))
            {
                if (Directory.Exists(controllerFileLocation))
                {
                    if (File.Exists(SourceFileLocation + p1_gen))
                    {
                        if (!File.Exists(controllerFileLocation + p1_gen))
                        {
                            File.Copy(SourceFileLocation + p1_gen, controllerFileLocation + Path.GetFileName(source));
                            didUpload = true;
                        }
                    }
                }
            }

            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");
            if (Directory.Exists(controllerFileLocation))
            {
                if (File.Exists(controllerFileLocation + p1_gen))
                {
                    if (!File.Exists(SourceFileLocationNew + p1_gen))
                    {
                        File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen, true);
                        tmsWait.Hard(1);
                        didUpload = true;
                        Console.WriteLine("**Performed local copy because file did exist locally.");
                    }
                }
            }
            if (Directory.Exists(SourceFileLocation))
            {
                if (Directory.Exists(SourceFileLocationNew))
                {
                    if (File.Exists(SourceFileLocation + p1_gen))
                    {
                        if (!File.Exists(SourceFileLocationNew + p1_gen))
                        {
                            File.Copy(SourceFileLocation + p1_gen, "C:\\Temp\\" + p1_gen, true);
                            didUpload = true;
                        }
                    }
                }
            }
            else
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
            if (didUpload)
            {

                string FileName = "C:\\Temp\\" + p1_gen;
                string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen);
                //Move method moves an existing file to a new location with the same or a different file name, move delete original file
                File.Move(@FileName, @newFileName);
                FileName = newFileName;


                By upload = By.CssSelector("[test-id='import-input-fileUpload']");
                IWebElement uploadElement = Browser.Wd.FindElement(upload);
                uploadElement.SendKeys(FileName);
                tmsWait.Hard(2);

                By uploadBtn = By.XPath("//button[contains(.,'Upload')]");
                IWebElement uploadButton = Browser.Wd.FindElement(uploadBtn);
                fw.ExecuteJavascript(uploadButton);
                tmsWait.Hard(2);
                By import = By.CssSelector("[test-id='import-btn-import']");
                IWebElement importBtn = Browser.Wd.FindElement(import);
                fw.ExecuteJavascript(importBtn);
                tmsWait.Hard(2);
                By fileProcess = By.LinkText("File Processing Status page");
                fw.ExecuteJavascript(Browser.Wd.FindElement(fileProcess));
                tmsWait.Hard(30);



            }
        }


        [When(@"RAM Application Flag for Audit Page ALM Test ID ""(.*)"" attached File ""(.*)"" is renamed and imported with New File Name ""(.*)"" in EAM")]
        [When(@"RAMX Application Flag for Audit Page ALM Test ID ""(.*)"" attached File ""(.*)"" is renamed and imported with New File Name ""(.*)"" in EAM")]
        [When(@"RAMX Application Flag for Audit Page ALM Test ID ""(.*)"" attached File ""(.*)"" is renamed and imported with New File Name ""(.*)"" in RAMX")]
        public void WhenRAMApplicationFlagForAuditPageALMTestIDAttachedFileIsRenamedAndImportedWithNewFileNameInEAM(string p0, string p1, string p2)
        {
            string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);

            Boolean keepTrying = true;
            int maxAttempts = 11;
            int thisAttempt = 0;
            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            // We added this code for Jenkins run
            string SourceFileLocation = "C:\\SourceFile\\";
            string SourceFileLocationnew = "C:\\Temp\\";
            Boolean didUpload = false;
            string source = SourceFileLocation + p1_gen;
            if (Directory.Exists(SourceFileLocation))
            {
                if(File.Exists(SourceFileLocation + p1_gen))
                { 
                if (!File.Exists(controllerFileLocation+ p1_gen))
                {
                   
                        File.Copy(SourceFileLocation + p1_gen, controllerFileLocation + Path.GetFileName(source));
                    
                    }
                }
            }

            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");
            if (File.Exists(controllerFileLocation + p1_gen))
            {
                if (!File.Exists(SourceFileLocationnew + p1_gen)) {
                File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen, true);
                }
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");

            }
            else
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
            if (didUpload)
            {
                string FileName = "C:\\Temp\\" + p1_gen;
                string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen);
                //Move method moves an existing file to a new location with the same or a different file name, move delete original file
                File.Move(@FileName, @newFileName);
                FileName = newFileName;
                By upload = By.CssSelector("[test-id='flagForAuditReview-upload-fileUpload'] input");
                IWebElement uploadElement = Browser.Wd.FindElement(upload);
                uploadElement.SendKeys(FileName);
            }
        }

        [When(@"RAMX Application Flag for Audit Page csv file is imported with New File Name ""(.*)""")]
        public void WhenRAMXApplicationFlagForAuditPageCsvFileIsImportedWithNewFileName(string p0)
        {
            IWebElement refresh = Browser.Wd.FindElement(By.CssSelector("[test-id='flagForAuditReview-btn-btnRefresh']"));
            fw.ExecuteJavascript(refresh);
            tmsWait.Hard(5);
            string fileName = tmsCommon.GenerateData(p0);
            string FileName = "C:\\Temp\\" + fileName;
            // string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen);
            By upload = By.CssSelector("[test-id='flagForAuditReview-fileUpload']");
            IWebElement uploadElement = Browser.Wd.FindElement(upload);
            uploadElement.SendKeys(FileName);
        }

        [Then(@"on RAMX Administration Flag for Audit page ALM Test ID ""(.*)"" attached File ""(.*)"" is renamed and imported with New File Name ""(.*)""")]
        public void ThenOnRAMXAdministrationFlagForAuditPageALMTestIDAttachedFileIsRenamedAndImportedWithNewFileName(string p0, string p1, string p2)
        {
            Console.Write("Testing new method");
            string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);

            Boolean keepTrying = true;
            int maxAttempts = 11;
            int thisAttempt = 0;
            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            // We added this code for Jenkins run
            string SourceFileLocation = "C:\\SourceFile\\";
            Boolean didUpload = false;
            string source = SourceFileLocation + p1_gen;
            if (Directory.Exists(SourceFileLocation))
            {
                if (!File.Exists(controllerFileLocation))
                {
                    File.Copy(SourceFileLocation + p1_gen, controllerFileLocation + Path.GetFileName(source));
                }
            }

            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");
            if (File.Exists(controllerFileLocation + p1_gen))
            {
                File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen, true);
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");

            }
            else
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
            if (didUpload)
            {

                string FileName = "C:\\Temp\\" + p1_gen;
                string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen);
                //Move method moves an existing file to a new location with the same or a different file name, move delete original file
                File.Move(@FileName, @newFileName);
                FileName = newFileName;
                By upload = By.CssSelector("[test-id='flagForAuditReview-fileUpload']");
                IWebElement uploadElement = Browser.Wd.FindElement(upload);
                uploadElement.SendKeys(FileName);
          
            }
        }
        [Then(@"Verify Flag for Audit page displayed Warning message as ""(.*)""")]
        public void ThenVerifyFlagForAuditPageDisplayedWarningMessageAs(string p0)
        {
            Console.Write("Testing new method");
        }
        [Then(@"on RAMX Administration Flag for Audit page ALM Test ID ""(.*)"" attached File ""(.*)"" is renamed and imported with New File Name ""(.*)"" and verify correct message ""(.*)"" is displayed")]
        public void ThenOnRAMXAdministrationFlagForAuditPageALMTestIDAttachedFileIsRenamedAndImportedWithNewFileNameAndVerifyCorrectMessageIsDisplayed(string p0, string p1, string p2, string expMessage)
        {
            Console.Write("Testing new method");
            string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);

            Boolean keepTrying = true;
            int maxAttempts = 11;
            int thisAttempt = 0;
            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            // We added this code for Jenkins run
            string SourceFileLocation = "C:\\SourceFile\\";
            string SourceFileLocationnew = "C:\\temp\\";
            Boolean didUpload = false;
            string source = SourceFileLocation + p1_gen;
            if (Directory.Exists(SourceFileLocation))
            { if(File.Exists(SourceFileLocation + p1_gen)) { 
                if (!File.Exists(controllerFileLocation + Path.GetFileName(source)))
                {
                    File.Copy(SourceFileLocation + p1_gen, controllerFileLocation + Path.GetFileName(source));
                }
                }
            }

            //Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]"); 

            else if (File.Exists(controllerFileLocation + p1_gen))
            {
                if (!File.Exists(SourceFileLocationnew + p1_gen))
                { 
                File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen, true);
                }
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");

            }
            else
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
            if (didUpload)
            {

                string FileName = "C:\\Temp\\" + p1_gen;
                string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen);
                //Move method moves an existing file to a new location with the same or a different file name, move delete original file
                File.Move(@FileName, @newFileName);
                FileName = newFileName;
                //flagForAuditReview - fileUpload
                By upload = By.CssSelector("[test-id='flagForAuditReview-upload-fileUpload'] input");
                IWebElement uploadElement = Browser.Wd.FindElement(upload);
                uploadElement.SendKeys(FileName);
                string actualMessage = Browser.Wd.FindElement(By.XPath("//div[@class='k-notification-content']")).Text;
                Assert.AreEqual(expMessage, actualMessage, "Expected Toaster message is not displayed");
            }
        }



        [Then(@"Verify Crosswalk MBI Update page displayed Processed Cross walk file ""(.*)"" status as ""(.*)""")]
        public void ThenVerifyCrosswalkMBIUpdatePageDisplayedProcessedCrossWalkFileStatusAs(string p0, string status)
        {
            string file = tmsCommon.GenerateData(p0);
            By processedFile = By.XPath("//div[@test-id='crosswalkFile-grid']//table//td[contains(.,'" + file + "')]/following-sibling::td/span[@class='SuccessFulFinishIcon'][contains(.,'" + status + "')]");
            IWebElement uploadElement = Browser.Wd.FindElement(processedFile);

            Assert.IsTrue(uploadElement.Displayed, file + " is not displayed");
        }

        [When(@"Cross Walk MBI Update Page ALM Test ID ""(.*)"" attached File ""(.*)"" is renamed and imported with New File Name ""(.*)"" in EAM")]
        public void WhenCrossWalkMBIUpdatePageALMTestIDAttachedFileIsRenamedAndImportedWithNewFileNameInEAM(string p0, string p1, string p2)
        {

            string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);

            Boolean keepTrying = true;

            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            // We added this code for Jenkins run
            string SourceFileLocation = "C:\\SourceFile\\";
            Boolean didUpload = false;
            string source = SourceFileLocation + p1_gen;
            if (Directory.Exists(SourceFileLocation))
            {
                if (!File.Exists(controllerFileLocation))
                {
                    File.Copy(SourceFileLocation + p1_gen, controllerFileLocation + Path.GetFileName(source));
                }
            }

            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");
            if (File.Exists(controllerFileLocation + p1_gen))
            {
                File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen, true);
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");

            }
            else
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
            if (didUpload)
            {
                while (keepTrying)
                {
                    string FileName = "C:\\Temp\\" + p1_gen;


                    string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen);
                    //Move method moves an existing file to a new location with the same or a different file name, move delete original file
                    File.Move(@FileName, @newFileName);
                    FileName = newFileName;

                    By upload = By.Id("mbifileUpload");
                    Browser.Wd.FindElement(upload).SendKeys(FileName);
                    tmsWait.Hard(1);
                    By uploadBtn = By.Id("btnUploadFiles");
                    ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(uploadBtn));
                    tmsWait.Hard(5);
                    By confDialog = By.CssSelector("[test-id='confirmationDialog-btn-Yes']");
                    ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(confDialog));
                    //Browser.ClosePopUps(true);
                    tmsWait.Hard(5);
                    Browser.Wd.Navigate().Refresh();
                    tmsWait.Hard(12);
                    break; // Exit from while loop
                }

            }

        }

        [When(@"Rules Mapping Page Upload Rules section ALM Test ID ""(.*)"" attached File ""(.*)"" is renamed and Uploaded with New File Name ""(.*)"" in EAM")]
        public void WhenRulesMappingPageUploadRulesSectionALMTestIDAttachedFileIsRenamedAndUploadedWithNewFileNameInEAM(string p0, string p1, string p2)
        {

            string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);
            try
            {
                ReUsableFunctions.deleteFilesFromDownloadFolder();
                ReUsableFunctions.deleteFilesFromTempFolder();
            }
            catch
            {
                fw.ConsoleReport(" There is no Temp and Download File to delete");
            }
            // Create a Specific Folder
            string activeDir = "c:\\temp\\tmsAlm\\";
            if (!Directory.Exists(activeDir))  //  Verify Specific Folder Exists, if No then Create it.
            {
                Directory.CreateDirectory(activeDir);
            }
            Boolean keepTrying = true;
            int maxAttempts = 11;
            int thisAttempt = 0;
            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            // We added this code for Jenkins run
            // Do not comment below code as it will be used for Smoke test suite
            string SourceFileLocation = "C:\\SourceFile\\";
            Boolean didUpload = false;
            string source = SourceFileLocation + p1_gen;
            if (Directory.Exists(SourceFileLocation))
            {
                if (!File.Exists(controllerFileLocation))
                {
                    File.Copy(SourceFileLocation + p1_gen, controllerFileLocation + Path.GetFileName(source));
                }
            }

            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");
            if (File.Exists(controllerFileLocation + p1_gen))
            {
                File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen, true);
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");

            }
            else
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
            if (didUpload)
            {
                while (keepTrying)
                {
                    string FileName = "C:\\Temp\\" + p1_gen;


                    string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen);
                    //Move method moves an existing file to a new location with the same or a different file name, move delete original file
                    File.Move(@FileName, @newFileName);
                    FileName = newFileName;

                    IWebElement uploadInput = Browser.Wd.FindElement(By.CssSelector("div [name='files']"));
                    uploadInput.SendKeys(FileName);
                    tmsWait.Hard(3);
                    IWebElement uploadBtn = Browser.Wd.FindElement(By.XPath("//button[contains(.,'Upload')]"));
                    fw.ExecuteJavascript(uploadBtn);
                    tmsWait.Hard(3);
                    try
                    {
                        UIMODUtilFunctions.clickOnConfirmationYesDialog();
                    }
                    catch
                    {
                        fw.ConsoleReport(" There is no confirmation dialog"); // This dialog is not appearing from 5.7 R3 onwards.
                    }

                    break; // Exit from while loop
                }

            }

            try
            {
                System.IO.DirectoryInfo di = new DirectoryInfo("c:\\Temp\\");

                foreach (FileInfo file in di.GetFiles())
                {
                    file.Delete();
                }

            }
            catch
            {

            }


        }

        [When(@"Imports Page ALM Test ID ""(.*)"" attached File ""(.*)"" is Replaced with MBI ""(.*)"" and imported with New File Name ""(.*)"" in EAM")]
        public void WhenImportsPageALMTestIDAttachedFileIsReplacedWithMBIAndImportedWithNewFileNameInEAM(string p0, string p1, string p2, string p3)
        {

            ReUsableFunctions.deleteFilesFromDownloadFolder();
            ReUsableFunctions.deleteFilesFromTempFolder();
            // Create a Specific Folder
            string activeDir = "c:\\temp\\tmsAlm\\";
            if (!Directory.Exists(activeDir))  //  Verify Specific Folder Exists, if No then Create it.
            {
                Directory.CreateDirectory(activeDir);
            }

            string mbi = tmsCommon.GenerateData(p2);

            if (ConfigFile.EnvType.Equals("ESI") || ConfigFile.EnvType.Equals("Main"))
            {
                string po_gen = tmsCommon.GenerateData(p0);
                string p1_gen = tmsCommon.GenerateData(p1);
                string p2_gen = tmsCommon.GenerateData(p3);

                Boolean keepTrying = true;

                Console.WriteLine("**Before call to ALM file download**");
                //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
                //if they are there, we copy across.   Otherwise we reach into ALM to get them.
                string controllerFileLocation = "c:\\temp\\tmsAlm\\";
                // We added this code for Jenkins run
                // Do not comment below code as it will be used for Smoke test suite
                string SourceFileLocation = "C:\\SourceFile\\";
                string tempFolder = "c:\\temp\\";
                Boolean didUpload = false;
                string source = SourceFileLocation + p1_gen;
                bool fileDownloadOnALM = false;
                if (Directory.Exists(SourceFileLocation))
                {
                    if (!File.Exists(controllerFileLocation))
                    {
                        File.Copy(SourceFileLocation + p1_gen, tempFolder + p1_gen);
                        fileDownloadOnALM = true;
                        didUpload = true;
                    }
                }

                Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");

                if (!fileDownloadOnALM)
                {
                    Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                    didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
                }
              
                if (didUpload)
                {
                    while (keepTrying)
                    {
                        string FileName = "C:\\Temp\\" + p1_gen;
                        string newFileName = "C:\\Temp\\tmsAlm\\" + tmsCommon.GenerateData(p2_gen);
                        //Move method moves an existing file to a new location with the same or a different file name, move delete original file ( CUT Operation)


                        //string sourceTRR = "c:\\temp\\" + tmsCommon.GenerateData(p1);

                      //  List<string> sqllist = new List<string>();
                       // sqllist = db.OutputDBResultsToList(p0);

                        //string[] sqlarray = sqllist.ToArray();

                        string[] lines = System.IO.File.ReadAllLines(FileName);
              
                        string[] st1 = new string[lines.Length];

                        for (int i = 0; i < lines.Length; i++)
                        {

                            StringBuilder st = new StringBuilder(lines[i]);
                            if (i == 1)
                            {

                                st.Remove(10, 11);
                                //  Console.WriteLine($"{sqlarray[i]} - {sqlarray[i].Length}");
                                st.Insert(10, mbi);
                               
                            }
                            st1[i] = st.ToString();
                            // Console.WriteLine(st1[i]);


                        }

                        System.IO.File.WriteAllLines(newFileName, st1);

                       // File.Move(@FileName, @newFileName);
                      //  FileName = newFileName;
                        EAM.LoadEAFFile.SelectFiles.SendKeys(newFileName);
                        tmsWait.Hard(3);
                        EAM.LoadEAFFile.Upload.Click();
                        tmsWait.Hard(5);

                        fw.ConsoleReport(" Verifying Application is throwing any error message like Duplicate file or file format issue etc after uploading the File  ");
                        try
                        {
                            thisResponse = EAM.LoadEAFFile.UIModResponseMessage.Text;
                        }
                        catch
                        {
                            if (thisResponse == "The specified filename does not match for this file type. Please verify the file or modify the filename.")
                            {
                                keepTrying = false;
                                Console.WriteLine("File load failed with message [" + thisResponse + "]");
                                break; //  Exit from While loop
                            }
                        }

                        break; // Exit from while loop
                    }

                }

                try
                {
                    System.IO.DirectoryInfo di = new DirectoryInfo("c:\\Temp\\");

                    foreach (FileInfo file in di.GetFiles())
                    {
                        file.Delete();
                    }

                }
                catch
                {

                }

                tmsWait.Hard(40);  // we kep this wait for intentionally as EAF file processing is taking time, will remove later
            }
            else
            {

                string po_gen = tmsCommon.GenerateData(p0);
                string p1_gen = tmsCommon.GenerateData(p1);
                string p2_gen = tmsCommon.GenerateData(p3);

                Boolean keepTrying = true;

                Console.WriteLine("**Before call to ALM file download**");
                //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
                //if they are there, we copy across.   Otherwise we reach into ALM to get them.
                string controllerFileLocation = "c:\\temp\\tmsAlm\\";
                string tempFolder = "c:\\temp\\";
                // We added this code for Jenkins run
                // Do not comment below code as it will be used for Smoke test suite
                string SourceFileLocation = "C:\\SourceFile\\";
                Boolean didUpload = false;
                string source = SourceFileLocation + p1_gen;
                bool fileFoundOnTemp = false;
                bool fileDownloadOnALM = false;
                if (Directory.Exists(SourceFileLocation))
                {
                    if (!File.Exists(controllerFileLocation))
                    {
                        File.Copy(SourceFileLocation + p1_gen, tempFolder + p1_gen);
                        fileFoundOnTemp = true;
                        fileDownloadOnALM = true;
                        didUpload = true;
                    }
                }

                Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");

                if (!fileDownloadOnALM)
                {
                    Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                    didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
                }
                if (didUpload)
                {
                    while (keepTrying)
                    {
                        string FileName = "C:\\Temp\\" + p1_gen;


                        string newFileName = "C:\\Temp\\tmsAlm\\" + tmsCommon.GenerateData(p2_gen);
                        //Move method moves an existing file to a new location with the same or a different file name, move delete original file
                        File.Move(@FileName, @newFileName);
                        FileName = newFileName;
                        EAM.LoadEAFFile.SelectFiles.SendKeys(FileName);
                        tmsWait.Hard(3);
                        EAM.LoadEAFFile.Upload.Click();
                        tmsWait.Hard(5);
                        fw.ConsoleReport(" Verifying Application is throwing any error message like Duplicate file or file format issue etc after uploading the File  ");
                        try
                        {
                            thisResponse = EAM.LoadEAFFile.UIModResponseMessage.Text;
                        }
                        catch
                        {
                            if (thisResponse == "The specified filename does not match for this file type. Please verify the file or modify the filename.")
                            {
                                keepTrying = false;
                                Console.WriteLine("File load failed with message [" + thisResponse + "]");
                                break; //  Exit from While loop
                            }
                        }

                        break; // Exit from while loop
                    }

                }

                try
                {
                    System.IO.DirectoryInfo di = new DirectoryInfo("c:\\Temp\\");

                    foreach (FileInfo file in di.GetFiles())
                    {
                        file.Delete();
                    }

                }
                catch
                {

                }
            }
        }

        [When(@"Load DDPS File ""(.*)"" again")]
        public void WhenLoadDDPSFileAgain(string p0)
        {

            string newFileName = "C:\\Temp\\tmsAlm\\" + tmsCommon.GenerateData(p0);
            if (ConfigFile.BrowserType.Equals("edge") || ConfigFile.BrowserType.Equals("edgelegacy"))
            {

                string sharedFolderPath = ReUsableFunctions.returnTMSSharedInputFolder(ConfigFile.EAMdb);
                string destinationLoc = sharedFolderPath + tmsCommon.GenerateData(p0);
                File.Copy(newFileName, destinationLoc);

            }
            else
            {
                EAM.LoadEAFFile.SelectFiles.SendKeys(newFileName);
                fw.ConsoleReport(" Loading the same File again "+ newFileName);
                tmsWait.Hard(3);
                fw.ExecuteJavascript(EAM.LoadEAFFile.Upload);
                fw.ConsoleReport(" Clicked on Uploaded Button");
                tmsWait.Hard(5);
                

            }


        }

        [When(@"Load the same Provider File ""(.*)"" again")]
        public void WhenLoadTheSameProviderFileAgain(string p0)
        {
            string newFileName = "C:\\Temp\\tmsAlm\\" + tmsCommon.GenerateData(p0);
            if (ConfigFile.BrowserType.Equals("edge") || ConfigFile.BrowserType.Equals("edgelegacy"))
            {

                string sharedFolderPath = ReUsableFunctions.returnTMSSharedInputFolder(ConfigFile.EAMdb);
                string destinationLoc = sharedFolderPath + tmsCommon.GenerateData(p0);
                File.Copy(newFileName, destinationLoc);

            }
            else
            {
                EAM.LoadEAFFile.SelectFiles.SendKeys(newFileName);
                fw.ConsoleReport(" Loading the same File again " + newFileName);
                tmsWait.Hard(3);
                fw.ExecuteJavascript(EAM.LoadEAFFile.Upload);
                fw.ConsoleReport(" Clicked on Uploaded Button");
                tmsWait.Hard(5);


            }
        }



        [When(@"Imports Page ALM Test ID ""(.*)"" attached File ""(.*)"" is renamed and imported with New File Name ""(.*)"" in PDEM")]
        public void WhenImportsPageALMTestIDAttachedFileIsRenamedAndImportedWithNewFileNameInPDEM(string p0, string p1, string p2)
        {
            string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);

            Boolean keepTrying = true;

            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            string tempFolder = "c:\\temp\\";
            // We added this code for Jenkins run
            // Do not comment below code as it will be used for Smoke test suite
            string SourceFileLocation = "C:\\SourceFile\\";
            Boolean didUpload = false;
            string source = SourceFileLocation + p1_gen;
            bool fileFoundOnTemp = false;
            bool fileDownloadOnALM = false;
            if (Directory.Exists(SourceFileLocation))
            {
                if (!File.Exists(controllerFileLocation))
                {
                    fw.ConsoleReport(" Copy File From SourceFile to Temp Folder");
                    File.Copy(SourceFileLocation + p1_gen, tempFolder + p1_gen);
                    fileFoundOnTemp = true;
                    fileDownloadOnALM = true;
                    didUpload = true;
                    fw.ConsoleReport(" File is found on Source File Folder");
                }
            }

            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");

            if (!fileDownloadOnALM)
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
            if (didUpload)
            {
                while (keepTrying)
                {
                    string FileName = "C:\\Temp\\" + p1_gen;


                    string newFileName = "C:\\Temp\\tmsAlm\\" + tmsCommon.GenerateData(p2_gen);
                    //Move method moves an existing file to a new location with the same or a different file name, move delete original file
                    File.Move(@FileName, @newFileName);
                    FileName = newFileName;
                    fw.ConsoleReport(" Renaming File");

                    // This Implementation is only for Edge browser

                    if (ConfigFile.BrowserType.Equals("edge") || ConfigFile.BrowserType.Equals("edgelegacy"))
                    {

                        string sharedFolderPath = ReUsableFunctions.returnTMSSharedInputFolder(ConfigFile.EAMdb);
                        string destinationLoc = sharedFolderPath + tmsCommon.GenerateData(p2_gen);
                        File.Copy(FileName, destinationLoc);

                    }
                    else
                    {
                        EAM.LoadEAFFile.SelectFiles.SendKeys(FileName);
                        fw.ConsoleReport(" Sending File");
                        tmsWait.Hard(3);
                        fw.ExecuteJavascript(EAM.LoadEAFFile.Upload);
                        fw.ConsoleReport(" Clicked on Uploaded Button");
                        tmsWait.Hard(5);
                        fw.ConsoleReport(" Verifying Application is throwing any error message like Duplicate file or file format issue etc after uploading the File  ");
                        
                    }

                    break; // Exit from while loop
                }

            }

        }

        [When(@"Imports Page ALM Test ID ""(.*)"" Download attached File ""(.*)"" is renamed and Placed with New File Name ""(.*)"" in EAM Input Folder")]
        public void WhenImportsPageALMTestIDDownloadAttachedFileIsRenamedAndPlacedWithNewFileNameInEAMInputFolder(string p0, string p1, string p2)
        {

            ReUsableFunctions.deleteFilesFromDownloadFolder();
            ReUsableFunctions.deleteFilesFromTempFolder();
            // Create a Specific Folder
            string activeDir = "c:\\temp\\tmsAlm\\";
            if (!Directory.Exists(activeDir))  //  Verify Specific Folder Exists, if No then Create it.
            {
                Directory.CreateDirectory(activeDir);
            }

            if (ConfigFile.EnvType.Equals("ESI") || ConfigFile.EnvType.Equals("Main"))
            {
                string po_gen = tmsCommon.GenerateData(p0);
                string p1_gen = tmsCommon.GenerateData(p1);
                string p2_gen = tmsCommon.GenerateData(p2);

                Boolean keepTrying = true;

                Console.WriteLine("**Before call to ALM file download**");
                //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
                //if they are there, we copy across.   Otherwise we reach into ALM to get them.
                string controllerFileLocation = "c:\\temp\\tmsAlm\\";
                // We added this code for Jenkins run
                // Do not comment below code as it will be used for Smoke test suite
                string SourceFileLocation = "C:\\SourceFile\\";
                string tempFolder = "c:\\temp\\";
                Boolean didUpload = false;
                string source = SourceFileLocation + p1_gen;
                bool fileDownloadOnALM = false;
                if (Directory.Exists(SourceFileLocation))
                {
                    if (!File.Exists(controllerFileLocation))
                    {
                        File.Copy(SourceFileLocation + p1_gen, tempFolder + p1_gen);
                        fileDownloadOnALM = true;
                        didUpload = true;

                        fw.ConsoleReport(" File is found on Source File Folder");
                    }
                }

                Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");

                if (!fileDownloadOnALM)
                {
                    Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                    didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
                }
                if (didUpload)
                {
                    while (keepTrying)
                    {
                        string FileName = "C:\\Temp\\" + p1_gen;
                        string newFileName = "C:\\Temp\\tmsAlm\\" + tmsCommon.GenerateData(p2_gen);
                        //Move method moves an existing file to a new location with the same or a different file name, move delete original file ( CUT Operation)
                        File.Move(@FileName, @newFileName);
                        fw.ConsoleReport("Renaming File");
                        FileName = newFileName;
                       
                            fw.ConsoleReport("You are using Edge Browser");
                            string sharedFolderPath = ReUsableFunctions.returnTMSSharedInputFolder(ConfigFile.EAMdb);
                            string destinationLoc = sharedFolderPath + tmsCommon.GenerateData(p2_gen);
                            File.Copy(FileName, destinationLoc);

                       
                      
                        break; // Exit from while loop
                    }

                }

                try
                {
                    System.IO.DirectoryInfo di = new DirectoryInfo("c:\\Temp\\");

                    foreach (FileInfo file in di.GetFiles())
                    {
                        file.Delete();
                    }

                }
                catch
                {

                }

                tmsWait.Hard(40);  // we kep this wait for intentionally as EAF file processing is taking time, will remove later
            }
            else
            {

                string po_gen = tmsCommon.GenerateData(p0);
                string p1_gen = tmsCommon.GenerateData(p1);
                string p2_gen = tmsCommon.GenerateData(p2);

                Boolean keepTrying = true;

                Console.WriteLine("**Before call to ALM file download**");
                //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
                //if they are there, we copy across.   Otherwise we reach into ALM to get them.
                string controllerFileLocation = "c:\\temp\\tmsAlm\\";
                string tempFolder = "c:\\temp\\";
                // We added this code for Jenkins run
                // Do not comment below code as it will be used for Smoke test suite
                string SourceFileLocation = "C:\\SourceFile\\";
                Boolean didUpload = false;
                string source = SourceFileLocation + p1_gen;
                bool fileFoundOnTemp = false;
                bool fileDownloadOnALM = false;
                if (Directory.Exists(SourceFileLocation))
                {
                    if (!File.Exists(controllerFileLocation))
                    {
                        fw.ConsoleReport(" Copy File From SourceFile to Temp Folder");
                        File.Copy(SourceFileLocation + p1_gen, tempFolder + p1_gen);
                        fileFoundOnTemp = true;
                        fileDownloadOnALM = true;
                        didUpload = true;
                        fw.ConsoleReport(" File is found on Source File Folder");
                    }
                }

                Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");

                if (!fileDownloadOnALM)
                {
                    Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                    didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
                }
                if (didUpload)
                {
                    while (keepTrying)
                    {
                        string FileName = "C:\\Temp\\" + p1_gen;


                        string newFileName = "C:\\Temp\\tmsAlm\\" + tmsCommon.GenerateData(p2_gen);
                        //Move method moves an existing file to a new location with the same or a different file name, move delete original file
                        File.Move(@FileName, @newFileName);
                        FileName = newFileName;
                        fw.ConsoleReport(" Renaming File");

                        // This Implementation is only for Edge browser

                        if (ConfigFile.BrowserType.Equals("edge") || ConfigFile.BrowserType.Equals("edgelegacy"))
                        {

                            string sharedFolderPath = ReUsableFunctions.returnTMSSharedInputFolder(ConfigFile.EAMdb);
                            string destinationLoc = sharedFolderPath + tmsCommon.GenerateData(p2_gen);
                            File.Copy(FileName, destinationLoc);

                        }
                        else
                        {
                            EAM.LoadEAFFile.SelectFiles.SendKeys(FileName);
                            fw.ConsoleReport(" Sending File");
                            tmsWait.Hard(3);
                            fw.ExecuteJavascript(EAM.LoadEAFFile.Upload);
                            fw.ConsoleReport(" Clicked on Uploaded Button");
                            tmsWait.Hard(5);
                          
                        }

                        break; // Exit from while loop
                    }

                }

                try
                {
                    System.IO.DirectoryInfo di = new DirectoryInfo("c:\\Temp\\");

                    foreach (FileInfo file in di.GetFiles())
                    {
                        file.Delete();
                    }

                }
                catch
                {

                }
            }
        }


        //Gurdeep Arora
        [When(@"on Imports Page ALM Test ID ""(.*)"" attached File ""(.*)"" is updated with value ""(.*)"" and imported with New File Name ""(.*)"" in EAM")]
        public void WhenOnImportsPageALMTestIDAttachedFileIsUpdatedWithValueAndImportedWithNewFileNameInEAM(string p0, string p1, string p2, string p3)
        {
            {
                ReUsableFunctions.deleteFilesFromDownloadFolder();
                ReUsableFunctions.deleteFilesFromTempFolder();
                // Create a Specific Folder
                string activeDir = "c:\\temp\\tmsAlm\\";
                if (!Directory.Exists(activeDir))  //  Verify Specific Folder Exists, if No then Create it.
                {
                    Directory.CreateDirectory(activeDir);
                }

                if (ConfigFile.EnvType.Equals("ESI") || ConfigFile.EnvType.Equals("Main"))
                {
                    string po_gen = tmsCommon.GenerateData(p0);
                    string p1_gen = tmsCommon.GenerateData(p1);
                    string valueToUpdate = tmsCommon.GenerateData(p2);
                    string p3_gen = tmsCommon.GenerateData(p3);

                    Boolean keepTrying = true;

                    Console.WriteLine("**Before call to ALM file download**");
                    //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
                    //if they are there, we copy across.   Otherwise we reach into ALM to get them.
                    string controllerFileLocation = "c:\\temp\\tmsAlm\\";
                    // We added this code for Jenkins run
                    // Do not comment below code as it will be used for Smoke test suite
                    string SourceFileLocation = "C:\\SourceFile\\";
                    string tempFolder = "c:\\temp\\";
                    Boolean didUpload = false;
                    string source = SourceFileLocation + p1_gen;
                    bool fileDownloadOnALM = false;
                    if (Directory.Exists(SourceFileLocation))
                    {
                        if (File.Exists(controllerFileLocation))
                        {
                            File.Copy(SourceFileLocation + p1_gen, tempFolder + p1_gen);
                            fileDownloadOnALM = true;
                            didUpload = true;

                            fw.ConsoleReport(" File is found on Source File Folder");
                        }
                    }

                    Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");

                    if (!fileDownloadOnALM)
                    {
                        Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                        didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
                    }
                    if (didUpload)
                    {
                        while (keepTrying)
                        {
                            string FileName = "C:\\Temp\\" + p1_gen;
                            string newFileName = "C:\\Temp\\tmsAlm\\" + tmsCommon.GenerateData(p3_gen);
                            //Move method moves an existing file to a new location with the same or a different file name, move delete original file ( CUT Operation)
                            File.Move(@FileName, @newFileName);
                            fw.ConsoleReport("Renaming File");
                            FileName = newFileName;
                            if (ConfigFile.BrowserType.Equals("edge"))
                            {
                                fw.ConsoleReport("You are using Edge Browser");
                                string sharedFolderPath = ReUsableFunctions.returnTMSSharedInputFolder(ConfigFile.EAMdb);
                                string destinationLoc = sharedFolderPath + tmsCommon.GenerateData(p3_gen);
                                File.Copy(FileName, destinationLoc);

                            }
                            else
                            {
                                string FileFullPath = newFileName;
                                StreamWriter sw = null;
                                StringBuilder st;
                                sw = new StreamWriter(FileFullPath, true);
                                sw.Close();
                                string[] lines = System.IO.File.ReadAllLines(FileFullPath);
                                string[] line1words = lines[1].Split(' ');
                                
                                string[] line2words = lines[2].Split(' ');
                                st = new StringBuilder(lines[1]);
                                foreach (string wrd in line1words)
                                    if (wrd.ToString().Contains("7C77C01CC01")) {
                                        st.Replace("7C77C01CC01", valueToUpdate);
                                    }

                                Console.Write(st.ToString());

                               

                                string[] st1 = new string[lines.Length];
                                st1[0] = lines[0].ToString();
                                st1[1] = st.ToString();
                                st1[2] = st.ToString();
                                System.IO.File.WriteAllLines(FileFullPath, st1);
                                sw.Close();
                                                            
                                
                                System.IO.File.WriteAllLines(FileFullPath, st1);
                                sw.Close();
                                fw.ConsoleReport("Sending File using Send Keys");
                                EAM.LoadEAFFile.SelectFiles.SendKeys(FileName);
                                fw.ConsoleReport("Click on Select File Button");
                                tmsWait.Hard(5); // Currently Application is taking much time to load
                                fw.ExecuteJavascript(EAM.LoadEAFFile.Upload);
                                fw.ConsoleReport("Uploaded File using Upload Button");

                                tmsWait.Hard(5);

                                fw.ConsoleReport(" Verifying Application is throwing any error message like Duplicate file or file format issue etc after uploading the File  ");
                                try
                                {
                                    thisResponse = EAM.LoadEAFFile.UIModResponseMessage.Text;
                                }
                                catch
                                {
                                    if (thisResponse == "The specified filename does not match for this file type. Please verify the file or modify the filename.")
                                    {
                                        keepTrying = false;
                                        Console.WriteLine("File load failed with message [" + thisResponse + "]");
                                        break; //  Exit from While loop
                                    }
                                }

                            }
                            break; // Exit from while loop
                        }

                    }

                    try
                    {
                        System.IO.DirectoryInfo di = new DirectoryInfo("c:\\Temp\\");

                        foreach (FileInfo file in di.GetFiles())
                        {
                            file.Delete();
                        }

                    }
                    catch
                    {

                    }

                    tmsWait.Hard(40);  // we kep this wait for intentionally as EAF file processing is taking time, will remove later
                }
                else
                {

                    string po_gen = tmsCommon.GenerateData(p0);
                    string p1_gen = tmsCommon.GenerateData(p1);
                    string valueToUpdate = tmsCommon.GenerateData(p2);
                    string p3_gen = tmsCommon.GenerateData(p3);

                    Boolean keepTrying = true;

                    Console.WriteLine("**Before call to ALM file download**");
                    //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
                    //if they are there, we copy across.   Otherwise we reach into ALM to get them.
                    string controllerFileLocation = "c:\\temp\\tmsAlm\\";
                    string tempFolder = "c:\\temp\\";
                    // We added this code for Jenkins run
                    // Do not comment below code as it will be used for Smoke test suite
                    string SourceFileLocation = "C:\\SourceFile\\";
                    Boolean didUpload = false;
                    string source = SourceFileLocation + p1_gen;
                    bool fileFoundOnTemp = false;
                    bool fileDownloadOnALM = false;
                    if (Directory.Exists(SourceFileLocation))
                    {
                        if (!File.Exists(controllerFileLocation))
                        {
                            fw.ConsoleReport(" Copy File From SourceFile to Temp Folder");
                            File.Copy(SourceFileLocation + p1_gen, tempFolder + p1_gen);
                            fileFoundOnTemp = true;
                            fileDownloadOnALM = true;
                            didUpload = true;
                            fw.ConsoleReport(" File is found on Source File Folder");
                        }
                    }

                    Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");

                    if (!fileDownloadOnALM)
                    {
                        Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                        didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
                    }
                    if (didUpload)
                    {
                        while (keepTrying)
                        {
                            string FileName = "C:\\Temp\\" + p1_gen;


                            string newFileName = "C:\\Temp\\tmsAlm\\" + tmsCommon.GenerateData(p3_gen);
                            //Move method moves an existing file to a new location with the same or a different file name, move delete original file
                            File.Move(@FileName, @newFileName);
                            FileName = newFileName;
                            fw.ConsoleReport(" Renaming File");

                            // This Implementation is only for Edge browser

                            if (ConfigFile.BrowserType.Equals("edge"))
                            {

                                string sharedFolderPath = ReUsableFunctions.returnTMSSharedInputFolder(ConfigFile.EAMdb);
                                string destinationLoc = sharedFolderPath + tmsCommon.GenerateData(p3_gen);
                                File.Copy(FileName, destinationLoc);

                            }
                            else
                            {
                                string FileFullPath = newFileName;
                                StreamWriter sw = null;
                                StringBuilder st;
                                sw = new StreamWriter(FileFullPath, true);
                                sw.Close();
                                string[] lines = System.IO.File.ReadAllLines(FileFullPath);
                                string[] line1words = lines[1].Split(' ');

                                string[] line2words = lines[2].Split(' ');
                                st = new StringBuilder(lines[1]);
                                foreach (string wrd in line1words)
                                    if (wrd.ToString().Contains("7C77C01CC01"))
                                    {
                                        st.Replace("7C77C01CC01", valueToUpdate);
                                    }

                                Console.Write(st.ToString());
                                
                                string[] st1 = new string[lines.Length];
                                st1[0] = lines[0].ToString();
                                st1[1] = st.ToString();
                                st1[2] = st.ToString();
                                System.IO.File.WriteAllLines(FileFullPath, st1);
                                sw.Close();


                                System.IO.File.WriteAllLines(FileFullPath, st1);
                                sw.Close();
                                EAM.LoadEAFFile.SelectFiles.SendKeys(FileName);
                                fw.ConsoleReport(" Sending File");
                                tmsWait.Hard(3);
                                fw.ExecuteJavascript(EAM.LoadEAFFile.Upload);
                                fw.ConsoleReport(" Clicked on Uploaded Button");
                                tmsWait.Hard(5);
                                fw.ConsoleReport(" Verifying Application is throwing any error message like Duplicate file or file format issue etc after uploading the File  ");
                                try
                                {
                                    thisResponse = EAM.LoadEAFFile.UIModResponseMessage.Text;
                                }
                                catch
                                {
                                    if (thisResponse == "The specified filename does not match for this file type. Please verify the file or modify the filename.")
                                    {
                                        keepTrying = false;
                                        Console.WriteLine("File load failed with message [" + thisResponse + "]");
                                        break; //  Exit from While loop
                                    }
                                }
                            }

                            break; // Exit from while loop
                        }

                    }

                    try
                    {
                        System.IO.DirectoryInfo di = new DirectoryInfo("c:\\Temp\\");

                        foreach (FileInfo file in di.GetFiles())
                        {
                            file.Delete();
                        }

                    }
                    catch
                    {

                    }
                }
            }
        }





        //Gurdeep Arora
        [When(@"on Imports Page ALM Test ID ""(.*)"" attached File ""(.*)"" is renamed and imported with New File Name ""(.*)"" in EAM")]
        public void WhenOnImportsPageALMTestIDAttachedFileIsRenamedAndImportedWithNewFileNameInEAM(string p0, string p1, string p2)
        {
            {
                ReUsableFunctions.deleteFilesFromDownloadFolder();
                ReUsableFunctions.deleteFilesFromTempFolder();
                // Create a Specific Folder
                string activeDir = "c:\\temp\\tmsAlm\\";
                if (!Directory.Exists(activeDir))  //  Verify Specific Folder Exists, if No then Create it.
                {
                    Directory.CreateDirectory(activeDir);
                }

                if (ConfigFile.EnvType.Equals("ESI") || ConfigFile.EnvType.Equals("Main"))
                {
                    string po_gen = tmsCommon.GenerateData(p0);
                    string p1_gen = tmsCommon.GenerateData(p1);
                    string p2_gen = tmsCommon.GenerateData(p2);

                    Boolean keepTrying = true;

                    Console.WriteLine("**Before call to ALM file download**");
                    //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
                    //if they are there, we copy across.   Otherwise we reach into ALM to get them.
                    string controllerFileLocation = "c:\\temp\\tmsAlm\\";
                    // We added this code for Jenkins run
                    // Do not comment below code as it will be used for Smoke test suite
                    string SourceFileLocation = "C:\\SourceFile\\";
                    string tempFolder = "c:\\temp\\";
                    Boolean didUpload = false;
                    string source = SourceFileLocation + p1_gen;
                    bool fileDownloadOnALM = false;
                    if (Directory.Exists(SourceFileLocation))
                    {
                        if (File.Exists(controllerFileLocation))
                        {
                            File.Copy(SourceFileLocation + p1_gen, tempFolder + p1_gen);
                            fileDownloadOnALM = true;
                            didUpload = true;

                            fw.ConsoleReport(" File is found on Source File Folder");
                        }
                    }

                    Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");

                    if (!fileDownloadOnALM)
                    {
                        Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                        didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
                    }
                    if (didUpload)
                    {
                        while (keepTrying)
                        {
                            string FileName = "C:\\Temp\\" + p1_gen;
                            string newFileName = "C:\\Temp\\tmsAlm\\" + tmsCommon.GenerateData(p2_gen);
                            //Move method moves an existing file to a new location with the same or a different file name, move delete original file ( CUT Operation)
                            File.Move(@FileName, @newFileName);
                            fw.ConsoleReport("Renaming File");
                            FileName = newFileName;
                            if (ConfigFile.BrowserType.Equals("edge") || ConfigFile.BrowserType.Equals("edgelegacy"))
                            {
                                fw.ConsoleReport("You are using Edge Browser");
                                string sharedFolderPath = ReUsableFunctions.returnTMSSharedInputFolder(ConfigFile.EAMdb);
                                string destinationLoc = sharedFolderPath + tmsCommon.GenerateData(p2_gen);
                                File.Copy(FileName, destinationLoc);

                            }
                            else
                            {
                                fw.ConsoleReport("Sending File using Send Keys");
                                EAM.LoadEAFFile.SelectFiles.SendKeys(FileName);
                                fw.ConsoleReport("Click on Select File Button");
                                tmsWait.Hard(5); // Currently Application is taking much time to load


                                fw.ExecuteJavascript(EAM.LoadEAFFile.Upload);

                                fw.ConsoleReport("Uploaded File using Upload Button");

                                tmsWait.Hard(5);

                                //fw.ConsoleReport(" Verifying Application is throwing any error message like Duplicate file or file format issue etc after uploading the File  ");
                                //try
                                //{
                                //    thisResponse = EAM.LoadEAFFile.UIModResponseMessage.Text;
                                //}
                                //catch
                                //{
                                //    if (thisResponse == "The specified filename does not match for this file type. Please verify the file or modify the filename.")
                                //    {
                                //        keepTrying = false;
                                //        Console.WriteLine("File load failed with message [" + thisResponse + "]");
                                //        break; //  Exit from While loop
                                //    }
                                //}

                            }
                            break; // Exit from while loop
                        }

                    }

                    try
                    {
                        System.IO.DirectoryInfo di = new DirectoryInfo("c:\\Temp\\");

                        foreach (FileInfo file in di.GetFiles())
                        {
                            file.Delete();
                        }

                    }
                    catch
                    {

                    }

                    tmsWait.Hard(40);  // we kep this wait for intentionally as EAF file processing is taking time, will remove later
                }
                else
                {

                    string po_gen = tmsCommon.GenerateData(p0);
                    string p1_gen = tmsCommon.GenerateData(p1);
                    string p2_gen = tmsCommon.GenerateData(p2);

                    Boolean keepTrying = true;

                    Console.WriteLine("**Before call to ALM file download**");
                    //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
                    //if they are there, we copy across.   Otherwise we reach into ALM to get them.
                    string controllerFileLocation = "c:\\temp\\tmsAlm\\";
                    string tempFolder = "c:\\temp\\";
                    // We added this code for Jenkins run
                    // Do not comment below code as it will be used for Smoke test suite
                    string SourceFileLocation = "C:\\SourceFile\\";
                    Boolean didUpload = false;
                    string source = SourceFileLocation + p1_gen;
                    bool fileFoundOnTemp = false;
                    bool fileDownloadOnALM = false;
                    if (Directory.Exists(SourceFileLocation))
                    {
                        if (!File.Exists(controllerFileLocation))
                        {
                            fw.ConsoleReport(" Copy File From SourceFile to Temp Folder");
                            File.Copy(SourceFileLocation + p1_gen, tempFolder + p1_gen);
                            fileFoundOnTemp = true;
                            fileDownloadOnALM = true;
                            didUpload = true;
                            fw.ConsoleReport(" File is found on Source File Folder");
                        }
                    }

                    Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");

                    if (!fileDownloadOnALM)
                    {
                        Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                        didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
                    }
                    if (didUpload)
                    {
                        while (keepTrying)
                        {
                            string FileName = "C:\\Temp\\" + p1_gen;


                            string newFileName = "C:\\Temp\\tmsAlm\\" + tmsCommon.GenerateData(p2_gen);
                            //Move method moves an existing file to a new location with the same or a different file name, move delete original file
                            File.Move(@FileName, @newFileName);
                            FileName = newFileName;
                            fw.ConsoleReport(" Renaming File");

                            // This Implementation is only for Edge browser

                            if (ConfigFile.BrowserType.Equals("edge") || ConfigFile.BrowserType.Equals("edgelegacy"))
                            {

                                string sharedFolderPath = ReUsableFunctions.returnTMSSharedInputFolder(ConfigFile.EAMdb);
                                string destinationLoc = sharedFolderPath + tmsCommon.GenerateData(p2_gen);
                                File.Copy(FileName, destinationLoc);

                            }
                            else
                            {
                                EAM.LoadEAFFile.SelectFiles.SendKeys(FileName);
                                fw.ConsoleReport(" Sending File");
                                tmsWait.Hard(3);
                                fw.ExecuteJavascript(EAM.LoadEAFFile.Upload);
                                fw.ConsoleReport(" Clicked on Uploaded Button");
                                tmsWait.Hard(5);
                                //fw.ConsoleReport(" Verifying Application is throwing any error message like Duplicate file or file format issue etc after uploading the File  ");
                                //try
                                //{
                                //    thisResponse = EAM.LoadEAFFile.UIModResponseMessage.Text;
                                //}
                                //catch
                                //{
                                //    if (thisResponse == "The specified filename does not match for this file type. Please verify the file or modify the filename.")
                                //    {
                                //        keepTrying = false;
                                //        Console.WriteLine("File load failed with message [" + thisResponse + "]");
                                //        break; //  Exit from While loop
                                //    }
                                //}
                            }

                            break; // Exit from while loop
                        }

                    }

                    try
                    {
                        System.IO.DirectoryInfo di = new DirectoryInfo("c:\\Temp\\");

                        foreach (FileInfo file in di.GetFiles())
                        {
                            file.Delete();
                        }

                    }
                    catch
                    {

                    }
                }
            }

        }

        [When(@"Imports Page ALM Test ID ""(.*)"" attached File ""(.*)"" is renamed and imported with New File Name ""(.*)"" in RAM")]
        public void WhenImportsPageALMTestIDAttachedFileIsRenamedAndImportedWithNewFileNameInRAM(string p0, string p1, string p2)
        {
            ReUsableFunctions.deleteFilesFromDownloadFolder();
            ReUsableFunctions.deleteFilesFromTempFolder();
            // Create a Specific Folder
            string activeDir = "c:\\temp\\tmsAlm\\";
            if (!Directory.Exists(activeDir))  //  Verify Specific Folder Exists, if No then Create it.
            {
                Directory.CreateDirectory(activeDir);
            }

            if (ConfigFile.EnvType.Equals("ESI") || ConfigFile.EnvType.Equals("Main"))
            {
                string po_gen = tmsCommon.GenerateData(p0);
                string p1_gen = tmsCommon.GenerateData(p1);
                string p2_gen = tmsCommon.GenerateData(p2);

                Boolean keepTrying = true;

                Console.WriteLine("**Before call to ALM file download**");
                //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
                //if they are there, we copy across.   Otherwise we reach into ALM to get them.
                string controllerFileLocation = "c:\\temp\\tmsAlm\\";
                // We added this code for Jenkins run
                // Do not comment below code as it will be used for Smoke test suite
                string SourceFileLocation = "C:\\SourceFile\\";
                string tempFolder = "c:\\temp\\";
                Boolean didUpload = false;
                string source = SourceFileLocation + p1_gen;
                bool fileDownloadOnALM = false;
                if (Directory.Exists(SourceFileLocation))
                {
                    if (!File.Exists(controllerFileLocation))
                    {
                        File.Copy(SourceFileLocation + p1_gen, tempFolder + p1_gen);
                        fileDownloadOnALM = true;
                        didUpload = true;

                        fw.ConsoleReport(" File is found on Source File Folder");
                    }
                }

                Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");

                if (!fileDownloadOnALM)
                {
                    Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                    didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
                }
                if (didUpload)
                {
                    while (keepTrying)
                    {
                        string FileName = "C:\\Temp\\" + p1_gen;
                        string newFileName = "C:\\Temp\\tmsAlm\\" + tmsCommon.GenerateData(p2_gen);
                        //Move method moves an existing file to a new location with the same or a different file name, move delete original file ( CUT Operation)
                        File.Move(@FileName, @newFileName);
                        fw.ConsoleReport("Renaming File");
                        FileName = newFileName;
                        if (ConfigFile.BrowserType.Equals("edge") || ConfigFile.BrowserType.Equals("edgelegacy"))
                        {
                            fw.ConsoleReport("You are using Edge Browser");
                            string sharedFolderPath = ReUsableFunctions.returnTMSSharedInputFolder(ConfigFile.EAMdb);
                            string destinationLoc = sharedFolderPath + tmsCommon.GenerateData(p2_gen);
                            File.Copy(FileName, destinationLoc);

                        }
                        else
                        {
                            fw.ConsoleReport("Sending File using Send Keys");
                            EAM.LoadEAFFile.SelectFiles.SendKeys(FileName);
                            fw.ConsoleReport("Click on Select File Button");
                            tmsWait.Hard(5); // Currently Application is taking much time to load


                            fw.ExecuteJavascript(EAM.LoadEAFFile.Upload);

                            fw.ConsoleReport("Uploaded File using Upload Button");

                            tmsWait.Hard(5);

                            //fw.ConsoleReport(" Verifying Application is throwing any error message like Duplicate file or file format issue etc after uploading the File  ");
                            //try
                            //{
                            //    thisResponse = EAM.LoadEAFFile.UIModResponseMessage.Text;
                            //}
                            //catch
                            //{
                            //    if (thisResponse == "The specified filename does not match for this file type. Please verify the file or modify the filename.")
                            //    {
                            //        keepTrying = false;
                            //        Console.WriteLine("File load failed with message [" + thisResponse + "]");
                            //        break; //  Exit from While loop
                            //    }
                            //}

                        }
                        break; // Exit from while loop
                    }

                }

                try
                {
                    System.IO.DirectoryInfo di = new DirectoryInfo("c:\\Temp\\");

                    foreach (FileInfo file in di.GetFiles())
                    {
                        file.Delete();
                    }

                }
                catch
                {

                }

                tmsWait.Hard(40);  // we kep this wait for intentionally as EAF file processing is taking time, will remove later
            }
            else
            {

                string po_gen = tmsCommon.GenerateData(p0);
                string p1_gen = tmsCommon.GenerateData(p1);
                string p2_gen = tmsCommon.GenerateData(p2);

                Boolean keepTrying = true;

                Console.WriteLine("**Before call to ALM file download**");
                //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
                //if they are there, we copy across.   Otherwise we reach into ALM to get them.
                string controllerFileLocation = "c:\\temp\\tmsAlm\\";
                string tempFolder = "c:\\temp\\";
                // We added this code for Jenkins run
                // Do not comment below code as it will be used for Smoke test suite
                string SourceFileLocation = "C:\\SourceFile\\";
                Boolean didUpload = false;
                string source = SourceFileLocation + p1_gen;
                bool fileFoundOnTemp = false;
                bool fileDownloadOnALM = false;
                if (Directory.Exists(SourceFileLocation))
                {
                    if (!File.Exists(controllerFileLocation))
                    {
                        fw.ConsoleReport(" Copy File From SourceFile to Temp Folder");
                        File.Copy(SourceFileLocation + p1_gen, tempFolder + p1_gen);
                        fileFoundOnTemp = true;
                        fileDownloadOnALM = true;
                        didUpload = true;
                        fw.ConsoleReport(" File is found on Source File Folder");
                    }
                }

                Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");

                if (!fileDownloadOnALM)
                {
                    Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                    didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
                }
                if (didUpload)
                {
                    while (keepTrying)
                    {
                        string FileName = "C:\\Temp\\" + p1_gen;


                        string newFileName = "C:\\Temp\\tmsAlm\\" + tmsCommon.GenerateData(p2_gen);
                        //Move method moves an existing file to a new location with the same or a different file name, move delete original file
                        File.Move(@FileName, @newFileName);
                        FileName = newFileName;
                        fw.ConsoleReport(" Renaming File");

                        // This Implementation is only for Edge browser

                        if (ConfigFile.BrowserType.Equals("edge") || ConfigFile.BrowserType.Equals("edgelegacy"))
                        {

                            string sharedFolderPath = ReUsableFunctions.returnTMSSharedInputFolder(ConfigFile.EAMdb);
                            string destinationLoc = sharedFolderPath + tmsCommon.GenerateData(p2_gen);
                            File.Copy(FileName, destinationLoc);

                        }
                        else
                        {
                            EAM.LoadEAFFile.SelectFiles.SendKeys(FileName);
                            fw.ConsoleReport(" Sending File");
                            tmsWait.Hard(3);
                            fw.ExecuteJavascript(EAM.LoadEAFFile.Upload);
                            fw.ConsoleReport(" Clicked on Uploaded Button");
                            tmsWait.Hard(5);
                            //fw.ConsoleReport(" Verifying Application is throwing any error message like Duplicate file or file format issue etc after uploading the File  ");
                            //try
                            //{
                            //    thisResponse = EAM.LoadEAFFile.UIModResponseMessage.Text;
                            //}
                            //catch
                            //{
                            //    if (thisResponse == "The specified filename does not match for this file type. Please verify the file or modify the filename.")
                            //    {
                            //        keepTrying = false;
                            //        Console.WriteLine("File load failed with message [" + thisResponse + "]");
                            //        break; //  Exit from While loop
                            //    }
                            //}
                        }

                        break; // Exit from while loop
                    }

                }

                try
                {
                    System.IO.DirectoryInfo di = new DirectoryInfo("c:\\Temp\\");

                    foreach (FileInfo file in di.GetFiles())
                    {
                        file.Delete();
                    }

                }
                catch
                {

                }
            }




        }


        [When(@"Imports Page ALM Test ID ""(.*)"" attached File ""(.*)"" is downloaded Updated TC renamed EAF File and imported with New File Name ""(.*)"" in EAM")]
        public void WhenImportsPageALMTestIDAttachedFileIsDownloadedUpdatedTCRenamedEAFFileAndImportedWithNewFileNameInEAM(string p0, string p1, string p2)
        {

            ReUsableFunctions.deleteFilesFromDownloadFolder();
            ReUsableFunctions.deleteFilesFromTempFolder();
            // Create a Specific Folder
            string activeDir = "c:\\temp\\tmsAlm\\";
            if (!Directory.Exists(activeDir))  //  Verify Specific Folder Exists, if No then Create it.
            {
                Directory.CreateDirectory(activeDir);
            }

            if (ConfigFile.EnvType.Equals("ESI") || ConfigFile.EnvType.Equals("Main"))
            {
                string po_gen = tmsCommon.GenerateData(p0);
                string p1_gen = tmsCommon.GenerateData(p1);
                string p2_gen = tmsCommon.GenerateData(p2);

                Boolean keepTrying = true;

                Console.WriteLine("**Before call to ALM file download**");
                //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
                //if they are there, we copy across.   Otherwise we reach into ALM to get them.
                string controllerFileLocation = "c:\\temp\\tmsAlm\\";
                // We added this code for Jenkins run
                // Do not comment below code as it will be used for Smoke test suite
                string SourceFileLocation = "C:\\SourceFile\\";
                string tempFolder = "c:\\temp\\";
                Boolean didUpload = false;
                string source = SourceFileLocation + p1_gen;
                bool fileDownloadOnALM = false;
                if (Directory.Exists(SourceFileLocation))
                {
                    if (!File.Exists(controllerFileLocation))
                    {
                        File.Copy(SourceFileLocation + p1_gen, tempFolder + p1_gen);
                        fileDownloadOnALM = true;
                        didUpload = true;

                        fw.ConsoleReport(" File is found on Source File Folder");
                    }
                }

                Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");

                if (!fileDownloadOnALM)
                {
                    Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                    didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
                }
                if (didUpload)
                {
                    while (keepTrying)
                    {


                        string sourceEAF = "c:\\temp\\" + tmsCommon.GenerateData(p1_gen);
                        string runTimeTCType = "00";

                        List<string> sqllist = new List<string>();
                        //sqllist = db.OutputDBResultsToList(p0);

                        //string[] sqlarray = sqllist.ToArray();
                       // string transID;
                       // transID = db.OutputDBResultsToList(p0)[0].ToString();
                        fw.ConsoleReport(" Trans Type which will be replaced in EAF File is " + runTimeTCType);
                        fw.ConsoleReport(" MBI which will be replaced in TRR File is " + runTimeTCType);


                        string[] lines = System.IO.File.ReadAllLines(sourceEAF);
                        string[] st1 = new string[lines.Length];

                        for (int i = 0; i < lines.Length; i++)
                        {
                            StringBuilder st = new StringBuilder(lines[i]);
                            if (i == 0)
                            {
                                fw.ConsoleReport(" Header ");
                            }
                            else
                            {
                               
                                //line.Split('\t')[74]
                                st.Replace(lines[i].Split('\t')[73], runTimeTCType);
                            }

                           
                            st1[i] = st.ToString();
                            Console.WriteLine(st1[i]);

                           
                        }

                        System.IO.File.WriteAllLines(sourceEAF, st1);




                        string FileName = "C:\\Temp\\" + p1_gen;
                        string newFileName = "C:\\Temp\\tmsAlm\\" + tmsCommon.GenerateData(p2_gen);
                        //Move method moves an existing file to a new location with the same or a different file name, move delete original file ( CUT Operation)
                        File.Move(@FileName, @newFileName);
                        fw.ConsoleReport("Renaming File");
                        FileName = newFileName;
                        if (ConfigFile.BrowserType.Equals("edge") || ConfigFile.BrowserType.Equals("edgelegacy"))
                        {
                            fw.ConsoleReport("You are using Edge Browser");
                            string sharedFolderPath = ReUsableFunctions.returnTMSSharedInputFolder(ConfigFile.EAMdb);
                            string destinationLoc = sharedFolderPath + tmsCommon.GenerateData(p2_gen);
                            File.Copy(FileName, destinationLoc);

                        }
                        else
                        {
                            fw.ConsoleReport("Sending File using Send Keys");
                            EAM.LoadEAFFile.SelectFiles.SendKeys(FileName);
                            fw.ConsoleReport("Click on Select File Button");
                            tmsWait.Hard(5); // Currently Application is taking much time to load


                            fw.ExecuteJavascript(EAM.LoadEAFFile.Upload);

                            fw.ConsoleReport("Uploaded File using Upload Button");

                            tmsWait.Hard(5);

                            //fw.ConsoleReport(" Verifying Application is throwing any error message like Duplicate file or file format issue etc after uploading the File  ");
                            //try
                            //{
                            //    thisResponse = EAM.LoadEAFFile.UIModResponseMessage.Text;
                            //}
                            //catch
                            //{
                            //    if (thisResponse == "The specified filename does not match for this file type. Please verify the file or modify the filename.")
                            //    {
                            //        keepTrying = false;
                            //        Console.WriteLine("File load failed with message [" + thisResponse + "]");
                            //        break; //  Exit from While loop
                            //    }
                            //}

                        }
                        break; // Exit from while loop
                    }

                }

                try
                {
                    System.IO.DirectoryInfo di = new DirectoryInfo("c:\\Temp\\");

                    foreach (FileInfo file in di.GetFiles())
                    {
                        file.Delete();
                    }

                }
                catch
                {

                }

                tmsWait.Hard(40);  // we kep this wait for intentionally as EAF file processing is taking time, will remove later
            }
            else
            {

                string po_gen = tmsCommon.GenerateData(p0);
                string p1_gen = tmsCommon.GenerateData(p1);
                string p2_gen = tmsCommon.GenerateData(p2);

                Boolean keepTrying = true;

                Console.WriteLine("**Before call to ALM file download**");
                //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
                //if they are there, we copy across.   Otherwise we reach into ALM to get them.
                string controllerFileLocation = "c:\\temp\\tmsAlm\\";
                string tempFolder = "c:\\temp\\";
                // We added this code for Jenkins run
                // Do not comment below code as it will be used for Smoke test suite
                string SourceFileLocation = "C:\\SourceFile\\";
                Boolean didUpload = false;

               string source = SourceFileLocation + p1_gen;
                bool fileFoundOnTemp = false;
                bool fileDownloadOnALM = false;
                if (Directory.Exists(SourceFileLocation))
                {
                    if (!File.Exists(controllerFileLocation))
                    {
                        fw.ConsoleReport(" Copy File From SourceFile to Temp Folder");
                        File.Copy(SourceFileLocation + p1_gen, tempFolder + p1_gen);
                        fileFoundOnTemp = true;
                        fileDownloadOnALM = true;
                        didUpload = true;
                        fw.ConsoleReport(" File is found on Source File Folder");
                    }
                }

                Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");

                if (!fileDownloadOnALM)
                {
                    Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                    didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
                }
                if (didUpload)
                {
                    while (keepTrying)
                    {
                        string FileName = "C:\\Temp\\" + p1_gen;


                        string newFileName = "C:\\Temp\\tmsAlm\\" + tmsCommon.GenerateData(p2_gen);
                        //Move method moves an existing file to a new location with the same or a different file name, move delete original file
                        File.Move(@FileName, @newFileName);
                        FileName = newFileName;
                        fw.ConsoleReport(" Renaming File");

                        // This Implementation is only for Edge browser

                        if (ConfigFile.BrowserType.Equals("edge") || ConfigFile.BrowserType.Equals("edgelegacy"))
                        {

                            string sharedFolderPath = ReUsableFunctions.returnTMSSharedInputFolder(ConfigFile.EAMdb);
                            string destinationLoc = sharedFolderPath + tmsCommon.GenerateData(p2_gen);
                            File.Copy(FileName, destinationLoc);

                        }
                        else
                        {
                            EAM.LoadEAFFile.SelectFiles.SendKeys(FileName);
                            fw.ConsoleReport(" Sending File");
                            tmsWait.Hard(3);
                            fw.ExecuteJavascript(EAM.LoadEAFFile.Upload);
                            fw.ConsoleReport(" Clicked on Uploaded Button");
                            tmsWait.Hard(5);
                            //fw.ConsoleReport(" Verifying Application is throwing any error message like Duplicate file or file format issue etc after uploading the File  ");
                            //try
                            //{
                            //    thisResponse = EAM.LoadEAFFile.UIModResponseMessage.Text;
                            //}
                            //catch
                            //{
                            //    if (thisResponse == "The specified filename does not match for this file type. Please verify the file or modify the filename.")
                            //    {
                            //        keepTrying = false;
                            //        Console.WriteLine("File load failed with message [" + thisResponse + "]");
                            //        break; //  Exit from While loop
                            //    }
                            //}
                        }

                        break; // Exit from while loop
                    }

                }

                try
                {
                    System.IO.DirectoryInfo di = new DirectoryInfo("c:\\Temp\\");

                    foreach (FileInfo file in di.GetFiles())
                    {
                        file.Delete();
                    }

                }
                catch
                {

                }
            }
        }



        [When(@"Imports Page ALM Test ID ""(.*)"" attached File ""(.*)"" is renamed and imported with New File Name ""(.*)"" in EAM")]
        public void WhenImportsPageALMTestIDAttachedFileIsRenamedAndImportedWithNewFileNameInEAM(string p0, string p1, string p2)
         {
            string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);

            string p2_gen = tmsCommon.GenerateData(p2);
            ReUsableFunctions.deleteFilesFromDownloadFolder();
            ReUsableFunctions.deleteFilesFromTempFolder();
            // Create a Specific Folder
            
            string activeDir = GlobalRef.tmsAlmFolder;
           
           
          //  string activeDir = "c:\\temp\\tmsAlm\\";
            if (!Directory.Exists(activeDir))  //  Verify Specific Folder Exists, if No then Create it.
            {
                Directory.CreateDirectory(activeDir);
            }

            if (ConfigFile.EnvType.Equals("ESI") || ConfigFile.EnvType.Equals("Main"))
            {
               
                

                Boolean keepTrying = true;

                Console.WriteLine("**Before call to ALM file download**");
                //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
                //if they are there, we copy across.   Otherwise we reach into ALM to get them.
                string controllerFileLocation = activeDir;
                // We added this code for Jenkins run
                // Do not comment below code as it will be used for Smoke test suite
                string SourceFileLocation = "C:\\SourceFile\\";
                string tempFolder = "c:\\temp\\";
                Boolean didUpload = false;
                string source = SourceFileLocation + p1_gen;                
                bool fileDownloadOnALM = false;
                if (Directory.Exists(SourceFileLocation))
                {
                    if (!File.Exists(controllerFileLocation))
                    {
                        File.Copy(SourceFileLocation + p1_gen, tempFolder + p1_gen);                      
                        fileDownloadOnALM = true;
                        didUpload = true;

                        fw.ConsoleReport(" File is found on Source File Folder");
                    }
                }

                Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");

                if (!fileDownloadOnALM)
                {
                    Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                    didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
                }
                if (didUpload)
                {
                    while (keepTrying)
                    {
                        string FileName = "C:\\Temp\\" + p1_gen;
                        string newFileName = activeDir + tmsCommon.GenerateData(p2_gen);
                        //Move method moves an existing file to a new location with the same or a different file name, move delete original file ( CUT Operation)
                      
                            File.Move(@FileName, @newFileName);
                    
                        fw.ConsoleReport("Renaming File");
                        FileName = newFileName;
                        if (ConfigFile.BrowserType.Equals("edge") || ConfigFile.BrowserType.Equals("edgelegacy") || ConfigFile.BrowserType.Equals("chromegrid"))
                        {
                            fw.ConsoleReport("You are using Edge Browser");
                            string sharedFolderPath = ReUsableFunctions.returnTMSSharedInputFolder(ConfigFile.EAMdb);
                            string destinationLoc = sharedFolderPath + tmsCommon.GenerateData(p2_gen);
                            File.Copy(FileName, destinationLoc);

                        }
                        else
                        {
                            fw.ConsoleReport("Sending File using Send Keys");
                            if (ConfigFile.tenantType.Equals("tmsx"))
                            {
                                By Drp = By.CssSelector("[test-id='import-input-fileUpload'] input");
                                Browser.Wd.FindElement(Drp).Clear();
                                Browser.Wd.FindElement(Drp).SendKeys(FileName);
                            }
                            else
                            {
                                EAM.LoadEAFFile.SelectFiles.SendKeys(FileName);
                            }

                               
                            fw.ConsoleReport("Click on Select File Button");
                            tmsWait.Hard(5); // Currently Application is taking much time to load


                            fw.ExecuteJavascript(EAM.LoadEAFFile.Upload);

                            fw.ConsoleReport("Uploaded File using Upload Button");

                            tmsWait.Hard(5);

                           

                        }
                        break; // Exit from while loop
                    }

                }

                try
                {
                    System.IO.DirectoryInfo di = new DirectoryInfo("c:\\Temp\\");

                    foreach (FileInfo file in di.GetFiles())
                    {
                        file.Delete();
                    }

                }
                catch
                {

                }

                tmsWait.Hard(40);  // we kep this wait for intentionally as EAF file processing is taking time, will remove later
            }
            else
            {

                

                Boolean keepTrying = true;
               
                Console.WriteLine("**Before call to ALM file download**");
                //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
                //if they are there, we copy across.   Otherwise we reach into ALM to get them.
                string controllerFileLocation = "c:\\temp\\tmsAlm\\";
                string tempFolder = "c:\\temp\\";
                // We added this code for Jenkins run
                // Do not comment below code as it will be used for Smoke test suite
                string SourceFileLocation = "C:\\SourceFile\\";
                Boolean didUpload = false;
                string source = SourceFileLocation + p1_gen;
                bool fileFoundOnTemp = false;
                bool fileDownloadOnALM = false;
                if (Directory.Exists(SourceFileLocation))
                {
                    if (!File.Exists(controllerFileLocation))
                    {
                        fw.ConsoleReport(" Copy File From SourceFile to Temp Folder");
                        File.Copy(SourceFileLocation + p1_gen, tempFolder + p1_gen);
                        fileFoundOnTemp = true;
                        fileDownloadOnALM = true;
                        didUpload = true;
                        fw.ConsoleReport(" File is found on Source File Folder");
                    }
                }

                Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");

                if (!fileDownloadOnALM)
                {
                    Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                    didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
                }
                if (didUpload)
                {
                    while (keepTrying)
                    {
                        string FileName = "C:\\Temp\\" + p1_gen;


                        string newFileName = "C:\\Temp\\tmsAlm\\" + tmsCommon.GenerateData(p2_gen);
                        //Move method moves an existing file to a new location with the same or a different file name, move delete original file
                        File.Move(@FileName, @newFileName);
                        FileName = newFileName;
                        fw.ConsoleReport(" Renaming File");

                        // This Implementation is only for Edge browser

                        if (ConfigFile.BrowserType.Equals("edge") || ConfigFile.BrowserType.Equals("edgelegacy"))
                        {                                                      
                              
                            string sharedFolderPath = ReUsableFunctions.returnTMSSharedInputFolder(ConfigFile.EAMdb);
                            string destinationLoc = sharedFolderPath + tmsCommon.GenerateData(p2_gen);
                            File.Copy(FileName, destinationLoc);
                            
                        }
                        else
                        {
                            EAM.LoadEAFFile.SelectFiles.SendKeys(FileName);
                            fw.ConsoleReport(" Sending File");
                            tmsWait.Hard(3);
                            fw.ExecuteJavascript(EAM.LoadEAFFile.Upload);
                            fw.ConsoleReport(" Clicked on Uploaded Button");
                            tmsWait.Hard(5);
                            //fw.ConsoleReport(" Verifying Application is throwing any error message like Duplicate file or file format issue etc after uploading the File  ");
                            //try
                            //{
                            //    thisResponse = EAM.LoadEAFFile.UIModResponseMessage.Text;
                            //}
                            //catch
                            //{
                            //    if (thisResponse == "The specified filename does not match for this file type. Please verify the file or modify the filename.")
                            //    {
                            //        keepTrying = false;
                            //        Console.WriteLine("File load failed with message [" + thisResponse + "]");
                            //        break; //  Exit from While loop
                            //    }
                            //}
                        }

                        break; // Exit from while loop
                    }

                }

                try
                {
                    System.IO.DirectoryInfo di = new DirectoryInfo("c:\\Temp\\");

                    foreach (FileInfo file in di.GetFiles())
                    {
                        file.Delete();
                    }

                }
                catch
                {

                }
            }
        }

        [When(@"Load EAF File page, Config File ALM Project, Test ID ""(.*)"" attached file ""(.*)"" is selected with New File Name ""(.*)""")]
        public void WhenLoadEAFFilePageConfigFileALMProjectTestIDAttachedFileIsSelectedWithNewFileName(string p0, string p1, string p2)
        {            
            string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);
            Boolean keepTrying = true;
            int maxAttempts = 11;
            int thisAttempt = 0;
            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            // We added this code for Jenkins run  
            string SourceFileLocation = "C:\\SourceFile\\";
            Boolean didUpload = false;
            string source = SourceFileLocation + p1_gen;
            if (Directory.Exists(SourceFileLocation))
            {
                if (!File.Exists(controllerFileLocation))
                {
                    File.Copy(SourceFileLocation + p1_gen, controllerFileLocation + Path.GetFileName(source));
                }
            }

            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen)  + "]");
            if (File.Exists(controllerFileLocation + p1_gen))
            {
                File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen,true);
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");

            }
            else
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
            if (didUpload)
            {
                while (keepTrying)
                {
                    string FileName = "C:\\Temp\\" + p1_gen;

                    
                    string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen);
       //Move method moves an existing file to a new location with the same or a different file name, move delete original file
                    File.Move(@FileName, @newFileName);
                    FileName = newFileName;
                    EAM.LoadEAFFile.Browse.SendKeys(FileName);
                    //EAM.LoadEAFFile.Import.Click();
                    EAM.LoadEAFFile.Upload.Click();
                    tmsWait.Hard(1);
                    string thisResponse = EAM.LoadEAFFile.ResponseMessage.Text;
                    if (thisResponse != "The specified filename does not match for this file type. Please verify the file or modify the filename.")
                    {
                        keepTrying = false;
                        Console.WriteLine("File load failed with message [" + thisResponse + "]");
                    }
                    if (thisAttempt > maxAttempts)
                    {
                        keepTrying = false;
                    }
                    thisAttempt++;
                }

            }
        }
        [When(@"Load EAF File page, Config File ALM Project, Test ID ""(.*)"" attached file ""(.*)"" is selected")]
        public void WhenLoadEAFFilepageConfigFileALMProjectTestIDAttachedFileIsSelected(string p0, string p1)
        {
            Boolean didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1, p0);
            if (didUpload)
            {
                string FileName = "C:\\Temp\\" + p1;

                ////System.Windows.Forms.SendKeys.SendWait(FileName);
                ////System.Windows.Forms.SendKeys.SendWait("{ENTER}");
                IWebElement fileInput = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_FileUpload1"));
                fileInput.SendKeys(FileName);
                
            }
        }

        [When(@"Create CMS File Remove Checkboxes All Checked and Removed")]
        [Given(@"Create CMS File Remove Checkboxes All Checked and Removed")]
        [Then(@"Create CMS File Remove Checkboxes All Checked and Removed")]
        public void WhenCreateCMSFileRemoveCheckboxesAllCheckedAndRemoved()
        {
            try
            {
                IWebElement thisTable = EAM.CreateCMSFile.DataTable;
                IList<IWebElement> theseInputs = thisTable.FindElements(By.TagName("input"));
                int delRowCount = 0;
                foreach (IWebElement thisInput in theseInputs)
                {
                    if (thisInput.GetAttribute("id").Contains("chkDel"))
                    {
                        thisInput.Click();
                        delRowCount++;
                    }
                }
                if (delRowCount > 0)
                {
                    EAM.CreateCMSFile.Remove.Click();
                    tmsWait.Hard(1);
                    Browser.Wd.SwitchTo().Alert();
                    Browser.Wd.SwitchTo().Alert().Accept();
                    tmsWait.Hard(2);
                    if (delRowCount > 20)
                    {
                        tmsWait.Hard(3);

                    }
                }

            }
            catch { }
        }
        [When(@"Create CMS File Send Checkboxes All Checked and Mark")]
        [Given(@"Create CMS File Send Checkboxes All Checked and Mark")]
        [Then(@"Create CMS File Send Checkboxes All Checked and Mark")]
        public void WhenCreateCMSFileSendCheckboxesAllCheckedAndSend()
        {
            try
            {
                IWebElement thisTable = EAM.CreateCMSFile.DataTable;
                IList<IWebElement> theseInputs = thisTable.FindElements(By.TagName("input"));
                int markRowCount = 0;
                foreach (IWebElement thisInput in theseInputs)
                {
                    if (thisInput.GetAttribute("id").EndsWith("chk"))
                    {
                        thisInput.Click();
                        markRowCount++;
                    }
                }
                if (markRowCount > 0)
                {
                    EAM.CreateCMSFile.CMFFileMarkButton.Click();
                    tmsWait.Hard(1);
                    Browser.Wd.SwitchTo().Alert();
                    Browser.Wd.SwitchTo().Alert().Accept();
                    tmsWait.Hard(2);
                    if (markRowCount > 20)
                    {
                        tmsWait.Hard(3);

                    }
                }

            }
            catch { }
        }
    }
    [Binding]
    public class fsCreateBEQFile
    {
        [Then(@"I click on Create BEQ File Export Button")]
        public void ThenIClickOnCreateBEQFileExportButton()
        {
            EAM.CreateBEQFile.BEQFileExport.Click();
        }

    [When(@"CreateBEQFile PlanID is set to ""(.*)""")]
    [Then(@"CreateBEQFile PlanID is set to ""(.*)""")]
    public void WhenCreateBEQFilePlanIDIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.CreateBEQFile.CreateBEQFilePlan);
            select.SelectByText(GeneratedData);
            tmsWait.Hard(2);
        }
    }
    [Binding]
    public class fsCreateRetroFile
    {
        [When(@"CreateRetroFile PlanID is set to ""(.*)""")]
        [Given(@"CreateRetroFile PlanID is set to ""(.*)""")]
        [Then(@"CreateRetroFile PlanID is set to ""(.*)""")]
        public void WhenCreateRetroFilePlanIDIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.CreateRetroFile.PlanIDDropdownlist);
            select.SelectByText(GeneratedData);
            tmsWait.Hard(2);
        }

        [Then(@"Verify that the ""(.*)"" does not exist in the RetroFileMarkTable")]
        public void ThenVerifyThatTheDoesNotExistInTheRetroFileMarkTable(string p0)
        {
            try
            {
                IWebElement RetroExportFileTable = EAM.CreateRetroFile.PlanIDDropdownlist;
                IList<IWebElement> rows = RetroExportFileTable.FindElements(By.TagName("tr"));
                foreach (var row in rows)
                {
                    Assert.IsFalse(row.Text.Contains(p0));
                }
            }
            catch
            {
                Console.WriteLine("Create Retro file data table does not exist");
            }

        }
    }
        [Binding]
    public class fsCreateCMSFile
    {
        [When(@"CreateCMSFile PlanID is set to ""(.*)""")]
        [Given(@"CreateCMSFile PlanID is set to ""(.*)""")]
        [Then(@"CreateCMSFile PlanID is set to ""(.*)""")]
        public void WhenCreateCMSFilePlanIDIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.CreateCMSFile.CreateCMSFilePlan);
            select.SelectByText(GeneratedData);
            tmsWait.Hard(2);
        }

        [When(@"Create CMS File Transaction Code is set to ""(.*)""")]
        [Given(@"Create CMS File Transaction Code is set to ""(.*)""")]
        [Then(@"Create CMS File Transaction Code is set to ""(.*)""")]
        public void WhenCreateCMSFileTransactionCodeIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.CreateCMSFile.CreateCMSFileTransaction);
            select.SelectByText(GeneratedData);
            tmsWait.Hard(2);
        }

        [When(@"Create CMS File Election Code is set to ""(.*)""")]
        [Given(@"Create CMS File Election Code is set to ""(.*)""")]
        [Then(@"Create CMS File Election Code is set to ""(.*)""")]
        public void WhenCreateCMSFileElectionCodeIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.CreateCMSFile.CreateCMSFileTransaction);
            select.SelectByText(GeneratedData);
            tmsWait.Hard(2);
        }

        [When(@"CMS File Exclude Retros Checkbox Enable")]
        public void WhenCMSFileExcludeRetrosCheckboxEnable()
        {
            EAM.CreateCMSFile.ExcludeRetro.Click();
        }

        [When(@"CMS File Exclude Futures Checkbox Enable")]
        public void WhenCMSFileExcludeFuturesCheckboxEnable()
        {
            EAM.CreateCMSFile.ExcludeFutures.Click();
        }       

        [Then(@"I click on Create CMS File Export Button")]
        public void ThenIClickOnCreateCMSFileExportButton()
        {
            EAM.CreateCMSFile.CMSFileExport.Click();
            tmsWait.Hard(3);
        }

        [Then(@"I click on Create CMS File Mark Button")]
        public void ThenIClickOnCreateCMSFileMarkButton()
        {
            EAM.CreateCMSFile.CMFFileMarkButton.Click();
            tmsWait.Hard(3);
        }

        [Then(@"I click on ""(.*)"" alert OK button")]
        public void ThenIClickOnAlertOKButton(string p0)
        {
            string option = tmsCommon.GenerateData(p0);
            tmsWait.Hard(1);
            switch (option) {
             
                case "File Upload":
                    Browser.Wd.FindElement(By.XPath("//*[@test-id='confirmationDialog-div-dialog']//button[@id='confirmationDialogYes']")).Click();
                    break;
                case "Manual Data Load":
                    Browser.Wd.FindElement(By.XPath("//*[@id='ExecuteButtonPopUpYes']")).Click();
                    break;
            }
            tmsWait.Hard(1);
        }


        [Then(@"I click on alert OK button")]
        public void ThenIClickOnAlertOKButton()
        {
           
        }

        [Then(@"Create CMS File Sent CMSDate is set to ""(.*)""")]
        public void ThenCreateCMSFileSentCMSDateIsSetTo(string p0)
        {
            string date = p0.ToString();
            EAM.CreateCMSFile.CMSFileExportDate.SendKeys(date);
        }

        [When(@"Create CMS Earliest Effective Date is set to ""(.*)""")]
        [Given(@"Create CMS Earliest Effective Date is set to ""(.*)""")]
        [Then(@"Create CMS Earliest Effective Date is set to ""(.*)""")]
        public void ThenCreateCMSEarliestEffectiveDateIsSetTo(string p0)
        {
            
            string GeneratedData = tmsCommon.GenerateData(p0);
            string ExpectedData = GeneratedData;

            GeneratedData = GeneratedData.Replace("/", "");
            for (int i = 0; i < 5; i++)
            {
                EAM.CreateCMSFile.CMSFileEarliestEffectiveDate.SendKeys(GeneratedData);
                tmsWait.Hard(1);
                string thisValue = EAM.CreateCMSFile.CMSFileEarliestEffectiveDate.GetAttribute("value");
                tmsWait.Hard(1);
                if (thisValue == ExpectedData)
                {
                    break;
                }
                else
                {
                    EAM.CreateCMSFile.CMSFileEarliestEffectiveDate.Clear();
                    tmsWait.Hard(1);
                }
            }

        }

        [When(@"Create CMS Latest Effective Date is set to ""(.*)""")]
        [Given(@"Create CMS Latest Effective Date is set to ""(.*)""")]
        [Then(@"Create CMS Latest Effective Date is set to ""(.*)""")]
        public void ThenCreateCMSLatestEffectiveDateIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string ExpectedData = GeneratedData;

            GeneratedData = GeneratedData.Replace("/", "");
            for (int i = 0; i < 5; i++)
            {
                EAM.CreateCMSFile.CMSFileLatestEffectiveDate.SendKeys(GeneratedData);
                tmsWait.Hard(1);
                string thisValue = EAM.CreateCMSFile.CMSFileLatestEffectiveDate.GetAttribute("value");
                tmsWait.Hard(1);
                if (thisValue == ExpectedData)
                {
                    break;
                }
                else
                {
                    EAM.CreateCMSFile.CMSFileLatestEffectiveDate.Clear();
                    tmsWait.Hard(1);
                }
            }

        }

        [Then(@"CMS Table with ""(.*)"" Remove Checkbox Enable")]
        [Given(@"CMS Table with ""(.*)"" Remove Checkbox Enable")]
        [When(@"CMS Table with ""(.*)"" Remove Checkbox Enable")]
        public void ThenCMSTableWithRemoveCheckboxEnable(string p0)
        {
            IWebElement removeCheck =
                Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_grdMarkFile_ctl02_chkDel"));
            removeCheck.Click();
        }
        [Given(@"CMS Table with ""(.*)"" Send Checkbox Enable")]
        [When(@"CMS Table with ""(.*)"" Send Checkbox Enable")]
        [Then(@"CMS Table with ""(.*)"" Send Checkbox Enable")]
        public void ThenCMSTableWithSendCheckboxEnable(string p0)
        {
            IWebElement sendCheck =
                Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_grdMarkFile_ctl02_chk"));
            sendCheck.Click();
        }
        
        [Then(@"I click on Create CMS File Remove Button")]
        public void ThenIClickOnCreateCMSFileRemoveButton()
        {
            EAM.CreateCMSFile.Remove.Click();
        }
        [Then(@"I click on the CMS file Refresh button")]
        public void ThenIClickOnTheCMSFileRefreshButton()
        {
            EAM.CreateCMSFile.CMSFileRefreshButton.Click();
        }
        [Then(@"Verify that the ""(.*)"" does not exist in the CMSFileMarkTable")]
        public void ThenVerifyThatTheDoesNotExistInTheCMSFileMarkTable(string p0)
        {
            try
            {
                IWebElement CMSExportFileTable = EAM.CreateCMSFile.DataTable;
                IList<IWebElement> rows = CMSExportFileTable.FindElements(By.TagName("tr"));
                foreach (var row in rows)
                {
                    Assert.IsFalse(row.Text.Contains(p0));
                }
            }
            catch
            {
                Console.WriteLine("Create CMS file data table does not exist");
            }
            
        }
    }

    [Binding]
    public class fsLoadTRRFile
    {
        [When(@"Load TRR File Browse button is clicked")]
        public void WhenLoadTRRFileBrowseButtonIsClicked()
        {
            //EAM.LoadTRRFile.Browse.Click();
            Console.WriteLine("Browse Button does not need clicked for the Import File Process");
        }

        [When(@"Load TRR File Import button is clicked")]
        public void WhenLoadTRRFileImportButtonIsClicked()
        {
            //EAM.LoadTRRFile.Import.Click();
            Console.WriteLine("Import Button does not need clicked for the Import File Process");
        }


        [When(@"Load Provider File page, Config File ALM Project, Test ID ""(.*)"" attached file ""(.*)"" is selected with New File Name ""(.*)""")]
        public void WhenLoadProviderFilePageConfigFileALMProjectTestIDAttachedFileIsSelectedWithNewFileName(string p0, string p1, string p2)
        {
            string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);
            Boolean keepTrying = true;
            int maxAttempts = 11;
            int thisAttempt = 0;
            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            Boolean didUpload = false;
            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");
            if (File.Exists(controllerFileLocation + p1_gen))
            {
                File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen);
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");

            }
            else
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
            if (didUpload)
            {
                while (keepTrying)
                {
                    string FileName = "C:\\Temp\\" + p1_gen;

                    //For debugging
                    string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen);
                    File.Move(@FileName, @newFileName);
                    FileName = newFileName;
                    EAM.LoadProviderFile.Browse.SendKeys(FileName);
                    EAM.LoadProviderFile.Import.Click();
                    tmsWait.Hard(1);
                    string thisResponse = EAM.LoadProviderFile.ResponseMessage.Text;
                    if (thisResponse != "The specified filename does not match for this file type. Please verify the file or modify the filename.")
                    {
                        keepTrying = false;
                        Console.WriteLine("File load failed with message [" + thisResponse + "]");
                    }
                    if (thisAttempt > maxAttempts)
                    {
                        keepTrying = false;
                    }
                    thisAttempt++;
                }

            }

        }


        [Given(@"I set variable ""(.*)"" to value from file, filename ""(.*)"", TestID ""(.*)"", line ""(.*)"", position zero based ""(.*)"" to ""(.*)""")]
        public void GivenISetVariableToValueFromFileFilenameTestIDLinePositionZeroBasedTo(string p0, string p1, string p2, int p3, int p4, int p5)
        {
            string thisVariableName = p0;
            string filename = tmsCommon.GenerateData(p1);
            string testid = tmsCommon.GenerateData(p2);
            int lineNumber = p3;
            int beginning = p4;
            int ending = p5;
            int linesFound = 0;
            Boolean didCapture = false;
            string captureChars = "";

            //Here, if location is ALM, delete local file and get from ALM
            if (!File.Exists(filename))
            {
                string controllerFileLocation = "c:\\temp\\tmsAlm\\";
                // We added this code for Jenkins run
                string SourceFileLocation = "C:\\SourceFile\\";
                Boolean didUpload = false;
                string source = SourceFileLocation + filename;
                if (Directory.Exists(SourceFileLocation))
                {
                    if (!File.Exists(controllerFileLocation))
                    {
                        File.Copy(SourceFileLocation + filename, controllerFileLocation + Path.GetFileName(source));
                    }
                }

                Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + filename + "] is [" + File.Exists(controllerFileLocation + filename) + "]");
                if (File.Exists(controllerFileLocation + filename))
                {
                    File.Copy(controllerFileLocation + filename, "C:\\Temp\\" + filename);
                    tmsWait.Hard(1);
                    didUpload = true;
                    Console.WriteLine("**Performed local copy because file did exist locally.");

                }
                else
                {
                    Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                    didUpload = ALMUtilities.GetALMTestPlanAttachedFile(filename, testid);
                }
            }
            filename = "C:\\temp\\" + filename;

            if (beginning < 0 || ending < 0)
            {
                Console.WriteLine("Performing Capture on file [" + filename + "] line [" + lineNumber + "] beginning [" + beginning + "] ending [" + ending + "] to Variable [" + thisVariableName + "]");
                Assert.Fail("On File Capture: Beginning [" + beginning + "] or ending [" + ending + "] is less than 0.   Beginning and ending should be 0 or greater");
            }
            if (beginning > ending)
            {
                Console.WriteLine("Performing Capture on file [" + filename + "] line [" + lineNumber + "] beginning [" + beginning + "] ending [" + ending + "] to Variable [" + thisVariableName + "]");
                Assert.Fail("On File Capture: Beginning [" + beginning + "] is greater than [" + ending + "].   Beginning must be less than or equal to ending");
            }
            if (lineNumber < 1)
            {
                Console.WriteLine("Performing Capture on file [" + filename + "] line [" + lineNumber + "] beginning [" + beginning + "] ending [" + ending + "] to Variable [" + thisVariableName + "]");
                Assert.Fail("On File Capture: Line Number [" + lineNumber + "] is less than 1.   Line Number should be 1 or greater");
            }

            string[] thisFile = File.ReadAllLines(@filename);
            int CurrentLineCounter = 1;

            foreach (string line in thisFile)
            {
                string thisLine = line;
                linesFound++;
                if (CurrentLineCounter == lineNumber)
                {

                    //change to fail if ending is past line length
                    if (ending + 1 > thisLine.Length)
                    {
                        Console.WriteLine("Performing Capture on file [" + filename + "] line [" + lineNumber + "] beginning [" + beginning + "] ending [" + ending + "] to Variable [" + thisVariableName + "]");
                        Assert.Fail("Capture failed because the line is only [" + thisLine.Length + "] characters long and you are trying to capture from [" + beginning + "] to [" + ending + "], past end of the line");
                    }

                    captureChars = thisLine.Substring(beginning - 1, ending - beginning + 1);

                    Console.WriteLine("Initial Line:");
                    Console.WriteLine(line);
                    Console.WriteLine(captureChars);
                    Console.WriteLine("Capture Characters");
                    CurrentLineCounter++;
                    didCapture = true;
                    continue;
                }
                else
                {
                    CurrentLineCounter++;
                }

            }

            if (!didCapture)
            {
                Console.WriteLine("Performing Capture on file [" + filename + "] line [" + lineNumber + "] beginning [" + beginning + "] ending [" + ending + "] to Variable [" + thisVariableName + "]");
                Assert.Fail("On File Edit: No Capture happened.   Possible because you are using line [" + lineNumber + "] and we only found [" + linesFound + "] lines.");
            }
            else
            {
                Console.WriteLine("Performing Capture on file [" + filename + "] line [" + lineNumber + "] beginning [" + beginning + "] ending [" + ending + "] to Variable [" + thisVariableName + "]");
                //    Console.WriteLine("Variable [" + thisVariableName + "] set to [" + captureChars + "]");
                fw.setVariable(thisVariableName, captureChars);
            }
        }


        [Given(@"I edit File from ""(.*)"" with filename ""(.*)"", TestID ""(.*)"", line ""(.*)"", position zero based ""(.*)"" to ""(.*)"" with new data ""(.*)""")]
        public void GivenIEditFileFromALMWithFilenameFileNameLinePositionToWithNewDataGenerateVariableMyVariableName(string p0, string p1, string p2, int p3, int p4, int p5, string p6)
        {
            string location = tmsCommon.GenerateData(p0);
            string filename = tmsCommon.GenerateData(p1);
            string testid = tmsCommon.GenerateData(p2);
            int lineNumber = p3;
            int beginning = p4;
            int ending = p5;
            string NewData = tmsCommon.GenerateData(p6);
            Boolean didEdit = false;
            StringBuilder newFile = new StringBuilder();

            string temp = "";

            if (location.ToLower() != "alm" && location.ToLower() != "temp")
            {
                Console.WriteLine("Performing edit on file.   Location [] needs to be 'alm' or 'temp'. ");
                Assert.Fail("Performing edit on file.   Location [] needs to be 'alm' or 'temp'. ");
            }


            //Here, if location is ALM, delete local file and get from ALM
            if (location.ToLower() == "alm")
            {
                string controllerFileLocation = "c:\\temp\\tmsAlm\\";
                // We added this code for Jenkins run
                string SourceFileLocation = "C:\\SourceFile\\";
                Boolean didUpload = false;
                string source = SourceFileLocation + filename;
                if (Directory.Exists(SourceFileLocation))
                {
                    if (!File.Exists(controllerFileLocation))
                    {
                        File.Copy(SourceFileLocation + filename, controllerFileLocation + Path.GetFileName(source));
                    }
                }

                Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + filename + "] is [" + File.Exists(controllerFileLocation + filename) + "]");
                if (File.Exists(controllerFileLocation + filename))
                {
                    File.Copy(controllerFileLocation + filename, "C:\\Temp\\" + filename);
                    tmsWait.Hard(1);
                    didUpload = true;
                    Console.WriteLine("**Performed local copy because file did exist locally.");

                }
                else
                {
                    Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                    didUpload = ALMUtilities.GetALMTestPlanAttachedFile(filename, testid);
                }
            }
            //if it's Temp, don't get the file from ALM, just edit from Temp directly
            filename = "C:\\temp\\" + filename;

            if (beginning < 0 || ending < 0)
            {
                Console.WriteLine("Performing edit on file [" + filename + "] line [" + lineNumber + "] beginning [" + beginning + "] ending [" + ending + "] with new data [" + NewData + "]");
                Assert.Fail("On File Edit: Beginning [" + beginning + "] or ending [" + ending + "] is less than 0.   Beginning and ending should be 0 or greater");
            }
            if (beginning > ending)
            {
                Console.WriteLine("Performing edit on file [" + filename + "] line [" + lineNumber + "] beginning [" + beginning + "] ending [" + ending + "] with new data [" + NewData + "]");
                Assert.Fail("On File Edit: Beginning [" + beginning + "] is greater than [" + ending + "].   Beginning must be less than or equal to ending");
            }
            if (lineNumber < 1)
            {
                Console.WriteLine("Performing edit on file [" + filename + "] line [" + lineNumber + "] beginning [" + beginning + "] ending [" + ending + "] with new data [" + NewData + "]");
                Assert.Fail("On File Edit: Line Number [" + lineNumber + "] is less than 1.   Line Number should be 1 or greater");
            }
            if (ending - beginning + 1 < NewData.Length)
            {
                Console.WriteLine("Performing edit on file [" + filename + "] line [" + lineNumber + "] beginning [" + beginning + "] ending [" + ending + "] with new data [" + NewData + "]");
                Assert.Fail("On File Edit: The New Data has length [" + NewData.Length + "] which is greater than the space given to place it [" + (ending - beginning + 1) + "] characters.");
            }

            int linesFound = 0;
            string[] thisFile = File.ReadAllLines(@filename);
            int CurrentLineCounter = 1;
            foreach (string line in thisFile)
            {
                string thisLine = line;
                linesFound++;
                if (CurrentLineCounter == lineNumber)
                {
                    while (ending + 1 > thisLine.Length)
                    {
                        thisLine += " ";  //if the spot we add the data is past the overall length padd the front half of the string.
                    }


                    string FrontHalf = thisLine.Substring(0, beginning);
                    string BackHalf = thisLine.Substring(ending + 1, thisLine.Length - ending - 1);
                    int ExpectedReplacementLength = ending - beginning;

                    while (beginning > thisLine.Length)
                    {
                        FrontHalf += " ";  //if the spot we add the data is past the overall length padd the front half of the string.
                    }
                    while (NewData.Length < ExpectedReplacementLength + 1)
                    {
                        NewData += " "; //pad spaces after the given data
                    }
                    temp = FrontHalf + NewData + BackHalf;

                    newFile.Append(temp + "\r\n");
                    Console.WriteLine("Initial Line:");
                    Console.WriteLine(line);
                    Console.WriteLine(temp);
                    Console.WriteLine("Changed Line");
                    CurrentLineCounter++;
                    didEdit = true;
                    continue;
                }
                else
                {
                    CurrentLineCounter++;
                }
                newFile.Append(thisLine + "\r\n");

            }

            File.WriteAllText(filename, newFile.ToString());
            if (!didEdit)
            {
                Console.WriteLine("Performing edit on file [" + filename + "] line [" + lineNumber + "] beginning [" + beginning + "] ending [" + ending + "] with new data [" + NewData + "]");
                Assert.Fail("On File Edit: No edit happened.   Possible because you are editing line [" + lineNumber + "] and we only found [" + linesFound + "] lines.");
            }
        }


        [When(@"TRR File is Downloaded from HP ALM Test ID ""(.*)"" attached file ""(.*)"" is selected with New File Name ""(.*)"" and replaced with new MBI ""(.*)"" value")]
        public void WhenTRRFileIsDownloadedFromHPALMTestIDAttachedFileIsSelectedWithNewFileNameAndReplacedWithNewMBIValue(string p0, string p1, string p2, string p3)
        {
            string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);
            string runTimeMBI= tmsCommon.GenerateData(p3);
            Boolean keepTrying = true;

            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            // We added this code for Jenkins run
            string SourceFileLocation = "C:\\SourceFile\\";
            Boolean didUpload = false;
            string source = SourceFileLocation + p1_gen;
            if (Directory.Exists(SourceFileLocation))
            {
                if (File.Exists(controllerFileLocation + p1_gen))
                {
                    File.Copy(SourceFileLocation + p1_gen, controllerFileLocation + Path.GetFileName(source));
                }
            }

            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");
            if (File.Exists(controllerFileLocation + p1_gen))
            {
                File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen);
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");

            }
            else
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
            if (didUpload)
            {

                string FileName = "C:\\Temp\\" + p1_gen;

                //For debugging
                string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen);

                // Renaming File Name to New Name
                File.Move(@FileName, @newFileName);
                FileName = newFileName;
                tmsWait.Hard(1);


            }
        }


        [When(@"BEQ File is Downloaded from HP ALM Test ID ""(.*)"" attached file ""(.*)"" is selected with New File Name ""(.*)""")]
        [When(@"TRR File is Downloaded from HP ALM Test ID ""(.*)"" attached file ""(.*)"" is selected with New File Name ""(.*)""")]
        [Then(@"TRR File is Downloaded from HP ALM Test ID ""(.*)"" attached file ""(.*)"" is selected with New File Name ""(.*)""")]
        public void ThenTRRFileIsDownloadedFromHPALMTestIDAttachedFileIsSelectedWithNewFileName(string p0, string p1, string p2)
        {
            string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);
            Boolean keepTrying = true;
            ReUsableFunctions.deleteFilesFromDownloadFolder();
            ReUsableFunctions.deleteFilesFromTempFolder();
            // Create a Specific Folder
            string activeDir = "c:\\temp\\tmsAlm\\";
            if (!Directory.Exists(activeDir))  //  Verify Specific Folder Exists, if No then Create it.
            {
                Directory.CreateDirectory(activeDir);
            }


            //string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            //// We added this code for Jenkins run
            //string SourceFileLocation = "C:\\SourceFile\\";
            //Boolean didUpload = false;
            //string source = SourceFileLocation + p1_gen;
            //if (Directory.Exists(SourceFileLocation))
            //{
            //    if (File.Exists(controllerFileLocation + p1_gen))
            //    {
            //        File.Copy(SourceFileLocation + p1_gen, controllerFileLocation + Path.GetFileName(source));
            //    }
            //}

            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            string tempFolder = "c:\\temp\\";
            // We added this code for Jenkins run
            // Do not comment below code as it will be used for Smoke test suite
            string SourceFileLocation = "C:\\SourceFile\\";
            Boolean didUpload = false;
            string source = SourceFileLocation + p1_gen;
            bool fileFoundOnTemp = false;
            bool fileDownloadOnALM = false;
            if (Directory.Exists(SourceFileLocation))
            {
                if (!File.Exists(controllerFileLocation))
                {
                    File.Copy(SourceFileLocation + p1_gen, tempFolder + p1_gen);
                    fileFoundOnTemp = true;
                    fileDownloadOnALM = true;
                    didUpload = true;
                }
            }
            if (!fileDownloadOnALM)
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
            //if (File.Exists(controllerFileLocation + p1_gen))
            //{
            //    File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen);
            //    tmsWait.Hard(1);
            //    didUpload = true;
            //    Console.WriteLine("**Performed local copy because file did exist locally.");

            //}
            //else
            //{
            //    Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

            //    didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            //}
            if (didUpload)
            {

                string FileName = "C:\\Temp\\" + p1_gen;

                //For debugging
                string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen);

                // Renaming File Name to New Name
                File.Move(@FileName, @newFileName);
                FileName = newFileName;
                tmsWait.Hard(1);


            }
        }

        [When(@"Upload Updated TRR file ""(.*)""")]
        public void WhenUploadUpdatedTRRFile(string p0)
        {
            string FileName = "C:\\Temp\\" + tmsCommon.GenerateData(p0);
            tmsWait.Hard(1);
            EAM.LoadEAFFile.SelectFiles.SendKeys(FileName);
            fw.ExecuteJavascript(EAM.LoadEAFFile.Upload);
            //EAM.LoadTRRFile.Browse.SendKeys(FileName);
            //EAM.LoadTRRFile.Import.Click();

        }


        [When(@"Load TRR File page, Config File ALM Project, Test ID ""(.*)"" attached file ""(.*)"" is selected with New File Name ""(.*)""")]
        public void WhenLoadTRRFilePageConfigFileALMProjectTestIDAttachedFileIsSelectedWithNewFileName(string p0, string p1, string p2)
        {
            string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);
            Boolean keepTrying = true;
            int maxAttempts = 11;
            int thisAttempt = 0;
            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            // We added this code for Jenkins run
            string SourceFileLocation = "C:\\SourceFile\\";
            Boolean didUpload = false;
            string source = SourceFileLocation + p1_gen;
            if (Directory.Exists(SourceFileLocation))
            {
                if (!File.Exists(controllerFileLocation))
                {
                    File.Copy(SourceFileLocation + p1_gen, controllerFileLocation + Path.GetFileName(source));
                }
            }

            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");
            if (File.Exists(controllerFileLocation + p1_gen))
            {
                File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen);
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");

            }
            else
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
            if (didUpload)
            {
                while (keepTrying)
                {
                    string FileName = "C:\\Temp\\" + p1_gen;

                    //For debugging
                    string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen);
                    File.Move(@FileName, @newFileName);
                    FileName = newFileName;
                    EAM.LoadTRRFile.Browse.SendKeys(FileName);
                    EAM.LoadTRRFile.Import.Click();
                    tmsWait.Hard(1);
                    string thisResponse = EAM.LoadTRRFile.ResponseMessage.Text;
                    if (thisResponse != "The specified filename does not match for this file type. Please verify the file or modify the filename.")
                    {
                        keepTrying = false;
                        Console.WriteLine("File load failed with message [" + thisResponse + "]");
                    }
                    if (thisAttempt > maxAttempts)
                    {
                        keepTrying = false;
                    }
                    thisAttempt++;
                }

            }
        }

        [When(@"EAM Home page queues items count for ""(.*)"" is noted")]
        public void WhenEAMHomePageQueuesItemsCountForIsNoted(string nameOfItem)
        {
            string count = string.Empty;
            switch (nameOfItem)
            {
                case "letters in Confirmation of Enrollment Letter queue":
                    {
                        GlobalRef.Confirmation_of_Enrollment_Letter_queue_Count = Int32.Parse(EAM.EAMHomePage.Confirmation_of_Enrollment_Letter_queue_Count.Text);
                        break;
                    }
            }
        }


        [When(@"Load TRR File page, Config File ALM Project, Test ID ""(.*)"" attached file ""(.*)"" is selected")]
        public void WhenLoadTRRFilepageConfigFileALMProjectTestIDAttachedFileIsSelected(string p0, string p1)
        {
            tmsWait.Hard(2);
            string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);
            Boolean keepTrying = true;
            int maxAttempts = 11;
            int thisAttempt = 0;
            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            Boolean didUpload = false;
            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");
            if (File.Exists(controllerFileLocation + p1_gen))
            {
                File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen, true);
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");

            }
            else
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
            if (didUpload)
            {
                while (keepTrying)
                {
                    string FileName = "C:\\Temp\\" + p1_gen;

                    ////For debugging
                    //string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData("generate|variable|NewFileName");
                    //File.Move(@FileName, @newFileName);
                    //FileName = newFileName;
                    EAM.LoadTRRFile.Browse.SendKeys(FileName);
                    EAM.LoadTRRFile.Import.Click();
                    tmsWait.Hard(1);
                    string thisResponse = EAM.LoadTRRFile.ResponseMessage.Text;
                    if (thisResponse != "The specified filename does not match for this file type. Please verify the file or modify the filename.")
                    {
                        keepTrying = false;
                        Console.WriteLine("File load failed with message [" + thisResponse + "]");
                    }
                    if (thisAttempt > maxAttempts)
                    {
                        keepTrying = false;
                    }
                    thisAttempt++;
                }

            }
        }

        [When(@"Load No Premium Due File page, Config File ALM Project, Test ID ""(.*)"" attached file ""(.*)"" is selected with New File Name ""(.*)""")]
        public void WhenLoadNoPremiumDueFilePageConfigFileALMProjectTestIDAttachedFileIsSelectedWithNewFileName(string p0, string p1, string p2)
        {
            string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);
            Boolean keepTrying = true;
            int maxAttempts = 11;
            int thisAttempt = 0;
            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            // We added this code for Jenkins run
            string SourceFileLocation = "C:\\SourceFile\\";
            Boolean didUpload = false;
            string source = SourceFileLocation + p1_gen;
            if (Directory.Exists(SourceFileLocation))
            {
                if (!File.Exists(controllerFileLocation))
                {
                    File.Copy(SourceFileLocation + p1_gen, controllerFileLocation + Path.GetFileName(source));
                }
            }

            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");
            if (File.Exists(controllerFileLocation + p1_gen))
            {
                File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen, true);
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");

            }
            else
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
            if (didUpload)
            {
                while (keepTrying)
                {
                    string FileName = "C:\\Temp\\" + p1_gen;


                    string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen);
                    //Move method moves an existing file to a new location with the same or a different file name, move delete original file
                    File.Move(@FileName, @newFileName);
                    FileName = newFileName;
                    EAM.LoadNoPremiumDueFile.Browse.SendKeys(FileName);
                    EAM.LoadNoPremiumDueFile.Import.Click();
                    tmsWait.Hard(1);
                    break;

                }

            }
        }
        [When(@"Load NoRx File page, Config File ALM Project, Test ID ""(.*)"" attached file ""(.*)"" is selected with New File Name ""(.*)""")]
        public void WhenLoadNoRxFilePageConfigFileALMProjectTestIDAttachedFileIsSelectedWithNewFileName(int p0, string p1, string p2)
        {

            string po_gen = tmsCommon.GenerateData(p0.ToString());
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);
            Boolean keepTrying = true;
            int maxAttempts = 11;
            int thisAttempt = 0;
            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            Boolean didUpload = false;
            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");
            if (File.Exists(controllerFileLocation + p1_gen))
            {
                File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen, true);
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");

            }
            else
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
            if (didUpload)
            {
                while (keepTrying)
                {
                    string FileName = "C:\\Temp\\" + p1_gen;

                    //For debugging
                    string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen);
                    File.Move(@FileName, @newFileName);
                    FileName = newFileName;
                    EAM.LoadNoRxFile.Browse.SendKeys(FileName);
                    EAM.LoadNoRxFile.Import.Click();
                    tmsWait.Hard(1);
                    string thisResponse = EAM.LoadEAFFile.ResponseMessage.Text;
                    if (thisResponse != "The specified filename does not match for this file type. Please verify the file or modify the filename.")
                    {
                        keepTrying = false;
                        Console.WriteLine("File load failed with message [" + thisResponse + "]");
                    }
                    if (thisAttempt > maxAttempts)
                    {
                        keepTrying = false;
                    }
                    thisAttempt++;
                }

            }
        
    }
    


        [When(@"Load LegacyReset File page, Config File ALM Project, Test ID ""(.*)"" attached file ""(.*)"" is selected with New File Name ""(.*)""")]
        public void WhenLoadLegacyResetFilePageConfigFileALMProjectTestIDAttachedFileIsSelectedWithNewFileName(int p0, string p1, string p2)
        {
            string po_gen = tmsCommon.GenerateData(p0.ToString());
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);
            Boolean keepTrying = true;
            int maxAttempts = 11;
            int thisAttempt = 0;
            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            Boolean didUpload = false;
            Console.WriteLine("**Checking file exist on local file.  [" + controllerFileLocation + p1_gen + "] is [" + File.Exists(controllerFileLocation + p1_gen) + "]");
            if (File.Exists(controllerFileLocation + p1_gen))
            {
                File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen, true);
                tmsWait.Hard(1);
                didUpload = true;
                Console.WriteLine("**Performed local copy because file did exist locally.");

            }
            else
            {
                Console.WriteLine("**Trying to Go to ALM becuase file didn't exist locally.");

                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
            if (didUpload)
            {
                while (keepTrying)
                {
                    string FileName = "C:\\Temp\\" + p1_gen;

                    //For debugging
                    string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen);
                    File.Move(@FileName, @newFileName);
                    FileName = newFileName;
                    EAM.LoadEAFFile.Browse.SendKeys(FileName);
                    EAM.LoadEAFFile.Import.Click();
                    tmsWait.Hard(1);
                    string thisResponse = EAM.LoadEAFFile.ResponseMessage.Text;
                    if (thisResponse != "The specified filename does not match for this file type. Please verify the file or modify the filename.")
                    {
                        keepTrying = false;
                        Console.WriteLine("File load failed with message [" + thisResponse + "]");
                    }
                    if (thisAttempt > maxAttempts)
                    {
                        keepTrying = false;
                    }
                    thisAttempt++;
                }

            }
        }

    }
}