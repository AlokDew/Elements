﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows;
using System.Drawing;
using OpenQA.Selenium.Support.UI;
using TMSoR1.FrameworkCode;

namespace TMSoR1
{
    [Binding]
    public class EAMMembersSearchSteps
    {
        //[When(@"I have entered ""(.*)"" into the HIC Field")]
        //public void WhenIHaveEnteredIntoTheHICField(string p0)
        //{
        //    EAM.MembersSearch.HICNumber.SendKeys(p0);
        //}
        [When(@"Members Search HIC Number is set to ""(.*)""")]
        [Then(@"Members Search HIC Number is set to ""(.*)""")]
        public void WhenMembersSearchHICNumberIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODViewEditMember.MemberLookup.MBI, GeneratedData);
                tmsWait.Hard(2);

                // PC - commenting it out , because negative test is failing

                //By mbiValue = By.XPath("//table[@role='presentation']//td[contains(.,'"+ GeneratedData + "')]/preceding-sibling::td/input");
                //UIMODUtilFunctions.clickOnWebElementUsingLocators(mbiValue);
                //tmsWait.Hard(1);
                //By AddBtn = By.CssSelector("[test-id='member-btn-add']");
                //UIMODUtilFunctions.clickOnWebElementUsingLocators(AddBtn);
                //tmsWait.Hard(1);

            }
            else
            {
                ReUsableFunctions.enterValueOnWebElementWithClear(cfUIMODViewEditMember.MemberLookup.MBI, GeneratedData);
                tmsWait.Hard(2);
            }
            GlobalRef.LTMBI = GeneratedData;
            GlobalRef.TransMBI = GeneratedData;
            
        }

        [When(@"Members Search PlanID is set to ""(.*)""")]
        public void WhenMembersSearchPlanIDIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            tmsWait.Hard(4);

            IWebElement planid = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPlan"));

            SelectElement plan = new SelectElement(planid);
            plan.SelectByText(GeneratedData);

        }

        [When(@"I want to do something new and my varialbe ""(.*)""")]
        public void WhenIWantToDoSomethingNewAndMyVarialbe(string p0)
        {
            Console.WriteLine("Hello");
        }


        [When(@"Members View Edit HIC Number is set to ""(.*)""")]
        public void WhenMembersViewEditHICNumberIsSetTo(string p0)
        {
        }

        [When(@"I have entered ""(.*)"" into the First Name Field")]
        public void WhenIHaveEnteredIntoTheFirstNameField(string p0)
        {
            tmsWait.Hard(2);
            string fname = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By fnameloc = By.CssSelector("[test-id='transSearch-input-firstName']");
                UIMODUtilFunctions.enterValueOnWebElementUsingLocators(fnameloc, fname);

            }
            else
            {
                
                EAM.MembersSearch.FirstName.SendKeys(fname);
                EAM.MembersSearch.FirstName.SendKeys(Keys.Tab);
                tmsWait.Hard(2);
            }
        }

        [When(@"Transactions Search Trans Status is set to ""(.*)""")]
        public void WhenTransactionsSearchTransStatusIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string status = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Transaction Status')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + status + "']");


                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);



            }
            else
            {
                IWebElement ele = Browser.Wd.FindElement(By.CssSelector("[aria-owns='dropdownTransStatus_listbox']"));
                UIMODUtilFunctions.selectDropDownValueFromGendoUI(ele, status);

            }
        }

        [When(@"I have entered ""(.*)"" into the Last Name Field")]
        public void WhenIHaveEnteredIntoTheLastNameField(string p0)
        {
            tmsWait.Hard(2);
            string lname = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By fnameloc = By.CssSelector("[test-id='transSearch-input-lastName']");
                UIMODUtilFunctions.enterValueOnWebElementUsingLocators(fnameloc, lname);

            }
            else
            {
                EAM.MembersSearch.LastName.SendKeys(lname);
            }
        }

        [When(@"I have entered ""(.*)"" into the Member ID Field")]
        public void WhenIHaveEnteredIntoTheMemberIDField(string p0)
        {
            tmsWait.Hard(2);
            string memid = tmsCommon.GenerateData(p0);
            EAM.MembersSearch.MemberID.SendKeys(memid);
        }

        [When(@"I have entered ""(.*)"" into the PBP ID Field")]
        public void WhenIHaveEnteredIntoThePBPIDField(string p0)
        {
            tmsWait.Hard(2);
            string pbpid = tmsCommon.GenerateData(p0);
            EAM.MembersSearch.PBPID.SendKeys(pbpid);
        }

        [When(@"I have entered ""(.*)"" into the Plan ID Field")]
        public void WhenIHaveEnteredIntoThePlanIDField(string p0)
        {
            tmsWait.Hard(2);
            string planid = tmsCommon.GenerateData(p0);
            EAM.MembersSearch.PlanID.SendKeys(planid);
        }

        [When(@"I have entered ""(.*)"" into the Member Status Field")]
        public void WhenIHaveEnteredIntoTheMemberStatusField(string p0)
        {
            tmsWait.Hard(2);
            string planid = tmsCommon.GenerateData(p0);
            EAM.MembersSearch.MemberStatus.SendKeys(planid);
        }

        [When(@"I have entered ""(.*)"" into the Program Source Field")]
        public void WhenIHaveEnteredIntoTheProgramSourceField(string p0)
        {

            tmsWait.Hard(2);
            string pgm = tmsCommon.GenerateData(p0);
            EAM.MembersSearch.ProgramSource.SendKeys(pgm);
        }



        [When(@"Members View Edit Search button is clicked")]
        public void WhenMembersViewEditSearchButtonIsClicked()
        {
            EAM.MembersSearch.Search.Click();
            tmsWait.Hard(2);
        }

        [Then(@"Members View Edit Verify Attachement icon should not be displayed")]
        public void ThenMembersViewEditVerifyAttachementIconShouldNotBeDisplayed()
        {
            tmsWait.Hard(5);
            try
            {
                if (EAM.MembersNew.AddAttachment.Displayed)
                {
                    Assert.Fail();
                }
                else
                {
                    Assert.IsTrue(true, "Attachment icon is not displayed...");
                }
            }
            catch (Exception)
            {
                Assert.IsTrue(true, "Attachment icon is not displayed...");
            }
        }

        [Then(@"Verify MemberViewEdit Contact page SCC is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditContactPageSCCIsSetTo(string p0)
        {
            Assert.IsTrue(EAM.MembersNewTabContact.SCC.Text == p0, "SCC has default value as expected");
        }

        [Then(@"Verify MemberViewEdit Contact page State is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditContactPageStateIsSetTo(string p0)
        {
            Assert.IsTrue(EAM.MembersNewTabContact.State.Text == p0, "State has default value as expected");
        }

        [Then(@"Verify MemberViewEdit Contact page City is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditContactPageCityIsSetTo(string p0)
        {
            Assert.IsTrue(EAM.MembersNewTabContact.City.Text == p0, "City has default value as expected");
        }

        [Then(@"Verify MemberViewEdit Contact page Zip is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditContactPageZipIsSetTo(string p0)
        {
            Assert.IsTrue(EAM.MembersNewTabContact.Zip.Text == p0, "Zip has default value as expected");
        }


        [Then(@"Letters Table has a row")]
        [When(@"Letters Table has a row")]
        public void WhenLettersTableHasARow(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.LettersPostCMS.LettersTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Members View Edit Table has row: {0}", e.Message);
            }
        }


        [Then(@"Members View Edit Transactions Tab transactions Table does not have the below row")]
        public void ThenMembersViewEditTransactionsTabTransactionsTableDoesNotHaveTheBelowRow(Table table)
        {
            tmsWait.Hard(3);

            try
            {
                IWebElement objWebTable = EAM.MembersViewEditTransactionsTab.TransactionsTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index >= 0)
                        {
                            Assert.Fail("Expected row [{0}] was found but should NOT {1}: ", i + 1, arrRes[i, 1]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Verify Transactions Table does not have rows: {0}", e.Message);
            }
        }

        [When(@"No rows are found and ""(.*)"" is displayed")]
        [Then(@"No rows are found and ""(.*)"" is displayed")]
        [Given(@"No rows are found and ""(.*)"" is displayed")]
        public void WhenNoRowsAreFoundAndIsDisplayed(string p0)
        {
            int DisplayCount = 0;
            try
            {
                for (int i = 1; i < 100; i++)
                {
                    string Size = EAM.MemberInformation.MemberNotPresentMessage.Size.ToString();
                    string Location = EAM.MemberInformation.MemberNotPresentMessage.Location.ToString();
                    string Text = EAM.MemberInformation.MemberNotPresentMessage.Text;
                    Boolean size, location, text, WasDisplayed;
                    WasDisplayed = false;

                    size = Size.Length > 19;
                    location = Location.Length > 9;
                    text = Text == p0;
                    WasDisplayed = size && location && text;
                    if (WasDisplayed) { DisplayCount++; break; }
                }
                Boolean passed = DisplayCount > 0;
                Console.WriteLine("Pop up message [" + p0 + "] was displayed [" + passed + "]");
                Assert.AreEqual(true, passed, "Pop up message [" + p0 + "] was displayed");
            }
            catch
            {
                Console.WriteLine("Pop up message [" + p0 + "] was displayed [Unknown]");

            }

        }


        [Then(@"Members View Edit Table does not have a row")]
        public void ThenMembersViewEditTableDoesNotHaveARow(Table table)
        {
            tmsWait.Hard(3);
            try
            {
                IWebElement objWebTable = EAM.MembersViewEditTransactionsTab.TransactionsTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index >= 0)
                        {
                            Assert.Fail("Expected row [{0}] was found but should NOT {1}: ", i + 1, arrRes[i, 1]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Verify Letters Table does not have rows");
            }
        }


        [Then(@"Members View Edit Transactions Tab transactions Table has row")]
        public void ThenMembersViewEditTransactionsTabTransactionsTableHasRow(Table table)
        {
            tmsWait.Hard(3);
            try
            {
                IWebElement objWebTable = EAM.MembersViewEditTransactionsTab.TransactionsTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                            tmsWait.Hard(2);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Members View Edit Table has row: {0}", e.Message);
                tmsWait.Hard(2);
            }
        }


        [Then(@"Members View Edit Table has HIC ""(.*)""")]
        public void ThenMembersViewEditTableHasHIC(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            Console.WriteLine("Input data row: [" + GeneratedData + "]");
            try
            {
                if (Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + GeneratedData + "')]/preceding-sibling::td/a")).Displayed)
                {
                    Assert.IsTrue(true, "Expected HIC[{0}] was found: ", GeneratedData);
                }
            }
            catch (Exception ex)
            {
                Assert.Fail("Expected HIC[{0}] was not found: ", GeneratedData);
            }
        }


        [Then(@"Members View Edit Table has row")]
        [When(@"Members View Edit Table has row")]
        [Given(@"Members View Edit Table has row")]
        public void ThenMembersViewEditTableHasRow(Table table)
        {
            Exception thisE = null;
            Boolean bSuccess = false;
            int iCt = 0;
            while (iCt < 5 && !bSuccess)
            {
                iCt++;
                try
                {
                    IWebElement objWebTable = EAM.MembersSearch.MemberSearchTable;
                    Console.WriteLine("Input data row: [" + table.ToString() + "]");

                    String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                    for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                    {
                        int index = 0;
                        if (int.TryParse(arrRes[i, 0], out index))
                        {
                            if (index < 0)
                            {
                                Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                            }
                        }
                    }
                    bSuccess = true;
                }
                catch (Exception e)
                {
                    thisE = e;
                    Console.WriteLine("Failed trying to hit found hic lookup [" + iCt + "]");
                }
            }
            if (!bSuccess)
            {
                Assert.Fail("Members View Edit Table has row: {0}", thisE.Message);

            }
        }

        [When(@"FRM Main General Search page MBI ""(.*)"" record is Clicked")]
        public void WhenFRMMainGeneralSearchPageMBIRecordIsClicked(string mbi)
        {
            tmsWait.Hard(5);
            IWebElement mbirecord = Browser.Wd.FindElement(By.XPath("//div[@test-id='genSearchCrt-grid-generalGrid']//div[contains(.,'" + mbi + "')]/parent::div/following-sibling::div/div/a[@title='View']"));
            fw.ExecuteJavascript(mbirecord);
        }


        [Then(@"Members Spans Table has the below row")]
        public void ThenMembersSpansTableHasTheBelowRow(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.MembersViewEditSpansTab.SpansTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                //           thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "th", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }

                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                //else
                //{
                //    //Click next page link and start over.
                //    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                //    {
                //        thisTP.bNotAtLastPageOfRecords = true;
                //        thisTP.NPL.Click();
                //        tmsWait.Hard(2);
                //    }
                //}
                baseTable = EAM.MembersViewEditSpansTab.SpansTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

        [When(@"Span tab EFF button is clicked")]
        public void WhenSpanTabEFFButtonIsClicked()
        {
            tmsWait.Hard(2);
            EAM.MembersViewEditSpansTab.EFFButton.Click();
        }


        [Then(@"Members Search Table has rows")]
        public void ThenMembersSearchTableHasRows(Table table)
        {
            //Establish the next page link for flipping pages as necessary
            string NextPageLinkText = "";
            Boolean bNotAtLastPageOfRecords = true;
            Boolean bHaveGoodPageLink = true;
            IWebElement NPL = null;
            //Get the Table Header off of the test script Gherkin table
            ICollection<string> thisTH = table.Header;
            int thCount = thisTH.Count;
            string[] thisHeader = new string[thisTH.Count];
            thisTH.CopyTo(thisHeader, 0);   //copies the header to an array

            //Set up an array of classes to hold the table data, first one (0) will be the header info
            //The class has flags for this data row being a header, data and if we have yet matched it in our trials
            TableRow[] thisTableArr = new TableRow[table.RowCount + 1];
            thisTableArr[0] = new TableRow();
            thisTableArr[0].RowIsHeader = true;
            thisTableArr[0].RowIsData = false;
            thisTableArr[0].RowIsMatched = false;
            //Add the header data to the array 0 table row instance
            foreach (string thisString in thisHeader)
            {
                thisTableArr[0].Row.Add(thisString);
            }
            int iCounter = 1;
            //Add the Gherkin table row data to the array of rows.  These are all data, not headers, not matched yet.
            foreach (var row in table.Rows)
            {
                thisTableArr[iCounter] = new TableRow();
                thisTableArr[iCounter].RowIsHeader = false;
                thisTableArr[iCounter].RowIsData = true;
                thisTableArr[iCounter].RowIsMatched = false;

                for (int c = 0; c < row.Count; c++)
                {
                    thisTableArr[iCounter].Row.Add(row[c]);
                }
                iCounter++;
            }
            //While we have not matched all rows yet
            //and we are not on the last page of records..
            while (thisTableArr[0].AllRowsMatched(thisTableArr) == false && bNotAtLastPageOfRecords)
            {
                bNotAtLastPageOfRecords = false;
                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.MembersSearch.MemberSearchTable;
                //Get the spans data, this is the current page number.  Derive the next page number.
                ICollection<IWebElement> mySpans = baseTable.FindElements(By.TagName("span"));
                foreach (IWebElement thisSpan in mySpans)
                {
                    int CurrentPageNumber = Convert.ToInt16(thisSpan.Text);
                    int NextPageNumber = CurrentPageNumber + 1;
                    NextPageLinkText = NextPageNumber.ToString();
                }
                //Find the link for the next page.  (for later)
                try
                {
                    NPL = baseTable.FindElement(By.LinkText(NextPageLinkText));
                }
                catch
                {
                    bNotAtLastPageOfRecords = true;
                    bHaveGoodPageLink = false;
                }
                //Get rows out of the table on the page, from the table object
                ICollection<IWebElement> myRows = baseTable.FindElements(By.TagName("tr"));
                int RowCount = myRows.Count;
                //Establish an array of table rows for the page data.
                TableRow[] thisDataArr = new TableRow[RowCount];
                int EstablishedRowItemCount = 0;
                int iRowCounter = 0;
                foreach (IWebElement thisRow in myRows)
                {
                    //For each new data row we look at, add a new instance of the class to the array.
                    thisDataArr[iRowCounter] = new TableRow();
                    thisDataArr[iRowCounter].RowIsHeader = true;
                    thisDataArr[iRowCounter].RowIsData = false;
                    thisDataArr[iRowCounter].RowIsMatched = false;
                    //Get all of the elements from the row (<td>)
                    ICollection<IWebElement> myElements = thisRow.FindElements(By.TagName("td"));
                    //Row 0 is the header
                    //The rest of the rows are data
                    foreach (IWebElement thisElement in myElements)
                    {
                        if (iRowCounter == 0)
                        {
                            //Finding the normal item count because the page numbers are a data row.
                            //Row 0 is the header
                            EstablishedRowItemCount = myElements.Count;
                            thisDataArr[iRowCounter].RowIsHeader = true;
                            thisDataArr[iRowCounter].RowIsData = false;
                        }
                        else
                        {
                            //Other rows are data
                            thisDataArr[iRowCounter].RowIsHeader = false;
                            thisDataArr[iRowCounter].RowIsData = true;
                        }
                        if (myElements.Count == EstablishedRowItemCount)
                        {
                            //Only add data if we have a data row, not if we have a 0 length row.
                            thisDataArr[iRowCounter].Row.Add(thisElement.Text.ToString());
                        }
                        else
                        {
                            //If this row count isn't the right number of items, we didn't match with expected.
                            thisDataArr[iRowCounter].RowIsData = false;
                        }
                    }
                    iRowCounter++;
                }
                int iTableCounter = 0;
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TableRow TTA in thisTableArr)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.
                    if (TTA.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] ta = TTA.Row.ToArray();

                        //For each row in the page data
                        foreach (TableRow TDA in thisDataArr)
                        {
                            //Convert page data to array elements
                            string[] td = TDA.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.
                            foreach (string tde in td)
                            {
                                if (iElementCounter > 0 && TDA.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (tde != ta[iElementCounter - 1] && ta[iElementCounter - 1] != "[Skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (td.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same
                            if (bThisRowMatches)
                            {
                                //Report the match, first convert the array back to a string we can read.
                                thisTableArr[iTableCounter].RowIsMatched = true;
                                string TR0 = TableRow.ArrayToString(td);
                                string TR1 = TableRow.ArrayToString(ta);
                                Console.WriteLine("Expected Row Data --- " + TR1);
                                Console.WriteLine("Found Row Data --- " + TR0);

                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisTableArr[0].AllRowsMatched(thisTableArr);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        bNotAtLastPageOfRecords = true;
                        NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.MembersSearch.MemberSearchTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (bHaveGoodPageLink == false && !fullMatching)
                {
                    int iCount = 0;
                    var TableRow = new TMSString();
                    foreach (TableRow thisTR in thisTableArr)
                    {
                        if (thisTR.RowIsMatched == false && thisTR.RowIsHeader == false)
                        {
                            string thisRowData = TableRow.ArrayToString(thisTR.Row.ToArray());
                            Console.WriteLine("Unmatched Data Row -- " + thisRowData);
                        }
                        iCount++;
                    }
                    Assert.AreEqual(true, false, "Not all expected rows in the Gherkin test table were found in the page table data rows.");
                }
            }
        }

        [Then(@"the table will include a record where HIC is ""(.*)"" and status is ""(.*)""")]
        public void ThenTheTableWillIncludeARecordWhereHICIsAndStatusIs(string p0, string p1)
        {
            IList<IWebElement> allElements = EAM.MembersSearch.MemberSearchTable.FindElements(By.CssSelector("td[class='charData']")); // you have all row that are visible
            Boolean thisHICMatch = false;
            Boolean thisStatusMatch = false;
            foreach (IWebElement item in allElements)
            {
                Console.WriteLine(item);

                string[] arr = new string[255];
                arr = item.Text.Split(' ');

                for (int i = 0; i < arr.Length; i++)
                {
                    Console.WriteLine(arr[i]);

                    if (arr[i] == p0)
                    {
                        thisHICMatch = true;
                    }
                    if (arr[i] == p1)
                    {
                        thisStatusMatch = true;
                    }
                }
            }
            Assert.AreEqual(thisHICMatch, true, "Hic Match Found");
            Console.WriteLine("Hic match was [{0}]", thisHICMatch);
            Assert.AreEqual(thisStatusMatch, true, "Status Match Found");
            Console.WriteLine("Status match was [{0}]", thisStatusMatch);
        }

        [Then(@"the table will not include a record with HIC equal ""(.*)""")]
        public void ThenTheTableWillNotIncludeARecordWithHICEqual(string p0)
        {
            Boolean objExists = fw.elementExists(EAM.MembersSearch.MemberSearchTable);
            if (objExists)
            {
                IList<IWebElement> allElements = EAM.MembersSearch.MemberSearchTable.FindElements(By.CssSelector("td[class='charData']")); // you have all row that are visible
                Boolean thisHICMatch = false;
                foreach (IWebElement item in allElements)
                {
                    Console.WriteLine(item);
                    string[] arr = new string[255];
                    arr = item.Text.Split(' ');

                    for (int i = 0; i < arr.Length; i++)
                    {
                        Console.WriteLine(arr[i]);
                        if (arr[i] == p0)
                        {
                            thisHICMatch = true;
                        }
                    }
                }
                Assert.AreEqual(thisHICMatch, false, "Hic Match not Found");
                Console.WriteLine("Hic match was [{0}]", thisHICMatch);
            }
            else
            {
                Assert.AreEqual(true, true, "Table did not exist, no HIC found as expected");
                Console.WriteLine("Table did not exist, no HIC found as expected");
            }
        }

        [Then(@"Members View Edit Table Edit Icon is clicked for HIC ""(.*)""")]
        public void ThenMembersViewEditTableEditIconIsClickedForHIC(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            try
            {
                if (Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + GeneratedData + "')]/preceding-sibling::td/a")).Displayed)
                {
                    Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + GeneratedData + "')]/preceding-sibling::td/a")).Click();
                }
            }
            catch (Exception ex)
            {
                Assert.Fail("Expected HIC[{0}] was not found: ", GeneratedData);
            }
        }


        //NL 04/01/2015
        [When(@"Members View Edit Table Edit Icon is clicked for row")]
        [Then(@"Members View Edit Table Edit Icon is clicked for row")]

        public void ThenMembersViewEditTableEditIconIsClickedForRow(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.MembersSearch.MemberSearchTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index > 0)
                        {
                            index++;
                            string xPath = "//tr[" + index + "]//img[@alt='Edit']";
                            IWebElement editIcon = EAM.MembersSearch.MemberSearchTable.FindElement(By.XPath(xPath));
                            editIcon.Click();
                            try
                            {
                                editIcon.SendKeys(Keys.Enter);
                            }
                            catch (Exception) { }
                            tmsWait.Hard(3);
                            //                            tmsWait.WaitForReadyStateComplete(30);
                            // IWebElement objHIC = tmsWait.WaitForElementExist(By.XPath("//*[contains(@id ,'txtHic_01')]"), 60);
                            Console.WriteLine("Edit icon was clicked");
                        }
                        else { Assert.Fail("Edit Icon for expected row was not found"); }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Members Edit Icon is clicked for row: {0}", e.Message);
            }
        }

        [Then(@"Members View Edit Table contains ""(.*)"" number of records")]
        public void ThenMembersViewEditTableContainsNumberOfRecords(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            try
            { 
                Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//kendo-pager-info[contains(.,'" + GeneratedData + "')]")).Displayed);
            }
            catch (Exception ex)
            {
                Assert.Fail("Member count was not equal to: ", GeneratedData);
            }
        }

        [Then(@"Members New Tab IDHistory Table has row")]
        public void ThenMembersNewTabIDHistoryTableHasRow(Table table)
        {
            Exception thisE = null;
            Boolean bSuccess = false;
            int iCt = 0;
            while (iCt < 5 && !bSuccess)
            {
                iCt++;
                try
                {
                    IWebElement objWebTable = EAM.MembersSearch.MemberSearchTable;
                    Console.WriteLine("Input data row: [" + table.ToString() + "]");

                    String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                    for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                    {
                        int index = 0;
                        if (int.TryParse(arrRes[i, 0], out index))
                        {
                            if (index < 0)
                            {
                                Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                            }
                        }
                    }
                    bSuccess = true;
                }
                catch (Exception e)
                {
                    thisE = e;
                    Console.WriteLine("Failed trying to hit found hic lookup [" + iCt + "]");
                }
            }
            if (!bSuccess)
            {
                Assert.Fail("Members View Edit Table has row: {0}", thisE.Message);

            }
        }

        [When(@"Members View Edit page Note Image button is clicked")]
        [Then(@"Members View Edit page Note Image button is clicked")]
        public void ThenMembersViewEditPageNoteImageButtonIsClicked()
        {
            tmsWait.Hard(4);
            fw.ExecuteJavascript(cfUIMODMemberCreation.UIMODMemberCreation.ViewNotesIcon);

           // Browser.SwitchToWindowUsingTitle("Notes Screen");
        }

        [When(@"Notes and Actions Page ""(.*)"" MBI row Notes is Clicked")]
        public void WhenNotesAndActionsPageMBIRowNotesIsClicked(string p0)
        {
            string mbi = tmsCommon.GenerateData(p0);
            By loc;
            if (ConfigFile.tenantType == "tmsx")
            {
               loc = By.XPath("//*[@test-id='noteSearch-grid-notes']//td[contains(.,'" + mbi + "')]/following-sibling::td/a[2]");
            }
            else {
               loc = By.XPath("//div[@test-id='noteSearch-grid-notes']//td[contains(.,'" + mbi + "')]/following-sibling::td/a[2]");
            }
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            tmsWait.Hard(4);
        }

        [Then(@"Note page ADD Action link is clicked")]
        public void ThenNotePageADDActionLinkIsClicked()
        {
            By loc = By.XPath("//li[@test-id='outOfAre-li-actions']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);

            tmsWait.Hard(4);
        }

        [Then(@"Note page View Action link is clicked")]
        public void ThenNotePageViewActionLinkIsClicked()
        {
            By loc = By.XPath("//span[@class='py-2 fas fa-copy']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            tmsWait.Hard(4);
        }



        [Then(@"Verify Members View Edit page Note as ""(.*)"" is displayed")]
        public void ThenVerifyMembersViewEditPageNoteAsIsDisplayed(string p0)
        {
            tmsWait.Hard(2);

            string note = tmsCommon.GenerateData(p0);
            By loc;
            if (ConfigFile.tenantType == "tmsx")
            {
                loc = By.XPath("//*[@test-id='viewNotes-grid-grdViewNotesTab'][contains(.,'" + note + "')]");
            }
            else
            {
                loc = By.XPath("//div[@test-id='viewNotes-grid-grdViewNotesTab'][contains(.,'" + note + "')]");
            }
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);

            ////fw.ExecuteJavascript(EAM.MembersViewEdit.ViewNoteButton);
            //Browser.SwitchToWindowUsingTitle("EAM - Full View");
            //tmsWait.Hard(2);
            //string noteexist = Browser.Wd.FindElement(By.XPath("(//td[contains(.,'Test Note')])[4]")).Text;
            //Assert.IsTrue(noteexist.Equals(note), "Note is not displayed as expected.");
            //fw.ExecuteJavascript(EAM.MembersViewEdit.ViewNoteCloseButton);
            //Browser.SwitchToParentWindow();
            //Browser.SwitchToWindowUsingTitle("Notes Screen");
        }


        [Then(@"Verify Members View Edit page Action as ""(.*)"" is displayed")]
        public void ThenVerifyMembersViewEditPageActionAsIsDisplayed(string p0)
        {
            tmsWait.Hard(2);

            string note = tmsCommon.GenerateData(p0);
            By loc = By.XPath("//*[@test-id='addNotes-input-description']");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }

        [Then(@"Note page ADD Action radio button is clicked")]
        public void ThenNotePageADDActionRadioButtonIsClicked()
        {
            tmsWait.Hard(2);
            IWebElement add = Browser.Wd.FindElement(By.XPath("//label[@test-id='addNotes-label-rdAction']"));

            fw.ExecuteJavascript(add);
        }


        [Then(@"Note page ADD Note button is clicked")]
        public void ThenNotePageADDNoteButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(EAM.MembersViewEdit.NoteImageButton);
            Browser.SwitchToWindowUsingTitle("Add Note/Action");
        }

        [When(@"Note page ADD Note button is clicked")]
        public void WhenNotePageADDNoteButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(EAM.MembersViewEdit.NoteImageButton);
            Browser.SwitchToWindowUsingTitle("Notes Screen");
        }

        [When(@"New Note page Note as ""(.*)"" is entered")]
        [Then(@"New Note page Note as ""(.*)"" is entered")]
        public void ThenNewNotePageNoteAsIsEntered(string note)
        {
            tmsWait.Hard(2);
            string strValue = tmsCommon.GenerateData(note.ToString());
            EAM.MembersViewEdit.NewNotesTextArea.SendKeys(note);
        }

        [When(@"New Note page Add Note button is clicked")]
        [Then(@"New Note page Add Note button is clicked")]
        public void ThenNewNotePageAddNoteButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(EAM.MembersViewEdit.NewNoteAddbutton);
            tmsWait.Hard(2);

        }
        [Then(@"Members View Edit page Note view button is clicked")]
        public void ThenMembersViewEditPageNoteViewButtonIsClicked()
        {
            IWebElement add = Browser.Wd.FindElement(By.XPath("//i[@class='py-2 fas fa-copy']"));

            fw.ExecuteJavascript(add);
          
        }

        [Then(@"Members View Edit page Actions view button is clicked")]
        public void ThenMembersViewEditPageACtionsViewButtonIsClicked()
        {
            IWebElement add = Browser.Wd.FindElement(By.XPath("//li[@id='k-tabstrip-tab-1']"));

            fw.ExecuteJavascript(add);
        }


        [Then(@"New Note page Close Note button is clicked")]
        [When(@"New Note page Close Note button is clicked")]
        public void ThenNewNotePageCloseNoteButtonIsClicked()
        {
            tmsWait.Hard(2);
            EAM.MembersViewEdit.NewNoteCloseButton.Click();
            // Browser.SwitchToParentWindow();
            // Browser.SwitchToWindowUsingTitle("Notes Screen");
            // EAM.MembersViewEdit.NotesScreenClosebutton.Click();
            Browser.SwitchToParentWindow();
        }
    }

    //NL 04/02/2015
    class TableHelper
    {

        public static IList<IWebElement> GetTableHeadingAsListOfObjects(IWebElement objWebTable)
        {
            string tableID = objWebTable.GetAttribute("id");
            string XPath = "//table[@id ='" + tableID + "']//td[@class = 'headingbox']";

            IList<IWebElement> objUITableHeadingsList = null;
            objUITableHeadingsList = Browser.Wd.FindElements(By.XPath(XPath)); //"//td[@class = 'headingbox']"
            if (objUITableHeadingsList.Count == 0)
            {
                XPath = "//table[@id ='" + tableID + "']//th";
                objUITableHeadingsList = Browser.Wd.FindElements(By.XPath(XPath));
            }
            if (objUITableHeadingsList.Count == 0)
            {
                XPath = "//table[@id ='" + tableID + "']//tr[not(@height=0) and not(.='')][1]/td";
                objUITableHeadingsList = Browser.Wd.FindElements(By.XPath(XPath));
            }
            //if (objUITableHeadingsList.Count == 0)
            //{
            //    XPath = "//table[@id ='" + tableID + "'] +//tr[not(@height=0)][2]/td";
            //    objUITableHeadingsList = Browser.Wd.FindElements(By.XPath(XPath));
            //}
            if (objUITableHeadingsList.Count == 0)
            { Assert.Fail("Unable to find heading in the UI table. "); }

            return objUITableHeadingsList;
        }

        public static List<string> GetTableHeadingsAsStringList(IList<IWebElement> objUITableHeadingsList)
        {
            List<string> strUITableHeadingsList = new List<string>();
            foreach (IWebElement objHeading in objUITableHeadingsList)
            {
                // string highlightJavascript = @"arguments[0].style.cssText = ""border-width: 2px; border-style: solid; border-color: red"";";
                // ((IJavaScriptExecutor)Browser.Wd).ExecuteScript(highlightJavascript, new object[] { objHeading });

                strUITableHeadingsList.Add(objHeading.Text.ToLower());
            }
            return strUITableHeadingsList;
        }

        public static List<string> GetTableHeadingsAsStringList(IWebElement objWebTable)
        {
            IList<IWebElement> objUITableHeadingsList = GetTableHeadingAsListOfObjects(objWebTable);
            List<string> strUITableHeadingsList = GetTableHeadingsAsStringList(objUITableHeadingsList);
            return strUITableHeadingsList;
        }

        public static bool TablePageNavigation(ref IWebElement objWebTable, ref int intCurrentPageNumber, ref bool isNextPageExist)
        {
            intCurrentPageNumber++;
            string strUITableID = objWebTable.GetAttribute("id");
            IWebElement nextPageLink = null;
            try
            {
                nextPageLink = objWebTable.FindElement(By.LinkText(intCurrentPageNumber.ToString()));
            }
            catch (NoSuchElementException)
            {
                //look for 11
                //11 doesn't exist
                //look for ...
                //click ...
                try
                {
                    //nextPageLink = objWebTable.FindElement(By.XPath("//a[text()='...' and contains(@href, 'ctl2')]"));
                    IWebElement Forward = null;
                    IList<IWebElement> theseATags = objWebTable.FindElements(By.TagName("a"));
                    foreach (IWebElement thisA in theseATags)
                    {
                        // "javascript:__doPostBack('ctl00$ctl00$MainMasterContent$MainContent$dgLetters$ctl01$ctl10','')"
                        string myhref = thisA.GetAttribute("href");
                        string last2 = myhref.Substring(myhref.Length - 7);
                        last2 = last2.Substring(0, 2);
                        int iLast2 = Convert.ToInt32(last2);
                        if (thisA.Text == "..." && iLast2 > 0)
                        {
                            Forward = thisA;
                            break;
                        }
                    }
                    nextPageLink = Forward;
                }
                catch (NoSuchElementException)
                {
                    Console.WriteLine("WebTable Navigation: next link for navigation was not found");
                    isNextPageExist = false;
                    return false;
                }
            }
            if (nextPageLink != null)
            {
                nextPageLink.Click();
                try
                {
                    nextPageLink.SendKeys(Keys.Enter);
                }
                catch (Exception) { }
                Console.WriteLine("Link {0} was clicked", intCurrentPageNumber);
                tmsWait.Hard(5);

                //redefine table 
                // tmsWait.WaitForElementExist(By.Id(strUITableID), 30);
                tmsWait.Hard(2);
                objWebTable = Browser.Wd.FindElement(By.Id(strUITableID));

                return true;
            }
            else { isNextPageExist = false; return false; }
        }

        ///<summary>
        ///Finds one or more rows in the web table by combination Column Name - Column Value; 
        ///Returns array with pairs for each expected row: web table's row index and message; 
        ///if row was not found - output array will have values [-1],[message]
        ///</summary>
        ///<remarks>
        ///Nina Lukyanava
        ///04/03/2015
        ///</remarks>
        public static String[,] FindRowsInWebTable(Table dataTable, ref IWebElement objWebTable)
        {
            //array for result: for each expected row first elemet will contain index of found webTable's row(-1 if not found) and the second one - message
            String[,] arrExpRowsFoundResult = new String[dataTable.RowCount, 2];
            int intNumberOfMatchedRows = 0;  //Daron 7.9.2015
            int intNeededMatchedRowCount = dataTable.RowCount;
            try
            {
                int intCurrentPageNumber = 1;
                string strUITableID = objWebTable.GetAttribute("id");

                //Get list of heading columns' names         
                List<string> strUITableHeadingsList = TableHelper.GetTableHeadingsAsStringList(objWebTable);

                ICollection<string> strExpectedHeaderCollection = dataTable.Header;

                int intCurrentColumnIndex = 0;
                bool isAllRowsFound = false;

                // foreach (var row in dataTable.Rows)
                while (!isAllRowsFound)
                {
                    isAllRowsFound = true;
                    int CurrentRowIndex = 1;
                    bool isNextPageExist = true;
                    int intDataRowIndex = 0;

                    //go through rows in WebTable
                    IList<IWebElement> objUITableRowsList = objWebTable.FindElements(By.TagName("tr"));
                    int intRowsCount = objUITableRowsList.Count;
                    for (int i = CurrentRowIndex; i < intRowsCount; i++)
                    {
                        var objCells = objUITableRowsList[i].FindElements(By.TagName("td"));
                        if (objCells.Count > intCurrentColumnIndex)
                        {
                            //go through all rows from expected data table

                            intDataRowIndex = 0;
                            isAllRowsFound = true;
                            string AppDataRow = "";
                            foreach (var dataRow in dataTable.Rows)
                            {
                                if (arrExpRowsFoundResult[intDataRowIndex, 0] == null || arrExpRowsFoundResult[intDataRowIndex, 0] == "-1")
                                {
                                    using (IEnumerator<string> enumHeader = strExpectedHeaderCollection.GetEnumerator())
                                    {
                                        //check if each cell in expected row is found in the current web table's row
                                        AppDataRow = "";
                                        while (enumHeader.MoveNext())
                                        {
                                            //      Console.WriteLine("Building Data Row: ["+ AppDataRow +"]");
                                            var dataHeader = enumHeader.Current;
                                            string dataValue = tmsCommon.GenerateDataForTable(dataRow[dataHeader]).ToLower();

                                            if (dataValue != "[skip]")
                                            {
                                                intCurrentColumnIndex = strUITableHeadingsList.IndexOf(dataHeader.ToLower());
                                                if (intCurrentColumnIndex < 0)
                                                {
                                                    Console.WriteLine("Header {0} was not found in the web table", dataHeader);
                                                }
                                                else
                                                {
                                                    string cellValue = objUITableRowsList[i].FindElements(By.TagName("td"))[intCurrentColumnIndex].Text;
                                                    AppDataRow += cellValue + " - ";
                                                    if (cellValue.ToLower().Equals(dataValue))
                                                    {
                                                        CurrentRowIndex = i;
                                                        arrExpRowsFoundResult[intDataRowIndex, 0] = i.ToString();
                                                        arrExpRowsFoundResult[intDataRowIndex, 1] = arrExpRowsFoundResult[intDataRowIndex, 1] + String.Format("[{0}] - [{1}];", dataHeader, dataValue);
                                                        intNumberOfMatchedRows++;
                                                        Console.WriteLine("Expected Row [{0}]: {1} - {2} was found", intDataRowIndex, dataHeader, dataValue);
                                                    }
                                                    else
                                                    {
                                                        if (arrExpRowsFoundResult[intDataRowIndex, 0] == i.ToString())
                                                        {
                                                            arrExpRowsFoundResult[intDataRowIndex, 1] = arrExpRowsFoundResult[intDataRowIndex, 1] + String.Format("[{0}] - [{1}];", dataHeader, cellValue);
                                                            Console.WriteLine("Application data: [" + AppDataRow + "]");
                                                            Console.WriteLine("Row [{0}] has wrong values: [{1}] - [{2}]", intDataRowIndex, dataHeader, dataValue);
                                                        }
                                                        arrExpRowsFoundResult[intDataRowIndex, 0] = "-1";
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                int intRowIndex;
                                if (int.TryParse(arrExpRowsFoundResult[intDataRowIndex, 0], out intRowIndex))
                                {
                                    if (intRowIndex <= 0)
                                    {
                                        isAllRowsFound = false;
                                    }
                                }
                                intDataRowIndex++;
                            }
                            if (isAllRowsFound)
                            { break; }
                        }
                    }
                    //if no row with expected value was found, try to navigate if possible
                    if (!isAllRowsFound)
                    {
                        if (TableHelper.TablePageNavigation(ref objWebTable, ref intCurrentPageNumber, ref isNextPageExist))
                        {
                            objWebTable = Browser.Wd.FindElement(By.Id(strUITableID));
                            objUITableRowsList = objWebTable.FindElements(By.TagName("tr"));
                        }
                        else { isAllRowsFound = true; }
                    }
                }
            }
            catch (Exception e)
            {
                if (intNumberOfMatchedRows < intNeededMatchedRowCount)  //Daron 7.9.2015  If we matched enough rows, don't send back the -1 fail stuff, zero them out.
                {
                    Assert.Fail("Find row(s) in the web table: {0}", e.Message);
                }
            }
            if (intNumberOfMatchedRows >= intNeededMatchedRowCount)  //Daron 7.9.2015  If we matched enough rows, don't send back the -1 fail stuff, zero them out. 
            {
                for (int i = 0; i < arrExpRowsFoundResult.Length / 2; i++)
                {
                    if (arrExpRowsFoundResult[i, 0] == "-1")
                    {
                        arrExpRowsFoundResult[i, 0] = "0";
                    }
                }
            }

            return arrExpRowsFoundResult;
        }
    }


    class TableRow
    {
        public Boolean RowIsData;
        public Boolean RowIsHeader;
        public Boolean RowIsMatched;
        public List<string> Row = new List<string>();
        public List<IWebElement> Element = new List<IWebElement>();

        public Boolean AllRowsMatched(TableRow[] thisArr)
        {
            Boolean thisReturnValue = true;
            int Counter = 0;
            foreach (TableRow a in thisArr)
            {
                if (a.RowIsMatched == false && Counter > 0)
                {
                    thisReturnValue = false;
                }
                Counter++;
            }
            return thisReturnValue;
        }
    }
    public class TMSString
    {
        public string ArrayToString(string[] inArr)
        {
            string returnString = "";
            foreach (string thisString in inArr)
            {
                returnString += " [" + thisString + "] ";
            }
            return returnString;
        }
    }

}
