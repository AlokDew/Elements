﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.EAM
{
    [Binding]
    class fsCreateNewTransaction
    {
        [When(@"Verify New Transaction page Search button is Clicked")]
        public void WhenVerifyNewTransactionPageSearchButtonIsClicked()
        {
            cfCreateNewTransaction.CreateNewTransaction.SearchButton.Click();
        }

        [Then(@"Verify Transaction Search Page displayed Text as ""(.*)""")]
        public void ThenVerifyTransactionSearchPageDisplayedTextAs(string expectedValue)
        {
            string actualValue = cfTransactionSearch.TransactionSearch.SearchPageText.Text;

            Assert.AreEqual(expectedValue, actualValue, " Both Text message are not matching");
        }


    }
}
