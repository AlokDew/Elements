﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows;
using System.Drawing;
using OpenQA.Selenium.Support.UI;
using TMSoR1.FrameworkCode;

namespace TMSoR1
{
    [Binding]
    public class EAMMembersViewEdit
    {
        [When(@"Members View Edit Transactions Tab is clicked")]
        public void WhenMembersViewEditTransactionsTabIsClicked()
        {
            EAM.MembersNewTabTransactions.TransactionsTabLink.Click();
        }

        [Then(@"Verify View Edit Member page OEC Sales section OEC File Date is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageOECSalesSectionOECFileDateIsSetTo(string expected)
        {
            By fileDate = By.XPath("//input[@test-id='oecSales-txt-oecFileDate']");

            string actual = Browser.Wd.FindElement(fileDate).GetAttribute("value");

            Assert.AreEqual(expected,actual);


        }

        [Then(@"Verify View Edit Member Page Provider Section ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageProviderSectionIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string expvalue = tmsCommon.GenerateData(p1);
            string actvalue;
            By ele;

            switch(field)
            {
                case "First Name":
                    ele = By.CssSelector("[test-id='provider-input-firstName']");
                    actvalue = Browser.Wd.FindElement(ele).GetAttribute("value");
                    Assert.AreEqual(expvalue, actvalue," Both Values are not matching");
                    break;

                case "Last Name":
                    ele = By.CssSelector("[test-id='provider-input-lastname']");
                    actvalue = Browser.Wd.FindElement(ele).GetAttribute("value");
                    Assert.AreEqual(expvalue, actvalue, " Both Values are not matching");
                    break;

                case "PCP ID":
                    ele = By.CssSelector("[test-id='provider-input-pcpId']");
                    actvalue = Browser.Wd.FindElement(ele).GetAttribute("value");
                    Assert.AreEqual(expvalue, actvalue, " Both Values are not matching");
                    break;
                    

                case "PCP Prv Id":
                    ele = By.Name("pcpPrevId");
                    actvalue = Browser.Wd.FindElement(ele).GetAttribute("value");
                    Assert.AreEqual(expvalue, actvalue, " Both Values are not matching");
                    break;
            }

        }


        [Then(@"Verify View Edit Member page User Entered Field displayed as ""(.*)""")]
        public void ThenVerifyViewEditMemberPageUserEnteredFieldDisplayedAs(string p0)
        {
            
            string expvalue = tmsCommon.GenerateData(p0);
            string actvalue;
            By ele = By.XPath("//span[@test-id='memberInfo-span-userEntered']");
            actvalue = Browser.Wd.FindElement(ele).Text;
            Assert.AreEqual(expvalue, actvalue, " Both Values are not matching"); 

            
        }

        [Then(@"Verify View Edit Member page Date Entered Field displayed as Today Date")]
        public void ThenVerifyViewEditMemberPageDateEnteredFieldDisplayedAsTodayDate()
        {
            string expvalue = AngularFunction.returnDateMMDDYYYY();
            string actvalue;
            By ele = By.XPath("//span[@test-id='memberInfo-span-dateEntered']");
            actvalue = Browser.Wd.FindElement(ele).Text.Split(" ")[0];

            Assert.AreEqual(expvalue, actvalue, " Both Values are not matching");
        }

        [Then(@"Verify View Edit Member page Date Modified Field displayed as Today Date")]
        public void ThenVerifyViewEditMemberPageDateModifiedFieldDisplayedAsTodayDate()
        {
            string expvalue = AngularFunction.returnDateMMDDYYYY();
            string actvalue;
            By ele = By.XPath("//span[@test-id='memberInfo-span-dateModified']");
            actvalue = Browser.Wd.FindElement(ele).Text.Split(" ")[0];

            Assert.AreEqual(expvalue, actvalue, " Both Values are not matching");
        }

        [Then(@"Verify View Edit Transaction page User Entered Field displayed as ""(.*)""")]
        public void ThenVerifyViewEditTransactionPageUserEnteredFieldDisplayedAs(string p0)
        {
            string expvalue = tmsCommon.GenerateData(p0);
            string actvalue;
            By ele = By.XPath("//span[@test-id='transaction-span-userEntered']");
            actvalue = Browser.Wd.FindElement(ele).Text;
            Assert.AreEqual(expvalue, actvalue, " Both Values are not matching");
        }

        [Then(@"Verify View Edit Transaction page Date Entered Field displayed as Today Date")]
        public void ThenVerifyViewEditTransactionPageDateEnteredFieldDisplayedAsTodayDate()
        {
            string expvalue = AngularFunction.returnDateMMDDYYYY();
            string actvalue;
            By ele = By.XPath("//span[@test-id='transaction-span-dateEntered']");
            actvalue = Browser.Wd.FindElement(ele).Text.Split(" ")[0];

            Assert.AreEqual(expvalue, actvalue, " Both Values are not matching");
        }

        [Then(@"Verify View Edit Transaction page Date Modified Field displayed as ""(.*)""")]
        public void ThenVerifyViewEditTransactionPageDateModifiedFieldDisplayedAs(string p0)
        {
            if (p0.Equals(""))
            {
                string expvalue = p0;
                string actvalue;
                By ele = By.XPath("//span[@test-id='transaction-span-dateModified']");
                actvalue = Browser.Wd.FindElement(ele).Text;

                Assert.AreEqual(expvalue, actvalue, " Both Values are not matching");
            }
            else
            {
                string expvalue = AngularFunction.returnDateMMDDYYYY();
                string actvalue;
                By ele = By.XPath("//span[@test-id='transaction-span-dateModified']");
                actvalue = Browser.Wd.FindElement(ele).Text.Split(" ")[0];

                Assert.AreEqual(expvalue, actvalue, " Both Values are not matching");
            }
        }

        [Then(@"Verify View Edit Transaction page User Modified Field displayed as ""(.*)""")]
        public void ThenVerifyViewEditTransactionPageUserModifiedFieldDisplayedAs(string p0)
        {
            if (p0.Equals(""))
            {
                string expvalue = p0;
                string actvalue;
                By ele = By.XPath("//span[@test-id='transaction-span-userModified']");
                actvalue = Browser.Wd.FindElement(ele).Text;

                Assert.AreEqual(expvalue, actvalue, " Both Values are not matching");
            }
            else
            {
                string expvalue = AngularFunction.returnDateMMDDYYYY();
                string actvalue;
                By ele = By.XPath("//span[@test-id='transaction-span-userModified']");
                actvalue = Browser.Wd.FindElement(ele).Text.Split(" ")[0];

                Assert.AreEqual(expvalue, actvalue, " Both Values are not matching");
            }
        }


        [Then(@"Verify View Edit Member page User Modified Field displayed as ""(.*)""")]
        public void ThenVerifyViewEditMemberPageUserModifiedFieldDisplayedAs(string p0)
        {
            if (p0.Equals(""))
            {
                string expvalue = p0;
                string actvalue;
                By ele = By.XPath("//span[@test-id='memberInfo-span-userModified']");
                actvalue = Browser.Wd.FindElement(ele).Text;

                Assert.AreEqual(expvalue, actvalue, " Both Values are not matching");
            }
            else
            {
                string expvalue = AngularFunction.returnDateMMDDYYYY();
                string actvalue;
                By ele = By.XPath("//span[@test-id='memberInfo-span-userModified']");
                actvalue = Browser.Wd.FindElement(ele).Text.Split(" ")[0];

                Assert.AreEqual(expvalue, actvalue, " Both Values are not matching");
            }
        }


        [Then(@"Verify View Edit Member page OEC Sales section OEC Submit Time is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageOECSalesSectionOECSubmitTimeIsSetTo(string expected)
        {
            By fileDate = By.XPath("//input[@test-id='oecSales-txt-oecSubmitTime']");

            string actual = Browser.Wd.FindElement(fileDate).GetAttribute("value");

            Assert.AreEqual(expected, actual);
        }

        [Then(@"Verify View Edit Transaction page Signature Date is set to ""(.*)""")]
        public void ThenVerifyViewEditTransactionPageSignatureDateIsSetTo(string expected)
        {
            By fileDate = By.XPath("//kendo-datepicker[@test-id='DemographicDetailsSignatureDate']//input");

            string actual = Browser.Wd.FindElement(fileDate).GetAttribute("value");

            Assert.AreEqual(expected, actual);
        }

        [Then(@"Verify View Edit Member page Transaction section TC ""(.*)"" Plan ID ""(.*)"" PBP ""(.*)"" Trans Status ""(.*)"" Program Source ""(.*)"" is Clicked")]
        public void ThenVerifyViewEditMemberPageTransactionSectionTCPlanIDPBPTransStatusProgramSourceIsClicked(string p0, string p1, string p2, string p3, string p4)
        {
            string tc = tmsCommon.GenerateData(p0);
            string plan = tmsCommon.GenerateData(p1);
            string pbp = tmsCommon.GenerateData(p2);
            string transstatus = tmsCommon.GenerateData(p3);
            string source = tmsCommon.GenerateData(p4);

            By ele = By.XPath("//kendo-grid[@test-id='transactions-grid-memberTransactionsGrid']//td[contains(.,'"+tc+"')]/following-sibling::td[contains(.,'"+plan+"')]/following-sibling::td[contains(.,'"+pbp+"')]/following-sibling::td[contains(.,'"+ transstatus + "')]/following-sibling::td[contains(.,'"+source+ "')]/following-sibling::td/a");
            AngularFunction.clickOnElement(ele);

        }


        [Then(@"Verify View Edit Member page Plan Defined Fields section Use Mapping check box is ""(.*)""")]
        public void ThenVerifyViewEditMemberPagePlanDefinedFieldsSectionUseMappingCheckBoxIs(string p0)
        {
            By checkBox = By.CssSelector("[test-id='planDefinedFields-chk-useMapping']");
            bool checkStatus = false;
            if (p0.ToLower().Equals("checked"))
            {
                 checkStatus = Browser.Wd.FindElement(checkBox).Selected;
                Assert.IsTrue(checkStatus);
            }
            else
            {
                checkStatus = Browser.Wd.FindElement(checkBox).Selected;
                Assert.IsFalse(checkStatus);
            }
            
        }


        [Then(@"Verify Members View Edit Eligibility Tab Country Code has a default value set to ""(.*)""")]
        public void ThenVerifyMembersViewEditEligibilityTabCountryCodeHasADefaultValueSetTo(string p0)
        {
            string CountryCode = EAM.MembersViewEditEligibilityTab.CountryCode.Text;            
            Assert.IsTrue(EAM.MembersViewEditEligibilityTab.CountryCode.Enabled == false, "Passed" + "CountryCode {0} set to expected value", false);
        }

        [When(@"EAM Home page Acknowledgment of Enrollment Letter queue is Clicked")]
        public void WhenEAMHomePageAcknowledgmentOfEnrollmentLetterQueueIsClicked()
        {
            tmsWait.Hard(5);
            IWebElement queue = Browser.Wd.FindElement(By.XPath("//table//td[contains(.,'letters in Acknowledgment of Enrollment Letter queue')]/preceding-sibling::td/a"));
            fw.ExecuteJavascript(queue);
        }

        [When(@"Verify Letter Template is set for Plan ID")]
        public void WhenVerifyLetterTemplateIsSetForPlanID()
        {
            IWebElement drp = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboPlan"));
            IWebElement Go = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnGo"));
            
            IWebElement checkbox = Browser.Wd.FindElement(By.XPath("(//table[@id='ctl00_ctl00_MainMasterContent_MainContent_dgLetters']//tr//td//input[@type='checkbox'])[1]"));
            int i = 1;
            while(!checkbox.Selected)
            {
                new SelectElement(drp).SelectByIndex(i);
                tmsWait.Hard(2);
                fw.ExecuteJavascript(Go);
                tmsWait.Hard(3);
                i++;
                checkbox = Browser.Wd.FindElement(By.XPath("(//table[@id='ctl00_ctl00_MainMasterContent_MainContent_dgLetters']//tr//td//input[@type='checkbox'])[1]"));
            }
            
        }


        [When(@"Letter Queue Acknowledgment of Enrollment Letter page DeSelect All button is Clicked")]
        public void WhenLetterQueueAcknowledgmentOfEnrollmentLetterPageDeSelectAllButtonIsClicked()
        {
            IWebElement queue = Browser.Wd.FindElement(By.XPath("//a[@id='ctl00_ctl00_MainMasterContent_MainContent_lnkDeSelectAll']"));
            fw.ExecuteJavascript(queue);

            tmsWait.Hard(5);
        }

        [When(@"Letter Queue Acknowledgment of Enrollment Letter page Send Checkbox is Clicked")]
        public void WhenLetterQueueAcknowledgmentOfEnrollmentLetterPageSendCheckboxIsClicked()
        {
            IWebElement queue = Browser.Wd.FindElement(By.XPath("(//table[@id='ctl00_ctl00_MainMasterContent_MainContent_dgLetters']//input[@type='checkbox'])[1]"));
            fw.ExecuteJavascript(queue);

        }

        [When(@"Letter Queue Acknowledgment of Enrollment Letter page ""(.*)"" Send Checkbox is Clicked")]
        public void WhenLetterQueueAcknowledgmentOfEnrollmentLetterPageSendCheckboxIsClicked(string p0)
        {
            string mbi = tmsCommon.GenerateData(p0);
            tmsWait.Hard(2);
            IWebElement queue = Browser.Wd.FindElement(By.XPath("(//table[@id='ctl00_ctl00_MainMasterContent_MainContent_dgLetters']//tr/td[contains(.,'"+ mbi + "')]/parent::tr//td//input)[1]"));
            fw.ExecuteJavascript(queue);
        }


        [When(@"Letter Queues page Preview Button is Clicked")]
        public void WhenLetterQueuesPagePreviewButtonIsClicked()
        {
            IWebElement button = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnPreview"));
            fw.ExecuteJavascript(button);
            tmsWait.Hard(10);
            Browser.SwitchToChildWindow();
            Browser.SwitchToIFrame();            
            string reportPagesource = Browser.Wd.PageSource;
            string reportURL = Browser.Wd.FindElement(By.Id("plugin")).GetAttribute("src");
            if (reportURL != null)
            {
                Assert.IsTrue(true, " Letter is Previewed successfully");
            }

        }


        [When(@"Letter Queue Acknowledgment of Enrollment Letter page Generate Letters button is Clicked")]
        [Then(@"Letter Queue Acknowledgment of Enrollment Letter page Generate Letters button is Clicked")]
        [Given(@"Letter Queue Acknowledgment of Enrollment Letter page Generate Letters button is Clicked")]
        public void WhenLetterQueueAcknowledgmentOfEnrollmentLetterPageGenerateLettersButtonIsClicked()
        {
            IWebElement queue = Browser.Wd.FindElement(By.XPath("//input[@id='ctl00_ctl00_MainMasterContent_MainContent_btnGenerateLetters']"));
            fw.ExecuteJavascript(queue);
        }

        [When(@"Letter Queue page Letter Generation Job Rquest is Noted")]
        [Given(@"Letter Queue page Letter Generation Job Rquest is Noted")]
        [Then(@"Letter Queue page Letter Generation Job Rquest is Noted")]
        public void WhenLetterQueuePageLetterGenerationJobRquestIsNoted()
        {
            IWebElement msg = Browser.Wd.FindElement(By.XPath("//span[@class='messageTextInfo']"));

            string[] jobID = msg.Text.Split(':');

            ScenarioContext.Current.Add("JobID", jobID[1]);
            fw.ConsoleReport(" Letter Generation Job Id -->" + jobID[1]);

        }
        [When(@"Root Administration page Manage Configuration is Clicked for Tenant")]
        public void WhenRootAdministrationPageManageConfigurationIsClickedForTenant()
        {

            string[] URLParts = ConfigFile.URL.Split('/');
            string newTenant = (URLParts[2].Split('.'))[0].ToUpper();
            GlobalRef.Tenant = newTenant;
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By tmsTenant = By.XPath("//*[@id='TenantSetupFrm']/div/div[3]/div/kendo-grid/div//td[contains(.,'" + newTenant + "')]/following-sibling::td/a[contains(.,'Manage Configuration')]");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(tmsTenant);
                tmsWait.Hard(5);
            }
            else
            {
                By tmsTenant = By.XPath("//div[@test-id='tenantSetup-grid-grdTenantSetUp']//td[contains(.,'" + newTenant + "')]/following-sibling::td/a[contains(.,'Manage Configuration')]");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(tmsTenant);
                tmsWait.Hard(5);
            }
               

        }

        [When(@"PIR Response Fallout Report Folder Path is noted")]
        public void WhenPIRResponseFalloutReportFolderPathIsNoted()
        {
            string tenant = GlobalRef.Tenant.ToString();
            By fileRootPath = By.CssSelector("[test-id='manageConfiguration-txt-fileRootPath']");
            string RootPath = UIMODUtilFunctions.returnValuefromWebComponentUsingGetAttribute(Browser.Wd.FindElement(fileRootPath));
            string falloutReportPath = RootPath +"\\"+ tenant+"\\RAMX\\Input\\Upload\\PIRResponse\\Fallout\\";
            GlobalRef.falloutReportPath = falloutReportPath;

            fw.ConsoleReport(" RAMx fallout report Path -->" + falloutReportPath);
            
        }

        [When(@"RAMX CMS Extract Report Folder Path is noted")]
        public void WhenRAMXCMSExtractReportFolderPathIsNoted()
        {
            By fileRootPath;
            string tenant = GlobalRef.Tenant.ToString();
           
            fileRootPath = By.CssSelector("[test-id='manageConfiguration-txt-fileRootPath']");
            string RootPath = UIMODUtilFunctions.returnValuefromWebComponentUsingGetAttribute(Browser.Wd.FindElement(fileRootPath));
            string falloutReportPath = RootPath + "\\" + tenant + "\\RAMX\\Output";
            GlobalRef.cmsextractPath = falloutReportPath;
        }

        [When(@"Root Administration page Manage Configuration Back to Record link is clicked")]
        public void WhenRootAdministrationPageManageConfigurationBackToRecordLinkIsClicked()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@test-id='manageConfiguration-span-back']")));
            tmsWait.Hard(3);
        }



        [When(@"TMS Shared Folder Letter Path noted for Letter Name as ""(.*)"" Plan as ""(.*)"" PBP ID as ""(.*)""")]
        public void WhenTMSSharedFolderLetterPathNotedForLetterNameAsPlanAsPBPIDAs(string p0, string p1, string p2)
        {
            string letterName = tmsCommon.GenerateData(p0);
            string planID = tmsCommon.GenerateData(p1);
            string PBPID = tmsCommon.GenerateData(p2);
            string jobID = GlobalRef.JobID.ToString().Trim();
            string tenant = GlobalRef.Tenant.ToString();
            By fileRootPath = By.CssSelector("[test-id='manageConfiguration-txt-fileRootPath']");
            string RootPath = UIMODUtilFunctions.returnValuefromWebComponentUsingGetAttribute(Browser.Wd.FindElement(fileRootPath));
            string LetterNameinServer=jobID+"_"+letterName+"_"+planID+"_" + PBPID+".pdf";
            string path = RootPath + "\\" + tenant + "\\EAM\\Letter\\" + LetterNameinServer;
            fw.ConsoleReport(" Letter Path -->" + path);
           GlobalRef.PDFPath = path;
        }
        [Then(@"Verify Letter PDF displayed content ""(.*)""")]
        public void ThenVerifyLetterPDFDisplayedContent(string p0)
        {
            string letterName = GlobalRef.PDFPath.ToString();
            string letterValidationText = tmsCommon.GenerateData(p0);
                tmsWait.Hard(10);
                string pdfText = ReadFileFunctions.ReadPDFFile(letterName);
                Assert.IsTrue(pdfText.ToUpper().Contains(letterValidationText), "PDF File missed expected data. Failed...");
          

        }


        [When(@"Framework page Jobs section is Clicked")]
        public void WhenFrameworkPageJobsSectionIsClicked()
        {
            IWebElement msg = Browser.Wd.FindElement(By.XPath("//a[@title='Jobs']"));
            fw.ExecuteJavascript(msg);
         }


        [Then(@"Verify Members View Edit Eligibility Tab State Code has a default value set to ""(.*)""")]
        public void ThenVerifyMembersViewEditEligibilityTabStateCodeHasADefaultValueSetTo(string p0)
        {
            string StateCode = EAM.MembersViewEditEligibilityTab.StateCode.Text;
            Assert.IsTrue(EAM.MembersViewEditEligibilityTab.StateCode.Enabled == false, "Passed" + "StateCode {0} set to expected value", false);   
        }

        [Then(@"Verify Members View Edit Eligibility Tab Date of Death has a default value set to ""(.*)""")]
        public void ThenVerifyMembersViewEditEligibilityTabDateOfDeathHasADefaultValueSetTo(string p0)
        {
            string DateOfDeath = EAM.MembersViewEditEligibilityTab.DateOfDeath.Text;
            Assert.IsTrue(EAM.MembersViewEditEligibilityTab.DateOfDeath.Enabled == false, "Passed" + "DateOfDeath {0} set to expected value", false);    
        }

        [Then(@"Verify Members View Edit Eligibility Tab ESRD has a default value set to ""(.*)""")]
        public void ThenVerifyMembersViewEditEligibilityTabESRDHasADefaultValueSetTo(string p0)
        {
            string ESRD = EAM.MembersViewEditEligibilityTab.ESRD.Text;
            Assert.IsTrue(EAM.MembersViewEditEligibilityTab.ESRD.Enabled == false, "Passed" + "ESRD {0} set to expected value", false);                
        }

        [Then(@"Verify Members View Edit Eligibility Tab CMSPartAEff has a default value set to ""(.*)""")]
        public void ThenVerifyMembersViewEditEligibilityTabCMSPartAEffHasADefaultValueSetTo(string p0)
        {
            string CMSPartAEff = EAM.MembersViewEditEligibilityTab.CMSPartAEff.GetAttribute("value");
            Assert.IsTrue(CMSPartAEff == p0, "Passed" + "CMSPartAEff is default set to :{0}", CMSPartAEff);
        }

        [Then(@"Verify Members View Edit Eligibility Tab CMSPartAEnd has a default value set to ""(.*)""")]
        public void ThenVerifyMembersViewEditEligibilityTabCMSPartAEndHasADefaultValueSetTo(string p0)
        {
            string CMSPartAEnd = EAM.MembersViewEditEligibilityTab.CMSPartAEnd.GetAttribute("value");
            Assert.IsTrue(CMSPartAEnd == p0, "Passed" + "CMSPartAEff is default set to :{0}", CMSPartAEnd);
        }

        [When(@"ReportsEligibility Passed Page PlanId is set to ""(.*)""")]
        public void WhenReportsEligibilityPassedPagePlanIdIsSetTo(string p0)
        {
            SelectElement PlanId = new SelectElement(EAM.MembersViewEditEligibilityTab.PlanId);
            PlanId.SelectByText(p0);
            
        }


        [Then(@"Verify Members View Edit Eligibility Tab CMSPartBEff has a default value set to ""(.*)""")]
        public void ThenVerifyMembersViewEditEligibilityTabCMSPartBEffHasADefaultValueSetTo(string p0)
        {
            string CMSPartBEff = EAM.MembersViewEditEligibilityTab.CMSPartBEff.GetAttribute("value");
            Assert.IsTrue(CMSPartBEff == p0, "Passed" + "CMSPartAEff is default set to :{0}", CMSPartBEff);
        }

        [Then(@"Verify Members View Edit Eligibility Tab CMSPartBEnd has a default value set to ""(.*)""")]
        public void ThenVerifyMembersViewEditEligibilityTabCMSPartBEndHasADefaultValueSetTo(string p0)
        {
            string CMSPartBEnd = EAM.MembersViewEditEligibilityTab.CMSPartBEnd.GetAttribute("value");
            Assert.IsTrue(CMSPartBEnd == p0, "Passed" + "CMSPartAEff is default set to :{0}", CMSPartBEnd);
        }

        [When(@"Members View Edit Transactions Tab Table row Edit Image is clicked")]
        public void WhenMembersViewEditTransactionsTabTableRowEditImageIsClicked(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.MembersNewTabTransactions.TransactionsTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                IList<IWebElement> theseImages = ApplicationRow.Element[0].FindElements(By.TagName("img"));
                                foreach (IWebElement thisImage in theseImages)
                                { 
                                    if (thisImage.GetAttribute("src").Contains("gotoIcon.gif"))
                                    {
                                        thisImage.Click();
                                    }
                                }
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.MembersNewTabTransactions.TransactionsTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }

        [Then(@"Verify Member View Edit Page RXBilling Tab Credit Cover has a default value set to ""(.*)""")]
        public void ThenVerifyMemberViewEditPageRXBillingTabCreditCoverHasADefaultValueSetTo(string p0)
        {

            SelectElement CreditCover = new SelectElement(EAM.MembersNewTabRXBilling.CreditCover);

            Assert.IsTrue(EAM.MembersNewTabRXBilling.CreditCover.Enabled == true, "Passed" + "CreditCover field is enabled");
            Assert.AreEqual(p0, CreditCover.SelectedOption.Text, "Passed" + "CreditCover default value is {0}", CreditCover.SelectedOption.Text);

        }

        [Then(@"Verify Member View Edit Page RXBilling Tab Uncovered Months has a default value set to ""(.*)""")]
        public void ThenVerifyMemberViewEditPageRXBillingTabUncoveredMonthsHasADefaultValueSetTo(string p0)
        {
            
            Assert.IsTrue(EAM.MembersNewTabRXBilling.UncoveredMonths.Enabled == true, "Passed" + "UncoveredMonths field is enabled");
            Assert.IsTrue(EAM.MembersNewTabRXBilling.UncoveredMonths.Text == p0);
            Assert.IsTrue(true,"Uncovered Months is set to {0}",p0);            
        }

        [Then(@"Verify Members View Edit Transactions Tab Table has row")]
        public void ThenVerifyMembersViewEditTransactionsTabTableHasRow(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.MembersNewTabTransactions.TransactionsTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]" )
                                    {
                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.MembersNewTabTransactions.TransactionsTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }
        [When(@"Member Page Span Tab is Clicked")]
        public void WhenMemberPageSpanTabIsClicked()
        {
            
        }

        [When(@"EAMConfiguration ""(.*)"" link is clicked")]
        public void GivenEAMConfigurationLinkIsClicked(string p0)
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement ele = Browser.Wd.FindElement(By.XPath("//label[contains(text(),'" + p0 + "')]"));
                fw.ExecuteJavascript(ele);
            }
            else
            {
                fw.ExecuteJavascript(EAM.BuisnessRulesFields.BuisnessRuleLink);
            }
        }

        [When(@"Verify EAMConfiguration business rule Address validation checkbox is checked")]
        public void GivenVerifyEAMConfigurationBusinessRuleAddressValidationCheckboxIsChecked()
        {
            ReUsableFunctions.CheckBoxOperations(EAM.BuisnessRulesFields.AddToServiceAreaSCCcodeValidation,"checked");
            fw.ExecuteJavascript(EAM.BuisnessRulesFields.SaveButton);


            //tmsWait.Hard(5);
            //string checkedvalue = EAM.BuisnessRulesFields.AddToServiceAreaSCCcodeValidation.GetAttribute("checked");
            //Boolean mycheck = false;
            //if (checkedvalue == "true")
            //{
            //    mycheck = true;
            //}
            //else
            //{
            //    fw.ExecuteJavascript(EAM.BuisnessRulesFields.AddToServiceAreaSCCcodeValidation);
            //    fw.ExecuteJavascript(Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSaveOthers")));
            //    tmsWait.Hard(3);
            //}

            //Assert.IsTrue(mycheck);
        }

        [Then(@"Verify Member view edit page SCC ""(.*)"" is displayed readonly")]
        public void ThenVerifyMemberViewEditPageSCCIsDisplayedReadonly(int sccvalue)
        {
           
            string ac = EAM.MembersViewEdit.MemberViewEditSCC.GetAttribute("value");
            int actualscc = Int32.Parse(ac);
            Assert.AreEqual(sccvalue, actualscc , "SCC value for member does not match");
            Assert.IsFalse(EAM.MembersViewEdit.MemberViewEditSCC.Enabled, "SCC field is not disabled");
            tmsWait.Hard(1);
        }

        [Then(@"View Edit Member page Zip value ""(.*)"" is displayed")]
        public void ThenViewEditMemberPageZipValueIsDisplayed(int zipvalue)
        {
            string az = EAM.MembersViewEdit.MemberViewEditResidenceZip.GetAttribute("value");
            int actualzip = Int32.Parse(az);
            Assert.AreEqual(zipvalue, actualzip, "Zip is incorrect");
            tmsWait.Hard(1);
        }

        [Then(@"View Edit Member page county ""(.*)"" is displayed")]
        public void ThenViewEditMemberPageCountyIsDisplayed(string county)
        {
            Assert.AreEqual(county, EAM.MembersViewEdit.MemberViewEditCountyName.GetAttribute("value"), "County is not expected");
            tmsWait.Hard(1);
        }

    }
}
