﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using OpenQA.Selenium.Support.UI;


namespace TMSoR1.FrameworkCode.EAM
{
    class cfERFAttestationQuestion
    {
        TMSoR1.ERF ERFObj = new ERF();
        public string CalculateDate(string month, string Day, string Year)
        {
            string calculatedDate = "";
            DateTime current = DateTime.Now;
            if(month.Contains('+') || month.Contains('-')) month = current.AddMonths(Int32.Parse(month)).ToString("MM"); else month = month;
            if (Day.Contains('+') || Day.Contains('-')) Day = current.AddDays(Int32.Parse(Day)).ToString("dd"); else Day = Day;
            if (Year.Contains('+') || Year.Contains('-')) Year = current.AddYears(Int32.Parse(Year)).ToString("yyyy"); else Year = Year;

            calculatedDate = month + "/" + Day + "/" + Year;
            return calculatedDate;
        }
        public void SwitchToERFFrame()
        {
            int size = Browser.Wd.FindElements(OpenQA.Selenium.By.TagName("iFrame")).Count();
            Browser.Wd.SwitchTo().Frame(size - 1);
            //Browser.Wd.SwitchTo().Frame(ERFObj.ERFFrame);
        }
        public void SwitchToEAMFrame()
        {
            Browser.Wd.FindElements(By.Id("sideNavigationContainer"));
            Browser.Wd.SwitchTo().ParentFrame();
            //Browser.Wd.SwitchTo().Frame(ERFObj.ERFFrame);
        }
    }
}
