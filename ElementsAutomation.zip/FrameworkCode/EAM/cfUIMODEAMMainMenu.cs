﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
namespace TMSoR1
{
    class cfUIMODEAMMainMenu
    {
        public static MainMenu MainMenu { get { return new MainMenu(); } }
    }

    [Binding]
    public class MainMenu
    {
        public IWebElement Main { get { return Browser.Wd.FindElement(By.CssSelector("[title='Main']")); } }
        public IWebElement NewMember { get { return Browser.Wd.FindElement(By.CssSelector("[title='New Member']")); } }

        public IWebElement ViewEditMember { get { return Browser.Wd.FindElement(By.CssSelector("[title='View/Edit Member']")); } }
        public IWebElement TC90 { get { return Browser.Wd.FindElement(By.CssSelector("[title='TC 90']")); } }
        public IWebElement ExpandMenu { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='header-btn-expanMenu']")); } }
    }

    }
