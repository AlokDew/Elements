﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows;
using System.Drawing;
using OpenQA.Selenium.Support.UI;
using System.Collections.ObjectModel;
using TMSoR1.FrameworkCode;
//using System.Windows.Forms;


namespace TMSoR1
{
    [Binding]
    public class EAMLetters
    {
        /*
         *  All following methods and elements are equal for all Letters pages so there is no need to create separate keywords for each Letter page
         * */
        
        [When(@"Letters Plan ID is set to ""(.*)""")]
        public void WhenLettersPlanIDIsSetTo(string p0)
        {
            string strID = EAM.Letters.PBP.GetAttribute("id");

            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.Letters.PlanID);
            select.SelectByText(GeneratedData);

            tmsWait.Hard(2);
            tmsWait.WaitForReadyStateComplete(30);
            tmsWait.WaitForElementExist(By.Id(strID), 30);
            try
            {
                EAM.Letters.PBP.Click();
                EAM.Letters.PBP.Click();
            }
            catch (Exception) { }
            tmsWait.Hard(2);
            tmsWait.WaitForReadyStateComplete(30);

        }

        [When(@"I navigate to EAM ""(.*)"" section Click on ""(.*)""")]
        public void WhenINavigateToEAMSectionClickOn(string p0, string nameofLetter)
        {
            AngularFunction.clickOnElement(cfUIMODLetters.LettersCollections.LettersSection);

            By lettername = By.XPath("//span[contains(text(),'"+ nameofLetter + "')]");
            AngularFunction.clickOnElement(lettername);
        }

        [When(@"Letters Queue Page Plan ID is set to ""(.*)""")]
        public void WhenLettersQueuePagePlanIDIsSetTo(string p0)
        {
            string plan = tmsCommon.GenerateData(p0);
            AngularFunction.selectKendoDropDownValue(cfUIMODLetters.LettersCollections.PlanID, plan);
        }

        [When(@"Letters Queue Page PBP ID is set to ""(.*)""")]
        public void WhenLettersQueuePagePBPIDIsSetTo(string p0)
        {
            string pbp = tmsCommon.GenerateData(p0);
            AngularFunction.selectKendoDropDownValue(cfUIMODLetters.LettersCollections.PBPID, pbp);
        }

        [When(@"Letters Queue Page SEARCH button is clicked")]
        public void WhenLettersQueuePageSEARCHButtonIsClicked()
        {
            AngularFunction.clickOnElement(cfUIMODLetters.LettersCollections.SearchButton);
        }

        [Then(@"Verify Letters page displayed ""(.*)""")]
        public void ThenVerifyLettersPageDisplayed(string p0)
        {
            string mbi = tmsCommon.GenerateData(p0);
            By elementPresence = By.XPath("//kendo-grid[@test-id='letterQueue-grid-resultsGrid']//tr//td[contains(.,'"+ mbi + "')]");
            AngularFunction.elementPresenceUsingLocators(elementPresence);


        }

        [When(@"Letters PBP is set to ""(.*)""")]
        public void WhenLettersPBPIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.Letters.PBP);
            select.SelectByText(GeneratedData);

            tmsWait.Hard(1);
            tmsWait.WaitForReadyStateComplete(30);
        }

        [When(@"EAM Letter Queue page ""(.*)"" Letter count is noted")]
        public void WhenEAMLetterQueuePageLetterCountIsNoted(string letter)
        {
            tmsWait.Hard(1);
            IWebElement lettercounts = Browser.Wd.FindElement(By.XPath("//table//td[contains(.,'"+letter+"')]/preceding-sibling::td/a"));
            GlobalRef.BeforeLetter = lettercounts.Text;

        }

        [Then(@"Verify EAM Letter Queue page ""(.*)"" Letter count is decreased")]
        public void ThenVerifyEAMLetterQueuePageLetterCountIsDecreased(string p0)
        {
            int beforecount = Convert.ToInt32(GlobalRef.BeforeLetter.ToString());
            IWebElement lettercounts = Browser.Wd.FindElement(By.XPath("//table//td[contains(.,'"+p0+"')]/preceding-sibling::td/a"));
            int aftercount = Convert.ToInt32(lettercounts.Text);
            bool results = (aftercount < beforecount);
            Assert.IsTrue(results, " Both Letter counts are not matching");
            

        }

        [When(@"EAM Home page Letter ""(.*)"" is Clicked")]
        public void WhenEAMHomePageLetterIsClicked(string p0)
        {
            IWebElement lettercounts = Browser.Wd.FindElement(By.XPath("//table//td[contains(.,'"+p0+"')]/preceding-sibling::td/a"));
            fw.ExecuteJavascript(lettercounts);
        }

        [When(@"Open Actions for tms admin page Mark As Complete Cross mark is Clicked")]
        public void WhenOpenActionsForTmsAdminPageMarkAsCompleteCrossMarkIsClicked()
        {
            IWebElement markascomplete= Browser.Wd.FindElement(By.XPath("(//a/img[@alt='Mark As Complete'])[1]"));
            fw.ExecuteJavascript(markascomplete);

        }

        [When(@"Please Set Complete Date dialog OK button is Clicked")]
        public void WhenPleaseSetCompleteDateDialogOKButtonIsClicked()
        {
            IWebElement OK = Browser.Wd.FindElement(By.XPath("(//button[@role='button'])[1]"));
            fw.ExecuteJavascript(OK);
        }


        [When(@"Letters Language is set to ""(.*)""")]
        public void WhenLettersLanguageIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.Letters.Language);
            select.SelectByText(GeneratedData);

            tmsWait.Hard(1);
            tmsWait.WaitForReadyStateComplete(30);
        }


        [When(@"Letters Go button is clicked")]
        public void WhenLettersGoButtonIsClicked()
        {
            EAM.Letters.GoButton.Click();
            tmsWait.Hard(4);
            tmsWait.WaitForReadyStateComplete(30);
        }


        [Then(@"Verify Letters Table does not have row HIC ""(.*)""")]
        public void ThenVerifyLettersTableDoesNotHaveRowHIC(string p0)
        {
            tmsWait.Hard(4);
            bool nextPage;
            int index = 1;
            string hicToSerach= tmsCommon.GenerateData(p0);
            var pageCount= Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dgLetters")).FindElements(By.TagName("a")).Count;
            do
            {
                nextPage = VerifyHIC(hicToSerach);
                if (nextPage)
                {
                    index++;
                    if (index > pageCount)
                    {
                        Assert.IsTrue(true);
                        break;
                    }
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//tr[@class='pgn']//a[contains(.,'" + index + "')]")));
                }
            } while (nextPage);
        }

        public bool VerifyHIC(string hic)
        {
            try
            {
                if (Browser.Wd.FindElement(By.XPath("//td[contains(.,'" + hic + "')]")).Displayed)
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                return true;
            }
            return true;
        }

        
        [Then(@"Verify Letters Table does not have row")]
        [Then(@"Verify Letters Table does not have rows")]
        public void ThenVerifyLettersTableDoesNotHaveRow(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.Letters.LettersTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index >= 0)
                        {
                            Assert.Fail("Expected row [{0}] was found but should NOT {1}: ", i + 1, arrRes[i, 1]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Verify Letters Table does not have rows: {0}", e.Message);
            }
        }

        [Then(@"Verify Letters Table has row")]
        public void ThenVerifyLettersTableHasRow(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.Letters.LettersTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row was not found: {0}", arrRes[i, 1]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Verify Letters Table has row: {0}", e.Message);
            }
        }

        [Then(@"Verify Letters Table has Not displaye row")]
        public void ThenVerifyLettersTableHasNotDisplayeRow(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.Letters.LettersTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.IsTrue(true,"Expected row was not found: {0}", arrRes[i, 1]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.IsTrue(true,"Verify Letters HIC is not display: {0}", e.Message);
            }
        }

        [Then(@"Verify Letters Table does Not display row")]
        public void ThenVerifyLettersTableDoesNotDisplayRow(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.Letters.LettersTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index > 0)
                        {
                            Assert.Fail("Expected row was found: {0}", arrRes[i, 1]);
                         }
                    }
                }
            }
            catch (Exception e)
            {
                //Assert.Fail("Verify Letters HIC is not display: {0}", e.Message);
            }
        }


        [Then(@"Verify Letters Post-CMS Loss of Part AB table has row")]
        public void ThenVerifyLettersPost_CMSLossOfPartABTableHasRow(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.LettersPostCMS.LettersTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.LettersPostCMS.LettersTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }
        [When(@"Letters Letter Page Find Search Page for ""(.*)""")]
        public void WhenLettersLetterPageFindSearchPageFor(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            EAM.Letters.LetterSpyGlass.Click();
            tmsWait.Hard(1);
            EAM.Letters.LetterSearchText.SendKeys(GeneratedData);
            EAM.Letters.LetterHighlightAll.Click();
            EAM.Letters.LetterFindNext.Click();
        //    EAM.Letters.LetterHighlightAll.Click();
            tmsWait.Hard(2);

        }

        [Then(@"Verify Letters Letter Page Address 1 is set to ""(.*)""")]
        public void ThenVerifyLettersLetterPageAddress1IsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string[] divText = new string[2500];
            Single[] divLeft = new Single[2500];
            int counter = 0;
    //        IList<IWebElement> allDivs = EAM.Letters.LetterPage.FindElements(By.TagName("div"));
            IList<IWebElement> allDivs = EAM.Letters.LetterPage.FindElements(By.TagName("div"));
            //Make a Div Data class
            //include the text, the Style Left, etc..
            //Spin through.. if the next left is less than this left, we have a new line??
            foreach (IWebElement thisDiv in allDivs)
            {
                divText[counter] = thisDiv.Text;
                string strStyleAttr = thisDiv.GetAttribute("style");
                string[] styleParts = strStyleAttr.Split(';');
                foreach (string thisPart in styleParts)
                {
                    if (thisPart.Contains("left"))
                    {
                        string[] leftParts = thisPart.Split(':');
                        string[] leftValueParts = leftParts[1].Split('p');
                        float thisLeftValue = Convert.ToSingle(leftValueParts[0]);
                        divLeft[counter] = thisLeftValue;
                    }
                }
                counter++;

            }

            Boolean foundCorrectItem = false;
            for (int i = 0; i <= counter; i++)
            {
                //Here we are checking that Address is found.   From there, next thing is 1 (Address 1)
                //And verifying the "Left" position of the 1 is greater than the left position of the Address
                //And verifying the Left postion of the address itself is > left position of the 1.
                //These left positions needing to be > happen because there is no line feed or anything else to 
                //check.   If the address is blank, that last div will be missing, thus the div which is i + 3
                //will be less than the left of the 1.  (yes, very complicated, so read again if it didn't make sense)
                //Daron
                if (divText[i] == "Address")
                {

                    Console.WriteLine("Text [" + divText[i] + "](" + divLeft[i] + "), P1 [" + divText[i + 1] + "](" + divLeft[i + 1] + "), P3 [" + divText[i + 3] + "](" + divLeft[i + 3] + ")");
                    Console.WriteLine("Text [" + divText[i] + "](" + divLeft[i] + "), P1 [" + divText[i + 1] + "](" + divLeft[i + 1] + "), P2 [" + divText[i + 2] + "](" + divLeft[i + 2] + ")");
                }

                if (divText[i] == "Address" && divText[i + 1].Contains("1") && divLeft[i + 1] > divLeft[i] && divText[i + 3] == GeneratedData && GeneratedData != "" && divLeft[i + 3] > divLeft[i + 1])
                {
                    foundCorrectItem = true;
                    break;
                }
                if (divText[i] == "Address" && divText[i + 1].Contains("1") && divLeft[i + 1] > divLeft[i] && divText[i + 2] == GeneratedData && GeneratedData != "" && divLeft[i + 2] > divLeft[i + 1])
                {
                    foundCorrectItem = true;
                    break;
                }
                if (divText[i] == "Address" && divText[i + 1].Contains("1") && divLeft[i + 1] > divLeft[i] && divText[i + 3] == GeneratedData && GeneratedData == "" && divLeft[i + 3] < divLeft[i + 1])
                {
                    foundCorrectItem = true;
                    break;
                }
            }
            string pagetextItems = "";
            for (int i = 0; i <= counter; i++)
            {
                pagetextItems += divText[i] + " | ";
            }
            pagetextItems = " - page text is cleared for reporting for now - ";
            Assert.AreEqual(true, foundCorrectItem, "Couldn't find address 1 set to [" + GeneratedData + "] in page data [" + pagetextItems + "]");
            Console.WriteLine("Found address 1 set to [" + GeneratedData + "] in page data [" + pagetextItems + "]");
        }

        [Then(@"Verify Letters Letter Page Address 2 is set to ""(.*)""")]
        public void ThenVerifyLettersLetterPageAddress2IsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            string[] divText = new string[2500];
            Single[] divLeft = new Single[2500];
            int counter = 0;
     //       IList<IWebElement> allDivs = EAM.Letters.LetterPage.FindElements(By.TagName("div"));
            IList<IWebElement> allDivs = EAM.Letters.LetterPage.FindElements(By.TagName("div"));
            //Make a Div Data class
            //include the text, the Style Left, etc..
            //Spin through.. if the next left is less than this left, we have a new line??
            try
            {
                foreach (IWebElement thisDiv in allDivs)
                {
                    divText[counter] = thisDiv.Text;
                    string strStyleAttr = thisDiv.GetAttribute("style");
                    string[] styleParts = strStyleAttr.Split(';');
                    foreach (string thisPart in styleParts)
                    {
                        if (thisPart.Contains("left"))
                        {
                            string[] leftParts = thisPart.Split(':');
                            string[] leftValueParts = leftParts[1].Split('p');
                            float thisLeftValue = Convert.ToSingle(leftValueParts[0]);
                            divLeft[counter] = thisLeftValue;
                        }
                    }
                    counter++;

                }
            }
            catch
            {
                allDivs = EAM.Letters.LetterPage.FindElements(By.TagName("div"));

                foreach (IWebElement thisDiv in allDivs)
                {
                    divText[counter] = thisDiv.Text;
                    string strStyleAttr = thisDiv.GetAttribute("style");
                    string[] styleParts = strStyleAttr.Split(';');
                    foreach (string thisPart in styleParts)
                    {
                        if (thisPart.Contains("left"))
                        {
                            string[] leftParts = thisPart.Split(':');
                            string[] leftValueParts = leftParts[1].Split('p');
                            float thisLeftValue = Convert.ToSingle(leftValueParts[0]);
                            divLeft[counter] = thisLeftValue;
                        }
                    }
                    counter++;

                }

            }
            Boolean foundCorrectItem = false;
            for (int i = 0; i <= counter; i++)
            {
                //Here we are checking that Address is found.   From there, next thing is 2 (Address 2)
                //And verifying the "Left" position of the 1 is greater than the left position of the Address
                //And verifying the Left postion of the address itself is > left position of the 2.
                //These left positions needing to be > happen because there is no line feed or anything else to 
                //check.   If the address is blank, that last div will be missing, thus the div which is i + 3
                //will be less than the left of the 1.  (yes, very complicated, so read again if it didn't make sense)
                //Daron

                if (divText[i] == "Address")
                {
                    Console.WriteLine("Text [" + divText[i] + "], P1 [" + divText[i + 1] + "], P3 [" + divText[i + 3] + "], Left Address[" + divLeft[i] + "], Left 1 [" + divLeft[i + 1] + "], left 3 [" + divLeft[i + 3] + "]");
                }
                if (GeneratedData.Length > 0)
                {

                    if (divText[i] == "Address" && divText[i + 1].Contains("2") && divLeft[i + 1] > divLeft[i] && divText[i + 3] == GeneratedData && divLeft[i + 3] > divLeft[i + 1])
                    {
                        foundCorrectItem = true;
                        break;
                    }
                    if (divText[i] == "Address" && divText[i + 1].Contains("2") && divLeft[i + 1] > divLeft[i] && divText[i + 2] == GeneratedData && GeneratedData != "" && divLeft[i + 2] > divLeft[i + 1])
                    {
                        foundCorrectItem = true;
                        break;
                    }

                }
                if (GeneratedData.Length == 0)
                {
                    if (divText[i] == "Address" && divText[i + 1].Contains("2") && divLeft[i + 1] > divLeft[i] && divLeft[i + 3] < divLeft[i + 1])
                    {
                        foundCorrectItem = true;
                        break;
                    }
                }
            }
            string pagetextItems = "";
            for (int i = 0; i <= counter; i++)
            {
                pagetextItems += divText[i] + " | ";
            }
            pagetextItems = " - page text is cleared for reporting for now - ";

            Assert.AreEqual(true, foundCorrectItem, "Couldn't find address 2 set to [" + GeneratedData + "] in page data [" + pagetextItems + "]");
            Console.WriteLine("Found address 2 set to [" + GeneratedData + "] in page data [" + pagetextItems + "]");
        }

        [When(@"Letter is closed")]
        public void LetterIsClosed()
        {
            try
            {
                LettersCommon.CloseLetter();
            }
            catch (Exception e)
            {
                Assert.Fail("Letter was not closed. Exception: {0}", e.Message);
            }

        }


        [When(@"Navigate to the Letter Page ""(.*)""")]
        public void ThenNavigateToTheLetterPage(string p0)
        {
            try
            {
                string GeneratedData = tmsCommon.GenerateData(p0);

                By letterViewBy = EAM.Letters.LetterPageDiv;
                string letterExpText = "";
                LettersCommon.SwitchToLettersWindow(letterViewBy, 30, letterExpText);


            }
            catch (Exception e) { Assert.Fail("Report Page Navigation failed: {0}", e.Message); }
        }


        [Given(@"I click on the ""(.*)""")]
        [Then(@"I click on the ""(.*)""")]
        [When(@"I click on the ""(.*)""")]
        public void ThenIClickOnThe(string p0)
        {
            tmsWait.Hard(2);
            IWebElement letterHomePage = EAM.Letters.LettersHomePageGrid;
            ReadOnlyCollection<IWebElement> allRows = letterHomePage.FindElements(By.TagName("tr"));
            foreach( IWebElement row in allRows )
            {
                if(row.Text.Contains(p0))
                {
                    ReadOnlyCollection<IWebElement> cells = row.FindElements(By.TagName("td"));

                    foreach (IWebElement cell in cells)
                    {
                        IWebElement letterLink = cell.FindElement(By.TagName("a"));
                        letterLink.Click();
                        break;
                    }
                    break;
                }
            }
            tmsWait.Hard(2);
        }

        [Given(@"Letter Page PlanID is set to ""(.*)""")]
        [Then(@"Letter Page PlanID is set to ""(.*)""")]
        [When(@"Letter Page PlanID is set to ""(.*)""")]
        public void ThenLetterPagePlanIDIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.Letters.PlanID);
            select.SelectByText(value);
            tmsWait.Hard(2);
        }

        [Given(@"Letter Page PBP is set to ""(.*)""")]
        [Then(@"Letter Page PBP is set to ""(.*)""")]
        [When(@"Letter Page PBP is set to ""(.*)""")]
        public void ThenLetterPagePBPIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.Letters.PBP);
            select.SelectByText(value);
            tmsWait.Hard(2);
        }

        [Then(@"the first mapped row is selected")]
        public void ThenTheFirstMappedRowIsSelected()
        {
            int countOfRows = Browser.Wd.FindElements(By.XPath("//*[@id='ctl00_ctl00_MainMasterContent_MainContent_dgLetters']/tbody/*/td[3]")).Count;
            IWebElement curRow = null;
            IWebElement curColumn = null;

            tmsWait.Hard(5);
            for (int index = 3; index < countOfRows + 1; index++)
            {
                curRow = Browser.Wd.FindElement(By.XPath(".//*[@id='ctl00_ctl00_MainMasterContent_MainContent_dgLetters']/tbody/tr[" + index + "]"));
                curColumn = curRow = Browser.Wd.FindElement(By.XPath(".//*[@id='ctl00_ctl00_MainMasterContent_MainContent_dgLetters']/tbody/tr[" + index + "]/td[6]"));
                tmsWait.Hard(2);
                IWebElement chkSend = curColumn.FindElement(By.TagName("input"));
                if(chkSend.Enabled)
                {
                    chkSend.Click();
                    break;
                }              

            }
        }

        [When(@"I Click on TZlogo")]
        public void WhenIClickOnTZlogo()
        {
            Navigation.TZlogo();
        }

        [When(@"I Click on Administration link")]
        public void WhenIClickOnAdministrationLink()
        {
            Navigation.selectAdministration();
            //selectAdministration();
            /*tmsWait.Implicit(3);
            IWebElement AdministrationPage = Browser.Wd.FindElement(By.Id("Navigation1_ProductMenu1_Menu1-menuItem000-subMenu-menuItem000"));
            AdministrationPage.Click();*/
        }

        [Then(@"Verify that the letter generation is complete")]
        public void ThenVerifyThatTheLetterGenerationIsComplete()
        {
            string jobId = GlobalRef.LettersJobId.ToString();
            int count = 0;
           
            while(count < 4 )
            {
                try
                {
                    IWebElement objWebTable = EAM.AdministrationJobsPage.JobsGrid;

                    //string allRows = objWebTable.FindElements(By.TagName("tr")).ToString();

                    ReadOnlyCollection<IWebElement> allRows = objWebTable.FindElements(By.TagName("tr")); 
                    foreach (IWebElement row in allRows)
                    {
                        if (row.Text.Contains(jobId))
                        {
                            IWebElement status = row.FindElement(By.XPath("./td[6]"));
                            tmsWait.Hard(2);
                            Assert.IsTrue(status.Text.Contains("Complete"));
                            break;
                        }
                    }
                    count = count + 1;
                }
                catch (StaleElementReferenceException e)
                {
                    e.ToString();
                    count = count + 1;
                }
               // count = count + 4;
            }

        }
        
        [Binding]
        public static class LettersCommon
        {
            /// <summary>
            /// MainWindowHandle - handle of current window
            /// </summary>
            public static string MainWindowHandle = "";
            /// <summary>
            /// ReportWindowHandle - handle of new opened window. Initialized if report window is found and is used in other methods like VerifyReportHasData, CloseReport etc.
            /// </summary>
            public static string LetterWindowHandle = "";

            /// <summary>
            /// Find window which is not the same as curent one and initialize MainWindowHandle, ReportWindowHandle with appropriate values.
            /// Waits until expected text appears.
            /// </summary>
            public static string SwitchToLettersWindow(By letterViewBy, int timeout, string expectedText)
            {
                tmsWait.Hard(2);
                string letterHandle = "", currentHandle = "";
                ReadOnlyCollection<string> windowHandles = Browser.Wd.WindowHandles;
                currentHandle = Browser.Wd.CurrentWindowHandle;

                if (MainWindowHandle == "")
                {
                    MainWindowHandle = currentHandle;
                }
                if (MainWindowHandle != currentHandle)
                {
                    if (LetterWindowHandle == "")
                    {
                        LetterWindowHandle = currentHandle;
                    }
                    return currentHandle;
                }

                LetterWindowHandle = "";

                foreach (string handle in windowHandles)
                {
                    if (handle != MainWindowHandle)
                    {
                        letterHandle = handle;
                        break;
                    }
                }
                for (int i = 0; i < 6; i++)
                {
                    try
                    {
                        Browser.Wd.SwitchTo().Window(letterHandle).SwitchTo().DefaultContent().SwitchTo().Frame(0);
                        break;
                    }
                    catch (Exception) { tmsWait.Hard(2); }
                }
                //for (int i = 0; i < 6; i++)
                //{
                //    try
                //    {
                //        new WebDriverWait(Browser.Wd.SwitchTo().Window(letterHandle).SwitchTo().DefaultContent().SwitchTo().Frame(0), TimeSpan.FromSeconds(timeout)).Until(drv => drv.FindElement(letterViewBy));
                //        break;
                //    }
                //    catch (Exception) { tmsWait.Hard(2); }
                //}
                //for (int i = 0; i < 6; i++)
                //{
                //    try
                //    {
                //        new WebDriverWait(Browser.Wd.SwitchTo().Window(letterHandle).SwitchTo().DefaultContent().SwitchTo().Frame(0), TimeSpan.FromSeconds(timeout)).Until(drv => drv.FindElement(letterViewBy).Text.Contains(expectedText));
                //        break;
                //    }
                //    catch (Exception) { tmsWait.Hard(2); }
                //}

      //          string reportText = Browser.Wd.SwitchTo().Window(letterHandle).SwitchTo().DefaultContent().SwitchTo().Frame(0).FindElement(letterViewBy).Text;
       //         Assert.IsTrue(reportText.Contains(expectedText), "letter was not opened");
                fw.ConsoleReport("letter was opened");

                LetterWindowHandle = letterHandle;
                return letterHandle;
            }


            /// <summary>
            /// Close Letter Window which handle is equal to the previously saved ReportWindowHandle.
            /// If ReportWindowHandle is empty, method will close first window which is not the same to the current window.
            /// ReportWindowHandle will be set to empty.
            /// </summary>
            public static void CloseLetter()
            {
                if (LetterWindowHandle == "")
                {
                    ReadOnlyCollection<string> windowHandles = Browser.Wd.WindowHandles;
                    MainWindowHandle = Browser.Wd.CurrentWindowHandle;

                    foreach (string handle in windowHandles)
                    {
                        if (handle != MainWindowHandle)
                        {
                            LetterWindowHandle = handle;
                            break;
                        }
                    }
                }

                Browser.Wd.SwitchTo().Window(LetterWindowHandle).Close();
                Browser.Wd.SwitchTo().Window(MainWindowHandle);
                fw.ConsoleReport("Letter was closed");
                LetterWindowHandle = "";
            }
        }
    }
}

