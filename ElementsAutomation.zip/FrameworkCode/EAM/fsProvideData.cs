﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using OpenQA.Selenium.Support.UI;
using TMSoR1.FrameworkCode.EAM;

namespace TMSoR1
{
    [Binding]
    class fsProvideData
    {
        [Then(@"PCP IPA Lookup Window for ""(.*)"" ""(.*)"" is selected")]
        public void ThenPCPIPALookupWindowForIsSelected(string option, string selection)
        {
            if (option.ToLower().Equals("accepts new members"))
            {
                By Drp = By.XPath("//kendo-dropdownlist[@test-id='pcpIpa-select-acceptNewMembers']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + selection + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                //fw.ExecuteJavascript(EAM.PCPIPALookup.AcceptNewMembersDropdown);
                //By drpValue = By.XPath("//div[@class='k-animation-container']//li[contains(.,'" + selection + "')]");
                //fw.ExecuteJavascript(Browser.Wd.FindElement(drpValue));
            }
        }

        [Then(@"PCP IPA Lookup Window for Provider ID ""(.*)"" is entered")]
        public void ThenPCPIPALookupWindowForProviderIDIsEntered(string p0)
        {
            string providerID = tmsCommon.GenerateData(p0);
            EAM.PCPIPALookup.ProviderIDTextbox.SendKeys(providerID);
        }

        [Then(@"PCP IPA Lookup Window for Provider First Name ""(.*)"" is entered")]
        public void ThenPCPIPALookupWindowForProviderFirstNameIsEntered(string firstname)
        {
            EAM.PCPIPALookup.ProviderFirstName.SendKeys(firstname);
        }

        [Then(@"PCP IPA Lookup Window for Provider Last Name ""(.*)"" is entered")]
        public void ThenPCPIPALookupWindowForProviderLastNameIsEntered(string lastname)
        {
            EAM.PCPIPALookup.ProviderLastName.SendKeys(lastname);
        }

        [Then(@"Verify PCP IPA Lookup Window has row")]
        public void ThenVerifyPCPIPALookupWindowHasRow(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.PCPIPALookup.ProviderLookUpTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Members View Edit Table has row: {0}", e.Message);
            }
        }


        [Then(@"PCP IPA Lookup Window Submit button is clicked")]
        public void ThenPCPIPALookupWindowSubmitButtonIsClicked()
        {
            EAM.PCPIPALookup.SubmitButton.Click();
            tmsWait.Hard(10);
        }

        [Then(@"Verify PopUp should appear with message ""(.*)""")]
        public void ThenVerifyPopUpShouldAppearWithMessage(string expected)
        {
            tmsWait.Hard(2);

            Assert.AreEqual(expected.ToString(), EAM.PCPIPALookup.Message.Text.ToString(), "Message text is mismatched.");
        }

        [Then(@"Verify Error '(.*)' should be displayed")]
        public void ThenVerifyErrorShouldBeDisplayed(string expected)
        {
            tmsWait.Hard(10);
            Assert.AreEqual(expected.ToString(), EAM.PCPIPALookup.NoRecordText.Text.Trim().ToString(), "Records are getting displayed.");
        }

        [Then(@"Click OK button")]
        public void ThenClickOKButton()
        {
            EAM.PCPIPALookup.OKButton.Click();
        }



        [Then(@"PCP IPA Lookup Window for any PCP ID Select link is clicked from the results grid")]
        public void ThenPCPIPALookupWindowForAnyPCPIDSelectLinkIsClickedFromTheResultsGrid()
        {
           fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("(//button[contains(.,'Select')])[1]")));
            tmsWait.Hard(3);
        

        }

        [Then(@"Verify that PCP ID value is displayed on New PCP ID field")]
        public void ThenVerifyThatPCPIDValueIsDisplayedOnNewPCPIDField()
        {

            IWebElement newPCP = Browser.Wd.FindElement(By.Id("txtNewPCP"));

            string value = newPCP.GetAttribute("value");
            Assert.IsTrue(!EAM.PCPIPALookup.NewPCPIDTextbox.Text.Equals(""), "New PCP ID text has new value: " + EAM.PCPIPALookup.NewPCPIDTextbox.Text.ToString());
            GlobalRef.FirstPCPID = EAM.PCPIPALookup.NewPCPIDTextbox.Text;
        }
        [Then(@"Verify that PCP ID value Has displayed on New PCP ID field")]
        public void ThenVerifyThatPCPIDValueHasDisplayedOnNewPCPIDField()
        {
           // Browser.Wd.FindElement(By.XPath("//input[@id='txtNewPCP']")).Click();
            string firstpcp = Browser.Wd.FindElement(By.XPath("//label[@test-id='pcpIpa-lbl-newPcpId']/following-sibling::span")).Text.ToString();
            Console.WriteLine(firstpcp);
            GlobalRef.FirstPCPID= firstpcp;

        }
        [Then(@"Verify that Group/IPA ID value is displayed on New Group/IPA ID field")]
        public void ThenVerifyThatGroupIPAIDValueIsDisplayedOnNewGroupIPAIDField()
        {
            Assert.IsTrue(!EAM.PCPIPALookup.NewIPATextbox.Text.Equals(""), "New PCP ID text has new value: " + EAM.PCPIPALookup.NewIPATextbox.Text.ToString());
            GlobalRef.FirstIPAID = EAM.PCPIPALookup.NewIPATextbox.Text;
        }


        [Then(@"PCPC IPA Lookup window Save button is clicked")]
        public void ThenPCPCIPALookupWindowSaveButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(EAM.PCPIPALookup.SaveButton);
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")));
        }

        [Then(@"""(.*)"" pop-up screen ""(.*)"" button is clicked")]
        public void ThenPop_UpScreenButtonIsClicked(string p0, string action)
        {
            
            if (action.ToLower().Equals("yes"))
                Browser.ClosePopUps(true);
            else
                Browser.ClosePopUps(false);
        }

        [Then(@"""(.*)"" popup screen ""(.*)"" button is clicked")]
        public void ThenPopUpScreenButtonIsClicked(string p0, string action)
        {

            if (action.ToLower().Equals("yes"))
               // Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")).Click();
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")));
            else if (action.ToLower().Equals("no"))
                Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-No']")).Click();
            // Browser.SwitchToParentWindow();
            tmsWait.Hard(3);

        }
       

        [Then(@"Verify ""(.*)"" value from PCP IPA Window is saved and displayed on PCP ID field on Provider Tab")]
        public void ThenVerifyValueFromPCPIPAWindowIsSavedAndDisplayedOnPCPIDFieldOnProviderTab(string p0)
        {
            GlobalRef.SecondPCPID = EAM.PCPIPALookup.PCPIDTextbox.GetAttribute("value");
            string firstpcp = GlobalRef.FirstPCPID.ToString();
            string secondpcp = GlobalRef.SecondPCPID.ToString();
            GlobalRef.PCPID= secondpcp;
            Assert.AreEqual(firstpcp, secondpcp, "PCP ID values are mismatched...");
        }


        [Then(@"Varaible ""(.*)"" is set to")]
        public void ThenVaraibleIsSetTo(string p0)
        {
            GlobalRef.PCPID = EAM.PCPIPALookup.PCPIDTextbox.GetAttribute("value").ToString();
        }


        [Then(@"Verify ""(.*)"" field is blank on ""(.*)"" Tab")]
        public void ThenVerifyFieldIsblankOnTab(string p0, string p1)
        {
            IWebElement web = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ucProviderInfo_txtPCPid"));
            String disable = web.GetAttribute("disabled");
            Assert.AreEqual("true", disable);
        }

        [Then(@"Verify ""(.*)"" field is empty on ""(.*)"" Tab")]
        public void ThenVerifyFieldIsEmptyOnTab(string p0, string p1)
        {
            Assert.IsTrue(EAM.PCPIPALookup.PCPIDTextbox.GetAttribute("disabled").Equals("disabled"), "PCP ID field is not empty.");
        }
        [Then(@"Members New Member ID is set to ""(.*)""")]
        public void ThenMembersNewMemberIDIsSetTo(string p0)
        {
            EAM.MembersNew.MemberID.Clear();
            EAM.MembersNew.MemberID.SendKeys(p0);
        }

        [Then(@"Verify that all records from Providers file are displayed")]
        public void ThenVerifyThatAllRecordsFromProvidersFileAreDisplayed()
        {
            var pagesize = EAM.PCPIPALookup.PageSizeText.GetAttribute("value");
            var lastpageno= EAM.PCPIPALookup.LastPageText.Text.Remove(0,2).Trim();

            var totalCount = Convert.ToInt32(pagesize) * Convert.ToInt32(lastpageno);
            if (!(Convert.ToInt32(lastpageno) < 10))
            {
                EAM.PCPIPALookup.LastPageNavButton.Click();
            }
            var recordsCount = Browser.Wd.FindElements(By.LinkText("Select")).Count;
            var exactCount = totalCount - (10 - Convert.ToInt32(recordsCount));

        }

    }
}
