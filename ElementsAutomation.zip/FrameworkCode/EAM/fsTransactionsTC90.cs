﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using TechTalk.SpecFlow;
using TMSoR1;
using System.Text.RegularExpressions;
using System.Collections;
using TMSoR1.FrameworkCode;

namespace Daron0004
{
    [Binding]
    class fsTransactionsTC90
    {
        public static string GeneratedUserID;

        [When(@"Transactions New (.*) Force Deny check box is set to ""(.*)""")]
        public void WhenTransactionsNewForceDenyCheckBoxIsSetTo(int p0, string p1)
        {
            string GenerateData = tmsCommon.GenerateData(p1);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {

                By denyCheckbox = By.XPath("//label[contains(.,'Force Deny')]/parent::div/input");
                ReUsableFunctions.CheckBoxOperations(Browser.Wd.FindElement(denyCheckbox),p1);               



            }
            else
            {

                switch (GenerateData.ToLower())
                {
                    case "checked": { setCheckboxTo = "checked"; break; }
                    case "on": { setCheckboxTo = "checked"; break; }
                    case "yes": { setCheckboxTo = "checked"; break; }
                    case "unchecked": { setCheckboxTo = "unchecked"; break; }
                    case "off": { setCheckboxTo = "unchecked"; break; }
                    case "no": { setCheckboxTo = "unchecked"; break; }
                    default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
                }

                if (setCheckboxTo.Equals("unchecked"))
                {
                    if (EAM.TransactionsNew.ForceDeny1.Selected == true)
                    {
                        EAM.TransactionsNew.ForceDeny1.Click();
                        Console.WriteLine("ForceDeny check box is set to " + GenerateData);
                    }


                }
                else
                {
                    if (EAM.TransactionsNew.ForceDeny1.Selected == false)
                    {
                        EAM.TransactionsNew.ForceDeny1.Click();
                        Console.WriteLine("ForceDeny check box is set to " + GenerateData);
                    }
                }
            }
        }

        [When(@"Transactions New (.*) Denial Reason is set to ""(.*)""")]
        public void WhenTransactionsNewDenialReasonIsSetTo(int p0, string p1)
        {
            string GenerateData = tmsCommon.GenerateData(p1);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Denial Reason')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + GenerateData + "']");


                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);



            }
            else
            {

                By DenialReason = By.XPath("//div[@id='div_ApplicationDispositionDenialReason']/span");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(DenialReason);
                tmsWait.Hard(1);
                UIMODUtilFunctions.selectTransDrpValue(GenerateData);

            }
        }

        [When(@"Switched from EAM to ERF Application")]
        [Given(@"Switched from EAM to ERF Application")]
        [Then(@"Switched from EAM to ERF Application")]
        public void WhenSwitchedFromEAMToERFApplication()
        {
            tmsWait.Hard(3);
            Browser.Wd.SwitchTo().Frame(EAM.ERF.ERFFrame);
            tmsWait.Hard(3);
        }

        [Then(@"Verify ERF page ""(.*)"" field value is set to ""(.*)""")]
        public void ThenVerifyERFPageFieldValueIsSetTo(string field, string value)
        {
            string expectedValue = tmsCommon.GenerateData(value);
            string actualValue = string.Empty;
            switch(field)
            {
                case "PBP":
                    actualValue = new SelectElement(Browser.Wd.FindElement(By.Id("PBP"))).SelectedOption.Text;
                    break;
                case "Segment ID":
                    actualValue = new SelectElement(Browser.Wd.FindElement(By.Id("Segment"))).SelectedOption.Text;
                    break;

                case "Last Name":
                    actualValue = Browser.Wd.FindElement(By.Id("LastName")).GetAttribute("value");
                    break;

                case "First Name":
                    actualValue = Browser.Wd.FindElement(By.Id("FirstName")).GetAttribute("value");
                    break;
                case "Plan Description":
                    actualValue = Browser.Wd.FindElement(By.Id("PlanDescription")).GetAttribute("value");
                    break;
                case "PBP Description":
                    actualValue = Browser.Wd.FindElement(By.Id("PBPDescription")).GetAttribute("value");
                    break;
            }

            Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");
        }

        [Then(@"Verify ERF page Application Disposition section  Names of Agent Broker are displayed")]
        public void ThenVerifyERFPageApplicationDispositionSectionNamesOfAgentBrokerAreDisplayed()
        {
            tmsWait.Hard(3);
            Browser.Wd.SwitchTo().Frame(EAM.ERF.ERFFrame);
            List<String> expectedagent = new List<String>() { "EAM001", "EAM002", "EAM003", "EAM004", "EAM005", "EAM006" };
            SelectElement actualagent = new SelectElement(EAM.ERF.ERFAgentDropdown);
            IList<IWebElement> options = actualagent.Options;

            Console.WriteLine(" List of Agents details");
            foreach (String expected in expectedagent)
            {

                foreach (IWebElement actual in options)
                {
                    if (actual.Text.Contains(expected))
                    {
                        Console.WriteLine(actual.Text);
                    }

                }
            }

        }


        [Then(@"Verify ERF Page Election Type dropdown list ""(.*)"" value is not displayed")]
        public void ThenVerifyERFPageElectionTypeDropdownListValueIsNotDisplayed(string p0)
        {
            bool flag = false;
            var expectedValue = p0.ToString();
            SelectElement actualValue = new SelectElement(EAM.ERF.ERFElectionTypeDropdown);
           var options = actualValue.Options;

            Console.WriteLine(" List of Election Type details");
            foreach (var expected in options)
            {
                if (expected.Text.Equals(expectedValue))
                {
                    fw.ConsoleReport(expectedValue + " Election Type is present on Eelction Type dropdown list");
                    flag = true;
                    break;
                }
            }
            if (!flag)
            fw.ConsoleReport(expectedValue + " Election Type is not present on Eelction Type dropdown list");


        }

        [Then(@"Verify ERF page displays ""(.*)"" section")]
        public void ThenVerifyERFPageDisplaysSection(string p0)
        {
            IWebElement sec = Browser.Wd.FindElement(By.XPath("//label/em[contains(.,'"+p0+"')]"));
            Assert.IsTrue(sec.Displayed, p0 + "is not getting displayed");
        }

        [Then(@"Verify ERF page Residence Address section Use as Mailing Address checkbox is Unchecked")]
        public void ThenVerifyERFPageResidenceAddressSectionUseAsMailingAddressCheckboxIsUnchecked()
        {
            IWebElement check = Browser.Wd.FindElement(By.Id("MailingAddressIsResidenceAddress"));
            Assert.IsFalse(check.Selected, check + "is getting selected");
           
        }

        [Then(@"Verify ERF page ""(.*)"" section is Hidden")]
        public void ThenVerifyERFPageSectionIsHidden(string p0)
        {

        IWebElement sec = Browser.Wd.FindElement(By.XPath("//label/em[contains(.,'" + p0 + "')]"));
            Assert.IsFalse(sec.Displayed, p0 + "is not getting displayed");
        }

        [Then(@"Verify ERF page Mailing Address section ""(.*)"" field is displayed")]
        public void ThenVerifyERFPageMailingAddressSectionFieldIsDisplayed(string p0)
        {
            string field = p0.ToString().Trim();
            IWebElement fieldele = Browser.Wd.FindElement(By.Id("" + field + ""));
            Assert.IsTrue(fieldele.Displayed, field + "is not getting displayed");
        }


        [Then(@"Verify ERF page Residence Address section ""(.*)"" field is displayed")]
        public void ThenVerifyERFPageResidenceAddressSectionFieldIsDisplayed(string p0)
        {
            string field = p0.ToString().Trim();
            IWebElement fieldele = Browser.Wd.FindElement(By.Id(""+field+""));
            Assert.IsTrue(fieldele.Displayed, field+"is not getting displayed");
        }

        [When(@"ERF page Residence Address section Use as Mailing Address checkbox is Checked")]
        public void WhenERFPageResidenceAddressSectionUseAsMailingAddressCheckboxIsChecked()
        {

            IWebElement check = Browser.Wd.FindElement(By.Id("MailingAddressIsResidenceAddress"));
            check.Click();
            tmsWait.Hard(2);
        }

        [When(@"Switched from ERF Application from EAM Application")]
        public void WhenSwitchedFromERFApplicationFromEAMApplication()
        {
            tmsWait.Hard(10);
            Browser.Wd.SwitchTo().DefaultContent();
        }


        [When(@"Switched from EAM Application to ERF Application")]
        [Then(@"Switched from EAM Application to ERF Application")]
        public void WhenSwitchedFromEAMApplicationToERFApplication()
        {
            tmsWait.Hard(2);

            do
            {
                if (tmsWait.IsAlertPresent())
                    Browser.ClosePopUps(true);
            } while (tmsWait.IsAlertPresent());

            Browser.Wd.SwitchTo().Frame(EAM.ERF.ERFFrame);
            
            while (true)
            {
                try
                {
                    IWebElement planID = EAM.ERF.ERFPBPIDDropdown;
                    if (planID != null)
                        break;
                }
                catch { }
            }
        }

        [Then(@"Verify EAM Configuration section View Out of Area Configuration table has row")]
        public void ThenVerifyEAMConfigurationSectionViewOutOfAreaConfigurationTableHasRow(Table table)
        {

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.AdministrationPlanDefinedFieldsOOATab.OutofAreaGrid;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");
                //               Boolean bTransStatusMatching = false;
                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {

                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //if(AppTableRow.Equals(GherkinTableArray[iElementCounter])
                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (appTD.Equals("Canceled"))
                                //{

                                //    Assert.IsTrue(appTD.Equals("Canceled"));
                                //    bTransStatusMatching = true;
                                //    //Console.WriteLine("TC 61 status is found as Canceled");
                                //}

                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //    //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }


                        }

                    }
                    iTableCounter++;
                    //if (bTransStatusMatching)
                    //{
                    //    Console.WriteLine("Transaction status is updated to Canceled in Transaction History");
                    //}
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                //if (bTransStatusMatching)
                //{
                //    Console.WriteLine("Member Info page Transaction status is updated to Canceled in Transaction History table");
                //}

                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                //baseTable = EAM.MemberInformation.TransactionHistoryTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }


        }


        [Then(@"ERF page Application Disposition section Name of Agent Broker is set to ""(.*)""")]
        [When(@"ERF page Application Disposition section Name of Agent Broker is set to ""(.*)""")]
        public void ThenERFPageApplicationDispositionSectionNameOfAgentBrokerIsSetTo(string p0)
        {
            
            //while (tmsWait.IsAlertPresent())
            //{
            //    try
            //    {

            //        IAlert alert = Browser.Wd.SwitchTo().Alert();
            //        alert.Accept();
            //    }
            //    catch (NoAlertPresentException)
            //    {
            //        fw.ConsoleReport("No alert Present");
            //        break;
            //    }
            //}
            

            tmsWait.Hard(10);
            if (p0.Equals("EAM003"))
            {
                SelectElement agent = new SelectElement(EAM.ERF.ERFAgentDropdown);
                agent.SelectByText(p0);
            }
            else
            {
                SelectElement agent = new SelectElement(EAM.ERF.ERFAgentDropdown);
                agent.SelectByIndex(2);
            }
        }

        [Then(@"ERF page Indicative section Plan ID is set to ""(.*)""")]
        public void ThenERFPageIndicativeSectionPlanIDIsSetTo(string plan)
        {
            string p0 = tmsCommon.GenerateData(plan);
            tmsWait.Hard(10);
            SelectElement planID = new SelectElement(EAM.ERF.ERFPlanIDDropdown);
            tmsWait.Hard(10);
            planID.SelectByText(p0);
        }

        [Then(@"ERF page Indicative section PBP ID is set to ""(.*)""")]
        public void ThenERFPageIndicativeSectionPBPIDIsSetTo(String p0)
        {
            tmsWait.Hard(10);
            string pbp = tmsCommon.GenerateData(p0);
            SelectElement pbpID = new SelectElement(EAM.ERF.ERFPBPIDDropdown);
            pbpID.SelectByText(pbp);
        }

        [Then(@"ERF page Indicative section Segment ID is set to ""(.*)""")]
        public void ThenERFPageIndicativeSectionSegmentIDIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            SelectElement pbpID = new SelectElement(EAM.ERF.ERFSegmentDropdown);
            pbpID.SelectByText(p0);
        }

        [Then(@"ERF page Indicative section SSN is set to ""(.*)""")]
        public void ThenERFPageIndicativeSectionSSNIsSetTo(string p0)
        {
            string ssn = tmsCommon.GenerateData(p0);
            EAM.ERF.SSN.SendKeys(ssn);
        }


        [Then(@"ERF page Indicative section Last Name is set to ""(.*)""")]
        public void ThenERFPageIndicativeSectionLastNameIsSetTo(string p0)
        {
            string lastName = tmsCommon.GenerateData(p0);
            EAM.ERF.ERFLastName.SendKeys(lastName);
        }

        [Then(@"ERF page Indicative section Appel is set to ""(.*)""")]
        public void ThenERFPageIndicativeSectionAppelIsSetTo(string Appel)
        {
            EAM.ERF.ERFAppel.SendKeys(Appel);
        }


        [Then(@"ERF page Indicative section First Name is set to ""(.*)""")]
        public void ThenERFPageIndicativeSectionFirstNameIsSetTo(string p0)
        {
            string firstName = tmsCommon.GenerateData(p0);
            EAM.ERF.ERFFirstName.SendKeys(firstName);
        }

        [Then(@"ERF page Indicative section Gender is set to ""(.*)""")]
        public void ThenERFPageIndicativeSectionGenderIsSetTo(string p0)
        {
            SelectElement pbpID = new SelectElement(EAM.ERF.ERFGenderDropdown);
            pbpID.SelectByText(p0);
        }

        [Then(@"ERF page Indicative section Enrollment Source is set to ""(.*)""")]
        public void ThenERFPageIndicativeSectionEnrollmentSourceIsSetTo(string p0)
        {
            SelectElement pbpID = new SelectElement(EAM.ERF.ERFEnrollmentSource);
            pbpID.SelectByText(p0);
        }

        [Then(@"ERF page Indicative section Type of Application is set to ""(.*)""")]
        public void ThenERFPageIndicativeSectionTypeOfApplicationIsSetTo(string p0)
        {
            SelectElement type = new SelectElement(EAM.ERF.ERFTypeofApplication);
            type.SelectByText(p0);
        }


        [Then(@"ERF page Indicative section DOB is set to ""(.*)""")]
        public void ThenERFPageIndicativeSectionDOBIsSetTo(string p0)
        {
            tmsWait.Hard(2);

            string GeneratedData = tmsCommon.GenerateData(p0);
            GeneratedData = GeneratedData.Replace("/", "");
            EAM.ERF.ERFDOB.Clear();

            EAM.ERF.ERFDOB.Click();
            EAM.ERF.ERFDOB.SendKeys(Keys.Home);
            EAM.ERF.ERFDOB.SendKeys(GeneratedData);

            //EAM.ERF.ERFDOB.SendKeys(p0);
        }

        [Then(@"ERF page Indicative section Election Type is set to ""(.*)""")]
        public void ThenERFPageIndicativeSectionElectionTypeIsSetTo(string p0)
        {
            string pbp = tmsCommon.GenerateData(p0);
            SelectElement pbpID = new SelectElement(EAM.ERF.ERFElectionTypeDropdown);
            pbpID.SelectByText(pbp);
        }

        [Then(@"ERF page Indicative section HIC is set to ""(.*)""")]
        public void ThenERFPageIndicativeSectionHICIsSetTo(string p0)
        {
            string HIC = tmsCommon.GenerateData(p0);
            EAM.ERF.ERFHIC.Clear();
            EAM.ERF.ERFHIC.SendKeys(HIC);
            Browser.Wd.FindElement(By.Id("indicativeSection")).Click();
            tmsWait.Hard(5);
        }

        [Then(@"ERF page Indicative section MemberID is set to ""(.*)""")]
        public void ThenERFPageIndicativeSectionMemberIDIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string memberID = tmsCommon.GenerateData(p0);
            EAM.ERF.ERFMemberID.SendKeys(memberID);
        }

        [Then(@"ERF page Indicative section PrimaryRXID is set to ""(.*)""")]
        public void ThenERFPageIndicativeSectionPrimaryRXIDIsSetTo(string p0)
        {
            string RXID = tmsCommon.GenerateData(p0);
            EAM.ERF.ERFPrimaryRxID.SendKeys(RXID);
        }


        [Then(@"ERF page Indicative section EffectiveDate is set to ""(.*)""")]
        public void ThenERFPageIndicativeSectionEffectiveDateIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            GeneratedData = GeneratedData.Replace("/", "");
            EAM.ERF.ERFEffectiveDate.Clear();

            EAM.ERF.ERFEffectiveDate.Click();
            EAM.ERF.ERFEffectiveDate.SendKeys(Keys.Home);
            EAM.ERF.ERFEffectiveDate.SendKeys(GeneratedData);

           // EAM.ERF.ERFEffectiveDate.SendKeys(p0);
        }

        [Then(@"ERF page Indicative section SignatureDate is set to ""(.*)""")]
        public void ThenERFPageIndicativeSectionSignatureDateIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            string GeneratedData = tmsCommon.GenerateData(p0);
            GeneratedData = GeneratedData.Replace("/", "");
            EAM.ERF.ERFSignatureDate.Clear();

            EAM.ERF.ERFSignatureDate.Click();
            EAM.ERF.ERFSignatureDate.SendKeys(Keys.Home);
            EAM.ERF.ERFSignatureDate.SendKeys(GeneratedData);
           // EAM.ERF.ERFSignatureDate.SendKeys(p0);
        }

        [Then(@"ERF page Indicative section ReceiptDate is set to ""(.*)""")]
        public void ThenERFPageIndicativeSectionReceiptDateIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            string GeneratedData = tmsCommon.GenerateData(p0);
            GeneratedData = GeneratedData.Replace("/", "");
            EAM.ERF.ERFReceiptDate.Clear();

            EAM.ERF.ERFReceiptDate.Click();
            EAM.ERF.ERFReceiptDate.SendKeys(Keys.Home);
            EAM.ERF.ERFReceiptDate.SendKeys(GeneratedData);
            //EAM.ERF.ERFReceiptDate.SendKeys(p0);
        }

        [Then(@"Verify View Edit Transaction page Enrollment Source field is set to ""(.*)""")]
        public void ThenVerifyViewEditTransactionPageEnrollmentSourceFieldIsSetTo(string p0)
        {
            string expectedValue = p0.ToString();

            SelectElement enrollsource = new SelectElement(EAM.TransactionsViewEdit.EnrollmentSource);
            string actualValue = enrollsource.SelectedOption.Text;
            Assert.AreEqual(expectedValue, actualValue, "Both values are getting matched ");
        }

        //Gurdeep Arora - Updated for Angular
        [When(@"Legacy Transaction File Export page ""(.*)"" Field is set to ""(.*)""")]
        public void WhenLegacyTransactionFileExportPageFieldIsSetTo(string p0, string p1)
        {

            string fieldValue = p0.ToString();
            string cmsrepType = tmsCommon.GenerateData(p1);
            GlobalRef.CMSREPType = cmsrepType;
            string disenrlReason = tmsCommon.GenerateData(p1);
            GlobalRef.DISENRL = disenrlReason;
            switch (fieldValue)
            {
                case "Plan ID":

                    tmsWait.Hard(1);

                    string planID = tmsCommon.GenerateData(p1);
                    IWebElement drp;
                    IWebElement element;
                    GlobalRef.PlanID = planID;
                    if (ConfigFile.tenantType == "tmsx")
                    {
                        drp = Browser.Wd.FindElement(By.XPath("//*[@test-id='legacyTrans-select-planId']/span/span"));
                        fw.ExecuteJavascript(drp);
                        tmsWait.Hard(2);
                        element = Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + planID + "')]"));
                        fw.ExecuteJavascript(element);
                    }
                    else {
                        drp = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='planId_listbox']"));
                        fw.ExecuteJavascript(drp);
                        tmsWait.Hard(2);
                        element = Browser.Wd.FindElement(By.XPath("//ul[@id='planId_listbox']/li[contains(.,'" + planID + "')]"));
                        fw.ExecuteJavascript(element);
                    }

                    //SelectElement planid = new SelectElement(EAM.TransactionsViewEdit.LegacyTransactionFileExportPlanID);
                    //planid.SelectByText(p1);
                    break;
                case "PBP ID":

                    
                    tmsWait.Hard(1);
                    string pbpID = tmsCommon.GenerateData(p1);
                    GlobalRef.PBPID = pbpID;
                    IWebElement drppbp; IWebElement elementpbp;
                    if (ConfigFile.tenantType == "tmsx")
                    {
                        drppbp = Browser.Wd.FindElement(By.XPath("//*[@test-id='legacyTrans-select-pbpID']/span/span"));
                        fw.ExecuteJavascript(drppbp);
                        tmsWait.Hard(2);
                        elementpbp = Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + pbpID + "')]"));
                        fw.ExecuteJavascript(elementpbp);
                    }
                    else
                    {
                        drppbp = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='pbpID_listbox']"));
                        fw.ExecuteJavascript(drppbp);
                        tmsWait.Hard(2);
                        elementpbp = Browser.Wd.FindElement(By.XPath("//ul[@id='pbpID_listbox']/li[contains(.,'" + pbpID + "')]"));
                        fw.ExecuteJavascript(elementpbp);
                    }
                    break;


                case "Transaction Type":

                    tmsWait.Hard(1);
                    string ttype = tmsCommon.GenerateData(p1);
                    GlobalRef.TType = ttype;
                    IWebElement drpttype; IWebElement elementttype;
                    if (ConfigFile.tenantType == "tmsx")
                    {
                        drpttype = Browser.Wd.FindElement(By.XPath("//*[@test-id='legacyTrans-select-transactionType']/span/span"));
                        fw.ExecuteJavascript(drpttype);
                        tmsWait.Hard(2);
                        elementttype = Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + ttype + "')]"));
                        fw.ExecuteJavascript(elementttype);
                    }
                    else
                    {
                        drpttype = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='transactionType_listbox']"));
                        fw.ExecuteJavascript(drpttype);
                        tmsWait.Hard(2);
                        elementttype = Browser.Wd.FindElement(By.XPath("//ul[@id='transactionType_listbox']/li[contains(.,'" + ttype + "')]"));
                        fw.ExecuteJavascript(elementttype);
                    }

                   break;

                case "Transaction Status":

                    tmsWait.Hard(1);
                    string tstatus = tmsCommon.GenerateData(p1);
                    GlobalRef.TStatus = tstatus;
                    IWebElement drptstatus;
                    IWebElement elementtstatus;
                    if (ConfigFile.tenantType == "tmsx")
                    {
                        drptstatus = Browser.Wd.FindElement(By.XPath("//*[@test-id='legacyTrans-select-transactionStatus']/span/span"));
                        fw.ExecuteJavascript(drptstatus); 
                        tmsWait.Hard(2);
                        elementtstatus = Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + tstatus + "')]"));
                        fw.ExecuteJavascript(elementtstatus);
                    }
                    else
                    {
                        drptstatus = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='transactionStatus_listbox']"));
                        fw.ExecuteJavascript(drptstatus);
                        tmsWait.Hard(2);
                         elementtstatus = Browser.Wd.FindElement(By.XPath("//ul[@id='transactionStatus_listbox']/li[contains(.,'" + tstatus + "')]"));
                        fw.ExecuteJavascript(elementtstatus);
                    }
                    break;


                case "FromDate":
                    tmsWait.Hard(3);
                    string GeneratedData = tmsCommon.GenerateData(p1);
                    tmsWait.Hard(2);
                    if (ConfigFile.tenantType == "tmsx")
                    {

                        By Drp = By.XPath("//label[contains(.,'From Date')]/parent::div//input");
                        string value = GeneratedData.Replace("/", "");
                        tmsWait.Hard(5);
                        Browser.Wd.FindElement(Drp).Clear();
                        tmsWait.Hard(5);
                        Browser.Wd.FindElement(Drp).SendKeys(value);
                        tmsWait.Hard(3);
                    }
                    else
                    {
                        IWebElement from = Browser.Wd.FindElement(By.CssSelector("[test-id='legacyTrans-txt-fromdate']"));
                        from.Clear();
                        from.SendKeys(GeneratedData);
                    }

                    break;

                case "ToDate":
                    tmsWait.Hard(1);
                    string GeneratedData1 = tmsCommon.GenerateData(p1);


                    if (ConfigFile.tenantType == "tmsx")
                    {
                        By Drp = By.XPath("//label[contains(.,'To Date')]/parent::div//input");
                        string value = GeneratedData1.Replace("/", "");
                        tmsWait.Hard(1);
                        Browser.Wd.FindElement(Drp).Clear();
                        tmsWait.Hard(2);
                        Browser.Wd.FindElement(Drp).SendKeys(value);
                        tmsWait.Hard(3);
                    }
                    else
                    {

                        IWebElement To = Browser.Wd.FindElement(By.CssSelector("[test-id='legacyTrans-txt-todate']"));
                        fw.ExecuteJavascriptSetText(To, GeneratedData1);
                        To.Clear();
                        To.SendKeys(GeneratedData1);
                    }

                                 
                    break;

                case "CMS Response Type":
                    tmsWait.Hard(1);
                   
                    IWebElement drpCMSREPType;
                    IWebElement elementCMSREPType;

                    //legacyTrans-select-cmsResponseType
                    if (ConfigFile.tenantType == "tmsx")
                    {
                        drpCMSREPType = Browser.Wd.FindElement(By.XPath("//*[@test-id='legacyTrans-select-cmsResponseType']/span/span"));
                        fw.ExecuteJavascript(drpCMSREPType);
                        tmsWait.Hard(2);
                        elementCMSREPType = Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + cmsrepType + "')]"));
                        fw.ExecuteJavascript(elementCMSREPType);
                    }
                    else
                    {
                        drpCMSREPType = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='cmsResponseType_listbox']"));
                        fw.ExecuteJavascript(drpCMSREPType);
                        tmsWait.Hard(2);
                        elementCMSREPType = Browser.Wd.FindElement(By.XPath("//ul[@id='cmsResponseType_listbox']/li[contains(.,'" + cmsrepType + "')]"));
                        fw.ExecuteJavascript(elementCMSREPType);
                    }
                    break;

                case "Disenroll Reasons":
                    tmsWait.Hard(1);
                    IWebElement drpdisenrlReason;
                    IWebElement elementdisenrlReason;

                   
                    if (ConfigFile.tenantType == "tmsx")
                    {
                        drpdisenrlReason = Browser.Wd.FindElement(By.XPath("//*[@test-id='legacyTrans-select-disenrollmentReasons']/span/span"));
                        fw.ExecuteJavascript(drpdisenrlReason);
                        tmsWait.Hard(2);
                        elementdisenrlReason = Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + disenrlReason + "')]"));
                        fw.ExecuteJavascript(elementdisenrlReason);
                    }
                    else
                    {
                        drpdisenrlReason = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='disenrollmentReasons_listbox']"));
                        fw.ExecuteJavascript(drpdisenrlReason);
                        tmsWait.Hard(2);
                        elementdisenrlReason = Browser.Wd.FindElement(By.XPath("//ul[@id='disenrollmentReasons_listbox']/li[contains(.,'" + disenrlReason + "')]"));
                        fw.ExecuteJavascript(elementdisenrlReason);
                    }
                                      
                    break;
                case "Problem Case Type":
                    tmsWait.Hard(1);

                    string prpcaseType = tmsCommon.GenerateData(p1);
                    GlobalRef.PRBCASETYPE = prpcaseType;
                    IWebElement drpprpcaseType;
                    IWebElement elementprpcaseType;

                    if (ConfigFile.tenantType == "tmsx")
                    {
                        drpprpcaseType = Browser.Wd.FindElement(By.XPath("//*[@name='problemCaseType']/span/span"));
                        fw.ExecuteJavascript(drpprpcaseType);
                        tmsWait.Hard(2);
                        elementprpcaseType = Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + prpcaseType + "')]"));
                        fw.ExecuteJavascript(elementprpcaseType);
                    }
                    else
                    {
                        drpprpcaseType = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='problemCaseType_listbox']"));
                        fw.ExecuteJavascript(drpprpcaseType);
                        tmsWait.Hard(2);
                        elementprpcaseType = Browser.Wd.FindElement(By.XPath("//ul[@id='problemCaseType_listbox']/li[contains(.,'" + prpcaseType + "')]"));
                        fw.ExecuteJavascript(elementprpcaseType);
                    }
                
                    break;

                case "Reply Code":
                    tmsWait.Hard(1);

                    string replycode = tmsCommon.GenerateData(p1);
                    GlobalRef.ReplyCode = replycode;
                    IWebElement drpReplyCode;
                    IWebElement elementReplyCode;

                    if (ConfigFile.tenantType == "tmsx")
                    {
                        drpReplyCode = Browser.Wd.FindElement(By.XPath("//*[@test-id='legacyTrans-select-replyCodes']/span/span"));
                        fw.ExecuteJavascript(drpReplyCode);
                        tmsWait.Hard(2);
                        elementReplyCode = Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + replycode + "')]"));
                        fw.ExecuteJavascript(elementReplyCode);
                    }
                    else
                    {

                        drpReplyCode = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='replyCodes_listbox']"));
                        fw.ExecuteJavascript(drpReplyCode);
                        tmsWait.Hard(2);
                        elementReplyCode = Browser.Wd.FindElement(By.XPath("//ul[@id='replyCodes_listbox']/li[contains(.,'" + replycode + "')]"));
                        fw.ExecuteJavascript(elementReplyCode);
                    }
                    break;
   
            }
        }

     

        [When(@"Legacy Transaction File Export page Go button is Clicked")]
        public void WhenLegacyTransactionFileExportPageGoButtonIsClicked()
        {
            tmsWait.Hard(3);
            IWebElement element;
            if (ConfigFile.tenantType == "tmsx")
              element = Browser.Wd.FindElement(By.XPath("//*[@test-id='retro-btn-refresh']"));
            else 
              element=EAM.TransactionsViewEdit.LegacyTransactionFileExportGoButton;
            
            fw.ExecuteJavascript(element);
            tmsWait.Hard(5);
        }


        [When(@"Legacy Transaction File Export page Reset button is Clicked")]
        public void WhenLegacyTransactionFileExportPageResetButtonIsClicked()
        {
            if (ConfigFile.tenantType == "tmsx")
            {
                IWebElement ResetBtn = Browser.Wd.FindElement(By.XPath("//button[@test-id='retro-btn-markAsSent' and contains(., 'RESET')]"));
                fw.ExecuteJavascript(ResetBtn);
            }
            else
            {
                fw.ExecuteJavascript(EAM.TransactionsViewEdit.LegacyTransactionFileExportResetButton);
            }
            tmsWait.Hard(3);
        }

        [Then(@"Verify Legacy Transaction File Export page ""(.*)"" field value is set to ""(.*)""")]
        public void ThenVerifyLegacyTransactionFileExportPageFieldValueIsSetTo(string field, string value)
        {
            bool elemenPresence;
            tmsWait.Hard(4);
            switch (field)
            {
                case "Plan ID":
                    if (ConfigFile.tenantType == "tmsx")
                    {
                        elemenPresence = Browser.Wd.FindElement(By.XPath("//*[@test-id='legacyTrans-select-planId']/span/span[contains(.,'" + value + "')]")).Displayed;
                    }
                    else{
                        elemenPresence = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='planId_listbox']//span[@class='k-input ng-scope'][contains(.,'" + value + "')]")).Displayed;
                    }
                       Assert.IsTrue(elemenPresence, value + " is not present");
                    break;

                case "PBP ID":
                    if (ConfigFile.tenantType == "tmsx")
                    {
                        elemenPresence = Browser.Wd.FindElement(By.XPath("//*[@test-id='legacyTrans-select-pbpID']/span/span[contains(.,'" + value + "')]")).Displayed;
                    }
                    else
                    {
                        elemenPresence = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='pbpID_listbox']//span[@class='k-input ng-scope'][contains(.,'" + value + "')]")).Displayed;

                    }    Assert.IsTrue(elemenPresence, value + " is not present");
                    break;

                case "Transaction Type":
                    if (ConfigFile.tenantType == "tmsx")
                    {
                        elemenPresence = Browser.Wd.FindElement(By.XPath("//*[@test-id='legacyTrans-select-transactionType']/span/span[contains(.,'" + value + "')]")).Displayed;
                    }
                    else
                    {
                        elemenPresence = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='transactionType_listbox']//span[@class='k-input ng-scope'][contains(.,'" + value + "')]")).Displayed;
                    }
                        Assert.IsTrue(elemenPresence, value + " is not present");
                    break;

                case "Transaction Status":
                    if (ConfigFile.tenantType == "tmsx")
                    {
                        elemenPresence = Browser.Wd.FindElement(By.XPath("//*[@test-id='legacyTrans-select-transactionStatus']/span/span[contains(.,'" + value + "')]")).Displayed;
                    }
                    else
                    {
                        elemenPresence = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='transactionStatus_listbox']//span[@class='k-input ng-scope'][contains(.,'" + value + "')]")).Displayed;
                    }
                        Assert.IsTrue(elemenPresence, value + " is not present");
                    break;

                case "Reply Codes":
                    if (ConfigFile.tenantType == "tmsx")
                    {
                        elemenPresence = Browser.Wd.FindElement(By.XPath("//*[@test-id='legacyTrans-select-replyCodes']/span/span[contains(.,'" + value + "')]")).Displayed;
                    }
                    else
                    {
                        elemenPresence = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='replyCodes_listbox']//span[@class='k-input ng-scope'][contains(.,'" + value + "')]")).Displayed;
                    }
                        Assert.IsTrue(elemenPresence, value + " is not present");
                    break;


                case "Disenrollment Reasons":
                    if (ConfigFile.tenantType == "tmsx")
                    {
                        elemenPresence = Browser.Wd.FindElement(By.XPath("//*[@test-id='legacyTrans-select-disenrollmentReasons']/span/span[contains(.,'" + value + "')]")).Displayed;
                    }
                    else
                    {
                        elemenPresence = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='disenrollmentReasons_listbox']//span[@class='k-input ng-scope'][contains(.,'" + value + "')]")).Displayed;
                    }
                        Assert.IsTrue(elemenPresence, value + " is not present");
                    break;


                case "CMS Response Type":
                    if (ConfigFile.tenantType == "tmsx")
                    {
                        elemenPresence = Browser.Wd.FindElement(By.XPath("//*[@test-id='legacyTrans-select-cmsResponseType']/span/span[contains(.,'" + value + "')]")).Displayed;
                    }
                    else
                    {
                        elemenPresence = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='cmsResponseType_listbox']//span[@class='k-input ng-scope'][contains(.,'" + value + "')]")).Displayed;
                    }
                        Assert.IsTrue(elemenPresence, value + " is not present");
                    break;
                case "Problem Case Type":
                    if (ConfigFile.tenantType == "tmsx")
                    {
                        elemenPresence = Browser.Wd.FindElement(By.XPath("//*[@name='problemCaseType']/span/span[contains(.,'" + value + "')]")).Displayed;
                    }
                    else
                    {
                        elemenPresence = Browser.Wd.FindElement(By.XPath("//span[@aria-owns='problemCaseType_listbox']//span[@class='k-input ng-scope'][contains(.,'" + value + "')]")).Displayed;
                    }
                        Assert.IsTrue(elemenPresence, value + " is not present");
                    break;
            }
        }


        [Then(@"Verify Legacy Transaction File Export page display default values")]
        public void ThenVerifyLegacyTransactionFileExportPageDisplayDefaultValues()
        {
            IWebElement AllPlanid = Browser.Wd.FindElement(By.XPath("//select[@id='ctl00_ctl00_MainMasterContent_MainContent_ddlPlan']//option[contains(.,'---All---')]"));
            string selecteddefault = AllPlanid.GetAttribute("selected");
            string expected = "true";
            Assert.AreEqual(selecteddefault, expected, "Default value is not displayed for plan id" );
        }


        [When(@"Legacy Transaction File Export page Export button is Clicked")]
        public void WhenLegacyTransactionFileExportPageExportButtonIsClicked()
        {
            tmsWait.Hard(1);
            fw.ExecuteJavascript(EAM.TransactionsViewEdit.LegacyTransactionFileExportExportButton);

        }

        [Then(@"Verify Transaction File Export Message ""(.*)""")]
        public void ThenVerifyTransactionFileExportMessage(string p0)
        {
            tmsWait.Hard(3);
            Assert.AreEqual(p0, Browser.Wd.FindElement(By.XPath("//li[contains(., 'To Date')]")).Text, "Error Message is not displayed");
            
        }

       


        [Then(@"Verify Legacy Transaction File Export page Exported MBI is not displayed on Search Results")]
        public void ThenVerifyLegacyTransactionFileExportPageExportedMBIIsNotDisplayedOnSearchResults()
        {
            string expectedValue = GlobalRef.TransMBI;

            IWebElement transexportTable;
            try
            {
                if (ConfigFile.tenantType == "tmsx")
                {
                    transexportTable = Browser.Wd.FindElement(By.XPath("//*[@class='k-grid-aria-root']//td[contains(.,'" + expectedValue + "')]"));
                    Assert.Fail(" Exported MBI is stil present");
                }
                else
                {
                    transexportTable = Browser.Wd.FindElement(By.XPath("//div[@test-id='legacyTrans-grid-legacyTransGrid']/table//tbody[contains(.,'" + expectedValue + "')]"));
                    Assert.Fail(" Exported MBI is stil present");
                }
            }
            catch
            {
                Assert.IsTrue(true, " Exported MBI is stil present");
                fw.ConsoleReport(expectedValue + " --> Exported MBI is not present on Search results");
            }


            //try
            
            ////IReadOnlyCollection<IWebElement> exporttransaction = transexportTable.FindElements(By.TagName("tr"));
            //foreach (var trans in exporttransaction)
            //{
            //    IWebElement MBI = trans.FindElement(By.XPath("td[1]"));
            //    if (MBI.Text.Equals(expectedValue))
            //    {
            //        isnotpresent = true;
            //        break;
            //    }
            //}

            //Assert.IsTrue(isnotpresent);
        }


        [Then(@"Verify Legacy Transaction File Export page HIC ""(.*)"" is not displayed")]
        public void ThenVerifyLegacyTransactionFileExportPageHICIsNotDisplayed(string p0)
        {
 string expectedValue = GlobalRef.TransMBI;
            Boolean isnotpresent = true;
            IWebElement transexportTable = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_dgRaps']/tbody"));
            IReadOnlyCollection<IWebElement> exporttransaction = transexportTable.FindElements(By.TagName("tr"));
            foreach(var trans in exporttransaction)
            {
                IWebElement MBI = trans.FindElement(By.XPath("td[1]"));
                if(MBI.Text.Equals(expectedValue))
                {
                    isnotpresent = true;
                    break;
                }
            }

            Assert.IsTrue(isnotpresent);
        }


        [When(@"Legacy Transaction Send checkbox is checked for MBI ""(.*)""")]
        public void WhenLegacyTransactionSendCheckboxIsCheckedForMBI(string p0)
        {
            string expectedMbi = tmsCommon.GenerateData(p0);
            IWebElement exportGrid = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_dgRaps']/tbody"));
            IReadOnlyCollection<IWebElement> allrows = exportGrid.FindElements(By.TagName("tr"));
            foreach (var row in allrows)
            {
                string actualMBI = row.FindElement(By.XPath("td[1]")).Text;
                //string[] actualhic = row.Text.Split(' ');
                if (expectedMbi == actualMBI)
                {
                    fw.ExecuteJavascript(row.FindElement(By.XPath("td[7]/input")));
                    break;
                }
            }
        }


        [Then(@"ERF page Residence Address section Residence Address(.*) is set to ""(.*)""")]
        public void ThenERFPageResidenceAddressSectionResidenceAddressIsSetTo(int p0, string p1)
        {
            tmsWait.Hard(5);
            string address = tmsCommon.GenerateData(p1);
            EAM.ERF.ERFResidenceAddress1.SendKeys(address);
        }

        [Then(@"ERF page Residence Address section ZIP is set to ""(.*)""")]
        public void ThenERFPageResidenceAddressSectionZIPIsSetTo(string p0)
        {
            EAM.ERF.ERFResidenceZip.SendKeys(p0);
            EAM.ERF.ERFResidenceAddress1.Click();
        }

        [Then(@"ERF page Residence Address section SCC is set to ""(.*)""")]
        public void ThenERFPageResidenceAddressSectionSCCIsSetTo(string p0)
        {
            EAM.ERF.ERFResidenceSCC.Clear();
            EAM.ERF.ERFResidenceSCC.SendKeys(p0);
        }


        [Then(@"ERF page Residence Address section Use as Mailing Address checkbox is checked")]
        public void ThenERFPageResidenceAddressSectionUseAsMailingAddressCheckboxIsChecked()
        {
            EAM.ERF.ERFMailingAddressCheckbox.Click();
        }

        [Then(@"Verify ERF page Premium Payment Options section Premium Withhold Options dropdown list displays ""(.*)""")]
        public void ThenVerifyERFPagePremiumPaymentOptionsSectionPremiumWithholdOptionsDropdownListDisplays(string col)
        {
            string[] co = col.Split(',');
            List<string> expList = new List<string>(co);
            List<string> actList = new List<string>();

            IWebElement elem = Browser.Wd.FindElement(By.Id("PremiumWithholdOption"));
            ReadOnlyCollection<IWebElement> options = elem.FindElements(By.TagName("option"));
            foreach (IWebElement temp in options)
            {
                actList.Add(temp.Text);
            }

            for (int i = 0; i < expList.Count; i++)
            {
                if (expList[i].Equals(actList[i]))
                {
                    Assert.IsTrue(true);
                }
                else
                {
                    Assert.IsTrue(false);
                }
            }

        }


        [Then(@"Verify ERF page Premium Payment Options section Bank Type drop down list displays ""(.*)""")]
        public void ThenVerifyERFPagePremiumPaymentOptionsSectionBankTypeDropDownListDisplays(string col)
        {
            string[] co = col.Split(',');
            List<string> expList = new List<string>(co);
            List<string> actList=new List<string>();
                   
            IWebElement elem = Browser.Wd.FindElement(By.Id("BankAccountType"));
            ReadOnlyCollection<IWebElement> options = elem.FindElements(By.TagName("option"));
            foreach (IWebElement temp in options)
            {
                actList.Add(temp.Text);
            }

            for (int i=0;i< expList.Count;i++)
            {
                if (expList[i].Equals(actList[i]))
                {
                    Assert.IsTrue(true);
                }
                else
                {
                    Assert.IsTrue(false);
                }
            }
          

        }

        [Then(@"Verify ERF Page ""(.*)"" is displayed")]
        public void ThenVerifyERFPageIsDisplayed(string p0)
        {
            tmsWait.Hard(3);
            IWebElement lookup = Browser.Wd.FindElement(By.XPath("//span[contains(.,'"+p0+"')]"));
            Assert.IsTrue(lookup.Displayed, p0 + "is not getting displayed");
        }

        [When(@"ERF Page PCP section ""(.*)"" field is Clicked")]
        public void WhenERFPagePCPSectionFieldIsClicked(string p0)
        {
            IWebElement field = Browser.Wd.FindElement(By.Id("" + p0 + ""));
            field.Click();
            tmsWait.Hard(5);
        }

        [When(@"Verify ERF Page PCP section ""(.*)"" field is ""(.*)""")]
        public void WhenVerifyERFPagePCPSectionFieldIs(string p0, string p1)
        {
            IWebElement ele = null;
            if (p1.ToLower().Equals("disabled"))
            {
                ele = Browser.Wd.FindElement(By.Id("" + p0 + ""));


                Assert.IsFalse(ele.Enabled, p0 + "is Enabled");
            }
            else if (p1.ToLower().Equals("enabled"))
            {
                ele = Browser.Wd.FindElement(By.Id("" + p0 + ""));


                Assert.IsTrue(ele.Enabled, p0 + "is Disabled");
            }
        }


        [When(@"Verify ERF Page PCP IPA Lookup section ""(.*)"" field is ""(.*)""")]
        public void WhenVerifyERFPagePCPIPALookupSectionFieldIs(string p0, string p1)
        {
            
                IWebElement ele = null;
                if (p1.ToLower().Equals("disabled"))
                {
                    ele = Browser.Wd.FindElement(By.Id("" + p0 + ""));


                    Assert.IsFalse(ele.Enabled, p0 + "is Enabled");
                }
                else if (p1.ToLower().Equals("enabled"))
                {
                    ele = Browser.Wd.FindElement(By.Id("" + p0 + ""));


                    Assert.IsTrue(ele.Enabled, p0 + "is Disabled");
                }
          }


        [When(@"ERF Page Premium Payment Options section ""(.*)"" drop down list is set to ""(.*)""")]
        public void WhenERFPagePremiumPaymentOptionsSectionDropDownListIsSetTo(string p0, string p1)
        {
            SelectElement drp = new SelectElement(Browser.Wd.FindElement(By.Id("" + p0 + "")));
            drp.SelectByText(p1);
        }


        [When(@"ERF Page Premium Payment Options section ""(.*)"" field is set to ""(.*)""")]
        public void WhenERFPagePremiumPaymentOptionsSectionFieldIsSetTo(string p0, string p1)
        {

            IWebElement field = Browser.Wd.FindElement(By.Id(""+p0+""));
            field.SendKeys(p1);
        }

        [When(@"Verify ERF Page Premium Payment Options section ""(.*)"" field is ""(.*)""")]
        public void WhenVerifyERFPagePremiumPaymentOptionsSectionFieldIs(string p0, string p1)
        {
            IWebElement ele = null;
            if (p1.ToLower().Equals("disabled"))
            {
                ele = Browser.Wd.FindElement(By.Id(""+p0+""));
               

                Assert.IsFalse(ele.Enabled, p0 + "is Enabled");
            }
            else if (p1.ToLower().Equals("enabled"))
            {
                ele = Browser.Wd.FindElement(By.Id("" + p0 + ""));


                Assert.IsTrue(ele.Enabled, p0 + "is Disabled");
            }
        }


        [When(@"Verify ERF page Premium Payment Options section Electronic Funds Transfer checkbox is ""(.*)""")]
        public void WhenVerifyERFPagePremiumPaymentOptionsSectionElectronicFundsTransferCheckboxIs(string p0)
        {

            string GenerateData = tmsCommon.GenerateData(p0);


            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("unchecked"))
            {
                if (EAM.ERF.ERFElectrionicFundTransferCheckbox.Selected)
                {
                    fw.ExecuteJavascript(EAM.ERF.ERFElectrionicFundTransferCheckbox);
                }
            }
            else if (setCheckboxTo.Equals("checked"))
            {
                if (!EAM.ERF.ERFElectrionicFundTransferCheckbox.Selected)
                {
                    fw.ExecuteJavascript(EAM.ERF.ERFElectrionicFundTransferCheckbox);
                }
            }
        }


        [When(@"I execute SQL Query ""(.*)"" on Database ""(.*)"" with SSN ""(.*)""")]
        public void WhenIExecuteSQLQueryOnDatabaseWithSSN(string query, string DB, string SSN)
        {
            string DBname = tmsCommon.GenerateData(DB);
            string HIC = tmsCommon.GenerateData(SSN);
            string sql = tmsCommon.GenerateData(query);
            string SqlString = sql + "'" + HIC + "'";
            Console.Write("Query is : " + SqlString);
            string dbQuery = tmsCommon.GenerateData(SqlString);
            db.AddDBQuery(DBname, dbQuery);
        }




        [Then(@"Verify Member Information Table has NameAppel as ""(.*)"" for SSN ""(.*)""")]
        public void ThenVerifyMemberInformationTableHasNameAppelAsForSSN(string tbvalue, string p1)
        {
            tmsWait.Hard(3);

            string SSN = tmsCommon.GenerateData(p1);

            ArrayList actList = new ArrayList();
            ArrayList expList = new ArrayList();
            string[] expArray = tbvalue.Split(',');
            foreach (string ele in expArray)
            {
                expList.Add(ele);
            }
            string DB = ConfigFile.EAMdb;
            fsRSMLogin DBquery = new fsRSMLogin();
            string SqlString = " select NameAppel from [" + DB + "].[dbo].[tbMemberInfo] where SSN = '" + SSN + "'";
            tmsWait.Hard(2);
            actList = DBquery.ExecuteSQLQuery(SqlString, DB);

            for (int i = 0; i < expList.Count; i++)
            {
                if (expList[i].Equals(actList[i]))
                {
                    Assert.IsTrue(true);
                    tmsWait.Hard(2);
                    Console.WriteLine("Expected " + expList[i] + " Actual " + actList[i]);
                }
                else
                {
                    Console.WriteLine("Expected " + expList[i] + " Actual " + actList[i]);
                    Assert.IsTrue(false);
                }
            }
        }

        [Then(@"Verify Member Information Table has data ""(.*)"" for SSN ""(.*)""")]
        public void ThenVerifyMemberInformationTableHasDataForSSN(string tbvalue, string p1)
        {
          
        string SSN = tmsCommon.GenerateData(p1);

            ArrayList actList = new ArrayList();
            ArrayList expList = new ArrayList();
            string[] expArray = tbvalue.Split(',');
            foreach (string ele in expArray)
            {
                expList.Add(ele);
            }
            string DB = ConfigFile.EAMdb;
            fsRSMLogin DBquery = new fsRSMLogin();
              string SqlString = " select EmergContact,EmergRel from [" + DB + "].[dbo].[tbMemberInfo] where SSN = '" + SSN + "'";

            actList = DBquery.ExecuteSQLQuery(SqlString, DB);

            for (int i = 0; i < expList.Count; i++)
            {
                if (expList[i].Equals(actList[i]))
                {
                    Assert.IsTrue(true);
                    Console.WriteLine("Expected " + expList[i] + " Actual " + actList[i]);
                }
                else
                {
                    Console.WriteLine("Expected " + expList[i] + " Actual " + actList[i]);
                    Assert.IsTrue(false);
                }
            }
        }



        [Then(@"Verify Member Enrollment Table has data ""(.*)"" for HIC ""(.*)""")]
        public void ThenVerifyMemberEnrollmentTableHasDataForHIC(string tbvalue, string p1)
        {

            string SSN = tmsCommon.GenerateData(p1);

            ArrayList actList = new ArrayList();
            ArrayList expList = new ArrayList();
            string[] expArray = tbvalue.Split(',');
            foreach (string ele in expArray)
            {
                string temp = tmsCommon.GenerateData(ele);
                expList.Add(temp);
            }
            string DB = ConfigFile.EAMdb;
            fsRSMLogin DBquery = new fsRSMLogin();
            //string SqlString = "select Description from [" + DB + "].[dbo].[tbEnrollmentSources]";

            string SqlString = "select HIC, PlanID from [" + DB + "].[dbo].[tbTransactions] where HIC = '"+SSN+"'";
             
            actList = DBquery.ExecuteSQLQuery(SqlString, DB);

            for (int i = 0; i < expList.Count; i++)
            {
                if (expList[i].Equals(actList[i]))
                {
                    Assert.IsTrue(true);
                    Console.WriteLine("Expected " + expList[i] + " Actual " + actList[i]);
                }
                else
                {
                    Console.WriteLine("Expected " + expList[i] + " Actual " + actList[i]);
                    Assert.IsTrue(false);
                }
            }
        }




        [Then(@"Verify Transactions Table has data ""(.*)"" for HIC ""(.*)""")]
        public void ThenVerifyTransactionsTableHasDataForHIC(string tbvalue, string p1)
        {
            string SSN = tmsCommon.GenerateData(p1);

            ArrayList actList = new ArrayList();
            ArrayList expList = new ArrayList();
            string[] expArray = tbvalue.Split(',');
            
            foreach (string ele in expArray)
            {
                string temp = tmsCommon.GenerateData(ele);
                expList.Add(temp);
            }
            string DB = ConfigFile.EAMdb;
            fsRSMLogin DBquery = new fsRSMLogin();
            //string SqlString = "select Description from [" + DB + "].[dbo].[tbEnrollmentSources]";

            string SqlString = "Select HIC,TransCode from [" + DB + "].[dbo].[tbTransactions] where SSN = '" + SSN + "'";
            actList = DBquery.ExecuteSQLQuery(SqlString, DB);

            for (int i = 0; i < expList.Count; i++)
            {
                
                if (expList[i].Equals(actList[i]))
                {
                    Assert.IsTrue(true);
                    Console.WriteLine("Expected " + expList[i] + " Actual " + actList[i]);
                }
                else
                {
                    Console.WriteLine("Expected " + expList[i] + " Actual " + actList[i]);
                    Assert.IsTrue(false);
                }
            }
        }


        [Then(@"Verify Membership Table has data ""(.*)"" for HIC ""(.*)""")]
        public void ThenVerifyMembershipTableHasDataForHIC(string tbvalue, string p1)
        {
            string SSN = tmsCommon.GenerateData(p1);

            ArrayList actList = new ArrayList();
            ArrayList expList = new ArrayList();
            string[] expArray = tbvalue.Split(',');
            foreach (string ele in expArray)
            {
                expList.Add(ele);
            }
            string DB = ConfigFile.EAMdb;
            fsRSMLogin DBquery = new fsRSMLogin();
            //string SqlString = "select Description from [" + DB + "].[dbo].[tbEnrollmentSources]";

            string SqlString = "select ResponAddress, ResponCity, ResponZip, ResponRel, ResponName, ResponTelNum  from [" + DB + "].[dbo].[tbMemberinfo] where SSN = '"+ SSN + "'";
            actList = DBquery.ExecuteSQLQuery(SqlString, DB);

            for (int i = 0; i < expList.Count; i++)
            {
                if (expList[i].Equals(actList[i]))
                {
                    Assert.IsTrue(true);
                    Console.WriteLine("Expected " + expList[i] + " Actual " + actList[i]);
                }
                else
                {
                    Console.WriteLine("Expected " + expList[i] + " Actual " + actList[i]);
                    Assert.IsTrue(false);
                }
            }
        }

        [Then(@"Verify View Edit Member page ""(.*)"" field is set to ""(.*)""")]
        public void ThenVerifyViewEditMemberPageFieldIsSetTo(string field, string value)
        {
            switch(field)
            {
                case "Responsibility Name":
                    Assert.AreEqual(value, EAM.ViewEditMemberContact.ResponsibilityName.GetAttribute("value"), "Both values are not getting matched");
                    break;
                case "Respons Address":
                    Assert.AreEqual(value, EAM.ViewEditMemberContact.ResponsibilityAddress.GetAttribute("value"), "Both values are not getting matched");
                    break;
                case "Respons City":
                    Assert.AreEqual(value, EAM.ViewEditMemberContact.ResponsibilityCity.GetAttribute("value"), "Both values are not getting matched");
                    break;
                case "Respons State":
                    Assert.AreEqual(value, EAM.ViewEditMemberContact.ResponsibilityState.GetAttribute("value"), "Both values are not getting matched");
                    break;
                case "Respons Zip":
                    Assert.AreEqual(value, EAM.ViewEditMemberContact.ResponsibilityZip.GetAttribute("value"), "Both values are not getting matched");
                    break;
                case "Respons Relation":
                    SelectElement rel = new SelectElement(EAM.ViewEditMemberContact.ResponsibilityRelation);
                    
                    Assert.AreEqual(value, rel.SelectedOption.Text, "Both values are not getting matched");
                    break;
                case "Respons Phone":
                    Assert.AreEqual(value, EAM.ViewEditMemberContact.ResponsibilityPhone.GetAttribute("value"), "Both values are not getting matched");
                    break;

                    

            }
        }

        [Then(@"ERF page Authorized Representative section ""(.*)"" field is selected to ""(.*)""")]
        public void ThenERFPageAuthorizedRepresentativeSectionFieldIsSelectedTo(string p0, string p1)
        {
            SelectElement rel = new SelectElement(EAM.ERF.AuthorizedRepresentativeRelationship);
            rel.SelectByText(p1);
        }

        [Then(@"Emergency Contact section ""(.*)"" is set to ""(.*)""")]
        public void ThenEmergencyContactSectionIsSetTo(string field, string value)
        {

            switch (field)
            {
                case "Emergency Contact":
                    EAM.ERF.EmergencyContact.SendKeys(value);
                    break;
                case "Emergency Contact Phone":
                    EAM.ERF.EmergencyContactPhone.SendKeys(value);
                    break;
                case "Emergency Contact Relationship":
                    EAM.ERF.EmergencyContactRelationship.SendKeys(value);
                    break;
                
            }
        }



        [Then(@"ERF page Authorized Representative section ""(.*)"" field is set to ""(.*)""")]
        public void ThenERFPageAuthorizedRepresentativeSectionFieldIsSetTo(string field, string value)
        {
           
            switch(field)
            {
                case "Name":
                    EAM.ERF.AuthorizedRepresentativeName.SendKeys(value);
                    break;
                case "Address":
                    EAM.ERF.AuthorizedRepresentativeAddress.SendKeys(value);
                    break;
                case "City":
                    EAM.ERF.AuthorizedRepresentativeCity.SendKeys(value);
                    break;
                case "State":
                    EAM.ERF.AuthorizedRepresentativeState.SendKeys(value);
                    break;
                case "Zip":
                    EAM.ERF.AuthorizedRepresentativeZip.SendKeys(value);
                    break;
                case "Phone":
                    EAM.ERF.AuthorizedRepresentativePhone.SendKeys(value);
                    break;
                 }
        }


        [When(@"Verify ERF page Premium Payment Options section Electronic Funds Transfer checkbox is checked")]
        public void WhenVerifyERFPagePremiumPaymentOptionsSectionElectronicFundsTransferCheckboxIsChecked()
        {
            EAM.ERF.ERFElectrionicFundTransferCheckbox.Click();
            tmsWait.Hard(2);
        }

        [Then(@"ERF page Premium Payment Options section Premium Withhold Options is set to ""(.*)""")]
        public void ThenERFPagePremiumPaymentOptionsSectionPremiumWithholdOptionsIsSetTo(string p0)
        {

            tmsWait.Hard(6);
            SelectElement pbpID = new SelectElement(EAM.ERF.ERFPremiumWithholdOption);
            tmsWait.Hard(6);
            pbpID.SelectByText(p0);

            tmsWait.Hard(5);
        }
        [Then(@"ERF page Premium Payment Options section Deny Application checkbox is checked")]
        public void ThenERFPagePremiumPaymentOptionsSectionDenyApplicationCheckboxIsChecked()
        {
            EAM.ERF.DenyApplicationCheckbox.Click();
        }
        [When(@"Denial Reason drop down is set to ""(.*)""")]
        public void WhenDenialReasonDropDownIsSetTo(string p0)
        {
            SelectElement denialreason = new SelectElement(EAM.ERF.DenyReasonDrpdownlist);
            denialreason.SelectByText(p0);
        }


        [Then(@"Verify Denial Reason drop down display ""(.*)"" message")]
        public void ThenVerifyDenialReasonDropDownDisplayMessage(string p0)
        {
            tmsWait.Hard(3);
            string expected = p0.ToString();
            string actual = Browser.Wd.FindElement(By.ClassName("qtip-content")).Text;
            Assert.AreEqual(expected, actual, "Both are not matching");

        }



        [Then(@"ERF Page Application Disposition section Deny Application checkbox is ""(.*)""")]
        public void ThenERFPageApplicationDispositionSectionDenyApplicationCheckboxIs(string p0)
        {
            EAM.ERFAppDisposition.DenyApplication.Click();
            tmsWait.Hard(1);
        }

        [Then(@"ERF Page Application Disposition section Denial Reason set to ""(.*)""")]
        public void ThenERFPageApplicationDispositionSectionDenialReasonSetTo(string p0)
        {
            string inputValue = p0.ToString();
            SelectElement select = new SelectElement(EAM.ERFAppDisposition.DenialReason);
            select.SelectByText(inputValue);
        }



        [Then(@"ERF page Special Member ""(.*)"" is ""(.*)""")]
        public void ThenERFPageSpecialMemberIs(string member, string status)
        {
            switch (member)
            {
                case "EGHP":
                    if (status.ToLower() == "checked")
                    {
                        if (!EAM.ERF.EGHPMember.Selected)
                        {
                            EAM.ERF.EGHPMember.Click();
                        }
                    }
                    else
                    {
                        if (EAM.ERF.EGHPMember.Selected)
                        {
                            EAM.ERF.EGHPMember.Click();
                        }
                    }
                    break;
            }
        }


        [When(@"ERF Page Application Disposition section Incomplete Application checkbox is ""(.*)""")]
        public void WhenERFPageApplicationDispositionSectionIncompleteApplicationCheckboxIs(string p0)
        {
            EAM.ERFAppDisposition.InCompleteApplication.Click();
        }

        [When(@"ERF Page Application Disposition section Deny Application checkbox is ""(.*)""")]
        public void WhenERFPageApplicationDispositionSectionDenyApplicationCheckboxIs(string p0)
        {
            EAM.ERFAppDisposition.DenyApplication.Click();
        }


        [When(@"ERF page Premium Payment Options section Electronic Funds Transfer checkbox is checked")]
        [Then(@"ERF page Premium Payment Options section Electronic Funds Transfer checkbox is checked")]
        public void WhenERFPagePremiumPaymentOptionsSectionElectronicFundsTransferCheckboxIsChecked()
        {
            EAM.ERF.ERFElectrionicFundTransferCheckbox.Click();
        }

        [When(@"ERF Page Premium Payment Options section Account Holder Name is set to ""(.*)""")]
        public void WhenERFPagePremiumPaymentOptionsSectionAccountHolderNameIsSetTo(string p0)
        {
            EAM.ERF.ERFAccountHolderName.SendKeys(p0);

        }

        [When(@"ERF Page Premium Payment Options section Bank Routing Number is set to ""(.*)""")]
        public void WhenERFPagePremiumPaymentOptionsSectionBankRoutingNumberIsSetTo(string p0)
        {
            EAM.ERF.ERFBankRoutingNumber.SendKeys(p0);
        }

        [When(@"ERF Page Premium Payment Options section Bank Account Number is set to ""(.*)""")]
        public void WhenERFPagePremiumPaymentOptionsSectionBankAccountNumberIsSetTo(string p0)
        {

            EAM.ERF.ERFBankAccountNumber.SendKeys(p0);
        }

        [Then(@"ERF page Premium Payment Options section Bank Account Type is set to ""(.*)""")]
        public void ThenERFPagePremiumPaymentOptionsSectionBankAccountTypeIsSetTo(string accountType)
        {
            SelectElement bankAccountTypeDD = new SelectElement(EAM.ERF.ERFBankAccountTypeDropdown);
            if (accountType.ToLower().Equals("checking"))
            {
                bankAccountTypeDD.SelectByValue("1");
            }
            else
            {
                bankAccountTypeDD.SelectByValue("2");
            }
        }

        [When(@"ERF page Special Status section Employer Group Number Add Icon is Clicked")]
        public void WhenERFPageSpecialStatusSectionEmployerGroupNumberAddIconIsClicked()
        {
            IWebElement icon = Browser.Wd.FindElement(By.Id("editEmployerGroup"));
            fw.ExecuteJavascript(icon);
           
            tmsWait.Hard(2);
        }

        [When(@"Employer Group popup ""(.*)"" is set to ""(.*)""")]
        public void WhenEmployerGroupPopupIsSetTo(string p0, string p1)
        {
            string value = tmsCommon.GenerateData(p1);
            IWebElement element = Browser.Wd.FindElement(By.Id("" + p0 + ""));
            element.SendKeys(value);

        }

        [Then(@"Verify Employer Group popup displays Message ""(.*)""")]
        public void ThenVerifyEmployerGroupPopupDisplaysMessage(string p0)
        {
            IWebElement element = Browser.Wd.FindElement(By.XPath("//div[@class='qtip-content']"));
            string actual = element.Text;
            Assert.AreEqual(p0, actual, "Both are not getting matched");
            Browser.Wd.FindElement(By.Id("EmployerGroupNumber")).Clear();
            Browser.Wd.FindElement(By.Id("EmployerGroupNumber")).SendKeys("Hello");

            tmsWait.Hard(3);

        }


        [Then(@"Verify Employer Group popup ""(.*)"" dropdown list is set to ""(.*)""")]
        public void ThenVerifyEmployerGroupPopupDropdownListIsSetTo(string p0, string p1)
        {
            string value = tmsCommon.GenerateData(p1);

            SelectElement drp = new SelectElement(Browser.Wd.FindElement(By.Id("EmployerGroup")));
            Assert.AreEqual(value, drp.SelectedOption.Text, value + "is not getting displayed");

        }


        [Then(@"Verify Employer Group popup ""(.*)"" is set to ""(.*)""")]
        public void ThenVerifyEmployerGroupPopupIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(2);
            string value = tmsCommon.GenerateData(p1);
            IWebElement element = Browser.Wd.FindElement(By.Id("" + p0 + ""));
            Assert.AreEqual(value, element.GetAttribute("value"), value + "is not getting displayed");
        }


        [When(@"ERF page Special Status section Employer Group Number dropdown list is set to ""(.*)""")]
        public void WhenERFPageSpecialStatusSectionEmployerGroupNumberDropdownListIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);

            SelectElement drp = new SelectElement(Browser.Wd.FindElement(By.Id("EmployerGroup")));
            drp.SelectByText(value);
        }

        [When(@"ERF page Special Status section ""(.*)"" is set to ""(.*)""")]
        public void WhenERFPageSpecialStatusSectionIsSetTo(string p0, string p1)
        {
            string value = tmsCommon.GenerateData(p1);
            IWebElement element = Browser.Wd.FindElement(By.Id("" + p0 + ""));
            element.SendKeys(value);
        }

        [When(@"Employer Group popup Save button is Clicked")]
        public void WhenEmployerGroupPopupSaveButtonIsClicked()
        {
            IWebElement icon = Browser.Wd.FindElement(By.Id("ButtonSave"));
            icon.Click();
            tmsWait.Hard(2);
            IWebElement close= Browser.Wd.FindElement(By.Id("ButtonClose"));
            close.Click();
            tmsWait.Hard(2);
        }

        [Then(@"Verify ERF page Special Status section Employer Group Number dropdown list contains ""(.*)""")]
        public void ThenVerifyERFPageSpecialStatusSectionEmployerGroupNumberDropdownListContains(string p0)
        {
            string value = tmsCommon.GenerateData(p0);

            SelectElement drp = new SelectElement(Browser.Wd.FindElement(By.Id("EmployerGroup")));
            IList<IWebElement> options = drp.Options;
            foreach(IWebElement temp in options)
            {
                if(temp.Text.Equals(value))
                {
                    Assert.IsTrue(true);
                }
            }



        }

        [When(@"ERF page Special Status section ""(.*)"" field is set to ""(.*)""")]
        public void WhenERFPageSpecialStatusSectionFieldIsSetTo(string p0, string p1)
        {
            IWebElement element = Browser.Wd.FindElement(By.Id("" + p0 + ""));
            element.SendKeys(p1);
        }

        [Then(@"Verify Special Status section ""(.*)"" field is ""(.*)""")]
        public void ThenVerifySpecialStatusSectionFieldIs(string p0, string p1)
        {
            IWebElement ele = null;
            if (p1.ToLower().Equals("disabled"))
            {
                ele = Browser.Wd.FindElement(By.Id("" + p0 + ""));


                Assert.IsFalse(ele.Enabled, p0 + "is Enabled");
            }
            else if (p1.ToLower().Equals("enabled"))
            {
                ele = Browser.Wd.FindElement(By.Id("" + p0 + ""));


                Assert.IsTrue(ele.Enabled, p0 + "is Disabled");
            }

        }


        [Then(@"Verify ERF page Enrollment Source drop down list is set to ""(.*)""")]
        public void ThenVerifyERFPageEnrollmentSourceDropDownListIsSetTo(string p0)
        {

            ArrayList actList = new ArrayList();
            ArrayList expList = new ArrayList();
            string[] expArray = p0.Split('|');
            foreach (string ele in expArray)
            {
                expList.Add(ele);
            }
            string DB = ConfigFile.EAMdb;
            fsRSMLogin DBquery = new fsRSMLogin();
            string SqlString = "select Description from [" + DB + "].[dbo].[tbEnrollmentSources]";

            actList = DBquery.ExecuteSQLQuery(SqlString, DB);

            for (int i = 0; i < expList.Count; i++)
            {
                if (expList[i].Equals(actList[i]))
                {
                    Assert.IsTrue(true);
                    Console.WriteLine("Expected " + expList[i] + " Actual " + actList[i]);
                }
                else
                {
                    Console.WriteLine("Expected " + expList[i] + " Actual " + actList[i]);
                    Assert.IsTrue(false);
                }
            }
        }


        [Then(@"Verify Transaction Search page Transaction Status is set to ""(.*)""")]
        public void ThenVerifyTransactionSearchPageTransactionStatusIsSetTo(string p0)
        {

            ArrayList actList = new ArrayList();
            ArrayList expList = new ArrayList();
            string[] expArray = p0.Split(',');
            foreach (string ele in expArray)
            {
                expList.Add(ele);
            }
             string DB = ConfigFile.EAMdb;
            fsRSMLogin DBquery = new fsRSMLogin();
            string SqlString = "select Description from [" + DB + "].[dbo].[tbTransStatus]";

            actList = DBquery.ExecuteSQLQuery(SqlString, DB);

            for (int i = 0; i < expList.Count; i++)
            {
                if (expList[i].Equals(actList[i]))
                {
                    Assert.IsTrue(true);
                    Console.WriteLine("Expected " + expList[i] + " Actual " + actList[i]);
                }
                else
                {
                    Console.WriteLine("Expected " + expList[i] + " Actual " + actList[i]);
                    Assert.IsTrue(false);
                }
            }

        }




        [Then(@"Verfiy Authorized Representative section Relationship drop down displays ""(.*)""")]
        public void ThenVerfiyAuthorizedRepresentativeSectionRelationshipDropDownDisplays(string p0)
        {
            ArrayList actList = new ArrayList();
            ArrayList expList = new ArrayList();
            string[] expArray = p0.Split(',');
            foreach(string ele in expArray)
            {
                expList.Add(ele);
            }
            Dictionary<int, string[]> table = new Dictionary<int, string[]>();
             string DB = ConfigFile.EAMdb;
            fsRSMLogin DBquery = new fsRSMLogin();
            string SqlString = "select relname from [" + DB + "].[dbo].[tbRelationship]";
          
            actList= DBquery.ExecuteSQLQuery(SqlString, DB);

            for (int i = 0; i < expList.Count; i++)
            {
                if (expList[i].Equals(actList[i]))
                {
                    Assert.IsTrue(true);
                    Console.WriteLine("Expected " + expList[i] + " Actual " + actList[i]);
                }
                //else
                //{
                //    Console.WriteLine("Expected " + expList[i] + " Actual " + actList[i]);
                //    Assert.IsTrue(false);
                //}
            }

        }


        [Then(@"Verify ERF page ""(.*)"" field displays message as ""(.*)""")]
        public void ThenVerifyERFPageFieldDisplaysMessageAs(string field, string message)
        {
              bool res = false;
            tmsWait.Hard(2);
            switch (field)
            {
                case "DOB":
                     res=verifyErrorMessageDisplay("qtip-content", message);
                    Assert.IsTrue(res, message + "is not getting displayed");
                    break;
                case "EffectiveDate":
                     res = verifyErrorMessageDisplay("qtip-content", message);
                    Assert.IsTrue(res, message + "is not getting displayed");
                    break;               
                case "ElectionType":
                     res = verifyErrorMessageDisplay("qtip-content", message);
                    Assert.IsTrue(res, message + "is not getting displayed");
                    break;
                case "FirstName":
                    res = verifyErrorMessageDisplay("qtip-content", message);
                    Assert.IsTrue(res, message + "is not getting displayed");
                    break;
                case "GenderCode":
                    res = verifyErrorMessageDisplay("qtip-content", message);
                    Assert.IsTrue(res, message + "is not getting displayed");
                    break;

                case "MBI":
                    res = verifyErrorMessageDisplay("qtip-content", message);
                    Assert.IsTrue(res, message + "is not getting displayed");
                    break;
                case "PBP":
                    res = verifyErrorMessageDisplay("qtip-content", message);
                    Assert.IsTrue(res, message + "is not getting displayed");
                    break;
                case "Plan":
                    res = verifyErrorMessageDisplay("qtip-content", message);
                    Assert.IsTrue(res, message + "is not getting displayed");
                    break;

                case "ReceiptDate":
                    res = verifyErrorMessageDisplay("qtip-content", message);
                    Assert.IsTrue(res, message + "is not getting displayed");
                    break;
                case "SignatureDate":
                    res = verifyErrorMessageDisplay("qtip-content", message);
                    Assert.IsTrue(res, message + "is not getting displayed");
                    break;
                    
            }
           }

        //Gurdeep Arora
        [Given(@"verify message is displayed ""(.*)""")]
        public void GivenVerifyMessageIsDisplayed(string actualMsg)
        {try {
            string expMsg = Browser.Wd.FindElement(By.XPath("//span[@test-id='exportcms-span-fileProcessingLink']")).Text.ToString();
            Assert.AreEqual(expMsg, actualMsg, "Incorrect message is getting displayed");
            }
            catch
            {
                Console.WriteLine("Any File is not Available to Export for this Plan. Please Check HIC should be in valid format");
            }

        }


        public bool verifyErrorMessageDisplay(string locator, string message)
        {
            IWebElement element = Browser.Wd.FindElement(By.XPath("//div[@class='"+locator+"'][contains(.,'" + message + "')]"));
            return element.Displayed;

        }

        [When(@"ERF page Special Status section ""(.*)"" checkbox is ""(.*)""")]
        public void WhenERFPageSpecialStatusSectionCheckboxIs(string p0, string p1)
        {
            IWebElement element = Browser.Wd.FindElement(By.Id(""+p0+""));

            string GenerateData = tmsCommon.GenerateData(p1);

            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("unchecked"))
            {
                if (element.Selected == true)
                {
                    element.Click();
                }
            }
            else if (setCheckboxTo.Equals("checked"))
            {
                if (element.Selected == false)
                {
                    element.Click();
                }
            }


        }


        [When(@"Special Status section Long Term Case checkbox is ""(.*)""")]
        public void WhenSpecialStatusSectionLongTermCaseCheckboxIs(string p0)
        {

            string GenerateData = tmsCommon.GenerateData(p0);


            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("unchecked"))
            {
                if (EAM.ERF.ERFLongTermCareCheckbox.Selected == true)
                {
                    EAM.ERF.ERFLongTermCareCheckbox.Click();
                }
            }
            else if (setCheckboxTo.Equals("checked"))
            {
                if (EAM.ERF.ERFLongTermCareCheckbox.Selected == false)
                {
                    EAM.ERF.ERFLongTermCareCheckbox.Click();
                }
            }

           
        }

        [Then(@"Special Status section Institution Name field is set to ""(.*)""")]
        public void ThenSpecialStatusSectionInstitutionNameFieldIsSetTo(string p0)
        {
            EAM.ERF.ERFInstitutionName.SendKeys(p0);
        }

        [Then(@"Special Status section Address field is ""(.*)""")]
        public void ThenSpecialStatusSectionAddressFieldIs(string p0)
        {
          
        EAM.ERF.ERFInstitutionAddress.SendKeys(p0);
        }

        [Then(@"Special Status section City field is ""(.*)""")]
        public void ThenSpecialStatusSectionCityFieldIs(string p0)
        {
            EAM.ERF.ERFInstitutionCity.SendKeys(p0);
        }

        [Then(@"Special Status section State field is ""(.*)""")]
        public void ThenSpecialStatusSectionStateFieldIs(string p0)
        {
            EAM.ERF.ERFInstitutionState.SendKeys(p0);
        }

        [Then(@"Special Status section Zip field is ""(.*)""")]
        public void ThenSpecialStatusSectionZipFieldIs(string p0)
        {
            EAM.ERF.ERFInstitutionZip.SendKeys(p0);
        }

        [Then(@"Special Status section Phone field is ""(.*)""")]
        public void ThenSpecialStatusSectionPhoneFieldIs(string p0)
        {
            EAM.ERF.ERFInstitutionPhone.SendKeys(p0);
        }


        [When(@"Special Status section Other Insurance checkbox is ""(.*)""")]
        public void WhenSpecialStatusSectionOtherInsuranceCheckboxIs(string p0)
        {
            string GenerateData = tmsCommon.GenerateData(p0);


            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("unchecked"))
            {
                if (EAM.ERF.ERFOtherInsuranceCheckbox.Selected == true)
                {
                    EAM.ERF.ERFOtherInsuranceCheckbox.Click();
                }
            }
            else if (setCheckboxTo.Equals("checked"))
            {
                if (EAM.ERF.ERFOtherInsuranceCheckbox.Selected == false)
                {
                    EAM.ERF.ERFOtherInsuranceCheckbox.Click();
                }
            }

        }

        [Then(@"Special Status section Other Insurance Name field is set to ""(.*)""")]
        public void ThenSpecialStatusSectionOtherInsuranceNameFieldIsSetTo(string p0)
        {
            EAM.ERF.ERFOtherInsuranceGroup.SendKeys(p0);
        }

        [Then(@"Special Status section Other Insurance ID Number field is set to ""(.*)""")]
        public void ThenSpecialStatusSectionOtherInsuranceIDNumberFieldIsSetTo(string p0)
        {
            EAM.ERF.ERFOtherInsuranceIDNumber.SendKeys(p0);
        }


        [When(@"Special Status section ""(.*)"" field is ""(.*)""")]
        public void WhenSpecialStatusSectionFieldIs(string p0, string p1)
        {
            bool visibleValue = false;
            string fieldValue = p0.ToString();
            if (p1.Equals("Enabled"))
            {
                visibleValue = true;
            }
            else if (p1.Equals("Disabled"))
            {
                visibleValue = false;
            }
            else
                fw.ConsoleReport("Provied Input is wrong");


            if (visibleValue)
            {
                switch (fieldValue)
                {
                    case "Institution Name":

                        Assert.IsTrue(EAM.ERF.ERFInstitutionName.Enabled, p0 + " Field is enabled");
                        break;
                    case "Address":

                        Assert.IsTrue(EAM.ERF.ERFInstitutionAddress.Enabled, p0 + " Field is enabled");
                        break;

                    case "City":

                        Assert.IsTrue(EAM.ERF.ERFInstitutionCity.Enabled, p0 + " Field is enabled");
                        break;

                    case "State":

                        Assert.IsTrue(EAM.ERF.ERFInstitutionState.Enabled, p0 + " Field is enabled");
                        break;

                    case "Zip":

                        Assert.IsTrue(EAM.ERF.ERFInstitutionZip.Enabled, p0 + " Field is enabled");
                        break;

                    case "Phone":

                        Assert.IsTrue(EAM.ERF.ERFInstitutionPhone.Enabled, p0 + " Field is enabled");
                        break;
                    case "Name":

                        Assert.IsTrue(EAM.ERF.ERFOtherInsuranceGroup.Enabled, p0 + " Field is enabled");
                        break;

                    case "ID Number":

                        Assert.IsTrue(EAM.ERF.ERFOtherInsuranceIDNumber.Enabled, p0 + " Field is enabled");
                        break;

                }


            }

            else
            {

                switch (fieldValue)
                {
                    case "Institution Name":

                        Assert.IsFalse(EAM.ERF.ERFInstitutionName.Enabled, p0 + " Field is Disabled");
                        break;
                    case "Address":

                        Assert.IsFalse(EAM.ERF.ERFInstitutionAddress.Enabled, p0 + " Field is Disabled");
                        break;

                    case "City":

                        Assert.IsFalse(EAM.ERF.ERFInstitutionCity.Enabled, p0 + " Field is Disabled");
                        break;

                    case "State":

                        Assert.IsFalse(EAM.ERF.ERFInstitutionState.Enabled, p0 + " Field is Disabled");
                        break;

                    case "Zip":

                        Assert.IsFalse(EAM.ERF.ERFInstitutionZip.Enabled, p0 + " Field is Disabled");
                        break;

                    case "Phone":

                        Assert.IsFalse(EAM.ERF.ERFInstitutionPhone.Enabled, p0 + " Field is Disabled");
                        break;

                    
                    case "Name":

                        Assert.IsFalse(EAM.ERF.ERFOtherInsuranceGroup.Enabled, p0 + " Field is Disabled");
                        break;

                    case "ID Number":

                        Assert.IsFalse(EAM.ERF.ERFOtherInsuranceIDNumber.Enabled, p0 + " Field is Disabled");
                        break;

                }

            }






        }


        [When(@"ERF Page Application Disposition section Incomplete Application Missing Item is set to ""(.*)""")]
        public void WhenERFPageApplicationDispositionSectionIncompleteApplicationMissingItemIsSetTo(string p0)
        {
            SelectElement missing = new SelectElement(EAM.ERFAppDisposition.MissingItem);
            missing.SelectByText(p0);
        }

        [When(@"ERF Page Application Disposition Denial Reason drop down is set to ""(.*)""")]
        public void WhenERFPageApplicationDispositionDenialReasonDropDownIsSetTo(string p0)
        {
            SelectElement missing = new SelectElement(EAM.ERFAppDisposition.DenialReason);
            missing.SelectByText(p0);
        }
        [When(@"ERF Page Application Disposition Denial Reason is set to ""(.*)""")]
        public void WhenERFPageApplicationDispositionDenialReasonIsSetTo(string p0)
        {
            IWebElement other = Browser.Wd.FindElement(By.Id("DenialOther"));
            other.SendKeys(p0);
        }


        [Then(@"Verify ERF Page Application Disposition section displays message ""(.*)""")]
        public void ThenVerifyERFPageApplicationDispositionSectionDisplaysMessage(string p0)
        {
            tmsWait.Hard(1);

            string expected = p0.ToString();
                
            string actual = EAM.ERFAppDisposition.MissingItemTooltipmsg.Text;

            Assert.AreEqual(expected, actual, expected + " Values are getting with displayed " + actual);
        }

        [Then(@"Verify ERF Page Application Disposition Denial Reason section displays message ""(.*)""")]
        public void ThenVerifyERFPageApplicationDispositionDenialReasonSectionDisplaysMessage(string p0)
        {

            tmsWait.Hard(1);

            string expected = p0.ToString();

            string actual = EAM.ERFAppDisposition.DenialReasonTooltipmsg.Text;

            Assert.AreEqual(expected, actual, expected + " Values are getting with displayed " + actual);
        }


        [When(@"ERF Page Application Disposition section Other field is set to ""(.*)""")]
        public void WhenERFPageApplicationDispositionSectionOtherFieldIsSetTo(string p0)
        {
            SelectElement missing = new SelectElement(EAM.ERFAppDisposition.MissingItem);
            missing.SelectByValue("Other");
            tmsWait.Hard(1);
            EAM.ERFAppDisposition.IncompleteOther.SendKeys(p0);
            tmsWait.Hard(2);
        }

        [When(@"ERF Page Application Disposition section ""(.*)"" field is set to ""(.*)""")]
        public void WhenERFPageApplicationDispositionSectionFieldIsSetTo(string p0, string p1)
        {

            string field = p0.ToString();
            string value = p1.ToString();

            switch (field)
                {
                case "Legal Authorization":
                    EAM.ERFAppDisposition.IncompleteOther.SendKeys(value);
                    break;

                case "Part A/B and Legal":
                    EAM.ERFAppDisposition.IncompleteOther.SendKeys(value);
                    break;

                case "Part A/B and Other":
                    EAM.ERFAppDisposition.IncompleteOther.SendKeys(value);
                    break;

                case "Legal and Other":
                    EAM.ERFAppDisposition.IncompleteOther.SendKeys(value);
                    break;


                case "Part A/B":
                    EAM.ERFAppDisposition.IncompleteOther.SendKeys(value);
                    break;

                case "Other":
                    EAM.ERFAppDisposition.IncompleteOther.SendKeys(value);
                    break;
            }
        }


        [Then(@"Verify Transaction View Edit page ""(.*)"" field displayed as ""(.*)""")]
        public void ThenVerifyTransactionViewEditPageFieldDisplayedAs(string p0, string p1)
        {
            string field = p0.ToString();
            string value = p1.ToString();

            if (field.Equals("Missing Item"))
            {
                switch (field)
                {
                    case "Missing Item":

                        SelectElement missing = new SelectElement(EAM.TransactionsViewEdit.DenialReason);
                        Assert.AreEqual(value, missing.SelectedOption.Text, field + " displayed value as " + missing.SelectedOption.Text);

                        break;

                    case "Other":

                        Assert.AreEqual(value, EAM.TransactionsViewEdit.MissingOther.GetAttribute("value"), field + " displayed value as " + EAM.TransactionsViewEdit.MissingOther.Text);

                        break;
                    case "Legal Authorization":

                        Assert.AreEqual(value, EAM.TransactionsViewEdit.MissingOther.GetAttribute("value"), field + " displayed value as " + EAM.TransactionsViewEdit.MissingOther.Text);

                        break;

                    case "Part A/B and Legal":

                        Assert.AreEqual(value, EAM.TransactionsViewEdit.MissingOther.GetAttribute("value"), field + " displayed value as " + EAM.TransactionsViewEdit.MissingOther.Text);

                        break;

                    case "Part A/B and Other":

                        Assert.AreEqual(value, EAM.TransactionsViewEdit.MissingOther.GetAttribute("value"), field + " displayed value as " + EAM.TransactionsViewEdit.MissingOther.Text);

                        break;
                    case "Legal and Other":

                        Assert.AreEqual(value, EAM.TransactionsViewEdit.MissingOther.GetAttribute("value"), field + " displayed value as " + EAM.TransactionsViewEdit.MissingOther.Text);

                        break;

                    case "Part A/B":

                        Assert.AreEqual(value, EAM.TransactionsViewEdit.MissingOther.GetAttribute("value"), field + " displayed value as " + EAM.TransactionsViewEdit.MissingOther.Text);

                        break;
                }
            }

            if (field.Equals("Denial Reason"))
            {

                switch (field)
                {
                    case "Info not received":

                        SelectElement info = new SelectElement(EAM.TransactionsViewEdit.MissingItem);
                        Assert.AreEqual(value, info.SelectedOption.Text, field + " displayed value as " + info.SelectedOption.Text);

                        break;

                    case "Part A":

                        SelectElement parta = new SelectElement(EAM.TransactionsViewEdit.MissingItem);
                        Assert.AreEqual(value, parta.SelectedOption.Text, field + " displayed value as " + parta.SelectedOption.Text);

                        break;

                }
            }

        }

        [Then(@"Verify Transaction View Edit page Incomplete Application check box is ""(.*)""")]
        public void ThenVerifyTransactionViewEditPageIncompleteApplicationCheckBoxIs(string p0)
        {
            Assert.IsTrue(EAM.TransactionsViewEdit.Incompletecheckbox.Selected, " InComplete Checkbox is checked");
        }

        [Then(@"Verify Transaction View Edit page ForceDeny check box is ""(.*)""")]
        public void ThenVerifyTransactionViewEditPageForceDenyCheckBoxIs(string p0)
        {
            Assert.IsTrue(EAM.TransactionsViewEdit.ForceDenyCheckbox.Selected, " Force Deny Checkbox is checked");
        }

        [When(@"Transaction View Edit page ForceDeny check box is ""(.*)""")]
        public void WhenTransactionViewEditPageForceDenyCheckBoxIs(string p0)
        {
            fw.ExecuteJavascript(EAM.TransactionsViewEdit.ForceDenyCheckbox);
            tmsWait.Hard(3);
        }






        string currentHandle = null;
        [When(@"Send To CMS Queue Report page Run Report button is Clicked")]
        public void WhenSendToCMSQueueReportPageRunReportButtonIsClicked()
        {
            currentHandle = Browser.Wd.CurrentWindowHandle;
            EAM.SendToCMSQueueReport.RunReportbutton.Click();
            tmsWait.Hard(5);

            ReUsableFunctions.reportAuthenticationHandler();
        }

        [Then(@"Incomplete Transaction Report is closed")]
        public void ThenIncompleteTransactionReportIsClosed()
        {

            try
            {
                ReportsCommon.CloseReport();
            }
            catch (Exception e)
            {
                Assert.Fail("Incomplete Transaction Report was not closed. Exception: {0}", e.Message);
            }

        }


        [When(@"Enrollment Letter page Generate Letters button is Clicked")]
        public void WhenEnrollmentLetterPageGenerateLettersButtonIsClicked()
        {
   
            tmsWait.Hard(10);
            string titleWin = "E*ENRL Letter";

            //Add ids of all the opened window on screen.These ids will be set to specific windows which are opened in order.
            List<string> w = new List<string>(Browser.Wd.WindowHandles);

            // Set window id and switch to any window
            for (int i = 0; i < w.Count; i++)
            {
                if (Browser.Wd.SwitchTo().Window(w[i]).Title.Equals(titleWin))
                    Browser.Wd.SwitchTo().Window(w[i]);
            }

            tmsWait.Hard(5);

            //Browser.Wd.FindElement(By.XPath("//input[@value='Generate Letters']")).Click();
            EAM.Letters.GenerateButton.Click();

            IAlert alert = Browser.Wd.SwitchTo().Alert();
            alert.Accept();
            tmsWait.Hard(2);

        }

        [Then(@"Verify Job status for the Job is completed")]
        public void ThenVerifyJobStatusForTheJobIsCompleted()
        {
            string jobID = GlobalRef.letterJobID.ToString();

            string jobstatus = "//span[contains(.,'" + jobID + "')]/parent::a/parent::td/following-sibling::td/img";
            IWebElement Jobstatus = Browser.Wd.FindElement(By.XPath(jobstatus));
            string statusfromUI = Jobstatus.GetAttribute("title").ToString();
            if (statusfromUI.Equals("Processing failed"))
            {
                throw new Exception("Job is Failed");
            }
            
            if (statusfromUI.Equals("Executing") || statusfromUI.Equals("Pending"))
            {
                do
                {
                    
                    tmsWait.Hard(10);
                    IWebElement updatedStatus = Browser.Wd.FindElement(By.XPath(jobstatus));
                    statusfromUI = updatedStatus.GetAttribute("title").ToString();
                } while (statusfromUI.Equals("Executing") || statusfromUI.Equals("Pending"));
            }
            if (statusfromUI.Equals("Processing completed"))
            {
                Console.WriteLine("Job has been completed");
            }
        }

        [When(@"Enrollment Letter page Generate Letters button is clicked for Plan ID as ""(.*)"" PBP as ""(.*)"" Letter Name as ""(.*)""")]
        [Then(@"Enrollment Letter page Generate Letters button is clicked for Plan ID as ""(.*)"" PBP as ""(.*)"" Letter Name as ""(.*)""")]
        [Given(@"Enrollment Letter page Generate Letters button is clicked for Plan ID as ""(.*)"" PBP as ""(.*)"" Letter Name as ""(.*)""")]
        public void WhenEnrollmentLetterPageGenerateLettersButtonIsClickedForPlanIDAsPBPAsLetterNameAs(string planId, string pbpid, string letterName)
        {
            string pbp = tmsCommon.GenerateData(pbpid);
            string planID = tmsCommon.GenerateData(planId);
            EAM.Letters.GenerateLetterButton.Click();
            tmsWait.Hard(10);
            if (tmsWait.IsAlertPresent())
            {
                Browser.Wd.SwitchTo().Alert().Accept();
            }
            var message = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_lblMsg")).Text;
            char[] split = { ':' };
            string[] messageList = message.Split(split);
            var jobID = messageList[1].Trim();

            string appServerUrl = ConfigFile.URL;
            int index = appServerUrl.IndexOf('/');
            int index2 = appServerUrl.IndexOf('/', index + 1);
            string subs = appServerUrl.Substring(index2 + 1, 32);
            string[] path = subs.Split('.');
            var letterLocation = "\\\\" + path[1] + "\\TMSShareFolder" + "\\" + jobID.ToString() + "_" + letterName + "_" + planID + "_" + pbp + ".pdf";
            
            GlobalRef.letterJobID = jobID;
        }


        [Then(@"Store the JobId")]
        [Given(@"Store the JobId")]
        public void ThenStoreTheJobId()
        {
            tmsWait.Hard(2);
            string message = EAM.LettersPostCMS.LettersMessage.Text;
            int index = message.IndexOf(':') + 1;
            string jobId = message.Substring(index, message.Length - (index));
            GlobalRef.LettersJobId = jobId;
            
        }

        
        [When(@"Generated letter for Plan ID as ""(.*)"" PBP as ""(.*)"" Letter Name as ""(.*)""  is read from letter location")]
        [Given(@"Generated letter for Plan ID as ""(.*)"" PBP as ""(.*)"" Letter Name as ""(.*)""  is read from letter location")]
        [Then(@"Generated letter for Plan ID as ""(.*)"" PBP as ""(.*)"" Letter Name as ""(.*)""  is read from letter location")]
        public void WhenGeneratedLetterForPlanIDAsPBPAsLetterNameAsIsReadFromLetterLocation(string planID, string pbpid, string letterName)
        {
            planID = tmsCommon.GenerateData(planID);
            string pbp = tmsCommon.GenerateData(pbpid);
            pbp = pbp.Substring(0, 3);
            string jobID = GlobalRef.letterJobID.ToString().PadLeft(6, '0');
            var letterLocation = GlobalRef.LetterLocation + "\\" + jobID.ToString() + "_" + letterName + "_" + planID + "_" + pbp + ".pdf";
            GlobalRef.LetterData = ReadFileFunctions.ReadPDFFile(letterLocation.ToString());
        }


        [Then(@"location is noted for letter PDF for Plan ID as ""(.*)"" PBP as ""(.*)"" and Letter Name as ""(.*)""")]
        public void ThenLocationIsNotedForLetterPDFForPlanIDAsPBPAsAndLetterNameAs(string planId, string pbpid, string letterName)
        {
            string pbp = tmsCommon.GenerateData(pbpid);
            string planID = tmsCommon.GenerateData(planId);
            string jobID = GlobalRef.LettersJobId.ToString().Trim();
            string appServerUrl = ConfigFile.URL;
            string[] URLParts = ConfigFile.URL.Split('/');
            string newTenant = (URLParts[2].Split('.'))[0].ToUpper();
            int index = appServerUrl.IndexOf('/');
            int index2 = appServerUrl.IndexOf('/', index + 1);
            string subs = appServerUrl.Substring(index2 + 1, 32);
            string[] path = subs.Split('.');
            var letterLocation = "\\\\" + path[1] + "\\TMSShareFolder" + "\\" + newTenant.ToString() + "\\EAM\\Letter\\" + jobID.ToString() + "_" + letterName + "_" + planID + "_" + pbp + ".pdf";
            GlobalRef.LetterLocation = letterLocation.ToString();
        }

        [Then(@"verify text ""(.*)"" in the letter PDF")]
        public void ThenVerifyTextInTheLetterPDF(string p0)
        {
            string letterValidationText = tmsCommon.GenerateData(p0);
            tmsWait.Hard(10);
            string letterLocation = GlobalRef.LetterLocation.ToString();
            string pdfText = ReadFileFunctions.ReadPDFFile(letterLocation);
            Assert.IsTrue(pdfText.ToUpper().Contains(letterValidationText), "PDF File missed expected data. Failed...");
        }

        
        [When(@"verify ""(.*)"" placeholder")]
        public void WhenVerifyPlaceholder(string PlaceholderName)
        {
            string dbQueryResult = GlobalRef.DBQueryResult.ToString();
            char[] delim = { ',' };
            string[] dbvalues = dbQueryResult.Split(delim);

            string valuefromDB = "";
            string valuefromLetter = ReadPlaceHolderValue(PlaceholderName);
            switch (PlaceholderName.ToUpper().Trim())
                {
                    case "COVERAGE NO COV LAST DAY PLUSONE":
                        string date = dbvalues[2];
                        DateTime Date;
                    bool con = DateTime.TryParse(date, out Date);
                        valuefromDB = Date.ToString("MM/dd/yyyy"); break;
                case "DATE IEP 2 START": valuefromDB = calculateIPE2StartDate(dbvalues[1]); break;
                case "DATE IEP 2 END": valuefromDB = calculateIPE2EndDate(dbvalues[1]); break;
                case "IEP 2 START PAST FUTURE": valuefromDB = calculateIPE2StartpastFuture(calculateIPE2StartDate(dbvalues[1])); break;
                case "ENROLL STATUS": valuefromDB = dbvalues[5]; break;
                case "PREMIUM WITH HOLD MEMBER": valuefromDB = dbvalues[6]; break;
                case "IS RETROACTIVE": valuefromDB = IsRetroactive(dbvalues[2]); break;
                
                    case "NUN CMO":
                        if (dbvalues[0] == "000") valuefromDB = "0";
                        else valuefromDB = dbvalues[0].TrimStart(new char[] { '0' }); break;

                    case "ENROLL PD FIRST TIME":
                        if (dbvalues[3].Trim().Equals("F")) dbvalues[3] = "New Enrollee";
                        else dbvalues[3] = "Has previous Part D";
                        valuefromDB = dbvalues[3]; break;
                default: Console.WriteLine("placeholder is not haldled"); break;
                 }
            bool compareresult = valuefromDB.Equals(valuefromLetter.Trim());
            Assert.IsTrue(compareresult, "Value for " + PlaceholderName + " is displayed as " + valuefromLetter + ". value of placeholder should be " + valuefromDB);
                                
            }
        public string calculateIPE2StartpastFuture(string IPEStartDate)
        {
            DateTime IPE2StartDate;
            bool con = DateTime.TryParse(IPEStartDate, out IPE2StartDate);
            DateTime currentTime = DateTime.Now;
            int result = DateTime.Compare(currentTime, IPE2StartDate);
            if (result > 0) return "1";
            if (result == 0) return "0";
            else return "0";
        }
        public string IsRetroactive(string EffectiveDate)
        {
            DateTime effectiveDate;
            bool con = DateTime.TryParse(EffectiveDate, out effectiveDate);
            DateTime currentTime = DateTime.Now;
           int result = DateTime.Compare(currentTime, effectiveDate);
            if (result > 0) return "1";
            if (result == 0) return "0";
            else return "0";
        }
        public string calculateIPE2StartDate(string DOB)
        {
            
            DateTime birthdate = Convert.ToDateTime(DOB);
            DateTime sixtyfifthbday = birthdate.AddYears(65);
            sixtyfifthbday = sixtyfifthbday.Date;
            DateTime ipe2start = sixtyfifthbday.AddMonths(-3);
            ipe2start = new DateTime(ipe2start.Year, ipe2start.Month, 1);
            string ipestart = ipe2start.ToString("MM/dd/yyyy");
            return ipestart;
        }
        public string calculateIPE2EndDate(string DOB)
        {
            DateTime birthdate = Convert.ToDateTime(DOB);
            DateTime sixtyfifthbday = birthdate.AddYears(65);
            sixtyfifthbday = sixtyfifthbday.Date;
            DateTime ipe2start = sixtyfifthbday.AddMonths(3);
            ipe2start = new DateTime(ipe2start.Year, ipe2start.Month, DateTime.DaysInMonth(ipe2start.Year, ipe2start.Month));
            string ipestart = ipe2start.ToString("MM/dd/yyyy");
            return ipestart;
        }
        public static string RemoveSpecialCharacters(string str)
        {
            return Regex.Replace(str, "[^a-zA-Z0-9_./ ]+", "", RegexOptions.Compiled);
        }
        public string ReadPlaceHolderValue(string PlaceholderName)
        {
            string letterdata = GlobalRef.LetterData.ToString();
            char[] split1 = { '\n' };
            string valueofplacehlder = "";
            string[] rows = letterdata.Split(split1);
            foreach (string placehlder in rows)
            {
                if (placehlder.Contains(PlaceholderName))
                {
                    int position = placehlder.LastIndexOf(PlaceholderName);
                    int adjustedPosA = position + PlaceholderName.Length;
                     valueofplacehlder = placehlder.Substring(adjustedPosA);
                    valueofplacehlder = RemoveSpecialCharacters(valueofplacehlder);
                    break;
                }
            }
            return valueofplacehlder;
        }
        [When(@"Verify that ""(.*)"" exist at Letter Names page")]
        public void WhenVerifyThatExistAtLetterNamesPage(string templatename)
        {
            IWebElement lettername;
            templatename = tmsCommon.GenerateData(templatename);
            string xpath = ".//tr/td[text()='"+ templatename + "']";
            try
            {
                Console.WriteLine(templatename + "exists");
                lettername = Browser.Wd.FindElement(By.XPath(xpath));
            }
            catch
            {
                EAM.LettersTemplate.OnDemandLetterNamesAddButton.Click();
                WhenAddLetterNameDialogLetterNameIsSetTo(templatename);
                tmsWait.Hard(1);
                EAM.LettersTemplate.AddLetterNameSaveButton.Click();
                tmsWait.Hard(1);
            }
            //again try to capture element

             lettername = Browser.Wd.FindElement(By.XPath(xpath));
            if(lettername.Displayed == true)
            {
                Console.WriteLine(templatename + "is added to the application");
            }
        }


        [When(@"Verify that ""(.*)"" mapped to ""(.*)"" exist at OnDemand Letter template page")]
        [Then(@"Verify that ""(.*)"" mapped to ""(.*)""exist at OnDemand Letter template page")]
        [Then(@"Verify that ""(.*)"" mapped to ""(.*)"" exist at OnDemand Letter template page")]
        public void ThenVerifyThatMappedToExistAtOnDemandLetterTemplatePage(string TemplateName, string TCSTemplate)
        {
            IWebElement TemplateMapped;
            string TCStemplate = "";
            TCStemplate = GlobalRef.TCSTemplateExist.ToString();
            TemplateName = tmsCommon.GenerateData(TemplateName);

            if (TCStemplate.Equals("DonotExistAlready"))
            {
                string xpath = ".//span[text()='" + TemplateName + "']/parent::node()/following-sibling::td/span[text()='" + TCSTemplate + "']";
                try
                {
                    TemplateMapped = Browser.Wd.FindElement(By.XPath(xpath));
                }
                catch
                {
                    EAM.LettersTemplate.OnDemandLetterTempAddButton.Click();
                    tmsWait.Hard(1);
                    WhenAddLetterTemplateDialogLetterNameIsSetTo(TemplateName);
                    WhenAddLetterTemplateDialogTCSTemplateIDIsSetTo(TCSTemplate);
                    EAM.LettersTemplate.SaveButton.Click();
                }
                //again try to capture element

                TemplateMapped = Browser.Wd.FindElement(By.XPath(xpath));
                if (TemplateMapped.Displayed == true)
                {
                    Console.WriteLine(TemplateName + "is mapped to " + TCSTemplate);
                }
               }
          }

        
        [When(@"On Demand Letter Names page new letter ""(.*)"" is created")]
        public void WhenOnDemandLetterNamesPageNewLetterIsCreated(string p0)
        {
            EAM.LettersTemplate.OnDemandLetterNamesAddButton.Click();
            tmsWait.Hard(1);
            string letterName = tmsCommon.GenerateData(p0);
            EAM.LettersTemplate.AddLetterNameDialogLetterNameTextBox.SendKeys(letterName);
            EAM.LettersTemplate.AddLetterNameSaveButton.Click();
        }

       

        [Then(@"On Demand Letter Template page new letter template ""(.*)"" is mapped to TCS Template")]
        public void ThenOnDemandLetterTemplatePageNewLetterTemplateIsMappedToTCSTemplate(string p0)
        {


            string TemplateName = tmsCommon.GenerateData(p0);
            EAM.LettersTemplate.OnDemandLetterTempAddButton.Click();
            tmsWait.Hard(1);
            WhenAddLetterTemplateDialogLetterNameIsSetTo(TemplateName);

            By Drp = By.XPath("//kendo-dropdownlist//span[@class='k-select']");

            By typeapp = By.XPath("//li[text()='" + TemplateName + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            //// WhenAddLetterTemplateDialogTCSTemplateIDIsSetTo(TCSTemplate);
            //OpenQA.Selenium.Support.UI.SelectElement TCSTemplate = new SelectElement(EAM.LettersTemplate.AddLetterTempdialogTCSTemplateIDdropdown);
            //TCSTemplate.SelectByIndex(1);
            EAM.LettersTemplate.SaveButton.Click();
        }


        [When(@"Verify that ""(.*)"" exist at OnDemand Letter template page")]
        public void WhenVerifyThatExistAtOnDemandLetterTemplatePage(string TCSTemplate)
        {
            IWebElement TemplateExist;
            
            string xpath = ".//span[text()='" + TCSTemplate + "']";
            try
            {
                TemplateExist = Browser.Wd.FindElement(By.XPath(xpath));
                if (TemplateExist.Displayed) GlobalRef.TCSTemplateExist = "alreadyExist";
                //assign the template name to any golbal variable and use it. below xpath returns the template name
                string xpathfortemplatename = ".//span[text() ='" + TCSTemplate + "']/parent::node()/preceding-sibling::td/span";
                IWebElement templatename = Browser.Wd.FindElement(By.XPath(xpathfortemplatename));
                GeneratedUserID = tmsCommon.GenerateData(templatename.Text.ToString());
                fw.setVariable("TemplateName", GeneratedUserID);
            }
            catch
            {
                GlobalRef.TCSTemplateExist = "DonotExistAlready";
            }
        }

        [Then(@"Verify EENRL Letter window PDF Frame has data ""(.*)""")]
        public void ThenVerifyEENRLLetterWindowPDFFrameHasData(string p0)
        {
            string tobeVerifyData = tmsCommon.GenerateData(p0);
            var letterData = GlobalRef.LetterData;
            Assert.IsTrue(letterData.ToString().Contains(tobeVerifyData));
        }


        [Then(@"EENRL Letter Window is closed")]
        public void ThenEENRLLetterWindowIsClosed()
        {
            tmsWait.Hard(1);
            string titleWin = "E*ENRL Letter";

            List<string> w = new List<string>(Browser.Wd.WindowHandles);
            for (int i = 0; i < w.Count; i++)
            {

                if (Browser.Wd.SwitchTo().Window(w[i]).Title.Equals(titleWin))
                {
                    Browser.Wd.SwitchTo().Window(w[i]).Close();
                }
            }
            Browser.SwitchToParentWindow();
        }



        [When(@"View Edit Member page Correspondence tab is Clicked")]
        public void WhenViewEditMemberPageCorrespondenceTabIsClicked()
        {
            fw.ExecuteJavascript(EAM.MemberInformation.CorrespondenceTab);
        }

        [Then(@"Verify View Edit Member page Correspondence tab Letter Name ""(.*)"" is displayed")]
        public void ThenVerifyViewEditMemberPageCorrespondenceTabLetterNameIsDisplayed(string p0)
        {
            tmsWait.Hard(2);
            IWebElement letterPresence = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_ucCorrespondence_gvCORR']//tr[contains(.,'"+p0+"')]"));
            Assert.IsTrue(letterPresence.Displayed, p0 + "is not getting displayed");
            
        }

        [Then(@"Verify View Edit Member page Correspondence tab Letter Name ""(.*)"" is not displayed")]
        public void ThenVerifyViewEditMemberPageCorrespondenceTabLetterNameIsNotDisplayed(string p0)
        {
            tmsWait.Hard(2);
            IWebElement letterPresence = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_ucCorrespondence_gvCORR']//tr[contains(.,'" + p0 + "')]"));
            Assert.IsFalse(letterPresence.Displayed, p0 + "is getting displayed");

        }

        [Then(@"Verify Correspondence tab table has row for ""(.*)"" and ""(.*)""")]
        public void ThenVerifyCorrespondenceTabTableHasRowForAnd(string p0, string p1)
        {



          IWebElement letterPresen = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_ucCorrespondence_gvCORR']/tbody//tr/td[contains(text(),'Acknowledgment of Disenrollment Letter')]/following-sibling::td[contains(text(),'Pre-CMS')]"));
            Assert.IsTrue(letterPresen.Displayed, p0 + "is not getting displayed");
        }

        [Then(@"Verify Correspondence tab table displayed below row")]
        public void ThenVerifyCorrespondenceTabTableDisplayedBelowRow(Table table)
        {
            //tmsWait.Implicit(60);
            try
            {
             
                IWebElement objWebTable = EAM.MembersNewTabCorrespondence.CorrespondenceTabTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                tmsWait.Hard(5);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Members View Edit Correspondence Table has row: {0}", e.Message);
            }


        }




        [Then(@"Reports Send to CMS Queue Report is closed")]
        public void ThenReportsSendToCMSQueueReportIsClosed()
        {
            try
            {
                ReportsCommon.CloseReport();
            }
            catch (Exception e)
            {
                Assert.Fail("Send to CMS Report was not closed. Exception: {0}", e.Message);
            }


        }


        [When(@"Incomplete Transaction Report page Plan ID is set to ""(.*)""")]
        public void WhenIncompleteTransactionReportPagePlanIDIsSetTo(string p0)
        {

            SelectElement pbpid = new SelectElement(EAM.IncompleteTransactionReport.PlanID);
            pbpid.SelectByText(p0);
        }

        [When(@"Incomplete Transaction Report page PBP ID is set to ""(.*)""")]
        public void WhenIncompleteTransactionReportPagePBPIDIsSetTo(string p0)
        {

            SelectElement pbpid = new SelectElement(EAM.IncompleteTransactionReport.PBPID);
            pbpid.SelectByText(p0);
        }

       

        [Then(@"Verify Reports Denial window table has row ""(.*)""")]
        public void ThenVerifyReportsDenialWindowTableHasRow(string p0)
        {

            string[] temp = p0.ToString().Split(',');

            By reportViewBy = EAM.Reports.ReportMainViewBy;

            ReadOnlyCollection<string> windowHandles = Browser.Wd.WindowHandles;
            bool next = true;

            foreach (string handle in windowHandles)
            {
                if (handle != currentHandle)
                {
                    childWindow = handle;
                    Browser.Wd.SwitchTo().Window(childWindow).SwitchTo().Frame(0);
                    do
                    {

                        foreach (string value in temp)
                        {
                            string valuePresencecheck = tmsCommon.GenerateData(value);

                           valuePresenceonReport(valuePresencecheck);                      

                        }
                        next = Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl05_ctl00_Next_ctl00_ctl00")).Displayed;

                        if (next)
                        {
                            Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl05_ctl00_Next_ctl00_ctl00")).Click();
                        }

                    } while (next);


                }

            }
            Browser.Wd.SwitchTo().Window(childWindow).Close();
            Browser.Wd.SwitchTo().Window(currentHandle);


        }


        string childWindow = null;
        [Then(@"Verify Reports Send to CMS Queue window has no ""(.*)""")]
        public void ThenVerifyReportsSendToCMSQueueWindowHasNo(string p0)
        {
            string[] temp = p0.ToString().Split(',');

            By reportViewBy = EAM.Reports.ReportMainViewBy;

            ReadOnlyCollection<string> windowHandles = Browser.Wd.WindowHandles;
            bool next = true;

            foreach (string handle in windowHandles)
            {
                if (handle != currentHandle)
                {
                    childWindow = handle;
                    Browser.Wd.SwitchTo().Window(childWindow).SwitchTo().Frame(0);
                    do
                    {
                        
                        foreach (string value in temp)
                        {
                            string valuePresencecheck = tmsCommon.GenerateData(value);

                            valuePresenceonReport(valuePresencecheck);
                            

                        }
                        next = Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl05_ctl00_Next_ctl00_ctl00")).Displayed;

                        if(next)
                        {
                            Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl05_ctl00_Next_ctl00_ctl00")).Click();
                        }

                    } while (next);


                }

            }
            Browser.Wd.SwitchTo().Window(childWindow).Close();
            Browser.Wd.SwitchTo().Window(currentHandle);


        }

        void valuePresenceonReport(string value)
        {
            IWebElement reportTable=Browser.Wd.FindElement(By.Id("ReportViewerControl_ctl09"));
            IList<IWebElement> theseTDs = reportTable.FindElements(By.TagName("td"));
            IList<IWebElement> theseTRs = reportTable.FindElements(By.TagName("tr"));
            List<string> compiledTRText = new List<string>();
            List<string> compiledTRTextsp = new List<string>();

            foreach (IWebElement thisTR in theseTRs)
            {
                string thisTRString = thisTR.Text.Replace("\n", "");
                thisTRString = thisTRString.Replace("\r", "");
                if (thisTRString.Trim() != "")
                {
                    compiledTRText.Add(thisTRString.Trim());
                    string thisTRStringsp = thisTR.Text.Replace("\n\r", " ");
                    thisTRStringsp = thisTRStringsp.Replace("\r\n", " ");
                    compiledTRTextsp.Add(thisTRStringsp.Trim());
                }
            }

            foreach (string AppTRow in compiledTRTextsp)
            {
                if (AppTRow.ToLower().Trim().Contains(value.ToLower()))
                {
                    tmsWait.Hard(2);
                    Assert.IsTrue(true, value+" is not getting displayed");
                    Console.WriteLine("[" + value + "] is found report ");
                    break;
                }
                if (AppTRow.ToLower().Trim().Contains(value))
                {
                    tmsWait.Hard(2);
                    Assert.IsTrue(true, value + " is not getting displayed");
                    Console.WriteLine("[" + value + "] is found report ");
                    break;
                }
                if (!AppTRow.Trim().Contains(value))
                {
                    tmsWait.Hard(2);
                 
                    Assert.IsFalse(false, value + " is getting displayed");
                    Console.WriteLine(" [" + value + "] is not found in report ");
                    break;
                }


            }
           


        }

        [When(@"Incomplete Transaction Report page Run Report button is Clicked")]
        public void WhenIncompleteTransactionReportPageRunReportButtonIsClicked()
        {
            EAM.IncompleteTransactionReport.RunReportbutton.Click();

            tmsWait.Hard(3);
            if (ConfigFile.BrowserType.ToString().ToLower().Equals("chrome"))
            {
                Browser.winium.FindElement(By.Name("Username")).SendKeys(ConfigFile.DBUser);
               // //System.Windows.Forms.SendKeys.SendWait("{TAB}");
                Browser.winium.FindElement(By.Name("Password")).SendKeys(ConfigFile.DBPassword);
                //System.Windows.Forms.SendKeys.SendWait("{TAB}");
                //System.Windows.Forms.SendKeys.SendWait("{ENTER}");
            }
            if (ConfigFile.BrowserType.ToString().ToLower().Equals("ff"))
            {


                Browser.winium.FindElement(By.Name("User Name:")).SendKeys(ConfigFile.DBUser);
                //System.Windows.Forms.SendKeys.SendWait("{TAB}");
                Browser.winium.FindElement(By.Name("Password:")).SendKeys(ConfigFile.DBPassword);
                //System.Windows.Forms.SendKeys.SendWait("{TAB}");
                //System.Windows.Forms.SendKeys.SendWait("{ENTER}");
            }
        }


        [Then(@"Verify Reports Denial window table has row")]
        public void ThenVerifyReportsDenialWindowTableHasRow(Table table)
        {
            By reportViewBy = EAM.Reports.ReportMainViewBy;
            string reportHandle = ReportsCommon.SwitchToReportWindow(reportViewBy, 30, "Denial Report");

            if (reportHandle == "")
            {
                Assert.Fail(" Incomplete Transaction Report was not opened");
            }

            try
            {
                By reportTableBy = By.XPath("//table[contains(., 'HIC')]");
                ReportsCommon.VerifyReportTableHasRow(reportTableBy, table);

            }
            catch (Exception e)
            {
                //       Browser.Wd.SwitchTo().Window(ReportsCommon.ReportWindowHandle).Close();
                //        Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle).Close();
                Assert.Fail("Verify  Incomplete Transaction Report table has row. Exception: {0}", e.Message);
            }

            Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle);




        }

        [Then(@"Reports Denial window is closed")]
        public void ThenReportsDenialWindowIsClosed()
        {

            tmsWait.Hard(1);
            string titleWin = "EAM";

            List<string> w = new List<string>(Browser.Wd.WindowHandles);
            for (int i = 0; i < w.Count; i++)
            {

                if (Browser.Wd.SwitchTo().Window(w[i]).Title.Equals(titleWin))
                {
                    Browser.Wd.SwitchTo().Window(w[i]).Close();
                }
            }
        }


        [Then(@"Verify Reports Incomplete Transaction window table has row")]
        public void ThenVerifyReportsIncompleteTransactionWindowTableHasRow(Table table)
        {

            By reportViewBy = EAM.Reports.ReportMainViewBy;
            string reportHandle = ReportsCommon.SwitchToReportWindow(reportViewBy, 30, "Incomplete Transaction Report");

            if (reportHandle == "")
            {
                Assert.Fail(" Incomplete Transaction Report was not opened");
            }

            try
            {
                By reportTableBy = By.XPath("//table[contains(., 'HIC')]");
                ReportsCommon.VerifyReportTableHasRow(reportTableBy, table);

            }
            catch (Exception e)
            {
                //       Browser.Wd.SwitchTo().Window(ReportsCommon.ReportWindowHandle).Close();
                //        Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle).Close();
                Assert.Fail("Verify  Incomplete Transaction Report table has row. Exception: {0}", e.Message);
            }

            Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle);

        }



        [Then(@"Verify Reports Send to CMS Queue window table has no row")]
        public void ThenVerifyReportsSendToCMSQueueWindowTableHasNoRow(Table table)
        {

            //tmsWait.Hard(2);
            //string titleWin = "EAM";

            ////Add ids of all the opened window on screen.These ids will be set to specific windows which are opened in order.
            //List<string> w = new List<string>(Browser.Wd.WindowHandles);

            //// Set window id and switch to any window
            //for (int i = 0; i < w.Count; i++)
            //{
            //    if (Browser.Wd.SwitchTo().Window(w[i]).Title.Equals(titleWin))
            //        Browser.Wd.SwitchTo().Window(w[i]);
            //}

            By reportViewBy = EAM.Reports.ReportMainViewBy;
            string reportExpText = "Send to CMS Queue Report";
            string reportHandle = "";


            reportHandle = ReportsCommon.SwitchToReportWindow(reportViewBy, 60, reportExpText);

            if (reportHandle == "")
            {
                Assert.Fail(" Send to CMS Queue Report was not opened");
            }

            try
            {
                ReportsCommon.VerifyReportDoesNotHaveData(reportViewBy, reportExpText, table);
            }
            catch (Exception e)
            {
                Assert.Fail("Verify Send to CMS Queue Report has data that should not be there. ");
            }
            Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle);

        }

        [When(@"Denial Report page ""(.*)"" field is set to ""(.*)""")]
        public void WhenDenialReportPageFieldIsSetTo(string p0, string p1)
        {

            string field = p0.ToString();

            string value = p1.ToString();
            string TodayDate = DateTime.Now.ToString("MM/dd/yyyy");
            //string CustTodayDate=TodayDate.Replace("/", "");

            switch (field)

            {

                case "Plan ID":
                    SelectElement planid = new SelectElement(EAM.DenialReport.PlanID);
                    planid.SelectByText(value);
                    break;

                case "PBP ID":
                    SelectElement pbp = new SelectElement(EAM.DenialReport.PBPID);
                    pbp.SelectByText(value);

                    break;
            }

        }

        [When(@"Denial Report page Run Report button is Clicked")]
        public void WhenDenialReportPageRunReportButtonIsClicked()
        {
            currentHandle = Browser.Wd.CurrentWindowHandle;
            EAM.DenialReport.RunReportbutton.Click();
            tmsWait.Hard(3);

            ReUsableFunctions.reportAuthenticationHandler();
        }



        [When(@"Send To CMS Queue Report page ""(.*)"" field is set to ""(.*)""")]
        public void WhenSendToCMSQueueReportPageFieldIsSetTo(string p0, string p1)
        {
            string field = p0.ToString();

            string value = p1.ToString();
            string TodayDate = DateTime.Now.ToString("MM/dd/yyyy");
            //string CustTodayDate=TodayDate.Replace("/", "");

            switch (field)

            {

                case "Plan ID":
                    SelectElement planid = new SelectElement(EAM.SendToCMSQueueReport.PlanID);
                    planid.SelectByText(value);

                    break;

                case "PBP ID":
                    SelectElement pbpid = new SelectElement(EAM.SendToCMSQueueReport.PBPID);
                    pbpid.SelectByText(value);
                    break;

                case "Effective Date From":

                   //tmsWait.Hard(1);
                   // EAM.SendToCMSQueueReport.EffectiveDateFrom.Clear();
                   // tmsWait.Hard(1);
                   // EAM.SendToCMSQueueReport.EffectiveDateFrom.Click();
                   //tmsWait.Hard(1);
                    EAM.SendToCMSQueueReport.EffectiveDateFrom.SendKeys(Keys.Home);
                    tmsWait.Hard(1);
                    EAM.SendToCMSQueueReport.EffectiveDateFrom.SendKeys(TodayDate);
                    break;
                case "Effective Date To":
                    EAM.SendToCMSQueueReport.EffectiveDateTo.Clear();
                    EAM.SendToCMSQueueReport.EffectiveDateTo.Click();
                    EAM.SendToCMSQueueReport.EffectiveDateTo.SendKeys(Keys.Home);
                    tmsWait.Hard(2);
                    EAM.SendToCMSQueueReport.EffectiveDateTo.SendKeys(TodayDate);
                    break;

            }
        }

       



        [When(@"ERF page Submit button is Clicked")]
        public void WhenERFPageSubmitButtonIsClicked()
        {
          
            IJavaScriptExecutor jse = (IJavaScriptExecutor)Browser.Wd;
            jse.ExecuteScript("document.getElementById('ButtonSubmitAjax').click();");

            do
            {
                if (tmsWait.IsAlertPresent())
                    Browser.ClosePopUps(true);
                tmsWait.Hard(3);
            } while (tmsWait.IsAlertPresent());


            

        }


        [Then(@"View Edit Member page OEC Sales Tab is clicked")]
        public void ThenViewEditMemberPageOECSalesTabIsClicked()
        {
            EAM.MembersNewTabOECSales.OECSalesTabLink.Click();
        }

        [Then(@"ERF page Medicare Insurance Part A Effective Date is set to ""(.*)""")]
        public void ThenERFPageMedicareInsurancePartAEffectiveDateIsSetTo(string p0)
        {
            EAM.ERF.MedicareInsurancePartAEffectiveDate.Clear();
            EAM.ERF.MedicareInsurancePartAEffectiveDate.Click();
            EAM.ERF.MedicareInsurancePartAEffectiveDate.SendKeys(p0);

        }

        [Then(@"ERF page Medicare Insurance Part B Effective Date is set to ""(.*)""")]
        public void ThenERFPageMedicareInsurancePartBEffectiveDateIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            GeneratedData = GeneratedData.Replace("/", "");
            EAM.ERF.MedicareInsurancePartBEffectiveDate.Clear();

            EAM.ERF.MedicareInsurancePartBEffectiveDate.Click();
            EAM.ERF.MedicareInsurancePartBEffectiveDate.SendKeys(Keys.Home);
            EAM.ERF.MedicareInsurancePartBEffectiveDate.SendKeys(p0);
        }


        [Then(@"Verify Error message display ""(.*)""")]
        public void ThenVerifyErrorMessageDisplay(string p0)
        {
            tmsWait.Hard(1);

            string expected = p0.ToString(); 
            if (expected.Contains("Part A Effective Date must be a valid date and must be the first day of the Month."))
            {
                string actual = EAM.ERF.PartAEffectiveDateToolTip.Text;
                Assert.AreEqual(actual, expected, "Both values getting matched");
                fw.ConsoleReport(" Tool tip displayed " + expected);
            }
            else if (expected.Contains("Part B Effective Date must be a valid date and must be the first day of the Month."))
            {
                string actual = EAM.ERF.PartBEffectiveDateToolTip.Text;
                Assert.AreEqual(actual, expected, "Both values getting matched");
                fw.ConsoleReport(" Tool tip displayed " + expected);
            }

            else if (expected.Contains("Part A Effective Date is not a valid date."))
            {
                string actual = EAM.ERF.PartAEffectiveDateToolTip1.Text;
                Assert.AreEqual(actual, expected, "Both values getting matched");
                fw.ConsoleReport(" Tool tip displayed " + expected);
            }
            else if (expected.Contains("Part B Effective Date is not a valid date."))
            {
                string actual = EAM.ERF.PartBEffectiveDateToolTip1.Text;
                Assert.AreEqual(actual, expected, "Both values getting matched");
                fw.ConsoleReport(" Tool tip displayed " + expected);
            }

            else if (expected.Contains("Part A Effective Date cannot be less than 01/01/1900 and greater than 06/01/2079."))
            {
                string actual = EAM.ERF.PartAEffectiveDateToolTip2.Text;
                Assert.AreEqual(actual, expected, "Both values getting matched");
                fw.ConsoleReport(" Tool tip displayed " + expected);
            }
            else if (expected.Contains("Part B Effective Date cannot be less than 01/01/1900 and greater than 06/01/2079."))
            {
                string actual = EAM.ERF.PartBEffectiveDateToolTip2.Text;
                Assert.AreEqual(actual, expected, "Both values getting matched");
                fw.ConsoleReport(" Tool tip displayed " + expected);
            }

            else if (expected.Contains("Part A Effective Date must be a valid date and must be the first day of the Month."))
            {
                string actual = EAM.ERF.PartAEffectiveDateToolTip3.Text;
                Assert.AreEqual(actual, expected, "Both values getting matched");
                fw.ConsoleReport(" Tool tip displayed " + expected);
            }

            else if (expected.Contains("Part B Effective Date must be a valid date and must be the first day of the Month."))
            {
                string actual = EAM.ERF.PartBEffectiveDateToolTip3.Text;
                Assert.AreEqual(actual, expected, "Both values getting matched");
                fw.ConsoleReport(" Tool tip displayed " + expected);
            }
            else if (expected.Contains("Election Type is required."))
            {
                string actual = EAM.ERF.ERFResultsmsg.Text;
                Assert.AreEqual(actual, expected, "Both values getting matched");
                fw.ConsoleReport(" Tool tip displayed " + expected);
            }






        }


        [Then(@"Verify OEC Sales Table Sales Rep is set to ""(.*)""")]
        public void ThenVerifyOECSalesTableSalesRepIsSetTo(string p0)
        {
            string fieldName = "Member Info Page OEC Sales tab Sales Rep ";
            string GeneratedData = tmsCommon.GenerateData(p0);

            //SelectElement sales = new SelectElement(EAM.MembersNewTabOECSales.SalesRep);
            string thisFieldValue = EAM.MembersNewTabOECSales.SalesRep.GetAttribute("value");
            Assert.AreEqual(GeneratedData, thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");

        }


        [Then(@"ERF page Submit button is Clicked")]
        public void ThenERFPageSubmitButtonIsClicked()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.Id("ButtonSubmitAjax")));

            try
            {
                tmsWait.Hard(2);
                IAlert alert = Browser.Wd.SwitchTo().Alert();
                alert.Accept();
                tmsWait.Hard(2);

            }
            catch
            {
                fw.ConsoleReport(" There is no Alert Presence");
            }
            try {
                if (Browser.Wd.FindElement(By.XPath("//button/span[contains(.,'Continue Anyway')]")).Displayed)
                {
                    tmsWait.Hard(5);
                    Browser.Wd.FindElement(By.XPath("//button/span[contains(.,'Continue Anyway')]")).Click();
                }
            }
            
            catch
            {
                Console.WriteLine("There is no continue anyway button");
            }

            try
            {
                tmsWait.Hard(2);
                IAlert alert = Browser.Wd.SwitchTo().Alert();
                alert.Accept();
                tmsWait.Hard(2);

            }
            catch
            {
                fw.ConsoleReport(" There is no Alert Presence");
            }
        }

        [Then(@"Switch from ERF Frame Page to EAM Page")]
        public void ThenSwitchFromERFFramePageToEAMPage()
        {
            //tmsWait.Hard(3);
            Browser.Wd.SwitchTo().DefaultContent();
           // Browser.Wd.Navigate().Refresh();
        }

        [Then(@"Verify ERF page ""(.*)"" field is disabled")]
        public void ThenVerifyERFPageFieldIsDisabled(string value)
        {
            IWebElement field = Browser.Wd.FindElement(By.Id(value));
            ReUsableFunctions.verifyComponentDisabled(field);
        }


        [Then(@"Verify ERF page displayed message ""(.*)""")]
        public void ThenVerifyERFPageDisplayedMessage(string p0)
        {
            tmsWait.Hard(2);
            try
            {
                IAlert alert = Browser.Wd.SwitchTo().Alert();
                alert.Accept();
                tmsWait.Implicit(10);
            }
            catch (NoAlertPresentException)
            {
                fw.ConsoleReport("No alert Present");
            }

            string expected = p0.ToString();
           // tmsWait.WaitForElement(By.XPath(".//*[@id='ResultMessage']"), 30);
            tmsWait.Hard(7);
            string actual = EAM.ERF.ERFResultsmsg.Text;

            Assert.IsTrue(actual.Contains(p0), "Expected message is not getting displayed on ERF Page");
          //  Assert.AreEqual(expected, actual, actual + " is displayed on ERF Page");

        }


        [Then(@"Verify View Edit Transaction page ""(.*)"" field is set to ""(.*)""")]
        public void ThenVerifyViewEditTransactionPageFieldIsSetTo(string p0, string p1)
        {
            string expectedField = p0.ToString();
            string expectedValue = p1.ToString();

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'" + expectedField + "')]/parent::div//div//input");

             string actualValue = Browser.Wd.FindElement(Drp).GetAttribute("value");
                Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");

               
                fw.ConsoleReport("Both Actual and Expected values are getting matched");
                tmsWait.Hard(3);


            }
            else
            {


                switch (expectedField)
                {
                    case "Plan1":


                        string plan1Actual = EAM.TransactionsViewEdit.Plan1.GetAttribute("value");
                        Assert.IsTrue(EAM.TransactionsViewEdit.Plan1.Enabled, "Plan1 Field is enabled");
                        fw.ConsoleReport("Plan1 Field is enabled");

                        Assert.AreEqual(expectedValue, plan1Actual, "Both values are getting matched");
                        fw.ConsoleReport("Both Actual and Expected values are getting matched");
                        break;

                    case "Plan2":


                        string plan2Actual = EAM.TransactionsViewEdit.Plan2.GetAttribute("value");
                        Assert.IsTrue(EAM.TransactionsViewEdit.Plan2.Enabled, "Plan2 Field is enabled");
                        fw.ConsoleReport("Plan2 Field is enabled");

                        Assert.AreEqual(expectedValue, plan2Actual, "Both values are getting matched");
                        fw.ConsoleReport("Both Actual and Expected values are getting matched");
                        break;

                    case "Plan3":


                        string plan3Actual = EAM.TransactionsViewEdit.Plan3.GetAttribute("value");
                        Assert.IsTrue(EAM.TransactionsViewEdit.Plan3.Enabled, "Plan3 Field is enabled");
                        fw.ConsoleReport("Plan3 Field is enabled");

                        Assert.AreEqual(expectedValue, plan3Actual, "Both values are getting matched");
                        fw.ConsoleReport("Both Actual and Expected values are getting matched");
                        break;

                    case "Plan4":


                        string plan4Actual = EAM.TransactionsViewEdit.Plan4.GetAttribute("value");
                        Assert.IsTrue(EAM.TransactionsViewEdit.Plan4.Enabled, "Plan4 Field is enabled");
                        fw.ConsoleReport("Plan4 Field is enabled");

                        Assert.AreEqual(expectedValue, plan4Actual, "Both values are getting matched");
                        fw.ConsoleReport("Both Actual and Expected values are getting matched");
                        break;
                    case "Plan5":


                        string plan5Actual = EAM.TransactionsViewEdit.Plan5.GetAttribute("value");
                        Assert.IsTrue(EAM.TransactionsViewEdit.Plan5.Enabled, "Plan5 Field is enabled");
                        fw.ConsoleReport("Plan5 Field is enabled");

                        Assert.AreEqual(expectedValue, plan5Actual, "Both values are getting matched");
                        fw.ConsoleReport("Both Actual and Expected values are getting matched");
                        break;

                    case "Plan6":


                        string plan6Actual = EAM.TransactionsViewEdit.Plan6.GetAttribute("value");
                        Assert.IsTrue(EAM.TransactionsViewEdit.Plan6.Enabled, "Plan6 Field is enabled");
                        fw.ConsoleReport("Plan6 Field is enabled");

                        Assert.AreEqual(expectedValue, plan6Actual, "Both values are getting matched");
                        fw.ConsoleReport("Both Actual and Expected values are getting matched");
                        break;
                    case "Plan7":


                        string plan7Actual = EAM.TransactionsViewEdit.Plan7.GetAttribute("value");
                        Assert.IsTrue(EAM.TransactionsViewEdit.Plan7.Enabled, "Plan7 Field is enabled");
                        fw.ConsoleReport("Plan7 Field is enabled");

                        Assert.AreEqual(expectedValue, plan7Actual, "Both values are getting matched");
                        fw.ConsoleReport("Both Actual and Expected values are getting matched");
                        break;
                    case "Plan8":


                        string plan8Actual = EAM.TransactionsViewEdit.Plan8.GetAttribute("value");
                        Assert.IsTrue(EAM.TransactionsViewEdit.Plan8.Enabled, "Plan8 Field is enabled");
                        fw.ConsoleReport("Plan8 Field is enabled");

                        Assert.AreEqual(expectedValue, plan8Actual, "Both values are getting matched");
                        fw.ConsoleReport("Both Actual and Expected values are getting matched");
                        break;

                    case "Plan9":


                        string plan9Actual = EAM.TransactionsViewEdit.Plan9.GetAttribute("value");
                        Assert.IsTrue(EAM.TransactionsViewEdit.Plan9.Enabled, "Plan9 Field is enabled");
                        fw.ConsoleReport("Plan9 Field is enabled");

                        Assert.AreEqual(expectedValue, plan9Actual, "Both values are getting matched");
                        fw.ConsoleReport("Both Actual and Expected values are getting matched");
                        break;

                    case "Plan10":


                        string plan10Actual = EAM.TransactionsViewEdit.Plan10.GetAttribute("value");
                        Assert.IsTrue(EAM.TransactionsViewEdit.Plan10.Enabled, "Plan10 Field is enabled");
                        fw.ConsoleReport("Plan10 Field is enabled");

                        Assert.AreEqual(expectedValue, plan10Actual, "Both values are getting matched");
                        fw.ConsoleReport("Both Actual and Expected values are getting matched");
                        break;

                    default:
                        fw.ConsoleReport(" Provied input is not matching");
                        break;

                }


            }
        }


        [When(@"Member ViewEdit page Action image is Clicked")]
        public void WhenMemberViewEditPageActionImageIsClicked()
        {
            EAM.MembersViewEdit.NotesScreenAddNewAction.Click();

            tmsWait.Hard(2);
        }

        [When(@"Notes Screen page New Action button is Clicked")]
        public void WhenNotesScreenPageNewActionButtonIsClicked()
        {
            EAM.MembersViewEdit.NewActionAddbutton.Click();
        }

        [When(@"New Action page Action Text area is set to ""(.*)""")]
        public void WhenNewActionPageActionTextAreaIsSetTo(string p0)
        {
           
        }

        [When(@"New Action page Due Date is set to ""(.*)""")]
        public void WhenNewActionPageDueDateIsSetTo(string p0)
        {
            
        }

        [When(@"New Action page Add Action button is Clicked")]
        public void WhenNewActionPageAddActionButtonIsClicked()
        {
           
        }

        [When(@"New Action page Add Close button is Clicked")]
        public void WhenNewActionPageAddCloseButtonIsClicked()
        {
           
        }

        [When(@"Notes Screen page Close button is clicked")]
        public void WhenNotesScreenPageCloseButtonIsClicked()
        {
           
        }
        //10/07/2015 - Notes and Action image is not visible on IE while running automation , so Automation is not yet done - Venkatesh P

        [When(@"Member ViewEdit page Attachment image is Clicked")]
        public void WhenMemberViewEditPageAttachmentImageIsClicked()
        {
            EAM.MembersViewEdit.ViewAttachment.Click();
        }

        [When(@"Member Documents dialog Attach button is Clicked")]
        public void WhenMemberDocumentsDialogAttachButtonIsClicked()
        {
            tmsWait.Hard(4);
            fw.ExecuteJavascript(EAM.MembersViewEdit.MemberDocAttachment);
        }
       
        [When(@"Dummy Text File is created with filename ""(.*)""")]
        public void WhenDummyTextFileIsCreatedWithFilename(string p0)
        {
            string generatedData = tmsCommon.GenerateData(p0);
            string fullFilepath = "c:\\temp\\" + generatedData;
            using (StreamWriter writer = new StreamWriter(fullFilepath))
            {
                for (int i = 0; i < 200; i++)
                {
                    writer.WriteLine(DateTime.Now.ToString());
                }
            }

        }


        [When(@"Attach Document dialog Document is attached with filename ""(.*)""")]
        public void WhenAttachDocumentDialogDocumentIsAttachedWithFilename(string p0)
        {
            tmsWait.Hard(2);
            string generatedData = tmsCommon.GenerateData(p0);
         //   string path = @"C:\Temp\Test.txt";
            string path = @"C:\tms\" + generatedData;
            TextWriter tw = new StreamWriter(path, true);
            tw.WriteLine("This is for EAM Testing line done by Automation Testing Team!");
            tw.Close();
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement selectButton = Browser.Wd.FindElement(By.XPath("//span[contains(.,'SELECT FILES')]/preceding-sibling::input"));
                selectButton.SendKeys(path);

            }

            else
            {
                EAM.MembersViewEdit.AttachDocBrowse.SendKeys(path);

            }
            EAM.MembersViewEdit.AttachDocUpload.Click();

        }

        [When(@"Attach Document dialog Description Text Area is set to ""(.*)""")]
        public void WhenAttachDocumentDialogDescriptionTextAreaIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            EAM.MembersViewEdit.AttachDocDesc.SendKeys(p0);
            //EAM.MembersViewEdit.AttachDocUpload.Click();
        }
        [When(@"Attach Document dialog Description Click on Add Button")]
        public void WhenAttachDocumentDialogDescriptionClickOnAddButton()
        {
            tmsWait.Hard(8);
            fw.ExecuteJavascript(EAM.MembersViewEdit.AttachDocAdd);
            tmsWait.Hard(2);
        }


        [Then(@"Verify Upload File dialog ""(.*)"" message displayed")]
        public void ThenVerifyUploadFileDialogMessageDisplayed(string p0)
        {
            tmsWait.Hard(2);
            string fieldName = "Upload File dialog  ";        

            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MembersViewEdit.UploadFileMessage.Text;
            Assert.AreEqual(expected, actual, "Field " + fieldName + " value is [" + expected + "], actual [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], actual [" + actual + "] - They are expected to match.");
            tmsWait.Hard(1);

            EAM.MembersViewEdit.UploadFileClose.Click();

        }

        [Then(@"Member Documents dialog displays Attached documents details")]
        public void ThenMemberDocumentsDialogDisplaysAttachedDocumentsDetails(Table table)
        {
            tmsWait.Hard(5);
             try
            {
                IWebElement objWebTable = EAM.MembersViewEdit.MemberDocAttachTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Members View Edit Table has row: {0}", e.Message);
            }
             tmsWait.Hard(2);
        }

        

        [Then(@"Member Documents dialog Close button is Clicked")]
        public void ThenMemberDocumentsDialogCloseButtonIsClicked()
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                IWebElement closeBtn= Browser.Wd.FindElement(By.XPath("//a[contains(@class,'close')]/span"));
                fw.ExecuteJavascript(closeBtn);
            }
            else
            {
                EAM.MembersViewEdit.MemberDocClose.Click();
            }
        }


        [When(@"Plan Defined Fields page OEV Letter Configuration is set to ""(.*)""")]
        public void WhenPlanDefinedFieldsPageOEVLetterConfigurationIsSetTo(string p0)
        {

            string oevswitch = tmsCommon.GenerateData(p0.ToLower());
            bool iselementpresent = false;

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(5);
                if (p0.ToLower().Equals("unchecked"))
                {
                    p0 = "off";
                }
                if (p0.Equals("checked"))
                {
                    p0 = "on";
                }
                string switchChk = Browser.Wd.FindElement(By.XPath("//kendo-switch[@test-id='oevletter-input-all']//span[@role='switch']")).GetAttribute("aria-checked");

                switch (p0.ToLower())
                {
                    case "on":

                        if (switchChk.Contains("false"))
                        {
                            Browser.Wd.FindElement(By.XPath("//kendo-switch[@test-id='oevletter-input-all']//span[@class='k-switch-handle']")).Click();
                        }
                        break;
                    case "off":
                        if (switchChk.Contains("true"))
                        {
                            Browser.Wd.FindElement(By.XPath("//kendo-switch[@test-id='oevletter-input-all']//span[@class='k-switch-handle']")).Click();
                        }
                        break;
                }
                tmsWait.Hard(2);
            }
            else
            {
                By OEVStatus = By.XPath("//div[@id='mainSwitchButtonArea']//span[contains(@class,'switch-" + oevswitch + "')]");
                if (oevswitch.Equals("on"))
                {
                    try
                    {
                        iselementpresent = Browser.Wd.FindElement(OEVStatus).Displayed;
                        fw.ConsoleReport(" OEV is already in ON Status");
                    }
                    catch
                    {
                        Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-container km-switch-container'])[1]")).Click();
                        tmsWait.Hard(2);
                    }
                }

                else if (oevswitch.Equals("off"))

                {
                    try
                    {
                        iselementpresent = Browser.Wd.FindElement(OEVStatus).Displayed;
                        fw.ConsoleReport(" OEV is already in OFF Status");
                    }
                    catch
                    {
                        Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-container km-switch-container'])[1]")).Click();
                        tmsWait.Hard(2);
                    }
                }

                //try
                //{
                //    iselementpresent = Browser.Wd.FindElement(By.XPath(xpath1)).Displayed;
                //}

                //catch
                //{
                //    //ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-container km-switch-container'])[1]")));
                //    Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-container km-switch-container'])[1]")).Click();
                //    tmsWait.Hard(2);
                //    iselementpresent = iselementpresent = Browser.Wd.FindElement(By.XPath(xpath1)).Displayed;
                //}

                //Assert.IsTrue(iselementpresent, "OEV Configuration is already switched " + oevswitch + " or Unable to switch " + oevswitch + "");

                //string GenerateData = tmsCommon.GenerateData(p0);


                //switch (GenerateData.ToLower())
                //{
                //    case "checked": { setCheckboxTo = "checked"; break; }
                //    case "on": { setCheckboxTo = "checked"; break; }
                //    case "yes": { setCheckboxTo = "checked"; break; }
                //    case "unchecked": { setCheckboxTo = "unchecked"; break; }
                //    case "off": { setCheckboxTo = "unchecked"; break; }
                //    case "no": { setCheckboxTo = "unchecked"; break; }
                //    default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
                //}

                //if (setCheckboxTo.Equals("unchecked"))
                //{
                //    if (EAM.AdministrationPlanDefinedFieldsOEVLetter.OEVLetterConfiguration.Selected == true)
                //    {
                //        EAM.AdministrationPlanDefinedFieldsOEVLetter.OEVLetterConfigurationAnchor.Click();
                //        Console.WriteLine("OEV Letter Configuration is set to " + GenerateData);
                //    }


                //}
                //else
                //{
                //    if (EAM.AdministrationPlanDefinedFieldsOEVLetter.OEVLetterConfiguration.Selected == false)
                //    {
                //        EAM.AdministrationPlanDefinedFieldsOEVLetter.OEVLetterConfigurationAnchor.Click();
                //        Console.WriteLine("OEV Letter Configuration is set to " + GenerateData);
                //    }
                //}

            }

        }

        [When(@"Transactions New County is set to ""(.*)""")]
        public void WhenTransactionsNewCountyIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string coutyvalue = tmsCommon.GenerateData(p0);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'County')]/parent::div//span[2]");
                By typeapp = By.XPath("//li[text()='" + coutyvalue + "']");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
            }
            else
            {
                By county = By.XPath("//div[@id='div_Transactioncode61ResidentialAddressupdateCounty']/span");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(county);
                tmsWait.Hard(1);
                UIMODUtilFunctions.selectTransDrpValue(coutyvalue);
            }
        }
        [When(@"Transactions New NewCounty is set to ""(.*)""")]
        public void WhenTransactionsNewNewCountyIsSetTo(string p0)
        {
           

        tmsWait.Hard(3);
            string coutyvalue = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {

                By Drp = By.XPath("//label[contains(.,'County')]/parent::div//input");

                Browser.Wd.FindElement(Drp).SendKeys(coutyvalue);
                tmsWait.Hard(3);


            }
            else
            {
                By county = By.XPath("//div[@id='div_Transactioncode61ResidentialAddressupdateCounty']/span");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(county);
                tmsWait.Hard(1);
                UIMODUtilFunctions.selectTransDrpValue(coutyvalue);
            }
        }

        [Then(@"Member page New MBI is set to ""(.*)"" and Clicked on Save button")]
        public void ThenMemberPageNewMBIIsSetToAndClickedOnSaveButton(string p0)
        {
            string mbivalue = tmsCommon.GenerateData(p0);
            IWebElement mbi = Browser.Wd.FindElement(By.Id("mbi"));
            mbi.Clear();
            mbi.SendKeys(mbivalue);

            IWebElement mem = Browser.Wd.FindElement(By.Id("memberId"));
            mem.SendKeys("Hello123455");
            tmsWait.Hard(3);
            IWebElement save = Browser.Wd.FindElement(By.XPath("//span[@id='spnSaveMemberFields']"));
            fw.ScrollWindowToViewElement(save);
            fw.ExecuteJavascript(save);


        }

        [When(@"Member page New MBI is set to ""(.*)"" and Clicked on Save button")]
        public void WhenMemberPageNewMBIIsSetToAndClickedOnSaveButton(string p0)
        {
            string mbivalue = tmsCommon.GenerateData(p0);
            IWebElement mbi = Browser.Wd.FindElement(By.Id("mbi"));
            mbi.Clear();
            mbi.SendKeys(mbivalue);
            tmsWait.Hard(3);
            IWebElement save = Browser.Wd.FindElement(By.XPath("//span[@id='spnSaveMemberFields']"));
            fw.ScrollWindowToViewElement(save);
            fw.ExecuteJavascript(save);



        }
        [When(@"Member page New RXID is set to ""(.*)"" and Clicked on Save button")]
        public void WhenMemberPageNewRXIDIsSetToAndClickedOnSaveButton(string p0)
        {

            IWebElement mem = Browser.Wd.FindElement(By.Id("rxid"));
            mem.Clear();
            mem.SendKeys(p0);
            tmsWait.Hard(3);
            IWebElement save = Browser.Wd.FindElement(By.XPath("//span[@id='spnSaveMemberFields']"));
            fw.ScrollWindowToViewElement(save);
            fw.ExecuteJavascript(save);
        }

        [When(@"Member page New Member is set to ""(.*)"" and Clicked on Save button")]
        public void WhenMemberPageNewMemberIsSetToAndClickedOnSaveButton(string p0)
        {
            IWebElement mem = Browser.Wd.FindElement(By.Id("memberId"));
            mem.Clear();
            mem.SendKeys(p0);
            tmsWait.Hard(3);
            IWebElement save = Browser.Wd.FindElement(By.XPath("//span[@id='spnSaveMemberFields']"));
            fw.ScrollWindowToViewElement(save);
            fw.ExecuteJavascript(save);
        }
        [When(@"Transactions New Street Address is set to ""(.*)""")]
        public void WhenTransactionsNewStreetAddressIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            string GeneratedUserID = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                AngularFunction.sendKeysWithClear(cfAngularTransaction.AngularNewTransaction.AddressOne, GeneratedUserID);

                tmsWait.Hard(3);


            }
            else
            {

                EAM.TransactionsNew.StreetAddress.SendKeys(GeneratedUserID);
            }
        }

        [Then(@"Verify that Transactions page displaye the election type ""(.*)""")]
        public void ThenVerifyThatTransactionsPageDisplayeTheElectionType(string p0)
        {
            tmsWait.Hard(5);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(3);

                By Drp = By.XPath("//label[contains(.,'Election Type')]/parent::div//span[@class='k-input']");
                string actualValue = Browser.Wd.FindElement(Drp).Text;
                Assert.AreEqual(p0, actualValue, " Both values are not matching");
            }
            else
            {

                SelectElement select = new SelectElement(Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cboElectionPeriod_09")));
                string selectedValue = select.SelectedOption.Text;
                Assert.AreEqual(selectedValue, p0.ToString(), "Election Type is not macthing with expected value");
            }
        }


        [When(@"Transactions New Street Address1 is set to ""(.*)""")]
        public void WhenTransactionsNewStreetAddress1IsSetTo(string p1)
        {
            tmsWait.Hard(2);
            string GeneratedUserID = tmsCommon.GenerateData(p1);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                AngularFunction.sendKeysWithClear(cfAngularTransaction.AngularNewTransaction.AddressOne, GeneratedUserID);
                //By Drp = By.XPath("//label[contains(.,'Residence Address 1')]/parent::div//input");
                //Browser.Wd.FindElement(Drp).Clear();
                //Browser.Wd.FindElement(Drp).SendKeys(GeneratedUserID);

                tmsWait.Hard(3);


            }
            else
            {
                EAM.TransactionsNew.StreetAddress1.SendKeys(GeneratedUserID);
            }
        }

        [When(@"Transactions New Street Address Two is set to ""(.*)""")]
        public void WhenTransactionsNewStreetAddressTwoIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string GeneratedUserID = tmsCommon.GenerateData(p0);


            if (ConfigFile.tenantType.Equals("tmsx"))
            {

                AngularFunction.sendKeysWithClear(cfAngularTransaction.AngularNewTransaction.AddressTwo, GeneratedUserID);
                //By Drp = By.XPath("//label[contains(.,'Residence Address 2')]/parent::div//input");
                //Browser.Wd.FindElement(Drp).Clear();
                //Browser.Wd.FindElement(Drp).SendKeys(GeneratedUserID);

                tmsWait.Hard(3);


            }
            else
            {
                IWebElement add2 = Browser.Wd.FindElement(By.CssSelector("[test-id='Transactioncode61ResidentialAddressupdateStreetAddress2']"));
                add2.Clear();
                add2.SendKeys(GeneratedUserID);
            }
        }

      

        [When(@"Transactions Page Street Address One is set to ""(.*)""")]
        public void WhenTransactionsPageStreetAddressOneIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string address = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {

                AngularFunction.sendKeysWithClear(cfAngularTransaction.AngularNewTransaction.AddressOne, address);

                //By Drp = By.XPath("//label[contains(.,'Residence Address 1')]/parent::div//input");
                //Browser.Wd.FindElement(Drp).Clear();
                //Browser.Wd.FindElement(Drp).SendKeys(address);

                tmsWait.Hard(3);


            }
            else
            {

                IWebElement add1 = Browser.Wd.FindElement(By.CssSelector("[test-id='Transactioncode61ResidentialAddressupdateStreetAddress']"));
                add1.Clear();
                add1.SendKeys(address);
            }
            GlobalRef.ADD1 = address;
        }

        [When(@"Transactions Page Street Address Two is set to ""(.*)""")]
        public void WhenTransactionsPageStreetAddressTwoIsSetTo(string p0)
        {
            tmsWait.Hard(2);
            string address = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                AngularFunction.sendKeysWithClear(cfAngularTransaction.AngularNewTransaction.AddressTwo, address);
                //By Drp = By.XPath("//label[contains(.,'Residence Address 1')]/parent::div//input");
                //Browser.Wd.FindElement(Drp).Clear();
                //Browser.Wd.FindElement(Drp).SendKeys(address);

                //tmsWait.Hard(3);


            }
            else
            {
                IWebElement add2 = Browser.Wd.FindElement(By.CssSelector("[test-id='Transactioncode61ResidentialAddressupdateStreetAddress2']"));
                add2.Clear();
                add2.SendKeys(address);
            }
            GlobalRef.ADD2 = address;
        }



        [When(@"Plan Defined Fields page Change PBP is set to ""(.*)""")]
        public void WhenPlanDefinedFieldsPageChangePBPIsSetTo(string p0)
        {

            string switchOnOff = tmsCommon.GenerateData(p0.ToLower());
            bool iselementpresent = false;

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(5);
                if (p0.ToLower().Equals("unchecked"))
                {
                    p0 = "off";
                }
                if (p0.Equals("checked"))
                {
                    p0 = "on";
                }
                string switchChk = Browser.Wd.FindElement(By.XPath("//kendo-switch[@test-id='oevletter-input-changepbp']//span[@role='switch']")).GetAttribute("aria-checked");

                switch (p0.ToLower())
                {
                    case "on":

                        if (switchChk.Contains("false"))
                        {
                            Browser.Wd.FindElement(By.XPath("//kendo-switch[@test-id='oevletter-input-changepbp']//span[@class='k-switch-handle']")).Click();
                        }
                        break;
                    case "off":
                        if (switchChk.Contains("true"))
                        {
                            Browser.Wd.FindElement(By.XPath("//kendo-switch[@test-id='oevletter-input-changepbp']//span[@class='k-switch-handle']")).Click();
                        }
                        break;
                }
                tmsWait.Hard(2);
            }
            else
            {
                By OEVStatus = By.XPath("//label[contains(.,'Change PBP')]/parent::div/div/span[contains(@class,'switch-" + switchOnOff + "')]");
                if (switchOnOff.Equals("on"))
                {
                    try
                    {
                        iselementpresent = Browser.Wd.FindElement(OEVStatus).Displayed;
                        fw.ConsoleReport(" OEV is already in ON Status");
                    }
                    catch
                    {
                        Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-container km-switch-container'])[2]")).Click();
                        tmsWait.Hard(2);
                    }
                }

                else if (switchOnOff.Equals("off"))

                {
                    try
                    {
                        iselementpresent = Browser.Wd.FindElement(OEVStatus).Displayed;
                        fw.ConsoleReport(" OEV is already in OFF Status");
                    }
                    catch
                    {
                        Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-container km-switch-container'])[2]")).Click();
                        tmsWait.Hard(2);
                    }
                }
            }
            //bool iselementpresent;
            //string xpath1 = "//label[contains(.,'Change PBP')]/parent::div/div/span[contains(@class,'switch-" + switchOnOff + "')]";
            //try
            //{
            //    iselementpresent = Browser.Wd.FindElement(By.XPath(xpath1)).Displayed;
            //}

            //catch
            //{
            //    //ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-container km-switch-container'])[1]")));
            //    Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-container km-switch-container'])[2]")).Click();
            //    tmsWait.Hard(2);
            //    iselementpresent = iselementpresent = Browser.Wd.FindElement(By.XPath(xpath1)).Displayed;
            //}

            //string GenerateData = tmsCommon.GenerateData(p0);


            //switch (GenerateData.ToLower())
            //{
            //    case "checked": { setCheckboxTo = "checked"; break; }
            //    case "on": { setCheckboxTo = "checked"; break; }
            //    case "yes": { setCheckboxTo = "checked"; break; }
            //    case "unchecked": { setCheckboxTo = "unchecked"; break; }
            //    case "off": { setCheckboxTo = "unchecked"; break; }
            //    case "no": { setCheckboxTo = "unchecked"; break; }
            //    default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            //}

            //if (setCheckboxTo.Equals("unchecked"))
            //{
            //    if (EAM.AdministrationPlanDefinedFieldsOEVLetter.ChangePBP.Selected == true)
            //    {
            //        fw.ExecuteJavascript(EAM.AdministrationPlanDefinedFieldsOEVLetter.ChangePBPAnchor);
            //        Console.WriteLine("OEV Letter Configuration is set to " + GenerateData);
            //    }


            //}
            //else
            //{
            //    if (EAM.AdministrationPlanDefinedFieldsOEVLetter.ChangePBP.Selected == false)
            //    {
            //        fw.ExecuteJavascript(EAM.AdministrationPlanDefinedFieldsOEVLetter.ChangePBPAnchor);
            //        Console.WriteLine("OEV Letter Configuration is set to " + GenerateData);
            //    }
            //}

        }

        [When(@"Plan Defined Fields page EGHP is set to ""(.*)""")]
        public void WhenPlanDefinedFieldsPageEGHPIsSetTo(string p0)
        {
            string switchOnOff = tmsCommon.GenerateData(p0.ToLower());
            bool iselementpresent = false;

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(5);
                if (p0.ToLower().Equals("unchecked"))
                {
                    p0 = "off";
                }
                if (p0.Equals("checked"))
                {
                    p0 = "on";
                }
                string switchChk = Browser.Wd.FindElement(By.XPath("//kendo-switch[@test-id='oevletter-input-eghp']//span[@role='switch']")).GetAttribute("aria-checked");

                switch (p0.ToLower())
                {
                    case "on":

                        if (switchChk.Contains("false"))
                        {
                            Browser.Wd.FindElement(By.XPath("//kendo-switch[@test-id='oevletter-input-eghp']//span[@class='k-switch-handle']")).Click();
                        }
                        break;
                    case "off":
                        if (switchChk.Contains("true"))
                        {
                            Browser.Wd.FindElement(By.XPath("//kendo-switch[@test-id='oevletter-input-eghp']//span[@class='k-switch-handle']")).Click();
                        }
                        break;
                }
                tmsWait.Hard(2);
            }
            else
            {
                By OEVStatus = By.XPath("//label[contains(.,'EGHP')]/parent::div/div/span[contains(@class,'switch-" + switchOnOff + "')]");
                if (switchOnOff.Equals("on"))
                {
                    try
                    {
                        iselementpresent = Browser.Wd.FindElement(OEVStatus).Displayed;
                        fw.ConsoleReport(" EGHP is already in ON Status");
                    }
                    catch
                    {
                        Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-container km-switch-container'])[3]")).Click();
                        tmsWait.Hard(2);
                    }
                }

                else if (switchOnOff.Equals("off"))

                {
                    try
                    {
                        iselementpresent = Browser.Wd.FindElement(OEVStatus).Displayed;
                        fw.ConsoleReport(" EGHP is already in OFF Status");
                    }
                    catch
                    {
                        Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-container km-switch-container'])[3]")).Click();
                        tmsWait.Hard(2);
                    }
                }
            }
            //string switchOnOff = tmsCommon.GenerateData(p0.ToLower());
            //bool iselementpresent = false;
          
            //string xpatheghp = "//label[contains(.,'EGHP')]/parent::div/div/span[contains(@class,'switch-" + switchOnOff + "')]";
            //try
            //{
            //    iselementpresent = Browser.Wd.FindElement(By.XPath(xpatheghp)).Displayed;
            //}

            //catch
            //{
            //    //ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-container km-switch-container'])[1]")));
            //    Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-container km-switch-container'])[3]")).Click();
            //    tmsWait.Hard(2);
            //    iselementpresent = iselementpresent = Browser.Wd.FindElement(By.XPath(xpatheghp)).Displayed;
            //}

            //string GenerateData = tmsCommon.GenerateData(p0);


            //switch (GenerateData.ToLower())
            //{
            //    case "checked": { setCheckboxTo = "checked"; break; }
            //    case "on": { setCheckboxTo = "checked"; break; }
            //    case "yes": { setCheckboxTo = "checked"; break; }
            //    case "unchecked": { setCheckboxTo = "unchecked"; break; }
            //    case "off": { setCheckboxTo = "unchecked"; break; }
            //    case "no": { setCheckboxTo = "unchecked"; break; }
            //    default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            //}

            //if (setCheckboxTo.Equals("unchecked"))
            //{
            //    if (EAM.AdministrationPlanDefinedFieldsOEVLetter.EGHP.Selected == true)
            //    {
            //        fw.ExecuteJavascript(EAM.AdministrationPlanDefinedFieldsOEVLetter.EGHPAnchor);
            //        Console.WriteLine("OEV Letter Configuration is set to " + GenerateData);
            //    }


            //}
            //else
            //{
            //    if (EAM.AdministrationPlanDefinedFieldsOEVLetter.EGHP.Selected == false)
            //    {
            //        fw.ExecuteJavascript(EAM.AdministrationPlanDefinedFieldsOEVLetter.EGHPAnchor);
            //        Console.WriteLine("OEV Letter Configuration is set to " + GenerateData);
            //    }
            //}
        }

        [When(@"Plan Defined Fields page Passed BEQ Status is set to ""(.*)""")]
        public void WhenPlanDefinedFieldsPagePassedBEQStatusIsSetTo(string p0)
        {
            string oevswitch = tmsCommon.GenerateData(p0.ToLower());
            bool iselementpresent = false;

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(5);
                if (p0.ToLower().Equals("unchecked"))
                {
                    p0 = "off";
                }
                if (p0.Equals("checked"))
                {
                    p0 = "on";
                }
                string switchChk = Browser.Wd.FindElement(By.XPath("//kendo-switch[@test-id='oevletter-input-beqstatus']//span[@role='switch']")).GetAttribute("aria-checked");

                switch (p0.ToLower())
                {
                    case "on":

                        if (switchChk.Contains("false"))
                        {
                            Browser.Wd.FindElement(By.XPath("//kendo-switch[@test-id='oevletter-input-beqstatus']//span[@class='k-switch-handle']")).Click();
                        }
                        break;
                    case "off":
                        if (switchChk.Contains("true"))
                        {
                            Browser.Wd.FindElement(By.XPath("//kendo-switch[@test-id='oevletter-input-beqstatus']//span[@class='k-switch-handle']")).Click();
                        }
                        break;
                }
                tmsWait.Hard(2);
            }
            else
            {
                By OEVStatus = By.XPath("//label[contains(.,'Pass BEQ Status')]/parent::div/div/span[contains(@class,'switch-" + oevswitch + "')]");
                if (oevswitch.Equals("on"))
                {
                    try
                    {
                        iselementpresent = Browser.Wd.FindElement(OEVStatus).Displayed;
                        fw.ConsoleReport(" Passed BEQ is already in ON Status");
                    }
                    catch
                    {
                        IWebElement ele1 = Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-container km-switch-container'])[4]"));
                        tmsWait.Hard(2);
                        fw.ExecuteJavascript(ele1);
                    }
                }

                else if (oevswitch.Equals("off"))

                {
                    try
                    {
                        iselementpresent = Browser.Wd.FindElement(OEVStatus).Displayed;
                        fw.ConsoleReport(" Passed BEQ is already in OFF Status");
                    }
                    catch
                    {
                        IWebElement ele = Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-container km-switch-container'])[4]"));
                        fw.ExecuteJavascript(ele);
                        tmsWait.Hard(2);
                    }
                }
            }
            //string switchOnOff = tmsCommon.GenerateData(p0.ToLower());
            //bool iselementpresent = false;
            //string xpathbeq = "//label[contains(.,'Pass BEQ Status')]/parent::div/div/span[contains(@class,'switch-" + switchOnOff + "')]";
            //try
            //{
            //    iselementpresent = Browser.Wd.FindElement(By.XPath(xpathbeq)).Displayed;
            //}

            //catch
            //{
            //    //ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-container km-switch-container'])[1]")));
            //    Browser.Wd.FindElement(By.XPath("(//span[@class='k-switch-container km-switch-container'])[4]")).Click();
            //    tmsWait.Hard(2);
            //    iselementpresent = iselementpresent = Browser.Wd.FindElement(By.XPath(xpathbeq)).Displayed;
            //}


            //string GenerateData = tmsCommon.GenerateData(p0);


            //switch (GenerateData.ToLower())
            //{
            //    case "checked": { setCheckboxTo = "checked"; break; }
            //    case "on": { setCheckboxTo = "checked"; break; }
            //    case "yes": { setCheckboxTo = "checked"; break; }
            //    case "unchecked": { setCheckboxTo = "unchecked"; break; }
            //    case "off": { setCheckboxTo = "unchecked"; break; }
            //    case "no": { setCheckboxTo = "unchecked"; break; }
            //    default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            //}

            //if (setCheckboxTo.Equals("unchecked"))
            //{
            //    if (EAM.AdministrationPlanDefinedFieldsOEVLetter.PassBEQStatus.Selected == true)
            //    {
            //        fw.ExecuteJavascript(EAM.AdministrationPlanDefinedFieldsOEVLetter.PassBEQStatusAnchor);
            //        Console.WriteLine("OEV Letter Configuration is set to " + GenerateData);
            //    }


            //}
            //else
            //{
            //    if (EAM.AdministrationPlanDefinedFieldsOEVLetter.PassBEQStatus.Selected == false)
            //    {
            //        fw.ExecuteJavascript(EAM.AdministrationPlanDefinedFieldsOEVLetter.PassBEQStatusAnchor);
            //        Console.WriteLine("OEV Letter Configuration is set to " + GenerateData);
            //    }
            //}
        }

        [Then(@"Verify Queue Potential OOA letter check box is disabled")]
        public void ThenVerifyQueuePotentialOOALetterCheckBoxIsDisabled()
        {
            tmsWait.Hard(2);
            string fieldName = "Out Of Area Verification process dialog Potential OOA letter checkbox is disabled ";
            bool actual = EAM.MemberInformation.QueuePotentialOOALetter.Enabled;

            Assert.IsFalse(actual, "Field " + fieldName);
            fw.ConsoleReport(" Verification Point: Out Of Area Verification process dialog  Potential OOA letter checkbox is disabled"); 
        }

        [Then(@"Member View Edit page Address Type is Set to ""(.*)""")]
        public void ThenMemberViewEditPageAddressTypeIsSetTo(string p0)
        {
            SelectElement type = new SelectElement(EAM.MemberInformation.AddressTypeMailing);
            type.SelectByText(p0);

        }

        [Then(@"Member View Edit page Mailing Address1 is set to ""(.*)""")]
        public void ThenMemberViewEditPageMailingAddress1IsSetTo(string p1)
        {
            tmsWait.Hard(1);
            EAM.MembersViewEdit.MemberViewEditMailingAddress1.Clear();
        }

        [Then(@"Member View Edit page Mailing Address2 is set to ""(.*)""")]
        public void ThenMemberViewEditPageMailingAddress2IsSetTo(string p1)
        {
            tmsWait.Hard(1);
            EAM.MembersViewEdit.MemberViewEditMailingAddress2.Clear();
        }

        [Then(@"Member View Edit page Mailing City is set to ""(.*)""")]
        public void ThenMemberViewEditPageMailingCityIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            EAM.MembersViewEdit.MemberViewEditMailingCity.Clear();
        }

        [Then(@"Member View Edit page Mailing State is set to ""(.*)""")]
        public void ThenMemberViewEditPageMailingStateIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            EAM.MembersViewEdit.MemberViewEditMailingState.Clear();
        }

        [Then(@"Member View Edit page Mailing Zip is set to ""(.*)""")]
        public void ThenMemberViewEditPageZipIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            EAM.MembersViewEdit.MemberViewEditMailingZip.Clear();
        }

        [Then(@"Member View Edit page Residence Address1 is set to ""(.*)""")]
        public void ThenMemberViewEditPageResidenceAddress1IsSetTo(string p1)
        {
            tmsWait.Hard(1);
            EAM.MembersViewEdit.MemberViewEditResidenceAddress1.Clear();
        }
        [Then(@"Member View Edit page Residence Address2 is set to ""(.*)""")]
        public void ThenMemberViewEditPageResidenceAddress2IsSetTo(string p1)
        {
            tmsWait.Hard(1);
            EAM.MembersViewEdit.MemberViewEditResidenceAddress2.Clear();
        }

        [Then(@"Member View Edit page Residence City is set to ""(.*)""")]
        public void ThenMemberViewEditPageResidenceCityIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            EAM.MembersViewEdit.MemberViewEditResidenceCity.Clear();
        }

        [Then(@"Member View Edit page Residence State is set to ""(.*)""")]
        public void ThenMemberViewEditPageResidenceStateIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            EAM.MembersViewEdit.MemberViewEditResidenceState.Clear();
        }

        [Then(@"Member View Edit page Residence Zip is set to ""(.*)""")]
        public void ThenMemberViewEditPageResidenceZipIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            EAM.MembersViewEdit.MemberViewEditResidenceZip.Clear();
        }

        [Then(@"Member view Edit page Save button is Clicked")]
        public void ThenMemberViewEditPageSaveButtonIsClicked()
        {
            EAM.MembersViewEdit.MemberViewEditSaveButton.Click();
        }

        [Then(@"Queue Potential OOA letter check box Alert message displays ""(.*)""")]
        [When(@"Queue Potential OOA letter check box Alert message displays ""(.*)""")]
        public void ThenQueuePotentialOOALetterCheckBoxAlertMessageDisplays(string p0)
        {
            tmsWait.Hard(1);
            string GenerateData = tmsCommon.GenerateData(p0);

            OpenQA.Selenium.Interactions.Actions builder = new OpenQA.Selenium.Interactions.Actions(Browser.Wd);

            builder.MoveToElement(EAM.MemberInformation.PotentialAlertTooltip).Build().Perform();
            tmsWait.Hard(2);
            String TooltipTitle = EAM.MemberInformation.AlertTooltipTitle.Text;
            String TooltipMessage = EAM.MemberInformation.AlertTooltipMsg.Text;
            String actual = TooltipTitle + " " + TooltipMessage;
            Assert.AreEqual(GenerateData, actual, "Expected Alert icon Tool tip message is displayed");     
           
        }

        [Then(@"Verify OOA dialog SCC OOA Research Finding section Continuation Area check box is disabled")]
        public void ThenVerifyOOADialogSCCOOAResearchFindingSectionContinuationAreaCheckBoxIsDisabled()
        {
            bool Conarea = cfUIMODViewEditMember.ViewOOA.InContinuingAreaCheckbox.Enabled; //EAM.MemberInformation.OOAContiuningArea.Enabled;
            Assert.IsFalse(Conarea, "Continuation Area Field is Disabled");
            fw.ConsoleReport(" Out of Area Verification Process dialog Research Finding Section Continuation Area Field is disabled ");
        }

        [Then(@"Verify OOA dialog SCC OOA Research Finding section Travelers Visitors Program check box is disabled")]
        public void ThenVerifyOOADialogSCCOOAResearchFindingSectionTravelersVisitorsProgramCheckBoxIsDisabled()
        {
            bool travel = cfUIMODViewEditMember.ViewOOA.TravelersVisitorsProgramCheckbox.Enabled;
            Assert.IsFalse(travel, "Travelers VisitorsProgram Field is Disabled");
            fw.ConsoleReport(" Out of Area Verification Process dialog Research Finding Section Travelers Visitors Program Field is disabled ");
        }

        [Then(@"Verify OOA dialog SCC OOA Research Finding section ICEP Conversion check box is disabled")]
        public void ThenVerifyOOADialogSCCOOAResearchFindingSectionICEPConversionCheckBoxIsDisabled()
        {
            bool icep = cfUIMODViewEditMember.ViewOOA.ICEPConversion.Enabled;
            Assert.IsFalse(icep, "ICEP Conversion Field is Disabled");
            fw.ConsoleReport(" Out of Area Verification Process dialog Research Finding Section ICEP Conversion Field is disabled ");
        }


        [Then(@"Member View Edit Page OOA is clicked")]
        [When(@"Member View Edit Page OOA is clicked")]

        public void ThenMemberViewEditPageOOAIsClicked()
        {
            fw.ExecuteJavascript(cfUIMODViewEditMember.ViewOOA.ViewOOABtn);
            tmsWait.Hard(5);
        }

        [When(@"Letter On Demand option is selected")]
        public void WhenLetterOnDemandOptionIsSelected()
        {
            Browser.Wd.FindElement(By.XPath("ctl00_ctl00_MainMasterContent_MainContent_ucCorrespondence_radBtnOnDemand")).Click();

            
        }



        [Then(@"Member View Edit Page Out Of Area verification process dialog Add new suspect button is clicked")]
        [When(@"Member View Edit Page Out Of Area verification process dialog Add new suspect button is clicked")]
        public void ThenMemberViewEditPageOutOfAreaVerificationProcessDialogAddNewSuspectButtonIsClicked()
        {
            tmsWait.Hard(2);
            try
            {
                fw.ExecuteJavascript(cfUIMODViewEditMember.ViewOOA.AddNewSuspectBtn);
                tmsWait.Hard(1);
            }
            catch
            {

            }
            
        }

        [Then(@"Verify Reports OEC/EAF Fallout Window has details")]
        public void ThenVerifyReportsOECEAFFalloutWindowHasDetails(Table table)
        {
            By reportViewBy = EAM.Reports.ReportMainViewBy;
            string reportExpText = "OEC/EAF Fallout Report";
            string reportHandle = "";


            reportHandle = ReportsCommon.SwitchToReportWindow(reportViewBy, 60, reportExpText);

            if (reportHandle == "")
            {
                Assert.Fail(" OEC/EAF Fallout Report was not opened");
            }

            try
            {
                ReportsCommon.VerifyOECEAFFalloutReportDoesNotHaveData(reportViewBy, reportExpText, table);
            }
            catch (Exception e)
            {
                Assert.Fail("Verify OEC/EAF Fallout Report has data that should not be there. ");
            }
            Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle);

        }


        [Then(@"Verify Reports OEC/EAF Fallout Window has no Member details")]
        public void ThenVerifyReportsOECEAFFalloutWindowHasNoMemberDetails(Table table)
        {
            By reportViewBy = EAM.Reports.ReportMainViewBy;
            string reportExpText = "OEC/EAF Fallout Report";
            string reportHandle = "";


            reportHandle = ReportsCommon.SwitchToReportWindow(reportViewBy, 60, reportExpText);

            if (reportHandle == "")
            {
                Assert.Fail(" OEC/EAF Fallout Report was not opened");
            }

            try
            {
                ReportsCommon.VerifyOECEAFFalloutReportDoesNotHaveData(reportViewBy, reportExpText, table);
            }
            catch (Exception e)
            {
                Assert.Fail("Verify OEC/EAF Fallout Report has data that should not be there. ");
            }
            Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle);

        }

        [Then(@"Verify Out Of Area verification process dialog Save button diplays tooltip message ""(.*)""")]
        public void ThenVerifyOutOfAreaVerificationProcessDialogSaveButtonDiplaysTooltipMessage(string p0)
        {

            tmsWait.Hard(2);
            string GenerateData = tmsCommon.GenerateData(p0);

            OpenQA.Selenium.Interactions.Actions builder = new OpenQA.Selenium.Interactions.Actions(Browser.Wd);

            builder.MoveToElement(EAM.MemberInformation.SavebuttonTooltip).ClickAndHold().Build().Perform();
            //builder.MoveToElement(EAM.MemberInformation.AlertTooltip).Build().Perform();

            tmsWait.Hard(2);
            String TooltipTitle = EAM.MemberInformation.SavebuttonTooltip.GetAttribute("title");
            //String TooltipMessage = EAM.MemberInformation.SusAlertTooltipMsg.Text;
            String actual = TooltipTitle;
            Assert.AreEqual(GenerateData, actual, "Expected Alert icon Tool tip message is displayed");     

        }

        [Then(@"Verify Out Of Area verification process dialog Date Modified is disabled")]
        public void ThenVerifyOutOfAreaVerificationProcessDialogDateModifiedIsDisabled()
        {
            bool DateField = cfUIMODViewEditMember.ViewOOA.DateModified.Enabled;
            Assert.IsFalse(DateField, "Date Field is Disabled");
            fw.ConsoleReport(" Out of Area Verification Process dialog Date Field is disabled ");
        }

        [Then(@"Verify Out Of Area verification process dialog User Modified is disabled")]
        public void ThenVerifyOutOfAreaVerificationProcessDialogUserModifiedIsDisabled()
        {
            //bool DateField = EAM.MemberInformation.OOAUserModified.Enabled;
            bool DateField = cfUIMODViewEditMember.ViewOOA.UserModified.Enabled;
            
            Assert.IsFalse(DateField, "DUser Modified Field is Disabled");
            fw.ConsoleReport(" Out of Area Verification Process dialog User Modified Field is disabled ");
        }

        [Then(@"Out Of Area verification process dialog Potential Out Of area check box is ""(.*)""")]
        [When(@"Out Of Area verification process dialog Potential Out Of area check box is ""(.*)""")]
        public void ThenOutOfAreaVerificationProcessDialogPotentialOutOfAreaCheckBoxIs(string p0)
        {
            ReUsableFunctions.CheckBoxOperations(cfUIMODViewEditMember.ViewOOA.PotentialOutOfAreaCheckbox,p0); ;
            tmsWait.Hard(5);
            //string GenerateData = tmsCommon.GenerateData(p0);


            //switch (GenerateData.ToLower())
            //{
            //    case "checked": { setCheckboxTo = "checked"; break; }
            //    case "on": { setCheckboxTo = "checked"; break; }
            //    case "yes": { setCheckboxTo = "checked"; break; }
            //    case "unchecked": { setCheckboxTo = "unchecked"; break; }
            //    case "off": { setCheckboxTo = "unchecked"; break; }
            //    case "no": { setCheckboxTo = "unchecked"; break; }
            //    default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            //}

            //if (setCheckboxTo.Equals("unchecked"))
            //{

            //    if (EAM.MemberInformation.PotentialOutOfArea.Selected == true)
            //    {
            //       fw.ExecuteJavascript(EAM.MemberInformation.PotentialOutOfArea);
            //    }

            //}
            //else if (setCheckboxTo.Equals("checked"))
            //{
            //    if (EAM.MemberInformation.PotentialOutOfArea.Selected == false)
            //    {
            //        fw.ExecuteJavascript(EAM.MemberInformation.PotentialOutOfArea);

            //    }
            //}
            //tmsWait.Hard(1);
        }

        [Then(@"Out Of Area verification process dialog Suspect Status drop down is set to ""(.*)""")]
        public void ThenOutOfAreaVerificationProcessDialogSuspectStatusDropDownIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            SelectElement suspectstatus = new SelectElement(EAM.MemberInformation.SuspectStatusDDL);
            suspectstatus.SelectByText(p0);
        }

        [Then(@"Out Of Area verification process dialog Possible SCC discrepancy exists check box is ""(.*)""")]
        public void ThenOutOfAreaVerificationProcessDialogPossibleSCCDiscrepancyExistsCheckBoxIs(string p0)
        {
            ReUsableFunctions.CheckBoxOperations(cfUIMODViewEditMember.ViewOOA.PossibleSCCDiscrepancyExistsCheckbox, p0); ;

            //tmsWait.Hard(1);
            //string GenerateData = tmsCommon.GenerateData(p0);


            //switch (GenerateData.ToLower())
            //{
            //    case "checked": { setCheckboxTo = "checked"; break; }
            //    case "on": { setCheckboxTo = "checked"; break; }
            //    case "yes": { setCheckboxTo = "checked"; break; }
            //    case "unchecked": { setCheckboxTo = "unchecked"; break; }
            //    case "off": { setCheckboxTo = "unchecked"; break; }
            //    case "no": { setCheckboxTo = "unchecked"; break; }
            //    default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            //}

            //if (setCheckboxTo.Equals("unchecked"))
            //{

            //    if (EAM.MemberInformation.PossibleSCCDisExists.Selected == true)
            //    {
            //        fw.ExecuteJavascript(EAM.MemberInformation.PossibleSCCDisExists);
            //    }

            //}
            //else if (setCheckboxTo.Equals("checked"))
            //{
            //    if (EAM.MemberInformation.PossibleSCCDisExists.Selected == false)
            //    {
            //        fw.ExecuteJavascript(EAM.MemberInformation.PossibleSCCDisExists);
            //    }
            //}
        }

        [Then(@"Accept Alert message ""(.*)""")]
        public void ThenAcceptAlertMessage(string p0)
        {
            string fieldName = "OOA Suspect Alert Message ";
            IAlert alert = Browser.Wd.SwitchTo().Alert();

            string expected = tmsCommon.GenerateData(p0);
            string actual = alert.Text;
            Assert.AreEqual(expected, actual, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
            tmsWait.Hard(1);
            alert.Accept();
        }


        [Then(@"Verify Alert displays message ""(.*)""")]
        public void ThenVerifyAlertDisplaysMessage(string p0)
        {
            string fieldName = "OOA Suspect Alert Message ";
            IAlert alert = Browser.Wd.SwitchTo().Alert();
            
            string expected = tmsCommon.GenerateData(p0);
            string actual = alert.Text;
            Assert.AreEqual(expected, actual, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
            tmsWait.Hard(1);
            alert.Dismiss();
        }

        [Then(@"Verify Out Of Area verification process dialog displays message ""(.*)""")]
        [When(@"Verify Out Of Area verification process dialog displays message ""(.*)""")]
        public void ThenVerifyOutOfAreaVerificationProcessDialogDisplaysMessage(string p0)
        {

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By toastMsg = By.XPath("//div[@class='k-notification-content']");
                string actValue = Browser.Wd.FindElement(toastMsg).Text;
                Assert.IsTrue(p0.Contains(actValue), "Toaster message does not display as expected");
            }
            
            else
            {
                ReUsableFunctions.toasterMessageDisplay(p0);
            }
            //string fieldName = "OOA Static Message ";
            //string expected = tmsCommon.GenerateData(p0);
            //string actual = EAM.MemberInformation.OOAStaticMsg.Text;
            //actual = actual.Trim().Replace("\r\n", ",");
            //Assert.AreEqual(expected, actual, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            //fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
            //tmsWait.Hard(1);

        }

        [Then(@"Verify Plan Defined Fields page Update Out of Area Configuration section Disenrollment Months Dropdown list default value is set to ""(.*)""")]
        public void ThenVerifyPlanDefinedFieldsPageUpdateOutOfAreaConfigurationSectionDisenrollmentMonthsDropdownListDefaultValueIsSetTo(String p0)
        {
            tmsWait.Hard(2);
            string fieldName = "Out of Area Configuration section Disenrollment Months Dropdown list Default value";
            SelectElement mon = new SelectElement(EAM.AdministrationPlanDefinedFieldsOOATab.DisEnrollmentMonths);
            String actual = mon.SelectedOption.Text;
            string expected = tmsCommon.GenerateData(p0);
            Assert.AreEqual(expected, actual, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
            tmsWait.Hard(1);



        }

        [Then(@"Verify Plan Defined Fields page Update Out of Area Configuration section Disenrollment Months Dropdown list displays Months")]
        public void ThenVerifyPlanDefinedFieldsPageUpdateOutOfAreaConfigurationSectionDisenrollmentMonthsDropdownListDisplaysMonths()
        {

            tmsWait.Hard(2);
            SelectElement soc = new SelectElement(EAM.AdministrationPlanDefinedFieldsOOATab.DisEnrollmentMonths);
            string[] drop = { "6", "7", "8", "9", "10", "11", "12" };
            IList<IWebElement> actual = soc.Options;            
           for (int i = 0; i < drop.Length; i++)
            {
                Console.Write(" " + drop[i]);
                Assert.IsTrue(drop[i].Equals(actual[i].Text));
            }

        

        }


        [When(@"Plan Defined Fields page Update Out of Area Configuration section Plan ID is set to ""(.*)""")]
        public void WhenPlanDefinedFieldsPageUpdateOutOfAreaConfigurationSectionPlanIDIsSetTo(string p0)
        {
            tmsWait.Hard(3);
           
            SelectElement plan = new SelectElement(EAM.AdministrationPlanDefinedFieldsOOATab.PlanId);
            plan.SelectByText(p0);
        }

        [When(@"Plan Defined Fields page Update Out of Area Configuration section Continuation Area is set to ""(.*)""")]
        public void WhenPlanDefinedFieldsPageUpdateOutOfAreaConfigurationSectionContinuationAreaIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            string GenerateData = tmsCommon.GenerateData(p0);


            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("unchecked"))
            {

                if (EAM.AdministrationPlanDefinedFieldsOOATab.ContinuationArea.Selected == true)
                {
                    fw.ExecuteJavascript(EAM.AdministrationPlanDefinedFieldsOOATab.ContinuationArea);
                }

            }
            else if (setCheckboxTo.Equals("checked"))
            {
                if (EAM.AdministrationPlanDefinedFieldsOOATab.ContinuationArea.Selected == false)
                {
                    fw.ExecuteJavascript(EAM.AdministrationPlanDefinedFieldsOOATab.ContinuationArea);
                }
            }
        }

        [When(@"Plan Defined Fields page Update Out of Area Configuration section Travelers Visitors is set to ""(.*)""")]
        public void WhenPlanDefinedFieldsPageUpdateOutOfAreaConfigurationSectionTravelersVisitorsIsSetTo(string p0)
        {

            tmsWait.Hard(1);
            string GenerateData = tmsCommon.GenerateData(p0);


            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("unchecked"))
            {

                if (EAM.AdministrationPlanDefinedFieldsOOATab.Travellers.Selected == true)
                {
                    fw.ExecuteJavascript(EAM.AdministrationPlanDefinedFieldsOOATab.Travellers);
                }

            }
            else if (setCheckboxTo.Equals("checked"))
            {
                if (EAM.AdministrationPlanDefinedFieldsOOATab.Travellers.Selected == false)
                {
                    fw.ExecuteJavascript(EAM.AdministrationPlanDefinedFieldsOOATab.Travellers);
                }
            }
        }

        [When(@"Plan Defined Fields page Update Out of Area Configuration section ICEP Conversion is set to ""(.*)""")]
        public void WhenPlanDefinedFieldsPageUpdateOutOfAreaConfigurationSectionICEPConversionIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string GenerateData = tmsCommon.GenerateData(p0);


            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("unchecked"))
            {

                if (EAM.AdministrationPlanDefinedFieldsOOATab.ICEPConversion.Selected == true)
                {
                    fw.ExecuteJavascript(EAM.AdministrationPlanDefinedFieldsOOATab.ICEPConversion);
                }

            }
            else if (setCheckboxTo.Equals("checked"))
            {
                if (EAM.AdministrationPlanDefinedFieldsOOATab.ICEPConversion.Selected == false)
                {
                    fw.ExecuteJavascript(EAM.AdministrationPlanDefinedFieldsOOATab.ICEPConversion);
                }
            }
        }


        [Then(@"Verify Plan Defined Fields page Update Out of Area Configuration section Continuation Area is ""(.*)""")]
        public void ThenVerifyPlanDefinedFieldsPageUpdateOutOfAreaConfigurationSectionContinuationAreaIs(string p0)
        {

            tmsWait.Hard(1);
            string GenerateData = tmsCommon.GenerateData(p0);


            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("unchecked"))
            {
                Assert.IsFalse(EAM.AdministrationPlanDefinedFieldsOOATab.ContinuousAreaCheckbox.Selected, "Plan Defined Fields Page Update OutOfArea Configuration Section ContinuationArea checkbox is Selected  ");
                
            }
            else if (setCheckboxTo.Equals("checked"))
            {
                Assert.IsTrue(EAM.AdministrationPlanDefinedFieldsOOATab.ContinuousAreaCheckbox.Selected, "Plan Defined Fields Page Update OutOfArea Configuration Section ContinuationArea checkbox is not Selected  ");
                
            }
            
        }

        [Then(@"Verify Plan Defined Fields page Update Out of Area Configuration section Travelers Visitors is ""(.*)""")]
        public void ThenVerifyPlanDefinedFieldsPageUpdateOutOfAreaConfigurationSectionTravelersVisitorsIs(string p0)
        {
            tmsWait.Hard(1);
            string GenerateData = tmsCommon.GenerateData(p0);


            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("unchecked"))
            {
                Assert.IsFalse(EAM.AdministrationPlanDefinedFieldsOOATab.TravelersCheckbox.Selected, "Plan Defined Fields Page Update OutOfArea Configuration Section TravelersCheckbox checkbox is Selected  ");

            }
            else if (setCheckboxTo.Equals("checked"))
            {
                Assert.IsTrue(EAM.AdministrationPlanDefinedFieldsOOATab.TravelersCheckbox.Selected, "Plan Defined Fields Page Update OutOfArea Configuration Section TravelersCheckbox checkbox is not Selected  ");

            }
        }

        [Then(@"Verify Plan Defined Fields page Update Out of Area Configuration section ICEP Conversion is ""(.*)""")]
        public void ThenVerifyPlanDefinedFieldsPageUpdateOutOfAreaConfigurationSectionICEPConversionIs(string p0)
        {
            tmsWait.Hard(1);
            string GenerateData = tmsCommon.GenerateData(p0);


            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("unchecked"))
            {
                Assert.IsFalse(EAM.AdministrationPlanDefinedFieldsOOATab.ICEPConversionCheckbox.Selected, "Plan Defined Fields Page Update OutOfArea Configuration Section ICEPConversion checkbox is Selected  ");

            }
            else if (setCheckboxTo.Equals("checked"))
            {
                Assert.IsTrue(EAM.AdministrationPlanDefinedFieldsOOATab.ICEPConversionCheckbox.Selected, "Plan Defined Fields Page Update OutOfArea Configuration Section ICEPConversion checkbox is not Selected  ");

            }
        }

        [When(@"Plan Defined Fields page Update Out of Area Update button is Clicked")]
        public void WhenPlanDefinedFieldsPageUpdateOutOfAreaUpdateButtonIsClicked()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(EAM.AdministrationPlanDefinedFieldsOOATab.Update);
        }


        [When(@"Reports Deemed LIS Detail Report page File Run Date is set to ""(.*)""")]
        public void WhenReportsDeemedLISDetailReportPageFileRunDateIsSetTo(string p0)
        {

            tmsWait.Hard(5);
            string GeneratedData = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                
                    By Drp = By.XPath("//label[contains(.,'File Run Date')]/parent::div//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + GeneratedData + "']");


                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    tmsWait.Hard(3);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);



             }
               
            else
            {
                SelectElement select = new SelectElement(EAM.ReportsDeemedLISDetailReport.FileRunDate);
                select.SelectByText(GeneratedData);
            }
        }

        [When(@"EAM Reports page Trans Status is set to ""(.*)""")]
        public void WhenEAMReportsPageTransStatusIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string GeneratedData = tmsCommon.GenerateData(p0); 
            IWebElement planid = Browser.Wd.FindElement(By.CssSelector("[test-id='transStatusCode']"));
            SelectElement select = new SelectElement(planid);
            select.SelectByText(GeneratedData);
        }
        [When(@"EAM Report page Plan Id is set to ""(.*)""")]
        public void WhenEAMReportPagePlanIdIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            string GeneratedData = tmsCommon.GenerateData(p0);
            IWebElement planid = Browser.Wd.FindElement(By.CssSelector("[test-id='Planid']"));
            SelectElement select = new SelectElement(planid);
            select.SelectByText(GeneratedData);
        }

        [When(@"EAM Report page Date Changed is set to ""(.*)""")]
        public void WhenEAMReportPageDateChangedIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string GeneratedData = System.DateTime.Today.ToString("MM/dd/yyyy");
            IWebElement date = Browser.Wd.FindElement(By.CssSelector("[test-id='DateChanged']"));
            fw.ExecuteJavascriptSetText(date, GeneratedData);
        }

        [When(@"EAM Report page Change Type is set to ""(.*)""")]
        public void WhenEAMReportPageChangeTypeIsSetTo(string p0)
        {
            tmsWait.Hard(3);            
            string GeneratedData = tmsCommon.GenerateData(p0);
            IWebElement planid = Browser.Wd.FindElement(By.CssSelector("[test-id='ChangeType']"));
            SelectElement select = new SelectElement(planid);
            select.SelectByText(GeneratedData);
        }
        [When(@"EAM Report page Change Source is set to ""(.*)""")]
        public void WhenEAMReportPageChangeSourceIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string GeneratedData = tmsCommon.GenerateData(p0);
            IWebElement planid = Browser.Wd.FindElement(By.CssSelector("[test-id='ChangeSource']"));
            SelectElement select = new SelectElement(planid);
            select.SelectByText(GeneratedData);
        }



        [When(@"EAM Reports page Plan Id is set to ""(.*)""")]
        public void WhenEAMReportsPagePlanIdIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string GeneratedData = tmsCommon.GenerateData(p0);
            IWebElement planid = Browser.Wd.FindElement(By.CssSelector("[test-id='PlanID']"));
            SelectElement select = new SelectElement(planid);
            select.SelectByText(GeneratedData);
        }

        [When(@"EAM Reports page PBP Id is set to ""(.*)""")]
        public void WhenEAMReportsPagePBPIdIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string GeneratedData = tmsCommon.GenerateData(p0);
            IWebElement pbp = Browser.Wd.FindElement(By.CssSelector("[test-id='PBPID']"));
            SelectElement select = new SelectElement(pbp);
            select.SelectByText(GeneratedData);
        }
        [When(@"EAM Reports page Multi Select Plan Id is set to ""(.*)""")]
        public void WhenEAMReportsPageMultiSelectPlanIdIsSetTo(string p0)
        {
          
        }


        [When(@"EAM Reports page Disenrollment Reason Code is set to ""(.*)""")]
        public void WhenEAMReportsPageDisenrollmentReasonCodeIsSetTo(string p0)
        {
            tmsWait.Hard(3);
            string GeneratedData = tmsCommon.GenerateData(p0);
            IWebElement reason = Browser.Wd.FindElement(By.CssSelector("[test-id='Disenrollmentreason']"));
            SelectElement select = new SelectElement(reason);
            select.SelectByText(GeneratedData);
        }


        [When(@"EAM Reports page Cancelation Type is set to ""(.*)""")]
        public void WhenEAMReportsPageCancelationTypeIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            IWebElement planid = Browser.Wd.FindElement(By.CssSelector("[test-id='CancelationType']"));
            SelectElement select = new SelectElement(planid);
            select.SelectByText(GeneratedData);
        }



        [When(@"Reports Deemed LIS Detail Report page Plan Id is set to ""(.*)""")]
        [Given(@"Reports Deemed LIS Detail Report page Plan Id is set to ""(.*)""")]
        [Then(@"Reports Deemed LIS Detail Report page Plan Id is set to ""(.*)""")]
        public void WhenReportsDeemedLISDetailReportPagePlanIdIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            string GeneratedData = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Plan ID')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + GeneratedData + "']");


                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
            }
            else
            {
                SelectElement select = new SelectElement(EAM.ReportsDeemedLISDetailReport.PlanID);
                select.SelectByText(GeneratedData);
            }
        }

        [When(@"Reports Deemed LIS Detail Report page PBP Id is set to ""(.*)""")]
        [Given(@"Reports Deemed LIS Detail Report page PBP Id is set to ""(.*)""")]
        [Then(@"Reports Deemed LIS Detail Report page PBP Id is set to ""(.*)""")]
        public void WhenReportsDeemedLISDetailReportPagePBPIdIsSetTo(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'PBP Id')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + GeneratedData + "']");


                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
            }
            else
            {
                SelectElement select = new SelectElement(EAM.ReportsDeemedLISDetailReport.PBPID);
                select.SelectByText(GeneratedData);
            }
        }

        [When(@"Reports Deemed LIS Detail Run Report Button is Clicked")]
        [Given(@"Reports Deemed LIS Detail Run Report Button is Clicked")]
        [Then(@"Reports Deemed LIS Detail Run Report Button is Clicked")]
        public void WhenReportsDeemedLISDetailRunReportButtonIsClicked()
        {
            fw.ExecuteJavascript(EAM.ReportsDeemedLISDetailReport.RunReport);

            tmsWait.Hard(4);

            ReUsableFunctions.reportAuthenticationHandler();
        }
        [When(@"EAM Reports page Run Report Button is Clicked")]
        public void WhenEAMReportsPageRunReportButtonIsClicked()
        {
            fw.ExecuteJavascript(EAM.ReportsDeemedLISDetailReport.RunReport);

            tmsWait.Hard(4);

            ReUsableFunctions.reportAuthenticationHandler();
        }
        [When(@"EAM Reports Page ""(.*)"" link is Clicked")]
        public void WhenEAMReportsPageLinkIsClicked(string p0)
        {
            IWebElement link = Browser.Wd.FindElement(By.LinkText("Click here to search for value(s)"));
            fw.ExecuteJavascript(link);
            tmsWait.Hard(3);

          

        }



        [When(@"Plan Defined Fields page Update Out of Area Configuration section Disenrollment Months is set to ""(.*)""")]
        public void WhenPlanDefinedFieldsPageUpdateOutOfAreaConfigurationSectionDisenrollmentMonthsIsSetTo(string p0)
        {
            tmsWait.Hard(1);
            SelectElement mon = new SelectElement(EAM.AdministrationPlanDefinedFieldsOOATab.DisEnrollmentMonths);
            tmsWait.Hard(1);
            mon.SelectByText(p0);
        }

        [Then(@"Verify Plan Defined Fields page Update Out of Area Configuration section Disenrollment Months is selected to ""(.*)""")]
        public void ThenVerifyPlanDefinedFieldsPageUpdateOutOfAreaConfigurationSectionDisenrollmentMonthsIsSelectedTo(string p0)
        {
            tmsWait.Hard(2);
            string fieldName = " Out of Area Configuration section Disenrollment Months";
            SelectElement mon = new SelectElement(EAM.AdministrationPlanDefinedFieldsOOATab.DisEnrollmentMonths);
            String actual = mon.SelectedOption.Text;
            string expected = tmsCommon.GenerateData(p0);
            Assert.AreEqual(expected, actual, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
            tmsWait.Hard(1);

        }

        [Then(@"Verify Plan Defined Fields page View Out of Area Configuration table displays row")]
        public void ThenVerifyPlanDefinedFieldsPageViewOutOfAreaConfigurationTableDisplaysRow(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.AdministrationPlanDefinedFieldsOOATab.OutofAreaGrid;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "th", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                           


                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.AdministrationPlanDefinedFieldsOOATab.OutofAreaGrid;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }



        }

        [Then(@"Verify Plan Defined Fields page Possible OOA status tab has row ""(.*)"" ""(.*)"" ""(.*)""")]
        public void ThenVerifyPlanDefinedFieldsPagePossibleOOAStatusTabHasRow(string p0, string p1, string p2)
        {
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//tr[@id='ctl00_ctl00_MainMasterContent_MainContent_OutOfAreaConfiguration_statusesConfigView_uc_statusesGrid_ctl00__0']/td[2]")).Text.Contains(p0),"Status is not present");
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//tr[@id='ctl00_ctl00_MainMasterContent_MainContent_OutOfAreaConfiguration_statusesConfigView_uc_statusesGrid_ctl00__0']/td[3]")).Text.Contains(p1), "Source is not present");
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//tr[@id='ctl00_ctl00_MainMasterContent_MainContent_OutOfAreaConfiguration_statusesConfigView_uc_statusesGrid_ctl00__0']/td[5]")).Text.Contains(p2), "UserModified is not present");
        }


        [Then(@"Verify Plan Defined Fields page Possible Out of Area Status tab View OOA statuses table has row")]
        public void ThenVerifyPlanDefinedFieldsPagePossibleOutOfAreaStatusTabViewOOAStatusesTableHasRow(Table table)
        {

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.AdministrationPlanDefinedFieldsOOATab.PossibleOOAStatus;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                           

                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.AdministrationPlanDefinedFieldsOOATab.PossibleOOAStatus;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }



        }



        [Then(@"Verify Plan Defined Fields page Possible Out of Area Status tab New status field is disabled")]
        public void ThenVerifyPlanDefinedFieldsPagePossibleOutOfAreaStatusTabNewStatusFieldIsDisabled()
        {
            bool newstatus = EAM.AdministrationPlanDefinedFieldsOOATab.PossibleOOANewStatus.Enabled;
            Assert.IsFalse(newstatus, "New Status Field Is Disabled");
            fw.ConsoleReport(" Plan Defined Fields Page Possible OutOfArea Status Tab New Status Field Is Disabled ");
        }

        [Then(@"Verify Plan Defined Fields page Possible Out of Area Status tab Complete status field is disabled")]
        public void ThenVerifyPlanDefinedFieldsPagePossibleOutOfAreaStatusTabCompleteStatusFieldIsDisabled()
        {
            bool completestatus = EAM.AdministrationPlanDefinedFieldsOOATab.PossibleOOACompleteStatus.Enabled;
            Assert.IsFalse(completestatus, "Complete Status Field Is Disabled");
            fw.ConsoleReport(" Plan Defined Fields Page Possible OutOfArea Status Tab Complete Status Field Is Disabled ");
        }

        [Then(@"Verify Plan Defined Fields page OOA Configuration tab Disenrollment Months field displays tool tip message ""(.*)""")]
        public void ThenVerifyPlanDefinedFieldsPageOOAConfigurationTabDisenrollmentMonthsFieldDisplaysToolTipMessage(string p0)
        {
            string fieldName = "Plan Defined Fields page OOA Configuration tab Disenrollment Months ";
           
             OpenQA.Selenium.Interactions.Actions builder = new OpenQA.Selenium.Interactions.Actions(Browser.Wd);

             builder.MoveToElement(EAM.AdministrationPlanDefinedFieldsOOATab.DisEnrollmentMonthsLabel).Build().Perform();
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.AdministrationPlanDefinedFieldsOOATab.DisEnrollmentMonthsLabel.GetAttribute("title");
            tmsWait.Hard(2);
            Assert.AreEqual(expected, actual, "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
            tmsWait.Hard(1);
        }

        [Then(@"Out Of Area verification process dialog Save button is Clicked")]
        [When(@"Out Of Area verification process dialog Save button is Clicked")]
        public void ThenOutOfAreaVerificationProcessDialogSaveButtonIsClicked()
        {
            ReUsableFunctions.clickOnWebElement(cfUIMODViewEditMember.ViewOOA.OOASave); ;
            // tmsWait.Hard(1);
            //// EAM.MemberInformation.Savebutton.Click();
            // fw.ExecuteJavascript(EAM.MemberInformation.Savebutton);
            // tmsWait.Hard(3);
            // try
            // {
            //     Browser.Wd.SwitchTo().Alert().Accept();
            // }
            // catch
            // {
            // }
            // tmsWait.Hard(1);
        }

        [When(@"Out Of Area verification process dialog Close button is Clicked")]
        [Then(@"Out Of Area verification process dialog Close button is Clicked")]
        public void ThenOutOfAreaVerificationProcessDialogCloseButtonIsClicked()
        {
            tmsWait.Hard(1);
            fw.ExecuteJavascript(cfUIMODViewEditMember.ViewOOA.OOAClose);
        }

        [Then(@"Verify Add New Suspect button is displayed")]
        public void ThenVerifyAddNewSuspectButtonIsDisplayed()
        {
            Assert.IsTrue(EAM.MemberInformation.OOAAddNewSuspectbutton.Displayed);
        }

        [When(@"Verify Out Of Area verification process dialog Potential Out Of area check box is ""(.*)""")]
        [Then(@"Verify Out Of Area verification process dialog Potential Out Of area check box is ""(.*)""")]
        public void ThenVerifyOutOfAreaVerificationProcessDialogPotentialOutOfAreaCheckBoxIs(string p0)
        {
            tmsWait.Hard(1);
            string GenerateData = tmsCommon.GenerateData(p0);


            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }
            if (setCheckboxTo.Equals("unchecked"))
            {
                bool actual = EAM.MemberInformation.PotentialOutOfArea.Selected;
                Assert.IsFalse(actual, "Check box is not Checked");
                fw.ConsoleReport(" Potential Out Of Area check box is not Checked");

            }
            else if (setCheckboxTo.Equals("checked"))
            {
                bool actual = EAM.MemberInformation.PotentialOutOfArea.Selected;
                Assert.IsTrue(actual, "Check box is Checked");
                fw.ConsoleReport(" Potential Out Of Area check box is Checked");
            }

        }

        [Then(@"Verify Out Of Area verification process dialog Possible SCC discrepancy exists check box is ""(.*)""")]
        public void ThenVerifyOutOfAreaVerificationProcessDialogPossibleSCCDiscrepancyExistsCheckBoxIs(string p0)
        {
            tmsWait.Hard(1);
            string GenerateData = tmsCommon.GenerateData(p0);


            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }
            if (setCheckboxTo.Equals("unchecked"))
            {
                bool actual = EAM.MemberInformation.PossibleSCCDisExists.Selected;
                Assert.IsFalse(actual, "Check box is not Checked");
                fw.ConsoleReport(" Possible SCC Discrepancy Exists check box is not Checked");

            }
            else if (setCheckboxTo.Equals("checked"))
            {
                bool actual = EAM.MemberInformation.PossibleSCCDisExists.Selected;
                Assert.IsTrue(actual, "Check box is Checked");
                fw.ConsoleReport(" Possible SCC Discrepancy Exists check box is Checked");
            }
        }

        [When(@"Verify Out Of Area verification process dialog Queue Potential OOA letter check box is ""(.*)""")]
        [Then(@"Verify Out Of Area verification process dialog Queue Potential OOA letter check box is ""(.*)""")]
        [Given(@"Verify Out Of Area verification process dialog Queue Potential OOA letter check box is ""(.*)""")]
        public void ThenVerifyOutOfAreaVerificationProcessDialogQueuePotentialOOALetterCheckBoxIs(string p0)
        {
            tmsWait.Hard(2);
            string GenerateData = tmsCommon.GenerateData(p0);

            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("unchecked"))
            {

                if (EAM.MemberInformation.QueuePotentialOOALetter.Selected == true)
                {
                    EAM.MemberInformation.QueuePotentialOOALetter.Click();
            }

            }
            else if (setCheckboxTo.Equals("checked"))
            {
                if (EAM.MemberInformation.QueuePotentialOOALetter.Selected == false)
                {
                   EAM.MemberInformation.QueuePotentialOOALetter.Click();
            }
        }
        }


        [Then(@"OOA dialog Research Finding section Continuation Area check box is ""(.*)""")]
        public void ThenOOADialogResearchFindingSectionContinuationAreaCheckBoxIs(string p0)
        {
            ReUsableFunctions.CheckBoxOperations(cfUIMODViewEditMember.ViewOOA.InContinuingAreaCheckbox, p0);
            
            //tmsWait.Hard(1);
            //string GenerateData = tmsCommon.GenerateData(p0);


            //switch (GenerateData.ToLower())
            //{
            //    case "checked": { setCheckboxTo = "checked"; break; }
            //    case "on": { setCheckboxTo = "checked"; break; }
            //    case "yes": { setCheckboxTo = "checked"; break; }
            //    case "unchecked": { setCheckboxTo = "unchecked"; break; }
            //    case "off": { setCheckboxTo = "unchecked"; break; }
            //    case "no": { setCheckboxTo = "unchecked"; break; }
            //    default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            //}

            //if (setCheckboxTo.Equals("unchecked"))
            //{

            //    if (EAM.MemberInformation.OOAContiuningArea.Selected == true)
            //    {
            //        fw.ExecuteJavascript(EAM.MemberInformation.OOAContiuningArea);
            //    }

            //}
            //else if (setCheckboxTo.Equals("checked"))
            //{
            //    if (EAM.MemberInformation.OOAContiuningArea.Selected == false)
            //    {
            //        fw.ExecuteJavascript(EAM.MemberInformation.OOAContiuningArea);
            //    }
            //}

        }

        [Then(@"OOA dialog Research Finding section Travelers Visitors program check box is ""(.*)""")]
        public void ThenOOADialogResearchFindingSectionTravelersVisitorsProgramCheckBoxIs(string p0)
        {
            ReUsableFunctions.CheckBoxOperations(cfUIMODViewEditMember.ViewOOA.TravelersVisitorsProgramCheckbox, p0);
            //tmsWait.Hard(1);
            //string GenerateData = tmsCommon.GenerateData(p0);


            //switch (GenerateData.ToLower())
            //{
            //    case "checked": { setCheckboxTo = "checked"; break; }
            //    case "on": { setCheckboxTo = "checked"; break; }
            //    case "yes": { setCheckboxTo = "checked"; break; }
            //    case "unchecked": { setCheckboxTo = "unchecked"; break; }
            //    case "off": { setCheckboxTo = "unchecked"; break; }
            //    case "no": { setCheckboxTo = "unchecked"; break; }
            //    default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            //}

            //if (setCheckboxTo.Equals("unchecked"))
            //{

            //    if (EAM.MemberInformation.OOATravelersVisitors.Selected == true)
            //    {
            //        fw.ExecuteJavascript(EAM.MemberInformation.OOATravelersVisitors);
            //    }

            //}
            //else if (setCheckboxTo.Equals("checked"))
            //{
            //    if (EAM.MemberInformation.OOATravelersVisitors.Selected == false)
            //    {
            //        fw.ExecuteJavascript(EAM.MemberInformation.OOATravelersVisitors);
            //    }
            //}
        }

        [Then(@"OOA dialog Research Finding section ICEP conversion check box is ""(.*)""")]
        public void ThenOOADialogResearchFindingSectionICEPConversionCheckBoxIs(string p0)
        {
            ReUsableFunctions.CheckBoxOperations(cfUIMODViewEditMember.ViewOOA.ICEPConversion, p0);
            //tmsWait.Hard(1);
            //string GenerateData = tmsCommon.GenerateData(p0);


            //switch (GenerateData.ToLower())
            //{
            //    case "checked": { setCheckboxTo = "checked"; break; }
            //    case "on": { setCheckboxTo = "checked"; break; }
            //    case "yes": { setCheckboxTo = "checked"; break; }
            //    case "unchecked": { setCheckboxTo = "unchecked"; break; }
            //    case "off": { setCheckboxTo = "unchecked"; break; }
            //    case "no": { setCheckboxTo = "unchecked"; break; }
            //    default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            //}

            //if (setCheckboxTo.Equals("unchecked"))
            //{

            //    if (EAM.MemberInformation.OOAICEPConversion.Selected == true)
            //    {
            //        fw.ExecuteJavascript(EAM.MemberInformation.OOAICEPConversion);
            //    }

            //}
            //else if (setCheckboxTo.Equals("checked"))
            //{
            //    if (EAM.MemberInformation.OOAICEPConversion.Selected == false)
            //    {
            //        fw.ExecuteJavascript(EAM.MemberInformation.OOAICEPConversion);
            //    }
            //}
        }


        [Then(@"Out Of Area verification process dialog Queue Potential OOA letter check box is ""(.*)""")]
        public void ThenOutOfAreaVerificationProcessDialogQueuePotentialOOALetterCheckBoxIs(string p0)
        {
            ReUsableFunctions.CheckBoxOperations(cfUIMODViewEditMember.ViewOOA.QueuePotentialOOALetterCheckbox, p0); ;
            //tmsWait.Hard(1);
            //string GenerateData = tmsCommon.GenerateData(p0);


            //switch (GenerateData.ToLower())
            //{
            //    case "checked": { setCheckboxTo = "checked"; break; }
            //    case "on": { setCheckboxTo = "checked"; break; }
            //    case "yes": { setCheckboxTo = "checked"; break; }
            //    case "unchecked": { setCheckboxTo = "unchecked"; break; }
            //    case "off": { setCheckboxTo = "unchecked"; break; }
            //    case "no": { setCheckboxTo = "unchecked"; break; }
            //    default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            //}

            //if (setCheckboxTo.Equals("unchecked"))
            //{

            //    if (EAM.MemberInformation.QueuePotentialOOALetter.Selected == true)
            //    {
            //        fw.ExecuteJavascript(EAM.MemberInformation.QueuePotentialOOALetter);
            //    }

            //}
            //else if (setCheckboxTo.Equals("checked"))
            //{
            //    if (EAM.MemberInformation.QueuePotentialOOALetter.Selected == false)
            //    {
            //        fw.ExecuteJavascript(EAM.MemberInformation.QueuePotentialOOALetter);
            //    }
            //}
        }

        [Then(@"Verify Out Of Area verification process dialog Save button is disabled")]
        public void ThenVerifyOutOfAreaVerificationProcessDialogSaveButtonIsDisabled()
        {
            tmsWait.Hard(2);
            string fieldName = "Out Of Area Verification process dialog Save button ";
            bool actual = EAM.MemberInformation.Savebutton.Enabled;  
            
            Assert.IsFalse(actual, "Field " + fieldName + "Actual value is [" + actual + "]");           
            fw.ConsoleReport("   Verification Point: Out Of Area Verification process dialog Save button is disabled"); 
        }

        [Then(@"Verify Alert icon displays tooltip message ""(.*)""")]
        public void ThenVerifyAlertIconDisplaysTooltipMessage(string p0)
        {
           tmsWait.Hard(2);
            string GenerateData = tmsCommon.GenerateData(p0);            

            OpenQA.Selenium.Interactions.Actions builder = new OpenQA.Selenium.Interactions.Actions(Browser.Wd);

            builder.MoveToElement(EAM.MemberInformation.AlertTooltip).ClickAndHold().Build().Perform();
            //builder.MoveToElement(EAM.MemberInformation.AlertTooltip).Build().Perform();

            tmsWait.Hard(2);
            String TooltipTitle = EAM.MemberInformation.SusAlertTooltipTitle.Text;
            String TooltipMessage = EAM.MemberInformation.SusAlertTooltipMsg.Text;
            String actual = TooltipTitle + " " + TooltipMessage;
            Assert.AreEqual(GenerateData, actual, "Expected Alert icon Tool tip message is displayed");


        }

        [When(@"Receipt Date Validation Check box is ""(.*)""")]
        public void WhenReceiptDateValidationCheckBoxIs(string p0)
        {


            string GenerateData = tmsCommon.GenerateData(p0);


            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("unchecked"))
            {

                if (EAM.AdministrationPage.ReceiptDateValidation.Selected == true)
                {
                    EAM.AdministrationPage.ReceiptDateValidation.Click();
                }

            }
            else if (setCheckboxTo.Equals("checked"))
            {
                if (EAM.AdministrationPage.ReceiptDateValidation.Selected == false)
                {
                    EAM.AdministrationPage.ReceiptDateValidation.Click();
                }
            }
        }


        [When(@"EGHP Validation Check box is ""(.*)""")]
        public void WhenEGHPValidationCheckBoxIs(string p0)
        {

            string GenerateData = tmsCommon.GenerateData(p0);


            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("unchecked"))
            {

                if (EAM.AdministrationPage.EGHP.Selected == true)
                {
                    EAM.AdministrationPage.EGHP.Click();
                }

            }
            else if (setCheckboxTo.Equals("checked"))
            {
                if (EAM.AdministrationPage.EGHP.Selected == false)
                {
                    EAM.AdministrationPage.EGHP.Click();
                }
            }
        }


        [When(@"Plan Defined Fields page Save button is clicked")]
        public void WhenPlanDefinedFieldsPageSaveButtonIsClicked()
        {
            ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.OEVLetter.SaveBtn);
            tmsWait.Hard(3);
        }

        [Then(@"Verify View Edit Transaction page Credit Cover is set to ""(.*)""")]
        public void ThenVerifyViewEditTransactionPageCreditCoverIsSetTo(string p0)
        {
            string GeneratedData;
            string fieldName = "Member View Edit Transaction Page Credit Cover";
            if (p0.Equals("N"))
            {
                GeneratedData = "0";
            }
            else
            {
                GeneratedData = "1";
            }
            string thisFieldValue = EAM.TransactionsViewEdit.CreditCover.GetAttribute("value");
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }

        [When(@"WebAdministration page Enable Workflow Check box is ""(.*)""")]
        public void WhenWebAdministrationPageEnableWorkflowCheckBoxIs(string action)
        {
            if (action.ToLower().Equals("checked"))
            {
                if (!EAM.AdministrationPage.WorkFlowEnable.Selected)
                    EAM.AdministrationPage.WorkFlowEnable.Click();
            }
            else
            {
                if (EAM.AdministrationPage.WorkFlowEnable.Selected)
                    EAM.AdministrationPage.WorkFlowEnable.Click();
            }
        }


        [When(@"WebAdministration page Facet Integration Check box is ""(.*)""")]
        public void WhenWebAdministrationPageFacetIntegrationCheckBoxIs(string action)
        {
            if (action.ToLower().Equals("checked"))
            {
                if (!EAM.AdministrationPage.FacetsIntegrationCheckbox.Selected)
                    EAM.AdministrationPage.FacetsIntegrationCheckbox.Click();
            }
            else
            {
                if (EAM.AdministrationPage.FacetsIntegrationCheckbox.Selected)
                    EAM.AdministrationPage.FacetsIntegrationCheckbox.Click();
            }
        }


        [When(@"WebAdministration page Enable Member Lookup Check box is ""(.*)""")]
        public void WhenWebAdministrationPageEnableMemberLookupCheckBoxIs(string action)
        {
            if (action.ToLower().Equals("checked"))
            {
                if (!EAM.AdministrationPage.EnableMemberLookupCheckbox.Selected)
                    EAM.AdministrationPage.EnableMemberLookupCheckbox.Click();
            }
            else
            {
                if (EAM.AdministrationPage.EnableMemberLookupCheckbox.Selected)
                    EAM.AdministrationPage.EnableMemberLookupCheckbox.Click();
            }
        }

        [When(@"WebAdministration page Enable Export Span Check box is ""(.*)""")]
        public void WhenWebAdministrationPageEnableExportSpanCheckBoxIs(string action)
        {
            if (action.ToLower().Equals("checked"))
            {
                if (!EAM.AdministrationPage.EnableExportSpanCheckbox.Selected)
                    EAM.AdministrationPage.EnableExportSpanCheckbox.Click();
            }
            else
            {
                if (EAM.AdministrationPage.EnableExportSpanCheckbox.Selected)
                    EAM.AdministrationPage.EnableExportSpanCheckbox.Click();
            }
        }


        [When(@"Verify Facet End Point textbox Field is ""(.*)""")]
        public void WhenVerifyFacetEndPointTextboxFieldIs(string status)
        {
            if (status.ToLower().Equals("displayed"))
            {
                Assert.IsTrue(EAM.AdministrationPage.FacetEndPointtextbox.Displayed);
            }
            else
            {
                Assert.IsTrue(!EAM.AdministrationPage.FacetEndPointtextbox.Displayed);
            }
        }


        [When(@"Verify Identity textbox Field is ""(.*)""")]
        public void WhenVerifyIdentityTextboxFieldIs(string status)
        {
            if (status.ToLower().Equals("displayed"))
            {
                Assert.IsTrue(EAM.AdministrationPage.IdentityTextbox.Displayed);
            }
            else
            {
                Assert.IsTrue(!EAM.AdministrationPage.IdentityTextbox.Displayed);
            }
        }

        [When(@"Verify Region textbox Field is ""(.*)""")]
        public void WhenVerifyRegionTextboxFieldIs(string status)
        {
            if (status.ToLower().Equals("displayed"))
            {
                Assert.IsTrue(EAM.AdministrationPage.RegionTextbox.Displayed);
            }
            else
            {
                Assert.IsTrue(!EAM.AdministrationPage.RegionTextbox.Displayed);
            }
        }

        [When(@"Verify Calling System Name textbox Field is ""(.*)""")]
        public void WhenVerifyCallingSystemNameTextboxFieldIs(string status)
        {
            if (status.ToLower().Equals("displayed"))
            {
                Assert.IsTrue(EAM.AdministrationPage.CallingSystemNameTextbox.Displayed);
            }
            else
            {
                Assert.IsTrue(!EAM.AdministrationPage.CallingSystemNameTextbox.Displayed);
            }
        }

        [When(@"Verify Database Platform dropdown Field is ""(.*)""")]
        public void WhenVerifyDatabasePlatformDropdownFieldIs(string status)
        {
            if (status.ToLower().Equals("displayed"))
            {
                Assert.IsTrue(EAM.AdministrationPage.DatabasePlatformDropdown.Displayed);
            }
            else
            {
                Assert.IsTrue(!EAM.AdministrationPage.DatabasePlatformDropdown.Displayed);
            }
        }

        [When(@"Verify Server textbox Field is ""(.*)""")]
        public void WhenVerifyServerTextboxFieldIs(string status)
        {
            if (status.ToLower().Equals("displayed"))
            {
                Assert.IsTrue(EAM.AdministrationPage.ServerTextbox.Displayed);
            }
            else
            {
                Assert.IsTrue(!EAM.AdministrationPage.ServerTextbox.Displayed);
            }
        }

        [When(@"Verify Database textbox Field is ""(.*)""")]
        public void WhenVerifyDatabaseTextboxFieldIs(string status)
        {
            if (status.ToLower().Equals("displayed"))
            {
                Assert.IsTrue(EAM.AdministrationPage.DBTextbox.Displayed);
            }
            else
            {
                Assert.IsTrue(!EAM.AdministrationPage.DBTextbox.Displayed);
            }
        }

        [When(@"Verify Database User ID textbox Field is ""(.*)""")]
        public void WhenVerifyDatabaseUserIDTextboxFieldIs(string status)
        {
            if (status.ToLower().Equals("displayed"))
            {
                Assert.IsTrue(EAM.AdministrationPage.DBUserTextbox.Displayed);
            }
            else
            {
                Assert.IsTrue(!EAM.AdministrationPage.DBUserTextbox.Displayed);
            }
        }

        [When(@"Verify Database Password textbox Field is ""(.*)""")]
        public void WhenVerifyDatabasePasswordTextboxFieldIs(string status)
        {
            if (status.ToLower().Equals("displayed"))
            {
                Assert.IsTrue(EAM.AdministrationPage.DBPasswordTextbox.Displayed);
            }
            else
            {
                Assert.IsTrue(!EAM.AdministrationPage.DBPasswordTextbox.Displayed);
            }
        }

        [When(@"Verify User Warning Message textbox Field is ""(.*)""")]
        public void WhenVerifyUserWarningMessageTextboxFieldIs(string status)
        {
            if (status.ToLower().Equals("displayed"))
            {
                Assert.IsTrue(EAM.AdministrationPage.UserWarningMessageTextbox.Displayed);
            }
            else
            {
                Assert.IsTrue(!EAM.AdministrationPage.UserWarningMessageTextbox.Displayed);
            }
        }

        [When(@"Verify Warning Message TermDate dropdown Field is ""(.*)""")]
        public void WhenVerifyWarningMessageTermDateDropdownFieldIs(string status)
        {
            if (status.ToLower().Equals("displayed"))
            {
                Assert.IsTrue(EAM.AdministrationPage.WarningMessageTermDropdown.Displayed);
            }
            else
            {
                Assert.IsTrue(!EAM.AdministrationPage.WarningMessageTermDropdown.Displayed);
            }
        }

        [When(@"Verify HOSP ESRD Span TermDate dropdown Field is ""(.*)""")]
        public void WhenVerifyHOSPESRDSpanTermDateDropdownFieldIs(string status)
        {
            if (status.ToLower().Equals("displayed"))
            {
                Assert.IsTrue(EAM.AdministrationPage.HOSPESRDTermDateDropdown.Displayed);
            }
            else
            {
                Assert.IsTrue(!EAM.AdministrationPage.HOSPESRDTermDateDropdown.Displayed);
            }
        }

        [When(@"WebAdministration page Enable Export Span Checkbox is ""(.*)""")]
        public void WhenWebAdministrationPageEnableExportSpanCheckboxIs(string status)
        {
            if (status.ToLower().Equals("displayed"))
            {
                Assert.IsTrue(EAM.AdministrationPage.EnableExportSpanCheckbox.Displayed);
            }
            else
            {
                Assert.IsTrue(!EAM.AdministrationPage.EnableExportSpanCheckbox.Displayed);
            }
        }

        [When(@"WebAdministration page Enable Member Lookup Checkbox is ""(.*)""")]
        public void WhenWebAdministrationPageEnableMemberLookupCheckboxIs(string status)
        {
            if (status.ToLower().Equals("displayed"))
            {
                Assert.IsTrue(EAM.AdministrationPage.EnableMemberLookupCheckbox.Displayed);
            }
            else
            {
                Assert.IsTrue(!EAM.AdministrationPage.EnableMemberLookupCheckbox.Displayed);
            }
        }


        [When(@"WebAdministration page Modify Assigned Application Details dialog Plan Change PostCMS Check box is ""(.*)""")]
        public void WhenWebAdministrationPageModifyAssignedApplicationDetailsDialogPlanChangePostCMSCheckBoxIs(string p0)
        {
            string GenerateData = tmsCommon.GenerateData(p0);


            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("unchecked"))
            {

                if (EAM.AdministrationPage.PlanChangePostCMS.Selected == true)
                {
                    EAM.AdministrationPage.PlanChangePostCMS.Click();
                }

            }
            else if (setCheckboxTo.Equals("checked"))
            {
                if (EAM.AdministrationPage.PlanChangePostCMS.Selected == false)
                {
                    EAM.AdministrationPage.PlanChangePostCMS.Click();
                }
            }
        }
        [When(@"""(.*)"" Database query is executed")]
        public void WhenDatabaseQueryIsExecuted(string Querystring)
        {
            Querystring = tmsCommon.GenerateData(Querystring);
            if (Querystring.ToUpper().Contains("HICNUMBER")) { Querystring = Querystring.Replace("HICNumber", tmsCommon.GenerateData("Generate|variable|HIC")); }
            Dictionary<int, string[]> table = new Dictionary<int, string[]>();
           
            fsRSMLogin Executequery = new fsRSMLogin();
            table = Executequery.ExecuteSingleQuery(Querystring, ConfigFile.EAMdb, 7);
            string dbQueryResult = string.Join(",", table[0]);
            GlobalRef.DBQueryResult = dbQueryResult;
        }



        [When(@"WebAdministration page LetterLocation path is saved")]
        [Then(@"WebAdministration page LetterLocation path is saved")]
        public void WhenWebAdministrationPageLetterLocationPathIsSaved()
        {
            GlobalRef.LetterLocation = Browser.Wd.FindElement(By.Id("LetterFolder")).GetAttribute("value");
        }



        [Then(@"Members View Edit page Contact Address Type is set to ""(.*)""")]
        public void ThenMembersViewEditPageContactAddressTypeIsSetTo(string p0)
        {
            string GenerateData = tmsCommon.GenerateData(p0);
            SelectElement select = new SelectElement(EAM.MembersNewTabContact.AddressType);
            select.SelectByText(GenerateData);

        }

        [Then(@"Members View Edit Page New RxID is set to ""(.*)""")]
        [Given(@"Members View Edit Page New RxID is set to ""(.*)""")]
        public void ThenMembersViewEditPageNewRxIDIsSetTo(string ip)
        {
            string p0 = tmsCommon.GenerateData(ip);
            EAM.MemberInformation.MemberInfoPrimaryRxID.Clear();
            EAM.MemberInformation.MemberInfoPrimaryRxID.SendKeys(p0);
        }

        [Then(@"Members  View Edit Page Member ID is set to ""(.*)""")]
        public void ThenMembersViewEditPageMemberIDIsSetTo(string ip)
        {
            string p0 = tmsCommon.GenerateData(ip);
            EAM.MemberInformation.MemberInfoMemberID.Clear();
            EAM.MemberInformation.MemberInfoMemberID.SendKeys(p0);
        }


        [Then(@"Members View Edit page Contact tab Address1 is set to ""(.*)""")]
        public void ThenMembersViewEditPageContactTabAddressIsSetTo(string p1)
        {

            EAM.MembersViewEdit.MemberViewEditResidenceAddress1.Clear();
            EAM.MembersViewEdit.MemberViewEditResidenceAddress1.SendKeys(p1);
        }

        [Then(@"Members View Edit page Save button is clicked")]
        public void ThenMembersViewEditPageSaveButtonIsClicked()
        {
            EAM.MembersViewEdit.MemberViewEditSaveButton.Click();
        }


        [When(@"WebAdministration page Modify Assigned Application Details dialog Plan Change PreCMS Check box is ""(.*)""")]
        public void WhenWebAdministrationPageModifyAssignedApplicationDetailsDialogPlanChangePreCMSCheckBoxIs(string p0)
        {
            string GenerateData = tmsCommon.GenerateData(p0);


            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("UnChecked"))
            {

                if (EAM.AdministrationPage.PlanChangePreCMS.Selected == true)
                {
                    EAM.AdministrationPage.PlanChangePreCMS.Click();
                }

            }
            else if (setCheckboxTo.Equals("checked"))
            {
                if (EAM.AdministrationPage.PlanChangePreCMS.Selected == false)
                {
                    EAM.AdministrationPage.PlanChangePreCMS.Click();
                }
            }
        }


        [When(@"On Demand Letter Names page Add button is clicked")]
        public void WhenOnDemandLetterNamesPageAddButtonIsClicked()
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                fw.ExecuteJavascript(EAM.LettersTemplate.AngularOnDemandLetterTempAddButton);
            }
            else
            {
                fw.ExecuteJavascript(EAM.LettersTemplate.OnDemandLetterNamesAddButton);
            }
          
        }

        [When(@"On Demand Letter Templates page Add button is clicked")]
        public void WhenOnDemandLetterTemplatesPageAddButtonIsClicked()
        {

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                fw.ExecuteJavascript(EAM.LettersTemplate.AngularOnDemandLetterTempAddButton);
            }
            else
            {
                fw.ExecuteJavascript(EAM.LettersTemplate.OnDemandLetterTempAddButton);
            }
        }

        public static string MainWindowHandle = "";
        public static string ReportWindowHandle = "";
        public static string setCheckboxTo;

        [When(@"Edit Letter Template dialog Is active checkbox is set to ""(.*)""")]
        public void WhenEditLetterTemplateDialogIsActiveCheckboxIsSetTo(string p0)
        {

            tmsWait.Hard(2);
            string reportHandle = "", currentHandle = "";
            ReadOnlyCollection<string> windowHandles = Browser.Wd.WindowHandles;
            currentHandle = Browser.Wd.CurrentWindowHandle;

            if (MainWindowHandle == "")
            {
                MainWindowHandle = currentHandle;
            }
            if (MainWindowHandle != currentHandle)
            {
                if (ReportWindowHandle == "")
                {
                    ReportWindowHandle = currentHandle;
                }

            }

            ReportWindowHandle = "";

            foreach (string handle in windowHandles)
            {
                if (handle != MainWindowHandle)
                {
                    reportHandle = handle;
                    break;
                }
            }
            for (int i = 0; i < 6; i++)
            {
                try
                {
                    Browser.Wd.SwitchTo().Window(reportHandle);

                    String ReportTitle = Browser.Wd.SwitchTo().Window(reportHandle).Title;
                    Console.WriteLine(ReportTitle);

                    break;
                }
                catch (Exception) { tmsWait.Hard(2); }
            }

            string GenerateData = tmsCommon.GenerateData(p0);


            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("unchecked"))
            {
                if (EAM.LettersTemplate.EditLetterTemplateIsActivecheckbox.Selected == true)
                {
                    EAM.LettersTemplate.EditLetterTemplateIsActivecheckbox.Click();
                }
            }
            else if (setCheckboxTo.Equals("checked"))
            {
                if (EAM.LettersTemplate.EditLetterTemplateIsActivecheckbox.Selected == false)
                {
                    EAM.LettersTemplate.EditLetterTemplateIsActivecheckbox.Click();
                }
            }



            tmsWait.Hard(2);

        }


        [When(@"Edit Letter Name dialog Is active checkbox is set to ""(.*)""")]
        public void WhenEditLetterNameDialogIsActiveCheckboxIsSetTo(string p0)
        {
            string status = tmsCommon.GenerateData(p0);
            IWebElement letterName = Browser.Wd.FindElement(By.CssSelector("[name='letterIsActive']"));
            ReUsableFunctions.CheckBoxOperations(letterName,status);
            tmsWait.Hard(2);
        }

        [When(@"Edit Letter Template dialog Save button is Clicked")]
        public void WhenEditLetterTemplateDialogSaveButtonIsClicked()
        {
            fw.ExecuteJavascript(EAM.LettersTemplate.EditLetterTemplateSavebutton);
        }

        [When(@"Edit Letter Name dialog Save button is Clicked")]
        [Given(@"Edit Letter Name dialog Save button is Clicked")]
        public void WhenEditLetterNameDialogSaveButtonIsClicked()
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                fw.ExecuteJavascript(EAM.LettersTemplate.AngularEditLetterNameSaveButton);
            }
            else
            {
                fw.ExecuteJavascript(EAM.LettersTemplate.EditLetterNameSaveButton);
            }
        }


        [When(@"Add Letter Name dialog Letter Name is set to ""(.*)""")]
        public void WhenAddLetterNameDialogLetterNameIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            string dropDownValue = "999Anastasiya_SimpleTemplate";
            By name = By.Name("letterName");
            UIMODUtilFunctions.enterValueOnWebElementUsingLocators(name, value);
            tmsWait.Hard(2);
            Browser.Wd.FindElement(name).SendKeys(Keys.Tab);
            tmsWait.Hard(2);


            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//*[@id='onDemandLetterResultGrid']//div[@role='presentation']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + dropDownValue + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                tmsWait.Hard(3);
            }
            else
            {
                By tcsTemplatedrp = By.CssSelector("[aria-owns='templateId_listbox']");
                UIMODUtilFunctions.selectDropDownValueFromGendoUI(Browser.Wd.FindElement(tcsTemplatedrp), "999Anastasiya");
                tmsWait.Hard(2);
            }
        }


        [When(@"Add Letter Template dialog Letter Name is set to ""(.*)""")]
        public void WhenAddLetterTemplateDialogLetterNameIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            IWebElement ele = Browser.Wd.FindElement(By.Name("letterName"));
            ele.SendKeys(value);
            ele.SendKeys(Keys.Tab);
        }

        [When(@"Add Letter Template dialog TCS Template ID is set to ""(.*)""")]
        public void WhenAddLetterTemplateDialogTCSTemplateIDIsSetTo(string p0)
        {
            if (EAM.LettersTemplate.TCSTemplateStaticMessage.Text == "Please select a TCS Template ID.")
            {

                OpenQA.Selenium.Support.UI.SelectElement TCSTemplate = new SelectElement(EAM.LettersTemplate.AddLetterTempdialogTCSTemplateIDdropdown);
                string TCSTemplateName  = tmsCommon.GenerateData(p0);
                TCSTemplate.SelectByText(TCSTemplateName);

            }
            else
            {
                tmsWait.Hard(2);
                OpenQA.Selenium.Support.UI.SelectElement TCSTemplate = new SelectElement(EAM.LettersTemplate.AddLetterTempdialogTCSTemplateIDdropdown);
                string TCSTemplateName = tmsCommon.GenerateData(p0);
                TCSTemplate.SelectByText(TCSTemplateName);
            }
        }

        [When(@"Add Letter Template dialog TCS Template ID is set to ""(.*)"" Successfully")]
        public void WhenAddLetterTemplateDialogTCSTemplateIDIsSetToSuccessfully(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//*[@id='onDemandLetterResultGrid']//div[@role='presentation']//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + value + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                tmsWait.Hard(3);
            }
            else
            {
                UIMODUtilFunctions.selectDropDownValueFromGendoUI(EAM.LettersTemplate.AddLetterTempdialogTCSTemplateIDdropdown, value);
            }
        }


        [Then(@"On Demand Letter Templates table has existing Letter Template is Clicked")]
        public void ThenOnDemandLetterTemplatesTableHasExistingLetterTemplateIsClicked(Table table)
        {
           
        }


        [Then(@"On Demand Letter Names table has existing Letter Template is Clicked")]
        [When(@"On Demand Letter Names table has existing Letter Template is Clicked")]
        [Given(@"On Demand Letter Names table has existing Letter Template is Clicked")]
        public void ThenOnDemandLetterNamesTableHasExistingLetterTemplateIsClicked(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.LettersTemplate.OnDemandLetterTempTable; ;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            if (bThisRowMatches)
                            {
                                IWebElement thisEditTD = ApplicationRow.Element[10];
                                IWebElement thisEditLink = thisEditTD.FindElement(By.TagName("input"));
                                thisEditLink.Click();
                                tmsWait.Hard(2);

                            }

                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.LettersTemplate.OnDemandLetterTempTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }


        [Then(@"Letter Templates Page Letters Dropdown list ""(.*)"" is selected")]
        public void ThenLetterTemplatesPageLettersDropdownListIsSelected(string p0)
        {
            tmsWait.Hard(3);
            OpenQA.Selenium.Support.UI.SelectElement LetterTemplate = new SelectElement(EAM.LettersTemplate.LettersDropdown);
            string letterTemplate = tmsCommon.GenerateData(p0);
            LetterTemplate.SelectByText(letterTemplate);
        
        }

        [Then(@"Letter Templates Page Letter Name drop down list ""(.*)"" is not displayed")]
        [Given(@"Letter Templates Page Letter Name drop down list ""(.*)"" is not displayed")]
        [Then(@"Letter Templates Page Letter Name drop down list ""(.*)"" is not displayed")]
        public void ThenLetterTemplatesPageLetterNameDropDownListIsNotDisplayed(string p0)
        {
            try
            {
                SelectElement Letternames = new SelectElement(EAM.LettersTemplate.LetterNameDropdown);
                string GeneratedData = tmsCommon.GenerateData(p0);

                foreach (IWebElement element in Letternames.Options)
                {
                    if (element.Text != GeneratedData)
                    {
                        break;

                    }
                }
                Console.WriteLine("In Letter Template page, There are no " + p0 + " found on this Drop down list");
            }
            catch
            {
                Console.WriteLine("In Letter Template page, There are no " + p0 + " found on this Drop down list");
            }
        }

        [Then(@"Letter Templates Page Letter Name drop down list ""(.*)"" is displayed")]
        public void ThenLetterTemplatesPageLetterNameDropDownListIsDisplayed(string p0)
        {
            SelectElement Letternames = new SelectElement(EAM.LettersTemplate.LetterNameDropdown);
            string GeneratedData = tmsCommon.GenerateData(p0);
            string fieldName = "Letter Template Page ";
           
            foreach (IWebElement element in Letternames.Options)
            {
                if (element.Text == GeneratedData)
                {
                    String actual = element.Text;
                                                        
                    Assert.AreEqual(true, GeneratedData == actual, "Field " + fieldName + " value is [" + actual + "], expected [" + GeneratedData + "]");
                    fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + actual + "], expected [" + GeneratedData + "] - They are expected to match.");
                }
            }

            
        }


        [Then(@"On Demand Letter Names table has newly added Letter Name")]
        public void ThenOnDemandLetterNamesTableHasNewlyAddedLetterName(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.LettersTemplate.OnDemandLetterNamesTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("On Demand Letter Template Table has row: {0}", e.Message);
            }

        }


        [Then(@"On Letters Template Page has ""(.*)"" message")]
        public void ThenOnLettersTemplatePageHasMessage(string p0)
        {
                        
            string fieldName = "Letter Template Page Message";
            string actual = tmsCommon.GenerateData(p0);
            string expected = null;
            if (ConfigFile.tenantType == "tmsx")
            {
                 expected = EAM.LettersTemplate.LetterTemplateRetireMsgLbl.Text;
            }
            else
            {
                 expected = EAM.LettersTemplate.LetterTemplateRetireMsg.Text;
            }

            string result = Regex.Replace(expected, @"\r\n?|\n", "sep");
            String[] spearator = {  "sep" };
            string[] L = result.Split(spearator, StringSplitOptions.RemoveEmptyEntries);

            if (ConfigFile.tenantType == "tmsx")
            {
                Assert.IsTrue(actual.Contains(L[0]), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
                fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
            }
            else
            {
                Assert.IsTrue(actual.Contains(L[3]), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
                fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");

            }
              
        }

        [Then(@"Verify On Demand Letter Names displayed ""(.*)""")]
        public void ThenVerifyOnDemandLetterNamesDisplayed(string letter)
        {
            tmsWait.Hard(3);
            string p0 = tmsCommon.GenerateData(letter);
            IWebElement edit;

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                edit = Browser.Wd.FindElement(By.XPath("//*[@id='onDemandLetterResultGrid']//td[contains(.,'" + p0 + "')]"));
                Assert.IsTrue(edit.Displayed, "expected Template is not getting displayed");
            }
            else
            {
                edit = Browser.Wd.FindElement(By.XPath("//div[@test-id='onDemandLetter-grid']//td[contains(.,'" + p0 + "')]"));
                Assert.IsTrue(edit.Displayed, p0 + " is not getting displayed");
            }
        }

        [Then(@"On Demand Letter Names table existing Letter Template ""(.*)"" is Clicked")]
        [When(@"On Demand Letter Names table existing Letter Template ""(.*)"" is Clicked")]
        [Given(@"On Demand Letter Names table existing Letter Template ""(.*)"" is Clicked")]
        public void ThenOnDemandLetterNamesTableExistingLetterTemplateIsClicked(string letter)
        {
            tmsWait.Hard(3);
            string p0 = tmsCommon.GenerateData(letter);
            IWebElement edit;

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                edit = Browser.Wd.FindElement(By.XPath("//*[@id='onDemandLetterResultGrid']//td[contains(.,'" + p0 + "')]/following-sibling::td//a"));
                fw.ExecuteJavascript(edit);
            }
            else
            {
                edit = Browser.Wd.FindElement(By.XPath("//div[@test-id='onDemandLetter-grid']//td[contains(.,'" + p0 + "')]/following-sibling::td//a"));
                fw.ExecuteJavascript(edit);
            }
        }

        [When(@"Letter Templates page Letters drp down value is set to ""(.*)""")]
        public void WhenLetterTemplatesPageLettersDrpDownValueIsSetTo(string name)
        {
            new SelectElement(Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlLetters"))).SelectByText(name);

            tmsWait.Hard(3);
        }

        [When(@"Letter Templates page Ok button is clicked")]
        public void WhenLetterTemplatesPageOkButtonIsClicked()
        {
            IWebElement edit = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_cmdOK"));
            fw.ExecuteJavascript(edit);
            tmsWait.Hard(5);
        }

        [When(@"Letter Templates page Existing Letter Name ""(.*)"" is Edited and UnChecked")]
        public void WhenLetterTemplatesPageExistingLetterNameIsEditedAndUnChecked(string p0)
        {
            string name = tmsCommon.GenerateData(p0);
            IWebElement edit = Browser.Wd.FindElement(By.XPath("//table[@id='ctl00_ctl00_MainMasterContent_MainContent_grdLetterTypes']//tr/td[contains(.,'"+ name + "')]/preceding-sibling::td/input"));
            fw.ExecuteJavascript(edit);
            tmsWait.Hard(1);
            IWebElement checkBox = Browser.Wd.FindElement(By.XPath("//div[@id='ctl00_ctl00_MainMasterContent_MainContent_upLetterTypeEdit']//input[@type='checkbox']"));
              fw.ExecuteJavascript(checkBox);
            tmsWait.Hard(1);
            IWebElement save = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_btnSaveLetterType"));
            fw.ExecuteJavascript(save);
        }


        [Then(@"Verify Letter Templates page Letter Name ""(.*)"" is displayed")]
        public void ThenVerifyLetterTemplatesPageLetterNameIsDisplayed(string p0)
        {
            string name = tmsCommon.GenerateData(p0);
            try
            {
                new SelectElement(Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlLetterTypes"))).SelectByText(name);
            }
            catch
            {
                Assert.Fail(" Letter Name is not found");
            }
        }

        [Then(@"Verify Letter Templates page Letter Name ""(.*)"" is not displayed")]
        public void ThenVerifyLetterTemplatesPageLetterNameIsNotDisplayed(string p0)
        {
            string name = tmsCommon.GenerateData(p0);
            try
            {
                new SelectElement(Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlLetters"))).SelectByText(name);
                Assert.Fail(" Letter Name is  found");
            }
            catch
            {
                Assert.IsTrue(true);
                fw.ConsoleReport(" There is no Letter Name found  after Uncheck");
            }
        }


        [Then(@"On Demand Letter Names table has newly added Letter Name as ""(.*)""")]
        public void ThenOnDemandLetterNamesTableHasNewlyAddedLetterNameAs(string p0)
        {
            tmsWait.Hard(3);
            string lettername = tmsCommon.GenerateData(p0);
            IWebElement textPresence;

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                textPresence = Browser.Wd.FindElement(By.XPath("//*[@id='onDemandLetterResultGrid']//td[contains(.,'" + lettername + "')]"));
                Assert.IsTrue(textPresence.Displayed, "expected Template is not getting displayed");
            }
            else
            {
                textPresence = Browser.Wd.FindElement(By.XPath("//div[@test-id='onDemandLetter-grid']//td[contains(.,'" + lettername + "')]"));
                Assert.IsTrue(textPresence.Displayed, "expected Template is not getting displayed");

            }
        }


        [Then(@"On Demand Letter Templates table has newly added Letter Template as ""(.*)"" TCS Template ID as ""(.*)""")]
        public void ThenOnDemandLetterTemplatesTableHasNewlyAddedLetterTemplateAsTCSTemplateIDAs(string p0, string p1)
        {
            tmsWait.Hard(3);
            string lettername = tmsCommon.GenerateData(p0);
            string template = tmsCommon.GenerateData(p1);
            IWebElement textPresence;

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                textPresence = Browser.Wd.FindElement(By.XPath("//*[@id='onDemandLetterResultGrid']//td[contains(.,'" + lettername + "')]/following-sibling::td[contains(.,'" + template + "')]"));
                Assert.IsTrue(textPresence.Displayed, "expected Template is not getting displayed");
            }
            else
            {
                textPresence = Browser.Wd.FindElement(By.XPath("//div[@test-id='onDemandLetter-grid']//td[contains(.,'" + lettername + "')]/following-sibling::td[contains(.,'" + template + "')]"));
                Assert.IsTrue(textPresence.Displayed, "expected Template is not getting displayed");
            }
            
        }


        [Then(@"On Demand Letter Templates table has newly added Letter Template")]
        [When(@"On Demand Letter Templates table has newly added Letter Template")]
        [Given(@"On Demand Letter Templates table has newly added Letter Template")]
        public void ThenOnDemandLetterTemplatesTableHasNewlyAddedLetterTemplate(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.LettersTemplate.OnDemandLetterTempTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("On Demand Letter Template Table has row: {0}", e.Message);
            }

        }

        [When(@"Add Letter Name dialog Save button is clicked")]
        public void WhenAddLetterNameDialogSaveButtonIsClicked()
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                fw.ExecuteJavascript(EAM.LettersTemplate.AngularOnDemandSaveButton);
            }
            else
            {
                fw.ExecuteJavascript(EAM.LettersTemplate.AddLetterNameSaveButton);
            }
        }

        [When(@"Add Letter Template dialog Save button is clicked")]
        public void WhenAddLetterTemplateDialogSaveButtonIsClicked()
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                fw.ExecuteJavascript(EAM.LettersTemplate.AngularOnDemandSaveButton);
            }
            else
            {
                fw.ExecuteJavascript(EAM.LettersTemplate.SaveButton);
            }
           
        }

        [Then(@"Verify View Edit Transaction page UnCovered Months is set to ""(.*)""")]
        public void ThenVerifyViewEditTransactionPageUnCoveredMonthsIsSetTo(string p0)
        {
           string fieldName = "Member View Edit Transaction Page Uncovered Months";
            string GeneratedData = tmsCommon.GenerateData(p0);
            string thisFieldValue = EAM.TransactionsViewEdit.UncoveredMonths.GetAttribute("value");
            Assert.AreEqual(true, GeneratedData == thisFieldValue, "Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "]");
            fw.ConsoleReport(" Verification Point: Field " + fieldName + " value is [" + thisFieldValue + "], expected [" + GeneratedData + "] - They are expected to match.");
        }


        [Then(@"Verify Members New Tab RXBilling Table has LIS row")]
        public void ThenVerifyMembersNewTabRXBillingTableHasLISRow(Table table)
        {
            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.MembersNewTabRXBilling.LISTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                //            thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 2)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[2];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                //else
                //{
                //    //Click next page link and start over.
                //    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                //    {
                //        thisTP.bNotAtLastPageOfRecords = true;
                //        thisTP.NPL.Click();
                //        tmsWait.Hard(2);
                //    }
                //}
                baseTable = EAM.MembersNewTabRXBilling.LISTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }
        }


        //[Then(@"Verify Reports OEC/EAF Fallout Window has no Member details")]
        //public void ThenVerifyReportsOECEAFFalloutWindowHasNoMemberDetails(Table table)
        //{
        //    By reportViewBy = EAM.Reports.ReportMainViewBy;
        //    string reportExpText = "HIC";
        //    string reportHandle = "";

        //    reportHandle = ReportsCommon.SwitchToReportWindow(reportViewBy, 30, reportExpText);

        //    if (reportHandle == "")
        //    {
        //        Assert.Fail("CMS Response Code Level Detail Report was not opened");
        //    }

        //    //try
        //    //{
        //    //    ReportsCommon.VerifyReportHasnoData(reportViewBy, reportExpText, table);
        //    //}
        //    catch (Exception e)
        //    {
        //        Browser.Wd.SwitchTo().Window(reportHandle).Close();
        //        Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle).Close();
        //        Assert.Fail("Verify CMS Response Code Level Detail Report has data. Exception: {0}", e.Message);
        //    }

        //    Browser.Wd.SwitchTo().Window(ReportsCommon.MainWindowHandle);

        //}

       


        [Then(@"Home Page Confirmation of Disenrollment Due to Passive Enrollment into a Medicare-Medicaid Plan queue should not display following data")]
        public void ThenHomePageConfirmationOfDisenrollmentDueToPassiveEnrollmentIntoAMedicare_MedicaidPlanQueueShouldNotDisplayFollowingData(Table table)
        {


            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.Letters.MedicareMedicaidLettersQueueTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            try
                            {
                                if (bThisRowMatches)
                                {
                                    IWebElement thisEditTD = ApplicationRow.Element[0];
                                    IWebElement thisEditLink = thisEditTD.FindElement(By.XPath("//a[contains(@href,'reports/reportmain_letterqueue.aspx?code=030&type=2')]"));
                                   

                                }
                            }
                            catch
                            {
                                GlobalRef.LetterCount = 0;
                            }


                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.Letters.MedicareMedicaidLettersQueueTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }




        }


        [Then(@"Home Page Confirmation of Disenrollment Due to Passive Enrollment into a Medicare-Medicaid Plan queue is clicked")]
        public void ThenHomePageConfirmationOfDisenrollmentDueToPassiveEnrollmentIntoAMedicare_MedicaidPlanQueueIsClicked(Table table)
        {

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.Letters.LettersQueueTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                            try
                            {
                                if (bThisRowMatches)
                                {
                                    IWebElement thisEditTD = ApplicationRow.Element[0];
                                    IWebElement thisEditLink = thisEditTD.FindElement(By.XPath("//a[contains(@href,'reports/reportmain_letterqueue.aspx?code=030&type=2')]"));
                                    tmsWait.Hard(2);
                                    thisEditLink.Click();
                                    


                                }
                            }
                            catch
                            {
                                GlobalRef.LetterCount = 0;
                            }


                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                baseTable = EAM.Letters.LettersQueueTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }




        }


        [Then(@"Member Info Page Transaction History table has TC51 row")]
        public void ThenMemberInfoPageTransactionHistoryTableHasTC51Row(Table table)
        {

            try
            {
                IWebElement objWebTable = EAM.MemberInformation.TransactionHistoryTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Members View Edit Table has row: {0}", e.Message);
            }




        }




        [Then(@"Member Info Page Transaction History table has TC61 row")]
        public void ThenMemberInfoPageTransactionHistoryTableHasTC61Row(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.MemberInformation.TransactionHistoryTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Members View Edit Table has row: {0}", e.Message);
            }




        }



        [Then(@"Verify Member View Edit Page Residence Address1 is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditPageResidenceAddressIsSetTo(string p1)
        {
            string fieldName = "Member View Edit Page Residence Address 1";
            string expected = tmsCommon.GenerateData(p1);
            string actual = EAM.MembersViewEdit.MemberViewEditResidenceAddress1.GetAttribute("value");
            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is expected [" + expected + "], actual [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }
        [Then(@"Verify Member View Edit Page Residence Address2 is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditPageResidenceAddress2IsSetTo(string p1)
        {
            string fieldName = "Member View Edit Page Residence Address 2";
            string expected = tmsCommon.GenerateData(p1);
            string actual = EAM.MembersViewEdit.MemberViewEditResidenceAddress2.GetAttribute("value");
            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }

       

        [Then(@"Verify Member View Edit Page Mailing Address2 is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditPageMailingAddress2IsSetTo(string p1)
        {
            string fieldName = "Member View Edit Page Mailing Address 2";
            string expected = tmsCommon.GenerateData(p1);
            string actual = EAM.MembersViewEdit.MemberViewEditMailingAddress2.GetAttribute("value");
            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }


        [Then(@"Verify Member View Edit Page Residence City is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditPageResidenceCityIsSetTo(string p0)
        {
            string fieldName = "Member View Edit Page Residence City";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MembersViewEdit.MemberViewEditResidenceCity.GetAttribute("value");
            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }

        [Then(@"Verify Member View Edit Page Residence State is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditPageResidenceStateIsSetTo(string p0)
        {
            string fieldName = "Member View Edit Page Residence state";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MembersViewEdit.MemberViewEditResidenceState.GetAttribute("value");
            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }
        [Then(@"Verify Member View Edit Page Residence County value is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditPageResidenceCountyValueIsSetTo(string p0)
        {
            string fieldName = "Member View Edit Page Residence County";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MembersViewEdit.MemberViewEditResidenceInvalidCounty.GetAttribute("value");
            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }

        [When(@"Member Info Page Contact tab Save button is clicked")]
        public void WhenMemberInfoPageContactTabSaveButtonIsClicked()
        {
            EAM.MembersViewEdit.MemberViewEditSaveButton.Click();
        }

        [Then(@"Verify Member View Edit Page Residence ZIP is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditPageResidenceZIPIsSetTo(string p0)
        {
            string fieldName = "Member View Edit Page Residence ZIP";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MembersViewEdit.MemberViewEditResidenceZip.GetAttribute("value");
            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }

        [Then(@"Verify Member View Edit Page Residence County is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditPageResidenceCountyIsSetTo(string p0)
        {
            string fieldName = "Member View Edit Page Residence County";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MembersViewEdit.MemberViewEditResidenceCounty.GetAttribute("value");
            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }

        [Then(@"Verify Member View Edit Page Residence SCC is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditPageResidenceSCCIsSetTo(string p0)
        {
            string fieldName = "Member View Edit Page Residence SCC";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MembersViewEdit.MemberViewEditResidenceSCC.GetAttribute("value");
            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }

        [Then(@"Verify Member View Edit Page Other City is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditPageOtherCityIsSetTo(string p0)
        {
            string fieldName = "Member View Edit Page Other City";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MembersViewEdit.MemberViewEditMailingModAddress1.GetAttribute("value");
            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }
        [Then(@"Verify Member View Edit Page Other Address(.*) is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditPageOtherAddressIsSetTo(string p0, string p1)
        {
            string fieldName = "Member View Edit Page Other Address";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MembersViewEdit.MemberViewEditMailingModAddress1.GetAttribute("value");
            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }


        [Then(@"Verify Member View Edit Page Mailing Address1 is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditPageMailingAddress1IsSetTo(string p1)
        {
            string fieldName = "Member View Edit Page Mailing Address 1";
            string expected = tmsCommon.GenerateData(p1);
            string actual = EAM.MembersViewEdit.MemberViewEditMailingModAddress1.GetAttribute("value");
            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }

        [Then(@"Verify Member View Edit Page Mailing City is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditPageMailingCityIsSetTo(string p0)
        {
            string fieldName = "Member View Edit Page Mailing City";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MembersViewEdit.MemberViewEditMailingCity.GetAttribute("value");
            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }

        [Then(@"Verify Member View Edit Page Other State is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditPageOtherStateIsSetTo(string p0)
        {
            string fieldName = "Member View Edit Page Other State";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MembersViewEdit.MemberViewEditResidenceState.GetAttribute("value");
            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");

        }


        [Then(@"Verify Member View Edit Page Mailing State is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditPageMailingStateIsSetTo(string p0)
        {
            string fieldName = "Member View Edit Page Mailing State";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MembersViewEdit.MemberViewEditMailingState.GetAttribute("value");
            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }

        [Then(@"Verify Member View Edit Page Mailing ZIP is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditPageMailingZIPIsSetTo(string p0)
        {
            string fieldName = "Member View Edit Page Mailing ZIP";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MembersViewEdit.MemberViewEditMailingZip.GetAttribute("value");
            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }

        [Then(@"Verify Member View Edit Page Other ZIP is set to ""(.*)""")]
        public void ThenVerifyMemberViewEditPageOtherZIPIsSetTo(string p0)
        {
            string fieldName = "Member View Edit Page Other ZIP";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MembersViewEdit.MemberViewEditResidenceZip.GetAttribute("value");
            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");

        }


        [Then(@"Verify Members View Edit Page HIC Number is set to ""(.*)""")]
        public void ThenVerifyMembersViewEditPageHICNumberIsSetTo(string p0)
        {
           
            string fieldName = "Member View Edit Page HIC Number";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MembersViewEdit.MemberViewEditHIC.GetAttribute("value");
             Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }

        [Then(@"Verify Members View Edit Page First Name is set to ""(.*)""")]
        public void ThenVerifyMembersViewEditPageFirstNameIsSetTo(string p0)
        {
            string fieldName = "Member View Edit Page First Name";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MembersViewEdit.MemberViewEditFirstName.GetAttribute("value");
            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }

        [Then(@"Verify Members View Edit Page Last Name is set to ""(.*)""")]
        public void ThenVerifyMembersViewEditPageLastNameIsSetTo(string p0)
        {
            string fieldName = "Member View Edit Page Last Name";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MembersViewEdit.MemberViewEditLastName.GetAttribute("value");
            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }

        [Then(@"Verify Members View Edit Page Effective Date is set to ""(.*)""")]
        public void ThenVerifyMembersViewEditPageEffectiveDateIsSetTo(string p0)
        {
            string fieldName = "Member View Edit Page EffectiveDate";
            string expected = tmsCommon.GenerateData(p0);
            string actual = EAM.MembersViewEdit.MemberViewEditEffectiveDate.GetAttribute("value");
            Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
        }



        [When(@"Load OEC File page, Config File ALM Project, Test ID ""(.*)"" attached file ""(.*)"" is selected with New File Name ""(.*)""")]
        public void WhenLoadOECFilePageConfigFileALMProjectTestIDAttachedFileIsSelectedWithNewFileName(string p0, string p1, string p2)
        {
            string po_gen = tmsCommon.GenerateData(p0);
            string p1_gen = tmsCommon.GenerateData(p1);
            string p2_gen = tmsCommon.GenerateData(p2);
            Boolean keepTrying = true;
            int maxAttempts = 11;
            int thisAttempt = 0;
            Console.WriteLine("**Before call to ALM file download**");
            //If we run from the controller, the controller will bring the files to c:\temp\tmsalm\
            //if they are there, we copy across.   Otherwise we reach into ALM to get them.
            string controllerFileLocation = "c:\\temp\\tmsAlm\\";
            // We added this code for Jenkins run
            string SourceFileLocation = "C:\\SourceFile\\";
            Boolean didUpload = false;
            string source = SourceFileLocation + p1_gen;
            if (Directory.Exists(SourceFileLocation))
            {
                if (!File.Exists(controllerFileLocation))
                {
                    File.Copy(SourceFileLocation + p1_gen, controllerFileLocation + Path.GetFileName(source));
                }
            }

            if (File.Exists(controllerFileLocation + p1_gen))
            {
                File.Copy(controllerFileLocation + p1_gen, "C:\\Temp\\" + p1_gen);
                tmsWait.Hard(1);
                didUpload = true;
            }
            else
            {
                didUpload = ALMUtilities.GetALMTestPlanAttachedFile(p1_gen, po_gen);
            }
            if (didUpload)
            {
                 string FileName = "C:\\Temp\\" + p1_gen;

                    //For debugging
                    string newFileName = "C:\\Temp\\" + tmsCommon.GenerateData(p2_gen);
                    File.Move(@FileName, @newFileName);
                    FileName = newFileName;
                    EAM.LoadEAFFile.Browse.SendKeys(FileName);
                    EAM.LoadEAFFile.Import.Click();
                    tmsWait.Hard(1);
                        string thisResponse = EAM.LoadEAFFile.ResponseMessage.Text;
                    if (thisResponse.Equals("The specified filename does not match for this file type. Please verify the file or modify the filename."))
                    {
                        keepTrying = false;
                        Console.WriteLine("File load failed with message [" + thisResponse + "]");
                    }

            }
        }


        [Given(@"Home page ""(.*)"" queue count is note down")]
        [When(@"Home page ""(.*)"" queue count is note down")]
        [Then(@"Home page ""(.*)"" queue count is note down")]
        public void GivenHomePageQueueCountIsNoteDown(string p0)
        {
            tmsWait.Implicit(30);
            Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_EamNavigation_lnkHome")).Click();

            try
            {
                tmsWait.WaitForElement(By.XPath("//tr[contains(.,'transactions in the Send to CMS queue')]//td//a"), 5);
                GlobalRef.Count = Int32.Parse(Browser.Wd.FindElement(By.XPath("//tr[contains(.,'transactions in the Send to CMS queue')]//td//a")).Text);
            }
            catch (Exception e)
            {
                GlobalRef.Count = 0;
            }
            Console.WriteLine("Count of Sent to CMS transactions => " + GlobalRef.Count);


        }
        [Then(@"TC (.*)  Plan ID is set to ""(.*)""")]
        public void ThenTCPlanIDIsSetTo(int p0, string p1)
        {
            IWebElement planid = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_ddlPlans"));
            SelectElement id = new SelectElement(planid);
            id.SelectByText(p1);
        }
        [Then(@"TC (.*) New Plan ID is set to ""(.*)""")]
        public void ThenTCNewPlanIDIsSetTo(int p0, string p1)
        {
            IWebElement planid = Browser.Wd.FindElement(By.Id("ddlPlanId"));
            SelectElement id = new SelectElement(planid);
            id.SelectByText(p1);
        }


        [Then(@"TC 90 Drug Edit Transaction Page HIC is set to ""(.*)""")]
        [When(@"TC 90 Drug Edit Transaction Page HIC is set to ""(.*)""")]
        [Given(@"TC 90 Drug Edit Transaction Page HIC is set to ""(.*)""")]
        public void ThenTCDrugEditTransactionPageHICIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            // Click on MBI Lookup
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                tmsWait.Hard(3);
                ReUsableFunctions.clickOnWebElement(cfEAMTC90.TC90DrugEditTC.mbiLookup);
                tmsWait.Hard(3);
                ReUsableFunctions.enterValueOnWebElement(cfEAMTC90.TC90DrugEditTC.MBITextBox, value);
                ReUsableFunctions.clickOnWebElement(cfEAMTC90.TC90DrugEditTC.SearchButton);

                By mbiSelect = By.XPath("//table//td[contains(.,'" + value + "')]/preceding-sibling::td/input");
                fw.ExecuteJavascript(Browser.Wd.FindElement(mbiSelect));
                tmsWait.Hard(2);
                ReUsableFunctions.clickOnWebElement(cfEAMTC90.TC90DrugEditTC.AddButton);

            }
            else
            {
                tmsWait.Hard(3);
                ReUsableFunctions.clickOnWebElement(cfEAMTC90.TC90DrugEditTC.mbiLookup);
                tmsWait.Hard(3);
                ReUsableFunctions.enterValueOnWebElement(cfEAMTC90.TC90DrugEditTC.MBITextBox, value);
                ReUsableFunctions.clickOnWebElement(cfEAMTC90.TC90DrugEditTC.SearchButton);

                By mbiSelect = By.XPath("//table//td[contains(.,'" + value + "')]/preceding-sibling::td/input");
                fw.ExecuteJavascript(Browser.Wd.FindElement(mbiSelect));
                tmsWait.Hard(2);
                ReUsableFunctions.clickOnWebElement(cfEAMTC90.TC90DrugEditTC.AddButton);
            }
        }

        [Then(@"TC 90 Transaction Page HIC is set to ""(.*)""")]
        [Given(@"TC 90 Transaction Page HIC is set to ""(.*)""")]
        [When(@"TC 90 Transaction Page HIC is set to ""(.*)""")]
        public void ThenTCTransactionPageHICIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            IWebElement ele = Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_tbxHic"));
            ReUsableFunctions.clickOnWebElement(ele);
            tmsWait.Hard(1);
            ele.Clear();
            tmsWait.Hard(1);
            ele.SendKeys(value);
        }
     
        [Then(@"TC (.*) Transaction New Page HIC is set to ""(.*)""")]
        public void ThenTCTransactionNewPageHICIsSetTo(int p0, string p1)
        {
            string value = tmsCommon.GenerateData(p1);
            IWebElement ele = Browser.Wd.FindElement(By.Id("//span[contains(text(),'Add MBI')]"));
            ReUsableFunctions.clickOnWebElement(ele);
            tmsWait.Hard(1);
            ele.Clear();
            tmsWait.Hard(1);
            ele.SendKeys(value);
        }



        [Given(@"Export Page Exclude Retro check box is checked")]
        public void GivenExportPageExcludeRetroCheckBoxIsChecked()
        {
            tmsWait.Hard(2);
            IWebElement ExcludeRetroCheckbox = Browser.Wd.FindElement(By.Id("chkIdExcludeRetros"));
            fw.ExecuteJavascript(ExcludeRetroCheckbox);
            tmsWait.Hard(2);
        }

        [Given(@"Export Page Exclude Futures check box is checked")]
        public void GivenExportPageExcludeFuturesCheckBoxIsChecked()
        {
            tmsWait.Hard(2);
            IWebElement ExcludeFuturesCheckbox = Browser.Wd.FindElement(By.Id("chkIdExcludeFutures"));
            fw.ExecuteJavascript(ExcludeFuturesCheckbox);
            tmsWait.Hard(2);
        }


        [Then(@"TC 90 Drug Edit Transaction Page PlanID is set to ""(.*)""")]
        [When(@"TC 90 Drug Edit Transaction Page PlanID is set to ""(.*)""")]
        [Given(@"TC 90 Drug Edit Transaction Page PlanID is set to ""(.*)""")]
        public void ThenTCDrugEditTransactionPagePlanIDIsSetTo(string p1)
        {
            string value = tmsCommon.GenerateData(p1);

            tmsWait.Hard(2);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {


                By Drp = By.XPath("//label[text()='Plan Id']/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + value + "']");


                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);

            }
            else
            {


                ReUsableFunctions.clickOnWebElement(cfEAMTC90.TC90DrugEditTC.planIDDrpOwns);
                tmsWait.Hard(2);
                By valuePlan = By.XPath("//ul[@id='ddlPlanId_listbox']/li[contains(.,'" + value + "')]");

                ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(valuePlan));

                tmsWait.Hard(3);
            }
            

        }

        [Then(@"verify TC 90 Drug Edit Transaction Page ""(.*)"" field is disabled and is set to ""(.*)""")]
        [When (@"verify TC 90 Drug Edit Transaction Page ""(.*)"" field is disabled and is set to ""(.*)""")]
        public void ThenVerifyTCDrugEditTransactionPageFieldIsDisabledAndIsSetTo(string p0, string datavalue)
        {
            tmsWait.Hard(1);
            string actualValue = null;
           // string expValue = p0.ToUpper();
            switch (p0)
            {
                case "Transaction Code":
                    actualValue = EAM.TC90.TC90TCDropdown.GetAttribute("value");
                    Assert.IsFalse(EAM.TC90.TC90TCDropdown.Enabled, p0  + " is Disabled");
                    break;
                case "First Name":
                    actualValue = EAM.TC90.TC90FirstName.GetAttribute("value");
                    Assert.IsFalse(EAM.TC90.TC90FirstName.Enabled, p0 + " is Disabled");
                    break;
                case "MI":
                   
                    actualValue = EAM.TC90.TC90MI.GetAttribute("value");
                    Assert.IsFalse(EAM.TC90.TC90MI.Enabled, p0 + " is Disabled");
                    break;
                case "Surname":
                    actualValue = EAM.TC90.TC90Surname.GetAttribute("value");
                    Assert.IsFalse(EAM.TC90.TC90Surname.Enabled, p0 + " is Disabled");
                    break;
                case "Gender":
                    
                    actualValue = EAM.TC90.TC90Gender.GetAttribute("value");
                    Assert.IsFalse(EAM.TC90.TC90Gender.Enabled, p0 + " is Disabled");
                    break;
                case "DOB":
                    actualValue = EAM.TC90.TC90DOB.GetAttribute("value").ToString();
                    Assert.IsFalse(EAM.TC90.TC90DOB.Enabled, p0 + " is Enabled");
                    break;

            }
                    
            string expectedValue = tmsCommon.GenerateData(datavalue).ToUpper();
            string fieldName = "TC 90 Edit Transaction Page - " + p0;
            Assert.AreEqual(true, actualValue.Equals(expectedValue), "Field " + fieldName + " value is [" + expectedValue + "], expected [" + actualValue + "]");
            fw.ConsoleReport("Verification Point: Field " + fieldName + " value is [" + expectedValue + "], expected [" + actualValue + "] - They are expected to match.");
        }

        [Then(@"TC 90 Drug Edit Transaction Page Update Delete flag is set to ""(.*)""")]
        [When(@"TC 90 Drug Edit Transaction Page Update Delete flag is set to ""(.*)""")]
        public void ThenTCDrugEditTransactionPageUpdateDeleteFlagIsSetTo(string p1)
        {
            string value = tmsCommon.GenerateData(p1);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Add/Update/Delete flag')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + value + "']");


                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);



            }
            else
            {


                ReUsableFunctions.clickOnWebElement(cfEAMTC90.TC90DrugEditTC.addUpdateDeleteFlagOwns);
                tmsWait.Hard(2);
                By val = By.XPath("//ul[@id='formInputBoxAUD_listbox']/li[contains(.,'" + value + "')]");

                ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(val));
            }
           
        }

        [Then(@"TC (.*) Drug Edit Transaction Page Notification Start Date is set to ""(.*)""")]
        public void ThenTCDrugEditTransactionPageNotificationStartDateIsSetTo(int p0, string p1)
        {
            string value = tmsCommon.GenerateData(p1);
            tmsWait.Hard(2);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                //value = value.Replace("/", ""); //not needed anymore, AngularFunction handles this
                By Drp = By.XPath("//kendo-datepicker[@test-id='tc90-txt-notificationStartDate']//span[@role='button']");
                AngularFunction.enterDate(Drp, value);

                tmsWait.Hard(3);
                tmsWait.Hard(3);


            }
            else
            {
                ReUsableFunctions.enterValueOnWebElement(cfEAMTC90.TC90DrugEditTC.NotificationStartDate, value);
            }
        }

        [Then(@"TC (.*) Drug Edit Transaction Page Notification End Date is set to ""(.*)""")]
        public void ThenTCDrugEditTransactionPageNotificationEndDateIsSetTo(int p0, string p1)
        {
            string value = tmsCommon.GenerateData(p1);
            tmsWait.Hard(2);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                //value = value.Replace("/", ""); //not needed anymore, AngularFunction handles this
                By Drp = By.XPath("//kendo-datepicker[@test-id='tc90-txt-notificationEndDate']//span[@role='button']");
                AngularFunction.enterDate(Drp, value);

                tmsWait.Hard(3);

                tmsWait.Hard(3);


            }
            else
            {

                ReUsableFunctions.enterValueOnWebElement(cfEAMTC90.TC90DrugEditTC.NotificationEndDate, value);
            }
        }


        [Then(@"TC 90 Drug Edit Transaction Page POS Drug Edit Status is set to ""(.*)""")]
        [When(@"TC 90 Drug Edit Transaction Page POS Drug Edit Status is set to ""(.*)""")]
        public void ThenTCDrugEditTransactionPagePOSDrugEditStatusIsSetTo(string p1)
        {
            string value = tmsCommon.GenerateData(p1);

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'POS Edit Status')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + value + "']");


                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);



            }
            else
            {

                ReUsableFunctions.clickOnWebElement(cfEAMTC90.TC90DrugEditTC.posEditStatus);
                tmsWait.Hard(2);
                By val = By.XPath("//ul[@id='formInputBoxDos_listbox']/li[contains(.,'" + value + "')]");

                ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(val));
                tmsWait.Hard(3);
            }
        }

        [Then(@"TC 90 Drug Edit Transaction Page Change Notification Date is set to ""(.*)""")]
        [When(@"TC 90 Drug Edit Transaction Page Change Notification Date is set to ""(.*)""")]
        [Given(@"TC 90 Drug Edit Transaction Page Change Notification Date is set to ""(.*)""")]

        public void ThenTCDrugEditTransactionPageChangeNotificationDateIsSetTo(string p1)
        {
            string value = tmsCommon.GenerateData(p1);
            tmsWait.Hard(2);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                
                tmsWait.Hard(3);

                By Drp = By.XPath("//kendo-datepicker[@test-id='tc90-txt-notificationStartDate']//span[@role='button']");
                AngularFunction.enterDate(Drp, value);

                tmsWait.Hard(3);


            }
            else
            {
                ReUsableFunctions.enterValueOnWebElement(cfEAMTC90.TC90DrugEditTC.NotificationStartDate, value);
            }
        }


       // [Then(@"TC 90 Drug Edit Transaction Page Notification Date is set to ""(.*)""")]
       // public void ThenTCDrugEditTransactionPageNotificationDateIsSetTo(string p0)
       // {
       //
          //  string GeneratedData = tmsCommon.GenerateData(p0);
          //  GeneratedData = GeneratedData.Replace("/", "");
          //  EAM.TC90.TC90NotificationDate.Clear();
           // tmsWait.Hard(2);
           // EAM.TC90.TC90NotificationDate.Click();
            //tmsWait.Hard(2);
           // EAM.TC90.TC90NotificationDate.SendKeys(Keys.Home);
           // tmsWait.Hard(2);
           // EAM.TC90.TC90NotificationDate.SendKeys(GeneratedData);
           // tmsWait.Hard(3);
           //
       // }

        [Then(@"TC 90 Drug Edit Transaction Page Termination Date is set to ""(.*)""")]
        [When(@"TC 90 Drug Edit Transaction Page Termination Date is set to ""(.*)""")]
        public void ThenTCDrugEditTransactionPageTerminationDateIsSetTo(string p1)
        {

            string GeneratedData = tmsCommon.GenerateData(p1);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                string value = GeneratedData.Replace("/", "");
                By Drp = By.XPath("//label[contains(.,'Residence Address 1')]/parent::div//input");
                Browser.Wd.FindElement(Drp).Clear();
                Browser.Wd.FindElement(Drp).SendKeys(value);

                tmsWait.Hard(3);


            }
            else
            {
                GeneratedData = GeneratedData.Replace("/", "");
                EAM.TC90.TC90TerminationDate.Clear();
                // tmsWait.Hard(2);
                // EAM.TC90.TC90NotificationDate.Click();
                //tmsWait.Hard(2);
                EAM.TC90.TC90TerminationDate.SendKeys(Keys.Home);
                // tmsWait.Hard(2);
                EAM.TC90.TC90TerminationDate.SendKeys(GeneratedData);
                // tmsWait.Hard(3);
            }

        }

        [When(@"TC 90 Drug Edit Transaction Page Implementation Start Date is set to ""(.*)""")]
        [Then(@"TC 90 Drug Edit Transaction Page Implementation Start Date is set to ""(.*)""")]
        public void ThenTCDrugEditTransactionPageImplementationDateIsSetTo(string p1)
        {
            string value = tmsCommon.GenerateData(p1);
            tmsWait.Hard(2);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                //value = value.Replace("/", ""); //No longer needed, AngularFunction handles this

                By Drp = By.XPath("//kendo-datepicker[@test-id='tc90-txt-implementationStartDate']//span[@role='button']");
                AngularFunction.enterDate(Drp, value);               

                tmsWait.Hard(3);
            }
            else
            {
                ReUsableFunctions.enterValueOnWebElement(cfEAMTC90.TC90DrugEditTC.ImplementationStartDate, value);
            }
        }
        [When(@"TC (.*) Drug Edit Transaction Page Implementation End Date is set to ""(.*)""")]
        public void WhenTCDrugEditTransactionPageImplementationEndDateIsSetTo(int p0, string p1)
        {
           string value = tmsCommon.GenerateData(p1);
            tmsWait.Hard(2);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                
               
                By Drp = By.XPath("//kendo-datepicker[@test-id='tc90-txt-implementationEndDate']//span[@role='button']");
                AngularFunction.enterDate(Drp, value);

                tmsWait.Hard(3);


            }
            else
            {
                ReUsableFunctions.enterValueOnWebElement(cfEAMTC90.TC90DrugEditTC.ImplementationEndDate, value);
            }
        }


        [When(@"TC (.*) Drug Edit Transaction Page Notification Start Date is set to ""(.*)""")]
        public void WhenTCDrugEditTransactionPageNotificationStartDateIsSetTo(int p0, string p1)
        {
                      string value = tmsCommon.GenerateData(p1);
            tmsWait.Hard(2);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
               
                By Drp = By.XPath("//kendo-datepicker[@test-id='tc90-txt-notificationStartDate']//span[@role='button']");
                AngularFunction.enterDate(Drp, value);

                tmsWait.Hard(3);


            }
            else
            {

                ReUsableFunctions.enterValueOnWebElement(cfEAMTC90.TC90DrugEditTC.NotificationStartDate, value);
            }
        }
        [When(@"TC (.*) Drug Edit Transaction Page Save button is clicked")]
        public void WhenTCDrugEditTransactionPageSaveButtonIsClicked(int p0)
        {
            tmsWait.Hard(2);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By loc = By.CssSelector("[test-id='tc90btn-save']");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            }
            else
            {
                ReUsableFunctions.clickOnWebElement(cfEAMTC90.TC90DrugEditTC.Savebutton);
            }
        }


        [When(@"TC (.*) Drug Edit Transaction Page Notification End Date is set to ""(.*)""")]
        public void WhenTCDrugEditTransactionPageNotificationEndDateIsSetTo(int p0, string p1)
        {
            string value = tmsCommon.GenerateData(p1);
            tmsWait.Hard(2);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//kendo-datepicker[@test-id='tc90-txt-notificationEndDate']//span[@role='button']");
                AngularFunction.enterDate(Drp, value);

                tmsWait.Hard(3);


            }
            else
            {
                ReUsableFunctions.enterValueOnWebElement(cfEAMTC90.TC90DrugEditTC.NotificationEndDate, value);
            }
        }
        



        [Then(@"TC 90 Drug Edit Transaction Page POS Drug Edit class is set to ""(.*)""")]
        [When(@"TC 90 Drug Edit Transaction Page POS Drug Edit class is set to ""(.*)""")]
        public void ThenTCDrugEditTransactionPagePOSDrugEditClassIsSetTo(string p1)
        {
            
            string value = tmsCommon.GenerateData(p1);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Drug Class')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + value + "']");


                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);



            }
            else
            {
                ReUsableFunctions.clickOnWebElement(cfEAMTC90.TC90DrugEditTC.drugClass);
                tmsWait.Hard(2);
                By val = By.XPath("//ul[@id='formInputBoxDrugClass_listbox']/li[contains(.,'" + value + "')]");

                ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(val));
                tmsWait.Hard(3);
            }
        }

        [Then(@"TC 90 Drug Edit Transaction Page POS Drug Edit code is set to ""(.*)""")]
        [When(@"TC 90 Drug Edit Transaction Page POS Drug Edit code is set to ""(.*)""")]
        public void ThenTCDrugEditTransactionPagePOSDrugEditCodeIsSetTo(string p1)
        {
            string value = tmsCommon.GenerateData(p1);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'POS Edit Code')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + value + "']");


                UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                tmsWait.Hard(3);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);



            }
            else
            {
                tmsWait.Hard(2);
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@aria-owns='formInputBoxposeditcode_listbox']")));

                tmsWait.Hard(2);
                fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//li[contains(.,'" + value + "')]")));

                tmsWait.Hard(1);

            }
        }

        [When(@"TC 90 Drug Edit Transaction Page Reset button is clicked")]
        public void WhenTCDrugEditTransactionPageResetButtonIsClicked()
        {
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By loc = By.CssSelector("[test-id='tc90btn-reset']");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            }
            else { 
                fw.ExecuteJavascript(EAM.TC90.TC90ResetButton);
                tmsWait.Hard(3);
                EAM.TC90.TC90ResetButton.SendKeys(Keys.Enter);
            }
          }


        [Then(@"TC 90 Drug Edit Transaction Page Save button is clicked")]
        public void ThenTCDrugEditTransactionPageSaveButtonIsClicked()
        {
            tmsWait.Hard(2);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By loc = By.CssSelector("[test-id='tc90btn-save']");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            }
            else
            {
                fw.ExecuteJavascript(EAM.TC90.TC90SaveButton);
            }
        }

        [Then(@"Verify TC 90 Drug Edit Transaction Page Response message is set to ""(.*)""")]
        public void ThenVerifyTCDrugEditTransactionPageResponseMessageIsSetTo(string expMsg)
        {
            ReUsableFunctions.toasterMessageDisplay(expMsg);
            //tmsWait.Hard(5);
            //string fieldName = "TC 90 Response Message";
            //string expected = tmsCommon.GenerateData(p1);
            //string staticmessage = EAM.TC90.TC90StaticMessage.Text;
            //Console.WriteLine("message "+staticmessage);
            ////string expected = staticmessage.Trim();
            //string actual = staticmessage.Trim().Replace("\r\n", ",");
            //Console.WriteLine("Message is "+actual);
            //Assert.AreEqual(true, actual.Equals(expected), "Field " + fieldName + " value is [" + expected + "], expected [" + actual + "]");
            //fw.ConsoleReport("   Verification Point: Field " + fieldName + " value is [" + expected + "], expected [" + actual + "] - They are expected to match.");
         }

       

        //Gurdeep Arora
        [Then(@"Verify TC90 History Table has row")]
        public void ThenVerifyTC90HistoryTableHasRow(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.AdministrationStatusoverride.TransactionSearchTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("TC90 History Table has row: {0}", e.Message);
            }
        }

        
        [Then(@"Verify Home page ""(.*)"" queue count increase successfully\.""")]
        public void ThenVerifyHomePageQueueCountIncreaseSuccessfully_(string p0)
        {
            int expectedCount = Convert.ToInt32(GlobalRef.Count.ToString());
         
            IWebElement ele= Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_EamNavigation_lnkHome"));

            fw.ExecuteJavascript(ele);
           // Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_EamNavigation_lnkHome")).Click();
            int actualCount = Convert.ToInt32(Browser.Wd.FindElement(By.XPath("//tr[contains(.,'transactions in the Send to CMS queue')]//td//a")).Text);
            Assert.AreEqual(actualCount, expectedCount);
        }

        [When(@"Verify Activity table ""(.*)"" checkbox is set to ""(.*)"" for row")]
        public void WhenVerifyActivityTableCheckboxIsSetToForRow(string p0, string p1)
        {
            tmsWait.Hard(5);
            string xpath = "//td[contains(.,'"+p0.ToString()+"')]/following-sibling::td/span/span";
            if (p1.ToString().Contains("checked"))
            {
                Browser.Wd.FindElement(By.XPath(xpath)).Click();
            }

        }

        [When(@"Auditing Configuration page ""(.*)"" button is click")]
        public void WhenAuditingConfigurationPageButtonIsClick(string p0)
        {
            string xpath = "//button[@test-id='auditConfig-btn-save']";
            IWebElement thisSave = Browser.Wd.FindElement(By.XPath(xpath));
            //thisSave.Click();
            fw.ExecuteJavascript(thisSave);
        }


        [Then(@"MemberViewEditSpansTab has rows")]
        public void ThenMemberViewEditSpansTabHasRows(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.MemberInformation.SpansTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Members View Edit span Table has row: {0}", e.Message);
            }

        }


        [Then(@"Verify TC 90 Drug Edit Transaction page History table has Transaction row")]
        public void ThenVerifyTCDrugEditTransactionPageHistoryTableHasTransactionRow(Table table)
        {

            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.MemberInformation.Transaction90HistoryTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");
                //               Boolean bTransStatusMatching = false;
                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {

                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //if(AppTableRow.Equals(GherkinTableArray[iElementCounter])
                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (appTD.Equals("Canceled"))
                                //{

                                //    Assert.IsTrue(appTD.Equals("Canceled"));
                                //    bTransStatusMatching = true;
                                //    //Console.WriteLine("TC 61 status is found as Canceled");
                                //}

                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //    //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }


                        }

                    }
                    iTableCounter++;
                    //if (bTransStatusMatching)
                    //{
                    //    Console.WriteLine("Transaction status is updated to Canceled in Transaction History");
                    //}
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                //if (bTransStatusMatching)
                //{
                //    Console.WriteLine("Member Info page Transaction status is updated to Canceled in Transaction History table");
                //}

                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                else
                {
                    //Click next page link and start over.
                    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                    {
                        thisTP.bNotAtLastPageOfRecords = true;
                        thisTP.NPL.Click();
                        tmsWait.Hard(2);
                    }
                }
                //baseTable = EAM.MemberInformation.TransactionHistoryTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }

        }


        [Then(@"Verify Member Info Page Transaction History table has (.*) Transaction row")]
        public void ThenVerifyMemberInfoPageTransactionHistoryTableHasTransactionRow(int p0, Table table)
        {

            try
            {
                IWebElement objWebTable = EAM.MemberInformation.TransactionHistoryTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index < 0)
                        {
                            Assert.Fail("Expected row[{0}] was not found: {1} ", i++, arrRes[i, i]);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Members View Edit Table has row: {0}", e.Message);
            }

        }

        [Then(@"TC (.*) Drug Edit Transaction Page Change Notification Date is set to a new date")]
        public void ThenTCDrugEditTransactionPageChangeNotificationDateIsSetToANewDate(int p0)
        {
            try
            {
                tmsWait.Hard(2);
                IWebElement objWebTable = EAM.MemberInformation.Transaction90HistoryTable;
                IList<IWebElement> objUITableRowsList = objWebTable.FindElements(By.TagName("tr"));
                int intRowsCount = objUITableRowsList.Count;
                Console.WriteLine("TC90 History Table Rows Count " + intRowsCount);
                var dates = new List<string>();
                string GeneratedData = null;

                if (intRowsCount >= 3)
                {
                    for (int i = 2; i < intRowsCount; i++)
                    {
                        string cellValue = Browser.Wd.FindElement(By.XPath("//*[@id='ctl00_ctl00_MainMasterContent_MainContent_grdTransactionHistory']/tbody/tr[" + i + "]/td[6]")).Text;
                        dates.Add(cellValue);
                    }
                    dates.Sort();
                    string latestDate = dates[dates.Count - 1];
                    tmsWait.Hard(5);
                    DateTime newDate = Convert.ToDateTime(latestDate);
                    newDate = newDate.AddDays(1);
                    GeneratedData = tmsCommon.GenerateData(newDate.ToString("MM/dd/yyyy"));
                }
                else if (intRowsCount < 3)
                {
                    GeneratedData = tmsCommon.GenerateData("01/01/2017");
                }
                Console.WriteLine("New Notification Date " + GeneratedData);
                GeneratedData = GeneratedData.Replace("/", "");
                EAM.TC90.TC90NotificationDate.Clear();
                fw.ExecuteJavascript(EAM.TC90.TC90NotificationDate);
                tmsWait.Hard(2);
                EAM.TC90.TC90NotificationDate.SendKeys(Keys.Home);
                tmsWait.Hard(1);
                EAM.TC90.TC90NotificationDate.SendKeys(GeneratedData);
            }
            catch (Exception e) {
                Assert.Fail(e.Message);
            }

        }
     

        [Then(@"Verify Letter PDF is opened in window on clicking preview button")]
        public void ThenVerifyLetterPDFIsOpenedInWindowOnClickingPreviewButton()
        {
            string cwhandle = Browser.Wd.CurrentWindowHandle;
            fw.ExecuteJavascript(EAM.Letters.PreviewButton);
            tmsWait.Hard(5);
            IReadOnlyCollection<String> whandles = Browser.Wd.WindowHandles;
            int windowcount = whandles.Count;
            Boolean rightcount = false;
            string popupHandle = string.Empty;
            foreach (string handle in whandles)
            {
                if (handle != cwhandle)
                {
                    popupHandle = handle; break;
                }
            }
            
            if (windowcount!=1)
            {
                rightcount = true;
            }

            Browser.Wd.SwitchTo().Window(popupHandle);
            Browser.Wd.Close();
            Browser.Wd.SwitchTo().Window(cwhandle);
            Assert.IsTrue(rightcount);
        }

        [When(@"EAM Letter page Generate button is clicked")]
        public void WhenEAMLetterPageGenerateButtonIsClicked()
        {
            fw.ExecuteJavascript(EAM.Letters.GenerateLetterButton);
            tmsWait.Hard(20);
        }

    }
}
