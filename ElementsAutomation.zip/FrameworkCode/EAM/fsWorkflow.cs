﻿using System;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System.Collections.ObjectModel;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace TMSoR1
{
    [Binding]
    class fsWorkflow
    {
        public string transId = null;
        public string HicBefore = null;
        public string setCheckboxTo;




        //*******WorkFlow Configurations********

        [When(@"Workflow configurations Name is set to ""(.*)""")]
        public void WhenWorkflowConfigurationsNameIsSetTo(string p0)
        {
            EAM.WorkFlowConfiguration.WFConfigurationName.SendKeys(p0);
        }

        [Given(@"I have navigated WorkFlowEngine setup")]
        public void GivenIHaveNavigatedWorkFlowEngineSetup()
        {
            IWebElement engine = Browser.Wd.FindElement(By.XPath("//a[@title='Workflow Engine']/span"));
            fw.ExecuteJavascript(engine);
        }

        [When(@"Workflow configurations ApplicationUrl is set to ""(.*)""")]
        public void WhenWorkflowConfigurationsApplicationUrlIsSetTo(string p0)
        {
            EAM.WorkFlowConfiguration.WFConfigurationAppUrl.SendKeys(p0);
        }

        [When(@"Workflow configurations ServiceUrl is set to ""(.*)""")]
        public void WhenWorkflowConfigurationsServiceUrlIsSetTo(string p0)
        {
            EAM.WorkFlowConfiguration.WFConfigurationServiceUrl.Clear();
            EAM.WorkFlowConfiguration.WFConfigurationServiceUrl.SendKeys(p0);
        }

        [Then(@"Verify WorkFlow Configurations Page is displayed")]
        public void ThenVerifyWorkFlowConfigurationsPageIsDisplayed()
        {
            //String actualTitle = Browser.Wd.getTitle();
            //String expectedTitle = "Workflow Configurations";
            //Assert.AreEqual(actualTitle, expectedTitle);
        }

        [When(@"Workflow configuration Save button is clicked")]
        public void WhenWorkflowConfigurationSaveButtonIsClicked()
        {
            EAM.WorkFlowConfiguration.WFConfigurationSaveBtn.Click();
            tmsWait.Hard(3);
            IAlert alert = Browser.Wd.SwitchTo().Alert();
            alert.Accept();
            tmsWait.Hard(2);
        }
        [When(@"Workflow configuration Reset button is clicked")]
        public void WhenWorkflowConfigurationResetButtonIsClicked()
        {
            EAM.WorkFlowConfiguration.WFConfigurationResetBtn.Click();
            tmsWait.Hard(3);
            //IAlert alert = Browser.Wd.SwitchTo().Alert();
            //alert.Accept();
            tmsWait.Hard(2);
        }

        [When(@"Workflow configuration Update button is clicked")]
        public void WhenWorkflowConfigurationUpdateButtonIsClicked()
        {
            EAM.WorkFlowConfiguration.WFConfigurationUpdateBtn.Click();
            tmsWait.Hard(3);
            //string text = Browser.Wd.SwitchTo().Alert().Text;
            //Assert.IsTrue(text.Contains("Configuration updated Successfully"));
            IAlert alert = Browser.Wd.SwitchTo().Alert();
            alert.Accept();
            tmsWait.Hard(2);
        }

        [Then(@"Workflow configuration List has row")]
        public void ThenWorkflowConfigurationListHasRow(Table table)
        {



            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = true;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.WorkFlowConfiguration.WFConfigurationListTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                //            thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");

                int iTableCounter = 0;
                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {
                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {
                                        bThisRowMatches = false;
                                    }
                                    if (iElementCounter == 2)
                                    {
                                        expectedTableCheckboxValue = GherkinTableArray[2];
                                    }
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();
                            //If we get here and we still match, then the array elements were the same

                            if (bThisRowMatches)
                            {
                                //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                            }
                        }
                    }
                    iTableCounter++;
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                //else
                //{
                //    //Click next page link and start over.
                //    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                //    {
                //        thisTP.bNotAtLastPageOfRecords = true;
                //        thisTP.NPL.Click();
                //        tmsWait.Hard(2);
                //    }
                //}
                baseTable = EAM.WorkFlowConfiguration.WFConfigurationListTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportNotMatching(thisGT.GTable);
                }
            }


        }


        [When(@"Workflow configuration List Edit Icon is clicked for row")]
        public void WhenWorkflowConfigurationListIconIsClickedForRow(Table table)
        {
            //Browser.Wd.FindElement(By.XPath(String.Format("//td[contains(. ,'{1})]//preceding-sibling::td/div/input[contains(@id,'{0}Configuration')]",p0,p1))).Click();
            //if (p0 == "remove")
            //{
            //    IAlert alert = Browser.Wd.SwitchTo().Alert();
            //    alert.Accept();
            //}
            try
            {
                IWebElement objWebTable = EAM.WorkFlowConfiguration.WFConfigurationListTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index > 0)
                        {
                            index++;
                            //string xPath = "//tr[" + index + "]//img[@alt='Edit']";
                            string xPath1 = ".//*[@id='ConfigurationList_editConfiguration_" + (index - 2) + "']";
                            IWebElement editIcon = EAM.WorkFlowConfiguration.WFConfigurationListTable.FindElement(By.XPath(xPath1));
                            editIcon.Click();
                            try
                            {
                                editIcon.SendKeys(Keys.Enter);
                            }
                            catch (Exception) { }
                            tmsWait.Hard(3);
                            //                            tmsWait.WaitForReadyStateComplete(30);
                            // IWebElement objHIC = tmsWait.WaitForElementExist(By.XPath("//*[contains(@id ,'txtHic_01')]"), 60);
                            Console.WriteLine("Edit icon was clicked");
                        }
                        else { Assert.Fail("Edit Icon for expected row was not found"); }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Members Edit Icon is clicked for row: {0}", e.Message);
            }


        }

        [When(@"Workflow configuration List Delete Icon is clicked for row")]
        public void WhenWorkflowConfigurationListDeleteIconIsClickedForRow(Table table)
        {
            try
            {
                IWebElement objWebTable = EAM.WorkFlowConfiguration.WFConfigurationListTable;

                String[,] arrRes = TableHelper.FindRowsInWebTable(table, ref objWebTable);
                for (int i = 0; i <= arrRes.GetUpperBound(0); i++)
                {
                    int index = 0;
                    if (int.TryParse(arrRes[i, 0], out index))
                    {
                        if (index > 0)
                        {
                            index++;
                            //string xPath = "//tr[" + index + "]//img[@alt='Edit']";
                            string xPath2 = ".//*[@id='ConfigurationList_removeConfiguration_" + (index - 2) + "']";
                            IWebElement removeIcon = EAM.WorkFlowConfiguration.WFConfigurationListTable.FindElement(By.XPath(xPath2));
                            removeIcon.Click();
                            IAlert alert = Browser.Wd.SwitchTo().Alert();
                            alert.Accept();
                            tmsWait.Hard(3);
                            alert.Accept();
                            try
                            {
                                removeIcon.SendKeys(Keys.Enter);
                            }
                            catch (Exception) { }
                            tmsWait.Hard(3);
                            
                            Console.WriteLine("Delete icon was clicked");
                        }
                        else { Assert.Fail("Delete Icon for expected row was not found"); }
                    }
                }
            }
            catch (Exception e)
            {
                Assert.Fail("Members Delete Icon is clicked for row: {0}", e.Message);
            }
        }


        [Then(@"Verify Error popup message ""(.*)""")]
        public void ThenVerfifyErrorPopupMessage(string p0)
        {
            EAM.WorkFlowConfiguration.WFConfigurationSaveBtn.Click();
            tmsWait.Hard(2);
            //try
            //{

            IWebElement act = Browser.Wd.FindElement(By.XPath("//form[@id='WorkflowFrm']//span[contains(.,'"+p0+"')]"));
            Assert.IsTrue(act.Displayed, p0 + " is not getting displayed");


            //String expected = p0.ToString();
            //string errortext = Browser.Wd.SwitchTo().Alert().Text;
            //string actual = errortext.Replace("\r\n", string.Empty);
           
            //    tmsWait.Hard(2);

            //    Assert.AreEqual(expected, actual, " Both are matching");
            //    //Assert.IsTrue(errortext.Contains(expected));
               
            //    //IAlert alert = Browser.Wd.SwitchTo().Alert();
            //    Browser.Wd.SwitchTo().Alert().Accept();
            ////}
            ////catch (Exception e)
            ////{
            ////    throw e;
            //}

        }

        [Then(@"Verify Workflow configuration ServiceUrl ""(.*)"" is displayed")]
        public void ThenVerifyWorkflowConfigurationServiceUrlIsDisplayed(string p0)
        {
            string ab = EAM.WorkFlowConfiguration.WFConfigurationServiceUrl.GetAttribute("value");
            Assert.AreEqual(p0,ab);

        }

        [Then(@"Verify Workflow configuration List has no row")]
        public void ThenVerifyWorkflowConfigurationListHasNoRow(Table table)
        {


            //Create Storage for the Gherkin table and the page data
            GherkinTable thisGT = new GherkinTable();
            TablePaging thisTP = new TablePaging();

            //Load the Gherkin table into the storage
            thisGT.LoadGherkinTable(table);

            //The big loop.  Keep working until all the Gherkin table rows are marked as matched
            //Or until we are on the last page of records, then we also quit looking.
            while (thisGT.GTable[0].AllRowsMatched(thisGT.GTable) == false && thisTP.bNotAtLastPageOfRecords)
            {
                //Start out with the assumption we are not on the last page of records.  We will check later.
                thisTP.bNotAtLastPageOfRecords = false;

                //Get the table object again, since the page refreshes we need to get it fresh
                IWebElement baseTable = EAM.WorkFlowConfiguration.WFConfigurationListTable;

                //Look for a next page link.  We will set 'last page of records' here also.
                //           thisTP.LoadNextPageLink(baseTable);

                //Load the page data off the application.   
                //Sometimes these have a header with tag th, sometimes it is a td.  (2nd param)
                thisTP.LoadPageTable(baseTable, "td", "td");
                //               Boolean bTransStatusMatching = false;
                int iTableCounter = 0;
                //                string expectedTableCheckboxValue = "";
                //for each row in the Gherkin table, start flipping through all the rows in the page data.
                foreach (TMSTableRow GherkinTableRow in thisGT.GTable)
                {

                    //If we previously already matched the Gherkin table data, then we don't need to try anymore on that row.

                    //Check to see if we are done with the loaded rows.  The first not loaded row will be null.
                    if (GherkinTableRow == null)
                    {
                        break;
                    }

                    //If this Gherkin table row is not yet matched, proceed.
                    if (GherkinTableRow.RowIsMatched == false)
                    {
                        //Convert the row to an array so we can do an element by element match.
                        string[] GherkinTableArray = GherkinTableRow.Row.ToArray();

                        //For each row in the page data
                        foreach (TMSTableRow ApplicationRow in thisTP.PageTable)
                        {
                            //Convert page data to array elements
                            //Only work with the loaded element rows.  The first unloaded one will be null.
                            if (ApplicationRow == null)
                            {
                                break;
                            }

                            //Convert the page row to array so we can pair up by elements.
                            string[] AppTableRow = ApplicationRow.Row.ToArray();
                            int iElementCounter = 0;
                            Boolean bThisRowMatches = true;  //assumption the row matches.  When we find one element not matching later, fail the match.

                            //if(AppTableRow.Equals(GherkinTableArray[iElementCounter])
                            //In here as we pair up the data you will have custom matching.
                            //special handlers if the Gherkin table is "no" and the app is a checkbox, etc..
                            foreach (string appTD in AppTableRow)
                            {
                                //if (appTD.Equals("Canceled"))
                                //{

                                //    Assert.IsTrue(appTD.Equals("Canceled"));
                                //    bTransStatusMatching = true;
                                //    //Console.WriteLine("TC 61 status is found as Canceled");
                                //}

                                //if (iElementCounter > 0 && TDA.RowIsData)
                                if (ApplicationRow.RowIsData)
                                {
                                    //if our elements don't match, and the Gherkin table is not [Skip] then fail the row match.
                                    if (appTD != GherkinTableArray[iElementCounter] && GherkinTableArray[iElementCounter].ToLower() != "[skip]")
                                    {

                                        bThisRowMatches = false;
                                    }
                                    //if (iElementCounter == 5)
                                    //{
                                    //    expectedTableCheckboxValue = GherkinTableArray[5];
                                    //}
                                }
                                else
                                {
                                    //Also fail row match if the element count of the page data row is 0
                                    if (iElementCounter > 0)
                                    {
                                        bThisRowMatches = false;
                                    }
                                }
                                iElementCounter++;
                            }
                            if (AppTableRow.Length == 0)
                            {
                                //Another check that if the page data row is 0 long, we didn't match, fail the match.
                                bThisRowMatches = false;
                            }
                            //Instance of TableRow Class for reporting functions
                            var TableRow = new TMSString();

                            if (bThisRowMatches)
                            {
                                //    //report the success stuff.  Puts out the row data, etc.
                                thisTP.ReportMatching(thisTP.PageTable[iTableCounter], thisGT.GTable[iTableCounter], AppTableRow, GherkinTableArray);
                                Assert.AreEqual(true, false, "Did not expect to match any rows.   This row did match.   Fail");

                            }



                        }

                    }
                    iTableCounter++;
                    //if (bTransStatusMatching)
                    //{
                    //    Console.WriteLine("Transaction status is updated to Canceled in Transaction History");
                    //}
                }
                //If we matched all the rows, we are done..  Otherwise we need to flip the page ahead and look again.
                Boolean fullMatching = thisGT.GTable[0].AllRowsMatched(thisGT.GTable);
                //if (bTransStatusMatching)
                //{
                //    Console.WriteLine("Member Info page Transaction status is updated to Canceled in Transaction History table");
                //}

                if (fullMatching)
                {
                    Console.WriteLine("All rows are matched, step completed as passed");
                }
                //else
                //{


                //    //Click next page link and start over.
                //    if (thisTP.bHaveGoodPageLink)  //When we can't get it above, don't click it here.
                //    {
                //        thisTP.bNotAtLastPageOfRecords = true;
                //        thisTP.NPL.Click();
                //        tmsWait.Hard(2);
                //    }
                //}
                baseTable = EAM.WorkFlowConfiguration.WFConfigurationListTable;

                //We are at a point when we don't have a good page link to go to.   We didn't match all the rows.
                //Time to boil it down and report which rows didn't get matched.
                //Also to fail because we were planning to match the rows.
                if (thisTP.bHaveGoodPageLink == false && !fullMatching)
                {
                    thisTP.ReportPassOnNotMatching(thisGT.GTable);
                }
            }
        }

        [When(@"Enable Workflow Validation Check box is set to ""(.*)""")]
        public void WhenEnableWorkflowValidationCheckBoxIsSetTo(string p0)
        {
            string GenerateData = tmsCommon.GenerateData(p0);


            switch (GenerateData.ToLower())
            {
                case "checked": { setCheckboxTo = "checked"; break; }
                case "on": { setCheckboxTo = "checked"; break; }
                case "yes": { setCheckboxTo = "checked"; break; }
                case "unchecked": { setCheckboxTo = "unchecked"; break; }
                case "off": { setCheckboxTo = "unchecked"; break; }
                case "no": { setCheckboxTo = "unchecked"; break; }
                default: { Console.WriteLine(" Check box status should be Checked/on/Yes or Unchecked/off/no"); break; }
            }

            if (setCheckboxTo.Equals("UnChecked"))
            {

                if (EAM.AdministrationPage.WorkFlowEnable.Selected == true)
                {
                    EAM.AdministrationPage.WorkFlowEnable.Click();
                }

            }
            else if (setCheckboxTo.Equals("checked"))
            {
                if (EAM.AdministrationPage.WorkFlowEnable.Selected == false)
                {
                    EAM.AdministrationPage.WorkFlowEnable.Click();
                }
            }
        }
        [When(@"Workflow configuration Name is set to ""(.*)""")]
        public void WhenWorkflowConfigurationNameIsSetTo(string p0)
        {
            SelectElement WFconfigurantionname = new SelectElement(EAM.AdministrationPage.WorkFlowConfigurationName);
            WFconfigurantionname.SelectByText(p0);
        }


        [Then(@"Verify Administration ""(.*)"" link is available")]
        public void ThenVerifyAdministrationLinkIsAvailable(string p0)
        {
            try
            {
                if (EAM.AdministrationWorkflow.WorkflowLink.Enabled)
                {

                }
            }
            catch (NoSuchElementException exp)
            {
                throw exp;
            }
        }
        [Then(@"Verify Workflow ""(.*)"" link is available")]
        public void ThenVerifyWorkflowLinkIsAvailable(string p0)
        {
            try
            {
                if (EAM.AdministrationWorkflow.WorkflowLink.Enabled)
                {

                }
            }
            catch (NoSuchElementException exp)
            {
                throw exp;
            }
        }

        //*******WorkflowTaskbar Operations*******

        //[Then(@"Verify WFTaskbarOperations ErrorMessage ""(.*)""")]
        //public void ThenVerifyWFTaskbarOperationsErrorMessage(string p0)
        //{

        //    try
        //    {
        //        if (EAM.WFTaskbarOperations.WFTaskbarNoWorkItemKey.Displayed)
        //        {
        //            string Actualerrormsg = EAM.WFTaskbarOperations.WFTaskbarEmptyPageError.Text;
        //            Assert.AreEqual(p0, Actualerrormsg, "Error Message is displayed as expected");

        //        }
        //    }
        //    catch(NoSuchElementException)
        //    {
        //        fw.ConsoleReport("There is atleast a WorkItem key");
        //    }
               
        //}
        [Then(@"Verify WorkflowTaskbar has workitemkey")]
        public void ThenVerifyWorkflowTaskbarHasWorkitemkey()
        {
            tmsWait.Hard(5);
            try
            { 
               if (EAM.WFTaskbarOperations.WFTaskbarHasWorkItemKey.Displayed)
               {
                fw.ConsoleReport("Workitem is displayed on workflow transaction/member edit page");
                   char[] spliter = { ':' };
                   string[] BeforeWFOperation = EAM.WFTaskbarOperations.WFTaskbarHasWorkItemKey.Text.Split(spliter);
                    GlobalRef.ItemBeforeWFOperation = BeforeWFOperation[1].Trim();
                }
            }
            catch(NoSuchElementException)
            {
                fw.ConsoleReport("Workitem is not available on workflow transaction/member edit page");
            }
        }

        [When(@"WorkflowTaskbar Resolve and Get Next operation is performed")]
        public void WhenWorkflowTaskbarResolveAndGetNextOperationIsPerformed()
        {
            SelectElement WFOperation = new SelectElement(EAM.WFTaskbarOperations.WFActionDropDown);
            WFOperation.SelectByText("Resolve and Get Next");
            EAM.WFTaskbarOperations.WFTaskbarSubmitBtn.Click();
            Browser.ClosePopUps(true);
            tmsWait.Hard(5);
        }

        [Then(@"Verify WorkflowTaskbar Operation is performed successfully")]
        public void ThenVerifyWorkflowTaskbarOperationIsPerformedSuccessfully()
        {
            char[] spliter = { ':' };
            string[] AfterWFOperation = EAM.WFTaskbarOperations.WFTaskbarHasWorkItemKey.Text.Split(spliter);
            Assert.AreNotEqual((Convert.ToInt32(GlobalRef.ItemBeforeWFOperation.ToString())),(Convert.ToInt32(AfterWFOperation[1].ToString().Trim())));
        }

        [When(@"WorkflowTaskbar SetAside operation is performed for ""(.*)"" ""(.*)"" because ""(.*)""")]
        public void WhenWorkflowTaskbarSetAsideOperationIsPerformedForBecause(int p0, string p1, string p2)
        {
            SelectElement WFSetasideoperation = new SelectElement(EAM.WFTaskbarOperations.WFActionDropDown);
            WFSetasideoperation.SelectByText("Set Aside");
            SelectElement WFSetAsideReason = new SelectElement(EAM.WFTaskbarOperations.SetAsideReason);
            WFSetAsideReason.SelectByText(p2);
            SelectElement WFSetAsideReactiveTimeUnit = new SelectElement(EAM.WFTaskbarOperations.SetAsideReactiveAfterTimeUnit);
            WFSetAsideReactiveTimeUnit.SelectByText(p1);
            if (p1 != "Minutes")
            {
                EAM.WFTaskbarOperations.SetAsideReactiveAfterTxttime.SendKeys(p0.ToString());
            }

            EAM.WFTaskbarOperations.WFTaskbarSubmitBtn.Click();
            tmsWait.Hard(2);
            Browser.ClosePopUps(true);
            tmsWait.Hard(5);
        }

        [When(@"WorkflowTaskbar Workitem is ManuallyRoute in queue ""(.*)"" for role ""(.*)"" because ""(.*)""")]
        public void WhenWorkflowTaskbarWorkitemIsManuallyRouteInQueueForRoleBecause(string p0, string p1, string p2)
        {
            SelectElement WFManuallyRouteOperation = new SelectElement(EAM.WFTaskbarOperations.WFActionDropDown);
            WFManuallyRouteOperation.SelectByText("Manually Route");
            SelectElement WFManuallyRouteReason = new SelectElement(EAM.WFTaskbarOperations.ManuallyRouteReasons);
            WFManuallyRouteReason.SelectByText(p2);
            SelectElement WFManuallyRouteToQueue = new SelectElement(EAM.WFTaskbarOperations.ManuallyRouteQueues);
            WFManuallyRouteToQueue.SelectByText(p0);
            SelectElement WFManuallyRouteToQueueRole = new SelectElement(EAM.WFTaskbarOperations.ManuallyRouteRoles);
            EAM.WFTaskbarOperations.WFTaskbarSubmitBtn.Click();
            tmsWait.Hard(2);
            Browser.ClosePopUps(true);
            tmsWait.Hard(10);
        }
        [When(@"WorkflowTaskbar TakeABreak is performed becasue ""(.*)""")]
        public void WhenWorkflowTaskbarTakeABreakIsPerformedBecasue(string p0)
        {
            SelectElement WFTakeABreakOperation = new SelectElement(EAM.WFTaskbarOperations.WFActionDropDown);
            WFTakeABreakOperation.SelectByText("Take a break");
            SelectElement BreakReason = new SelectElement(EAM.WFTaskbarOperations.TakeABreakReasons);
            BreakReason.SelectByText(p0);
            EAM.WFTaskbarOperations.WFTaskbarSubmitBtn.Click();
            Browser.ClosePopUps(true);
            tmsWait.Hard(5);
            IWebElement Homebtnpath = Browser.Wd.FindElement(By.LinkText("Home"));
            Assert.IsTrue(Homebtnpath.Enabled);       

        }
        [Then(@"Verify After Take a break operation same workitem is displayed")]
        public void ThenVerifyAfterTakeABreakOperationSameWorkitemIsDisplayed()
        {
            char[] takeabreakspliter = { ':' };
            string[] AfterTakeabreakOperation = EAM.WFTaskbarOperations.WFTaskbarHasWorkItemKey.Text.Split(takeabreakspliter);
            Assert.AreEqual((Convert.ToInt32(GlobalRef.ItemBeforeWFOperation.ToString())), (Convert.ToInt32(AfterTakeabreakOperation[1].ToString().Trim())));
        }
        //[When(@"Check workitem availability for ""(.*)"" and HIC is set to ""(.*)""")]
        //public void WhenCheckWorkitemAvailabilityForAndHICIsSetTo(string p0, string p1)
        //{
        //    IWebElement basetable = EAM.WFDashboard.WFDashboardTable;
        //    ReadOnlyCollection<IWebElement> allRows = basetable.FindElements(By.TagName("tr"));


        //    foreach(IWebElement row in allRows)
        //    {
        //        if(row.Text.Contains(p0))
        //        {
        //            ReadOnlyCollection<IWebElement> cells = row.FindElements(By.TagName("td"));

        //            foreach(IWebElement cell in cells)
        //            {
        //                IWebElement countlink = cell.FindElement(By.TagName("a"));
        //                if(countlink.Text.Equals("0"))
        //                {
        //                    switch (p0)
        //                    {
        //                        case "Enrollment Rejection":
        //                            EAM.AdministrationStatusoverride.StatusOverrideLink.Click();
        //                            EAM.AdministrationStatusoverride.SearchForTransactionCheckbox.Click();
        //                            EAM.AdministrationStatusoverride.SearchForHIC.SendKeys(p1);
        //                            EAM.AdministrationStatusoverride.SearchButton.Click();
        //                            tmsWait.Hard(1);

        //                            //td[contains(.,'6073')]//following-sibling::td/a
        //                            break;
        //                        case "OOA":
        //                            break;
        //                        case "EAFOEC Trigger":
        //                            break;
        //                        case "Failed BEQ":
        //                            break;
        //                        case "BEQ Mismatch":
        //                            break;
        //                        case ""
        //                    }
        //                }
        //            }
        //        }
        //    }
        //}

        //[When(@"Workitemdetails SearchWorkitem is set to ""(.*)""")]
        //public void WhenWorkitemdetailsSearchWorkitemIsSetTo(string p0)
        //{
        //    EAM.WFDashboard.WFDashboardSearchWorkItem.SendKeys(p0);
        //}

        [When(@"Workitemdetails Search button is clicked")]
        public void WhenWorkitemdetailsSearchButtonIsClicked()
        {
            tmsWait.Hard(3);
            fw.ExecuteJavascript(EAM.WFDashboard.WFDashboardSearchBtn);
        }

        [When(@"Get the TransactionId from Transaction Status override")]
        public void WhenGetTheTransactionIdFromTransactionStatusOverride()
        {
            string GetTransid = EAM.AdministrationStatusoverride.GetFirstTransId.Text;
            string Workitemkey = "Transaction" + Convert.ToInt32(GetTransid);
            GlobalRef.TransactionWorkItem = Workitemkey.Trim();

        }
        [When(@"Workitemdetails Enter Workitem for search")]
        
        public void WhenWorkitemdetailsEnterWorkitemForSearch()
        {
            string WFitem = (GlobalRef.TransactionWorkItem.ToString());
            EAM.WFDashboard.WFDashboardSearchWorkItem.SendKeys(WFitem);
        }

        [Then(@"Verify Workitemdetails SearchedWorkitem is displayed")]
        public void ThenWorkitemdetailsSearchedWorkitemIsDisplayed()
        {
            IWebElement baseTable = EAM.WFDashboard.WorkItemTable;
            ReadOnlyCollection<IWebElement> allRows = baseTable.FindElements(By.TagName("tr"));
            bool isPresent = false;

            foreach (IWebElement row in allRows)
            {

                if (row.Text.Contains((GlobalRef.TransactionWorkItem.ToString())))
                {
                    isPresent = true;
                    break
                        ;
                }
            }
            Assert.IsTrue(isPresent);
        }

        [When(@"Workitemdetails SearchedWorkitem check box is checked")]

        public void ThenWorkitemdetailsWorkitemCheckBoxIsChecked()
        {
            //IWebElement baseTable = EAM.WFDashboard.WorkItemTable;
            //ReadOnlyCollection<IWebElement> allRows = baseTable.FindElements(By.TagName("tr"));

            //foreach (IWebElement row in allRows)
            //{

            //    if (row.Text.Contains(GlobalRef.TransactionWorkItem.ToString()))
            //    {
            //        IWebElement checkSel = row.FindElement(By.XPath("./td[1]"));
            //        fw.ExecuteJavascript(checkSel);
            //        //checkSel.Click();
            //        break;
            //    }

            //}
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.Id("ctl00_ctl00_MainMasterContent_MainContent_dgQueueDetails_ctl02_chkSelect")));
        }

        [When(@"ChangePriority Priority for SearchedWorkitem is set to ""(.*)""")]
        public void WhenChangePriorityPriorityForWorkitemIsSetTo(string p0)
        {
            IWebElement baseTable = EAM.WFDashboard.WorkItemTable;
            ReadOnlyCollection<IWebElement> allRows = baseTable.FindElements(By.TagName("tr"));

            foreach (IWebElement row in allRows)
            {
                if (row.Text.Contains(GlobalRef.TransactionWorkItem.ToString()))
                {
                    SelectElement select = new SelectElement(EAM.WFDashboard.NewPriorityDropDown);
                    select.SelectByText(p0);
                    break;
                }

            }
        }
        [Then(@"Verify workitemdetails Searchedworkitem Priority ""(.*)"" is displayed")]
        public void ThenVerifyWorkitemdetailsWorkitemPriorityIsDisplayed(string p0)
        {
            IWebElement baseTable = EAM.WFDashboard.WorkItemTable;
            ReadOnlyCollection<IWebElement> allRows = baseTable.FindElements(By.TagName("tr"));
            foreach (IWebElement row in allRows)
            {
                if (row.Text.Contains(GlobalRef.TransactionWorkItem.ToString()))
                {
                    IWebElement priority = row.FindElement(By.XPath("./td[3]"));
                    Assert.AreEqual(priority.Text, p0);
                    break;
                }
            }
        }
        [When(@"Workitemdetails Enter Workitem for search ""(.*)""")]
        public void WhenWorkitemdetailsEnterWorkitemForSearch(string p0)
        {
            EAM.WFDashboard.WFDashboardSearchWorkItem.SendKeys(p0);
        }

        [Then(@"Verify Workitemdetails ""(.*)"" is displayed")]
        public void ThenVerifyWorkitemdetailsIsDisplayed(string p0)
        {
            Assert.AreEqual(EAM.WFDashboard.WFDashboardSearchNotFoundMessage.Text, p0);  
        }

        [When(@"EAMWFDashboard queue count for ""(.*)"" is clicked")]
        public void WhenEAMWFDashboardQueueCountForIsClicked(string p0)
        {
            string q = tmsCommon.GenerateData(p0.ToString());
            IWebElement Queuetable = Browser.Wd.FindElement(By.XPath(".//*[@id='ctl00_ctl00_MainMasterContent_MainContent_dgQueueItem']/tbody"));
            IReadOnlyCollection<IWebElement> myqueues = Queuetable.FindElements(By.TagName("tr"));
            int i = 0;
            foreach(var row in myqueues)
            {
                if(i>0)
                {
                    string queuename = row.FindElement(By.XPath("td[2]")).Text;
                    if(queuename == q)
                    {
                        IWebElement countlink = row.FindElement(By.XPath("td[1]/a"));
                        fw.ExecuteJavascript(countlink);
                        break;
                    }
                }
                i++;
            }
        }

        [When(@"EAMWFDashboard set filter for ""(.*)"" priority")]
        public void WhenEAMWFDashboardSetFilterForPriority(string p0)
        {
            tmsWait.Hard(2);
            string strValue = tmsCommon.GenerateData(p0.ToString());
            SelectElement priority = new SelectElement(EAM.WFDashboard.PriorityDropdown);
            priority.SelectByText(strValue);
            tmsWait.Hard(1);
            fw.ExecuteJavascript(EAM.WFDashboard.ApplyButton);

        }

        [Then(@"Verify WFdashboard only ""(.*)"" prioirty items are displayed")]
        public void ThenVerifyWFdashboardOnlyPrioirtyItemsAreDisplayed(string p0)
        {
            string expectedpriority = tmsCommon.GenerateData(p0.ToString());
            IWebElement workitemstable = Browser.Wd.FindElement(By.XPath(".//*[@id='ctl00_ctl00_MainMasterContent_MainContent_dgQueueDetails']/tbody"));
            IReadOnlyCollection<IWebElement> queue = workitemstable.FindElements(By.TagName("tr"));
            Boolean priorityNotSet = true;
            foreach (var row in queue)
            {

                string isHeader = row.GetAttribute("class");
                if (isHeader != "Header")
                {

                    if (row.FindElement(By.XPath("td[1]")).Text == "No records found")
                    {
                        break;
                    }
                    else
                    {
                        string setpriority = row.FindElement(By.XPath("td[3]")).Text;
                        if (setpriority != expectedpriority)
                        {
                            priorityNotSet = false;
                            break;

                        }
                    }
                }
            }

            Assert.IsTrue(priorityNotSet);
        }

        [When(@"EAMWFDashboard select multiple workitems")]
        public void WhenEAMWFDashboardSelectMultipleWorkitems()
        {
            IWebElement workitemstable = Browser.Wd.FindElement(By.XPath(".//*[@id='ctl00_ctl00_MainMasterContent_MainContent_dgQueueDetails']/tbody"));
            IReadOnlyCollection<IWebElement> queue = workitemstable.FindElements(By.TagName("tr"));
            int i = 0;
            foreach (var row in queue)
            {

                
                string isHeader = row.GetAttribute("class");
                if (isHeader != "Header")
                {
                   fw.ExecuteJavascript(row.FindElement(By.XPath("td[1]//input")));
                   tmsWait.Hard(1);
                   if(i>1)    //Selecting first three workitems only
                    {
                        GlobalRef.Item = row.FindElement(By.XPath("td[2]")).Text;
                        break;
                    } 
                }
                //GlobalRef.Item = row.FindElement(By.XPath("td[2]")).Text;
                i++;
            }
        }

        [When(@"EAMWFDashboard Change Priority button is clicked")]
        public void WhenEAMWFDashboardChangePriorityButtonIsClicked()
        {
            fw.ExecuteJavascript(EAM.WFDashboard.PriorityBtn);
            tmsWait.Hard(1);
        }

        [Then(@"Verify ChangePriority window is displayed")]
        public void ThenVerifyChangePriorityWindowIsDisplayed()
        {
            Browser.Wd.SwitchTo().ActiveElement();
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath(".//*[@id='RadWindowWrapper_ctl00_ctl00_MainMasterContent_MainContent_modalPopupPriority']//following-sibling::td//em")).Displayed);
        }

        [When(@"Workflow Engine ""(.*)"" is set  to ""(.*)""")]
        public void WhenWorkflowEngineIsSetTo(string p0, string p1)
        {
          
        }


        [Then(@"Verify Selected workitems displayed on new window")]
        public void ThenVerifySelectedWorkitemsDisplayedOnNewWindow()
        {
            string selecteditem = GlobalRef.Item.ToString();
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath(".//span[contains(text(), '" + selecteditem + "')]")).Displayed);
        }

        [When(@"ChangePriority priority ""(.*)"" is selected")]
        public void WhenChangePriorityPriorityIsSelected(string p0)
        {
            string priority = tmsCommon.GenerateData(p0.ToString());
            SelectElement select = new SelectElement(EAM.WFDashboard.NewPriorityDropDown);
            select.SelectByText(priority);
            tmsWait.Hard(1);
        }

        [Then(@"Verify Priority for selected workitems is set to ""(.*)""")]
        public void ThenVerifyPriorityForSelectedWorkitemsIsSetTo(string p0)
        {
            fw.ExecuteJavascript("location.reload()");
            try
            {
                Browser.ClosePopUps(true);
                tmsWait.Hard(3);
            }
            catch
            { tmsWait.Hard(1); }
            string priority = tmsCommon.GenerateData(p0.ToString());
            string selecteditem = GlobalRef.Item.ToString();
            IWebElement workitemstable = Browser.Wd.FindElement(By.XPath(".//*[@id='ctl00_ctl00_MainMasterContent_MainContent_dgQueueDetails']/tbody"));
            IReadOnlyCollection<IWebElement> queue = workitemstable.FindElements(By.TagName("tr"));

            foreach (var row in queue)
            {
                
                string isHeader = row.GetAttribute("class");
                if (isHeader != "Header")
                {
                    if(row.FindElement(By.XPath("td[2]")).Text == selecteditem)
                    {
                        Assert.AreEqual(row.FindElement(By.XPath("td[3]")).Text, priority, "Priority is not changed");
                    }
                }
            }

        }
    }

}









