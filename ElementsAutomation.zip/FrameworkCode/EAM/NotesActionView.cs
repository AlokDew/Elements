﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using System.Collections.Generic;
using OpenQA.Selenium.Support.UI;
using System.IO;

namespace TMSoR1.FrameworkCode.EAM
{
    [Binding]
    class NotesActionView
    {

        [When(@"Notes Action View page Search button is clicked")]
        public void WhenNotesActionViewPageSearchButtonIsClicked()
        {
            tmsWait.Hard(2);
            Browser.SwitchWindow();
            Browser.Wd.FindElement(By.XPath("//input[@value='Search']")).Click();
        }


        [When(@"Notes Action View page First record is selected")]
        public void WhenNotesActionViewPageFirstRecordIsSelected()
        {
            tmsWait.Hard(2);
            Browser.Wd.FindElement(By.XPath("//img[@alt='Edit']")).Click();
        }


        [When(@"Notes Action View page Add New button is clicked")]
        public void WhenNotesActionViewPageAddNewButtonIsClicked()
        {
            tmsWait.Hard(2);
            Browser.Wd.FindElement(By.XPath("//img[@alt='Add Note']")).Click();
        }

        [When(@"Enter the new note into EAM New Notes page note area ""(.*)""")]
        public void WhenEnterTheNewNoteIntoEAMNewNotesPageNoteArea(string p0)
        {
            string GeneratedData = tmsCommon.GenerateData(p0);
            tmsWait.Hard(2);
            string strTitle = "EAM - New Note";
            Browser.SwitchToWindowUsingTitle(strTitle);
            tmsWait.Hard(2);
            Browser.Wd.FindElement(By.Id("txtNote")).SendKeys(GeneratedData);

            //IWebElement txtNote= Browser.Wd.FindElement(By.Id("txtNote"));
            //fw.ExecuteJavascriptSetText(txtNote,GeneratedData);
        }

        [When(@"EAM New Notes page note page Add Note button is clicked")]
        public void WhenEAMNewNotesPageNotePageAddNoteButtonIsClicked()
        {
            Browser.Wd.FindElement(By.Name("cmdAdd")).Click();
            tmsWait.Hard(2);
        }


        [When(@"Verify that notes get added and displaye the message ""(.*)""")]
        public void WhenVerifyThatNotesGetAddedAndDisplayeTheMessage(string p0)
        {
            tmsWait.Hard(2);
            string message = Browser.Wd.FindElement(By.Id("lblMsg")).Text;
            Assert.AreEqual(message, p0.ToString(), "Expected message is not displayed. Please check notes added page");
        }


        [When(@"Verify that EAM New Notes page note displayed remaining Characters Left is ""(.*)""")]
        public void WhenVerifyThatEAMNewNotesPageNoteDisplayedRemainingCharactersLeftIs(int p0)
        {
            tmsWait.Hard(2);
            string strTitle = "EAM - New Note";
            Browser.SwitchToWindowUsingTitle(strTitle);
            Boolean ismatched = false;
            int count = Int32.Parse(Browser.Wd.FindElement(By.XPath(".//*[@id='lblCount']")).Text);
            if (count == p0)
            {
                ismatched = true;
            }

            Assert.IsTrue(ismatched);
        }

        [Then(@"I have clicked on View Notes and Actions item to add a ""(.*)"" for Member ""(.*)""")]
        public void ThenIHaveClickedOnViewNotesAndActionsItemToAddAForMember(string p0, string p1)
        {
            IWebElement viewNoteBtn = Browser.Wd.FindElement(By.Id("btnViewNotes"));
            viewNoteBtn.Click();
            tmsWait.Hard(3);
            IWebElement addNoteBtn = Browser.Wd.FindElement(By.XPath("//*[@role='button']/span[@class='fa fa-plus-circle']"));
            addNoteBtn.Click();

            switch (p0)
            {
                case "note":
                    IWebElement radioNote = Browser.Wd.FindElement(By.Id("rdNote"));
                    fw.ExecuteJavascript(radioNote);
                    IWebElement descriptionText = Browser.Wd.FindElement(By.XPath("//*[@test-id= 'addNotes-input-description']"));
                    descriptionText.SendKeys(p1);
                    break;

                case "action":
                    IWebElement radioAction = Browser.Wd.FindElement(By.Id("rdAction"));
                    IWebElement dueDateAction = Browser.Wd.FindElement(By.Id("dueDate"));
                    fw.ExecuteJavascript(radioAction);
                    tmsWait.Hard(2);
                    string actionDate = DateTime.Today.ToString("MMddyyyy");
                    tmsWait.Hard(2);
                    dueDateAction.Click();
                    tmsWait.Hard(2);
                    dueDateAction.SendKeys(actionDate);
                    IWebElement action_descriptionText = Browser.Wd.FindElement(By.XPath("//*[@test-id= 'addNotes-input-description']"));
                    action_descriptionText.SendKeys(p1);
                    break;
            }
            IWebElement addBtn = Browser.Wd.FindElement(By.Id("btnAdd"));
            addBtn.Click();
            tmsWait.Hard(3);
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//*[@test-id='memberAudit-lbl-back']")));
            tmsWait.Hard(3);

        }

        [When(@"NotesAndActions page ""(.*)"" Textbox is set to ""(.*)""")]
        public void WhenNotesAndActionsPageTextboxIsSetTo(string p0, string p1)
        {
            switch (p0)
            {
                case "MBI":
                    {
                        IWebElement Notes_MBI = Browser.Wd.FindElement(By.XPath("//*[@id='tagOrSearch']/div/div/input"));
                        Notes_MBI.Click();
                        Notes_MBI.SendKeys(p1);
                        tmsWait.Hard(2);
                        IWebElement Notes_searchBtn = Browser.Wd.FindElement(By.XPath("//*[@test-id='notesSearch-button-btnSearch']"));
                        Notes_searchBtn.Click();
                        tmsWait.Hard(5);
                        break;
                    }
            }


        }

        [When(@"i have selected Type as ""(.*)"" radio button")]
        public void WhenIHaveSelectedTypeAsRadioButton(string p0)
        {
            switch (p0)
            {
                case "Notes":
                    {
                        IWebElement Type_notes = Browser.Wd.FindElement(By.XPath("//*[@test-id='notesSearch-radio-notes']"));
                        fw.ExecuteJavascript(Type_notes);
                        tmsWait.Hard(1);
                        break;
                    }

                case "Actions":
                    {
                        IWebElement Type_actions = Browser.Wd.FindElement(By.XPath("//*[@test-id='notesSearch-radio-actions']"));
                        fw.ExecuteJavascript(Type_actions);
                        tmsWait.Hard(1);
                        break;
                    }
                case "All":
                    {
                        IWebElement Type_All = Browser.Wd.FindElement(By.XPath("//*[@test-id='notesSearch-radio-typeAll']"));
                        fw.ExecuteJavascript(Type_All);
                        tmsWait.Hard(5);
                        break;
                    }

            }
        }

        [When(@"on NotesAndActions page search by is selected as ""(.*)""")]
        public void WhenOnNotesAndActionsPageSearchByIsSelectedAs(string p0)
        {
            IWebElement searchBy= Browser.Wd.FindElement(By.XPath("//*[@id='orSearchMenu']/button/span"));
            fw.ExecuteJavascript(searchBy);
            IWebElement item_lastName= Browser.Wd.FindElement(By.XPath("//*[@id='orSearchMenu']/ul/li/a[contains(.,'Last Name')]"));
            item_lastName.Click();
            tmsWait.Hard(2);
        }



        [When(@"i have clicked on ""(.*)"" button on NotesandActions page")]
        public void WhenIHaveClickedOnButtonOnNotesandActionsPage(string p0)
        {
            switch (p0)
            {
                case "Reset":
                    IWebElement Type_All = Browser.Wd.FindElement(By.XPath("//*[@test-id='notesSearch-radio-typeAll']"));
                    IWebElement Notes_resetBtn = Browser.Wd.FindElement(By.XPath("//*[@test-id='notesSearch-button-btnReset']"));
                    Notes_resetBtn.Click();
                    tmsWait.Hard(2);
                    Assert.IsTrue(Type_All.Selected, "Type - All radio button is not selected");
                    IWebElement status_drpDown = Browser.Wd.FindElement(By.XPath("//*[@id='mainContant']/div[1]/div/div/div[2]/div[2]/div/div/span/span/span[1]"));
                    Assert.AreEqual("All", status_drpDown.Text, "Status dropdown is not defaulted to All");
                    break;

                case "Search":
                    IWebElement Notes_searchBtn = Browser.Wd.FindElement(By.Id("btnSearch"));
                    Notes_searchBtn.Click();
                    break;
            }
        }


        [Then(@"I have clicked on View Notes and Actions item on View Member page")]
        public void ThenIHaveClickedOnViewNotesAndActionsItemOnViewMemberPage()
        {
            IWebElement viewNoteBtn = Browser.Wd.FindElement(By.Id("btnViewNotes"));
            viewNoteBtn.Click();
            tmsWait.Hard(3);
        }

        [Then(@"i click on cancel button")]
        public void ThenIClickOnCancelButton()
        {
            IWebElement cancelBtn = Browser.Wd.FindElement(By.Id("btnCancel"));
            fw.ExecuteJavascript(cancelBtn);
            tmsWait.Hard(3);
            IWebElement viewNoteBtn = Browser.Wd.FindElement(By.Id("btnViewNotes"));
            Assert.IsTrue(viewNoteBtn.Displayed);

        }

       
        [Then(@"i verify ""(.*)"" details- date ""(.*)"", author ""(.*)"" and Description ""(.*)""")]
        [Given(@"i verify ""(.*)"" details- date ""(.*)"", author ""(.*)"" and Description ""(.*)""")]
        [When(@"i verify ""(.*)"" details- date ""(.*)"", author ""(.*)"" and Description ""(.*)""")]
        public void ThenIVerifyDetails_DateAuthorAndDescription(string p0, string date, string author, string description)
        {
            bool flag = false;
            IList<IWebElement> expandSign;
            string expDescription = tmsCommon.GenerateData(description);
            switch (p0)
            {
                case "Actions":
                    IWebElement editActions = Browser.Wd.FindElement(By.XPath("//*[@test-id='outOfAre-li-actions']/span[2]"));
                    editActions.Click();
                    tmsWait.Hard(2);
                    expandSign = Browser.Wd.FindElements(By.XPath("//*[@aria-label='Expand']"));

                    foreach (IWebElement expandSignElement in expandSign)
                    {
                        expandSignElement.Click();
                        tmsWait.Hard(1);
                    }

                    IWebElement labelDescription_Action = Browser.Wd.FindElement(By.XPath("//*[@id='grdViewActionsTab']//tr[2]/td[2]/div/b/span"));
                    Assert.AreEqual("Detailed Action Description:", labelDescription_Action.Text);

                    string actualDueDate_Action = Browser.Wd.FindElement(By.XPath("//*[@id='grdViewActionsTab']/div[2]//tr[1]/td[3]/div/div/span[3]")).Text;
                    string expDueDate_Action = "Due Date: "+tmsCommon.GenerateData(date);
                    Assert.AreEqual(expDueDate_Action, actualDueDate_Action, "Due Date is incorrect");

                    string actualauthor_Action = Browser.Wd.FindElement(By.XPath("//*[@id='grdViewActionsTab']//tr[1]/td[3]/div/div/span[2]")).Text;
                    string expAuthor_Action = "Author: " + tmsCommon.GenerateData(author);
                    Assert.AreEqual(expAuthor_Action, actualauthor_Action, "Author Name is incorrect");
                    break;

                case "Notes":
                    IWebElement notesTab = Browser.Wd.FindElement(By.XPath("//*[@data-title='Notes']"));
                    notesTab.Click();
                    tmsWait.Hard(2);
                    expandSign = Browser.Wd.FindElements(By.XPath("//*[@aria-label='Expand']"));
                    foreach (IWebElement expandSignElement in expandSign)
                    {
                        expandSignElement.Click();
                        tmsWait.Hard(1);
                    }

                    IWebElement labelDescription_Note = Browser.Wd.FindElement(By.XPath("//*[@id='grdViewNotesTab']//tr[2]/td[2]/div/b/span"));
                    Assert.AreEqual("Detailed Notes Description:", labelDescription_Note.Text);

                    string actualauthor_Note = Browser.Wd.FindElement(By.XPath("//*[@id='grdViewNotesTab']/div[2]//tr[1]/td[2]/div/div/span[2]")).Text;
                    string expAuthor_Note = "Author: " + tmsCommon.GenerateData(author);
                    Assert.AreEqual(expAuthor_Note, actualauthor_Note, "Author Name is incorrect");

                    break;
            }

            IList<IWebElement> descriptionText = Browser.Wd.FindElements(By.XPath("//*[@class='ui-grid-cell-contents padding0']/div"));
            string shortDescription = Browser.Wd.FindElement(By.XPath("//*[@class='ui-grid-cell-contents col-xs-12']")).Text;

            foreach (IWebElement desc in descriptionText)
            {
                string actualDesText = desc.Text;
                if ((shortDescription.Length <= 100) || (actualDesText == expDescription))
                {
                    flag = true;
                    break;
                }
            }

            if (flag == false)
                Assert.Fail("Either short description is more than 100 characters or details description text is incorrect");

            IList<IWebElement> collapseSign = Browser.Wd.FindElements(By.XPath("//*[@aria-label='Collapse']"));
            foreach (IWebElement collapseSignElement in collapseSign)
            {
                collapseSignElement.Click();
                tmsWait.Hard(1);
            }
        }

        [Then(@"i click on Edit NotesAndActions button")]
        public void ThenIClickOnEditNotesAndActionsButton()
        {
            tmsWait.Hard(2);
            //bool flag = false;
            IWebElement editNotesBtn = Browser.Wd.FindElement(By.XPath("//*[@role='button']/span[@class='fa fa-pencil']"));
            fw.ExecuteJavascript(editNotesBtn);
            //editNotesBtn.Click();
            tmsWait.Hard(3);
        }

        [Then(@"i click on Edit button for ""(.*)"" to verify noteDescription ""(.*)""")]
        public void ThenIClickOnEditButtonForToVerifyNoteDescription(string p0, string p1)
        {
            bool flag = false;
            IWebElement editNotesBtn = Browser.Wd.FindElement(By.XPath("//*[@role='button']/span[@class='fa fa-pencil']"));
            editNotesBtn.Click();
            tmsWait.Hard(3);
            IList<IWebElement> expandSign = Browser.Wd.FindElements(By.XPath("//*[@aria-label='Expand']"));
            IList<IWebElement> collapseSign = Browser.Wd.FindElements(By.XPath("//*[@aria-label='Collapse']"));
            string expDescription = tmsCommon.GenerateData(p1);
            switch (p0)
                {
                case "Actions":
                    IWebElement editActions = Browser.Wd.FindElement(By.XPath("//*[@test-id='outOfAre-li-actions']/span[2]"));
                    editActions.Click();
                    break;

                case "Notes":
                    IWebElement notesTab = Browser.Wd.FindElement(By.XPath("//*[@data-title='Notes']"));
                    notesTab.Click();
                    break;
                }
                foreach (IWebElement expandSignElement in expandSign)
                {
                 expandSignElement.Click();
                tmsWait.Hard(1);
                }

                IList<IWebElement> noteDescription = Browser.Wd.FindElements(By.XPath("//*[@class='ui-grid-cell-contents padding0']/div"));
                foreach (IWebElement desc in noteDescription)
                 {
                 string actualDesText = desc.Text;
                 if (actualDesText == expDescription)
                 {
                      flag = true;
                      break;
                  }
                 }

                if (flag == false)
                   Assert.Fail("Description did not match");

                foreach (IWebElement collapseSignElement in collapseSign)
                {
                    collapseSignElement.Click();
                    tmsWait.Hard(1);
                }
          
            }
        [Then(@"i click on Actions Tab")]
        public void ThenIClickOnActionsTab()
        {
            IWebElement editActions = Browser.Wd.FindElement(By.XPath("//*[@test-id='outOfAre-li-actions']/span[2]"));
            editActions.Click();
            tmsWait.Hard(1);
        }

        [Then(@"i click on Back To Record link")]
        public void ThenIClickOnBackToRecordLink()
        {
            
            IWebElement backBtn = Browser.Wd.FindElement(By.XPath("//*[@test-id='notesDetails-lbl-back']"));
            backBtn.Click();
            tmsWait.Hard(3);
        }


        [Then(@"verify UI of View Notes and Actions page")]
        public void ThenVerifyUIOfViewNotesAndActionsPage()
        {

            string expMBI= Browser.Wd.FindElement(By.XPath("//*[@id='notesSearchResultGrid']//div[2]//tr[1]/td[1]")).Text;
            string expMemID = Browser.Wd.FindElement(By.XPath("//*[@id='notesSearchResultGrid']//div[2]//tr[1]/td[2]")).Text;
            string expMemName = Browser.Wd.FindElement(By.XPath("//*[@id='notesSearchResultGrid']//div[2]//tr[1]/td[3]")).Text;
            IWebElement editNotesBtn = Browser.Wd.FindElement(By.XPath("//*[@role='button']/span[@class='fa fa-pencil']"));
            editNotesBtn.Click();
            tmsWait.Hard(2);

            string pageTitle= "View Notes and Actions";
            string actTitleText= Browser.Wd.FindElement(By.XPath("//[@test-id='  notesDetails-lbl-notesTitle']")).Text;
            Assert.AreEqual(pageTitle, actTitleText, "Heading Notes and Actions is not displayed");
            
            IWebElement mbiLabel = Browser.Wd.FindElement(By.XPath("//[@test-id='notes-lbl-mbi']"));
            Assert.IsTrue(mbiLabel.Displayed, "MBI label is not displayed");

            IList<IWebElement> mbiText = Browser.Wd.FindElements(By.XPath("//*[@class='col-xs-2 ng-binding'][1]"));
            string actualMBIVal= mbiText[2].Text;
            Assert.AreEqual(expMBI,actualMBIVal, "MBI value is incorrect");
            
            
        }


        [Then(@"i have added a ""(.*)"" for Member with duedate as ""(.*)"" description as ""(.*)"", Make Private as ""(.*)""")]
        public void ThenIHaveAddedAForMemberWithDuedateAsDescriptionAsMakePrivateAs(string note_OR_action, string duedate, string descriptionText, string makePrivate)
        {
            IWebElement viewNoteBtn = Browser.Wd.FindElement(By.Id("btnViewNotes"));
            fw.ExecuteJavascript(viewNoteBtn);
            tmsWait.Hard(30);
            IWebElement addNoteBtn = Browser.Wd.FindElement(By.XPath("//*[@role='button']/span[@class='fa fa-plus-circle']"));
            addNoteBtn.Click();
            tmsWait.Hard(30);
            switch (note_OR_action)
            {
                case "Note":
                    IWebElement radioNote = Browser.Wd.FindElement(By.Id("rdNote"));
                    fw.ExecuteJavascript(radioNote);
                    tmsWait.Hard(20);
                    break;

                case "Action":
                    IWebElement radioAction = Browser.Wd.FindElement(By.Id("rdAction"));
                    IWebElement dueDateAction = Browser.Wd.FindElement(By.Id("dueDate"));
                    fw.ExecuteJavascript(radioAction);
                    tmsWait.Hard(2);
                    if (duedate == "current date")
                    {
                        string actionDate = DateTime.Today.ToString("MMddyyyy");
                        tmsWait.Hard(2);
                        dueDateAction.Click();
                        tmsWait.Hard(2);
                        dueDateAction.SendKeys(actionDate);
                    }
                    if (duedate == "past date")
                    {
                        string actionDate = DateTime.Today.AddDays(-1).ToString("MMddyyyy");
                        tmsWait.Hard(2);
                        dueDateAction.Click();
                        tmsWait.Hard(2);
                        dueDateAction.SendKeys(actionDate);
                    }
                    break;
                   

            }

            IWebElement description = Browser.Wd.FindElement(By.XPath("//*[@test-id= 'addNotes-input-description']"));
            string descText = tmsCommon.GenerateData(descriptionText);
            description.SendKeys(tmsCommon.GenerateData(descText));
            if (descText.Length > 1000)
            {
                string actualDescText = description.GetAttribute("value");
                GlobalRef.DescriptionText = actualDescText;
                Assert.AreEqual(1000, actualDescText.Length, "Description text is not equal to 1000 characters");

            }

            if (makePrivate == "checked")
            {
                IWebElement radio_makePrivate = Browser.Wd.FindElement(By.Id("lblMakePrivate"));
                if (radio_makePrivate.Selected == false)
                {
                    radio_makePrivate.Click();
                }
                tmsWait.Hard(1);
            }

            IWebElement addBtn = Browser.Wd.FindElement(By.Id("btnAdd"));
            addBtn.Click();
            tmsWait.Hard(2);
        }


        //Gurdeep Arora
        [Then(@"Verify toaster message is displayed on the page as ""(.*)""")]
        public void ThenVerifyToasterMessageIsDisplayedOnThePageAs(string p0)
        {
            string expMessage = tmsCommon.GenerateData(p0);
            string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).GetAttribute("aria-label");
            Assert.AreEqual(expMessage, actualValue, "Toaster message is not displayed");
        }


        [Then(@"Verify error message for ""(.*)"" is displayed as ""(.*)""")]
        public void ThenVerifyErrorMessageForIsDisplayedAs(string p0, string p1)
        {
            switch (p0) {
                case "due date":
                    {
                        IWebElement dueDateErrMsg = Browser.Wd.FindElement(By.XPath("//*[@data-for='dueDate']"));
                        Assert.IsTrue(dueDateErrMsg.Displayed, "Due Date Error Message is not displayed");
                        break;
                    }
                case "description":
                    {
                        IWebElement descriptionErrMsg = Browser.Wd.FindElement(By.Id("description"));
                        Assert.IsTrue(descriptionErrMsg.Displayed, "Description Error Message is not displayed");
                        break;
                    }
            }
        }


        [Then(@"Verify description ""(.*)"" should be less than thousand words ""(.*)""")]
        public void ThenVerifyDescriptionShouldBeLessThanThousandWords(string p0, string p1)
        {
            IWebElement action_descriptionText = Browser.Wd.FindElement(By.XPath("//*[@test-id= 'addNotes-input-description']"));
            action_descriptionText.SendKeys(tmsCommon.GenerateData(p0));
            tmsWait.Hard(1);
            string actualTxt= action_descriptionText.Text;
            string expectedTxt = tmsCommon.GenerateData(p1);
            Assert.AreEqual(expectedTxt,actualTxt, "Description text is more than 1000 words");
        }



        [Then(@"Verify Toaster message is displayed as ""(.*)""")]
        public void ThenVerifyToasterMessageIsDisplayedAs(string p0)
        {
            string expMessage = tmsCommon.GenerateData(p0);
           // string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).GetAttribute("aria-label");
            //Assert.AreEqual(expMessage, actualValue, "Toaster message is not displayed");
        }

        [When(@"i have selected Status as ""(.*)""")]
        public void WhenIHaveSelectedStatusAs(string p0)
        {
            IWebElement status_drpDown = Browser.Wd.FindElement(By.XPath("//*[@id='mainContant']/div[1]/div/div/div[2]/div[2]/div/div/span/span/span[1]"));

        }

        //IWebElement status_drpDown = Browser.Wd.FindElement(By.XPath("//*[@id='mainContant']/div[1]/div/div/div[2]/div[2]/div/div/span/span/span[1]"));
        //Assert.AreEqual("All", status_drpDown.Text, "Status dropdown is not defaulted to All");

    }



    //[When(@"i have clicked on Reset button on NotesandActions page")]
    //    public void WhenIHaveClickedOnResetButtonOnNotesandActionsPage()
    //    {
    //        IWebElement Type_All = Browser.Wd.FindElement(By.XPath("//*[@test-id='notesSearch-radio-typeAll']"));
    //        IWebElement Notes_resetBtn = Browser.Wd.FindElement(By.XPath("//*[@test-id='notesSearch-button-btnReset']"));
    //        Notes_resetBtn.Click();
    //        tmsWait.Hard(2);
    //        Assert.IsTrue(Type_All.Selected, "Type - All radio button is not selected");
    //        IWebElement status_drpDown = Browser.Wd.FindElement(By.XPath("//*[@id='mainContant']/div[1]/div/div/div[2]/div[2]/div/div/span/span/span[1]"));
    //        Assert.AreEqual("All", status_drpDown.Text, "Status dropdown is not defaulted to All");
            

    //    }


    //}
}

