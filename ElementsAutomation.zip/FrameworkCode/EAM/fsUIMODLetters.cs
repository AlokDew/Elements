﻿

using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using TMSoR1.FrameworkCode;

namespace TMSoR1
{
    [Binding]
    class fsUIMODLetters
    {

       

        [When(@"Letters Page ""(.*)"" Letter is Clicked")]
        public void WhenLettersPageLetterIsClicked(string letter)
        {
            string p0 = tmsCommon.GenerateData(letter).ToLower();
            By letterName = By.CssSelector("[test-id='"+p0+"']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(letterName);
            tmsWait.Hard(3);
        }

        [When(@"Letters Page Plan ID drop down list ""(.*)"" value is selected")]
        public void WhenLettersPagePlanIDDropDownListValueIsSelected(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'Plan ID')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + value + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                tmsWait.Hard(3);
            }
            else
            {
                UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODLetters.LettersCollections.PlanID, value);
            }
              
        }

        [When(@"Letters Page PBP ID drop down list ""(.*)"" value is selected")]
        public void WhenLettersPagePBPIDDropDownListValueIsSelected(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By Drp = By.XPath("//label[contains(.,'PBP')]/parent::div//span[@class='k-select']");
                By typeapp = By.XPath("//li[text()='" + value + "']");
                fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                tmsWait.Hard(3);
            }
            else
            {
                UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODLetters.LettersCollections.PBPID, value);
            }
           
        }

        [When(@"Letters Page Letter Name drop down list ""(.*)"" value is selected")]
        public void WhenLettersPageLetterNameDropDownListValueIsSelected(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODLetters.LettersCollections.LetterName, value);
        }

        [Then(@"Verify Confirmation of Enrollment Letter page displayed MBI value as ""(.*)""")]
        public void ThenVerifyConfirmationOfEnrollmentLetterPageDisplayedMBIValueAs(string p0)
        {
            tmsWait.Hard(3);
            string mbi = tmsCommon.GenerateData(p0);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//div[@test-id='letterQueue-grid-resultsGrid']//td/span[@ng-bind='dataItem.mbi'][contains(.,'"+ mbi + "')]"));
            UIMODUtilFunctions.elementPresenceUsingWebElement(ele);
        }

        [Then(@"Verify Acknowledgment of Disenrollment Letter page displayed MBI value as ""(.*)""")]
        public void ThenVerifyAcknowledgmentOfDisenrollmentLetterPageDisplayedMBIValueAs(string p0)
        {

            tmsWait.Hard(3);
            string mbi = tmsCommon.GenerateData(p0);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//div[@test-id='letterQueue-grid-resultsGrid']//td/span[contains(.,'" + mbi + "')]"));
            UIMODUtilFunctions.elementPresenceUsingWebElement(ele);
        }
        [When(@"Verify Letters page has row with MBI ""(.*)""")]
        [Then(@"Verify Letters page has row with MBI ""(.*)""")]
        public void ThenVerifyLettersPageHasRowWithMBI(string p0)
        {
            tmsWait.Hard(3);
            string mbi = tmsCommon.GenerateData(p0);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
               //int totalPagesIntheGrid = ReUsableFunctions.getTotalPages();
                string xpath = "//div[@role='presentation']//td[contains(.,'"+mbi+"')]";
                //ReUsableFunctions.clickOnGridElement(xpath);
                // ReUsableFunctions.verifyGridElementPresence(xpath);
                IWebElement ele = Browser.Wd.FindElement(By.XPath(xpath));
                UIMODUtilFunctions.elementPresenceUsingWebElement(ele);
            }
            else
            {
                IWebElement ele = Browser.Wd.FindElement(By.XPath("//div[@test-id='letterQueue-grid-resultsGrid']//td/span[contains(.,'" + mbi + "')]"));
                UIMODUtilFunctions.elementPresenceUsingWebElement(ele);

            }
        }


        [When(@"Facets Master Configuration page Allow EAM Facets Mapping Button is Switched ""(.*)""")]
        public void WhenFacetsMasterConfigurationPageAllowEAMFacetsMappingButtonIsSwitched(string TypeOfAction)
        {

            //ReUsableFunctions.SwitchONOFFButton(TypeOfAction);
            //IWebElement switchEle = Browser.Wd.FindElement(By.CssSelector("[test-id='masterLevel-switch-eamToFacetMapping']"));
            //string curentStatus = switchEle.GetAttribute("value").ToString();

            //IWebElement switchBtn = Browser.Wd.FindElement(By.XPath("//input[@test-id='masterLevel-switch-eamToFacetMapping']/parent::span/span"));


            //if (TypeOfAction.ToLower().Equals("checked") || TypeOfAction.ToLower().Equals("on"))
            //{
            //    if (curentStatus.Equals("false"))
            //    {
            //        fw.ExecuteJavascript(switchBtn);

            //    }
            //}
            //if (TypeOfAction.ToLower().Equals("unchecked") || TypeOfAction.ToLower().Equals("off"))
            //{
            //    if (curentStatus.Equals("true"))
            //    {
            //        fw.ExecuteJavascript(switchBtn);

            //    }
            //}
        }

        [Then(@"Verify Letter page displayed MBI value as ""(.*)""")]
        public void ThenVerifyLetterPageDisplayedMBIValueAs(string p0)
        {
            tmsWait.Hard(5);
            string mbi = tmsCommon.GenerateData(p0);
           // IWebElement ele = Browser.Wd.FindElement(By.XPath("//div[@test-id='letterQueue-grid-resultsGrid']//td/span[@ng-bind='dataItem.mbi'][contains(.,'" + mbi + "')]"));
            //UIMODUtilFunctions.elementPresenceUsingWebElement(ele);




           // string mbi = ScenarioContext.Current["LTMBI"].ToString();


            bool elementSearch = false;
            By mbiBy = By.XPath("(//kendo-grid[@test-id='letterQueue-grid-resultsGrid']//td[contains(.,'"+mbi+"')])[1]");
            By nextPage = By.XPath("//a[@title='Go to the next page']");
            By DeselectAll = By.Id("btnLegacyMemberDeSelectAll");
            while (!elementSearch)
            {
                elementSearch = elementPresence(mbiBy);
                tmsWait.Hard(3);
                if (!elementSearch)
                {
                    try
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(nextPage));
                    }
                    catch
                    {
                        Assert.Fail(" Expected MBI is not present on Export Search results");
                    }
                }

                if (elementSearch)
                {

                    Assert.IsTrue(true, mbi + "  Value is found on Letter page");
                    break;      
                                    
                }

            }
        }

        public bool elementPresence(By ele)
        {

            try
            {
                Browser.Wd.FindElement(ele);
                return true;
            }
            catch
            {
                return false;
            }
        }

        [Then(@"Verify Home Page Letter count for Outbound Enrollment Verification ""(.*)"" is not queued")]
        public void ThenVerifyHomePageLetterCountForOutboundEnrollmentVerificationIsNotQueued(string p0)
        {
            tmsWait.Hard(3);
            string mbi = tmsCommon.GenerateData(p0);
           

            bool elementSearch = false;
            By mbiBy = By.XPath("//div[@id='letterQueueGrid']//span[contains(.,'" + mbi + "')]");
            By nextPage = By.XPath("//a[@title='Go to the next page']");
           // By DeselectAll = By.Id("btnLegacyMemberDeSelectAll");
            while (!elementSearch)
            {
                elementSearch = elementPresence(mbiBy);
                tmsWait.Hard(3);
                if (!elementSearch)
                {
                    try
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(nextPage));
                    }
                    catch
                    {
                        Assert.IsTrue(true,"  MBI is not present on Export Search results");
                    }
                }

                if (elementSearch)
                {

                    Assert.IsFalse(false, mbi + "  Value is found on Letter page");
                    break;

                }

            }
        }

        //[Then(@"Verify ""(.*)"" Message is displayed")]
        //public void ThenVerifyMessageIsDisplayed(string p0)
        //{
        //    clearingLetterQueue();
        //    string expectedMessage = tmsCommon.GenerateData(p0);
        //    string actualMessage = Browser.Wd.FindElement(By.XPath("//label[@test-id='letter-lbl-jobSessionMsg']")).Text;
        //    Assert.AreEqual(expectedMessage, actualMessage, "Expected message is not displayed");
        //}


        [When(@"Letters Page Search Button is Clicked")]
        public void WhenLettersPageSearchButtonIsClicked()
        {
            //By jobProc = By.XPath("//label[contains(.,'Not allowed: You are already processing the same task from another browser.')]");
            //By exportSession = By.XPath("//a[@title='Export Session']");

            //try
            //{
            //    if (Browser.Wd.FindElement(jobProc).Displayed)
            //    {
            //        UIMODUtilFunctions.clickOnWebElementUsingLocators(exportSession);
            //        // This part will be implemented once Export Session is Modernized - Venkatesh
            //    }
            //}
            //catch
            //{
            //    fw.ConsoleReport(" There is no Job Processing");
            //}

            ReUsableFunctions.clickOnWebElement(cfUIMODLetters.LettersCollections.SearchButton);
          
        }

        [When(@"Letters Search results MBI ""(.*)"" row is selected and Click on Send Check box")]
        public void WhenLettersSearchResultsMBIRowIsSelectedAndClickOnSendCheckBox(string mbi)
        {
            string mbi1 = tmsCommon.GenerateData(mbi);
            By loc = By.XPath("(//kendo-grid[@test-id='letterQueue-grid-resultsGrid']//td[contains(.,'"+ mbi1 + "')]/following-sibling::td/input)[1]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
        }

        [When(@"Letters Search results any MBI row is selected and Click on Send Check box")]
        public void WhenLettersSearchResultsAnyMBIRowIsSelectedAndClickOnSendCheckBox()
        {
            IReadOnlyCollection<IWebElement> checkBoxes = Browser.Wd.FindElements(By.XPath("//input[@name='sendLetter']"));

            foreach(IWebElement temp in checkBoxes)
            {
               
                if(temp.Enabled)
                {
                    ReUsableFunctions.CheckBoxOperations(temp, "checked");                    
                    break;
                }
            }

           
        }

        [When(@"Letters Search results MBI ""(.*)"" row is not Present")]
        public void WhenLettersSearchResultsMBIRowIsNotPresent(string mbi)
        {
            By loc = By.XPath("//div[@test-id='letterQueue-grid-resultsGrid']//td[contains(.,'" + mbi + "')]/following-sibling::td/input[@name='sendLetter']");
            UIMODUtilFunctions.elementNotPresenceUsingLocators(loc);
        }

        [When(@"Letters Page ""(.*)"" Letter is not Present")]
        public void WhenLettersPageLetterIsnotPresent(string letter)
        {
            string p0 = tmsCommon.GenerateData(letter).ToLower();
            By letterName = By.CssSelector("[test-id='" + p0 + "']");
            UIMODUtilFunctions.elementNotPresenceUsingLocators(letterName);
        }

        [When(@"Letters Page Preview Button is Clicked")]
        public void WhenLettersPagePreviewButtonIsClicked()
        {
            ReUsableFunctions.clickOnWebElement(cfUIMODLetters.LettersCollections.PreviewButton);
            tmsWait.Hard(35);
        }

        [When(@"Letters Page Generate Button is Clicked")]
        public void WhenLettersPageGenerateButtonIsClicked()
        {

            ReUsableFunctions.clickOnWebElement(cfUIMODLetters.LettersCollections.GenerateLettersButton);
        }

        [Then(@"Verify Letters page Warning Message ""(.*)""")]
        public void ThenVerifyLettersPageWarningMessage(string p0)
        {
            string expectedMsg = tmsCommon.GenerateData(p0);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//div[contains(.,'" + expectedMsg + "')]")).Displayed, "Expected message is not displayed");
        }

        [When(@"Letters Page Confirmation Popup selects ""(.*)"" for generating letters")]
        public void WhenLettersPageConfirmationPopupSelectsForGeneratingLetters(string p0)
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='confirmationDialog-btn-Yes']")));
            tmsWait.Hard(3);
        }


        [When(@"Letters Page Letter Generation Job Rquest ID is Noted")]
        public void WhenLettersPageLetterGenerationJobRquestIDIsNoted()
        {
            IWebElement msg = Browser.Wd.FindElement(By.XPath("//label[@test-id='letter-lbl-jobSessionMsg']"));
            tmsWait.Hard(3);
            string jobID = (msg.Text.Split(' '))[7].Trim();
            ScenarioContext.Current.Add("JobID", jobID);
            fw.ConsoleReport(" Requested Letter Generation Job Id --> " + jobID[1]);
            tmsWait.Hard(10);
        }


        [When(@"Letters Page DeSelect All Button is Clicked")]
        public void WhenLettersPageDeSelectAllButtonIsClicked()
        {
            tmsWait.Hard(3);
            fw.ScrollWindowToViewElement(cfUIMODLetters.LettersCollections.DeselctAllButton);
            ReUsableFunctions.clickOnWebElement(cfUIMODLetters.LettersCollections.DeselctAllButton);
        }

        [When(@"Letters Page Toggle Remove All Button is Clicked")]
        public void WhenLettersPageToggleRemoveAllButtonIsClicked()
        {
            bool queueMessage = false;
            tmsWait.Hard(3);
            //IList<IWebElement> countMessage = Browser.Wd.FindElements(By.XPath("//label[contains(.,'No records in the Queue')]"));
            //if (countMessage.Count != 0)
            //{
            //    fw.ScrollWindowToViewElement(cfUIMODLetters.LettersCollections.ToggleRemoveAllButton);
            //    ReUsableFunctions.clickOnWebElement(cfUIMODLetters.LettersCollections.ToggleRemoveAllButton);
            //}


            try
            {

                queueMessage = Browser.Wd.FindElement(By.XPath("//label[contains(.,'No records in the Queue')]")).Displayed;

            }
            catch (Exception ex)
            {
                bool hasrow = false;
                int totalPagesIntheGrid = 0;
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    totalPagesIntheGrid = ReUsableFunctions.getTotalPages();

                    for (int i = 1; i <= totalPagesIntheGrid; i++)
                    {
                        fw.ScrollWindowToViewElement(cfUIMODLetters.LettersCollections.ToggleRemoveAllButton);
                        ReUsableFunctions.clickOnWebElement(cfUIMODLetters.LettersCollections.ToggleRemoveAllButton);
                        IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                        ReUsableFunctions.clickOnWebElement(nextpage);

                    }

                }
                else
                {
                    totalPagesIntheGrid = Int32.Parse(Browser.Wd.FindElement(By.XPath("//a[@title='Go to the last page']")).GetAttribute("data-page"));
                    for (int i = 1; i <= totalPagesIntheGrid; i++)
                    {
                        fw.ScrollWindowToViewElement(cfUIMODLetters.LettersCollections.ToggleRemoveAllButton);
                        ReUsableFunctions.clickOnWebElement(cfUIMODLetters.LettersCollections.ToggleRemoveAllButton);
                        IWebElement nextpage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));
                        ReUsableFunctions.clickOnWebElement(nextpage);

                    }

                    //        if (!queueMessage)
                    //    {
                    //        fw.ScrollWindowToViewElement(cfUIMODLetters.LettersCollections.ToggleRemoveAllButton);
                    //        ReUsableFunctions.clickOnWebElement(cfUIMODLetters.LettersCollections.ToggleRemoveAllButton);
                    //    }
                    //    else
                    //    {
                    //        fw.ConsoleReport("Queue is already cleared Toggle Remove All skipped");
                    //    }
                    //}
                }
            }
            fw.ConsoleReport("Queue is already cleared Toggle Remove All skipped");
        }
        [When(@"Letters Page Remove Button is Clicked")]
        public void WhenLettersPageRemoveButtonIsClicked()
        {
            tmsWait.Hard(3);
            bool queueMessage = false;
            try
            {
               queueMessage = Browser.Wd.FindElement(By.XPath("//label[contains(.,'No records in the Queue')]")).Displayed;

            }
            catch { 
                if (!queueMessage)
            {
                fw.ScrollWindowToViewElement(cfUIMODLetters.LettersCollections.RemoveButton);
                ReUsableFunctions.clickOnWebElement(cfUIMODLetters.LettersCollections.RemoveButton);
                tmsWait.Hard(3);
                try
                {
                    UIMODUtilFunctions.clickOnConfirmationYesDialog();
                    tmsWait.Hard(3);
                }
                catch
                {
                    tmsWait.Hard(3);
                }
            }
            else
            {
                fw.ConsoleReport("Queue is already cleared Remove skipped");
            }

            }
        }

        [Then(@"Switch to Letter Preview and Generate Page")]
        public void ThenSwitchToLetterPreviewAndGeneratePage()
        {
            Browser.SwitchToChildWindow();
            tmsWait.Hard(15);

            By template = By.XPath("//label[@test-id='previewLetters-lbl-jobSessionMsg'][contains(.,'Letter Template is not registered for this letter. Please register Templates on Letter Templates page.')]");
            try
            {
                if(Browser.Wd.FindElement(template).Displayed)
                {
                    Assert.AreEqual(1,2,"Letter Template is not registered for this letter. Please register Templates on Letter Templates page ");

                    // In this line, Assert.Fail, Assert.IsTrue were not working , so used above. dont modify it.
                }
            }
            catch
            {

            }

        }

        [Then(@"Verify Letter Preview is working properly")]
        public void ThenVerifyLetterPreviewIsWorkingProperly()
        {
            Browser.SwitchToIFrame();
            string reportPagesource = Browser.Wd.PageSource;
            string letterId = Browser.Wd.FindElement(By.XPath("//embed[@type='application/pdf']")).GetAttribute("internalid");
            if (letterId != null)
            {
                Assert.IsTrue(true, " Letter is Previewed successfully");
            }
        }

    }
}