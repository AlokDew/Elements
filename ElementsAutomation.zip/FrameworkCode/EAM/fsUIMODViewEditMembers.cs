﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

using TMSoR1.FrameworkCode;
namespace TMSoR1
{
    [Binding]
    class fsUIMODViewEditMembers
    {

        [When(@"View Edit Members page MBI Textbox is set to ""(.*)""")]
        public void WhenViewEditMembersPageMBITextboxIsSetTo(string p0)
        {
            string mbi = tmsCommon.GenerateData(p0);
            IWebElement mbiTextbox = Browser.Wd.FindElement(By.XPath("//input[@test-id='memberSearch-input-mbi']"));
            mbiTextbox.SendKeys(mbi);
            mbiTextbox.SendKeys(Keys.Tab);

        }

        [Then(@"Verify View Edit Member page Transactions section only one TC ""(.*)"" is created for Plan ID ""(.*)"" PBP ""(.*)"" Program Source ""(.*)""")]
        public void ThenVerifyViewEditMemberPageTransactionsSectionOnlyOneTCIsCreatedForPlanIDPBPProgramSource(string p0, string p1, string p2, string p3)
        {
            string tc = tmsCommon.GenerateData(p0);
            string plan = tmsCommon.GenerateData(p1);
            string pbp = tmsCommon.GenerateData(p2);
            string source = tmsCommon.GenerateData(p3);

            By ele = By.XPath("//kendo-grid[@test-id='transactions-grid-memberTransactionsGrid']//td[contains(.,'" + tc + "')]/following-sibling::td[contains(.,'" + plan + "')]/following-sibling::td[contains(.,'" + pbp + "')]//following-sibling::td[contains(.,'" + source + "')]");
            IReadOnlyCollection<IWebElement> tcelements = Browser.Wd.FindElements(ele);

            int tccount = tcelements.Count;
            int expectedCount = 1;

            Assert.AreEqual(expectedCount, tccount);


        }


        [When(@"View Edit Members page ""(.*)"" Textbox is set to ""(.*)""")]
        [Then(@"View Edit Members page ""(.*)"" Textbox is set to ""(.*)""")]
        [Given(@"View Edit Members page ""(.*)"" Textbox is set to ""(.*)""")]
        public void WhenViewEditMembersPageTextboxIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(4);
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1).ToUpper();
            By resultGrid;
            switch (componentType)
            {
                case "MBI":
                    // ReUsableFunctions.clickOnWebElement(cfUIMODViewEditMember.ViewEditMemberPage.MBILookup);
                    // tmsWait.Hard(30);
                    try
                    {
                        ReUsableFunctions.enterValueOnWebElementWithoutClear(cfUIMODViewEditMember.MemberLookup.MBI, value);
                    }
                    catch
                    {
                        ReUsableFunctions.enterValueOnWebElementWithoutClear(cfUIMODViewEditMember.MemberLookup.MBI_R2, value);
                    }
                    tmsWait.Hard(2);
                    GlobalRef.LTMBI = value;
                    GlobalRef.TransMBI = value;
                   // ReUsableFunctions.clickOnWebElement(cfUIMODViewEditMember.MemberLookup.SearchBtn);
                    //tmsWait.Hard(12);
                    //if (ConfigFile.tenantType.Equals("tmsx"))
                    //{
                    //    resultGrid = By.XPath("//*[@id='auditMembersListGrid']//td[contains(.,'" + value + "')]/preceding-sibling::td/input");
                    //    UIMODUtilFunctions.clickOnWebElementUsingLocators(resultGrid);
                    //    tmsWait.Hard(2);
                    //}
                    //else
                    //{
                    //    resultGrid = By.XPath("//div[@test-id='member-grid-auditslist']//td[contains(.,'" + value + "')]/preceding-sibling::td/input");
                    //    UIMODUtilFunctions.clickOnWebElementUsingLocators(resultGrid);
                    //    tmsWait.Hard(2);
                    //}
                   

                    //ReUsableFunctions.clickOnWebElement(cfUIMODViewEditMember.MemberLookup.ADDBtn);
                    tmsWait.Hard(5);
                    break;

                case "Employer Group Name":
                    string empgname = tmsCommon.GenerateData(p1);
                    By Drp = By.XPath("//label[contains(.,'Employer Group Name')]/parent::div//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + empgname + "']");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                    break;

                case "Member Id":
                    //ReUsableFunctions.clickOnWebElement(cfUIMODViewEditMember.ViewEditMemberPage.MBILookup);
                    //tmsWait.Hard(3);
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODViewEditMember.MemberLookup.MemberID, value);
                    //ReUsableFunctions.clickOnWebElement(cfUIMODViewEditMember.MemberLookup.SearchBtn);
                    tmsWait.Hard(1);
                    //if (ConfigFile.tenantType.Equals("tmsx"))
                    //{
                    //    resultGrid = By.XPath("//*[@id='auditMembersListGrid']//td[contains(.,'" + value + "')]/preceding-sibling::td/input");
                    //    UIMODUtilFunctions.clickOnWebElementUsingLocators(resultGrid);
                    //    tmsWait.Hard(2);
                    //}
                    //else
                    //{

                    //By resGrid = By.XPath("//div[@test-id='member-grid-auditslist']//td[contains(.,'" + value + "')]/preceding-sibling::td/input");
                    //UIMODUtilFunctions.clickOnWebElementUsingLocators(resGrid);
                    //}

                    //tmsWait.Hard(1);
                    //ReUsableFunctions.clickOnWebElement(cfUIMODViewEditMember.MemberLookup.ADDBtn);
                    //tmsWait.Hard(1);
                    break;
                case "MemberID":
                    
                        ReUsableFunctions.enterValueOnWebElement(cfUIMODViewEditMember.ViewEditMemberPage.ViewEditPageMemberID, value);
                    break;

                case "FirstName":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODViewEditMember.ViewEditMemberPage.FirstName, value);
                    break;
                case "LastName":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODViewEditMember.ViewEditMemberPage.LastName, value);
                    break;
                case "MembID":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODViewEditMember.ViewEditMemberPage.MEMID, value);
                    break;
                case "Status":

                    string status = tmsCommon.GenerateData(p1);
                    
                    
                       By DrpStatus = By.XPath("//label[contains(.,'Member Status')]/parent::div//span[@class='k-select']");

                       By typeappStatus = By.XPath("//li[text()='" + status + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(DrpStatus));
                        //tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeappStatus));

                        tmsWait.Hard(3);

                   
                   
                    break;
                case "Program Source":
                    string source = tmsCommon.GenerateData(p1);
                   
                        By Drppsource = By.XPath("//label[contains(.,'Program Source')]/parent::div//span[@class='k-select']");

                        By typeappsource = By.XPath("//li[text()='" + source + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drppsource));
                        //tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeappsource));

                        tmsWait.Hard(3);

                   
                    break;
                case "PlanID":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drppid = By.XPath("//label[contains(.,'Plan ID')]/parent::div//span[@class='k-select']");

                        By typeapppid = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drppid));
                        //tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapppid));

                        tmsWait.Hard(3);

                    }
                    else
                    {
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODViewEditMember.ViewEditMemberPage.PlanIDDropDownlist, value);
                    }
                    break;

                case "PBPID":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drppbp = By.XPath("//label[contains(.,'PBP ID')]/parent::div//span[@class='k-select']");

                        By typeapppbp = By.XPath("//li[text()='" + value + "']");

                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(Drp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(Drppbp));
                        //tmsWait.Hard(3);
                        //UIMODUtilFunctions.clickOnWebElementUsingLocators(typeapp);
                        fw.ExecuteJavascript(Browser.Wd.FindElement(typeapppbp));

                        tmsWait.Hard(3);

                    }
                    else
                    {
                        UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODViewEditMember.ViewEditMemberPage.PBPIDDropDownlist, value);
                        }
                        break;

            }
        }

        [When(@"on View Edit Members page ""(.*)"" Textbox is set to ""(.*)""")]
        [Given(@"on View Edit Members page ""(.*)"" Textbox is set to ""(.*)""")]
        [Then(@"on View Edit Members page ""(.*)"" Textbox is set to ""(.*)""")]
        public void WhenOnViewEditMembersPageTextboxIsSetTo(string p0, string p1)
        {
            tmsWait.Hard(4);
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1).ToUpper();
            switch (componentType)
            {
                case "MBI":
                    ReUsableFunctions.clickOnWebElement(cfUIMODViewEditMember.ViewEditMemberPage.MBILookup);
                    tmsWait.Hard(30);
                    ReUsableFunctions.enterValueOnWebElementWithoutClear(cfUIMODViewEditMember.MemberLookup.MBI, value);
                    tmsWait.Hard(2);
                    GlobalRef.LTMBI = value;
                    GlobalRef.TransMBI = value;
                    ReUsableFunctions.clickOnWebElement(cfUIMODViewEditMember.MemberLookup.SearchBtn);
                    tmsWait.Hard(12);
                    try
                    {
                        //By resultGrid = By.XPath("//div[@test-id='member-grid-auditslist']//input[@type='checkbox']");
                        By resultGrid = By.XPath("//div[@test-id='member-grid-auditslist']//td[contains(.,'" + value + "')]/preceding-sibling::td/input");
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(resultGrid);
                        tmsWait.Hard(2);
                        ReUsableFunctions.clickOnWebElement(cfUIMODViewEditMember.MemberLookup.ADDBtn);
                        tmsWait.Hard(5);
                    }
                    catch
                    {
                        Browser.Wd.Navigate().Refresh();
                        ReUsableFunctions.clickOnWebElement(cfUIMODViewEditMember.ViewEditMemberPage.MBILookup);
                        tmsWait.Hard(30);
                        ReUsableFunctions.enterValueOnWebElementWithoutClear(cfUIMODViewEditMember.MemberLookup.MBI, value);
                        tmsWait.Hard(2);
                        GlobalRef.LTMBI = value;
                        GlobalRef.TransMBI = value;
                        ReUsableFunctions.clickOnWebElement(cfUIMODViewEditMember.MemberLookup.SearchBtn);
                        tmsWait.Hard(12);
                        By resultGrid = By.XPath("//div[@test-id='member-grid-auditslist']//td[contains(.,'" + value + "')]/preceding-sibling::td/input");
                        UIMODUtilFunctions.clickOnWebElementUsingLocators(resultGrid);
                        tmsWait.Hard(2);
                        ReUsableFunctions.clickOnWebElement(cfUIMODViewEditMember.MemberLookup.ADDBtn);
                        tmsWait.Hard(5);
                    }
                    break;
                case "Member Id":
                    ReUsableFunctions.clickOnWebElement(cfUIMODViewEditMember.ViewEditMemberPage.MBILookup);
                    tmsWait.Hard(3);
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODViewEditMember.MemberLookup.MemberID, value);
                    ReUsableFunctions.clickOnWebElement(cfUIMODViewEditMember.MemberLookup.SearchBtn);
                    tmsWait.Hard(1);
                    By resGrid = By.XPath("//div[@test-id='member-grid-auditslist']//td[contains(.,'" + value + "')]/preceding-sibling::td/input");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(resGrid);
                    tmsWait.Hard(1);
                    ReUsableFunctions.clickOnWebElement(cfUIMODViewEditMember.MemberLookup.ADDBtn);
                    tmsWait.Hard(1);
                    break;
                case "MemberID":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODViewEditMember.ViewEditMemberPage.ViewEditPageMemberID, value);
                    break;

                case "FirstName":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODViewEditMember.ViewEditMemberPage.FirstName, value);
                    break;
                case "LastName":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODViewEditMember.ViewEditMemberPage.LastName, value);
                    break;
                case "MembID":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODViewEditMember.ViewEditMemberPage.MEMID, value);
                    break;
                case "Status":
                    string status = tmsCommon.GenerateData(p1);
                    //UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODViewEditMember.ViewEditMemberPage.MemberStatusDropDownlist, p1);
                    ReUsableFunctions.clickOnWebElement(cfUIMODViewEditMember.ViewEditMemberPage.MemberStatusDropDownlist);
                    //UIMODUtilFunctions.selectDropDownValueFromGendoUIWithoutAriaOwns(cfUIMODViewEditMember.ViewEditMemberPage.MemberStatusDropDownlist, value);
                    fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//ul[@id='dropdownMemberStatus_listbox']/li[contains(.,'" + status + "')]")));
                    break;
                case "Program Source":
                    string source = tmsCommon.GenerateData(p1);
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODViewEditMember.ViewEditMemberPage.ProgramSourceDropDownlist, source);
                    break;
                case "PlanID":
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODViewEditMember.ViewEditMemberPage.PlanIDDropDownlist, value);
                    break;

                case "PBPID":
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfUIMODViewEditMember.ViewEditMemberPage.PBPIDDropDownlist, value);
                    break;

            }
        }

    [When(@"View Edit Members page Search By Select Drop down list is set to ""(.*)""")]
        public void WhenViewEditMembersPageSearchBySelectDropDownListIsSetTo(string p0)
        {
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p0);
            switch (componentType)
            {
                case "MBI":
                    ReUsableFunctions.clickOnWebElement(cfUIMODViewEditMember.ViewEditMemberPage.MBIorMemSelectBtn);
                    By Option = By.XPath("//li[@role='presentation']/a[contains(.,'"+value+"')]");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Option);
                    break;
                case "Member ID":
                    ReUsableFunctions.clickOnWebElement(cfUIMODViewEditMember.ViewEditMemberPage.MBIorMemSelectBtn);
                    By Option1 = By.XPath("//li[@role='presentation']/a[contains(.,'" + value + "')]");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(Option1);
                    break;
            }

            }


        [When(@"View Edit Members page ""(.*)"" value is set to ""(.*)""")]
        public void WhenViewEditMembersPageValueIsSetTo(string p0, string p1)
        {
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (componentType)
            {
                case "MBI":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODViewEditMember.MemberInformation.MBI, value);
                    break;
                case "Member Id":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODViewEditMember.MemberInformation.MemberID, value);
                    break;
            }
        }


        [Then(@"Verify View Edit Member page has not displayed search results for MBI ""(.*)""")]
        public void ThenVerifyViewEditMemberPageHasNotDisplayedSearchResultsForMBI(string p0)
        {
            string mbi = tmsCommon.GenerateData(p0);
            By searchResults = By.XPath("//div[@test-id='memberSearch-grid-members']//td[contains(.,'"+ mbi + "')]");

            try
            {
               IWebElement results=Browser.Wd.FindElement(searchResults);
                Assert.Fail(" MBI should not be found on Page");
            }
            catch
            {
                Assert.IsTrue(true," Expected Element is not found");
            }
        }
  

        [When(@"View Edit Members page ""(.*)"" Textbox is set to ""(.*)"" using Invalid MBI")]
        public void WhenViewEditMembersPageTextboxIsSetToUsingInvalidMBI(string p0, string p1)
        {
            string componentType = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (componentType)
            {
                case "MBI":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODMemberCreation.UIMODMemberCreation.AddMBI, value);                   
                    break;
            }

        }
        [When(@"View Edit Members page Search Button is Clicked")]
        [Given(@"View Edit Members page Search Button is Clicked")]
        [Then(@"View Edit Members page Search Button is Clicked")]
        public void WhenViewEditMembersPageSearchButtonIsClicked()
        {
            tmsWait.Hard(3);
            ReUsableFunctions.clickOnWebElement(cfUIMODViewEditMember.ViewEditMemberPage.SearchBtn);
            tmsWait.Hard(3);
        }


        [When(@"View Edit Members page ""(.*)"" is disabled")]
        public void WhenViewEditMembersPageIsDisabled(string p0)
        {

            string field = tmsCommon.GenerateData(p0);
            switch(field)
            {
                case "Employer Group Number": Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//input[@test-id='memberDemographics-input-emplGroupNum'][contains(@class,'untouched ')]")).Displayed, "Field is not disabled");
                    break;

                case "Employer Group Name":
                    Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//input[@test-id='memberDemographics-input-employerName'][contains(@class,'untouched ')]")).Displayed, "Field is not disabled");
                    break;
            }
            
    }


        [When(@"View Edit Members page Next page is clicked for search result")]
        public void WhenViewEditMembersPageNextPageIsClickedForSearchResult()
        {
            tmsWait.Hard(5);
            ReUsableFunctions.clickOnWebElement(cfUIMODViewEditMember.ViewEditMemberPage.NextPageSearchResult);
            tmsWait.Hard(5);
        }



        [Then(@"View Edit Members page Note Down ""(.*)"" MBI Value")]
        public void ThenViewEditMembersPageNoteDownMBIValue(int p0)
        {
            GlobalRef.MBI = Browser.Wd.FindElement(By.XPath("(//div[@test-id='memberSearch-grid-members']//td[2]/span)["+p0+"]")).Text;
        }


        [Then(@"Verify Member ""(.*)"" Exist")]
        public void ThenVerifyMemberExist(string p0)
        {
            tmsWait.Hard(5);
            string membercheck = tmsCommon.GenerateData(p0);
            bool ispresent = false;
            try
            {
                if (ConfigFile.tenantType.Equals("tmsx"))
                {
                    ispresent = Browser.Wd.FindElement(By.XPath("//div[@role='presentation']//td[contains(.,'" + membercheck + "')]")).Displayed;
                }
                else
                {
                    ispresent = Browser.Wd.FindElement(By.XPath("(//div[@test-id='memberSearch-grid-members']//td[contains(.,'" + membercheck + "')])[1]")).Displayed;
                }
            
            }

            catch { }

            Assert.IsTrue(ispresent, "Expected "+ membercheck + "Member does not Exist");
        }



        [When(@"View Edit Members page ""(.*)"" Button is Clicked")]
        [Then(@"View Edit Members page ""(.*)"" Button is Clicked")]
        public void ThenViewEditMembersPageButtonIsClicked(string p0)
        {
           

        tmsWait.Hard(5);
            ReUsableFunctions.clickOnWebElement(cfUIMODViewEditMember.ViewEditMemberPage.ViewmemInfo);
            tmsWait.Hard(5);
        }

        [Then(@"View Edit Members page Search results page Any ""(.*)"" is Clicked and Value is noted")]
        public void ThenViewEditMembersPageSearchResultsPageAnyIsClickedAndValueIsNoted(string p0)
        {
            tmsWait.Hard(3);
            By mbi = By.XPath("(//kendo-grid[@test-id='memberSearch-grid-members']//td[1])[1]");
           string MBIValue= UIMODUtilFunctions.returnTextUsingLocators(mbi);
            fw.setVariable(p0, MBIValue);

            By link = By.XPath("(//td/a)[1]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(link);
            tmsWait.Hard(3);
        }

        [Then(@"Verify View Edit Members page ""(.*)"" field is displayed as ""(.*)""")]
        [When(@"Verify View Edit Members page ""(.*)"" field is displayed as ""(.*)""")]
        public void ThenVerifyViewEditMembersPageFieldIsDisplayedAs(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string expectedValue = tmsCommon.GenerateData(p1);
            string actualValue;
            tmsWait.Hard(2);
            switch (field)
            {
               
                case "Member Status":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        tmsWait.Hard(3);

                        By Drp = By.XPath("//span[@test-id='memberInfo-span-memberStatus']");
                        actualValue = Browser.Wd.FindElement(Drp).Text;
                        Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");
                    }
                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfUIMODViewEditMember.MemberInformation.MemberStatus);
                    }
                    break;
                case "Record Source":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        tmsWait.Hard(3);

                        By Drp = By.XPath("//span[@test-id='memberInfo-span-recordSource']");
                        actualValue = Browser.Wd.FindElement(Drp).Text;
                        Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");
                    }
                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(expectedValue, cfUIMODViewEditMember.MemberInformation.RecordSource);
                    }
                    break;
                case "MBI":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        tmsWait.Hard(3);

                        By Drp = By.XPath("//label[contains(.,'MBI')]/parent::div//input");
                         actualValue = Browser.Wd.FindElement(Drp).GetAttribute("value");
                        Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");
                    }
                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODViewEditMember.MemberInformation.MBI);
                    }
                    break;
                case "Member ID":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        tmsWait.Hard(3);

                        By Drp = By.XPath("//label[contains(.,'Member ID')]/parent::div//input");
                         actualValue = Browser.Wd.FindElement(Drp).GetAttribute("value");
                        Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");
                    }
                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODViewEditMember.MemberInformation.MemberID);
                    }
                    break;
                case "FirstName":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        tmsWait.Hard(3);

                        By Drp = By.XPath("(//label[contains(.,'First Name')]/parent::div//input)[1]");
                         actualValue = Browser.Wd.FindElement(Drp).GetAttribute("value");
                        Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");
                    }
                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODViewEditMember.MemberInformation.FirstName);
                    }
                    break;
                case "LastName":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        tmsWait.Hard(3);

                        By Drp = By.XPath("(//label[contains(.,'Last Name')]/parent::div//input)[1]");
                        actualValue = Browser.Wd.FindElement(Drp).GetAttribute("value");
                        Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");
                    }
                    else
                    {
                        ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(expectedValue, cfUIMODViewEditMember.MemberInformation.LastName);
                    }
                    break;

                case "Member sub Status":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        tmsWait.Hard(3);

                        By Drp = By.XPath("//span[@test-id='memberInfo-span-memberStatus']");
                        actualValue = Browser.Wd.FindElement(Drp).Text;
                        Assert.AreEqual(expectedValue, actualValue, " Both values are not matching");
                    }
                    else
                    {
                        IWebElement MembersubStatus = Browser.Wd.FindElement(By.XPath("//sub[@class='memberSubStatusTxt ng-binding']"));


                        Assert.IsTrue(MembersubStatus.Text.Contains(expectedValue));
                    }
                    break;
            }

        }
        [Then(@"View Edit Members page Transactions Section Add New Transaction Is Clicked")]
        public void ThenViewEditMembersPageTransactionsSectionAddNewTransactionIsClicked()
        {
            By AddTransaction = By.XPath("//a[@test-id='transactions-link-AddTransaction']");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(AddTransaction);
        }

        [Then(@"View Edit Members page Search results MBI as ""(.*)"" Plan ID as ""(.*)"" PBP ID as ""(.*)"" Status as ""(.*)"" is Clicked")]
        public void ThenViewEditMembersPageSearchResultsMBIAsPlanIDAsPBPIDAsStatusAsIsClicked(string p0, string p1, string p2, string p3)
        {
            tmsWait.Hard(10);
            string mbi = tmsCommon.GenerateData(p0);
            string planid = tmsCommon.GenerateData(p1);
            string pbp = tmsCommon.GenerateData(p2);
            string active = tmsCommon.GenerateData(p3);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By resultsRow = By.XPath("//table[@role='presentation']//td[contains(.,'" + mbi + "')]/following-sibling::td[contains(.,'" + planid + "')]/following-sibling::td[contains(.,'" + pbp + "')]/following-sibling::td[contains(.,'" + active + "')]/following-sibling::td/a");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(resultsRow);
                tmsWait.Hard(16);

            }
            else
            {
                By resultsRow = By.XPath("//div[@test-id='memberSearch-grid-members']//td[contains(.,'" + mbi + "')]/following-sibling::td[contains(.,'" + planid + "')]/following-sibling::td[contains(.,'" + pbp + "')]/following-sibling::td[contains(.,'" + active + "')]/following-sibling::td/a");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(resultsRow);
                tmsWait.Hard(16);
            }
        }

        [When(@"View Edit Members page Transaction section transaction ""(.*)"" is Opened")]
        public void ThenViewEditMembersPageTransactionSectionTransactionIsOpened(string p0)
        {
            tmsWait.Hard(3);
            string tcCode = tmsCommon.GenerateData(p0.ToString()).ToUpper();

            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By resultsRow = By.XPath("//*[@id='searchMemberGridSection']//td[contains(.,'" + tcCode + "')]//following-sibling::td/a");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(resultsRow);
                tmsWait.Hard(3);
            }
            else
            {
                By resultsRow = By.XPath("//div[@test-id='transactions-grid-memberTransactionsGrid']//td[contains(.,'" + tcCode + "')]//following-sibling::td/a");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(resultsRow);
                tmsWait.Hard(3);
            }
        }

        [Then(@"on View/Edit Transaction page verify ""(.*)"" is displayed as ""(.*)""")]
        public void ThenOnViewEditTransactionPageVerifyIsDisplayedAs(string p0, string p1)
        {
           string fieldName = tmsCommon.GenerateData(p0);
           string value= tmsCommon.GenerateData(p1);
            IWebElement ele=null;
            switch (fieldName)
            {
                case "Transaction Status":
                    ele = Browser.Wd.FindElement(By.XPath("//span[@test-id='transaction-span-transactionStatus']")); //cfUIMODMemberCreation.UIMODTransaction. UIMODMemberTransactionLink;
                break;
                case "Reply Code":
                    ele = cfUIMODMemberCreation.UIMODTransaction.ReplyCodeTextbox;
                break;
                case "Reply Descrip":
                    ele = cfUIMODMemberCreation.UIMODTransaction.ReplyDescTextbox;
                break;
                case "TRR Response Date":
                    ele = cfUIMODMemberCreation.UIMODTransaction.TRRRespDateTextbox;
                break;
                
            }
            Assert.AreEqual(value, ele.Text, "Incorrect value is displayed..");
        }


        [When(@"I have clicked on Add new Transaction link")]
        [When(@"I have clicked on Add new Transaciton link")]
        public void WhenIHaveClickedOnAddNewTransacitonLink()
        {
            ReUsableFunctions.clickOnWebElement(cfUIMODMemberCreation.UIMODMemberCreation.AddNewTransactionLink);
            tmsWait.Hard(7);
        }



        [Then(@"View Edit Members page Search results MBI as ""(.*)"" Plan ID as ""(.*)"" PBP ID as ""(.*)"" MemberID as ""(.*)"" is Clicked")]
        public void ThenViewEditMembersPageSearchResultsMBIAsPlanIDAsPBPIDAsMemberIDAsIsClicked(string p0, string p1, string p2, string p3)
        {
            tmsWait.Hard(5);
            string mbi = tmsCommon.GenerateData(p0).ToUpper();
            string planid = tmsCommon.GenerateData(p1);
            string pbp = tmsCommon.GenerateData(p2);
            string memberId = tmsCommon.GenerateData(p3);
            By resultsRow = By.XPath("//div[@test-id='memberSearch-grid-members']//td[contains(.,'" + mbi + "')]/following-sibling::td[contains(.,'" + planid + "')]/following-sibling::td[contains(.,'" + pbp + "')]/following-sibling::td[contains(.,'" + memberId + "')]/following-sibling::td/a");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(resultsRow);
            tmsWait.Hard(10);
        }

        [When(@"View Edit Members page ""(.*)"" tab is clicked")]
        public void WhenViewEditMembersPageTabIsClicked(string p0)
        {
            string tab = tmsCommon.GenerateData(p0);
            switch(tab.ToUpper())
            {
                case "OOA":
                    ReUsableFunctions.clickOnWebElement(cfUIMODViewEditMember.ViewEditMemberPage.ViewOOABtn);
                    break;
                case "VIEW NOTES AND ACTIONS":
                    ReUsableFunctions.clickOnWebElement(cfUIMODViewEditMember.ViewEditMemberPage.ViewNotesBtn);
                    break;

            }
        }




    }

}



