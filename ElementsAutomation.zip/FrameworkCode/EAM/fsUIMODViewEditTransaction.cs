﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

using TMSoR1.FrameworkCode;
namespace TMSoR1
{
    [Binding]
    class fsUIMODViewEditTransaction
    {

        [Then(@"Verify View Edit Transaction page ""(.*)"" field is displayed as ""(.*)""")]
        public void ThenVerifyViewEditTransactionPageFieldIsDisplayedAs(string p0, string p1)
        {
            tmsWait.Hard(3);
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (field.ToLower()) 
            {
                case "rxgroup":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'Primary Rx Group')]/parent::div//input");
                        string actualValue = Browser.Wd.FindElement(Drp).GetAttribute("value");
                        Assert.AreEqual(value, actualValue, " Both values are not matching");
                    }
                    break;
                case "rxbin":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'Primary Rx BIN')]/parent::div//input");
                        string actualValue = Browser.Wd.FindElement(Drp).GetAttribute("value");
                        Assert.AreEqual(value, actualValue, " Both values are not matching");
                    }
                    break;

                case "rxpcn":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'Primary Rx PCN')]/parent::div//input");
                        string actualValue = Browser.Wd.FindElement(Drp).GetAttribute("value");
                        Assert.AreEqual(value, actualValue, " Both values are not matching");
                    }
                    break;
                case "transaction status": ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(value, cfUIMODCreateTransaction.UIMODCreateTransactionBasic.TransactionStatus);
                                           break; 
                case "mbi": ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(value, cfUIMODCreateTransaction.TransDemographics.MBITextbox);
                            break;

                case "pwoption":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'Prem. Withhold Option')]/parent::div//span[@class='k-input']");
                        string actualValue = Browser.Wd.FindElement(Drp).Text;
                        Assert.AreEqual(value, actualValue, " Both values are not matching");
                        //ReUsableFunctions.compareExpectedValueWithKendoDropDownValue(value, Drp);
                    }
                    else
                            {
                                ReUsableFunctions.compareExpectedValueWithKendoDropDownValue(value, cfUIMODCreateTransaction.TransDemographics.VerifyValueOfPremiumWithHoldOption);
                            }
                            break;

                case "primary rx id":
                    ReUsableFunctions.compareExpectedStringActualWebElementAttributeStringValue(value, cfUIMODCreateTransaction.TransRxDetails.PrimaryRxID);
                    break;

                case "disenrollment reason":
                    ReUsableFunctions.compareExpectedStringActualWebElementGetTextMethod(value, cfUIMODCreateTransaction.TransDemographics.DisenReason);
                    break;

                case "onhold transaction status":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'On-Hold Transaction Status')]/parent::div//span[@class='k-input']");
                        string actualValue = Browser.Wd.FindElement(Drp).Text;
                        Assert.AreEqual(value, actualValue, " Both values are not matching");
                    }
                    break;

                case "onhold reason":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'On-Hold Reason')]/parent::div//span[@class='k-input']");
                        string actualValue = Browser.Wd.FindElement(Drp).Text;
                        Assert.AreEqual(value, actualValue, " Both values are not matching");
                    }
                    break;

                case "date edit override":
                    if (ConfigFile.tenantType.Equals("tmsx"))
                    {
                        By Drp = By.XPath("//label[contains(.,'Date Edit Override')]/parent::div//span[@class='k-input']");
                        string actualValue = Browser.Wd.FindElement(Drp).Text;
                        Assert.AreEqual(value, actualValue, " Both values are not matching");
                    }
                    break;
            }
        }


        [Then(@"on Notes and Actions page ""(.*)"" is set to ""(.*)""")]
        [Then(@"on View Edit Transaction page ""(.*)"" is set to ""(.*)""")]
        public void ThenOnViewEditTransactionPageIsSetTo(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string fieldvalue = tmsCommon.GenerateData(p1);
            switch (field.ToLower())
            {
                case "mbi":
                    string value = fieldvalue.ToUpper();
                    ReUsableFunctions.clickOnWebElement(cfUIMODViewEditMember.ViewEditMemberPage.MBILookup);
                    tmsWait.Hard(3);
                    ReUsableFunctions.enterValueOnWebElementWithoutClear(cfUIMODViewEditMember.MemberLookup.MBI, value);

                    GlobalRef.LTMBI = value;
                    GlobalRef.TransMBI = value;
                    ReUsableFunctions.clickOnWebElement(cfUIMODViewEditMember.MemberLookup.SearchBtn);
                    tmsWait.Hard(1);
                    //By resultGrid = By.XPath("//div[@test-id='member-grid-auditslist']//input[@type='checkbox']");
                    By resultGrid = By.XPath("//div[@test-id='member-grid-auditslist']//td[contains(.,'" + value + "')]/preceding-sibling::td/input");
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(resultGrid);
                    tmsWait.Hard(1);
                    ReUsableFunctions.clickOnWebElement(cfUIMODViewEditMember.MemberLookup.ADDBtn);
                    tmsWait.Hard(1);
                    //IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@id='tagOrSearch']/div/div/input[@class='input ng-valid ng-touched ng-dirty ng-empty']"));
                    //ReUsableFunctions.enterValueOnWebElement(ele, value.ToUpper());
                    break;

                case "transaction status":
                    //ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("//span[@aria-owns='dropdownTransStatus_listbox']")));
                    //UIMODUtilFunctions.selectDropDownValueFromGendoUI(Browser.Wd.FindElement(By.XPath("//span[@aria-owns='dropdownTransStatus_listbox']")), fieldvalue);
                    By Drp = By.XPath("//kendo-dropdownlist[@id='dropdownTransStatus']//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + fieldvalue + "']");
                    fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                    fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                    break;
                case "transaction code":
                    ReUsableFunctions.clickOnWebElement(Browser.Wd.FindElement(By.XPath("//span[@aria-owns='inputBoxTransCode_listbox']")));
                    UIMODUtilFunctions.selectDropDownValueFromGendoUI(Browser.Wd.FindElement(By.XPath("//span[@aria-owns='inputBoxTransCode_listbox']")), fieldvalue);
                    break;
            }
        }

        


        [Then(@"View Edit Transaction page Search Button is Clicked")]
        public void ThenViewEditTransactionPageSearchButtonIsClicked()
        {
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@test-id='transSearch-btn-search']"));
            ReUsableFunctions.clickOnWebElement(ele);
            tmsWait.Hard(5);
        }

        [Then(@"Notes and Actions page Search Button is Clicked")]
        public void ThenNotesAndActionsPageSearchButtonIsClicked()
        {
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//*[@test-id='notesSearch-button-btnSearch']"));
            ReUsableFunctions.clickOnWebElement(ele);
            tmsWait.Hard(5);
        }

        
        [Then(@"View Edit Transaction page Search results MBI as ""(.*)"" Plan ID as ""(.*)"" Status as ""(.*)"" is Clicked")]
        public void ThenViewEditTransactionPageSearchResultsMBIAsPlanIDAsStatusAsIsClicked(string p0, string p1, string p2)
        {
            tmsWait.Hard(25);
            string mbi = tmsCommon.GenerateData(p0).ToUpper();
            string planid = tmsCommon.GenerateData(p1);
            string TransCode = tmsCommon.GenerateData(p2);
            if (ConfigFile.tenantType.Equals("tmsx"))
            {
                By resultsGrid = By.XPath("//div[@role='presentation']//td[contains(.,'" + mbi + "')]/following-sibling::td[contains(.,'" + planid + "')]/following-sibling::td[contains(.,'" + TransCode + "')]//following-sibling::td/a");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(resultsGrid);
            }
            else
            {
                By resultsRow = By.XPath("//*[@id='transactionsDataGrid']//td[contains(.,'" + mbi + "')]/following-sibling::td[contains(.,'" + planid + "')]/following-sibling::td[contains(.,'" + TransCode + "')]/following-sibling::td/a");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(resultsRow);
                tmsWait.Hard(15);
            }
        }

        [Then(@"View Edit Transaction page Search results First MBI Edit Icon is clicked")]
        public void ThenViewEditTransactionPageSearchResultsFirstMBIEditIconIsClicked()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//div[@test-id='transSearch-grid-transactions']//table/tbody/tr[1]/td[9]/a")));
            tmsWait.Hard(3);
        }


        [When(@"View Edit Transaction page ""(.*)"" is set to ""(.*)""")]
        public void WhenViewEditTransactionPageIsSetTo(string p0, string p1)
        {
            string fieldtobeNoted = tmsCommon.GenerateData(p0);
            string valueTobeStored = null;
            switch(fieldtobeNoted.ToLower())
            {
                case "mbi": valueTobeStored = Browser.Wd.FindElement(By.XPath("//input[@test-id='DemographicDetailsMBI']")).GetAttribute("value");
                    break;
                case "pbpid": string valuetobeSplit = Browser.Wd.FindElement(By.XPath("//div[@id='div_DemographicDetailsPbp']/span/span")).Text;
                               string[] splittedValue = valuetobeSplit.Split('-');
                               valueTobeStored = splittedValue[0].Trim();
                               break;
                case "planid":  valueTobeStored = Browser.Wd.FindElement(By.XPath("//div[@id='div_DemographicDetailsPbp']/span/span")).Text; break;
                case "eff date": valueTobeStored = Browser.Wd.FindElement(By.XPath("//input[@id='DemographicDetailsEffectiveDate']")).GetAttribute("value"); break;
            }

            
            fw.setVariable(p0, valueTobeStored);
            tmsWait.Hard(1);
        }


    }
}
