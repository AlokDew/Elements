﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.EAM
{
    [Binding]
    class fsTCTRCConfiguration
    {
        [Then(@"Verify EAM Application displayed ""(.*)"" page successfully")]
        public void ThenVerifyEAMApplicationDisplayedPageSuccessfully(string expected)
        {
            tmsWait.Hard(5);

            IWebElement actualPage = Browser.Wd.FindElement(By.CssSelector("[test-id='actLvlConfg-span-actionConfig']"));
            ReUsableFunctions.compareExpectedStringActualWebElementStringValue(expected, actualPage);
        }

        [When(@"TRR Rules Configuration page ""(.*)"" Option button is Clicked")]
        public void WhenTRRRulesConfigurationPageOptionButtonIsClicked(string p0)
        {
            tmsWait.Hard(5);
            IWebElement button = null;
            if (p0.Contains("TC TRC"))
            {
                button = Browser.Wd.FindElement(By.CssSelector("[test-id='actLevelSearch-lbl-rdbTcTrc']"));
                fw.ExecuteJavascript(button);
            }
            else if (p0.Contains("Action"))
            {
                button = Browser.Wd.FindElement(By.CssSelector("[test-id='actLevelSearch-lbl-rdbAction']"));
                fw.ExecuteJavascript(button);
            }
            else
            {

                Assert.Fail(" Please provide valid Option");
            }
        }


        [When(@"TRR Rules Configuration page ""(.*)"" drop down list is selected as ""(.*)""")]
        public void WhenTRRRulesConfigurationPageDropDownListIsSelectedAs(string Type, string code)
        {
            tmsWait.Hard(5);
            IWebElement drp = null;
            IWebElement drpicon = null;
            if (Type.Contains("TC"))
            {
                drpicon = Browser.Wd.FindElement(By.XPath("//span[@aria-label='select']"));
                fw.ExecuteJavascript(drpicon);
                tmsWait.Hard(2);
                drp = Browser.Wd.FindElement(By.XPath("//li[@role='option'][contains(.,'" + code+"')]"));
                fw.ExecuteJavascript(drp);
                
            }
            else if (Type.Contains("TRC"))
            {
                drpicon = Browser.Wd.FindElement(By.XPath("//ul[@id='mulsltTranReplyCodes_taglist']"));
                fw.ExecuteJavascript(drpicon);
                tmsWait.Hard(2);
                drp = Browser.Wd.FindElement(By.XPath("//li[@role='option'][contains(.,'" + code + "')]"));
                fw.ExecuteJavascript(drp);
            }
        }


        [When(@"TRR Rules Configuration page Click on Search button")]
        public void WhenTRRRulesConfigurationPageClickOnSearchButton()
        {
            IWebElement button = Browser.Wd.FindElement(By.CssSelector("[test-id='actLevelSearch-button-search']"));
            fw.ExecuteJavascript(button);
        }

        [When(@"User Rules Results grid User Settings section ""(.*)"" row Actions link is Clicked")]
        public void WhenUserRulesResultsGridUserSettingsSectionRowActionsLinkIsClicked(string p0)
        {
            tmsWait.Hard(2);
            IWebElement button = Browser.Wd.FindElement(By.XPath("(//table[@role='grid']//td[contains(.,'"+p0+"')]/following-sibling::td/img)[2]"));
            fw.ExecuteJavascript(button);
            tmsWait.Hard(5);
        }
        bool setCheckboxTo = false;
        public void clickOnCheckbox(IWebElement elem, bool checkboxStatus)
        {
            if (checkboxStatus)
            {
                if (!elem.Selected)
                {
                    fw.ExecuteJavascript(elem);
                }
            }
            else if (!checkboxStatus)
            {
                
                if (elem.Selected)
                {
                    fw.ExecuteJavascript(elem);
                }
            }

        }

        [When(@"Edit TRR Rules Configuration page Update button is Clicked")]
        public void WhenEditTRRRulesConfigurationPageUpdateButtonIsClicked()
        {
            IWebElement update = Browser.Wd.FindElement(By.CssSelector("[test-id='editAction-button-update']"));
            fw.ExecuteJavascript(update);
            tmsWait.Hard(1);

        }
        [When(@"Members View Edit Page resulted MBI is Clicked")]
        public void WhenMembersViewEditPageResultedMBIIsClicked()
        {
            tmsWait.Hard(5);
            IWebElement update = Browser.Wd.FindElement(By.XPath("//img[@title='click here to edit this member information.']"));
            fw.ExecuteJavascript(update);
        }


        [Then(@"Verify TRR Rules Configuration page displayed Toaster message as ""(.*)""")]
        public void ThenVerifyTRRRulesConfigurationPageDisplayedToasterMessageAs(string msg)
        {
            IWebElement toastermsg = Browser.Wd.FindElement(By.XPath("//div[@class='toast-message'][contains(.,'"+msg+"')]"));
            bool toasterDisplayed = toastermsg.Displayed;
            Assert.IsTrue(toasterDisplayed, msg + "  is not getting displayed");
            tmsWait.Hard(5);
        }


        [When(@"Edit TRR Rules Configuration page ""(.*)"" checkbox is ""(.*)""")]
        public void WhenEditTRRRulesConfigurationPageCheckboxIs(string usersettings, string checkboxAction)
        {


            IWebElement checkbox = null;

            switch (checkboxAction.ToLower())
            {
                case "checked": { setCheckboxTo = true; break; }
                case "on": { setCheckboxTo = true; break; }
                case "yes": { setCheckboxTo = true; break; }
                case "unchecked": { setCheckboxTo = false; break; }
                case "off": { setCheckboxTo = false; break; }
                case "no": { setCheckboxTo = false; break; }
            }

            if (usersettings.Contains("CMS Intiated"))
            {
                checkbox = Browser.Wd.FindElement(By.CssSelector("[test-id='editUserAction-checkbox-cmsInitiated']"));

                clickOnCheckbox(checkbox, setCheckboxTo);

            }

            if (usersettings.Contains("Plan Intiated"))
            {
                checkbox = Browser.Wd.FindElement(By.Id("chkPlanInitiated"));

                clickOnCheckbox(checkbox, setCheckboxTo);

            }




        }


        [When(@"TRR Rules Configuration page ""(.*)"" tab is Clicked")]
        public void WhenTRRRulesConfigurationPageTabIsClicked(string p0)
        {
            IWebElement button = null;
           if(p0.Contains("USER RULES"))
            {
                button = Browser.Wd.FindElement(By.CssSelector("[test-id='actLevelSearch-btn-btnUserAction']"));
                fw.ExecuteJavascript(button);
            }
           else if (p0.Contains("MANDATORY RULES"))
            {
                button = Browser.Wd.FindElement(By.CssSelector("[test-id='actLevelSearch-btn-btnMandatoryAction']"));
                fw.ExecuteJavascript(button);
            }
           else
            {
               
                Assert.Fail(" Please provide valid Option");
            }
        }


        [When(@"TRR Field Configuration page ""(.*)"" drop down list is selected as ""(.*)""")]
        public void WhenTRRFieldConfigurationPageDropDownListIsSelectedAs(string p0, string p1)
        {
            string field = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);

            switch(field.ToLower())
            {
                case "tc":
                    By Drp = By.XPath("//kendo-dropdownlist[@id='drpTransactionCodes']//span[@class='k-select']");
                    By typeapp = By.XPath("//li[text()='" + value + "']");
                    fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
                    fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
                    break;



                case "trc":

                    By Drp1 = By.XPath("//kendo-dropdownlist[@id='drpTransactionReplyCodes']//span[@class='k-select']");
                    By typeapp1 = By.XPath("//li[text()='" + value + "']");
                    fw.ExecuteJavascript(Browser.Wd.FindElement(Drp1));
                    fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp1));
                    break;
            }
            
        }

        [When(@"TRR Field Configuration page Click on Search button")]
        public void WhenTRRFieldConfigurationPageClickOnSearchButton()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//button[@test-id='trrConfigurationFieldSearchField-btn-btnSearch']")));
            tmsWait.Hard(3);
        }

        [When(@"TRR Field Configuration page Click on Next button")]
        public void WhenTRRFieldConfigurationPageClickOnNextButton()
        {
            fw.ExecuteJavascript(Browser.Wd.FindElement(By.XPath("//span[@aria-label='Go to the next page']")));
            tmsWait.Hard(3);
        }

        [Then(@"Verify TRR Field Configuration Grid Displayed with ""(.*)"" and ""(.*)""")]
        public void ThenVerifyTRRFieldConfigurationGridDisplayedWithAnd(string p0, string p1)
        {
            Boolean ispresent = false;
            try
            {
                ispresent = Browser.Wd.FindElement(By.XPath("//kendo-grid[@test-id='trrConfigurationFieldSearchField-grid-dgFieldsConfiguration']//td[contains(.,'" + p0 + "')]/parent::tr//td[contains(.,'" + p1 + "')]")).Displayed;
            }

            catch
            {
                Console.WriteLine("No matching Row Found");
            }


            
        }

    }
}
