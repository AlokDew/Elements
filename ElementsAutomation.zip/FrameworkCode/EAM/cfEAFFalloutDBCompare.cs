﻿using System;
//using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows;
using System.Drawing;
//using System.Windows.Forms;
using OpenQA.Selenium.Support.UI;
using System.Collections.ObjectModel;
using OpenQA.Selenium.Interactions;
using System.Text;
using System.Linq;
using System.Globalization;
using TMSoR1.FrameworkCode;
using System.Data.SqlClient;
using Microsoft.VisualStudio.TestTools.UnitTesting;


namespace TMSoR1
{
    [Binding]

    class cfEAFFalloutDBCompare
    {
        public Dictionary<string, string> ElecAppFileTableSrc = new Dictionary<string, string>();
        public Dictionary<string, string> EnrlMngFalloutDataDes = new Dictionary<string, string>();

        [When(@"Fetch record from DB table and store into dictionary variable ""(.*)"" with query ""(.*)""")]
        [Then(@"Fetch record from DB table and store into dictionary variable ""(.*)"" with query ""(.*)""")]

        public void WhenFetchRecordFromDBTableAndStoreIntoDictionaryVariableWithQuery(string p0, string p1)
        {

            string dbQuery = tmsCommon.GenerateData(p1);
            db.CreateConnRAMX("EAM");
            db.AddDBQuery("EAM", dbQuery);

            if (p0 == "SrcRecord")
            {
                ElecAppFileTableSrc = db.OutputDBResultsToDic("EAM");
            }
            else if (p0 == "DesRecord")
            {
                EnrlMngFalloutDataDes = db.OutputDBResultsToDic("EAM");
            }

        }

        [When(@"update ""(.*)"" field ""(.*)"" value as ""(.*)""")]
        public void WhenUpdateFieldValueAs(string p0, string p1, string p2)
        {

            if (p0.Equals("SrcRecord"))
            {
                if (ElecAppFileTableSrc.ContainsKey(p1))
                {
                    ElecAppFileTableSrc[p1] = p2;
                }

            }
        }


        [Then(@"Verify ""(.*)"" and ""(.*)"" tables Data")]
        public void ThenVerifyAndTablesData(string p0, string p1)
        {
            if ((p0 == "SrcRecord") && (p1 == "DesRecord"))
            {
                for (int srcKey = 1; srcKey <= ElecAppFileTableSrc.Count - 1; srcKey++)
                {
                    if (EnrlMngFalloutDataDes.ContainsKey(ElecAppFileTableSrc.ElementAt(srcKey).Key))
                    {
                        switch ((ElecAppFileTableSrc.ElementAt(srcKey).Key).ToString())
                        {
                            case "":
                                break;

                            case "EntityId":

                                if (EnrlMngFalloutDataDes[ElecAppFileTableSrc.ElementAt(srcKey).Key] != "" && ElecAppFileTableSrc.ElementAt(srcKey).Value == "")
                                { }
                                else if ((ElecAppFileTableSrc.ElementAt(srcKey).Value).ToLower() != (EnrlMngFalloutDataDes[ElecAppFileTableSrc.ElementAt(srcKey).Key]).ToLower())
                                {
                                    Assert.Fail("The coulmn key '" + ElecAppFileTableSrc.ElementAt(srcKey).Key + "' is not matching with its values, EXPECTED '" + (ElecAppFileTableSrc.ElementAt(srcKey).Value) + "' but ACTUAL '" + EnrlMngFalloutDataDes[ElecAppFileTableSrc.ElementAt(srcKey).Key] + "'");
                                    //Console.WriteLine("MISMATCH == " + ElecAppFileTableSrc.ElementAt(srcKey).Key + " <==> " + ElecAppFileTableSrc.ElementAt(srcKey).Value + " | " + EnrlMngFalloutDataDes[ElecAppFileTableSrc.ElementAt(srcKey).Key]);
                                }
                                break;

                            case "ApplicantCounty":

                                if (EnrlMngFalloutDataDes[ElecAppFileTableSrc.ElementAt(srcKey).Key] != "" && ElecAppFileTableSrc.ElementAt(srcKey).Value == "")
                                { }
                                else if ((ElecAppFileTableSrc.ElementAt(srcKey).Value).ToLower() != (EnrlMngFalloutDataDes[ElecAppFileTableSrc.ElementAt(srcKey).Key]).ToLower())
                                {
                                    Assert.Fail("The coulmn key '" + ElecAppFileTableSrc.ElementAt(srcKey).Key + "' is not matching with its values, EXPECTED '" + (ElecAppFileTableSrc.ElementAt(srcKey).Value) + "' but ACTUAL '" + EnrlMngFalloutDataDes[ElecAppFileTableSrc.ElementAt(srcKey).Key] + "'");
                                    //Console.WriteLine("MISMATCH == " + ElecAppFileTableSrc.ElementAt(srcKey).Key + " <==> " + ElecAppFileTableSrc.ElementAt(srcKey).Value + " | " + EnrlMngFalloutDataDes[ElecAppFileTableSrc.ElementAt(srcKey).Key]);
                                }
                                break;

                            case "FiveStarPlan":
                                if (ElecAppFileTableSrc.ElementAt(srcKey).Value == "" && EnrlMngFalloutDataDes[ElecAppFileTableSrc.ElementAt(srcKey).Key].ToUpper() == "NO")
                                { }
                                else if ((ElecAppFileTableSrc.ElementAt(srcKey).Value).ToLower() != (EnrlMngFalloutDataDes[ElecAppFileTableSrc.ElementAt(srcKey).Key]).ToLower())
                                {
                                    Assert.Fail("The coulmn key '" + ElecAppFileTableSrc.ElementAt(srcKey).Key + "' is not matching with its values, EXPECTED '" + (ElecAppFileTableSrc.ElementAt(srcKey).Value) + "' but ACTUAL '" + EnrlMngFalloutDataDes[ElecAppFileTableSrc.ElementAt(srcKey).Key] + "'");
                                    //Console.WriteLine("MISMATCH == " + ElecAppFileTableSrc.ElementAt(srcKey).Key + " <==> " + ElecAppFileTableSrc.ElementAt(srcKey).Value + " | " + EnrlMngFalloutDataDes[ElecAppFileTableSrc.ElementAt(srcKey).Key]);
                                }
                                break;

                            default:
                                if ((ElecAppFileTableSrc.ElementAt(srcKey).Value).ToLower() != (EnrlMngFalloutDataDes[ElecAppFileTableSrc.ElementAt(srcKey).Key]).ToLower())
                                {
                                    Assert.Fail("The coulmn key '" + ElecAppFileTableSrc.ElementAt(srcKey).Key + "' is not matching with its values, EXPECTED '" + (ElecAppFileTableSrc.ElementAt(srcKey).Value) + "' but ACTUAL '" + EnrlMngFalloutDataDes[ElecAppFileTableSrc.ElementAt(srcKey).Key] + "'");
                                    //Console.WriteLine("MISMATCH == " + ElecAppFileTableSrc.ElementAt(srcKey).Key + " <==> " + ElecAppFileTableSrc.ElementAt(srcKey).Value + " | " + EnrlMngFalloutDataDes[ElecAppFileTableSrc.ElementAt(srcKey).Key]);
                                }
                                break;
                        }
                    }
                    else
                    {
                        Assert.Fail("The column key not found :" + ElecAppFileTableSrc.ElementAt(srcKey).Key);
                        //Console.WriteLine("key not found  " + ElecAppFileTableSrc.ElementAt(srcKey).Key);
                    }
                }
            }
        }

        [When(@"""(.*)"" page ""(.*)"" is set as ""(.*)""")]
        public void WhenPageIsSetAs(string p0, string p1, string p2)
        {
            By DatePicker = null;
            String Page = tmsCommon.GenerateData(p0);
            String Field = tmsCommon.GenerateData(p1);
            String[] arrDate = tmsCommon.GenerateData(p2).Trim().Split('/');

            String strDate = (arrDate[1].StartsWith("0")) ? arrDate[1].Substring(1, 1) : arrDate[1];
            String strMonth = CultureInfo.CurrentCulture.DateTimeFormat.GetAbbreviatedMonthName(Int32.Parse(arrDate[0]));
            Boolean PreDecadeYear = (Int32.Parse(arrDate[2]) % 10).Equals(0) ? true : false;


            By YearIcon = By.CssSelector(".k-bare");
            By PreYearTrue = By.XPath("//td/span");
            By Month = By.XPath("//span[text()='" + strMonth + "']");
            By Date = By.XPath("//span[text()='" + strDate + "']");
            By Year = By.XPath("//span[starts-with(.,'" + arrDate[2] + "')]");
            By PreYearFalse = By.XPath("//span[contains(.,'" + (Int32.Parse(arrDate[2]) - (Int32.Parse(arrDate[2]) % 10)).ToString() + "')]");


            switch (Page.ToUpper() + "-" + Field.ToUpper())
            {
                case "TRANSACTIONS-SIGNATUREDATE":

                    DatePicker = By.CssSelector("#DemographicDetailsSignatureDate .k-icon");
                    break;

                case "TRANSACTIONS-RECEIPTDATE":

                    DatePicker = By.CssSelector("#DemographicDetailsReceiptDate .k-icon");
                    break;

                default:
                    break;
            }

            UIMODUtilFunctions.clickOnWebElementUsingLocators(DatePicker);
            for (int i = 0; i < 3; i++)
            {
                UIMODUtilFunctions.clickOnWebElementUsingLocators(YearIcon);
            }
            if (PreDecadeYear.Equals(true))
            {
                UIMODUtilFunctions.clickOnWebElementUsingLocators(Year);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(PreYearTrue);
            }
            else
            {
                UIMODUtilFunctions.clickOnWebElementUsingLocators(PreYearFalse);
                UIMODUtilFunctions.clickOnWebElementUsingLocators(Year);
            }

            UIMODUtilFunctions.clickOnWebElementUsingLocators(Month);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(Date);


        }

    }
}

