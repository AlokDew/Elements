﻿
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using TMSoR1.FrameworkCode;
using TMSoR1.FrameworkCode.ADFS;


namespace TMSoR1
{
    [Binding]
    class fsUserManagementAngular
    {

        [When(@"Root Administration Menu External System sub menu Identity Server Sub menu is Clicked")]
        public void WhenRootAdministrationMenuExternalSystemSubMenuIdentityServerSubMenuIsClicked()
        {
            By Root = By.CssSelector("[title='Root Administration']");
            By externalSystem = By.XPath("//span[contains(.,'External Systems')]");
            By idServer = By.XPath("//span[contains(.,'Identity Server')]");
            UIMODUtilFunctions.clickOnWebElementUsingLocators(Root);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(externalSystem);
            UIMODUtilFunctions.clickOnWebElementUsingLocators(idServer);
            
            string tenantName = "Identity Server_" + ((ConfigFile.URL.Split('.'))[0].Split(':'))[1].Substring(2);
            string splTenantName = "Identity Server_" + ((ConfigFile.URL.Split('.'))[0].Split(':'))[1].Substring(2).ToUpper();
            tmsWait.Hard(2);
            try
            {
                By path = By.XPath("//kendo-grid//table[@role='presentation']//td[contains(.,'" + tenantName + "')]/following-sibling::td/a[1]");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(path);
            }
            catch
            {
                By path = By.XPath("//kendo-grid//table[@role='presentation']//td[contains(.,'" + splTenantName + "')]/following-sibling::td/a[1]");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(path);
            }
            tmsWait.Hard(5);
            Browser.SwitchToWindow(1);
            tmsWait.Hard(5);
        }

        [When(@"User Management page Add User button is Clicked")]
        public void WhenUserManagementPageAddUserButtonIsClicked()
        {
            tmsWait.Hard(5);
            ///Browser.SwitchToWindow(1);
            fw.ExecuteJavascript(cfUserManagementAngular.UserManagementAngular.addUser);
        }

        [When(@"User Management page User List section Clicked on ""(.*)"" link")]
        public void WhenUserManagementPageUserListSectionClickedOnLink(string p0)
        {
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//a[@title='"+p0+"']"));
            fw.ExecuteJavascript(ele);
            tmsWait.Hard(2);
        }

        [When(@"User Management page User List section Existing User ""(.*)"" is Edited")]
        public void WhenUserManagementPageUserListSectionExistingUserIsEdited(string p0)
        {
            string username = tmsCommon.GenerateData(p0);
            IWebElement ele = Browser.Wd.FindElement(By.XPath("//tr//td[contains(.,'" + username + "')]/following-sibling::td/a/span[@class='fas fa-pencil-alt']"));
            fw.ExecuteJavascript(ele);
            tmsWait.Hard(2);
            
        }

        [When(@"User Management page Click on No option button under Active section")]
        public void WhenUserManagementPageClickOnNoOptionButtonUnderActiveSection()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(cfUserManagementAngular.UserManagementAngular.NoActive);
            tmsWait.Hard(5);
        }


        [When(@"User Management page Clicked on UPDATE button")]
        public void WhenUserManagementPageClickedOnUPDATEButton()
        {
            tmsWait.Hard(2);
            fw.ExecuteJavascript(cfUserManagementAngular.UserManagementAngular.UPDATE);
            tmsWait.Hard(2);
        }


        [When(@"User Management page Login Name is set to ""(.*)""")]
        public void WhenUserManagementPageLoginNameIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);

            UIMODUtilFunctions.enterValueOnWebElementUsingWebElement(cfUserManagementAngular.UserManagementAngular.loginName, value);
        }

        [When(@"User Management page New Password is set to ""(.*)""")]
        public void WhenUserManagementPageNewPasswordIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);

            UIMODUtilFunctions.enterValueOnWebElementUsingWebElement(cfUserManagementAngular.UserManagementAngular.password, value);
        }

        [When(@"User Management page Confirm New Password is set to ""(.*)""")]
        public void WhenUserManagementPageConfirmNewPasswordIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);

            UIMODUtilFunctions.enterValueOnWebElementUsingWebElement(cfUserManagementAngular.UserManagementAngular.confirmPassword, value);
        }

        [When(@"User Management page Display Name is set to ""(.*)""")]
        public void WhenUserManagementPageDisplayNameIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);

            UIMODUtilFunctions.enterValueOnWebElementUsingWebElement(cfUserManagementAngular.UserManagementAngular.displayName, value);
        }

        [When(@"User Management page First Name is set to ""(.*)""")]
        public void WhenUserManagementPageFirstNameIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);

            UIMODUtilFunctions.enterValueOnWebElementUsingWebElement(cfUserManagementAngular.UserManagementAngular.firstName, value);
        }

        [When(@"User Management page Last Name is set to ""(.*)""")]
        public void WhenUserManagementPageLastNameIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);

            UIMODUtilFunctions.enterValueOnWebElementUsingWebElement(cfUserManagementAngular.UserManagementAngular.lastName, value);
        }

        [When(@"User Management page Email Id is set to ""(.*)""")]
        public void WhenUserManagementPageEmailIdIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);

            UIMODUtilFunctions.enterValueOnWebElementUsingWebElement(cfUserManagementAngular.UserManagementAngular.emailID, value);
        }

        [When(@"User Management page Phone number is set to ""(.*)""")]
        public void WhenUserManagementPagePhoneNumberIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);

            UIMODUtilFunctions.enterValueOnWebElementUsingWebElement(cfUserManagementAngular.UserManagementAngular.phone, value);
        }

        [When(@"User Management page Active User Button is Clicked")]
        public void WhenUserManagementPageActiveUserButtonIsClicked()
        {
            fw.ExecuteJavascript(cfUserManagementAngular.UserManagementAngular.activeYesOptionButton);
        }

        [When(@"User Management page Role Drop down is selected as ""(.*)""")]
        public void WhenUserManagementPageRoleDropDownIsSelectedAs(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            tmsWait.Hard(2);
            //ReUsableFunctions.selectDropDownValueUsingAngularChanges(cfUserManagementAngular.UserManagementAngular.RoleDropdown, value);
            
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='edit-user-select-role']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + value + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            tmsWait.Hard(2);

        }

        [When(@"User Management page Add Record button is Clicked")]
        public void WhenUserManagementPageAddRecordButtonIsClicked()
        {
            fw.ExecuteJavascript(cfUserManagementAngular.UserManagementAngular.AddRecordButton);
        }

        [When(@"Add Record section Application Id Drop down is set to ""(.*)""")]
        public void WhenAddRecordSectionApplicationIdDropDownIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            ReUsableFunctions.selectDropDownValueUsingContainsTextAngularChanges(cfUserManagementAngular.UserManagementAngular.ApplicantID, value);

        }

        [When(@"Add Record section Role Name Drop down is set to ""(.*)""")]
        public void WhenAddRecordSectionRoleNameDropDownIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            ReUsableFunctions.selectDropDownValueUsingContainsTextAngularChanges(cfUserManagementAngular.UserManagementAngular.RoleName, value);
        }

        [When(@"Add Record section Save button is Clicked")]
        public void WhenAddRecordSectionSaveButtonIsClicked()
        {
            fw.ExecuteJavascript(cfUserManagementAngular.UserManagementAngular.SaveButton);
        }

        [When(@"Added ""(.*)"" Application is deleted")]
        public void WhenAddedApplicationIsDeleted(string p0)
        {
            //IWebElement ram = Browser.Wd.FindElement(By.XPath("//form[@id='applicationAndRolesFrm']//td[contains(.,'"+p0+"')]/following-sibling::td//a/span[@class='fas fa-trash']"));
            IWebElement ram = Browser.Wd.FindElement(By.XPath("//form[@id='applicationAndRolesFrm']//td[contains(.,'" + p0 + "')]/following-sibling::td//button/span[@class='fas fa-trash']"));
            AngularFunction.clickOnElement(ram);
            tmsWait.Hard(2);

        }

        [Then(@"Verify ""(.*)"" application is not present")]
        public void ThenVerifyApplicationIsNotPresent(string p0)
        {
           By app= By.XPath("//form[@id='applicationAndRolesFrm']//td[contains(.,'" + p0 + "')]");
             AngularFunction.elementNotPresenceUsingLocators(app);
        }


        [When(@"Map EAM Role section Roles drop down is selected as ""(.*)""")]
        public void WhenMapEAMRoleSectionRolesDropDownIsSelectedAs(string p0)
        {
            tmsWait.Hard(5);
            string value = tmsCommon.GenerateData(p0);
            ReUsableFunctions.selectDropDownValueUsingAngularChanges(cfUserManagementAngular.UserManagementAngular.MapEAMRoleDropdown, value);
        }

        [When(@"Set Default Application Applicaitons Drop down is selected as  ""(.*)""")]
        public void WhenSetDefaultApplicationApplicaitonsDropDownIsSelectedAs(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            ReUsableFunctions.selectDropDownValueUsingAngularChanges(cfUserManagementAngular.UserManagementAngular.SetDefaultApplication, value);
        }

        [When(@"EAM Applications ""(.*)"" check box is ""(.*)""")]
        public void WhenEAMApplicationsCheckBoxIs(string p0, string p1)
        {
            tmsWait.Hard(8);
           if(p0.Contains("TC90 App"))
            {
                AngularFunction.clickOnElement(cfUserManagementAngular.UserManagementAngular.TC90Checkbox);                   

            }
           else if(p0.Contains("Status Override"))
            {
                AngularFunction.clickOnElement(cfUserManagementAngular.UserManagementAngular.StatusOverrideCheckbox);

            }
        }


        [When(@"Clicked on ADD Button")]
        public void WhenClickedOnADDButton()
        {
            fw.ExecuteJavascript(cfUserManagementAngular.UserManagementAngular.ADDButton);
            tmsWait.Hard(3);
        }
    }


    
}
