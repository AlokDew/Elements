﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TMSoR1.FrameworkCode.ADFS
{
    class cfADFSLogin
    {

        public static ADFSLoginPage ADFSLoginPage { get { return new ADFSLoginPage(); } }
        public static IdentityProviderAdminPage IdentityProviderAdminPage { get { return new IdentityProviderAdminPage(); } }
    }

    [Binding]
    public class IdentityProviderAdminPage
    {
        public IWebElement ClaimTransformationSettings { get { return Browser.Wd.FindElement(By.XPath("//span[contains(text(),'Claim Transformation Settings')]")); } }
        public IWebElement ConfigureIdentityProvider { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='identityProvider-li-configureIdentityProvider']")); } }
        public IWebElement RuleName { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='claimTransformationSettings-Input-ruleName']")); } }

        public IWebElement TransformIncomingClaimOpt { get { return Browser.Wd.FindElement(By.XPath("//div[@test-id='claimTransformationSettings-lbl-transformIncommingClaim']/input[@test-id='claimTransformationSettings-radio-transformIncommingClaim']")); } }
        public IWebElement TransformIncomingClaimValueOpt { get { return Browser.Wd.FindElement(By.XPath("(//label[@test-id='claimTransformationSettings-lbl-transformIncommingClaim']/span)[2]")); } }
        public IWebElement ApplyregularexpressiononallexternalclaimtypeOpt { get { return Browser.Wd.FindElement(By.XPath("//label[@test-id='claimTransformationSettings-lbl-regularExpressionType']/span")); } }
        public IWebElement ExternalClaimType { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='claimTransformationSettings-Input-externalClaimType']")); } }
        public IWebElement TMSClaimType { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='claimTransformationSettings-txt-ddlTmsClaimType']")); } }
        public IWebElement Passthroughallclaimvalues { get { return Browser.Wd.FindElement(By.XPath("/label[@test-id='claimTransformationSettings-lbl-passthruClaimValues']/span")); } }

        public IWebElement ADD { get { return Browser.Wd.FindElement(By.CssSelector("[id='btnAddClaim']")); } }
        public IWebElement UPDATE { get { return Browser.Wd.FindElement(By.CssSelector("[id='btnUpdateClaim']")); } }
        
        public IWebElement IdentityProviderAdministration { get { return Browser.Wd.FindElement(By.XPath("//i[@test-id='menu-3']")); } }
        public IWebElement TenantConfiguration { get { return Browser.Wd.FindElement(By.CssSelector("a[title='Tenant Configuration']")); } }
        public IWebElement Pattern { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='claimTransformationSettings-Input-regPattern']")); } }
        public IWebElement Replacement { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='claimTransformationSettings-Input-regreplacement']")); } }
        public IWebElement ApplyregularexpressiononallexternalclaimtypeOption { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='claimTransformationSettings-radio-regularExpressionType']")); } }
        public IWebElement TransformIncomingClaimValueOption { get { return Browser.Wd.FindElement(By.XPath("//div[@id='transformIncommingClaimValue']/label")); } }
        public IWebElement ExternalClaimTypeTextBox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='claimTransformationSettings-input-claimValueExternalClaimType']")); } }
        public IWebElement ClaimTypeSettingsExternalClaimTypeTextBox { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='claimTransformationSettings-Input-claimValueExternalClaimType']")); } }
        public IWebElement PassthroughallclaimvaluesOption { get { return Browser.Wd.FindElement(By.XPath("//label[@for='rdbClaimValuePassthruClaimValues']/span")); } }
        public IWebElement PassthroughonlyspecificclaimvalueOption { get { return Browser.Wd.FindElement(By.XPath("//label[@for='rdbClaimValueReplaceSpecificClaimValue']/span")); } }

        public IWebElement ExternalClaimValueTextBox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='claimTransformationSettings-Input-externalClaimValue']")); } }
        public IWebElement TMSClaimValueTextBox { get { return Browser.Wd.FindElement(By.CssSelector("[test-id='claimTransformationSettings-Input-tmsClaimValue']")); } }
        public IWebElement ReplaceanExternalClaimValuewithTMSClaimvalueOption { get { return Browser.Wd.FindElement(By.XPath("//div[@test-id='claimTransformationSettings-lbl-replaceincomingoutgoingclaimvalue']/input[@test-id='claimTransformationSettings-radio-passthruClaimValues']")); } }
        public IWebElement ApplyregularexpressiononexternalclaimvalueOption { get { return Browser.Wd.FindElement(By.XPath("//label[@for='rdbReplaceincomingRegular']/span")); } }
        public IWebElement PassthroughonlyspecificclaimvalueOptionButton { get { return Browser.Wd.FindElement(By.XPath("//div[@id='rblReplaceincomingoutgoingclaimvalue']/label")); } }

        public IWebElement ExternalClaimValue { get { return Browser.Wd.FindElement(By.CssSelector("[id='txtClaimValueExternalClaimValue']")); } }
        public IWebElement UserTypeFilterType { get { return Browser.Wd.FindElement(By.XPath("(//a[@title='Filter'])[2]")); } }

        public IWebElement UserTypeFilterTextbox { get { return Browser.Wd.FindElement(By.XPath("//kendo-grid-string-filter-menu-input[1]/kendo-grid-filter-menu-input-wrapper/input")); } }

        public IWebElement FilterSubmitButton { get { return Browser.Wd.FindElement(By.XPath("//button[@type='submit']")); } }

        public IWebElement claimTransformationRuleGrid { get { return Browser.Wd.FindElement(By.XPath("//div[@role='grid']")); } }

        public IWebElement ruleGridUpArrow { get { return Browser.Wd.FindElement(By.XPath("//*[@class='fa  fa-arrow-up k-grid-customCommand upArrowMargin upDownArrowBtn']")); } }

        public IWebElement ruleGridDownArrow { get { return Browser.Wd.FindElement(By.XPath("//*[@class='fa  fa-arrow-down upDownArrowBtn k-grid-customCommand']")); } }

        public IWebElement identityProviderOpenIDRadio { get { return Browser.Wd.FindElement(By.XPath("//input[@test-id='configureIdentityProvider-radio-openIDConnect']")); } }

        public IWebElement identityProviderOpenID { get { return Browser.Wd.FindElement(By.Id("openIDConnect")); } }

        public IWebElement identityProviderWSSecurity{ get { return Browser.Wd.FindElement(By.XPath("//div[@id='wsSecurityD']/label")); } }

        public IWebElement identityProviderEnableLocalAuthentication { get { return Browser.Wd.FindElement(By.XPath("//span[@class='k-switch-label-on']")); } }

        public IWebElement identityProviderAddButten { get { return Browser.Wd.FindElement(By.Id("btnAddProvider")); } }

        public IWebElement openIdConnectProviderPopup{ get { return Browser.Wd.FindElement(By.XPath("//span[contains(text(),'Add OpenID Connect Provider')]")); } }

        public IWebElement openIdConnectProviderSaveBtn { get { return Browser.Wd.FindElement(By.Id("wsSecurityProviderbtnSave")); } }

       
        public IWebElement openIdConnectProviderCloseBtn { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='searchProvider-btn-close']")); } }

    
        public IWebElement openIdConnectProviderUpdateBtn { get { return Browser.Wd.FindElement(By.XPath("//button[@test-id='searchProvider-btn-update']")); } }
        public IWebElement WSUpdateBtn { get { return Browser.Wd.FindElement(By.Id("btnSave")); } }

        public IWebElement openIdConnectProviderCaption { get { return Browser.Wd.FindElement(By.Id("txtCaption")); } }
        public IWebElement openIdConnectProviderClientId { get { return Browser.Wd.FindElement(By.Id("txtClientId")); } }
        public IWebElement openIdConnectProviderAuthority { get { return Browser.Wd.FindElement(By.Id("txtAuthority")); } }
        public IWebElement openIdConnectProviderChangePwdURL{ get { return Browser.Wd.FindElement(By.Name("txtChangePasswordURL")); } }

        public IWebElement openIdConnectProviderRedirectURI { get { return Browser.Wd.FindElement(By.Name("txtRedirectURI")); } }

        public IWebElement openIdConnectProviderActiveCheckbox { get { return Browser.Wd.FindElement(By.Id("chkActive")); } }

        public IWebElement openIdConnectProviderScope { get { return Browser.Wd.FindElement(By.Id("txtScope")); } }

        public IWebElement openIdConnectProviderResponseType { get { return Browser.Wd.FindElement(By.Id("txtResponseType")); } }

        public IWebElement WSAddProviderPopup { get { return Browser.Wd.FindElement(By.XPath("//span[contains(text(),'Add WS Security (WS*) Provider')]")); } }
        public IWebElement WSWtrelam { get { return Browser.Wd.FindElement(By.Name("txtWtrelam")); } }
        public IWebElement WSMetadata { get { return Browser.Wd.FindElement(By.Name("txtMetadata")); } }

        public IWebElement WSSaveButton { get { return Browser.Wd.FindElement(By.Id("wsSecurityProviderbtnSave")); } }

        public IWebElement WSCloseButton { get { return Browser.Wd.FindElement(By.XPath("//*[@test-id='wsSecurityProvider-btn-cancel']")); } }



    }


    [Binding]
    public class ADFSLoginPage
    {
        public IWebElement loginWithADFSButton { get { return Browser.Wd.FindElement(By.XPath("//button[contains(.,'Login With ADFS')]")); } }
        public IWebElement username { get { return Browser.Wd.FindElement(By.Id("userNameInput")); } }
        public IWebElement password { get { return Browser.Wd.FindElement(By.Id("passwordInput")); } }
        public IWebElement signInButton { get { return Browser.Wd.FindElement(By.Id("submitButton")); } }
        public IWebElement errorMsg { get { return Browser.Wd.FindElement(By.XPath("//div[@class='text-danger']/div")); } }
        public IWebElement errorBindMsg { get { return Browser.Wd.FindElement(By.XPath("//app-error-page//p[@class='card-text']")); } }
        public IWebElement logoutButton { get { return Browser.Wd.FindElement(By.XPath("//app-error-page//a[contains(.,'here')]")); } }
        public IWebElement logoutMessage{ get { return Browser.Wd.FindElement(By.XPath("//app-loggedout/h4")); } }

        public IWebElement email { get { return Browser.Wd.FindElement(By.Id("userNameInput")); } }
        public IWebElement OldPassword { get { return Browser.Wd.FindElement(By.Id("oldPasswordInput")); } }
        public IWebElement NewPassword { get { return Browser.Wd.FindElement(By.Id("newPasswordInput")); } }
        public IWebElement ConfNewPassword { get { return Browser.Wd.FindElement(By.Id("confirmNewPasswordInput")); } }
        public IWebElement SubmitButton { get { return Browser.Wd.FindElement(By.Id("submitButton")); } }

    }

}
