﻿
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using TMSoR1.FrameworkCode;
using TMSoR1.FrameworkCode.ADFS;

namespace TMSoR1
{
    [Binding]
    public class fsADFSLogin
    {
        private readonly ScenarioContext Context;

        public fsADFSLogin(ScenarioContext catalogContext)
        {
            Context = catalogContext;
        }


        [When(@"User Management Page Identity Provider Administration section is Clicked")]
        public void WhenUserManagementPageIdentityProviderAdministrationSectionIsClicked()
        {
            //ReUsableFunctions.clickOnWebElement(cfADFSLogin.IdentityProviderAdminPage.IdentityProviderAdministration);
            fw.ExecuteJavascript(cfADFSLogin.IdentityProviderAdminPage.IdentityProviderAdministration);
            tmsWait.Hard(5);
        }

        [When(@"User Management Page Identity Provider Administration section Claim Transformation Settings is Clicked")]
        public void WhenUserManagementPageIdentityProviderAdministrationSectionClaimTransformationSettingsIsClicked()
        {
            ReUsableFunctions.clickOnWebElement(cfADFSLogin.IdentityProviderAdminPage.ClaimTransformationSettings);
            tmsWait.Hard(5);
        }




        [Then(@"Verfiy Error Message displayed as ""(.*)""")]
        public void ThenVerfiyErrorMessageDisplayedAs(string p0)
        {
            By loc = By.XPath("//span[contains(.,'" + p0 + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }

        [Then(@"Verify Rx Reconciliation Manager application is displayed")]
        public void ThenVerifyRxReconciliationManagerApplicationIsDisplayed()
        {
            tmsWait.Hard(5);
            By loc = By.XPath("//span[@test-id='header-title-applicationName'][contains(.,'Rx Reconciliation Manager')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }


        [Then(@"Verify Administration application is displayed")]
        public void ThenVerifyAdministrationApplicationIsDisplayed()
        {
            tmsWait.Hard(5);
            By loc = By.XPath("//span[@test-id='header-title-applicationName'][contains(.,'Administration')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(loc);
        }


        [Then(@"Verify Claim Transformation Rules page displayed Rule Name ""(.*)""")]
        public void ThenVerifyClaimTransformationRulesPageDisplayedRuleName(string p0)
        {
            //IWebElement first = Browser.Wd.FindElement(By.XPath("(//a[@title='Go to the first page'])[2]"));
            //fw.ExecuteJavascript(first);
            //string value = tmsCommon.GenerateData(p0);
            //  IWebElement ele = Browser.Wd.FindElement(By.XPath("(//span[@class='k-pager-info k-label'])[2]"));
            // int totalrec = Convert.ToInt32((ele.Text.Split(' '))[4]);
            //fw.ConsoleReport(" Total record " + totalrec);
            //IWebElement next = Browser.Wd.FindElement(By.XPath("(//a[@title='Go to the next page'])[2]"));
            // bool elementFound = false;

            string value = tmsCommon.GenerateData(p0);

            bool flag = false;

            while (!flag)
            {
                try
                {

                    By loc = By.XPath(" //form[@id='claimTransformationSettingsFrm']//td[contains(text(),'" + value + "')]");
                    AngularFunction.elementPresenceUsingLocators(loc);
                    flag = true;
                }
                catch
                {
                    AngularFunction.clickonNextLink();
                    tmsWait.Hard(1);
                }
            }


            //while (!elementFound)
            //{

            //    try
            //    {
            //        //By loc = By.XPath("//div[@test-id='claimTransformation-grid-member']//span[@ng-bind='dataItem.claimRuleName'][contains(.,'" + value + "')]");
            //        By loc = By.XPath(" //form[@id='claimTransformationSettingsFrm']//td[contains(text(),'"+ value +"')]");

            //        //form[@id='claimTransformationSettingsFrm']//td[contains(text(),'TMS ROLE')]
            //        UIMODUtilFunctions.elementPresenceUsingLocators(loc);
            //        elementFound = true;
            //    }

            //    catch
            //    {

            //    }
            //    int navigatedRec = Convert.ToInt32((ele.Text.Split(' '))[2]);
            //    if (navigatedRec.Equals(totalrec) && (!elementFound))
            //    {
            //        elementFound = true;
            //        Assert.AreEqual(1, 2, "Both are not matching"); // As nunit assert is creating trouble, we used this statement intentionaly
            //    }

            //    fw.ExecuteJavascript(next);
            //}
            //tmsWait.Hard(5);
        }

        [When(@"Verify Claim Transformation Rules page is not displayed Rule Name ""(.*)""")]
        public void WhenVerifyClaimTransformationRulesPageIsNotDisplayedRuleName(string p0)
        {
            //IWebElement last = Browser.Wd.FindElement(By.XPath("(//a[@title='Go to the last page'])[2]"));
            //fw.ExecuteJavascript(last);
            string value = tmsCommon.GenerateData(p0);
            Browser.Wd.Navigate().Refresh();
            tmsWait.Hard(5);
            ReUsableFunctions.clickOnWebElement(cfADFSLogin.IdentityProviderAdminPage.ClaimTransformationSettings);
            tmsWait.Hard(5);
            bool isEnable = false;
            do
            {
                try
                {

                    IWebElement element = Browser.Wd.FindElement(By.XPath("//span[@aria-label='Go to the next page']/parent::a[@class[contains(.,'disabled')]]"));
                    string classAttribute = element.GetAttribute("class");
                    fw.ConsoleReport("Value is " + classAttribute);
                    isEnable = element.GetAttribute("class").Contains("disabled");
                    fw.ConsoleReport("Go to the next page element flag is " + isEnable);
                    By loc = By.XPath(" //form[@id='claimTransformationSettingsFrm']//td[contains(text(),'" + value + "')]");
                    AngularFunction.elementNotPresenceUsingLocators(loc);

                }

                catch {
                                     
                    isEnable = false;
                    fw.ConsoleReport("Go to the next page element flag is" + isEnable);
                    By loc = By.XPath(" //form[@id='claimTransformationSettingsFrm']//td[contains(text(),'" + value + "')]");
                    AngularFunction.elementNotPresenceUsingLocators(loc);
                    //click on next page only of next link page is present 
                    AngularFunction.clickonNextLink();

                }

               }
            while (!isEnable);
                       
            //    while (!flag)
            //{
            //    try
            //    {

            //       //IWebElement last = Browser.Wd.FindElement(By.CssSelector("a[title='Go to the next page']"));
            //       // last.Click();

            //    }

            //    catch
            //    {
            //        By loc = By.XPath(" //form[@id='claimTransformationSettingsFrm']//td[contains(text(),'" + value + "')]");
            //        //AngularFunction.elementPresenceUsingLocators(loc);
            //        AngularFunction.elementNotPresenceUsingLocators(loc);
            //        flag = true;

            //    }

            //    }


            //IWebElement ele = Browser.Wd.FindElement(By.XPath("(//span[@class='k-pager-input k-label'])[2]"));
            //int totalrec = Convert.ToInt32((ele.Text.Split(' '))[4]);
            //fw.ConsoleReport(" Total record " + totalrec);
            //IWebElement next = Browser.Wd.FindElement(By.XPath("(//a[@title='Go to the next page'])[2]"));
            //bool elementFound = false;
            //while (!elementFound)
            //{

            //    try
            //    {
            //        By loc = By.XPath("//div[@test-id='claimTransformation-grid-member']//span[@ng-bind='dataItem.claimRuleName'][contains(.,'" + value + "')]");
            //        UIMODUtilFunctions.elementNotPresenceUsingLocators(loc);
            //        elementFound = true;
            //    }

            //    catch
            //    {

            //    }
            //    int navigatedRec = Convert.ToInt32((ele.Text.Split(' '))[2]);
            //    if (navigatedRec.Equals(totalrec) && (!elementFound))
            //    {
            //        elementFound = true;
            //        Assert.AreEqual(1, 2, "Both are not matching"); // As nunit assert is creating trouble, we used this statement intentionaly
            //    }

            //    fw.ExecuteJavascript(next);
            //}
            //tmsWait.Hard(5);

        }

        [When(@"Verify Claim Transformation Rules page displayed Rule Name ""(.*)"" is edited")]
        public void WhenVerifyClaimTransformationRulesPageDisplayedRuleNameIsEdited(string p0)
        {
            

        //    IWebElement first = Browser.Wd.FindElement(By.XPath("(//a[@title='Go to the first page'])[2]"));
          //  fw.ExecuteJavascript(first);
          
            string value = tmsCommon.GenerateData(p0);
            //IWebElement ele = Browser.Wd.FindElement(By.XPath("(//span[@class='k-pager-info k-label'])[2]"));
            //int totalrec = Convert.ToInt32((ele.Text.Split(' '))[4]);
            //fw.ConsoleReport(" Total record " + totalrec);
            //IWebElement next = Browser.Wd.FindElement(By.XPath("(//a[@title='Go to the next page'])[2]"));
            //bool elementFound = false;
            //while (!elementFound)
            //{

            //    try
            //    {
            //        By loc = By.XPath("//div[@test-id='claimTransformation-grid-member']//td[contains(.,'" + value + "')]/following-sibling::td/a[1]");
            //        UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            //        elementFound = true;
            //    }

            //    catch
            //    {

            //    }
            //    int navigatedRec = Convert.ToInt32((ele.Text.Split(' '))[2]);
            //    if (navigatedRec.Equals(totalrec) && (!elementFound))
            //    {
            //        elementFound = true;
            //        Assert.AreEqual(1, 2, "Both are not matching"); // As nunit assert is creating trouble, we used this statement intentionaly
            //    }

            //    fw.ExecuteJavascript(next);
            //}

            bool flag = false;

            while (!flag)
            {
                try
                {
                    tmsWait.Hard(2);
                    By locedit = By.XPath(" //form[@id='claimTransformationSettingsFrm']//td[contains(text(),'" + value + "')]//following-sibling::td//a[@name='edit']/span");

                    AngularFunction.elementPresenceUsingLocators(locedit);

                    flag = true;
                }
                catch
                {
                    AngularFunction.clickonNextLink();
                }
            }
            By loc = By.XPath(" //form[@id='claimTransformationSettingsFrm']//td[contains(text(),'" + value + "')]//following-sibling::td//a[@name='edit']/span");
            AngularFunction.clickOnElement(loc);
            tmsWait.Hard(2);
        }

        [When(@"Verify Claim Transformation Rules page displayed Rule Name ""(.*)"" is deleted")]
        public void WhenVerifyClaimTransformationRulesPageDisplayedRuleNameIsDeleted(string p0)
        {
            //IWebElement first = Browser.Wd.FindElement(By.XPath("(//a[@title='Go to the first page'])[2]"));
            //fw.ExecuteJavascript(first);
            string value = tmsCommon.GenerateData(p0);
            bool flag = false;

            while (!flag)
            {
                try
                {
                    tmsWait.Hard(2);
                    By locdelete = By.XPath(" //form[@id='claimTransformationSettingsFrm']//td[contains(text(),'" + value + "')]//following-sibling::td//a[@name='delete']/span");

                    AngularFunction.elementPresenceUsingLocators(locdelete);

                    flag = true;
                }
                catch
                {
                    AngularFunction.clickonNextLink();
                }
            }
            By loc = By.XPath(" //form[@id='claimTransformationSettingsFrm']//td[contains(text(),'" + value + "')]//following-sibling::td//a[@name='delete']/span");
            AngularFunction.clickOnElement(loc);
            tmsWait.Hard(2);
            UIMODUtilFunctions.clickOnConfirmationYesDialog();
            tmsWait.Hard(3);
               


            //IWebElement ele = Browser.Wd.FindElement(By.XPath("(//span[@class='k-pager-info k-label'])[2]"));
            //int totalrec = Convert.ToInt32((ele.Text.Split(' '))[4]);
            //fw.ConsoleReport(" Total record " + totalrec);
            //IWebElement next = Browser.Wd.FindElement(By.XPath("(//a[@title='Go to the next page'])[2]"));
            //bool elementFound = false;
            //while (!elementFound)
            //{

            //    try
            //    {
            //        By loc = By.XPath("//div[@test-id='claimTransformation-grid-member']//td[contains(.,'" + value + "')]/following-sibling::td/a[2]");
            //        UIMODUtilFunctions.clickOnWebElementUsingLocators(loc);
            //        elementFound = true;
            //        if (elementFound)
            //        {
            //            UIMODUtilFunctions.clickOnConfirmationYesDialog();
            //            tmsWait.Hard(3);
            //        }
            //    }

            //    catch
            //    {

            //    }
            //    int navigatedRec = Convert.ToInt32((ele.Text.Split(' '))[2]);
            //    if (navigatedRec.Equals(totalrec) && (!elementFound))
            //    {
            //        elementFound = true;
            //        Assert.AreEqual(1, 2, "Both are not matching"); // As nunit assert is creating trouble, we used this statement intentionaly
            //    }

            //    fw.ExecuteJavascript(next);
            //}

        }

        [When(@"Identity Provider Administration page Add button is Clicked and Verify message display ""(.*)""")]
        public void WhenIdentityProviderAdministrationPageAddButtonIsClickedAndVerifyMessageDisplay(string p0)
        {
            ReUsableFunctions.clickOnWebElement(cfADFSLogin.IdentityProviderAdminPage.ADD);
            //By loc = By.XPath("//div[contains(@aria-label,'" + p0 + "')]");
            //UIMODUtilFunctions.elementPresenceUsingLocators(loc);
            By toastMsg = By.XPath("//div[@class='k-notification-content']");
            string actValue = Browser.Wd.FindElement(toastMsg).Text;
            Assert.IsTrue(actValue.Contains(p0));


        }


        [When(@"Identity Provider Administration page Add button is Clicked")]
        public void WhenIdentityProviderAdministrationPageAddButtonIsClicked()
        {
            ReUsableFunctions.clickOnWebElement(cfADFSLogin.IdentityProviderAdminPage.ADD);
            tmsWait.Hard(5);
        }
        [When(@"Identity Provider Administration page UPDATE button is Clicked")]
        public void WhenIdentityProviderAdministrationPageUPDATEButtonIsClicked()
        {
            ReUsableFunctions.clickOnWebElement(cfADFSLogin.IdentityProviderAdminPage.UPDATE);
            tmsWait.Hard(5);
        }


        [When(@"User Management Page Identity Provider Administration page Rule Name is set to ""(.*)""")]
        public void WhenUserManagementPageIdentityProviderAdministrationPageRuleNameIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            UIMODUtilFunctions.enterValueOnWebElementUsingWebElement(cfADFSLogin.IdentityProviderAdminPage.RuleName, value);
        }

        [When(@"Transform Incoming Claim Value Claim Type Settings External Clam Type is set to ""(.*)""")]
        public void WhenTransformIncomingClaimValueClaimTypeSettingsExternalClamTypeIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            UIMODUtilFunctions.enterValueOnWebElementUsingWebElement(cfADFSLogin.IdentityProviderAdminPage.ClaimTypeSettingsExternalClaimTypeTextBox, value);
        }

        [When(@"User Management Page Identity Provider Administration page External Claim Type is set to ""(.*)""")]
        public void WhenUserManagementPageIdentityProviderAdministrationPageExternalClaimTypeIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            UIMODUtilFunctions.enterValueOnWebElementUsingWebElement(cfADFSLogin.IdentityProviderAdminPage.ExternalClaimType, value);
        }

        [When(@"Claim Value Settings Replace an External claim value with TMS claim value External Claim Value is set to ""(.*)""")]
        public void WhenClaimValueSettingsReplaceAnExternalClaimValueWithTMSClaimValueExternalClaimValueIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            UIMODUtilFunctions.enterValueOnWebElementUsingWebElementWithoutClear(cfADFSLogin.IdentityProviderAdminPage.ExternalClaimValueTextBox, value);
        }

        [When(@"Claim Value Settings Replace an External claim value with TMS claim value TMS Claim Value is set to ""(.*)""")]
        public void WhenClaimValueSettingsReplaceAnExternalClaimValueWithTMSClaimValueTMSClaimValueIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            UIMODUtilFunctions.enterValueOnWebElementUsingWebElement(cfADFSLogin.IdentityProviderAdminPage.TMSClaimValueTextBox, value);
        }


        [When(@"User Management Page Identity Provider Administration page TMS Claim Type is set to ""(.*)""")]
        public void WhenUserManagementPageIdentityProviderAdministrationPageTMSClaimTypeIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            By Drp = By.XPath("//kendo-dropdownlist[@test-id='claimTransformationSettings-txt-ddlTmsClaimType']//span[@class='k-select']");
            By typeapp = By.XPath("//li[text()='" + value + "']");
            fw.ExecuteJavascript(Browser.Wd.FindElement(Drp));
            fw.ExecuteJavascript(Browser.Wd.FindElement(typeapp));
            //UIMODUtilFunctions.selectDropDownValueFromGendoUI(cfADFSLogin.IdentityProviderAdminPage.TMSClaimType, value);
        }

        [When(@"Claim Value Settings Pass through only specific claim value checkbox is checked")]
        public void WhenClaimValueSettingsPassThroughOnlySpecificClaimValueCheckboxIsChecked()
        {
            ReUsableFunctions.clickOnWebElement(cfADFSLogin.IdentityProviderAdminPage.PassthroughonlyspecificclaimvalueOptionButton);
            tmsWait.Hard(4);
        }

        [When(@"Claim Value Settings Pass through only specific claim value External Claim Value text box is set to ""(.*)""")]
        public void WhenClaimValueSettingsPassThroughOnlySpecificClaimValueExternalClaimValueTextBoxIsSetTo(string p0)
        {
            string value = tmsCommon.GenerateData(p0);
            UIMODUtilFunctions.enterValueOnWebElementUsingWebElementWithoutClear(cfADFSLogin.IdentityProviderAdminPage.ExternalClaimValueTextBox, value);
        }


        [Given(@"I am logged in to Elements Application through ADFS")]
        public void GivenIAmLoggedInToElementsApplicationThroughADFS()
        {


            Navigation.navigate();
            tmsWait.Hard(5);
            Browser.Wd.Manage().Window.Maximize();
            tmsWait.Hard(40);
            fw.ConsoleReport(" Navigating to ADFS Login page");
            ReUsableFunctions.clickOnWebElement(cfADFSLogin.ADFSLoginPage.loginWithADFSButton);

            //Adding the following to handle the possibility of the certificate dialog appearing after ADFS link
            if (ConfigFile.BrowserType.Equals("ie"))
            {
                tmsWait.Hard(15); //  this wait is intentional
            }

            if (Browser.Wd.Title.Equals("Certificate Error: Navigation Blocked"))
            {
                Browser.Wd.Navigate().GoToUrl("javascript:document.getElementById('overridelink').click()");
            }


            if (ConfigFile.BrowserType.Equals("edge") || ConfigFile.BrowserType.Equals("chrome") || ConfigFile.BrowserType.Equals("edgelegacy") || ConfigFile.BrowserType.Equals("edgechrome"))
            {
                try
                {
                    IWebElement advancedButton = Browser.Wd.FindElement(By.CssSelector("[id='details-button']"));
                    fw.ExecuteJavascript(advancedButton);
                    tmsWait.Hard(5);

                    IWebElement acceptRiskBtn = Browser.Wd.FindElement(By.CssSelector("[id='proceed-link']"));
                    fw.ExecuteJavascript(acceptRiskBtn);
                    tmsWait.Hard(10);

                    IWebElement advancedButton1 = Browser.Wd.FindElement(By.CssSelector("[id='details-button']"));
                    fw.ExecuteJavascript(advancedButton1);
                    tmsWait.Hard(5);

                    IWebElement acceptRiskBtn1 = Browser.Wd.FindElement(By.CssSelector("[id='proceed-link']"));
                    fw.ExecuteJavascript(acceptRiskBtn1);

                }
                catch
                {
                    try
                    {
                        IWebElement continueBtn = Browser.Wd.FindElement(By.PartialLinkText("Continue to this webpage"));
                        fw.ExecuteJavascript(continueBtn);
                        tmsWait.Hard(5);
                    }
                    catch
                    {

                        fw.ConsoleReport("There is no Certiicate Warning");
                    }
                }
            }


            if (ConfigFile.BrowserType.Equals("edge") || ConfigFile.BrowserType.Equals("edgelegacy") || ConfigFile.BrowserType.Equals("edgechrome"))
            {
                try
                {
                    IWebElement advancedButton = Browser.Wd.FindElement(By.CssSelector("[id='continueLink']"));
                    fw.ExecuteJavascript(advancedButton);
                    tmsWait.Hard(5);

                    IWebElement acceptRiskBtn = Browser.Wd.FindElement(By.CssSelector("[id='continueLink']"));
                    fw.ExecuteJavascript(acceptRiskBtn);
                    tmsWait.Hard(10);
                }

                catch
                {
                    fw.ConsoleReport("There is no Certiicate Warning");
                }

            }

            if (ConfigFile.BrowserType.Equals("firefox"))
            {
                try
                {
                    IWebElement advancedButton = Browser.Wd.FindElement(By.Id("advancedButton"));
                    fw.ExecuteJavascript(advancedButton);
                    tmsWait.Hard(5);

                    IWebElement acceptRiskBtn = Browser.Wd.FindElement(By.Id("exceptionDialogButton"));
                    fw.ExecuteJavascript(acceptRiskBtn);
                    tmsWait.Hard(10);

                    IWebElement advancedButton1 = Browser.Wd.FindElement(By.Id("advancedButton")); // Due to Stale Element reference Exception, we created Duplicate statement
                    fw.ExecuteJavascript(advancedButton1);
                    tmsWait.Hard(5);

                    IWebElement acceptRiskBtn1 = Browser.Wd.FindElement(By.Id("exceptionDialogButton"));
                    fw.ExecuteJavascript(acceptRiskBtn1);
                    tmsWait.Hard(10);

                }
                catch
                {
                    fw.ConsoleReport("There is no Warning: Potential Security Risk Ahead");
                }
            }

            if (ConfigFile.BrowserType.Equals("ie"))
            {
                try
                {
                    IWebElement Moreinformation = Browser.Wd.FindElement(By.LinkText("More information"));
                    fw.ExecuteJavascript(Moreinformation);
                    tmsWait.Hard(2);

                    IWebElement Goontothewebpage = Browser.Wd.FindElement(By.PartialLinkText("Go on to the webpage"));
                    fw.ExecuteJavascript(Goontothewebpage);
                    tmsWait.Hard(10);


                    IWebElement Moreinformation1 = Browser.Wd.FindElement(By.LinkText("More information"));
                    fw.ExecuteJavascript(Moreinformation1);
                    tmsWait.Hard(2);

                    IWebElement Goontothewebpage1 = Browser.Wd.FindElement(By.PartialLinkText("Go on to the webpage"));
                    fw.ExecuteJavascript(Goontothewebpage1);

                }
                catch
                {
                    fw.ConsoleReport(" There is no App Server Certificate Issue");
                }
            }
            tmsWait.Hard(12);

        }

        [When(@"ADFS Sign In page User Name is set as ""(.*)""")]
        public void WhenADFSSignInPageUserNameIsSetAs(string p0)
        {
            string username = p0;
            ReUsableFunctions.enterValueOnWebElement(cfADFSLogin.ADFSLoginPage.username, username);

        }

        [When(@"ADFS Sign In page password is set as ""(.*)""")]
        public void WhenADFSSignInPagePasswordIsSetAs(string p0)
        {
            string password = p0;
            ReUsableFunctions.enterValueOnWebElement(cfADFSLogin.ADFSLoginPage.password, password);
        }

        [When(@"Identity Provider Administration page Apply regular expression on all external claim type option button is Clicked")]
        public void WhenIdentityProviderAdministrationPageApplyRegularExpressionOnAllExternalClaimTypeOptionButtonIsClicked()
        {
            ReUsableFunctions.clickOnWebElement(cfADFSLogin.IdentityProviderAdminPage.ApplyregularexpressiononallexternalclaimtypeOption);
            tmsWait.Hard(4);

        }

        [When(@"Identity Provider Administration page Transform Incoming Claim option button is Clicked")]
        public void WhenIdentityProviderAdministrationPageTransformIncomingClaimOptionButtonIsClicked()
        {
            ReUsableFunctions.clickOnWebElement(cfADFSLogin.IdentityProviderAdminPage.TransformIncomingClaimOpt);
        }


        [When(@"Identity Provider Administration page Transform Incoming Claim Value option button is Clicked")]
        public void WhenIdentityProviderAdministrationPageTransformIncomingClaimValueOptionButtonIsClicked()
        {
            ReUsableFunctions.clickOnWebElement(cfADFSLogin.IdentityProviderAdminPage.TransformIncomingClaimValueOption);
        }
        [When(@"User Management Page Identity Provider Administration page Replace an External claim value with TMS claim value Option button is Clicked")]
        public void WhenUserManagementPageIdentityProviderAdministrationPageReplaceAnExternalClaimValueWithTMSClaimValueOptionButtonIsClicked()
        {
            tmsWait.Hard(3);

            ReUsableFunctions.clickOnWebElement(cfADFSLogin.IdentityProviderAdminPage.ReplaceanExternalClaimValuewithTMSClaimvalueOption);
            tmsWait.Hard(3);
        }


        [When(@"Identity Provider Administration page Claim Type Settings Pattern is set to ""(.*)""")]
        public void WhenIdentityProviderAdministrationPageClaimTypeSettingsPatternIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            string value = tmsCommon.GenerateData(p0);
            ReUsableFunctions.enterValueOnWebElementWithoutClear(cfADFSLogin.IdentityProviderAdminPage.Pattern, value);
        }

        [When(@"Identity Provider Administration page Claim Type Settings Replacement is set to ""(.*)""")]
        public void WhenIdentityProviderAdministrationPageClaimTypeSettingsReplacementIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            string value = tmsCommon.GenerateData(p0);
            ReUsableFunctions.enterValueOnWebElementWithoutClear(cfADFSLogin.IdentityProviderAdminPage.Replacement, value);
        }

        [When(@"ADFS Sign In page Sign In button is Clicked")]
        public void WhenADFSSignInPageSignInButtonIsClicked()
        {
            ReUsableFunctions.clickOnWebElement(cfADFSLogin.ADFSLoginPage.signInButton);
            tmsWait.Hard(40);
        }
        [Then(@"Verify User Management page Identity Server menu is not displayed")]
        public void ThenVerifyUserManagementPageIdentityServerMenuIsNotDisplayed()
        {
            By loc = By.CssSelector("[title='Identity Server']");
            UIMODUtilFunctions.elementNotPresenceUsingLocators(loc);
        }





        [When(@"Tenant Administration page Navigated to User Management page")]
        public void WhenTenantAdministrationPageNavigatedToUserManagementPage()
        {
            tmsWait.Hard(10);
            Browser.Wd.Navigate().GoToUrl(ConfigFile.IDMURL);
            tmsWait.Hard(10);
        }
        [Then(@"Verify User Management page External User Type Edit button is disabled")]
        public void ThenVerifyUserManagementPageExternalUserTypeEditButtonIsDisabled()
        {
            bool editbutton = false;
            By edit = By.XPath("(//a[@role='button'])[1]");

            string status = Browser.Wd.FindElement(edit).GetAttribute("class");

            if (status.Contains("disabled"))
            {
                editbutton = true;
            }

            fw.ConsoleReport("IS Edit Button Disabled? " + editbutton);

            Assert.IsTrue(true);
        }


        [When(@"User Management page External User Type is filtered")]
        public void WhenUserManagementPageExternalUserTypeIsFiltered()
        {
            tmsWait.Hard(5);

            fw.ExecuteJavascript(cfADFSLogin.IdentityProviderAdminPage.UserTypeFilterType);
            ReUsableFunctions.enterValueOnWebElementWithoutClear(cfADFSLogin.IdentityProviderAdminPage.UserTypeFilterTextbox, "External");
            tmsWait.Hard(2);
            fw.ExecuteJavascript(cfADFSLogin.IdentityProviderAdminPage.FilterSubmitButton);
        }


        [When(@"When Root Administration menu External Systems submenu Identity Server sub menu is Clicked")]
        public void WhenWhenRootAdministrationMenuExternalSystemsSubmenuIdentityServerSubMenuIsClicked()
        {
            fw.ExecuteJavascript(EAM.EAMLogin.IdentityServer);
            string tenantName = "Identity Server_" + ((ConfigFile.URL.Split('.'))[0].Split(':'))[1].Substring(2);
            string splTenantName = "Identity Server_" + ((ConfigFile.URL.Split('.'))[0].Split(':'))[1].Substring(2).ToUpper();
            tmsWait.Hard(2);
            try
            {
                By path = By.XPath("//div[@test-id='identityserver-grid-grdidentityserver']//td[contains(.,'" + tenantName + "')]/following-sibling::td/a[1]");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(path);
            }
            catch
            {
                By path = By.XPath("//div[@test-id='identityserver-grid-grdidentityserver']//td[contains(.,'" + splTenantName + "')]/following-sibling::td/a[1]");
                UIMODUtilFunctions.clickOnWebElementUsingLocators(path);
            }
            tmsWait.Hard(10);
            Browser.SwitchToWindow(1);
            tmsWait.Hard(20);
        }

        //Gurdeep Arora
        [When(@"I click on plus icon for user ""(.*)"" and verify claim details sub grid is displayed")]
        public void WhenIClickOnPlusIconForUserAndVerifyClaimDetailsSubGridIsDisplayed(string p0)
        {
            //By path = By.XPath("//div[@id='grdUsers']/div[3]/a[@title='Go to the next page']");
            //UIMODUtilFunctions.clickOnWebElementUsingLocators(path);

            tmsWait.Hard(3);
            while (true) {
                try {

                    //By userloc = By.XPath("//div[@test-id='users-grid-users']//span[@ng-bind='dataItem.name'][contains(.,'" + p0 + "')]");
                    By userloc = By.XPath("//td[contains(text(),'" + p0 + "')]");
                    UIMODUtilFunctions.elementPresenceUsingLocators(userloc);
                    fw.ConsoleReport("User found on User List page :" + p0);
                    //IWebElement plusIcon = Browser.Wd.FindElement(By.XPath("//td[contains(.,'rootadmin@dev.trizetto.com')]/preceding-sibling::td/a[@aria-label='Expand']"));
                    IWebElement plusIcon = Browser.Wd.FindElement(By.XPath("//td[contains(.,'tms_root_admin@dev.trizetto.com')]/parent::tr/td/a[@title='Expand Details']"));                                 
                    UIMODUtilFunctions.clickOnWebElementUsingLocators(plusIcon);
                    tmsWait.Hard(2);
                    ThenVerifyClaimDetailsSubGridIsDisplayed();
                    break;
                }
                catch {

                    //UIMODUtilFunctions.clickOnWebElementUsingLocators(path);
                    AngularFunction.clickonNextLink();
                    tmsWait.Hard(3);
                }


            }


        }

        [Then(@"verify ""(.*)"" page is displayed")]
        public void ThenVerifyPageIsDisplayed(string p0)
        {
            IWebElement pageTitle;
            switch (p0) {
                case "Add New Transaction":
                    pageTitle = Browser.Wd.FindElement(By.XPath("//div[contains(text(),'New Transaction')]"));
                    Assert.IsTrue(pageTitle.Displayed, "Add New Transaction page is not displayed");
                    break;
                case "TC 90 Drug Edit Transaction":
                    pageTitle = Browser.Wd.FindElement(By.XPath("//div[contains(text(),'TC 90')]"));
                    Assert.IsTrue(pageTitle.Displayed, "TC 90 Drug Edit Transaction page is not displayed");
                    break;
            }

        }

        // Gurdeep Arora
        [Then(@"i verify ""(.*)"" menu ""(.*)"" for user ""(.*)"" and verify submenu options")]
        [When(@"i verify ""(.*)"" menu ""(.*)"" for user ""(.*)"" and verify submenu options")]
        [Given(@"i verify ""(.*)"" menu ""(.*)"" for user ""(.*)"" and verify submenu options")]
        public void ThenIVerifyMenuForUserAndVerifySubmenuOptions(string p0, string p1, string p2)
        {
            string applicationName = tmsCommon.GenerateData(p0);
            string menuName = tmsCommon.GenerateData(p1);
            string userName = tmsCommon.GenerateData(p2);
            string actualSubmenuItem;
            string[] expSubmenuItems = null;

            tmsWait.Hard(2);
            IWebElement eleMenu = Browser.Wd.FindElement(By.XPath("//*[@title='" + menuName + "']"));


            switch (applicationName) {


                case "FRM":
                    Assert.IsTrue(eleMenu.Displayed, menuName + " is not displayed");
                    tmsWait.Hard(2);
                    break;

                case "RSM":
                    switch (menuName)
                    {

                        case "Main":
                            expSubmenuItems = new string[] { "Member Discrepancy", "Member HCC Details", "RSM Member HCC Extract", "EDPS/RAPS Reconciliation" };
                            eleMenu.Click();
                            tmsWait.Hard(1);
                            foreach (string expSubmenuItem in expSubmenuItems)
                            {

                                actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//*[@title='" + expSubmenuItem + "']/span")).Text;
                                Assert.AreEqual(expSubmenuItem, actualSubmenuItem, "Submenu " + expSubmenuItem + " does not exist under " + menuName + " menu");
                            }
                            break;

                        case "Administration":
                            expSubmenuItems = new string[] { "Sweeps/ Risk Cut Over Dates", "Minimum Enroll Months" };
                            eleMenu.Click();
                            tmsWait.Hard(1);
                            foreach (string expSubmenuItem in expSubmenuItems)
                            {

                                actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//*[@title='" + expSubmenuItem + "']/span")).Text;
                                Assert.AreEqual(expSubmenuItem, actualSubmenuItem, "Submenu " + expSubmenuItem + " does not exist under " + menuName + " menu");
                            }
                            break;

                        default:
                            Assert.IsTrue(eleMenu.Displayed, menuName + " is not displayed");
                            tmsWait.Hard(2);
                            break;

                    } break;

                case "RAM":
                    switch (menuName)
                    {
                        case "Tasks":
                            expSubmenuItems = new string[] { "Import", "Export", "Risk Adjustment Updates", "On-Hold and Diagnosis Review", "Delete Submitted Diag Codes", "Audit-View/Export" };
                            eleMenu.Click();
                            tmsWait.Hard(1);
                            foreach (string expSubmenuItem in expSubmenuItems)
                            {

                                actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//*[@title='" + expSubmenuItem + "']/span")).Text;
                                Assert.AreEqual(expSubmenuItem, actualSubmenuItem, "Submenu " + expSubmenuItem + " does not exist under " + menuName + " menu");
                            }
                            break;

                        case "Main":
                            expSubmenuItems = new string[] { "Manage Suspects", "Enter New Diagnosis Data", "Manage Suspect Assignments", "Prospective Evaluation" };
                            eleMenu.Click();
                            tmsWait.Hard(1);
                            foreach (string expSubmenuItem in expSubmenuItems)
                            {

                                actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//*[@title='" + expSubmenuItem + "']/span")).Text;
                                Assert.AreEqual(expSubmenuItem, actualSubmenuItem, "Submenu " + expSubmenuItem + " does not exist under " + menuName + " menu");
                            }
                            break;

                        case "Suspects":
                            expSubmenuItems = new string[] { "Cancel Suspects", "View and Undo PIR Responses", "Update PIR Provider", "Update Provider Info" };
                            eleMenu.Click();
                            tmsWait.Hard(1);
                            foreach (string expSubmenuItem in expSubmenuItems)
                            {

                                actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//*[@title='" + expSubmenuItem + "']/span")).Text;
                                Assert.AreEqual(expSubmenuItem, actualSubmenuItem, "Submenu " + expSubmenuItem + " does not exist under " + menuName + " menu");
                            }
                            break;

                        case "Administration":
                            expSubmenuItems = new string[] { "Add Diagnosis Codes", "Add Reasons", "Add On Hold Reasons", "Add Coder IDs", "Suspect Assignment Options", "RAM Configuration", "Add Payment Year", "Exclude/Include Provider", "Customize PIR Cover Letter", "Add Chart Review Source", "Audit Configuration", "Auditor Review", "Flag for Auditor Review" };
                            eleMenu.Click();
                            tmsWait.Hard(1);
                            foreach (string expSubmenuItem in expSubmenuItems)
                            {

                                actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//*[@title='" + expSubmenuItem + "']/span")).Text;
                                Assert.AreEqual(expSubmenuItem, actualSubmenuItem, "Submenu " + expSubmenuItem + " does not exist under " + menuName + " menu");
                            }
                            break;


                        default:
                            Assert.IsTrue(eleMenu.Displayed, menuName + " is not displayed");
                            tmsWait.Hard(2);
                            break;

                    }
                    break;


                case "Framework":
                    switch (menuName)
                    {
                        case "Jobs":
                            expSubmenuItems = new string[] { "Jobs" };
                            eleMenu.Click();
                            tmsWait.Hard(1);
                            foreach (string expSubmenuItem in expSubmenuItems)
                            {
                                actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//*[@id='fisrtLevelMenu']/li/a/span")).Text;
                                Assert.AreEqual(expSubmenuItem, actualSubmenuItem, "Submenu " + expSubmenuItem + " does not exist under " + menuName + " menu");
                            }
                            break;


                        default:
                            Assert.IsTrue(eleMenu.Displayed, menuName + " is not displayed");
                            tmsWait.Hard(2);
                            break;
                    }

                    break;

                case "DLM":
                    switch (menuName)
                    {
                        case "Tasks":
                            expSubmenuItems = new string[] { "MMR Load", "MBI Crosswalk" };
                            eleMenu.Click();
                            tmsWait.Hard(1);
                            foreach (string expSubmenuItem in expSubmenuItems)
                            {
                                actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//*[@title='" + expSubmenuItem + "']/span")).Text;
                                Assert.AreEqual(expSubmenuItem, actualSubmenuItem, "Submenu " + expSubmenuItem + " does not exist under " + menuName + " menu");
                            }
                            break;


                        default:
                            Assert.IsTrue(eleMenu.Displayed, menuName + " is not displayed");
                            tmsWait.Hard(2);
                            break;
                    }
                    break;

                case "PDEM":
                    switch (menuName)
                    {
                        case "Main":
                            if (userName.Equals("readOnlyUser"))
                            {
                                expSubmenuItems = new string[] { "View Edit PDE" };
                            }
                            else
                            {
                                expSubmenuItems = new string[] { "View Edit PDE", "Batch Admin" };
                            }
                            eleMenu.Click();
                            tmsWait.Hard(1);
                            foreach (string expSubmenuItem in expSubmenuItems)
                            {
                                actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//*[@title='" + expSubmenuItem + "']/span")).Text;
                                Assert.AreEqual(expSubmenuItem, actualSubmenuItem, "Submenu " + expSubmenuItem + " does not exist under " + menuName + " menu");
                            }
                            break;


                        case "Tasks":
                            if (userName.Equals("readOnlyUser"))
                            {
                                expSubmenuItems = new string[] { "Batches", "Duplicate Records", "P2P AR Management", "Audit History" };
                            }
                            else
                            {
                                expSubmenuItems = new string[] { "Import", "Batches", "Duplicate Records", "P2P AR Management", "Audit History" };
                            }


                            eleMenu.Click();
                            tmsWait.Hard(1);
                            foreach (string expSubmenuItem in expSubmenuItems)
                            {
                                actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//*[@title='" + expSubmenuItem + "']/span")).Text;
                                Assert.AreEqual(expSubmenuItem, actualSubmenuItem, "Submenu " + expSubmenuItem + " does not exist under " + menuName + " menu");
                            }
                            break;

                        default:
                            Assert.IsTrue(eleMenu.Displayed, menuName + " is not displayed");
                            tmsWait.Hard(2);
                            break;
                    }
                    break;

                case "CDM":
                    switch (menuName)
                    {
                        case "Administration":
                            if (userName.Equals("rootUser"))
                            {
                                expSubmenuItems = new string[] { "Batch Update", "Manage Providers", "CDM Configurations" };
                                eleMenu.Click();
                                tmsWait.Hard(1);
                                foreach (string expSubmenuItem in expSubmenuItems)
                                {
                                    actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//*[@title='" + expSubmenuItem + "']/span")).Text;
                                    Assert.AreEqual(expSubmenuItem, actualSubmenuItem, "Submenu " + expSubmenuItem + " does not exist under " + menuName + " menu");
                                }
                            }
                            break;

                        case "Tasks":
                            if (userName.Equals("rootUser") || userName.Equals("User"))
                            {
                                expSubmenuItems = new string[] { "Import", "Export" };
                                eleMenu.Click();
                                tmsWait.Hard(1);
                                foreach (string expSubmenuItem in expSubmenuItems)
                                {
                                    actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//*[@title='" + expSubmenuItem + "']/span")).Text;
                                    Assert.AreEqual(expSubmenuItem, actualSubmenuItem, "Submenu " + expSubmenuItem + " does not exist under " + menuName + " menu");
                                }
                            }
                            break;

                        default:
                            Assert.IsTrue(eleMenu.Displayed, menuName + " is not displayed");
                            tmsWait.Hard(2);
                            break;
                    } break;


                case "EAM":
                    switch (menuName)
                    {

                        case "Workflow":
                            expSubmenuItems = new string[] { "Start" };
                            eleMenu.Click();
                            tmsWait.Hard(1);
                            foreach (string expSubmenuItem in expSubmenuItems)
                            {
                                actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//*[@title='" + expSubmenuItem + "']/span")).Text;
                                Assert.AreEqual(expSubmenuItem, actualSubmenuItem, "Submenu " + expSubmenuItem + " does not exist under " + menuName + " menu");
                            }
                            break;


                        case "Main":
                            if (userName.Equals("rootUser"))
                                expSubmenuItems = new string[] { "New Transaction", "View/Edit Transaction", "New Member", "View/Edit Member", "EAF Fallout Records" };
                            else
                                expSubmenuItems = new string[] { "View/Edit Transaction", "View/Edit Member" };

                            eleMenu.Click();
                            tmsWait.Hard(1);
                            foreach (string expSubmenuItem in expSubmenuItems)
                            {
                                actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//*[@title='" + expSubmenuItem + "']/span")).Text;
                                Assert.AreEqual(expSubmenuItem, actualSubmenuItem, "Submenu " + expSubmenuItem + " does not exist under " + menuName + " menu");
                            }
                            break;

                        case "Tasks":
                            if (userName.Equals("rootUser"))
                                expSubmenuItems = new string[] { "Import", "Export", "Load Bulk Attachment", "TRR Fallout", "TRR Activity Logging", "LEP Data File Status", "Audit-View/Export", "Actions" };
                            else if (userName.Equals("readOnlyUser"))
                                expSubmenuItems = new string[] { "LEP Data File Status", "Audit-View/Export" };
                            else
                                expSubmenuItems = new string[] { "Load Bulk Attachment", "LEP Data File Status", "Audit-View/Export", "Actions" };

                            eleMenu.Click();
                            tmsWait.Hard(1);
                            foreach (string expSubmenuItem in expSubmenuItems)
                            {
                                actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//*[@title='" + expSubmenuItem + "']/span")).Text;
                                Assert.AreEqual(expSubmenuItem, actualSubmenuItem, "Submenu " + expSubmenuItem + " does not exist under " + menuName + " menu");
                            }
                            break;

                        case "Administration":
                            expSubmenuItems = new string[] { "External Integration", "View/Edit Plan Info.", "Status Override", "Export Session", "Letters", "Recalculations", "Edit LIS Information", "EAM Configuration", "View Bid Data", "BEQ/CMS Transfer", "Manage Plan/SCC", "MMP Management", "Auditing Configuration", "Workflow", "TRR Configuration", "Facets Configuration", "EAF Fallout Configuration" };
                            eleMenu.Click();
                            tmsWait.Hard(1);
                            foreach (string expSubmenuItem in expSubmenuItems)
                            {
                                actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//*[@title='" + expSubmenuItem + "']/span")).Text;
                                Assert.AreEqual(expSubmenuItem, actualSubmenuItem, "Submenu " + expSubmenuItem + " does not exist under " + menuName + " menu");
                            }
                            break;

                        default:
                            Assert.IsTrue(eleMenu.Displayed, menuName + " is not displayed");
                            tmsWait.Hard(2);
                            break;
                    }
                    break;

                case "RxM":
                    switch (menuName)
                    {
                        case "Tasks":
                            expSubmenuItems = new string[] { "Import" };
                            eleMenu.Click();
                            tmsWait.Hard(1);
                            foreach (string expSubmenuItem in expSubmenuItems)
                            {
                                actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//*[@title='" + expSubmenuItem + "']/span")).Text;
                                Assert.AreEqual(expSubmenuItem, actualSubmenuItem, "Submenu " + expSubmenuItem + " does not exist under " + menuName + " menu");
                            }
                            break;

                        case "File Processing Status":
                            expSubmenuItems = new string[] { "File Processing Status", "Loaded File Status" };
                            eleMenu.Click();
                            tmsWait.Hard(1);
                            foreach (string expSubmenuItem in expSubmenuItems)
                            {
                                actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//*[@title='" + expSubmenuItem + "']/span")).Text;
                                Assert.AreEqual(expSubmenuItem, actualSubmenuItem, "Submenu " + expSubmenuItem + " does not exist under " + menuName + " menu");
                            }
                            break;

                        default:
                            Assert.IsTrue(eleMenu.Displayed, menuName + " is not displayed");
                            tmsWait.Hard(2);
                            break;
                    }
                    break;

            }
        }

        // Gurdeep Arora
        [Then(@"verify UI of IDM application")]
        public void ThenVerifyUIOfIDMApplication()
        {
            tmsWait.Hard(4);
            string[] expMenuNames = new string[] { "User Management", "Tenant Configuration", "Identity Provider Administration", "Secrets Configuration" };
            foreach (string expMenuItem in expMenuNames)
            {
                IWebElement actualMenuItem = Browser.Wd.FindElement(By.XPath("//*[@title='" + expMenuItem + "']"));
                Assert.IsTrue(actualMenuItem.Displayed, "Menu " + actualMenuItem + " does not exist");
            }
        }

        // Gurdeep Arora
        [Then(@"verify rules on Claim Transformation Settings page")]
        public void ThenVerifyRulesOnClaimTransformationSettingsPage()
        {
            IWebElement ruleGrid = cfADFSLogin.IdentityProviderAdminPage.claimTransformationRuleGrid;
            IWebElement upArrow;
            IWebElement downArrow;
            string ruleNameText;
            IList<IWebElement> rows = ruleGrid.FindElements(By.TagName("tr"));
            if (rows.Count > 1)
            {
                Console.Write("There are existing claim transaformation rules on the page");

                //for (int i = 1; i <= rows.Count; i++)
                for (int i = 2; i <= rows.Count; i++)
                    {

                 //   upArrow = Browser.Wd.FindElement(By.XPath("//*[@id='claimTransformationGrid']/div[2]/table/tbody/tr[" + i + "]/td[1]/i[1]"));
                    upArrow = Browser.Wd.FindElement(By.XPath("//table//tbody/tr["+i+"]/td/i[1]"));
                    //table//tbody/tr[2]/td/i[2]
                    if (upArrow.Displayed == true)
                    {
                        ruleNameText = rows[i].Text;
                        upArrow.Click();
                        tmsWait.Hard(5);
                        rows = ruleGrid.FindElements(By.TagName("tr"));
                        Assert.AreEqual(ruleNameText, rows[i - 1].Text, "Up Arrow button validation failed");
                        break;
                    }
                }

                for (int i = 2; i <= rows.Count; i++)
                {

                    downArrow = Browser.Wd.FindElement(By.XPath("//table//tbody/tr[" + i + "]/td/i[2]"));
                    if (downArrow.Displayed == true)
                    {
                        ruleNameText = rows[i].Text;
                        downArrow.Click();
                        tmsWait.Hard(5);
                        rows = ruleGrid.FindElements(By.TagName("tr"));
                        Assert.AreEqual(ruleNameText, rows[i + 1].Text, "Up Arrow button validation failed");
                        break;
                    }
                }

            }

            else {
                Console.Write("There are no claim transaformation rules on the page");
            }

        }


        //Gurdeep Arora
        [Then(@"verify UI of IDM Identity Provider Administration page")]
        public void ThenVerifyUIOfIDMIdentityProviderAdministrationPage()
        {
            tmsWait.Hard(3);
            Assert.IsTrue(cfADFSLogin.IdentityProviderAdminPage.identityProviderOpenIDRadio.Enabled, "Open ID radio is not displayed");
            Assert.IsTrue(cfADFSLogin.IdentityProviderAdminPage.identityProviderWSSecurity.Enabled, "WS Security radio is not displayed");
            Assert.IsTrue(cfADFSLogin.IdentityProviderAdminPage.identityProviderEnableLocalAuthentication.Enabled, "Enable Local Authentication is not enabled");
            Assert.IsTrue(cfADFSLogin.IdentityProviderAdminPage.identityProviderOpenID.Selected, "Open ID radio is not selected");
        }

        [Then(@"verify error message when local authentication is turned off")]
        [When(@"verify error message when local authentication is turned off")]
        [Given(@"verify error message when local authentication is turned off")]

        public void ThenVerifyErrorMessageWhenLocalAuthenticationIsTurnedOff()
        {
            string expErrMessage = "Local Authentication can't be turned off as there are no external identity provider/s set";
            cfADFSLogin.IdentityProviderAdminPage.identityProviderEnableLocalAuthentication.Click();
            string actualErrMsg = Browser.Wd.FindElement(By.ClassName("toast-message")).GetAttribute("aria-label");
            Assert.AreEqual(expErrMessage, actualErrMsg, "Toaster message is not displayed");
        }


        [Then(@"verify default values of autopopulated fields")]
        public void ThenVerifyDefaultValuesOfAutopopulatedFields()
        {
            tmsWait.Hard(3);
            Assert.AreEqual("openid tms_userinfo tms_app_api", cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderScope.GetAttribute("value"), "Scope value is not defaulted to correct value");
            Assert.AreEqual("id_token token", cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderResponseType.GetAttribute("value"), "Response Type value is not defaulted to correct value");

        }

        [When(@"i select ""(.*)"" radio button")]
        public void WhenISelectRadioButton(string p0)
        {
            switch (p0) {

                case "WS Security":
                    tmsWait.Hard(5);
                    AngularFunction.clickOnElement(cfADFSLogin.IdentityProviderAdminPage.identityProviderWSSecurity);
                   // cfADFSLogin.IdentityProviderAdminPage.identityProviderWSSecurity.Click();
                    tmsWait.Hard(1);


                    break;


            }
        }



        //Gurdeeep Arora
        [When(@"I click on Add Provider button for ""(.*)""")]
        [Then(@"I click on Add Provider button for ""(.*)""")]
        [Given(@"I click on Add Provider button for ""(.*)""")]
        public void WhenIClickOnAddProviderButtonFor(string p0)
        {
            switch (p0) {
                case "WS Security":
                    cfADFSLogin.IdentityProviderAdminPage.identityProviderAddButten.Click();
                    tmsWait.Hard(5);
                    //Assert.IsTrue(cfADFSLogin.IdentityProviderAdminPage.WSAddProviderPopup.Displayed);
                    AngularFunction.elementPresenceUsingWebElement(cfADFSLogin.IdentityProviderAdminPage.WSAddProviderPopup);
                    tmsWait.Hard(2);
                    break;

                case "OpenID Connect":
                    cfADFSLogin.IdentityProviderAdminPage.identityProviderAddButten.Click();
                    tmsWait.Hard(5);
                    Assert.IsTrue(cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderPopup.Displayed);
                    tmsWait.Hard(2);
                    break;

            }
        }

        //Gurdeep Arora
        [When(@"I click on Save buttton on Add ""(.*)"" Provider window")]
        [Then(@"I click on Save buttton on Add ""(.*)"" Provider window")]
        [Given(@"I click on Save buttton on Add ""(.*)"" Provider window")]
        public void WhenIClickOnSaveButttonOnAddProviderWindow(string p0)
        {
            switch (p0) {
                case "OpenID Connect":
                    cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderSaveBtn.Click();
                    break;

                case "WS Security":
                    cfADFSLogin.IdentityProviderAdminPage.WSSaveButton.Click();
                    break;

            }

        }

        //Gurdeep Arora
        [Then(@"Verify error message is displayed on ""(.*)"" page as ""(.*)""")]
        public void ThenVerifyErrorMessageIsDisplayedOnPageAs(string p0, string p1)
        {
            IWebElement errorMsg;
            switch (p0)
            {
                case "OpenID Connect":
                    errorMsg = Browser.Wd.FindElement(By.XPath("//form[@id='openIdconnectFrm']//span[contains(., '" + p1 + "')]"));
                    Assert.IsTrue(errorMsg.Displayed);
                    break;

                case "WS Security":
                    errorMsg = Browser.Wd.FindElement(By.XPath("//form[@id='wSSecurityFrm']//span[contains(., '" + p1 + "')]"));
                    Assert.IsTrue(errorMsg.Displayed);
                    break;
            }
        }


        //Gurdeep Arora
        [When(@"i enter all mandatory values on Add OpenID Connect Provider window and click on save butten")]
        public void WhenIEnterAllMandatoryValuesOnAddOpenIDConnectProviderWindowAndClickOnSaveButten()
        {
            string DBName = "DBClientID";
            db.CreateConnRAMX(DBName);
            string dbQuery = tmsCommon.GenerateData("select top 1 clientId from[IdentityServer].[dbo].[Clients]");
            db.AddDBQuery(DBName, dbQuery);


            string caption = tmsCommon.GenerateData("Generate|'OpenId'|num|3|");
            GlobalRef.captionText = caption;

            string clientId = db.StoreDBResultsInString(DBName);
            string changePwdUrl = ConfigFile.URL; // check
            string redirectURI = ConfigFile.URL; // check;

            GlobalRef.clientId = clientId;
            cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderCaption.SendKeys(caption);
            cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderClientId.SendKeys(clientId);
            cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderAuthority.SendKeys(ConfigFile.URL);
            cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderChangePwdURL.SendKeys(changePwdUrl);
            cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderRedirectURI.SendKeys(redirectURI);

            cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderSaveBtn.Click();
            tmsWait.Hard(2);

            IWebElement captionInGrid = Browser.Wd.FindElement(By.XPath("//td[contains(., '" + caption + "')]"));
            Assert.IsTrue(captionInGrid.Displayed);
        }


        //Gurdeep Arora
        [Then(@"verify on Identity Provider Administration page Active checkbox is unchecked")]
        public void ThenVerifyOnIdentityProviderAdministrationPageActiveCheckboxIsUnchecked()
        {
            editIdentityProvider();
        }


        //Gurdeep Arora
        [When(@"i enter all mandatory values on Add OpenID Connect Provider window and ""(.*)"" Active checkbox and click on save butten")]
        public void WhenIEnterAllMandatoryValuesOnAddOpenIDConnectProviderWindowAndActiveCheckboxAndClickOnSaveButten(string p0)
        {
            string DBName = "DBClientID";
            db.CreateConnRAMX(DBName);
            string dbQuery = tmsCommon.GenerateData("select top 1 clientId from[IdentityServer].[dbo].[Clients]");
            db.AddDBQuery(DBName, dbQuery);


            string caption = tmsCommon.GenerateData("Generate|'OpenId'|num|3|");
            GlobalRef.captionText = caption;

            string clientId = db.StoreDBResultsInString(DBName);
            string changePwdUrl = ConfigFile.URL; // check
            string redirectURI = ConfigFile.URL; // check;

            GlobalRef.clientId = clientId;
            cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderCaption.SendKeys(caption);
            cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderClientId.SendKeys(clientId);
            cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderAuthority.SendKeys(ConfigFile.URL);
            cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderChangePwdURL.SendKeys(changePwdUrl);
            cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderRedirectURI.SendKeys(redirectURI);
            bool isSelected = cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderActiveCheckbox.Selected;
            if (isSelected == true)
            {
                if (p0 == "uncheck")
                {
                    cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderActiveCheckbox.Click();
                }
            }
            else
            {
                if (p0 == "check")
                {
                    cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderActiveCheckbox.Click();
                }

            }

            cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderSaveBtn.Click();
            tmsWait.Hard(2);

            searchIdentityProvider(caption);

        }




        //Gurdeep Arora
        [Then(@"i edit OpenId Connect Provider information and verify toaster message ""(.*)""")]
        public void ThenIEditOpenIdConnectProviderInformationAndVerifyToasterMessage(string p0)
        {
            string caption = GlobalRef.captionText.ToString();
            string expMessage = tmsCommon.GenerateData(p0);
           // IWebElement editButton = Browser.Wd.FindElement(By.XPath("//*[@id='identityProviderGrid']/div[2]//tr[contains(., '" + caption + "')]/td[8]/a"));
            IWebElement editButton = Browser.Wd.FindElement(By.XPath("//div[@role='grid']//td[@data-kendo-grid-column-index=1][contains(text(),'"+ caption +"')]/following-sibling::td//span[@class='fas fa-pencil-alt']"));
            AngularFunction.clickOnElement(editButton);
            //editButton.Click();
            tmsWait.Hard(2);
            cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderCaption.Clear();
            tmsWait.Hard(1);
            cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderCaption.SendKeys("Edit" + caption);
            cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderActiveCheckbox.Click();
            tmsWait.Hard(2);
            bool isSelected = cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderActiveCheckbox.Selected;

            cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderUpdateBtn.Click();
            //string actualValue = Browser.Wd.FindElement(By.ClassName("toast-message")).GetAttribute("aria-label");
            By toastMsg = By.XPath("//div[@class='k-notification-content']");
            string actValue = Browser.Wd.FindElement(toastMsg).Text;
            Assert.AreEqual(expMessage, actValue, "Toaster message is not displayed");
                
            IWebElement captionInGrid = Browser.Wd.FindElement(By.XPath("//td[contains(., 'Edit" + caption + "')]"));
            IWebElement activeCheckboxInGrid = Browser.Wd.FindElement(By.XPath("//td[contains(., 'Edit" + caption + "')]/parent::tr//td[6]/input"));
         

            searchIdentityProvider(caption);

            if (isSelected == true)
            {
                Assert.IsTrue(activeCheckboxInGrid.Selected);
            }
            else {
                Assert.IsFalse(activeCheckboxInGrid.Selected);
            }
        }


        //Gurdeep Arora
        [Then(@"verify error message when i enter incorrect values in Authority URL, Change Password URL, Redirect URL")]
        public void ThenVerifyErrorMessageWhenIEnterIncorrectValuesInAuthorityURLChangePasswordURLRedirectURL()
        {
            string DBName = "DBClientID";
            db.CreateConnRAMX(DBName);
            string dbQuery = tmsCommon.GenerateData("select top 1 clientId from[IdentityServer].[dbo].[Clients]");
            db.AddDBQuery(DBName, dbQuery);
            string clientId = db.StoreDBResultsInString(DBName);

            string caption = tmsCommon.GenerateData("Generate|'OpenId'|num|3|");


            cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderCaption.SendKeys(caption);
            cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderClientId.SendKeys(clientId);
            cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderAuthority.SendKeys("TestAuthorityURL");
            cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderChangePwdURL.SendKeys("TestChangePasswordURL");
            cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderRedirectURI.SendKeys("TestRedirectURI");
            cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderSaveBtn.Click();
            tmsWait.Hard(2);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[@id='txtAuthority-error-msg']")).Displayed);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[@id='txtChangePasswordURL-error-msg']")).Displayed);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[@id='txtRedirectURI-error-msg']")).Displayed);

        }

        //Gurdeep Arora
        [Then(@"verify error message when i enter incorrect values in Metadata, Change Password URL")]
        public void ThenVerifyErrorMessageWhenIEnterIncorrectValuesInMetadataChangePasswordURL()
        {
            string caption = tmsCommon.GenerateData("Generate|'WS'|num|3|");
            cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderCaption.SendKeys(caption);
            cfADFSLogin.IdentityProviderAdminPage.WSWtrelam.SendKeys("urn:identityServerz");
            cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderChangePwdURL.SendKeys("TestChangePasswordURL");
            cfADFSLogin.IdentityProviderAdminPage.WSMetadata.SendKeys("TestWSMetadata");
            cfADFSLogin.IdentityProviderAdminPage.WSSaveButton.Click();
            tmsWait.Hard(2);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[@id='txtMetadata-error-msg']")).Displayed);
            Assert.IsTrue(Browser.Wd.FindElement(By.XPath("//span[@id='txtChangePasswordURL-error-msg']")).Displayed);
            cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderChangePwdURL.Clear();
            cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderChangePwdURL.SendKeys("https://asp-tms-adfs-01.dev.trizetto.com/federationmetadata/2007-06/federationmetadata.xml");
            cfADFSLogin.IdentityProviderAdminPage.WSMetadata.Clear();
            cfADFSLogin.IdentityProviderAdminPage.WSMetadata.SendKeys("https://asp-tms-adfs-01.dev.trizetto.com/adfs/portal/updatepassword");
            cfADFSLogin.IdentityProviderAdminPage.WSSaveButton.Click();
            tmsWait.Hard(7);
            searchIdentityProvider(caption);

        }

        [When(@"i enter all mandatory information on Add WS Provider window and click on save butten")]
        public void WhenIEnterAllMandatoryInformationOnAddWSProviderWindowAndClickOnSaveButten()
        {
            string caption = tmsCommon.GenerateData("Generate|'WS'|num|3|");
            IWebElement activeCheckboxInGrid = Browser.Wd.FindElement(By.XPath("//*[@id='identityProviderGrid']//tr[contains(., 'Edit" + caption + "')]/td[6]/input"));


            cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderCaption.SendKeys(caption);
            cfADFSLogin.IdentityProviderAdminPage.WSWtrelam.SendKeys("urn:identityServerz");
            cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderChangePwdURL.Clear();
            cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderChangePwdURL.SendKeys("https://asp-tms-adfs-01.dev.trizetto.com/federationmetadata/2007-06/federationmetadata.xml");
            cfADFSLogin.IdentityProviderAdminPage.WSMetadata.Clear();
            cfADFSLogin.IdentityProviderAdminPage.WSMetadata.SendKeys("https://asp-tms-adfs-01.dev.trizetto.com/adfs/portal/updatepassword");
            cfADFSLogin.IdentityProviderAdminPage.WSSaveButton.Click();
            bool isSelected = cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderActiveCheckbox.Selected;
            if (isSelected == true)
            {
                Assert.IsTrue(activeCheckboxInGrid.Selected);
            }
            else
            {
                Assert.IsFalse(activeCheckboxInGrid.Selected);
            }

            tmsWait.Hard(7);

            searchIdentityProvider(caption);
        
    }


        [Then(@"i click on Local Authentication button")]
        public void ThenIClickOnLocalAuthenticationButton()
        {
            cfADFSLogin.IdentityProviderAdminPage.identityProviderEnableLocalAuthentication.Click();
            IWebElement editButton = Browser.Wd.FindElement(By.XPath("//*[@id='identityProviderGrid']/div[2]//tr[2]/td[8]/a"));
            string providerType = Browser.Wd.FindElement(By.XPath("//*[@id='identityProviderGrid']//tr[2]/td[1]")).Text;
            tmsWait.Hard(2);
            editButton.Click();
            tmsWait.Hard(3);
            bool isSelected = cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderActiveCheckbox.Selected;
            if (isSelected == false)
            {
                tmsWait.Hard(3);
                cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderActiveCheckbox.Click();

                if (providerType.Equals("OPENID"))
                    cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderUpdateBtn.Click();
                else if (providerType.Equals("WS"))
                    cfADFSLogin.IdentityProviderAdminPage.WSUpdateBtn.Click();

                tmsWait.Hard(4);
            }
            cfADFSLogin.IdentityProviderAdminPage.identityProviderEnableLocalAuthentication.Click();
        }



        //Gurdeep Arora
        public void editIdentityProvider()
        {
          By activeCheckBox = By.XPath("//tr/td[6]/input");

            IWebElement nextPage = Browser.Wd.FindElement(By.XPath("//a[@title='Go to the next page']"));

            bool isEnabled = nextPage.Enabled;

           
            string tpage = Browser.Wd.FindElement(By.XPath("//*[@id='identityProviderGrid']/div[3]/span[1]")).Text;
            int currentPageNum = Convert.ToInt32(Browser.Wd.FindElement(By.XPath("//*[@id='identityProviderGrid']/div[3]/span[1]/input")).GetAttribute("aria-label"));

            string[] pages = tpage.Split(' ');
            int lastPage = Convert.ToInt32(pages[1]);

            while (currentPageNum <= lastPage) 
            {
                    IWebElement providerGrid = Browser.Wd.FindElement(By.XPath("//*[@id='identityProviderGrid']"));
                    IList<IWebElement> rows = providerGrid.FindElements(By.TagName("tr"));
                    for (int i = 1; i < rows.Count; i++)
                    {
                        IWebElement editButton = Browser.Wd.FindElement(By.XPath("//*[@id='identityProviderGrid']/div[2]//tr[" + i + "]/td[8]/a"));
                        string providerType = Browser.Wd.FindElement(By.XPath("//*[@id='identityProviderGrid']//tr[" + i + "]/td[1]")).Text;
                        tmsWait.Hard(2);
                        editButton.Click();
                        tmsWait.Hard(3);
                        bool isSelected = cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderActiveCheckbox.Selected;
                        if (isSelected == true)
                        {
                            tmsWait.Hard(3);
                            cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderActiveCheckbox.Click();

                            if (providerType.Equals("OPENID"))
                                cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderUpdateBtn.Click();
                            else if (providerType.Equals("WS"))
                                cfADFSLogin.IdentityProviderAdminPage.WSUpdateBtn.Click();

                            tmsWait.Hard(4);
                        }
                        else
                        {
                            tmsWait.Hard(3);

                            if (providerType.Equals("OPENID"))
                                cfADFSLogin.IdentityProviderAdminPage.openIdConnectProviderCloseBtn.Click();
                            else if (providerType.Equals("WS"))
                                cfADFSLogin.IdentityProviderAdminPage.WSCloseButton.Click();

                            tmsWait.Hard(4);
                        }
                    }
                       nextPage.Click();
                        tmsWait.Hard(3);
                        currentPageNum = Convert.ToInt32(Browser.Wd.FindElement(By.XPath("//*[@id='identityProviderGrid']/div[3]/span[1]/input")).GetAttribute("aria-label"));

            }
   }

           //Gurdeep Arora
           public void searchIdentityProvider(string caption) {
            
            bool elementSearch = false;
            //By captionBy = By.XPath("//*[@id='identityProviderGrid']//span[contains(., '" + caption + "')]");
            By captionBy = By.XPath("//div[@role='grid']//td[@data-kendo-grid-column-index=1][contains(text(),'" + caption + "')]");
            By nextPage = By.XPath("//a[@title='Go to the next page']");

            while (!elementSearch)
            {
                elementSearch = elementPresence(captionBy);
                tmsWait.Hard(3);
                if (!elementSearch)
                {
                    try
                    {
                        fw.ExecuteJavascript(Browser.Wd.FindElement(nextPage));
                    }
                    catch
                    {
                        Assert.Fail(" Expected MBI is not present on Export Search results");
                    }
                }

                if (elementSearch)
                {
                    Assert.AreEqual(true, elementSearch, "caption not found");
                }


            }

      }

        public bool elementPresence(By ele)
        {

            try
            {
                Browser.Wd.FindElement(ele);
                return true;
            }
            catch
            {
                return false;
            }

        }





        //Gurdeep Arora
        [When(@"i verify EAM menu ""(.*)"" for user ""(.*)"" and verify submenu options")]
        [Then(@"i verify EAM menu ""(.*)"" for user ""(.*)"" and verify submenu options")]
        public void ThenIVerifyEAMMenuForUserAndVerifySubmenuOptions(string p0, string p1)
        {
            string menuName = tmsCommon.GenerateData(p0);
            string userName = tmsCommon.GenerateData(p1);
            string actualSubmenuItem;
            string[] expSubmenuItems = null; 
            tmsWait.Hard(2);

            IWebElement eleMenu = Browser.Wd.FindElement(By.XPath("//*[@title='" + menuName + "']"));
            Assert.IsTrue(eleMenu.Displayed, menuName + " is not displayed");
            tmsWait.Hard(2);


            switch (menuName)
            {
                case "Workflow":
                    expSubmenuItems = new string[] { "Start" };
                    //eleMenu.Click();
                    AngularFunction.clickOnElement(eleMenu);
                    tmsWait.Hard(1);
                    foreach (string expSubmenuItem in expSubmenuItems)
                    {
                        //actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//*[@title='" + expSubmenuItem + "']/span")).Text;
                        //actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//kendo-drawer[@test-id='subMenu-titleList']//span")).Text;
                        actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//kendo-drawer[@test-id='subMenu-titleList']//span[contains(.,'" + expSubmenuItem + "')]")).Text;
                        Assert.AreEqual(expSubmenuItem, actualSubmenuItem, "Submenu " + expSubmenuItem + " does not exist under " + menuName + " menu");
                    }
                
                    break;

                case "Main":
                    if (userName.Equals("UserWithNoTC90"))
                        expSubmenuItems = new string[] { "New Transaction", "View/Edit Transaction", "New Member", "View/Edit Member","EAF Fallout Records","Check Eligibility" };
                    else if (userName.Equals("UserTC90StatusOverride")) 
                        expSubmenuItems = new string[] { "New Transaction", "View/Edit Transaction", "New Member", "View/Edit Member", "TC 90", "EAF Fallout Records","Check Eligibility" };
                    AngularFunction.clickOnElement(eleMenu);
                    //eleMenu.Click();
                    tmsWait.Hard(2);
                    foreach (string expSubmenuItem in expSubmenuItems)
                    {
                        //actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//*[@title='" + expSubmenuItem + "']/span")).Text;
                        actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//kendo-drawer[@test-id='subMenu-titleList']//span[contains(.,'"+ expSubmenuItem +"')]")).Text;
                        Assert.AreEqual(expSubmenuItem, actualSubmenuItem, "Submenu " + expSubmenuItem + " does not exist under " + menuName + " menu");
                    }
               
                    break;

                case "Tasks":
                    expSubmenuItems = new string[] { "Load Bulk Attachment", "LEP Data File Status", "Audit-View/Export", "Actions" };
                    eleMenu.Click();
                    tmsWait.Hard(1);
                    foreach (string expSubmenuItem in expSubmenuItems)
                    {
                        //actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//*[@title='" + expSubmenuItem + "']/span")).Text;
                        actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//kendo-drawer[@test-id='subMenu-titleList']//span[contains(.,'" + expSubmenuItem + "')]")).Text;
                        Assert.AreEqual(expSubmenuItem, actualSubmenuItem, "Submenu " + expSubmenuItem + " does not exist under " + menuName + " menu");
                    }
                
                    break;

                case "Administration":
                    expSubmenuItems = new string[] { "Status Override" };
                    eleMenu.Click();
                    tmsWait.Hard(1);
                    foreach (string expSubmenuItem in expSubmenuItems)
                    {
                        //actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//*[@title='" + expSubmenuItem + "']/span")).Text;
                        actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//kendo-drawer[@test-id='subMenu-titleList']//span[contains(.,'" + expSubmenuItem + "')]")).Text;
                        Assert.AreEqual(expSubmenuItem, actualSubmenuItem, "Submenu " + expSubmenuItem + " does not exist under " + menuName + " menu");
                    }
                  
                    break;

            }
        }




        //Gurdeep Arora
        [Then(@"i verify EAM menu ""(.*)"" and verify submenu items")]
        public void ThenIVerifyEAMMenuAndVerifySubmenuItems(string p0)
        {
            string menuName = tmsCommon.GenerateData(p0);
            string actualSubmenuItem;
            string[] expSubmenuItems;
            tmsWait.Hard(2);

            IWebElement eleMenu= Browser.Wd.FindElement(By.XPath("//*[@title='" + menuName + "']"));
            Assert.IsTrue(eleMenu.Displayed, menuName + " is not displayed");
            tmsWait.Hard(2);


            switch (menuName)
            {
                case "Workflow":
                    expSubmenuItems = new string[] { "Start" };
                    eleMenu.Click();
                    tmsWait.Hard(1);
                    foreach (string expSubmenuItem in expSubmenuItems)
                    {
                        actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//*[@title='" + expSubmenuItem + "']/span")).Text;
                        Assert.AreEqual(expSubmenuItem, actualSubmenuItem, "Submenu " + expSubmenuItem + " does not exist under " + menuName + " menu");
                    }
                    break;

                case "Main":
                  
                    expSubmenuItems = new string[] { "New Transaction", "View/Edit Transaction", "New Member", "View/Edit Member", "TC 90", "EAF Fallout Records" };
                    eleMenu.Click();
                    tmsWait.Hard(1);
                    foreach (string expSubmenuItem in expSubmenuItems)
                    {
                        actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//*[@title='" + expSubmenuItem + "']/span")).Text;
                        Assert.AreEqual(expSubmenuItem, actualSubmenuItem, "Submenu " + expSubmenuItem + " does not exist under " + menuName + " menu");
                    }
                    break;
                 
                case "Tasks":
                    expSubmenuItems = new string[] { "Load Bulk Attachment", "LEP Data File Status", "Audit-View/Export", "Actions" };
                    eleMenu.Click();
                    tmsWait.Hard(1);
                    foreach (string expSubmenuItem in expSubmenuItems)
                    {
                        actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//*[@title='" + expSubmenuItem + "']/span")).Text;
                        Assert.AreEqual(expSubmenuItem, actualSubmenuItem, "Submenu " + expSubmenuItem + " does not exist under " + menuName + " menu");
                    }
                    break;

                case "Administration":
                    expSubmenuItems = new string[] { "Status Override"};
                    eleMenu.Click();
                    tmsWait.Hard(1);
                    foreach (string expSubmenuItem in expSubmenuItems)
                    {
                        actualSubmenuItem = Browser.Wd.FindElement(By.XPath("//*[@title='" + expSubmenuItem + "']/span")).Text;
                        Assert.AreEqual(expSubmenuItem, actualSubmenuItem, "Submenu " + expSubmenuItem + " does not exist under " + menuName + " menu");
                    }
                    break;

            }
        }



        //Gurdeep Arora
        [Then(@"verify claim details sub grid is displayed")]
        public void ThenVerifyClaimDetailsSubGridIsDisplayed()
        {
            //IWebElement claimGrid = Browser.Wd.FindElement(By.XPath("//*[@test-id='users-grid-grdUserClaimInfo']"));
            string[] columnNames = new string[] { "Claim Name", "Claim Value" };
            foreach (string column in columnNames)
            {
                //IWebElement gridElement = Browser.Wd.FindElement(By.XPath("//*[@test-id='users-grid-grdUserClaimInfo']//tr/th[contains(.,'" + column + "')]"));
                IWebElement gridElement = Browser.Wd.FindElement(By.XPath("//span[contains(.,'" + column + "')]"));
                Assert.IsTrue(gridElement.Displayed, "Column Name : " + column + " is not displayed in file processing grid ");
            }
            //Assert.IsFalse(claimGrid.Enabled, "Claim details sub-grid is not disabled");
        }

        

        [When(@"for any user plus icon is clicked")]
        public void WhenForAnyUserPlusIconIsClicked()
        {
            ReUsableFunctions.clickOnWebElement(EAM.UserAdministrationCrudUser.UserList_ExpandBtn);
        }


        [Then(@"Clicked on Last page Pagination and Verify newly added User ID ""(.*)"" is getting displayed")]
        public void ThenClickedOnLastPagePaginationAndVerifyNewlyAddedUserIDIsGettingDisplayed(string p0)
        {
            //  By path = By.XPath("//a[@title='Go to the last page']");
            //UIMODUtilFunctions.clickOnWebElementUsingLocators(path);
            tmsWait.Hard(3);
            AngularFunction.clickonLastpageLink();
            tmsWait.Hard(3);
            string newuser = tmsCommon.GenerateData(p0);
            //By newuserloc = By.XPath("//div[@test-id='users-grid-users']//span[@ng-bind='dataItem.name'][contains(.,'" + newuser + "')]");
            By newuserloc = By.XPath("//div[@test-id='users-grid-usersGrid']//td[contains(.,'" + newuser + "')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(newuserloc);
            fw.ConsoleReport(" New Created ADFS User found User List page :" + newuser);
        }

        [Then(@"Verify Data Load Manager Application is getting displayed")]
        public void ThenVerifyDataLoadManagerApplicationIsGettingDisplayed()
        {
            tmsWait.Hard(3);
            //By newuserloc = By.XPath("//span[@test-id='header-title-applicationName']");
            By newuserloc = By.XPath("//div[contains(.,'Data Load Manager')]");
            UIMODUtilFunctions.elementPresenceUsingLocators(newuserloc);
        }

        [Then(@"Verify Error Binding message displayed as ""(.*)""")]
        public void ThenVerifyErrorBindingMessageDisplayedAs(string p0)
        {
            tmsWait.Hard(5);
            string actualresult = UIMODUtilFunctions.returnTextUsingWebElement(cfADFSLogin.ADFSLoginPage.errorBindMsg);
            string expectedresult = p0;

            Assert.AreEqual(expectedresult, actualresult, "Both are not matching");
        }

        [When(@"I Clicked on Log out button")]
        public void WhenIClickedOnLogOutButton()
        {
            UIMODUtilFunctions.clickOnWebElementUsingLocators(cfADFSLogin.ADFSLoginPage.logoutButton);
            tmsWait.Hard(3);

        }

        [When(@"ADFS Update Password Default page Email Id is set to ""(.*)""")]
        public void WhenADFSUpdatePasswordDefaultPageEmailIdIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            string value = tmsCommon.GenerateData(p0);
            ReUsableFunctions.enterValueOnWebElementWithoutClear(cfADFSLogin.ADFSLoginPage.email, value);
        }

        [When(@"ADFS Update Password Default page Old Password is set to ""(.*)""")]
        public void WhenADFSUpdatePasswordDefaultPageOldPasswordIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            string value = tmsCommon.GenerateData(p0);
            ReUsableFunctions.enterValueOnWebElementWithoutClear(cfADFSLogin.ADFSLoginPage.OldPassword, value);
        }

        [When(@"ADFS Update Password Default page New Password is set to ""(.*)""")]
        public void WhenADFSUpdatePasswordDefaultPageNewPasswordIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            string value = tmsCommon.GenerateData(p0);
            ReUsableFunctions.enterValueOnWebElementWithoutClear(cfADFSLogin.ADFSLoginPage.NewPassword, value);
        }

        [When(@"ADFS Update Password Default page Confirm New Password is set to ""(.*)""")]
        public void WhenADFSUpdatePasswordDefaultPageConfirmNewPasswordIsSetTo(string p0)
        {
            tmsWait.Hard(5);
            string value = tmsCommon.GenerateData(p0);
            ReUsableFunctions.enterValueOnWebElementWithoutClear(cfADFSLogin.ADFSLoginPage.ConfNewPassword, value);
        }

        [When(@"ADFS Update Password Default page Submit Button is Clicked")]
        public void WhenADFSUpdatePasswordDefaultPageSubmitButtonIsClicked()
        {
            UIMODUtilFunctions.clickOnWebElementUsingLocators(cfADFSLogin.ADFSLoginPage.SubmitButton);
            tmsWait.Hard(3);
        }


        [Then(@"Verify Log out message displayed as ""(.*)""")]
        public void ThenVerifyLogOutMessageDisplayedAs(string p0)
        {
            tmsWait.Hard(5);
            string actualresult = UIMODUtilFunctions.returnTextUsingWebElement(cfADFSLogin.ADFSLoginPage.logoutMessage);
            string expectedresult = p0;

            Assert.AreEqual(expectedresult, actualresult, "Both are not matching");
        }

       



        [Then(@"Verify Error message displayed as ""(.*)""")]
        public void ThenVerifyErrorMessageDisplayedAs(string p0)
        {
            tmsWait.Hard(5);
            string actualresult = UIMODUtilFunctions.returnTextUsingWebElement(cfADFSLogin.ADFSLoginPage.errorMsg);
            string expectedresult = p0;

            Assert.AreEqual(expectedresult, actualresult, "Both are not matching");
        }

    }
}
