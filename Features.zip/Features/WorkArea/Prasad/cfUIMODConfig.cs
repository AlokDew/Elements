﻿using OpenQA.Selenium;
using System.Collections.Generic;
using TechTalk.SpecFlow;
using TMSoR1.FrameworkCode;

namespace TMSoR1.Features.WorkArea.Prasad
{
    [Binding]
    class cfUIMODConfig
    {
        [When(@"Language Page ""(.*)"" is set to ""(.*)""")]
        public void WhenLanguagePageIsSetTo(string p0, string p1)
        {
            string txtName = tmsCommon.GenerateData(p0);
            string value = tmsCommon.GenerateData(p1);
            switch (txtName)
            {
                case "code":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.Language.Code, value);
                    break;
                case "Language":
                    ReUsableFunctions.enterValueOnWebElement(cfUIMODEAMConfiguration.Language.LanguageTextbox, value);
                    break;
            }
        }
        [When(@"Language page clicked on save button")]
        public void WhenLanguagePageClickedOnSaveButton()
        {
            ReUsableFunctions.clickOnWebElement(cfUIMODEAMConfiguration.Language.SaveButton);
            tmsWait.Hard(3);
        }

        
        [Then(@"Language page verify the record in gridd")]
        public void ThenLanguagePageVerifyTheRecordInGridd()
        {
            
        }

    }
}
