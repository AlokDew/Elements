--Multiple Flag ON

--Select PlanID,Create_72_NoRX, Create_72_TRR from tbplans
--Update tbplans Set Create_72_NoRX = 1,Create_72_TRR = 1
Select * from tbplan_pbp where PlanID = 'H1003' and PBPID = '011'
Select * from tbplans where PlanID = 'H1003'

Update tbplan_pbp Set Multiple = 1
Select multiple from tbplan_pbp

Delete FROM [dbo].[tbEGWPPlanPbpAssociation]

 -- EAF - H1001,001MAPD with idtyep  = 0
    --H1003,011
	--H1003,011 MAPD with idtype = 2

select PP.PlanID,PBPID,PBPtype,IDType from tbplan_pbp PP Inner join tbplans P ON PP.PlanID = P.PlanID where PP.PlanID='H0002' and PP.PBPID = '006'
--Update tbplan_pbp Set PBPtype = 0 where PlanID='H0002' and PBPID='006'
select PP.PlanID,PBPID,PBPtype,IDType from tbplan_pbp PP Inner join tbplans P ON PP.PlanID = P.PlanID where PP.PlanID='H1003' and PP.PBPID = '011'
select PP.PlanID,PBPID,PBPtype,IDType from tbplan_pbp PP Inner join tbplans P ON PP.PlanID = P.PlanID where PP.PlanID='S2004' and PP.PBPID = '016'
select PP.PlanID,PBPID,PBPtype,IDType from tbplan_pbp PP Inner join tbplans P ON PP.PlanID = P.PlanID where PP.PlanID='H1005' and PP.PBPID = '021'

--select IDType , * from tbplans  where PlanID='H1003'
--select IDType , * from tbplans  where PlanID='S2004'
---select IDType , * from tbplans  where PlanID='H1005'

 --Accepted BY CMs
 -- Change Rx Id - PCP1, PCP2,PCP3...
 --Uplaod TRR - 117/118/100 with Plan - H1003,011/ S2004,016 / H1003,012
 -- 15/16 - New TC 61 & 72 Autogeneratd RX
 --17 Plan Change with Same RxId PCP17 


  
select HIC,TransStatus,* from tbTRansactions where 
HIC in ('7C77C10PN15','7C77C10PN16','7C77C10PN17')
 
 
select HIC,MemberStatus,* from tbEEnrlMembers where 
HIC in ('7C77C10PN15','7C77C10PN16','7C77C10PN17')


select HIC,MemCodNUm,* from tbTRansactions where 
HIC in ('7C77C10PN15','7C77C10PN16','7C77C10PN17')


select RxID,* from tbMemberInfo where MemCodNum in ('21918','21916','21917')

select HIC,PlanId,PBPID,MemCodNUm,* from tbTRansactions where 
HIC in ('7C77C10PN15','7C77C10PN16','7C77C10PN17')
And TransCode='72'

Select * from tbtransactions where hic = '7C77C10PN16'


 
select HIC,PlanID,PBP,* from tbEEnrlMembers where 
HIC in ('7C77C10PN15','7C77C10PN16','7C77C10PN17')

select HIC,RxID,* from tbTRansactions where 
HIC in ('7C77C10PN15','7C77C10PN16','7C77C10PN17')
And TransCode='72'

