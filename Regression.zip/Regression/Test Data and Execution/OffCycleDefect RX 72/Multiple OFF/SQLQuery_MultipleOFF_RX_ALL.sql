-- EAF - 
--1. H0002/006 - MA plan with Id 1
--2. H1003/011 - MAPD Plan with ID2
--3. H1001/011 - MAPD Id 0


--7A77C01AA05 - H0002/006 - MA plan with Id 1
--7A77C01AA06 - H0002/006 - MA plan with Id 1
--7A77C01AA07 - H0002/006 - MA plan with Id 1
--7A77C01AA10 - H1003/011 - MAPD Plan with ID2


Select multiple from tbplan_pbp
Update tbplan_pbp Set multiple = 0


Select tbpbp.PlanID, PBPID, PBPtype,IDType From tbPlan_pbp tbpbp inner join tbPlans tbplan
on tbpbp.PlanId = tbPlan.PlanId
Where tbpbp.PlanId in ('H0002','H1003','S2004','H1005') and tbpbp.PBPID in ('006','011','016','021')  

Select multiple,* from tbplan_pbp
Update tbplan_pbp Set multiple = 0

Select * from tbplans


Select * from tbtransactions where hic like '7A77C01AA%'

----H0002/006 should have PBP Type as '0' in tbplan_pbp
----H1003/011 should have PBP Type as '1' in tbplan_pbp and IDType as "2" in tbPlans
----H1005/021 should have PBP Type as '1' in tbplan_pbp and IDType as "4" in tbPlans
----S2004/016 should have PBP Type as '2' in tbplan_pbp and IDType as "3" in tbPlans

 
 
select Multiple,* from tbplan_pbp

select * from tbplan_pbp where PlanID='H0002' and PBPID='006'
--Update tbplan_pbp Set PBPtype = 0 where PlanID='H0002' and PBPID='006'
select * from tbplan_pbp where PlanID='H1003' and PBPID='011'
select * from tbplan_pbp where PlanID='S2004' and PBPID='016'
select * from tbplan_pbp where PlanID='H1005' and PBPID='021'

select IDType , * from tbplans  where PlanID='H1003'
select IDType , * from tbplans  where PlanID='S2004'
select IDType , * from tbplans  where PlanID='H1005'


Select error from elecAppfile where filename = 'EAF_RxID1_20191801.txt'

select HIC,TransStatus,* from tbTRansactions where 
HIC in ('7A77C01AA04','7A77C01AA05','7A77C01AA06','7A77C01AA07','7A77C01AA08','7A77C01AA09','7A77C01AA10','7A77C01AA11','7A77C01AA12')


select HIC,MemberStatus,* from tbEEnrlMembers where 
HIC in ('7A77C01AA04','7A77C01AA05','7A77C01AA06','7A77C01AA07','7A77C01AA08','7A77C01AA09','7A77C01AA10','7A77C01AA11','7A77C01AA12')


select HIC,MemCodNUm,* from tbTRansactions where 
HIC in ('7A77C01AA08','7A77C01AA09','7A77C01AA10')

select RxID,* from tbMemberInfo where MemCodNum in ('20894','20895','20896')


select HIC,MemCodNUm,* from tbTRansactions where 
HIC in ('7A77C01AA05','7A77C01AA06','7A77C01AA07','7A77C01AA08','7A77C01AA09','7A77C01AA10','7A77C01AA13')
And TransCode='72'

select HIC,PlanID,PBP,MemberID,* from tbEEnrlMembers where 
HIC in ('7A77C01AA05','7A77C01AA06','7A77C01AA07','7A77C01AA08','7A77C01AA09','7A77C01AA10','7A77C01AA13')

Select RxID,* from tbMemberInfo Where MemCodNum = '20891'


select HIC,RxID,* from tbTRansactions where 
HIC in ('7A77C01AA05','7A77C01AA06','7A77C01AA07','7A77C01AA08','7A77C01AA09','7A77C01AA10','7A77C01AA13')And TransCode='72'


Select * from ElecAppFile order by loadeddate desc

Use EAMWarehouse
Select ErrorDesc,Filename,* from [dbo].[TrrImportReportingWarehouse] where ClaimNumber = '7A77C01AA13'

Select * from 
EAMWarehouse..[HistoryInputManagerTrrData] W Inner join
EAMWarehouse..[HistoryInputManagerEntities] E 
On W.EntityId = E.EntityId Inner join
EAMWarehouse..[HistoryInputManagerRequests] R
On E.RequestId = R.Requestid
Where W.ClaimNumber = '7A77C01AA13'