USe EAM
Select * from tbtransactions where hic like '2C77C03PR03'

Select * from tbeenrlmembers where hic in ('2C77C03PR03','2C77C03PR04','2C77C03PR05','2C77C03PR06','2C77C03PR07','8C77C03AA08','1C77C03PR03','1C77C03PR04','1C77C03PR05','1C77C03PR06','1C77C03PR07','1C77C03PR09')

Select multiple,* from tbplan_pbp

Update tbPlan_PBP Set multiple = 0

select Error,ApplicantHICN,* from elecappfile where filename = 'EAF_MultipleOff2_20200104.txt' and isprocessed = '0' order by ApplicantBirthDate 

select Error,ApplicantHICN,* from elecappfile where filename = 'EAF_MultipleOn2_20200105.txt' and isprocessed = '0' order by ApplicantBirthDate

select PlanID,PBPID,* from tbtransactions where hic in ('1C77C03PR88','1C77C03PF99','3E77C01PF66') 




Update elecappfile Set IsProcessed = 1, Error = ''  Where ApplicantHICN in ('1C77C03PR88', '1C77C03PF99', '3E77C03PF66')
Select error, isprocessed, * from elecAppfile where ApplicantHicn = '2C77C03PR55'

Update elecAppfile Set Error = 'Possible Duplicates. See the following HICs: 2C77C03PQ55' Where ApplicantHicn = '2C77C03PR55'
Update elecAppfile Set Error = 'Member is already enrolled or enrollment is pending in same plan.' Where ApplicantHicn = '8C77C03AA08'