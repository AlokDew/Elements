--No existing HIC with same 
Select * from tbtransactions where HIC like '%5A77C00AA%'

--Check Multiple Flag --0

Select multiple from tbplan_pbp

--Plan Check 

Update tbPlan_pbp Set PBPtype = 1 where PlanID = 'H0001' and PBPID = '005'

Select * From tbPlan_pbp b inner join tbPlans p
on b.PlanId = p.PlanId
Where p.PlanID in ('H0001','H1001','S2001')
And PBPID IN ('001','002','005')

--Load OEC file and verify nothing is fallout - 26 records fetched successfully.
Select Error,IsProcessed,ApplicantHICN,ContractID,* from ElecAppFile where filename = 'OEC_01012019_Console_Y04_HXXXX.txt'

---Verify in trnasaction and memeber level
Select T.HIC,T.PlanID,T.EffectiveDate,
T.ApplicationDate,T.EnrollmentPlanYear, TransStatus,T.ElectionType,T.SEPSReason as TransSepReason,M.SepReason as MemberSepReason
From Tbtransactions T Join tbmemberinfo M
On T.MemCodNum = M.MemCodNum Join ElecAppFile E
On T.HIC = E.ApplicantHICN 												
--Where T.TransStatus = 0
And
E.FileName = 'OEC_01012020_ETETE_TC61E1_HXXXX.txt'
Order by HIC

--- Spans Created 
Select T.HIC,StartDate, EndDate From tbENRLSpans S Join tbTransactions T
On T.MemCodNum = S.MemCodNum Join ElecAppFile E
On T.HIC = E.ApplicantHICN 												
Where E.FileName = 'OEC_01012019_Console_Y04_HXXXX.txt'
Order by HIC


--Export BEQ - H0001,H1001,H1002,S2001

---Verify in trnasaction status change to Passed BEQ and ET set Correctly with SepReasonCode
Select T.HIC,T.PlanID,T.EffectiveDate,T.ApplicationDate,T.EnrollmentPlanYear, TransStatus,ET.ElectionType,
R.Reason as TransSepReason,M.SepReason as MemberSepReason, T.IsElectionTypeManual
From Tbtransactions T Join tbmemberinfo M
On T.MemCodNum = M.MemCodNum Left Join TB_EAM_SEPS_REASON R
On T.SEPSReason = R.Reason_ID Left Join tbElectiontypes ET 
On T.ElectionType = ET.ElectTypeID Join ElecAppFile E
On T.HIC = E.ApplicantHICN 												
Where E.FileName = 'OEC_01012019_Console_Y04_HXXXX.txt'
And
T.TransStatus = 2
Order by HIC

-- Verify Records in Manual Queue
Select Q.Category,T.HIC from tbnotes Q Join tbtransactions T
On Q.Data = T.TransID Join ElecAppFile E
On T.HIC = E.ApplicantHICN
Where E.FileName = 'OEC_01012019_Console_Y04_HXXXX.txt'


Select TransID from tbtransactions where hic in ('1D77C00AA07','1D77C00AA13','1D77C00AA15','1D77C00AA17','1D77C00AA20','1D77C00AA23','1D77C00AA26')

Select * from tbnotes where data in ('107494','107500','107502','107504','107507','107510','107513')

--UI Verification
--1D77C00AA02,1D77C00AA06,1D77C00AA07,1D77C00AA10,1D77C00AA13,1D77C00AA18,1D77C00AA22,1D77C00AA25



Select * from tbElectiontypes Where ElectTypeID In (3,2,14,4,10)


