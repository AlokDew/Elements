--Remove 717 for all
exec BEQResponse_Generator '3A77C00AZ01',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20200101;
MedPartAEntEndDate=20211231;
MedPartBEntStartDate=20200101;
MedPartBEntEndDate=20211231;
PartDEligibilityStartDate=20210101;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'

exec BEQResponse_Generator '3A77C00AZ02',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20200101;
MedPartBEntStartDate=20200101;
PartDEligibilityStartDate=20200101;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'

exec BEQResponse_Generator '3A77C00AZ03',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20200101;
MedPartBEntStartDate=20200101;
PartDEligibilityStartDate=20210101;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'

exec BEQResponse_Generator '3A77C00AZ04',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20200101;
MedPartBEntStartDate=20200101;
PartDEligibilityStartDate=20210101;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'


exec BEQResponse_Generator '3A77C00AZ05',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20180101;
MedPartBEntStartDate=20180101;
PartDEligibilityStartDate=20200101;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'	

exec BEQResponse_Generator '3A77C00AZ06',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20180101;
MedPartBEntStartDate=20180101;
PartDEligibilityStartDate=20210101;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'	

exec BEQResponse_Generator '3A77C00AZ07',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20200101;
MedPartBEntStartDate=20200101;
PartDEligibilityStartDate=20211201;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'
