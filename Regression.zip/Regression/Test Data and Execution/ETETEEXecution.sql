--- Remove from force Review Queue

Use EAM Select * from tbNotes where Category in ('ICEP','AEP','MAOEP','IEP','IEP2','OEPI')

--Delete tbNotes where Category in ('ICEP','AEP','MAOEP','IEP','IEP2','OEPI')

--Verify No Transactions is with same MBI

Select * from tbTransactions where HIC like '9A77C00AA%'   --0 Result

Select multiple from tbplan_pbp


--EGHP Turn off fro plans

-- Make sure EnhanceDupeCheck OFF

--Verify Plan are per requirement

Update tbPlan_pbp Set PBPtype = 0 where PlanID = 'H0001' and PBPID = '002'

Select * From tbPlan_pbp 
Where PlanID In ('H0001') and PBPID In ('002','005')  --MA and MAPD

--Update tbPlan_pbp Set PBPtype = 1 Where PlanID = 'H0001' and PBPID = '005'

Select * From tbPlan_pbp 
Where PlanID In ('H1001','S2001') and PBPID In ('001')  --MAPD and PDP

--Verify TRR transactions loaded successfully

Select HIC,PlanID,PBPID,EffectiveDate,ElectionType,TransCode,TransStatus
From tbtransactions
where HIC like '9A77C00AA%' 

--Load OEC file and verify nothing is fallout - 22 records fetched successfully.
Select Error,IsProcessed,ApplicantHICN,ContractID,* 
From ElecAppFile
Where filename = 'OEC_01012020_ETETE_TC61E1_HXXXX1.txt'

Select Count(IsProcessed) as RecordCount
From ElecAppFile
Where IsProcessed = 1
And
Filename like 'OEC_01012020_ETETE_TC61E%'

---Verify in trnasaction and memeber level
Select T.HIC,T.PlanID,T.EffectiveDate,
T.ApplicationDate,T.EnrollmentPlanYear, TransStatus,T.ElectionType,M.SepReason as OECSepReason
From Tbtransactions T Join tbmemberinfo M
On T.MemCodNum = M.MemCodNum Join ElecAppFile E
On T.HIC = E.ApplicantHICN 												
Where T.TransStatus = 0
And
E.FileName = 'OEC_01012020_ETETE_TC61E1_HXXXX1.txt'
Order by HIC

--- Spans Created 
Select T.HIC,StartDate, EndDate From tbENRLSpans S Join tbTransactions T
On T.MemCodNum = S.MemCodNum Join ElecAppFile E
On T.HIC = E.ApplicantHICN 												
Where S.SpanType = 'SCC'
And 
T.TransStatus = 0
And
E.FileName = 'OEC_01012020_ETETE_TC61E1_HXXXX1.txt'
Order by HIC

---Verify in trnasaction status change to Passed BEQ and ET set Correctly with SepReasonCode
Select T.HIC,T.PlanID,T.EffectiveDate,T.ApplicationDate,T.EnrollmentPlanYear, TransStatus,ET.ElectionType,
M.SepReason as OECSepReason, T.IsElectionTypeManual
From Tbtransactions T Join tbmemberinfo M
On T.MemCodNum = M.MemCodNum Left Join TB_EAM_SEPS_REASON R
On T.SEPSReason = R.Reason_ID Left Join tbElectiontypes ET 
On T.ElectionType = ET.ElectTypeID Join ElecAppFile E
On T.HIC = E.ApplicantHICN 												
Where E.FileName = 'OEC_01012020_ETETE_TC61E1_HXXXX1.txt'
And
T.TransStatus = 2
Order by HIC

--Verify only Manual Queue records went into queue
Select T.HIC,Q.Category from tbnotes Q Join tbtransactions T
On Q.Data = T.TransID Join ElecAppFile E
On T.HIC = E.ApplicantHICN
Where E.FileName = 'OEC_01012020_ETETE_TC61E1_HXXXX1.txt'

-- Select * from tbnotes where data = '38729'


Select TransStatus, count(1) as TotalRecords from tbtransactions T Join ElecAppFile E
On T.HIC = E.Applicanthicn
Where 
E.FileName = 'OEC_01012020_ETETE_TC61E1_HXXXX1.txt'
Group By TransStatus

