--Execute this query on sql server. 
Select * From ConfigurationManagerTrcLepActionMap 
WHERE UpdateFieldMapId IN (SELECT UpdateFieldMapId
                           FROM
                               ConfigurationManagerActionUpdateFieldMap
                           WHERE 
                                   FieldId  = 61
                               AND ActionMapId in (select ActionMapId from ConfigurationManagerTcTrcActionMap where TransactionReplyCode = '290' )
                               AND [User] = 'Y')
--Execute attached script if above query do not return 3 rows. (Database which restore from R2 and apply dacpac first time do not need it)
--Let me know in case of query.

-----------------------------------------------------------------------------------------
DELETE ConfigurationManagerTrcLepActionMap 
WHERE UpdateFieldMapId IN (SELECT UpdateFieldMapId
                           FROM
                               ConfigurationManagerActionUpdateFieldMap
                           WHERE 
                                   FieldId  = 61
                               AND ActionMapId in (select ActionMapId from ConfigurationManagerTcTrcActionMap where TransactionReplyCode = '290' )
                               AND [User] = 'Y')

/* TRC 290 */
INSERT ConfigurationManagerTrcLepActionMap (UpdateFieldMapId, LepAmount, ActionId, DateCreated, UserCreated, DateModified, UserModified) 
select UpdateFieldMapId, 1, 2, GETDATE(), 'tmsadmin', GETDATE(), 'tmsadmin'
from
    ConfigurationManagerActionUpdateFieldMap
where 
        FieldId  = 61
    AND ActionMapId in (select ActionMapId from ConfigurationManagerTcTrcActionMap where TransactionReplyCode = '290' )
    AND [User] = 'Y'

INSERT ConfigurationManagerTrcLepActionMap (UpdateFieldMapId, LepAmount, ActionId, DateCreated, UserCreated, DateModified, UserModified) 
select UpdateFieldMapId, 2, 2, GETDATE(), 'tmsadmin', GETDATE(), 'tmsadmin'
from
    ConfigurationManagerActionUpdateFieldMap
where 
        FieldId  = 61
    AND ActionMapId in (select ActionMapId from ConfigurationManagerTcTrcActionMap where TransactionReplyCode = '290' )
    AND [User] = 'Y'

INSERT ConfigurationManagerTrcLepActionMap (UpdateFieldMapId, LepAmount, ActionId, DateCreated, UserCreated, DateModified, UserModified) 
select UpdateFieldMapId, 3, 3, GETDATE(), 'tmsadmin', GETDATE(), 'tmsadmin'
from
    ConfigurationManagerActionUpdateFieldMap
where 
        FieldId  = 61
    AND ActionMapId in (select ActionMapId from ConfigurationManagerTcTrcActionMap where TransactionReplyCode = '290' )
    AND [User] = 'Y'
