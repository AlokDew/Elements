
exec PIR_GetProviderAndPIR '88','','',0

exec PIR_GetProviderWithGroup '88','',''
exec PIR_GetProviderWithGroupAffiliation '88','',''

------------------------------------------------------------------------------------------------------
		---	 PREPARE DATA FOR GROUP AND AFFILIATION RAM - MANAGE SUSPECT SEARCH
------------------------------------------------------------------------------------------------------

--Step 1: Select Six (Group,Affliation) intClaimID  - 4457742,4457062,4455280,4455161,4454288,4452466
Select distinct Top 6 E.intClaimID,E.txtProviderID,E.stampdate,E.stampuser from tbDiags D Inner join tbExceptionLetters E
ON D.intClaimID = E.intClaimID Inner Join [tbProvider] P
On E.txtProviderID = P.txtProviderID 
Where D.intClaimID is Not Null 
Order by E.intClaimID Desc

--Step 2: Verify [tbProviderGroup] has records, If not then Insert records Step 3
Select * from [dbo].[tbProviderGroup]
--Delete [tbProviderGroup] where txtGroup = 'ABCD'

--Step 3: Updtae GroupID in Provider Table based upon Provider ID fetched in Step 1
Update [tbProvider] Set txtGRoupID = 'GRP001', IntStatus = 0 Where txtProviderID = '040426006761'
Update [tbProvider] Set txtGRoupID = 'GRP002', IntStatus = 0 Where txtProviderID = '040426006671'
Update [tbProvider] Set txtGRoupID = 'GRP003', IntStatus = 0 Where txtProviderID = '040426007694'
Update [tbProvider] Set txtGRoupID = 'AGRP001', IntStatus = 1 Where txtProviderID = '050818000005'
Update [tbProvider] Set txtGRoupID = 'AGRP002', IntStatus = 1 Where txtProviderID = '040426014251'
Update [tbProvider] Set txtGRoupID = 'AGRP003', IntStatus = 1 Where txtProviderID = '070820000013'

--Step 4: Make sure updated in Provider Table
Select * from [tbProvider] where txtGroupID <> '' 

--Step 5: Inser Records in to [tbProviderGroup] table by updting stamp date and user from Step 1

Insert into [tbProviderGroup] values ('88','GRP001','MangSusGrp1','ADD1','ADD2','MIAMI','FL','33134','','','','','2016-05-25 17:21:00','admin') 
Insert into [tbProviderGroup] values ('88','GRP002','MangSusGrp2','ADD1','ADD2','MIAMI','FL','33134','','','','','2016-05-25 17:21:00','admin') 
Insert into [tbProviderGroup] values ('88','GRP003','MangSusGrp3','ADD1','ADD2','MIAMI','FL','33134','','','','','2016-05-25 17:21:00','admin') 
Insert into [tbProviderGroup] values ('88','AGRP001','MangSusAffGrp1','ADD1','ADD2','NewYork','NY','10121','','','','','2016-05-25 17:21:00','admin') 
Insert into [tbProviderGroup] values ('88','AGRP002','MangSusAffGrp2','ADD1','ADD2','NewYork','NY','10121','','','','','2016-05-25 17:21:00','admin') 
Insert into [tbProviderGroup] values ('88','AGRP003','MangSusAffGrp3','ADD1','ADD2','NewYork','NY','10121','','','','','2016-05-25 17:21:00','admin') 

--Step 6: Update tbdiags for Group from based on records fetched from 1,2,3 in Step 1

Update tbDiags Set intSuspectStatus = '10' Where intClaimID = '4457742'
Update tbDiags Set intSuspectStatus = '10' Where intClaimID = '4457062'
Update tbDiags Set intSuspectStatus = '10' Where intClaimID = '4455280'




------------------------------------------------------------------------------------------------------
		---	 REMOVE DATA FOR GROUP AND AFFILIATION RAM - MANAGE SUSPECT SEARCH
------------------------------------------------------------------------------------------------------

Delete from [tbProviderGroup]