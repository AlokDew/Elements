How to run:

1.	Tms.Executables.ApplicationHost  - Run the Server (Owin Self Host) 
2.	Identity Manager: https://localhost:44330/idm/
3.	Identity Server: https://localhost:44330/ids/



In order to run the server, you should allow Owin Self host to run under HTTPS and install certificate.

There are 2 certificate under the solution. �wildcard.localhost.pfx� for the https and �idsrv3test.pfx�  for identity server.

=>	Installing certificates using MMC
	1. *.localhost.pfx - should be under trusted root certificate + personal
	2. idsrv3test.pfx - should be under personal + Trusted People
		Note! password is "12345"


=> 	Give permission to the user who run the application for idsrv3test.pfx on 		the certificate private key

=> 	set certificate in app.config for Ids 

6b 7a cc 52 03 05 bf db 4f 72 52 da eb 21 77 cc 09 1f aa e1


=>	Allow the application to open HTTPS
	[run CMD as administrator]

	> netsh http add urlacl url=https://+:44330/ user=Everyone

	> netsh http add sslcert ipport=0.0.0.0:44330 certhash=9C2A053A9067BC7D29D4A11AC66E1BCB9CDD86FA appid={214124cd-d05b-4309		-9af9-9caa44b2b74a}


